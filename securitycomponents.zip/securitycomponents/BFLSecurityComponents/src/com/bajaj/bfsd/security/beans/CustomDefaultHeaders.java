package com.bajaj.bfsd.security.beans;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;


@Component
@RequestScope
public class CustomDefaultHeaders {
	private String authtoken;
	private String cmptcorrid;
	private String guardtoken;
	private String src;
	private String pltfrm;
	private long usrkey;
	private String dfltRole;
	private String lgnId;
	private long applntId;

	public static final String AUTH_TOKEN = "authtoken";
	public static final String CMPTCORR_ID = "cmptcorrid";
	public static final String GUARD_TOKEN = "guardtoken";
	public static final String SOURCE = "source";
	public static final String PLATFORM = "platform";
	public static final String USERKEY = "userkey";
	public static final String DEFAULTROLE = "defaultrole";
	public static final String LOGINID = "loginid";
	public static final String APPLICANTID = "applicantid";
	

	public CustomDefaultHeaders() {
		//empty constructor
	}
	
	public CustomDefaultHeaders(CustomDefaultHeaders customDefaultHeader)
	{
		this.setAuthtoken(customDefaultHeader.getAuthtoken());
		this.setCmptcorrid(customDefaultHeader.getCmptcorrid());
		this.setGuardtoken(customDefaultHeader.getGuardtoken());
		this.setPlatform(customDefaultHeader.getPlatform());
		this.setSource(customDefaultHeader.getSource());
		this.setUserkey(customDefaultHeader.getUserKey());
		this.setDefaultRole(customDefaultHeader.getDefaultRole());
		this.setLoginid(customDefaultHeader.getLoginid());
		this.setApplntId(customDefaultHeader.getApplntId());
	}
	
	public String getAuthtoken() {
		return authtoken;
	}

	public void setAuthtoken(String authtoken) {
		this.authtoken = authtoken;
	}

	public String getCmptcorrid() {
		return cmptcorrid;
	}

	public void setCmptcorrid(String cmptcorrid) {
		this.cmptcorrid = cmptcorrid;
	}

	public String getGuardtoken() {
		return guardtoken;
	}

	public void setGuardtoken(String guardtoken) {
		this.guardtoken = guardtoken;
	}

	public String getSource() {
		return src;
	}

	public void setSource(String source) {
		this.src = source;
	}

	public String getPlatform() {
		return pltfrm;
	}

	public void setPlatform(String platform) {
		this.pltfrm = platform;
	}

	public long getUserKey() {
		return usrkey;
	}

	public void setUserkey(long userkey) {
		this.usrkey = userkey;
	}

	public void setCustomHeaders(HttpServletRequest req) {
		this.authtoken = req.getHeader(AUTH_TOKEN);
		this.cmptcorrid = req.getHeader(CMPTCORR_ID);
		this.guardtoken = req.getHeader(GUARD_TOKEN);
		this.src = req.getHeader(SOURCE);
		this.pltfrm = req.getHeader(PLATFORM);
		String userKeyStr = req.getHeader(USERKEY)==null?"0":req.getHeader(USERKEY);
		String userApplntId = req.getHeader(APPLICANTID)==null?"0":req.getHeader(APPLICANTID);

		try {
			this.usrkey = Long.parseLong(userKeyStr);
			this.applntId = Long.parseLong(userApplntId);
		} catch (Exception ex) {//NOSONAR
			// Not doing anything if userKey is not present then it will be set
			// to 0
		}
		// This is not expected to be there in header, but still trying to get it from there in case required in future.
		this.dfltRole = req.getHeader(DEFAULTROLE);
	}
	
	public String getDefaultRole() {
		return dfltRole;
	}

	public void setDefaultRole(String defaultRole) {
		this.dfltRole = defaultRole;
	}

	/**
	 * @return the loginid
	 */
	public String getLoginid() {
		return lgnId;
	}

	/**
	 * @param loginid the loginid to set
	 */
	public void setLoginid(String loginid) {
		this.lgnId = loginid;
	}

	/**
	 * @return the applntId
	 */
	public long getApplntId() {
		return applntId;
	}

	/**
	 * @param applntId the applntId to set
	 */
	public void setApplntId(long applntId) {
		this.applntId = applntId;
	}
}
