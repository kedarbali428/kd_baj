package com.bajaj.bfsd.security.beans;

public class BFLAuthorizationPolicy {
	private String uri;
	private String requestMethod;
	private boolean isAuthenticationRequired;
	private boolean isAuthorizationRequired;
	private String rolesStr;

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getRequestMethod() {
		return requestMethod;
	}

	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	public boolean getIsAuthenticationRequired() {
		return isAuthenticationRequired;
	}

	public void setIsAuthenticationRequired(String isAuthenticationRequired) {
		this.isAuthenticationRequired = false;

		if (null != isAuthenticationRequired) {
			this.isAuthenticationRequired = "Y".equalsIgnoreCase(isAuthenticationRequired.trim());
		}
	}

	public boolean getIsAuthorizationRequired() {
		return isAuthorizationRequired;
	}

	public void setIsAuthorizationRequired(String isAuthorizationRequired) {
		this.isAuthorizationRequired = false;

		if (null != isAuthorizationRequired) {
			this.isAuthorizationRequired = "Y".equalsIgnoreCase(isAuthorizationRequired.trim());
		}
	}

	public String getRolesStr() {
		return rolesStr;
	}

	public void setRoles(String roles) {
		this.rolesStr = roles;
		if (null != rolesStr)
			rolesStr.trim().toLowerCase();
	}

	public boolean isAuthorizationRequired() {
		if(!isAuthorizationRequired || null == rolesStr || rolesStr.isEmpty())
			return false;				
		return isAuthorizationRequired;
	}

	public boolean hasRole(String role) {
		if (null != role && this.rolesStr != null && this.rolesStr.indexOf(role.toLowerCase().trim()) >= 0) {
			return true;
		}
		return false;
	}
}
