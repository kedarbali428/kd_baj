package com.bajaj.bfsd.security.beans;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

@Component
@RequestScope
public class UserProfileBean {
	private long userid;
	private long userRoleKey;	
	private String defaultRole;

	public Long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public Long getUserRoleKey() {
		return userRoleKey;
	}

	public void setUserRoleKey(long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}	

	@Override
	public String toString() {
		return "userid: " + this.userid + ", userRoleKey: " + this.userRoleKey + ", defaultRole: " + this.defaultRole;
	}

	public String getDefaultRole() {
		return defaultRole;
	}

	public void setDefaultRole(String defaultRole) {
		this.defaultRole = defaultRole;
	}
}
