package com.bajaj.bfsd.security.beans;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class BFLAuthorizationPolicyMap {

	private Map<String, BFLAuthorizationPolicy> authMap;
	
	public BFLAuthorizationPolicyMap(){
		authMap = new HashMap<>();
	}
	public void setPolicyMap(Map<String, BFLAuthorizationPolicy> authMap){
		this.authMap = authMap;
	}
	
	public Map<String, BFLAuthorizationPolicy> getAuthMap(){
		return authMap;
	}
	
	public BFLAuthorizationPolicy getPolicy(String uri){
		BFLAuthorizationPolicy policy;
		// Not doing null and empty check to improve performance and expecting caller to check for it or hashmap to handle.
		policy = authMap.get(uri);
		return policy;
	}
	
	public void putPolicy(String uri, BFLAuthorizationPolicy policy){
		authMap.put(uri, policy);
	}
}

