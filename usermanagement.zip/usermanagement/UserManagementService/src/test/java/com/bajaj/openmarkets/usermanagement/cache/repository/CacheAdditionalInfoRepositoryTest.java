package com.bajaj.openmarkets.usermanagement.cache.repository;

import static org.mockito.Mockito.spy;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.openmarkets.usermanagement.cache.entity.CacheAdditionalInfo;

@SpringBootTest
@SpringBootConfiguration
public class CacheAdditionalInfoRepositoryTest {

	@InjectMocks
	CacheAdditionalInfoRepository cacheAdditionalInfoRepo;

	@Mock
	Environment env;

	@Mock
	RedisConfig redisConfig;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGet_withOutTtl() {
		SingleObjectCacheRepositoryImpl<String, CacheAdditionalInfo> cacheRepository = Mockito
				.mock(SingleObjectCacheRepositoryImpl.class);
		ReflectionTestUtils.setField(cacheAdditionalInfoRepo, "cacheRepository", cacheRepository);
		cacheAdditionalInfoRepo.get(1234l);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testSave() {
		SingleObjectCacheRepositoryImpl<String, CacheAdditionalInfo> cacheRepository = Mockito
				.mock(SingleObjectCacheRepositoryImpl.class);
		ReflectionTestUtils.setField(cacheAdditionalInfoRepo, "cacheRepository", cacheRepository);
		cacheAdditionalInfoRepo.save(1234l, new CacheAdditionalInfo(), 60);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGet() {
		SingleObjectCacheRepositoryImpl<String, CacheAdditionalInfo> cacheRepository = Mockito
				.mock(SingleObjectCacheRepositoryImpl.class);
		ReflectionTestUtils.setField(cacheAdditionalInfoRepo, "cacheRepository", cacheRepository);
		cacheAdditionalInfoRepo.get(1234l, 60);
	}

	@Test(expected = Exception.class)
	public void testGet_ForGetCacheRepo() {
		cacheAdditionalInfoRepo.get(1234l, 60);
	}

}
