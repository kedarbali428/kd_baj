package com.bajaj.openmarkets.usermanagement.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLExceptionHandler;
import com.bajaj.openmarkets.usermanagement.bean.UserRequest;
import com.bajaj.openmarkets.usermanagement.bean.UserResponse;
import com.bajaj.openmarkets.usermanagement.cache.entity.CacheAdditionalInfo;
import com.bajaj.openmarkets.usermanagement.service.OMUserManagementService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@SpringBootConfiguration
public class OMUserManagementControllerTest {

	@InjectMocks
	OMUserManagementController omUserManagementController;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	OMUserManagementService omUserManagementService;

	@Autowired
	Environment env;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(omUserManagementController)
				.setControllerAdvice(BFLExceptionHandler.class)
				.addPlaceholderValue("api.usermanagement.user.additionalprofile.POST.uri", "/v1/user")
				.addPlaceholderValue("api.usermanagement.user.additionalprofile.GET.uri", "/v1/user").build();
	}

	@Test
	public void testGetUser_PseudoUser() throws Exception {
		UserRequest userRequest = new UserRequest();
		userRequest.setUserType((short) 10);
		userRequest.setMobile("9999999999");
		userRequest.setApplicationKey(1234l);
		userRequest.setApplicantKey(1234l);
		Mockito.when(omUserManagementService.getUser(Mockito.any(UserRequest.class))).thenReturn(new UserResponse());

		mockMvc.perform(
				post("/v1/user").content(prepareRequestJsonString(userRequest)).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());

	}

	@Test
	public void testGetUser_PseudoVerifiedUser() throws Exception {
		UserRequest userRequest = new UserRequest();
		userRequest.setUserType((short) 11);
		userRequest.setMobile("9999999999");
		userRequest.setApplicationKey(1234l);
		Mockito.when(omUserManagementService.getUser(Mockito.any(UserRequest.class))).thenReturn(new UserResponse());

		mockMvc.perform(
				post("/v1/user").content(prepareRequestJsonString(userRequest)).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());

	}

	@Test
	public void testGetUser_CustomerUser() throws Exception {
		UserRequest userRequest = new UserRequest();
		userRequest.setUserType((short) 1);
		userRequest.setMobile("9999999999");
		userRequest.setDateOfBirth("1900-10-10");
		Mockito.when(omUserManagementService.getUser(Mockito.any(UserRequest.class))).thenReturn(new UserResponse());

		mockMvc.perform(
				post("/v1/user").content(prepareRequestJsonString(userRequest)).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());

	}

	@Test
	public void testGetUser_IncorrectDate() throws Exception {
		UserRequest userRequest = new UserRequest();
		userRequest.setDateOfBirth("10-10-1990");
		Mockito.when(omUserManagementService.getUser(Mockito.any(UserRequest.class))).thenReturn(new UserResponse());

		mockMvc.perform(
				post("/v1/user").content(prepareRequestJsonString(userRequest)).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest());

	}

	@Test
	public void testGetUser_BadRequest1() throws Exception {
		UserRequest userRequest = new UserRequest();
		userRequest.setUserType((short) 1);
		userRequest.setMobile("9999999999");
		Mockito.when(omUserManagementService.getUser(Mockito.any(UserRequest.class))).thenReturn(new UserResponse());

		mockMvc.perform(
				post("/v1/user").content(prepareRequestJsonString(userRequest)).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest());

	}

	@Test
	public void testGetUser_BadRequest2() throws Exception {
		UserRequest userRequest = new UserRequest();
		userRequest.setUserType((short) 10);
		userRequest.setMobile("9999999999");
		Mockito.when(omUserManagementService.getUser(Mockito.any(UserRequest.class))).thenReturn(new UserResponse());

		mockMvc.perform(
				post("/v1/user").content(prepareRequestJsonString(userRequest)).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest());

	}

	@Test
	public void testGetUser_FetchProfile() throws Exception {
		CacheAdditionalInfo additionalInfo = new CacheAdditionalInfo(1234l, 1234l, 1234l, null);

		Mockito.when(omUserManagementService.getUser(Mockito.anyLong())).thenReturn(additionalInfo);

		mockMvc.perform(get("/v1/user").param("userId", "1234").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	private String prepareRequestJsonString(Object requestObject) {
		String requestJson = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			requestJson = mapper.writeValueAsString(requestObject);
		} catch (JsonProcessingException e) {
		}
		return requestJson;
	}
}
