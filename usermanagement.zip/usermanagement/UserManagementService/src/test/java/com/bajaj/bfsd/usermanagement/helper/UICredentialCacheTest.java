package com.bajaj.bfsd.usermanagement.helper;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.dao.UserManagementDao;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bfl.common.exceptions.BFLBusinessException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = UICredentialCache.class)
public class UICredentialCacheTest {

	@InjectMocks
	UICredentialCache uiCredentialCache;

	@Mock
	UserManagementDao userManagementDao;
	
	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	Environment env;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.uiCredentialCache.initCache();

	}

	@Test
	public void getSystemUserTest() {
		UserLoginAccount userLoginAccount = new UserLoginAccount();
		List<UserLoginAccount> userLoginAccountList = new ArrayList<>();
		userLoginAccount.setLoginpwd("test1");
		userLoginAccount.setLoginid("test");
		userLoginAccountList.add(userLoginAccount);
		Map<String, UserLoginAccount> userMapresult = new HashMap<>();
		userMapresult.put("test", userLoginAccount);
		ReflectionTestUtils.setField(uiCredentialCache, "userLoginAccountList", userLoginAccountList);
		ReflectionTestUtils.setField(uiCredentialCache, "userMapresult", userMapresult);
		Mockito.when(userManagementDao.getSystemUsers()).thenReturn(userLoginAccountList);
		userLoginAccount = uiCredentialCache.getSystemUser("test");
		assertEquals(userLoginAccount, userLoginAccount);

	}

	@Test(expected = BFLBusinessException.class)
	public void getSystemUserTestListAsNullFailure() {
		UserLoginAccount userLoginAccount = new UserLoginAccount();
		List<UserLoginAccount> userLoginAccountList = new ArrayList<>();
		userLoginAccount.setLoginpwd("test1");
		userLoginAccount.setLoginid("test");
		userLoginAccountList.add(userLoginAccount);
		Map<String, UserLoginAccount> userMapresult = new HashMap<>();
		userMapresult.put("test", userLoginAccount);
		ReflectionTestUtils.setField(uiCredentialCache, "userLoginAccountList", userLoginAccountList);
		ReflectionTestUtils.setField(uiCredentialCache, "userMapresult", userMapresult);
		Mockito.when(userManagementDao.getSystemUsers()).thenReturn(userLoginAccountList);
		uiCredentialCache.getSystemUser("test1");

	}

}
