package com.bajaj.bfsd.usermanagement.dao.impl;

import static org.junit.Assert.assertNotNull;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.FacebookProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;
import com.bajaj.bfsd.usermanagement.model.UserSocialProfileFacebook;
import com.bfl.common.exceptions.BFLBusinessException;

@SpringBootTest
public class FacebookDaoImplTest {

	@InjectMocks
	private FacebookDaoImpl fbDaoImpl;
	
	@Mock
    private BFLLoggerUtil logger;
	
	@Mock
	EntityManager entityManager;
	
	@Mock
	private Environment env;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}


	@Test(expected = Test.None.class)
	public void testSaveProfile() {
		
		FacebookProfileBean profileBean = new FacebookProfileBean();
		
		Query mockedQuery = Mockito.mock(Query.class);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString()))
				.thenReturn(mockedQuery);
		fbDaoImpl.saveProfile(profileBean, 1234L, "some response");
	}

	@Test
	public void testGetUserProfile() {
		
		UserSocialProfileFacebook facebookEntity = new UserSocialProfileFacebook();
		
		Query mockedQuery = Mockito.mock(Query.class);
		Mockito.when(entityManager.createQuery(Mockito.anyString()))
			.thenReturn(mockedQuery);
		Mockito.when(mockedQuery.getSingleResult()).thenReturn(facebookEntity);
		UserProfileBean userProfile = fbDaoImpl.getUserProfile(1234L);
		assertNotNull(userProfile);
	}
	
	@Test
	public void testGetUserProfile_NoResultException() {
		
		Query mockedQuery = Mockito.mock(Query.class);
		Mockito.when(entityManager.createQuery(Mockito.anyString()))
			.thenReturn(mockedQuery);
		Mockito.when(mockedQuery.getSingleResult()).thenThrow(NoResultException.class);
		UserProfileBean userProfile = fbDaoImpl.getUserProfile(1234L);
		assertNotNull(userProfile);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testGetUserProfile_NonUniqueResultException() {
				
		Query mockedQuery = Mockito.mock(Query.class);
		Mockito.when(entityManager.createQuery(Mockito.anyString()))
			.thenReturn(mockedQuery);
		Mockito.when(mockedQuery.getSingleResult()).thenThrow(NonUniqueResultException.class);
		fbDaoImpl.getUserProfile(1234L);
	}

	
}
