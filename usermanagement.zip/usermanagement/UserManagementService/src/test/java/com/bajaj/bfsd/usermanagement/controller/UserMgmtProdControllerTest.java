package com.bajaj.bfsd.usermanagement.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserProdMappingBean;
import com.bajaj.bfsd.usermanagement.model.ProductMaster;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataPluginMapper;
import com.bajaj.bfsd.usermanagement.service.UserMgmtProdService;

@RunWith(PowerMockRunner.class)
public class UserMgmtProdControllerTest {

	@InjectMocks
	UserMgmtProdController userMgmtProdController;
	
	@Mock
	UserMgmtProdService userMgmtProdService;

	@Mock
	BFLLoggerUtil bflLoggerUtil;

	@Mock
	OMMasterDataPluginMapper omMasterDataPluginMapper;
	
	@Mock
	HttpHeaders headers;
	
	@Test
	public void getUserInformationTest() {
		UserConfigurationBean userConfiguration = new UserConfigurationBean();
		Mockito.when(userMgmtProdService.getUserDetails(Mockito.any(),Mockito.any())).thenReturn(userConfiguration);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getUserInformation(userConfiguration, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void saveUserMappingTest() {
		UserProdMappingBean userMappingBean = new UserProdMappingBean();
		userMappingBean.setProdMastKey(123L);
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("OMINS");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(userMgmtProdService.saveUserMappingForOMInsurance(Mockito.any(), Mockito.any())).thenReturn(123L);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.saveUserMapping(userMappingBean, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void saveUserMappingTest_1() {
		UserProdMappingBean userMappingBean = new UserProdMappingBean();
		userMappingBean.setProdMastKey(123L);
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("OMCREDIT");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(userMgmtProdService.savePrincipalUserMapping(Mockito.any(), Mockito.any())).thenReturn(123L);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.saveUserMapping(userMappingBean, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void saveUserMappingTest_2() {
		UserProdMappingBean userMappingBean = new UserProdMappingBean();
		userMappingBean.setProdMastKey(123L);
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("TEST");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(userMgmtProdService.saveUserMappingForOMInsurance(Mockito.any(), Mockito.any())).thenReturn(123L);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.saveUserMapping(userMappingBean, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void saveUserMappingTest_3() {
		UserProdMappingBean userMappingBean = new UserProdMappingBean();
		userMappingBean.setProdMastKey(123L);
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(12345L);
		productMaster.setProdmastcode("OMINS");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(userMgmtProdService.saveUserMappingForOMInsurance(Mockito.any(), Mockito.any())).thenReturn(123L);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.saveUserMapping(userMappingBean, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getUserSuperVisorTest(){
		List<SupervisorBean> user = new ArrayList<>();
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("OMINS");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(userMgmtProdService.getUserSuperVisorForOmInsurance(Mockito.anyLong(), Mockito.anyLong(), Mockito.any(),Mockito.any())).thenReturn(user);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getUserSuperVisor(123L, 123L, 123L,"123", headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getUserSuperVisorTest_1(){
		List<SupervisorBean> user = new ArrayList<>();
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("OMINS1");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(userMgmtProdService.getUserSuperVisor(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(user);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getUserSuperVisor(123L, 123L, 123L,"12,12", headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getUserSuperVisorTest_2(){
		List<SupervisorBean> user = new ArrayList<>();
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("OMINS");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(userMgmtProdService.getUserSuperVisorForOmInsurance(Mockito.anyLong(), Mockito.anyLong(), Mockito.any(),Mockito.any())).thenReturn(user);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getUserSuperVisor(1234L, 1234L, 1234L,"12,12", headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getSuperVisorLocationsTest() {
		List<LocationBean> bflBranchList = new ArrayList<>();
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("OMINS");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(omMasterDataPluginMapper.findSuperVisorLocation(Mockito.anyLong(), Mockito.any())).thenReturn(bflBranchList);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getSuperVisorLocations(12L, 123L,123L,123L, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getSuperVisorLocationsTest_1() {
		List<LocationBean> bflBranchList = new ArrayList<>();
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("OMCREDIT");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(omMasterDataPluginMapper.findSuperVisorLocation(Mockito.anyLong(), Mockito.any())).thenReturn(bflBranchList);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getSuperVisorLocations(12L, 123L,123L,123L, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getSuperVisorLocationsTest_2() {
		List<LocationBean> bflBranchList = new ArrayList<>();
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("TEST");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(userMgmtProdService.getSuperVisorLocations(Mockito.anyLong())).thenReturn(bflBranchList);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getSuperVisorLocations(12L, 123L,123L,123L, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getSuperVisorLocationsTest_3() {
		List<LocationBean> bflBranchList = new ArrayList<>();
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("TEST");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(userMgmtProdService.getSuperVisorLocations(Mockito.anyLong())).thenReturn(bflBranchList);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getSuperVisorLocations(12L, null,123L,123L, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getSuperVisorLocationsTest_4() {
		List<LocationBean> bflBranchList = new ArrayList<>();
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(1234L);
		productMaster.setProdmastcode("OMINS");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(omMasterDataPluginMapper.findSuperVisorLocation(Mockito.anyLong(), Mockito.any())).thenReturn(bflBranchList);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getSuperVisorLocations(12L, 123L,123L,123L, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getSuperVisorChannelsTest() {
		List<ChannelBean> bflChannelList = new ArrayList<>();
		Mockito.when(userMgmtProdService.getSuperVisorChannels(Mockito.anyLong())).thenReturn(bflChannelList);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getSuperVisorChannels(123L, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getUserMappingDetailsTest() {
		List<UserProdMappingBean> list = new ArrayList<>();
		Mockito.when(userMgmtProdService.getUserMappingDetails(Mockito.anyLong(),Mockito.any())).thenReturn(list);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.getUserMappingDetails(123L,12L, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void deleteUserMappingTest() {
		Mockito.when(userMgmtProdService.deleteUserMapping(Mockito.anyLong(),Mockito.anyLong(),Mockito.any())).thenReturn(true);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.deleteUserMapping(123L,123L, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void updateUserMappingTest(){
		UserProdMappingBean userMappingBean = new UserProdMappingBean();
		Mockito.when(userMgmtProdService.saveUserMapping(Mockito.any(),Mockito.any())).thenReturn(123L);
		ResponseEntity<ResponseBean> responseEntity = userMgmtProdController
				.updateUserMapping(userMappingBean, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
}
