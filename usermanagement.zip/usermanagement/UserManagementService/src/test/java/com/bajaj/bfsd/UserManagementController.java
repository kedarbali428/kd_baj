package com.bajaj.bfsd;

public class UserManagementController {

}
