package com.bajaj.bfsd.usermanagement.service.impl;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.service.UserMgmtProdService;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserMgmtServiceCoreImplTest {

	@InjectMocks
	private UserMgmtServiceCoreImpl userMgmtServiceCoreImpl;
	
	@Mock
	private UserMgmtProdService userMgmtProdService;

	
	@Test
	public void testGetUserAttributes() {
		UserConfigurationBean userConfigBean = new UserConfigurationBean();
		Mockito.when(userMgmtProdService.getUserDetails(Mockito.any(UserConfigurationBean.class), Mockito.any(HttpHeaders.class)))
				.thenReturn(userConfigBean);
		
		assertNotNull(userMgmtServiceCoreImpl.getUserAttributes(new UserConfigurationBean(), new HttpHeaders()));
	}

	@Test
	public void testGetAdditionalUserAttributes() {
		UserConfigurationBean configBean = new UserConfigurationBean();
		Mockito.when(userMgmtProdService.getAdditionalUserDetails(Mockito.any(UserConfigurationBean.class)))
				.thenReturn(configBean);
		assertNotNull(userMgmtServiceCoreImpl.getAdditionalUserAttributes(new UserConfigurationBean()));

	}
}
