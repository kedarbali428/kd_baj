package com.bajaj.bfsd.usermanagement.dao.impl;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import javax.persistence.EntityManager;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;

@RunWith(PowerMockRunner.class)
public class AppViewDefinitionDaoImplTest {
	
	@InjectMocks
	AppViewDefinitionDaoImpl appViewDefinitionDaoImpl;
	
	@Mock
	Environment environment;
	
	@Mock
	EntityManager entityManager;
	
	@Test
	public void testCreateAndSaveAppViewDefinition() {
		Mockito.when(environment.getProperty(Mockito.any())).thenReturn("");
		appViewDefinitionDaoImpl.createAndSaveAppViewDefinition(1l, 1, 1l, "");
		verify(environment, times(4)).getProperty(Mockito.any());
	}

}
