package com.bajaj.bfsd.usermanagement.util;

import org.junit.Test;

import com.openpojo.validation.Validator;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.rule.impl.GetterMustExistRule;
import com.openpojo.validation.rule.impl.SetterMustExistRule;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;

public class PojoTest {
	private String modelPackageName = "com.bajaj.bfsd.usermanagement.model";
	@Test
	public void validateModel() {
		Validator validator = ValidatorBuilder.create().with(new SetterTester(), new GetterTester()).build();
		validator.validate(modelPackageName);
	}

	private String beanPackageName = "com.bajaj.bfsd.usermanagement.bean";
	@Test
	public void validateBean() {
		Validator validator = ValidatorBuilder.create().with(new SetterTester(), new GetterTester()).build();
		validator.validate(beanPackageName);
	}

	private String entityPackageName = "com.bajaj.openmarkets.usermanagement.cache.entity";
	@Test
	public void validateOpenmarketsEntity() {
		Validator validator = ValidatorBuilder.create().with(new SetterTester(), new GetterTester()).build();
		validator.validate(entityPackageName);
	}

	private String openmarketsBeanPackageName = "com.bajaj.openmarkets.usermanagement.bean";
	@Test
	public void validateOpenmarketsBean() {
		Validator validator = ValidatorBuilder.create().with(new SetterMustExistRule(), new GetterMustExistRule())
				.with(new SetterTester(), new GetterTester()).build();
		validator.validate(openmarketsBeanPackageName);
	}
}