package com.bajaj.bfsd.usermanagement.service.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserProdMappingBean;
import com.bajaj.bfsd.usermanagement.dao.UserMgmtProdDao;
import com.bajaj.bfsd.usermanagement.model.BfsdFunction;
import com.bajaj.bfsd.usermanagement.model.BfsdFunctionProduct;
import com.bajaj.bfsd.usermanagement.model.BfsdFunctionRole;
import com.bajaj.bfsd.usermanagement.model.BfsdRoleMaster;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.LoanProduct;
import com.bajaj.bfsd.usermanagement.model.ProductCategory;
import com.bajaj.bfsd.usermanagement.model.ProductMaster;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bajaj.bfsd.usermanagement.model.UserRoleChannelL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleLocationL3;
import com.bajaj.bfsd.usermanagement.model.UserRolePinCodeL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleProductL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleProductType;
import com.bajaj.bfsd.usermanagement.model.UserRoleUtmSourceChannel;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataInsurancePluginMapper;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataPluginMapper;
import com.bfsd.om.bean.UserRoleLocationsBean;
import com.bfsd.om.bean.UserRoleProductBean;
import com.bfsd.om.bean.UserRoleProductTypeBean;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserMgmtProdServiceImplTest {

	@InjectMocks
	UserMgmtProdServiceImpl userMgmtProdServiceImpl;
	
	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	OMMasterDataInsurancePluginMapper oMMasterDataInsurancePluginMapper;
	
	@Mock
	OMMasterDataPluginMapper omMasterDataPluginMapper;
	
	@Mock
	HttpHeaders headers;  
	
	@Mock
	UserMgmtProdDao userMgmtProdDao;
	
	@Mock
	UserProfileBean upb;
	
	@Mock
	Query query;

	@Mock
	EntityManager entityManager;
	
	@Test
	public void getUserSuperVisorForOmInsuranceTest() {
		List<SupervisorBean> supervisorList = new ArrayList<>();
		SupervisorBean supervisorBean=new SupervisorBean();
		supervisorBean.setHighestRole(true);
		supervisorBean.setId(12L);
		supervisorBean.setName("bnm");
		supervisorBean.setUserRoleKey(234L);
		supervisorBean.setUserRoleProdKey(234L);
		supervisorList.add(supervisorBean);
		Mockito.when(oMMasterDataInsurancePluginMapper.
				getUserSuperVisor(Mockito.anyLong(), Mockito.anyLong(), Mockito.any(),Mockito.any())).thenReturn(supervisorList);
		userMgmtProdServiceImpl.getUserSuperVisorForOmInsurance(123L, 123L, "123", headers);
		assertNotNull(supervisorList);
	}
	
	@Test
	public void getUserSuperVisorForOmCreditTest() {
		List<SupervisorBean> supervisorList = new ArrayList<>();
		SupervisorBean supervisorBean=new SupervisorBean();
		supervisorBean.setHighestRole(true);
		supervisorBean.setId(12L);
		supervisorBean.setName("bnm");
		supervisorBean.setUserRoleKey(234L);
		supervisorBean.setUserRoleProdKey(234L);
		supervisorList.add(supervisorBean);
		Mockito.when(omMasterDataPluginMapper.
				getUserSuperVisor(Mockito.anyLong(), Mockito.anyLong(), Mockito.any(),Mockito.any())).thenReturn(supervisorList);
		userMgmtProdServiceImpl.getUserSuperVisorForOmCredit(123L, 123L, "123", headers);
		assertNotNull(supervisorList);
	}
	
	@Test
	public void savePrincipalUserMappingForOMInsuranceTest_not0() {
		UserProdMappingBean inputBean=new UserProdMappingBean();
		inputBean.setUserRoleProdKey(10L);
		inputBean.setCreditLimit(BigDecimal.ONE);
		inputBean.setEmployeeType("dealer");
		inputBean.setFunctionKey(7L);
		inputBean.setHighRole(true);
		inputBean.setLoanProdKey(5L);
		inputBean.setProdCatKey(23L);
		inputBean.setProdMastKey(89L);
		inputBean.setRoleCode("roleCode");
		inputBean.setRoleKey(0L);
		inputBean.setSupervisorRoleProdKey(1234L);
		List<Long> userChannelKey=new ArrayList<Long>();
		userChannelKey.add(1L);
		inputBean.setUserChannelKey(userChannelKey);
		inputBean.setUserKey(1234L);
		List<Long> userLocKey=new ArrayList<Long>();
		userLocKey.add(2L);
		inputBean.setUserLocKey(userLocKey);
		List<Long> userPinCdKey=new ArrayList<Long>();
		userPinCdKey.add(3L);
		inputBean.setUserPinCdKey(userPinCdKey);
		List<Long> utmMastKey=new ArrayList<Long>();
		utmMastKey.add(4L);
		inputBean.setUtmMastKey(utmMastKey);
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		BfsdRoleMaster bfsdRoleMaster=new BfsdRoleMaster();
		List<UserRole> userRoles=new ArrayList<UserRole>();
		UserRole userRole1=new UserRole();
		userRole1.setUserrolekey(256L);
		BfsdUser bfsduser=new BfsdUser();
		bfsduser.setUserkey(123L);
		userRole1.setBfsduser(bfsduser);
		userRoles.add(userRole1);
		bfsdRoleMaster.setUserRoles(userRoles);;
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		userRole.setBfsduser(bfsduser);
		userRole.setCreditlimit(BigDecimal.ONE);
		userRole.setIsactive(1L);
		userRole.setLstupdateby("lstupdateby");
		userRole.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRole.setParentuser(2L);
		userRole.setUserrolekey(22L);
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
		userRole.setUserRoleProducts(userRoleProducts);
		UserRoleProductBean omBean=new UserRoleProductBean();
		omBean.setUserrolekey(123L);
		omBean.setLstupdateby("lstupdateby");
		omBean.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		omBean.setProdCatKey(122L);
		omBean.setProdmastkey(89L);
		omBean.setSubprodkey(123L);
		omBean.setUserprodkey(123L);
		List<UserRoleLocationsBean> userRoleLocations=new ArrayList<UserRoleLocationsBean>();
		omBean.setUserRoleLocations(userRoleLocations);
		List<UserRoleProductTypeBean> userRoleProductTypes=new ArrayList<UserRoleProductTypeBean>();
		omBean.setUserRoleProductTypes(userRoleProductTypes);
		
		Mockito.when(oMMasterDataInsurancePluginMapper.findUserRoleProduct(Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(omBean);
		Mockito.when( userMgmtProdDao.findUserRoleKey(omBean.getUserrolekey())).thenReturn(userRole);
		Mockito.when( userMgmtProdDao.saveUserMapping(Mockito.any())).thenReturn(userRole);
		Mockito.when(oMMasterDataInsurancePluginMapper.saveUserRoleMapping(Mockito.any(),
				Mockito.any())).thenReturn(omBean);
		long ans=userMgmtProdServiceImpl.saveUserMappingForOMInsurance(inputBean, headers);
	}
	@Test
	public void savePrincipalUserMappingForOMInsuranceTest_0() {
		UserProdMappingBean inputBean=new UserProdMappingBean();
		List<Long> l3ProdKeys=new ArrayList<Long>();
		l3ProdKeys.add(26L);
		inputBean.setL3ProdKeys(l3ProdKeys);
		inputBean.setUserRoleProdKey(0L);
		inputBean.setCreditLimit(BigDecimal.ONE);
		inputBean.setEmployeeType("dealer");
		inputBean.setFunctionKey(7L);
		inputBean.setHighRole(true);
		inputBean.setLoanProdKey(5L);
		inputBean.setProdCatKey(23L);
		inputBean.setProdMastKey(89L);
		inputBean.setRoleCode("roleCode");
		inputBean.setRoleKey(256L);
		inputBean.setSupervisorRoleProdKey(1234L);
		List<Long> userChannelKey=new ArrayList<Long>();
		userChannelKey.add(1L);
		inputBean.setUserChannelKey(userChannelKey);
		inputBean.setUserKey(1234L);
		inputBean.setRoleKey(23L);
		List<Long> userLocKey=new ArrayList<Long>();
		userLocKey.add(2L);
		inputBean.setUserLocKey(userLocKey);
		List<Long> userPinCdKey=new ArrayList<Long>();
		userPinCdKey.add(3L);
		inputBean.setUserPinCdKey(userPinCdKey);
		List<Long> utmMastKey=new ArrayList<Long>();
		utmMastKey.add(4L);
		inputBean.setUtmMastKey(utmMastKey);
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		BfsdRoleMaster bfsdRoleMaster=new BfsdRoleMaster();
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		BfsdUser bfsduser=new BfsdUser();
		userRole.setBfsduser(bfsduser);
		userRole.setCreditlimit(BigDecimal.ONE);
		userRole.setIsactive(1L);
		userRole.setLstupdateby("lstupdateby");
		userRole.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRole.setParentuser(2L);
		userRole.setUserrolekey(22L);
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
		userRole.setUserRoleProducts(userRoleProducts);
		UserRoleProductBean userRoleProduct=new UserRoleProductBean();
		userRoleProduct.setUserrolekey(123L);
		userRoleProduct.setLstupdateby("lstupdateby");
		userRoleProduct.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProduct.setProdCatKey(122L);
		userRoleProduct.setProdmastkey(89L);
		userRoleProduct.setSubprodkey(123L);
		userRoleProduct.setUserprodkey(123L);
		userRoleProduct.setUserrolekey(123L);
		List<UserRoleLocationsBean> userRoleLocations=new ArrayList<UserRoleLocationsBean>();
		userRoleProduct.setUserRoleLocations(userRoleLocations);
		List<UserRoleProductTypeBean> userRoleProductTypes=new ArrayList<UserRoleProductTypeBean>();
		userRoleProduct.setUserRoleProductTypes(userRoleProductTypes);
		Mockito.when(userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), inputBean.getRoleKey())).thenReturn(userRole);
		
		UserRoleProductBean omBean=new UserRoleProductBean();
		Mockito.when(oMMasterDataInsurancePluginMapper.findUserRoleProduct(Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(omBean);
		Mockito.when( userMgmtProdDao.findUserRoleKey(userRoleProduct.getUserrolekey())).thenReturn(userRole);
		long ans=userMgmtProdServiceImpl.saveUserMappingForOMInsurance(inputBean, headers);
	}
	
	@Test
	public void savePrincipalUserMappingForOMInsuranceTest_0_1() {
		UserProdMappingBean inputBean=new UserProdMappingBean();
		inputBean.setUserRoleProdKey(0L);
		inputBean.setCreditLimit(BigDecimal.ONE);
		inputBean.setEmployeeType("dealer");
		inputBean.setFunctionKey(7L);
		inputBean.setHighRole(true);
		inputBean.setLoanProdKey(5L);
		inputBean.setProdCatKey(23L);
		inputBean.setProdMastKey(89L);
		inputBean.setRoleCode("roleCode");
		inputBean.setRoleKey(256L);
		inputBean.setSupervisorRoleProdKey(1234L);
		List<Long> userChannelKey=new ArrayList<Long>();
		userChannelKey.add(1L);
		inputBean.setUserChannelKey(userChannelKey);
		inputBean.setUserKey(1234L);
		inputBean.setRoleKey(23L);
		List<Long> userLocKey=new ArrayList<Long>();
		userLocKey.add(2L);
		inputBean.setUserLocKey(userLocKey);
		List<Long> userPinCdKey=new ArrayList<Long>();
		userPinCdKey.add(3L);
		inputBean.setUserPinCdKey(userPinCdKey);
		List<Long> utmMastKey=new ArrayList<Long>();
		utmMastKey.add(4L);
		inputBean.setUtmMastKey(utmMastKey);
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		BfsdRoleMaster bfsdRoleMaster=new BfsdRoleMaster();
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		BfsdUser bfsduser=new BfsdUser();
		userRole.setBfsduser(bfsduser);
		userRole.setCreditlimit(BigDecimal.ONE);
		userRole.setIsactive(1L);
		userRole.setLstupdateby("lstupdateby");
		userRole.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRole.setParentuser(2L);
		userRole.setUserrolekey(22L);
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
		userRole.setUserRoleProducts(userRoleProducts);
		UserRoleProductBean userRoleProduct=new UserRoleProductBean();
		userRoleProduct.setUserrolekey(123L);
		userRoleProduct.setLstupdateby("lstupdateby");
		userRoleProduct.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProduct.setProdCatKey(122L);
		userRoleProduct.setProdmastkey(89L);
		userRoleProduct.setSubprodkey(123L);
		userRoleProduct.setUserprodkey(123L);
		userRoleProduct.setUserrolekey(123L);
		Mockito.when(userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), inputBean.getRoleKey())).thenReturn(userRole);
		
		UserRoleProductBean omBean=null;
		Mockito.when(oMMasterDataInsurancePluginMapper.findUserRoleProduct(Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(omBean);
		Mockito.when( userMgmtProdDao.findUserRoleKey(userRoleProduct.getUserrolekey())).thenReturn(userRole);
		Mockito.when(oMMasterDataInsurancePluginMapper.saveUserRoleMapping(Mockito.any(),Mockito.any())).thenReturn(userRoleProduct);
		
		long ans=userMgmtProdServiceImpl.saveUserMappingForOMInsurance(inputBean, headers);
	}
	
	@Test
	public void savePrincipalUserMappingTest_not0() {
		UserProdMappingBean inputBean=new UserProdMappingBean();
		inputBean.setUserRoleProdKey(10L);
		inputBean.setCreditLimit(BigDecimal.ONE);
		inputBean.setEmployeeType("dealer");
		inputBean.setFunctionKey(7L);
		inputBean.setHighRole(true);
		inputBean.setLoanProdKey(5L);
		inputBean.setProdCatKey(23L);
		inputBean.setProdMastKey(89L);
		inputBean.setRoleCode("roleCode");
		inputBean.setRoleKey(0L);
		inputBean.setSupervisorRoleProdKey(1234L);
		List<Long> userChannelKey=new ArrayList<Long>();
		userChannelKey.add(1L);
		inputBean.setUserChannelKey(userChannelKey);
		inputBean.setUserKey(1234L);
		List<Long> userLocKey=new ArrayList<Long>();
		userLocKey.add(2L);
		inputBean.setUserLocKey(userLocKey);
		List<Long> userPinCdKey=new ArrayList<Long>();
		userPinCdKey.add(3L);
		inputBean.setUserPinCdKey(userPinCdKey);
		List<Long> utmMastKey=new ArrayList<Long>();
		utmMastKey.add(4L);
		inputBean.setUtmMastKey(utmMastKey);
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		BfsdRoleMaster bfsdRoleMaster=new BfsdRoleMaster();
		List<UserRole> userRoles=new ArrayList<UserRole>();
		UserRole userRole1=new UserRole();
		userRole1.setUserrolekey(256L);
		BfsdUser bfsduser=new BfsdUser();
		bfsduser.setUserkey(123L);
		userRole1.setBfsduser(bfsduser);
		userRoles.add(userRole1);
		bfsdRoleMaster.setUserRoles(userRoles);;
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		userRole.setBfsduser(bfsduser);
		userRole.setCreditlimit(BigDecimal.ONE);
		userRole.setIsactive(1L);
		userRole.setLstupdateby("lstupdateby");
		userRole.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRole.setParentuser(2L);
		userRole.setUserrolekey(22L);
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
		userRole.setUserRoleProducts(userRoleProducts);
		UserRoleProductBean omBean=new UserRoleProductBean();
		omBean.setUserrolekey(123L);
		omBean.setLstupdateby("lstupdateby");
		omBean.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		omBean.setProdCatKey(122L);
		omBean.setProdmastkey(89L);
		omBean.setSubprodkey(123L);
		omBean.setUserprodkey(123L);
		List<UserRoleLocationsBean> userRoleLocations=new ArrayList<UserRoleLocationsBean>();
		omBean.setUserRoleLocations(userRoleLocations);
		List<UserRoleProductTypeBean> userRoleProductTypes=new ArrayList<UserRoleProductTypeBean>();
		omBean.setUserRoleProductTypes(userRoleProductTypes);
		
		Mockito.when(omMasterDataPluginMapper.findUserRoleProduct(Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(omBean);
		Mockito.when( userMgmtProdDao.findUserRoleKey(omBean.getUserrolekey())).thenReturn(userRole);
		Mockito.when( userMgmtProdDao.saveUserMapping(Mockito.any())).thenReturn(userRole);
		Mockito.when(omMasterDataPluginMapper.saveUserRoleMapping(Mockito.any(),
				Mockito.any())).thenReturn(omBean);
		long ans=userMgmtProdServiceImpl.savePrincipalUserMapping(inputBean, headers);
	}
	
	@Test
	public void savePrincipalUserMappingTest_0_1() {
		UserProdMappingBean inputBean=new UserProdMappingBean();
		inputBean.setUserRoleProdKey(0L);
		inputBean.setCreditLimit(BigDecimal.ONE);
		inputBean.setEmployeeType("dealer");
		inputBean.setFunctionKey(7L);
		inputBean.setHighRole(true);
		inputBean.setLoanProdKey(5L);
		inputBean.setProdCatKey(23L);
		inputBean.setProdMastKey(89L);
		inputBean.setRoleCode("roleCode");
		inputBean.setRoleKey(256L);
		inputBean.setSupervisorRoleProdKey(1234L);
		List<Long> userChannelKey=new ArrayList<Long>();
		userChannelKey.add(1L);
		inputBean.setUserChannelKey(userChannelKey);
		inputBean.setUserKey(1234L);
		inputBean.setRoleKey(23L);
		List<Long> userLocKey=new ArrayList<Long>();
		userLocKey.add(2L);
		inputBean.setUserLocKey(userLocKey);
		List<Long> userPinCdKey=new ArrayList<Long>();
		userPinCdKey.add(3L);
		inputBean.setUserPinCdKey(userPinCdKey);
		List<Long> utmMastKey=new ArrayList<Long>();
		utmMastKey.add(4L);
		inputBean.setUtmMastKey(utmMastKey);
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		BfsdRoleMaster bfsdRoleMaster=new BfsdRoleMaster();
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		BfsdUser bfsduser=new BfsdUser();
		userRole.setBfsduser(bfsduser);
		userRole.setCreditlimit(BigDecimal.ONE);
		userRole.setIsactive(1L);
		userRole.setLstupdateby("lstupdateby");
		userRole.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRole.setParentuser(2L);
		userRole.setUserrolekey(22L);
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
		userRole.setUserRoleProducts(userRoleProducts);
		UserRoleProductBean userRoleProduct=new UserRoleProductBean();
		userRoleProduct.setUserrolekey(123L);
		userRoleProduct.setLstupdateby("lstupdateby");
		userRoleProduct.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProduct.setProdCatKey(122L);
		userRoleProduct.setProdmastkey(89L);
		userRoleProduct.setSubprodkey(123L);
		userRoleProduct.setUserprodkey(123L);
		userRoleProduct.setUserrolekey(123L);
		Mockito.when(userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), inputBean.getRoleKey())).thenReturn(userRole);
		
		UserRoleProductBean omBean=null;
		Mockito.when(omMasterDataPluginMapper.findUserRoleProduct(Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(omBean);
		Mockito.when( userMgmtProdDao.findUserRoleKey(userRoleProduct.getUserrolekey())).thenReturn(userRole);
		Mockito.when(omMasterDataPluginMapper.saveUserRoleMapping(Mockito.any(),Mockito.any())).thenReturn(userRoleProduct);
		
		long ans=userMgmtProdServiceImpl.savePrincipalUserMapping(inputBean, headers);
	}
	
	@Test
	public void deleteUserMappingTest() {
		long userRoleProdKey=55212222L;
		long prodMastKey =123L;
		boolean isSupervisor=false; 
		Mockito.when(userMgmtProdDao.getSupervisor(userRoleProdKey)).thenReturn(isSupervisor);
		
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("OMINS");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdServiceImpl.getAllMasterProducts()).thenReturn(masterProducts);
		
		UserRoleProductL3 userRoleProduct =new UserRoleProductL3();
		userRoleProduct.setCreditlimit(BigDecimal.ONE);
		userRoleProduct.setIsactive(1L);
		userRoleProduct.setLstupdateby("lstupdateby");
		userRoleProduct.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProduct.setPricinglimit(BigDecimal.ONE);
		userRoleProduct.setProdmastkey(56L);
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
		userRoleProducts.add(userRoleProduct);
		userRole.setUserRoleProducts(userRoleProducts);
		userRoleProduct.setUserRole(userRole);
		List<UserRoleProductType> userRoleProductTypes=new ArrayList<UserRoleProductType>();
		UserRoleProductType userRoleProductType=new UserRoleProductType();
		userRoleProductType.setIsactive(1L);
		userRoleProductType.setLstupdateby("lstupdateby");
		userRoleProductType.setLstupdatedt(new Date(System.currentTimeMillis()));
		userRoleProductType.setSubprodtypekey(56L);
		userRoleProductType.setUserroleprodtypekey(55L);
		userRoleProductType.setUserRoleProduct(userRoleProduct);
		userRoleProductTypes.add(userRoleProductType);
		
		userRoleProduct.setUserRoleProductTypes(userRoleProductTypes);
		Mockito.when(userMgmtProdDao.getEntity(Mockito.any(), Mockito.any())).thenReturn(userRoleProduct);
		Mockito.when(userMgmtProdDao.saveUserMapping(Mockito.any())).thenReturn(userRole);
		
		boolean ans=userMgmtProdServiceImpl.deleteUserMapping(userRoleProdKey,prodMastKey,headers);
		
		
	}
	
	@Test
	public void deleteUserMappingTest1() {
		long userRoleProdKey=55212222L;
		long prodMastKey =123L;
		boolean isSupervisor=false;
		Mockito.when(userMgmtProdDao.getSupervisor(userRoleProdKey)).thenReturn(isSupervisor);
		
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("OMCREDIT");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdServiceImpl.getAllMasterProducts()).thenReturn(masterProducts);
		
		UserRoleProductL3 userRoleProduct =new UserRoleProductL3();
		userRoleProduct.setCreditlimit(BigDecimal.ONE);
		userRoleProduct.setIsactive(1L);
		userRoleProduct.setLstupdateby("lstupdateby");
		userRoleProduct.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProduct.setPricinglimit(BigDecimal.ONE);
		userRoleProduct.setProdmastkey(56L);
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		
		
		
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
		userRoleProducts.add(userRoleProduct);
		userRole.setUserRoleProducts(userRoleProducts);
		userRoleProduct.setUserRole(userRole);
		List<UserRoleProductType> userRoleProductTypes=new ArrayList<UserRoleProductType>();
		UserRoleProductType userRoleProductType=new UserRoleProductType();
		userRoleProductType.setIsactive(1L);
		userRoleProductType.setLstupdateby("lstupdateby");
		userRoleProductType.setLstupdatedt(new Date(System.currentTimeMillis()));
		userRoleProductType.setSubprodtypekey(56L);
		userRoleProductType.setUserroleprodtypekey(55L);
		userRoleProductType.setUserRoleProduct(userRoleProduct);
		userRoleProductTypes.add(userRoleProductType);
	
		userRoleProduct.setUserRoleProductTypes(userRoleProductTypes);
		Mockito.when(userMgmtProdDao.getEntity(Mockito.any(), Mockito.any())).thenReturn(userRoleProduct);

		Mockito.when(userMgmtProdDao.saveUserMapping(Mockito.any())).thenReturn(userRole);
		
		boolean ans=userMgmtProdServiceImpl.deleteUserMapping(userRoleProdKey,prodMastKey,headers);
		
		
	}
	
	@Test
	public void deleteUserMappingTest2() {
		long userRoleProdKey=55212222L;
		long prodMastKey =123L;
		boolean isSupervisor=false;
		Mockito.when(userMgmtProdDao.getSupervisor(userRoleProdKey)).thenReturn(isSupervisor);
		
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(123L);
		productMaster.setProdmastcode("Null");
		List<ProductMaster> masterProducts = new ArrayList<>();
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdServiceImpl.getAllMasterProducts()).thenReturn(masterProducts);
		
		UserRoleProductL3 userRoleProduct =new UserRoleProductL3();
		userRoleProduct.setCreditlimit(BigDecimal.ONE);
		userRoleProduct.setIsactive(1L);
		userRoleProduct.setLstupdateby("lstupdateby");
		userRoleProduct.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProduct.setPricinglimit(BigDecimal.ONE);
		userRoleProduct.setProdmastkey(56L);
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		
		
		
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
		userRoleProducts.add(userRoleProduct);
		userRole.setUserRoleProducts(userRoleProducts);
		userRoleProduct.setUserRole(userRole);
		List<UserRoleProductType> userRoleProductTypes=new ArrayList<UserRoleProductType>();
		UserRoleProductType userRoleProductType=new UserRoleProductType();
		userRoleProductType.setIsactive(1L);
		userRoleProductType.setLstupdateby("lstupdateby");
		userRoleProductType.setLstupdatedt(new Date(System.currentTimeMillis()));
		userRoleProductType.setSubprodtypekey(56L);
		userRoleProductType.setUserroleprodtypekey(55L);
		userRoleProductType.setUserRoleProduct(userRoleProduct);
		userRoleProductTypes.add(userRoleProductType);
	
		userRoleProduct.setUserRoleProductTypes(userRoleProductTypes);
		Mockito.when(userMgmtProdDao.getEntity(Mockito.any(), Mockito.any())).thenReturn(userRoleProduct);

		Mockito.when(userMgmtProdDao.saveUserMapping(Mockito.any())).thenReturn(userRole);
		
		boolean ans=userMgmtProdServiceImpl.deleteUserMapping(userRoleProdKey,prodMastKey,headers);
		
		
	}
	
	@Test
	public void getUserMappingDetailsTest_BAU() {
		long userRoleProdKey=256L;
		UserRoleProductL3 userRoleProduct=new UserRoleProductL3();
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		BfsdRoleMaster bfsdRoleMaster=new BfsdRoleMaster();
		bfsdRoleMaster.setIsactive(BigDecimal.ONE);
		List<BfsdFunctionRole> bfsdFunctionRoles=new ArrayList<BfsdFunctionRole>();
		BfsdFunctionRole bfsdFunctionRole=new BfsdFunctionRole();
		BfsdFunction bfsdFunction=new BfsdFunction();
		List<BfsdFunctionProduct> bfsdFunctionProducts=new ArrayList<BfsdFunctionProduct>();
		BfsdFunctionProduct bfsdFunctionProduct=new BfsdFunctionProduct();
		bfsdFunctionProduct.setBfsdFunction(bfsdFunction);
		bfsdFunctionProduct.setIsactive(BigDecimal.ONE);
		bfsdFunctionProduct.setLnprdtypekey(BigDecimal.ONE);
		bfsdFunctionProduct.setLstupdateby("lstupdateby");
		bfsdFunctionProduct.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		bfsdFunctionProduct.setProdfunctionkey(555L);
		bfsdFunctionProducts.add(bfsdFunctionProduct);
		bfsdFunction.setBfsdFunctionProducts(bfsdFunctionProducts);
		bfsdFunction.setBfsdFunctionRoles(bfsdFunctionRoles);
		bfsdFunction.setFunctioncd(BigDecimal.ONE);
		bfsdFunction.setFunctiondesc("functiondesc");
		bfsdFunction.setFunctionkey(222L);
		bfsdFunction.setIsactive(BigDecimal.ONE);
		bfsdFunction.setLstupdateby("lstupdateby");
		bfsdFunction.setLstupdatedt(new Timestamp(System.currentTimeMillis()) );
		bfsdFunctionRole.setBfsdFunction(bfsdFunction);
		bfsdFunctionRole.setBfsdRoleMaster(bfsdRoleMaster);
		bfsdFunctionRole.setFunctionrolekey(555L);
		bfsdFunctionRole.setIsactive(BigDecimal.ONE);
		bfsdFunctionRole.setLstupdateby("lstupdateby");
		bfsdFunctionRole.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		bfsdFunctionRoles.add(bfsdFunctionRole);
		bfsdRoleMaster.setBfsdFunctionRoles(bfsdFunctionRoles);
		List<UserRole> userRoles=new ArrayList<UserRole>();
		UserRole userRole1=new UserRole();
		userRole1.setUserrolekey(256L);
		BfsdUser bfsduser=new BfsdUser();
		bfsduser.setUserkey(123L);
		userRole1.setBfsduser(bfsduser);
		userRole1.setBfsduser(bfsduser);
		userRole1.setBfsdRoleMaster(bfsdRoleMaster);
		userRoles.add(userRole1);
		bfsdRoleMaster.setUserRoles(userRoles);
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		userRole.setBfsduser(bfsduser);
		userRole.setCreditlimit(BigDecimal.ONE);
		userRole.setIsactive(1L);
		userRole.setLstupdateby("lstupdateby");
		userRole.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRole.setParentuser(2L);
		userRole.setUserrolekey(22L);
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
	
		userRoleProduct.setIsactive(1L);
		userRoleProduct.setCreditlimit(BigDecimal.ONE);
		userRoleProduct.setLstupdateby("lstupdateby");
		userRoleProduct.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProduct.setParentUserRoleProduct(userRoleProduct);
		userRoleProduct.setPricinglimit(BigDecimal.ONE);
		userRoleProduct.setProdmastkey(333L);
		userRoleProduct.setSubprodkey(55L);
		userRoleProduct.setSubprodtypekey(22L);
		userRoleProduct.setUserprodkey(444L);
		userRoleProduct.setUserRole(userRole);
		userRoleProduct.getCreditlimit();
		userRoleProduct.getIsactive();
		userRoleProduct.getLstupdateby();
		userRoleProduct.getLstupdatedt();
		userRoleProduct.getParentUserRoleProduct();
		userRoleProduct.getPricinglimit();
		userRoleProduct.getProdmastkey();
		userRoleProduct.getUserprodkey();
		userRoleProduct.getUserRole();
		userRoleProduct.getUserRoleChannels();
		userRoleProduct.getUserRoleLocations();
		userRoleProduct.getUserRolePinCodes();
		userRoleProduct.getUserRoleProductTypes();
		userRoleProduct.getUserRoleUtmSourceChannels();
		List<UserRoleChannelL3> userRoleChannels=new ArrayList<>();
		List<UserRoleLocationL3> userRoleLocations=new ArrayList<>();
		userRoleProduct.setUserRoleLocations(userRoleLocations);
		List<UserRolePinCodeL3> userRolePinCodes=new ArrayList<>();
		userRoleProduct.setUserRolePinCodes(userRolePinCodes);
		List<UserRoleProductType> userRoleProductTypes=new ArrayList<>();
		userRoleProduct.setUserRoleProductTypes(userRoleProductTypes);
		List<UserRoleUtmSourceChannel> userRoleUtmSourceChannels=new ArrayList<>();
		userRoleProduct.setUserRoleUtmSourceChannels(userRoleUtmSourceChannels);
		userRoleProduct.setUserRoleChannels(userRoleChannels);
		userRoleProducts.add(userRoleProduct);
		userRole.setUserRoleProducts(userRoleProducts);
		List<UserProdMappingBean> userProdMappingBeanList=new ArrayList<>();
		UserProdMappingBean userProdMappingBean=new UserProdMappingBean();
		userProdMappingBean.setCreditLimit(BigDecimal.ONE);
		userProdMappingBean.setEmployeeType("dealer");
		userProdMappingBean.setFunctionKey(7L);
		userProdMappingBean.setHighRole(false);
		userProdMappingBean.setHighSupvisorRole(true);
		userProdMappingBean.setLoanProdKey(22L);
		List<Long> loanProductType=new ArrayList<Long>();
		loanProductType.add(22L);
		userProdMappingBean.setLoanProductType(loanProductType);
		userProdMappingBean.setPricinglimit(BigDecimal.ONE);
		userProdMappingBean.setProdCatKey(25L);
		userProdMappingBean.setRoleCode("roleCode");
		userProdMappingBean.setUserKey(2555L);
		userProdMappingBean.setProdMastKey(355L);
		userProdMappingBean.setRoleKey(55L);
		List<Long> userLocKey=new ArrayList<Long>();
		userLocKey.add(22L);
		userProdMappingBean.setUserLocKey(userLocKey);
		List<Long> userPinCdKey=new ArrayList<Long>();
		userPinCdKey.add(22L);
		userProdMappingBean.setUserPinCdKey(userPinCdKey);
		userProdMappingBean.setUserRoleKey(222L);
		userProdMappingBean.setUserRoleProdKey(userRoleProdKey);
		List<Long> utmMastKey=new ArrayList<Long>();
		utmMastKey.add(22L);
		userProdMappingBean.setUtmMastKey(utmMastKey);
		userProdMappingBeanList.add(userProdMappingBean);
		
		UserRoleProductBean userRoleProductBean=new UserRoleProductBean();
		Mockito.when(omMasterDataPluginMapper.findUserRoleProduct(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
					Mockito.any())).thenReturn(userRoleProductBean);
		ProductMaster productMaster=new ProductMaster();
		productMaster.setProdmastcode("prodmastcode");
		productMaster.setProdmastdesc("prodmastdesc");
		productMaster.setProdmastisactive(BigDecimal.ONE);
		productMaster.setProdmastkey(333L);
		productMaster.setProdmastlstupdateby("prodmastlstupdateby");
		productMaster.setProdmastlstupdatedt(new Timestamp(System.currentTimeMillis()));
		List<ProductCategory> productCategories=new ArrayList<ProductCategory>();
		ProductCategory productCategory=new ProductCategory();
		productCategory.setProdcatcode("lll");
		productCategory.setProdcatdesc("prodcatdesc");
		productCategory.setProductMaster(productMaster);
		productCategory.setProdcatisactive(BigDecimal.ONE);
		List<LoanProduct> loanProducts=new ArrayList<LoanProduct>();
		LoanProduct loanProduct=new LoanProduct();
		loanProduct.setLnprodcode("lnprodcode");
		loanProduct.setLnproddesc("lnproddesc");
		loanProduct.setLnprodisactive(BigDecimal.ONE);
		loanProduct.setLnprodkey(111L);
		loanProduct.setLnprodlstupdateby("lnprodlstupdateby");
		loanProduct.setLnprodlstupdatedt(new Timestamp(System.currentTimeMillis()));
		loanProduct.setProductCategory(productCategory);
		loanProducts.add(loanProduct);
		productCategory.setLoanProducts(loanProducts);
		productCategories.add(productCategory);
		productMaster.setProductCategories(productCategories);
		Mockito.when(userMgmtProdDao.getEntity(Mockito.any(), Mockito.any())).thenReturn(userRoleProduct,productMaster);
		userProdMappingBeanList=userMgmtProdServiceImpl.getUserMappingDetails(userRoleProdKey, headers);
	}
	
	//@Test
	public void getUserMappingDetailsTest_OM() {
		long userRoleProdKey=256L;
		List<UserProdMappingBean> userProdMappingBeanList=new ArrayList<UserProdMappingBean>();
		UserRoleProductL3 userRoleProduct=new UserRoleProductL3();
		
		UserRoleProductBean userRoleProductBean=new UserRoleProductBean();
		userRoleProductBean.setUserrolekey(22L);
		userRoleProductBean.setUserprodkey(222L);
		Mockito.when(omMasterDataPluginMapper.findUserRoleProduct(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
					Mockito.any())).thenReturn(userRoleProductBean);
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		BfsdUser bfsduser=new BfsdUser();
		userRole.setBfsduser(bfsduser);
		Mockito.when(userMgmtProdDao.findUserRoleKey(Mockito.anyLong())).thenReturn(userRole);
		userProdMappingBeanList = userMgmtProdServiceImpl.getUserMappingDetails(userRoleProdKey, headers);
	}
	
	@Test 
	public void saveUserMappingTest_not0() {
		UserProdMappingBean inputBean=new UserProdMappingBean();
		inputBean.setUserRoleProdKey(10L);
		inputBean.setCreditLimit(BigDecimal.ONE);
		inputBean.setEmployeeType("dealer");
		inputBean.setFunctionKey(7L);
		inputBean.setHighRole(true);
		inputBean.setLoanProdKey(5L);
		inputBean.setProdCatKey(23L);
		inputBean.setProdMastKey(89L);
		inputBean.setRoleCode("roleCode");
		inputBean.setRoleKey(0L);
		inputBean.setSupervisorRoleProdKey(1234L);
		List<Long> userChannelKey=new ArrayList<Long>();
		userChannelKey.add(1L);
		inputBean.setUserChannelKey(userChannelKey);
		inputBean.setUserKey(1234L);
		List<Long> userLocKey=new ArrayList<Long>();
		userLocKey.add(2L);
		inputBean.setUserLocKey(userLocKey);
		List<Long> userPinCdKey=new ArrayList<Long>();
		userPinCdKey.add(3L);
		inputBean.setUserPinCdKey(userPinCdKey);
		List<Long> utmMastKey=new ArrayList<Long>();
		utmMastKey.add(4L);
		inputBean.setUtmMastKey(utmMastKey);
		long userRoleProdkey=555L;
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		BfsdRoleMaster bfsdRoleMaster=new BfsdRoleMaster();
		List<UserRole> userRoles=new ArrayList<UserRole>();
		UserRole userRole1=new UserRole();
		userRole1.setUserrolekey(256L);
		BfsdUser bfsduser=new BfsdUser();
		bfsduser.setUserkey(123L);
		userRole1.setBfsduser(bfsduser);
		userRoles.add(userRole1);
		bfsdRoleMaster.setUserRoles(userRoles);;
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		userRole.setBfsduser(bfsduser);
		userRole.setCreditlimit(BigDecimal.ONE);
		userRole.setIsactive(1L);
		userRole.setLstupdateby("lstupdateby");
		userRole.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRole.setParentuser(2L);
		userRole.setUserrolekey(22L);
		UserRoleProductL3 userRoleProduct=new UserRoleProductL3();
		UserRoleProductBean omBean=new UserRoleProductBean();
		omBean.setUserrolekey(123L);
		omBean.setLstupdateby("lstupdateby");
		omBean.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		omBean.setProdCatKey(122L);
		omBean.setProdmastkey(89L);
		omBean.setSubprodkey(123L);
		omBean.setUserprodkey(123L);
		List<UserRoleLocationsBean> userRoleLocations=new ArrayList<UserRoleLocationsBean>();
		omBean.setUserRoleLocations(userRoleLocations);
		List<UserRoleProductTypeBean> userRoleProductTypes=new ArrayList<UserRoleProductTypeBean>();
		omBean.setUserRoleProductTypes(userRoleProductTypes);
		
		Mockito.when(omMasterDataPluginMapper.findUserRoleProduct(Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(omBean);
		Mockito.when(userMgmtProdDao.findUserRoleKey(Mockito.anyLong())).thenReturn(userRole);
		Mockito.when(omMasterDataPluginMapper.saveUserRoleMapping(Mockito.any(), Mockito.any())).thenReturn(omBean);
		userRoleProdkey = userMgmtProdServiceImpl.saveUserMapping(inputBean, headers);

		
	}
	
	@Test
	public void deleteUserMappingForOMCreditTest() {
		long userRoleProdKey=55212222L;
		Long userroleKey = 5L;
		
		
		UserRoleProductBean userRoleProductBean= new UserRoleProductBean();
		userRoleProductBean.setCreditlimit(BigDecimal.ONE);
		userRoleProductBean.setIsactive(BigDecimal.ONE);
		userRoleProductBean.setLstupdateby("lstupdateby");
		userRoleProductBean.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProductBean.setPricinglimit(BigDecimal.ONE);
		userRoleProductBean.setProdmastkey(56L);
		
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		List<UserRoleProductL3> userRoleProducts = new ArrayList<UserRoleProductL3>();
		
		userRole.setUserRoleProducts(userRoleProducts);
		
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		
		Mockito.when(query.getSingleResult()).thenReturn( userRole);
		
		boolean successFlag = false;
		
		Mockito.when(omMasterDataPluginMapper.findUserRoleProduct(Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(userRoleProductBean);
		
		Mockito.when(omMasterDataPluginMapper.updateUserRoleProduct(Mockito.any(),Mockito.any())).thenReturn(successFlag);
		boolean ans=userMgmtProdServiceImpl.deleteUserMappingForOMCredit(userRoleProdKey,headers);
		
		
	}
	
	@Test
	public void deleteUserMappingForOMInsuranceTest() {
		long userRoleProdKey=55212222L;
		Long userroleKey = 5L;
		
		
		UserRoleProductBean userRoleProductBean= new UserRoleProductBean();
		userRoleProductBean.setCreditlimit(BigDecimal.ONE);
		userRoleProductBean.setIsactive(BigDecimal.ONE);
		userRoleProductBean.setLstupdateby("lstupdateby");
		userRoleProductBean.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProductBean.setPricinglimit(BigDecimal.ONE);
		userRoleProductBean.setProdmastkey(56L);
		
		UserRoleL3 userRole=new UserRoleL3();
		userRole.setIsactive(1L);
		userRole.setUserrolekey(123L);
		
        List<UserRoleProductL3> userRoleProducts = new ArrayList<UserRoleProductL3>();
		
		userRole.setUserRoleProducts(userRoleProducts);
		
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		
		Mockito.when(query.getSingleResult()).thenReturn( userRole);
		
		boolean successFlag = false;
		
		Mockito.when(oMMasterDataInsurancePluginMapper.findUserRoleProduct(Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(userRoleProductBean);
		
		Mockito.when(oMMasterDataInsurancePluginMapper.updateUserRoleProduct(Mockito.any(),Mockito.any())).thenReturn(successFlag);
		boolean ans=userMgmtProdServiceImpl.deleteUserMappingForOMInsurance(userRoleProdKey,headers);
		
		
	}
	
	@Test
	public void getUserDetailsTest() {
		UserConfigurationBean userConfig = new UserConfigurationBean();
		UserConfigurationBean userConfigResponse = new UserConfigurationBean();
		Mockito.when(userMgmtProdDao.getUserDetails(userConfig, headers)).thenReturn(userConfigResponse);
		assertNotNull(userMgmtProdServiceImpl.getUserDetails(userConfig, headers));
	}
	
	@Test
	public void getOMUserSuperVisorForOmCreditTest() {
		List<SupervisorBean> supervisorList = new ArrayList<>();
		Mockito.when(omMasterDataPluginMapper.getMultiOMUserSuperVisor(1234L, 1234L,"prod", headers)).thenReturn(supervisorList);
		assertNotNull(userMgmtProdServiceImpl.getOMUserSuperVisorForOmCredit(1234L, 1234L,"prod", headers));
	}
	
	
	@Test
	public void getAdditionalUserDetailsTest() {
		UserConfigurationBean userConfig = new UserConfigurationBean();
		UserConfigurationBean userConfigResponse = new UserConfigurationBean();
		Mockito.when(userMgmtProdDao.getAdditionalUserDetails(userConfig)).thenReturn(userConfigResponse);
		assertNotNull(userMgmtProdServiceImpl.getAdditionalUserDetails(userConfig));
	}
	
	@Test
	public void getOMUserMappingDetailsTest() {
		UserRoleProductBean userRoleProductBean = new UserRoleProductBean();
		UserProdMappingBean userProdMappingBean = new UserProdMappingBean();
		UserRoleL3 userRole = new UserRoleL3();
		BfsdUser bfsduser = new BfsdUser();
		List<UserProdMappingBean> userProuctMappingBeans = new ArrayList<>();
		List<Object[]> userProfiles =  new ArrayList<>();
		Mockito.when(omMasterDataPluginMapper.findUserRoleProduct(null,null,null, 1234L,headers)).thenReturn(userRoleProductBean);
			
		userRoleProductBean.setUserrolekey(1234L);
		userProdMappingBean.setUserRoleProdKey(1234L);
		userProdMappingBean.setUserRoleKey(userRoleProductBean.getUserrolekey());
		userProuctMappingBeans.add(userProdMappingBean);
		bfsduser.setUserkey(1234L);
		userRole.setBfsduser(bfsduser);
		Mockito.when(userMgmtProdDao.findUserRoleKey(userRoleProductBean.getUserrolekey())).thenReturn(userRole);
		Mockito.when(userMgmtProdDao.getUserProfileByUserKey(userRole.getBfsduser().getUserkey())).thenReturn(userProfiles);
		
		assertNotNull(userMgmtProdServiceImpl.getOMUserMappingDetails(1234L, headers));
	}

	@Test
	public void getOMInsuranceUserMappingDetailsTest() {
		UserRoleProductBean userRoleProductBean = new UserRoleProductBean();
		UserProdMappingBean userProdMappingBean = new UserProdMappingBean();
		UserRoleL3 userRole = new UserRoleL3();
		BfsdUser bfsduser = new BfsdUser();
		List<UserProdMappingBean> userProuctMappingBeans = new ArrayList<>();
		List<Object[]> userProfiles =  new ArrayList<>();
		Mockito.when(oMMasterDataInsurancePluginMapper.findUserRoleProduct(null,null,null, 1234L,headers)).thenReturn(userRoleProductBean);
			
		userRoleProductBean.setUserrolekey(1234L);
		userProdMappingBean.setUserRoleProdKey(1234L);
		userProdMappingBean.setUserRoleKey(userRoleProductBean.getUserrolekey());
		userProuctMappingBeans.add(userProdMappingBean);
		bfsduser.setUserkey(1234L);
		userRole.setBfsduser(bfsduser);
		Mockito.when(userMgmtProdDao.findUserRoleKey(userRoleProductBean.getUserrolekey())).thenReturn(userRole);
		Mockito.when(userMgmtProdDao.getUserProfileByUserKey(userRole.getBfsduser().getUserkey())).thenReturn(userProfiles);
		
		assertNotNull(userMgmtProdServiceImpl.getOMInsuranceUserMappingDetails(1234L, headers));
	}
	
	@Test
	public void getUserSuperVisorTest() {
		SupervisorBean supervisorBean = new SupervisorBean();
		List<SupervisorBean> supervisors = new ArrayList<>();
		supervisors.add(supervisorBean);
		Mockito.when(userMgmtProdDao.getUserSuperVisor(123L,123L,123L)).thenReturn(supervisors);
		assertNotNull(userMgmtProdServiceImpl.getUserSuperVisor(123L, 123L, 123L));
	}
	
	@Test
	public void getSuperVisorLocationsTest() {
		LocationBean locationBean = new LocationBean();
		List<LocationBean> locations = new ArrayList<>();
		locations.add(locationBean);
		Mockito.when(userMgmtProdDao.getSuperVisorLocations(123L)).thenReturn(locations);
		assertNotNull(userMgmtProdServiceImpl.getSuperVisorLocations(123L));
	}
	
	@Test
	public void getSuperVisorChannelsTest() {
		ChannelBean channelBean = new ChannelBean();
		List<ChannelBean> channels = new ArrayList<>();
		channels.add(channelBean);
		Mockito.when(userMgmtProdDao.getSuperVisorChannels(123L)).thenReturn(channels);
		assertNotNull(userMgmtProdServiceImpl.getSuperVisorChannels(123L));
	}
	
}
