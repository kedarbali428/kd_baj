package com.bajaj.bfsd.usermanagement.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.regex.Pattern;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.usermanagement.util.LoginPasswordValidator;

@RunWith(SpringJUnit4ClassRunner.class)
public class LoginPasswordValidatorTest {

	@InjectMocks
	private LoginPasswordValidator pwdValidator;
	
	@Before
	public void setUp() {
		String DEALER_LOGIN_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,20})";
		String PASSWORD_PATTERN = "((?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{8,})";
		String LOGIN_PATTERN = "^(.+)@(.+)$";

		ReflectionTestUtils.setField(pwdValidator, "patternPassword", Pattern.compile(PASSWORD_PATTERN));
		ReflectionTestUtils.setField(pwdValidator, "patternLogin", Pattern.compile(LOGIN_PATTERN));
		//ReflectionTestUtils.setField(pwdValidator, "patternDealerLogin", Pattern.compile(DEALER_LOGIN_PATTERN));

	}
	
	@Test
	public void testLoginPasswordValidator() {
		assertNotNull(pwdValidator);
	}

	@Test
	public void testValidateLogin() {
		boolean validateLogin = pwdValidator.validateLogin("999@abc");
		assertTrue(validateLogin);
	}

	@Test
	public void testValidateLogin_Invalid() {
		boolean validateLogin = pwdValidator.validateLogin("999abc");
		assertFalse(validateLogin);
	}
	
	@Test
	public void testValidatePassword() {
		boolean validatePassword = pwdValidator.validatePassword("Password123#");
		assertTrue(validatePassword);
	}

	@Test
	public void testValidatePassword_Invalid() {
		boolean validatePassword = pwdValidator.validatePassword("Password123");
		assertFalse(validatePassword);
	}
	
}