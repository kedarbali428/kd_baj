package com.bajaj.bfsd.usermanagement.beanmapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bajaj.bfsd.usermanagement.bean.UserMappingDeleteResponseBean;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;

@RunWith(PowerMockRunner.class)
public class BeanMapperTest {
	@InjectMocks
	BeanMapper beanMapper;

	@Test
	public void testMapToUserLoginAccountBeanNull() {
		List<Object[]> resultSet = new ArrayList<>();
		Object[] args = new Object[] { null, null, null, null, null, null, null, null, null, null };
		resultSet.add(args);
		// method under test
		UserLoginAccount userLoginAccount = beanMapper.mapToUserLoginAccountBean(resultSet);
		assertNull(userLoginAccount.getLoginpwd());
	}

	@Test
	public void testMapToUserLoginAccountBean() {
		List<Object[]> resultSet = new ArrayList<>();
		Object[] args = new Object[] { "pass", "123456", "1992-12-02 10:25:25", "12", "12", "12", "1992-12-02 10:25:25",
				"12", "12", "1992-12-02 10:25:25" };
		resultSet.add(args);
		// method under test
		UserLoginAccount userLoginAccount = beanMapper.mapToUserLoginAccountBean(resultSet);
		assertEquals("pass", userLoginAccount.getLoginpwd());
	}

	@Test
	public void mapTo() {
		UserMappingDeleteResponseBean userLoginAccount = beanMapper.mapTo(124L, 1425L, true);
	}

	@Test
	public void testMapToBean() {
		List<Object[]> resultSet = new ArrayList<>();
		Object[] args = new Object[] { null, null, null, null, null, null };
		resultSet.add(args);
		List<UserName> users = beanMapper.mapToBean(resultSet);
	}
}
