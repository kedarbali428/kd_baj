package com.bajaj.openmarkets.usermanagement.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.openmarkets.usermanagement.bean.AuthorizationCodesRequest;
import com.bajaj.openmarkets.usermanagement.bean.AuthorizationCodesResponse;
import com.bajaj.openmarkets.usermanagement.service.OMUserAuthorizationService;
import com.bfl.common.exceptions.BFLHttpException;

@RunWith(SpringJUnit4ClassRunner.class)
public class OMUserAuthorizationControllerTest {

	@InjectMocks
	private OMUserAuthorizationController federatedController;
	
	@Mock
	private BFLLoggerUtilExt logger;
	
	@Mock
	private OMUserAuthorizationService federatedAuthService;
	
	@Test
	public void testFederatedAuthentication() throws Exception {
		AuthorizationCodesResponse codeResponse = new AuthorizationCodesResponse();
		codeResponse.setAuthorizationCode("authorizedCodeString");

		AuthorizationCodesRequest request = new AuthorizationCodesRequest();
		request.setApplicantKey(12345L);
		request.setAuthorizedClient("BFDL_AuthClient");
		request.setClientId("BFDL_Markets_App");
		
		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		ResponseEntity<?> federatedAuthentication = federatedController.federatedAuthentication(request,
				mockedBindingResult, "Some Auth token");
		assertEquals(HttpStatus.OK, federatedAuthentication.getStatusCode());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testFederatedAuthentication_BindingErrors() {
		
		AuthorizationCodesRequest request = new AuthorizationCodesRequest();

		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		Mockito.when(mockedBindingResult.hasErrors()).thenReturn(true);
		Mockito.when(mockedBindingResult.getFieldErrors()).thenReturn(new ArrayList<FieldError>());

		federatedController.federatedAuthentication(request,
				mockedBindingResult, "Some Auth token");	
	}
}
