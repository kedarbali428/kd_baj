package com.bajaj.bfsd.usermanagement.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.usermanagement.bean.AadharProfileBean;
import com.bajaj.bfsd.usermanagement.bean.FacebookProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileSaveRequest;
import com.bajaj.bfsd.usermanagement.service.UserProfileService;
import com.bajaj.bfsd.usermanagement.service.UserProfileServiceFactory;
import com.bajaj.bfsd.usermanagement.service.impl.AadharProfileService;
import com.bajaj.bfsd.usermanagement.service.impl.FacebookProfileService;
import com.bfl.common.exceptions.BFLBusinessException;

@RunWith(PowerMockRunner.class)
public class UserProfileControllerTest {

	@InjectMocks
	private UserProfileController profileController;
	
	@Mock
    private BFLLoggerUtil logger;
	
	@Mock
	private UserProfileServiceFactory profileServiceFactory;
	
	@Mock
	private Environment env;
	
	@Mock
	private CustomDefaultHeaders customHeader;

	@Test
	public void testSaveUserProfile() {
		UserProfileSaveRequest userProfileSaveRequest = new UserProfileSaveRequest();
		String source = "source";

		UserProfileService mockedUserProfile = Mockito.mock(FacebookProfileService.class);
		Mockito.when(profileServiceFactory.getServiceInstance(Mockito.anyString()))
				.thenReturn(mockedUserProfile);		
		ResponseEntity<ResponseBean> saveUserProfile = profileController.saveUserProfile(userProfileSaveRequest, source, new HttpHeaders());
		assertEquals(saveUserProfile.getBody().getStatus().name(), StatusCode.SUCCESS.name());
	}

	@Test
	public void testGetUserProfile() {
		String source = "source";
		AadharProfileBean profileBean = new AadharProfileBean();
		profileBean.setAadharNumber("1234-5678-9012");
		profileBean.setProfileJson("{ \"key1\": \"value1\", \"key2\": \"value2\"}");
		UserProfileService aadharProfileService = Mockito.mock(AadharProfileService.class);
		
		Mockito.when(customHeader.getUserKey()).thenReturn(12345L);
		Mockito.when(profileServiceFactory.getServiceInstance(Mockito.anyString()))
				.thenReturn(aadharProfileService);
		Mockito.when(aadharProfileService.getUserProfile(Mockito.anyLong()))
				.thenReturn(profileBean);
		
		ResponseEntity<ResponseBean> userProfile = profileController.getUserProfile(source, new HttpHeaders());
		assertEquals(userProfile.getBody().getStatus().name(), StatusCode.SUCCESS.name());

	}

	@Test(expected = BFLBusinessException.class)
	public void testGetUserProfile_InvalidUserKey() {
		String source = "source";
		profileController.getUserProfile(source, new HttpHeaders());
	}
	
	@Test
	public void testGetUserProfile_IOException() {
		String source = "source";
		AadharProfileBean profileBean = new AadharProfileBean();
		profileBean.setAadharNumber("1234-5678-9012");
		profileBean.setProfileJson("somebadjson");
		UserProfileService aadharProfileService = Mockito.mock(AadharProfileService.class);
		
		Mockito.when(customHeader.getUserKey()).thenReturn(12345L);
		Mockito.when(profileServiceFactory.getServiceInstance(Mockito.anyString()))
				.thenReturn(aadharProfileService);
		Mockito.when(aadharProfileService.getUserProfile(Mockito.anyLong()))
				.thenReturn(profileBean);
		
		ResponseEntity<ResponseBean> userProfile = profileController.getUserProfile(source, new HttpHeaders());
		assertEquals(userProfile.getBody().getStatus().name(), StatusCode.SUCCESS.name());

	}
	
	@Test(expected = BFLBusinessException.class)
	public void testGetUserProfile_NoCustomHeader() {
		String source = "source";
		ReflectionTestUtils.setField(profileController, "customHeader", null);
		profileController.getUserProfile(source, new HttpHeaders());

	}
	
	@Test
	public void testGetUserProfile_FbProfile() {
		String source = "source";
		FacebookProfileBean profileBean = new FacebookProfileBean();
		profileBean.setProfileJson("somebadjson");
		UserProfileService fbProfileService = Mockito.mock(FacebookProfileService.class);
		
		Mockito.when(customHeader.getUserKey()).thenReturn(12345L);
		Mockito.when(profileServiceFactory.getServiceInstance(Mockito.anyString()))
				.thenReturn(fbProfileService);
		Mockito.when(fbProfileService.getUserProfile(Mockito.anyLong()))
				.thenReturn(profileBean);
		
		ResponseEntity<ResponseBean> userProfile = profileController.getUserProfile(source, new HttpHeaders());
		assertEquals(userProfile.getBody().getStatus().name(), StatusCode.SUCCESS.name());

	}
}
