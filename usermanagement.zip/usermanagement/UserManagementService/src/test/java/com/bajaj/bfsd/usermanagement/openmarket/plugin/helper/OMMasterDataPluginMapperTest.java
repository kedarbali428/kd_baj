package com.bajaj.bfsd.usermanagement.openmarket.plugin.helper;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfdl.om.impl.EpBauClientImpl;
import com.bfsd.om.bean.CityMasterBean;
import com.bfsd.om.bean.UserRoleProductBean;

@RunWith(SpringJUnit4ClassRunner.class)
public class OMMasterDataPluginMapperTest {

	@InjectMocks
	OMMasterDataPluginMapper omMasterDataPluginMapper; 
	
	@Mock
	private EpBauClientImpl bauClientImpl;
	
	@Mock
	HttpHeaders headers;
	
	@Test
	public void findSuperVisorLocationTest(){
		CityMasterBean cityMasterBean = new CityMasterBean();
		cityMasterBean.setCitykey(123L);
		cityMasterBean.setCityname("Test");
		List<CityMasterBean> list = new ArrayList<>();  
		list.add(cityMasterBean);
		Mockito.when(bauClientImpl.findSuperVisorLocation(Mockito.anyLong(), Mockito.any())).thenReturn(list);
		omMasterDataPluginMapper.findSuperVisorLocation(132L, headers);
		assertNotNull(list);
	}
	
//	@Test
//	public void findUserRoleProductTest() {
//		UserRoleProductBean bean = new UserRoleProductBean();   
//		Mockito.when(bauClientImpl.getUserRoleProduct(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any())).thenReturn(bean);
//		omMasterDataPluginMapper.findUserRoleProduct(123L, 123L, 123L, 123L, headers);
//		assertNotNull(bean);
//	}
	
	@Test
	public void saveUserRoleMappingTest(){
		UserRoleProductBean bean = new UserRoleProductBean(); 
		Mockito.when(bauClientImpl.saveUserRoleProduct(Mockito.any(), Mockito.any())).thenReturn(bean);
		omMasterDataPluginMapper.saveUserRoleMapping(bean, headers);
		assertNotNull(bean);
	}
}
