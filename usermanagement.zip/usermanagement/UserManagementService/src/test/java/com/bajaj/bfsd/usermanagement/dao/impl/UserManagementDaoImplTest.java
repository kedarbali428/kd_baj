package com.bajaj.bfsd.usermanagement.dao.impl;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterRequest;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.DeleteUserRoleBean;
import com.bajaj.bfsd.usermanagement.bean.EmployeeRoleDetails;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.ReportingManager;
import com.bajaj.bfsd.usermanagement.bean.User;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountRequest;
import com.bajaj.bfsd.usermanagement.bean.UserMappingRequest;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.bean.UserProfileDetails;
import com.bajaj.bfsd.usermanagement.bean.UserVendorProfileBean;
import com.bajaj.bfsd.usermanagement.bean.ValidateTokenBean;
import com.bajaj.bfsd.usermanagement.beanmapper.BeanMapper;
import com.bajaj.bfsd.usermanagement.dao.UserMgmtProdDao;
import com.bajaj.bfsd.usermanagement.data.UserManagementTestData;
import com.bajaj.bfsd.usermanagement.helper.UserManagementHelper;
import com.bajaj.bfsd.usermanagement.model.AppContactAuthRequest;
import com.bajaj.bfsd.usermanagement.model.AppContactAuthValidation;
import com.bajaj.bfsd.usermanagement.model.AppViewDefinition;
import com.bajaj.bfsd.usermanagement.model.BfsdFunction;
import com.bajaj.bfsd.usermanagement.model.BfsdFunctionRole;
import com.bajaj.bfsd.usermanagement.model.BfsdRoleMaster;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.CityMaster;
import com.bajaj.bfsd.usermanagement.model.SerReqViewDefinition;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.model.UserProfile;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bajaj.bfsd.usermanagement.model.UserRoleChannel;
import com.bajaj.bfsd.usermanagement.model.UserRoleChannelL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleLocation;
import com.bajaj.bfsd.usermanagement.model.UserRoleLocationL3;
import com.bajaj.bfsd.usermanagement.model.UserRolePinCode;
import com.bajaj.bfsd.usermanagement.model.UserRoleProduct;
import com.bajaj.bfsd.usermanagement.model.UserRoleProductL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleProductType;
import com.bajaj.bfsd.usermanagement.model.UserRoleUtmSourceChannel;
import com.bajaj.bfsd.usermanagement.repository.UserAddlAttributesRepository;
import com.bajaj.bfsd.usermanagement.util.Ldaputility;
import com.bajaj.bfsd.usermanagement.util.QueryConstants;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserManagementDaoImplTest {
	private static final Date date = new Date("12/12/2018");;

	@InjectMocks
	UserManagementDaoImpl userManagementDaoImpl;

	@Mock
	EntityManager entityManager;

	@Mock
	Environment environment;

	@Mock
	UserManagementHelper userManagementHelper;

	@Mock
	EntityManagerFactory entityManagerFactory;

	@Mock
	private BFLLoggerUtil bflLoggerUtil;

	@Mock
	Ldaputility ldaputility;

	@Mock
	BeanMapper beanMapper;

	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	CriteriaBuilder criteriaBlder;
	
	@Mock
	@RequestScoped
	CustomDefaultHeaders custmHeaders;

	@Mock
	UserProfileBean upb;
	
	@Mock
	Root<Object> rootUserRole;

	@Mock
	private Query query;
	
	@Mock
	private Query query1;

	@Mock
	CriteriaQuery<Object> criteriaQry;
	
	@Mock
	UserMgmtProdDao userMgmtProdDao;
	
	@Mock
	UserAddlAttributesRepository userAddlAttributesRepository;

	@Test
	public void testCreateUser() {
		List<UserProfile> userProfiles = new ArrayList<>();
		UserProfile userProfile = new UserProfile();
		userProfile.setCompanyname("Bajaj");
		userProfiles.add(userProfile);

		UserVendorProfileBean userVendorProfileBean = new UserVendorProfileBean();
		userVendorProfileBean.setEmailId("@gmail");
		userVendorProfileBean.setCompanyId(1245L);
		userVendorProfileBean.setAddress("knr");
		userVendorProfileBean.setCity(1245L);
		userVendorProfileBean.setCompanyName("Bajaj");
		userVendorProfileBean.setContactPersonName("ABC");
		userVendorProfileBean.setFirstName("Fisrtname");
		userVendorProfileBean.setGst("12");
		userVendorProfileBean.setLandline("landline");
		userVendorProfileBean.setLastName("Lastnamwe");
		userVendorProfileBean.setMiddleName("Middlename");
		userVendorProfileBean.setMobileNo("100");
		userVendorProfileBean.setPan("1245");
		userVendorProfileBean.setPincode("1245");
		userVendorProfileBean.setParentUserEmailId("@gmail");
		userVendorProfileBean.setPartnerKey("1455");
		userVendorProfileBean.setServiceKey("1455");
		userVendorProfileBean.setIsActive(1245L);
		userVendorProfileBean.setEmployeeType("vendorIndividual");
		userVendorProfileBean.setAssociationType(1245L);

		User userBean = new User();
		userBean.setIsActive(BigDecimal.ONE);
		userBean.setEmployeeType("vendorCompany");
		userBean.setUserVendorProfile(userVendorProfileBean);
		userBean.setEmailId("@gmail");
		userBean.setFirstName("Firstname");
		userBean.setLastName("LastName");
		userBean.setMobileNumber("92200");
		userBean.setDesignation("Associate");
		userBean.setPoType("ABC");
		userBean.setSpCode("1");
		userBean.setLpCode("1");
		userBean.setMaxSumAssuredLimit("100");
		userBean.setMaxPremiumLimit("10000");
		List<String> values = new ArrayList<>();
		values.add("557");
		userBean.setChannel(values);
		values.clear();
		values.add("English");
		userBean.setSkills(values);
		values.clear();
		values.add("CROSS-SELL");
		userBean.setSpecialization(values);
		values.clear();
		values.add("BFL-ONLINE");
		userBean.setPaymentModes(values);
		BfsdUser bfsdUser = new BfsdUser();
		Mockito.when(entityManager.merge(Mockito.any())).thenReturn(bfsdUser);
		assertEquals(bfsdUser, userManagementDaoImpl.createUser(userBean));
	}
	
	@Test
	public void testCreateUser1() {
		List<UserProfile> userProfiles = new ArrayList<>();
		UserProfile userProfile = new UserProfile();
		userProfile.setCompanyname("Bajaj");
		userProfiles.add(userProfile);

		UserVendorProfileBean userVendorProfileBean = new UserVendorProfileBean();
		userVendorProfileBean.setEmailId("@gmail");
		userVendorProfileBean.setCompanyId(1245L);
		userVendorProfileBean.setAddress("knr");
		userVendorProfileBean.setCity(1245L);
		userVendorProfileBean.setCompanyName("Bajaj");
		userVendorProfileBean.setContactPersonName("ABC");
		userVendorProfileBean.setFirstName("Fisrtname");
		userVendorProfileBean.setGst("12");
		userVendorProfileBean.setLandline("landline");
		userVendorProfileBean.setLastName("Lastnamwe");
		userVendorProfileBean.setMiddleName("Middlename");
		userVendorProfileBean.setMobileNo("100");
		userVendorProfileBean.setPan("1245");
		userVendorProfileBean.setPincode("1245");
		userVendorProfileBean.setParentUserEmailId("@gmail");
		userVendorProfileBean.setPartnerKey("1455");
		userVendorProfileBean.setServiceKey("1455");
		userVendorProfileBean.setIsActive(1245L);
		userVendorProfileBean.setEmployeeType("");
		userVendorProfileBean.setAssociationType(1245L);

		User userBean = new User();
		userBean.setIsActive(BigDecimal.ONE);
		userBean.setEmployeeType("");
		userBean.setUserVendorProfile(userVendorProfileBean);
		userBean.setEmailId("@gmail");
		userBean.setFirstName("Firstname");
		userBean.setLastName("LastName");
		userBean.setMobileNumber("92200");
		userBean.setDesignation("Associate");
		List<Object[]> reportingManagers = new ArrayList<>();
		Mockito.when(userMgmtProdDao.loadUserData()).thenReturn(reportingManagers);
		
		BfsdUser bfsdUser = new BfsdUser();
		Mockito.when(entityManager.merge(Mockito.any())).thenReturn(bfsdUser);
		assertEquals(bfsdUser, userManagementDaoImpl.createUser(userBean));
	}
	
	
	@Test
	public void testCreateUser_DEALER() {
		List<UserProfile> userProfiles = new ArrayList<>();
		UserProfile userProfile = new UserProfile();
		userProfile.setCompanyname("Bajaj");
		userProfiles.add(userProfile);

		UserVendorProfileBean userVendorProfileBean = new UserVendorProfileBean();
		userVendorProfileBean.setEmailId("@gmail");
		userVendorProfileBean.setCompanyId(1245L);
		userVendorProfileBean.setAddress("knr");
		userVendorProfileBean.setCity(1245L);
		userVendorProfileBean.setCompanyName("Bajaj");
		userVendorProfileBean.setContactPersonName("ABC");
		userVendorProfileBean.setFirstName("Fisrtname");
		userVendorProfileBean.setGst("12");
		userVendorProfileBean.setLandline("landline");
		userVendorProfileBean.setLastName("Lastnamwe");
		userVendorProfileBean.setMiddleName("Middlename");
		userVendorProfileBean.setMobileNo("100");
		userVendorProfileBean.setPan("1245");
		userVendorProfileBean.setPincode("1245");
		userVendorProfileBean.setParentUserEmailId("@gmail");
		userVendorProfileBean.setPartnerKey("1455");
		userVendorProfileBean.setServiceKey("1455");
		userVendorProfileBean.setIsActive(1245L);
		userVendorProfileBean.setEmployeeType("vendorIndividual");
		userVendorProfileBean.setAssociationType(1245L);

		User userBean = new User();
		userBean.setIsActive(BigDecimal.ONE);
		userBean.setEmployeeType("dealer");
		userBean.setUserVendorProfile(userVendorProfileBean);
		userBean.setEmailId("@gmail");
		userBean.setFirstName("Firstname");
		userBean.setLastName("LastName");
		userBean.setMobileNumber("92200");
		userBean.setDesignation("Associate");

		BfsdUser bfsdUser = new BfsdUser();
		Mockito.when(entityManager.merge(Mockito.any())).thenReturn(bfsdUser);
		BfsdRoleMaster bfsdRoleMaster=new BfsdRoleMaster();
		bfsdRoleMaster.setIsactive(BigDecimal.ONE);
		List<UserRole> userRoles=new ArrayList<>();
		UserRole userrole=new UserRole();
		userrole.setBfsduser(bfsdUser);
		userRoles.add(userrole);
		Mockito.when(entityManager.createNamedQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenReturn(bfsdRoleMaster);
		UserRoleL3 userRoleL3=new UserRoleL3();
		userRoleL3.setBfsdRoleMaster(bfsdRoleMaster);
		userRoleL3.setCreditlimit(BigDecimal.ONE);
		userRoleL3.setBfsduser(bfsdUser);
		userRoleL3.setIsactive(1L);
		userRoleL3.setLstupdateby("user1");
		userRoleL3.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleL3.setParentuser(1234L);
		userRoleL3.setUserrolekey(34567L);
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
		UserRoleProductL3 userRoleProductL3=new UserRoleProductL3();
		userRoleProductL3.setCreditlimit(BigDecimal.ONE);
		userRoleProductL3.setIsactive(1L);
		userRoleProductL3.setLstupdateby("lstupdateby");
		userRoleProductL3.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProductL3.setPricinglimit(BigDecimal.ONE);
		userRoleProductL3.setProdmastkey(2345L);
		userRoleProductL3.setSubprodkey(67L);
		userRoleProductL3.setUserprodkey(4555L);
		userRoleProductL3.setUserRole(userRoleL3);
		List<UserRoleChannelL3> userRoleChannels=new ArrayList<UserRoleChannelL3>();
		UserRoleChannelL3 userRoleChannelL3=new UserRoleChannelL3();
		userRoleChannelL3.setChanneltypekey(23L);
		userRoleChannelL3.setIsactive(1L);
		userRoleChannelL3.setLstupdateby("lstupdateby");
		userRoleChannelL3.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleChannelL3.setUserchannelkey(234L);
		userRoleChannelL3.setUserRoleProduct(userRoleProductL3);
		userRoleChannels.add(userRoleChannelL3);
		userRoleProductL3.setUserRoleChannels(userRoleChannels);
		List<UserRoleLocationL3> userRoleLocations=new ArrayList<UserRoleLocationL3>();
		UserRoleLocationL3 userRoleLocationL3=new UserRoleLocationL3();
		userRoleLocationL3.setBflbranchkey(234L);
		userRoleLocationL3.setIsactive(1L);
		userRoleLocationL3.setLstupdateby("lstupdateby");
		userRoleLocationL3.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleLocationL3.setUserRoleProduct(userRoleProductL3);
		userRoleLocationL3.setUserlockey(23L);
		userRoleLocations.add(userRoleLocationL3);
		userRoleProductL3.setUserRoleLocations(userRoleLocations);
		List<UserRoleProductType> userRoleProductTypes=new ArrayList<UserRoleProductType>();
		UserRoleProductType userRoleProductType=new UserRoleProductType();
		userRoleProductType.setIsactive(1L);
		userRoleProductType.setLstupdateby("lstupdateby");
		userRoleProductType.setLstupdatedt(new Date(System.currentTimeMillis()));
		userRoleProductType.setSubprodtypekey(23L);
		userRoleProductType.setUserroleprodtypekey(233L);
		userRoleProductType.setUserRoleProduct(userRoleProductL3);
		userRoleProductTypes.add(userRoleProductType);
		userRoleProductL3.setUserRoleProductTypes(userRoleProductTypes);
		List<UserRoleUtmSourceChannel> userRoleUtmSourceChannels=new ArrayList<UserRoleUtmSourceChannel>();
		UserRoleUtmSourceChannel userRoleUtmSourceChannel=new UserRoleUtmSourceChannel();
		userRoleUtmSourceChannel.setIsactive(BigDecimal.ONE);
		userRoleUtmSourceChannel.setLstupdateby("lstupdateby");
		userRoleUtmSourceChannel.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleUtmSourceChannel.setUserRoleProduct(userRoleProductL3);
		userRoleUtmSourceChannel.setUserutmkey(234L);
		userRoleUtmSourceChannel.setUtmsrcchnmastkey(BigDecimal.ONE);
		userRoleUtmSourceChannels.add(userRoleUtmSourceChannel);
		userRoleProductL3.setUserRoleUtmSourceChannels(userRoleUtmSourceChannels);
		userRoleProducts.add(userRoleProductL3);
		userRoleL3.setUserRoleProducts(userRoleProducts);
		Mockito.when(userMgmtProdDao.saveUserMapping(Mockito.any())).thenReturn(userRoleL3);
		assertEquals(bfsdUser, userManagementDaoImpl.createUser(userBean));
	}
	
	@Test
	public void testCreateUser_principalUser() {
		List<UserProfile> userProfiles = new ArrayList<>();
		UserProfile userProfile = new UserProfile();
		userProfile.setCompanyname("Bajaj");
		userProfiles.add(userProfile);

		UserVendorProfileBean userVendorProfileBean = new UserVendorProfileBean();
		userVendorProfileBean.setEmailId("@gmail");
		userVendorProfileBean.setCompanyId(1245L);
		userVendorProfileBean.setAddress("knr");
		userVendorProfileBean.setCity(1245L);
		userVendorProfileBean.setCompanyName("Bajaj");
		userVendorProfileBean.setContactPersonName("ABC");
		userVendorProfileBean.setFirstName("Fisrtname");
		userVendorProfileBean.setGst("12");
		userVendorProfileBean.setLandline("landline");
		userVendorProfileBean.setLastName("Lastnamwe");
		userVendorProfileBean.setMiddleName("Middlename");
		userVendorProfileBean.setMobileNo("100");
		userVendorProfileBean.setPan("1245");
		userVendorProfileBean.setPincode("1245");
		userVendorProfileBean.setParentUserEmailId("@gmail");
		userVendorProfileBean.setPartnerKey("1455");
		userVendorProfileBean.setServiceKey("1455");
		userVendorProfileBean.setIsActive(1245L);
		userVendorProfileBean.setEmployeeType("vendorIndividual");
		userVendorProfileBean.setAssociationType(1245L);

		User userBean = new User();
		userBean.setIsActive(BigDecimal.ONE);
		userBean.setEmployeeType("principalUser");
		userBean.setUserVendorProfile(userVendorProfileBean);
		userBean.setEmailId("@gmail");
		userBean.setFirstName("Firstname");
		userBean.setLastName("LastName");
		userBean.setMobileNumber("92200");
		userBean.setDesignation("Associate");

		BfsdUser bfsdUser = new BfsdUser();
		Mockito.when(entityManager.merge(Mockito.any())).thenReturn(bfsdUser);
		BfsdRoleMaster bfsdRoleMaster=new BfsdRoleMaster();
		bfsdRoleMaster.setIsactive(BigDecimal.ONE);
		List<UserRole> userRoles=new ArrayList<>();
		UserRole userrole=new UserRole();
		userrole.setBfsduser(bfsdUser);
		userRoles.add(userrole);
		Mockito.when(entityManager.createNamedQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenReturn(bfsdRoleMaster);
		UserRoleL3 userRoleL3=new UserRoleL3();
		userRoleL3.setBfsdRoleMaster(bfsdRoleMaster);
		userRoleL3.setCreditlimit(BigDecimal.ONE);
		userRoleL3.setBfsduser(bfsdUser);
		userRoleL3.setIsactive(1L);
		userRoleL3.setLstupdateby("user1");
		userRoleL3.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleL3.setParentuser(1234L);
		userRoleL3.setUserrolekey(34567L);
		List<UserRoleProductL3> userRoleProducts=new ArrayList<UserRoleProductL3>();
		UserRoleProductL3 userRoleProductL3=new UserRoleProductL3();
		userRoleProductL3.setCreditlimit(BigDecimal.ONE);
		userRoleProductL3.setIsactive(1L);
		userRoleProductL3.setLstupdateby("lstupdateby");
		userRoleProductL3.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleProductL3.setPricinglimit(BigDecimal.ONE);
		userRoleProductL3.setProdmastkey(2345L);
		userRoleProductL3.setSubprodkey(67L);
		userRoleProductL3.setUserprodkey(4555L);
		userRoleProductL3.setUserRole(userRoleL3);
		List<UserRoleChannelL3> userRoleChannels=new ArrayList<UserRoleChannelL3>();
		UserRoleChannelL3 userRoleChannelL3=new UserRoleChannelL3();
		userRoleChannelL3.setChanneltypekey(23L);
		userRoleChannelL3.setIsactive(1L);
		userRoleChannelL3.setLstupdateby("lstupdateby");
		userRoleChannelL3.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleChannelL3.setUserchannelkey(234L);
		userRoleChannelL3.setUserRoleProduct(userRoleProductL3);
		userRoleChannels.add(userRoleChannelL3);
		userRoleProductL3.setUserRoleChannels(userRoleChannels);
		List<UserRoleLocationL3> userRoleLocations=new ArrayList<UserRoleLocationL3>();
		UserRoleLocationL3 userRoleLocationL3=new UserRoleLocationL3();
		userRoleLocationL3.setBflbranchkey(234L);
		userRoleLocationL3.setIsactive(1L);
		userRoleLocationL3.setLstupdateby("lstupdateby");
		userRoleLocationL3.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleLocationL3.setUserRoleProduct(userRoleProductL3);
		userRoleLocationL3.setUserlockey(23L);
		userRoleLocations.add(userRoleLocationL3);
		userRoleProductL3.setUserRoleLocations(userRoleLocations);
		List<UserRoleProductType> userRoleProductTypes=new ArrayList<UserRoleProductType>();
		UserRoleProductType userRoleProductType=new UserRoleProductType();
		userRoleProductType.setIsactive(1L);
		userRoleProductType.setLstupdateby("lstupdateby");
		userRoleProductType.setLstupdatedt(new Date(System.currentTimeMillis()));
		userRoleProductType.setSubprodtypekey(23L);
		userRoleProductType.setUserroleprodtypekey(233L);
		userRoleProductType.setUserRoleProduct(userRoleProductL3);
		userRoleProductTypes.add(userRoleProductType);
		userRoleProductL3.setUserRoleProductTypes(userRoleProductTypes);
		List<UserRoleUtmSourceChannel> userRoleUtmSourceChannels=new ArrayList<UserRoleUtmSourceChannel>();
		UserRoleUtmSourceChannel userRoleUtmSourceChannel=new UserRoleUtmSourceChannel();
		userRoleUtmSourceChannel.setIsactive(BigDecimal.ONE);
		userRoleUtmSourceChannel.setLstupdateby("lstupdateby");
		userRoleUtmSourceChannel.setLstupdatedt(new Timestamp(System.currentTimeMillis()));
		userRoleUtmSourceChannel.setUserRoleProduct(userRoleProductL3);
		userRoleUtmSourceChannel.setUserutmkey(234L);
		userRoleUtmSourceChannel.setUtmsrcchnmastkey(BigDecimal.ONE);
		userRoleUtmSourceChannels.add(userRoleUtmSourceChannel);
		userRoleProductL3.setUserRoleUtmSourceChannels(userRoleUtmSourceChannels);
		userRoleProducts.add(userRoleProductL3);
		userRoleL3.setUserRoleProducts(userRoleProducts);
		Mockito.when(userMgmtProdDao.saveUserMapping(Mockito.any())).thenReturn(userRoleL3);
		assertEquals(bfsdUser, userManagementDaoImpl.createUser(userBean));
	}



	@Test
	public void testCreateBfsdUser() {
		Long userkey = 12452L;
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(1245L);
		entityManager.persist(bfsdUser);
		userManagementDaoImpl.createBfsdUser(userkey);
	}

	@Test(expected = Exception.class)
	public void testMapUserProfile() {

		UserConfigurationBean userConfigurationBean = new UserConfigurationBean();

		List<Object[]> authors = new ArrayList<>();

		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setIsactive(BigDecimal.ONE);
		List<BfsdUser> users = new ArrayList<>();
		users.add(bfsdUser);

		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(1245L);
		bfsdRoleMaster.setRolename("ABC");

		UserRole userRolekey = new UserRole();
		userRolekey.setBfsdRoleMaster(bfsdRoleMaster);
		List<UserRole> userRoleList = new ArrayList<>();

		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(users).thenReturn(authors).thenReturn(userRoleList);
		userManagementDaoImpl.mapUserProfile(authors, true,new HttpHeaders());
		assertEquals(userConfigurationBean, userManagementDaoImpl.mapUserProfile(authors, true,new HttpHeaders()));
	}

	@Test
	public void testGetUserInformation() {
		UserConfigurationBean userConfig = new UserConfigurationBean();
		userConfig.setEmployeeType("vendorCompany");
		userConfig.setUserKey(1245L);

		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(1245L);
		bfsdUser.setUsertype(new BigDecimal(3));
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(1245L);
		bfsdRoleMaster.setRolename("ABC");

		List<UserProfile> userProfiles = new ArrayList<>();
		UserProfile userProfile = new UserProfile();
		userProfile.setAddress("ABC");
		userProfile.setAssociationdt(date);
		userProfile.setAssociationtype(new BigDecimal(2));
		userProfile.setCity(1245L);
		userProfile.setCompanyname("Bajaj");
		userProfile.setContactpersonname("ABC");
		userProfile.setEmailid("@gmail");
		userProfile.setFirstname("Firstname");
		userProfile.setGst("12");
		userProfile.setIsactive(BigDecimal.ONE);
		userProfile.setLandline("landline");
		userProfile.setLastname("lastname");
		userProfile.setMiddlename("middlename");
		userProfile.setPan("124556");
		userProfile.setParentuseremailid("@gmail.");
		userProfile.setPartnerkey("124522");
		userProfile.setServicekey("124545");
		userProfile.setPincode("15246");
		userProfile.setBfsdUser(bfsdUser);
		userProfile.setUserprofilekey(1245L);
		userProfile.setParentCompany(userProfile);
		userProfile.setUserprofilekey(1245L);

		userProfiles.add(userProfile);

		UserVendorProfileBean userVendorProfile = new UserVendorProfileBean();

		List<UserVendorProfileBean> userVendorProfileBeans = new ArrayList<>();
		userVendorProfileBeans.add(userVendorProfile);

		CityMaster cityMaster = new CityMaster();
		cityMaster.setCityname("KBNR");

		UserRole userRole = new UserRole();
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		List<UserRole> userRoleList = new ArrayList<>();
		userRoleList.add(userRole);

		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userProfiles).thenReturn(userRoleList);
		Mockito.when(entityManager.find(Mockito.any(), Mockito.any())).thenReturn(cityMaster);
		/*Mockito.
		Mockito.when(userManagementDaoImpl.getUserVendorDetails(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(cityMaster);*/
		List<BfsdUser> bfsdUserlist = new ArrayList<BfsdUser>();
		bfsdUserlist.add(bfsdUser);
		BfsdUser bfsdUser1 = new BfsdUser();
		bfsdUser.setUserkey(1245L);
		bfsdUser.setUsertype(new BigDecimal(3));
		bfsdUserlist.add(bfsdUser1);
		//Mockito.when(userManagementDaoImpl.getUserType(Mockito.any(Long.class))).thenReturn(Mockito.mock(BfsdUser.class));
		//getUserType
		userManagementDaoImpl.getUserInformation(userConfig,new HttpHeaders());
	}
	
	@Test(expected=Exception.class)
	public void testGetUserInformation1() {
		UserConfigurationBean userConfig = new UserConfigurationBean();
		userConfig.setEmployeeType("");
		userConfig.setUserKey(1245L);

		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(1245L);
		bfsdUser.setUsertype(new BigDecimal(3));
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(1245L);
		bfsdRoleMaster.setRolename("ABC");

		List<UserProfile> userProfiles = new ArrayList<>();
		UserProfile userProfile = new UserProfile();
		userProfile.setAddress("ABC");
		userProfile.setAssociationdt(date);
		userProfile.setAssociationtype(new BigDecimal(2));
		userProfile.setCity(1245L);
		userProfile.setCompanyname("Bajaj");
		userProfile.setContactpersonname("ABC");
		userProfile.setEmailid("@gmail");
		userProfile.setFirstname("Firstname");
		userProfile.setGst("12");
		userProfile.setIsactive(BigDecimal.ONE);
		userProfile.setLandline("landline");
		userProfile.setLastname("lastname");
		userProfile.setMiddlename("middlename");
		userProfile.setPan("124556");
		userProfile.setParentuseremailid("@gmail.");
		userProfile.setPartnerkey("124522");
		userProfile.setServicekey("124545");
		userProfile.setPincode("15246");
		userProfile.setBfsdUser(bfsdUser);
		userProfile.setUserprofilekey(1245L);
		userProfile.setParentCompany(userProfile);
		userProfile.setUserprofilekey(1245L);

		userProfiles.add(userProfile);

		UserVendorProfileBean userVendorProfile = new UserVendorProfileBean();

		List<UserVendorProfileBean> userVendorProfileBeans = new ArrayList<>();
		userVendorProfileBeans.add(userVendorProfile);

		CityMaster cityMaster = new CityMaster();
		cityMaster.setCityname("KBNR");

		UserRole userRole = new UserRole();
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		List<UserRole> userRoleList = new ArrayList<>();
		userRoleList.add(userRole);
		List<Object[]> authors =  new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(authors);

		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userProfiles).thenReturn(userRoleList);
		Mockito.when(entityManager.find(Mockito.any(), Mockito.any())).thenReturn(cityMaster);
		/*Mockito.
		Mockito.when(userManagementDaoImpl.getUserVendorDetails(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(cityMaster);*/
		List<BfsdUser> bfsdUserlist = new ArrayList<BfsdUser>();
		bfsdUserlist.add(bfsdUser);
		BfsdUser bfsdUser1 = new BfsdUser();
		bfsdUser.setUserkey(1245L);
		bfsdUser.setUsertype(new BigDecimal(3));
		bfsdUserlist.add(bfsdUser1);
		//Mockito.when(userManagementDaoImpl.getUserType(Mockito.any(Long.class))).thenReturn(Mockito.mock(BfsdUser.class));
		//getUserType
		userManagementDaoImpl.getUserInformation(userConfig,new HttpHeaders());
	}

	@Test
	public void testdetails() {

		List<Long> cityPin = new ArrayList<>();
		EmployeeRoleDetails employeeRoleDetails = new EmployeeRoleDetails();
		employeeRoleDetails.setCityPin(cityPin);
		employeeRoleDetails.setProdMastKey(null);

		UserProfile userpro = new UserProfile();
		userpro.setIsactive(new BigDecimal(1));
		userpro.setFirstname("Firstname");
		userpro.setLastname("Lastname");
		userpro.setMobileno("100");
		userpro.setEmailid("@gmail");
		userpro.setDesignation("Designation");
		List<UserProfile> userProfiles = new ArrayList<>();
		userProfiles.add(userpro);

		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setIsactive(BigDecimal.ONE);
		bfsdUser.setUserProfiles(userProfiles);
		List<BfsdUser> users = new ArrayList<>();
		users.add(bfsdUser);

		BfsdFunction bfsdFunction = new BfsdFunction();
		bfsdFunction.setFunctionkey(12454L);
		BfsdFunctionRole bfsdFunctionRole = new BfsdFunctionRole();
		bfsdFunctionRole.setBfsdFunction(bfsdFunction);

		List<BfsdFunctionRole> bfsdFunctionRoles = new ArrayList<>();

		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setBfsdRoleMaster(null);
		bfsdRoleMaster.setRolecd("ABC");
		bfsdRoleMaster.setBfsdFunctionRoles(bfsdFunctionRoles);

		UserRolePinCode usrPin = new UserRolePinCode();
		usrPin.setIsactive(new BigDecimal(1));
		usrPin.setPincodekey(BigDecimal.ONE);
		List<UserRolePinCode> userRolePinCodes = new ArrayList<>();

		UserRoleLocation userLoc = new UserRoleLocation();
		userLoc.setIsactive(new BigDecimal(1));
		userLoc.setBflbranchkey(BigDecimal.ONE);
		List<UserRoleLocation> userRoleLocations = new ArrayList<>();

		UserRoleChannel userChn = new UserRoleChannel();
		userChn.setIsactive(new BigDecimal(1));
		userChn.setChanneltypekey(BigDecimal.ONE);
		List<UserRoleChannel> userRoleChannels = new ArrayList<>();

		UserRoleProduct userPro = new UserRoleProduct();
		userPro.setIsactive(new BigDecimal(1));
		userPro.setSubprodtypekey(BigDecimal.ONE);
		userPro.setProdmastkey(BigDecimal.ONE);
		List<UserRoleProduct> userRoleProducts = new ArrayList<>();

		UserRole userRole = new UserRole();
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		userRole.setBfsduser(bfsdUser);
		userRole.setCreditlimit(new BigDecimal(500000));
		userRole.setParentuser(BigDecimal.ONE);
		userRole.setUserRolePinCodes(userRolePinCodes);
		userRole.setUserRoleLocations(userRoleLocations);
		userRole.setUserRoleChannels(userRoleChannels);
		userRole.setUserRoleProducts(userRoleProducts);
		List<UserRole> userRoleList = new ArrayList<>();
		userRoleList.add(userRole);

		List<Object[]> prdtKeyList = new ArrayList<>();

		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(prdtKeyList);

		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userRoleList);
		userManagementDaoImpl.details(1245L, 1245L);
	}

	@Test
	public void testUpdateUserDetails() {

		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(1); //Start added for Partner Portal
		UserInfoRequest userInfoRequest=new UserInfoRequest();
		List <String> skills=new ArrayList<>();
		List <String> specialization=new ArrayList<>();
		List <String> paymentModes=new ArrayList<>();
		List <String> channel=new ArrayList<>();
		userInfoRequest.setUserKey(1245L);
		userInfoRequest.setMobileNumber("100");
		userInfoRequest.setIsActive(BigDecimal.ONE);
		userInfoRequest.setStatusChngReason(BigDecimal.ONE);
		userInfoRequest.setEmailId("g4545@gmail.com");
		userInfoRequest.setSpCode("1234");
		userInfoRequest.setLpCode("1234");
		userInfoRequest.setMaxSumAssuredLimit("1234");
		userInfoRequest.setMaxPremiumLimit("1234");
		userInfoRequest.setReportingManager("1234");
		userInfoRequest.setDescription("1234");
		userInfoRequest.setSamaccountname("1234");
		skills.add("Hindi");
		specialization.add("");
		paymentModes.add("");
		channel.add("");
		userInfoRequest.setSkills(skills);
		userInfoRequest.setSpecialization(specialization);
		userInfoRequest.setPaymentModes(paymentModes);
		userInfoRequest.setChannel(channel);
		userManagementDaoImpl.updateUserDetails(userInfoRequest);
	}

	@Test(expected = Exception.class)
	public void testGetSuperVisorLocations() {
		List<LocationBean> userList = new ArrayList<>();
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(0L);

		UserRole userRole = new UserRole();
		userRole.setBfsduser(bfsdUser);
		List<UserRole> userRoles = new ArrayList<>();
		userRoles.add(userRole);

		Object[] app = { new Object() };
		List<Object[]> bFlBranches = new ArrayList<>();
		bFlBranches.add(app);

		Mockito.when(entityManager.createNamedQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userRoles);

		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		assertEquals(userList, userManagementDaoImpl.getSuperVisorLocations("1"));
	}

	@Test(expected = Exception.class)
	public void testGetSuperVisorChannels() {
		List<ChannelBean> supervisorChannelList = new ArrayList<>();
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(0L);

		UserRole userRole = new UserRole();
		userRole.setBfsduser(bfsdUser);
		List<UserRole> userRoles = new ArrayList<>();
		userRoles.add(userRole);

		Object[] app = { new Object() };
		List<Object[]> bFlBranches = new ArrayList<>();
		bFlBranches.add(app);

		Mockito.when(entityManager.createNamedQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userRoles);

		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		assertEquals(supervisorChannelList, userManagementDaoImpl.getSuperVisorChannels("1"));
	}

	@Test
	public void testGetLocationPin() {
		List<PinCodeBean> pinCodeList = new ArrayList<>();
		List<Object[]> pinCodes = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(pinCodes);
		assertEquals(pinCodeList, userManagementDaoImpl.getLocationPin("1"));
	}


	@Test
	public void testgetUserLoginAccount() {

		UserLoginAccount userLoginAccount = new UserLoginAccount();
		UserLoginAccountRequest userLoginAccountRequest = new UserLoginAccountRequest();
		userLoginAccountRequest.setLoginId("122");
		userLoginAccountRequest.setLoginType((short) 8);
		userLoginAccountRequest.setUserType((short) 2);
		userLoginAccountRequest.setDateOfBirth("12-01-2018");

		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(1245L);

		List<Object[]> resultSet = new ArrayList<>();

		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(resultSet);

		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);

		Mockito.when(beanMapper.mapToUserLoginAccountBean(Mockito.any())).thenReturn(userLoginAccount);
		Mockito.when(query.getSingleResult()).thenReturn(userLoginAccount);

		Mockito.when(entityManager.merge(Mockito.any())).thenReturn(userLoginAccount);
		entityManager.persist(bfsdUser);
		entityManager.persist(userLoginAccount);
		userManagementDaoImpl.getUserLoginAccount(userLoginAccountRequest);
	}

	@Test
	public void testGetUserId() {

		List<UserLoginAccount> userLoginAccounts = new ArrayList<>();
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userLoginAccounts);
		userManagementDaoImpl.getUserId("1");
	}

	@Test
	public void testUpdateFailedCount() {

		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(-1L);
		entityManager.merge(bfsdUser);
		userManagementDaoImpl.updateFailedCount(bfsdUser, (short) -1, (short)5);
	}

	@Test
	public void testGetRolesByUserKey() {

		List<UserRole> result = new ArrayList<>();
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		assertEquals(result, userManagementDaoImpl.getRolesByUserKey(12456L));
	}

	@Test
	public void testGetListOfUserName() {
		long userkey = 12345;
		List<UserName> result = new ArrayList<>();
		List<Object[]> resultSet = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(resultSet);
		Mockito.when(beanMapper.mapToBean(Mockito.any())).thenReturn(result);
		assertEquals(result, userManagementDaoImpl.getListOfUserName(userkey, userkey, userkey, userkey, userkey));
	}

	@Test
	public void testGetUserProfileByUserKey() {
		List<Object[]> userProfiles = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userProfiles);
		userManagementDaoImpl.getUserProfileByUserKey(12456L);
	}

	@Test
	public void testAssignRoleToUser() {
		BfsdUser currentUser = new BfsdUser();
		currentUser.setUserkey(1245L);
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(1245L);

		List<UserRole> userRoles = new ArrayList<>();

		Mockito.when(entityManager.createNamedQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenReturn(bfsdRoleMaster);
		Mockito.when(query.getResultList()).thenReturn(userRoles);
		userManagementDaoImpl.assignRoleToUser(currentUser, (short) 5, (short) 3);
	}

	@Test
	public void testAutoRegister() {

		AutoRegisterRequest request = new AutoRegisterRequest();
		request.setUserKey(1245L);
		request.setLoginId("122");
		request.setFirstName("FirstName");
		request.setLastName("LastName");
		request.setMobile("90046464");
		request.setEmail("Email");
		request.setDateOfBirth("12-02-1992");

		UserLoginAccount loginAccount = new UserLoginAccount();

		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenReturn(loginAccount);
		Mockito.when(query.executeUpdate()).thenReturn(1);

		userManagementDaoImpl.autoRegister(request);
	}

	@Test(expected = Exception.class)
	public void testAutoRegister_Fail() {

		AutoRegisterRequest request = new AutoRegisterRequest();
		request.setUserKey(1245L);
		request.setLoginId("122");
		request.setFirstName("FirstName");
		request.setLastName("LastName");
		request.setMobile("90046464");
		request.setEmail("Email");
		request.setDateOfBirth("12-02-1992");

		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenThrow(NonUniqueResultException.class);
		Mockito.when(query.executeUpdate()).thenReturn(1);

		userManagementDaoImpl.autoRegister(request);
	}

	@Test
	public void testSavePassword() {
		long userkey = 12345;
		UserLoginAccount loginAcct = new UserLoginAccount();
		loginAcct.getUserloginacctype();
		loginAcct.getLstupdatedt();
		loginAcct.getLstupdateby();
		loginAcct.getCreationdate();
		loginAcct.setUserloginacckey(44L);
		loginAcct.getUserloginacckey();
		loginAcct.setLoginid("1245");
		List<UserLoginAccount> loginAccts = new ArrayList<>();
		loginAccts.add(loginAcct);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(loginAccts);
		short userType=8;
		userManagementDaoImpl.savePassword("ABC", "XYZ", userkey);
	}
	
	@Test(expected=Exception.class)
	public void testSavePassword1() {
		long userkey = 12345;
		UserLoginAccount loginAcct = new UserLoginAccount();
		loginAcct.getUserloginacctype();
		loginAcct.getLstupdatedt();
		loginAcct.getLstupdateby();
		loginAcct.getCreationdate();
		loginAcct.setUserloginacckey(44L);
		loginAcct.getUserloginacckey();
		loginAcct.setLoginid("1245");
		List<UserLoginAccount> loginAccts = new ArrayList<>();
		loginAccts.add(loginAcct);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(loginAccts);
		short userType=8;
		userManagementDaoImpl.savePassword("ABC", "", userkey);
	}

	@Test
	public void testSearchUser() {
		UserConfigurationBean userConfigurationBean = new UserConfigurationBean();
		userConfigurationBean.setEmployeeType("vendorCompany");
		userConfigurationBean.setFirstName("fName");
		userConfigurationBean.setLastName("lName");
		userConfigurationBean.setEmailId("email");
		userConfigurationBean.setCompanyName("companyName");
		userConfigurationBean.setPrincipalUser("principalUser");
		userConfigurationBean.getUserVendorList();
		userConfigurationBean.isStatusIfExist();
		userConfigurationBean.getUserADList();
		List<UserProfile> result = new ArrayList<>();
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		assertEquals(result, userManagementDaoImpl.searchUser(userConfigurationBean));
	}

	@Test
	public void testMergeUsers() {
		long userkey = 12345;
		BfsdUser oldUser = new BfsdUser();
		oldUser.setUserkey(userkey);
		oldUser.getBfsdUser();
		oldUser.getBfsdUsers();
		oldUser.getIsactive();
		oldUser.getLstfailedlogindt();
		oldUser.getLstupdateby();
		oldUser.getLstupdatedt();
		oldUser.getRegistrationdate();
		oldUser.getStatuschngreason();
		oldUser.getUserApplicants();
		oldUser.getUserApplicants();
		UserLoginAccount newLoginAcct = new UserLoginAccount();
		newLoginAcct.setBfsdUser(oldUser);
		List<UserLoginAccount> accounts = new ArrayList<>();
		accounts.add(newLoginAcct);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenReturn(oldUser);
		Mockito.when(query.getResultList()).thenReturn(accounts);
		assertEquals(newLoginAcct, userManagementDaoImpl.mergeUsers(userkey, userkey));
	}

	@Test
	public void testCheckLoginEmail() {
		List<UserLoginAccount> loginAccts = new ArrayList<>();
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(loginAccts);
		userManagementDaoImpl.checkLoginEmail("ABC");
	}

	@Test
	public void testCheckApplicantEmail() {
		List<Object[]> emails = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(emails);
		userManagementDaoImpl.checkApplicantEmail("gmail", 1245L);
	}

	@Test
	public void testSaveEmail() {
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(1);
		userManagementDaoImpl.saveEmail(1245L, "gmail", "abc");
	}

	@Test
	public void testexiprePrevLinks() {
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		userManagementDaoImpl.exiprePrevLinks("gmail", 1245L);
	}

	@Test
	public void testGetUserVendorProfile() {
		long userkey = 12345;
		List<UserProfile> userVendorProfiles = new ArrayList<>();

		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userVendorProfiles);
		userManagementDaoImpl.getUserVendorProfile(userkey, userkey, "@gmail");
	}

	@Test
	public void testGetUserVendorProfile1() {
		long userkey = 0L;
		List<UserProfile> userVendorProfiles = new ArrayList<>();

		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userVendorProfiles);
		userManagementDaoImpl.getUserVendorProfile(userkey, userkey, "");
	}

	@Test
	public void testSaveUserVendorProfile() {
		UserProfile userVendorProfile = new UserProfile();
		userVendorProfile.setAssociationtype(new BigDecimal(2));
		userVendorProfile.setCompanyname("bajaj");
		userVendorProfile.setUserprofilekey(1245L);
		userVendorProfile.setIsactive(BigDecimal.ONE);

		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		userManagementDaoImpl.saveUserVendorProfile(userVendorProfile);
	}

	@Test
	public void testgetUserRoleProductsByUserKey() {
		List<Object[]> result = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		userManagementDaoImpl.getUserRoleProductsByUserKey(1245L);
	}

	@Test
	public void testGetUserLoginAccountMultipleUser() {
		ReflectionTestUtils.setField(userManagementDaoImpl, "logger", logger);
		UserLoginAccountRequest userLoginAccountRequest = UserManagementTestData.pouserLoginAccountRequest();
		UserLoginAccount loginAccount = UserManagementTestData.popUserLoginAccount();
		List<Object[]> listArgs = UserManagementTestData.popListObject();
		Mockito.when(entityManager.createNativeQuery(QueryConstants.FETCH_LOGIN_USER_DETAILS_WITH_LOGINID_DOB))
				.thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(listArgs);
		Mockito.when(beanMapper.mapToUserLoginAccountBean(listArgs)).thenReturn(loginAccount);
		// method under test
		UserLoginAccount result = userManagementDaoImpl.getUserLoginAccount(userLoginAccountRequest);
		assertEquals("987654", String.valueOf(result.getBfsdUser().getUserkey()));
	}

	@Test
	public void testGetUserLoginAccountSingleUser() {
		ReflectionTestUtils.setField(userManagementDaoImpl, "logger", logger);
		UserLoginAccountRequest userLoginAccountRequest = UserManagementTestData.pouserLoginAccountRequest();
		userLoginAccountRequest.setLoginType((short) 2);
		UserLoginAccount loginAccount = UserManagementTestData.popUserLoginAccount();
		Mockito.when(entityManager.createQuery(QueryConstants.FETCH_LOGIN_USER_DETAILS_WITH_LOGINID)).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenReturn(loginAccount);
		// method under test
		UserLoginAccount result = userManagementDaoImpl.getUserLoginAccount(userLoginAccountRequest);
		assertEquals("987654", String.valueOf(result.getBfsdUser().getUserkey()));
	}

	@Test(expected = Exception.class)
	public void testDeleteUserMapping() {

		UserRole role = new UserRole();
		role.setUserrolekey(12345L);
		List<UserRole> userRoleKeyLists = new ArrayList<>();
		userRoleKeyLists.add(role);

		List<Long> appViewKeys = new ArrayList<>();

		DeleteUserRoleBean bean = new DeleteUserRoleBean();
		bean.setUserKey(12345L);
		bean.setRoleKey(12345L);
		bean.setAppViewKeys(appViewKeys);
		bean.setAppUserViewKeys(appViewKeys);
		bean.setAppViewRoleKeys(appViewKeys);
		bean.setSrViewKeys(appViewKeys);
		bean.setSrUserViewKeys(appViewKeys);
		bean.setSrViewRoleKeys(appViewKeys);

		Object[] result = (Object[]) new Object();
		List<Object[]> results = new ArrayList<>();
		results.add(result);

		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userRoleKeyLists);

		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(results);
		Mockito.when(query.executeUpdate()).thenReturn(1);

		Mockito.when(entityManager.createNamedQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(1);

		userManagementDaoImpl.deleteUserMapping(12454L, 1245L);
	}

	@Test(expected = Exception.class)
	public void testCreateUserMapping() {
		List<Long> list = new ArrayList<>();
		Long userkey = 12452L;
		list.add(userkey);
		Mockito.when(entityManager.getCriteriaBuilder()).thenReturn(criteriaBlder);
		Mockito.when(criteriaBlder.createQuery(Mockito.any())).thenReturn(criteriaQry);
		UserMappingRequest userMappingBean = new UserMappingRequest();
		userMappingBean.setUserKey(userkey);
		userMappingBean.setRoleKey(userkey);
		userMappingBean.isHighestRole();
		userMappingBean.setSupervisor(userkey);
		userMappingBean.setCreditLimit(userkey);
		userMappingBean.setEmployeeType("employee");
		userMappingBean.setUserlockey(list);
		userMappingBean.setUserChannelkey(list);
		userMappingBean.setUserPinCdKey(list);

		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(userkey);
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(userkey);

		UserRole userRole = new UserRole();
		userRole.setBfsduser(bfsdUser);
		userRole.setBfsdRoleMaster(bfsdRoleMaster);

		List<UserRole> existUserRole = new ArrayList<>();
		existUserRole.add(userRole);

		BigDecimal[] app = { new BigDecimal(1L), new BigDecimal(1L), new BigDecimal(1L), new BigDecimal(1L),
				new BigDecimal(1L), new BigDecimal(1L) };
		List<Object[]> branchKeyList = new ArrayList<>();
		branchKeyList.add(app);

		BigDecimal[] app1 = { new BigDecimal(1L), new BigDecimal(1L), new BigDecimal(1L), new BigDecimal(1L),
				new BigDecimal(1L), new BigDecimal(1L) };
		List<Object[]> channelKeyList = new ArrayList<>();
		channelKeyList.add(app1);

		AppViewDefinition appViewDef = new AppViewDefinition();
		List<AppViewDefinition> appViewDefinitionList = new ArrayList<>();
		appViewDefinitionList.add(appViewDef);

		SerReqViewDefinition serReqViewDefinition = new SerReqViewDefinition();
		List<SerReqViewDefinition> aSerReqViewDefinitions = new ArrayList<>();
		aSerReqViewDefinitions.add(serReqViewDefinition);

		Mockito.when(entityManager.find(Mockito.any(), Mockito.any())).thenReturn(bfsdRoleMaster).thenReturn(bfsdUser);

		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(branchKeyList).thenReturn(channelKeyList);

		Mockito.when(entityManager.merge(Mockito.any())).thenReturn(userRole);
		entityManager.merge(appViewDef);
		entityManager.merge(serReqViewDefinition);

		userManagementDaoImpl.createUserMapping(userMappingBean);
	}

	@Test(expected = Exception.class)
	public void testUpdateUserMapping() {
		UserMappingRequest userMappingBean = new UserMappingRequest();
		userMappingBean.setOldMappingRequest(userMappingBean);
		userMappingBean.setRoleKey(1245L);
		userMappingBean.setSupervisor(1245L);

		Mockito.when(entityManager.getCriteriaBuilder()).thenReturn(criteriaBlder);
		Mockito.when(criteriaBlder.createQuery(Mockito.any())).thenReturn(criteriaQry);
		assertEquals("", userManagementDaoImpl.updateUserMapping(userMappingBean));
	}

	@Test
	public void testGetUserEmpDetails() {
		UserConfigurationBean userConfig = new UserConfigurationBean();
		userConfig.setFirstName("FirstName");
		userConfig.setLastName("LastName");
		userConfig.setEmailId("EmailId");
		userConfig.setDesignation("Designation");
		userConfig.setFirstName("FirstName");
		List<User> userList = new ArrayList<>();
		Mockito.when(ldaputility.getADUsers(Mockito.any())).thenReturn(userList);
		userManagementDaoImpl.getUserEmpDetails(userConfig, userConfig);
	}
	@Test
	public void testUpdateTokenStat() {
		ValidateTokenBean tokenBean = new ValidateTokenBean();
		tokenBean.setToken("ajshdgjHSgdjhsadgjhsagjh");
		AppContactAuthRequest appContactAuthRequest = new AppContactAuthRequest();
		AppContactAuthValidation appContactAuthValidation= new AppContactAuthValidation();
		List<AppContactAuthValidation> list = new ArrayList<>();
		list.add(appContactAuthValidation);
		appContactAuthRequest.setAppContactAuthValidations(list);
		userManagementDaoImpl.updateTokenStatus(tokenBean, appContactAuthRequest, new Timestamp(Long.valueOf(0)), BigDecimal.ONE);
	}
	
	@Test
	public void testgetSystemUsers() {
		UserLoginAccount userLoginAccount = new UserLoginAccount();
		userLoginAccount.setLoginid("test1");
		userLoginAccount.setLoginpwd("test1");
		List<UserLoginAccount> userLoginAccountsList= new ArrayList<>();
		userLoginAccountsList.add(userLoginAccount);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userLoginAccountsList);
		assertEquals(userLoginAccountsList, userManagementDaoImpl.getSystemUsers());
	}
	
	@Test
	public void testGetUserInfoByUserKey(){
		List<UserProfile> userList = new ArrayList<UserProfile>();
		UserProfile userProfile = new UserProfile();
		userProfile.setFirstname("Test");
		userProfile.setLastname("Test");
		userList.add(userProfile);
		List<UserRole> userRoleList = new ArrayList<>();
		UserRole userRole = new UserRole();
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(24l);
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		userRoleList.add(userRole);
		Mockito.when(entityManager.createQuery("from UserProfile userpr where userpr.bfsdUser.userkey=:userkey and userpr.isactive = 1")).thenReturn(query);
		Mockito.when(entityManager.createQuery(QueryConstants.QRY_GET_USER_ROLES_BY_USERKEY)).thenReturn(query1);
		Mockito.when(query.getResultList()).thenReturn(userList);
		Mockito.when(query1.getResultList()).thenReturn(userRoleList);
		userManagementDaoImpl.getUserInfoByUserKey(1007l);
	}
	
	@Test
	public void testGetUserInfoByEmail(){
		String userEmail = "bala@bajajfinserv.in";
		List<UserProfile> userList = new ArrayList<UserProfile>();
		UserProfile userProfile = new UserProfile();
		userProfile.setFirstname("Test");
		userProfile.setLastname("Test");
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(1141l);
		bfsdUser.setUsertype(BigDecimal.ONE);
		userProfile.setBfsdUser(bfsdUser);
		userList.add(userProfile);
		List<UserRole> userRoleList = new ArrayList<>();
		UserRole userRole = new UserRole();
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(24l);
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		userRoleList.add(userRole);
		Mockito.when(entityManager.createQuery("from UserProfile userpr where userpr.emailid=:userEmail and userpr.isactive = 1")).thenReturn(query);
		Mockito.when(entityManager.createQuery(QueryConstants.QRY_GET_USER_ROLES_BY_USERKEY)).thenReturn(query1);
		Mockito.when(query.getResultList()).thenReturn(userList);
		Mockito.when(query1.getResultList()).thenReturn(userRoleList);
		userManagementDaoImpl.getUserInfoByEmail(userEmail);
	}
	@Test
	public void test_getUserProfilesByRoleKeys() {
		List<Long> roleKeyList = new ArrayList<>();
		roleKeyList.add(67L);
		List<UserProfileDetails> userProfiles = new ArrayList<>();
		UserProfileDetails userProfileDetails = new UserProfileDetails();
		userProfileDetails.setUserRoleKey(67L);
		userProfiles.add(userProfileDetails);
		List<Object[]> userDetails = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(QueryConstants.USER_PROFILES_BY_ROLEKEY)).thenReturn(query);
		Mockito.when(query.setParameter("rolekeys", roleKeyList)).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userDetails);
		assertEquals(new ArrayList<>(), userManagementDaoImpl.getUserProfilesByRoleKeys(roleKeyList));
	}
	
	@Test
	public void testGetUserInfoByAdid(){
		String userAdid = "sfsd353";
		List<UserProfile> userList = new ArrayList<UserProfile>();
		UserProfile userProfile = new UserProfile();
		userProfile.setFirstname("Test");
		userProfile.setLastname("Test");
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(1141l);
		bfsdUser.setUsertype(BigDecimal.ONE);
		userProfile.setBfsdUser(bfsdUser);
		userList.add(userProfile);
		List<UserRole> userRoleList = new ArrayList<>();
		UserRole userRole = new UserRole();
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(24l);
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		userRoleList.add(userRole);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userList);
		Mockito.when(entityManager.createQuery(QueryConstants.QRY_GET_USER_ROLES_BY_USERKEY)).thenReturn(query1);
		Mockito.when(query1.getResultList()).thenReturn(userRoleList);
		userManagementDaoImpl.getUserInfoByAdId(userAdid);
	}
	
	@Test(expected=Exception.class)
	public void testdeleteUserMapping() {
		Long employeeKey = 1L;
		Long roleKey = 2L;
		List<UserRole> userRoleKeyLists = new ArrayList<>();
		UserRole userRole = new UserRole();
		userRole.setUserrolekey(1);
		userRole.setLstupdateby(null);
		userRole.setIsactive(BigDecimal.ONE);
		userRoleKeyLists.add(userRole);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyInt(), Mockito.any())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyInt(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userRoleKeyLists);
		userManagementDaoImpl.deleteUserMapping(employeeKey,roleKey);
	}
	@Test
    public void getUserRoleInfoTest() {
		Long userKey= 1L;
		Long roleKey=2L;		
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		userManagementDaoImpl.getUserRoleInfo(userKey,roleKey);
		
	}
	
	@Test
    public void getUserInfoTest() {
		Long userRoleKey= 1L;
		List<UserRole> userRoles= new ArrayList<>();
		Mockito.when(entityManager.createNamedQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userRoles);
		
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		userManagementDaoImpl.getUserInfo(userRoleKey);
	}
	
}