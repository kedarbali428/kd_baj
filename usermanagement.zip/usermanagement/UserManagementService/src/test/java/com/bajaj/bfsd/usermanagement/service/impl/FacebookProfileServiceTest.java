package com.bajaj.bfsd.usermanagement.service.impl;

import org.json.simple.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.UserProfileSaveRequest;
import com.bajaj.bfsd.usermanagement.dao.UserProfileDao;
import com.google.gson.Gson;

@RunWith(PowerMockRunner.class)
public class FacebookProfileServiceTest {
	@InjectMocks
	FacebookProfileService  facebookProfileService;
	
	@Mock
    private BFLLoggerUtil logger;
	
	@Mock
	private UserProfileDao facebookDao;
	
	@Test
	public void testsaveUserProfile() {
		UserProfileSaveRequest profileSaveRequest=new UserProfileSaveRequest();
		JSONObject facebookProfileBean=new JSONObject();
		JSONObject age=new JSONObject();
		facebookProfileBean.put("first_name", "");
		facebookProfileBean.put("last_name", "");
		facebookProfileBean.put("email", "");
		facebookProfileBean.put("id", "");
		facebookProfileBean.put("is_verified", true);
		facebookProfileBean.put("link", "");
		age.put("min", 18);
		facebookProfileBean.put("age_range",age );
		profileSaveRequest.setProfileJson(new Gson().toJson(facebookProfileBean));
		facebookProfileService.saveUserProfile(profileSaveRequest);
	}
	
	@Test
	public void testGetUser() {
		facebookProfileService.getUserProfile(1l);
	}

}
