package com.bajaj.bfsd.usermanagement.service.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.JDBCException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.model.ApplicantPhoneNumberV2;
import com.bajaj.bfsd.usermanagement.model.ApplicantV2;
import com.bajaj.bfsd.usermanagement.model.ApplicationApplicantV2;
import com.bajaj.bfsd.usermanagement.model.ApplicationV2;
import com.bajaj.bfsd.usermanagement.model.BfsdUserV2;
import com.bajaj.bfsd.usermanagement.model.UserApplicantV2;
import com.bajaj.bfsd.usermanagement.model.UserProfileEntity;
import com.bajaj.bfsd.usermanagement.repository.ApplicationApplicantRepository;
import com.bajaj.bfsd.usermanagement.repository.BfsdUserRepository;
import com.bajaj.bfsd.usermanagement.repository.BfsdUserV2Repository;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserProfileServiceImplTest {

	@InjectMocks
	private UserProfileServiceImpl userProfileServiceImpl;
	
	@Mock
	private BFLLoggerUtil logger;
	
	@Mock
	private BfsdUserV2Repository bfsdUserRepositoryV2;

	@Mock
	private BfsdUserRepository bfsdUserRepository;
	
	@Mock
	private ApplicationApplicantRepository applicationApplicantRepository;
	
	private String limitOne;
	
	private String limitTwo;
	
	@Before
	public void setUp() {
		ReflectionTestUtils.setField(userProfileServiceImpl, "limitOne", "1");
		ReflectionTestUtils.setField(userProfileServiceImpl, "limitTwo", "2");
	}
	
	@Test
	public void testLoadUserProfileV2() {
		
		ApplicantPhoneNumberV2 applicantPhoneNumber = new ApplicantPhoneNumberV2();
		applicantPhoneNumber.setApltphnumkey(1234L);
		applicantPhoneNumber.setApltphnumnumber("9988776655");
		applicantPhoneNumber.setApplicantkey(123L);
		
		List<ApplicantPhoneNumberV2> phoneNumbers = new ArrayList<>();
		phoneNumbers.add(applicantPhoneNumber);
		
		ApplicationV2 applicationDetails = new ApplicationV2();
		applicationDetails.setAppprocessidentifier("APPLID12345");
		
		ApplicationApplicantV2 application = new ApplicationApplicantV2();
		application.setAppapltkey(14L);
		application.setApplicantkey(123L);
		application.setApplicationkey(23L);
		application.setApplication(applicationDetails);
		
		List<ApplicationApplicantV2> applications = new ArrayList<>();
		applications.add(application);

		ApplicantV2 applicant = new ApplicantV2();
		applicant.setApltdateofbirth(new Date());
		applicant.setApplicantkey(123L);
		applicant.setApplicantPhoneNumbers(phoneNumbers);
		applicant.setApplicationApplicants(applications);
		
		
		UserApplicantV2 applicantV2 = new UserApplicantV2();
		applicantV2.setApplicantkey(123L);
		applicantV2.setUserapplicantkey(12L);
		applicantV2.setUserkey(1L);
		applicantV2.setApplicant(applicant);
		List<UserApplicantV2> userApplicants = new ArrayList<>();
		userApplicants.add(applicantV2);
	
		BfsdUserV2 user1 = new BfsdUserV2();
		user1.setUserkey(1L);
		user1.setUsertype(UserManagementConstants.USERTYPE_CUSTOMER);
		user1.setUserApplicants(userApplicants);
		
		List<BfsdUserV2> bfsdUsers = new ArrayList<>();
		bfsdUsers.add(user1);
		
		Mockito.when(bfsdUserRepositoryV2.findByUserkeyAndUsertypeNot(Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(bfsdUsers);
		
		UserProfileEntity loadUserProfileV2 = userProfileServiceImpl.loadUserProfileV2(1234L);
		assertNotNull(loadUserProfileV2);	
	}

	@Test(expected = BFLTechnicalException.class)
	public void testLoadUserProfileV2_ThrowsException() {
		Mockito.when(bfsdUserRepositoryV2.findByUserkeyAndUsertypeNot(Mockito.anyLong(), Mockito.anyLong()))
			.thenThrow(JDBCException.class);
		userProfileServiceImpl.loadUserProfileV2(1234L);
	}
	
}
