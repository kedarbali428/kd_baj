package com.bajaj.bfsd.usermanagement.data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountRequest;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;

public class UserManagementTestData {
	
	public static UserLoginAccountRequest pouserLoginAccountRequest() {
		UserLoginAccountRequest loginAccountRequest = new UserLoginAccountRequest();
		loginAccountRequest.setLoginId("9182736450");
		loginAccountRequest.setDateOfBirth("03/03/1992");
		loginAccountRequest.setLoginType((short) 8);
		loginAccountRequest.setPwd("111111");
		loginAccountRequest.setUserType((short)1);
		return loginAccountRequest;
	}
	
	public static UserLoginAccount popUserLoginAccount() {
		UserLoginAccount userLoginAccount = new UserLoginAccount();
		userLoginAccount.setBfsdUser(popBfsdUser());
		userLoginAccount.setLoginpwd("bcb15f821479b4d5772bd0ca866c00ad5f926e3580720659cc80d39c9d09802a");
		return userLoginAccount;
		
	}
	
	public static BfsdUser popBfsdUser() {
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setFailedlogincount(new BigDecimal("0"));
		bfsdUser.setUserkey(Long.valueOf("987654"));
		bfsdUser.setUserblockedflg(new BigDecimal("0"));
		return bfsdUser;
	}
	
	public static List<Object[]> popListObject(){
		List<Object[]> resultSet = new ArrayList<>();
		Object[] args = new Object[] {"pass", "","", "","", "","", "","", ""};
		resultSet.add(args);
		return resultSet;
	}

}
