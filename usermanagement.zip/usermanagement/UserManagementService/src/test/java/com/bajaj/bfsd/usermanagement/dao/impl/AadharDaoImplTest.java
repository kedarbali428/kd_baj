package com.bajaj.bfsd.usermanagement.dao.impl;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.AadharProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserAddress;
import com.bajaj.bfsd.usermanagement.bean.UserEmail;
import com.bajaj.bfsd.usermanagement.bean.UserPhone;
import com.bajaj.bfsd.usermanagement.model.LoanProductType;
import com.bajaj.bfsd.usermanagement.model.UserProfile;
import com.bajaj.bfsd.usermanagement.model.UserProfileAadhaar;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@SpringBootTest
public class AadharDaoImplTest {
	@InjectMocks
	private AadharDaoImpl aadharDaoImpl;
	
	@Mock
	EntityManager entityManager;
	
	@Mock
    private BFLLoggerUtil logger;
	
	@Mock
	private Environment env;
	@Mock
	private Query query;
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	
	@Test
	public void testSaveProfile() throws JsonProcessingException {
		ObjectMapper mapper=new ObjectMapper();
		mapper.writeValueAsString(new LoanProductType());
		mapper.writeValueAsString(new UserProfile());
		AadharProfileBean aadharProfile=new AadharProfileBean();
		List<UserAddress> addressDetails=new ArrayList<>();
		UserAddress userAddress=new UserAddress();
		userAddress.setAddrLine1("sdfsdfsdf");
		userAddress.setAddrLine2("sdfsdfsdf");
		userAddress.setAddrType("sdc");
		userAddress.setPin("123456");
		addressDetails.add(userAddress);
		List<UserEmail> emailList=new ArrayList<>();
		UserEmail email=new UserEmail();
		emailList.add(email);
		List<UserPhone> userPhones=new ArrayList<>();
		UserPhone userPhone=new UserPhone();
		userPhones.add(userPhone);
		aadharProfile.setEmailDetails(emailList);
		aadharProfile.setAddressDetails(addressDetails);
		aadharProfile.setPhoneNumberDetails(userPhones);
		Mockito.when(entityManager
				.createNativeQuery(Mockito.any())).thenReturn(query);
		aadharDaoImpl.saveProfile(aadharProfile, 1l, "");
		verify(entityManager, times(4)).persist(Mockito.any());
	}
	
	@Test
	public void testGetProfile() {
		UserProfileAadhaar aadharEntit=new UserProfileAadhaar();
		aadharEntit.setAadhaarnumber("10987");
		Mockito.when(entityManager
				.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenReturn(aadharEntit);
		aadharDaoImpl.getUserProfile(1l);
		verify(query, times(1)).getSingleResult();
	}
	
	

}
