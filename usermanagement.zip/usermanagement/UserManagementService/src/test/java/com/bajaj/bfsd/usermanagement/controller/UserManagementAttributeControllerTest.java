package com.bajaj.bfsd.usermanagement.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.usermanagement.bean.BusinessVerticalBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoBean;
import com.bajaj.bfsd.usermanagement.bean.UserRoleBean;
import com.bajaj.bfsd.usermanagement.beanmapper.BeanMapper;
import com.bajaj.bfsd.usermanagement.service.UserManagementAttributeService;
import com.bajaj.bfsd.usermanagement.service.UserManagementService;

@RunWith(PowerMockRunner.class)
public class UserManagementAttributeControllerTest {
	@InjectMocks
	UserManagementAttributeController userManagementAttributeController;
	
	@Mock
    BFLLoggerUtil logger;
	
	@Mock
	Environment env;
	
	@Mock
	BeanMapper beanMapper;
	
	@Mock
	UserManagementAttributeService userManagementAttributeService;
	
	@Mock
	HttpHeaders headers;
	
	@SuppressWarnings("unchecked")
	@Test
	public void testGetUserDetailsByUserKey(){
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(userManagementAttributeService.getUserDetailsByUserKey(19076)).thenReturn(userInfoBean);
		ResponseEntity<ResponseBean> responseEntity = (ResponseEntity<ResponseBean>) userManagementAttributeController.getUserDetailsByUserKey(19076L, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}	
	@SuppressWarnings("unchecked")
	@Test
	public void testGetBusinessVerticalAndPOTypes(){
		List<BusinessVerticalBean> businessVerticalBeans = new ArrayList<BusinessVerticalBean>();
		Mockito.when(userManagementAttributeService.getBusinessVerticalAndPOTypes()).thenReturn(businessVerticalBeans);
		ResponseEntity<ResponseBean> responseEntity = (ResponseEntity<ResponseBean>) userManagementAttributeController.getBusinessVerticalAndPOTypes(headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	@SuppressWarnings("unchecked")
	@Test(expected = Exception.class)
	public void testGetBusinessVerticalAndPOTypesFailure(){
		Mockito.when(userManagementAttributeService.getBusinessVerticalAndPOTypes()).thenThrow(Exception.class);
		ResponseEntity<ResponseBean> responseEntity = (ResponseEntity<ResponseBean>) userManagementAttributeController.getBusinessVerticalAndPOTypes(headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
}