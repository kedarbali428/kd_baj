package com.bajaj.openmarkets.usermanagement.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserProdMappingBean;
import com.bajaj.bfsd.usermanagement.dao.UserMgmtProdDao;
import com.bajaj.bfsd.usermanagement.model.BfsdRoleMaster;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserRoleL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleProductL3;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataInsurancePluginMapper;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataPluginMapper;
import com.bajaj.bfsd.usermanagement.service.impl.UserMgmtProdServiceImpl;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bfl.common.exceptions.BFLBusinessException;

@SpringBootTest
public class UserMgmtProdServiceImplTest {
	
	@InjectMocks
	UserMgmtProdServiceImpl userMgmtProdServiceImpl;
	
	@Mock
	BFLLoggerUtil logger;

	@Mock
	Environment env;

	@Mock
	UserMgmtProdDao userMgmtProdDao;

	@Mock
	UserProfileBean upb;

	@Mock
	OMMasterDataPluginMapper omMasterDataPluginMapper;

	@Mock
	OMMasterDataInsurancePluginMapper oMMasterDataInsurancePluginMapper;
	
	@Mock
	EntityManager entityManager;
	
	HttpHeaders headers =null;
	
	@Before
	public void setUp() {
		headers = new HttpHeaders();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getUserDetailsTest(){
		UserConfigurationBean userConfig = new UserConfigurationBean();
		userConfig.setUserKey(1l);
		Mockito.when(userMgmtProdDao.getUserDetails(userConfig, headers)).thenReturn(userConfig);
		UserConfigurationBean userConfigurationBean = userMgmtProdServiceImpl.getUserDetails(userConfig, headers);
		assertEquals(userConfigurationBean.getUserKey(), userConfig.getUserKey());
	}
	
	@Test(expected = BFLBusinessException.class)
	public void saveUserMappingTestUserRoleKeyZeroUserRoleIsNull(){
		UserProdMappingBean inputBean = getUserProdMappingBean();
		Mockito.when(userMgmtProdDao.fetchUserRole(Mockito.anyLong(), Mockito.anyLong())).thenReturn(null);
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		Mockito.when(userMgmtProdDao.getEntity(BfsdRoleMaster.class, inputBean.getRoleKey())).thenReturn(bfsdRoleMaster);
		BfsdUser bfsdUser = new BfsdUser();
		Mockito.when(userMgmtProdDao.getEntity(BfsdUser.class, inputBean.getUserKey())).thenReturn(bfsdUser);
		Mockito.when(userMgmtProdDao.getAllLocations()).thenReturn(new ArrayList(Arrays.asList(1l,2l)));
		Mockito.when(userMgmtProdDao.getAllChannels()).thenReturn(new ArrayList(Arrays.asList(1l,2l)));
		UserRoleProductL3 parentUserRoleProduct = new UserRoleProductL3();
		Mockito.when(userMgmtProdDao.getEntity(UserRoleProductL3.class,inputBean.getSupervisorRoleProdKey())).thenReturn(parentUserRoleProduct);
		userMgmtProdServiceImpl.saveUserMapping(inputBean, headers);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void saveUserMappingTestUserRoleKeyZeroUserRoleIsNotNull(){
		UserProdMappingBean inputBean = getUserProdMappingBean();
		UserRoleL3 userRole = new UserRoleL3();
		userRole.setUserrolekey(1l);
		Mockito.when(userMgmtProdDao.fetchUserRole(Mockito.anyLong(), Mockito.anyLong())).thenReturn(userRole);
		List<UserRoleProductL3> existingUserRoles = new ArrayList<>();
		UserRoleProductL3 userRoleProduct = new UserRoleProductL3();
		userRoleProduct.setIsactive(1);
		existingUserRoles.add(userRoleProduct);
		Mockito.when(userMgmtProdDao.getUserProdMapping(
						userRole.getUserrolekey(), inputBean.getLoanProdKey(), inputBean.getProdMastKey())).thenReturn(existingUserRoles);
		userMgmtProdServiceImpl.saveUserMapping(inputBean, headers);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void saveUserMappingTestUserRoleKeyNotZeroUserRoleProdNull(){
		UserProdMappingBean inputBean = getUserProdMappingBean();
		inputBean.setUserRoleProdKey(1l);
		UserRoleProductL3 userRoleProduct = new UserRoleProductL3();
		userRoleProduct.setIsactive(1);
		Mockito.when(userMgmtProdDao.getEntity(UserRoleProductL3.class, inputBean.getUserRoleProdKey())).thenReturn(null);
		userMgmtProdServiceImpl.saveUserMapping(inputBean, headers);
	}
	
	@Test
	public void saveUserMappingTestUserRoleKeyNotZeroUserRoleProdNotNull(){
		UserProdMappingBean inputBean = getUserProdMappingBean();
		inputBean.setUserRoleProdKey(1l);
		UserRoleProductL3 userRoleProduct = new UserRoleProductL3();
		userRoleProduct.setIsactive(1);
		userRoleProduct.setUserprodkey(1l);
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(1l);
		UserRoleL3 userRoleL3 = new UserRoleL3();
		userRoleL3.setBfsdRoleMaster(bfsdRoleMaster);
		userRoleProduct.setUserRole(userRoleL3);
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(1l);
		userRoleL3.setBfsduser(bfsdUser);
		Mockito.when(userMgmtProdDao.getEntity(UserRoleProductL3.class, inputBean.getUserRoleProdKey())).thenReturn(userRoleProduct);
		Mockito.when(userMgmtProdDao.saveUserMapping(userRoleL3)).thenReturn(userRoleL3);
		userMgmtProdServiceImpl.saveUserMapping(inputBean, headers);
	}

	private UserProdMappingBean getUserProdMappingBean() {
		UserProdMappingBean userBean = new UserProdMappingBean();
		userBean.setUserRoleProdKey(0l);
		userBean.setUserKey(1l);
		userBean.setRoleKey(1l);
		userBean.setEmployeeType(UserManagementConstants.EMPLOYEE);
		userBean.setHighRole(true);
		userBean.setSupervisorRoleProdKey(1l);
		userBean.setLoanProdKey(1l);
		userBean.setProdMastKey(1l);
		return userBean;
	}
}
