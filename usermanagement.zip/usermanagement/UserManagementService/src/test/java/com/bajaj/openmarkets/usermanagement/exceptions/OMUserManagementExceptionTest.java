package com.bajaj.openmarkets.usermanagement.exceptions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.domain.ErrorBean;

@RunWith(SpringJUnit4ClassRunner.class)
public class OMUserManagementExceptionTest {

	@InjectMocks
	private OMUserManagementException exception;
	
	@Test
	public void testOMUserManagementException() {
		exception.setCode(HttpStatus.OK);
		exception.setErrorBean(new ErrorBean());
		exception.setPayload(new Object());
		assertNotNull(exception.getCode());
		assertNotNull(exception.getErrorBean());
		assertNotNull(exception.getPayload());
		assertNotNull(exception);
	}

	@Test
	public void testOMUserManagementExceptionHttpStatusErrorBeanObject() {
		exception = new OMUserManagementException(HttpStatus.OK, new ErrorBean(), new Object());
		assertNotNull(exception.getCode());
		assertNotNull(exception.getErrorBean());
		assertNotNull(exception.getPayload());
	}

	@Test
	public void testOMUserManagementExceptionHttpStatusErrorBean() {
		exception = new OMUserManagementException(HttpStatus.OK, new ErrorBean());
		assertNotNull(exception.getCode());
		assertNotNull(exception.getErrorBean());
	}

	@Test
	public void testOMUserManagementExceptionHttpStatusObject() {
		exception = new OMUserManagementException(HttpStatus.OK, new Object());
		assertEquals(HttpStatus.OK, exception.getCode());
		assertNotNull(exception.getPayload());
	}

	@Test
	public void testOMUserManagementExceptionHttpStatusErrorBeanObjectThrowable() {
		exception = new OMUserManagementException(HttpStatus.OK, new ErrorBean(), new Object(), new Exception());
		assertNotNull(exception);
	}

	@Test
	public void testToString() {
		assertFalse(exception.toString().isEmpty());
	}

}
