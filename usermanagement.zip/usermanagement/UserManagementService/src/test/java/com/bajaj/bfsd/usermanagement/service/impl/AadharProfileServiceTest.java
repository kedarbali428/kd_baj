package com.bajaj.bfsd.usermanagement.service.impl;

import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.UserProfileSaveRequest;
import com.bajaj.bfsd.usermanagement.dao.UserProfileDao;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(PowerMockRunner.class)
public class AadharProfileServiceTest {
	
	@InjectMocks
	private AadharProfileService aadharProfileService;
	
	@Mock
    private BFLLoggerUtil logger;
	
	@Mock
	private UserProfileDao aadharDao;
	
	@Test(expected = Test.None.class)
	public void testSaveUserProfile() {
		UserProfileSaveRequest saveRequest = new UserProfileSaveRequest();
		saveRequest.setUserKey(1234L);
		saveRequest.setProfileJson("{\"firstName\":\"FIRST\",\"middleName\":\"MIDDLE\",\"lastName\":\"LAST\","
				+ "\"dateOfBirth\":\"1999-01-01\",\"aadhaarNumber\":\"123456789012\","
				+ "\"emailDetails\":[{\"emailAddress\":\"sample1@email.com\",\"type\":\"PERSONAL\"},"
				+ "{\"emailAddress\":\"sample2@email.com\",\"type\":\"OFFICE\"}],"
				+ "\"addressDetails\":[{\"line1\":\"Address Line 1\",\"line2\":\"Address Line 2\","
				+ "\"type\":\"HOME\",\"city\":\"CITY\",\"country\":\"COUNTRY\",\"pinCode\":\"123-345\",\"state\":\"STATE\"}],"
				+ "\"phoneNumberDetails\":[{\"areaCode\":\"91\",\"countryCode\":\"IN\",\"number\":9012345678,\"type\":\"PERSONAL\"}]}");
		aadharProfileService.saveUserProfile(saveRequest);
	}
	
	@Test(expected = BFLTechnicalException.class )
	public void testSaveUserProfile_ThrowsException() {
		UserProfileSaveRequest saveRequest = new UserProfileSaveRequest();
		saveRequest.setUserKey(1234L);
		saveRequest.setProfileJson("{\"firstName\":\"FIRST\",\"middleName\":\"MIDDLE\",\"lastName\":\"LAST\","
				+ "\"dateOfBirth\":\"1999-01-01\",\"aadhaarNumber\":\"123456789012\",");
		aadharProfileService.saveUserProfile(saveRequest);

	}
	
	@Test
	public void testGetUserProfile() {
		assertNull(aadharProfileService.getUserProfile(1l));
	}

}
