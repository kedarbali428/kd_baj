package com.bajaj.bfsd.usermanagement.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterRequest;
import com.bajaj.bfsd.usermanagement.bean.BfsdUserDetails;
import com.bajaj.bfsd.usermanagement.bean.ChangePasswordRequest;
import com.bajaj.bfsd.usermanagement.bean.ReportingManager;
import com.bajaj.bfsd.usermanagement.bean.TokenResponse;
import com.bajaj.bfsd.usermanagement.bean.Tokens;
import com.bajaj.bfsd.usermanagement.bean.UICredentialsResponse;
import com.bajaj.bfsd.usermanagement.bean.User;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountResponse;
import com.bajaj.bfsd.usermanagement.bean.UserManagementResponse;
import com.bajaj.bfsd.usermanagement.bean.UserMappingRequest;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.bean.UserProfileDetails;
import com.bajaj.bfsd.usermanagement.bean.UserRoleBean;
import com.bajaj.bfsd.usermanagement.bean.UserVendorProfileBean;
import com.bajaj.bfsd.usermanagement.dao.UserManagementDao;
import com.bajaj.bfsd.usermanagement.data.UserManagementTestData;
import com.bajaj.bfsd.usermanagement.helper.UICredentialCache;
import com.bajaj.bfsd.usermanagement.helper.UserManagementHelper;
import com.bajaj.bfsd.usermanagement.model.BfsdFunction;
import com.bajaj.bfsd.usermanagement.model.BfsdFunctionRole;
import com.bajaj.bfsd.usermanagement.model.BfsdRoleMaster;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.model.UserProfile;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bajaj.bfsd.usermanagement.repository.BfsdRoleMasterRepository;
import com.bajaj.bfsd.usermanagement.repository.BfsdUserRepository;
import com.bajaj.bfsd.usermanagement.service.impl.UserManagementServiceImpl.AsyncClass;
import com.bajaj.bfsd.usermanagement.util.Ldaputility;
import com.bajaj.bfsd.usermanagement.util.LoginPasswordValidator;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.bfsd.usermanagement.util.UserManagementUtility;
import com.bajaj.markets.credit.sender.config.EventMessage;
import com.bajaj.markets.credit.sender.service.SenderService;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@PrepareForTest({BFLCommonRestClient.class, UserManagementUtility.class})
@RunWith(PowerMockRunner.class)
public class UserManagementServiceImplTest {
	private static final Date date = null;
	@InjectMocks
	UserManagementServiceImpl userManagementServiceImpl;
	
	@Mock
	private AsyncClass asyncClass; 
	
	@Mock
	BFLLoggerUtil logger;

	@Mock
	Environment env;

	@Mock
	UserManagementDao userManagementDao;

	@Mock
	UserManagementHelper userManagementHelper;

	@Mock
	UserManagementResponse userManagementResponse;

	@Mock
	private LoginPasswordValidator validator;

	@Mock
	UserProfileBean upb;

	@Mock
	private CustomDefaultHeaders headers;

	@Mock
	Ldaputility ldaputility;

	@Mock
	UICredentialCache uiCredentialCache;

	@Mock
	BfsdUserRepository bfsdUserRepo;
	
	@Mock
	BfsdRoleMasterRepository bfsdRoleMasterRepository;
	
	@Mock
	SenderService senderService;
	
	@Before
	public void setUp() {
		ReflectionTestUtils.setField(userManagementServiceImpl, "tokenServiceURL", "http://tokenservice.url.com");
	}
	
	@Test
	public void testCreateUser() {

		User userBean = new User();
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(1L);
		bfsdUser.setUsertype(BigDecimal.ONE);
		when(userManagementDao.createUser(any())).thenReturn(bfsdUser);
		userManagementServiceImpl.createUser(userBean);
	}

	@Test
	public void testCreateUserMapping() {

		UserMappingRequest userMappingBean = new UserMappingRequest();
		userManagementDao.createUserMapping(userMappingBean);
		userManagementServiceImpl.createUserMapping(userMappingBean);
	}

	@Test
	public void testUpdateUserMapping() {

		UserMappingRequest userMappingBean = new UserMappingRequest();
		userManagementDao.updateUserMapping(userMappingBean);
		userManagementServiceImpl.updateUserMapping(userMappingBean);
	}

	@Test
	public void testDeleteUser() {

		UserConfigurationBean userConfig = new UserConfigurationBean();
		userManagementDao.deleteUser(userConfig);
		userManagementServiceImpl.deleteUser(userConfig);
	}

	@Test
	public void testGetUserInformation() {

		UserConfigurationBean userConfig = new UserConfigurationBean();
		userManagementDao.getUserInformation(userConfig,new HttpHeaders());
		userManagementServiceImpl.getUserInformation(userConfig,new HttpHeaders());
	}

	@Test
	public void testGetActiveDirectoryUsers() {

		UserConfigurationBean userConfig = new UserConfigurationBean();
		userConfig.setEmployeeType("employee");
		userConfig.setFirstName("FirstName");
		userConfig.setLastName("LastName");
		userConfig.setEmailId("EmailId");
		userConfig.setDesignation("Designation");

		List<User> userList = new ArrayList<>();
		Mockito.when(ldaputility.getADUsers(Mockito.any())).thenReturn(userList);
		userManagementServiceImpl.getActiveDirectoryUsers(userConfig);
	}

	@Test
	public void testGetActiveDirectoryUsers1() {

		UserConfigurationBean userConfig = new UserConfigurationBean();
		userConfig.setEmployeeType("vendorCompany");
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(1245L);

		UserProfile userVendorProfile = new UserProfile();
		userVendorProfile.setAddress("Adress");
		userVendorProfile.setAssociationdt(date);
		userVendorProfile.setAssociationtype(new BigDecimal(2L));
		userVendorProfile.setCity(1243L);
		userVendorProfile.setCompanyname("Bajaj");
		userVendorProfile.setContactpersonname("ABC");
		userVendorProfile.setEmailid("@gmail");
		userVendorProfile.setFirstname("Firstname");
		userVendorProfile.setGst("12");
		userVendorProfile.setIsactive(BigDecimal.ONE);
		userVendorProfile.setLandline("1245");
		userVendorProfile.setLastname("Lastname");
		userVendorProfile.setMiddlename("Middlename");
		userVendorProfile.setMobileno("100");
		userVendorProfile.setPan("100247");
		userVendorProfile.setParentuseremailid("@mail");
		userVendorProfile.setPartnerkey("124");
		userVendorProfile.setServicekey("1245");
		userVendorProfile.setPincode("150582");
		userVendorProfile.setBfsdUser(bfsdUser);
		userVendorProfile.setUserprofilekey(1245L);
		userVendorProfile.setParentCompany(userVendorProfile);
		List<UserProfile> userVendorProfiles = new ArrayList<>();
		userVendorProfiles.add(userVendorProfile);
		UserVendorProfileBean userVendorProfileBean = new UserVendorProfileBean();
		List<UserVendorProfileBean> userVendorProfileBeans = new ArrayList<>();
		userVendorProfileBeans.add(userVendorProfileBean);
		Mockito.when(userManagementDao.searchUser(Mockito.any())).thenReturn(userVendorProfiles);
		userManagementServiceImpl.getActiveDirectoryUsers(userConfig);
	}


	@Test
	public void testGetuserSuperVisor() {
		String userRole = "ABC";
		userManagementDao.getuserSuperVisor(userRole);
		userManagementServiceImpl.getuserSuperVisor(userRole);
	}

	@Test
	public void testGetSuperVisorLocations() {
		String userKey = "ABC";
		userManagementDao.getSuperVisorLocations(userKey);
		userManagementServiceImpl.getSuperVisorLocations(userKey);
	}
	
	@Test
	public void testGetSuperVisorChannels() {
		String userRoleKey = "ABC";
		userManagementDao.getSuperVisorChannels(userRoleKey);
		userManagementServiceImpl.getSuperVisorChannels(userRoleKey);
	}

	@Test
	public void testGetLocationPin() {
		String locationKey = "ABC";
		userManagementDao.getLocationPin(locationKey);
		userManagementServiceImpl.getLocationPin(locationKey);
	}

	@Test
	public void testRoleMapped() {
		long Key = 1245L;
		userManagementDao.details(Key, Key);
		userManagementServiceImpl.roleMapped(Key, Key);
	}

	@Test
	public void testDeleteUserMapping() {
		Long Key = 1245L;
		userManagementDao.deleteUserMapping(Key, Key);
		userManagementServiceImpl.deleteUserMapping(Key, Key);
	}

	@Test
	public void testGetUserId() {

		UserLoginAccount userLoginAccount = new UserLoginAccount();
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(1245L);
		bfsdUser.setUsertype(new BigDecimal(2));
		userLoginAccount.setBfsdUser(bfsdUser);
		Mockito.when(userManagementDao.getUserId(Mockito.any())).thenReturn(userLoginAccount);
		userManagementServiceImpl.getUserId("1252");
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testGetUserId_ThrowsException() {
		Mockito.when(userManagementDao.getUserId(Mockito.any())).thenReturn(null);
		userManagementServiceImpl.getUserId("1252");
	}
	
	
	@Test
	public void testGetUserLoginAccount() {
		short failedCount=0;
		short userType =1;
		UserLoginAccountRequest userLoginAccountRequest= UserManagementTestData.pouserLoginAccountRequest();
		UserLoginAccount loginAccount = UserManagementTestData.popUserLoginAccount();
		Mockito.when(userManagementDao.getUserLoginAccount(userLoginAccountRequest)).thenReturn(loginAccount);
		Mockito.when(userManagementDao.updateFailedCount(loginAccount.getBfsdUser(), failedCount, userType)).thenReturn(loginAccount.getBfsdUser());
		//method under test
		UserLoginAccountResponse userLoginAccountResponse=userManagementServiceImpl.getUserLoginAccount(userLoginAccountRequest);
	   assertEquals(failedCount, userLoginAccountResponse.getLoginFailCount());
	   assertEquals("9182736450", userLoginAccountResponse.getLoginId());
	   assertEquals("987654", String.valueOf(userLoginAccountResponse.getUserId()));
	}	
	
	@Test
	public void testGetUserLoginAccountInvalidPass() {
		short failedCount=1;
		short userType =1;
		UserLoginAccountRequest userLoginAccountRequest= UserManagementTestData.pouserLoginAccountRequest();
		UserLoginAccount loginAccount = UserManagementTestData.popUserLoginAccount();
		loginAccount.setLoginpwd("111111");
		Mockito.when(userManagementDao.getUserLoginAccount(userLoginAccountRequest)).thenReturn(loginAccount);
		Mockito.when(userManagementDao.updateFailedCount(loginAccount.getBfsdUser(), failedCount,userType)).thenReturn(loginAccount.getBfsdUser());
		//method under test
		UserLoginAccountResponse userLoginAccountResponse=userManagementServiceImpl.getUserLoginAccount(userLoginAccountRequest);
	   assertEquals(0, userLoginAccountResponse.getLoginFailCount());
	   assertEquals("9182736450", userLoginAccountResponse.getLoginId());
	   assertEquals("987654", String.valueOf(userLoginAccountResponse.getUserId()));
	}
	
	@Test(expected = NullPointerException.class)
	public void testGetUserLoginAccountNullBfsdUser() {
		UserLoginAccountRequest userLoginAccountRequest= UserManagementTestData.pouserLoginAccountRequest();
		UserLoginAccount loginAccount = UserManagementTestData.popUserLoginAccount();
		loginAccount.setBfsdUser(new BfsdUser());
		Mockito.when(userManagementDao.getUserLoginAccount(userLoginAccountRequest)).thenReturn(loginAccount);
		//method under test
		UserLoginAccountResponse userLoginAccountResponse=userManagementServiceImpl.getUserLoginAccount(userLoginAccountRequest);
		assertEquals(0, userLoginAccountResponse.getLoginFailCount());
		assertEquals("9182736450", userLoginAccountResponse.getLoginId());
	    assertEquals("987654", String.valueOf(userLoginAccountResponse.getUserId()));
	}
	
	
	@Test
	public void testGetUserLoginAccountNullUserLogin() {
		UserLoginAccountRequest userLoginAccountRequest= UserManagementTestData.pouserLoginAccountRequest();
		//method under test
		UserLoginAccountResponse userLoginAccountResponse=userManagementServiceImpl.getUserLoginAccount(userLoginAccountRequest);
	   assertNull(userLoginAccountResponse.getLoginId());
	}
	@Test
	public void testgetUICredentials() {
		UICredentialsResponse uiCredentialsResponse = new UICredentialsResponse();
		uiCredentialsResponse.setSecretKey("test1");
		UserLoginAccount userLoginAcocountResult = new UserLoginAccount();
		userLoginAcocountResult.setLoginpwd("test1");
		userLoginAcocountResult.setLoginid("test");
		Mockito.when(uiCredentialCache.getSystemUser(Mockito.any())).thenReturn(userLoginAcocountResult);
		uiCredentialsResponse = userManagementServiceImpl.getUICredentials("test");
		assertEquals(userLoginAcocountResult.getLoginpwd(), uiCredentialsResponse.getSecretKey());
	}
	
	@Test
	public void getUserInfoByEmailTest(){
		String userEmail = "bal@bajajfinserv.in";
		List<UserRoleBean> userList = new ArrayList<>();
		UserRoleBean userRoleBean = new UserRoleBean();
		userRoleBean.setRoleKey(122l);
		userList.add(userRoleBean);
		Mockito.when(userManagementDao.getUserInfoByEmail(userEmail)).thenReturn(userList);
		userManagementServiceImpl.getUserInfoByEmail(userEmail);
	}
	@Test
	public void test_getRoleMasterByRoleKey() {
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		List<BfsdFunctionRole> bfsdFunctionRoles = new ArrayList<>();
		BfsdFunctionRole bfsdFunctionRole = new BfsdFunctionRole();
		BfsdFunction bfsdFunction = new BfsdFunction();
		bfsdFunction.setFunctioncd(BigDecimal.ONE);
		bfsdFunction.setFunctiondesc("OA Telecaller");
		bfsdFunctionRole.setBfsdFunction(bfsdFunction);
		bfsdFunctionRoles.add(bfsdFunctionRole);
		bfsdRoleMaster.setBfsdFunctionRoles(bfsdFunctionRoles);
		Mockito.when(bfsdRoleMasterRepository.findByRolekeyAndIsactive(Mockito.any(),Mockito.any())).thenReturn(bfsdRoleMaster);
		assertNotNull(userManagementServiceImpl.getRoleMasterByRoleKey("67"));
	}
	@Test
	public void test_getUserProfilesByRoleKeys() {
		List<Long> roleKeyList = new ArrayList<>();
		roleKeyList.add(67L);
		List<UserProfileDetails> userProfiles = new ArrayList<UserProfileDetails>();
		UserProfileDetails userProfileDetails = new UserProfileDetails();
		userProfileDetails.setUserRoleKey(67L);
		userProfiles.add(userProfileDetails);
		Mockito.when(userManagementDao.getUserProfilesByRoleKeys(roleKeyList)).thenReturn(userProfiles);
		userManagementServiceImpl.getUserProfilesByRoleKeys(roleKeyList);
	}
	
	@Test
	public void getUserInfoByAdidTest(){
		String userAdid = "balsda22";
		List<UserRoleBean> userList = new ArrayList<>();
		UserRoleBean userRoleBean = new UserRoleBean();
		userRoleBean.setRoleKey(122l);
		userList.add(userRoleBean);
		Mockito.when(userManagementDao.getUserInfoByAdId(userAdid)).thenReturn(userList);
		userManagementServiceImpl.getUserInfoByAdId(userAdid);
	}
	
	@Test
	public void getRolesByUserKeyTest() {
		UserRole user1 = new UserRole();
		user1.setBfsdRoleMaster(new BfsdRoleMaster());
		List<UserRole> userRoles = new ArrayList<>();
		userRoles.add(user1);
		UserProfile userProfile = new UserProfile();
		userProfile.setAssociationtype(BigDecimal.ONE);
		Mockito.when(userManagementDao.getRolesByUserKey(123L)).thenReturn(userRoles);
		Mockito.when(userManagementDao.getUserProfileByUserKey(123L)).thenReturn(userProfile);
		userManagementServiceImpl.getRolesByUserKey(123L);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testGetUserName_ThrowsException() {
		UserName userName1 = new UserName();
		UserName userName2 = new UserName();
		List<UserName> userNames = new ArrayList<>();
		userNames.add(userName1);
		userNames.add(userName2);

		Mockito.when(userManagementDao.getListOfUserName(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong()))
				.thenReturn(userNames);
		List<ErrorBean> errorList = new ArrayList<>();
		errorList.add(new ErrorBean("CODE-1", "Error Message"));
		ResponseBean responseBean = new ResponseBean(errorList);
		ResponseEntity<ResponseBean> repsonse = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), 
				Mockito.any(), Mockito.eq(null), Mockito.any(), Mockito.any(), Mockito.any(String.class), 
				Mockito.any(), Mockito.eq(null)))
				.thenReturn(repsonse);
		userManagementServiceImpl.getUserName(1L, 1L, 1L, 1L, 1L, 1L);

	}
	
	@Test
	public void testGetUserName() {
		UserName userName1 = new UserName();
		UserName userName2 = new UserName();
		List<UserName> userNames = new ArrayList<>();
		userNames.add(userName1);
		userNames.add(userName2);

		Mockito.when(userManagementDao.getListOfUserName(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong()))
				.thenReturn(userNames);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		UserName userName = userManagementServiceImpl.getUserName(1L, 1L, 1L, 1L, 1L, 1L);
		assertNotNull(userName);
	}
	
	@Test
	public void getListOfUserNameTest() {
		UserName userName = new UserName();
		List<UserName> userNames = new ArrayList<>();
		userNames.add(userName);
		Mockito.when(userManagementDao.getListOfUserName(123L,123L,123L,123L,123L)).thenReturn(userNames);
		userManagementServiceImpl.getListOfUserName(123L,123L,123L,123L,123L);
	}
	
	@Test
	public void autoRegisterTest() {
		AutoRegisterRequest request = new AutoRegisterRequest();
		boolean userExists = true;
		Mockito.when(userManagementDao.autoRegister(request)).thenReturn(userExists);
		userManagementServiceImpl.autoRegister(request);
	}
	
	
	@Test(expected = BFLTechnicalException.class)
	public void changePasswordTest_PwdValidtionfails() {
		ChangePasswordRequest passwordRequest = new ChangePasswordRequest();
		passwordRequest.setAuthToken("authToken");
		passwordRequest.setContactType(1L); 
		BfsdUser bfsduser = new BfsdUser();
		bfsduser.setUsertype(BigDecimal.valueOf(1));
		Mockito.when(userManagementDao.getUserType(123L)).thenReturn(bfsduser);
		Mockito.when(validator.validatePassword(passwordRequest.getPassword())).thenReturn(false);
		userManagementServiceImpl.changePassword(passwordRequest,123L);
	}
	
	
	@Test
	public void mergeUsersTest() {
		UserLoginAccount user = new UserLoginAccount();
		BfsdUser bfsdUser = new BfsdUser();
		user.setBfsdUser(bfsdUser);
		user.setLoginid("12345");
		bfsdUser.setUserkey(789L);
		bfsdUser.setUsertype(BigDecimal.valueOf(3));
		Mockito.when(userManagementDao.mergeUsers(1234L,123L)).thenReturn(user);
		userManagementServiceImpl.mergeUsers(1234L, 1235L);
	}
	
	@Test
	public void validateEmailTest() {
		Mockito.when(userManagementDao.checkApplicantEmail("abc@gmail.com",1234L)).thenReturn(false);
		Mockito.when(userManagementDao.checkLoginEmail("abc@gmail.com")).thenReturn(true);
		userManagementServiceImpl.validateEmail("abc@gmail.com",1234L);
	}
	
	@Test
	public void getUserRoleInfoTest() {
		UserRoleBean userRoleBean = new UserRoleBean();
		Mockito.when(userManagementDao.getUserRoleInfo(123L,789L)).thenReturn(userRoleBean);
		userManagementServiceImpl.getUserRoleInfo(123L,789L);
	}
	
	@Test
	public void getUserInfoTestForIsUserKey() {
		List<UserName> userList = new ArrayList<>();
		UserName userName = new UserName();
		userList.add(userName);
		Mockito.when(userManagementDao.getUserKeyFromUserRoleKey(123L)).thenReturn(1234L);
		Mockito.when(userManagementDao.getUserInfoByUserKey(123L)).thenReturn(userList);
		userManagementServiceImpl.getUserInfo(123L,true,true);
	}
	
	@Test
	public void getUserInfoTestForIsPrinciple() {
		BfsdUser bfsduser = new BfsdUser();
		bfsduser.setUsertype(BigDecimal.valueOf(3));
		Mockito.when(userManagementDao.getUserKeyFromUserRoleKey(123L)).thenReturn(1234L);
		Mockito.when(userManagementDao.getUserType(1234L)).thenReturn(bfsduser);
		userManagementServiceImpl.getUserInfo(123L,true,false);
	}
	
	@Test
	public void getUserInfoTest() {
		List<UserName> userList = new ArrayList<>();
		UserName userName = new UserName();
		userList.add(userName);
		Mockito.when(userManagementDao.getUserKeyFromUserRoleKey(123L)).thenReturn(1234L);
		Mockito.when(userManagementDao.getUserInfo(123L)).thenReturn(userList);
		userManagementServiceImpl.getUserInfo(123L,false,false);
	}
	
	@Test
	public void getAllReportingManagersTest() {
		ReportingManager manager = new ReportingManager();
		List<ReportingManager> mgrs= new ArrayList<>();
		mgrs.add(manager);
		Mockito.when(userManagementDao.getAllReportingManagers("abc")).thenReturn(mgrs);
		userManagementServiceImpl.getAllReportingManagers("abc");
	}
	
	@Test(expected = Exception.class)
	public void saveUserVendorProfilesTest() {
		User userBean = new User();
		userBean.setEmployeeType("employee");
		UserVendorProfileBean userVendorProfileBean = new UserVendorProfileBean();
		userVendorProfileBean.setUserKey(19076);
		userVendorProfileBean.setCompanyId(1L);
		userVendorProfileBean.setCompanyName("companyName");
		userVendorProfileBean.setVendorProfileKey(2);
		
		userBean.setUserVendorProfile(userVendorProfileBean);
		userManagementServiceImpl.saveUserVendorProfile(userBean);
	}
	
	@Test
	public void testmergeUsers_ValidTokenGenerated() {
		List<Tokens> tokenList = new ArrayList<>();
		tokenList.add(new Tokens());
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokenList);
		JSONObject tokenListJson = new JSONObject();
		tokenListJson.put("payload", new JSONObject(tokenList));

		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(tokenListJson);
		responseBean.setStatus(StatusCode.SUCCESS);
		
		ResponseEntity<ResponseBean> response = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		
		UserLoginAccount user = new UserLoginAccount();
		BfsdUser bfsdUser = new BfsdUser();
		user.setBfsdUser(bfsdUser);
		user.setLoginid("12345");
		bfsdUser.setUserkey(789L);
		bfsdUser.setUsertype(BigDecimal.valueOf(3));
		
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), 
				Mockito.eq(null), Mockito.any(), Mockito.eq(null), Mockito.isA(String.class), 
				Mockito.isA(HttpHeaders.class), Mockito.eq(null)))
				.thenReturn(response);

		Mockito.when(userManagementDao.mergeUsers(Mockito.anyLong(),Mockito.anyLong())).thenReturn(user);

		TokenResponse mergeUsers = userManagementServiceImpl.mergeUsers(1L, 2L);
		assertNotNull(mergeUsers);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testmergeUsers_GenerateTokenApiFailed() {
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(new Tokens());
		responseBean.setStatus(StatusCode.SUCCESS);
		
		ResponseEntity<ResponseBean> response = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		
		UserLoginAccount user = new UserLoginAccount();
		BfsdUser bfsdUser = new BfsdUser();
		user.setBfsdUser(bfsdUser);
		user.setLoginid("12345");
		bfsdUser.setUserkey(789L);
		bfsdUser.setUsertype(BigDecimal.valueOf(3));
		
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), 
				Mockito.eq(null), Mockito.any(), Mockito.eq(null), Mockito.isA(String.class), 
				Mockito.isA(HttpHeaders.class), Mockito.eq(null)))
				.thenReturn(response);

		Mockito.when(userManagementDao.mergeUsers(Mockito.anyLong(),Mockito.anyLong())).thenReturn(user);

		userManagementServiceImpl.mergeUsers(1L, 2L);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testMergeUsers_GenerateTokenResponseFailed() {
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(new Tokens());
		responseBean.setStatus(StatusCode.FAILURE);
		
		ResponseEntity<ResponseBean> response = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		
		UserLoginAccount user = new UserLoginAccount();
		BfsdUser bfsdUser = new BfsdUser();
		user.setBfsdUser(bfsdUser);
		user.setLoginid("12345");
		bfsdUser.setUserkey(789L);
		bfsdUser.setUsertype(BigDecimal.valueOf(3));
		
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), 
				Mockito.eq(null), Mockito.any(), Mockito.eq(null), Mockito.isA(String.class), 
				Mockito.isA(HttpHeaders.class), Mockito.eq(null)))
				.thenReturn(response);

		Mockito.when(userManagementDao.mergeUsers(Mockito.anyLong(),Mockito.anyLong())).thenReturn(user);

		userManagementServiceImpl.mergeUsers(1L, 2L);
	}
	
	@Test
	public void testSaveUserVendorProfile() {
		UserVendorProfileBean userVendor = new UserVendorProfileBean();
		userVendor.setVendorProfileKey(0L);
		userVendor.setUserKey(0L);
		User user = new User();
		user.setUserVendorProfile(userVendor);
		user.setEmployeeType(UserManagementConstants.VENDOR_COMPANY);

		BfsdUser bfsdUser = new BfsdUser();
		
		BfsdUserDetails userDetails = new BfsdUserDetails();
		
		EventMessage eventMessage = new EventMessage();
		Mockito.when(userManagementDao.createUser(Mockito.any(User.class)))
			.thenReturn(bfsdUser);
		Mockito.when(userManagementHelper.mapUserEntityToBean(Mockito.any(BfsdUser.class)))
			.thenReturn(userDetails);
		Mockito.when(userManagementHelper.createEventMessage(Mockito.anyString(), Mockito.any(), 
				Mockito.any(CustomDefaultHeaders.class)))
			.thenReturn(eventMessage);
		
		BfsdUser saveUserVendorProfile = userManagementServiceImpl.saveUserVendorProfile(user);
		assertNotNull(saveUserVendorProfile);
	}
	
	@Test
	public void testSaveUserVendorProfile_PrincipleUser() {
		UserVendorProfileBean userVendor = new UserVendorProfileBean();
		userVendor.setVendorProfileKey(0L);
		userVendor.setUserKey(1L);
		userVendor.setEmployeeType(UserManagementConstants.VENDOR_INDIVIDUAL);
		userVendor.setIsActive(1L);
		User user = new User();
		user.setUserVendorProfile(userVendor);
		user.setEmployeeType(UserManagementConstants.PRINCIPAL_USER);

		BfsdUser bfsdUser = new BfsdUser();
		UserProfile parentCompany = new UserProfile();
		parentCompany.setCompanyname("Parent Company");
		
		Mockito.when(userManagementDao.getEntity(Mockito.eq(BfsdUser.class), Mockito.anyLong()))
			.thenReturn(bfsdUser);
		Mockito.when(userManagementDao.getEntity(Mockito.eq(UserProfile.class), Mockito.anyLong()))
			.thenReturn(parentCompany);

		
		Mockito.when(upb.getUserRoleKey()).thenReturn(2L);
		BfsdUser saveUserVendorProfile = userManagementServiceImpl.saveUserVendorProfile(user);
		assertNotNull(saveUserVendorProfile);
	}
	
	@Test
	public void testSaveUserVendorProfile_OtherVendorUsers() {
		UserVendorProfileBean userVendor = new UserVendorProfileBean();
		userVendor.setVendorProfileKey(1L);
		userVendor.setUserKey(1L);
		userVendor.setParentUserEmailId("parentuser@email.com");
		userVendor.setEmployeeType(UserManagementConstants.VENDOR_INDIVIDUAL);
		userVendor.setCompanyId(1L);
		userVendor.setIsActive(1L);
		User user = new User();
		user.setUserVendorProfile(userVendor);
		user.setEmployeeType(UserManagementConstants.PRINCIPAL_USER);

		BfsdUser bfsdUser = new BfsdUser();
		UserProfile userProfile = new UserProfile();
		userProfile.setBfsdUser(bfsdUser);
		
		Mockito.when(userManagementDao.getUserVendorProfile(Mockito.anyLong(), Mockito.anyLong(),
				Mockito.eq(null)))
			.thenReturn(userProfile);

		Mockito.when(userManagementDao.getEntity(Mockito.eq(UserProfile.class), Mockito.anyLong()))
				.thenReturn(userProfile);
				
		Mockito.when(upb.getUserRoleKey()).thenReturn(2L);
		BfsdUser saveUserVendorProfile = userManagementServiceImpl.saveUserVendorProfile(user);
		assertNotNull(saveUserVendorProfile);
	}

	@Test(expected = BFLBusinessException.class)
	public void testValidateEmail_AlreadyExists() {
		Mockito.when(userManagementDao.checkApplicantEmail("abc@gmail.com",1234L)).thenReturn(true);
		userManagementServiceImpl.validateEmail("abc@gmail.com",1234L);

	}
	
	@Test(expected = Test.None.class)
	public void testSaveEmail() {
		
		Map<String, Object> responseMap = new HashMap<>();
		responseMap.put("updateCount", 1);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.SUCCESS);
		responseBean.setPayload(responseMap);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		
		Mockito.when(userManagementDao.checkApplicantEmail("abc@gmail.com",1234L)).thenReturn(false);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint
				(Mockito.isA(HttpMethod.class), Mockito.anyString(), Mockito.eq(null), Mockito.eq(ResponseBean.class),
								Mockito.isA(Map.class), Mockito.anyString(), 
								Mockito.isA(HttpHeaders.class), Mockito.eq(null)))
			.thenReturn(responseEntity);
		
		userManagementServiceImpl.saveEmail("newEmail@email.com", "oldEmail@email.com", 1L);
	}
}
