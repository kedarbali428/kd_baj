package com.bajaj.bfsd.usermanagement.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.LinkedinPositionBean;
import com.bajaj.bfsd.usermanagement.bean.LinkedinProfileBean;
import com.bajaj.bfsd.usermanagement.model.UserSocPrfLnkdinPosition;
import com.bajaj.bfsd.usermanagement.model.UserSocialProfileLinkedin;
import com.bfl.common.exceptions.BFLBusinessException;

@SpringBootTest
public class LinkedinDaoImplTest {
	
	@InjectMocks
	LinkedinDaoImpl linkedinDaoImpl;
	
	@Mock
	EntityManager entityManager;
	
	@Mock
	private Environment env;
	
	@Mock
    private BFLLoggerUtil logger;
	
	@Mock
	private Query query;
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testsaveProfile() {
		LinkedinProfileBean profileBean=new LinkedinProfileBean();
		List<LinkedinPositionBean> positions=new ArrayList<>();
		LinkedinPositionBean position=new LinkedinPositionBean();
		positions.add(position);
		profileBean.setPositions(positions);
		Mockito.when(entityManager
				.createNativeQuery(Mockito.any())).thenReturn(query);
		linkedinDaoImpl.saveProfile(profileBean, 1l, "");
	}

	@Test
	public void testGetUserprofile() {
		List<UserSocPrfLnkdinPosition> positions=new ArrayList<>();
		UserSocPrfLnkdinPosition position=new UserSocPrfLnkdinPosition();
		positions.add(position);
		UserSocialProfileLinkedin userSocialProfileLinkedin=new UserSocialProfileLinkedin();
		userSocialProfileLinkedin.setUserSocPrfLnkdinPositions(positions);
		Mockito.when(entityManager
				.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenReturn(userSocialProfileLinkedin);
		linkedinDaoImpl.getUserProfile(1l);
	}
	
	@Test
	public void testGetUserprofileNoResult() {
		List<UserSocPrfLnkdinPosition> positions=new ArrayList<>();
		UserSocPrfLnkdinPosition position=new UserSocPrfLnkdinPosition();
		positions.add(position);
		UserSocialProfileLinkedin userSocialProfileLinkedin=new UserSocialProfileLinkedin();
		userSocialProfileLinkedin.setUserSocPrfLnkdinPositions(positions);
		Mockito.when(entityManager
				.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenThrow(NoResultException.class);
		linkedinDaoImpl.getUserProfile(1l);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testGetUserprofileNonUnique() {
		List<UserSocPrfLnkdinPosition> positions=new ArrayList<>();
		UserSocPrfLnkdinPosition position=new UserSocPrfLnkdinPosition();
		positions.add(position);
		UserSocialProfileLinkedin userSocialProfileLinkedin=new UserSocialProfileLinkedin();
		userSocialProfileLinkedin.setUserSocPrfLnkdinPositions(positions);
		Mockito.when(entityManager
				.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenThrow(NonUniqueResultException.class);
		linkedinDaoImpl.getUserProfile(1l);
	}
}
