package com.bajaj.openmarkets.usermanagement.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bajaj.openmarkets.usermanagement.bean.UserRequest;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@SpringBootTest
public class OMUserManagementDaoImplTest {

	@InjectMocks
	OMUserManagementDaoImpl omUserManagementDao;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	EntityManager entityManager;
	
	@Mock
	private Query qury;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetUserAccount() {
		UserRequest userRequest = new UserRequest();
		userRequest.setMobile("9999999999");
		userRequest.setDateOfBirth("1900-10-10");

		Query query = Mockito.mock(Query.class);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenReturn(new UserLoginAccount());

		Assert.assertNotNull(omUserManagementDao.getUserAccount(userRequest));
	}

	@SuppressWarnings("unchecked")
	@Test(expected = BFLBusinessException.class)
	public void testGetUserAccount_NoResult() {
		UserRequest userRequest = new UserRequest();
		userRequest.setMobile("9999999999");
		userRequest.setDateOfBirth("1900-10-10");

		Query query = Mockito.mock(Query.class);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenThrow(NoResultException.class);

		omUserManagementDao.getUserAccount(userRequest);
	}

	@SuppressWarnings("unchecked")
	@Test(expected = BFLBusinessException.class)
	public void testGetUserAccount_NoUniqueResulst() {
		UserRequest userRequest = new UserRequest();
		userRequest.setMobile("9999999999");
		userRequest.setDateOfBirth("1900-10-10");

		Query query = Mockito.mock(Query.class);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenThrow(NonUniqueResultException.class);

		omUserManagementDao.getUserAccount(userRequest);
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = BFLTechnicalException.class)
	public void testGetUserAccount_TechnicalError() {
		UserRequest userRequest = new UserRequest();
		userRequest.setMobile("9999999999");
		userRequest.setDateOfBirth("1900-10-10");

		Query query = Mockito.mock(Query.class);
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getSingleResult()).thenThrow(Exception.class);

		omUserManagementDao.getUserAccount(userRequest);
	}
	
	@Test
	public void testgetUserRole() {
		List<UserRole> userRoles = new ArrayList<UserRole>();
		UserRole userRole = new UserRole();
		userRole.setUserrolekey(1l);
		userRoles.add(userRole);
		Query query = Mockito.mock(Query.class);
		Mockito.when(entityManager.createNamedQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.anyLong())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userRoles);
		Assert.assertNotNull(omUserManagementDao.getUserRole(1l,1l));
	}
	
	@Test
	public void testgetUserRolenull() {
		List<UserRole> userRoles = new ArrayList<UserRole>();
		Query query = Mockito.mock(Query.class);
		Mockito.when(entityManager.createNamedQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.anyLong())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userRoles);
		omUserManagementDao.getUserRole(1l,1l);
	}
}
