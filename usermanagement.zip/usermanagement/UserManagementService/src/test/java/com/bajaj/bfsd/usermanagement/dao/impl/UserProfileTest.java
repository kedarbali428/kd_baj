package com.bajaj.bfsd.usermanagement.dao.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.usermanagement.bean.UserVendorProfileBean;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserProfile;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
public class UserProfileTest {
	@Test
	public void testgetEntityFromBeanIndividual() {
		UserVendorProfileBean userVendorProfileBean=new UserVendorProfileBean();
		UserProfile userVendorProfile=new UserProfile();
		userVendorProfileBean.setIsActive(1l);
		userVendorProfileBean.setParentUserEmailId("jkkjh");
		userVendorProfileBean.setEmployeeType(UserManagementConstants.VENDOR_INDIVIDUAL);
		UserProfile.getEntityFromBean(userVendorProfileBean, userVendorProfile);
		assertNotNull(userVendorProfile);
	}
	@Test
	public void testgetEntityFromBeanCompany() {
		UserVendorProfileBean userVendorProfileBean=new UserVendorProfileBean();
		UserProfile userVendorProfile=new UserProfile();
		userVendorProfileBean.setIsActive(1l);
		userVendorProfileBean.setParentUserEmailId("jkkjh");
		userVendorProfileBean.setEmployeeType(UserManagementConstants.VENDOR_COMPANY);
		UserProfile.getEntityFromBean(userVendorProfileBean, userVendorProfile);
		assertNotNull(userVendorProfile);
	}
	@Test
	public void testgetEntityFromBeanPrincipal() {
		UserVendorProfileBean userVendorProfileBean=new UserVendorProfileBean();
		UserProfile userVendorProfile=new UserProfile();
		userVendorProfileBean.setIsActive(1l);
		userVendorProfileBean.setEmployeeType(UserManagementConstants.PRINCIPAL_USER);
		UserProfile.getEntityFromBean(userVendorProfileBean, userVendorProfile);
		assertNotNull(userVendorProfile);
	}
	@Test
	public void testGetBeanFromEntity() throws JsonProcessingException {
		ObjectMapper mapper=new ObjectMapper();
		mapper.writeValueAsString(new BfsdUser());
		UserVendorProfileBean userVendorProfileBean=new UserVendorProfileBean();
		UserProfile userVendorProfile=new UserProfile();
		userVendorProfile.setAssociationtype(BigDecimal.valueOf(2l));
		userVendorProfile.setBfsdUser(new BfsdUser());
		userVendorProfile.setIsactive(BigDecimal.ONE);
		userVendorProfile.setParentCompany(new UserProfile());
		UserProfile.getBeanFromEntity(userVendorProfile, userVendorProfileBean);
		assertNotNull(userVendorProfile);
	}
	
	@Test
	public void testGetBeanFromEntity3l() {
		UserVendorProfileBean userVendorProfileBean=new UserVendorProfileBean();
		UserProfile userVendorProfile=new UserProfile();
		userVendorProfile.setAssociationtype(BigDecimal.valueOf(3l));
		userVendorProfile.setBfsdUser(new BfsdUser());
		userVendorProfile.setIsactive(BigDecimal.ONE);
		userVendorProfile.setParentCompany(new UserProfile());
		UserProfile.getBeanFromEntity(userVendorProfile, userVendorProfileBean);
		assertNotNull(userVendorProfile);
	}
	
	@Test
	public void testGetBeanFromEntity5l() {
		UserVendorProfileBean userVendorProfileBean=new UserVendorProfileBean();
		UserProfile userVendorProfile=new UserProfile();
		userVendorProfile.setAssociationtype(BigDecimal.valueOf(5l));
		userVendorProfile.setBfsdUser(new BfsdUser());
		userVendorProfile.setIsactive(BigDecimal.ONE);
		userVendorProfile.setParentCompany(new UserProfile());
		UserProfile.getBeanFromEntity(userVendorProfile, userVendorProfileBean);
		assertNotNull(userVendorProfile);
	}

}
