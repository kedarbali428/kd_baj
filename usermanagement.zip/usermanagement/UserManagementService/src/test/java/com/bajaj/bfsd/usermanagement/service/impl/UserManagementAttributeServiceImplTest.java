package com.bajaj.bfsd.usermanagement.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import com.bajaj.bfsd.usermanagement.bean.BusinessVerticalBean;
import com.bajaj.bfsd.usermanagement.bean.POTypeBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoBean;
import com.bajaj.bfsd.usermanagement.dao.UserManagementAttributeDao;
import com.bajaj.bfsd.usermanagement.repository.BusinessVerticalMasterRepository;

@AutoConfigureMockMvc
@WebMvcTest
public class UserManagementAttributeServiceImplTest {
	@InjectMocks
	UserManagementAttributeServiceImpl userManagementAttributeServiceImpl;
	
	@Mock
	UserManagementAttributeDao userManagementAttributeDao;
	
	@Mock
	BusinessVerticalMasterRepository businessVerticalMasterRepository;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testGetUserDetailsByUserKey() {
		UserInfoBean userInfoBean = new UserInfoBean();
		userManagementAttributeDao.getUserProfileDetails(userInfoBean, 19076L);
		userManagementAttributeDao.getUserAdditionalAttributeDetails(userInfoBean, 19076L);
		userManagementAttributeDao.getEmployeeTypeAndStatusChangeReason(userInfoBean, 19076L);
		userManagementAttributeServiceImpl.getUserDetailsByUserKey(19076L);
	}
	@SuppressWarnings("unused")
	@Test
	public void testGetBusinessVerticalAndPOTypes() {
		List<BusinessVerticalBean> businessVerticalBeans = new ArrayList<>();
		BigDecimal isActive = new BigDecimal(1);
		List<Object[]> businessVerticalDetails = new ArrayList<>();
		Object[] objects1 = new Object[] {"DIGITAL_INSURANCE", "Digital Insurance"};
		businessVerticalDetails.add(objects1);
		Mockito.when(businessVerticalMasterRepository.findByIsActive(isActive)).thenReturn(businessVerticalDetails);
		BusinessVerticalBean businessVerticalBean = new BusinessVerticalBean();
		businessVerticalBean.setBusinessVerticalCode(String.valueOf(objects1[0]));
		businessVerticalBean.setBusinessVerticalDesc(String.valueOf(objects1[1]));
		
		List<POTypeBean> poTypeBeans = new ArrayList<POTypeBean>();
		List<Object[]> poDetails = new ArrayList<>();
		Object[] objects2 = new Object[] {"DIGINS", "Digital Insurance"};
		poDetails.add(objects2);
		Mockito.when(businessVerticalMasterRepository.findByBusinessVerticalCodeAndIsActive("DIGITAL_INSURANCE", isActive)).thenReturn(poDetails);
		POTypeBean poTypeBean = new POTypeBean();
		poTypeBean.setPOTypeCode(String.valueOf(objects2[0]));
		poTypeBean.setPOTypeDesc(String.valueOf(objects2[1]));
		poTypeBeans.add(poTypeBean);
		businessVerticalBean.setPoTypes(poTypeBeans);		
		
		userManagementAttributeServiceImpl.getBusinessVerticalAndPOTypes();	
	}
}