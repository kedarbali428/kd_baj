package com.bajaj.bfsd.usermanagement.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileSaveRequest;
import com.bajaj.bfsd.usermanagement.dao.UserProfileDao;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringJUnit4ClassRunner.class)
public class LinkedinProfileServiceTest {

	@InjectMocks
	private LinkedinProfileService linkedInProfileService;
	
	@Mock
    private BFLLoggerUtil logger;
	
	@Mock
	private UserProfileDao linkedinDao;
		
	@Test(expected = Test.None.class)
	public void testSaveUserProfile() {
		UserProfileSaveRequest saveRequest = new UserProfileSaveRequest();
		saveRequest.setUserKey(12345L);
		saveRequest.setProfileJson("{\"emailAddress\":\"example@email.com\",\"firstName\":\"First\",\"lastName\":\"Last\",\"headline\":\"HEADLINE\",\"id\":\"1234567\",\"location\":{\"name\":\"Location\",\"country\":{\"code\":\"CODE\"}},\"positions\":{\"values\":[{\"company\":{\"id\":\"12345\",\"name\":\"Company Name\",\"type\":\"FINANCE\",\"industry\":\"INDUSTRY\",\"isCurrent\":false,\"title\":\"DEVELOPER\"},\"startDate\":{\"month\":\"3\",\"year\":\"2003\"},\"endDate\":{\"month\":\"03\",\"year\":\"2010\"}}]}}");
		linkedInProfileService.saveUserProfile(saveRequest);
	}

	@Test(expected = BFLTechnicalException.class)
	public void testSaveUserProfile_ThrowsException() {
		UserProfileSaveRequest saveRequest = new UserProfileSaveRequest();
		saveRequest.setUserKey(12345L);
		saveRequest.setProfileJson("{\"firstName\": \"First\", \"lastName\": \"Last\", \"emailAddress\": \"example@email.com\"");
		linkedInProfileService.saveUserProfile(saveRequest);
	}
	
	@Test
	public void testGetUserProfile() {
		UserProfileBean profileBean = new UserProfileBean();
		Mockito.when(linkedinDao.getUserProfile(Mockito.anyLong()))
				.thenReturn(profileBean);
		linkedInProfileService.getUserProfile(1234L);
	}
	

}
