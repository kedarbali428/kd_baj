package com.bajaj.bfsd.usermanagement.config;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bajaj.bfsd.usermanagement.service.UserMgmtIntegration;

@RunWith(PowerMockRunner.class)
public class InstanceConfigTest {
	@InjectMocks
	InstanceConfig instanceConfig;
	
	@Mock
	UserMgmtIntegration usermgmtIntegration;
	
	@Test
	public void testCreateBFDLCustomerService() {
		assertNotNull(instanceConfig.createBFDLCustomerService());
	}
	
	@Test
	public void testCreateBFLCustomerService() {
		assertNotNull(instanceConfig.createBFLCustomerService());
	}
}