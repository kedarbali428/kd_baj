package com.bajaj.bfsd.usermanagement.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.usermanagement.bean.BfsdRoleMasterResponse;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.bean.UserProfileDetails;
import com.bajaj.bfsd.usermanagement.bean.UserRoleBean;
import com.bajaj.bfsd.usermanagement.beanmapper.BeanMapper;
import com.bajaj.bfsd.usermanagement.service.UserManagementService;

@RunWith(PowerMockRunner.class)
public class RoleInformationControllerTest {

	@InjectMocks
	RoleInformationController roleInformationController;
	
	@Mock
    BFLLoggerUtil logger;
	@Mock
	Environment env;
	@Mock
	BeanMapper beanMapper;
	@Mock
	UserManagementService userManagementService;
	
	@Mock
	HttpHeaders headers;
	
	@Test
	public void getUserRoleInfoTest(){
		Long userKey = 1212l;
		Long roleKey = 1231l;
		UserRoleBean userRoleBean = new UserRoleBean();
		Mockito.when(userManagementService.getUserRoleInfo(userKey, roleKey)).thenReturn(userRoleBean);
		ResponseEntity<ResponseBean> responseEntity = roleInformationController.getUserRoleInfo(userKey, roleKey, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getUserInfoTest(){
		Long userRoleKey = 1212l;
		String isPrinciple = "true";
		String isUserkey = "true";
		List<UserName> userNameBean = new ArrayList<>();
		Mockito.when(userManagementService.getUserInfo(userRoleKey, Boolean.valueOf(isPrinciple), Boolean.valueOf(isUserkey))).thenReturn(userNameBean);
		ResponseEntity<ResponseBean> responseEntity = roleInformationController.getUserInfo(userRoleKey, isPrinciple, isUserkey, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getUserInfoByEmailTest(){
		String userEmail = "bak@bajajfinserv.in";
		List<UserRoleBean> userNameBean = new ArrayList<>();
		Mockito.when(userManagementService.getUserInfoByEmail(userEmail)).thenReturn(userNameBean);
		ResponseEntity<ResponseBean> responseEntity = roleInformationController.getUserInfoByEmail(userEmail, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	@Test
	public void getRoleMasterByRoleKeyTest(){
		BfsdRoleMasterResponse bfsdRoleMasterResponse = new BfsdRoleMasterResponse();
		bfsdRoleMasterResponse.setRoleKey(67L);
		Mockito.when(userManagementService.getRoleMasterByRoleKey("67")).thenReturn(bfsdRoleMasterResponse);
		ResponseEntity<?> responseEntity = roleInformationController.getRoleMasterByRoleKey("67", headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	@Test
	public void getUserProfilesByRoleKeysTest(){
		List<UserProfileDetails> userProfileDetails = new ArrayList<>();
		UserProfileDetails userProfile = new UserProfileDetails();
		userProfile.setUserRoleKey(67L);
		userProfileDetails.add(userProfile);
		List<Long> roleKeyList = new ArrayList<Long>();
		roleKeyList.add(67L);
		Mockito.when(userManagementService.getUserProfilesByRoleKeys(roleKeyList)).thenReturn(userProfileDetails);
		ResponseEntity<?> responseEntity = roleInformationController.getUserProfilesByRoleKeys(roleKeyList, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void getUserInfoByAdidTest(){
		String useradid = "adid22333";
		List<UserRoleBean> userNameBean = new ArrayList<>();
		Mockito.when(userManagementService.getUserInfoByAdId(useradid)).thenReturn(userNameBean);
		ResponseEntity<ResponseBean> responseEntity = roleInformationController.getUserInfoByAdId(useradid, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
}
