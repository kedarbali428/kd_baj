package com.bajaj.bfsd.usermanagement.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;
import com.bajaj.bfsd.usermanagement.beanmapper.BeanMapper;
import com.bajaj.bfsd.usermanagement.helper.UserManagementHelper;
import com.bajaj.bfsd.usermanagement.model.BfsdRoleMaster;
import com.bajaj.bfsd.usermanagement.model.UserRoleL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleProductL3;
import com.bajaj.bfsd.usermanagement.model.UtmSourceChannelMaster;
import com.bajaj.bfsd.usermanagement.util.Ldaputility;
import com.bajaj.bfsd.usermanagement.util.QueryConstants;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserMgmtProdDaoImplTest {

	@InjectMocks
	UserMgmtProdDaoImpl userMgmtProdDaoImpl;
	
	@InjectMocks
	FacebookDaoImpl facebookDaoImpl;
	
	@Mock
	EntityManager entityManager;

	@Mock
	Environment environment;

	@Mock
	UserManagementHelper userManagementHelper;

	@Mock
	EntityManagerFactory entityManagerFactory;

	@Mock
	private BFLLoggerUtil bflLoggerUtil;

	@Mock
	Ldaputility ldaputility;

	@Mock
	BeanMapper beanMapper;

	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	CriteriaBuilder criteriaBlder;
	
	@Mock
	@RequestScoped
	CustomDefaultHeaders custmHeaders;
	
	@Mock
	UserManagementDaoImpl userManagementDao;

	@Mock
	private Query query;
	
	@Test
	public void getAdditionalUserDetailsTest() {
		UserConfigurationBean userConfig = new UserConfigurationBean();
		userConfig.setSpCode("spCode");
		List<Object[]> attributeList= new ArrayList<>();
		UserConfigurationBean userConfigurationBean = new UserConfigurationBean();
		userConfigurationBean.setUserKey(19076L);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(attributeList);
		
		userMgmtProdDaoImpl.getAdditionalUserDetails(userConfig);
		
	}
		
	@Test
	public void findUserRoleKeyTest() {
		
		long userrolekey= 1L;
		List<UserRoleL3> result = new ArrayList<>();
		
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		userMgmtProdDaoImpl.findUserRoleKey(userrolekey);
		
	}
	
	@Test
    public void getSupervisorTest() {
		Long userRoleProdKey= 1L;
		List<Object[]> userRoleProducts=new ArrayList<>();
		
		Mockito.when(entityManager.createNativeQuery(QueryConstants.QRY_TO_GET_CHECK_SUPERVISOR)).thenReturn(query);
		Mockito.when(query.setParameter("userprodkey", userRoleProdKey)).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userRoleProducts);
		userMgmtProdDaoImpl.getSupervisor(userRoleProdKey);
		
	}
	
	@Test
    public void getPincodesByLocTest() {
		List<Long> branchKeyList=new ArrayList<>();
		branchKeyList.add(1L);
		List<Object[]> pinCodes =new ArrayList<>();
		
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.anyList())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(pinCodes);
		userMgmtProdDaoImpl.getPincodesByLoc(branchKeyList);
		
	}
		
	@Test
    public void deleteUserMappingTest() {
		UserRoleL3 userRole = new UserRoleL3();
		userMgmtProdDaoImpl.deleteUserMapping(userRole);
		
	}
	
	@Test(expected=Exception.class)
    public void getAllChannelsTest() {
		List<Long> branchKeyList=new ArrayList<>();
		branchKeyList.add(1L);
		
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(branchKeyList);
		userMgmtProdDaoImpl.getAllChannels();
		
	}
	
	@Test(expected=Exception.class)
    public void getAllLocationsTest() {
		List<Long> branchKeyList=new ArrayList<>();
		branchKeyList.add(1L);
		
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(branchKeyList);
		userMgmtProdDaoImpl.getAllLocations();
		
	}
		
	@Test
    public void getUserDetailsTest() {
		UserConfigurationBean userConfigBean = new UserConfigurationBean();
		HttpHeaders headers = new HttpHeaders();
		List<Object[]> authors= new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.anyList())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(authors);
		userMgmtProdDaoImpl.getUserDetails(userConfigBean,headers);
		
	}
	
	@Test
    public void getUserDetailsTest1() {
		UserConfigurationBean userConfigBean = new UserConfigurationBean();
		userConfigBean.setEmployeeType("vendorCompany");
		HttpHeaders headers = new HttpHeaders();
		List<Object[]> authors= new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.anyList())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(authors);
		userMgmtProdDaoImpl.getUserDetails(userConfigBean,headers);
		
	}
	
	@Test
    public void getSuperVisorChannelsTest() {
		Long userRoleProdKey= 0L;
		List<Object[]> channels = new ArrayList<>();
		
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(channels);
		userMgmtProdDaoImpl.getSuperVisorChannels(userRoleProdKey);
		
	}
	
	@Test
    public void getSuperVisorChannelsTest1() {
		Long userRoleProdKey= 1L;
		List<Object[]> channels = new ArrayList<>();
		
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(channels);
		userMgmtProdDaoImpl.getSuperVisorChannels(userRoleProdKey);
		
	}
	
	@Test(expected=Exception.class)
    public void getUserSuperVisorTest() {
		long roleKey= 1L;
		long prodKey = 2L;
		long subProdKey= 3L;
		BfsdRoleMaster roleMaster = userManagementDao.getEntity(BfsdRoleMaster.class, roleKey);
		List<Object[]> authors =new ArrayList<>();
		
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(authors);
		userMgmtProdDaoImpl.getUserSuperVisor(roleKey,prodKey,subProdKey);
		
	}
	
	@Test
	public void getUserProdMappingTest() {
		Long userRoleKey= 1L;
		Long loanProdKey= 2L;
		Long prodMastKey= 3L;
		List<UserRoleProductL3> result = new ArrayList<>();
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		
		userMgmtProdDaoImpl.getUserProdMapping(userRoleKey,loanProdKey,prodMastKey);
		
	}
	
	@Test
	public void getUserRoleProductsByUserKeyTest() {
		Long userKey= 1L;
		List<Object[]> result = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		
		userMgmtProdDaoImpl.getUserRoleProductsByUserKey(userKey);
		
	}
	
	@Test
	public void getSuperVisorLocationsTest() {
		Long userRoleProdKey= 0L;
		List<LocationBean> userList = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userList);
		
		userMgmtProdDaoImpl.getSuperVisorLocations(userRoleProdKey);
		
	}
	
	@Test
	public void getSuperVisorLocationsTest1() {
		Long userRoleProdKey= 1L;
		List<LocationBean> userList = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userList);
		
		userMgmtProdDaoImpl.getSuperVisorLocations(userRoleProdKey);
		
	}
	

	@Test
	public void saveUserMappingsTest() {
		
		UserRoleL3 userRole = new UserRoleL3();
		
		userMgmtProdDaoImpl.saveUserMapping(userRole);
		
	}
	
	@Test
	public void saveLocationTest() {
		long userRoleProdKey= 1L;
		List<Long> keyList = new ArrayList<>();
		keyList.add(1L);
		List<Long> exisingKeyList = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(exisingKeyList);
		
		userMgmtProdDaoImpl.saveLocation(userRoleProdKey,keyList);
		
	}
	
	@Test
	public void getUserProfileByUserKeyTest() {
		long userKey= 1L;
		List<Object[]> userProfiles=new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(userProfiles);
		
		userMgmtProdDaoImpl.getUserProfileByUserKey(userKey);
		
	}
	
	@Test
	public void getUTMSourceMappingTest() {
		List<Long> utmMastKey=new ArrayList<>();
		List<UtmSourceChannelMaster> result = new ArrayList<>();
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		
		userMgmtProdDaoImpl.getUTMSourceMapping(utmMastKey);
		
	}
}