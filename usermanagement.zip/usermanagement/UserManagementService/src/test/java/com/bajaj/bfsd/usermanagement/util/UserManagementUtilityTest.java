package com.bajaj.bfsd.usermanagement.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.bajaj.bfsd.common.BFLLoggerUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@PropertySource("classpath:/my/package/config/myfile.properties")
@ContextConfiguration
@WebAppConfiguration
public class UserManagementUtilityTest {
	@InjectMocks
	UserManagementUtility userManagementUtility;

	@Mock
	BFLLoggerUtil logger;

	@Test
	public void testgetCurrentTimeStamp() throws Exception {
		Timestamp expectedTime = UserManagementUtility.getCurrentDateTimeStamp();
		assertNotNull(expectedTime);

	}

	@Test
	public void testgetCurrentTimeStamp1() throws Exception {
		Timestamp expectedTime = UserManagementUtility.getCurrentTimeStamp();
		assertNotNull(expectedTime);

	}

	@Test
	public void testgetEffectiveEndDate() throws ParseException {

		String date = "";

		Date tempDate = null;
		tempDate = new SimpleDateFormat("yyyy-MM-dd").parse("2018-11-28");
		DateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
		date = formatter.format(tempDate);
		Date expectedValue = UserManagementUtility.getEffectiveEndDate(logger);
	}

	@Test
	public void testGenrateDate() throws ParseException {
		UserManagementUtility.genrateDate("Wed Oct 16 00:00:00 CEST 2013", logger);
	}

}