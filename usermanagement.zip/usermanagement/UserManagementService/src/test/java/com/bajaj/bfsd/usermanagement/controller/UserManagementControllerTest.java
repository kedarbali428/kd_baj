package com.bajaj.bfsd.usermanagement.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterRequest;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterResponse;
import com.bajaj.bfsd.usermanagement.bean.ChangePasswordRequest;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.EmailUpdateRequest;
import com.bajaj.bfsd.usermanagement.bean.EmployeeRoleDetails;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.ReportingManager;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.TokenResponse;
import com.bajaj.bfsd.usermanagement.bean.UICredentialsResponse;
import com.bajaj.bfsd.usermanagement.bean.User;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserDetailBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountResponse;
import com.bajaj.bfsd.usermanagement.bean.UserMappingDeleteResponseBean;
import com.bajaj.bfsd.usermanagement.bean.UserMappingRequest;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.bean.UserVendorProfileBean;
import com.bajaj.bfsd.usermanagement.beanmapper.BeanMapper;
import com.bajaj.bfsd.usermanagement.data.UserManagementTestData;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.ProductMaster;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataPluginMapper;
import com.bajaj.bfsd.usermanagement.service.UserManagementService;
import com.bajaj.bfsd.usermanagement.service.UserMgmtProdService;
import com.bajaj.bfsd.usermanagement.service.impl.UserManagementServiceImpl.AsyncClass;
import com.bfl.common.exceptions.BFLBusinessException;

@RunWith(PowerMockRunner.class)
public class UserManagementControllerTest {
	@InjectMocks
	UserManagementController userManagementController;

	@Mock
	BFLLoggerUtil bflLoggerUtil;

	@Mock
	UserManagementService userManagementService;
	@Mock
	HttpHeaders headers;

	@Mock
	UserProfileBean upb;

	@Mock
	Environment environment;

	@Mock
	BeanMapper beanMapper;

	@Mock
	CustomDefaultHeaders custmHeaders;

	@Mock
	private AsyncClass asyncClass;

	@Mock
	UserMgmtProdService userMgmtProdService;
	
	@Mock
	OMMasterDataPluginMapper omMasterDataPluginMapper;
	
	@Test
	public void testGetUserLoginAccount() {
		UserLoginAccountRequest userLoginAccountRequest = UserManagementTestData.pouserLoginAccountRequest();
		Mockito.when(userManagementService.getUserLoginAccount(userLoginAccountRequest))
				.thenReturn(new UserLoginAccountResponse());
		ResponseEntity<ResponseBean> responseEntity = userManagementController
				.getUserLoginAccount(userLoginAccountRequest, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testCreateUser() throws Exception {

		UserVendorProfileBean userVendorProfile = new UserVendorProfileBean();
		userVendorProfile.setEmployeeType("vendorCompany");
		userVendorProfile.setVendorProfileKey(0);
		userVendorProfile.setUserKey(0);
		userVendorProfile.setEmailId("vendor");

		custmHeaders.setCmptcorrid("vendor");

		User userBean = new User();
		userBean.setUserVendorProfile(userVendorProfile);

		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(-1);

		BindingResult result = Mockito.mock(BindingResult.class);
		Mockito.when(userManagementService.saveUserVendorProfile(Mockito.any())).thenReturn(bfsdUser);
		ResponseEntity<ResponseBean> response = userManagementController.createUser(userBean, result, headers);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testDeleteUser() {
		UserConfigurationBean userConfig = new UserConfigurationBean();
		Mockito.when(userManagementService.deleteUser(Mockito.any())).thenReturn(1);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.deleteUser(userConfig, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testCreateUserMapping() {
		UserMappingRequest userMappingBean = new UserMappingRequest();
		ResponseEntity<ResponseBean> responseEntity = userManagementController.createUserMapping(userMappingBean,
				headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testUpdateUserMapping() {
		UserMappingRequest userMappingBean = new UserMappingRequest();
		ResponseEntity<ResponseBean> responseEntity = userManagementController.updateUserMapping(userMappingBean,
				headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testGetActiveDirectoryUsers() {
		UserConfigurationBean userConfig = new UserConfigurationBean();
		Mockito.when(userManagementService.getActiveDirectoryUsers(Mockito.any())).thenReturn(userConfig);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getActiveDirectoryUsers(userConfig,
				headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testEmployeeRoleDetail() {

		List<EmployeeRoleDetails> list = new ArrayList<>();
		Mockito.when(userManagementService.roleMapped(Mockito.anyLong(), Mockito.anyLong())).thenReturn(list);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.employeeRoleDetail(1245L, 1245L,
				headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testGetUserInformation() {
		UserConfigurationBean userConfig = new UserConfigurationBean();
		Mockito.when(userManagementService.getUserInformation(Mockito.any(),Mockito.any())).thenReturn(userConfig);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getUserInformation(userConfig, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testUpdateUserInformation() { // Start added for Partner Portal
		Mockito.when(userManagementService.updateUserDetails(Mockito.any())).thenReturn(1);
		UserInfoRequest userInfoRequest=new UserInfoRequest();
		ResponseEntity<ResponseBean> responseEntity = userManagementController.updateUserInformation(userInfoRequest,headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testGetuserSuperVisor() {
		custmHeaders.setCmptcorrid("vendor");

		List<SupervisorBean> user = new ArrayList<>();
		Mockito.when(userManagementService.getuserSuperVisor(Mockito.any())).thenReturn(user);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getuserSuperVisor("Userrole", headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testGetSuperVisorLocations() {
		custmHeaders.setCmptcorrid("vendor");

		List<LocationBean> bflBranchList = new ArrayList<>();
		Mockito.when(userManagementService.getSuperVisorLocations(Mockito.any())).thenReturn(bflBranchList);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getSuperVisorLocations("Userrole",
				headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testGetSuperVisorChannels() {
		custmHeaders.setCmptcorrid("vendor");

		List<ChannelBean> bflChannelList = new ArrayList<>();
		Mockito.when(userManagementService.getSuperVisorChannels(Mockito.any())).thenReturn(bflChannelList);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getSuperVisorChannels("Userrole",
				headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testGetLocationPin() {
		custmHeaders.setCmptcorrid("vendor");

		List<PinCodeBean> pinCodeList = new ArrayList<>();
		Mockito.when(userManagementService.getLocationPin(Mockito.any())).thenReturn(pinCodeList);
		List<ProductMaster> masterProducts = new ArrayList<>();
		ProductMaster productMaster = new ProductMaster();
		productMaster.setProdmastkey(1L);
		productMaster.setProdmastcode("OMINS");
		masterProducts.add(productMaster);
		Mockito.when(userMgmtProdService.getAllMasterProducts()).thenReturn(masterProducts);
		Mockito.when(omMasterDataPluginMapper.getLocationPinForOM("121", headers)).thenReturn(pinCodeList);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getLocationPin("role",1l, headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testDeleteUserMapping() {

		UserMappingDeleteResponseBean result = new UserMappingDeleteResponseBean();

		Mockito.when(userManagementService.deleteUserMapping(Mockito.anyLong(), Mockito.anyLong())).thenReturn(true);
		Mockito.when(beanMapper.mapTo(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyBoolean())).thenReturn(result);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.deleteUserMapping("1", "2", headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test(expected = BFLBusinessException.class)
	public void testDeleteUserMapping_fail() {

		UserMappingDeleteResponseBean result = new UserMappingDeleteResponseBean();

		Mockito.when(userManagementService.deleteUserMapping(Mockito.anyLong(), Mockito.anyLong())).thenReturn(true);
		Mockito.when(beanMapper.mapTo(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyBoolean())).thenReturn(result);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.deleteUserMapping("", "", headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testGetUICredentials() {

		UICredentialsResponse uiCredentialsResponse = new UICredentialsResponse();
		Mockito.when(userManagementService.getUICredentials(Mockito.any())).thenReturn(uiCredentialsResponse);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getUICredentials("12", headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testGetUserId() {

		UserLoginAccountResponse user = new UserLoginAccountResponse();
		Mockito.when(userManagementService.getUserId(Mockito.any())).thenReturn(user);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getUserId("12", headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testGetRolesByUserKey() {
		upb.setUserid(12L);
		UserDetailBean result = new UserDetailBean();
		Mockito.when(userManagementService.getRolesByUserKey(Mockito.anyLong())).thenReturn(result);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getRolesByUserKey(headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testGetListOfUsers() {

		List<UserName> result = new ArrayList<>();
		Mockito.when(userManagementService.getListOfUserName(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong())).thenReturn(result);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getListOfUsers(12L, 13L, 14L, 15L, 16L,
				headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void testGetListOfReportingManagers() {
		List<ReportingManager> result = new ArrayList<>();
		Mockito.when(userManagementService.getAllReportingManagers(Mockito.any())).thenReturn(result);
		ResponseEntity<?> responseEntity =  userManagementController.getAllReportingManagers("A", "A", headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	} 
	
	@Test
	public void testGetUser() {

		UserName result = new UserName();
		Mockito.when(userManagementService.getUserName(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(),
				Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong())).thenReturn(result);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.getUser(12L, 13L, 14L, 15L, 16L, 17L,
				headers);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testAutoRegister() {

		AutoRegisterRequest request = new AutoRegisterRequest();

		AutoRegisterResponse response = new AutoRegisterResponse();
		Mockito.when(userManagementService.autoRegister(Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.autoRegister(request);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testChangePassword() {

		custmHeaders.setUserkey(1);
		BindingResult result = Mockito.mock(BindingResult.class);
		ChangePasswordRequest request = new ChangePasswordRequest();

		ResponseEntity<ResponseBean> responseEntity = userManagementController.changePassword(request, result);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	// @Test
	public void testMergeUsers() {

		custmHeaders.setUserkey(1);
		TokenResponse tokenResponse = new TokenResponse();
		Mockito.when(userManagementService.mergeUsers(Mockito.anyLong(), Mockito.anyLong())).thenReturn(tokenResponse);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.mergeUsers("1");
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test(expected = BFLBusinessException.class)
	public void testMergeUsers_fail() {

		custmHeaders.setUserkey(0);
		TokenResponse tokenResponse = new TokenResponse();
		Mockito.when(userManagementService.mergeUsers(Mockito.anyLong(), Mockito.anyLong())).thenReturn(tokenResponse);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.mergeUsers("0");
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testValidateNewEmail() {

		custmHeaders.setCmptcorrid("1");
		BindingResult result = Mockito.mock(BindingResult.class);
		EmailUpdateRequest emailUpdateRequest = new EmailUpdateRequest();
		emailUpdateRequest.setNewEmail("@gmail");
		emailUpdateRequest.setApplicantKey(1245L);
		Mockito.when(userManagementService.validateEmail(Mockito.any(), Mockito.anyLong())).thenReturn(true);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.validateNewEmail(emailUpdateRequest,
				result);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testSaveNewEmail() {

		custmHeaders.setCmptcorrid("1");
		bflLoggerUtil.setCorrelationID("customerportal");
		BindingResult result = Mockito.mock(BindingResult.class);
		EmailUpdateRequest emailUpdateRequest = new EmailUpdateRequest();
		emailUpdateRequest.setNewEmail("@gmail");
		emailUpdateRequest.setOldEmail("@gmail");
		emailUpdateRequest.setApplicantKey(1245L);
		Mockito.when(userManagementService.validateEmail(Mockito.any(), Mockito.anyLong())).thenReturn(true);
		ResponseEntity<ResponseBean> responseEntity = userManagementController.saveNewEmail(emailUpdateRequest, result);
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
}
