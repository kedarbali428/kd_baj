package com.bajaj.openmarkets.usermanagement.service.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.usermanagement.model.ApplicantPhoneNumberV2;
import com.bajaj.bfsd.usermanagement.model.ApplicantV2;
import com.bajaj.bfsd.usermanagement.model.BfsdUserV2;
import com.bajaj.bfsd.usermanagement.model.PhoneNumberType;
import com.bajaj.bfsd.usermanagement.model.UserApplicantV2;
import com.bajaj.bfsd.usermanagement.repository.ApplicantPhoneNumberV2Repository;
import com.bajaj.bfsd.usermanagement.repository.BfsdUserV2Repository;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.openmarkets.usermanagement.bean.AuthorizationCodesRequest;
import com.bajaj.openmarkets.usermanagement.bean.AuthorizationCodesResponse;
import com.bajaj.openmarkets.usermanagement.bean.ValidateTokenResponse;
import com.bajaj.openmarkets.usermanagement.exceptions.OMUserManagementException;
import com.bajaj.openmarkets.usermanagement.util.TokenValidationUtil;

@RunWith(SpringJUnit4ClassRunner.class)
public class OMUserAuthorizationServiceImplTest {

	@InjectMocks
	private OMUserAuthorizationServiceImpl federatedImpl;
	
	@Mock
	private Environment env;
	
	@Mock
	private BFLLoggerUtilExt logger;
	
	@Mock
	private TokenValidationUtil tokenValidator;
	
	@Mock
	private RestTemplate restTemplate;
		
	private String bfdlMarketsClientSecret;
	
	private String bfdlMarketsClientId;
	
	private String authenticationUrl;
	
	private String validateTokenUrl;
	
	@Mock
	private BfsdUserV2Repository bfsdUserV2Repository;
 
	@Mock
	private ApplicantPhoneNumberV2Repository appltPhnNumV2Repository;

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(federatedImpl, "bfdlMarketsClientSecret", "QkZETE1GQVBQQDEyMw==");
		ReflectionTestUtils.setField(federatedImpl, "bfdlMarketsClientId", "BFDL_MarketsApp");
		ReflectionTestUtils.setField(federatedImpl, "authenticationUrl", "http://localhost:8080/v1/user/authorization-codes");
		ReflectionTestUtils.setField(federatedImpl, "validateTokenUrl", "http://localhost:8080/v1/tokens/validations");
		ReflectionTestUtils.setField(federatedImpl, "restTemplate", restTemplate);
	}
	
	@Test
	public void testGetAuthorizationTokenCode() {
		AuthorizationCodesRequest codeRequest = getAuthorizationCodesRequest();

		ValidateTokenResponse tokenResponse = getValidatedTokenResponse();
		
		BfsdUserV2 bfsdUserV2 = getBfsdUserV2();
		
		AuthorizationCodesResponse codeResponse = new AuthorizationCodesResponse();
		codeResponse.setAuthorizationCode("Some Auth Code");
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.SUCCESS);
		responseBean.setPayload(codeResponse);
		
		JSONObject responseBody = new JSONObject(responseBean);
		
		Mockito.when(tokenValidator.getValidatedToken(Mockito.anyString()))
				.thenReturn(tokenResponse);
		
		Mockito.when(bfsdUserV2Repository.findByUserkeyAndUsertype(Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(bfsdUserV2);
		Mockito.when(appltPhnNumV2Repository.findByApplicantkeyAndPhoneNumberTypeAndApltphnumisactive(Mockito.anyLong(), 
				Mockito.any(PhoneNumberType.class),  Mockito.eq(1)))
				.thenReturn(getPhoneNumbers());
		ResponseEntity<String> mockedResponse = new ResponseEntity<String>(responseBody.toString(), HttpStatus.OK);

		Mockito.when( restTemplate.exchange(Mockito.matches("http://.*"), 
				Mockito.isA(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(String.class)) )
				.thenReturn(mockedResponse);
		AuthorizationCodesResponse federatedAuthenticationToken = federatedImpl.getAuthorizationTokenCode(codeRequest, "Auth Token");
		assertNotNull(federatedAuthenticationToken);
	}

	@Test(expected = OMUserManagementException.class)
	public void testGetFederrated_VerificationFailure_EmptyPhoneList() {
		
		ValidateTokenResponse tokenResponse = getValidatedTokenResponse();

		Date bdate = new Date();
		ApplicantV2 applicantV2 = new ApplicantV2();
		applicantV2.setApltdateofbirth(bdate);
		applicantV2.setApplicantkey(12345L);
		applicantV2.setApplicantPhoneNumbers(null);

		List<UserApplicantV2> userApplicants = new ArrayList<>();
		UserApplicantV2 userApplicantV2 = new UserApplicantV2();
		userApplicantV2.setApplicant(applicantV2);
		userApplicantV2.setApplicantkey(12345L);
		
		userApplicants.add(userApplicantV2);

		BfsdUserV2 bfsdUserV2 = new BfsdUserV2();
		bfsdUserV2.setUsertype(UserManagementConstants.USERTYPE_CUSTOMER);
		bfsdUserV2.setUserkey(1234L);
		bfsdUserV2.setUserApplicants(userApplicants);

		Mockito.when(tokenValidator.getValidatedToken(Mockito.anyString()))
			.thenReturn(tokenResponse);

		Mockito.when(bfsdUserV2Repository.findByUserkeyAndUsertype(Mockito.anyLong(), Mockito.anyLong()))
			.thenReturn(bfsdUserV2);
		federatedImpl.getAuthorizationTokenCode(getAuthorizationCodesRequest(),
					"Auth Token");

	}
	
	@Test(expected = OMUserManagementException.class)
	public void testGetFederrated_VerificationFailure_NoNumberMatch() {
		
		ValidateTokenResponse tokenResponse = getValidatedTokenResponse();

		ApplicantPhoneNumberV2 phoneNumber = new ApplicantPhoneNumberV2();
		phoneNumber.setApltphnumkey(123L);
		phoneNumber.setApltphnumnumber("9988876655");
		phoneNumber.setApplicantkey(12345L);
		
		List<ApplicantPhoneNumberV2> phoneList = new ArrayList<>();
		phoneList.add(phoneNumber);

		Date bdate = new Date();
		ApplicantV2 applicantV2 = new ApplicantV2();
		applicantV2.setApltdateofbirth(bdate);
		applicantV2.setApplicantkey(12345L);
		applicantV2.setApplicantPhoneNumbers(phoneList);

		List<UserApplicantV2> userApplicants = new ArrayList<>();
		UserApplicantV2 userApplicantV2 = new UserApplicantV2();
		userApplicantV2.setApplicant(applicantV2);
		userApplicantV2.setApplicantkey(12345L);
		
		userApplicants.add(userApplicantV2);

		BfsdUserV2 bfsdUserV2 = new BfsdUserV2();
		bfsdUserV2.setUsertype(UserManagementConstants.USERTYPE_CUSTOMER);
		bfsdUserV2.setUserkey(1234L);
		bfsdUserV2.setUserApplicants(userApplicants);

		Mockito.when(tokenValidator.getValidatedToken(Mockito.anyString()))
			.thenReturn(tokenResponse);

		Mockito.when(bfsdUserV2Repository.findByUserkeyAndUsertype(Mockito.anyLong(), Mockito.anyLong()))
			.thenReturn(bfsdUserV2);
		federatedImpl.getAuthorizationTokenCode(getAuthorizationCodesRequest(),
					"Auth Token");

	}

	@Test(expected = OMUserManagementException.class)
	public void testGetFederrated_VerificationFailure_NoApplicantFound() {
		Mockito.when(tokenValidator.getValidatedToken(Mockito.anyString()))
			.thenReturn(getValidatedTokenResponse());

		Mockito.when(bfsdUserV2Repository.findByUserkeyAndUsertype(Mockito.anyLong(), Mockito.anyLong()))
			.thenReturn(null);
		federatedImpl.getAuthorizationTokenCode(getAuthorizationCodesRequest(),
				"Auth Token");

	}
	
	@Test(expected = OMUserManagementException.class)
	public void testGetAuthorizationTokenCode_AuthorizationRequestFailure() {
		AuthorizationCodesRequest codeRequest = getAuthorizationCodesRequest();

		ValidateTokenResponse tokenResponse = getValidatedTokenResponse();
		
		BfsdUserV2 bfsdUserV2 = getBfsdUserV2();
		
		AuthorizationCodesResponse codeResponse = new AuthorizationCodesResponse();
		codeResponse.setAuthorizationCode("Some Auth Code");
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.SUCCESS);
		responseBean.setPayload(codeResponse);
		
		JSONObject responseBody = new JSONObject(responseBean);
		
		Mockito.when(tokenValidator.getValidatedToken(Mockito.anyString()))
				.thenReturn(tokenResponse);
		
		Mockito.when(bfsdUserV2Repository.findByUserkeyAndUsertype(Mockito.anyLong(), Mockito.anyLong()))
				.thenReturn(bfsdUserV2);
		
		ResponseEntity<String> mockedResponse = new ResponseEntity<String>(responseBody.toString(), HttpStatus.OK);

		Mockito.when( restTemplate.exchange(Mockito.matches("http://.*"), 
				Mockito.isA(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(String.class)) )
				.thenThrow(RestClientException.class);
		federatedImpl.getAuthorizationTokenCode(codeRequest, "Auth Token");
	}
	
	@Test(expected = OMUserManagementException.class)
	public void testGetAuthorizationTokenCode_TokenValidationFailure() {
		AuthorizationCodesRequest authorizationCodesRequest = getAuthorizationCodesRequest();
		Mockito.when(tokenValidator.getValidatedToken(Mockito.anyString()))
			.thenThrow(NullPointerException.class);
		federatedImpl.getAuthorizationTokenCode(authorizationCodesRequest, "Some Auth Token");
	}
	
	public AuthorizationCodesRequest getAuthorizationCodesRequest() {
		AuthorizationCodesRequest codeRequest = new AuthorizationCodesRequest();
		codeRequest.setApplicantKey(12345L);
		codeRequest.setAuthorizedClient("AuthorizedClient");
		codeRequest.setClientId("BFDL_MarketsApp");
		return codeRequest;
	}
	
	public ValidateTokenResponse getValidatedTokenResponse() {
		ValidateTokenResponse tokenResponse = new ValidateTokenResponse();
		tokenResponse.setDefaultRole("customer");
		tokenResponse.setLoginId("9988776655");
		tokenResponse.setTokenStatus("VALID");
		tokenResponse.setUserId(1234L);
		
		return tokenResponse;
	}
	
	public BfsdUserV2 getBfsdUserV2() {
		Date bdate = new Date();
		
		List<ApplicantPhoneNumberV2> phoneList = getPhoneNumbers();

		ApplicantV2 applicantV2 = new ApplicantV2();
		applicantV2.setApltdateofbirth(bdate);
		applicantV2.setApplicantkey(12345L);
		applicantV2.setApplicantPhoneNumbers(phoneList);

		List<UserApplicantV2> userApplicants = new ArrayList<>();
		UserApplicantV2 userApplicantV2 = new UserApplicantV2();
		userApplicantV2.setApplicant(applicantV2);
		userApplicantV2.setApplicantkey(12345L);
		
		userApplicants.add(userApplicantV2);

		BfsdUserV2 bfsdUserV2 = new BfsdUserV2();
		bfsdUserV2.setUsertype(UserManagementConstants.USERTYPE_CUSTOMER);
		bfsdUserV2.setUserkey(1234L);
		bfsdUserV2.setUserApplicants(userApplicants);

		return bfsdUserV2;
	}
	
	public List<ApplicantPhoneNumberV2> getPhoneNumbers() {
		
		PhoneNumberType numberType = new PhoneNumberType();
		numberType.setPhonetypekey(UserManagementConstants.PHONETYPE_MOBILE);
		numberType.setPhonetypecode(UserManagementConstants.PHONE_MOBILE_TYPE);
		
		ApplicantPhoneNumberV2 phoneNumber = new ApplicantPhoneNumberV2();
		phoneNumber.setApltphnumkey(123L);
		phoneNumber.setApltphnumnumber("9988776655");
		phoneNumber.setApplicantkey(12345L);
		phoneNumber.setApltphnumisactive(1);
		phoneNumber.setPhoneNumberType(numberType);
		
		List<ApplicantPhoneNumberV2> phoneList = new ArrayList<>();
		phoneList.add(phoneNumber);

		return phoneList;
	}
}
