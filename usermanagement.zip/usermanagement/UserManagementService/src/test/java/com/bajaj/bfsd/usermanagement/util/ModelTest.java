package com.bajaj.bfsd.usermanagement.util;

import org.junit.Test;

import com.bajaj.bfsd.usermanagement.bean.AadharProfileBean;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterRequest;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterResponse;
import com.bajaj.bfsd.usermanagement.bean.BfsdUserDetails;
import com.bajaj.bfsd.usermanagement.bean.BfsdUserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.ChangePasswordRequest;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.DeleteUserRoleBean;
import com.bajaj.bfsd.usermanagement.bean.EmailUpdateRequest;
import com.bajaj.bfsd.usermanagement.bean.EmployeeRoleDetails;
import com.bajaj.bfsd.usermanagement.bean.EventMessage;
import com.bajaj.bfsd.usermanagement.bean.EventSchema;
import com.bajaj.bfsd.usermanagement.bean.FacebookProfileBean;
import com.bajaj.bfsd.usermanagement.bean.LinkedinPositionBean;
import com.bajaj.bfsd.usermanagement.bean.LinkedinProfileBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.ProductBean;
import com.bajaj.bfsd.usermanagement.model.AppAppointment;
import com.bajaj.bfsd.usermanagement.model.AppContactAuthRequest;
import com.bajaj.bfsd.usermanagement.model.AppContactAuthValidation;
import com.bajaj.bfsd.usermanagement.model.AppCtaProduct;
import com.bajaj.bfsd.usermanagement.model.AppCtaRole;
import com.bajaj.bfsd.usermanagement.model.AppCtaSection;
import com.bajaj.bfsd.usermanagement.model.AppCtaType;
import com.bajaj.bfsd.usermanagement.model.Applicant;
import com.bajaj.bfsd.usermanagement.model.ApplicantPhoneNumber;
import com.bajaj.bfsd.usermanagement.model.Application;
import com.bajaj.bfsd.usermanagement.model.ApplicationApltAttribute;
import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.Validator;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;

public class ModelTest {
	
	@Test
	public void validateAadharProfileBean() {
		PojoClass bean = PojoClassFactory.getPojoClass(AadharProfileBean.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(bean);
	}

	@Test
	public void validateAutoRegisterRequest() {
		PojoClass applicationDocUploadRequest = PojoClassFactory.getPojoClass(AutoRegisterRequest.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(applicationDocUploadRequest);
	}

	@Test
	public void validateAutoRegisterResponse() {
		PojoClass bean = PojoClassFactory.getPojoClass(AutoRegisterResponse.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(bean);
	}

	@Test
	public void validateBfsdUserDetails() {
		PojoClass bean = PojoClassFactory.getPojoClass(BfsdUserDetails.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(bean);
	}

	@Test
	public void validateBfsdUserProfileBean() {
		PojoClass bean = PojoClassFactory.getPojoClass(BfsdUserProfileBean.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(bean);
	}

	@Test
	public void validateChangePasswordRequest() {
		PojoClass bean = PojoClassFactory.getPojoClass(ChangePasswordRequest.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(bean);
	}

	
	@Test
	public void validateChannelBean() {
		PojoClass pdfResponse = PojoClassFactory.getPojoClass(ChannelBean.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(pdfResponse);
	}

	
	@Test
	public void validateDeleteUserRoleBean() {
		PojoClass properties = PojoClassFactory.getPojoClass(DeleteUserRoleBean.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(properties);
	}

	@Test
	public void validateEmailUpdateRequest() {
		PojoClass user = PojoClassFactory.getPojoClass(EmailUpdateRequest.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(user);
	}

	
	@Test
	public void validateEmployeeRoleDetails() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(EmployeeRoleDetails.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}


	@Test
	public void validateEventMessaget() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(EventMessage.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}

	@Test
	public void validateEventSchema() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(EventSchema.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
	
	@Test
	public void validateLinkedinPositionBean() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(LinkedinPositionBean.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}

	@Test
	public void validateFacebookProfileBean() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(FacebookProfileBean.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}

	@Test
	public void validateLinkedinProfileBean() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(LinkedinProfileBean.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}

	@Test
	public void validateLocationBean() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(LocationBean.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}

	@Test
	public void validatePinCodeBean() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(PinCodeBean.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}

	@Test
	public void validateProductBean() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(ProductBean.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}

	@Test
	public void validateApplicantPhoneNumber() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(ApplicantPhoneNumber.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}

	@Test
	public void validateApplicationApltAttribute() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(ApplicationApltAttribute.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
	@Test
	public void validateApplication() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(Application.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
	
	@Test
	public void validateAppCtaRole() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(AppCtaRole.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
	@Test
	public void validateAppCtaSection() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(AppCtaSection.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
	@Test
	public void validateAppCtaType() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(AppCtaType.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
	@Test
	public void validateAppContactAuthRequest() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(AppContactAuthRequest.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
	@Test
	public void validateAppAppointment() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(AppAppointment.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
	@Test
	public void validateAppContactAuthValidation() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(AppContactAuthValidation.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
	@Test
	public void validateAppCtaProduct() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(AppCtaProduct.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
	@Test
	public void validateApplicant() {
		PojoClass barcodeValue = PojoClassFactory.getPojoClass(Applicant.class);
		Validator validator = ValidatorBuilder.create().with(new SetterTester()).with(new GetterTester()).build();

		// Start the Test
		validator.validate(barcodeValue);
	}
}
