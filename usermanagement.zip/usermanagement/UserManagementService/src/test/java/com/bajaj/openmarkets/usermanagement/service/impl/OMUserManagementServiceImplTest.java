package com.bajaj.openmarkets.usermanagement.service.impl;

import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.USERTYPE_CUSTOMER;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.USERTYPE_PSEUDO_CUSTOMER;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.USERTYPE_PSEUDO_VERIFIED_CUSTOMER;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.cache.service.UserCacheService;
import com.bajaj.bfsd.common.cache.service.entity.CacheUserEntity;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bajaj.openmarkets.usermanagement.bean.UserRequest;
import com.bajaj.openmarkets.usermanagement.cache.entity.CacheAdditionalInfo;
import com.bajaj.openmarkets.usermanagement.cache.repository.CacheAdditionalInfoRepository;
import com.bajaj.openmarkets.usermanagement.dao.OMUserManagementDao;

@SpringBootTest
public class OMUserManagementServiceImplTest {

	@InjectMocks
	OMUserManagementServiceImpl omUserManagementService;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	OMUserManagementDao userManagementDao;

	@Mock
	CacheAdditionalInfoRepository cacheAdditionalInfoRepo;
	
	@Mock
	UserCacheService userCacheService;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetUser_UserType_Cust() {
		UserRequest userRequest = new UserRequest();
		userRequest.setUserType(USERTYPE_CUSTOMER);
		userRequest.setMobile("9999999999");
		userRequest.setDateOfBirth("1900-10-10");

		UserLoginAccount userLoginAccount = new UserLoginAccount();
		BfsdUser bfsdUser = new BfsdUser();

		bfsdUser.setUserkey(1234l);
		bfsdUser.setUsertype(BigDecimal.ONE);

		userLoginAccount.setBfsdUser(bfsdUser);
		userLoginAccount.setLoginid("9999999999@1900-10-10");
		List<String> applicationIds=new ArrayList<>();
		applicationIds.add("123456");
		Map<String,Object> resourceMap=new HashMap<>();
		Mockito.when(userManagementDao.getUserAccount(Mockito.any())).thenReturn(userLoginAccount);
		CacheAdditionalInfo additionalInfo = new CacheAdditionalInfo(1234l, 123l, 123l,resourceMap);
		Mockito.when(cacheAdditionalInfoRepo.get(Mockito.any())).thenReturn(additionalInfo);

		Assert.assertEquals(1234l, omUserManagementService.getUser(userRequest).getUserId().longValue());
	}

	@Test
	public void testGetUser_UserType_Pseudo() {
		UserRequest userRequest = new UserRequest();
		userRequest.setUserType(USERTYPE_PSEUDO_CUSTOMER);
		userRequest.setMobile("9999999999");
		userRequest.setDateOfBirth("1900-10-10");
		userRequest.setApplicantKey(1234l);
		userRequest.setApplicationKey(1234l);
		
		Assert.assertEquals(9999999999l, omUserManagementService.getUser(userRequest).getUserId().longValue());
	}

	@Test
	public void testGetUser_UserType_PseudoVerified() {
		UserRequest userRequest = new UserRequest();
		userRequest.setUserType(USERTYPE_PSEUDO_VERIFIED_CUSTOMER);
		userRequest.setMobile("9999999999");
		userRequest.setApplicationKey(1234l);

		Assert.assertEquals(9999999999l, omUserManagementService.getUser(userRequest).getUserId().longValue());
	}
	
	@Test
	public void testGetUser_FetchAdditionalInfo() {
		CacheAdditionalInfo additionalInfo = new CacheAdditionalInfo(1234l, 123l, 123l, null);
		
		Mockito.when(cacheAdditionalInfoRepo.get(Mockito.anyLong(), Mockito.anyInt())).thenReturn(additionalInfo);
		
		Assert.assertNotNull(omUserManagementService.getUser(1234l));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetUser_FetchAdditionalInfo_Ex() {
		
		Mockito.when(cacheAdditionalInfoRepo.get(Mockito.anyLong(), Mockito.anyInt())).thenThrow(Exception.class);
		
		Assert.assertNull(omUserManagementService.getUser(1234l));
	}
	
	@Test
	public void testgetUserRoleKey_Exception() {
		CacheAdditionalInfo additionalInfo = new CacheAdditionalInfo(1234l, 123l, 123l, null);
		CacheUserEntity cacheUserEntity = new CacheUserEntity();
		cacheUserEntity.setUserKey(1l);
		Mockito.when(cacheAdditionalInfoRepo.get(Mockito.anyLong(), Mockito.anyInt())).thenReturn(additionalInfo);
		Mockito.when(userCacheService.get(1l)).thenReturn(cacheUserEntity);
		omUserManagementService.getUserRoleKey(1234l);
	}

	@Test
	public void testgetUserRoleKey_FetchData() {
		CacheAdditionalInfo additionalInfo = new CacheAdditionalInfo(1234l, 123l, 123l, null);
		CacheUserEntity cacheUserEntity = new CacheUserEntity();
		cacheUserEntity.setRoleKey(1l);
		UserRole userrole = new UserRole();
		userrole.setUserrolekey(1l);
		Mockito.when(userManagementDao.getUserRole(1234, cacheUserEntity.getRoleKey())).thenReturn(userrole);
		Mockito.when(cacheAdditionalInfoRepo.get(Mockito.anyLong(), Mockito.anyInt())).thenReturn(additionalInfo);
		Mockito.when(userCacheService.get(1234l)).thenReturn(cacheUserEntity);
		Assert.assertNotNull(omUserManagementService.getUserRoleKey(1234l));
	}
}
