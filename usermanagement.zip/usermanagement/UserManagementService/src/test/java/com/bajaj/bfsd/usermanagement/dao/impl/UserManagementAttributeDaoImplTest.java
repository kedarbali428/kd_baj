package com.bajaj.bfsd.usermanagement.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import com.bajaj.bfsd.usermanagement.bean.UserInfoBean;
import com.bajaj.bfsd.usermanagement.model.UserAddlAttributes;
import com.bajaj.bfsd.usermanagement.util.QueryConstants;
import com.bfl.common.exceptions.BFLTechnicalException;

@AutoConfigureMockMvc
@WebMvcTest
public class UserManagementAttributeDaoImplTest {
	@InjectMocks
	UserManagementAttributeDaoImpl userManagementAttributeDaoImpl;
	
	@Mock
	EntityManager entityManager;
	
	@Mock
	private Query query;
	
	@Mock
	QueryConstants queryConstants;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testGetUserProfileDetails() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		query.setParameter("userKey", 19076L);
		query.setParameter("isActive", new BigDecimal(1));
		List<Object[]> userProfileDetails = new ArrayList<Object[]>();
		Object[] objects = new Object[]{123,"Bala", "Patil", "bala.patil@bajajfinserv.in","9988776655","PMO","bala.patil","19076","Bajaj"};
		userProfileDetails.add(objects);
		Mockito.when(query.getResultList()).thenReturn(userProfileDetails);
		userManagementAttributeDaoImpl.getUserProfileDetails(userInfoBean, 19076L);
	}
	@SuppressWarnings("unchecked")
	@Test(expected = Exception.class)
	public void testGetUserProfileDetailsFailure() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(query.getResultList()).thenThrow(BFLTechnicalException.class);
		userManagementAttributeDaoImpl.getUserProfileDetails(userInfoBean, 19076L);
	}
	@SuppressWarnings("static-access")
	@Test
	public void testGetUserAdditionalAttributeDetails() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(entityManager.createQuery(queryConstants.GET_ADDITIONAL_ATTRIBUTE)).thenReturn(query);
		query.setParameter("userKey", 19076L);
		query.setParameter("isActive", 1);
		List<UserAddlAttributes> attributeList =new ArrayList<>();
		UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
		userAddlAttributes.setAttrcode("xyz");
		userAddlAttributes.setAttrvalue("attrvalue");
		attributeList.add(userAddlAttributes);
		Mockito.when(query.getResultList()).thenReturn(attributeList);
		userManagementAttributeDaoImpl.getUserAdditionalAttributeDetails(userInfoBean, 19076L);
	}
	@SuppressWarnings("unchecked")
	@Test(expected = Exception.class)
	public void testGetUserAdditionalAttributeDetailsFailure() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(query.getResultList()).thenThrow(BFLTechnicalException.class);
		userManagementAttributeDaoImpl.getUserAdditionalAttributeDetails(userInfoBean, 19076L);
	}
	@SuppressWarnings("static-access")
	@Test
	public void testGetEmployeeTypeAndStatusChangeReason_system_user() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(entityManager.createQuery(queryConstants.EMP_TYPE_STATUS_CHANGE_REASON)).thenReturn(query);
		query.setParameter("userKey", 19076L);
		query.setParameter("isActive", new BigDecimal(1));
		List<Object[]> details = new ArrayList<>();
		Object[] objects = new Object[]{new BigDecimal(0), new BigDecimal(1)};
		details.add(objects);
		Mockito.when(query.getResultList()).thenReturn(details);
		userManagementAttributeDaoImpl.getEmployeeTypeAndStatusChangeReason(userInfoBean, 19076L);
	}
	@SuppressWarnings("static-access")
	@Test
	public void testGetEmployeeTypeAndStatusChangeReason_customer() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(entityManager.createQuery(queryConstants.EMP_TYPE_STATUS_CHANGE_REASON)).thenReturn(query);
		query.setParameter("userKey", 19076L);
		query.setParameter("isActive", new BigDecimal(1));
		List<Object[]> details = new ArrayList<>();
		Object[] objects = new Object[]{new BigDecimal(1), new BigDecimal(1)};
		details.add(objects);
		Mockito.when(query.getResultList()).thenReturn(details);
		userManagementAttributeDaoImpl.getEmployeeTypeAndStatusChangeReason(userInfoBean, 19076L);
	}
	@SuppressWarnings("static-access")
	@Test
	public void testGetEmployeeTypeAndStatusChangeReason_employee() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(entityManager.createQuery(queryConstants.EMP_TYPE_STATUS_CHANGE_REASON)).thenReturn(query);
		query.setParameter("userKey", 19076L);
		query.setParameter("isActive", new BigDecimal(1));
		List<Object[]> details = new ArrayList<>();
		Object[] objects = new Object[]{new BigDecimal(2), new BigDecimal(1)};
		details.add(objects);
		Mockito.when(query.getResultList()).thenReturn(details);
		userManagementAttributeDaoImpl.getEmployeeTypeAndStatusChangeReason(userInfoBean, 19076L);
	}
	@SuppressWarnings("static-access")
	@Test
	public void testGetEmployeeTypeAndStatusChangeReason_third_party_vendor() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(entityManager.createQuery(queryConstants.EMP_TYPE_STATUS_CHANGE_REASON)).thenReturn(query);
		query.setParameter("userKey", 19076L);
		query.setParameter("isActive", new BigDecimal(1));
		List<Object[]> details = new ArrayList<>();
		Object[] objects = new Object[]{new BigDecimal(3), new BigDecimal(1)};
		details.add(objects);
		Mockito.when(query.getResultList()).thenReturn(details);
		userManagementAttributeDaoImpl.getEmployeeTypeAndStatusChangeReason(userInfoBean, 19076L);
	}
	@SuppressWarnings("static-access")
	@Test
	public void testGetEmployeeTypeAndStatusChangeReason_b2b_partner() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(entityManager.createQuery(queryConstants.EMP_TYPE_STATUS_CHANGE_REASON)).thenReturn(query);
		query.setParameter("userKey", 19076L);
		query.setParameter("isActive", new BigDecimal(1));
		List<Object[]> details = new ArrayList<>();
		Object[] objects = new Object[]{new BigDecimal(4), new BigDecimal(1)};
		details.add(objects);
		Mockito.when(query.getResultList()).thenReturn(details);
		userManagementAttributeDaoImpl.getEmployeeTypeAndStatusChangeReason(userInfoBean, 19076L);
	}
	@SuppressWarnings("static-access")
	@Test
	public void testGetEmployeeTypeAndStatusChangeReason_chatbot() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(entityManager.createQuery(queryConstants.EMP_TYPE_STATUS_CHANGE_REASON)).thenReturn(query);
		query.setParameter("userKey", 19076L);	
		query.setParameter("isActive", new BigDecimal(1));
		List<Object[]> details = new ArrayList<>();
		Object[] objects = new Object[]{new BigDecimal(5), new BigDecimal(1)};
		details.add(objects);
		Mockito.when(query.getResultList()).thenReturn(details);
		userManagementAttributeDaoImpl.getEmployeeTypeAndStatusChangeReason(userInfoBean, 19076L);
	}
	@SuppressWarnings("static-access")
	@Test
	public void testGetEmployeeTypeAndStatusChangeReason_principal_user() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(entityManager.createQuery(queryConstants.EMP_TYPE_STATUS_CHANGE_REASON)).thenReturn(query);
		query.setParameter("userKey", 19076L);
		query.setParameter("isActive", new BigDecimal(1));
		List<Object[]> details = new ArrayList<>();
		Object[] objects = new Object[]{new BigDecimal(6), new BigDecimal(1)};
		details.add(objects);
		Mockito.when(query.getResultList()).thenReturn(details);
		userManagementAttributeDaoImpl.getEmployeeTypeAndStatusChangeReason(userInfoBean, 19076L);
	}
	@SuppressWarnings("unchecked")
	@Test(expected = Exception.class)
	public void testGetEmployeeTypeAndStatusChangeReasonFailure() {
		UserInfoBean userInfoBean = new UserInfoBean();
		Mockito.when(query.getResultList()).thenThrow(BFLTechnicalException.class);
		userManagementAttributeDaoImpl.getEmployeeTypeAndStatusChangeReason(userInfoBean, 19076L);
	}

}	