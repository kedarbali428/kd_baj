/*package com.bajaj.bfsd.usermanagement.openmarket.plugin.helper;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfdl.om.insurance.impl.EpBauInsuranceClientImpl;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfsd.om.bean.UserRoleProductBean;

@RunWith(SpringJUnit4ClassRunner.class)
public class OMMasterDataInsurancePluginMapperTest {

	@InjectMocks
	OMMasterDataInsurancePluginMapper omMasterDataInsurancePluginMapper;
	
	@Mock
	private EpBauInsuranceClientImpl epBauInsuranceClientImpl;
	
	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	HttpHeaders headers;
	
	@Test
	public void findUserRoleProductTest() {
		UserRoleProductBean bean = new UserRoleProductBean();
		Mockito.when(epBauInsuranceClientImpl
				.getUserRoleProduct(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any())).thenReturn(bean);
		omMasterDataInsurancePluginMapper.findUserRoleProduct(123L, 123L, 123L, 123L, headers);
		assertNotNull(bean);
	}
	
	@Test
	public void saveUserRoleMappingTest() {
		UserRoleProductBean bean = new UserRoleProductBean(); 
		Mockito.when(epBauInsuranceClientImpl.saveUserRoleProduct(Mockito.any(), Mockito.any())).thenReturn(bean);
		omMasterDataInsurancePluginMapper.saveUserRoleMapping(bean, headers);
		assertNotNull(bean);
	}
	
	@Test
	public void getUserSuperVisorTest() {
		List<com.bfsd.om.bean.SupervisorBean> superVisorList = new ArrayList<>();
		com.bfsd.om.bean.SupervisorBean supervisor = new com.bfsd.om.bean.SupervisorBean();
		supervisor.setId(123L);
		supervisor.setName("Test");
		supervisor.setUserRoleKey(123L);
		supervisor.setUserRoleProdKey(123L);
		superVisorList.add(supervisor);
		Mockito.when(epBauInsuranceClientImpl
				.getUserSuperVisorName(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any())).thenReturn(superVisorList);
		omMasterDataInsurancePluginMapper.getUserSuperVisor(123L, 123L, 123L, headers);
		assertNotNull(superVisorList);	
	}
}
*/