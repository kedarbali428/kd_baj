package com.bajaj.openmarkets.usermanagement.config;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class RestTemplateConfigTest {

	@InjectMocks
	private RestTemplateConfig restTemplate;
	
	@Test
	public void testGetRestTemplate() {
		assertNotNull(restTemplate.getRestTemplate());
	}

}
