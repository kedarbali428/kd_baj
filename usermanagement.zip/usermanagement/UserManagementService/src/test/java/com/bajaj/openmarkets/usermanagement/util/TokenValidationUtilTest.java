package com.bajaj.openmarkets.usermanagement.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.openmarkets.usermanagement.bean.ValidateTokenResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TokenValidationUtilTest {

	@InjectMocks
	private TokenValidationUtil validator;
	
	@Mock
	private BFLLoggerUtilExt logger;
	
	private String tokenValidateUrl;

	@Mock
	private RestTemplate restTemplate;

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(validator, "tokenValidateUrl", "http://localhost:8080/v1/authenticate");
	}
	
	@Test
	public void testGetTokenValidity() {
		ValidateTokenResponse validateTokenResponseBean = new ValidateTokenResponse();
		validateTokenResponseBean.setLoginId("9999999999");
		validateTokenResponseBean.setDefaultRole("pcustomer");
		validateTokenResponseBean.setTokenStatus("VALID");
		validateTokenResponseBean.setUserId(999999999l);

		ResponseEntity<ValidateTokenResponse> tokenValidationResponse = new ResponseEntity<>(validateTokenResponseBean, HttpStatus.OK);
		Mockito.when( restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(ValidateTokenResponse.class)) )
				.thenReturn(tokenValidationResponse);

		assertNotNull(validator.getTokenValidity("authtoken"));
	}

	@Test
	public void testIsValidToken() {
		ValidateTokenResponse response = new ValidateTokenResponse();
		response.setLoginId("9999999999");
		response.setDefaultRole("customer");
		response.setTokenStatus("VALID");
		response.setUserId(9999999999l);

		ResponseEntity<ValidateTokenResponse> tokenValidationResponse = new ResponseEntity<>(response, HttpStatus.OK);
		assertEquals(true, validator.isValidToken(tokenValidationResponse));
	}

	@Test
	public void testGetValidatedToken_Valid() {
		
		ValidateTokenResponse validateTokenResponseBean = new ValidateTokenResponse();
		validateTokenResponseBean.setLoginId("9999999999");
		validateTokenResponseBean.setDefaultRole("pcustomer");
		validateTokenResponseBean.setTokenStatus("VALID");
		validateTokenResponseBean.setUserId(999999999l);

		ResponseEntity<ValidateTokenResponse> tokenValidationResponse = new ResponseEntity<>(validateTokenResponseBean, HttpStatus.OK);
		Mockito.when( restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(ValidateTokenResponse.class)) )
				.thenReturn(tokenValidationResponse);
		
		ValidateTokenResponse response= validator.getValidatedToken("Some Auth Token");
		assertNotNull(response);
	}

	@Test
	public void testGetTokenValidity_RestClientException() {
		Mockito.when( restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(ValidateTokenResponse.class)) )
				.thenThrow(RestClientException.class);
		assertNull(validator.getTokenValidity("authtoken"));
	}
	
	@Test
	public void testIsTokenValid_NullResponse() {
		ResponseEntity<ValidateTokenResponse> tokenValidationResponse = null;
		assertEquals(false, validator.isValidToken(tokenValidationResponse));

	}
	
	@Test
	public void testIsTokenValid_InvalidToken() {
		
		ValidateTokenResponse response = new ValidateTokenResponse();
		response.setLoginId(null);
		response.setDefaultRole(null);
		response.setTokenStatus("INVALID");
		response.setUserId(null);
		
		ResponseEntity<ValidateTokenResponse> tokenValidationResponse = new ResponseEntity<>(response, HttpStatus.OK);

		assertEquals(false, validator.isValidToken(tokenValidationResponse));

	}
	
	@Test
	public void testGetValidatedToken_Invalid() {
		
		ValidateTokenResponse validateTokenResponseBean = new ValidateTokenResponse();
		validateTokenResponseBean.setLoginId(null);
		validateTokenResponseBean.setDefaultRole(null);
		validateTokenResponseBean.setTokenStatus("EXPIRED");
		validateTokenResponseBean.setUserId(null);

		ResponseEntity<ValidateTokenResponse> tokenValidationResponse = new ResponseEntity<>(validateTokenResponseBean, HttpStatus.OK);
		Mockito.when( restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(ValidateTokenResponse.class)) )
				.thenReturn(tokenValidationResponse);
		
		ValidateTokenResponse response= validator.getValidatedToken("Some Auth Token");
		assertNull(response);
	}

}
