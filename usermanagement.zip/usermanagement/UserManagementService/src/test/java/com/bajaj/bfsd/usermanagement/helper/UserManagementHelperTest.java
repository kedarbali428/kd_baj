package com.bajaj.bfsd.usermanagement.helper;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.ValidateTokenBean;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserManagementHelperTest {

	@InjectMocks
	UserManagementHelper userManagementHelper;

	@Value("authType")
	private String authType;

	@Value("authUserName")
	private String authUserName;

	@Value("authPassword")
	private String authPassword;
	@Mock
	BFLLoggerUtil logger;

	@Before
	public void setUp() throws Exception {
		ReflectionTestUtils.setField(userManagementHelper, "authUserName", authUserName);
		ReflectionTestUtils.setField(userManagementHelper, "authPassword", authPassword);
		ReflectionTestUtils.setField(userManagementHelper, "authType", authType);

	}

	@Test
	public void testGetAuthDetails() {
		userManagementHelper.getAuthDetails();
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testcalculateMob() {
		Date startDate = new Date();
		startDate.setDate(11 - 01 - 2019);
		userManagementHelper.calculateMob(startDate);
	}
	@Test
	public void testPopulateTokenBeanWithDecryptedValues() {
		String decryptedKey="abc@gmail.com~12345";
		ValidateTokenBean bean= new ValidateTokenBean();
		userManagementHelper.populateTokenBeanWithDecryptedValues(decryptedKey, bean, logger);
		assertEquals("abc@gmail.com", bean.getDecryptedEmail());
		assertEquals("12345", bean.getDecryptedAppApltKey());
	}
	
	@Test(expected=BFLTechnicalException.class)
	public void testPopulateTokenBeanWithDecryptedValues2() {
		String decryptedKey="abc@gmail.com";
		ValidateTokenBean bean= new ValidateTokenBean();
		userManagementHelper.populateTokenBeanWithDecryptedValues(decryptedKey, bean, logger);
	}
	@Test
	public void testDecryptKey() {
		String res=userManagementHelper.decrypt("/W8j6vCbKO4LDevfNvUn1FWa0VZRaT0yTI35S3Wsckk=", "ENCRYPTION_KEY_BAJAJ", logger);
	 assertEquals("dfg@gmail.com~84255", res);
	}
	
	@Test(expected=BFLTechnicalException.class)
	public void testDecryptKeyExce() {
		userManagementHelper.decrypt("/W8j6vCbKO4LDevfNvUn1FWa0VZRaT0yTI35S3Wsckk=", "", logger);
	}
}