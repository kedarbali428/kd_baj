package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

/**
 * The persistent class for the INVESTMENT_PRODUCTS database table.
 * 
 */
@Entity
@Table(name = "INVESTMENT_PRODUCTS")
public class InvestmentProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long ivprodkey;

	private String ivprodcode;

	private String ivproddesc;

	private BigDecimal ivprodisactive;

	private String ivprodlstupdateby;

	private Timestamp ivprodlstupdatedt;


	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODCATKEY")
	private ProductCategory productCategory;


	public InvestmentProduct() {
		// Constructor
	}

	public long getIvprodkey() {
		return this.ivprodkey;
	}

	public void setIvprodkey(long ivprodkey) {
		this.ivprodkey = ivprodkey;
	}

	public String getIvprodcode() {
		return this.ivprodcode;
	}

	public void setIvprodcode(String ivprodcode) {
		this.ivprodcode = ivprodcode;
	}

	public String getIvproddesc() {
		return this.ivproddesc;
	}

	public void setIvproddesc(String ivproddesc) {
		this.ivproddesc = ivproddesc;
	}

	public BigDecimal getIvprodisactive() {
		return this.ivprodisactive;
	}

	public void setIvprodisactive(BigDecimal ivprodisactive) {
		this.ivprodisactive = ivprodisactive;
	}

	public String getIvprodlstupdateby() {
		return this.ivprodlstupdateby;
	}

	public void setIvprodlstupdateby(String ivprodlstupdateby) {
		this.ivprodlstupdateby = ivprodlstupdateby;
	}

	public Timestamp getIvprodlstupdatedt() {
		return this.ivprodlstupdatedt;
	}

	public void setIvprodlstupdatedt(Timestamp ivprodlstupdatedt) {
		this.ivprodlstupdatedt = ivprodlstupdatedt;
	}
	
	
	public ProductCategory getProductCategory() {
		return this.productCategory;
	}

	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}

}