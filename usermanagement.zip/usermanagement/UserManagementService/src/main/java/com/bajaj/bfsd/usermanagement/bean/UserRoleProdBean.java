package com.bajaj.bfsd.usermanagement.bean;

public class UserRoleProdBean {
	private Long userRoleProdKey;
	private Long roleKey;
	private String roleName;
	private Long subProdKey;
	private Long subProdName;

	public Long getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(Long roleKey) {
		this.roleKey = roleKey;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Long getUserRoleProdKey() {
		return userRoleProdKey;
	}

	public void setUserRoleProdKey(Long userRoleProdKey) {
		this.userRoleProdKey = userRoleProdKey;
	}

	public Long getSubProdKey() {
		return subProdKey;
	}

	public void setSubProdKey(Long subProdKey) {
		this.subProdKey = subProdKey;
	}

	public Long getSubProdName() {
		return subProdName;
	}

	public void setSubProdName(Long subProdName) {
		this.subProdName = subProdName;
	}

}