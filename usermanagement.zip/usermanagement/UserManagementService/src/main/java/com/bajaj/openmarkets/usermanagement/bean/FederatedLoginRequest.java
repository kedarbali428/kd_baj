package com.bajaj.openmarkets.usermanagement.bean;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FederatedLoginRequest  {

	private String clientId;

	private String clientSecret;

	private String authorizedClient;

	private String mobile;

	private Integer customerFlag;

	private Integer partnerCustomerId;
	
	private String authorizedEmployeeCode;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getAuthorizedClient() {
		return authorizedClient;
	}

	public void setAuthorizedClient(String authorizedClient) {
		this.authorizedClient = authorizedClient;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getCustomerFlag() {
		return customerFlag;
	}

	public void setCustomerFlag(Integer customerFlag) {
		this.customerFlag = customerFlag;
	}

	public Integer getPartnerCustomerId() {
		return partnerCustomerId;
	}

	public void setPartnerCustomerId(Integer partnerCustomerId) {
		this.partnerCustomerId = partnerCustomerId;
	}

	public String getAuthorizedEmployeeCode() {
		return authorizedEmployeeCode;
	}

	public void setAuthorizedEmployeeCode(String authorizedEmployeeCode) {
		this.authorizedEmployeeCode = authorizedEmployeeCode;
	}

	@Override
	public String toString() {
		return "FederatedLoginRequest [clientId=" + clientId + ", clientSecret=" + (null != clientSecret) + ", authorizedClient="
				+ authorizedClient + ", mobile=" + mobile + ", customerFlag=" + customerFlag + ", partnerCustomerId="
				+ partnerCustomerId + ", authorizedEmployeeCode=" + authorizedEmployeeCode + "]";
	}

}
