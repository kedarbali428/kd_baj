package com.bajaj.bfsd.usermanagement.bean;

public class UserGetRoleResponceBean {

	long userKey;
	long roleKey;
	String roleName;

	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}

	public long getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(long roleKey) {
		this.roleKey = roleKey;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	@Override
	public String toString() {
		return "UserGetRoleResponceBean [userKey=" + userKey + ", roleKey=" + roleKey + ", roleName=" + roleName + "]";
	}

}
