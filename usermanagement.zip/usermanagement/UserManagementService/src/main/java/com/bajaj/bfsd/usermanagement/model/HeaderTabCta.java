package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the HEADER_TAB_CTA database table.
 * 
 */
@Entity
@Table(name="HEADER_TAB_CTA")
//@NamedQuery(name="HeaderTabCta.findAll", query="SELECT h FROM HeaderTabCta h")
public class HeaderTabCta implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long tabctakey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to CtaType
	@ManyToOne
	@JoinColumn(name="CTAKEY")
	private CtaType ctaType;

	//bi-directional many-to-one association to HeaderTabMaster
	@ManyToOne
	@JoinColumn(name="TABKEY")
	private HeaderTabMaster headerTabMaster;

	public long getTabctakey() {
		return this.tabctakey;
	}

	public void setTabctakey(long tabctakey) {
		this.tabctakey = tabctakey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public CtaType getCtaType() {
		return this.ctaType;
	}

	public void setCtaType(CtaType ctaType) {
		this.ctaType = ctaType;
	}

	public HeaderTabMaster getHeaderTabMaster() {
		return this.headerTabMaster;
	}

	public void setHeaderTabMaster(HeaderTabMaster headerTabMaster) {
		this.headerTabMaster = headerTabMaster;
	}

}