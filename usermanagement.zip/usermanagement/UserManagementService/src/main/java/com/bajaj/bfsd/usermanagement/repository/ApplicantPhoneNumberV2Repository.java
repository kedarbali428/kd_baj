package com.bajaj.bfsd.usermanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.usermanagement.model.ApplicantPhoneNumberV2;
import com.bajaj.bfsd.usermanagement.model.PhoneNumberType;

@Repository
public interface ApplicantPhoneNumberV2Repository extends JpaRepository<ApplicantPhoneNumberV2, Long>{

	List<ApplicantPhoneNumberV2> findByApplicantkeyAndPhoneNumberTypeAndApltphnumisactive(Long applicantKey,
			PhoneNumberType phoneType, Integer isActive);
}
