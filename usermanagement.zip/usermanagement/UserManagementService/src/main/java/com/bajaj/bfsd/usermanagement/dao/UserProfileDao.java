package com.bajaj.bfsd.usermanagement.dao;

import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;

public interface UserProfileDao{

	public void saveProfile(UserProfileBean profileBean, long userKey, String profileResponse);
	
	public UserProfileBean getUserProfile(long userKey);
}
