package com.bajaj.bfsd.usermanagement.bean;

public class ReportingManager {
	private long userKey;
	private String name;
	
	public ReportingManager() {
		super();
	}

	public ReportingManager(long userKey, String name) {
		super();
		this.userKey = userKey;
		this.name = name;
	}

	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
