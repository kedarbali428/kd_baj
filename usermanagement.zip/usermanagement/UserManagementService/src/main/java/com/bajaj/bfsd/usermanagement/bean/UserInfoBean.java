package com.bajaj.bfsd.usermanagement.bean;

import java.math.BigDecimal;
import java.util.List;

public class UserInfoBean {
	private Long userKey;
	private String firstName;
	private String lastName;
	private String designation;
	private String emailId;
	private String adID;
	private String employeeID;
	private String mobileNumber;
	private BigDecimal isActive;
	private String companyName;
	private Long vendorProfileKey;
	private String employeeType;
	private BigDecimal statusChngReason;
	private boolean highestRole;
	private String poType;
	private String maxSumAssuredLimit;
	private String maxPremiumLimit;
	private List <String> paymentModes;
	
	public Long getUserKey() {
		return userKey;
	}
	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAdID() {
		return adID;
	}
	public void setAdID(String adID) {
		this.adID = adID;
	}
	public String getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public BigDecimal getIsActive() {
		return isActive;
	}
	public void setIsActive(BigDecimal isActive) {
		this.isActive = isActive;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Long getVendorProfileKey() {
		return vendorProfileKey;
	}
	public void setVendorProfileKey(Long vendorProfileKey) {
		this.vendorProfileKey = vendorProfileKey;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public BigDecimal getStatusChngReason() {
		return statusChngReason;
	}
	public void setStatusChngReason(BigDecimal statusChngReason) {
		this.statusChngReason = statusChngReason;
	}
	public boolean getHighestRole() {
		return highestRole;
	}
	public void setHighestRole(boolean highestRole) {
		this.highestRole = highestRole;
	}
	public String getPoType() {
		return poType;
	}
	public void setPoType(String poType) {
		this.poType = poType;
	}
	public String getMaxSumAssuredLimit() {
		return maxSumAssuredLimit;
	}
	public void setMaxSumAssuredLimit(String maxSumAssuredLimit) {
		this.maxSumAssuredLimit = maxSumAssuredLimit;
	}
	public String getMaxPremiumLimit() {
		return maxPremiumLimit;
	}
	public void setMaxPremiumLimit(String maxPremiumLimit) {
		this.maxPremiumLimit = maxPremiumLimit;
	}
	public List<String> getPaymentModes() {
		return paymentModes;
	}
	public void setPaymentModes(List<String> paymentModes) {
		this.paymentModes = paymentModes;
	}
}