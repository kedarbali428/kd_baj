package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LinkedinProfileBean extends UserProfileBean implements Serializable{

	private static final long serialVersionUID = 1322594162376580259L;
	
	private String formattedName;
	
	private String phoneticFname;
	
	private String phoneticLname;
	
	private String phoneticFormattedname;

	private String headline;
	
	private String locationName;
	
	private String conuntryCode;
	
	private String industryCode;
	
	private long noOfConn;
	
	private String profileSummary;
	
	private String speacialities;
	
	private String pictureUrl;
	
	private String publicProfileUrl;
	
	private String primaryEmail;
	
	private String secondaryEmail;
	
	@JsonProperty("employmentDetails")
	private List<LinkedinPositionBean> positions;
	
	public String getFormattedName() {
		return formattedName;
	}

	public void setFormattedName(String formattedName) {
		this.formattedName = formattedName;
	}

	public String getPhoneticFname() {
		return phoneticFname;
	}

	public void setPhoneticFname(String phoneticFname) {
		this.phoneticFname = phoneticFname;
	}

	public String getPhoneticLname() {
		return phoneticLname;
	}

	public void setPhoneticLname(String phoneticLname) {
		this.phoneticLname = phoneticLname;
	}

	public String getPhoneticFormattedname() {
		return phoneticFormattedname;
	}

	public void setPhoneticFormattedname(String phoneticFormattedname) {
		this.phoneticFormattedname = phoneticFormattedname;
	}

	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getConuntryCode() {
		return conuntryCode;
	}

	public void setConuntryCode(String conuntryCode) {
		this.conuntryCode = conuntryCode;
	}

	public String getIndustryCode() {
		return industryCode;
	}

	public void setIndustryCode(String industryCode) {
		this.industryCode = industryCode;
	}

	public long getNoOfConn() {
		return noOfConn;
	}

	public void setNoOfConn(long noOfConn) {
		this.noOfConn = noOfConn;
	}

	public String getProfileSummary() {
		return profileSummary;
	}

	public void setProfileSummary(String profileSummary) {
		this.profileSummary = profileSummary;
	}

	public String getSpeacialities() {
		return speacialities;
	}

	public void setSpeacialities(String speacialities) {
		this.speacialities = speacialities;
	}

	public String getPictureUrl() {
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}

	public String getPublicProfileUrl() {
		return publicProfileUrl;
	}

	public void setPublicProfileUrl(String publicProfileUrl) {
		this.publicProfileUrl = publicProfileUrl;
	}

	public String getPrimaryEmail() {
		return primaryEmail;
	}

	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}

	public String getSecondaryEmail() {
		return secondaryEmail;
	}

	public void setSecondaryEmail(String secondaryEmail) {
		this.secondaryEmail = secondaryEmail;
	}

	public List<LinkedinPositionBean> getPositions() {
		return positions;
	}

	public void setPositions(List<LinkedinPositionBean> positions) {
		this.positions = positions;
	}
	
}
