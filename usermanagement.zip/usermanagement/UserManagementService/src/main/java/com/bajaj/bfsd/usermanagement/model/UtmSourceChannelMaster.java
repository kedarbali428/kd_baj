package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the UTM_SOURCE_CHANNEL_MASTER database table. 
 * 
 */
@Entity
@Table(name="UTM_SOURCE_CHANNEL_MASTER")
//@NamedQuery(name="UtmSourceChannelMaster.findAll", query="SELECT u FROM UtmSourceChannelMaster u")
public class UtmSourceChannelMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long utmsrcchnmastkey;

	private String channeltype;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String sourcingchannel;

	private String utmmedium;

	private String utmsource;
	
	@OneToMany(mappedBy="utmsrcchnmastkey")
	private List<UserRoleUtmSourceChannel> userRoleUtmSourceChannels=new ArrayList<>();

	public UtmSourceChannelMaster() {
	}

	public long getUtmsrcchnmastkey() {
		return this.utmsrcchnmastkey;
	}

	public void setUtmsrcchnmastkey(long utmsrcchnmastkey) {
		this.utmsrcchnmastkey = utmsrcchnmastkey;
	}

	public String getChanneltype() {
		return this.channeltype;
	}

	public void setChanneltype(String channeltype) {
		this.channeltype = channeltype;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getSourcingchannel() {
		return this.sourcingchannel;
	}

	public void setSourcingchannel(String sourcingchannel) {
		this.sourcingchannel = sourcingchannel;
	}

	public String getUtmmedium() {
		return this.utmmedium;
	}

	public void setUtmmedium(String utmmedium) {
		this.utmmedium = utmmedium;
	}

	public String getUtmsource() {
		return this.utmsource;
	}

	public void setUtmsource(String utmsource) {
		this.utmsource = utmsource;
	}

	public List<UserRoleUtmSourceChannel> getUserRoleUtmSourceChannels() {
		return userRoleUtmSourceChannels;
	}

	public void setUserRoleUtmSourceChannels(List<UserRoleUtmSourceChannel> userRoleUtmSourceChannels) {
		this.userRoleUtmSourceChannels = userRoleUtmSourceChannels;
	}
}