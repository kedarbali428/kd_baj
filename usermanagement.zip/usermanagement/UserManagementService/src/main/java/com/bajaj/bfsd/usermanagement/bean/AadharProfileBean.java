package com.bajaj.bfsd.usermanagement.bean;

import java.util.Date;

public class AadharProfileBean extends UserProfileBean {

	private static final long serialVersionUID = -7352551607846873183L;
	
	private String aadharNumber;
	
	private Date dob;
	
	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

}
