package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * The persistent class for the FIELD_SET_ROLES database table.
 * 
 */
@Entity
@Table(name = "FIELD_SET_ROLES")
//@NamedQuery(name = "FieldSetRole.findAll", query = "SELECT f FROM FieldSetRole f")
public class FieldSetRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long fieldrolekey;

	private BigDecimal fieldaccess;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	// bi-directional many-to-one association to BfsdRoleMaster
	@ManyToOne
	@JoinColumn(name = "ROLEKEY")
	private BfsdRoleMaster bfsdRoleMaster;

	// bi-directional many-to-one association to FieldSetAttribute
	@ManyToOne
	@JoinColumn(name = "FIELDKEY")
	private FieldSetAttribute fieldSetAttribute;

	public long getFieldrolekey() {
		return this.fieldrolekey;
	}

	public void setFieldrolekey(long fieldrolekey) {
		this.fieldrolekey = fieldrolekey;
	}

	public BigDecimal getFieldaccess() {
		return this.fieldaccess;
	}

	public void setFieldaccess(BigDecimal fieldaccess) {
		this.fieldaccess = fieldaccess;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return this.bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

	public FieldSetAttribute getFieldSetAttribute() {
		return this.fieldSetAttribute;
	}

	public void setFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		this.fieldSetAttribute = fieldSetAttribute;
	}

}