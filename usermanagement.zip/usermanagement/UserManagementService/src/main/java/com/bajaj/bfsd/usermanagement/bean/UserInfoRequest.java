package com.bajaj.bfsd.usermanagement.bean;

import java.math.BigDecimal;
import java.util.List;

public class UserInfoRequest {
	private Long userKey;
	private String mobileNumber;
	private BigDecimal isActive;
	private BigDecimal statusChngReason;
	private String emailId;
	private String spCode;
	private String lpCode;
	private String maxSumAssuredLimit;
	private String maxPremiumLimit;
	private String reportingManager;
	private String description;
	private String samaccountname;
	private List <String> skills;
	private List <String> specialization;
	private List <String> paymentModes;
	private List <String> channel;
	private String poType;
	
	public Long getUserKey() {
		return userKey;
	}
	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public BigDecimal getIsActive() {
		return isActive;
	}
	public void setIsActive(BigDecimal isActive) {
		this.isActive = isActive;
	}
	public BigDecimal getStatusChngReason() {
		return statusChngReason;
	}
	public void setStatusChngReason(BigDecimal statusChngReason) {
		this.statusChngReason = statusChngReason;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getSpCode() {
		return spCode;
	}
	public void setSpCode(String spCode) {
		this.spCode = spCode;
	}
	public String getLpCode() {
		return lpCode;
	}
	public void setLpCode(String lpCode) {
		this.lpCode = lpCode;
	}
	public String getMaxSumAssuredLimit() {
		return maxSumAssuredLimit;
	}
	public void setMaxSumAssuredLimit(String maxSumAssuredLimit) {
		this.maxSumAssuredLimit = maxSumAssuredLimit;
	}
	public String getMaxPremiumLimit() {
		return maxPremiumLimit;
	}
	public void setMaxPremiumLimit(String maxPremiumLimit) {
		this.maxPremiumLimit = maxPremiumLimit;
	}
	public String getReportingManager() {
		return reportingManager;
	}
	public void setReportingManager(String reportingManager) {
		this.reportingManager = reportingManager;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSamaccountname() {
		return samaccountname;
	}
	public void setSamaccountname(String samaccountname) {
		this.samaccountname = samaccountname;
	}
	public List<String> getSkills() {
		return skills;
	}
	public void setSkills(List<String> skills) {
		this.skills = skills;
	}
	public List<String> getSpecialization() {
		return specialization;
	}
	public void setSpecialization(List<String> specialization) {
		this.specialization = specialization;
	}
	public List<String> getPaymentModes() {
		return paymentModes;
	}
	public void setPaymentModes(List<String> paymentModes) {
		this.paymentModes = paymentModes;
	}
	public List<String> getChannel() {
		return channel;
	}
	public void setChannel(List<String> channel) {
		this.channel = channel;
	}
	public String getPoType() {
		return poType;
	}
	public void setPoType(String poType) {
		this.poType = poType;
	}
}
