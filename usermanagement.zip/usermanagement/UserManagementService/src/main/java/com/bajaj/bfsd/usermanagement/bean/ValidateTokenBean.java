package com.bajaj.bfsd.usermanagement.bean;

public class ValidateTokenBean {
	
	private String newEmail;
	private String token;
	private long contactType;
	private long applicationApplicantId;
	
	private String decryptedEmail;
	private String decryptedAppApltKey;

	public String getNewEmail() {
		return newEmail;
	}
	public void setNewEmail(String newEmail) {
		this.newEmail = newEmail;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public long getApplicationApplicantId() {
		return applicationApplicantId;
	}
	public void setApplicationApplicantId(long applicationApplicantId) {
		this.applicationApplicantId = applicationApplicantId;
	}
	public long getContactType() {
		return contactType;
	}
	public void setContactType(long contactType) {
		this.contactType = contactType;
	}
	public String getDecryptedEmail() {
		return decryptedEmail;
	}
	public void setDecryptedEmail(String decryptedEmail) {
		this.decryptedEmail = decryptedEmail;
	}
	public String getDecryptedAppApltKey() {
		return decryptedAppApltKey;
	}
	public void setDecryptedAppApltKey(String decryptedAppApltKey) {
		this.decryptedAppApltKey = decryptedAppApltKey;
	}	
	
}
