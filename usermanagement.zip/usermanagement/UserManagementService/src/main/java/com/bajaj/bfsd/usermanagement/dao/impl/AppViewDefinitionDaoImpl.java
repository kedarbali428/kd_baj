package com.bajaj.bfsd.usermanagement.dao.impl;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.usermanagement.dao.AppViewDefinitionDao;
import com.bajaj.bfsd.usermanagement.model.AppViewDefinition;
import com.bajaj.bfsd.usermanagement.util.UserManagementUtility;

@Repository
public class AppViewDefinitionDaoImpl extends BFLComponent implements AppViewDefinitionDao{
	
	@Autowired
	Environment environment;
	
	@Autowired
	EntityManager entityManager;

	@Override
	@Transactional
	public AppViewDefinition createAndSaveAppViewDefinition(Long userKey, Integer viewAccess, Long userRoleKey, String condition) {
        AppViewDefinition appViewDefinition = new AppViewDefinition();
		appViewDefinition.setViewname(userKey+environment.getProperty("-").trim()+userRoleKey+environment.getProperty(viewAccess.toString()).trim());  // FIX from DB Team
		appViewDefinition.setCreatedby(environment.getProperty("system").trim());   // To_Do confirm from DB Team
		appViewDefinition.setLstupdateby(environment.getProperty("system").trim());
		appViewDefinition.setCreateddt(UserManagementUtility.getCurrentTimeStamp());
		appViewDefinition.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
		appViewDefinition.setIsactive(new BigDecimal(1));
		appViewDefinition.setViewaccess(new BigDecimal(viewAccess));   
		appViewDefinition.setCondition(condition);                     // To_Do Condition FIX from DB Team
		entityManager.persist(appViewDefinition);
		return appViewDefinition;
	}

}
