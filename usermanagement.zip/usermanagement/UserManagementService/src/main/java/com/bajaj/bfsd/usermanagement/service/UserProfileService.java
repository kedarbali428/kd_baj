package com.bajaj.bfsd.usermanagement.service;

import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileSaveRequest;

public interface UserProfileService{

	public void saveUserProfile(UserProfileSaveRequest profileSaveRequest);
	
	public UserProfileBean getUserProfile(long userKey);
	
}
