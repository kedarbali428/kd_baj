package com.bajaj.bfsd.usermanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.usermanagement.service.impl.AadharProfileService;
import com.bajaj.bfsd.usermanagement.service.impl.FacebookProfileService;
import com.bajaj.bfsd.usermanagement.service.impl.LinkedinProfileService;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;

@Component
public class UserProfileServiceFactory extends BFLComponent{

	@Autowired
	FacebookProfileService fbProfileService;

	@Autowired
	LinkedinProfileService linkedinProfileService;
	
	@Autowired
	AadharProfileService aadharProfileService;

	public UserProfileService getServiceInstance(String source) {

		switch (source) {
		case UserManagementConstants.FACEBOOK:
			return fbProfileService;
		case UserManagementConstants.LINKEDIN:
			return linkedinProfileService;
		case UserManagementConstants.LOGINACCTYPE_AADHAR_STR:
			return aadharProfileService;
		default :
			return null;
		}
	}
}
