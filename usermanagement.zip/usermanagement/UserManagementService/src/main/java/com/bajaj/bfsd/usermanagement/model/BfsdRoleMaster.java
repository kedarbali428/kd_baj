package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the BFSD_ROLE_MASTER database table.
 * 
 */
@Entity
@Table(name = "BFSD_ROLE_MASTER")
@NamedQueries({
		@NamedQuery(name = "BfsdRoleMaster.findRoleFromCode", query = "SELECT b FROM BfsdRoleMaster b where rolecd = :roleCode and isactive=1"),
//		@NamedQuery(name = "BfsdRoleMaster.findAll", query = "SELECT b FROM BfsdRoleMaster b") 
		})
public class BfsdRoleMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long rolekey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String rolecd;

	private String rolename;

	// bi-directional many-to-one association to AppRoleQueue
	@OneToMany(mappedBy = "bfsdRoleMaster")
	private List<AppRoleQueue> appRoleQueues;

	// bi-directional many-to-one association to AppRoleView
	@OneToMany(mappedBy = "bfsdRoleMaster")
	private List<AppRoleView> appRoleViews;

	// bi-directional many-to-one association to BfsdFunctionRole
	@OneToMany(mappedBy = "bfsdRoleMaster")
	private List<BfsdFunctionRole> bfsdFunctionRoles;

	// bi-directional many-to-one association to BfsdRoleMaster
	@ManyToOne
	@JoinColumn(name = "PARENTROLE")
	private BfsdRoleMaster bfsdRoleMaster;

	// bi-directional many-to-one association to BfsdRoleMaster
	@OneToMany(mappedBy = "bfsdRoleMaster")
	private List<BfsdRoleMaster> bfsdRoleMasters;

	// bi-directional many-to-one association to CtaRole
	@OneToMany(mappedBy = "bfsdRoleMaster")
	private List<CtaRole> ctaRoles;

	// bi-directional many-to-one association to FieldSetRole
	@OneToMany(mappedBy = "bfsdRoleMaster")
	private List<FieldSetRole> fieldSetRoles;

	// bi-directional many-to-one association to HeaderTabRole
	@OneToMany(mappedBy = "bfsdRoleMaster")
	private List<HeaderTabRole> headerTabRoles;

	// bi-directional many-to-one association to UserRole
	@OneToMany(mappedBy = "bfsdRoleMaster")
	private List<UserRole> userRoles;

	// bi-directional many-to-one association to UserRole
	@OneToMany(mappedBy = "bfsdRoleMaster")
	private List<UserRoleL3> userRolesL3;

	public List<UserRoleL3> getUserRolesL3() {
		return userRolesL3;
	}

	public void setUserRolesL3(List<UserRoleL3> userRolesL3) {
		this.userRolesL3 = userRolesL3;
	}

	public long getRolekey() {
		return this.rolekey;
	}

	public void setRolekey(long rolekey) {
		this.rolekey = rolekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getRolecd() {
		return this.rolecd;
	}

	public void setRolecd(String rolecd) {
		this.rolecd = rolecd;
	}

	public String getRolename() {
		return this.rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	public List<AppRoleQueue> getAppRoleQueues() {
		return this.appRoleQueues;
	}

	public void setAppRoleQueues(List<AppRoleQueue> appRoleQueues) {
		this.appRoleQueues = appRoleQueues;
	}

	public AppRoleQueue addAppRoleQueue(AppRoleQueue appRoleQueue) {
		getAppRoleQueues().add(appRoleQueue);
		appRoleQueue.setBfsdRoleMaster(this);

		return appRoleQueue;
	}

	public AppRoleQueue removeAppRoleQueue(AppRoleQueue appRoleQueue) {
		getAppRoleQueues().remove(appRoleQueue);
		appRoleQueue.setBfsdRoleMaster(null);

		return appRoleQueue;
	}

	public List<AppRoleView> getAppRoleViews() {
		return this.appRoleViews;
	}

	public void setAppRoleViews(List<AppRoleView> appRoleViews) {
		this.appRoleViews = appRoleViews;
	}

	public AppRoleView addAppRoleView(AppRoleView appRoleView) {
		getAppRoleViews().add(appRoleView);
		appRoleView.setBfsdRoleMaster(this);

		return appRoleView;
	}

	public AppRoleView removeAppRoleView(AppRoleView appRoleView) {
		getAppRoleViews().remove(appRoleView);
		appRoleView.setBfsdRoleMaster(null);

		return appRoleView;
	}

	public List<BfsdFunctionRole> getBfsdFunctionRoles() {
		return this.bfsdFunctionRoles;
	}

	public void setBfsdFunctionRoles(List<BfsdFunctionRole> bfsdFunctionRoles) {
		this.bfsdFunctionRoles = bfsdFunctionRoles;
	}

	public BfsdFunctionRole addBfsdFunctionRole(BfsdFunctionRole bfsdFunctionRole) {
		getBfsdFunctionRoles().add(bfsdFunctionRole);
		bfsdFunctionRole.setBfsdRoleMaster(this);

		return bfsdFunctionRole;
	}

	public BfsdFunctionRole removeBfsdFunctionRole(BfsdFunctionRole bfsdFunctionRole) {
		getBfsdFunctionRoles().remove(bfsdFunctionRole);
		bfsdFunctionRole.setBfsdRoleMaster(null);

		return bfsdFunctionRole;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return this.bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

	public List<BfsdRoleMaster> getBfsdRoleMasters() {
		return this.bfsdRoleMasters;
	}

	public void setBfsdRoleMasters(List<BfsdRoleMaster> bfsdRoleMasters) {
		this.bfsdRoleMasters = bfsdRoleMasters;
	}

	public BfsdRoleMaster addBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		getBfsdRoleMasters().add(bfsdRoleMaster);
		bfsdRoleMaster.setBfsdRoleMaster(this);

		return bfsdRoleMaster;
	}

	public BfsdRoleMaster removeBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		getBfsdRoleMasters().remove(bfsdRoleMaster);
		bfsdRoleMaster.setBfsdRoleMaster(null);

		return bfsdRoleMaster;
	}

	public List<CtaRole> getCtaRoles() {
		return this.ctaRoles;
	}

	public void setCtaRoles(List<CtaRole> ctaRoles) {
		this.ctaRoles = ctaRoles;
	}

	public CtaRole addCtaRole(CtaRole ctaRole) {
		getCtaRoles().add(ctaRole);
		ctaRole.setBfsdRoleMaster(this);

		return ctaRole;
	}

	public CtaRole removeCtaRole(CtaRole ctaRole) {
		getCtaRoles().remove(ctaRole);
		ctaRole.setBfsdRoleMaster(null);

		return ctaRole;
	}

	public List<FieldSetRole> getFieldSetRoles() {
		return this.fieldSetRoles;
	}

	public void setFieldSetRoles(List<FieldSetRole> fieldSetRoles) {
		this.fieldSetRoles = fieldSetRoles;
	}

	public FieldSetRole addFieldSetRole(FieldSetRole fieldSetRole) {
		getFieldSetRoles().add(fieldSetRole);
		fieldSetRole.setBfsdRoleMaster(this);

		return fieldSetRole;
	}

	public FieldSetRole removeFieldSetRole(FieldSetRole fieldSetRole) {
		getFieldSetRoles().remove(fieldSetRole);
		fieldSetRole.setBfsdRoleMaster(null);

		return fieldSetRole;
	}

	public List<HeaderTabRole> getHeaderTabRoles() {
		return this.headerTabRoles;
	}

	public void setHeaderTabRoles(List<HeaderTabRole> headerTabRoles) {
		this.headerTabRoles = headerTabRoles;
	}

	public HeaderTabRole addHeaderTabRole(HeaderTabRole headerTabRole) {
		getHeaderTabRoles().add(headerTabRole);
		headerTabRole.setBfsdRoleMaster(this);

		return headerTabRole;
	}

	public HeaderTabRole removeHeaderTabRole(HeaderTabRole headerTabRole) {
		getHeaderTabRoles().remove(headerTabRole);
		headerTabRole.setBfsdRoleMaster(null);

		return headerTabRole;
	}

	public List<UserRole> getUserRoles() {
		return this.userRoles;
	}

	public void setUserRoles(List<UserRole> userRoles) {
		this.userRoles = userRoles;
	}

	public UserRole addUserRole(UserRole userRole) {
		getUserRoles().add(userRole);
		userRole.setBfsdRoleMaster(this);

		return userRole;
	}

	public UserRole removeUserRole(UserRole userRole) {
		getUserRoles().remove(userRole);
		userRole.setBfsdRoleMaster(null);

		return userRole;
	}

}