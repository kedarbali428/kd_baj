package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the USER_SOCIAL_PROFILE_FACEBOOK database table.
 * 
 */
@Entity
@Table(name="USER_SOCIAL_PROFILE_FACEBOOK")
//@NamedQuery(name="UserSocialProfileFacebook.findAll", query="SELECT u FROM UserSocialProfileFacebook u")
public class UserSocialProfileFacebook implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false, precision=20)
	private long usrsocprffbkkey;

	@Column(length=20)
	private String agerangemax;

	@Column(length=20)
	private String agerangemin;

	@Temporal(TemporalType.DATE)
	private Date dob;

	@Column(length=100)
	private String emailid;

	@Column(length=20)
	private String employeenum;

	@Column(length=100)
	private String firstname;

	@Column(length=20)
	private String gender;

	@Column(length=100)
	private String hometown;

	@Column(precision=1)
	private byte isverified;

	@Column(length=50)
	private String lastname;

	@Column(length=20)
	private String lstupdateby;

	private Timestamp lstupdatedt;

	@Column(length=50)
	private String middlename;

	@Column(length=100)
	private String profileid;

	@Column(length=100)
	private String profilelink;

	private Timestamp profileupdatedtime;

	@Column(length=20)
	private String relationshipstatus;

	@Lob
	private String responsedoc;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="USERKEY", nullable=false)
	private BfsdUser bfsdUser;

	public long getUsrsocprffbkkey() {
		return this.usrsocprffbkkey;
	}

	public void setUsrsocprffbkkey(long usrsocprffbkkey) {
		this.usrsocprffbkkey = usrsocprffbkkey;
	}

	public String getAgerangemax() {
		return this.agerangemax;
	}

	public void setAgerangemax(String agerangemax) {
		this.agerangemax = agerangemax;
	}

	public String getAgerangemin() {
		return this.agerangemin;
	}

	public void setAgerangemin(String agerangemin) {
		this.agerangemin = agerangemin;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmailid() {
		return this.emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getEmployeenum() {
		return this.employeenum;
	}

	public void setEmployeenum(String employeenum) {
		this.employeenum = employeenum;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getHometown() {
		return this.hometown;
	}

	public void setHometown(String hometown) {
		this.hometown = hometown;
	}

	public byte getIsverified() {
		return this.isverified;
	}

	public void setIsverified(byte isverified) {
		this.isverified = isverified;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getMiddlename() {
		return this.middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getProfileid() {
		return this.profileid;
	}

	public void setProfileid(String profileid) {
		this.profileid = profileid;
	}

	public String getProfilelink() {
		return this.profilelink;
	}

	public void setProfilelink(String profilelink) {
		this.profilelink = profilelink;
	}

	public Timestamp getProfileupdatedtime() {
		return this.profileupdatedtime;
	}

	public void setProfileupdatedtime(Timestamp profileupdatedtime) {
		this.profileupdatedtime = profileupdatedtime;
	}

	public String getRelationshipstatus() {
		return this.relationshipstatus;
	}

	public void setRelationshipstatus(String relationshipstatus) {
		this.relationshipstatus = relationshipstatus;
	}

	public String getResponsedoc() {
		return this.responsedoc;
	}

	public void setResponsedoc(String responsedoc) {
		this.responsedoc = responsedoc;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

}