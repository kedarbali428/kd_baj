package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the EMP_HIERARCHY_TMP database table.
 * 
 */
@Entity
@Table(name="EMP_HIERARCHY_TMP")
//@NamedQuery(name="EmpHierarchyTmp.findAll", query="SELECT e FROM EmpHierarchyTmp e")
public class EmpHierarchyTmp implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private Long dummyId;

	private String functions;

	private String notes;

	private String product;

	@Column(name="\"ROLES\"")
	private String roles;

	public String getFunctions() {
		return this.functions;
	}

	public void setFunctions(String functions) {
		this.functions = functions;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getProduct() {
		return this.product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getRoles() {
		return this.roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

}