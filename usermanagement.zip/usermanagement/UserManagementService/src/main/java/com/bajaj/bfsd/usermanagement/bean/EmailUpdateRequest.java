package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class EmailUpdateRequest implements Serializable{
	
	private static final long serialVersionUID = 629026023214667881L;
	
	@NotEmpty(message = "UMS-031")
	@Pattern(regexp = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$",message="UMS-032")
	private String newEmail;
	
	@NotEmpty(message = "UMS-031")
	private String oldEmail;
	
	@DecimalMin(value="1",message = "UMS-035")
	private long applicantKey;

	public String getNewEmail() {
		return newEmail;
	}

	public void setNewEmail(String newEmail) {
		this.newEmail = newEmail;
	}

	public long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getOldEmail() {
		return oldEmail;
	}

	public void setOldEmail(String oldEmail) {
		this.oldEmail = oldEmail;
	}

}
