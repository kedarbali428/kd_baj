package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the CTA_ROLES database table.
 * 
 */
@Entity
@Table(name="CTA_ROLES")
//@NamedQuery(name="CtaRole.findAll", query="SELECT c FROM CtaRole c")
public class CtaRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long ctarolekey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to BfsdRoleMaster
	@ManyToOne
	@JoinColumn(name="ROLEKEY")
	private BfsdRoleMaster bfsdRoleMaster;

	//bi-directional many-to-one association to CtaProduct
	@ManyToOne
	@JoinColumn(name="CTAPRODKEY")
	private CtaProduct ctaProduct;

	public long getCtarolekey() {
		return this.ctarolekey;
	}

	public void setCtarolekey(long ctarolekey) {
		this.ctarolekey = ctarolekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return this.bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

	public CtaProduct getCtaProduct() {
		return this.ctaProduct;
	}

	public void setCtaProduct(CtaProduct ctaProduct) {
		this.ctaProduct = ctaProduct;
	}

}