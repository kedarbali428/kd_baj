package com.bajaj.bfsd.usermanagement.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.usermanagement.model.BusinessVerticalMaster;

@Repository
public interface BusinessVerticalMasterRepository extends JpaRepository<BusinessVerticalMaster, Long> {
	@Query(value = "select distinct(businessverticalcode), businessverticalname from BusinessVerticalMaster where isactive=:isActive")
	List<Object[]> findByIsActive(@Param("isActive") BigDecimal isActive);
	
	@Query(value = "select potypecode, potype from BusinessVerticalMaster where businessverticalcode=:businessVerticalCode and isactive=:isActive")
	List<Object[]> findByBusinessVerticalCodeAndIsActive(@Param("businessVerticalCode") String businessVerticalCode, @Param("isActive") BigDecimal isActive);
}