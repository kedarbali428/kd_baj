package com.bajaj.openmarkets.usermanagement.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.openmarkets.usermanagement.bean.ValidateTokenResponse;

@Component
public class TokenValidationUtil {

	private static final String CLASS_NAME = TokenValidationUtil.class.getCanonicalName();
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Value("${api.tokenmanagement.authenticate.token.POST.url}")
	private String tokenValidateUrl;

	@Autowired
	@Qualifier("OMUserManagementRestTemplate")
	private RestTemplate restTemplate;

	public ResponseEntity<?> getTokenValidity(String authtoken) {
		HttpHeaders headers = new HttpHeaders();
		headers.add(UserManagementConstants.AUTH_TOKEN, authtoken);

		HttpEntity<Object> entity = new HttpEntity<>(null, headers);

		ResponseEntity<?> validationResponse = null;
		try {
			validationResponse = restTemplate.exchange(tokenValidateUrl, HttpMethod.POST, entity,
					ValidateTokenResponse.class);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Token Validation response: "+validationResponse);
		} catch (RestClientException e) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					" Rest call failed to: " + tokenValidateUrl);
		}

		return validationResponse;
	}
	
	public boolean isValidToken(ResponseEntity<?> tokenValidationResponse) {
		if (null == tokenValidationResponse || !HttpStatus.OK.equals(tokenValidationResponse.getStatusCode())
				|| null == tokenValidationResponse.getBody()) {
			return false;
		}

		ValidateTokenResponse tokenValidateResponse = (ValidateTokenResponse) tokenValidationResponse.getBody();

		String tokenStatus = tokenValidateResponse.getTokenStatus();
		if (tokenStatus == null || UserManagementConstants.EXPIRED_STATUS.equals(tokenStatus) 
				|| UserManagementConstants.INVALID_STATUS.equals(tokenStatus)) {
			return false;
		} else {
			return true;
		}
	}

	public ValidateTokenResponse getValidatedToken(String authToken) {
		ResponseEntity<?> tokenValidity = getTokenValidity(authToken);
		boolean validToken = isValidToken(tokenValidity);
		ValidateTokenResponse tokenValidateResponse = null;
		if(validToken) {
			tokenValidateResponse = (ValidateTokenResponse) tokenValidity.getBody();
		}
		return tokenValidateResponse;	
	}
}
