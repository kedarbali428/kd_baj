package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the APP_CTA_TYPES database table.
 * 
 */
@Entity
@Table(name="APP_CTA_TYPES")
//@NamedQuery(name="AppCtaType.findAll", query="SELECT a FROM AppCtaType a")
public class AppCtaType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long ctakey;

	private String ctaactivity;

	private BigDecimal ctacode;

	private String ctadescription;

	private BigDecimal ctalocation;

	private String ctaname;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to AppCtaProduct
	@OneToMany(mappedBy="appCtaType")
	private List<AppCtaProduct> appCtaProducts;

	//bi-directional many-to-one association to AppCtaSection
	@OneToMany(mappedBy="appCtaType")
	private List<AppCtaSection> appCtaSections;

	public long getCtakey() {
		return this.ctakey;
	}

	public void setCtakey(long ctakey) {
		this.ctakey = ctakey;
	}

	public String getCtaactivity() {
		return this.ctaactivity;
	}

	public void setCtaactivity(String ctaactivity) {
		this.ctaactivity = ctaactivity;
	}

	public BigDecimal getCtacode() {
		return this.ctacode;
	}

	public void setCtacode(BigDecimal ctacode) {
		this.ctacode = ctacode;
	}

	public String getCtadescription() {
		return this.ctadescription;
	}

	public void setCtadescription(String ctadescription) {
		this.ctadescription = ctadescription;
	}

	public BigDecimal getCtalocation() {
		return this.ctalocation;
	}

	public void setCtalocation(BigDecimal ctalocation) {
		this.ctalocation = ctalocation;
	}

	public String getCtaname() {
		return this.ctaname;
	}

	public void setCtaname(String ctaname) {
		this.ctaname = ctaname;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public List<AppCtaProduct> getAppCtaProducts() {
		return this.appCtaProducts;
	}

	public void setAppCtaProducts(List<AppCtaProduct> appCtaProducts) {
		this.appCtaProducts = appCtaProducts;
	}

	public AppCtaProduct addAppCtaProduct(AppCtaProduct appCtaProduct) {
		getAppCtaProducts().add(appCtaProduct);
		appCtaProduct.setAppCtaType(this);

		return appCtaProduct;
	}

	public AppCtaProduct removeAppCtaProduct(AppCtaProduct appCtaProduct) {
		getAppCtaProducts().remove(appCtaProduct);
		appCtaProduct.setAppCtaType(null);

		return appCtaProduct;
	}

	public List<AppCtaSection> getAppCtaSections() {
		return this.appCtaSections;
	}

	public void setAppCtaSections(List<AppCtaSection> appCtaSections) {
		this.appCtaSections = appCtaSections;
	}

	public AppCtaSection addAppCtaSection(AppCtaSection appCtaSection) {
		getAppCtaSections().add(appCtaSection);
		appCtaSection.setAppCtaType(this);

		return appCtaSection;
	}

	public AppCtaSection removeAppCtaSection(AppCtaSection appCtaSection) {
		getAppCtaSections().remove(appCtaSection);
		appCtaSection.setAppCtaType(null);

		return appCtaSection;
	}

}