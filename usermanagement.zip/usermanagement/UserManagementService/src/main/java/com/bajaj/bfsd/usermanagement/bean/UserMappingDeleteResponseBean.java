package com.bajaj.bfsd.usermanagement.bean;

public class UserMappingDeleteResponseBean {
	
	private long userKey;
	private long roleKey;
	private boolean isActive;
	public long getUserKey() {
		return userKey;
	}
	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}
	public long getRoleKey() {
		return roleKey;
	}
	public void setRoleKey(long roleKey) {
		this.roleKey = roleKey;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
}