package com.bajaj.bfsd.usermanagement.bean;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "firstName", "lastName", "designation","emailId" ,"adID","employeeID"})
public class User {
	private String lastName;
	private String userKey;
	private String mobileNumber;
	private String designation;
	private BigDecimal isActive;
	private String firstName;
	private String emailId;
	private String companyName;
	private long vendorProfileKey;
	private String employeeType;
	private UserVendorProfileBean userVendorProfile;
	private List<UserMapping> empRoleList;
	private BigDecimal statusChngReason;
	private String employeeID;
	private String adID;
	private String poType;
	private String reportingManager;
	private String spCode;
	private String lpCode;
	private String maxSumAssuredLimit;
	private String maxPremiumLimit;
	private List <String> skills;
	private List <String> specialization;
	private List <String> paymentModes;
	private List <String> channel;

	public BigDecimal getStatusChngReason() {
		return statusChngReason;
	}

	public void setStatusChngReason(BigDecimal statusChngReason) {
		this.statusChngReason = statusChngReason;
	}

	public List<UserMapping> getEmpRoleList() {
		return empRoleList;
	}

	public void setEmpRoleList(List<UserMapping> empRoleList) {
		this.empRoleList = empRoleList;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	private boolean highestRole;

	public boolean isHighestRole() {
		return highestRole;
	}

	public void setHighestRole(boolean highestRole) {
		this.highestRole = highestRole;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getUserKey() {
		return userKey;
	}

	public void setUserKey(String userKey) {
		this.userKey = userKey;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public BigDecimal getIsActive() {
		return isActive;
	}

	public void setIsActive(BigDecimal isActive) {
		this.isActive = isActive;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public long getVendorProfileKey() {
		return vendorProfileKey;
	}

	public void setVendorProfileKey(long vendorProfileKey) {
		this.vendorProfileKey = vendorProfileKey;
	}

	public UserVendorProfileBean getUserVendorProfile() {
		return userVendorProfile;
	}

	public void setUserVendorProfile(UserVendorProfileBean userVendorProfile) {
		this.userVendorProfile = userVendorProfile;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getAdID() {
		return adID;
	}

	public void setAdID(String adID) {
		this.adID = adID;
	}

	public String getPoType() {
		return poType;
	}

	public void setPoType(String poType) {
		this.poType = poType;
	}

	public String getReportingManager() {
		return reportingManager;
	}

	public void setReportingManager(String reportingManager) {
		this.reportingManager = reportingManager;
	}

	public String getSpCode() {
		return spCode;
	}

	public void setSpCode(String spCode) {
		this.spCode = spCode;
	}

	public String getLpCode() {
		return lpCode;
	}

	public void setLpCode(String lpCode) {
		this.lpCode = lpCode;
	}

	public String getMaxSumAssuredLimit() {
		return maxSumAssuredLimit;
	}

	public void setMaxSumAssuredLimit(String maxSumAssuredLimit) {
		this.maxSumAssuredLimit = maxSumAssuredLimit;
	}

	public String getMaxPremiumLimit() {
		return maxPremiumLimit;
	}

	public void setMaxPremiumLimit(String maxPremiumLimit) {
		this.maxPremiumLimit = maxPremiumLimit;
	}

	public List<String> getSkills() {
		return skills;
	}

	public void setSkills(List<String> skills) {
		this.skills = skills;
	}

	public List<String> getSpecialization() {
		return specialization;
	}

	public void setSpecialization(List<String> specialization) {
		this.specialization = specialization;
	}

	public List<String> getPaymentModes() {
		return paymentModes;
	}

	public void setPaymentModes(List<String> paymentModes) {
		this.paymentModes = paymentModes;
	}

	public List<String> getChannel() {
		return channel;
	}

	public void setChannel(List<String> channel) {
		this.channel = channel;
	}
	
}
