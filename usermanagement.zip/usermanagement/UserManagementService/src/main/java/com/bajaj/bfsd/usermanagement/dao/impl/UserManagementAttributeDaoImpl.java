package com.bajaj.bfsd.usermanagement.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.UserInfoBean;
import com.bajaj.bfsd.usermanagement.dao.UserManagementAttributeDao;
import com.bajaj.bfsd.usermanagement.model.UserAddlAttributes;
import com.bajaj.bfsd.usermanagement.util.QueryConstants;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bfl.common.exceptions.BFLTechnicalException;

@RefreshScope
@Repository
public class UserManagementAttributeDaoImpl implements UserManagementAttributeDao {
	@Autowired
	EntityManager entityManager;

	@Autowired
	EntityManagerFactory entityManagerFactory;
	
	@Autowired
	BFLLoggerUtil logger;
	
	private static final String THIS_CLASS = UserManagementAttributeDaoImpl.class.getSimpleName();
	
	public static final String UMS_047 = "UMS-047";
	public static final String UMS_048 = "UMS-048";
	public static final String UMS_049 = "UMS-049";

	@SuppressWarnings("unchecked")
	@Override
	public void getUserProfileDetails(UserInfoBean userInfoBean, long userKey) {
		try {
			Query query = entityManager.createQuery(QueryConstants.FETCH_USERPROFILE_DETAILS);
			BigDecimal isActive = new BigDecimal(1);
			query.setParameter("userKey", userKey);
			query.setParameter("isActive", isActive);
			
			List<Object[]> userProfileDetails = query.getResultList();
			if(!userProfileDetails.isEmpty()) {
				userInfoBean.setIsActive(new BigDecimal(1));
				for (Object[] objects : userProfileDetails) {
					userInfoBean.setVendorProfileKey(Long.valueOf(objects[0].toString()));
					userInfoBean.setFirstName(String.valueOf(objects[1]));
					userInfoBean.setLastName(String.valueOf(objects[2]));
					userInfoBean.setEmailId(String.valueOf(objects[3]));
					userInfoBean.setMobileNumber(String.valueOf(objects[4]));
					userInfoBean.setDesignation(String.valueOf(objects[5]));
					userInfoBean.setAdID(String.valueOf(objects[6]));
					userInfoBean.setEmployeeID(String.valueOf(objects[7]));
					userInfoBean.setCompanyName(String.valueOf(objects[8]));
				}
			}
		}catch (Exception exception) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
					"Exception occured while getting user profile details : " + exception);
			throw new BFLTechnicalException(UMS_047, "Exception occured while getting user profile details : " + exception);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void getUserAdditionalAttributeDetails(UserInfoBean userInfoBean, long userKey) {
		try {
			Query query = entityManager.createQuery(QueryConstants.GET_ADDITIONAL_ATTRIBUTE);
			query.setParameter("userKey", userKey);
			query.setParameter("isActive", 1);
			List<UserAddlAttributes> attributeList = query.getResultList();
			List<String> paymentModes = new ArrayList<>();
			if (!CollectionUtils.isEmpty(attributeList)) {
				for(UserAddlAttributes userAddlAttributes : attributeList) {
					if ("POTYPE".equalsIgnoreCase(userAddlAttributes.getAttrcode())) {
						userInfoBean.setPoType(userAddlAttributes.getAttrvalue());
					} else if ("MAX_SUM_ASSUR_LIMIT".equalsIgnoreCase(userAddlAttributes.getAttrcode())) {
						userInfoBean.setMaxSumAssuredLimit(userAddlAttributes.getAttrvalue());
					} else if ("MAX_PREMIUM_LIMIT".equalsIgnoreCase(userAddlAttributes.getAttrcode())) {
						userInfoBean.setMaxPremiumLimit(userAddlAttributes.getAttrvalue());
					} else if ("PAYMENT_MODES_ALLOW".equalsIgnoreCase(userAddlAttributes.getAttrcode())) {
						paymentModes.add(userAddlAttributes.getAttrvalue());
					}
					
				}
				userInfoBean.setPaymentModes(paymentModes);
			}
			
		}catch (Exception exception) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
					"Exception occured while getting user additional attribute details : " + exception);
			throw new BFLTechnicalException(UMS_048, "Exception occured while getting user additional attribute details : " + exception);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void getEmployeeTypeAndStatusChangeReason(UserInfoBean userInfoBean, long userKey) {
		try {
			Query query = entityManager.createQuery(QueryConstants.EMP_TYPE_STATUS_CHANGE_REASON);
			query.setParameter("userKey", userKey);
			query.setParameter("isActive", new BigDecimal(1));
			List<Object[]> userDetails = query.getResultList();
			if(!userDetails.isEmpty()){
				for (Object[] objects : userDetails) {
					BigDecimal userType = (BigDecimal) objects[0];
					if(userType.compareTo(new BigDecimal(0)) == 0)
						userInfoBean.setEmployeeType(UserManagementConstants.SYSTEM_USER);
					if(userType.compareTo(new BigDecimal(1)) == 0)
						userInfoBean.setEmployeeType(UserManagementConstants.CUSTOMER);
					if(userType.compareTo(new BigDecimal(2)) == 0)
						userInfoBean.setEmployeeType(UserManagementConstants.EMPLOYEE);
					if(userType.compareTo(new BigDecimal(3)) == 0)
						userInfoBean.setEmployeeType(UserManagementConstants.THIRD_PARTY_VENDOR);
					if(userType.compareTo(new BigDecimal(4)) == 0)
						userInfoBean.setEmployeeType(UserManagementConstants.B2B_PARTNER);
					if(userType.compareTo(new BigDecimal(5)) == 0)
						userInfoBean.setEmployeeType(UserManagementConstants.CHATBOT);
					if(userType.compareTo(new BigDecimal(6)) == 0)
						userInfoBean.setEmployeeType(UserManagementConstants.PRINCIPAL_USER);
					userInfoBean.setStatusChngReason((BigDecimal) objects[1]);
				}
			}
		}catch (Exception exception) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
					"Exception occured while getting employee type and status change reason : " + exception);
			throw new BFLTechnicalException(UMS_049, "Exception occured while getting employee type and status change reason : " + exception);
		}
	}
	
}