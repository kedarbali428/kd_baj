package com.bajaj.bfsd.usermanagement.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLRepository;
import com.bajaj.bfsd.usermanagement.bean.FacebookProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserEmail;
import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;
import com.bajaj.bfsd.usermanagement.dao.UserProfileDao;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserSocialProfileFacebook;
import com.bajaj.bfsd.usermanagement.util.UserManagementUtility;
import com.bfl.common.exceptions.BFLBusinessException;

@Repository("facebook")
public class FacebookDaoImpl extends BFLRepository implements UserProfileDao {

	private static final String THIS_CLASS = FacebookDaoImpl.class.getName();

	@Autowired
    private BFLLoggerUtil logger;
	
	@Autowired
	EntityManager entityManager;
	
	@Autowired
	private Environment env;
	
	@Override
	public void saveProfile(UserProfileBean profileBean, long userKey, String profileResponse) {
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfile - Facebook - started");
		
		FacebookProfileBean facebookProfileBean = (FacebookProfileBean)profileBean;
		
		Query query = entityManager
					.createNativeQuery("delete from USER_SOCIAL_PROFILE_FACEBOOK where userkey = :userKey");
		
		query.setParameter("userKey", userKey);
		query.executeUpdate();
		
		UserSocialProfileFacebook facebookEntity = new UserSocialProfileFacebook();
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(userKey);
		
		facebookEntity.setBfsdUser(bfsdUser);
		facebookEntity.setFirstname(facebookProfileBean.getFirstName());
		facebookEntity.setMiddlename(facebookProfileBean.getMiddleName());
		facebookEntity.setLastname(facebookProfileBean.getLastName());
		facebookEntity.setGender(facebookProfileBean.getGender());
		facebookEntity.setDob(facebookProfileBean.getDob());
		facebookEntity.setEmailid(facebookProfileBean.getEmail());
		facebookEntity.setEmployeenum(facebookProfileBean.getEmployeeNum());
		facebookEntity.setHometown(facebookProfileBean.getHometown());
		facebookEntity.setProfilelink(facebookProfileBean.getProfileLink());
		facebookEntity.setProfileupdatedtime(facebookProfileBean.getProfileUpdateTime());
		facebookEntity.setProfileid(facebookProfileBean.getProfileId());
		facebookEntity.setRelationshipstatus(facebookProfileBean.getRelationShipStatus());
		facebookEntity.setIsverified(facebookProfileBean.isVerified() ? (byte)1 : 0);
		facebookEntity.setAgerangemin(facebookProfileBean.getAgeRangeMin());
		facebookEntity.setAgerangemax(facebookProfileBean.getAgeRangeMax());
		facebookEntity.setResponsedoc(profileResponse);
		facebookEntity.setLstupdateby(String.valueOf(userKey));
		facebookEntity.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
		
		entityManager.persist(facebookEntity);
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfile - Facebook - complted");

	}

	@Override
	public UserProfileBean getUserProfile(long userKey) {
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "getUserProfile - Facebook - started");
		
		FacebookProfileBean facebookProfileBean;
		UserSocialProfileFacebook facebookEntity;
		
		Query query = entityManager
					.createQuery("from UserSocialProfileFacebook where bfsdUser.userkey = :userKey");
		
		query.setParameter("userKey", userKey);
		
		try {
			facebookEntity = (UserSocialProfileFacebook) query.getSingleResult();
		}
		catch (NoResultException ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "getUserProfile - Facebook - No record found for the user - "+userKey+
						"\n Exception - "+ex);
			return new FacebookProfileBean();
		}
		catch (NonUniqueResultException ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "getUserProfile - Facebook - Multiple records found for the user - "+userKey+
						"\n Exception - "+ex);
			throw new BFLBusinessException("UMS-013", env.getProperty("UMS-013"));
		}
		
		facebookProfileBean = new FacebookProfileBean();
		
		if(facebookEntity != null){
			facebookProfileBean.setProfileId(facebookEntity.getProfileid());
			facebookProfileBean.setFirstName(facebookEntity.getFirstname());
			facebookProfileBean.setMiddleName(facebookEntity.getMiddlename());
			facebookProfileBean.setLastName(facebookEntity.getLastname());
			facebookProfileBean.setEmail(facebookEntity.getEmailid());
			facebookProfileBean.setProfileJson(facebookEntity.getResponsedoc());
			
			List<UserEmail> userEmails = new ArrayList<>(1);
			UserEmail primaryEmail = new UserEmail();
			primaryEmail.setEmailAddress(facebookEntity.getEmailid());
			primaryEmail.setType("PERSON1");
			userEmails.add(primaryEmail);
			
			facebookProfileBean.setEmailDetails(userEmails);
		}
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "getUserProfile - Facebook - completed");
		
		return facebookProfileBean;
	}

}
