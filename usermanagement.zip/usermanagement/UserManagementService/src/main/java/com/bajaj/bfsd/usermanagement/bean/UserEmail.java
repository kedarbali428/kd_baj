package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;

public class UserEmail implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8680207245265248402L;
	private String emailAddress;
	private String type;
	private short isVerified;

	public UserEmail(){
		this.isVerified = 1;
	}
	
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public short getIsVerified() {
		return isVerified;
	}

	public void setIsVerified(short isVerified) {
		this.isVerified = isVerified;
	}
}
