package com.bajaj.bfsd.usermanagement.service;

import java.util.List;

import com.bajaj.bfsd.usermanagement.bean.BusinessVerticalBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoBean;

public interface UserManagementAttributeService {
	UserInfoBean getUserDetailsByUserKey(long userKey);
	
	List<BusinessVerticalBean> getBusinessVerticalAndPOTypes();
}