package com.bajaj.bfsd.usermanagement.bean;

public class UserLoginAccountRequest {
	String loginId;
	String pwd;
	short userType;
	short loginType;
	String dateOfBirth;
	
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public short getUserType() {
		return userType;
	}
	public void setUserType(short userType) {
		this.userType = userType;
	}
	public short getLoginType() {
		return loginType;
	}
	public void setLoginType(short loginType) {
		this.loginType = loginType;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	

}
