package com.bajaj.bfsd.usermanagement.deserializer;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.bajaj.bfsd.usermanagement.bean.AadharProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserAddress;
import com.bajaj.bfsd.usermanagement.bean.UserEmail;
import com.bajaj.bfsd.usermanagement.bean.UserPhone;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

public class AadharResponseDeserializer  extends JsonDeserializer<AadharProfileBean>{

	@Override
	public AadharProfileBean deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException{
		
		AadharProfileBean aadharBean = new AadharProfileBean();  
		
		JsonNode rootNode = jp.getCodec().readTree(jp);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		aadharBean.setFirstName(rootNode.get("firstName").asText());
		aadharBean.setMiddleName(!"null".equals(rootNode.get("middleName").asText())?rootNode.get("middleName").asText():null);
		aadharBean.setLastName(rootNode.get("lastName").asText());
		try {
			aadharBean.setDob(!"null".equals(rootNode.get("dateOfBirth").asText())?dateFormat.parse(rootNode.get("dateOfBirth").asText()):null);
		} catch (ParseException e) {
			//Nothing will happen
		}
		aadharBean.setProfileId(rootNode.get("aadhaarNumber").asText());
		aadharBean.setAadharNumber(rootNode.get("aadhaarNumber").asText());
		
		Iterable<JsonNode> emailDetails = rootNode.get("emailDetails");		
		if(emailDetails != null){
			List<UserEmail> emails = new ArrayList<>();
			UserEmail email;
			for(JsonNode emaildetail : emailDetails){
				email = new UserEmail();
				if(emaildetail.get("emailAddress")==null)
					continue;
				email.setEmailAddress(emaildetail.get("emailAddress").asText());
				email.setType(emaildetail.get("type").asText());
				emails.add(email);
			}
			
			aadharBean.setEmailDetails(emails);
		}
		
		Iterable<JsonNode> addressDetails = rootNode.get("addressDetails");		
		if(addressDetails != null){
			List<UserAddress> addresses = new ArrayList<>();
			UserAddress address;
			for(JsonNode addressDetail : addressDetails){
				address = new UserAddress();
				address.setAddrLine1(!"null".equals(addressDetail.get("line1").asText())?addressDetail.get("line1").asText():null);
				address.setAddrLine2(!"null".equals(addressDetail.get("line2").asText())?addressDetail.get("line2").asText():null);
				address.setAddrType(addressDetail.get("type").asText());
				address.setCity(addressDetail.get("city").asText());
				address.setCountry(addressDetail.get("country").asText());
				address.setPin(addressDetail.get("pinCode").asText());
				address.setState(!"null".equals(addressDetail.get("state").asText())?addressDetail.get("state").asText():null);
				
				addresses.add(address);
			}
			
			aadharBean.setAddressDetails(addresses);
		}
		
		Iterable<JsonNode> phoneDetails = rootNode.get("phoneNumberDetails");		
		if(phoneDetails != null){
			UserPhone phone;
			List<UserPhone> phones = new ArrayList<>();
			for(JsonNode phoneDetail : phoneDetails){
				phone = new UserPhone();
				phone.setAreaCode(phoneDetail.get("areaCode")!=null?phoneDetail.get("areaCode").asLong():null);
				phone.setCountryCode(phoneDetail.get("countryCode")!=null?phoneDetail.get("countryCode").asLong():null);
				phone.setPhnNumber(phoneDetail.get("number").asLong());
				phone.setPhnType(phoneDetail.get("type").asText());
				phones.add(phone);
			}
			
			aadharBean.setPhoneNumberDetails(phones);
		}

		return aadharBean;
	}

}
