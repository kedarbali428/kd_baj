package com.bajaj.openmarkets.usermanagement.bean;

public class UserRequest {

	private String mobile;
	private String dateOfBirth;
	private short userType;
	private Long applicationKey;
	private Long applicantKey;

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public short getUserType() {
		return userType;
	}

	public void setUserType(short userType) {
		this.userType = userType;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	@Override
	public String toString() {
		return "UserRequest [mobile=" + mobile + ", dateOfBirth=" + dateOfBirth + ", userType=" + userType
				+ ", applicationKey=" + applicationKey + ", applicantKey=" + applicantKey + "]";
	}

}
