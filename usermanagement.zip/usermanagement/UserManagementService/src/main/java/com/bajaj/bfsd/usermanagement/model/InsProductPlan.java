package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the INS_PRODUCT_PLANS database table.
 * 
 */
@Entity
@Table(name="INS_PRODUCT_PLANS")
//@NamedQuery(name="InsProductPlan.findAll", query="SELECT i FROM InsProductPlan i")
public class InsProductPlan implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long insprodplankey;

	private BigDecimal freelockperiod;

	private String insplancode;

	private String insplandesc;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal nomineerequired;

	private String remarks;

	//bi-directional many-to-one association to InsProductType
	@ManyToOne
	@JoinColumn(name="INSPRODTYPEKEY")
	private InsProductType insProductType;

	//bi-directional many-to-one association to InsProvider
	@ManyToOne
	@JoinColumn(name="INSPROVIDERKEY")
	private InsProvider insProvider;

	public InsProductPlan() {
	}

	public long getInsprodplankey() {
		return this.insprodplankey;
	}

	public void setInsprodplankey(long insprodplankey) {
		this.insprodplankey = insprodplankey;
	}

	public BigDecimal getFreelockperiod() {
		return this.freelockperiod;
	}

	public void setFreelockperiod(BigDecimal freelockperiod) {
		this.freelockperiod = freelockperiod;
	}

	public String getInsplancode() {
		return this.insplancode;
	}

	public void setInsplancode(String insplancode) {
		this.insplancode = insplancode;
	}

	public String getInsplandesc() {
		return this.insplandesc;
	}

	public void setInsplandesc(String insplandesc) {
		this.insplandesc = insplandesc;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getNomineerequired() {
		return this.nomineerequired;
	}

	public void setNomineerequired(BigDecimal nomineerequired) {
		this.nomineerequired = nomineerequired;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public InsProductType getInsProductType() {
		return this.insProductType;
	}

	public void setInsProductType(InsProductType insProductType) {
		this.insProductType = insProductType;
	}

	public InsProvider getInsProvider() {
		return this.insProvider;
	}

	public void setInsProvider(InsProvider insProvider) {
		this.insProvider = insProvider;
	}


}