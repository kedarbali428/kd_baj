package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the APP_CONTACT_AUTH_REQUEST database table.
 * 
 */
@Entity
@Table(name="APP_CONTACT_AUTH_REQUEST")
//@NamedQuery(name="AppContactAuthRequest.findAll", query="SELECT a FROM AppContactAuthRequest a")
public class AppContactAuthRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long appconauthreqkey;

	private BigDecimal acrauthstatus;

	private String acrauthtoken;

	private BigDecimal acrcontacttype;

	private String acremailid;

	private BigDecimal acrisactive;

	private String acrlstupdateby;

	private Timestamp acrlstupdatedt;

	private String acrmobilenum;

	private Timestamp acrreqdt;

	private BigDecimal acrreqsendmode;

	private BigDecimal acrresendreqflg;

	private String acrsrcbrowser;

	private String acrsrcdeviceid;

	private String acrsrcipadd;

	private BigDecimal acrsrclat;

	private BigDecimal acrsrclong;

	private Timestamp acrtokenexpdt;

	private Timestamp emailbouncedt;

	private BigDecimal emailbounceflg;

	private String emailmessageid;

	//bi-directional many-to-one association to AppContactAuthValidation
	@OneToMany(mappedBy="appContactAuthRequest")
	private List<AppContactAuthValidation> appContactAuthValidations;

	//bi-directional many-to-one association to ApplicationApplicant
	@ManyToOne
	@JoinColumn(name="APPAPLTKEY")
	private ApplicationApplicant applicationApplicant;

	public AppContactAuthRequest() {
	}

	public long getAppconauthreqkey() {
		return this.appconauthreqkey;
	}

	public void setAppconauthreqkey(long appconauthreqkey) {
		this.appconauthreqkey = appconauthreqkey;
	}

	public BigDecimal getAcrauthstatus() {
		return this.acrauthstatus;
	}

	public void setAcrauthstatus(BigDecimal acrauthstatus) {
		this.acrauthstatus = acrauthstatus;
	}

	public String getAcrauthtoken() {
		return this.acrauthtoken;
	}

	public void setAcrauthtoken(String acrauthtoken) {
		this.acrauthtoken = acrauthtoken;
	}

	public BigDecimal getAcrcontacttype() {
		return this.acrcontacttype;
	}

	public void setAcrcontacttype(BigDecimal acrcontacttype) {
		this.acrcontacttype = acrcontacttype;
	}

	public String getAcremailid() {
		return this.acremailid;
	}

	public void setAcremailid(String acremailid) {
		this.acremailid = acremailid;
	}

	public BigDecimal getAcrisactive() {
		return this.acrisactive;
	}

	public void setAcrisactive(BigDecimal acrisactive) {
		this.acrisactive = acrisactive;
	}

	public String getAcrlstupdateby() {
		return this.acrlstupdateby;
	}

	public void setAcrlstupdateby(String acrlstupdateby) {
		this.acrlstupdateby = acrlstupdateby;
	}

	public Timestamp getAcrlstupdatedt() {
		return this.acrlstupdatedt;
	}

	public void setAcrlstupdatedt(Timestamp acrlstupdatedt) {
		this.acrlstupdatedt = acrlstupdatedt;
	}

	public String getAcrmobilenum() {
		return this.acrmobilenum;
	}

	public void setAcrmobilenum(String acrmobilenum) {
		this.acrmobilenum = acrmobilenum;
	}

	public Timestamp getAcrreqdt() {
		return this.acrreqdt;
	}

	public void setAcrreqdt(Timestamp acrreqdt) {
		this.acrreqdt = acrreqdt;
	}

	public BigDecimal getAcrreqsendmode() {
		return this.acrreqsendmode;
	}

	public void setAcrreqsendmode(BigDecimal acrreqsendmode) {
		this.acrreqsendmode = acrreqsendmode;
	}

	public BigDecimal getAcrresendreqflg() {
		return this.acrresendreqflg;
	}

	public void setAcrresendreqflg(BigDecimal acrresendreqflg) {
		this.acrresendreqflg = acrresendreqflg;
	}

	public String getAcrsrcbrowser() {
		return this.acrsrcbrowser;
	}

	public void setAcrsrcbrowser(String acrsrcbrowser) {
		this.acrsrcbrowser = acrsrcbrowser;
	}

	public String getAcrsrcdeviceid() {
		return this.acrsrcdeviceid;
	}

	public void setAcrsrcdeviceid(String acrsrcdeviceid) {
		this.acrsrcdeviceid = acrsrcdeviceid;
	}

	public String getAcrsrcipadd() {
		return this.acrsrcipadd;
	}

	public void setAcrsrcipadd(String acrsrcipadd) {
		this.acrsrcipadd = acrsrcipadd;
	}

	public BigDecimal getAcrsrclat() {
		return this.acrsrclat;
	}

	public void setAcrsrclat(BigDecimal acrsrclat) {
		this.acrsrclat = acrsrclat;
	}

	public BigDecimal getAcrsrclong() {
		return this.acrsrclong;
	}

	public void setAcrsrclong(BigDecimal acrsrclong) {
		this.acrsrclong = acrsrclong;
	}

	public Timestamp getAcrtokenexpdt() {
		return this.acrtokenexpdt;
	}

	public void setAcrtokenexpdt(Timestamp acrtokenexpdt) {
		this.acrtokenexpdt = acrtokenexpdt;
	}

	public Timestamp getEmailbouncedt() {
		return this.emailbouncedt;
	}

	public void setEmailbouncedt(Timestamp emailbouncedt) {
		this.emailbouncedt = emailbouncedt;
	}

	public BigDecimal getEmailbounceflg() {
		return this.emailbounceflg;
	}

	public void setEmailbounceflg(BigDecimal emailbounceflg) {
		this.emailbounceflg = emailbounceflg;
	}

	public String getEmailmessageid() {
		return this.emailmessageid;
	}

	public void setEmailmessageid(String emailmessageid) {
		this.emailmessageid = emailmessageid;
	}

	public List<AppContactAuthValidation> getAppContactAuthValidations() {
		return this.appContactAuthValidations;
	}

	public void setAppContactAuthValidations(List<AppContactAuthValidation> appContactAuthValidations) {
		this.appContactAuthValidations = appContactAuthValidations;
	}

	public AppContactAuthValidation addAppContactAuthValidation(AppContactAuthValidation appContactAuthValidation) {
		getAppContactAuthValidations().add(appContactAuthValidation);
		appContactAuthValidation.setAppContactAuthRequest(this);

		return appContactAuthValidation;
	}

	public AppContactAuthValidation removeAppContactAuthValidation(AppContactAuthValidation appContactAuthValidation) {
		getAppContactAuthValidations().remove(appContactAuthValidation);
		appContactAuthValidation.setAppContactAuthRequest(null);

		return appContactAuthValidation;
	}

	public ApplicationApplicant getApplicationApplicant() {
		return this.applicationApplicant;
	}

	public void setApplicationApplicant(ApplicationApplicant applicationApplicant) {
		this.applicationApplicant = applicationApplicant;
	}

}