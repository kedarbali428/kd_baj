package com.bajaj.openmarkets.usermanagement.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.openmarkets.usermanagement.bean.AuthorizationCodesRequest;
import com.bajaj.openmarkets.usermanagement.bean.AuthorizationCodesResponse;
import com.bajaj.openmarkets.usermanagement.service.OMUserAuthorizationService;
import com.bfl.common.exceptions.BFLHttpException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class OMUserAuthorizationController extends BFLController {
	
	private static final String CLASS_NAME = OMUserAuthorizationController.class.getCanonicalName();
	
	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private OMUserAuthorizationService federatedAuthService;

	@ApiOperation(value = "Om User Autorization API", notes = "Om User Autorization API - Federrated SSO", httpMethod = "POST", response = ResponseBean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseBean.class),
			@ApiResponse(code = 400, message = "Validations Failed - Invalid request due to missing mandatory fields", response = ResponseBean.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Request Processing Failed – Unknown system issue", response = ErrorBean.class) })
	@PostMapping(value = "${api.usermanagement.authorizationcodes.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> federatedAuthentication(@Valid @RequestBody AuthorizationCodesRequest authorizationRequest, BindingResult bindingResult,
			@RequestHeader String authtoken) {
		if(bindingResult.hasErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid request: "+authorizationRequest);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "## Federated Authentication API started ##");
		AuthorizationCodesResponse federatedAuthenticationToken = federatedAuthService.getAuthorizationTokenCode(authorizationRequest, authtoken);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "## Federated Authentication API ended ##");
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(federatedAuthenticationToken);
		responseBean.setStatus(StatusCode.SUCCESS);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
}
