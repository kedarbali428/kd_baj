package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the APP_CONTACT_AUTH_VALIDATION database table.
 * 
 */
@Entity
@Table(name="APP_CONTACT_AUTH_VALIDATION")
//@NamedQuery(name="AppContactAuthValidation.findAll", query="SELECT a FROM AppContactAuthValidation a")
public class AppContactAuthValidation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long appconauthvalidationkey;

	private BigDecimal acvisactive;

	private String acvlstupdateby;

	private Timestamp acvlstupdatedt;

	private String acvremarks;

	private String acvsrcbrowser;

	private String acvsrcdeviceid;

	private String acvsrcipadd;

	private BigDecimal acvsrclat;

	private BigDecimal acvsrclong;

	private String acvtoken;

	private Timestamp acvvalidationdt;

	private BigDecimal acvvalidationsts;

	//bi-directional many-to-one association to AppContactAuthRequest
	@ManyToOne
	@JoinColumn(name="APPCONAUTHREQKEY")
	private AppContactAuthRequest appContactAuthRequest;

	public AppContactAuthValidation() {
	}

	public long getAppconauthvalidationkey() {
		return this.appconauthvalidationkey;
	}

	public void setAppconauthvalidationkey(long appconauthvalidationkey) {
		this.appconauthvalidationkey = appconauthvalidationkey;
	}

	public BigDecimal getAcvisactive() {
		return this.acvisactive;
	}

	public void setAcvisactive(BigDecimal acvisactive) {
		this.acvisactive = acvisactive;
	}

	public String getAcvlstupdateby() {
		return this.acvlstupdateby;
	}

	public void setAcvlstupdateby(String acvlstupdateby) {
		this.acvlstupdateby = acvlstupdateby;
	}

	public Timestamp getAcvlstupdatedt() {
		return this.acvlstupdatedt;
	}

	public void setAcvlstupdatedt(Timestamp acvlstupdatedt) {
		this.acvlstupdatedt = acvlstupdatedt;
	}

	public String getAcvremarks() {
		return this.acvremarks;
	}

	public void setAcvremarks(String acvremarks) {
		this.acvremarks = acvremarks;
	}

	public String getAcvsrcbrowser() {
		return this.acvsrcbrowser;
	}

	public void setAcvsrcbrowser(String acvsrcbrowser) {
		this.acvsrcbrowser = acvsrcbrowser;
	}

	public String getAcvsrcdeviceid() {
		return this.acvsrcdeviceid;
	}

	public void setAcvsrcdeviceid(String acvsrcdeviceid) {
		this.acvsrcdeviceid = acvsrcdeviceid;
	}

	public String getAcvsrcipadd() {
		return this.acvsrcipadd;
	}

	public void setAcvsrcipadd(String acvsrcipadd) {
		this.acvsrcipadd = acvsrcipadd;
	}

	public BigDecimal getAcvsrclat() {
		return this.acvsrclat;
	}

	public void setAcvsrclat(BigDecimal acvsrclat) {
		this.acvsrclat = acvsrclat;
	}

	public BigDecimal getAcvsrclong() {
		return this.acvsrclong;
	}

	public void setAcvsrclong(BigDecimal acvsrclong) {
		this.acvsrclong = acvsrclong;
	}

	public String getAcvtoken() {
		return this.acvtoken;
	}

	public void setAcvtoken(String acvtoken) {
		this.acvtoken = acvtoken;
	}

	public Timestamp getAcvvalidationdt() {
		return this.acvvalidationdt;
	}

	public void setAcvvalidationdt(Timestamp acvvalidationdt) {
		this.acvvalidationdt = acvvalidationdt;
	}

	public BigDecimal getAcvvalidationsts() {
		return this.acvvalidationsts;
	}

	public void setAcvvalidationsts(BigDecimal acvvalidationsts) {
		this.acvvalidationsts = acvvalidationsts;
	}

	public AppContactAuthRequest getAppContactAuthRequest() {
		return this.appContactAuthRequest;
	}

	public void setAppContactAuthRequest(AppContactAuthRequest appContactAuthRequest) {
		this.appContactAuthRequest = appContactAuthRequest;
	}

}