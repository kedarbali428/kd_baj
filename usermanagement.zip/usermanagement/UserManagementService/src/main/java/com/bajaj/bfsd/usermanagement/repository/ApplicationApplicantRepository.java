package com.bajaj.bfsd.usermanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.usermanagement.model.ApplicationApplicant;


@Repository
public interface ApplicationApplicantRepository extends JpaRepository<ApplicationApplicant, Long>{

	@Query("from ApplicationApplicant where applicant.apltisactive=1 and applicant.applicantkey=?1"
		+ " and appapltisactive=1 and applicanttype = 1")
		public List<ApplicationApplicant> findByApplicant(Long applicantkey);

}