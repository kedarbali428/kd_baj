package com.bajaj.bfsd.usermanagement.controller;

import static com.bajaj.bfsd.common.BFLLoggerComponent.CONTROLLER;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.CNTR_1;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.CNTR_2;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.CNTR_3;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.CNTR_4;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.CNTR_5;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.CNTR_6;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import javax.enterprise.context.RequestScoped;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerHeader;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterRequest;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterResponse;
import com.bajaj.bfsd.usermanagement.bean.ChangePasswordRequest;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.EmailUpdateRequest;
import com.bajaj.bfsd.usermanagement.bean.EmployeeRoleDetails;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.TokenResponse;
import com.bajaj.bfsd.usermanagement.bean.UICredentialsResponse;
import com.bajaj.bfsd.usermanagement.bean.User;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserDetailBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountResponse;
import com.bajaj.bfsd.usermanagement.bean.UserMappingDeleteResponseBean;
import com.bajaj.bfsd.usermanagement.bean.UserMappingRequest;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.bean.UserVendorProfileBean;
import com.bajaj.bfsd.usermanagement.beanmapper.BeanMapper;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.ProductMaster;
import com.bajaj.bfsd.usermanagement.model.UserProfileEntity;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataPluginMapper;
import com.bajaj.bfsd.usermanagement.service.UserManagementService;
import com.bajaj.bfsd.usermanagement.service.UserMgmtProdService;
import com.bajaj.bfsd.usermanagement.service.impl.UserManagementServiceImpl.AsyncClass;
import com.bajaj.bfsd.usermanagement.service.impl.UserProfileServiceImpl;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.bfsd.usermanagement.util.UserManagementUtility;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Strings;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
public class UserManagementController extends BFLController {

	private static final String THIS_CLASS = UserManagementController.class.getCanonicalName();

	public static final String UMS_012 = "UMS-012";

	@Autowired
	UserProfileBean upb;

	@Autowired
	Environment environment;

	@Autowired
	UserManagementService userManagementService;
	
	@Autowired
	UserProfileServiceImpl userProfileServiceImpl;

	@Autowired
	BeanMapper beanMapper;

	@Autowired
	BFLLoggerUtil bflLoggerUtil;

	@Autowired
	@RequestScoped
	CustomDefaultHeaders custmHeaders;

	@Autowired
	private AsyncClass asyncClass;
	
	@Autowired
	UserMgmtProdService userMgmtProdService;
	
	@Autowired
	OMMasterDataPluginMapper omMasterDataPluginMapper;

	@ApiOperation(value = "Create User", notes = "User Management Operations", httpMethod = "POST")
	@RequestMapping(method = RequestMethod.POST, value = "${api.usermanagement.createuser.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> createUser(@Valid @RequestBody User userBean, BindingResult result,
			@RequestHeader HttpHeaders headers) {

		BfsdUser bfsdUser;

		if (result.hasErrors()) {

			throw new BFLBusinessException(result.getFieldErrors());
		}
		if (null != userBean.getUserVendorProfile()) {
			userBean.setEmployeeType(userBean.getUserVendorProfile().getEmployeeType());
		}

		if (StringUtils.isNotBlank(userBean.getEmployeeType())
				&& (userBean.getEmployeeType().equalsIgnoreCase(UserManagementConstants.VENDOR_COMPANY)
						|| userBean.getEmployeeType().equalsIgnoreCase(UserManagementConstants.VENDOR_INDIVIDUAL)
						|| userBean.getEmployeeType().equalsIgnoreCase(UserManagementConstants.PRINCIPAL_USER))
				
				) {
			bfsdUser = userManagementService.saveUserVendorProfile(userBean);
			UserVendorProfileBean userVendorProfileBean = userBean.getUserVendorProfile();
			if (bfsdUser != null && userVendorProfileBean.getVendorProfileKey() == 0
					&& userVendorProfileBean.getUserKey() == 0) {
				asyncClass.sendMailForUpdatedEmail(userVendorProfileBean.getEmailId(), custmHeaders.getCmptcorrid(),
						UserManagementConstants.VENDOR);
			}

		} else {
			bfsdUser = userManagementService.createUser(userBean);
		}
		
		long userKey=-1;
		if(bfsdUser!=null){
			userKey=bfsdUser.getUserkey();
		}
		return new ResponseEntity<>(new ResponseBean(userKey), HttpStatus.OK);
	}

	@ApiOperation(value = "Delete User", notes = "User Management Operations", httpMethod = "POST")
	@RequestMapping(method = RequestMethod.POST, value = "${api.usermanagement.deleteuser.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> deleteUser(@RequestBody UserConfigurationBean userConfig,
			@RequestHeader HttpHeaders headers) {
		int userDeleteStatus = userManagementService.deleteUser(userConfig);

		return new ResponseEntity<>(new ResponseBean(userDeleteStatus), HttpStatus.OK);
	}

	@ApiOperation(value = "Create User Mapping", notes = "User Management Operations", httpMethod = "POST")
	@RequestMapping(method = RequestMethod.POST, value = "${api.usermanagement.createusermapping.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> createUserMapping(@Valid @RequestBody UserMappingRequest userMappingBean,
			@RequestHeader HttpHeaders headers) {

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"createUserMapping - User Mgmt Service class invoked");

		userManagementService.createUserMapping(userMappingBean);

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"createUserMapping - User management Service class completed");

		return new ResponseEntity<>(new ResponseBean("SUCCESS"), HttpStatus.OK);
	}

	@ApiOperation(value = "Update User Mapping", notes = "User Management Operations", httpMethod = "PUT")
	@RequestMapping(method = RequestMethod.PUT, value = "${api.usermanagement.updateusermapping.PUT.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> updateUserMapping(@RequestBody UserMappingRequest userMappingBean,
			@RequestHeader HttpHeaders headers) {

		userManagementService.updateUserMapping(userMappingBean);

		return new ResponseEntity<>(new ResponseBean("SUCCESS"), HttpStatus.OK);
	}

	@ApiOperation(value = "Check user is exist or not", notes = "User Management Operations", httpMethod = "POST")
	@RequestMapping(method = RequestMethod.POST, value = "${api.usermanagement.getactivedirectoryuser.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getActiveDirectoryUsers(@RequestBody UserConfigurationBean userConfig,
			@RequestHeader HttpHeaders headers) {

		UserConfigurationBean userConfiguration = userManagementService.getActiveDirectoryUsers(userConfig);

		return new ResponseEntity<>(new ResponseBean(userConfiguration), HttpStatus.OK);
	}

	/**
	 * Controller method for Product mapped details
	 * 
	 * @author 416225
	 * @param employeeKey
	 * @param roleKey
	 * @param headers
	 * @return
	 */
	@ApiOperation(value = "User Details", notes = "User Management Operations", httpMethod = "GET")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.employeeroledetail.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> employeeRoleDetail(@RequestParam(value = "userkey") long employeeKey,
			@RequestParam(value = "rolekey") long roleKey, @RequestHeader HttpHeaders headers) {
		logMessage(CNTR_1);
		@SuppressWarnings("unchecked")
		List<EmployeeRoleDetails> list = userManagementService.roleMapped(employeeKey, roleKey);
		logMessage(CNTR_2);
		return new ResponseEntity<>(new ResponseBean(list), HttpStatus.OK);

	}

	@ApiOperation(value = "get the information of user", notes = "User Management Operations", httpMethod = "POST")
	@RequestMapping(method = RequestMethod.POST, value = "${api.usermanagement.getuserinformation.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserInformation(@RequestBody UserConfigurationBean userConfig,
			@RequestHeader HttpHeaders headers) {

		UserConfigurationBean userConfiguration = userManagementService.getUserInformation(userConfig,headers);

		return new ResponseEntity<>(new ResponseBean(userConfiguration), HttpStatus.OK);
	}

	@ApiOperation(value = "update the information of user", notes = "User Management Operations", httpMethod = "PUT")
	@RequestMapping(method = RequestMethod.PUT, value = "${api.usermanagement.updateuserinformation.PUT.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> updateUserInformation(@RequestBody UserInfoRequest userInfoRequest,@RequestHeader HttpHeaders headers){
		logMessage("Controller : User Profile is updation process started");
		int userUpdate = userManagementService.updateUserDetails(userInfoRequest); // added Email id  for Partner portal
		logMessage("Controller : User Profile is updation process Completed");

		return new ResponseEntity<>(new ResponseBean(userUpdate), HttpStatus.OK);
	}

	/**
	 * @Desc This is Controller method for fetching the supervisor for the
	 *       selected userrole
	 * @param bean
	 * @param headers
	 * @return ResponseEntity
	 * @throws BFLTechnicalException
	 */
	@ApiOperation(value = "Get the Supervisor for the selected user role", notes = "Get the Supervisor for the selected user role", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.getusersupervisor.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getuserSuperVisor(@RequestParam String userRole,
			@RequestHeader HttpHeaders headers) {

		List<SupervisorBean> user;
		bflLoggerUtil.setCorrelationID(custmHeaders.getCmptcorrid());
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Fetch all supervisor for the user role Service execution invoked");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"RoleManagementController : User Mgmt Service class invoked");

		user = userManagementService.getuserSuperVisor(userRole);

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"getuserSuperVisor - User management Service class completed");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Completed Fetch all supervisor for the user role Service execution invoked");
		return new ResponseEntity<>(new ResponseBean(user), HttpStatus.OK);
	}

	/**
	 * @Desc This is Controller method for fetching the supervisor LOCATION for
	 *       the selected userrole
	 * @param bean
	 * @param headers
	 * @return ResponseEntity
	 * @throws BFLTechnicalException
	 */
	@ApiOperation(value = "Get the location for the selected user role supervisor", notes = "Get the Supervisor for the selected user role supervisor location", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.getsupervisorlocation.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getSuperVisorLocations(@RequestParam String userKey,
			@RequestHeader HttpHeaders headers) {

		List<LocationBean> bflBranchList;
		bflLoggerUtil.setCorrelationID(custmHeaders.getCmptcorrid());
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Fetch all supervisor for the user role Service execution invoked");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : User Mgmt Service class invoked");

		bflBranchList = userManagementService.getSuperVisorLocations(userKey);

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"getSuperVisorLocations - User management Service class completed");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Completed getSuperVisorLocations");
		return new ResponseEntity<>(new ResponseBean(bflBranchList), HttpStatus.OK);
	}

	/**
	 * @Desc This is Controller method for fetching the supervisor channels for
	 *       the selected userrolekey
	 * @param bean
	 * @param headers
	 * @return ResponseEntity
	 * @throws BFLTechnicalException
	 */
	@ApiOperation(value = "Get the location for the selected user role supervisor", notes = "Get the Supervisor for the selected user role supervisor location", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.getsupervisorchannel.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getSuperVisorChannels(@RequestParam String userRoleKey,
			@RequestHeader HttpHeaders headers) {

		List<ChannelBean> bflChannelList;
		bflLoggerUtil.setCorrelationID(custmHeaders.getCmptcorrid());
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Fetch all getSuperVisorChannels");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"RoleManagementController : User Mgmt Service class invoked");

		bflChannelList = userManagementService.getSuperVisorChannels(userRoleKey);

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : User management Service class completed");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Completed getSuperVisorChannels");
		return new ResponseEntity<>(new ResponseBean(bflChannelList), HttpStatus.OK);
	}

	/**
	 * @Desc This is Controller method for fetching the supervisor LOCATION for
	 *       the selected userrole
	 * @param bean
	 * @param headers
	 * @return ResponseEntity
	 * @throws BFLTechnicalException
	 */
	@ApiOperation(value = "Get the location for the selected user role supervisor", notes = "Get the Supervisor for the selected user role supervisor location", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.getlocationpin.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getLocationPin(@RequestParam String locationKey,
			@RequestParam(name = "l1ProdKey", required = false) Long l1ProdKey,
			@RequestHeader HttpHeaders headers) {

		List<PinCodeBean> pinCodeList = null;
		bflLoggerUtil.setCorrelationID(custmHeaders.getCmptcorrid());
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Fetch all getLocationPin");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : User Mgmt Service class invoked");
		
		List<ProductMaster> masterProducts = userMgmtProdService.getAllMasterProducts();
		if (null != l1ProdKey) {
			Optional<ProductMaster> optMaster = masterProducts.stream()
					.filter(item -> item.getProdmastkey() == l1ProdKey).findFirst();
			if (optMaster.isPresent()) {
				ProductMaster master = optMaster.get();
				switch (master.getProdmastcode()) {
				case "OMCREDIT":
				case "OMINS":
					pinCodeList = omMasterDataPluginMapper.getLocationPinForOM(locationKey, headers);
					bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
							"createUserMapping -  OM User management Service class completed");
					break;
//				case "OMPOCKET":
//					pinCodeList = omMasterDataPluginMapper.getLocationPinForOM(locationKey, headers);
//					bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
//							"createUserMapping -  OM User management Service class completed");
//					break;
				default:
					pinCodeList = userManagementService.getLocationPin(locationKey);
					bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
							"createUserMapping - User management Service class completed");
				}
			}
		}
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : User management Service class completed");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Completed getLocationPin");
		return new ResponseEntity<>(new ResponseBean(pinCodeList), HttpStatus.OK);
	}

	private void logMessage(String message) {
		bflLoggerUtil.info(THIS_CLASS, CONTROLLER, message);
	}

	@CrossOrigin
	@ApiOperation(value = "Delete user mapping.", notes = "Delete user mapping.")
	@RequestMapping(value = "${api.usermanagement.deleteusermapping.DELETE.uri}", method = RequestMethod.DELETE)
	public ResponseEntity<ResponseBean> deleteUserMapping(@PathVariable(value = "userKey") String employeeKey,
			@PathVariable(value = "roleKey") String roleKey, @RequestHeader HttpHeaders headers) {
		validateParameters(employeeKey, roleKey);
		Long employeeId = Long.parseLong(employeeKey);
		Long roleId = Long.parseLong(roleKey);

		boolean isDeleted = userManagementService.deleteUserMapping(employeeId, roleId);
		UserMappingDeleteResponseBean result = beanMapper.mapTo(employeeId, roleId, isDeleted);
		return new ResponseEntity<>(new ResponseBean(result), HttpStatus.OK);
	}

	private void validateParameters(String employeeKey, String roleKey) {
		if (Strings.isNullOrEmpty(employeeKey) || Strings.isNullOrEmpty(roleKey)) {
			throw new BFLBusinessException("UMS-001", "Request Parameters are either empty or not valid numbers.");
		}
	}

	@CrossOrigin
	@ApiOperation(value = "Gets the secretKey for clientId", notes = "Gets the secretKey for clientId")
	@RequestMapping(value = "${api.usermanagement.getuicredentials.GET.uri}", method = RequestMethod.GET)
	public ResponseEntity<ResponseBean> getUICredentials(@PathVariable(value = "clientId") String clientId,
			@RequestHeader HttpHeaders headers) {
		bflLoggerUtil.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : getUICredentials -> clientId = " + clientId);
		UICredentialsResponse uiCredentialsResponse = userManagementService.getUICredentials(clientId);

		return new ResponseEntity<>(new ResponseBean(uiCredentialsResponse), HttpStatus.OK);
	}

	@CrossOrigin
	@ApiOperation(value = "Gets the User Login Account Details", notes = "Gets the User Login Account Details")
	@RequestMapping(value = "${api.usermanagement.getloginaccount.POST.uri}", method = RequestMethod.POST)
	public ResponseEntity<ResponseBean> getUserLoginAccount(
			@RequestBody UserLoginAccountRequest userLoginAccountRequest, @RequestHeader HttpHeaders headers) {
		bflLoggerUtil.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : getUserLoginAccount -> loginId = " + userLoginAccountRequest.getLoginId());
		//validate login id for alphanumeric
				UserManagementUtility.validateLoginID(userLoginAccountRequest.getLoginId(),bflLoggerUtil,environment);
		UserLoginAccountResponse userLoginAccountResponse = userManagementService
				.getUserLoginAccount(userLoginAccountRequest);

		return new ResponseEntity<>(new ResponseBean(userLoginAccountResponse), HttpStatus.OK);
	}

	@CrossOrigin
	@ApiOperation(value = "Gets the User Login Account Details", notes = "Gets the User Login Account Details")
	@RequestMapping(value = "${api.usermanagement.getuserid.GET.uri}", method = RequestMethod.GET)
	public ResponseEntity<ResponseBean> getUserId(@PathVariable String loginId, @RequestHeader HttpHeaders headers) {
		bflLoggerUtil.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : getUserLoginAccount -> loginId = " + loginId);
		UserLoginAccountResponse user = userManagementService.getUserId(loginId);

		return new ResponseEntity<>(new ResponseBean(user), HttpStatus.OK);
	}

	@ApiOperation(value = "Get User Roles by user key", notes = "User Management Operations: get user roles", httpMethod = "GET")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.getuserroles.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getRolesByUserKey(@RequestHeader HttpHeaders headers) {
		logMessage(CNTR_3);

		long userKey = upb.getUserid();

		UserDetailBean result = userManagementService.getRolesByUserKey(userKey);
		if (result == null) {
			throw new BFLBusinessException("UMS-011", environment.getProperty("UMS-011"));
		}
		logMessage(CNTR_4);
		return new ResponseEntity<>(new ResponseBean(result), HttpStatus.OK);

	}
	
	  @CrossOrigin
      @ApiOperation(value = "Get the List of Users based on Product, Role, Function and location",
      notes = "Get the List of Users based on Product, Role, Function and Location", httpMethod="GET")
      @RequestMapping(value = "${api.usermanagement.getlistofuser.GET.uri}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
      public ResponseEntity<ResponseBean> getListOfUsers(
                      @RequestParam(value = "pin") long pincode,
                      @RequestParam(value = "function") long function,
                      @RequestParam(value = "role") long role,
                      @RequestParam(value = "tabkey") long tabkey,
                      @RequestParam(value = "subprodkey") long subprodkey,
                      @RequestHeader HttpHeaders headers) {
   
		  List<UserName> result = userManagementService.getListOfUserName(pincode, function, role, tabkey, subprodkey);
		  logMessage(CNTR_6);
		  return new ResponseEntity<>(new ResponseBean(result), HttpStatus.OK);
      }
	  
	  @CrossOrigin
      @ApiOperation(value = "Get the User name based on Product, Role, Function and location",
      notes = "Get the User name based on Product, Role, Function and Location", httpMethod="GET")
      @RequestMapping(value = "${api.usermanagement.getuser.GET.uri}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
      public ResponseEntity<ResponseBean> getUser(
    		  		  @RequestParam(value = "applicationId") long applicationId,
                      @RequestParam(value = "pin") long pincode,
                      @RequestParam(value = "function") long function,
                      @RequestParam(value = "role") long role,
                      @RequestParam(value = "tabkey") long tabkey,
                      @RequestParam(value = "subprodkey") long subprodkey,
                      @RequestHeader HttpHeaders headers) {


          logMessage(CNTR_5);    
		  UserName result = userManagementService.getUserName(pincode, function, role, applicationId,tabkey, subprodkey);
		  logMessage(CNTR_6);
		  return new ResponseEntity<>(new ResponseBean(result), HttpStatus.OK);
      }
	  
	  @CrossOrigin
	  @ApiOperation(value = "Register a customer", notes = "Check if customer is already "
				+ "registered else register a new customer", httpMethod="POST")
      @RequestMapping(value = "${api.usermanagement.autoregister.POST.uri}", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
      public ResponseEntity<ResponseBean> autoRegister(@RequestBody AutoRegisterRequest request) {
		logMessage("autoRegister - started");

		AutoRegisterResponse response = userManagementService.autoRegister(request);

		logMessage("autoRegister - completed");

		return new ResponseEntity<>(new ResponseBean(response), HttpStatus.OK);
	}

	@CrossOrigin
	@ApiOperation(value = "Change Password", notes = "Stores hashed value of actual password", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header") })
      @RequestMapping(value = "${api.usermanagement.changepassword.PUT.uri}", method=RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
      public ResponseEntity<ResponseBean> changePassword(@Valid @RequestBody ChangePasswordRequest request, BindingResult bindingResult) {

          logMessage("changePassword - started");    
          validateRequest(bindingResult, "changePassword");
          
          long userKey = custmHeaders.getUserKey();
          
          userManagementService.changePassword(request, userKey);
          
          logMessage("changePassword - completed");
		  
		  return new ResponseEntity<>(new ResponseBean(StatusCode.SUCCESS.name()), HttpStatus.OK);
      }
	  
	  @CrossOrigin
	  @ApiOperation(value = "Merge users", notes = "Merge a new userKey with an old one", httpMethod="GET")
	  @ApiImplicitParams(value = {@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			  @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header")})
    @RequestMapping(value = "${api.usermanagement.mergeuser.GET.uri}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)

	public ResponseEntity<ResponseBean> mergeUsers(@PathVariable("oldUserKey") String oldUserKeyStr) {

		logMessage("mergeUsers - started");

		long newUserKey = custmHeaders.getUserKey();
		long oldUserKey;
		try {
			oldUserKey = Long.parseLong(oldUserKeyStr);
		} catch (NumberFormatException e) {
			bflLoggerUtil.error(THIS_CLASS, CONTROLLER, "Invalid oldUserKey - " + oldUserKeyStr);
			throw new BFLBusinessException(UMS_012, environment.getProperty(UMS_012));
		}

		validateUserKeys(newUserKey, oldUserKey);

		TokenResponse tokenResponse = userManagementService.mergeUsers(newUserKey, oldUserKey);

		logMessage("mergeUsers - completed");

		return new ResponseEntity<>(new ResponseBean(tokenResponse), HttpStatus.OK);
	}

	@CrossOrigin
	@ApiOperation(value = "Validate Loginid of customer", notes = "Check the email id of customer in the database", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header") })
	@RequestMapping(value = "${api.usermanagement.validatenewemail.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> validateNewEmail(@Valid @RequestBody EmailUpdateRequest emailUpdateRequest,
			BindingResult result) {
		bflLoggerUtil.setCorrelationID(custmHeaders.getCmptcorrid());
		validateRequest(result, "validateNewEmail");
		boolean isValid = userManagementService.validateEmail(emailUpdateRequest.getNewEmail(),
				emailUpdateRequest.getApplicantKey());
		ObjectNode node = JsonNodeFactory.instance.objectNode();
		node.put("isValid", isValid);
		return new ResponseEntity<>(new ResponseBean(node), HttpStatus.OK);
	}

	@CrossOrigin
	@ApiOperation(value = "Update Loginid and email of customer", notes = "Check the email id of customer in the database", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header") })
	@RequestMapping(value = "${api.usermanagement.savenewemail.PUT.uri}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> saveNewEmail(@Valid @RequestBody EmailUpdateRequest emailUpdateRequest,
			BindingResult result) {
		bflLoggerUtil.setCorrelationID(custmHeaders.getCmptcorrid());
		validateRequest(result, "saveNewEmail");
		userManagementService.saveEmail(emailUpdateRequest.getNewEmail(), emailUpdateRequest.getOldEmail(),
				emailUpdateRequest.getApplicantKey());
		// send mail to set password
		asyncClass.sendMailForUpdatedEmail(emailUpdateRequest.getNewEmail(), bflLoggerUtil.getCorrelationID(),
				UserManagementConstants.CUSTOMER_PORTAL);
		return new ResponseEntity<>(new ResponseBean(StatusCode.SUCCESS), HttpStatus.OK);
	}

	@ApiOperation(value = "User Base Entity", notes = "Get User Base Entity", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header") })
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.baseprofile.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserBaseEntity(@PathVariable long userKey, @RequestHeader HttpHeaders headers) {
		logMessage(CNTR_1);
		UserProfileEntity userProfileEntity = userProfileServiceImpl.loadUserProfileV2(userKey);
		logMessage(CNTR_2);
		return new ResponseEntity<>(new ResponseBean(userProfileEntity), HttpStatus.OK);

	}
	
	private void validateRequest(BindingResult bindingResult, String method) {
		if (bindingResult.hasErrors()) {
			bflLoggerUtil.error(THIS_CLASS, CONTROLLER, "validateRequest - error in field values in - " + method);
			throw new BFLBusinessException(bindingResult.getFieldErrors());
		}
	}

	private void validateUserKeys(long newUserKey, long oldUserKey) {

		if (newUserKey == 0 || oldUserKey == 0) {
			bflLoggerUtil.error(THIS_CLASS, CONTROLLER,
					"mergeUsers - Invalid userKeys - newUserKey-" + newUserKey + "-, oldUserKey-" + oldUserKey);
			throw new BFLBusinessException(UMS_012, environment.getProperty(UMS_012));
		}
	}
	
	@ApiOperation(value = "Reporting Managers", notes = "Get all Reporting Managers", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header") })
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.users.details.GET.uri}")
	@CrossOrigin
	public ResponseEntity<?> getAllReportingManagers(@PathVariable String searchcriteria, @RequestParam String name, @RequestHeader HttpHeaders headers) {
		logMessage("Inside controller's getAllReportingManagers method with searchcriteria : " + searchcriteria);	
		return new ResponseEntity<>(userManagementService.getAllReportingManagers(name), HttpStatus.OK);
	}

}