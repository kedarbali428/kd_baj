package com.bajaj.openmarkets.usermanagement.exceptions;

import org.springframework.http.HttpStatus;

import com.bajaj.bfsd.common.domain.ErrorBean;


public class OMUserManagementException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private HttpStatus code;
	private ErrorBean errorBean;
	private Object payload;

	public OMUserManagementException() {
		super();
	}

	public OMUserManagementException(HttpStatus code, ErrorBean errorBean, Object payload) {
		super(errorBean.getErrorMessage());
		this.code = code;
		this.errorBean = errorBean;
		this.payload = payload;
	}

	public OMUserManagementException(HttpStatus code, ErrorBean errorBean) {
		super(errorBean.getErrorMessage());
		this.code = code;
		this.errorBean = errorBean;
	}

	public OMUserManagementException(HttpStatus code, Object payload) {
		super();
		this.code = code;
		this.payload = payload;
	}

	public OMUserManagementException(HttpStatus code, ErrorBean errorBean, Object payload, Throwable cause) {
		super(cause);
		this.code = code;
		this.errorBean = errorBean;
		this.payload = payload;
	}

	public HttpStatus getCode() {
		return code;
	}

	public void setCode(HttpStatus code) {
		this.code = code;
	}

	public ErrorBean getErrorBean() {
		return errorBean;
	}

	public void setErrorBean(ErrorBean errorBean) {
		this.errorBean = errorBean;
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "OMUserManagementException [code=" + code + ", errorBean=" + errorBean + ", payload=" + payload + "]";
	}

}
