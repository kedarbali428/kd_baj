package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the APPLICATION_APLT_ATTRIBUTES database table.
 * 
 */
@Entity
@Table(name="APPLICATION_APLT_ATTRIBUTES")
//@NamedQuery(name="ApplicationApltAttribute.findAll", query="SELECT a FROM ApplicationApltAttribute a")
public class ApplicationApltAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long appapltattkey;

	private BigDecimal aaaisactive;

	private String aaalstupdateby;

	private Timestamp aaalstupdatedt;

	//bi-directional many-to-one association to ApplicantPhoneNumber
	@ManyToOne
	@JoinColumn(name="APLTPHNUMKEY")
	private ApplicantPhoneNumber applicantPhoneNumber;

	//bi-directional many-to-one association to ApplicationApplicant
	@ManyToOne
	@JoinColumn(name="APPAPLTKEY")
	private ApplicationApplicant applicationApplicant;

	public ApplicationApltAttribute() {
	}

	public long getAppapltattkey() {
		return this.appapltattkey;
	}

	public void setAppapltattkey(long appapltattkey) {
		this.appapltattkey = appapltattkey;
	}

	public BigDecimal getAaaisactive() {
		return this.aaaisactive;
	}

	public void setAaaisactive(BigDecimal aaaisactive) {
		this.aaaisactive = aaaisactive;
	}

	public String getAaalstupdateby() {
		return this.aaalstupdateby;
	}

	public void setAaalstupdateby(String aaalstupdateby) {
		this.aaalstupdateby = aaalstupdateby;
	}

	public Timestamp getAaalstupdatedt() {
		return this.aaalstupdatedt;
	}

	public void setAaalstupdatedt(Timestamp aaalstupdatedt) {
		this.aaalstupdatedt = aaalstupdatedt;
	}

	public ApplicantPhoneNumber getApplicantPhoneNumber() {
		return this.applicantPhoneNumber;
	}

	public void setApplicantPhoneNumber(ApplicantPhoneNumber applicantPhoneNumber) {
		this.applicantPhoneNumber = applicantPhoneNumber;
	}

	public ApplicationApplicant getApplicationApplicant() {
		return this.applicationApplicant;
	}

	public void setApplicationApplicant(ApplicationApplicant applicationApplicant) {
		this.applicationApplicant = applicationApplicant;
	}

}