package com.bajaj.openmarkets.usermanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.openmarkets.usermanagement.bean.UserRequest;
import com.bajaj.openmarkets.usermanagement.bean.UserResponse;
import com.bajaj.openmarkets.usermanagement.cache.entity.CacheAdditionalInfo;
import com.bajaj.openmarkets.usermanagement.service.OMUserManagementService;
import com.bajaj.openmarkets.usermanagement.validator.RequestValidator;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class OMUserManagementController extends BFLController {
	
	private static final String EP_SOURCE = "EP";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	OMUserManagementService omUserManagementService;

	@CrossOrigin
	@ApiOperation(value = "User Additional Profile Creation for Pseudo Customer/ Pseudo Verified Customer and fetch User Id for Actual Customer", notes = "User Additional Profile Creation for Pseudo Customer/ Pseudo Verified Customer and fetch User Id for Actual Customer")
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Returns User Id, Login Id and User Type", response = UserResponse.class), })
	@PostMapping(value = "${api.usermanagement.user.additionalprofile.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getUser(@RequestBody UserRequest userRequest) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
				"Inside getUser - start with userRequest: " + userRequest);

		if (!RequestValidator.validateUserRequest(userRequest)) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					"Not a valid request: " + userRequest);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		UserResponse userResponse = omUserManagementService.getUser(userRequest);

		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
				"Inside getUser - end with userResponse: " + userResponse);
		return new ResponseEntity<UserResponse>(userResponse, HttpStatus.CREATED);
	}

	@CrossOrigin
	@ApiOperation(value = "Fetch Additional Profile using User Id", notes = "Fetch Additional Profile using User Id")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Returns Additional Cached info", response = CacheAdditionalInfo.class), })
	@GetMapping(value = "${api.usermanagement.user.additionalprofile.GET.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getUser(@RequestParam("userId") String userId,
			@RequestParam(name = "source", required = false) String source) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
				"Inside getUser - start with userId: " + userId);
		CacheAdditionalInfo additionalInfo = new CacheAdditionalInfo();
		long userID = Long.parseLong(userId);
		if (null != source && EP_SOURCE.equalsIgnoreCase(source)) {
			additionalInfo = omUserManagementService.getUserRoleKey(userID);
		} else {
			additionalInfo = omUserManagementService.getUser(userID);
		}

		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
				"Inside getUser - end with userResponse: " + additionalInfo);

		return new ResponseEntity<CacheAdditionalInfo>(additionalInfo, HttpStatus.OK);
	}
}
