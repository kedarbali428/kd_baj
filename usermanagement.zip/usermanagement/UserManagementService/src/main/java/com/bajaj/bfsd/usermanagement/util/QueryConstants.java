package com.bajaj.bfsd.usermanagement.util;

public class QueryConstants {
	
	public static final String FETCH_LOGIN_DETAILS_WITH_LOGINID = " FROM UserLoginAccount WHERE LOGINID=:loginid";
	
	public static final String FETCH_LOGIN_USER_DETAILS_WITH_LOGINID = " FROM UserLoginAccount WHERE LOGINID=:loginid and userloginacctype=:loginAcctType and "
			+ " bfsdUser.usertype =:userType and bfsdUser.isactive=1 ";
	
	public static final String FETCH_UI_LOGIN_USER_DETAILS_WITH_LOGINID = " FROM UserLoginAccount WHERE userloginacctype=:loginAcctType and "
			+ " bfsdUser.usertype =:userType and bfsdUser.isactive=1 ";
	public static final String FETCH_LOGIN_USER_DETAILS_WITH_LOGINID_DOB ="SELECT ac.LOGINPWD,bu.USERKEY,bu.REGISTRATIONDATE,bu.USERTYPE,bu.USERBLOCKEDFLG,bu.FAILEDLOGINCOUNT,bu.LSTFAILEDLOGINDT,bu.ISACTIVE,bu.LSTUPDATEBY,bu.LSTUPDATEDT,bu.PARENTUSERKEY From USER_LOGIN_ACCOUNTS ac ,BFSD_USERS bu, USER_PROFILES up where ac.USERKEY = bu.USERKEY and bu.USERKEY = up.USERKEY and ac.LOGINID=:loginid and ac.USERLOGINACCTYPE=:loginAcctType and bu.ISACTIVE=1 and bu.USERTYPE=:userType and  trunc(up.DATEOFBIRTH)=TO_DATE(:dateOfBirth,'dd/mm/yyyy')";

	public static final String FETCH_USERS_NAMES =" select Distinct up.FIRSTNAME, up.MIDDLENAME, up.LASTNAME, up.USERKEY, brm.ROLEKEY, ur.USERROLEKEY from USER_PROFILES up "
			+" inner join USER_ROLES ur on up.USERKEY = ur.USERKEY"
			+" inner join ORGSYSADM.USER_ROLE_PRODUCT urp on urp.userrolekey = ur.userrolekey"
			+" inner join USER_ROLE_LOCATIONS url on url.USERPRODKEY = urp.USERPRODKEY"
			+" inner join BFL_BRANCH_SERVICES bbs on bbs.BFLBRANCHKEY = url.BFLBRANCHKEY"
			+" inner join PIN_CODE_MASTER pcm on bbs.citykey = pcm.citykey"
			+" inner join BFSD_ROLE_MASTER brm  on ur.rolekey = brm.rolekey" 
			+" inner join BFSD_FUNCTION_ROLES bfr on brm.rolekey = bfr.rolekey" 
			+" inner join BFSD_FUNCTIONS bf on bfr.functionkey = bf.functionkey"
			+" where pcm.PINCODE=:pincode "
			+" and brm.ROLEKEY= :rolekey "
			+" and bf.FUNCTIONKEY=:functionKey"
			+" and ur.ISACTIVE=1 "
			+" and up.ISACTIVE=1 "
			+" and url.ISACTIVE=1 "
			+" and urp.isactive=1 "
			+" and urp.SUBPRODKEY=:subprodkey "
			+" and urp.PRODMASTKEY = (select distinct htp.prodmastkey from"
			+" HEADER_TAB_PRODUCTS htp where htp.tabkey=:tabkey and htp.isactive=1)";

	public static final String QRY_GET_USER_PROFILE_BY_USERKEY = "select up from UserProfile up where up.bfsdUser.userkey =:userKey and up.isactive=1";
	public static final String QRY_GET_USER_FIRST_AND_LAST_NAME = " SELECT "
			+ " p.firstname, p.lastname, p.companyname, p.emailid, p.associationtype FROM bfsd_users u , user_profiles p  "
			+ " where u.userkey = p.userkey and u.userkey = :userKey "
			+ " and u.isactive=1 ";
	
	public static final String QRY_GET_USER_VENDOR_PROFILE_BY_USER_VENDOR_PROFILE_KEY = "select up from UserProfile up where up.userprofilekey =:vendorProfileKey ";
	public static final String QRY_GET_USER_VENDOR_PROFILE_BY_USER_KEY = "select up from UserProfile up where up.bfsdUser.userkey =:userKey ";
	public static final String QRY_GET_USER_VENDOR_PROFILE_BY_EMAIL_ID = "select up from UserProfile up where up.emailid =:emailId and isactive=1 ";
	public static final String QRY_GET_USER_ROLE_PROD="select urp from UserRoleProductL3 urp where urp.userRole.userrolekey= :userRoleKey and urp.subprodkey= :subProdKey and urp.prodmastkey= :prodMastKey and urp.isactive=1 ";
	public static final String QRY_PARAM_EMAIL_ID= "emailId";
	public static final String QRY_PARAM_VENDOR_PROFILE_KEY= "vendorProfileKey";
	public static final String QRY_PARAM_USER_ROLE_KEY= "userRoleKey";
	public static final String QRY_PARAM_SUB_PROD_KEY= "subProdKey";
	public static final String QRY_PARAM_PROD_MAST_KEY= "prodMastKey";
	public static final String QRY_GET_UTM_SOURCE="select usm from UtmSourceChannelMaster usm where usm.utmsrcchnmastkey in (:utmsrcchnmastkey) and usm.isactive=1 ";
	public static final String QRY_PARAM_UTM_SOURCE= "utmsrcchnmastkey";
	
	/**
	 * This query selects role of a user which belongs to a function
	 */
	public static final String QRY_GET_USER_ROLES_BY_USERKEY = "select distinct ur from UserRole ur, BfsdFunctionRole br  where ur.bfsduser.userkey =:userKey "
			+ "and ur.bfsdRoleMaster.rolekey= br.bfsdRoleMaster.rolekey "
			+ "and ur.isactive=1";
	public static final String QRY_GET_USER_ROLE_PROD_BY_USERKEY = "select urp.USERPRODKEY, brm.ROLEKEY,brm.ROLECD,brm.ROLENAME,lp.LNPRODKEY,lp.LNPRODCODE,lp.LNPRODDESC from USER_ROLE_PRODUCT urp  "
			+ " inner join USER_ROLES ur on ur.USERROLEKEY=urp.USERROLEKEY  "
			+ " inner join BFSD_USERS bu on bu.USERKEY=ur.USERKEY  "
			+ " inner join BFSD_ROLE_MASTER brm on brm.ROLEKEY=ur.ROLEKEY  "
			+ " inner join LOAN_PRODUCTS lp on lp.LNPRODKEY=urp.SUBPRODKEY  "
			+ " inner join PRODUCT_CATEGORIES cp on cp.PRODCATKEY=lp.PRODCATKEY "
			+ " inner join PRODUCT_MASTER pm on pm.PRODMASTKEY=cp.PRODMASTKEY "
			+ " where ur.ISACTIVE=1 and urp.ISACTIVE=1 and brm.ISACTIVE=1 and lp.LNPRODISACTIVE=1 and   bu.USERKEY=:userKey and pm.PRODMASTCODE = 'LOAN' "
			+ " UNION  "
			+ " select urp.USERPRODKEY, brm.ROLEKEY,brm.ROLECD,brm.ROLENAME,ipt.INSPRODTYPEKEY,ipt.INSPRODTYPECODE,ipt.INSPRODTYPEDESC from USER_ROLE_PRODUCT urp  "
			+ " inner join USER_ROLES ur on ur.USERROLEKEY=urp.USERROLEKEY  "
			+ " inner join BFSD_USERS bu on bu.USERKEY=ur.USERKEY  "
			+ " inner join BFSD_ROLE_MASTER brm on brm.ROLEKEY=ur.ROLEKEY  "
			+ " inner join INS_PRODUCT_TYPES ipt on ipt.INSPRODTYPEKEY=urp.SUBPRODKEY  "
			+ " inner join PRODUCT_CATEGORIES cp on cp.PRODCATKEY=ipt.PRODCATKEY "
			+ " inner join PRODUCT_MASTER pm on pm.PRODMASTKEY=urp.PRODMASTKEY "
			+ " where ur.ISACTIVE=1 and urp.ISACTIVE=1 and brm.ISACTIVE=1 and ipt.ISACTIVE=1 and   bu.USERKEY=:userKey and pm.PRODMASTCODE = 'INSURANCE' "
			+ " UNION  "
			+" SELECT urp.USERPRODKEY, brm.ROLEKEY, brm.ROLECD, brm.ROLENAME, vpt.VASPRODTYPEKEY, vpt.VPTPRODTYPECODE, vpt.VPTPRODTYPEDESC " + 
			" FROM USER_ROLE_PRODUCT urp INNER JOIN USER_ROLES ur ON ur.USERROLEKEY=urp.USERROLEKEY " + 
			" INNER JOIN BFSD_USERS bu ON bu.USERKEY=ur.USERKEY INNER JOIN BFSD_ROLE_MASTER brm ON brm.ROLEKEY=ur.ROLEKEY " + 
			" INNER JOIN VAS_PRODUCT_TYPES vpt ON vpt.VASPRODTYPEKEY=urp.SUBPRODKEY INNER JOIN PRODUCT_CATEGORIES cp ON cp.PRODCATKEY=vpt.PRODCATKEY " + 
			" INNER JOIN PRODUCT_MASTER pm ON pm.PRODMASTKEY =urp.PRODMASTKEY " + 
			" WHERE ur.ISACTIVE =1 AND urp.ISACTIVE =1 AND brm.ISACTIVE =1 AND vpt.VPTISACTIVE =1 AND bu.USERKEY = :userKey AND pm.PRODMASTCODE = 'VAS' "
			+ " UNION  "
			+" SELECT urp.USERPRODKEY, brm.ROLEKEY,brm.ROLECD,brm.ROLENAME,ip.IVPRODKEY,ip.IVPRODCODE,ip.IVPRODDESC "
			+ " FROM USER_ROLE_PRODUCT urp INNER JOIN USER_ROLES ur on ur.USERROLEKEY=urp.USERROLEKEY " + 
			" INNER JOIN BFSD_USERS bu on bu.USERKEY=ur.USERKEY " + 
			" INNER JOIN BFSD_ROLE_MASTER brm on brm.ROLEKEY=ur.ROLEKEY " + 
			" INNER JOIN INVESTMENT_PRODUCTS ip on ip.IVPRODKEY=urp.SUBPRODKEY " + 
			" INNER JOIN PRODUCT_CATEGORIES cp on cp.PRODCATKEY=ip.PRODCATKEY " + 
			" INNER JOIN PRODUCT_MASTER pm on pm.PRODMASTKEY=urp.PRODMASTKEY " + 
			" WHERE ur.ISACTIVE=1 and urp.ISACTIVE=1 and brm.ISACTIVE=1 and ip.IVPRODISACTIVE=1 and  bu.USERKEY= :userKey and pm.PRODMASTCODE = 'INVESTMENT' "
			+ " order by 4,7 ";

	public static final String QRY_PARAM_USERKEY = "userKey";
	
	public static final String QRY_SAVE_PASSWORD = "update UserLoginAccount set loginpwd=:loginpwd "//NOSONAR
				+ "where userloginacctype=:userloginacctype and bfsdUser.userkey=:userKey"; //NOSONAR
	
	public static final String QRY_RESET_SAVE_PASSWORD = "from UserLoginAccount "//NOSONAR
			+ "where userloginacctype=:userloginacctype and loginpwd = :oldpwd and bfsdUser.userkey=:userKey"; //NOSONAR
	
	public static final String QRY_EXISTING_CHECK_LOGIN_EMAIL = "from UserLoginAccount where bfsdUser.isactive=1 and userloginacctype=5 and bfsdUser.usertype=1 "
			+ "and loginid=:loginId";
	
	public static final String QRY_EXISTING_CHECK_APPLICANT_EMAIL= "select a.APPLICANTKEY, ae.APLTEMAILADDRESS from APPLICANT_EMAILS ae, APPLICANTS a, EMAIL_TYPES et where lower(ae.APLTEMAILADDRESS)=:emailId and ae.APLTEMAILISACTIVE=1 "
						+"and a.APPLICANTKEY=ae.APPLICANTKEY and a.APLTISACTIVE=1 and et.EMAILTYPECODE='PERSON1' AND et.EMAILTYPEKEY=ae.EMAILTYPEKEY";
	
	public static final String QRY_TO_GET_CHECK_SUPERVISOR="select * from User_Role_Product urp where urp.parentuser=:userprodkey and urp.isactive =1";

	public static final String QRY_PARAM_USER_ROLE_PROD_KEY = "userRoleProdKey";
	
	public static final String GET_USER_ROLE_OM = "select ul from UserRoleL3  ul "//NOSONAR
			+ " where ul.userrolekey=:userrolekey"; //NOSONAR

	public static final String USER_ROLE_KEY = "userrolekey";
	
	public static final String USER_PROFILES_BY_ROLEKEY = "SELECT ur.USERROLEKEY, up.FIRSTNAME || ' ' || up.LASTNAME as fullname FROM USER_ROLES ur, USER_PROFILES up WHERE ur.rolekey IN :rolekeys AND up.USERKEY = ur.USERKEY AND up.isactive= 1";
	
	public static final String FETCH_REPORTING_MANAGERS = "select new com.bajaj.bfsd.usermanagement.bean.ReportingManager(up.bfsdUser.userkey, up.firstname||' '||up.lastname) from UserProfile up where Lower(up.firstname||' '||up.lastname) like :searchcriteria and up.isactive=1";
	
	public static final String FETCH_REPORTING_MANAGER_BY_USERKEY = "select up.firstname||' '||up.lastname from UserProfile up where up.bfsdUser.userkey=:userKey and up.isactive=1";
	
	public static final String FETCH_USERPROFILE_DETAILS = "select up.userprofilekey, up.firstname, up.lastname, up.emailid, up.mobileno, up.designation, up.adid, up.empid, up.companyname from UserProfile up where up.bfsdUser.userkey=:userKey and up.isactive=:isActive";
	
	public static final String GET_ATTRIBUTE_VALUE = "select ua.attrvalue from UserAddlAttributes ua where ua.attrrkey=:userKey and ua.attrcode=:attrCode and ua.isactive=:isActive";
	
	public static final String GET_ADDITIONAL_ATTRIBUTE = "select ua from UserAddlAttributes ua where ua.attrrkey=:userKey and ua.isactive=:isActive";
	
	public static final String EMP_TYPE_STATUS_CHANGE_REASON = "select bu.usertype, bu.statuschngreason from BfsdUser bu where bu.userkey=:userKey and bu.isactive=:isActive";
	
	public static final String FETCH_ALL_REPORTING_MANAGERS = "select up.bfsdUser.userkey,up.firstname,up.lastname from UserProfile up where up.isactive=1 and  up.bfsdUser.usertype=2 ";
	private QueryConstants(){
		
	}
}
