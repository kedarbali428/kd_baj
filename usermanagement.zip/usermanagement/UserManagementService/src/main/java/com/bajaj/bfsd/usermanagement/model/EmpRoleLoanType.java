package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the EMP_ROLE_LOAN_TYPES database table.
 * 
 */
@Entity
@Table(name="EMP_ROLE_LOAN_TYPES")
//@NamedQuery(name="EmpRoleLoanType.findAll", query="SELECT e FROM EmpRoleLoanType e")
public class EmpRoleLoanType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long empprodkey;

	private BigDecimal creditlimit;

	private BigDecimal isactive;

	private BigDecimal lnprdtypekey;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to EmployeeRole
	@ManyToOne
	@JoinColumn(name="EMPROLEKEY")
	private EmployeeRole employeeRole;

	public long getEmpprodkey() {
		return this.empprodkey;
	}

	public void setEmpprodkey(long empprodkey) {
		this.empprodkey = empprodkey;
	}

	public BigDecimal getCreditlimit() {
		return this.creditlimit;
	}

	public void setCreditlimit(BigDecimal creditlimit) {
		this.creditlimit = creditlimit;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public BigDecimal getLnprdtypekey() {
		return this.lnprdtypekey;
	}

	public void setLnprdtypekey(BigDecimal lnprdtypekey) {
		this.lnprdtypekey = lnprdtypekey;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public EmployeeRole getEmployeeRole() {
		return this.employeeRole;
	}

	public void setEmployeeRole(EmployeeRole employeeRole) {
		this.employeeRole = employeeRole;
	}

}