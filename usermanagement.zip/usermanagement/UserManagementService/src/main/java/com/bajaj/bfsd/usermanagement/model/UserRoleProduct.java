package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the USER_ROLE_PRODUCT database table.
 * 
 */
@Entity
@Table(name = "USER_ROLE_PRODUCT")
//@NamedQuery(name = "UserRoleProduct.findAll", query = "SELECT u FROM UserRoleProduct u")
public class UserRoleProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userprodkey;

	private BigDecimal creditlimit;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodmastkey;

	private BigDecimal subprodkey;

	private BigDecimal subprodtypekey;

	// bi-directional many-to-one association to UserRole
	@ManyToOne
	@JoinColumn(name = "USERROLEKEY")
	private UserRole userRole;

	// bi-directional many-to-one association to UserRoleProduct
	@ManyToOne
	@JoinColumn(name = "PARENTUSER")
	private UserRoleProduct userRoleProduct;

	// bi-directional many-to-one association to UserRoleChannel
	@OneToMany(mappedBy = "userRoleProduct", cascade = CascadeType.ALL)
	private List<UserRoleChannel> userRoleChannels;

	// bi-directional many-to-one association to UserRoleLocation
	@OneToMany(mappedBy = "userRoleProduct", cascade = CascadeType.ALL)
	private List<UserRoleLocation> userRoleLocations;

	// bi-directional many-to-one association to UserRolePinCode
	@OneToMany(mappedBy = "userRoleProduct", cascade = CascadeType.ALL)
	private List<UserRolePinCode> userRolePinCodes;


	// bi-directional many-to-one association to UserRoleProduct
	@OneToMany(mappedBy = "userRoleProduct")
	private List<UserRoleProductType> userRoleProductTypes;

	public long getUserprodkey() {
		return this.userprodkey;
	}

	public void setUserprodkey(long userprodkey) {
		this.userprodkey = userprodkey;
	}

	public BigDecimal getCreditlimit() {
		return this.creditlimit;
	}

	public void setCreditlimit(BigDecimal creditlimit) {
		this.creditlimit = creditlimit;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(BigDecimal prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public BigDecimal getSubprodtypekey() {
		return this.subprodtypekey;
	}

	public void setSubprodtypekey(BigDecimal subprodtypekey) {
		this.subprodtypekey = subprodtypekey;
	}

	public UserRole getUserRole() {
		return this.userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

	public BigDecimal getSubprodkey() {
		return subprodkey;
	}

	public void setSubprodkey(BigDecimal subprodkey) {
		this.subprodkey = subprodkey;
	}

	public UserRoleProduct getUserRoleProduct() {
		return userRoleProduct;
	}

	public void setUserRoleProduct(UserRoleProduct userRoleProduct) {
		this.userRoleProduct = userRoleProduct;
	}

	public List<UserRoleChannel> getUserRoleChannels() {
		return userRoleChannels;
	}

	public void setUserRoleChannels(List<UserRoleChannel> userRoleChannels) {
		this.userRoleChannels = userRoleChannels;
	}

	public List<UserRoleLocation> getUserRoleLocations() {
		return userRoleLocations;
	}

	public void setUserRoleLocations(List<UserRoleLocation> userRoleLocations) {
		this.userRoleLocations = userRoleLocations;
	}

	public List<UserRolePinCode> getUserRolePinCodes() {
		return userRolePinCodes;
	}

	public void setUserRolePinCodes(List<UserRolePinCode> userRolePinCodes) {
		this.userRolePinCodes = userRolePinCodes;
	}


	public List<UserRoleProductType> getUserRoleProductTypes() {
		return userRoleProductTypes;
	}

	public void setUserRoleProductTypes(List<UserRoleProductType> userRoleProductTypes) {
		this.userRoleProductTypes = userRoleProductTypes;
	}

}