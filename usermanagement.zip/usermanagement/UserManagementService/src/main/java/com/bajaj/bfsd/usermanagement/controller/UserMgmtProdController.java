package com.bajaj.bfsd.usermanagement.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

import javax.validation.Valid;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserProdMappingBean;
import com.bajaj.bfsd.usermanagement.config.InstanceConfig;
import com.bajaj.bfsd.usermanagement.model.ProductMaster;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataPluginMapper;
import com.bajaj.bfsd.usermanagement.service.UserMgmtIntegration;
import com.bajaj.bfsd.usermanagement.service.UserMgmtProdService;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

import ch.lambdaj.function.matcher.Predicate;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@RestController
public class UserMgmtProdController extends BFLController {

	private static final String THIS_CLASS = UserMgmtProdController.class.getCanonicalName();

	@Autowired
	UserMgmtProdService userMgmtProdService;

	@Autowired
	BFLLoggerUtil bflLoggerUtil;
	
	@Autowired
	InstanceConfig instanceConfig;

	@Autowired
	OMMasterDataPluginMapper omMasterDataPluginMapper;
	
	@Autowired
	private ApplicationContext context;
	
	@ApiOperation(value = "get the information of user", notes = "User Management Operations", httpMethod = "POST")
	@RequestMapping(method = RequestMethod.POST, value = "${api.usermanagement.user.details.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserInformation(@RequestBody UserConfigurationBean userConfig,
			@RequestHeader HttpHeaders headers) {

		UserMgmtIntegration svc;
		UserConfigurationBean userConfiguration = null;
		
		try {
			svc = (UserMgmtIntegration) context.getBean("userMgmtIntService");
			userConfiguration = svc.getUserAttributes(userConfig, headers);
			userConfiguration = svc.getAdditionalUserAttributes(userConfiguration);
		} catch (Exception e) {
			bflLoggerUtil.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"Service instance not available." + e);
			 userConfiguration = userMgmtProdService.getUserDetails(userConfig,headers);
		}

		return new ResponseEntity<>(new ResponseBean(userConfiguration), HttpStatus.OK);
	}

	@ApiOperation(value = "Create User Mapping", notes = "User Management Operations", httpMethod = "POST")
	@RequestMapping(method = RequestMethod.POST, value = "${api.usermanagement.users.mapping.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> saveUserMapping(@Valid @RequestBody UserProdMappingBean userMappingBean,
			@RequestHeader HttpHeaders headers) {

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"createUserMapping - User Mgmt Service class invoked");
		long userRoleProdKey = 0;
		List<ProductMaster> masterProducts = userMgmtProdService.getAllMasterProducts();

		Optional<ProductMaster> optMaster =  masterProducts.stream().
				filter(item-> item.getProdmastkey() == userMappingBean.getProdMastKey()).findFirst();
		if(optMaster.isPresent()) {
			ProductMaster master = optMaster.get();
			switch(master.getProdmastcode()) {
			case "OMCREDIT":
				userRoleProdKey = userMgmtProdService.savePrincipalUserMapping(userMappingBean, headers);
				bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
						"createUserMapping -  OM User management Service class completed");
				break;
			case "OMINS":
				userRoleProdKey = userMgmtProdService.saveUserMappingForOMInsurance(userMappingBean, headers);
				bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
						"OM Insurance User management createUserMapping");
				break;	
			default:
				userRoleProdKey = userMgmtProdService.saveUserMapping(userMappingBean,headers);
				bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
						"createUserMapping - User management Service class completed");
			}
			
			}
		return new ResponseEntity<>(new ResponseBean(userRoleProdKey), HttpStatus.OK);
	}

	@ApiOperation(value = "Get the Supervisor for the selected user role", notes = "Get the Supervisor for the selected user role", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.user.supervisor.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserSuperVisor(@RequestParam long roleKey, @RequestParam long prodKey,
			@RequestParam long subProdKey,
			@QueryParam("OMSubProdKeys") String OMSubProdKeys, 
			@RequestHeader HttpHeaders headers) {

		List<SupervisorBean> user = new ArrayList<>();
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Fetch all supervisor for the user role Service execution invoked");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserMgmtProdController : User Mgmt Service class invoked");
		List<ProductMaster> masterProducts = userMgmtProdService.getAllMasterProducts();
		Optional<ProductMaster> optMaster =  masterProducts.stream().
				filter(item-> item.getProdmastkey() == prodKey).findFirst();
		if(optMaster.isPresent()) {
			ProductMaster master = optMaster.get();
			switch(master.getProdmastcode()) {
			case "OMINS":
				user = userMgmtProdService.getUserSuperVisorForOmInsurance(roleKey, prodKey, OMSubProdKeys,headers);
				bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
						"OM Insurance User management get supervisorname");
				break;	
			case "OMCREDIT":
				user = userMgmtProdService.getOMUserSuperVisorForOmCredit(roleKey, prodKey, OMSubProdKeys,headers);
				bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
						"OM credit User management get supervisorname");
				break;	
			default:
				user = userMgmtProdService.getUserSuperVisor(roleKey, prodKey, subProdKey);
				bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
						"createUserMapping - User management Service class completed");
			}
			
			}

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"getuserSuperVisor - User management Service class completed");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Completed Fetch all supervisor for the user role Service execution invoked");
		return new ResponseEntity<>(new ResponseBean(user), HttpStatus.OK);
	}

	/**
	 * @Desc This is Controller method for fetching the supervisor LOCATION for
	 *       the selected userrole
	 * @param bean
	 * @param headers
	 * @return ResponseEntity
	 * @throws BFLTechnicalException
	 */
	@ApiOperation(value = "Get the location for the selected user role supervisor", notes = "Get the Supervisor for the selected user role supervisor location", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.supervisor.location.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getSuperVisorLocations(@RequestParam long userRoleProdKey,
			@RequestParam(name = "l1ProdKey", required = false) Long l1ProdKey,@RequestParam(name = "userKey", required = false) long userKey,@RequestParam(name = "prodKey", required = false) long prodKey, @RequestHeader HttpHeaders headers) {

		List<LocationBean> bflBranchList = new ArrayList<>();
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Fetch all supervisor for the user role Service execution invoked");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : User Mgmt Service class invoked");
		List<ProductMaster> masterProducts = userMgmtProdService.getAllMasterProducts();
		if (null != l1ProdKey) {
			Optional<ProductMaster> master = masterProducts.stream().filter(item -> item.getProdmastkey() == l1ProdKey)
					.findFirst();
			if (master.isPresent() && (master.get().getProdmastcode().equals("OMCREDIT"))) {
				bflBranchList = omMasterDataPluginMapper.findSuperVisorLocation(userRoleProdKey, headers);
				bflBranchList.removeIf(Objects::isNull);
			}else if(master.isPresent() && (master.get().getProdmastcode().equals("OMINS"))) {
				if(0 !=userKey) {
					bflBranchList = omMasterDataPluginMapper.findInsuranceSuperVisorLocation(userKey, prodKey,headers);
				}else {
					bflBranchList = omMasterDataPluginMapper.findInsuranceSuperVisorLocation(userRoleProdKey, headers);
				}
				bflBranchList.removeIf(Objects::isNull);
			}
			else{
				bflBranchList = userMgmtProdService.getSuperVisorLocations(userRoleProdKey);
			}
		} else {
			bflBranchList = userMgmtProdService.getSuperVisorLocations(userRoleProdKey);
		}

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"getSuperVisorLocations - User management Service class completed");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Completed getSuperVisorLocations");
		return new ResponseEntity<>(new ResponseBean(bflBranchList), HttpStatus.OK);
	}

	/**
	 * @Desc This is Controller method for fetching the supervisor channels for
	 *       the selected userrolekey
	 * @param bean
	 * @param headers
	 * @return ResponseEntity
	 * @throws BFLTechnicalException
	 */
	@ApiOperation(value = "Get the location for the selected user role supervisor", notes = "Get the Supervisor for the selected user role supervisor location", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.supervisor.channel.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getSuperVisorChannels(@RequestParam long userRoleProdKey,
			@RequestHeader HttpHeaders headers) {

		List<ChannelBean> bflChannelList;
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Fetch all getSuperVisorChannels");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserMgmtProdController : User Mgmt Service class invoked");

		bflChannelList = userMgmtProdService.getSuperVisorChannels(userRoleProdKey);

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : User management Service class completed");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Completed getSuperVisorChannels");
		return new ResponseEntity<>(new ResponseBean(bflChannelList), HttpStatus.OK);
	}

	@ApiOperation(value = "User Details", notes = "User Management Operations", httpMethod = "GET")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.users.mapping.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserMappingDetails(
			@RequestParam(value = "userRoleProdKey") long userRoleProdKey,@RequestParam(value = "l1ProdKey", required = false)Long l1ProdKey, @RequestHeader HttpHeaders headers) {
		List<UserProdMappingBean> list = new ArrayList<>();
		List<ProductMaster> masterProducts = userMgmtProdService.getAllMasterProducts();
		if (null != l1ProdKey) {
			Optional<ProductMaster> optMaster = masterProducts.stream().filter(item -> item.getProdmastkey() == l1ProdKey)
					.findFirst();
			if (optMaster.isPresent()) {
				ProductMaster master = optMaster.get();
				switch (master.getProdmastcode()) {
				case "OMCREDIT":
					list = userMgmtProdService.getOMUserMappingDetails(userRoleProdKey,headers);
					bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
							"OM credit User management get UserMappingDetails");
					break;
					case "OMINS":
						list = userMgmtProdService.getOMInsuranceUserMappingDetails(userRoleProdKey,headers);
						bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
								"OM Insurance User management get UserMappingDetails");
						break;
				default:
					list = userMgmtProdService.getUserMappingDetails(userRoleProdKey,headers);
					bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
							"getUserMappingDetails - In User management Service class");
				}
			}
		}else {
			list = userMgmtProdService.getUserMappingDetails(userRoleProdKey,headers);
		}
		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"getUserMappingDetails - User management Service class completed");

		bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"UserManagementController : Completed Fetch all UserMapping Details for the user role Service execution invoked");	
		return new ResponseEntity<>(new ResponseBean(list), HttpStatus.OK);
	}

	@ApiOperation(value = "Delete User Mapping", notes = "User Management Operations", httpMethod = "DELETE")
	@RequestMapping(method = RequestMethod.DELETE, value = "${api.usermanagement.users.mapping.DELETE.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> deleteUserMapping(@RequestParam(value = "userRoleProdKey") long userRoleProdKey,@RequestParam(value = "prodMastKey") long prodMastKey,
			@RequestHeader HttpHeaders headers) {

		@SuppressWarnings("unchecked")
		boolean isDeleted = userMgmtProdService.deleteUserMapping(userRoleProdKey,prodMastKey,headers);
		return new ResponseEntity<>(new ResponseBean(isDeleted), HttpStatus.OK);

	}

	@ApiOperation(value = "Update User Mapping", notes = "User Management Operations", httpMethod = "PUT")
	@RequestMapping(method = RequestMethod.PUT, value = "${api.usermanagement.users.mapping.PUT.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> updateUserMapping(@Valid @RequestBody UserProdMappingBean userMappingBean,
			@RequestHeader HttpHeaders headers) {
		long userRoleProdKey = 0;
		List<ProductMaster> masterProducts = userMgmtProdService.getAllMasterProducts();

		Optional<ProductMaster> optMaster =  masterProducts.stream().
				filter(item-> item.getProdmastkey() == userMappingBean.getProdMastKey()).findFirst();
		if(optMaster.isPresent()) {
			ProductMaster master = optMaster.get();
			switch(master.getProdmastcode()) {
			case "OMCREDIT":
				userRoleProdKey = userMgmtProdService.savePrincipalUserMapping(userMappingBean, headers);
				bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
						"createUserMapping -  OM User management Service class completed");
				break;
			case "OMINS":
				userRoleProdKey = userMgmtProdService.saveUserMappingForOMInsurance(userMappingBean, headers);
				bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
						"OM Insurance User management createUserMapping");
				break;	
			default:
				userRoleProdKey = userMgmtProdService.saveUserMapping(userMappingBean,headers);
				bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
						"createUserMapping - User management Service class completed");
			}
			
			}
		return new ResponseEntity<>(new ResponseBean(userRoleProdKey), HttpStatus.OK);
	}
}
