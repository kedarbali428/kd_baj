package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "USER_APPLICANT")
public class UserApplicantV2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long userapplicantkey;

	@Column(name = "APPLICANTKEY", insertable = false, updatable = false)
	private long applicantkey;

	private long userkey;

	@ManyToOne
	@JoinColumn(name = "APPLICANTKEY")
	private ApplicantV2 applicant;

	public long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public long getUserkey() {
		return userkey;
	}

	public void setUserkey(long userkey) {
		this.userkey = userkey;
	}

	public ApplicantV2 getApplicant() {
		return applicant;
	}

	public void setApplicant(ApplicantV2 applicant) {
		this.applicant = applicant;
	}

	public long getUserapplicantkey() {
		return userapplicantkey;
	}

	public void setUserapplicantkey(long userapplicantkey) {
		this.userapplicantkey = userapplicantkey;
	}

}