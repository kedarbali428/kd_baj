package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the USER_PROFILE_AADHAAR_PHONES database table.
 * 
 */
@Entity
@Table(name="USER_PROFILE_AADHAAR_PHONES")
//@NamedQuery(name="UserProfileAadhaarPhone.findAll", query="SELECT u FROM UserProfileAadhaarPhone u")
public class UserProfileAadhaarPhone implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long aadhaarphnkey;

	private Long areacode;

	private Long countrycode;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private Long phnnumber;

	private String phntype;

	//bi-directional many-to-one association to UserProfileAadhaar
	@ManyToOne
	@JoinColumn(name="AADHAARKEY")
	private UserProfileAadhaar userProfileAadhaar;

	public UserProfileAadhaarPhone() {
	}

	public long getAadhaarphnkey() {
		return this.aadhaarphnkey;
	}

	public void setAadhaarphnkey(long aadhaarphnkey) {
		this.aadhaarphnkey = aadhaarphnkey;
	}

	public Long getAreacode() {
		return this.areacode;
	}

	public void setAreacode(Long areacode) {
		this.areacode = areacode;
	}

	public Long getCountrycode() {
		return this.countrycode;
	}

	public void setCountrycode(Long countrycode) {
		this.countrycode = countrycode;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getPhnnumber() {
		return this.phnnumber;
	}

	public void setPhnnumber(Long phnnumber) {
		this.phnnumber = phnnumber;
	}

	public String getPhntype() {
		return this.phntype;
	}

	public void setPhntype(String phntype) {
		this.phntype = phntype;
	}

	public UserProfileAadhaar getUserProfileAadhaar() {
		return this.userProfileAadhaar;
	}

	public void setUserProfileAadhaar(UserProfileAadhaar userProfileAadhaar) {
		this.userProfileAadhaar = userProfileAadhaar;
	}

}