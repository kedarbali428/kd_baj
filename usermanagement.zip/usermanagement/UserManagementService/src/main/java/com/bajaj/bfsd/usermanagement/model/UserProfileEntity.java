/**
 * 
 */
package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.util.List;

/**
 * @author bflrdpuser1
 *
 */
public class UserProfileEntity implements Serializable {
	private static final long serialVersionUID = -1704479211322412114L;
	
	private String dateOfBirth;
	private String mobileNumber;
	private Long applicantId;
	private List<Long> applicationIds;
	private List<Long> applicationApplicantIds;
	private List<String> appProcessIds;
	private List<Long> applicantIds;
	private List<String> mobileNumbers;
	private List<String> dateOfBirths;
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Long getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}
	public List<Long> getApplicationIds() {
		return applicationIds;
	}
	public void setApplicationIds(List<Long> applicationIds) {
		this.applicationIds = applicationIds;
	}
	public List<Long> getApplicationApplicantIds() {
		return applicationApplicantIds;
	}
	public void setApplicationApplicantIds(List<Long> applicationApplicantIds) {
		this.applicationApplicantIds = applicationApplicantIds;
	}
	public List<String> getAppProcessIds() {
		return appProcessIds;
	}
	public void setAppProcessIds(List<String> appProcessIds) {
		this.appProcessIds = appProcessIds;
	}
	public List<Long> getApplicantIds() {
		return applicantIds;
	}
	public void setApplicantIds(List<Long> applicantIds) {
		this.applicantIds = applicantIds;
	}
	public List<String> getMobileNumbers() {
		return mobileNumbers;
	}
	public void setMobileNumbers(List<String> mobileNumbers) {
		this.mobileNumbers = mobileNumbers;
	}
	public List<String> getDateOfBirths() {
		return dateOfBirths;
	}
	public void setDateOfBirths(List<String> dateOfBirths) {
		this.dateOfBirths = dateOfBirths;
	}
	
}