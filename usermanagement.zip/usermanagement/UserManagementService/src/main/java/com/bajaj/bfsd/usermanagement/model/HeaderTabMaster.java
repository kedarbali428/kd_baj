package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the HEADER_TAB_MASTER database table.
 * 
 */
@Entity
@Table(name="HEADER_TAB_MASTER")
//@NamedQuery(name="HeaderTabMaster.findAll", query="SELECT h FROM HeaderTabMaster h")
public class HeaderTabMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long tabkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal tabcd;

	private String tabname;

	private BigDecimal vieworder;

	//bi-directional many-to-one association to HeaderTabCta
	@OneToMany(mappedBy="headerTabMaster")
	private List<HeaderTabCta> headerTabCtas;

	//bi-directional many-to-one association to HeaderTabRole
	@OneToMany(mappedBy="headerTabMaster")
	private List<HeaderTabRole> headerTabRoles;

	//bi-directional many-to-one association to HeaderTabSection
	@OneToMany(mappedBy="headerTabMaster")
	private List<HeaderTabSection> headerTabSections;

	public long getTabkey() {
		return this.tabkey;
	}

	public void setTabkey(long tabkey) {
		this.tabkey = tabkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getTabcd() {
		return this.tabcd;
	}

	public void setTabcd(BigDecimal tabcd) {
		this.tabcd = tabcd;
	}

	public String getTabname() {
		return this.tabname;
	}

	public void setTabname(String tabname) {
		this.tabname = tabname;
	}

	public BigDecimal getVieworder() {
		return this.vieworder;
	}

	public void setVieworder(BigDecimal vieworder) {
		this.vieworder = vieworder;
	}

	public List<HeaderTabCta> getHeaderTabCtas() {
		return this.headerTabCtas;
	}

	public void setHeaderTabCtas(List<HeaderTabCta> headerTabCtas) {
		this.headerTabCtas = headerTabCtas;
	}

	public HeaderTabCta addHeaderTabCta(HeaderTabCta headerTabCta) {
		getHeaderTabCtas().add(headerTabCta);
		headerTabCta.setHeaderTabMaster(this);

		return headerTabCta;
	}

	public HeaderTabCta removeHeaderTabCta(HeaderTabCta headerTabCta) {
		getHeaderTabCtas().remove(headerTabCta);
		headerTabCta.setHeaderTabMaster(null);

		return headerTabCta;
	}

	public List<HeaderTabRole> getHeaderTabRoles() {
		return this.headerTabRoles;
	}

	public void setHeaderTabRoles(List<HeaderTabRole> headerTabRoles) {
		this.headerTabRoles = headerTabRoles;
	}

	public HeaderTabRole addHeaderTabRole(HeaderTabRole headerTabRole) {
		getHeaderTabRoles().add(headerTabRole);
		headerTabRole.setHeaderTabMaster(this);

		return headerTabRole;
	}

	public HeaderTabRole removeHeaderTabRole(HeaderTabRole headerTabRole) {
		getHeaderTabRoles().remove(headerTabRole);
		headerTabRole.setHeaderTabMaster(null);

		return headerTabRole;
	}

	public List<HeaderTabSection> getHeaderTabSections() {
		return this.headerTabSections;
	}

	public void setHeaderTabSections(List<HeaderTabSection> headerTabSections) {
		this.headerTabSections = headerTabSections;
	}

	public HeaderTabSection addHeaderTabSection(HeaderTabSection headerTabSection) {
		getHeaderTabSections().add(headerTabSection);
		headerTabSection.setHeaderTabMaster(this);

		return headerTabSection;
	}

	public HeaderTabSection removeHeaderTabSection(HeaderTabSection headerTabSection) {
		getHeaderTabSections().remove(headerTabSection);
		headerTabSection.setHeaderTabMaster(null);

		return headerTabSection;
	}

}