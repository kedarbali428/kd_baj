package com.bajaj.openmarkets.usermanagement.cache.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.openmarkets.usermanagement.cache.entity.CacheAdditionalInfo;

@Component
public class CacheAdditionalInfoRepository {

	SingleObjectCacheRepositoryImpl<Long, CacheAdditionalInfo> cacheRepository;

	@Autowired
	protected Environment env;

	@Autowired
	protected RedisConfig redisConfig;

	public CacheAdditionalInfo get(Long userKey, long ttl) {
		return getCacheRepository().find(userKey, ttl);
	}

	public void save(Long userKey, CacheAdditionalInfo additionalInfo, long ttl) {
		getCacheRepository().save(userKey, additionalInfo, ttl);
	}

	public CacheAdditionalInfo get(Long userKey) {
		return getCacheRepository().find(userKey);
	}

	private SingleObjectCacheRepositoryImpl<Long, CacheAdditionalInfo> getCacheRepository() {
		if (null == this.cacheRepository) {
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(CacheAdditionalInfo.class, env, redisConfig);
		}
		return cacheRepository;
	}
}
