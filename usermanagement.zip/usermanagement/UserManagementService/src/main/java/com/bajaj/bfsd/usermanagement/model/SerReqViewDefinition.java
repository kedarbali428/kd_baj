package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;




/**
 * The persistent class for the SER_REQ_VIEW_DEFINITION database table.
 * 
 */
@Entity
@Table(name="SER_REQ_VIEW_DEFINITION")
//@NamedQuery(name="SerReqViewDefinition.findAll", query="SELECT s FROM SerReqViewDefinition s")
public class SerReqViewDefinition implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long viewkey;

	private String condition;

	private String createdby;

	private Timestamp createddt;

	@Lob
	@Column(name="FILTERCONDTIONJASON")
	private Blob filtercondtionjason;


	public Blob getFiltercondtionjason() {
		return filtercondtionjason;
	}

	public void setFiltercondtionjason(Blob filtercondtionjason) {
		this.filtercondtionjason = filtercondtionjason;
	}

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal viewaccess;

	private String viewname;

	private String wherecluase;
	
	// bi-directional many-to-one association to AppRoleView
	@OneToMany(mappedBy = "serReqViewDefinition",cascade=CascadeType.ALL)
	private List<SerReqRoleView> serReqRoleViews;

	public List<SerReqRoleView> getSerReqRoleViews() {
		return serReqRoleViews;
	}

	public void setSerReqRoleViews(List<SerReqRoleView> serReqRoleViews) {
		this.serReqRoleViews = serReqRoleViews;
	}

	//bi-directional many-to-one association to SerReqViewLastloginDtl
	@OneToMany(mappedBy="serReqViewDefinition",cascade=CascadeType.ALL)
	private List<SerReqViewLastloginDtl> serReqViewLastloginDtls;

	//bi-directional many-to-one association to SerReqViewSummaryField
	@OneToMany(mappedBy="serReqViewDefinition",cascade=CascadeType.ALL)
	private List<SerReqViewSummaryField> serReqViewSummaryFields;

	public long getViewkey() {
		return this.viewkey;
	}

	public void setViewkey(long viewkey) {
		this.viewkey = viewkey;
	}

	public String getCondition() {
		return this.condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getCreatedby() {
		return this.createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public Timestamp getCreateddt() {
		return this.createddt;
	}

	public void setCreateddt(Timestamp createddt) {
		this.createddt = createddt;
	}




	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getViewaccess() {
		return this.viewaccess;
	}

	public void setViewaccess(BigDecimal viewaccess) {
		this.viewaccess = viewaccess;
	}

	public String getViewname() {
		return this.viewname;
	}

	public void setViewname(String viewname) {
		this.viewname = viewname;
	}

	public String getWherecluase() {
		return this.wherecluase;
	}

	public void setWherecluase(String wherecluase) {
		this.wherecluase = wherecluase;
	}

	public List<SerReqViewLastloginDtl> getSerReqViewLastloginDtls() {
		return this.serReqViewLastloginDtls;
	}

	public void setSerReqViewLastloginDtls(List<SerReqViewLastloginDtl> serReqViewLastloginDtls) {
		this.serReqViewLastloginDtls = serReqViewLastloginDtls;
	}

	public SerReqViewLastloginDtl addSerReqViewLastloginDtl(SerReqViewLastloginDtl serReqViewLastloginDtl) {
		getSerReqViewLastloginDtls().add(serReqViewLastloginDtl);
		serReqViewLastloginDtl.setSerReqViewDefinition(this);

		return serReqViewLastloginDtl;
	}

	public SerReqViewLastloginDtl removeSerReqViewLastloginDtl(SerReqViewLastloginDtl serReqViewLastloginDtl) {
		getSerReqViewLastloginDtls().remove(serReqViewLastloginDtl);
		serReqViewLastloginDtl.setSerReqViewDefinition(null);

		return serReqViewLastloginDtl;
	}

	public List<SerReqViewSummaryField> getSerReqViewSummaryFields() {
		return this.serReqViewSummaryFields;
	}

	public void setSerReqViewSummaryFields(List<SerReqViewSummaryField> serReqViewSummaryFields) {
		this.serReqViewSummaryFields = serReqViewSummaryFields;
	}

	public SerReqViewSummaryField addSerReqViewSummaryField(SerReqViewSummaryField serReqViewSummaryField) {
		getSerReqViewSummaryFields().add(serReqViewSummaryField);
		serReqViewSummaryField.setSerReqViewDefinition(this);

		return serReqViewSummaryField;
	}

	public SerReqViewSummaryField removeSerReqViewSummaryField(SerReqViewSummaryField serReqViewSummaryField) {
		getSerReqViewSummaryFields().remove(serReqViewSummaryField);
		serReqViewSummaryField.setSerReqViewDefinition(null);

		return serReqViewSummaryField;
	}

}