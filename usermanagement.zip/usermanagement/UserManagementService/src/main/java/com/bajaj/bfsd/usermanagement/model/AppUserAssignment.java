package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the APP_USER_ASSIGNMENT database table.
 * 
 */
@Entity
@Table(name="APP_USER_ASSIGNMENT")
//@NamedQuery(name="AppUserAssignment.findAll", query="SELECT a FROM AppUserAssignment a")
public class AppUserAssignment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long assignmentkey;

	private BigDecimal applicationkey;

	private BigDecimal appstatus;

	private Timestamp appstatustm;

	private String assigncomments;

	private BigDecimal assignedby;

	private Timestamp assignenddt;

	private Timestamp assignstrtdt;

	private BigDecimal assigntoflg;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal rolekey;

	private BigDecimal userrolekey;

	//bi-directional many-to-one association to AppAppointment
	@OneToMany(mappedBy="appUserAssignment")
	private List<AppAppointment> appAppointments;

	public long getAssignmentkey() {
		return this.assignmentkey;
	}

	public void setAssignmentkey(long assignmentkey) {
		this.assignmentkey = assignmentkey;
	}

	public BigDecimal getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(BigDecimal applicationkey) {
		this.applicationkey = applicationkey;
	}

	public BigDecimal getAppstatus() {
		return this.appstatus;
	}

	public void setAppstatus(BigDecimal appstatus) {
		this.appstatus = appstatus;
	}

	public Timestamp getAppstatustm() {
		return this.appstatustm;
	}

	public void setAppstatustm(Timestamp appstatustm) {
		this.appstatustm = appstatustm;
	}

	public String getAssigncomments() {
		return this.assigncomments;
	}

	public void setAssigncomments(String assigncomments) {
		this.assigncomments = assigncomments;
	}

	public BigDecimal getAssignedby() {
		return this.assignedby;
	}

	public void setAssignedby(BigDecimal assignedby) {
		this.assignedby = assignedby;
	}

	public Timestamp getAssignenddt() {
		return this.assignenddt;
	}

	public void setAssignenddt(Timestamp assignenddt) {
		this.assignenddt = assignenddt;
	}

	public Timestamp getAssignstrtdt() {
		return this.assignstrtdt;
	}

	public void setAssignstrtdt(Timestamp assignstrtdt) {
		this.assignstrtdt = assignstrtdt;
	}

	public BigDecimal getAssigntoflg() {
		return this.assigntoflg;
	}

	public void setAssigntoflg(BigDecimal assigntoflg) {
		this.assigntoflg = assigntoflg;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getRolekey() {
		return this.rolekey;
	}

	public void setRolekey(BigDecimal rolekey) {
		this.rolekey = rolekey;
	}

	public BigDecimal getUserrolekey() {
		return this.userrolekey;
	}

	public void setUserrolekey(BigDecimal userrolekey) {
		this.userrolekey = userrolekey;
	}

	public List<AppAppointment> getAppAppointments() {
		return this.appAppointments;
	}

	public void setAppAppointments(List<AppAppointment> appAppointments) {
		this.appAppointments = appAppointments;
	}

	public AppAppointment addAppAppointment(AppAppointment appAppointment) {
		getAppAppointments().add(appAppointment);
		appAppointment.setAppUserAssignment(this);

		return appAppointment;
	}

	public AppAppointment removeAppAppointment(AppAppointment appAppointment) {
		getAppAppointments().remove(appAppointment);
		appAppointment.setAppUserAssignment(null);

		return appAppointment;
	}

}