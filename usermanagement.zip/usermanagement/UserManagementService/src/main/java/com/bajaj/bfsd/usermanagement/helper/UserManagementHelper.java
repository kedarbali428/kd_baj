package com.bajaj.bfsd.usermanagement.helper;

import static com.bajaj.bfsd.common.BFLLoggerComponent.SERVICE;
import static com.bajaj.bfsd.common.BFLLoggerComponent.UTILITY;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.usermanagement.bean.BFSDRoleMasterBean;
import com.bajaj.bfsd.usermanagement.bean.BFSDUserRoleBean;
import com.bajaj.bfsd.usermanagement.bean.BfsdUserDetails;
import com.bajaj.bfsd.usermanagement.bean.BfsdUserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.ValidateTokenBean;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserProfile;
import com.bajaj.bfsd.usermanagement.model.UserRoleL3;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.markets.credit.sender.config.EventMessage;
import com.bajaj.markets.credit.sender.service.SenderService;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RefreshScope
@Component
public class UserManagementHelper extends BFLComponent
{
	private SecretKeySpec secretKey;
	private static final String CLASS_NAME = UserManagementHelper.class.getCanonicalName();
	
	@Value("${auth-type}")
	private String authType;

	@Value("${auth-userName}")
	private String authUserName;

	@Value("${auth-password}")
	private String authPassword;

	@Value("${resource-base}")
	private String resourceBase;

	@Value("${resource-path}")
	private String resourcePath;
	
	@Autowired
	CustomDefaultHeaders customHeaders;
	
	@Autowired
	SenderService senderService;
	
	public String getAuthDetails() {
		String auth;
		String userNamePwd = authUserName.trim() + ":" + authPassword.trim() ;
		auth = Base64.getEncoder().encodeToString(userNamePwd.getBytes());
		auth = authType + " " + auth;
		return auth;
	}
	
	public int calculateMob(Date startDate) {
		Calendar startCalendar = new GregorianCalendar();
		startCalendar.setTime(startDate);
		Calendar endCalendar = new GregorianCalendar();
		endCalendar.setTime(new Date());

		int differenceYears = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
		return differenceYears * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
	}
	
	public void populateTokenBeanWithDecryptedValues(String decryptedString, ValidateTokenBean tokenBean,
			BFLLoggerUtil logger) {

		logger.debug(CLASS_NAME, SERVICE, "populateTokenBeanWithDecryptedValues - started");
		String[] decryptedArr = decryptedString.split(UserManagementConstants.TOKEN_DELIMETER);
		if (decryptedArr.length == 2) {
			tokenBean.setDecryptedEmail(decryptedArr[0]);
			tokenBean.setDecryptedAppApltKey(decryptedArr[1]);
		} else {
			logger.error(CLASS_NAME, SERVICE, "Unable to parse token");
			throw new BFLTechnicalException("UMS-044", "Unable to parse token");
		}
		logger.debug(CLASS_NAME, SERVICE, "populateTokenBeanWithDecryptedValues - completed");
	}
	
	public void setKey(String myKey,BFLLoggerUtil logger) 
    {
        MessageDigest sha = null;
        byte[] key;
        try {
            key = myKey.getBytes("UTF-8");
            sha = MessageDigest.getInstance("SHA-1");
            key = sha.digest(key);
            key = Arrays.copyOf(key, 16); 
            secretKey = new SecretKeySpec(key, "AES");
        } 
        catch (NoSuchAlgorithmException | UnsupportedEncodingException e ) {
        	
        	logger.error(CLASS_NAME,BFLLoggerComponent.UTILITY, "Exception Occurred during setting verification mail link key"+e);   
             throw new BFLTechnicalException("AR-17",e);
        } 
       
    }
 
    
    public String decrypt(String strToDecrypt, String secret,BFLLoggerUtil logger){
        try{
            setKey(secret,logger);
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (Exception e){
        	logger.error(CLASS_NAME,UTILITY, "Error occurred while decrypting token");   
             throw new BFLTechnicalException("UMS-045",e);
        }
       
    }


    public EventMessage createEventMessage(String eventName,Object payload,CustomDefaultHeaders cstheaders) {
		Map<String, String> headers = new HashMap<>();
		headers.put(UserManagementConstants.AUTH_TOKEN, cstheaders.getAuthtoken());
		EventMessage eventMessage = new EventMessage();
		eventMessage.setEventName(eventName);
		eventMessage.setEventType(UserManagementConstants.USER_EVENT);
		eventMessage.setPayload(payload);
		eventMessage.setHeaders(headers);
		return eventMessage;
	}
    public BfsdUserDetails mapUserEntityToBean(BfsdUser bfsdUser) {
    	BfsdUserDetails request = new BfsdUserDetails();
		request.setUserkey(bfsdUser.getUserkey());
		request.setIsactive(bfsdUser.getIsactive());
		request.setFailedlogincount(null != bfsdUser.getFailedlogincount() ? bfsdUser.getFailedlogincount() : null);
		request.setLstfailedlogindt(null != bfsdUser.getLstfailedlogindt() ? bfsdUser.getLstfailedlogindt() : null);
		request.setLstupdateby(null != bfsdUser.getLstupdateby() ? bfsdUser.getLstupdateby() : null);
		request.setLstupdatedt(null != bfsdUser.getLstupdatedt() ? bfsdUser.getLstupdatedt() : null);
		request.setUsertype(null != bfsdUser.getUsertype() ? bfsdUser.getUsertype() : null);
		request.setUserblockedflg(null != bfsdUser.getUserblockedflg() ? bfsdUser.getUserblockedflg() : null);
		request.setRegistrationdate(null != bfsdUser.getRegistrationdate() ? bfsdUser.getRegistrationdate() : null);
		request.setStatuschngreason(null != bfsdUser.getStatuschngreason() ? bfsdUser.getStatuschngreason(): null);
		List<BfsdUserProfileBean> userProfileDetailsList= new ArrayList<BfsdUserProfileBean>();
		List<UserProfile> bfsdList = bfsdUser.getUserProfiles();
		BfsdUserProfileBean profileBean = new BfsdUserProfileBean(); 
		bfsdList.forEach(userProfileItem->{
			profileBean.setAddress(userProfileItem.getAddress());
			profileBean.setAssociationdt(userProfileItem.getAssociationdt());
			profileBean.setAssociationid(userProfileItem.getAssociationid());
			profileBean.setAssociationtype(userProfileItem.getAssociationtype());
			profileBean.setCity(userProfileItem.getCity());
			profileBean.setCompanyname(userProfileItem.getCompanyname());
			profileBean.setContactpersonname(userProfileItem.getContactpersonname());
			profileBean.setDateofbirth(userProfileItem.getDateofbirth());
			profileBean.setDesignation(userProfileItem.getDesignation());
			profileBean.setEmailid(userProfileItem.getEmailid());
			profileBean.setFirstname(userProfileItem.getFirstname());
			profileBean.setGenderkey(userProfileItem.getGenderkey());
			profileBean.setGst(userProfileItem.getGst());
			profileBean.setIsactive(userProfileItem.getIsactive());
			profileBean.setLandline(userProfileItem.getLandline());
			profileBean.setLastname(userProfileItem.getLastname());
			profileBean.setLstupdateby(userProfileItem.getLstupdateby());
			profileBean.setLstupdatedt(userProfileItem.getLstupdatedt());
			profileBean.setMaritalstatuskey(userProfileItem.getMaritalstatuskey());
			profileBean.setMiddlename(userProfileItem.getMiddlename());
			profileBean.setMobileno(userProfileItem.getMobileno());
			profileBean.setPan(userProfileItem.getPan());
			profileBean.setParentuseremailid(userProfileItem.getParentuseremailid());
			profileBean.setPartnerkey(userProfileItem.getPartnerkey());
			profileBean.setPan(userProfileItem.getPincode());
			profileBean.setSalutationkey(userProfileItem.getSalutationkey());
			profileBean.setServicekey(userProfileItem.getServicekey());
			profileBean.setUserprofilekey(userProfileItem.getUserprofilekey());
			profileBean.setUserkey(userProfileItem.getBfsdUser().getUserkey());
			userProfileDetailsList.add(profileBean);
		});
		request.setUserProfiles(userProfileDetailsList);
		return request;
    }
    
	public void createEventMessageMapping(String eventName, UserRoleL3 userRole1,BFLLoggerUtil logger) {
		 try { 
			logger.debug(CLASS_NAME, UTILITY, "Inside createEventMessageMapping...");
			BFSDUserRoleBean bfsdUserRoleBean = mapUserRoleEntityToBean(userRole1);
			EventMessage eventMessage = createEventMessage(eventName,bfsdUserRoleBean,customHeaders);
			ObjectMapper mapper= new ObjectMapper();
	    	String messageStr = mapper.writeValueAsString(eventMessage);
	    	logger.debug(CLASS_NAME, UTILITY, "Sending message to SQS...");
			senderService.sendToSQS(messageStr); 
			logger.debug(CLASS_NAME,UTILITY, "Message send for user replica eventName- " + eventName+" message:" + messageStr);
		 }catch(Exception e) { 
			logger.error(CLASS_NAME,UTILITY, "Some techical error occured while sending EVENT MESSAGE ");
		} 
	}
	public BFSDUserRoleBean mapUserRoleEntityToBean(UserRoleL3 userRole1) {
		BFSDRoleMasterBean roleBean = new BFSDRoleMasterBean();
		roleBean.setRolecd(userRole1.getBfsdRoleMaster().getRolecd());
		roleBean.setRolekey(userRole1.getBfsdRoleMaster().getRolekey());
		roleBean.setRolename(userRole1.getBfsdRoleMaster().getRolename());
		roleBean.setIsactive(userRole1.getBfsdRoleMaster().getIsactive());
		roleBean.setLstupdateby(userRole1.getBfsdRoleMaster().getLstupdateby());
		roleBean.setLstupdatedt(userRole1.getBfsdRoleMaster().getLstupdatedt());
		
		BFSDUserRoleBean bfsdUserRoleBean = new BFSDUserRoleBean();
		bfsdUserRoleBean.setUserrolekey(userRole1.getUserrolekey());
		bfsdUserRoleBean.setCreditlimit(userRole1.getCreditlimit());
		bfsdUserRoleBean.setIsactive(BigDecimal.valueOf(userRole1.getIsactive()));
		bfsdUserRoleBean.setLstupdateby(userRole1.getLstupdateby());
		bfsdUserRoleBean.setLstupdatedt(userRole1.getLstupdatedt());
		if(null !=userRole1.getParentuser()) {
			bfsdUserRoleBean.setParentuser(BigDecimal.valueOf(userRole1.getParentuser()));
		}
		BfsdUserDetails userDetails = mapUserEntityToBean(userRole1.getBfsduser());
		bfsdUserRoleBean.setUserDetails(userDetails);
		bfsdUserRoleBean.setUserKey(userRole1.getBfsduser().getUserkey());
		bfsdUserRoleBean.setRoledetails(roleBean);
		
		return bfsdUserRoleBean;
	}
}