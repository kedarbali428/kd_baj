package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * The persistent class for the USER_ROLE_PRODUCT_TYPES database table.
 * 
 */
@Entity
@Table(name = "USER_ROLE_PRODUCT_TYPES")
//@NamedQuery(name = "UserRoleProductType.findAll", query = "SELECT u FROM UserRoleProductType u")
public class UserRoleProductType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userroleprodtypekey;

	private long isactive;

	private String lstupdateby;

	private Date lstupdatedt;

	private long subprodtypekey;

	// bi-directional many-to-one association to UserRole
	@OneToOne
	@JoinColumn(name = "USERPRODKEY")
	private UserRoleProductL3 userRoleProduct;

	public UserRoleProductType() {
	}

	public long getUserroleprodtypekey() {
		return this.userroleprodtypekey;
	}

	public void setUserroleprodtypekey(long userroleprodtypekey) {
		this.userroleprodtypekey = userroleprodtypekey;
	}

	public long getIsactive() {
		return isactive;
	}

	public void setIsactive(long isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Date getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Date lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getSubprodtypekey() {
		return this.subprodtypekey;
	}

	public UserRoleProductL3 getUserRoleProduct() {
		return userRoleProduct;
	}

	public void setUserRoleProduct(UserRoleProductL3 userRoleProduct) {
		this.userRoleProduct = userRoleProduct;
	}

	public void setSubprodtypekey(long subprodtypekey) {
		this.subprodtypekey = subprodtypekey;
	}

}