package com.bajaj.bfsd.usermanagement.bean;

import java.util.List;

public class UserMappingRequest {

	private Long userKey;
	private Long creditLimit; // EMP_ROLE_LOAN_TYPES
	private Long roleKey; // EMPLOYEE_ROLES (NEW)
	private Long supervisor; // EMPLOYEE_ROLES (NEW)
	private Long loanProdKey; // LOAN_PRODUCTS (OLD)
	private Long prodMastKey; // PRODUCT_MASTER (OLD)
	private Long prodCatKey; // PRODUCT_CATEGORIES (OLD)
	private boolean highestRole;
	private boolean highestRoleForUser;
	private List<Long> userlockey; // EMP_ROLE_LOCATIONS (NEW)
	private List<Long> userChannelkey; // EMP_ROLE_CHENNELS (NEW)
	private List<Long> userPinCdKey; // EMP_ROLE_PIN_CODE (New)
	private List<Long> lnPrdTypeKey; // EMP_ROLE_LOAN_TYPES (New)
	private List<ProductBean> loanproduct;
	private UserMappingRequest oldMappingRequest;
	private String employeeType;

	public boolean isHighestRole() {
		return highestRole;
	}

	public void setHighestRole(boolean highestRole) {
		this.highestRole = highestRole;
	}

	public boolean isHighestRoleForUser() {
		return highestRoleForUser;
	}

	public void setHighestRoleForUser(boolean highestRoleForUser) {
		this.highestRoleForUser = highestRoleForUser;
	}

	public UserMappingRequest getOldMappingRequest() {
		return oldMappingRequest;
	}

	public void setOldMappingRequest(UserMappingRequest oldMappingRequest) {
		this.oldMappingRequest = oldMappingRequest;
	}

	public List<ProductBean> getLoanproduct() {
		return loanproduct;
	}

	public void setLoanproduct(List<ProductBean> loanproduct) {
		this.loanproduct = loanproduct;
	}

	public Long getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(Long creditLimit) {
		this.creditLimit = creditLimit;
	}

	public Long getUserKey() {
		return userKey;
	}

	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}

	public Long getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(Long roleKey) {
		this.roleKey = roleKey;
	}

	public Long getLoanProdKey() {
		return loanProdKey;
	}

	public void setLoanProdKey(Long loanProdKey) {
		this.loanProdKey = loanProdKey;
	}

	public Long getProdMastKey() {
		return prodMastKey;
	}

	public void setProdMastKey(Long prodMastKey) {
		this.prodMastKey = prodMastKey;
	}

	public Long getProdCatKey() {
		return prodCatKey;
	}

	public void setProdCatKey(Long prodCatKey) {
		this.prodCatKey = prodCatKey;
	}

	public Long getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(Long supervisor) {
		this.supervisor = supervisor;
	}

	public List<Long> getUserlockey() {
		return userlockey;
	}

	public void setUserlockey(List<Long> userlockey) {
		this.userlockey = userlockey;
	}

	public List<Long> getUserChannelkey() {
		return userChannelkey;
	}

	public void setUserChannelkey(List<Long> userChannelkey) {
		this.userChannelkey = userChannelkey;
	}

	public List<Long> getUserPinCdKey() {
		return userPinCdKey;
	}

	public void setUserPinCdKey(List<Long> userPinCdKey) {
		this.userPinCdKey = userPinCdKey;
	}

	public List<Long> getLnPrdTypeKey() {
		return lnPrdTypeKey;
	}

	public void setLnPrdTypeKey(List<Long> lnPrdTypeKey) {
		this.lnPrdTypeKey = lnPrdTypeKey;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
}
