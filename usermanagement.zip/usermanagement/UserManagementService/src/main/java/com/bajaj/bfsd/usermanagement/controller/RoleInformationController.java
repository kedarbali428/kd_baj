package com.bajaj.bfsd.usermanagement.controller;




import static com.bajaj.bfsd.common.BFLLoggerComponent.CONTROLLER;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerHeader;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.usermanagement.bean.BfsdRoleMasterResponse;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.bean.UserProfileDetails;
import com.bajaj.bfsd.usermanagement.bean.UserRoleBean;
import com.bajaj.bfsd.usermanagement.beanmapper.BeanMapper;
import com.bajaj.bfsd.usermanagement.service.UserManagementService;
import com.bfl.common.exceptions.BFLBusinessException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;


@RestController
public class RoleInformationController extends BFLController{
	
	/**@Inject
    @RequestScoped*/
    @Autowired
    BFLLoggerUtil logger;
	@Autowired
	Environment env;
	@Autowired
	BeanMapper beanMapper;
	@Autowired
	UserManagementService userManagementService;
	
	
	private static final String CLASS_NAME = RoleInformationController.class.getCanonicalName();

	
	/**
	 * @Desc this is to fetch user role  info of the user
	 *  @param userKey
	 * @param rolekey
	 * @param headers
	 * @return ResponseEntity
	 * @throws BFLBusinessException
	 */
	@ApiOperation(value = "Get user roles Information", notes = "Get user roles Information", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.userroles.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserRoleInfo(@PathVariable("userKey") Long userKey,@PathVariable("roleKey") Long roleKey,
			@RequestHeader HttpHeaders headers) {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : Fetch  getUserRoleInfo  invoked");
		UserRoleBean userRoleBean = new UserRoleBean();
		try {
			userRoleBean = userManagementService.getUserRoleInfo(userKey,roleKey);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getUserRoleInfo method ends");
		} catch (Exception exception) {
			logger.error(CLASS_NAME, CONTROLLER, "Invalid data " + userKey +" - "+ roleKey);
			throw new BFLBusinessException("USMA_000", env.getProperty("USMA_000"));

		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : getUserRoleInfo execution completed");
		return new ResponseEntity<>(new ResponseBean(userRoleBean), HttpStatus.OK);
	}
	
	
	@ApiOperation(value = "Get user profile Information", notes = "Get user profile Information", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.userprofiles.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserInfo(@PathVariable("userKey") Long userKey,@RequestParam("isPrinciple") String isPrinciple,
			@RequestParam(name = "isUserkey", required = false) String isUserkey,@RequestHeader HttpHeaders headers) {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : Fetch  getUserProfileInfo  invoked");
		List<UserName> userNameBean = new ArrayList<>();
		try {
			userNameBean = userManagementService.getUserInfo(userKey,Boolean.parseBoolean(isPrinciple),Boolean.parseBoolean(isUserkey));
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getUserProfileInfo method ends");
		} catch (Exception exception) {
			logger.error(CLASS_NAME, CONTROLLER, "Invalid data " + userKey );
			throw new BFLBusinessException("USMA_000", env.getProperty("USMA_000"));

		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : getUserProfileInfo execution completed");
		return new ResponseEntity<>(new ResponseBean(userNameBean), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get user profile Information by EmailID", notes = "Get user profile Information by EmailID", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.userprofile.useremail.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserInfoByEmail(@PathVariable("userEmail") String userEmail,@RequestHeader HttpHeaders headers) {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : Fetch  getUserProfileInfo  invoked");
		List<UserRoleBean> userRoleList = new ArrayList<>();
		try {
			userRoleList = userManagementService.getUserInfoByEmail(userEmail);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getUserProfileInfo method ends");
		} catch (Exception exception) {
			logger.error(CLASS_NAME, CONTROLLER, "Invalid data " + userEmail);
			throw new BFLBusinessException("USMA_000", env.getProperty("USMA_000"));

		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : getUserProfileInfo execution completed");
		return new ResponseEntity<>(new ResponseBean(userRoleList), HttpStatus.OK);
	}

	@ApiOperation(value = "Get role master detail by role key", notes = "Get role master detail by role key", httpMethod = "GET")
	@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.rolemaster.GET.uri}")
	@CrossOrigin
	public ResponseEntity<?> getRoleMasterByRoleKey(@PathVariable("rolekey") String roleKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : Fetch  getRoleMasterByRoleKey  invoked");
		BfsdRoleMasterResponse bfsdRoleMasterResponse = null;
		try {
			bfsdRoleMasterResponse = userManagementService.getRoleMasterByRoleKey(roleKey);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getRoleMasterByRoleKey method ends");
		} catch (Exception exception) {
			logger.error(CLASS_NAME, CONTROLLER, "Invalid data " + roleKey);
			throw new BFLBusinessException("USMA_000", env.getProperty("USMA_000"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : getRoleMasterByRoleKey execution completed");
		return new ResponseEntity<>(bfsdRoleMasterResponse, HttpStatus.OK);
	}

	@ApiOperation(value = "Get user profile detail by rolekeys and userkey", notes = "Get user profile detail by rolekeys and userkey", httpMethod = "GET")
	@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.userprofiles.roles.GET.uri}")
	@CrossOrigin
	public ResponseEntity<?> getUserProfilesByRoleKeys(@PathVariable("rolekeys") List<Long> roleKeyList,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : Fetch  getUserProfilesByRoleKeys  invoked");
		List<UserProfileDetails> userProfileDetails = new ArrayList<>();
		try {
			userProfileDetails = userManagementService.getUserProfilesByRoleKeys(roleKeyList);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getUserProfilesByRoleKeys method ends");
		} catch (Exception exception) {
			logger.error(CLASS_NAME, CONTROLLER, "Invalid data " + roleKeyList);
			throw new BFLBusinessException("USMA_000", env.getProperty("USMA_000"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : getUserProfilesByRoleKeys execution completed");
		return new ResponseEntity<>(userProfileDetails, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get user profile Information by ADID", notes = "Get user profile Information by ADID", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.userprofile.useradid.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserInfoByAdId(@PathVariable("userAdId") String useradId,@RequestHeader HttpHeaders headers) {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : Fetch  getUserInfoByAdId  invoked");
		List<UserRoleBean> userRoleList = new ArrayList<>();
		try {
			userRoleList = userManagementService.getUserInfoByAdId(useradId);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getUserInfoByAdId method ends");
		} catch (Exception exception) {
			logger.error(CLASS_NAME, CONTROLLER, "Invalid data " + useradId);
			throw new BFLBusinessException("USMA_000", env.getProperty("USMA_000"));

		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : getUserProfileInfo execution completed");
		return new ResponseEntity<>(new ResponseBean(userRoleList), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get user details by user role key", notes = "Get user details by user role key", httpMethod = "GET")
	@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.usersrole.mapping.GET.uri}")
	@CrossOrigin
	public ResponseEntity<?> getUserNameBeanByUserRoleKey(@PathVariable Long userRoleKey, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleInformationController : getUserNameBeanByUserRoleKey invoked");
		UserRoleBean userRoleBean = new UserRoleBean();
		try {
			userRoleBean = userManagementService.getUserNameBeanByUserRoleKey(userRoleKey);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getUserNameBeanByUserRoleKey method ends");
		} catch (Exception exception) {
			logger.error(CLASS_NAME, CONTROLLER, "Invalid data " + userRoleKey);
			throw new BFLBusinessException("USMA_000", env.getProperty("USMA_000"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleInformationController : getUserNameBeanByUserRoleKey execution completed");
		return new ResponseEntity<>(userRoleBean, HttpStatus.OK);
	}
}
