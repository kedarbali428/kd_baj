package com.bajaj.bfsd.usermanagement;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bajaj.bfsd.common.baseclasses.BFLConfiguration;

@RefreshScope
@Configuration
public class LdapConfiguration extends BFLConfiguration{

	@Autowired
	LdapPropertiesConfigurer ldapPropertiesConfigurer;

	@RefreshScope
	@Bean
	public DirContext ldapTemplate() throws NamingException {
		return ldapContextSource();
	}

	public DirContext ldapContextSource() throws NamingException {

		Properties properties = new Properties();
		properties.put(Context.INITIAL_CONTEXT_FACTORY, ldapPropertiesConfigurer.getLdapFactClass());
		properties.put(Context.PROVIDER_URL,ldapPropertiesConfigurer.getLdapUrl());
		properties.put(Context.SECURITY_AUTHENTICATION, ldapPropertiesConfigurer.getLdapSecAuthType());
		properties.put(Context.SECURITY_PRINCIPAL, ldapPropertiesConfigurer.getLdapSecPrincipal());
		properties.put(Context.SECURITY_CREDENTIALS, ldapPropertiesConfigurer.getLdapUserPwd());
		properties.put(Context.REFERRAL, "ignore");
		return new InitialDirContext(properties);

	}

}
