package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="USER_ADDL_ATTRIBUTES" , schema="ORGSYSADM")
public class UserAddlAttributes implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long useraddlattrkey;

	private Long attrrkey;

	private String attrkeytype;

	private String attrcode;

	private String attrvalue;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;
	

	public Long getAttrrkey() {
		return attrrkey;
	}

	public void setAttrrkey(Long attrrkey) {
		this.attrrkey = attrrkey;
	}

	public String getAttrkeytype() {
		return attrkeytype;
	}

	public void setAttrkeytype(String attrkeytype) {
		this.attrkeytype = attrkeytype;
	}

	public String getAttrcode() {
		return attrcode;
	}

	public void setAttrcode(String attrcode) {
		this.attrcode = attrcode;
	}

	public String getAttrvalue() {
		return attrvalue;
	}

	public void setAttrvalue(String attrvalue) {
		this.attrvalue = attrvalue;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}


}