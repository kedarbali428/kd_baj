/**
 * 
 */
package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;

/**
 * @author bflrdpuser1
 *
 */
public class UserApplicationProfile implements Serializable {
	private static final long serialVersionUID = -9000508502014030772L;
	
	private Long applicationApplicantId;
	private String appProcessId;

	public Long getApplicationApplicantId() {
		return applicationApplicantId;
	}
	public void setApplicationApplicantId(Long applicationApplicantId) {
		this.applicationApplicantId = applicationApplicantId;
	}
	public String getAppProcessId() {
		return appProcessId;
	}
	public void setAppProcessId(String appProcessId) {
		this.appProcessId = appProcessId;
	}
	
}
