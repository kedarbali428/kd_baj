package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the APP_USER_VIEW database table.
 * 
 */
@Entity
@Table(name="APP_USER_VIEW")
//@NamedQuery(name="AppUserView.findAll", query="SELECT a FROM AppUserView a")
public class AppUserView implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long userviewkey;

	private BigDecimal isactive;

	private String latupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to AppRoleView
	@ManyToOne
	@JoinColumn(name="VIEWROLEKEY")
	private AppRoleView appRoleView;

	//bi-directional many-to-one association to UserRole
	@ManyToOne
	@JoinColumn(name="USERROLEKEY")
	private UserRole userRole;

	public long getUserviewkey() {
		return this.userviewkey;
	}

	public void setUserviewkey(long userviewkey) {
		this.userviewkey = userviewkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLatupdateby() {
		return this.latupdateby;
	}

	public void setLatupdateby(String latupdateby) {
		this.latupdateby = latupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public AppRoleView getAppRoleView() {
		return this.appRoleView;
	}

	public void setAppRoleView(AppRoleView appRoleView) {
		this.appRoleView = appRoleView;
	}

	public UserRole getUserRole() {
		return this.userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

}