package com.bajaj.bfsd.usermanagement.bean;

import java.util.List;

public class ProductBean {

	private Long loanProduct;
	private List<Long> loanProductType;

	public Long getLoanProduct() {
		return loanProduct;
	}

	public void setLoanProduct(Long loanProduct) {
		this.loanProduct = loanProduct;
	}

	public List<Long> getLoanProductType() {
		return loanProductType;
	}

	public void setLoanProductType(List<Long> loanProductType) {
		this.loanProductType = loanProductType;
	}
}
