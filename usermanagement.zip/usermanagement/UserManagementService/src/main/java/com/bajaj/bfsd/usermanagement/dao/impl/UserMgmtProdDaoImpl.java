package com.bajaj.bfsd.usermanagement.dao.impl;

import static com.bajaj.bfsd.common.BFLLoggerComponent.UTILITY;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_2;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_4;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_5;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_6;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_7;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.dao.UserMgmtProdDao;
import com.bajaj.bfsd.usermanagement.helper.UserManagementHelper;
import com.bajaj.bfsd.usermanagement.model.BfsdRoleMaster;
import com.bajaj.bfsd.usermanagement.model.ProductMaster;
import com.bajaj.bfsd.usermanagement.model.UserRoleL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleLocationL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleProductL3;
import com.bajaj.bfsd.usermanagement.model.UtmSourceChannelMaster;
import com.bajaj.bfsd.usermanagement.util.QueryConstants;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.bfsd.usermanagement.util.UserManagementUtility;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RefreshScope
@Repository
public class UserMgmtProdDaoImpl extends BFLComponent implements UserMgmtProdDao {

	public static final String UMS_024 = "UMS-024";
	@Autowired
	EntityManager entityManager;

	@Autowired
	Environment environment;

	@Autowired
	EntityManagerFactory entityManagerFactory;

	@Autowired
	UserProfileBean upb;

	@Autowired
	UserManagementDaoImpl userManagementDao;

	@Autowired 
	UserManagementHelper userManagementHelper;
	
	@Autowired
	BFLLoggerUtil logger;
	
	@Override
	public List<UserRoleProductL3> getUserProdMapping(Long userRoleKey, Long loanProdKey, Long prodMastKey) {
		List<UserRoleProductL3> result = new ArrayList<>();
		userManagementDao.logMessage(DAO_6);
		try {
			Query query = entityManager.createQuery(QueryConstants.QRY_GET_USER_ROLE_PROD);
			query.setParameter(QueryConstants.QRY_PARAM_USER_ROLE_KEY, userRoleKey);
			query.setParameter(QueryConstants.QRY_PARAM_SUB_PROD_KEY, loanProdKey);
			query.setParameter(QueryConstants.QRY_PARAM_PROD_MAST_KEY, prodMastKey);
			result = query.getResultList();

		} catch (PersistenceException e) {
			userManagementDao.logMessage("" + e);
			userManagementDao.logMessage(DAO_2);
		}
		userManagementDao.logMessage(DAO_7);
		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SupervisorBean> getUserSuperVisor(long roleKey, long prodKey,long subProdKey) {
		List<SupervisorBean> userList = new ArrayList<>();

		BfsdRoleMaster roleMaster = userManagementDao.getEntity(BfsdRoleMaster.class, roleKey);
		if (roleMaster == null) {
			throw new BFLBusinessException("UMS-006", environment.getProperty("UMS-006"));
		}

		if (roleMaster.getBfsdRoleMaster() == null) {
			SupervisorBean user = new SupervisorBean();
			user.setHighestRole(true);
			userList.add(user);
		} else {
			Query nativeQuery = entityManager.createNativeQuery(" SELECT  "
					+ " urp.USERPRODKEY, ur.USERROLEKEY, up.firstname || ' ' || up.lastname FROM user_roles ur, "
					+ " user_role_product urp , user_profiles up WHERE ur.rolekey IN (SELECT rolekey "
					+ " FROM bfsd_role_master rm WHERE rm.systemroleflg= 0 AND rm.isactive= 1 AND level > 1 START WITH rm.ROLEKEY= :roleKey "
					+ " CONNECT BY prior rm.PARENTROLE = rm.rolekey) AND urp.userrolekey = ur.userrolekey AND urp.prodmastkey = :prodMasterKey "
					+ " AND urp.subprodkey  = :subProdKey  AND ur.userkey= up.userkey AND up.isactive= 1 ");

			nativeQuery.setParameter("roleKey", roleKey);
			nativeQuery.setParameter("prodMasterKey", prodKey);
			nativeQuery.setParameter("subProdKey", subProdKey);

			List<Object[]> authors = nativeQuery.getResultList();
			if (authors != null && !authors.isEmpty()) {

				for (Object[] a : authors) {
					SupervisorBean user = new SupervisorBean();
					user.setId(((BigDecimal) a[0]).longValue());
					user.setUserRoleProdKey(((BigDecimal) a[0]).longValue());
					user.setUserRoleKey(((BigDecimal) a[1]).longValue());
					user.setName((String) a[2]);
					userList.add(user);
				}
			} else {
				// No Supervisor exist for above role
				throw new BFLBusinessException("UMS-020", environment.getProperty("UMS-020"));
			}
		}

		return userList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getUserRoleProductsByUserKey(long userKey) {
		List<Object[]> result = new ArrayList<>();
		userManagementDao.logMessage(DAO_4);
		try {
			Query query = entityManager.createNativeQuery(QueryConstants.QRY_GET_USER_ROLE_PROD_BY_USERKEY);
			query.setParameter(QueryConstants.QRY_PARAM_USERKEY, userKey);
			result = query.getResultList();
		} catch (PersistenceException e) {
			userManagementDao.logMessage(DAO_2 + "" + e);
		}

		userManagementDao.logMessage(DAO_5);
		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<LocationBean> getSuperVisorLocations(long userRoleProdKey) {

		List<LocationBean> userList = new ArrayList<>();
		Query nativeQuery;
		if (userRoleProdKey == 0L) {
			nativeQuery = entityManager.createNativeQuery(
					" SELECT DISTINCT B.BFLBRANCHKEY,B.BFLBRANCHNAME FROM USER_ROLES U,USER_ROLE_PRODUCT URP,USER_ROLE_LOCATIONS L,BFL_BRANCHES B WHERE U.USERROLEKEY=URP.USERROLEKEY AND URP.USERPRODKEY=L.USERPRODKEY AND B.BFLBRANCHKEY=L.BFLBRANCHKEY AND U.ISACTIVE=1 AND L.ISACTIVE=1 AND B.BFLBRANCHISACTIVE=1 order by B.BFLBRANCHNAME ");
		} else {
			nativeQuery = entityManager.createNativeQuery(
					" SELECT DISTINCT B.BFLBRANCHKEY,B.BFLBRANCHNAME FROM USER_ROLES U,USER_ROLE_PRODUCT URP,USER_ROLE_LOCATIONS L,BFL_BRANCHES B WHERE U.USERROLEKEY=URP.USERROLEKEY AND URP.USERPRODKEY=L.USERPRODKEY AND B.BFLBRANCHKEY=L.BFLBRANCHKEY AND U.ISACTIVE=1 AND L.ISACTIVE=1 AND B.BFLBRANCHISACTIVE=1 and L.USERPRODKEY=:userRoleProdKey order by B.BFLBRANCHNAME ");
			nativeQuery.setParameter(QueryConstants.QRY_PARAM_USER_ROLE_PROD_KEY, userRoleProdKey);
		}

		List<Object[]> bFlBranches = nativeQuery.getResultList();
		bflBranchMapper(userList, bFlBranches);
		return userList;
	}

	private void bflBranchMapper(List<LocationBean> userList, List<Object[]> bFlBranches) {
		if (bFlBranches != null && !bFlBranches.isEmpty()) {

			for (Object[] a : bFlBranches) {
				LocationBean bflBranchBn = new LocationBean();
				bflBranchBn.setId(((BigDecimal) a[0]).longValue());
				bflBranchBn.setName((String) a[1]);
				userList.add(bflBranchBn);
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ChannelBean> getSuperVisorChannels(long userRoleProdKey) {

		List<ChannelBean> supervisorChannelList = new ArrayList<>();
		Query nativeQuery;

		if (userRoleProdKey == 0L) {
			nativeQuery = entityManager.createNativeQuery(
					"select DISTINCT C.CHANNELTYPEKEY, C.CHANNETYPEDESC from CHANNEL_TYPES C INNER JOIN USER_ROLE_CHANNELS URC ON C.CHANNELTYPEKEY = URC.CHANNELTYPEKEY INNER JOIN USER_ROLE_PRODUCT URP ON  URC.USERPRODKEY = URP.USERPRODKEY INNER JOIN USER_ROLES UR ON  UR.USERROLEKEY=URP.USERROLEKEY order by C.CHANNETYPEDESC ");
		} else {

			nativeQuery = entityManager.createNativeQuery(
					" select DISTINCT C.CHANNELTYPEKEY, C.CHANNETYPEDESC from CHANNEL_TYPES C INNER JOIN USER_ROLE_CHANNELS URC ON C.CHANNELTYPEKEY = URC.CHANNELTYPEKEY INNER JOIN USER_ROLE_PRODUCT URP ON  URC.USERPRODKEY = URP.USERPRODKEY INNER JOIN USER_ROLES UR ON  UR.USERROLEKEY=URP.USERROLEKEY WHERE URP.USERPRODKEY= :userRoleProdKey order by C.CHANNETYPEDESC ");
			nativeQuery.setParameter(QueryConstants.QRY_PARAM_USER_ROLE_PROD_KEY, userRoleProdKey);
		}

		List<Object[]> channels = nativeQuery.getResultList();
		if (channels.isEmpty()) {
			nativeQuery = entityManager.createNativeQuery(
					"select DISTINCT C.CHANNELTYPEKEY, C.CHANNETYPEDESC from CHANNEL_TYPES C INNER JOIN USER_ROLE_CHANNELS URC ON C.CHANNELTYPEKEY = URC.CHANNELTYPEKEY INNER JOIN USER_ROLE_PRODUCT URP ON  URC.USERPRODKEY = URP.USERPRODKEY INNER JOIN USER_ROLES UR ON  UR.USERROLEKEY=URP.USERROLEKEY order by C.CHANNETYPEDESC ");
			channels = nativeQuery.getResultList();
		}
		if (channels != null && !channels.isEmpty()) {

			for (Object[] a : channels) {
				ChannelBean channelBean = new ChannelBean();
				channelBean.setId(((BigDecimal) a[0]).longValue());
				channelBean.setName((String) a[1]);
				supervisorChannelList.add(channelBean);
			}
		}
		return supervisorChannelList;
	}


	@SuppressWarnings("unchecked")
	@Override
	public UserRoleL3 fetchUserRole(long userKey, long roleKey) {
		Query query = entityManager.createNamedQuery("UserRoleL3.findByEmployeeAndRole");
		query.setParameter(UserManagementConstants.PARAM_ROLE_KEY, roleKey);
		query.setParameter(UserManagementConstants.PARAM_USER_KEY, userKey);

		List<UserRoleL3> userRoles = query.getResultList();

		if (userRoles != null && !userRoles.isEmpty()) {
			return userRoles.get(0);
		}
		return null;
	}

	@Override
	@Transactional
	public UserRoleL3 saveUserMapping(UserRoleL3 userRole) {
		UserRoleL3 mergedUserRole = null;
		try {
			mergedUserRole = entityManager.merge(userRole);
			userManagementHelper.createEventMessageMapping(UserManagementConstants.USERROLE_MAPPING_EVENT_CREATED,
					mergedUserRole, logger);
			entityManager.flush();
			return mergedUserRole;
		} catch (Exception e) {
			userManagementDao.logMessage("" + e);
		}
		return mergedUserRole;
	}

	@SuppressWarnings("unchecked")
	@Override
	public UserConfigurationBean getUserDetails(UserConfigurationBean userConfig, HttpHeaders headers) {

		UserConfigurationBean userConfigBean = new UserConfigurationBean();
		if (StringUtils.isNotBlank(userConfig.getEmployeeType())
				&& (userConfig.getEmployeeType().equalsIgnoreCase(UserManagementConstants.VENDOR_COMPANY)
						|| userConfig.getEmployeeType().equalsIgnoreCase(UserManagementConstants.VENDOR_INDIVIDUAL ) 
						|| userConfig.getEmployeeType().equalsIgnoreCase(UserManagementConstants.DEALER)
						|| userConfig.getEmployeeType().equalsIgnoreCase(UserManagementConstants.PRINCIPAL_USER))) {
			userManagementDao.getUserVendorDetails(userConfig, userConfigBean, true, headers);
			userConfigBean.setStatusIfExist(true);

		} else {
			Query nativeQry = entityManager.createNativeQuery(
					"select  USERKEY, FIRSTNAME, LASTNAME ,EMAILID, MOBILENO, DESIGNATION, ISACTIVE from  USER_PROFILES where EMAILID = :emailId and ISACTIVE=1 and  LSTUPDATEDT = (select max(LSTUPDATEDT) from USER_PROFILES where EMAILID = :emailId and ISACTIVE=1)");
			nativeQry.setParameter("emailId", userConfig.getEmailId());

			List<Object[]> authors = nativeQry.getResultList();
			if (authors != null && !authors.isEmpty()) {
				return userManagementDao.mapUserProfile(authors, true, headers);

			} else {
				userManagementDao.getUserEmpDetails(userConfig, userConfigBean);
			}
		}
		return userConfigBean;
	}

	@Override
	public <T> T getEntity(Class<T> clazz, Long key) {
		return entityManager.find(clazz, key);
	}

	boolean saveLocation(long userRoleProdKey, List<Long> keyList) {

		boolean result = false;
		
		List<Long> exisingKeyList = new ArrayList<>();
		UserRoleProductL3 userRoleProductL3 = getEntity(UserRoleProductL3.class, userRoleProdKey);
		try {
			Query nativeQuery = entityManager.createNativeQuery(
					"SELECT BFLBRANCHKEY from USER_ROLE_LOCATIONS where USERPRODKEY= :userRoleProdKey ");
			nativeQuery.setParameter(QueryConstants.QRY_PARAM_USER_ROLE_PROD_KEY, userRoleProdKey);
			exisingKeyList = nativeQuery.getResultList();

			List<Long> newKeyList = new ArrayList<>();
			List<Long> deleteKeyList = new ArrayList<>();
						if (exisingKeyList.isEmpty()) {
				newKeyList = keyList;
			} else {
				for (Long key : keyList) {
					setKeyList(exisingKeyList, newKeyList, key);
				}
				deleteKeyList = exisingKeyList;
			}
			UserRoleLocationL3 userRoleLocation;
			if (!newKeyList.isEmpty()) {
				for (Long key : newKeyList) {
					userRoleLocation = new UserRoleLocationL3();
					userRoleLocation.setBflbranchkey(key);
					userRoleLocation.setIsactive(1);
					userRoleLocation.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
					userRoleLocation.setUserRoleProduct(userRoleProductL3);
					userRoleLocation.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
					entityManager.persist(userRoleLocation);
				}
			}
			entityManager.flush();
			entityManager.clear();

			if (!deleteKeyList.isEmpty()) {
				Query qry = entityManager.createNativeQuery(
						"DELETE from USER_ROLE_LOCATIONS where USERPRODKEY= :userRoleProdKey and BFLBRANCHKEY in ("
								+ this.getInValuesStr(deleteKeyList.toString()) + ")");
				int isUpdated = qry.executeUpdate();
				if (isUpdated < 0) {
					throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
				}
			}
			result = true;
		} catch (Exception e) {
			userManagementDao.logMessage("" + e);
			result = false;
		}

		return result;
	}

	private void setKeyList(List<Long> exisingKeyList, List<Long> newKeyList, Long key) {
		if (!exisingKeyList.contains(key)) {
			newKeyList.add(key);
			exisingKeyList.remove(key);
		}
	}

	private String getInValuesStr(String inValuesStr) {
		return inValuesStr.substring(1, inValuesStr.length() - 1);
	}

	@Override
	public List<Long> getAllLocations() {
		List<Long> keys = new ArrayList<>();
		Query nativeQuery = entityManager
				.createNativeQuery("SELECT BFLBRANCHKEY FROM BFL_BRANCHES where BFLBRANCHISACTIVE=1");
		List<Object[]> branchKeyList = nativeQuery.getResultList();
		if (branchKeyList != null && !branchKeyList.isEmpty()) {
			for (Object a : branchKeyList) {
				keys.add(((BigDecimal) a).longValue());
			}
		}
		return keys;
	}

	@Override
	public List<Long> getAllChannels() {
		List<Long> keys = new ArrayList<>();
		Query nativeQuery = entityManager
				.createNativeQuery("SELECT CHANNELTYPEKEY FROM CHANNEL_TYPES where ISACTIVE=1");
		List<Object[]> branchKeyList = nativeQuery.getResultList();
		if (branchKeyList != null && !branchKeyList.isEmpty()) {
			for (Object a : branchKeyList) {
				keys.add(((BigDecimal) a).longValue());
			}
		}
		return keys;
	}

	@Override
	public List<Long> getPincodesByLoc(List<Long> branchKeyList) {
		List<Long> keys = new ArrayList<>();
		String branchList=branchKeyList.toString().substring(1,branchKeyList.toString().length()-1);
		Query nativeQuery = entityManager.createNativeQuery(
				"SELECT PN.PINCODEKEY FROM PIN_CODE_MASTER PN WHERE PN.CITYKEY IN(SELECT BR.CITYKEY FROM BFL_BRANCHES BR WHERE BR.BFLBRANCHKEY in (:bflBranchKeyList))");
		nativeQuery.setParameter("bflBranchKeyList", branchList);
		List<Object[]> pinCodes = nativeQuery.getResultList();
		if (pinCodes != null && !pinCodes.isEmpty()) {
			for (Object a : pinCodes) {
				keys.add(((BigDecimal) a).longValue());
			}
		}
		return keys;
	}
	
	@Override
	public List<Object[]> getUserProfileByUserKey(long userKey) {
		List<Object[]> userProfiles=new ArrayList<>();
		userManagementDao.logMessage(DAO_6);
		try {
			Query query = entityManager.createNativeQuery(QueryConstants.QRY_GET_USER_FIRST_AND_LAST_NAME);
			query.setParameter(QueryConstants.QRY_PARAM_USERKEY, userKey);
			userProfiles = query.getResultList();
		} catch (PersistenceException e) {
			userManagementDao.logMessage("" + e);
			userManagementDao.logMessage(DAO_2);
		}
		userManagementDao.logMessage(DAO_7);
		return userProfiles;
	}
	
	@Override
	@Transactional
	public boolean deleteUserMapping(UserRoleL3 userRole) {
		boolean isDeleted=false;
	
		try {
			entityManager.remove(userRole);
			entityManager.flush();
			isDeleted=true;

		} catch (Exception e) {
			userManagementDao.logMessage("" + e);
		}
		return isDeleted;
	}
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public boolean getSupervisor(long userRoleProdKey) {
		boolean isSupervisor=false;
		List<Object[]> userRoleProducts=new ArrayList<>();
		try {
			
			userRoleProducts= entityManager.createNativeQuery(QueryConstants.QRY_TO_GET_CHECK_SUPERVISOR)
					.setParameter("userprodkey", userRoleProdKey).getResultList();
			if(userRoleProducts!=null && !userRoleProducts.isEmpty()){
				isSupervisor=true;
			}
		} catch (Exception e) {
			userManagementDao.logMessage("" + e);
		}
		return isSupervisor;
	}
	
	@Override
	public List<UtmSourceChannelMaster> getUTMSourceMapping(List<Long> utmMastKey) {
		List<UtmSourceChannelMaster> result = new ArrayList<>();
		userManagementDao.logMessage("Start DaoImpl for getUTMSourceMapping");
		try {
			Query query = entityManager.createQuery(QueryConstants.QRY_GET_UTM_SOURCE);
			query.setParameter(QueryConstants.QRY_PARAM_UTM_SOURCE, utmMastKey);
			
			result = query.getResultList();

		} catch (PersistenceException e) {
			userManagementDao.logMessage("" + e);
			userManagementDao.logMessage(DAO_2);
		}
		userManagementDao.logMessage("End DaoImpl for getUTMSourceMapping");
		return result;
	}

	@Override
	public UserRoleL3 findUserRoleKey(long userrolekey) {
		List<UserRoleL3> result = new ArrayList<>();
		userManagementDao.logMessage("Start DaoImpl for findUserRoleKey");
		try {
			Query query = entityManager.createQuery(QueryConstants.GET_USER_ROLE_OM);
			query.setParameter(QueryConstants.USER_ROLE_KEY, userrolekey);
			result = query.getResultList();

		} catch (PersistenceException e) {
			userManagementDao.logMessage("" + e);
			userManagementDao.logMessage(DAO_2);
		}
		userManagementDao.logMessage("End DaoImpl for findUserRoleKey");
		if(!result.isEmpty()) {
			return result.get(0);	
		}else {
			return null;
		}
	}

	@Override
	public List<ProductMaster> findAllMasterProducts() {
		List<ProductMaster> productMasterList = entityManager.createNamedQuery("ProductMaster.findActive")
				.getResultList();
		return productMasterList;
	}

	@Override
	public UserConfigurationBean getAdditionalUserDetails(UserConfigurationBean userConfig) {
		try {
			Query nativeQry = entityManager.createNativeQuery(
					"select  * from  ORGSYSADM.USER_ADDL_ATTRIBUTES where attrrkey = :attrKey and ISACTIVE=1");
			nativeQry.setParameter("attrKey", userConfig.getUserKey());
			List<Object[]> attributeList = nativeQry.getResultList();
			List<String> skills = new ArrayList<>();
			List<String> specializations = new ArrayList<>();
			List<String> paymentModes = new ArrayList<>();
			List<String> channels = new ArrayList<>();

			
			if (!CollectionUtils.isEmpty(attributeList)) {
				for(Object[] data : attributeList) {
					if ("SPCODE".equalsIgnoreCase(data[3].toString())) {
						userConfig.setSpCode(data[4].toString());
					} else if ("LPCODE".equalsIgnoreCase(data[3].toString())) {
						userConfig.setLpCode(data[4].toString());
					} else if ("MAX_SUM_ASSUR_LIMIT".equalsIgnoreCase(data[3].toString())) {
						userConfig.setMaxSumAssuredLimit(data[4].toString());
					} else if ("MAX_PREMIUM_LIMIT".equalsIgnoreCase(data[3].toString())) {
						userConfig.setMaxPremiumLimit(data[4].toString());
					} else if ("SPECIALIZATION".equalsIgnoreCase(data[3].toString())) {
						specializations.add(data[4].toString());
					} else if ("SKILLS".equalsIgnoreCase(data[3].toString())) {
						skills.add(data[4].toString());
					} else if ("PAYMENT_MODES_ALLOW".equalsIgnoreCase(data[3].toString())) {
						paymentModes.add(data[4].toString());
					}else if ("CHANNEL".equalsIgnoreCase(data[3].toString())) {
						channels.add(data[4].toString());
					}else if ("POTYPE".equalsIgnoreCase(data[3].toString())) {
						userConfig.setPoType(data[4].toString());;
}
				}
				userConfig.setSkills(skills);
				userConfig.setSpecialization(specializations);
				userConfig.setPaymentModes(paymentModes);
				userConfig.setChannel(channels);

			} 
			
			nativeQry = entityManager.createNativeQuery(
					"select  * from  BFSD_USERS where userkey = :userKey and ISACTIVE=1");
			nativeQry.setParameter("userKey", userConfig.getUserKey());
			Long rprtMgrUserKey = null;
			List<Object[]> userData = nativeQry.getResultList();
			if (!CollectionUtils.isEmpty(userData)) {
				for (Object[] user : userData) {
					rprtMgrUserKey = null != user[13] ? Long.valueOf(user[13].toString()) : null;
				}
			}
			if(null != rprtMgrUserKey)
			{
				userConfig.setReportingManagerKey(rprtMgrUserKey);
				Query query = entityManager.createQuery(QueryConstants.FETCH_REPORTING_MANAGER_BY_USERKEY);
				query.setParameter("userKey", rprtMgrUserKey);
				String reportingManagerName = null;
				if(!query.getResultList().isEmpty()) {
					reportingManagerName = query.getResultList().get(0).toString();
					userConfig.setReportingManager(reportingManagerName);
				}
			}
	
		} catch (Exception exception) {
			userManagementDao.logMessage("Exception while fetching user details : " + exception);
			throw new BFLTechnicalException(UMS_024, "Technical exception while fetching user details : " + exception);
		}
		return userConfig;

	}

	@Override
	public List<Object[]> loadUserData() {
		try {
		Query query = entityManager.createQuery(QueryConstants.FETCH_ALL_REPORTING_MANAGERS);
		List<Object[]> reportingManagers = query.getResultList();
		return reportingManagers;
		} catch (Exception exception) {
			userManagementDao.logMessage("Exception while loading user details : " + exception);
			throw new BFLTechnicalException(UMS_024, "Technical exception while loading user details : " + exception);
		}

	}
	
}