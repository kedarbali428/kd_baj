package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;

public class ChangePasswordRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String password;
	private String oldPassword;
	private String authToken;
	private long contactType;
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public long getContactType() {
		return contactType;
	}

	public void setContactType(long contactType) {
		this.contactType = contactType;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
	
	

}
