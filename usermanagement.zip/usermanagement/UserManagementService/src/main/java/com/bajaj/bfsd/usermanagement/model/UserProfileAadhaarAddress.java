package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the USER_PROFILE_AADHAAR_ADDRESSES database table.
 * 
 */
@Entity
@Table(name="USER_PROFILE_AADHAAR_ADDRESSES")
//@NamedQuery(name="UserProfileAadhaarAddress.findAll", query="SELECT u FROM UserProfileAadhaarAddress u")
public class UserProfileAadhaarAddress implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long aadhaaraddrkey;

	private String addrline1;

	private String addrline2;

	private String addrtype;

	private String city;

	private String country;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private long pincode;

	private String state;

	//bi-directional many-to-one association to UserProfileAadhaar
	@ManyToOne
	@JoinColumn(name="AADHAARKEY")
	private UserProfileAadhaar userProfileAadhaar;

	public UserProfileAadhaarAddress() {
	}

	public long getAadhaaraddrkey() {
		return this.aadhaaraddrkey;
	}

	public void setAadhaaraddrkey(long aadhaaraddrkey) {
		this.aadhaaraddrkey = aadhaaraddrkey;
	}

	public String getAddrline1() {
		return this.addrline1;
	}

	public void setAddrline1(String addrline1) {
		this.addrline1 = addrline1;
	}

	public String getAddrline2() {
		return this.addrline2;
	}

	public void setAddrline2(String addrline2) {
		this.addrline2 = addrline2;
	}

	public String getAddrtype() {
		return this.addrtype;
	}

	public void setAddrtype(String addrtype) {
		this.addrtype = addrtype;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public long getPincode() {
		return this.pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public UserProfileAadhaar getUserProfileAadhaar() {
		return this.userProfileAadhaar;
	}

	public void setUserProfileAadhaar(UserProfileAadhaar userProfileAadhaar) {
		this.userProfileAadhaar = userProfileAadhaar;
	}

}