package com.bajaj.bfsd.usermanagement.util;

import java.nio.charset.StandardCharsets;
import java.security.DigestException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

public class UserManagementUtility {
	private static final String CLASS_NAME = UserManagementUtility.class.getCanonicalName();
	public static final String SQL_DATE_FORMAT = "yyyy-MM-dd";
	public static final String UMS_046 = "UMS-046";
	
	private UserManagementUtility() {
		
	}
	
	
	public static Timestamp getCurrentTimeStamp()
	{
		Instant instant = Instant.now();
		long timeStampMilliSeconds = instant.toEpochMilli();
		return new Timestamp(timeStampMilliSeconds);
	}



	
	public static Timestamp getCurrentDateTimeStamp() {
		Date date=Calendar.getInstance().getTime();
		return new Timestamp(date.getTime());
	}
	
	public static Date getEffectiveEndDate(BFLLoggerUtil logger) {
		
		try{
			String endDate = UserManagementConstants.DEFAULT_END_DATE;
			SimpleDateFormat sdf = new SimpleDateFormat(SQL_DATE_FORMAT);
			return sdf.parse(endDate);
		} catch(DateTimeParseException pex){
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,"Error in parsing effective end date : "+pex);
			return null;
		} catch(Exception ex){
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,"Error in parsing effective end date : "+ex);
			return null;
		}
	}
	
	public static String getHashedPassword(String password, BFLLoggerUtil logger){
		MessageDigest messageDigest;
		byte[] hashBytes;
		
		if(password == null){
			return null;
		}
		
		try {
			messageDigest = MessageDigest.getInstance("SHA-256");
			
		} catch (NoSuchAlgorithmException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "changePassword - unable to get instance for algorithm - "+e);
			throw new BFLTechnicalException("UMS-015",e);
		}
		hashBytes = messageDigest.digest(password.getBytes(StandardCharsets.UTF_8));
		StringBuilder hashValue = new StringBuilder();
        for(int i=0; i< hashBytes.length ;i++)
        {
        	hashValue.append(Integer.toString((hashBytes[i] & 0xff) + 0x100, 16).substring(1));
        }
		
		return hashValue.toString();
	}
	
	public static String decryptPassword(String secret, String value, BFLLoggerUtil logger){
		// Decrypt cipher
		
		String cipherText = value;

		try {
			byte[] cipherData = java.util.Base64.getDecoder().decode(cipherText);
			byte[] saltData = Arrays.copyOfRange(cipherData, 8, 16);

			MessageDigest md5 = MessageDigest.getInstance("MD5");
			final byte[][] keyAndIV = generateKeyAndIV(32, 16, 1, saltData, secret.getBytes(StandardCharsets.UTF_8), md5);
			SecretKeySpec key = new SecretKeySpec(keyAndIV[0], "AES");
			IvParameterSpec iv = new IvParameterSpec(keyAndIV[1]);

			byte[] encrypted = Arrays.copyOfRange(cipherData, 16, cipherData.length);
			Cipher aesCBC = Cipher.getInstance("AES/CBC/PKCS5Padding");
			aesCBC.init(Cipher.DECRYPT_MODE, key, iv);
			byte[] decryptedData = aesCBC.doFinal(encrypted);
			
			return new String(decryptedData, StandardCharsets.UTF_8);
		}
		catch (GeneralSecurityException ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "decryptPassword - unable to decrypt password - "+ex);
		}
		
		return "";


	}
	public static byte[][] generateKeyAndIV(int keyLength, int ivLength, int iterations, byte[] salt, byte[] password, MessageDigest md) 
			throws DigestException {

	    int digestLength = md.getDigestLength();
	    int requiredLength = (keyLength + ivLength + digestLength - 1) / digestLength * digestLength;
	    byte[] generatedData = new byte[requiredLength];
	    int generatedLength = 0;

	    
        md.reset();

        // Repeat process until sufficient data has been generated
        while (generatedLength < keyLength + ivLength) {

            // Digest data (last digest if available, password data, salt if available)
            if (generatedLength > 0)
                md.update(generatedData, generatedLength - digestLength, digestLength);
            md.update(password);
            if (salt != null)
                md.update(salt, 0, 8);
            md.digest(generatedData, generatedLength, digestLength);

            // additional rounds
            for (int i = 1; i < iterations; i++) {
                md.update(generatedData, generatedLength, digestLength);
                md.digest(generatedData, generatedLength, digestLength);
            }

            generatedLength += digestLength;
        }

        // Copy key and IV into separate byte arrays
        byte[][] result = new byte[2][];
        result[0] = Arrays.copyOfRange(generatedData, 0, keyLength);
        if (ivLength > 0)
            result[1] = Arrays.copyOfRange(generatedData, keyLength, keyLength + ivLength);

        return result;
	    
	}
	
	
	public static Date genrateDate(String date,BFLLoggerUtil logger) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy");
		DateTimeFormatter f = DateTimeFormatter.ofPattern("E MMM dd HH:mm:ss z uuuu").withLocale(Locale.US);
		try {
			ZonedDateTime zdt = ZonedDateTime.parse(date, f);
			LocalDate ld = zdt.toLocalDate();
			DateTimeFormatter fLocalDate = DateTimeFormatter.ofPattern("dd-MMM-uuuu");
			String output = ld.format(fLocalDate);
			return dateFormatter.parse(output);
		} catch (ParseException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Incorrect date of birth format");
		}
		return null;
	}
	
	public static void validateLoginID(String loginId, BFLLoggerUtil bflLoggerUtil, Environment environment) {
		if (!loginId.matches("^[a-zA-Z0-9@.\\-]+$")) {
			bflLoggerUtil.error(CLASS_NAME, BFLLoggerComponent.UTILITY,"Please check login id format");
			throw new BFLBusinessException(UMS_046,environment.getProperty(UMS_046));
		}

	}
	@SuppressWarnings("rawtypes")
	 public static JSONObject getJsonObject(Object object) {
		JSONObject jsonObject = new JSONObject();
		try {

			JSONParser parser = new JSONParser();
			if (object instanceof JSONObject) {
				jsonObject = (JSONObject) object;
			} else if (object instanceof LinkedHashMap) {
				jsonObject = new JSONObject((Map) object);
			} else {
				Object obj = parser.parse(object.toString());
				jsonObject = (JSONObject) obj;
			}

		} catch (Exception e) {
			//logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Error occurred while get Notification Response Json"+e);
		}
		return jsonObject;
	}
}
