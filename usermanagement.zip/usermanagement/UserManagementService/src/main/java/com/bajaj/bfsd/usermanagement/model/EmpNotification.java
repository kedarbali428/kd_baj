package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the EMP_NOTIFICATIONS database table.
 * 
 */
@Entity
@Table(name="EMP_NOTIFICATIONS")
//@NamedQuery(name="EmpNotification.findAll", query="SELECT e FROM EmpNotification e")
public class EmpNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long empnotificationkey;

	private Timestamp empnotfdeliverydt;

	private BigDecimal empnotfdeliveryflg;

	private String empnotfemailid;

	private BigDecimal empnotfisactive;

	private String empnotflstupdateby;

	private Timestamp empnotflstupdatedt;

	private String empnotfmessage;

	private String empnotfmobnum;

	private Timestamp empnotfreaddt;

	private BigDecimal empnotfreadflg;

	private Timestamp empnotfsentdt;

	private BigDecimal empnotfsentflg;

	private String empnotfsource;

	private String empnotfsourceuser;

	private BigDecimal emptnotfmode;

	//bi-directional many-to-one association to EmployeeRole
	@ManyToOne
	@JoinColumn(name="EMPROLEKEY")
	private EmployeeRole employeeRole;

	public long getEmpnotificationkey() {
		return this.empnotificationkey;
	}

	public void setEmpnotificationkey(long empnotificationkey) {
		this.empnotificationkey = empnotificationkey;
	}

	public Timestamp getEmpnotfdeliverydt() {
		return this.empnotfdeliverydt;
	}

	public void setEmpnotfdeliverydt(Timestamp empnotfdeliverydt) {
		this.empnotfdeliverydt = empnotfdeliverydt;
	}

	public BigDecimal getEmpnotfdeliveryflg() {
		return this.empnotfdeliveryflg;
	}

	public void setEmpnotfdeliveryflg(BigDecimal empnotfdeliveryflg) {
		this.empnotfdeliveryflg = empnotfdeliveryflg;
	}

	public String getEmpnotfemailid() {
		return this.empnotfemailid;
	}

	public void setEmpnotfemailid(String empnotfemailid) {
		this.empnotfemailid = empnotfemailid;
	}

	public BigDecimal getEmpnotfisactive() {
		return this.empnotfisactive;
	}

	public void setEmpnotfisactive(BigDecimal empnotfisactive) {
		this.empnotfisactive = empnotfisactive;
	}

	public String getEmpnotflstupdateby() {
		return this.empnotflstupdateby;
	}

	public void setEmpnotflstupdateby(String empnotflstupdateby) {
		this.empnotflstupdateby = empnotflstupdateby;
	}

	public Timestamp getEmpnotflstupdatedt() {
		return this.empnotflstupdatedt;
	}

	public void setEmpnotflstupdatedt(Timestamp empnotflstupdatedt) {
		this.empnotflstupdatedt = empnotflstupdatedt;
	}

	public String getEmpnotfmessage() {
		return this.empnotfmessage;
	}

	public void setEmpnotfmessage(String empnotfmessage) {
		this.empnotfmessage = empnotfmessage;
	}

	public String getEmpnotfmobnum() {
		return this.empnotfmobnum;
	}

	public void setEmpnotfmobnum(String empnotfmobnum) {
		this.empnotfmobnum = empnotfmobnum;
	}

	public Timestamp getEmpnotfreaddt() {
		return this.empnotfreaddt;
	}

	public void setEmpnotfreaddt(Timestamp empnotfreaddt) {
		this.empnotfreaddt = empnotfreaddt;
	}

	public BigDecimal getEmpnotfreadflg() {
		return this.empnotfreadflg;
	}

	public void setEmpnotfreadflg(BigDecimal empnotfreadflg) {
		this.empnotfreadflg = empnotfreadflg;
	}

	public Timestamp getEmpnotfsentdt() {
		return this.empnotfsentdt;
	}

	public void setEmpnotfsentdt(Timestamp empnotfsentdt) {
		this.empnotfsentdt = empnotfsentdt;
	}

	public BigDecimal getEmpnotfsentflg() {
		return this.empnotfsentflg;
	}

	public void setEmpnotfsentflg(BigDecimal empnotfsentflg) {
		this.empnotfsentflg = empnotfsentflg;
	}

	public String getEmpnotfsource() {
		return this.empnotfsource;
	}

	public void setEmpnotfsource(String empnotfsource) {
		this.empnotfsource = empnotfsource;
	}

	public String getEmpnotfsourceuser() {
		return this.empnotfsourceuser;
	}

	public void setEmpnotfsourceuser(String empnotfsourceuser) {
		this.empnotfsourceuser = empnotfsourceuser;
	}

	public BigDecimal getEmptnotfmode() {
		return this.emptnotfmode;
	}

	public void setEmptnotfmode(BigDecimal emptnotfmode) {
		this.emptnotfmode = emptnotfmode;
	}

	public EmployeeRole getEmployeeRole() {
		return this.employeeRole;
	}

	public void setEmployeeRole(EmployeeRole employeeRole) {
		this.employeeRole = employeeRole;
	}

}