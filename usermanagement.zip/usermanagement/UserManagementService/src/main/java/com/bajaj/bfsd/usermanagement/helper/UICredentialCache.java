package com.bajaj.bfsd.usermanagement.helper;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.dao.UserManagementDao;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.service.impl.UserManagementServiceImpl;
import com.bfl.common.exceptions.BFLBusinessException;

@Component
@RefreshScope
public class UICredentialCache {

	@Autowired
	Environment env;

	@Autowired
	UserManagementDao userManagementDao;

	private List<UserLoginAccount> userLoginAccountList;

	private Map<String, UserLoginAccount> userMapresult;
	
	@Autowired
	BFLLoggerUtil logger;
	
	private static final String CLASS_NAME = UICredentialCache.class.getCanonicalName();

	@PostConstruct
	public void initCache() {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "initCache to load data from the db - started");
		userLoginAccountList = userManagementDao.getSystemUsers();
		if (null != userLoginAccountList && !userLoginAccountList.isEmpty())
			userMapresult = userLoginAccountList.stream()
					.collect(Collectors.toMap(UserLoginAccount::getLoginid, Function.identity(), (e1, e2) -> e1));
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "initCache to load data from the db - ended");
		
	}

	public UserLoginAccount getSystemUser(String loginID) {
		UserLoginAccount userLoginDetails = null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getSystemUser of  UICredentialCache - started");
		if (null != userMapresult && !userMapresult.isEmpty()) {
			if (userMapresult.containsKey(loginID)) {
				userLoginDetails = userMapresult.get(loginID);
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "User Not Found in cache");
				throw new BFLBusinessException("UMS-009", env.getProperty("UMS-009"));
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getSystemUser of  UICredentialCache - started");
		return userLoginDetails;
	}

}
