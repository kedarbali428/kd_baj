package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the USER_SOC_PRF_LNKDIN_POSITIONS database table.
 * 
 */
@Entity
@Table(name="USER_SOC_PRF_LNKDIN_POSITIONS")
//@NamedQuery(name="UserSocPrfLnkdinPosition.findAll", query="SELECT u FROM UserSocPrfLnkdinPosition u")
public class UserSocPrfLnkdinPosition implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false, precision=20)
	private long usrsocprflnkposkey;

	@Column(precision=5)
	private long companyid;

	@Column(length=10)
	private String compindustrycode;

	@Column(length=100)
	private String compindustrydesc;

	@Column(length=100)
	private String compname;

	@Column(length=10)
	private String compticker;

	@Column(length=10)
	private String comptype;

	@Temporal(TemporalType.DATE)
	private Date enddt;

	@Column(precision=1)
	private byte iscurrent;

	@Column(precision=20)
	private long positionid;

	@Temporal(TemporalType.DATE)
	private Date startdt;

	@Column(length=500)
	private String summary;

	@Column(length=100)
	private String title;

	//bi-directional many-to-one association to UserSocialProfileLinkedin
	@ManyToOne
	@JoinColumn(name="USRSOCPRFLNKKEY", nullable=false)
	private UserSocialProfileLinkedin userSocialProfileLinkedin;

	public long getUsrsocprflnkposkey() {
		return this.usrsocprflnkposkey;
	}

	public void setUsrsocprflnkposkey(long usrsocprflnkposkey) {
		this.usrsocprflnkposkey = usrsocprflnkposkey;
	}

	public long getCompanyid() {
		return this.companyid;
	}

	public void setCompanyid(long companyid) {
		this.companyid = companyid;
	}

	public String getCompindustrycode() {
		return this.compindustrycode;
	}

	public void setCompindustrycode(String compindustrycode) {
		this.compindustrycode = compindustrycode;
	}

	public String getCompindustrydesc() {
		return this.compindustrydesc;
	}

	public void setCompindustrydesc(String compindustrydesc) {
		this.compindustrydesc = compindustrydesc;
	}

	public String getCompname() {
		return this.compname;
	}

	public void setCompname(String compname) {
		this.compname = compname;
	}

	public String getCompticker() {
		return this.compticker;
	}

	public void setCompticker(String compticker) {
		this.compticker = compticker;
	}

	public String getComptype() {
		return this.comptype;
	}

	public void setComptype(String comptype) {
		this.comptype = comptype;
	}

	public Date getEnddt() {
		return this.enddt;
	}

	public void setEnddt(Date enddt) {
		this.enddt = enddt;
	}

	public byte getIscurrent() {
		return this.iscurrent;
	}

	public void setIscurrent(byte iscurrent) {
		this.iscurrent = iscurrent;
	}

	public long getPositionid() {
		return this.positionid;
	}

	public void setPositionid(long positionid) {
		this.positionid = positionid;
	}

	public Date getStartdt() {
		return this.startdt;
	}

	public void setStartdt(Date startdt) {
		this.startdt = startdt;
	}

	public String getSummary() {
		return this.summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public UserSocialProfileLinkedin getUserSocialProfileLinkedin() {
		return this.userSocialProfileLinkedin;
	}

	public void setUserSocialProfileLinkedin(UserSocialProfileLinkedin userSocialProfileLinkedin) {
		this.userSocialProfileLinkedin = userSocialProfileLinkedin;
	}

}