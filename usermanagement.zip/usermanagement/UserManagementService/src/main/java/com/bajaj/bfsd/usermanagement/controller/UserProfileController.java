package com.bajaj.bfsd.usermanagement.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerHeader;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.usermanagement.MapperFactory;
import com.bajaj.bfsd.usermanagement.bean.AadharProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileSaveRequest;
import com.bajaj.bfsd.usermanagement.service.UserProfileService;
import com.bajaj.bfsd.usermanagement.service.UserProfileServiceFactory;
import com.bfl.common.exceptions.BFLBusinessException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import io.swagger.annotations.ApiOperation;

@RestController
public class UserProfileController extends BFLController {
	
	private static final String THIS_CLASS = UserProfileController.class.getSimpleName();
	
	@Autowired
    private BFLLoggerUtil logger;
	
	@Autowired
	private UserProfileServiceFactory profileServiceFactory;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private CustomDefaultHeaders customHeader;
	
	@ApiOperation(value = "Save profile details of a user", notes = "Gets a profile of user based on user id received in header", httpMethod = "POST")
	@RequestMapping(method = RequestMethod.POST, value = "${api.usermanagement.saveprofile.POST.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> saveUserProfile(@RequestBody UserProfileSaveRequest profileSaveRequest 
														,@PathVariable("source") String source,
														@RequestHeader HttpHeaders headers) {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getUserProfile - started");

		UserProfileService profileService = profileServiceFactory.getServiceInstance(source);
		profileService.saveUserProfile(profileSaveRequest);

		ResponseBean responseBean = new ResponseBean(StatusCode.SUCCESS.name());
		
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getUserProfile - completed");
		
		return new ResponseEntity<>(responseBean, HttpStatus.OK);

	}
	
	@ApiOperation(value = "Get profile details of a user", notes = "Gets a profile of user based on user id received in header", httpMethod = "GET")
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.getprofile.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserProfile(@PathVariable("source") String source,
			@RequestHeader HttpHeaders headers){

		long userKey = 0;
		ResponseBean responseBean;
		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		if(customHeader != null)
			userKey = customHeader.getUserKey();
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getUserProfile - started for user -"+userKey);
				
		if(userKey == 0){
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getUserProfile - Invalid user key in header - "+userKey);
			throw new BFLBusinessException("UMS-012", env.getProperty("UMS-012"));
		}
		
		UserProfileService profileService = profileServiceFactory.getServiceInstance(source);
		UserProfileBean userProfileBean  = profileService.getUserProfile(userKey);	
		responseBean = new ResponseBean(userProfileBean);
		
		if(userProfileBean instanceof AadharProfileBean){
			JsonNode nodes;
			try {
				nodes = MapperFactory.getInstance().readTree(userProfileBean.getProfileJson());
				nodes = ((ObjectNode)nodes).put("journeySourceKey", ((AadharProfileBean) userProfileBean).getAadharNumber());
				responseBean = new ResponseBean(nodes);
			} catch (IOException e) {
				logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getUserProfile - Unable to parse aadhar json - "+e);
			}
			
		}
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getUserProfile - completed");
		
		return new ResponseEntity<>(responseBean,headers, HttpStatus.OK);

	}
}
