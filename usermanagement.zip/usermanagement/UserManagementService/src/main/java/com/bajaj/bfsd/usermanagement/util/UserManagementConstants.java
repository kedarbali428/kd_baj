package com.bajaj.bfsd.usermanagement.util;

import java.math.BigDecimal;

public class UserManagementConstants {
	
	public static final String CONFIG_PROPERTY_FILE = "application.properties";
    public static final String RESPONSE_BODY = "body";
    public static final String RESPONSE_STATUS = "status";
    public static final String RESPONSE_ERROR = "error";
    public static final String LOAN_ISSUER_BAJAJ = "BAJAJ FIN LTD";
    public static final String UI_STATUS_TYPE_NORMAL = "Normal";
    public static final String RESPONSE = "RESPONSE";
    public static final String REQUEST = "REQUEST";
    public static final String STATUS_500 = "500";
    public static final String PAYLOAD_JSON_KEY = "payload";
    public static final String MAIL_OFFICE_TYPE_VALUE = "2";
    public static final String ADDRESS_TYPE_CURRENT_VALUE = "1";
    public static final String APPLICANT_PRIMARY = "PRIMARY";
    public static final String EMPLOYMENT_STATUS_CURRENT = "1";
    public static final String PRODUCT = "SPL";
    public static final String ERROR_PROPERTY_FILE = "error.properties";
    public static final String DAO_1 = "Inside DaoImpl for list details ";
	public static final String DAO_2 = "Exception in Database Query inside Impl Details";
	public static final String DAO_3 = "Successfully retrieved data from Database";
	public static final String DAO_4 = "Start DaoImpl for getRolesByUserKey";
	public static final String DAO_5 = "End DaoImpl for getRolesByUserKey";
	public static final String DAO_6 = "Start DaoImpl for getUserProfileByUserKey";
	public static final String DAO_7 = "End DaoImpl for getUserProfileByUserKey";
	public static final String CNTR_1 = "Inside controller for fetching details of products mapped to loan product type";
	public static final String CNTR_2 = "successfully fetched data from database and returning ";

	public static final String CNTR_3 = "Start controller for getRolesByUserKey";
	public static final String CNTR_4 = "End controller for getRolesByUserKey";
	
	public static final String CNTR_5 = "Start controller for getListOfUserName";
	public static final String CNTR_6 = "End controller for getListOfUserName";
	
	public static final String DEFAULT_PASSWORD="test";//NOSONAR
	public static final String UPDATED_BY_SYSTEM="SYSTEM";
	public static final int CUSTOMER_ROLEKEY = 45;
	public static final int PARTNER_ROLEKEY = 46;
	
	public static final String DEFAULT_END_DATE = "9999-12-31";
	public static final String DEFAULT_DOB_INSURANCE = "1800-01-01";
	
	public static final String JOURNEY ="journey";
	public static final String CUSTOMER_PORTAL = "customerportal";
	public static final String EMPLOYEE_PORTAL = "employeeportal";
	public static final String B2B_PARTNER = "b2bpartner";
	public static final String VENDOR = "vendor";
	public static final String VENDOR_INDIVIDUAL ="vendorIndividual";
	public static final String VENDOR_COMPANY = "vendorCompany";
	public static final String PRINCIPAL_USER = "principalUser";
	
	public static final String EMPLOYEE = "employee";
	public static final String SYSTEM_USER = "system user";
	public static final String CUSTOMER = "customer";
	public static final String THIRD_PARTY_VENDOR = "third party vendor";
	public static final String CHATBOT = "CHATBOT";
	
	public static final String FACEBOOK = "facebook";
	public static final String LINKEDIN = "linkedin";
	
	public static final String LOGINACCTYPE_SOCIAL_STR = "social";
	public static final String LOGINACCTYPE_AADHAR_STR = "aadhar";
	public static final String LOGINACCTYPE_MOBILEDOB_STR = "mobile";
	public static final String LOGINACCTYPE_MANUAL_STR = "manual";
	
	public static final short USERTYPE_CUSTOMER = 1;
	public static final short USERTYPE_EMPLOYEE = 2;
	public static final short USERTYPE_VENDOR_PARTNER = 3;
	public static final short USERTYPE_B2B_PARTNER = 4;
	public static final short USERTYPE_SYSTEM = 0;
	public static final short USERTYPE_PSEUDO_CUSTOMER = 10;
	public static final short USERTYPE_PSEUDO_VERIFIED_CUSTOMER = 11;
	
	public static final short LOGINACCTYPE_SOCIAL_FB = 1;
	public static final short LOGINACCTYPE_SOCIAL_LI = 2;
	public static final short LOGINACCTYPE_SOCIAL_GL = 3;
	public static final short LOGINACCTYPE_SOCIAL_TW = 4;
	public static final short LOGINACCTYPE_MANUAL = 5;
	public static final short LOGINACCTYPE_MOBILEDOB = 6;
	public static final short LOGINACCTYPE_AADHAR = 7;
	public static final short LOGINACCTYPE_MOBILE_DOB_OTP_MPIN = 8;
	public static final short LOGINACCTYPE_FORGOT_MPIN = 9;
	
	public static final short ISACTIVE = 1;
	
	public static final String CHAR_UNDERSCORE = "_";
	public static final String MY_APP_VIEW = "MyAppView";
	public static final String MY_TEAM_VIEW = "MyTeamView";
	public static final String ALL_APP_VIEW = "AllAppView";
	public static final String PARAM_USER_ROLE_KEY = "userRoleKey";
	public static final String PARAM_ROLE_KEY = "roleKey";
	public static final String PARAM_USER_KEY = "userKey";
	public static final String CHAR_PERCENT = "%";
	public static final String PARAM_FIRST_NAME = "fName";
	public static final String PARAM_LAST_NAME = "lName";
	public static final String PARAM_EMAIL_ID = "email";
	public static final String PARAM_COMPANY_NAME = "companyName";
	public static final BigDecimal AUTH_STATUS_SUCCESSFUL = new BigDecimal(1);
	public static final String TOKEN_DELIMETER = "~";
	
	public static final String QRY_DELETE_USER_ROLE_CHANNELS="DELETE from USER_ROLE_CHANNELS where USERROLEKEY= :userRoleKey";
	public static final String QRY_DELETE_USER_ROLE_LOCATIONS="DELETE from USER_ROLE_LOCATIONS where USERROLEKEY= :userRoleKey";
	public static final String QRY_DELETE_USER_ROLE_PIN_CODE="DELETE from USER_ROLE_PIN_CODE where USERROLEKEY= :userRoleKey";
	public static final String QRY_DELETE_USER_ROLE_PRODUCT="DELETE from USER_ROLE_PRODUCT where USERROLEKEY= :userRoleKey";
	
	public static final String FIELD_NAME_PERSONAL_EMAIL = "personalemail";
	public static final String LOAN = "LOAN";
	public static final String INSURANCE = "INSURANCE";
	public static final String VAS = "VAS";
	public static final String INVESTMENT = "INVESTMENT";
	
	public static final String OMCREDIT = "OMCREDIT";

	public static final String DATE_FORMATE = "yyyy-MM-dd";
	// Start added  for Partner Portal
	public static final String DEALER = "dealer";
	public static final String MERCHANT = "merchant";
	public static final short USERTYPE_DEALER = 8;
	public static final short USERTYPE_MERCHANT = 9;
	public static final int DEALER_ROLEKEY = 238;
	// End added  for Partner Portal
	public static final String AUTH_TOKEN = "authtoken";
	public static final String USER_EVENT = "USER";
	public static final String USER_EVENT_CREATED ="USER_CREATED";
	public static final String USER_EVENT_UPDATED ="USER_UPDATED";
	public static final String USER_EVENT_ACTIVATED ="USER_ACTIVATED";
	public static final String USER_EVENT_DEACTIVATED ="USER_DEACTIVATED";
	public static final String PRODUCT_CODE_CC = "CC";
	public static final String PARAM_PRINCIPAL_NAME ="principalUser";
	public static final String USERROLE_MAPPING_EVENT_CREATED ="USERROLE_MAPPING_CREATED";
	public static final String USERROLE_MAPPING_EVENT_UPDATED="USERROLE_MAPPING_UPDATED";
	public static final String MOBILE = "mobile";
	public static final String DATE_OF_BIRTH = "dateOfBirth";
	
	
	public static final String PHONE_MOBILE_TYPE="MOBILE";
	public static final String TOKEN_CUSTOMER_ROLE = "customer";
	public static final String VALID = "Valid";
	public static final String EXPIRED_STATUS = "EXPIRED";
	public static final String INVALID_STATUS = "INVALID";

	public static final long PHONETYPE_MOBILE  = 45L;

	private UserManagementConstants() {
	}
	
}
