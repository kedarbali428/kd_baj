package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the APPLICATIONS database table.
 * 
 */
@Entity
@Table(name = "APPLICATIONS")
public class ApplicationV2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long applicationkey;

	private String appprocessidentifier;

	public ApplicationV2() {
	}

	public String getAppprocessidentifier() {
		return this.appprocessidentifier;
	}

	public void setAppprocessidentifier(String appprocessidentifier) {
		this.appprocessidentifier = appprocessidentifier;
	}

	public long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(long applicationkey) {
		this.applicationkey = applicationkey;
	}

}