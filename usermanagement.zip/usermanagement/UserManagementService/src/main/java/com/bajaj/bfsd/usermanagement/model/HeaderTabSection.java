package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the HEADER_TAB_SECTION database table.
 * 
 */
@Entity
@Table(name="HEADER_TAB_SECTION")
//@NamedQuery(name="HeaderTabSection.findAll", query="SELECT h FROM HeaderTabSection h")
public class HeaderTabSection implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long tabsectionkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to FieldSetSection
	@ManyToOne
	@JoinColumn(name="SECTIONKEY")
	private FieldSetSection fieldSetSection;

	//bi-directional many-to-one association to HeaderTabMaster
	@ManyToOne
	@JoinColumn(name="TABKEY")
	private HeaderTabMaster headerTabMaster;

	public long getTabsectionkey() {
		return this.tabsectionkey;
	}

	public void setTabsectionkey(long tabsectionkey) {
		this.tabsectionkey = tabsectionkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public FieldSetSection getFieldSetSection() {
		return this.fieldSetSection;
	}

	public void setFieldSetSection(FieldSetSection fieldSetSection) {
		this.fieldSetSection = fieldSetSection;
	}

	public HeaderTabMaster getHeaderTabMaster() {
		return this.headerTabMaster;
	}

	public void setHeaderTabMaster(HeaderTabMaster headerTabMaster) {
		this.headerTabMaster = headerTabMaster;
	}

}