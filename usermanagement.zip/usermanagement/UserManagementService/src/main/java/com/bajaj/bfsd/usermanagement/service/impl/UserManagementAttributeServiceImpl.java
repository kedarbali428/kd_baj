package com.bajaj.bfsd.usermanagement.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.usermanagement.bean.BusinessVerticalBean;
import com.bajaj.bfsd.usermanagement.bean.POTypeBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoBean;
import com.bajaj.bfsd.usermanagement.dao.UserManagementAttributeDao;
import com.bajaj.bfsd.usermanagement.repository.BusinessVerticalMasterRepository;
import com.bajaj.bfsd.usermanagement.service.UserManagementAttributeService;

@Component
public class UserManagementAttributeServiceImpl implements UserManagementAttributeService {
	@Autowired
	UserManagementAttributeDao userManagementAttributeDao;
	
	@Autowired
	BusinessVerticalMasterRepository businessVerticalMasterRepository;

	@Override
	public UserInfoBean getUserDetailsByUserKey(long userKey) {
		UserInfoBean userInfoBean = new UserInfoBean();
		userInfoBean.setUserKey(userKey);
		userManagementAttributeDao.getUserProfileDetails(userInfoBean, userKey);
		userManagementAttributeDao.getUserAdditionalAttributeDetails(userInfoBean, userKey);
		userManagementAttributeDao.getEmployeeTypeAndStatusChangeReason(userInfoBean, userKey);
		return userInfoBean;
	}
	
	@Override
	public List<BusinessVerticalBean> getBusinessVerticalAndPOTypes() {
		List<BusinessVerticalBean> businessVerticalBeans = new ArrayList<>();
		BigDecimal isActive = new BigDecimal(1);
		List<Object[]> businessVerticalDetails = businessVerticalMasterRepository.findByIsActive(isActive);
		if(!businessVerticalDetails.isEmpty()) {
			for (Object[] objects1 : businessVerticalDetails) {
				BusinessVerticalBean businessVerticalBean = new BusinessVerticalBean();
				businessVerticalBean.setBusinessVerticalCode(String.valueOf(objects1[0]));
				businessVerticalBean.setBusinessVerticalDesc(String.valueOf(objects1[1]));
				List<POTypeBean> poTypeBeans = new ArrayList<POTypeBean>();
				List<Object[]> poTypesDetails = businessVerticalMasterRepository.findByBusinessVerticalCodeAndIsActive(objects1[0].toString(), isActive);
				if(!poTypesDetails.isEmpty()) {
					for (Object[] objects2 : poTypesDetails) {
						POTypeBean poTypeBean = new POTypeBean();
						poTypeBean.setPOTypeCode(String.valueOf(objects2[0]));
						poTypeBean.setPOTypeDesc(String.valueOf(objects2[1]));
						poTypeBeans.add(poTypeBean);
					}
					businessVerticalBean.setPoTypes(poTypeBeans);
					businessVerticalBeans.add(businessVerticalBean);
				}			
			}
		}	
		return businessVerticalBeans;
	}	
}