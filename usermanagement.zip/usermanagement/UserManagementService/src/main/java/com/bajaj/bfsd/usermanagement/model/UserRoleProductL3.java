package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * The persistent class for the USER_ROLE_PRODUCT database table.
 * 
 */
@Entity
@Table(name = "USER_ROLE_PRODUCT")
//@NamedQuery(name = "UserRoleProductL3.findAll", query = "SELECT u FROM UserRoleProductL3 u")
public class UserRoleProductL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userprodkey;

	private BigDecimal creditlimit;

	private long isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private Long prodmastkey;

	private Long subprodkey;

	private Long subprodtypekey;
	
	private BigDecimal pricinglimit;

	// bi-directional many-to-one association to UserRole
	@OneToOne
	@JoinColumn(name = "USERROLEKEY")
	private UserRoleL3 userRole;

	// bi-directional many-to-one association to UserRoleProduct
	@ManyToOne
	@JoinColumn(name = "PARENTUSER")
	private UserRoleProductL3 parentUserRoleProduct;

	// bi-directional many-to-one association to UserRoleChannel
	@OneToMany(mappedBy = "userRoleProduct", cascade = { CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.PERSIST }, orphanRemoval = true)
	private List<UserRoleChannelL3> userRoleChannels=new ArrayList<>();

	// bi-directional many-to-one association to UserRoleLocation
	@OneToMany(mappedBy = "userRoleProduct", cascade = { CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.PERSIST }, orphanRemoval = true)
	private List<UserRoleLocationL3> userRoleLocations=new ArrayList<>();

	// bi-directional many-to-one association to UserRolePinCode
	@OneToMany(mappedBy = "userRoleProduct", cascade = { CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.PERSIST }, orphanRemoval = true)
	private List<UserRolePinCodeL3> userRolePinCodes=new ArrayList<>();

	// bi-directional many-to-one association to UserRoleLocation
	@OneToMany(mappedBy = "userRoleProduct", cascade = { CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.PERSIST }, orphanRemoval = true)
	private List<UserRoleProductType> userRoleProductTypes = new ArrayList<>();
	
	//bi-directional many-to-one association to UserRoleUtmSourceChannel  
	@OneToMany(mappedBy="userRoleProduct", cascade = { CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.PERSIST }, orphanRemoval = true)
	private List<UserRoleUtmSourceChannel> userRoleUtmSourceChannels=new ArrayList<>();

	public Long getUserprodkey() {
		return userprodkey;
	}

	public void setUserprodkey(Long userprodkey) {
		this.userprodkey = userprodkey;
	}

	public BigDecimal getCreditlimit() {
		return creditlimit;
	}

	public void setCreditlimit(BigDecimal creditlimit) {
		this.creditlimit = creditlimit;
	}

	public long getIsactive() {
		return isactive;
	}

	public void setIsactive(long isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdmastkey() {
		return prodmastkey;
	}

	public void setProdmastkey(Long prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public Long getSubprodkey() {
		return subprodkey;
	}

	public void setSubprodkey(Long subprodkey) {
		this.subprodkey = subprodkey;
	}

	public Long getSubprodtypekey() {
		return subprodtypekey;
	}

	public void setSubprodtypekey(Long subprodtypekey) {
		this.subprodtypekey = subprodtypekey;
	}

	public UserRoleL3 getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRoleL3 userRole) {
		this.userRole = userRole;
	}

	public UserRoleProductL3 getParentUserRoleProduct() {
		return parentUserRoleProduct;
	}

	public void setParentUserRoleProduct(UserRoleProductL3 parentUserRoleProduct) {
		this.parentUserRoleProduct = parentUserRoleProduct;
	}

	public List<UserRoleChannelL3> getUserRoleChannels() {
		return userRoleChannels;
	}

	public void setUserRoleChannels(List<UserRoleChannelL3> userRoleChannels) {
		this.userRoleChannels = userRoleChannels;
	}

	/**
	 * @return the pricinglimit
	 */
	public BigDecimal getPricinglimit() {
		return pricinglimit;
	}

	/**
	 * @param pricinglimit the pricinglimit to set
	 */
	public void setPricinglimit(BigDecimal pricinglimit) {
		this.pricinglimit = pricinglimit;
	}

	public List<UserRoleLocationL3> getUserRoleLocations() {
		return userRoleLocations;
	}

	public void setUserRoleLocations(List<UserRoleLocationL3> userRoleLocations) {
		this.userRoleLocations = userRoleLocations;
	}

	public List<UserRolePinCodeL3> getUserRolePinCodes() {
		return userRolePinCodes;
	}

	public void setUserRolePinCodes(List<UserRolePinCodeL3> userRolePinCodes) {
		this.userRolePinCodes = userRolePinCodes;
	}

	public List<UserRoleProductType> getUserRoleProductTypes() {
		return userRoleProductTypes;
	}

	public void setUserRoleProductTypes(List<UserRoleProductType> userRoleProductTypes) {
		this.userRoleProductTypes = userRoleProductTypes;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<UserRoleUtmSourceChannel> getUserRoleUtmSourceChannels() {
		return userRoleUtmSourceChannels;
	}

	public void setUserRoleUtmSourceChannels(List<UserRoleUtmSourceChannel> userRoleUtmSourceChannels) {
		this.userRoleUtmSourceChannels = userRoleUtmSourceChannels;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (subprodkey ^ (subprodkey >>> 32));
		result = prime * result + ((userRole == null) ? 0 : userRole.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserRoleProductL3 other = (UserRoleProductL3) obj;
		if (subprodkey != other.subprodkey)
			return false;
		if (userRole == null) {
			if (other.userRole != null)
				return false;
		} else if (!userRole.equals(other.userRole))
			return false;
		return true;
	}

}