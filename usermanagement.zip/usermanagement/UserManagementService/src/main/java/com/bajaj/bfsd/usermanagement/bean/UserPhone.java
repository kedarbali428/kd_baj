package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserPhone implements Serializable{

	private static final long serialVersionUID = -7021703031861217269L;

	private Long areaCode;
	
	private Long countryCode;
	
	@JsonProperty("number")
	private Long phnNumber;
	@JsonProperty("type")
	private String phnType;

	public Long getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(Long areaCode) {
		this.areaCode = areaCode;
	}

	public Long getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(Long countryCode) {
		this.countryCode = countryCode;
	}

	public Long getPhnNumber() {
		return phnNumber;
	}

	public void setPhnNumber(Long phnNumber) {
		this.phnNumber = phnNumber;
	}

	public String getPhnType() {
		return phnType;
	}

	public void setPhnType(String phnType) {
		this.phnType = phnType;
	}
	
	
}
