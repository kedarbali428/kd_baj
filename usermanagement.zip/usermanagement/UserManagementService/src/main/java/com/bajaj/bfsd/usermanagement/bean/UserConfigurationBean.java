package com.bajaj.bfsd.usermanagement.bean;

import java.util.List;

public class UserConfigurationBean {

	boolean statusIfExist;
	private String emailId;
	private String firstName;
	private String lastName;
	private String designation;
	private String employeeType;
	private long userKey;
	private String companyName;
	private List<User> userADList;
	private List<UserVendorProfileBean> userVendorList;
	private String principalUser;
	private String spCode;
	private String lpCode;
	private String reportingManager;
	private long reportingManagerKey;
	private String maxSumAssuredLimit;
	private String maxPremiumLimit;
	private List <String> skills;
	private List <String> specialization;
	private List <String> paymentModes;
	private List <String> channel;
	private String poType;
	
	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public boolean isStatusIfExist() {
		return statusIfExist;
	}

	public void setStatusIfExist(boolean statusIfExist) {
		this.statusIfExist = statusIfExist;
	}

	public List<User> getUserADList() {
		return userADList;
	}

	public void setUserADList(List<User> userADList) {
		this.userADList = userADList;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public List<UserVendorProfileBean> getUserVendorList() {
		return userVendorList;
	}

	public void setUserVendorList(List<UserVendorProfileBean> userVendorList) {
		this.userVendorList = userVendorList;
	}
	
	public String getPrincipalUser() {
		return principalUser;
	}

	public void setPrincipalUser(String principalUser) {
		this.principalUser = principalUser;
	}

	/**
	 * @return the spCode
	 */
	public String getSpCode() {
		return spCode;
	}

	/**
	 * @param spCode the spCode to set
	 */
	public void setSpCode(String spCode) {
		this.spCode = spCode;
	}

	/**
	 * @return the lpCode
	 */
	public String getLpCode() {
		return lpCode;
	}

	/**
	 * @param lpCode the lpCode to set
	 */
	public void setLpCode(String lpCode) {
		this.lpCode = lpCode;
	}

	/**
	 * @return the reportingManager
	 */
	public String getReportingManager() {
		return reportingManager;
	}

	/**
	 * @param reportingManager the reportingManager to set
	 */
	public void setReportingManager(String reportingManager) {
		this.reportingManager = reportingManager;
	}

	public long getReportingManagerKey() {
		return reportingManagerKey;
	}

	public void setReportingManagerKey(long reportingManagerKey) {
		this.reportingManagerKey = reportingManagerKey;
	}

	public String getMaxSumAssuredLimit() {
		return maxSumAssuredLimit;
	}

	public void setMaxSumAssuredLimit(String maxSumAssuredLimit) {
		this.maxSumAssuredLimit = maxSumAssuredLimit;
	}

	public String getMaxPremiumLimit() {
		return maxPremiumLimit;
	}

	public void setMaxPremiumLimit(String maxPremiumLimit) {
		this.maxPremiumLimit = maxPremiumLimit;
	}

	public List<String> getSpecialization() {
		return specialization;
	}

	public void setSpecialization(List<String> specialization) {
		this.specialization = specialization;
	}

	public List<String> getSkills() {
		return skills;
	}

	public void setSkills(List<String> skills) {
		this.skills = skills;
	}

	public List<String> getPaymentModes() {
		return paymentModes;
	}

	public void setPaymentModes(List<String> paymentModes) {
		this.paymentModes = paymentModes;
	}

	public List<String> getChannel() {
		return channel;
	}

	public void setChannel(List<String> channel) {
		this.channel = channel;
	}
	
	public String getPoType() {
		return poType;
	}

	public void setPoType(String poType) {
		this.poType = poType;
	}
}
