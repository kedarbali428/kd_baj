package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * The persistent class for the APPLICATION_APPLICANTS database table.
 * 
 */
@Entity
@Table(name = "APPLICATION_APPLICANTS")
//@NamedQuery(name="ApplicationApplicant.findAll", query="SELECT a FROM ApplicationApplicant a")
public class ApplicationApplicantV2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long appapltkey;

	@Column(name = "APPLICATIONKEY", insertable = false, updatable = false)
	private long applicationkey;

	private long applicantkey;

	@OneToOne
	@JoinColumn(name = "APPLICATIONKEY")
	private ApplicationV2 application;

	public ApplicationApplicantV2() {
	}

	public long getAppapltkey() {
		return appapltkey;
	}

	public void setAppapltkey(long appapltkey) {
		this.appapltkey = appapltkey;
	}

	public long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public ApplicationV2 getApplication() {
		return application;
	}

	public void setApplication(ApplicationV2 application) {
		this.application = application;
	}

	public long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(long applicantkey) {
		this.applicantkey = applicantkey;
	}

}