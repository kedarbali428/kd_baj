package com.bajaj.bfsd.usermanagement.model;


import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the PRODUCT_CATEGORIES database table.
 * 
 */
@Entity
@Table(name="PRODUCT_CATEGORIES")
//@NamedQuery(name="ProductCategory.findAll", query="SELECT p FROM ProductCategory p")
public class ProductCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long prodcatkey;

	private String prodcatcode;

	private String prodcatdesc;

	private BigDecimal prodcatisactive;

	private String prodcatlstupdateby;

	private Timestamp prodcatlstupdatedt;

	//bi-directional many-to-one association to LoanProduct
	@OneToMany(mappedBy="productCategory")
	private List<LoanProduct> loanProducts;

	//bi-directional many-to-one association to ProductMaster
	@ManyToOne
	@JoinColumn(name="PRODMASTKEY")
	private ProductMaster productMaster;

	public long getProdcatkey() {
		return this.prodcatkey;
	}

	public void setProdcatkey(long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public String getProdcatcode() {
		return this.prodcatcode;
	}

	public void setProdcatcode(String prodcatcode) {
		this.prodcatcode = prodcatcode;
	}

	public String getProdcatdesc() {
		return this.prodcatdesc;
	}

	public void setProdcatdesc(String prodcatdesc) {
		this.prodcatdesc = prodcatdesc;
	}

	public BigDecimal getProdcatisactive() {
		return this.prodcatisactive;
	}

	public void setProdcatisactive(BigDecimal prodcatisactive) {
		this.prodcatisactive = prodcatisactive;
	}

	public String getProdcatlstupdateby() {
		return this.prodcatlstupdateby;
	}

	public void setProdcatlstupdateby(String prodcatlstupdateby) {
		this.prodcatlstupdateby = prodcatlstupdateby;
	}

	public Timestamp getProdcatlstupdatedt() {
		return this.prodcatlstupdatedt;
	}

	public void setProdcatlstupdatedt(Timestamp prodcatlstupdatedt) {
		this.prodcatlstupdatedt = prodcatlstupdatedt;
	}

	public List<LoanProduct> getLoanProducts() {
		return this.loanProducts;
	}

	public void setLoanProducts(List<LoanProduct> loanProducts) {
		this.loanProducts = loanProducts;
	}

	public LoanProduct addLoanProduct(LoanProduct loanProduct) {
		getLoanProducts().add(loanProduct);
		loanProduct.setProductCategory(this);

		return loanProduct;
	}

	public LoanProduct removeLoanProduct(LoanProduct loanProduct) {
		getLoanProducts().remove(loanProduct);
		loanProduct.setProductCategory(null);

		return loanProduct;
	}

	public ProductMaster getProductMaster() {
		return this.productMaster;
	}

	public void setProductMaster(ProductMaster productMaster) {
		this.productMaster = productMaster;
	}

}