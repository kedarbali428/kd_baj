package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * The persistent class for the USER_ROLE_PIN_CODE database table.
 * 
 */
@Entity
@Table(name = "USER_ROLE_PIN_CODE")
//@NamedQuery(name = "UserRolePinCode.findAll", query = "SELECT u FROM UserRolePinCode u")
public class UserRolePinCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userpincdkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal pincodekey;

	// bi-directional many-to-one association to UserRole
	@ManyToOne
	@JoinColumn(name = "USERROLEKEY")
	private UserRole userRole;

	// bi-directional many-to-one association to UserRole
	@ManyToOne
	@JoinColumn(name = "USERPRODKEY")
	private UserRoleProduct userRoleProduct;

	public long getUserpincdkey() {
		return this.userpincdkey;
	}

	public void setUserpincdkey(long userpincdkey) {
		this.userpincdkey = userpincdkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getPincodekey() {
		return this.pincodekey;
	}

	public void setPincodekey(BigDecimal pincodekey) {
		this.pincodekey = pincodekey;
	}

	public UserRole getUserRole() {
		return this.userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

	public UserRoleProduct getUserRoleProduct() {
		return userRoleProduct;
	}

	public void setUserRoleProduct(UserRoleProduct userRoleProduct) {
		this.userRoleProduct = userRoleProduct;
	}

}