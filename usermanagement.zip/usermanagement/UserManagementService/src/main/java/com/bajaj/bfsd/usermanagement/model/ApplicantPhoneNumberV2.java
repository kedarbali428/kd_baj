package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * The persistent class for the APPLICANT_PHONE_NUMBERS database table.
 * 
 */
@Entity
@Table(name = "APPLICANT_PHONE_NUMBERS")
public class ApplicantPhoneNumberV2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long apltphnumkey;

	private String apltphnumnumber;

	private Long applicantkey;

	private Integer apltphnumisactive;

	@ManyToOne
	@JoinColumn(name="PHONETYPEKEY")
	private PhoneNumberType phoneNumberType;

	public String getApltphnumnumber() {
		return apltphnumnumber;
	}

	public void setApltphnumnumber(String apltphnumnumber) {
		this.apltphnumnumber = apltphnumnumber;
	}

	public Long getApltphnumkey() {
		return apltphnumkey;
	}

	public void setApltphnumkey(Long apltphnumkey) {
		this.apltphnumkey = apltphnumkey;
	}

	public Long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(Long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public Integer getApltphnumisactive() {
		return apltphnumisactive;
	}

	public void setApltphnumisactive(Integer apltphnumisactive) {
		this.apltphnumisactive = apltphnumisactive;
	}
	
	public PhoneNumberType getPhoneNumberType() {
		return phoneNumberType;
	}

	public void setPhoneNumberType(PhoneNumberType phoneNumberType) {
		this.phoneNumberType = phoneNumberType;
	}
	
}