package com.bajaj.bfsd.usermanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

import com.bajaj.bfsd.common.business.baseclasses.BFLBusinessApplication;


@PropertySources(value = {@PropertySource("classpath:application.properties"),
        @PropertySource("classpath:error.properties")})
@EntityScan("com.bajaj")
@ComponentScans(value = {@ComponentScan("com.bajaj.openmarkets.*")})
public class UserManagementApplication extends BFLBusinessApplication{

	public static void main(String[] args) {
		SpringApplication.run(UserManagementApplication.class, args);
	}
}


