package com.bajaj.bfsd.usermanagement.deserializer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.bajaj.bfsd.usermanagement.bean.LinkedinPositionBean;
import com.bajaj.bfsd.usermanagement.bean.LinkedinProfileBean;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

public class LinkedinResponseDeserializer extends JsonDeserializer<LinkedinProfileBean>{

	@Override
	public LinkedinProfileBean deserialize(JsonParser jp, DeserializationContext ctxt)
			throws IOException{
		
		LinkedinProfileBean linkedinProfile = new LinkedinProfileBean();  
		
		JsonNode rootNode = jp.getCodec().readTree(jp);
		
		linkedinProfile.setFirstName(rootNode.get("firstName").asText());
		linkedinProfile.setLastName(rootNode.get("lastName").asText());
		linkedinProfile.setPrimaryEmail(rootNode.get("emailAddress").asText());
		linkedinProfile.setHeadline(rootNode.get("headline").asText());
		linkedinProfile.setProfileId(rootNode.get("id").asText());
		linkedinProfile.setPublicProfileUrl(rootNode.get("publicProfileUrl")!=null?rootNode.get("publicProfileUrl").asText():null);
		linkedinProfile.setFormattedName(rootNode.get("formattedName")!=null?rootNode.get("formattedName").asText():null);
		linkedinProfile.setPictureUrl(rootNode.get("pictureUrl")!=null ? rootNode.get("pictureUrl").asText() : null);
		
		JsonNode locationNode = rootNode.get("location");
		JsonNode countryNode = locationNode.get("country");
		
		linkedinProfile.setConuntryCode(countryNode.get("code").asText());
		linkedinProfile.setLocationName(locationNode.get("name").asText());
		
		
		JsonNode positionNode = rootNode.get("positions");		
		Iterable<JsonNode> positionList = positionNode.get("values");
		
		LinkedinPositionBean linkedinPosition;
		List<LinkedinPositionBean> linkedinPositions = new ArrayList<>();
		
		for(JsonNode position : positionList){
			
			linkedinPosition = new LinkedinPositionBean();
			
			JsonNode companyNode = position.get("company");
			linkedinPosition.setCompanyId(companyNode.get("id")!=null ? companyNode.get("id").asInt():0);
			linkedinPosition.setCompanyName(companyNode.get("name").asText());
			linkedinPosition.setCompanyType(companyNode.get("type")!=null?companyNode.get("type").asText():null);
			linkedinPosition.setIndustryDesc(companyNode.get("industry")!=null?companyNode.get("industry").asText():null);
			
			linkedinPosition.setPositionId(position.get("id")!=null?position.get("id").asLong():0);
			linkedinPosition.setCurrent(position.get("isCurrent") !=null?position.get("isCurrent").asBoolean():false);
			linkedinPosition.setTitle(position.get("title")!=null?position.get("title").asText():null);
			
			Calendar calendar = Calendar.getInstance();
			Date date;
			JsonNode startDate = position.get("startDate");
			if(null != startDate){
				calendar.clear();
				calendar.set(Calendar.MONTH, startDate.get("month").asInt()-1);
				calendar.set(Calendar.YEAR, startDate.get("year").asInt());
				date = calendar.getTime();
				
				linkedinPosition.setStartDate(date);
			}
			
			JsonNode endDate = position.get("endDate");
			if(null != endDate){
				calendar.clear();
				calendar.set(Calendar.MONTH, endDate.get("month").asInt()-1);
				calendar.set(Calendar.YEAR, endDate.get("year").asInt());
				date = calendar.getTime();
				
				linkedinPosition.setEndDate(date);
			}
			
			linkedinPositions.add(linkedinPosition);
		}
		linkedinProfile.setPositions(linkedinPositions);
		
		return linkedinProfile;
	}

}
