package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the CITY_MASTER database table.
 * 
 */
@Entity
@Table(name = "CITY_MASTER")
//@NamedQuery(name = "CityMaster.findAll", query = "SELECT c FROM CityMaster c")
public class CityMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false, precision = 10)
	private long citykey;

	@Column(length = 20)
	private String citycategory;

	@Column(nullable = false, length = 10)
	private String citycode;

	@Column(precision = 1)
	private BigDecimal cityisactive;

	@Column(length = 20)
	private String citylstupdateby;

	private Timestamp citylstupdatedt;

	@Column(nullable = false, length = 50)
	private String cityname;

	@Column(precision = 1)
	private BigDecimal cityserviceflg;

	@Column(length = 50)
	private String citysubcategory;

	@Column(precision = 1)
	private BigDecimal citysystemdefault;

	@Column(length = 20)
	private String citytier;

	public CityMaster() {
	}

	public long getCitykey() {
		return this.citykey;
	}

	public void setCitykey(long citykey) {
		this.citykey = citykey;
	}

	public String getCitycategory() {
		return this.citycategory;
	}

	public void setCitycategory(String citycategory) {
		this.citycategory = citycategory;
	}

	public String getCitycode() {
		return this.citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

	public BigDecimal getCityisactive() {
		return this.cityisactive;
	}

	public void setCityisactive(BigDecimal cityisactive) {
		this.cityisactive = cityisactive;
	}

	public String getCitylstupdateby() {
		return this.citylstupdateby;
	}

	public void setCitylstupdateby(String citylstupdateby) {
		this.citylstupdateby = citylstupdateby;
	}

	public Timestamp getCitylstupdatedt() {
		return this.citylstupdatedt;
	}

	public void setCitylstupdatedt(Timestamp citylstupdatedt) {
		this.citylstupdatedt = citylstupdatedt;
	}

	public String getCityname() {
		return this.cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public BigDecimal getCityserviceflg() {
		return this.cityserviceflg;
	}

	public void setCityserviceflg(BigDecimal cityserviceflg) {
		this.cityserviceflg = cityserviceflg;
	}

	public String getCitysubcategory() {
		return this.citysubcategory;
	}

	public void setCitysubcategory(String citysubcategory) {
		this.citysubcategory = citysubcategory;
	}

	public BigDecimal getCitysystemdefault() {
		return this.citysystemdefault;
	}

	public void setCitysystemdefault(BigDecimal citysystemdefault) {
		this.citysystemdefault = citysystemdefault;
	}

	public String getCitytier() {
		return this.citytier;
	}

	public void setCitytier(String citytier) {
		this.citytier = citytier;
	}

}