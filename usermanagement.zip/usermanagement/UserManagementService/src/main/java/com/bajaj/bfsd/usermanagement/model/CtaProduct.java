package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the CTA_PRODUCT database table.
 * 
 */
@Entity
@Table(name="CTA_PRODUCT")
//@NamedQuery(name="CtaProduct.findAll", query="SELECT c FROM CtaProduct c")
public class CtaProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long ctaprodkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodmastkey;

	private BigDecimal subprodtypekey;

	//bi-directional many-to-one association to CtaType
	@ManyToOne
	@JoinColumn(name="CTAKEY")
	private CtaType ctaType;

	//bi-directional many-to-one association to CtaRole
	@OneToMany(mappedBy="ctaProduct")
	private List<CtaRole> ctaRoles;

	public long getCtaprodkey() {
		return this.ctaprodkey;
	}

	public void setCtaprodkey(long ctaprodkey) {
		this.ctaprodkey = ctaprodkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(BigDecimal prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public BigDecimal getSubprodtypekey() {
		return this.subprodtypekey;
	}

	public void setSubprodtypekey(BigDecimal subprodtypekey) {
		this.subprodtypekey = subprodtypekey;
	}

	public CtaType getCtaType() {
		return this.ctaType;
	}

	public void setCtaType(CtaType ctaType) {
		this.ctaType = ctaType;
	}

	public List<CtaRole> getCtaRoles() {
		return this.ctaRoles;
	}

	public void setCtaRoles(List<CtaRole> ctaRoles) {
		this.ctaRoles = ctaRoles;
	}

	public CtaRole addCtaRole(CtaRole ctaRole) {
		getCtaRoles().add(ctaRole);
		ctaRole.setCtaProduct(this);

		return ctaRole;
	}

	public CtaRole removeCtaRole(CtaRole ctaRole) {
		getCtaRoles().remove(ctaRole);
		ctaRole.setCtaProduct(null);

		return ctaRole;
	}

}