package com.bajaj.bfsd.usermanagement.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.naming.CommunicationException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.LdapConfiguration;
import com.bajaj.bfsd.usermanagement.bean.User;

@Component
public class Ldaputility {

	private static final String THIS_CLASS = Ldaputility.class.getCanonicalName();
	
	@Autowired
	DirContext ldapContext;

	@Autowired
	LdapConfiguration ldapConfiguration;

	@Value("${ldap.domain}")
	public String searchBase;

	@Value("${ldap.search.attribute}")
	public String searchAttribute;

	@Autowired
    BFLLoggerUtil bflLoggerUtil;
	

	public List<User> getADUsers(User user) {
		List<User> userList = new ArrayList<>();
		NamingEnumeration results = null;
		try {
			String filter = computeFilter(user);
			String[] searchAttrArray = searchAttribute.split(",");
			SearchControls constraints = new SearchControls();
			constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
			results = ldapContext.search(searchBase, filter, constraints);

			while (results != null && results.hasMore()) {
				SearchResult sr = (SearchResult) results.next();
				String dn = sr.getName() + ", " + searchBase;
				Attributes attributes = ldapContext.getAttributes(dn, searchAttrArray);
				User userbean = new User();

				Attribute attr = attributes.get("sn");
				userbean.setLastName(attr == null ? "" : attr.getAll().nextElement().toString());

				attr = attributes.get("name");
				userbean.setFirstName(attr == null ? "" : attr.getAll().nextElement().toString());

				attr = attributes.get("mail");
				userbean.setEmailId(attr == null ? "" : attr.getAll().nextElement().toString());

				attr = attributes.get("telephoneNumber");
				userbean.setMobileNumber(attr == null ? "" : attr.getAll().nextElement().toString());

				attr = attributes.get("title");
				userbean.setDesignation(attr == null ? "" : attr.getAll().nextElement().toString());
				
				attr = attributes.get("samaccountname");
				userbean.setAdID(attr == null ? "" : attr.getAll().nextElement().toString());

				attr = attributes.get("description");
				userbean.setEmployeeID(attr == null ? "" : attr.getAll().nextElement().toString());

				userbean.setIsActive(new BigDecimal(1));
				userbean.setEmployeeType(UserManagementConstants.EMPLOYEE);
				userList.add(userbean);

			}
			
			if(results!=null){
				results.close();
			}

		} catch (CommunicationException connectionLostEx) {
			bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"Ldaputility : Lost Ldap Connection. " + connectionLostEx);
			try {
				ldapContext = ldapConfiguration.ldapContextSource();
				return getADUsers(user);
			} catch (NamingException e) {
				bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
						"Ldaputility : Naming Exception. " + e);
			}
		} catch (Exception e) {
			bflLoggerUtil.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"Ldaputility : Exception while getting Ldap data. " + e);
		}

		return userList;
	}

	private static String computeFilter(User user) {
		StringBuilder strBfr = new StringBuilder("(&");
		if (user.getFirstName() != null) {
			strBfr.append("(name=").append(user.getFirstName()).append("*)");
		}
		if (user.getLastName() != null) {
			strBfr.append("(sn=").append(user.getLastName()).append("*)");
		}
		if (user.getMobileNumber() != null) {
			strBfr.append("(telephoneNumber=").append(user.getMobileNumber()).append(")");
		}
		if (user.getEmailId() != null) {
			strBfr.append("(mail=").append(user.getEmailId()).append(")");
		}
		if (user.getDesignation() != null) {
			strBfr.append("(title=").append(user.getDesignation()).append("*)");
		}
		strBfr.append(")");

		return strBfr.toString();
	}
}
