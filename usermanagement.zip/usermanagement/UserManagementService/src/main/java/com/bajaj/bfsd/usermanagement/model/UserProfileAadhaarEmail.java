package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the USER_PROFILE_AADHAAR_EMAILS database table.
 * 
 */
@Entity
@Table(name="USER_PROFILE_AADHAAR_EMAILS")
//@NamedQuery(name="UserProfileAadhaarEmail.findAll", query="SELECT u FROM UserProfileAadhaarEmail u")
public class UserProfileAadhaarEmail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long aadhaaremailkey;

	private String emailaddress;

	private String emailtype;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to UserProfileAadhaar
	@ManyToOne
	@JoinColumn(name="AADHAARKEY")
	private UserProfileAadhaar userProfileAadhaar;

	public UserProfileAadhaarEmail() {
	}

	public long getAadhaaremailkey() {
		return this.aadhaaremailkey;
	}

	public void setAadhaaremailkey(long aadhaaremailkey) {
		this.aadhaaremailkey = aadhaaremailkey;
	}

	public String getEmailaddress() {
		return this.emailaddress;
	}

	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}

	public String getEmailtype() {
		return this.emailtype;
	}

	public void setEmailtype(String emailtype) {
		this.emailtype = emailtype;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public UserProfileAadhaar getUserProfileAadhaar() {
		return this.userProfileAadhaar;
	}

	public void setUserProfileAadhaar(UserProfileAadhaar userProfileAadhaar) {
		this.userProfileAadhaar = userProfileAadhaar;
	}

}