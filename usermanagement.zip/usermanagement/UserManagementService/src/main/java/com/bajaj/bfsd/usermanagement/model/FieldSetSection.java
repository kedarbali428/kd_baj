package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the FIELD_SET_SECTIONS database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_SECTIONS")
//@NamedQuery(name="FieldSetSection.findAll", query="SELECT f FROM FieldSetSection f")
public class FieldSetSection implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long sectionkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal orderno;

	private BigDecimal parentsection;

	private BigDecimal sectioncd;

	private String sectionname;

	//bi-directional many-to-one association to AppCtaSection
	@OneToMany(mappedBy="fieldSetSection")
	private List<AppCtaSection> appCtaSections;

	//bi-directional many-to-one association to FieldSetAttribute
	@OneToMany(mappedBy="fieldSetSection")
	private List<FieldSetAttribute> fieldSetAttributes;

	//bi-directional many-to-one association to FieldSetMaster
	@ManyToOne
	@JoinColumn(name="FIELDSETKEY")
	private FieldSetMaster fieldSetMaster;

	public long getSectionkey() {
		return this.sectionkey;
	}

	public void setSectionkey(long sectionkey) {
		this.sectionkey = sectionkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getOrderno() {
		return this.orderno;
	}

	public void setOrderno(BigDecimal orderno) {
		this.orderno = orderno;
	}

	public BigDecimal getParentsection() {
		return this.parentsection;
	}

	public void setParentsection(BigDecimal parentsection) {
		this.parentsection = parentsection;
	}

	public BigDecimal getSectioncd() {
		return this.sectioncd;
	}

	public void setSectioncd(BigDecimal sectioncd) {
		this.sectioncd = sectioncd;
	}

	public String getSectionname() {
		return this.sectionname;
	}

	public void setSectionname(String sectionname) {
		this.sectionname = sectionname;
	}

	public List<AppCtaSection> getAppCtaSections() {
		return this.appCtaSections;
	}

	public void setAppCtaSections(List<AppCtaSection> appCtaSections) {
		this.appCtaSections = appCtaSections;
	}

	public AppCtaSection addAppCtaSection(AppCtaSection appCtaSection) {
		getAppCtaSections().add(appCtaSection);
		appCtaSection.setFieldSetSection(this);

		return appCtaSection;
	}

	public AppCtaSection removeAppCtaSection(AppCtaSection appCtaSection) {
		getAppCtaSections().remove(appCtaSection);
		appCtaSection.setFieldSetSection(null);

		return appCtaSection;
	}

	public List<FieldSetAttribute> getFieldSetAttributes() {
		return this.fieldSetAttributes;
	}

	public void setFieldSetAttributes(List<FieldSetAttribute> fieldSetAttributes) {
		this.fieldSetAttributes = fieldSetAttributes;
	}

	public FieldSetAttribute addFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		getFieldSetAttributes().add(fieldSetAttribute);
		fieldSetAttribute.setFieldSetSection(this);

		return fieldSetAttribute;
	}

	public FieldSetAttribute removeFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		getFieldSetAttributes().remove(fieldSetAttribute);
		fieldSetAttribute.setFieldSetSection(null);

		return fieldSetAttribute;
	}

	public FieldSetMaster getFieldSetMaster() {
		return this.fieldSetMaster;
	}

	public void setFieldSetMaster(FieldSetMaster fieldSetMaster) {
		this.fieldSetMaster = fieldSetMaster;
	}

}