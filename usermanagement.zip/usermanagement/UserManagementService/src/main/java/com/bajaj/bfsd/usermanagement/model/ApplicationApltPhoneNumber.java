package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the APPLICATION_APLT_PHONE_NUMBERS database table.
 * 
 */
@Entity
@Table(name="APPLICATION_APLT_PHONE_NUMBERS")
//@NamedQuery(name="ApplicationApltPhoneNumber.findAll", query="SELECT a FROM ApplicationApltPhoneNumber a")
public class ApplicationApltPhoneNumber implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long appapltphnumkey;

	private BigDecimal aapisactive;

	private String aaplstupdateby;

	private Timestamp aaplstupdatedt;

	//bi-directional many-to-one association to ApplicantPhoneNumber
	@ManyToOne
	@JoinColumn(name="APLTPHNUMKEY")
	private ApplicantPhoneNumber applicantPhoneNumber;

	//bi-directional many-to-one association to ApplicationApplicant
	@ManyToOne
	@JoinColumn(name="APPAPLTKEY")
	private ApplicationApplicant applicationApplicant;
	
	private BigDecimal apltphnumisverified;

	private Timestamp apltphnumverifydt;

	public ApplicationApltPhoneNumber() {
	}

	public long getAppapltphnumkey() {
		return this.appapltphnumkey;
	}

	public void setAppapltphnumkey(long appapltphnumkey) {
		this.appapltphnumkey = appapltphnumkey;
	}

	public BigDecimal getAapisactive() {
		return this.aapisactive;
	}

	public void setAapisactive(BigDecimal aapisactive) {
		this.aapisactive = aapisactive;
	}

	public String getAaplstupdateby() {
		return this.aaplstupdateby;
	}

	public void setAaplstupdateby(String aaplstupdateby) {
		this.aaplstupdateby = aaplstupdateby;
	}

	public Timestamp getAaplstupdatedt() {
		return this.aaplstupdatedt;
	}

	public void setAaplstupdatedt(Timestamp aaplstupdatedt) {
		this.aaplstupdatedt = aaplstupdatedt;
	}

	public ApplicantPhoneNumber getApplicantPhoneNumber() {
		return this.applicantPhoneNumber;
	}

	public void setApplicantPhoneNumber(ApplicantPhoneNumber applicantPhoneNumber) {
		this.applicantPhoneNumber = applicantPhoneNumber;
	}

	public ApplicationApplicant getApplicationApplicant() {
		return this.applicationApplicant;
	}

	public void setApplicationApplicant(ApplicationApplicant applicationApplicant) {
		this.applicationApplicant = applicationApplicant;
	}

	public BigDecimal getApltphnumisverified() {
		return apltphnumisverified;
	}

	public void setApltphnumisverified(BigDecimal apltphnumisverified) {
		this.apltphnumisverified = apltphnumisverified;
	}

	public Timestamp getApltphnumverifydt() {
		return apltphnumverifydt;
	}

	public void setApltphnumverifydt(Timestamp apltphnumverifydt) {
		this.apltphnumverifydt = apltphnumverifydt;
	}
	
	

}