package com.bajaj.openmarkets.usermanagement.cache.entity;

import java.io.Serializable;
import java.util.Map;

public class CacheAdditionalInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6246678074651287810L;
	private Long userKey;
	private Long applicationKey;
	private Long applicantKey;
	private Long userRoleKey;
	private Map<String,Object> resourceMap;

	public CacheAdditionalInfo() {
	}

	public CacheAdditionalInfo(Long userKey, Long applicationKey, Long applicantKey,Map<String,Object> resourceMap) {
		super();
		this.userKey = userKey;
		this.applicationKey = applicationKey;
		this.applicantKey = applicantKey;
		this.resourceMap=resourceMap;
	}
	
	public CacheAdditionalInfo(Long userRoleKey) {
		super();
		this.userRoleKey = userRoleKey;
	}

	public Long getUserKey() {
		return userKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}
	
	public Long getUserRoleKey() {
		return userRoleKey;
	}
	
	public Map<String, Object> getResourceMap() {
		return resourceMap;
	}

	@Override
	public String toString() {
		return "CacheAdditionalInfo [userKey=" + userKey + ", applicationKey=" + applicationKey + ", applicantKey="
				+ applicantKey + ", userRoleKey=" + userRoleKey + ", resourceMap=" + resourceMap + "]";
	}

	

}
