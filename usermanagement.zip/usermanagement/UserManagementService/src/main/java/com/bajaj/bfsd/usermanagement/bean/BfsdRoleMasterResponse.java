package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class BfsdRoleMasterResponse implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private long roleKey;

	private BigDecimal isActive;

	private String roleCode;

	private String roleName;

	private BigDecimal functionCode;
	
	private String functionDesc;
	
	public long getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(long roleKey) {
		this.roleKey = roleKey;
	}

	public BigDecimal getIsActive() {
		return isActive;
	}

	public void setIsActive(BigDecimal isActive) {
		this.isActive = isActive;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public BigDecimal getFunctionCode() {
		return functionCode;
	}

	public void setFunctionCode(BigDecimal functionCode) {
		this.functionCode = functionCode;
	}

	public String getFunctionDesc() {
		return functionDesc;
	}

	public void setFunctionDesc(String functionDesc) {
		this.functionDesc = functionDesc;
	}
	
	
}
