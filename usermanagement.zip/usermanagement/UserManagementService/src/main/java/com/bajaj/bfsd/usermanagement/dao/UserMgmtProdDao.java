package com.bajaj.bfsd.usermanagement.dao;

import java.util.List;

import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.model.ProductMaster;
import com.bajaj.bfsd.usermanagement.model.UserRoleL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleProductL3;
import com.bajaj.bfsd.usermanagement.model.UtmSourceChannelMaster;

public interface UserMgmtProdDao {

	public UserRoleL3 saveUserMapping(UserRoleL3 userRoleL3);

	public List<UserRoleProductL3> getUserProdMapping(Long userRoleKey, Long loanProdKey, Long prodMastKey);

	public List<SupervisorBean> getUserSuperVisor(long roleKey, long prodKey, long subProdKey);

	public UserConfigurationBean getUserDetails(UserConfigurationBean userConfig,HttpHeaders headers);

	public List<Object[]> getUserRoleProductsByUserKey(long userKey);

	public List<LocationBean> getSuperVisorLocations(long userRoleProdKey);

	public List<ChannelBean> getSuperVisorChannels(long userRoleProdKey);

	public UserRoleL3 fetchUserRole(long userKey, long roleKey);

	public <T> T getEntity(Class<T> clazz, Long key);

	public List<Long> getAllLocations();

	public List<Long> getAllChannels();

	public List<Long> getPincodesByLoc(List<Long> locKeyList);

	public List<Object[]> getUserProfileByUserKey(long userKey);
	
	public boolean deleteUserMapping(UserRoleL3 userRole);

	boolean getSupervisor(long userRoleProdKey); 
	
	public List<UtmSourceChannelMaster> getUTMSourceMapping(List<Long> utmMastKey);

	public UserRoleL3 findUserRoleKey(long userrolekey);

	public List<ProductMaster> findAllMasterProducts();
	public UserConfigurationBean getAdditionalUserDetails(UserConfigurationBean userConfig);

	public List<Object[]> loadUserData();
}
