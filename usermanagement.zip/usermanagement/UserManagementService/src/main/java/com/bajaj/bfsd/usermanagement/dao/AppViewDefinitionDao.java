package com.bajaj.bfsd.usermanagement.dao;

import com.bajaj.bfsd.usermanagement.model.AppViewDefinition;

@FunctionalInterface
public interface AppViewDefinitionDao {
	AppViewDefinition createAndSaveAppViewDefinition(Long userKey, Integer viewAccess, Long userRoleKey, String condition);
}
