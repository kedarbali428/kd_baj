package com.bajaj.openmarkets.usermanagement.dao;

import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bajaj.openmarkets.usermanagement.bean.UserRequest;

public interface OMUserManagementDao {

	public UserLoginAccount getUserAccount(UserRequest userRequest);
	
	public UserRole getUserRole(long userKey, long roleKey);
}
