package com.bajaj.bfsd.usermanagement.model;


import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the PRODUCT_MASTER database table.
 * 
 */
@Entity
@Table(name="PRODUCT_MASTER")
//@NamedQuery(name="ProductMaster.findAll", query="SELECT p FROM ProductMaster p")
@NamedQuery(name="ProductMaster.findActive", query="SELECT p FROM ProductMaster p where p.prodmastisactive = 1")
public class ProductMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long prodmastkey;

	private String prodmastassestlibilityflag;

	private String prodmastcode;

	private String prodmastdesc;

	private BigDecimal prodmastisactive;

	private String prodmastlstupdateby;

	private Timestamp prodmastlstupdatedt;

	//bi-directional many-to-one association to ProductCategory
	@OneToMany(mappedBy="productMaster")
	private List<ProductCategory> productCategories;

	public long getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(long prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public String getProdmastassestlibilityflag() {
		return this.prodmastassestlibilityflag;
	}

	public void setProdmastassestlibilityflag(String prodmastassestlibilityflag) {
		this.prodmastassestlibilityflag = prodmastassestlibilityflag;
	}

	public String getProdmastcode() {
		return this.prodmastcode;
	}

	public void setProdmastcode(String prodmastcode) {
		this.prodmastcode = prodmastcode;
	}

	public String getProdmastdesc() {
		return this.prodmastdesc;
	}

	public void setProdmastdesc(String prodmastdesc) {
		this.prodmastdesc = prodmastdesc;
	}

	public BigDecimal getProdmastisactive() {
		return this.prodmastisactive;
	}

	public void setProdmastisactive(BigDecimal prodmastisactive) {
		this.prodmastisactive = prodmastisactive;
	}

	public String getProdmastlstupdateby() {
		return this.prodmastlstupdateby;
	}

	public void setProdmastlstupdateby(String prodmastlstupdateby) {
		this.prodmastlstupdateby = prodmastlstupdateby;
	}

	public Timestamp getProdmastlstupdatedt() {
		return this.prodmastlstupdatedt;
	}

	public void setProdmastlstupdatedt(Timestamp prodmastlstupdatedt) {
		this.prodmastlstupdatedt = prodmastlstupdatedt;
	}

	public List<ProductCategory> getProductCategories() {
		return this.productCategories;
	}

	public void setProductCategories(List<ProductCategory> productCategories) {
		this.productCategories = productCategories;
	}

	public ProductCategory addProductCategory(ProductCategory productCategory) {
		getProductCategories().add(productCategory);
		productCategory.setProductMaster(this);

		return productCategory;
	}

	public ProductCategory removeProductCategory(ProductCategory productCategory) {
		getProductCategories().remove(productCategory);
		productCategory.setProductMaster(null);

		return productCategory;
	}

}