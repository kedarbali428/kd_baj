package com.bajaj.bfsd.usermanagement.deserializer;

import java.io.IOException;

import com.bajaj.bfsd.usermanagement.bean.FacebookProfileBean;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

public class FacebookResponseDeserializer extends JsonDeserializer<FacebookProfileBean>{

	@Override
	public FacebookProfileBean deserialize(JsonParser jp, DeserializationContext ctxt)
			throws IOException{
		
		FacebookProfileBean facebookBean = new FacebookProfileBean();  
		
		JsonNode rootNode = jp.getCodec().readTree(jp);
		
		facebookBean.setFirstName(rootNode.get("first_name").asText());
		facebookBean.setLastName(rootNode.get("last_name").asText());
		facebookBean.setEmail(rootNode.get("email").asText());
		facebookBean.setProfileId(rootNode.get("id").asText());
		facebookBean.setVerified(rootNode.get("is_verified").asBoolean());
		facebookBean.setProfileLink(rootNode.get("link").asText());
		
		JsonNode ageRange = rootNode.get("age_range");
		facebookBean.setAgeRangeMin(ageRange.get("min").asText());
		
		return facebookBean;
	}

}
