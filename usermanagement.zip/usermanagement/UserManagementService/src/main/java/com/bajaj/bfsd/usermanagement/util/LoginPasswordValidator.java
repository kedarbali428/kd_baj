package com.bajaj.bfsd.usermanagement.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;

@Component
public class LoginPasswordValidator extends BFLComponent{

	  private Pattern patternPassword;
	  private Pattern patternLogin;

	  private static final String PASSWORD_PATTERN =//NOSONAR
			  "((?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{8,})";
	  
	  private static final String LOGIN_PATTERN = "^(.+)@(.+)$";


	  public LoginPasswordValidator(){
		  this.patternPassword = Pattern.compile(PASSWORD_PATTERN);
		  this.patternLogin = Pattern.compile(LOGIN_PATTERN);
	  }

	  /**
	   * Validate password with regular expression
	   * @param password password for validation
	   * @return true valid password, false invalid password
	   */
	  public boolean validateLogin(final String login){

		  boolean valid = false;
		
		  Matcher matcherLogin = patternLogin.matcher(login);
		  
		  if(matcherLogin.matches())
			  valid = true;
		  
		  return valid;

	  }
	  
	  /**
	   * Validate password with regular expression
	   * @param password password for validation
	   * @return true valid password, false invalid password
	   */
	  public boolean validatePassword(final String password){

		  boolean valid = false;
		  Matcher matcherPassword = patternPassword.matcher(password);		
		  
		  if(matcherPassword.matches())
			  valid = true;
		  
		  return valid;

	  }
}