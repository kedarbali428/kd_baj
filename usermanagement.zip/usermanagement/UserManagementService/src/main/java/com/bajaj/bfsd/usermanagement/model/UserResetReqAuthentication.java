package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the USER_RESET_REQ_AUTHENTICATION database table.
 * 
 */
@Entity
@Table(name="USER_RESET_REQ_AUTHENTICATION")
//@NamedQuery(name="UserResetReqAuthentication.findAll", query="SELECT u FROM UserResetReqAuthentication u")
public class UserResetReqAuthentication implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long userresetreqauthkey;

	private String authtoken;

	private String browser;

	private String deviceid;

	private String ipaddress;

	private BigDecimal isactive;

	private BigDecimal latitude;

	private BigDecimal longitude;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private Timestamp reqauthdt;

	private BigDecimal reqauthsts;

	//bi-directional many-to-one association to UserResetRequest
	@ManyToOne
	@JoinColumn(name="USERRESETREQKEY")
	private UserResetRequest userResetRequest;

	public long getUserresetreqauthkey() {
		return this.userresetreqauthkey;
	}

	public void setUserresetreqauthkey(long userresetreqauthkey) {
		this.userresetreqauthkey = userresetreqauthkey;
	}

	public String getAuthtoken() {
		return this.authtoken;
	}

	public void setAuthtoken(String authtoken) {
		this.authtoken = authtoken;
	}

	public String getBrowser() {
		return this.browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getDeviceid() {
		return this.deviceid;
	}

	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	public String getIpaddress() {
		return this.ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public BigDecimal getLatitude() {
		return this.latitude;
	}

	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	public BigDecimal getLongitude() {
		return this.longitude;
	}

	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Timestamp getReqauthdt() {
		return this.reqauthdt;
	}

	public void setReqauthdt(Timestamp reqauthdt) {
		this.reqauthdt = reqauthdt;
	}

	public BigDecimal getReqauthsts() {
		return this.reqauthsts;
	}

	public void setReqauthsts(BigDecimal reqauthsts) {
		this.reqauthsts = reqauthsts;
	}

	public UserResetRequest getUserResetRequest() {
		return this.userResetRequest;
	}

	public void setUserResetRequest(UserResetRequest userResetRequest) {
		this.userResetRequest = userResetRequest;
	}

}