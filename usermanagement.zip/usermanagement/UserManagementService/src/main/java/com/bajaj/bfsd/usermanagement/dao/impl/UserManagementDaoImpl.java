package com.bajaj.bfsd.usermanagement.dao.impl;

import static com.bajaj.bfsd.common.BFLLoggerComponent.DAO;
import static com.bajaj.bfsd.usermanagement.util.QueryConstants.FETCH_USERS_NAMES;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_1;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_2;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_3;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_4;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_5;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_6;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DAO_7;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.FlushModeType;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterRequest;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.DeleteUserRoleBean;
import com.bajaj.bfsd.usermanagement.bean.EmployeeRoleDetails;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.ProductBean;
import com.bajaj.bfsd.usermanagement.bean.ReportingManager;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.User;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountRequest;
import com.bajaj.bfsd.usermanagement.bean.UserMapping;
import com.bajaj.bfsd.usermanagement.bean.UserMappingRequest;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.bean.UserProfileDetails;
import com.bajaj.bfsd.usermanagement.bean.UserRoleBean;
import com.bajaj.bfsd.usermanagement.bean.UserVendorProfileBean;
import com.bajaj.bfsd.usermanagement.bean.ValidateTokenBean;
import com.bajaj.bfsd.usermanagement.beanmapper.BeanMapper;
import com.bajaj.bfsd.usermanagement.dao.UserManagementDao;
import com.bajaj.bfsd.usermanagement.dao.UserMgmtProdDao;
import com.bajaj.bfsd.usermanagement.helper.UserManagementHelper;
import com.bajaj.bfsd.usermanagement.model.AppContactAuthRequest;
import com.bajaj.bfsd.usermanagement.model.AppContactAuthValidation;
import com.bajaj.bfsd.usermanagement.model.AppRoleView;
import com.bajaj.bfsd.usermanagement.model.AppUserAssignment;
import com.bajaj.bfsd.usermanagement.model.AppUserView;
import com.bajaj.bfsd.usermanagement.model.AppViewDefinition;
import com.bajaj.bfsd.usermanagement.model.BfsdRoleMaster;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.CityMaster;
import com.bajaj.bfsd.usermanagement.model.ProductMaster;
import com.bajaj.bfsd.usermanagement.model.SerReqRoleView;
import com.bajaj.bfsd.usermanagement.model.SerReqUserView;
import com.bajaj.bfsd.usermanagement.model.SerReqViewDefinition;
import com.bajaj.bfsd.usermanagement.model.UserAddlAttributes;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.model.UserProfile;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bajaj.bfsd.usermanagement.model.UserRoleChannel;
import com.bajaj.bfsd.usermanagement.model.UserRoleL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleLocation;
import com.bajaj.bfsd.usermanagement.model.UserRolePinCode;
import com.bajaj.bfsd.usermanagement.model.UserRoleProduct;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataPluginMapper;
import com.bajaj.bfsd.usermanagement.repository.BfsdRoleMasterRepository;
import com.bajaj.bfsd.usermanagement.repository.UserAddlAttributesRepository;
import com.bajaj.bfsd.usermanagement.util.Ldaputility;
import com.bajaj.bfsd.usermanagement.util.QueryConstants;
import com.bajaj.bfsd.usermanagement.util.Trie;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.bfsd.usermanagement.util.UserManagementUtility;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.bfsd.om.bean.UserRoleProductBean;

@RefreshScope
@Repository
public class UserManagementDaoImpl extends BFLComponent implements UserManagementDao {

	public static final String SYSTEM = "SYSTEM";
	public static final String ISACTIVE = "isactive";
	public static final String LOGINID = "loginid";
	public static final String LOGIN_ACCT_TYPE = "loginAcctType";
	public static final String UMS_018 = "UMS-018";
	public static final String UMS_017 = "UMS-017";
	public static final String UMS_024 = "UMS-024";
	public static final String UMS_016 = "UMS-016";
	public static final String UMS_033 = "UMS-033";
	public static final String OLD_LOGIN_ID = "oldloginid";
	public static final String FETCH_ROLE_MASTER_QUERY = "SELECT rm.rolename, rm.rolekey,rm.isactive,rm.rolecd FROM BFSD_ROLE_MASTER rm WHERE rm.rolekey=:rolekey AND rm.isactive= 1;";
	
	
	@Value("${maxLoginAttempts}")
	private short maxLoginAttempts;

	@Autowired
	EntityManager entityManager;

	@Autowired
	Environment environment;

	@Autowired
	UserManagementHelper userManagementHelper;

	@Autowired
	EntityManagerFactory entityManagerFactory;

	@Autowired
	private BFLLoggerUtil bflLoggerUtil;

	@Autowired
	Ldaputility ldaputility;

	@Autowired
	BeanMapper beanMapper;

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	@RequestScoped
	CustomDefaultHeaders custmHeaders;

	@Autowired
	UserProfileBean upb;
	//Start Added for Partner Portal
	@Autowired
	UserMgmtProdDao userMgmtProdDao;
	//End Added for Partner Portal

	@Autowired
	OMMasterDataPluginMapper omMasterDataPluginMapper;
	
	@Autowired
	BfsdRoleMasterRepository bfsdRoleMasterRepository;
	
	@Autowired
	UserAddlAttributesRepository userAddlAttributesRepository;
	
	public Trie<ReportingManager> trieDataStructure;
	
	private static final String THIS_CLASS = UserManagementDaoImpl.class.getSimpleName();

	@Transactional
	@Override
	public BfsdUser createUser(User userBean) {

		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setIsactive(userBean.getIsActive());
		bfsdUser.setUsertype(new BigDecimal(2));
		bfsdUser.setRegistrationdate(UserManagementUtility.getCurrentTimeStamp());
		bfsdUser.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
		bfsdUser.setUserblockedflg(new BigDecimal(0));
		
		if(null != userBean.getStatusChngReason()){
			bfsdUser.setStatuschngreason(userBean.getStatusChngReason());
		}
		
		if (StringUtils.isNotBlank(userBean.getEmployeeType())
				&& (userBean.getEmployeeType().equalsIgnoreCase(UserManagementConstants.VENDOR_COMPANY)
						|| userBean.getEmployeeType().equalsIgnoreCase(UserManagementConstants.VENDOR_INDIVIDUAL))) {
			bfsdUser.setUsertype(new BigDecimal(3)); // Set user type as third
														// party vendor
			bfsdUser.setIsactive(BigDecimal.ONE);
			UserVendorProfileBean userVendorProfileBean = userBean.getUserVendorProfile();
			userBean.setEmailId(userVendorProfileBean.getEmailId());
			UserProfile userVendorProfile = new UserProfile();
			UserProfile.getEntityFromBean(userVendorProfileBean, userVendorProfile);
			userVendorProfile.setBfsdUser(bfsdUser);
			userVendorProfile.setAssociationdt(UserManagementUtility.getCurrentDateTimeStamp());
			userVendorProfile.setAssociationtype(BigDecimal.valueOf(userVendorProfileBean.getAssociationType()));
			userVendorProfile.setEmailid(userVendorProfileBean.getEmailId());
			userVendorProfile.setIsactive(BigDecimal.ONE);
			userVendorProfile.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
			userVendorProfile.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());

			if (userVendorProfileBean.getCompanyId() != null && userVendorProfileBean.getCompanyId() != 0) {
				UserProfile parentCompany = getEntity(UserProfile.class,
						userVendorProfileBean.getCompanyId());
				if (parentCompany != null) {
					userVendorProfile.setParentCompany(parentCompany);
					userVendorProfile.setCompanyname(parentCompany.getCompanyname());
				}
			}
			List<UserProfile> userProfiles = new ArrayList<>();
			userProfiles.add(userVendorProfile);
			bfsdUser.setUserProfiles(userProfiles);
			
		}else if (StringUtils.isNotBlank(userBean.getEmployeeType())
				&& (userBean.getEmployeeType().equalsIgnoreCase(UserManagementConstants.PRINCIPAL_USER))) {
			bfsdUser.setUsertype(new BigDecimal(6)); // Set user type as Prinicipal User			
			bfsdUser.setIsactive(BigDecimal.ONE);
			UserVendorProfileBean userVendorProfileBean = userBean.getUserVendorProfile();
			userBean.setEmailId(userVendorProfileBean.getEmailId());
			UserProfile userVendorProfile = new UserProfile();
			UserProfile.getEntityFromBean(userVendorProfileBean, userVendorProfile);
			userVendorProfile.setBfsdUser(bfsdUser);
			userVendorProfile.setAssociationdt(UserManagementUtility.getCurrentDateTimeStamp());
			userVendorProfile.setAssociationtype(BigDecimal.valueOf(userVendorProfileBean.getAssociationType()));
			userVendorProfile.setEmailid(userVendorProfileBean.getEmailId());
			userVendorProfile.setIsactive(BigDecimal.ONE);
			userVendorProfile.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
			userVendorProfile.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			
			userVendorProfile.setCompanyname(userVendorProfileBean.getPrincipalUserName());
			
			List<UserProfile> userProfiles = new ArrayList<>();
			userProfiles.add(userVendorProfile);
			bfsdUser.setUserProfiles(userProfiles);
		}  else {
			UserProfile userProfile = new UserProfile();
			userProfile.setEmailid(userBean.getEmailId());
			userProfile.setFirstname(userBean.getFirstName());
			userProfile.setLastname(userBean.getLastName());
			userProfile.setMobileno(userBean.getMobileNumber());
			userProfile.setDesignation(userBean.getDesignation());
			userProfile.setIsactive(userBean.getIsActive());
			userProfile.setAssociationtype(new BigDecimal(1));
			userProfile.setAssociationdt(UserManagementUtility.getCurrentTimeStamp());
			userProfile.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
			userProfile.setLstupdateby(SYSTEM); // TO-DO FIX
			userProfile.setBfsdUser(bfsdUser);
			List<UserProfile> userProfiles = new ArrayList<>();
			userProfiles.add(userProfile);
			bfsdUser.setUserProfiles(userProfiles);
		}

		UserLoginAccount userLoginAccount = new UserLoginAccount();
		userLoginAccount.setUserloginacctype(BigDecimal.valueOf(UserManagementConstants.LOGINACCTYPE_MANUAL)); // need
		// confirmation
		userLoginAccount.setLoginid(userBean.getEmailId()); // need confirmation
		userLoginAccount.setLoginpwd(
				UserManagementUtility.getHashedPassword(UserManagementConstants.DEFAULT_PASSWORD, bflLoggerUtil));
		userLoginAccount.setCreationdate(UserManagementUtility.getCurrentTimeStamp());
		userLoginAccount.setBfsdUser(bfsdUser);
		List<UserLoginAccount> userLoginAccounts = new ArrayList<>();
		userLoginAccounts.add(userLoginAccount);
		bfsdUser.setUserLoginAccounts(userLoginAccounts);
		if (StringUtils.isNotBlank(userBean.getReportingManager())){
			bfsdUser.setReportingManager(Long.valueOf(userBean.getReportingManager()));
		}
		bfsdUser = entityManager.merge(bfsdUser);
		
		if (!StringUtils.isEmpty(userBean.getPoType())) {
			UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
			userAddlAttributes.setAttrrkey(bfsdUser.getUserkey());
			userAddlAttributes.setAttrcode("POTYPE");
			userAddlAttributes.setAttrkeytype("USER");
			userAddlAttributes.setAttrvalue(userBean.getPoType());
			userAddlAttributes.setIsactive(1);
			userAddlAttributes.setLstupdateby(bfsdUser.getUserkey());
			userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			entityManager.merge(userAddlAttributes);
		}
		if (!StringUtils.isEmpty(userBean.getSpCode())) {
			UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
			userAddlAttributes.setAttrrkey(bfsdUser.getUserkey());
			userAddlAttributes.setAttrcode("SPCODE");
			userAddlAttributes.setAttrkeytype("USER");
			userAddlAttributes.setAttrvalue(userBean.getSpCode());
			userAddlAttributes.setIsactive(1);
			userAddlAttributes.setLstupdateby(bfsdUser.getUserkey());
			userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			entityManager.merge(userAddlAttributes);
		}
		if (!StringUtils.isEmpty(userBean.getLpCode())) {
			UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
			userAddlAttributes.setAttrrkey(bfsdUser.getUserkey());
			userAddlAttributes.setAttrcode("LPCODE");
			userAddlAttributes.setAttrkeytype("USER");
			userAddlAttributes.setAttrvalue(userBean.getLpCode());
			userAddlAttributes.setIsactive(1);
			userAddlAttributes.setLstupdateby(bfsdUser.getUserkey());
			userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			entityManager.merge(userAddlAttributes);
		}
		if (!StringUtils.isEmpty(userBean.getMaxSumAssuredLimit())) {
			UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
			userAddlAttributes.setAttrrkey(bfsdUser.getUserkey());
			userAddlAttributes.setAttrcode("MAX_SUM_ASSUR_LIMIT");
			userAddlAttributes.setAttrkeytype("USER");
			userAddlAttributes.setAttrvalue(userBean.getMaxSumAssuredLimit());
			userAddlAttributes.setIsactive(1);
			userAddlAttributes.setLstupdateby(bfsdUser.getUserkey());
			userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			entityManager.merge(userAddlAttributes);
		}
		if (!StringUtils.isEmpty(userBean.getMaxPremiumLimit())) {
			UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
			userAddlAttributes.setAttrrkey(bfsdUser.getUserkey());
			userAddlAttributes.setAttrcode("MAX_PREMIUM_LIMIT");
			userAddlAttributes.setAttrkeytype("USER");
			userAddlAttributes.setAttrvalue(userBean.getMaxPremiumLimit());
			userAddlAttributes.setIsactive(1);
			userAddlAttributes.setLstupdateby(bfsdUser.getUserkey());
			userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			entityManager.merge(userAddlAttributes);
		}
			
		if (!CollectionUtils.isEmpty(userBean.getChannel())) {
			createChannel(userBean.getChannel(), bfsdUser.getUserkey());
		}
		
		if (!CollectionUtils.isEmpty(userBean.getSpecialization())) {
			createSpecialization(userBean.getSpecialization(), bfsdUser.getUserkey());
		}
		
		if (!CollectionUtils.isEmpty(userBean.getSkills())) {
			createSkill(userBean.getSkills(), bfsdUser.getUserkey());
		}
		
		if (!CollectionUtils.isEmpty(userBean.getPaymentModes())) {
			createPaymentMode(userBean.getPaymentModes(), bfsdUser.getUserkey());
		}
		
		synchronized (this) {
			loadUserData();
		}
		
		return bfsdUser;
	}

	@Transactional
	public long createBfsdUser(long userType) {
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setIsactive(new BigDecimal(1));
		bfsdUser.setUsertype(new BigDecimal(2));
		bfsdUser.setRegistrationdate(UserManagementUtility.getCurrentTimeStamp());
		bfsdUser.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
		bfsdUser.setUserblockedflg(new BigDecimal(0));
		entityManager.persist(bfsdUser);
		entityManager.flush();
		return bfsdUser.getUserkey();
	}

	@Transactional
	@Override
	public String createUserMapping(UserMappingRequest userMappingBean) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Into createUserMapping...");
		CriteriaBuilder criteriaBlder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserRole> criteriaQry = criteriaBlder.createQuery(UserRole.class);
		Root<UserRole> rootUserRole = criteriaQry.from(UserRole.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlder.equal(rootUserRole.get("isactive"), new BigDecimal(1)));
		predicates.add(criteriaBlder.equal(rootUserRole.get("bfsdRoleMaster").get("rolekey"), // NOSONAR
				new BigDecimal(userMappingBean.getRoleKey())));
		predicates.add(criteriaBlder.equal(rootUserRole.get("bfsduser").get("userkey"), // NOSONAR
				new BigDecimal(userMappingBean.getUserKey())));
		criteriaQry.select(rootUserRole).where(predicates.toArray(new Predicate[] {}));

		List<UserRole> existUserRole = entityManager.createQuery(criteriaQry).getResultList();
		if (existUserRole != null && !existUserRole.isEmpty()) {
			throw new BFLTechnicalException("UMS-005", "User mapping already exist.");
		}

		// BfsdUser bfsdUserSupervisor = entityManager.find(BfsdUser.class,
		// userMappingBean.getSupervisor())
		BfsdRoleMaster bfsdRoleMaster = entityManager.find(BfsdRoleMaster.class, userMappingBean.getRoleKey());
		BfsdUser bfsdUser = entityManager.find(BfsdUser.class, userMappingBean.getUserKey());
		UserRole userRole = new UserRole();
		setParentUser(userMappingBean, userRole);
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		userRole.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
		userRole.setIsactive(new BigDecimal(1));
		userRole.setLstupdateby(SYSTEM);
		userRole.setBfsduser(bfsdUser);
		userRole.setCreditlimit(new BigDecimal(userMappingBean.getCreditLimit()));
		if (StringUtils.isNotBlank(userMappingBean.getEmployeeType())
				&& userMappingBean.getEmployeeType().equals(UserManagementConstants.EMPLOYEE)
				&& userMappingBean.isHighestRole()) {
			CriteriaQuery<ProductMaster> criteriaQry2 = criteriaBlder.createQuery(ProductMaster.class);
			Root<ProductMaster> rootProductMaster = criteriaQry2.from(ProductMaster.class);
			criteriaQry2.select(rootProductMaster);
			entityManager.createQuery(criteriaQry2).getResultList();
			updateUserMapForHighestRole(userMappingBean);
		}

		// Added all branch & channel to User highest role.(excluding vendor
		// users)
		if (StringUtils.isNotBlank(userMappingBean.getEmployeeType())
				&& userMappingBean.getEmployeeType().equals(UserManagementConstants.EMPLOYEE)
				&& userMappingBean.isHighestRoleForUser()) {
			updateUserMapForHighestRole(userMappingBean);
		}

		updateAssociateEntity(userMappingBean, userRole);

		UserRole userRole1 = entityManager.merge(userRole);
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "User-role Mapping saved...");
		setdefaultLoanAppViewMapping(userRole1);
		setdefaultServiceReqViewMapping(userRole1);
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Started Replication for userrolemapping created");

		return "SUCCESS";
	}

	private void setParentUser(UserMappingRequest userMappingBean, UserRole userRole) {
		if (!userMappingBean.isHighestRole()) {
			setSupervisor(userMappingBean, userRole);
		}
	}

	private void setSupervisor(UserMappingRequest userMappingBean, UserRole userRole) {
		if (userMappingBean.getSupervisor() != null) {
			userRole.setParentuser(new BigDecimal(userMappingBean.getSupervisor()));
		}
	}

	@Transactional
	@Override
	public String updateUserMapping(UserMappingRequest userMappingBean) {

		Long existingRole = userMappingBean.getOldMappingRequest().getRoleKey();
		Long newRole = userMappingBean.getRoleKey();
		Long existingSupervisor = null;
		if (userMappingBean.getOldMappingRequest() != null) {
			existingSupervisor = userMappingBean.getOldMappingRequest().getSupervisor();
		}
		Long newSupervisor = userMappingBean.getSupervisor();
		
		List<UserRole> userRoles = getUserRoles(userMappingBean, existingRole);
		UserRole userRole;
		if (userRoles != null && !userRoles.isEmpty()) {
			userRole = userRoles.get(0);
		} else {
			throw new BFLBusinessException(UMS_016, environment.getProperty(UMS_016));
		}

		if (newRole != existingRole) {
			userRole.setIsactive(new BigDecimal(0));
			updateInactiveField(userRole);

			entityManager.merge(userRole);
			createUserMapping(userMappingBean);
		} else {
			updateMapping(userMappingBean, existingSupervisor, newSupervisor, userRole);
		}

		return "SUCCESS";
	}

	private void updateMapping(UserMappingRequest userMappingBean, Long existingSupervisor, Long newSupervisor,
			UserRole userRole) {
		EntityManager em = entityManagerFactory.createEntityManager();
		List<Long> existingChannelKey = userMappingBean.getOldMappingRequest().getUserChannelkey() == null
				? new ArrayList<>() : userMappingBean.getOldMappingRequest().getUserChannelkey();
		List<Long> newChannelKey = userMappingBean.getUserChannelkey() == null ? new ArrayList<>()
				: userMappingBean.getUserChannelkey();
		List<Long> existingpinCodeKey = userMappingBean.getOldMappingRequest().getUserPinCdKey() == null
				? new ArrayList<>() : userMappingBean.getOldMappingRequest().getUserPinCdKey();
		List<Long> newpinCodeKey = userMappingBean.getUserPinCdKey() == null ? new ArrayList<>()
				: userMappingBean.getUserPinCdKey();
		List<Long> existingLocationKey = userMappingBean.getOldMappingRequest().getUserlockey() == null
				? new ArrayList<>() : userMappingBean.getOldMappingRequest().getUserlockey();
		List<Long> newLocationKey = userMappingBean.getUserlockey() == null ? new ArrayList<>()
				: userMappingBean.getUserlockey();

		try {

			em.setFlushMode(FlushModeType.COMMIT);
			em.getTransaction().begin();

			// Added all branch & channel to User highest role (excluding
			// vendor users).
			if (StringUtils.isNotBlank(userMappingBean.getEmployeeType())
					&& (!userMappingBean.getEmployeeType().equals(UserManagementConstants.VENDOR_COMPANY)
							|| !userMappingBean.getEmployeeType().equals(UserManagementConstants.VENDOR_INDIVIDUAL))
					&& userMappingBean.isHighestRoleForUser()) {
				updateHighRoleForUser(userMappingBean, userRole);
			} else {
				updateLocation(existingLocationKey, newLocationKey, em, userRole);
				updateChannel(existingChannelKey, newChannelKey, em, userRole);
				updatePinCode(existingpinCodeKey, newpinCodeKey, em, userRole);
			}

			setLoanProduct(userMappingBean, em);
			em.flush();
			em.getTransaction().commit();

		} catch (Exception exp) {
			em.getTransaction().rollback();
			logMessage("" + exp);
			throw new BFLBusinessException(UMS_017, environment.getProperty(UMS_017));
		}finally{
			em.close();
		}

		if (newSupervisor != existingSupervisor) {
			userRole.setParentuser(new BigDecimal(newSupervisor));
		}
		if (userMappingBean.getCreditLimit() != userMappingBean.getOldMappingRequest().getCreditLimit()) {
			userRole.setCreditlimit(new BigDecimal(userMappingBean.getCreditLimit()));
		}
		entityManager.merge(userRole);
	}

	private List<UserRole> getUserRoles(UserMappingRequest userMappingBean, Long existingRole) {
		CriteriaBuilder criteriaBlder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserRole> criteriaQry = criteriaBlder.createQuery(UserRole.class);
		Root<UserRole> rootUserRole = criteriaQry.from(UserRole.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlder.equal(rootUserRole.get(ISACTIVE), new BigDecimal(1)));
		predicates.add(
				criteriaBlder.equal(rootUserRole.get("bfsdRoleMaster").get("rolekey"), new BigDecimal(existingRole)));
		predicates.add(criteriaBlder.equal(rootUserRole.get("bfsduser").get("userkey"),
				new BigDecimal(userMappingBean.getUserKey())));

		criteriaQry.select(rootUserRole).where(predicates.toArray(new Predicate[] {}));
		List<UserRole> userRoles = entityManager.createQuery(criteriaQry).getResultList();
		return userRoles;
	}

	private void setLoanProduct(UserMappingRequest userMappingBean, EntityManager em) {
		List<Long> newProdKey = new ArrayList<>();
		for (ProductBean productBean : userMappingBean.getLoanproduct()) {
			newProdKey.addAll(productBean.getLoanProductType());
		}

		List<Long> existingProdKey = new ArrayList<>();
		for (ProductBean productBean : userMappingBean.getOldMappingRequest().getLoanproduct()) {
			existingProdKey.addAll(productBean.getLoanProductType());
		}
		updateProduct(existingProdKey, newProdKey, userMappingBean, em);
	}

	private void updateHighRoleForUser(UserMappingRequest userMappingBean, UserRole userRole) {
		Query qry = entityManager.createNativeQuery("DELETE from USER_ROLE_CHANNELS where USERROLEKEY= :userRoleKey");
		qry.setParameter(QueryConstants.QRY_PARAM_USER_ROLE_KEY, userRole.getUserrolekey());
		int isUpdated = qry.executeUpdate();
		if (isUpdated < 0) {
			throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
		}

		qry = entityManager.createNativeQuery("DELETE from USER_ROLE_LOCATIONS where USERROLEKEY= :userRoleKey");
		qry.setParameter(QueryConstants.QRY_PARAM_USER_ROLE_KEY, userRole.getUserrolekey());
		isUpdated = qry.executeUpdate();
		if (isUpdated < 0) {
			throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
		}
		updateUserMapForHighestRole(userMappingBean);

		updateUserLocForHighRole(userMappingBean, userRole);

		updateUserChannelForHighRole(userMappingBean, userRole);

		updatePinForhighRole(userMappingBean, userRole);
	}

	private void updateUserChannelForHighRole(UserMappingRequest userMappingBean, UserRole userRole) {
		List<UserRoleChannel> userRoleChannels = new ArrayList<>();
		if (userMappingBean.getUserChannelkey() != null) {
			for (Long channelkey : userMappingBean.getUserChannelkey()) {
				UserRoleChannel userRoleChannel = new UserRoleChannel();
				userRoleChannel.setUserRole(userRole);
				userRoleChannel.setIsactive(new BigDecimal(1));
				userRoleChannel.setChanneltypekey(new BigDecimal(channelkey));
				userRoleChannel.setLstupdateby(SYSTEM);
				userRoleChannel.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				userRoleChannel.setUserRole(userRole);
				userRoleChannels.add(userRoleChannel);
			}
		}
		userRole.setUserRoleChannels(userRoleChannels);
	}

	private void updateUserLocForHighRole(UserMappingRequest userMappingBean, UserRole userRole) {
		List<UserRoleLocation> userRoleLocations = new ArrayList<>();
		if (userMappingBean.getUserlockey() != null) {
			for (Long lockey : userMappingBean.getUserlockey()) {
				UserRoleLocation userRoleLocation = new UserRoleLocation();

				userRoleLocation.setIsactive(new BigDecimal(1));
				userRoleLocation.setLstupdateby(SYSTEM);
				userRoleLocation.setLstupdatedt(new Timestamp(1));
				userRoleLocation.setBflbranchkey(new BigDecimal(lockey)); // To_DO
																			// FIX
				userRoleLocation.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				userRoleLocation.setUserRole(userRole);
				userRoleLocations.add(userRoleLocation);
			}
		}
		userRole.setUserRoleLocations(userRoleLocations);
	}

	private void updateChannel(List<Long> existingLocationKey, List<Long> newLocationKey, EntityManager em,
			UserRole userRole) {
		List<Long> deactiveLocnList = new ArrayList<>();
		List<Long> newlyAddedLocnList = new ArrayList<>();

		// we need to iterate to the list to find if any existing loc key to be
		// diactivated
		for (Long existingLocnKey : existingLocationKey) {

			if (!newLocationKey.contains(existingLocnKey)) {
				deactiveLocnList.add(existingLocnKey);
			}
		}
		for (Long newLocnKey : newLocationKey) {

			if (!existingLocationKey.contains(newLocnKey)) {
				newlyAddedLocnList.add(newLocnKey);
			}
		}

		CriteriaBuilder criteriaBlder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserRoleChannel> criteriaQry = criteriaBlder.createQuery(UserRoleChannel.class);
		Root<UserRoleChannel> rootUserRoleChannel = criteriaQry.from(UserRoleChannel.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlder.equal(rootUserRoleChannel.get(ISACTIVE), new BigDecimal(1)));

		predicates.add(criteriaBlder.equal(rootUserRoleChannel.get("userRole").get("userrolekey"), // NOSONAR
				new BigDecimal(userRole.getUserrolekey())));
		criteriaQry.select(rootUserRoleChannel).where(predicates.toArray(new Predicate[] {}));
		List<UserRoleChannel> userRoleChannelList = entityManager.createQuery(criteriaQry).getResultList();

		if (!deactiveLocnList.isEmpty()) {
			for (int i = 0; i < userRoleChannelList.size(); i++) {
				UserRoleChannel userRoleChannel = userRoleChannelList.get(i);
				if (deactiveLocnList.contains(userRoleChannel.getChanneltypekey().longValue())) {
					userRoleChannelList.get(i).setIsactive(new BigDecimal(0));
					userRoleChannel = em.merge(userRoleChannel);
					em.persist(userRoleChannel);
				}
			}
		}

		if (!newlyAddedLocnList.isEmpty()) {
			for (Long newUserLoc : newlyAddedLocnList) {
				UserRoleChannel userRoleChannel = new UserRoleChannel();

				userRoleChannel.setIsactive(new BigDecimal(1));
				userRoleChannel.setChanneltypekey(new BigDecimal(newUserLoc));
				userRoleChannel.setLstupdateby(SYSTEM);
				userRoleChannel.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				userRoleChannel.setUserRole(userRoleChannelList.get(0).getUserRole());
				em.persist(userRoleChannel);

			}
		}

	}

	private void updateInactiveField(UserRole userRole) {
		for (int i = 0; i < userRole.getUserRoleChannels().size(); i++) {
			userRole.getUserRoleChannels().get(i).setIsactive(new BigDecimal(0));
		}
		for (int i = 0; i < userRole.getUserRoleLocations().size(); i++) {
			userRole.getUserRoleLocations().get(i).setIsactive(new BigDecimal(0));
		}
		for (int i = 0; i < userRole.getUserRolePinCodes().size(); i++) {
			userRole.getUserRolePinCodes().get(i).setIsactive(new BigDecimal(0));
		}
		for (int i = 0; i < userRole.getUserRoleProducts().size(); i++) {
			userRole.getUserRoleProducts().get(i).setIsactive(new BigDecimal(0));
		}
	}

	private void updateLocation(List<Long> existingLocationKey, List<Long> newLocationKey, EntityManager em,
			UserRole userRole) {

		List<Long> deactiveLocnList = new ArrayList<>();
		List<Long> newlyAddedLocnList = new ArrayList<>();

		// we need to iterate to the list to find if any existing loc key to be
		// diactivated
		for (Long existingLocnKey : existingLocationKey) {

			if (!newLocationKey.contains(existingLocnKey)) {
				deactiveLocnList.add(existingLocnKey);
			}
		}
		for (Long newLocnKey : newLocationKey) {

			if (!existingLocationKey.contains(newLocnKey)) {
				newlyAddedLocnList.add(newLocnKey);
			}
		}

		CriteriaBuilder criteriaBlder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserRoleLocation> criteriaQry = criteriaBlder.createQuery(UserRoleLocation.class);
		Root<UserRoleLocation> rootUserRoleLocation = criteriaQry.from(UserRoleLocation.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlder.equal(rootUserRoleLocation.get("userRole").get("userrolekey"),
				new BigDecimal(userRole.getUserrolekey())));

		criteriaQry.select(rootUserRoleLocation).where(predicates.toArray(new Predicate[] {}));
		List<UserRoleLocation> userRoleLocnList = entityManager.createQuery(criteriaQry).getResultList();

		if (!deactiveLocnList.isEmpty()) {
			for (int i = 0; i < userRoleLocnList.size(); i++) {
				UserRoleLocation userLocn = userRoleLocnList.get(i);
				if (deactiveLocnList.contains(userLocn.getBflbranchkey().longValue())) {
					userRoleLocnList.get(i).setIsactive(new BigDecimal(0));
					userLocn = em.merge(userLocn);
					em.persist(userLocn);
				}
			}
		}

		if (!newlyAddedLocnList.isEmpty()) {
			for (Long newUserLoc : newlyAddedLocnList) {
				UserRoleLocation userRoleLocation = new UserRoleLocation();

				userRoleLocation.setIsactive(new BigDecimal(1));
				userRoleLocation.setLstupdateby(SYSTEM);
				userRoleLocation.setLstupdatedt(new Timestamp(1));
				userRoleLocation.setBflbranchkey(new BigDecimal(newUserLoc)); // To_DO
																				// FIX
				userRoleLocation.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				userRoleLocation.setUserRole(userRoleLocnList.get(0).getUserRole());
				em.persist(userRoleLocation);

			}
		}

	}

	private void updatePinCode(List<Long> existingLocationKey, List<Long> newLocationKey, EntityManager em,
			UserRole userRole) {
		List<Long> deactiveLocnList = new ArrayList<>();
		List<Long> newlyAddedLocnList = new ArrayList<>();

		// we need to iterate to the list to find if any existing loc key to be
		// diactivated
		for (Long existingLocnKey : existingLocationKey) {

			if (!newLocationKey.contains(existingLocnKey)) {
				deactiveLocnList.add(existingLocnKey);
			}
		}
		for (Long newLocnKey : newLocationKey) {

			if (!existingLocationKey.contains(newLocnKey)) {
				newlyAddedLocnList.add(newLocnKey);
			}
		}

		CriteriaBuilder criteriaBlder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserRolePinCode> criteriaQry = criteriaBlder.createQuery(UserRolePinCode.class);
		Root<UserRolePinCode> rootUserRolePinCode = criteriaQry.from(UserRolePinCode.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlder.equal(rootUserRolePinCode.get(ISACTIVE), new BigDecimal(1)));

		predicates.add(criteriaBlder.equal(rootUserRolePinCode.get("userRole").get("userrolekey"),
				new BigDecimal(userRole.getUserrolekey())));

		criteriaQry.select(rootUserRolePinCode).where(predicates.toArray(new Predicate[] {}));
		List<UserRolePinCode> userRolepinCopdeList = entityManager.createQuery(criteriaQry).getResultList();

		if (!deactiveLocnList.isEmpty()) {
			for (int i = 0; i < userRolepinCopdeList.size(); i++) {
				UserRolePinCode userRolepinCode = userRolepinCopdeList.get(i);
				if (deactiveLocnList.contains(userRolepinCode.getPincodekey().longValue())) {
					userRolepinCopdeList.get(i).setIsactive(new BigDecimal(0));
					userRolepinCode = em.merge(userRolepinCode);
					em.persist(userRolepinCode);
				}
			}
		}

		if (!newlyAddedLocnList.isEmpty()) {
			for (Long newUserLoc : newlyAddedLocnList) {
				UserRolePinCode userRolePinCode = new UserRolePinCode();

				userRolePinCode.setIsactive(new BigDecimal(1));
				userRolePinCode.setPincodekey(new BigDecimal(newUserLoc));
				userRolePinCode.setLstupdateby(SYSTEM);
				userRolePinCode.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				userRolePinCode.setUserRole(userRolepinCopdeList.get(0).getUserRole());
				em.persist(userRolePinCode);

			}
		}

	}

	private void updateProduct(List<Long> existingLocationKey, List<Long> newLocationKey,
			UserMappingRequest userMappingBean, EntityManager em) {

		List<Long> deactiveLocnList = new ArrayList<>();
		List<Long> newlyAddedLocnList = new ArrayList<>();

		// we need to iterate to the list to find if any existing loc key to be
		// diactivated
		for (Long existingLocnKey : existingLocationKey) {

			if (!newLocationKey.contains(existingLocnKey)) {
				deactiveLocnList.add(existingLocnKey);
			}
		}
		for (Long newLocnKey : newLocationKey) {

			if (!existingLocationKey.contains(newLocnKey)) {
				newlyAddedLocnList.add(newLocnKey);
			}
		}

		CriteriaBuilder criteriaBlder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserRoleProduct> criteriaQry = criteriaBlder.createQuery(UserRoleProduct.class);
		Root<UserRoleProduct> rootUserRoleProduct = criteriaQry.from(UserRoleProduct.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlder.equal(rootUserRoleProduct.get(ISACTIVE), new BigDecimal(1)));
		predicates.add(criteriaBlder.equal(rootUserRoleProduct.get("userRole").get("bfsdRoleMaster").get("rolekey"),
				new BigDecimal(userMappingBean.getRoleKey())));
		predicates.add(criteriaBlder.equal(rootUserRoleProduct.get("userRole").get("bfsduser").get("userkey"),
				new BigDecimal(userMappingBean.getUserKey())));

		criteriaQry.select(rootUserRoleProduct).where(predicates.toArray(new Predicate[] {}));
		List<UserRoleProduct> userRoleProductList = entityManager.createQuery(criteriaQry).getResultList();

		if (!deactiveLocnList.isEmpty()) {
			for (int i = 0; i < userRoleProductList.size(); i++) {
				UserRoleProduct userRoleProduct = userRoleProductList.get(i);
				if (deactiveLocnList.contains(userRoleProduct.getSubprodtypekey().longValue())) {
					userRoleProductList.get(i).setIsactive(new BigDecimal(0));
					userRoleProduct = em.merge(userRoleProduct);
					em.persist(userRoleProduct);
				}
			}
		}

		if (!newlyAddedLocnList.isEmpty()) {
			for (Long newUserLoc : newlyAddedLocnList) {
				UserRoleProduct userRoleProduct = new UserRoleProduct();
				userRoleProduct.setProdmastkey(new BigDecimal(userMappingBean.getProdMastKey()));
				userRoleProduct.setSubprodtypekey(new BigDecimal(newUserLoc));
				userRoleProduct.setIsactive(new BigDecimal(1));
				userRoleProduct.setLstupdateby("SYSTEM-PROD-MR");
				userRoleProduct.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				userRoleProduct.setUserRole(userRoleProductList.get(0).getUserRole());
				em.persist(userRoleProduct);

			}
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public int deleteUser(UserConfigurationBean userConfig) {

		CriteriaBuilder criteriaBlde = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserProfile> criteriaQry = criteriaBlde.createQuery(UserProfile.class);
		Root<UserProfile> rootUserProfile = criteriaQry.from(UserProfile.class);
		criteriaQry.select(rootUserProfile);

		List<Predicate> predicates = new ArrayList<>();

		predicates.add(criteriaBlde.equal(rootUserProfile.get("emailid"), userConfig.getEmailId()));
		predicates.add(criteriaBlde.equal(rootUserProfile.get(ISACTIVE), new BigDecimal(1)));
		// comented code: Search user profile on the basis of email id &
		// isactive only.
		criteriaQry.select(rootUserProfile).where(predicates.toArray(new Predicate[] {}));
		List<UserProfile> userProfileList = entityManager.createQuery(criteriaQry).getResultList();

		if (userProfileList.isEmpty()) {
			throw new BFLTechnicalException("UMS-008", "User Does Not exist.");
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Delete User Started");
		int resultDeleteUser = 0;

		UserProfile userProfileDetails = userProfileList.get(0);
		long userKey = userProfileDetails.getBfsdUser().getUserkey();

		Query queryUserRoleKey = entityManager
				.createQuery("SELECT u FROM UserRole u where u.bfsduser.userkey = ?1 AND  u.isactive = 1")
				.setParameter(1, userKey);

		List<UserRole> userRoleKeyLists = queryUserRoleKey.getResultList();

		if (!userRoleKeyLists.isEmpty()) {

			for (UserRole userRoleKeyList : userRoleKeyLists) {

				long userRoleKey = userRoleKeyList.getUserrolekey();
				BigDecimal parentUserRoleKey = userRoleKeyList.getParentuser();

				Query queryAppUserAssgnmentSelect = entityManager
						.createQuery(
								"SELECT a FROM AppUserAssignment a where a.userrolekey =:userrolekey AND a.isactive =1")
						.setParameter("userrolekey", new BigDecimal(userRoleKey));

				List<AppUserAssignment> appUserAssignmentSelect = queryAppUserAssgnmentSelect.getResultList();

				updateUserAssignment(parentUserRoleKey, appUserAssignmentSelect);

			}

		}

		return resultDeleteUser;
	}

	private void updateUserAssignment(BigDecimal parentUserRoleKey, List<AppUserAssignment> appUserAssignmentSelect) {
		if (!appUserAssignmentSelect.isEmpty()) {

			for (AppUserAssignment appUserAssignmentSelectValue : appUserAssignmentSelect) {

				appUserAssignmentSelectValue.setAssignenddt(UserManagementUtility.getCurrentDateTimeStamp());
				appUserAssignmentSelectValue.setIsactive(BigDecimal.ZERO);

				AppUserAssignment appUserAssignmentInsert = new AppUserAssignment();
				appUserAssignmentInsert.setApplicationkey(appUserAssignmentSelectValue.getApplicationkey());
				appUserAssignmentInsert.setUserrolekey(parentUserRoleKey);
				appUserAssignmentInsert.setAppstatus(appUserAssignmentSelectValue.getAppstatus());
				appUserAssignmentInsert.setIsactive(new BigDecimal(1));
				appUserAssignmentInsert.setAssigntoflg(new BigDecimal(1));
				appUserAssignmentInsert.setAssignstrtdt(UserManagementUtility.getCurrentDateTimeStamp());
				appUserAssignmentInsert
						.setAssignenddt(new Timestamp(UserManagementUtility.getEffectiveEndDate(logger).getTime()));
				appUserAssignmentInsert.setAppstatustm(UserManagementUtility.getCurrentDateTimeStamp());
				appUserAssignmentInsert.setAssignedby(new BigDecimal(1274));
				appUserAssignmentInsert.setLstupdateby(SYSTEM);
				appUserAssignmentInsert.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
				entityManager.persist(appUserAssignmentInsert);

			}

		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public UserConfigurationBean getUserInformation(UserConfigurationBean userConfig,HttpHeaders headers) {

		UserConfigurationBean userConfigBean = new UserConfigurationBean();
		if (StringUtils.isNotBlank(userConfig.getEmployeeType())
				&& (userConfig.getEmployeeType().equalsIgnoreCase(UserManagementConstants.VENDOR_COMPANY)
						|| userConfig.getEmployeeType().equalsIgnoreCase(UserManagementConstants.VENDOR_INDIVIDUAL)) || userConfig.getEmployeeType().equalsIgnoreCase(UserManagementConstants.DEALER)) {
			getUserVendorDetails(userConfig, userConfigBean, false,headers);
			userConfigBean.setStatusIfExist(true);

		} else {

			Query nativeQry = entityManager.createNativeQuery(
					"select  USERKEY, FIRSTNAME, LASTNAME ,EMAILID, MOBILENO, DESIGNATION, ISACTIVE from  USER_PROFILES where EMAILID = :emailId and ISACTIVE=1 and ASSOCIATIONTYPE=1 and  LSTUPDATEDT = (select max(LSTUPDATEDT) from USER_PROFILES where EMAILID = :emailId and ISACTIVE=1 and ASSOCIATIONTYPE=1 )");
			nativeQry.setParameter("emailId", userConfig.getEmailId());

			List<Object[]> authors = nativeQry.getResultList();
			if (authors != null && !authors.isEmpty()) {
				return mapUserProfile(authors, false,headers);

			} else {
				getUserEmpDetails(userConfig, userConfigBean);
			}
		}
		return userConfigBean;
	}

	public void getUserEmpDetails(UserConfigurationBean userConfig, UserConfigurationBean userConfigBean) {
		User user1 = new User();
		if (userConfig.getFirstName() != null && !userConfig.getFirstName().isEmpty())
			user1.setFirstName(userConfig.getFirstName());
		if (userConfig.getLastName() != null && !userConfig.getLastName().isEmpty())
			user1.setLastName(userConfig.getLastName());

		if (userConfig.getEmailId() != null && !userConfig.getEmailId().isEmpty())
			user1.setEmailId(userConfig.getEmailId());

		if (userConfig.getDesignation() != null && !userConfig.getDesignation().isEmpty())
			user1.setDesignation(userConfig.getDesignation());

		List<User> userList = ldaputility.getADUsers(user1);

		userConfigBean.setStatusIfExist(false);
		userConfigBean.setUserADList(userList);
	}


	public void getUserVendorDetails(UserConfigurationBean userConfig, UserConfigurationBean userConfigBean,
			boolean isRoleProd,HttpHeaders headers ) {
		List<UserVendorProfileBean> userVendorProfileBeans = new ArrayList<>();
		UserProfile userVendorProfile = getUserVendorProfile(0L, userConfig.getUserKey(), null);
		UserVendorProfileBean userVendorProfileBean = new UserVendorProfileBean();
		UserProfile.getBeanFromEntity(userVendorProfile, userVendorProfileBean);

		if (userVendorProfile.getParentCompany() != null) {
			userVendorProfileBean.setCompanyId(userVendorProfile.getParentCompany().getUserprofilekey());
			userVendorProfileBean.setCompanyName(userVendorProfile.getParentCompany().getCompanyname());
		}
		
		
		if(userConfig.getEmployeeType().equalsIgnoreCase(UserManagementConstants.PRINCIPAL_USER)){
			userVendorProfileBean.setPrincipalUserName(userVendorProfile.getCompanyname());
		}

		if (userVendorProfile.getCity() != null) {
			CityMaster cityMaster = this.getEntity(CityMaster.class, userVendorProfile.getCity());
			if (cityMaster != null) {
				userVendorProfileBean.setCityName(cityMaster.getCityname());
			}
		}

		List<UserMapping> userRoleMappingList = new ArrayList<>();

		if (isRoleProd) {
			getUserRoleProdByUserKey(userConfig.getUserKey(), userRoleMappingList,headers);
		} else {

			List<UserRole> userRoleList = this.getRolesByUserKey(userConfig.getUserKey());
			if (!userRoleList.isEmpty()) {
				for (UserRole userRolekey : userRoleList) {
					UserMapping userMapping = new UserMapping();
					userMapping.setUserKey(userConfig.getUserKey());
					userMapping.setRoleKey(userRolekey.getBfsdRoleMaster().getRolekey());
					userMapping.setRoleName(userRolekey.getBfsdRoleMaster().getRolename());
					userRoleMappingList.add(userMapping);
				}
			}
		}
		userConfigBean.setUserKey(userConfig.getUserKey());
		userVendorProfileBean.setEmpRoleList(userRoleMappingList);
		userVendorProfileBeans.add(userVendorProfileBean);
		userConfigBean.setUserVendorList(userVendorProfileBeans);
	}

	public UserConfigurationBean mapUserProfile(List<Object[]> authors, boolean isRoleProd,HttpHeaders headers) {
		UserConfigurationBean userConfigBean = new UserConfigurationBean();

		Object[] a = authors.get(0);
		List<User> userList = new ArrayList<>();
		User user1 = new User();
		if (a[0] != null) {
			user1.setUserKey(a[0].toString());
			userConfigBean.setUserKey(Long.parseLong(a[0].toString()));
		}
		if (a[1] != null) {
			user1.setFirstName(a[1].toString());
			userConfigBean.setFirstName(a[1].toString());
		}

		if (a[2] != null) {
			user1.setLastName(a[2].toString());
			userConfigBean.setLastName(a[2].toString());
		}

		if (a[3] != null) {
			user1.setEmailId(a[3].toString());
			userConfigBean.setEmailId(a[3].toString());
		}

		if (a[4] != null) {
			user1.setMobileNumber(a[4].toString());
		}

		if (a[5] != null) {
			user1.setDesignation(a[5].toString());
			userConfigBean.setDesignation(a[5].toString());
		}

		long userKey = Long.parseLong(user1.getUserKey());
		Query queryUser = entityManager.createQuery("SELECT u FROM BfsdUser u where u.userkey = ?1");
		queryUser.setParameter(1, userKey);
		List<BfsdUser> users = queryUser.getResultList();
		if (users != null && !users.isEmpty()) {
			BfsdUser bfsdUser = users.get(0);
			if (bfsdUser != null) {
				user1.setIsActive(bfsdUser.getIsactive());
				if(null != bfsdUser.getStatuschngreason()){
					user1.setStatusChngReason(bfsdUser.getStatuschngreason());
				}
			}
		}
		userConfigBean.setStatusIfExist(true);
		userConfigBean.setUserADList(userList);

		List<UserMapping> userRoleMappingList = new ArrayList<>();

		if (isRoleProd) {
			getUserRoleProdByUserKey(userKey, userRoleMappingList,headers);
		} else {

			List<UserRole> userRoleList = this.getRolesByUserKey(userKey);
			if (!userRoleList.isEmpty()) {
				for (UserRole userRolekey : userRoleList) {
					UserMapping userMapping = new UserMapping();
					userMapping.setUserKey(Long.valueOf(user1.getUserKey()));
					userMapping.setRoleKey(userRolekey.getBfsdRoleMaster().getRolekey());
					userMapping.setRoleName(userRolekey.getBfsdRoleMaster().getRolename());
					userRoleMappingList.add(userMapping);
				}
			}
		}
		user1.setEmpRoleList(userRoleMappingList);
		user1.setEmployeeType(UserManagementConstants.EMPLOYEE);
		userList.add(user1);

		return userConfigBean;
	}

	private void getUserRoleProdByUserKey(long userKey, List<UserMapping> userMappingList, HttpHeaders headers) {

		userMappingList = addUserRoleDataFromOM(userKey, userMappingList, headers);
		List<Object[]> result = this.getUserRoleProductsByUserKey(userKey);
		UserMapping userMapping;
		for (Object[] row : result) {
			userMapping = new UserMapping();

			if (row[0] != null) {
				userMapping.setUserRoleProdKey(Long.parseLong(row[0].toString()));
			}
			if (row[1] != null) {
				userMapping.setRoleKey(Long.parseLong(row[1].toString()));
			}
			if (row[2] != null) {
				userMapping.setRoleCode(row[2].toString());
			}
			if (row[3] != null) {
				userMapping.setRoleName(row[3].toString());
			}
			if (row[4] != null) {
				userMapping.setLnProdKey(Long.parseLong(row[4].toString()));
			}
			if (row[5] != null) {
				userMapping.setLnProdCode(row[5].toString());
			}
			if (row[6] != null) {
				userMapping.setLnProdDesc(row[6].toString());
			}
			userMappingList.add(userMapping);
		}
	}

	/**
	 * Method to map details of Products mapped to user with role assigned to
	 * it.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List details(long employeeKey, long roleKey) {
		logMessage(DAO_1);
		List<EmployeeRoleDetails> list = new ArrayList<>();
		List<UserRole> userRoles = null;
		try {
			userRoles = entityManager
					.createQuery(
							"select e from UserRole e where e.bfsduser.userkey =:employeeKey and e.bfsdRoleMaster.rolekey =:roleKey and e.isactive=1")
					.setParameter("employeeKey", employeeKey)
					.setParameter(UserManagementConstants.PARAM_ROLE_KEY, roleKey).getResultList();
		} catch (PersistenceException e) {
			logMessage(DAO_2 + "" + e);
			throw new BFLBusinessException(UMS_017, environment.getProperty(UMS_017));
		}
		for (UserRole userRole : userRoles) {
			EmployeeRoleDetails details = new EmployeeRoleDetails();
			details.setHighestRoleForUser(false);
			BfsdRoleMaster roleMaster = userRole.getBfsdRoleMaster().getBfsdRoleMaster();
			if (roleMaster != null && roleMaster.getBfsdRoleMaster() == null) {
				details.setHighestRoleForUser(true);
			}

			details.setRolecd(userRole.getBfsdRoleMaster().getRolecd());
			if (userRole.getBfsduser() != null) {
				setUserProfileDetails(userRole, details);
				setUserSupervisorDetails(userRole, details);
				if (userRole.getCreditlimit() != null) {
					details.setCreditLimit(userRole.getCreditlimit().toString());
				}

			}
			setUserCityPinDetails(userRole, details);
			setUserLocationDetails(userRole, details);
			setUserChannelDetails(userRole, details);
			setUserProductDetails(userRole, details);
			if (userRole.getBfsdRoleMaster().getBfsdFunctionRoles() != null
					&& !userRole.getBfsdRoleMaster().getBfsdFunctionRoles().isEmpty())
				details.setFunctionKey(
						userRole.getBfsdRoleMaster().getBfsdFunctionRoles().get(0).getBfsdFunction().getFunctionkey());
			list.add(details);
		}
		logMessage(DAO_3);
		return list;
	}

	private void setUserProductDetails(UserRole userRole, EmployeeRoleDetails details) {
		if (userRole.getUserRoleProducts() != null && !userRole.getUserRoleProducts().isEmpty()) {
			List<Long> subProdKeyList = new ArrayList<>();

			addSubProduct(userRole, details, subProdKeyList);

			StringBuilder roleKeyID = new StringBuilder();
			for (Long roleKeyId : subProdKeyList) {
				roleKeyID.append(roleKeyId).append(",");
			}

			String nativeQueryStr = "SELECT  LP.LNPRODKEY,LT.LNPRDTYPEKEY,PM.PRODMASTKEY,PC.PRODCATKEY,PC.PRODCATDESC FROM PRODUCT_MASTER PM INNER JOIN PRODUCT_CATEGORIES PC ON PC.PRODMASTKEY = PM.PRODMASTKEY INNER JOIN LOAN_PRODUCTS LP ON LP.PRODCATKEY =PC.PRODCATKEY INNER JOIN LOAN_PRODUCT_TYPES LT ON LT.LNPRODKEY = LP.LNPRODKEY WHERE LT.LNPRDTYPEKEY IN("
					+ roleKeyID.replace(roleKeyID.length() - 1, roleKeyID.length(), "") + ")";
			List<Object[]> prdtKeyList = entityManager.createNativeQuery(nativeQueryStr).getResultList();

			Map<Long, List<Long>> subSectionMap = addSubSection(details, prdtKeyList);

			List<ProductBean> pdtBeansList = setProductBean(subSectionMap);

			details.setLoanproduct(pdtBeansList);

		}
	}

	private List<ProductBean> setProductBean(Map<Long, List<Long>> subSectionMap) {
		List<ProductBean> pdtBeansList = new ArrayList<>();
		Iterator<Long> keyIterator = subSectionMap.keySet().iterator();

		while (keyIterator.hasNext()) {
			Long keyName = keyIterator.next();
			List<Long> listPdtType = subSectionMap.get(keyName);

			ProductBean pdtBean = new ProductBean();
			pdtBean.setLoanProduct(keyName);
			pdtBean.setLoanProductType(listPdtType);
			pdtBeansList.add(pdtBean);
		}
		return pdtBeansList;
	}

	private Map<Long, List<Long>> addSubSection(EmployeeRoleDetails details, List<Object[]> prdtKeyList) {
		Map<Long, List<Long>> subSectionMap = new HashMap<>();
		if (prdtKeyList != null && !prdtKeyList.isEmpty()) {

			for (Object[] a : prdtKeyList) {
				if (details.getProdCatKey() == null) {
					details.setProdCatKey(((BigDecimal) a[3]).longValue());
				}
				List<Long> lnpdtList = subSectionMap.get(((BigDecimal) a[0]).longValue());
				if (lnpdtList == null) {
					lnpdtList = new ArrayList<>();
					lnpdtList.add(((BigDecimal) a[1]).longValue());
					subSectionMap.put(((BigDecimal) a[0]).longValue(), lnpdtList);
				} else {
					lnpdtList.add(((BigDecimal) a[1]).longValue());
					subSectionMap.put(((BigDecimal) a[0]).longValue(), lnpdtList);
				}

			}
		}
		return subSectionMap;
	}

	private void addSubProduct(UserRole userRole, EmployeeRoleDetails details, List<Long> subProdKeyList) {
		for (UserRoleProduct userPro : userRole.getUserRoleProducts()) {
			if (userPro.getIsactive().intValue() == 1) {
				subProdKeyList.add(userPro.getSubprodtypekey().longValue());
				if (details.getProdMastKey() == null)
					details.setProdMastKey(userPro.getProdmastkey().longValue());
			}

		}
	}

	private void setUserChannelDetails(UserRole userRole, EmployeeRoleDetails details) {
		if (userRole.getUserRoleChannels() != null && !userRole.getUserRoleChannels().isEmpty()) {
			List<String> channelKeyList = new ArrayList<>();
			for (UserRoleChannel userChn : userRole.getUserRoleChannels()) {
				if (userChn.getIsactive().intValue() == 1) {
					channelKeyList.add(userChn.getChanneltypekey().toString());
				}
			}
			details.setChannelType(channelKeyList);
		}
	}

	private void setUserLocationDetails(UserRole userRole, EmployeeRoleDetails details) {
		if (userRole.getUserRoleLocations() != null && !userRole.getUserRoleLocations().isEmpty()) {
			List<String> branchKeyList = new ArrayList<>();
			for (UserRoleLocation userLoc : userRole.getUserRoleLocations()) {
				if (userLoc.getIsactive().intValue() == 1) {
					branchKeyList.add(userLoc.getBflbranchkey().toString());
				}
			}
			details.setLocation(branchKeyList);
		}
	}

	private void setUserCityPinDetails(UserRole userRole, EmployeeRoleDetails details) {
		details.setCityPin(new ArrayList<>());
		if (userRole.getUserRolePinCodes() != null && !userRole.getUserRolePinCodes().isEmpty()) {
			List<Long> pinCdKeyList = new ArrayList<>();
			for (UserRolePinCode usrPin : userRole.getUserRolePinCodes()) {
				if (usrPin.getIsactive().intValue() == 1) {
					pinCdKeyList.add(usrPin.getPincodekey().longValue());
				}
			}
			details.setCityPin(pinCdKeyList);
		}
	}

	private void setUserSupervisorDetails(UserRole userRole, EmployeeRoleDetails details) {
		if (userRole.getParentuser() != null) {
			details.setSupervisorKey(userRole.getParentuser().toString());
			Query qry = entityManager
					.createQuery("select e from UserRole e where e.userrolekey= :userRoleKey and e.isactive=1");
			qry.setParameter(UserManagementConstants.PARAM_USER_ROLE_KEY, userRole.getParentuser().longValue());
			List<UserRole> supervisorRoles = qry.getResultList();
			setHighestRole(details, supervisorRoles);

		}
	}

	private void setHighestRole(EmployeeRoleDetails details, List<UserRole> supervisorRoles) {
		if (supervisorRoles != null && !supervisorRoles.isEmpty()) {
			UserRole supervisorRole = supervisorRoles.get(0);
			if (supervisorRole != null) {
				details.setHighestRole(false);
				if (supervisorRole.getBfsdRoleMaster() != null
						&& supervisorRole.getBfsdRoleMaster().getBfsdRoleMaster() == null) {
					details.setHighestRole(true);
				}
			}
		}
	}

	private void setUserProfileDetails(UserRole userRole, EmployeeRoleDetails details) {
		if (userRole.getBfsduser().getUserProfiles() != null) {
			for (UserProfile userpro : userRole.getBfsduser().getUserProfiles()) {
				if (userpro.getIsactive().equals(new BigDecimal(1))) {
					details.setFirstName(userpro.getFirstname());
					details.setLastName(userpro.getLastname());
					details.setPhone(userpro.getMobileno());
					details.setEmailId(userpro.getEmailid());
					details.setDesignation(userpro.getDesignation());
				}
			}
		}
	}

	@Transactional
	@Override
	public int updateUserDetails(UserInfoRequest userInfoRequest)  {
		// added EmailD in method parameter for Partner Portal
		int result = 0;
		try {
			String query;
			if (userInfoRequest.getStatusChngReason() != null) {
				query = "UPDATE BFSD_USERS set ISACTIVE =:isactive, LSTUPDATEDT= :lastUpdateDt, LSTUPDATEBY=:lastUpdateBy "
						+ ", STATUSCHNGREASON=:statuschngreason , STATUSCHNGBY=:ststuschngby , STATUSCHNGDT=:statuschngdt where USERKEY = :userKey";
			} else {
				query = "UPDATE BFSD_USERS set ISACTIVE =:isactive, LSTUPDATEDT= :lastUpdateDt, LSTUPDATEBY=:lastUpdateBy "
						+ " , STATUSCHNGBY=:ststuschngby , STATUSCHNGDT=:statuschngdt where USERKEY = :userKey";
		
			}
			
			Query qryUpdateStatusUsersTable = entityManager.createNativeQuery(query);
					
			qryUpdateStatusUsersTable.setParameter(ISACTIVE, userInfoRequest.getIsActive());
			qryUpdateStatusUsersTable.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
			qryUpdateStatusUsersTable.setParameter("lastUpdateDt", UserManagementUtility.getCurrentDateTimeStamp());
			qryUpdateStatusUsersTable.setParameter("lastUpdateBy", String.valueOf(userInfoRequest.getUserKey()));
			if (null != userInfoRequest.getStatusChngReason()) {
				qryUpdateStatusUsersTable.setParameter("statuschngreason", userInfoRequest.getStatusChngReason());
			}
			qryUpdateStatusUsersTable.setParameter("ststuschngby", String.valueOf(userInfoRequest.getUserKey()));
			qryUpdateStatusUsersTable.setParameter("statuschngdt", UserManagementUtility.getCurrentDateTimeStamp());
			
			int isUpdated = qryUpdateStatusUsersTable.executeUpdate();
			if (isUpdated < 0) {
				throw new BFLBusinessException(UMS_018, "Failed to activate or deactivate user.");
			}

		} catch (Exception e) {
			throw new BFLTechnicalException(UMS_018, "Failed to activate or deactivate user." + e);
		}

		// Update existing user profile details.
		Query qryUpdate = null; // added EmailD update query for Partner Portal
		Query selectQuery = null;
		try {
			int isUpdated=0;
			if (userInfoRequest.getMobileNumber() != null && !userInfoRequest.getMobileNumber().isEmpty()) {
				qryUpdate = entityManager.createNativeQuery(
					"UPDATE USER_PROFILES set MOBILENO =:mobileNo where USERKEY = :userKey and ISACTIVE=1");
				qryUpdate.setParameter("mobileNo", userInfoRequest.getMobileNumber());
				qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
				 isUpdated = qryUpdate.executeUpdate();
			}
			if (userInfoRequest.getEmailId()!= null && !userInfoRequest.getEmailId().isEmpty()) {
				qryUpdate = entityManager.createNativeQuery(
						"UPDATE USER_PROFILES set EMAILID =:emailId where USERKEY = :userKey and ISACTIVE=1");
				qryUpdate.setParameter("emailId", userInfoRequest.getEmailId());
				qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
				 isUpdated = qryUpdate.executeUpdate();

			}
			if (!StringUtils.isEmpty(userInfoRequest.getReportingManager())) {
				qryUpdate = entityManager.createNativeQuery(
						"UPDATE BFSD_USERS set REPORTING_MANAGER =:reportingManager where USERKEY = :userKey and ISACTIVE=1");
				qryUpdate.setParameter("reportingManager", userInfoRequest.getReportingManager());
				qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
				 isUpdated = qryUpdate.executeUpdate();
			}
			
			if (!StringUtils.isEmpty(userInfoRequest.getDescription())) {
				qryUpdate = entityManager.createNativeQuery(
						"UPDATE USER_PROFILES set EMPID =:description where USERKEY = :userKey and ISACTIVE=1");
				qryUpdate.setParameter("description", userInfoRequest.getDescription());
				qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
				 isUpdated = qryUpdate.executeUpdate();
			}
			if (!StringUtils.isEmpty(userInfoRequest.getSamaccountname())) {
				qryUpdate = entityManager.createNativeQuery(
						"UPDATE USER_PROFILES set ADID =:samaccountname where USERKEY = :userKey and ISACTIVE=1");
				qryUpdate.setParameter("samaccountname", userInfoRequest.getSamaccountname());
				qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
				 isUpdated = qryUpdate.executeUpdate();
			}
			
			
			if (!StringUtils.isEmpty(userInfoRequest.getSpCode())) {
				selectQuery = entityManager
						.createQuery("SELECT u FROM UserAddlAttributes u where u.attrrkey = :userKey AND  u.attrcode = 'SPCODE'")
						.setParameter("userKey", userInfoRequest.getUserKey());

				Object spResult = selectQuery.getResultList();
				if(spResult==null ||ObjectUtils.isEmpty(spResult)) {
					UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
					userAddlAttributes.setAttrrkey(userInfoRequest.getUserKey());
					userAddlAttributes.setAttrcode("SPCODE");
					userAddlAttributes.setAttrkeytype("USER");
					userAddlAttributes.setAttrvalue(userInfoRequest.getSpCode());
					userAddlAttributes.setIsactive(1);
					userAddlAttributes.setLstupdateby(userInfoRequest.getUserKey());
					userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
					entityManager.persist(userAddlAttributes);
					
				}else {
					qryUpdate = entityManager.createNativeQuery(
							"UPDATE ORGSYSADM.USER_ADDL_ATTRIBUTES set ATTRVALUE =:spCode where ATTRRKEY = :userKey and ATTRCODE = 'SPCODE' and ISACTIVE=1");
					qryUpdate.setParameter("spCode", userInfoRequest.getSpCode());
					qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
					 isUpdated = qryUpdate.executeUpdate();
				}

			}
			
			
			if (!StringUtils.isEmpty(userInfoRequest.getLpCode())) {
				selectQuery = entityManager
						.createQuery("SELECT u FROM UserAddlAttributes u where u.attrrkey = :userKey AND  u.attrcode = 'LPCODE'")
						.setParameter("userKey", userInfoRequest.getUserKey());

				Object lpResult = selectQuery.getResultList();
				if(lpResult==null ||ObjectUtils.isEmpty(lpResult)) {
					UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
					userAddlAttributes.setAttrrkey(userInfoRequest.getUserKey());
					userAddlAttributes.setAttrcode("LPCODE");
					userAddlAttributes.setAttrkeytype("USER");
					userAddlAttributes.setAttrvalue(userInfoRequest.getLpCode());
					userAddlAttributes.setIsactive(1);
					userAddlAttributes.setLstupdateby(userInfoRequest.getUserKey());
					userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
					entityManager.persist(userAddlAttributes);
					
				}else {
				qryUpdate = entityManager.createNativeQuery(
						"UPDATE ORGSYSADM.USER_ADDL_ATTRIBUTES set ATTRVALUE =:lpCode where ATTRRKEY = :userKey and ATTRCODE = 'LPCODE' and ISACTIVE=1");
				qryUpdate.setParameter("lpCode", userInfoRequest.getLpCode());
				qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
				 isUpdated = qryUpdate.executeUpdate();

			}
			}
			if (!StringUtils.isEmpty(userInfoRequest.getMaxSumAssuredLimit())) {
				selectQuery = entityManager
						.createQuery("SELECT u FROM UserAddlAttributes u where u.attrrkey = :userKey AND  u.attrcode = 'MAX_SUM_ASSUR_LIMIT'")
						.setParameter("userKey", userInfoRequest.getUserKey());

				Object maxSumAssureLimitResult = selectQuery.getResultList();
				if(maxSumAssureLimitResult==null ||ObjectUtils.isEmpty(maxSumAssureLimitResult)) {
					UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
					userAddlAttributes.setAttrrkey(userInfoRequest.getUserKey());
					userAddlAttributes.setAttrcode("MAX_SUM_ASSUR_LIMIT");
					userAddlAttributes.setAttrkeytype("USER");
					userAddlAttributes.setAttrvalue(userInfoRequest.getMaxSumAssuredLimit());
					userAddlAttributes.setIsactive(1);
					userAddlAttributes.setLstupdateby(userInfoRequest.getUserKey());
					userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
					entityManager.persist(userAddlAttributes);
					
				}else {
					qryUpdate = entityManager.createNativeQuery(
							"UPDATE ORGSYSADM.USER_ADDL_ATTRIBUTES set ATTRVALUE =:maxSumAssuredLimit where ATTRRKEY = :userKey and ATTRCODE = 'MAX_SUM_ASSUR_LIMIT' and ISACTIVE=1");
					qryUpdate.setParameter("maxSumAssuredLimit", userInfoRequest.getMaxSumAssuredLimit());
					qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
					 isUpdated = qryUpdate.executeUpdate();
				}

			}
			
			if (!StringUtils.isEmpty(userInfoRequest.getMaxPremiumLimit())) {
				selectQuery = entityManager
						.createQuery("SELECT u FROM UserAddlAttributes u where u.attrrkey = :userKey AND  u.attrcode = 'MAX_PREMIUM_LIMIT'")
						.setParameter("userKey", userInfoRequest.getUserKey());

				Object maxPremiumLimitResult = selectQuery.getResultList();
				if(maxPremiumLimitResult==null ||ObjectUtils.isEmpty(maxPremiumLimitResult)) {
					UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
					userAddlAttributes.setAttrrkey(userInfoRequest.getUserKey());
					userAddlAttributes.setAttrcode("MAX_PREMIUM_LIMIT");
					userAddlAttributes.setAttrkeytype("USER");
					userAddlAttributes.setAttrvalue(userInfoRequest.getMaxPremiumLimit());
					userAddlAttributes.setIsactive(1);
					userAddlAttributes.setLstupdateby(userInfoRequest.getUserKey());
					userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
					entityManager.persist(userAddlAttributes);
					
				}else {
					qryUpdate = entityManager.createNativeQuery(
							"UPDATE ORGSYSADM.USER_ADDL_ATTRIBUTES set ATTRVALUE =:maxPremiumLimit where ATTRRKEY = :userKey and ATTRCODE = 'MAX_PREMIUM_LIMIT' and ISACTIVE=1");
					qryUpdate.setParameter("maxPremiumLimit", userInfoRequest.getMaxPremiumLimit());
					qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
					 isUpdated = qryUpdate.executeUpdate();
				}

			}
			
			if (!CollectionUtils.isEmpty(userInfoRequest.getSpecialization())) {
				selectQuery = entityManager
						.createQuery("SELECT u FROM UserAddlAttributes u where u.attrrkey = :userKey AND  u.attrcode = 'SPECIALIZATION'")
						.setParameter("userKey", userInfoRequest.getUserKey());

				Object specializationResult = selectQuery.getResultList();
				if(specializationResult==null ||ObjectUtils.isEmpty(specializationResult)) {
					createSpecialization(userInfoRequest.getSpecialization(),userInfoRequest.getUserKey());
						
				}else {
					qryUpdate = entityManager.createNativeQuery(
							"DELETE FROM ORGSYSADM.USER_ADDL_ATTRIBUTES where ATTRRKEY = :userKey and ATTRCODE ='SPECIALIZATION'");
					qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
					 isUpdated = qryUpdate.executeUpdate();
					 createSpecialization(userInfoRequest.getSpecialization(),userInfoRequest.getUserKey());
				}

			}
			
			if (!CollectionUtils.isEmpty(userInfoRequest.getSkills())) {
				selectQuery = entityManager
						.createQuery("SELECT u FROM UserAddlAttributes u where u.attrrkey = :userKey AND  u.attrcode = 'SKILLS'")
						.setParameter("userKey", userInfoRequest.getUserKey());

				Object skillsResult = selectQuery.getResultList();
				if(skillsResult==null ||ObjectUtils.isEmpty(skillsResult)) {

                              createSkill(userInfoRequest.getSkills(),userInfoRequest.getUserKey());
					 }
					
				else {
					qryUpdate = entityManager.createNativeQuery(
							"DELETE FROM ORGSYSADM.USER_ADDL_ATTRIBUTES where ATTRRKEY = :userKey and ATTRCODE ='SKILLS'");
					qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
					 isUpdated = qryUpdate.executeUpdate();
					 createSkill(userInfoRequest.getSkills(),userInfoRequest.getUserKey());
				}

			}
			
			if (!CollectionUtils.isEmpty(userInfoRequest.getPaymentModes())) {
				selectQuery = entityManager
						.createQuery("SELECT u FROM UserAddlAttributes u where u.attrrkey = :userKey AND  u.attrcode = 'PAYMENT_MODES_ALLOW'")
						.setParameter("userKey", userInfoRequest.getUserKey());

				Object paymentModesResult = selectQuery.getResultList();
				if(paymentModesResult==null ||ObjectUtils.isEmpty(paymentModesResult)) {
					
					createPaymentMode(userInfoRequest.getPaymentModes(),userInfoRequest.getUserKey());
				}else {
					qryUpdate = entityManager.createNativeQuery(
							"DELETE FROM ORGSYSADM.USER_ADDL_ATTRIBUTES where ATTRRKEY = :userKey and ATTRCODE ='PAYMENT_MODES_ALLOW'");
					qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
					 isUpdated = qryUpdate.executeUpdate();
					 createPaymentMode(userInfoRequest.getPaymentModes(),userInfoRequest.getUserKey());
				}

			}
			
			if (!CollectionUtils.isEmpty(userInfoRequest.getChannel())) {
				selectQuery = entityManager
						.createQuery("SELECT u FROM UserAddlAttributes u where u.attrrkey = :userKey AND  u.attrcode = 'CHANNEL'")
						.setParameter("userKey", userInfoRequest.getUserKey());

				Object channelResult = selectQuery.getResultList();
				if(channelResult==null ||ObjectUtils.isEmpty(channelResult)) {
					
					createChannel(userInfoRequest.getChannel(),userInfoRequest.getUserKey());
				}else {
					qryUpdate = entityManager.createNativeQuery(
							"DELETE FROM ORGSYSADM.USER_ADDL_ATTRIBUTES where ATTRRKEY = :userKey and ATTRCODE ='CHANNEL'");
					qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
					 isUpdated = qryUpdate.executeUpdate();
					 createChannel(userInfoRequest.getChannel(),userInfoRequest.getUserKey());
				}

			}

			if (!StringUtils.isEmpty(userInfoRequest.getPoType())) {
				selectQuery = entityManager
						.createQuery("SELECT u FROM UserAddlAttributes u where u.attrrkey = :userKey AND  u.attrcode = 'POTYPE'")
						.setParameter("userKey", userInfoRequest.getUserKey());

				Object poType = selectQuery.getResultList();
				if(poType==null ||ObjectUtils.isEmpty(poType)) {
					UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
					userAddlAttributes.setAttrrkey(userInfoRequest.getUserKey());
					userAddlAttributes.setAttrcode("POTYPE");
					userAddlAttributes.setAttrkeytype("USER");
					userAddlAttributes.setAttrvalue(userInfoRequest.getPoType());
					userAddlAttributes.setIsactive(1);
					userAddlAttributes.setLstupdateby(userInfoRequest.getUserKey());
					userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
					entityManager.persist(userAddlAttributes);
					
				}else {
					qryUpdate = entityManager.createNativeQuery(
							"UPDATE ORGSYSADM.USER_ADDL_ATTRIBUTES set ATTRVALUE =:poType where ATTRRKEY = :userKey and ATTRCODE = 'POTYPE' and ISACTIVE=1");
					qryUpdate.setParameter("poType", userInfoRequest.getPoType());
					qryUpdate.setParameter(UserManagementConstants.PARAM_USER_KEY, userInfoRequest.getUserKey());
					 isUpdated = qryUpdate.executeUpdate();
				}
			}

			if (isUpdated < 0) {
				throw new BFLBusinessException(UMS_018, "Failed to update user profile.");
			}
		} catch (Exception ex) {
			throw new BFLTechnicalException(UMS_017, ex);
		}

		return result;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SupervisorBean> getuserSuperVisor(String roleKeyStr) {
		List<SupervisorBean> userList = new ArrayList<>();
		long roleKey = Long.parseLong(roleKeyStr);
		CriteriaBuilder criteriaBlde = entityManager.getCriteriaBuilder();
		CriteriaQuery<BfsdRoleMaster> criteriaQry = criteriaBlde.createQuery(BfsdRoleMaster.class);
		Root<BfsdRoleMaster> rootBfsdRoleMaster = criteriaQry.from(BfsdRoleMaster.class);
		criteriaQry.select(rootBfsdRoleMaster);
		criteriaQry.where(criteriaBlde.equal(rootBfsdRoleMaster.get("rolekey"), roleKey));

		BfsdRoleMaster bfsdRoleMaster = entityManager.createQuery(criteriaQry).getSingleResult();
		if (bfsdRoleMaster.getBfsdRoleMaster() == null) {
			SupervisorBean user = new SupervisorBean();
			user.setHighestRole(true);
			userList.add(user);
		} else {

			Query nativeQuery = entityManager.createNativeQuery(
					"SELECT DISTINCT ur.USERROLEKEY,  up.FIRSTNAME || ' ' ||  up.LASTNAME FROM USER_PROFILES up "
							+ " inner join BFSD_USERS  bu on bu.USERKEY=up.USERKEY "
							+ " inner join USER_ROLES ur on ur.USERKEY=up.USERKEY "
							+ " where  up.ISACTIVE =1  and bu.ISACTIVE =1 and  ur.ISACTIVE=1 and ur.USERROLEKEY IN "
							+ " ((select distinct USERROLEKEY from USER_roles where rolekey "
							+ " in ( select rolekey from BFSD_ROLE_MASTER t where level > 1 start with rolecd ="
							+ bfsdRoleMaster.getRolecd() + " connect by prior PARENTROLE = rolekey ) ))");

			List<Object[]> authors = nativeQuery.getResultList();
			if (authors != null && !authors.isEmpty()) {

				for (Object[] a : authors) {
					SupervisorBean user = new SupervisorBean();
					user.setId(((BigDecimal) a[0]).longValue());
					user.setName((String) a[1]);
					userList.add(user);
				}
			} else {
				// No Supervisor exist for above role
				throw new BFLBusinessException("UMS-020", environment.getProperty("UMS-020"));
			}
		}

		return userList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<LocationBean> getSuperVisorLocations(String userRoleKey) {

		long userKey = getUserKeyFromUserRoleKey(Long.parseLong(userRoleKey));
		List<LocationBean> userList = new ArrayList<>();

		Query nativeQuery;
		if (userKey == 0L) {
			nativeQuery = entityManager.createNativeQuery(
					"SELECT DISTINCT   B.BFLBRANCHKEY,B.BFLBRANCHNAME FROM USER_ROLES U,USER_ROLE_LOCATIONS L,BFL_BRANCHES B WHERE U.USERROLEKEY=L.USERROLEKEY AND B.BFLBRANCHKEY=L.BFLBRANCHKEY AND U.ISACTIVE=1 AND L.ISACTIVE=1 AND B.BFLBRANCHISACTIVE=1");
		} else {
			nativeQuery = entityManager.createNativeQuery(
					"SELECT DISTINCT   B.BFLBRANCHKEY,B.BFLBRANCHNAME FROM USER_ROLES U,USER_ROLE_LOCATIONS L,BFL_BRANCHES B WHERE U.USERROLEKEY=L.USERROLEKEY AND B.BFLBRANCHKEY=L.BFLBRANCHKEY AND U.ISACTIVE=1 AND L.ISACTIVE=1 AND B.BFLBRANCHISACTIVE=1 "
							+ "AND U.USERKEY= :userKey");
			nativeQuery.setParameter(QueryConstants.QRY_PARAM_USERKEY, userKey);
		}

		List<Object[]> bFlBranches = nativeQuery.getResultList();
		if (bFlBranches != null && !bFlBranches.isEmpty()) {

			for (Object[] a : bFlBranches) {
				LocationBean bflBranchBn = new LocationBean();
				bflBranchBn.setId(((BigDecimal) a[0]).longValue());
				bflBranchBn.setName((String) a[1]);
				userList.add(bflBranchBn);
			}
		}
		return userList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ChannelBean> getSuperVisorChannels(String userRoleKey) {

		List<ChannelBean> supervisorChannelList = new ArrayList<>();
		long userKey = getUserKeyFromUserRoleKey(Long.parseLong(userRoleKey));
		Query nativeQuery;

		if (userKey == 0L) {
			nativeQuery = entityManager.createNativeQuery(
					"select DISTINCT C.CHANNELTYPEKEY, C.CHANNETYPEDESC from CHANNEL_TYPES C INNER JOIN USER_ROLE_CHANNELS U ON C.CHANNELTYPEKEY = U.CHANNELTYPEKEY INNER JOIN USER_ROLES UR ON  U.USERROLEKEY = UR.USERROLEKEY");
		} else {

			nativeQuery = entityManager.createNativeQuery(
					"select DISTINCT C.CHANNELTYPEKEY, C.CHANNETYPEDESC from CHANNEL_TYPES C INNER JOIN USER_ROLE_CHANNELS U ON C.CHANNELTYPEKEY = U.CHANNELTYPEKEY INNER JOIN USER_ROLES UR ON  U.USERROLEKEY = UR.USERROLEKEY "
							+ "WHERE UR.USERKEY=:userKey");
			nativeQuery.setParameter(QueryConstants.QRY_PARAM_USERKEY, userKey);
		}

		List<Object[]> channels = nativeQuery.getResultList();
		if (channels != null && !channels.isEmpty()) {

			for (Object[] a : channels) {
				ChannelBean channelBean = new ChannelBean();
				channelBean.setId(((BigDecimal) a[0]).longValue());
				channelBean.setName((String) a[1]);
				supervisorChannelList.add(channelBean);
			}
		}
		return supervisorChannelList;
	}

	@Override
	public List<PinCodeBean> getLocationPin(String branchKey) {

		String[] branch = branchKey.split(",");
		List<PinCodeBean> pinCodeList = new ArrayList<>();
		List<String> selectedValues = Arrays.asList(branch);
		Query nativeQuery = entityManager.createNativeQuery(
				"SELECT PN.PINCODEKEY,PN.PINCODE FROM PIN_CODE_MASTER PN WHERE PN.CITYKEY IN(SELECT BR.CITYKEY FROM BFL_BRANCHES BR WHERE BR.BFLBRANCHKEY in (:selectedValues))");

		nativeQuery.setParameter("selectedValues", selectedValues);
		List<Object[]> pinCodes = nativeQuery.getResultList();

		if (pinCodes != null && !pinCodes.isEmpty()) {

			for (Object[] a : pinCodes) {
				PinCodeBean pinCodeBn = new PinCodeBean();
				pinCodeBn.setId((BigDecimal) a[0]);
				pinCodeBn.setName((String) a[1]);
				pinCodeList.add(pinCodeBn);
			}
		}

		return pinCodeList;
	}

	public void logMessage(String message) {

		bflLoggerUtil.debug(THIS_CLASS, DAO, message);

	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public Boolean deleteUserMapping(Long employeeKey, Long roleKey) {

		Boolean isactiveFlag = true;

		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Delete User mapping Started");
		Query queryUserRoleKey = entityManager
				.createQuery(
						"SELECT u FROM UserRole u where u.bfsduser.userkey = ?1 and u.bfsdRoleMaster.rolekey=?2 and isactive=1 ")
				.setParameter(1, employeeKey).setParameter(2, roleKey);

		List<UserRole> userRoleKeyLists = queryUserRoleKey.getResultList();

		if (userRoleKeyLists.isEmpty()) {
			throw new BFLBusinessException(UMS_016, environment.getProperty(UMS_016));
		}

		UserRole userRoleKeyList = userRoleKeyLists.get(0);
		Long userRoleKey = userRoleKeyList.getUserrolekey();

		if (deleteUserRoleReferences(employeeKey, roleKey, userRoleKey)) {

			int updateCount = entityManager.createNamedQuery("UserRole.DeactivateUserRole")
					.setParameter(UserManagementConstants.PARAM_USER_KEY, employeeKey)
					.setParameter(UserManagementConstants.PARAM_ROLE_KEY, roleKey).executeUpdate();

			if (updateCount < 0) {
				throw new BFLTechnicalException("UMS-002",
						"No Employee role mapping found for employee Key " + employeeKey + " and Rolekey " + roleKey);
			}
			isactiveFlag = false;

		}

		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Delete User mapping Completed");

		return isactiveFlag;

	}

	private boolean deleteUserRoleReferences(Long employeeKey, Long roleKey, Long userRoleKey) {
		boolean result = false;
		try {
			// Delete Default App and SR Views.
			DeleteUserRoleBean deleteUserRoleBean = new DeleteUserRoleBean();
			deleteUserRoleBean.setUserKey(employeeKey);
			deleteUserRoleBean.setUserRoleKey(userRoleKey);
			deleteUserRoleBean.setRoleKey(roleKey);
			prepareDataForDelete(deleteUserRoleBean);
			int isDeleted = deleteUserRoleMapping(deleteUserRoleBean);
			if (-1 < isDeleted) {
				result = true;
				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Falied to Delete User mapping");
			}
		} catch (Exception e) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Falied to Delete User mapping " + e);
			throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
		}

		return result;
	}

	@Override
	public UserLoginAccount getUserLoginAccount(UserLoginAccountRequest userLoginAccountRequest) {
		logger.setCorrelationID(custmHeaders.getCmptcorrid());
		String loginId = userLoginAccountRequest.getLoginId();
		short loginType = userLoginAccountRequest.getLoginType();
		short userType = userLoginAccountRequest.getUserType();
		//new usertype has been introduced which will be not used in database. This loginType will be 
		//used in case of forgot mpin only
		if(UserManagementConstants.LOGINACCTYPE_FORGOT_MPIN==userLoginAccountRequest.getLoginType()){
			loginType=UserManagementConstants.LOGINACCTYPE_MOBILE_DOB_OTP_MPIN;
		}

		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getUserLoginAccount loginId is " + loginId);
		UserLoginAccount userLoginAccount = null;
		Query query;
		try {
			if (8 == loginType && !StringUtils.isEmpty(userLoginAccountRequest.getDateOfBirth())) {
				// check logintype and dob for mobile and mpin based login for customer portal.
				// For mobile and mpin based login
				// loginType will always be 8.
				query = entityManager.createNativeQuery(QueryConstants.FETCH_LOGIN_USER_DETAILS_WITH_LOGINID_DOB);
				query.setParameter("dateOfBirth", userLoginAccountRequest.getDateOfBirth());
			} else {
				query = entityManager.createQuery(QueryConstants.FETCH_LOGIN_USER_DETAILS_WITH_LOGINID);
			}
			query.setParameter(LOGINID, loginId.trim());
			query.setParameter(LOGIN_ACCT_TYPE, BigDecimal.valueOf(loginType));
			query.setParameter("userType", BigDecimal.valueOf(userType));

			if (8 == loginType && !StringUtils.isEmpty(userLoginAccountRequest.getDateOfBirth())) {
				// check logintype and dob for mobile and mpin based login for customer portal.
				// For mobile and mpin
				// based login loginType will always be 8.
				List<Object[]> resultSet = query.getResultList();
				if (resultSet != null && !resultSet.isEmpty()) {
					userLoginAccount = beanMapper.mapToUserLoginAccountBean(resultSet);
				}
			} else {
				userLoginAccount = (UserLoginAccount) query.getSingleResult();
			}

			return userLoginAccount;

		} catch (javax.persistence.NoResultException nre) {

			if (Integer.valueOf(userType) == UserManagementConstants.USERTYPE_CUSTOMER) {
				
				if (loginType != UserManagementConstants.LOGINACCTYPE_MOBILE_DOB_OTP_MPIN) {

					Timestamp timestamp = UserManagementUtility.getCurrentTimeStamp();

					logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
							"getUserLoginAccount - no user found, creating a new user for non manual Type" + nre);
					userLoginAccount = new UserLoginAccount();
					logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "no details present for loginId - "
							+ userLoginAccountRequest.getLoginId() + ". Creating new login id for the same.");
					// Creating a new UserLoginAccount

					BfsdUser bfsdUser = new BfsdUser();
					bfsdUser.setRegistrationdate(timestamp);
					bfsdUser.setUsertype(BigDecimal.valueOf(userType));
					bfsdUser.setUserblockedflg(BigDecimal.ZERO);
					bfsdUser.setFailedlogincount(BigDecimal.ZERO);
					bfsdUser.setIsactive(BigDecimal.ONE);
					bfsdUser.setLstupdatedt(timestamp);
					bfsdUser.setLstupdateby("1");

					entityManager.persist(bfsdUser);
					entityManager.flush();
					logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
							"User Key for new User is " + bfsdUser.getUserkey());
					userLoginAccount.setLoginid(userLoginAccountRequest.getLoginId());
					userLoginAccount.setBfsdUser(bfsdUser);
					userLoginAccount.setCreationdate(timestamp);
					userLoginAccount.setLoginpwd(
							UserManagementUtility.getHashedPassword(UserManagementConstants.DEFAULT_PASSWORD, logger));
					userLoginAccount.setLstupdateby("1");
					userLoginAccount.setLstupdatedt(timestamp);
					userLoginAccount.setUserloginacctype(BigDecimal.valueOf(loginType));
					entityManager.persist(userLoginAccount);
					entityManager.flush();
					return userLoginAccount;
				}
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
						"getUserLoginAccount - no user found; login type mobile-OTP MPIN detected."+nre);
				return null;
			}
			//DIRUNSEC-2260 :: do not create user for any other usertype except Customer
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					"getUserLoginAccount - no user found, non-customer invalid login attempt detected.");
			return null;
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public UserLoginAccount getUserId(String loginId) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getUserLoginAccount loginId is " + loginId);
		UserLoginAccount userLoginAccount = null;
		try {

			Query query = entityManager.createQuery(QueryConstants.FETCH_LOGIN_DETAILS_WITH_LOGINID);
			query.setParameter(LOGINID, loginId );
			// temporary
			List<UserLoginAccount> list = query.getResultList();
			if (list != null && !list.isEmpty()) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Liist--" + list.size());
				userLoginAccount = list.get(0);

			}
			return userLoginAccount;

		} catch (javax.persistence.NoResultException nre) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
					"no details present for loginId - " + loginId + ". Creating new login id for the same." + nre);
			throw new BFLBusinessException("UMS-003", "No user found for given details.");

		}

	}

	@Override
	public BfsdUser updateFailedCount(BfsdUser bfsdUser, short failedCount, short userType) {

		Timestamp timestamp = UserManagementUtility.getCurrentTimeStamp();

		bfsdUser.setFailedlogincount(BigDecimal.valueOf(failedCount));
		if (failedCount > 0) {
			bfsdUser.setLstfailedlogindt(timestamp);
			bfsdUser.setLstupdateby(String.valueOf(bfsdUser.getUserkey()));
			bfsdUser.setLstupdatedt(timestamp);
		}
		//DIRUNSEC-2198(Added condition for system user)
		/*if(userType == UserManagementConstants.USERTYPE_SYSTEM && failedCount >= maxLoginAttempts){
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "System user has been locked as max incorrect login attempt exceeded.");
			bfsdUser.setUserblockedflg(BigDecimal.ONE);
		}*/
		if (userType != UserManagementConstants.USERTYPE_SYSTEM && failedCount >= 3) {
			bfsdUser.setUserblockedflg(BigDecimal.ONE);
		}
		return entityManager.merge(bfsdUser);

	}

	private void setdefaultServiceReqViewMapping(UserRole userRole) {

		String defaultMyAppView = userRole.getBfsduser().getUserkey() + "_" + userRole.getBfsdRoleMaster().getRolekey()
				+ "_MyAppView";
		String defaultAllAppViewname = userRole.getBfsduser().getUserkey() + "_"
				+ userRole.getBfsdRoleMaster().getRolekey() + "_AllAppView";
		String defaultMyTeamViewName = userRole.getBfsduser().getUserkey() + "_"
				+ userRole.getBfsdRoleMaster().getRolekey() + "_MyTeamView";

		CriteriaBuilder criteriaBlder = entityManager.getCriteriaBuilder();
		CriteriaQuery<SerReqViewDefinition> criteriaQry = criteriaBlder.createQuery(SerReqViewDefinition.class);
		Root<SerReqViewDefinition> rootSerReqViewDefinition = criteriaQry.from(SerReqViewDefinition.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlder.equal(rootSerReqViewDefinition.get(ISACTIVE), new BigDecimal(1)));
		predicates.add(criteriaBlder.equal(rootSerReqViewDefinition.get("viewname"), defaultMyAppView));

		criteriaQry.select(rootSerReqViewDefinition).where(predicates.toArray(new Predicate[] {}));
		List<SerReqViewDefinition> appViewDefinitionList = entityManager.createQuery(criteriaQry).getResultList();

		if (appViewDefinitionList != null && appViewDefinitionList.isEmpty()) {
			List<String> defaultViewNameList = new ArrayList<>();
			defaultViewNameList.add(defaultMyAppView);
			defaultViewNameList.add(defaultAllAppViewname);
			defaultViewNameList.add(defaultMyTeamViewName);
			List<SerReqViewDefinition> appViewDefinitions = new ArrayList<>();
			for (String defaultViewName : defaultViewNameList) {

				SerReqViewDefinition appViewDef = new SerReqViewDefinition();
				appViewDef.setIsactive(new BigDecimal(1));
				appViewDef.setLstupdateby(SYSTEM);
				appViewDef.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				appViewDef.setCreateddt(UserManagementUtility.getCurrentTimeStamp());
				appViewDef.setCreatedby(SYSTEM);
				appViewDef.setViewname(defaultViewName);
				appViewDef.setCondition("true");
				appViewDef.setViewaccess(new BigDecimal(1));
				SerReqRoleView appRoleView = new SerReqRoleView();
				appRoleView.setSerReqViewDefinition(appViewDef);
				appRoleView.setBfsdRoleMaster(userRole.getBfsdRoleMaster());
				appRoleView.setIsactive(new BigDecimal(1));
				appRoleView.setLstupdateby(SYSTEM);
				appRoleView.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());

				SerReqUserView appUserView = new SerReqUserView();
				appUserView.setSerReqRoleView(appRoleView);
				appUserView.setUserRole(userRole);
				appUserView.setIsactive(new BigDecimal(1));
				appUserView.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				appUserView.setUserRole(userRole);
				List<SerReqRoleView> appRoleViewList = new ArrayList<>();
				appRoleViewList.add(appRoleView);

				List<SerReqUserView> appUserViewList = new ArrayList<>();
				appUserViewList.add(appUserView);

				appRoleView.setSerReqUserViews(appUserViewList);
				appViewDef.setSerReqRoleViews(appRoleViewList);
				appViewDefinitions.add(appViewDef);
				entityManager.merge(appViewDef);

			}
		}

	}

	private void setdefaultLoanAppViewMapping(UserRole userRole) {

		String defaultMyAppView = userRole.getBfsduser().getUserkey() + "_" + userRole.getBfsdRoleMaster().getRolekey()
				+ "_MyAppView";
		String defaultAllAppViewname = userRole.getBfsduser().getUserkey() + "_"
				+ userRole.getBfsdRoleMaster().getRolekey() + "_AllAppView";
		String defaultMyTeamViewName = userRole.getBfsduser().getUserkey() + "_"
				+ userRole.getBfsdRoleMaster().getRolekey() + "_MyTeamView";

		CriteriaBuilder criteriaBlder = entityManager.getCriteriaBuilder();
		CriteriaQuery<AppViewDefinition> criteriaQry = criteriaBlder.createQuery(AppViewDefinition.class);
		Root<AppViewDefinition> rootAppViewDefinition = criteriaQry.from(AppViewDefinition.class);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlder.equal(rootAppViewDefinition.get(ISACTIVE), new BigDecimal(1)));
		predicates.add(criteriaBlder.equal(rootAppViewDefinition.get("viewname"), defaultMyAppView));

		criteriaQry.select(rootAppViewDefinition).where(predicates.toArray(new Predicate[] {}));
		List<AppViewDefinition> appViewDefinitionList = entityManager.createQuery(criteriaQry).getResultList();

		if (appViewDefinitionList != null && appViewDefinitionList.isEmpty()) {
			List<String> defaultViewNameList = new ArrayList<>();
			defaultViewNameList.add(defaultMyAppView);
			defaultViewNameList.add(defaultAllAppViewname);
			defaultViewNameList.add(defaultMyTeamViewName);
			List<AppViewDefinition> appViewDefinitions = new ArrayList<>();
			for (String defaultViewName : defaultViewNameList) {

				AppViewDefinition appViewDef = new AppViewDefinition();
				appViewDef.setIsactive(new BigDecimal(1));
				appViewDef.setLstupdateby(SYSTEM);
				appViewDef.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				appViewDef.setCreateddt(UserManagementUtility.getCurrentTimeStamp());
				appViewDef.setCreatedby(SYSTEM);
				appViewDef.setViewname(defaultViewName);
				appViewDef.setCondition("true");
				appViewDef.setViewaccess(new BigDecimal(1));
				AppRoleView appRoleView = new AppRoleView();
				appRoleView.setAppViewDefinition(appViewDef);
				appRoleView.setBfsdRoleMaster(userRole.getBfsdRoleMaster());
				appRoleView.setIsactive(new BigDecimal(1));
				appRoleView.setLstupdateby(SYSTEM);
				appRoleView.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());

				AppUserView appUserView = new AppUserView();
				appUserView.setAppRoleView(appRoleView);
				appUserView.setUserRole(userRole);
				appUserView.setIsactive(new BigDecimal(1));
				appUserView.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				appUserView.setUserRole(userRole);
				List<AppRoleView> appRoleViewList = new ArrayList<>();
				appRoleViewList.add(appRoleView);

				List<AppUserView> appUserViewList = new ArrayList<>();
				appUserViewList.add(appUserView);

				appRoleView.setAppUserViews(appUserViewList);
				appViewDef.setAppRoleViews(appRoleViewList);
				appViewDefinitions.add(appViewDef);
				entityManager.merge(appViewDef);

			}
		}

	}

	@SuppressWarnings("unchecked")
	private void updateUserMapForHighestRole(UserMappingRequest userMappingBean) {

		List<Long> userlockey = new ArrayList<>(); // EMP_ROLE_LOCATIONS (NEW)
		List<Long> userChannelkey = new ArrayList<>(); // EMP_ROLE_CHENNELS
														// (NEW)
		Query nativeQuery = entityManager
				.createNativeQuery("SELECT BFLBRANCHKEY FROM BFL_BRANCHES where BFLBRANCHISACTIVE=1");

		List<Object[]> branchKeyList = nativeQuery.getResultList();
		if (branchKeyList != null && !branchKeyList.isEmpty()) {

			for (Object a : branchKeyList) {
				userlockey.add(((BigDecimal) a).longValue());
			}
		}

		nativeQuery = entityManager.createNativeQuery("SELECT CHANNELTYPEKEY FROM CHANNEL_TYPES where ISACTIVE=1");

		List<Object[]> channelKeyList = nativeQuery.getResultList();
		if (channelKeyList != null && !channelKeyList.isEmpty()) {

			for (Object a : channelKeyList) {
				userChannelkey.add(((BigDecimal) a).longValue());
			}
		}

		userMappingBean.setUserChannelkey(userChannelkey);
		userMappingBean.setUserlockey(userlockey);
	}

	private void updateAssociateEntity(UserMappingRequest userMappingBean, UserRole userRole) {
		updateUserLocForHighRole(userMappingBean, userRole);

		updateUserChannelForHighRole(userMappingBean, userRole);

		updatePinForhighRole(userMappingBean, userRole);

		updateLoanProdForHighRole(userMappingBean, userRole);
	}

	private void updateLoanProdForHighRole(UserMappingRequest userMappingBean, UserRole userRole) {
		List<UserRoleProduct> userRoleProducts = new ArrayList<>();

		if (userMappingBean.getLoanproduct() != null) {
			for (ProductBean productBean : userMappingBean.getLoanproduct()) {
				for (Long productTypeKey : productBean.getLoanProductType()) {
					UserRoleProduct userRoleProduct = new UserRoleProduct();
					userRoleProduct.setProdmastkey(new BigDecimal(userMappingBean.getProdMastKey()));
					userRoleProduct.setSubprodtypekey(new BigDecimal(productTypeKey));
					userRoleProduct.setIsactive(new BigDecimal(1));
					userRoleProduct.setLstupdateby("SYSTEM-PROD-MR");
					userRoleProduct.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
					userRoleProduct.setUserRole(userRole);
					userRoleProducts.add(userRoleProduct);
				}
			}

		}

		userRole.setUserRoleProducts(userRoleProducts);
	}

	private void updatePinForhighRole(UserMappingRequest userMappingBean, UserRole userRole) {
		List<UserRolePinCode> userRolePinCodes = new ArrayList<>();

		if (userMappingBean.getUserPinCdKey() != null) {
			for (Long userPinKey : userMappingBean.getUserPinCdKey()) {

				UserRolePinCode userRolePinCode = new UserRolePinCode();
				userRolePinCode.setUserRole(userRole);
				userRolePinCode.setIsactive(new BigDecimal(1));
				userRolePinCode.setPincodekey(new BigDecimal(userPinKey));
				userRolePinCode.setLstupdateby(SYSTEM);
				userRolePinCode.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				userRolePinCodes.add(userRolePinCode);
			}
		}
		userRole.setUserRolePinCodes(userRolePinCodes);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserRole> getRolesByUserKey(long userKey) {
		List<UserRole> result = new ArrayList<>();
		logMessage(DAO_4);
		try {
			Query query = entityManager.createQuery(QueryConstants.QRY_GET_USER_ROLES_BY_USERKEY);
			query.setParameter(QueryConstants.QRY_PARAM_USERKEY, userKey);
			result = query.getResultList();
		} catch (PersistenceException e) {
			logMessage(DAO_2 + "" + e);
		}

		logMessage(DAO_5);
		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserName> getListOfUserName(long pincode, long functionKey, long roleKey, long tabkey, long subprodkey) {

		List<UserName> result = new ArrayList<>();

		Query qry = entityManager.createNativeQuery(FETCH_USERS_NAMES);

		qry.setParameter("rolekey", roleKey);
		qry.setParameter("functionKey", functionKey);
		qry.setParameter("pincode", pincode);
		qry.setParameter("tabkey", tabkey);
		qry.setParameter("subprodkey", subprodkey);

		List<Object[]> resultSet = qry.getResultList();
		if (resultSet != null && !resultSet.isEmpty()) {
			result = beanMapper.mapToBean(resultSet);
		}

		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public UserProfile getUserProfileByUserKey(long userKey) {
		UserProfile result = new UserProfile();
		logMessage(DAO_6);
		try {
			Query query = entityManager.createNativeQuery(QueryConstants.QRY_GET_USER_FIRST_AND_LAST_NAME);
			query.setParameter(QueryConstants.QRY_PARAM_USERKEY, userKey);
			List<Object[]> userProfiles = query.getResultList();
			mapUserProfileData(result, userProfiles);
		} catch (PersistenceException e) {
			logMessage("" + e);
			logMessage(DAO_2);
		}
		logMessage(DAO_7);
		return result;
	}

	private void mapUserProfileData(UserProfile result, List<Object[]> userProfiles) {
		if (!userProfiles.isEmpty()) {
			Object[] userProfile = userProfiles.get(0);
			if (userProfile[0] != null) {
				result.setFirstname((String) userProfile[0]);
			}
			if (userProfile[1] != null) {
				result.setLastname((String) userProfile[1]);
			}

			if (userProfile[0] == null && userProfile[1] == null && userProfile[2] != null) {
				result.setFirstname((String) userProfile[2]);
			}
			
			if (userProfile[3] != null) {
				result.setEmailid((String) userProfile[3]);
			}
			
			if (userProfile[4] != null) {
				result.setAssociationtype((BigDecimal) userProfile[4]);
			}
		}
	}

	private BfsdRoleMaster getRoleFromCode(String roleCode) {

		Query query = entityManager.createNamedQuery("BfsdRoleMaster.findRoleFromCode");
		query.setParameter("roleCode", roleCode);

		return (BfsdRoleMaster) query.getSingleResult();
	}

	@SuppressWarnings("unchecked")
	private UserRole getUserRole(long userKey, long roleKey) {
		Query query = entityManager.createNamedQuery("UserRole.findByEmployeeAndRole");
		query.setParameter(UserManagementConstants.PARAM_ROLE_KEY, roleKey);
		query.setParameter(UserManagementConstants.PARAM_USER_KEY, userKey);

		List<UserRole> userRoles = query.getResultList();

		if (userRoles != null && !userRoles.isEmpty()) {
			return userRoles.get(0);
		}
		return new UserRole();
	}

	@Override
	public void assignRoleToUser(BfsdUser currentUser, short loginType, short userType) {
		Timestamp timestamp = UserManagementUtility.getCurrentTimeStamp();
		// If user is not “Employee” then service should assigned default role
		// to this user and make entry into role assignment table.
		// For Customer it will be Role_Customer, partner it will be
		// Role_Partner.
		if ((loginType == UserManagementConstants.LOGINACCTYPE_MOBILE_DOB_OTP_MPIN
				|| loginType == UserManagementConstants.LOGINACCTYPE_MANUAL)
				&& userType != UserManagementConstants.USERTYPE_EMPLOYEE
				&& userType != UserManagementConstants.USERTYPE_SYSTEM) {

			BfsdRoleMaster role;
			switch (userType) {
			case UserManagementConstants.USERTYPE_CUSTOMER:
				role = getRoleFromCode(String.valueOf(UserManagementConstants.CUSTOMER_ROLEKEY));
				break;
			default:
				role = getRoleFromCode(String.valueOf(UserManagementConstants.PARTNER_ROLEKEY));
				break;
			}
			UserRole userrole = getUserRole(currentUser.getUserkey(), role.getRolekey());
			userrole.setBfsdRoleMaster(role);
			userrole.setBfsduser(currentUser);
			userrole.setIsactive(BigDecimal.valueOf(1));
			userrole.setLstupdatedt(timestamp);
			entityManager.merge(userrole);
		}
	}

	@SuppressWarnings("unchecked")
	private UserRole getUserRole(long userRoleKey) {
		Query query = entityManager.createNamedQuery("UserRole.findById");
		query.setParameter("userrolekey", userRoleKey);

		UserRole result = null;
		List<UserRole> userRoles = query.getResultList();
		if (userRoles != null && !userRoles.isEmpty()) {
			result = userRoles.get(0);
		}
		return result;
	}

	@Override
	public long getUserKeyFromUserRoleKey(long userRoleKey) {
		long userKey = 0L;
		UserRole userRole = getUserRole(userRoleKey);
		if (userRole != null) {
			userKey = userRole.getBfsduser().getUserkey();
		}
		return userKey;
	}

	@Override
	@Transactional
	public boolean autoRegister(AutoRegisterRequest request) {
		Long userKey = request.getUserKey();
		String loginId = request.getLoginId();

		logMessage("autoRegister - start for - " + userKey);

		UserLoginAccount loginAccount;
		boolean existingFlag = true;

		BigDecimal loginAcctType = BigDecimal.valueOf(UserManagementConstants.LOGINACCTYPE_MOBILE_DOB_OTP_MPIN);

		Query query = entityManager.createQuery("from UserLoginAccount where userloginacctype=:loginAcctType and "
				+ "bfsdUser.userkey = :userKey and bfsdUser.usertype=1 and bfsdUser.isactive=1");

		query.setParameter(LOGIN_ACCT_TYPE, loginAcctType);
		query.setParameter(UserManagementConstants.PARAM_USER_KEY, userKey);

		try {
			loginAccount = (UserLoginAccount) query.getSingleResult();
			loginAccount.setLoginid(loginId);

			entityManager.merge(loginAccount);
		} catch (NoResultException | NonUniqueResultException e) {

			if (e instanceof NonUniqueResultException) {// NOSONAR

				logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
						" Multiple records found for userKey - " + userKey + ", loginId - " + loginId + " - " + e);
				query = entityManager.createQuery(
						"delete from  USER_LOGIN_ACCOUNTS ul where ul.userkey=:userkey and userloginacctype=8 and "
								+ "exists (select 1 from BFSD_USERS bu where ul.userkey=bu.userkey and bu.usertype=1)");

				query.setParameter("userkey", userKey);
				query.executeUpdate();
			} else {

				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
						"No user present for - " + userKey + ", loginId - " + loginId + " - " + e);
			}

			Timestamp timestamp = UserManagementUtility.getCurrentTimeStamp();
			loginAccount = new UserLoginAccount();
			List<UserLoginAccount> userLoginAccountList=new ArrayList<>();
			List<UserProfile> userProfileList = new ArrayList<>();
			UserProfile userProfile = new UserProfile();
			BfsdUser bfsdUser = new BfsdUser();
			
			bfsdUser.setUserkey(userKey);
			bfsdUser.setFailedlogincount(BigDecimal.ZERO);
			bfsdUser.setUserblockedflg(BigDecimal.ZERO);
			bfsdUser.setRegistrationdate(timestamp);
			bfsdUser.setUsertype(BigDecimal.ONE);
			bfsdUser.setIsactive(BigDecimal.ONE);
			bfsdUser.setLstupdateby("1");
			bfsdUser.setLstupdatedt(timestamp);
			// data to persist in user account table
			loginAccount.setBfsdUser(bfsdUser);
			loginAccount.setLoginid(loginId);
			loginAccount.setUserloginacctype(loginAcctType);
			loginAccount.setLoginpwd(
					UserManagementUtility.getHashedPassword(String.format("%04d", 1000+new Random().nextInt(9000)), logger));
			loginAccount.setCreationdate(timestamp);
			loginAccount.setLstupdateby("1");
			loginAccount.setLstupdatedt(timestamp);
			// data to persist in user account table
			userProfile.setFirstname(request.getFirstName());
			userProfile.setLastname(request.getLastName());
			userProfile.setMobileno(request.getMobile());
			userProfile.setEmailid(request.getEmail());
			userProfile.setDateofbirth(UserManagementUtility.genrateDate(request.getDateOfBirth(),logger));
			userProfile.setAssociationtype(new BigDecimal(4));
		    userProfile.setAssociationdt(new Date());
		    userProfile.setBfsdUser(bfsdUser);
			
			//userProfile list has been added in order to persist in user profile table.
			userProfileList.add(userProfile);
		    bfsdUser.setUserProfiles(userProfileList);
		    //userLoginAccount list has been added to persist in User login account table
			userLoginAccountList.add(loginAccount);
			bfsdUser.setUserLoginAccounts(userLoginAccountList);
			entityManager.merge(bfsdUser);
			existingFlag = false;
		}

		logMessage("autoRegister - completed for - " + userKey);

		return existingFlag;
	}

	@Override
	@org.springframework.transaction.annotation.Transactional
	public void savePassword(String hashedNewPassword, String hashOldPassword, long userKey) {
		logMessage("savePassword - start, for userkey = "+userKey);
		Query oldPassQuery;
		Query newPassQuery;
		int count;

		if (hashOldPassword != null && !hashOldPassword.isEmpty()) {
			logMessage("In if, updating new password in Dao"); 
			oldPassQuery = entityManager.createQuery(QueryConstants.QRY_RESET_SAVE_PASSWORD);

			oldPassQuery.setParameter("oldpwd", hashOldPassword);
			oldPassQuery.setParameter("userloginacctype",
					BigDecimal.valueOf(UserManagementConstants.LOGINACCTYPE_MOBILE_DOB_OTP_MPIN));
			oldPassQuery.setParameter(UserManagementConstants.PARAM_USER_KEY, userKey);
			List<UserLoginAccount> loginAccts = oldPassQuery.getResultList();

			if (loginAccts != null && !loginAccts.isEmpty()) {
				UserLoginAccount loginAcct = loginAccts.get(0);
				loginAcct.setLoginpwd(hashedNewPassword);

				entityManager.merge(loginAcct);
			} else {
				logger.error(THIS_CLASS, DAO, "savePassword - Invalid old password of -" + userKey);
				throw new BFLBusinessException("UMS-025", environment.getProperty("UMS-025"));
			}
		} else {
			logMessage("In else, updating new password in Dao");
			newPassQuery = entityManager.createQuery(QueryConstants.QRY_SAVE_PASSWORD);
			newPassQuery.setParameter("loginpwd", hashedNewPassword);
			newPassQuery.setParameter("userloginacctype",
					BigDecimal.valueOf(UserManagementConstants.LOGINACCTYPE_MANUAL));
			newPassQuery.setParameter(UserManagementConstants.PARAM_USER_KEY, userKey);
			count = newPassQuery.executeUpdate();

			if (count != 1) {
				logger.error(THIS_CLASS, DAO, "savePassword - unable to save password, update count - " + count);
				throw new BFLBusinessException("UMS-015", environment.getProperty("UMS-015"));
			}
			newPassQuery = entityManager.createNativeQuery(
					"update BFSD_USERS set userblockedflg=0, failedlogincount=0, lstupdatedt=sysdate where userkey=:userKey");
			newPassQuery.setParameter("userKey", userKey);
			newPassQuery.executeUpdate();
		}

		logMessage("savePassword - end, for userkey = "+userKey);
	}

	@Override
	public List<UserProfile> searchUser(UserConfigurationBean userConfigurationBean) {

		logMessage("searchUser - start");
		List<UserProfile> result = new ArrayList<>();
		boolean fnameFlag = false;
		boolean lnameFlag = false;
		boolean emailFlag = false;
		boolean companyFlag = false;
		
		boolean pricipalFlag = false;

		try {
			StringBuilder queryStr = new StringBuilder();
			queryStr.append("from UserProfile where ");

			if (UserManagementConstants.VENDOR_INDIVIDUAL.equalsIgnoreCase(userConfigurationBean.getEmployeeType())) {
				queryStr.append("associationtype=2 and ");
				
			} else if (UserManagementConstants.VENDOR_COMPANY
					.equalsIgnoreCase(userConfigurationBean.getEmployeeType())) {
				queryStr.append("associationtype=3 and ");
			}else if (UserManagementConstants.PRINCIPAL_USER
					.equalsIgnoreCase(userConfigurationBean.getEmployeeType())) {
				queryStr.append("associationtype=5 and ");
			}
			if (StringUtils.isNotEmpty(userConfigurationBean.getFirstName())) {
				fnameFlag = true;
				queryStr.append("lower(firstname) like :fName and ");
			}
			if (StringUtils.isNotEmpty(userConfigurationBean.getLastName())) {
				lnameFlag = true;
				queryStr.append("lower(lastname) like :lName and ");
			}
			if (StringUtils.isNotEmpty(userConfigurationBean.getEmailId())) {
				emailFlag = true;
				if (UserManagementConstants.VENDOR_INDIVIDUAL.equalsIgnoreCase(userConfigurationBean.getEmployeeType())
						|| UserManagementConstants.VENDOR_COMPANY
								.equalsIgnoreCase(userConfigurationBean.getEmployeeType())
						|| UserManagementConstants.PRINCIPAL_USER
								.equalsIgnoreCase(userConfigurationBean.getEmployeeType())) {
					queryStr.append("lower(emailid) like :email and ");
				}

			}
			if (StringUtils.isNotEmpty(userConfigurationBean.getCompanyName())) {
				companyFlag = true;
				if (UserManagementConstants.VENDOR_INDIVIDUAL
						.equalsIgnoreCase(userConfigurationBean.getEmployeeType())) {
					queryStr.append("lower(companyname) like :companyName and ");
				} else if (UserManagementConstants.VENDOR_COMPANY
						.equalsIgnoreCase(userConfigurationBean.getEmployeeType())) {
					queryStr.append("lower(companyname) like :companyName and ");
				}

			}
			
			if (StringUtils.isNotEmpty(userConfigurationBean.getPrincipalUser())) {
				pricipalFlag = true;
				if (UserManagementConstants.PRINCIPAL_USER.equalsIgnoreCase(userConfigurationBean.getEmployeeType())
						) {
					queryStr.append("lower(companyname) like :principalUser and ");
				}

			}
			String qry = queryStr.substring(0, queryStr.length() - 5);

			Query query = entityManager.createQuery(qry);

			if (fnameFlag)
				query.setParameter(UserManagementConstants.PARAM_FIRST_NAME,
						UserManagementConstants.CHAR_PERCENT + userConfigurationBean.getFirstName().trim().toLowerCase()
								+ UserManagementConstants.CHAR_PERCENT);
			if (lnameFlag)
				query.setParameter(UserManagementConstants.PARAM_LAST_NAME,
						UserManagementConstants.CHAR_PERCENT + userConfigurationBean.getLastName().trim().toLowerCase()
								+ UserManagementConstants.CHAR_PERCENT);
			if (emailFlag)
				query.setParameter(UserManagementConstants.PARAM_EMAIL_ID,
						UserManagementConstants.CHAR_PERCENT + userConfigurationBean.getEmailId().trim().toLowerCase()
								+ UserManagementConstants.CHAR_PERCENT);

			if (companyFlag)
				query.setParameter(UserManagementConstants.PARAM_COMPANY_NAME,
						UserManagementConstants.CHAR_PERCENT
								+ userConfigurationBean.getCompanyName().trim().toLowerCase()
								+ UserManagementConstants.CHAR_PERCENT);
			
			if (pricipalFlag)
				query.setParameter(UserManagementConstants.PARAM_PRINCIPAL_NAME,
						UserManagementConstants.CHAR_PERCENT
								+ userConfigurationBean.getPrincipalUser().trim().toLowerCase()
								+ UserManagementConstants.CHAR_PERCENT);

			result = query.getResultList();

		} catch (Exception e) {
			logger.error(THIS_CLASS, DAO, "searchUser - " + e);
		}

		return result;
	}

	@Override
	public UserLoginAccount mergeUsers(long newUserKey, long oldUserKey) {
		logMessage("mergeUsers - start for new User Key - " + newUserKey);

		BfsdUser oldUser;

		Timestamp timestamp = UserManagementUtility.getCurrentTimeStamp();

		Query query = entityManager
				.createQuery("from BfsdUser where userkey=:oldUserKey and bfsdUser.userkey is null and isactive=1");
		query.setParameter("oldUserKey", oldUserKey);

		try{
			oldUser = (BfsdUser) query.getSingleResult();
		}
		catch(NoResultException e){
			logger.error(THIS_CLASS, DAO, "mergeUsers - UserMerge not applicable for - " + newUserKey +" - "+ e);
			return null;
		}
		
		logMessage("mergeUsers - old user found for " + oldUserKey);

		query = entityManager
				.createQuery("from UserLoginAccount where bfsdUser.userkey=:newUserKey and bfsdUser.isactive=1");
		query.setParameter("newUserKey", newUserKey);

		List<UserLoginAccount> accounts = query.getResultList();
		if (accounts != null && !accounts.isEmpty()) {
			logMessage("mergeUsers - new login account found for " + newUserKey);
			for(UserLoginAccount newLoginAcct:accounts){

				BfsdUser newUser = newLoginAcct.getBfsdUser();
				newUser.setBfsdUser(oldUser);
				newUser.setLstupdatedt(timestamp);
				newUser.setLstupdateby(String.valueOf(newUser.getUserkey()));

				newLoginAcct.setBfsdUser(oldUser);
				newLoginAcct.setLstupdatedt(timestamp);
				newLoginAcct.setLstupdateby(String.valueOf(newUser.getUserkey()));

				entityManager.merge(newUser);
				entityManager.merge(newLoginAcct);
			}
			return accounts.get(0);
		}
		
		else {
			logger.error(THIS_CLASS, DAO, "mergeUsers - new user not found for - " + newUserKey);
			throw new BFLBusinessException("UMS-042", environment.getProperty("UMS-042"));
		}
	}

	private void prepareDataForDelete(DeleteUserRoleBean bean) {
		List<String> viewNames = new ArrayList<>();
		String allAppView = bean.getUserKey() + UserManagementConstants.CHAR_UNDERSCORE + bean.getRoleKey()
				+ UserManagementConstants.CHAR_UNDERSCORE + UserManagementConstants.ALL_APP_VIEW;
		String myAppView = bean.getUserKey() + UserManagementConstants.CHAR_UNDERSCORE + bean.getRoleKey()
				+ UserManagementConstants.CHAR_UNDERSCORE + UserManagementConstants.MY_APP_VIEW;
		String myTeamView = bean.getUserKey() + UserManagementConstants.CHAR_UNDERSCORE + bean.getRoleKey()
				+ UserManagementConstants.CHAR_UNDERSCORE + UserManagementConstants.MY_TEAM_VIEW;

		viewNames.add(bean.getUserKey() + UserManagementConstants.CHAR_UNDERSCORE + bean.getRoleKey()
				+ UserManagementConstants.CHAR_UNDERSCORE + UserManagementConstants.ALL_APP_VIEW);
		viewNames.add(bean.getUserKey() + UserManagementConstants.CHAR_UNDERSCORE + bean.getRoleKey()
				+ UserManagementConstants.CHAR_UNDERSCORE + UserManagementConstants.MY_APP_VIEW);
		viewNames.add(bean.getUserKey() + UserManagementConstants.CHAR_UNDERSCORE + bean.getRoleKey()
				+ UserManagementConstants.CHAR_UNDERSCORE + UserManagementConstants.MY_TEAM_VIEW);

		Query nativeQuery = entityManager.createNativeQuery(
				" select avd.VIEWKEY,auv.USERVIEWKEY,arv.VIEWROLEKEY  from APP_VIEW_DEFINITION avd, APP_ROLE_VIEW arv, APP_USER_VIEW auv "
						+ " where avd.VIEWKEY=arv.VIEWKEY and arv.VIEWROLEKEY=auv.VIEWROLEKEY and "
						+ " avd.VIEWNAME in ('" + allAppView + "','" + myAppView + "','" + myTeamView + "')"
						+ " and auv.USERROLEKEY=:userRoleKey");
		nativeQuery.setParameter(UserManagementConstants.PARAM_USER_ROLE_KEY, bean.getUserRoleKey());

		List<Object[]> results = nativeQuery.getResultList();
		if (results != null && !results.isEmpty()) {

			for (Object[] result : results) {
				bean.getAppViewKeys().add(((BigDecimal) result[0]).longValue());
				bean.getAppUserViewKeys().add(((BigDecimal) result[1]).longValue());
				bean.getAppViewRoleKeys().add(((BigDecimal) result[2]).longValue());
			}
		}

		nativeQuery = entityManager.createNativeQuery(
				" select srvd.VIEWKEY, sruv.USERVIEWKEY,srrv.VIEWROLEKEY  from SER_REQ_VIEW_DEFINITION srvd, SER_REQ_ROLE_VIEW srrv, SER_REQ_USER_VIEW sruv "
						+ " where srvd.VIEWKEY=srrv.VIEWKEY and srrv.VIEWROLEKEY=sruv.VIEWROLEKEY and "
						+ " srvd.VIEWNAME in ('" + allAppView + "','" + myAppView + "','" + myTeamView + "')"
						+ " and sruv.USERROLEKEY=:userRoleKey");
		nativeQuery.setParameter(UserManagementConstants.PARAM_USER_ROLE_KEY, bean.getUserRoleKey());

		results = nativeQuery.getResultList();
		if (results != null && !results.isEmpty()) {

			for (Object[] result : results) {
				bean.getSrViewKeys().add(((BigDecimal) result[0]).longValue());
				bean.getSrUserViewKeys().add(((BigDecimal) result[1]).longValue());
				bean.getSrViewRoleKeys().add(((BigDecimal) result[2]).longValue());
			}
		}
	}

	@Transactional
	private int deleteUserRoleMapping(DeleteUserRoleBean bean) {
		int isUpdated;

		deleteAppViewRefs(bean);
		deleteSrViewRefs(bean);
		isUpdated = updateAssignToRefs(bean);
		if (isUpdated < 0) {
			throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
		}

		isUpdated = deleteRoleMappingRef(bean);

		return isUpdated;
	}

	private int updateAssignToRefs(DeleteUserRoleBean bean) {
		int isUpdated;
		Query qry;
		qry = entityManager.createNativeQuery(
				"update APP_USER_ASSIGNMENT set USERROLEKEY=NULL, ASSIGNTOFLG=2, LSTUPDATEDT=current_timestamp where  USERROLEKEY=:userRoleKey and ASSIGNENDDT like '%31-DEC-99%'");
		qry.setParameter(UserManagementConstants.PARAM_USER_ROLE_KEY, bean.getUserRoleKey());
		isUpdated = qry.executeUpdate();
		if (isUpdated < 0) {
			throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
		}

		qry = entityManager.createNativeQuery(
				"update SER_REQ_WORK_ASSIGNMENTS set ASSIGNEDTOUSERROLEKEY=NULL, ASSIGNTOFLG=2, LSTUPDATEDT=current_timestamp where  ASSIGNEDTOUSERROLEKEY=:userRoleKey and ASSIGNMENTENDDATE like '%31-DEC-99%'");
		qry.setParameter(UserManagementConstants.PARAM_USER_ROLE_KEY, bean.getUserRoleKey());
		isUpdated = qry.executeUpdate();
		return isUpdated;
	}

	private void deleteSrViewRefs(DeleteUserRoleBean bean) {
		int isUpdated;
		Query qry;
		if (!bean.getSrUserViewKeys().isEmpty()) {
			qry = entityManager.createNativeQuery("DELETE from SER_REQ_USER_VIEW where USERVIEWKEY in ("
					+ getInValuesStr(bean.getSrUserViewKeys().toString()) + ")");
			isUpdated = qry.executeUpdate();
			if (isUpdated < 0) {
				throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
			}
		}

		if (!bean.getSrViewRoleKeys().isEmpty()) {
			qry = entityManager.createNativeQuery("DELETE from SER_REQ_ROLE_VIEW where VIEWROLEKEY in ("
					+ getInValuesStr(bean.getSrViewRoleKeys().toString()) + ")");
			isUpdated = qry.executeUpdate();
			if (isUpdated < 0) {
				throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
			}
		}

		if (!bean.getSrViewKeys().isEmpty()) {
			qry = entityManager.createNativeQuery("DELETE from SER_REQ_VIEW_DEFINITION where VIEWKEY in ("
					+ getInValuesStr(bean.getSrViewKeys().toString()) + ")");
			isUpdated = qry.executeUpdate();
			if (isUpdated < 0) {
				throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
			}
		}
	}

	private void deleteAppViewRefs(DeleteUserRoleBean bean) {
		int isUpdated;
		Query qry;
		if (!bean.getAppUserViewKeys().isEmpty()) {
			qry = entityManager.createNativeQuery("DELETE from APP_USER_VIEW where USERVIEWKEY in ("
					+ getInValuesStr(bean.getAppUserViewKeys().toString()) + ")");
			isUpdated = qry.executeUpdate();
			if (isUpdated < 0) {
				throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
			}
		}

		if (!bean.getAppViewRoleKeys().isEmpty()) {
			qry = entityManager.createNativeQuery("DELETE from APP_ROLE_VIEW where VIEWROLEKEY in ("
					+ getInValuesStr(bean.getAppViewRoleKeys().toString()) + ")");
			isUpdated = qry.executeUpdate();
			if (isUpdated < 0) {
				throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
			}
		}

		if (!bean.getAppViewKeys().isEmpty()) {
			qry = entityManager
					.createNativeQuery("DELETE from APP_VIEW_LASTLOGIN_DETAILS where USERROLEKEY= :userRoleKey");
			qry.setParameter("userRoleKey", bean.getUserRoleKey());
			isUpdated = qry.executeUpdate();
			if (isUpdated < 0) {
				throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
			}
		}

		if (!bean.getAppViewKeys().isEmpty()) {
			qry = entityManager.createNativeQuery("DELETE from APP_VIEW_DEFINITION where VIEWKEY in ("
					+ getInValuesStr(bean.getAppViewKeys().toString()) + ")");
			isUpdated = qry.executeUpdate();
			if (isUpdated < 0) {
				throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
			}
		}
	}

	private int deleteRoleMappingRef(DeleteUserRoleBean bean) {
		int isUpdated;
		deleteUserRoleChannel(bean);
		deleteUserRoleLocations(bean);
		deleteUserRolePincode(bean);
		isUpdated = deleteUserRoleProduct(bean);
		return isUpdated;
	}

	private int deleteUserRoleProduct(DeleteUserRoleBean bean) {
		int isUpdated;
		Query qry;
		qry = entityManager.createNativeQuery(UserManagementConstants.QRY_DELETE_USER_ROLE_PRODUCT);
		qry.setParameter(UserManagementConstants.PARAM_USER_ROLE_KEY, bean.getUserRoleKey());
		isUpdated = qry.executeUpdate();
		if (isUpdated < 0) {
			throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
		}
		return isUpdated;
	}

	private void deleteUserRolePincode(DeleteUserRoleBean bean) {
		int isUpdated;
		Query qry;
		qry = entityManager.createNativeQuery(UserManagementConstants.QRY_DELETE_USER_ROLE_PIN_CODE);
		qry.setParameter(UserManagementConstants.PARAM_USER_ROLE_KEY, bean.getUserRoleKey());
		isUpdated = qry.executeUpdate();
		if (isUpdated < 0) {
			throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
		}
	}

	private void deleteUserRoleLocations(DeleteUserRoleBean bean) {
		int isUpdated;
		Query qry;
		qry = entityManager.createNativeQuery(UserManagementConstants.QRY_DELETE_USER_ROLE_LOCATIONS);
		qry.setParameter(UserManagementConstants.PARAM_USER_ROLE_KEY, bean.getUserRoleKey());
		isUpdated = qry.executeUpdate();
		if (isUpdated < 0) {
			throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
		}
	}

	private void deleteUserRoleChannel(DeleteUserRoleBean bean) {
		int isUpdated;
		Query qry;
		qry = entityManager.createNativeQuery(UserManagementConstants.QRY_DELETE_USER_ROLE_CHANNELS);
		qry.setParameter(UserManagementConstants.PARAM_USER_ROLE_KEY, bean.getUserRoleKey());
		isUpdated = qry.executeUpdate();
		if (isUpdated < 0) {
			throw new BFLTechnicalException(UMS_024, environment.getProperty(UMS_024));
		}
	}

	private String getInValuesStr(String inValuesStr) {
		return inValuesStr.substring(1, inValuesStr.length() - 1);
	}

	@Override
	public boolean checkLoginEmail(String emailId) {

		Query query = entityManager.createQuery(QueryConstants.QRY_EXISTING_CHECK_LOGIN_EMAIL);

		query.setParameter("loginId", emailId);

		List<UserLoginAccount> loginaccts = query.getResultList();

		if (loginaccts != null && !loginaccts.isEmpty()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"checkLoginEmail - Old and new email id can not be same - " + emailId);
			throw new BFLBusinessException(UMS_033, environment.getProperty(UMS_033));
		}

		return false;
	}

	@Override
	public boolean checkApplicantEmail(String emailId, long applicantKey) {

		Query query = entityManager.createNativeQuery(QueryConstants.QRY_EXISTING_CHECK_APPLICANT_EMAIL);

		query.setParameter("emailId", emailId);

		List<Object[]> emails = query.getResultList();

		if (emails != null && !emails.isEmpty()) {
			Object[] apltDet = emails.get(0);
			if (Long.parseLong(apltDet[0].toString()) == applicantKey) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"checkApplicantEmail - Old and new email id can not be same - " + emailId);
				throw new BFLBusinessException(UMS_033, environment.getProperty(UMS_033));
			}
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"checkApplicantEmail - email already exists in applicant details - " + emailId);
			return true;
		}

		return false;
	}

	@Override
	public void saveEmail(long userKey, String oldEmail, String newEmail) {

		Query query = entityManager.createNativeQuery(
				"update USER_LOGIN_ACCOUNTS ul set ul.loginid=:newloginid,lstupdateby=:userKey, lstupdatedt=sysdate where loginid=:oldloginid and userloginacctype=5 and "
						+ "exists (select 1 from BFSD_USERS bu where ul.userkey=bu.userkey and bu.usertype=1) ");

		query.setParameter("newloginid", newEmail);
		query.setParameter(OLD_LOGIN_ID, oldEmail);
		query.setParameter("userKey", userKey);

		int count = query.executeUpdate();

		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
				"saveEmail - number of records updated - " + count + " for oldEmail - " + oldEmail);
		if (count > 1) {
			throw new BFLBusinessException("UMS-034", environment.getProperty("UMS-034"));
		}
	}

	@Override
	public void exiprePrevLinks(String oldEmail, long currentUserKey) {
		Query query = entityManager.createNativeQuery(
				"update APP_CONTACT_AUTH_REQUEST set acrtokenexpdt=sysdate,acrlstupdatedt=sysdate,acrlstupdateby=:acrlstupdateby,acrisactive=0 where acremailid=:oldloginid and acrisactive=1");
		query.setParameter(OLD_LOGIN_ID, oldEmail);
		query.setParameter("acrlstupdateby", String.valueOf(currentUserKey));
		query.executeUpdate();

		query = entityManager.createNativeQuery("update USER_RESET_REQUESTS set isactive=0, lstupdateby=:lstupdateby, "
				+ "lstupdatedt=sysdate where emailid=:oldloginid");
		query.setParameter(OLD_LOGIN_ID, oldEmail);
		query.setParameter("lstupdateby", String.valueOf(currentUserKey));
		query.executeUpdate();
	}

	@Override
	public UserProfile getUserVendorProfile(Long vendorProfileKey, Long userKey, String emailId) {
		UserProfile result = null;
		logMessage(DAO_6);
		try {
			Query query;
			if (StringUtils.isNotBlank(emailId)) {
				query = entityManager.createQuery(QueryConstants.QRY_GET_USER_VENDOR_PROFILE_BY_EMAIL_ID);
				query.setParameter(QueryConstants.QRY_PARAM_EMAIL_ID, emailId);
			} else if (userKey != 0) {
				query = entityManager.createQuery(QueryConstants.QRY_GET_USER_VENDOR_PROFILE_BY_USER_KEY);
				query.setParameter(QueryConstants.QRY_PARAM_USERKEY, userKey);
			} else {
				query = entityManager
						.createQuery(QueryConstants.QRY_GET_USER_VENDOR_PROFILE_BY_USER_VENDOR_PROFILE_KEY);
				query.setParameter(QueryConstants.QRY_PARAM_VENDOR_PROFILE_KEY, vendorProfileKey);
			}
			List<UserProfile> userVendorProfiles = query.getResultList();
			if (!userVendorProfiles.isEmpty()) {
				result = userVendorProfiles.get(0);
			}
		} catch (PersistenceException e) {
			logMessage("" + e);
			logMessage(DAO_2);
		}
		logMessage(DAO_7);
		return result;
	}

	@Override
	@Transactional
	public int saveUserVendorProfile(UserProfile userVendorProfile) {
		int result = -1;
		try {
			entityManager.merge(userVendorProfile);
			if (userVendorProfile.getAssociationtype().longValue() == 2) {

				Query query = entityManager.createNativeQuery(
						"update USER_PROFILES uvp set uvp.companyname=:companyName, uvp.isactive=:isActive where uvp.parentcompany=:parentCompany");
				query.setParameter("companyName", userVendorProfile.getCompanyname());
				query.setParameter("parentCompany", userVendorProfile.getUserprofilekey());
				query.setParameter("isActive", userVendorProfile.getIsactive());
				query.executeUpdate();
			}
			result = 1;
		} catch (Exception e) {
			logMessage("" + e);
			logMessage(DAO_2);
		}
		return result;
	}

	@Override
	public <T> T getEntity(Class<T> clazz, Long key) {
		return entityManager.find(clazz, key);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getUserRoleProductsByUserKey(long userKey) {
		List<Object[]> result = new ArrayList<>();
		logMessage(DAO_4);
		try {
			Query query = entityManager.createNativeQuery(QueryConstants.QRY_GET_USER_ROLE_PROD_BY_USERKEY);
			query.setParameter(QueryConstants.QRY_PARAM_USERKEY, userKey);
			result = query.getResultList();
		} catch (PersistenceException e) {
			logMessage(DAO_2 + "" + e);
		}

		logMessage(DAO_5);
		return result;
	}
	
	@Override
	@Transactional
	public void updateTokenStatus(ValidateTokenBean bean, AppContactAuthRequest authRequest,
			Timestamp timestamp, BigDecimal authStatus) {

		logger.debug(THIS_CLASS, DAO, "updateTokenStatus - started");
		
		authRequest.setAcrauthstatus(authStatus);
		authRequest.setAcrlstupdatedt(timestamp);
		entityManager.merge(authRequest);
		
		AppContactAuthValidation authValidation = authRequest.getAppContactAuthValidations()!=null && !authRequest.getAppContactAuthValidations().isEmpty()
				? authRequest.getAppContactAuthValidations().get(0): new AppContactAuthValidation();
		
		authValidation.setAcvisactive(BigDecimal.ONE);
		authValidation.setAcvlstupdatedt(timestamp);
		authValidation.setAppContactAuthRequest(authRequest);
		authValidation.setAcvtoken(bean.getToken());
		authValidation.setAcvvalidationsts(authStatus);
		authValidation.setAcvvalidationdt(timestamp);
		
		
		if(!authStatus.equals(UserManagementConstants.AUTH_STATUS_SUCCESSFUL)){
			authValidation.setAcvremarks("Invalid Token");
		}
		entityManager.merge(authValidation);
		
		logger.debug(THIS_CLASS, DAO, "updateTokenStatus - completed");
	}
	
	@Override
	public AppContactAuthRequest validateToken(ValidateTokenBean bean) {
		
		AppContactAuthRequest authRequest = null;
		long contanctType = bean.getContactType();
		@SuppressWarnings("unchecked")
		List<AppContactAuthRequest> authReuqests = (List<AppContactAuthRequest>)entityManager
				.createQuery("select acr from AppContactAuthRequest acr"
						+ " where acr.applicationApplicant.appapltkey=:appApltKey "
						+ " and acr.acrauthtoken=:token"
						+ " and acr.acrcontacttype=:contactType"
						+ " and acr.acrreqsendmode=:sendMode "
						+ " and acr.acrisactive=1 ")
				
				.setParameter("appApltKey", Long.parseLong(bean.getDecryptedAppApltKey()))
				.setParameter("token", bean.getToken())
				.setParameter("contactType", BigDecimal.valueOf(contanctType))
				.setParameter("sendMode", BigDecimal.valueOf(contanctType))
				.getResultList();
		
		if(null != authReuqests && !authReuqests.isEmpty()){ 
			authRequest =  authReuqests.get(0);
		}
		return authRequest;
	}
	@Override
	public List<UserLoginAccount> getSystemUsers() {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "==== Inside getSystemUsers  ===");
		List<UserLoginAccount> userLoginAccountList=null;
		try {
			Query query = entityManager.createQuery(QueryConstants.FETCH_UI_LOGIN_USER_DETAILS_WITH_LOGINID);
			query.setParameter(LOGIN_ACCT_TYPE, BigDecimal.valueOf(UserManagementConstants.LOGINACCTYPE_MANUAL));
			query.setParameter("userType", BigDecimal.valueOf(UserManagementConstants.USERTYPE_SYSTEM));
			userLoginAccountList= query.getResultList();
		} catch (javax.persistence.NoResultException nre) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					"==== no details present  "+ nre);
			logMessage(nre.getMessage());
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "==== Exiting getSystemUsers  ===");
		return userLoginAccountList;
	}

     @Override
	public UserRoleBean getUserRoleInfo(Long userKey, Long roleKey) {
	   logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "UserRoleBean started : "+userKey+" - "+roleKey);
		UserRoleBean userRole = new UserRoleBean();
		Query query = entityManager.createQuery("from UserRole userRl where userRl.bfsduser.userkey=:userkey and userRl.bfsdRoleMaster.rolekey=:rolekey and userRl.isactive = 1");
		query.setParameter("userkey", userKey);
		query.setParameter("rolekey", roleKey);

		@SuppressWarnings("unchecked")
		List<UserRole> userRoleList = (List<UserRole>) query.getResultList();
		  logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "userRoleList size : "+userRoleList.size());
		if (null != userRoleList && userRoleList.size() == 1) {
			userRole.setRoleKey(roleKey);
			userRole.setUserKey(userKey);
			userRole.setUserRoleKey(userRoleList.get(0).getUserrolekey());
		}
		  logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "UserRoleKey : "+userRole.getUserRoleKey() +" - "+userRole.getUserKey());
		return userRole;
		
	}
   
		
	 
		// added new method for get User type  for PP
		@Override
		public BfsdUser getUserType(Long userKey) {
			short userType = 0;
			BfsdUser bfsdUser = entityManager.find(BfsdUser.class, userKey);
			if (bfsdUser != null) {
				userType = bfsdUser.getUsertype().shortValue();

			}
		return bfsdUser;
		}
		
		@Override
		public List<UserName> getUserInfo(Long userRoleKey) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getUserProfileInfo started : "+userRoleKey);
			List<UserName> userNameList = new ArrayList<UserName>();
			UserName userName = new UserName();
			try {
				Long userKey = getUserKeyFromUserRoleKey(userRoleKey);
				UserRole userRole = getUserRole(userRoleKey);
				Query query = entityManager.createQuery("from UserProfile userpr where userpr.bfsdUser.userkey=:userkey and userpr.isactive = 1");
				query.setParameter("userkey", userKey);
		
				@SuppressWarnings("unchecked")
				List<UserProfile> userList = (List<UserProfile>) query.getResultList();
				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "userList size : "+userList.size());
				for (UserProfile userProfile : userList) {
					userName.setUserName(userProfile.getFirstname()+' '+userProfile.getLastname());
					userName.setUserKey(userKey);
					if (userRole != null) {
						userName.setRoleKey(userRole.getBfsdRoleMaster().getRolekey());	
						}
					userName.setUserEmail(null != userProfile ? userProfile.getEmailid() : null);
					userNameList.add(userName);
				}
			} catch (javax.persistence.NoResultException nre) {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "==== no details present  " + nre);
				logMessage(nre.getMessage());
			}
			return userNameList;
		}

		private List<UserMapping> addUserRoleDataFromOM(long userKey, List<UserMapping> userMappingList,
				HttpHeaders headers) {
			List<UserRole> userRoleList = this.getRolesByUserKey(userKey);
			logger.debug(THIS_CLASS, DAO, "addUserRoleDataFromOM - started for user key : "+userKey  +"  list received "+userRoleList.size());
			try {
				List<UserRoleProductBean> creditList = omMasterDataPluginMapper.findUserRoleMaapped(userRoleList, headers);
				if(!CollectionUtils.isEmpty(creditList))
				fillUserMappingData(userMappingList, creditList);
				
				List<UserRoleProductBean> insuranceList = omMasterDataPluginMapper.findInsuranceUserRoleMaapped(userRoleList, headers);
				if(!CollectionUtils.isEmpty(insuranceList))
				fillUserMappingData(userMappingList, insuranceList);
				//List<UserRoleProductBean> omPocketList = omMasterDataPluginMapper.findOMPocketUserRoleMapped(userRoleList, headers);
//				if(!CollectionUtils.isEmpty(omPocketList))
//				fillUserMappingData(userMappingList, omPocketList);
			} catch (Exception e) {
			}
			return userMappingList;
		}

		/**
		 * @param userMappingList
		 * @param creditList
		 */
		public void fillUserMappingData(List<UserMapping> userMappingList, List<UserRoleProductBean> creditList) {
			creditList.stream().forEach(item -> {
				UserMapping userMapping = new UserMapping();
				userMapping.setUserRoleProdKey(item.getUserprodkey());
				userMapping.setRoleKey(item.getUserrolekey());
				UserRoleL3 userRoles = userMgmtProdDao.findUserRoleKey(item.getUserrolekey());
				userMapping.setRoleCode(userRoles.getBfsdRoleMaster().getRolecd());
				userMapping.setRoleName(userRoles.getBfsdRoleMaster().getRolename());
				userMapping.setLnProdCode(item.getProdCatCode());
				userMapping.setLnProdDesc(item.getProdCatDesc());
				userMapping.setL1ProdCode(item.getProdmastkey() != 0 ?item.getProdmastkey():0L);
				userMappingList.add(userMapping);
			});
		}
		
		@Override
		public List<UserName> getUserInfoByUserKey(Long userKey) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getUserInfoByUserKey started : "+userKey);
			List<UserName> userNameList = new ArrayList<UserName>();
			try {
				Query query = entityManager.createQuery("from UserProfile userpr where userpr.bfsdUser.userkey=:userkey and userpr.isactive = 1");
				query.setParameter("userkey", userKey);
		
				@SuppressWarnings("unchecked")
				List<UserProfile> userList = (List<UserProfile>) query.getResultList();
				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "userList size : "+userList.size());
				for (UserProfile userProfile : userList) {
					List<UserRole> UserRoleList = getRolesByUserKey(userKey);
					if (!UserRoleList.isEmpty()) {
						for (UserRole userRole : UserRoleList) {
							UserName userName = new UserName();
					userName.setUserName(userProfile.getFirstname()+' '+userProfile.getLastname());
					userName.setUserKey(userKey);
							userName.setRoleKey(userRole.getBfsdRoleMaster().getRolekey());
							userName.setUserRoleKey(userRole.getUserrolekey());
					userName.setUserEmail(null != userProfile ? userProfile.getEmailid() : null);
					userNameList.add(userName);
				}
					}
				}
			} catch (javax.persistence.NoResultException nre) {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "==== no details present  " + nre);
				logMessage(nre.getMessage());
			}
			return userNameList;
		}
		
	

		@Override
		public List<UserRoleBean> getUserInfoByEmail(String userEmail) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getUserInfoByEmail started : " + userEmail);
			List<UserRoleBean> userRoleBeanList = new ArrayList<UserRoleBean>();
			try {
				Query query = entityManager
						.createQuery("from UserProfile userpr where userpr.emailid=:userEmail and userpr.isactive = 1");
				query.setParameter("userEmail", userEmail);

				@SuppressWarnings("unchecked")
				List<UserProfile> userList = (List<UserProfile>) query.getResultList();
				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "userList size : " + userList.size());
				for (UserProfile userProfile : userList) {
	              List<UserRole> UserRoleList = getRolesByUserKey(userProfile.getBfsdUser().getUserkey());
					if (!UserRoleList.isEmpty()) {
						for (UserRole userRole : UserRoleList) {
							UserRoleBean userRoleBean = new UserRoleBean();
							userRoleBean.setUserKey(userProfile.getBfsdUser().getUserkey());
							userRoleBean.setUserType(userProfile.getBfsdUser().getUsertype().longValue());
							userRoleBean.setRoleKey(userRole.getBfsdRoleMaster().getRolekey());
							userRoleBean.setRoleName(userRole.getBfsdRoleMaster().getRolename());
							userRoleBean.setUserRoleKey(userRole.getUserrolekey());
							userRoleBeanList.add(userRoleBean);
						}
					}
				}
			} catch (javax.persistence.NoResultException nre) {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "==== no details present  " + nre);
				logMessage(nre.getMessage());
			}
			return userRoleBeanList;
		}

		@SuppressWarnings("unchecked")
		@Override
		public List<UserProfileDetails> getUserProfilesByRoleKeys(List<Long> roleKeyList) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "==== Inside getUserProfilesByRoleKeys  ===");
			List<UserProfileDetails> userProfileList = new ArrayList<>();
			try {
				Query nativeQry = entityManager.createNativeQuery(QueryConstants.USER_PROFILES_BY_ROLEKEY);
				nativeQry.setParameter("rolekeys", roleKeyList);
				List<Object[]> userDetails = nativeQry.getResultList();
				if(!CollectionUtils.isEmpty(userDetails)) {
					for (Object[] object : userDetails) {
						UserProfileDetails userProfileDetails = new UserProfileDetails();
						userProfileDetails.setFullName(object[1].toString());
						userProfileDetails.setUserRoleKey(((BigDecimal) object[0]).longValue());
						userProfileList.add(userProfileDetails);
					}
					
					
				}
			}catch (javax.persistence.NoResultException nre) {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "==== no details present  " + nre);
				logMessage(nre.getMessage());
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "==== Exit getUserProfilesByRoleKeys  ===");
			return userProfileList;
		}
		@PostConstruct
		public void createTrieMap() {
//			trieDataStructure = new Trie<ReportingManager>();
//			dataCache = new MasterDataCache(1200);
//			masterDataMap = dataCache.getAllDbData(entityManager);
//			ReportingManager response = null;
//			for (Entry<String, String> empDetail : masterDataMap.entrySet()) {
//				response = new ReportingManager(Long.valueOf(empDetail.getKey()), empDetail.getValue());
//				trieDataStructure.insert(empDetail.getValue(), response);
//			}
			loadUserData();
		}

		@Override
		public List<ReportingManager> getAllReportingManagers(final String searchcriteria) {
			List<ReportingManager> reportingManagers = trieDataStructure.search(searchcriteria);
			Set<ReportingManager> uniqueReportingManagers= new HashSet<ReportingManager>(reportingManagers);
			reportingManagers.clear();
			reportingManagers.addAll(uniqueReportingManagers);
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Exit from UserManagementDaoImpl's getAllReportingManagers method");
			return reportingManagers;
		}
		
		@Override
		public List<UserRoleBean> getUserInfoByAdId(String useradId) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getUserInfoByAdId started : " + useradId);
			List<UserRoleBean> userRoleBeanList = new ArrayList<UserRoleBean>();
			try {
				Query query = entityManager
						.createQuery("from UserProfile userpr where userpr.adid=:useradId and userpr.isactive = 1");
				query.setParameter("useradId", useradId);

				@SuppressWarnings("unchecked")
				List<UserProfile> userList = (List<UserProfile>) query.getResultList();
				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "userList size : " + userList.size());
				for (UserProfile userProfile : userList) {
					List<UserRole> UserRoleList = getRolesByUserKey(userProfile.getBfsdUser().getUserkey());
					if (!UserRoleList.isEmpty()) {
						for (UserRole userRole : UserRoleList) {
							UserRoleBean userRoleBean = new UserRoleBean();
							userRoleBean.setUserKey(userProfile.getBfsdUser().getUserkey());
							userRoleBean.setUserType(userProfile.getBfsdUser().getUsertype().longValue());
							userRoleBean.setRoleKey(userRole.getBfsdRoleMaster().getRolekey());
							userRoleBean.setRoleName(userRole.getBfsdRoleMaster().getRolename());
							userRoleBean.setUserRoleKey(userRole.getUserrolekey());
							userRoleBeanList.add(userRoleBean);
						}
					}
				}
			} catch (javax.persistence.NoResultException nre) {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "==== no details present  " + nre);
				logMessage(nre.getMessage());
			}
			return userRoleBeanList;

		}
		

		@SuppressWarnings("unchecked")
		@Override
		public UserRoleBean getUserNameBeanByUserRoleKey(long userRoleKey) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getUserNameBeanByUserRoleKey started : " + userRoleKey);
			UserRoleBean userRoleBean = new UserRoleBean();
			try {
				Query query = entityManager
						.createQuery("select ur.userrolekey, ur.bfsduser.userkey, ur.bfsduser.usertype, ur.bfsdRoleMaster.rolekey from UserRole ur where ur.userrolekey=:userRoleKey and ur.isactive=:isActive");
				query.setParameter("userRoleKey", userRoleKey);
				query.setParameter("isActive", new BigDecimal(1));
				List<Object[]> objects1 = query.getResultList();
				if(null != objects1 && !objects1.isEmpty()) {
					for (Object[] objects : objects1) {
						userRoleBean.setUserRoleKey(Long.valueOf(objects[0].toString()));
						userRoleBean.setUserKey(Long.valueOf(objects[1].toString()));
						userRoleBean.setUserType(Long.valueOf(objects[2].toString()));
						userRoleBean.setRoleKey(Long.valueOf(objects[3].toString()));
					}
				}
			} catch (javax.persistence.NoResultException nre) {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "No such record found : " + nre);
				logMessage(nre.getMessage());
			} catch (Exception exception) {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "Exception while getting user details based on userRoleKey : " + exception);
				throw new BFLTechnicalException("UMS-008", "User Does Not exist.");
			}
			return userRoleBean;
		}
		public void createSpecialization(List<String> specializations, Long userKey) {
			List<UserAddlAttributes> userAddlAttributesList = new ArrayList<>();
			for (String specialization : specializations) {
				UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
				userAddlAttributes.setAttrrkey(userKey);
				userAddlAttributes.setAttrcode("SPECIALIZATION");
				userAddlAttributes.setAttrkeytype("USER");
				userAddlAttributes.setAttrvalue(specialization);
				userAddlAttributes.setIsactive(1);
				userAddlAttributes.setLstupdateby(userKey);
				userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
				userAddlAttributesList.add(userAddlAttributes);
			}
			userAddlAttributesRepository.save(userAddlAttributesList);
		}

		public void createSkill(List<String> skills, Long userKey) {
			List<UserAddlAttributes> userAddlAttributesList = new ArrayList<>();
			for (String skill : skills) {
				UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
				userAddlAttributes.setAttrrkey(userKey);
				userAddlAttributes.setAttrcode("SKILLS");
				userAddlAttributes.setAttrkeytype("USER");
				userAddlAttributes.setAttrvalue(skill);
				userAddlAttributes.setIsactive(1);
				userAddlAttributes.setLstupdateby(userKey);
				userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
				userAddlAttributesList.add(userAddlAttributes);

			}
			userAddlAttributesRepository.save(userAddlAttributesList);
		}

		public void createPaymentMode(List<String> paymentModes, Long userKey) {
			List<UserAddlAttributes> userAddlAttributesList = new ArrayList<>();
			for (String paymentMode : paymentModes) {
				UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
				userAddlAttributes.setAttrrkey(userKey);
				userAddlAttributes.setAttrcode("PAYMENT_MODES_ALLOW");
				userAddlAttributes.setAttrkeytype("USER");
				userAddlAttributes.setAttrvalue(paymentMode);
				userAddlAttributes.setIsactive(1);
				userAddlAttributes.setLstupdateby(userKey);
				userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
				userAddlAttributesList.add(userAddlAttributes);

			}
			userAddlAttributesRepository.save(userAddlAttributesList);
		}

		public void createChannel(List<String> channels, Long userKey) {
			List<UserAddlAttributes> userAddlAttributesList = new ArrayList<>();
			for (String channel : channels) {
				UserAddlAttributes userAddlAttributes = new UserAddlAttributes();
				userAddlAttributes.setAttrrkey(userKey);
				userAddlAttributes.setAttrcode("CHANNEL");
				userAddlAttributes.setAttrkeytype("USER");
				userAddlAttributes.setAttrvalue(channel);
				userAddlAttributes.setIsactive(1);
				userAddlAttributes.setLstupdateby(userKey);
				userAddlAttributes.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
				userAddlAttributesList.add(userAddlAttributes);
			}
			userAddlAttributesRepository.save(userAddlAttributesList);
		}

		private void loadUserData() {
			List<Object[]> reportingManagers=userMgmtProdDao.loadUserData();
			if (!CollectionUtils.isEmpty(reportingManagers)) {
				trieDataStructure = null;
				trieDataStructure = new Trie<ReportingManager>();
				reportingManagers.forEach(detail -> {
					ReportingManager response = null;
					if (null != detail[2]) {
						// dataMap.put(detail[0].toString(), detail[1].toString() + " " +
						// detail[2].toString());
						response = new ReportingManager(Long.valueOf(detail[0].toString()),
								detail[1].toString() + " " + detail[2].toString());
						trieDataStructure.insert(detail[1].toString() + " " + detail[2].toString(), response);
					} else {
						// dataMap.put(detail[0].toString(), detail[1].toString());
						response = new ReportingManager(Long.valueOf(detail[0].toString()), detail[1].toString());
						trieDataStructure.insert(detail[1].toString(), response);

					}

				});
			}

		}

}
