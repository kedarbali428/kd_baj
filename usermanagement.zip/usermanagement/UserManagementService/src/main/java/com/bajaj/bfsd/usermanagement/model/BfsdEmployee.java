package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the BFSD_EMPLOYEES database table.
 * 
 */
@Entity
@Table(name = "BFSD_EMPLOYEES")
//@NamedQuery(name = "BfsdEmployee.findAll", query = "SELECT b FROM BfsdEmployee b")
public class BfsdEmployee implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long employeekey;

	@Temporal(TemporalType.DATE)
	private Date dateofbirth;

	private String designation;

	private String emailid;

	private String employeeid;

	private BigDecimal employeetype;

	private String firstname;

	private BigDecimal genderkey;

	private BigDecimal isactive;

	@Temporal(TemporalType.DATE)
	private Date joiningdt;

	private String lastname;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal maritalstatuskey;

	private String middlename;

	private String phone;

	private BigDecimal salutationkey;

	// bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name = "USERKEY")
	private BfsdUser bfsdUser;

	public long getEmployeekey() {
		return this.employeekey;
	}

	public void setEmployeekey(long employeekey) {
		this.employeekey = employeekey;
	}

	public Date getDateofbirth() {
		return this.dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getDesignation() {
		return this.designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmailid() {
		return this.emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getEmployeeid() {
		return this.employeeid;
	}

	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}

	public BigDecimal getEmployeetype() {
		return this.employeetype;
	}

	public void setEmployeetype(BigDecimal employeetype) {
		this.employeetype = employeetype;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public BigDecimal getGenderkey() {
		return this.genderkey;
	}

	public void setGenderkey(BigDecimal genderkey) {
		this.genderkey = genderkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public Date getJoiningdt() {
		return this.joiningdt;
	}

	public void setJoiningdt(Date joiningdt) {
		this.joiningdt = joiningdt;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getMaritalstatuskey() {
		return this.maritalstatuskey;
	}

	public void setMaritalstatuskey(BigDecimal maritalstatuskey) {
		this.maritalstatuskey = maritalstatuskey;
	}

	public String getMiddlename() {
		return this.middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public BigDecimal getSalutationkey() {
		return this.salutationkey;
	}

	public void setSalutationkey(BigDecimal salutationkey) {
		this.salutationkey = salutationkey;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

}