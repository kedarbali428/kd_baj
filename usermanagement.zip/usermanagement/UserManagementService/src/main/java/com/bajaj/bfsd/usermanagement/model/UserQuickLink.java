package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the USER_QUICK_LINKS database table.
 * 
 */
@Entity
@Table(name="USER_QUICK_LINKS")
//@NamedQuery(name="UserQuickLink.findAll", query="SELECT u FROM UserQuickLink u")
public class UserQuickLink implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long userquicklinkkey;

	private BigDecimal displayorder;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="USERKEY")
	private BfsdUser bfsdUser;

	//bi-directional many-to-one association to QuickLinkList
	@ManyToOne
	@JoinColumn(name="QUICKLINKKEY")
	private QuickLinkList quickLinkList;

	public long getUserquicklinkkey() {
		return this.userquicklinkkey;
	}

	public void setUserquicklinkkey(long userquicklinkkey) {
		this.userquicklinkkey = userquicklinkkey;
	}

	public BigDecimal getDisplayorder() {
		return this.displayorder;
	}

	public void setDisplayorder(BigDecimal displayorder) {
		this.displayorder = displayorder;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

	public QuickLinkList getQuickLinkList() {
		return this.quickLinkList;
	}

	public void setQuickLinkList(QuickLinkList quickLinkList) {
		this.quickLinkList = quickLinkList;
	}

}