package com.bajaj.bfsd.usermanagement.controller;

import static com.bajaj.bfsd.common.BFLLoggerComponent.CONTROLLER;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.BusinessVerticalBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoBean;
import com.bajaj.bfsd.usermanagement.service.UserManagementAttributeService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
public class UserManagementAttributeController {
	private static final String THIS_CLASS = UserManagementAttributeController.class.getCanonicalName();
	
	@Autowired
	BFLLoggerUtil bflLoggerUtil;
	
	@Autowired
	UserManagementAttributeService userManagementAttributeService;
	
	private static final String CLASS_NAME = UserManagementAttributeController.class.getCanonicalName();
	
	@ApiOperation(value = "User details based on userKey", notes = "Get user details based on userKey", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header") })
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.user.attributes.GET.uri}")
	@CrossOrigin
	public ResponseEntity<?> getUserDetailsByUserKey(@RequestParam(name= "userKey") Long userKey, @RequestHeader HttpHeaders headers) {
		bflLoggerUtil.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Inside getUserDetailsByUserKey method where userKey : " + userKey);
		UserInfoBean userInfoBean = userManagementAttributeService.getUserDetailsByUserKey(userKey);
		return new ResponseEntity<>(userInfoBean, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Business Vertical and PO Types", notes = "Get all Business Vertical and PO Types", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header") })
	@RequestMapping(method = RequestMethod.GET, value = "${api.usermanagement.businessvertical.types.GET.uri}")
	@CrossOrigin
	public ResponseEntity<?> getBusinessVerticalAndPOTypes(@RequestHeader HttpHeaders headers) {
		bflLoggerUtil.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Inside getBusinessVerticalAndPOTypes method.");
		List<BusinessVerticalBean> businessVerticalBeans = new ArrayList<BusinessVerticalBean>();
		try {
			businessVerticalBeans = userManagementAttributeService.getBusinessVerticalAndPOTypes();
		}catch (Exception exception) {
			bflLoggerUtil.error(CLASS_NAME, CONTROLLER, "Exception while fetching business vertical and corresponding PO types : " + exception);
			throw exception;
		}
		return new ResponseEntity<>(businessVerticalBeans, HttpStatus.OK);
	}
}