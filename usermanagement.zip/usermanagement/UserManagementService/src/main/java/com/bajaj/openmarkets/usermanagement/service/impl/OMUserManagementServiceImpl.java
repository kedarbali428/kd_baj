package com.bajaj.openmarkets.usermanagement.service.impl;

import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DATE_OF_BIRTH;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.MOBILE;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.USERTYPE_CUSTOMER;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.cache.service.UserCacheService;
import com.bajaj.bfsd.common.cache.service.entity.CacheUserEntity;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bajaj.openmarkets.usermanagement.bean.UserRequest;
import com.bajaj.openmarkets.usermanagement.bean.UserResponse;
import com.bajaj.openmarkets.usermanagement.cache.entity.CacheAdditionalInfo;
import com.bajaj.openmarkets.usermanagement.cache.repository.CacheAdditionalInfoRepository;
import com.bajaj.openmarkets.usermanagement.dao.OMUserManagementDao;
import com.bajaj.openmarkets.usermanagement.service.OMUserManagementService;

@Component
public class OMUserManagementServiceImpl implements OMUserManagementService {

	private static final int ADDITIONAL_INFO_PROFILE_TTL_MIN = 60;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	OMUserManagementDao userManagementDao;

	@Autowired
	CacheAdditionalInfoRepository cacheAdditionalInfoRepo;
	
	@Autowired
	UserCacheService userCacheService;

	@Override
	public UserResponse getUser(UserRequest userRequest) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.DAO, "Inside getUser - start");
		UserResponse userResponse = null;

		if (USERTYPE_CUSTOMER == userRequest.getUserType() && null != userRequest.getDateOfBirth()
				&& !userRequest.getDateOfBirth().isEmpty()) {
			UserLoginAccount userLoginAccount = userManagementDao.getUserAccount(userRequest);

			userResponse = new UserResponse();

			userResponse.setUserId(userLoginAccount.getBfsdUser().getUserkey());
			userResponse.setLoginId(userLoginAccount.getLoginid());
			userResponse.setUserType(userLoginAccount.getBfsdUser().getUsertype().shortValue());
			buildAdditionalInforProfile(userRequest, userResponse.getUserId());
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.DAO,
					"Inside getUser - end with user exist");
			return userResponse;

		} else {

			StringBuilder loginId = new StringBuilder(userRequest.getMobile());
			if (null != userRequest.getDateOfBirth() && !userRequest.getDateOfBirth().isEmpty())
				loginId.append("_").append(userRequest.getDateOfBirth());

			userResponse = new UserResponse();
			userResponse.setUserId(Long.valueOf(userRequest.getMobile()));
			userResponse.setLoginId(loginId.toString());

			userResponse.setUserType(userRequest.getUserType());
			buildAdditionalInforProfile(userRequest, userResponse.getUserId());
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.DAO,
					"Inside getUser - end with pseudo user created");
			return userResponse;
		}
	}

	@Override
	public CacheAdditionalInfo getUser(long userId) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
				"Inside getUser - start");
		CacheAdditionalInfo cacheAdditionalInfo = null;
		try {
			cacheAdditionalInfo = cacheAdditionalInfoRepo.get(userId, 60);
		} catch (Exception ex) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE, "Additional Info fetch failure from cache with exception: " + ex);
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
				"Inside getUser - end");
		return cacheAdditionalInfo;
	}
	
	@Override
	public CacheAdditionalInfo getUserRoleKey(long userId) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
				"Inside getUserRoleKey - start");
		CacheAdditionalInfo cacheAdditionalInfo = null;
		try {
			CacheUserEntity cacheUserEntity =userCacheService.get(userId);
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
					"Inside getUserRoleKey - try");
			UserRole userrole = userManagementDao.getUserRole(userId, cacheUserEntity.getRoleKey());
			if(null!=userrole )
			cacheAdditionalInfo = new CacheAdditionalInfo(userrole.getUserrolekey());
		} catch (Exception ex) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE, "Additional Info fetch failure from cache with exception: " + ex);
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
				"Inside getUserRoleKey - end");
		return cacheAdditionalInfo;
	}
	
	private void buildAdditionalInforProfile(UserRequest userRequest, Long userId) {

		Map<String,Object> resourceMap=new HashMap<>();
		if (!StringUtils.isBlank(userRequest.getMobile())) {
			resourceMap.put(MOBILE, userRequest.getMobile());
		}
		if (!StringUtils.isBlank(userRequest.getDateOfBirth())) {
			resourceMap.put(DATE_OF_BIRTH, userRequest.getDateOfBirth());
		}
		CacheAdditionalInfo cacheAdditionalInfo = new CacheAdditionalInfo(userId,
				userRequest.getApplicationKey(), userRequest.getApplicantKey(),resourceMap);
		 cacheAdditionalInfoRepo.save(userId, cacheAdditionalInfo, ADDITIONAL_INFO_PROFILE_TTL_MIN);
	}
}
