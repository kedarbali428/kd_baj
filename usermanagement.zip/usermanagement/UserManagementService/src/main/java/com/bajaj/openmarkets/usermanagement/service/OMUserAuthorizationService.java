package com.bajaj.openmarkets.usermanagement.service;

import com.bajaj.openmarkets.usermanagement.bean.AuthorizationCodesRequest;
import com.bajaj.openmarkets.usermanagement.bean.AuthorizationCodesResponse;

public interface OMUserAuthorizationService {

	public AuthorizationCodesResponse getAuthorizationTokenCode(AuthorizationCodesRequest request, 
			String authtoken);

}
