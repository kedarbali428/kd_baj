package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class FacebookProfileBean extends UserProfileBean implements Serializable{

	private static final long serialVersionUID = 1322594162476580259L;

	private String ageRangeMin;
	
	private String ageRangeMax;
	
	private Date dob;
	
	private String email;
	
	private String employeeNum;
	
	private String gender;
	
	private String hometown;
	
	private boolean isVerified;
	
	private String profileLink;
	
	private Timestamp profileUpdateTime;
	
	private String relationShipStatus;
	
	public String getAgeRangeMin() {
		return ageRangeMin;
	}

	public void setAgeRangeMin(String ageRangeMin) {
		this.ageRangeMin = ageRangeMin;
	}

	public String getAgeRangeMax() {
		return ageRangeMax;
	}

	public void setAgeRangeMax(String ageRangeMax) {
		this.ageRangeMax = ageRangeMax;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmployeeNum() {
		return employeeNum;
	}

	public void setEmployeeNum(String employeeNum) {
		this.employeeNum = employeeNum;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getHometown() {
		return hometown;
	}

	public void setHometown(String hometown) {
		this.hometown = hometown;
	}

	public boolean isVerified() {
		return isVerified;
	}

	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}

	public String getProfileLink() {
		return profileLink;
	}

	public void setProfileLink(String profileLink) {
		this.profileLink = profileLink;
	}

	public Timestamp getProfileUpdateTime() {
		return profileUpdateTime;
	}

	public void setProfileUpdateTime(Timestamp profileUpdateTime) {
		this.profileUpdateTime = profileUpdateTime;
	}

	public String getRelationShipStatus() {
		return relationShipStatus;
	}

	public void setRelationShipStatus(String relationShipStatus) {
		this.relationShipStatus = relationShipStatus;
	}

}
