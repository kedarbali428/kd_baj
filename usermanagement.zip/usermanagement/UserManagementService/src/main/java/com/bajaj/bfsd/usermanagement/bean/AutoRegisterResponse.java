package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;

public class AutoRegisterResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -496086279316914579L;
	private boolean userExists;

	public boolean isUserExists() {
		return userExists;
	}

	public void setUserExists(boolean userExists) {
		this.userExists = userExists;
	}
	
}
