package com.bajaj.bfsd.usermanagement.bean;

public class POTypeBean {
	private String POTypeCode;
	private String POTypeDesc;
	
	public String getPOTypeCode() {
		return POTypeCode;
	}
	
	public void setPOTypeCode(String pOTypeCode) {
		POTypeCode = pOTypeCode;
	}
	
	public String getPOTypeDesc() {
		return POTypeDesc;
	}
	
	public void setPOTypeDesc(String pOTypeDesc) {
		POTypeDesc = pOTypeDesc;
	}
}