package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the INS_PROVIDERS database table.
 * 
 */
@Entity
@Table(name="INS_PROVIDERS")
//@NamedQuery(name="InsProvider.findAll", query="SELECT i FROM InsProvider i")
public class InsProvider implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long insproviderkey;

	private String addressline1;

	private String addressline2;

	private String addressline3;

	private BigDecimal citykey;

	private BigDecimal countrykey;

	private String emailid;

	@Temporal(TemporalType.DATE)
	private Date establishmentdt;

	private String faxnumber;

	private String groupcode;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal pincodekey;

	private String postboxnum;

	private String providercode;

	private String providername;

	private BigDecimal providertype;

	private BigDecimal statekey;

	private String telephonenum;

	//bi-directional many-to-one association to InsProductPlan
	@OneToMany(mappedBy="insProvider")
	private List<InsProductPlan> insProductPlans;

	public InsProvider() {
	}

	public long getInsproviderkey() {
		return this.insproviderkey;
	}

	public void setInsproviderkey(long insproviderkey) {
		this.insproviderkey = insproviderkey;
	}

	public String getAddressline1() {
		return this.addressline1;
	}

	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	public String getAddressline2() {
		return this.addressline2;
	}

	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}

	public String getAddressline3() {
		return this.addressline3;
	}

	public void setAddressline3(String addressline3) {
		this.addressline3 = addressline3;
	}

	public BigDecimal getCitykey() {
		return this.citykey;
	}

	public void setCitykey(BigDecimal citykey) {
		this.citykey = citykey;
	}

	public BigDecimal getCountrykey() {
		return this.countrykey;
	}

	public void setCountrykey(BigDecimal countrykey) {
		this.countrykey = countrykey;
	}

	public String getEmailid() {
		return this.emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public Date getEstablishmentdt() {
		return this.establishmentdt;
	}

	public void setEstablishmentdt(Date establishmentdt) {
		this.establishmentdt = establishmentdt;
	}

	public String getFaxnumber() {
		return this.faxnumber;
	}

	public void setFaxnumber(String faxnumber) {
		this.faxnumber = faxnumber;
	}

	public String getGroupcode() {
		return this.groupcode;
	}

	public void setGroupcode(String groupcode) {
		this.groupcode = groupcode;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getPincodekey() {
		return this.pincodekey;
	}

	public void setPincodekey(BigDecimal pincodekey) {
		this.pincodekey = pincodekey;
	}

	public String getPostboxnum() {
		return this.postboxnum;
	}

	public void setPostboxnum(String postboxnum) {
		this.postboxnum = postboxnum;
	}

	public String getProvidercode() {
		return this.providercode;
	}

	public void setProvidercode(String providercode) {
		this.providercode = providercode;
	}

	public String getProvidername() {
		return this.providername;
	}

	public void setProvidername(String providername) {
		this.providername = providername;
	}

	public BigDecimal getProvidertype() {
		return this.providertype;
	}

	public void setProvidertype(BigDecimal providertype) {
		this.providertype = providertype;
	}

	public BigDecimal getStatekey() {
		return this.statekey;
	}

	public void setStatekey(BigDecimal statekey) {
		this.statekey = statekey;
	}

	public String getTelephonenum() {
		return this.telephonenum;
	}

	public void setTelephonenum(String telephonenum) {
		this.telephonenum = telephonenum;
	}

	public List<InsProductPlan> getInsProductPlans() {
		return this.insProductPlans;
	}

	public void setInsProductPlans(List<InsProductPlan> insProductPlans) {
		this.insProductPlans = insProductPlans;
	}

	public InsProductPlan addInsProductPlan(InsProductPlan insProductPlan) {
		getInsProductPlans().add(insProductPlan);
		insProductPlan.setInsProvider(this);

		return insProductPlan;
	}

	public InsProductPlan removeInsProductPlan(InsProductPlan insProductPlan) {
		getInsProductPlans().remove(insProductPlan);
		insProductPlan.setInsProvider(null);

		return insProductPlan;
	}

}