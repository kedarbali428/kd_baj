package com.bajaj.bfsd.usermanagement.bean;

import java.util.ArrayList;
import java.util.List;

public class BusinessVerticalBean {
	private String businessVerticalCode;
	private String businessVerticalDesc;
	private List<POTypeBean> poTypes = new ArrayList<POTypeBean>();
	
	public String getBusinessVerticalCode() {
		return businessVerticalCode;
	}
	
	public void setBusinessVerticalCode(String businessVerticalCode) {
		this.businessVerticalCode = businessVerticalCode;
	}
	
	public String getBusinessVerticalDesc() {
		return businessVerticalDesc;
	}
	
	public void setBusinessVerticalDesc(String businessVerticalDesc) {
		this.businessVerticalDesc = businessVerticalDesc;
	}
	
	public List<POTypeBean> getPoTypes() {
		return poTypes;
	}
	
	public void setPoTypes(List<POTypeBean> poTypes) {
		this.poTypes = poTypes;
	}
}