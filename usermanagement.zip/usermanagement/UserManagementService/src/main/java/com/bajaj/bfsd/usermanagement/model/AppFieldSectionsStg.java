package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the APP_FIELD_SECTIONS_STG database table.
 * 
 */
@Entity
@Table(name="APP_FIELD_SECTIONS_STG")
//@NamedQuery(name="AppFieldSectionsStg.findAll", query="SELECT a FROM AppFieldSectionsStg a")
public class AppFieldSectionsStg implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private Long dummyId;

	private BigDecimal orderno;

	private BigDecimal parentsection;

	private BigDecimal sectioncd;

	private String sectionname;

	public BigDecimal getOrderno() {
		return this.orderno;
	}

	public void setOrderno(BigDecimal orderno) {
		this.orderno = orderno;
	}

	public BigDecimal getParentsection() {
		return this.parentsection;
	}

	public void setParentsection(BigDecimal parentsection) {
		this.parentsection = parentsection;
	}

	public BigDecimal getSectioncd() {
		return this.sectioncd;
	}

	public void setSectioncd(BigDecimal sectioncd) {
		this.sectioncd = sectioncd;
	}

	public String getSectionname() {
		return this.sectionname;
	}

	public void setSectionname(String sectionname) {
		this.sectionname = sectionname;
	}

}