package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BUSINESS_VERTICAL_MASTER")
public class BusinessVerticalMaster implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long businessverticalmastkey;
	
	private String businessverticalcode;
	
	private String businessverticalname;
	
	private String potypecode;
	
	private String potype;
	
	private long createdby;
	
	private Timestamp createddt;
	
	private BigDecimal isactive;
	
	private long lstupdateby;
	
	private Timestamp lstupdatedt;
	
	public long getBusinessverticalmastkey() {
		return businessverticalmastkey;
	}
	public void setBusinessverticalmastkey(long businessverticalmastkey) {
		this.businessverticalmastkey = businessverticalmastkey;
	}
	public String getBusinessverticalcode() {
		return businessverticalcode;
	}
	public void setBusinessverticalcode(String businessverticalcode) {
		this.businessverticalcode = businessverticalcode;
	}
	public String getBusinessverticalname() {
		return businessverticalname;
	}
	public void setBusinessverticalname(String businessverticalname) {
		this.businessverticalname = businessverticalname;
	}
	public String getPotypecode() {
		return potypecode;
	}
	public void setPotypecode(String potypecode) {
		this.potypecode = potypecode;
	}
	public String getPotype() {
		return potype;
	}
	public void setPotype(String potype) {
		this.potype = potype;
	}
	public long getCreatedby() {
		return createdby;
	}
	public void setCreatedby(long createdby) {
		this.createdby = createdby;
	}
	public Timestamp getCreateddt() {
		return createddt;
	}
	public void setCreateddt(Timestamp createddt) {
		this.createddt = createddt;
	}
	public BigDecimal getIsactive() {
		return isactive;
	}
	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}
	public long getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
}