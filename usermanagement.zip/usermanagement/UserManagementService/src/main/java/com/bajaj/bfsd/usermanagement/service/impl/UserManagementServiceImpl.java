package com.bajaj.bfsd.usermanagement.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bajaj.bfsd.usermanagement.MapperFactory;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterRequest;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterResponse;
import com.bajaj.bfsd.usermanagement.bean.BfsdRoleMasterResponse;
import com.bajaj.bfsd.usermanagement.bean.BfsdUserDetails;
import com.bajaj.bfsd.usermanagement.bean.BfsdUserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.ChangePasswordRequest;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.ReportingManager;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.TokenResponse;
import com.bajaj.bfsd.usermanagement.bean.UICredentialsResponse;
import com.bajaj.bfsd.usermanagement.bean.User;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserDetailBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountResponse;
import com.bajaj.bfsd.usermanagement.bean.UserManagementResponse;
import com.bajaj.bfsd.usermanagement.bean.UserMappingRequest;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.bean.UserProfileDetails;
import com.bajaj.bfsd.usermanagement.bean.UserRoleBean;
import com.bajaj.bfsd.usermanagement.bean.UserVendorProfileBean;
import com.bajaj.bfsd.usermanagement.bean.ValidateTokenBean;
import com.bajaj.bfsd.usermanagement.dao.UserManagementDao;
import com.bajaj.bfsd.usermanagement.helper.UICredentialCache;
import com.bajaj.bfsd.usermanagement.helper.UserManagementHelper;
import com.bajaj.bfsd.usermanagement.model.AppContactAuthRequest;
import com.bajaj.bfsd.usermanagement.model.BfsdRoleMaster;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.model.UserProfile;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bajaj.bfsd.usermanagement.repository.BfsdRoleMasterRepository;
import com.bajaj.bfsd.usermanagement.repository.BfsdUserRepository;
import com.bajaj.bfsd.usermanagement.service.UserManagementService;
import com.bajaj.bfsd.usermanagement.util.Ldaputility;
import com.bajaj.bfsd.usermanagement.util.LoginPasswordValidator;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.bfsd.usermanagement.util.UserManagementUtility;
import com.bajaj.markets.credit.sender.config.EventMessage;
import com.bajaj.markets.credit.sender.service.SenderService;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RefreshScope
@Service
public class UserManagementServiceImpl extends BFLComponent implements UserManagementService {

	private static final String CLASS_NAME = UserManagementServiceImpl.class.getCanonicalName();
	public static final String UMS_036 = "UMS-036";
	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	Environment env;

	@Autowired
	UserManagementDao userManagementDao;

	@Autowired
	UserManagementHelper userManagementHelper;

	@Autowired
	UserManagementResponse userManagementResponse;

	@Autowired
	private LoginPasswordValidator validator;
	
	@Autowired
	UserProfileBean upb;

	@Autowired
	private CustomDefaultHeaders headers;
	
	@Autowired
	BfsdRoleMasterRepository bfsdRoleMasterRepository;
	
	@Value("${ENCRYPTION_KEY}")
	private String encryptionKey;

	@Value("${api.allocation.assignments.assignto.POST.url}")
	private String assignToUrl;
	@Value("${api.tokenmanagement.generatetoken.POST.url}")
	private String tokenServiceURL;
	@Value("${api.applicant.updateapplicantbyfield.PUT.url}")
	private String applicantUpdateUrl;

	@Autowired
	Ldaputility ldaputility;
	
	@Autowired
	UICredentialCache uiCredentialCache;
	@Autowired
	BfsdUserRepository userRepo;
	
	@Autowired
	SenderService senderService;
	
	@Override
	public BfsdUser createUser(User userBean) {
		BfsdUser bfsdUser = userManagementDao.createUser(userBean);
		createEventMessage(UserManagementConstants.USER_EVENT_CREATED,bfsdUser);
		return bfsdUser;
	}

	@Override
	public String createUserMapping(UserMappingRequest userMappingBean) {

		return userManagementDao.createUserMapping(userMappingBean);
	}

	@Override
	public String updateUserMapping(UserMappingRequest userMappingBean) {

		return userManagementDao.updateUserMapping(userMappingBean);
	}

	@Override
	public int deleteUser(UserConfigurationBean userConfig) {
		return userManagementDao.deleteUser(userConfig);
	}

	@Override
	public UserConfigurationBean getUserInformation(UserConfigurationBean userConfig,HttpHeaders headers) {
		return userManagementDao.getUserInformation(userConfig,headers);

	}

	@Override
	public UserConfigurationBean getActiveDirectoryUsers(UserConfigurationBean userConfig) {

		UserConfigurationBean userConfigBean = new UserConfigurationBean();

		if (UserManagementConstants.EMPLOYEE.equals(userConfig.getEmployeeType())) {
			getUserEmpList(userConfig, userConfigBean);
		} else if (UserManagementConstants.VENDOR_COMPANY.equals(userConfig.getEmployeeType())
				|| UserManagementConstants.VENDOR_INDIVIDUAL.equals(userConfig.getEmployeeType())
				|| UserManagementConstants.PRINCIPAL_USER.equalsIgnoreCase(userConfig.getEmployeeType())) {
			getUserVendorList(userConfig, userConfigBean);
		}

		return userConfigBean;

	}

	private void getUserEmpList(UserConfigurationBean userConfig, UserConfigurationBean userConfigBean) {
		List<User> userList;
		User user = new User();
		if (userConfig.getFirstName() != null && !userConfig.getFirstName().isEmpty())
			user.setFirstName(userConfig.getFirstName());
		if (userConfig.getLastName() != null && !userConfig.getLastName().isEmpty())
			user.setLastName(userConfig.getLastName());

		if (userConfig.getEmailId() != null && !userConfig.getEmailId().isEmpty())
			user.setEmailId(userConfig.getEmailId());

		if (userConfig.getDesignation() != null && !userConfig.getDesignation().isEmpty())
			user.setDesignation(userConfig.getDesignation());

		userList = ldaputility.getADUsers(user);
		userConfigBean.setUserADList(userList);
	}

	private void getUserVendorList(UserConfigurationBean userConfig, UserConfigurationBean userConfigBean) {
		List<UserProfile> userVendorProfiles = userManagementDao.searchUser(userConfig);
		List<UserVendorProfileBean> userVendorProfileBeans = new ArrayList<>();
		for (UserProfile userVendorProfile : userVendorProfiles) {
			UserVendorProfileBean user = new UserVendorProfileBean();
			UserProfile.getBeanFromEntity(userVendorProfile, user);
			userVendorProfileBeans.add(user);
		}
		userConfigBean.setUserVendorList(userVendorProfileBeans);
	}


	@Override
	public int updateUserDetails(UserInfoRequest userInfoRequest) {
		return  userManagementDao.updateUserDetails(userInfoRequest);

	}
	
	@Override
	public List<SupervisorBean> getuserSuperVisor(String userRole) {
		return userManagementDao.getuserSuperVisor(userRole);
	}

	@Override
	public List<LocationBean> getSuperVisorLocations(String userKey) {
		return userManagementDao.getSuperVisorLocations(userKey);
	}

	@Override
	public List<ChannelBean> getSuperVisorChannels(String userRoleKey) {
		return userManagementDao.getSuperVisorChannels(userRoleKey);
	}

	@Override
	public List<PinCodeBean> getLocationPin(String locationKey) {
		return userManagementDao.getLocationPin(locationKey);
	}

	@Override
	public List roleMapped(long employeeKey, long roleKey) {
		return userManagementDao.details(employeeKey, roleKey);

	}

	@Override
	public boolean deleteUserMapping(Long userKey, Long roleKey) {
		return userManagementDao.deleteUserMapping(userKey, roleKey);
	}

	// IAM changes - start

	@Override
	public UserLoginAccountResponse getUserId(String loginId) {
		UserLoginAccount userLoginAccount = userManagementDao.getUserId(loginId);
		UserLoginAccountResponse userLoginAccountResponse = new UserLoginAccountResponse();
		// BfsdUser bfsdUser = new BfsdUser()
		if (userLoginAccount != null) {
			userLoginAccountResponse.setUserId(userLoginAccount.getBfsdUser().getUserkey());
			userLoginAccountResponse.setUserType(userLoginAccount.getBfsdUser().getUsertype().shortValue());

			// bfsdUser = userLoginAccount.getBfsdUser()
		} else {
			throw new BFLBusinessException("UMS-009", "No login details found for Id - " + loginId);
		}
		return userLoginAccountResponse;
	}

	@Override
	@Transactional
	public UserLoginAccountResponse getUserLoginAccount(UserLoginAccountRequest userLoginAccountRequest) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getUserLoginAccount - started");
		UserLoginAccount userLoginAccount = userManagementDao.getUserLoginAccount(userLoginAccountRequest);
		UserLoginAccountResponse userLoginAccountResponse = new UserLoginAccountResponse();
		if (userLoginAccount != null) {
			short loginType = userLoginAccountRequest.getLoginType();
			short userType = userLoginAccountRequest.getUserType();
			short failedCount;
			short blockedFlag;
			BfsdUser currentUser = userLoginAccount.getBfsdUser();

			try {
				failedCount = currentUser.getFailedlogincount().shortValue();
			} catch (Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "getUserLoginAccount - failedCount - " + e);
				failedCount = 0;
			}
			try {
				blockedFlag = currentUser.getUserblockedflg().shortValue();
			} catch (Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "getUserLoginAccount - blockedFlag - " + e);
				blockedFlag = 0;
			}

			userLoginAccountResponse.setUserId(currentUser.getUserkey());
			userLoginAccountResponse.setAccountStatus(blockedFlag);
			userLoginAccountResponse.setLoginId(userLoginAccountRequest.getLoginId());
			userLoginAccountResponse.setUserType(userType);
			userLoginAccountResponse.setLoginFailCount(failedCount);

			// If login type in manual and if loginId is present in DB and
			// password does not match then this end point will increase the
			// login failed count.
			if ((loginType == UserManagementConstants.LOGINACCTYPE_MANUAL
					|| loginType == UserManagementConstants.LOGINACCTYPE_MOBILE_DOB_OTP_MPIN)
					&& userType != UserManagementConstants.USERTYPE_EMPLOYEE) {

				if (blockedFlag == 1) {
					userLoginAccountResponse.setFailedRequest(true);
					return userLoginAccountResponse;
				}

				String inputPlainPwd = userLoginAccountRequest.getPwd();
				String dbHashedPwd = userLoginAccount.getLoginpwd();

				if (!validatePwd(inputPlainPwd, dbHashedPwd, userType)) {
					failedCount++;
					userLoginAccountResponse.setFailedRequest(true);
				} else {
					failedCount = 0;
					//Commenting below code for prod slowness issue
					//userManagementDao.assignRoleToUser(currentUser, loginType, userLoginAccountRequest.getUserType());
				}
				currentUser = userManagementDao.updateFailedCount(currentUser, failedCount, userType);
				userLoginAccountResponse.setLoginFailCount(currentUser.getFailedlogincount().shortValue());
				userLoginAccountResponse.setAccountStatus(currentUser.getUserblockedflg().shortValue());
			}

		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getUserLoginAccount - completed");
		return userLoginAccountResponse;
	}
	/***
	 * BFSDPO-50 :Changes are done to fetch the system users at service startup.
	 */
	@Override
	public UICredentialsResponse getUICredentials(String loginId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getUICredentials - started");
		UICredentialsResponse uiCredentialsResponse = new UICredentialsResponse();
		UserLoginAccount userLoginAcocountResult = uiCredentialCache.getSystemUser(loginId);
		if (null != userLoginAcocountResult) {
			uiCredentialsResponse.setSecretKey(
					null != userLoginAcocountResult.getLoginpwd() ? userLoginAcocountResult.getLoginpwd() : null);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getUICredentials - ended");
		return uiCredentialsResponse;
	}

	// IAM changes - end

	@Override
	public UserDetailBean getRolesByUserKey(long userKey) {

		List<UserRoleBean> userRoleBeans = new ArrayList<>();
		UserDetailBean userDetailBean = new UserDetailBean();

		UserRoleBean userRoleBean;
		List<UserRole> userRoles = userManagementDao.getRolesByUserKey(userKey);
		for (UserRole userRole : userRoles) {
			userRoleBean = new UserRoleBean();
			userRoleBean.setUserKey(userKey);
			userRoleBean.setRoleName(userRole.getBfsdRoleMaster().getRolename());
			userRoleBean.setRoleKey(userRole.getBfsdRoleMaster().getRolekey());
			userRoleBean.setUserRoleKey(userRole.getUserrolekey());
			userRoleBeans.add(userRoleBean);
		}

		userDetailBean.setUserRoles(userRoleBeans);
		UserProfile userProfile = userManagementDao.getUserProfileByUserKey(userKey);
		if (userProfile != null) {
			userDetailBean.setFirstName(userProfile.getFirstname());
			userDetailBean.setLastName(userProfile.getLastname());
			userDetailBean.setProfileImage("/dummypath/profileImage.jpg");
			userDetailBean.setEmailId(userProfile.getEmailid());
			if (userProfile.getAssociationtype().longValue() == 1) {
				userDetailBean.setUserType(UserManagementConstants.EMPLOYEE);
			}else if (userProfile.getAssociationtype().longValue() == 2) {
				userDetailBean.setUserType(UserManagementConstants.VENDOR_INDIVIDUAL);
			}else if (userProfile.getAssociationtype().longValue() == 3) {
				userDetailBean.setUserType(UserManagementConstants.VENDOR_COMPANY);
			}
		}

		return userDetailBean;
	}

	@Override
	public List<UserName> getListOfUserName(long pincode, long function, long role, long tabkey, long subprodkey) {
		return userManagementDao.getListOfUserName(pincode, function, role, tabkey, subprodkey);
	}

	@Override
	public UserName getUserName(long pincode, long function, long role, Long applicationId, long tabkey,
			long subprodkey) {
		List<UserName> userList = userManagementDao.getListOfUserName(pincode, function, role, tabkey, subprodkey);
		UserName userName = userList.get(new Random().nextInt(userList.size()));
		HttpHeaders headersManual = new HttpHeaders();
		Map<String, String> queryParam = new HashMap<>();
		headersManual.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		JSONObject reqJsonObj = new JSONObject();
		reqJsonObj.put("userRoleKey", userName.getUserRoleKey());
		reqJsonObj.put("roleKey", userName.getRoleKey());
		reqJsonObj.put("assignTo", 2);
		reqJsonObj.put("comments", "Assigning in Schedule appointment flow");
		reqJsonObj.put("applicationKey", applicationId);
		queryParam.put("applicationKey", applicationId.toString());
		ResponseEntity<ResponseBean> appResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, assignToUrl, null, ResponseBean.class, queryParam,
						reqJsonObj.toString(), headersManual, null);
		if (appResponse != null && appResponse.getBody() != null && appResponse.getBody().getErrorBean() != null) {
			throw new BFLTechnicalException(appResponse.getBody().getErrorBean().get(0).getErrorCode(),
					appResponse.getBody().getErrorBean().get(0).getErrorMessage());
		}

		return userName;
	}

	@Override
	@Transactional
	public AutoRegisterResponse autoRegister(AutoRegisterRequest request) {

		AutoRegisterResponse response;

		boolean userExists = userManagementDao.autoRegister(request);

		response = new AutoRegisterResponse();
		response.setUserExists(userExists);

		return response;
	}

	@Override
	public void changePassword(ChangePasswordRequest passwordRequest, long userKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "changePassword - started, for userkey = "+userKey);
		String hashedNewPassword;
		String hashedOldPassword = null;

		// Validate new passoword
		boolean isValid = validator.validatePassword(passwordRequest.getPassword());

		if (!isValid) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"changePassword - invalid password format for - " + userKey);
			throw new BFLTechnicalException("UMS-026", env.getProperty("UMS-026"));
		}

		hashedNewPassword = UserManagementUtility.getHashedPassword(passwordRequest.getPassword(), logger);

		if (passwordRequest.getOldPassword() != null && !passwordRequest.getOldPassword().isEmpty())
			hashedOldPassword = UserManagementUtility.getHashedPassword(passwordRequest.getOldPassword(), logger);
		userManagementDao.savePassword(hashedNewPassword, hashedOldPassword, userKey);
		//update table to invalidate the auto-registration token. In case of change password this will not updated we are not sending any token.
		if(!StringUtils.isEmpty(passwordRequest.getAuthToken())&&(passwordRequest.getContactType()!=0)) {
		ValidateTokenBean tokenBean=new ValidateTokenBean();
		tokenBean.setToken(passwordRequest.getAuthToken());
		tokenBean.setContactType(passwordRequest.getContactType());
		String decryptedToken = userManagementHelper.decrypt(passwordRequest.getAuthToken(), encryptionKey, logger);
		userManagementHelper.populateTokenBeanWithDecryptedValues(decryptedToken,tokenBean, logger);
		AppContactAuthRequest authRequest = userManagementDao.validateToken(tokenBean);
		Timestamp curerntTime = Timestamp.from(Instant.now());
		userManagementDao.updateTokenStatus(tokenBean, authRequest, curerntTime, UserManagementConstants.AUTH_STATUS_SUCCESSFUL);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "changePassword - completed, for userkey = "+userKey);
	}

	private boolean validatePwd(String inputEncryptedPwd, String dbHashedPwd, short userType) {

		String inputHashedPwd = inputEncryptedPwd;
		// When userType is not system then hash the plain password and compare
		// with hashed value
		if (userType != UserManagementConstants.USERTYPE_SYSTEM)
			inputHashedPwd = UserManagementUtility.getHashedPassword(inputHashedPwd, logger);

		if (inputHashedPwd.equals(dbHashedPwd))
			return true;

		return false;
	}

	@Override
	@Transactional
	public TokenResponse mergeUsers(long newUserKey, long oldUserKey) {
		if(oldUserKey==newUserKey)
			return null;

		UserLoginAccount user = userManagementDao.mergeUsers(newUserKey, oldUserKey);
		
		if(user == null)
			return null;
		
		BfsdUser bfsdUser = user.getBfsdUser();
		return this.generateUserToken(user.getLoginid(), bfsdUser.getUserkey(), bfsdUser.getUsertype().shortValue());

	}

	private TokenResponse generateUserToken(String loginId, long userKey, short userType) {

		JSONObject tokenRequest = new JSONObject();
		tokenRequest.put("loginId", loginId);
		tokenRequest.put("userId", userKey);
		tokenRequest.put("userType", userType);// For customer

		ResponseEntity<ResponseBean> tokenServiceResponse = BFLCommonRestClient.create(tokenServiceURL, null,
				String.class, null, tokenRequest.toString(), getHttpHeaders(), null);

		if (tokenServiceResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(tokenServiceResponse.getBody().getStatus().name())) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Failure status received from token service - " + tokenServiceResponse);
				throw new BFLTechnicalException("UMS-021", env.getProperty("UMS-021"));

			} else {

				JSONObject respJson = new JSONObject(tokenServiceResponse.getBody().getPayload().toString());
				String json = respJson.getJSONObject("payload").toString();
				try {
					return MapperFactory.getInstance().readValue(json, TokenResponse.class);
				} catch (IOException e) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Unable to parse token json - " + e);
					return null;
				}
			}
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Invalid status received from token service -" + tokenServiceResponse);
			throw new BFLTechnicalException("UMS-022", env.getProperty("UMS-022"));
		}
	}

	private HttpHeaders getHttpHeaders() {
		HttpHeaders headersManual = new HttpHeaders();
		headersManual.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);

		return headersManual;
	}

	@Override
	@Transactional
	public BfsdUser saveUserVendorProfile(User userBean) {

		UserProfile userVendorProfile;
		BfsdUser bfsdUser;
		UserVendorProfileBean userVendorProfileBean = userBean.getUserVendorProfile();

		if (userBean.getEmployeeType().equalsIgnoreCase(UserManagementConstants.VENDOR_COMPANY)) {
			userVendorProfileBean.setAssociationType(3L);
		} else if (userBean.getEmployeeType().equalsIgnoreCase(UserManagementConstants.PRINCIPAL_USER)) {
			userVendorProfileBean.setAssociationType(5L);
		}else
		{
			userVendorProfileBean.setAssociationType(2L);
		}

		if (userVendorProfileBean.getVendorProfileKey() == 0 && userVendorProfileBean.getUserKey() == 0) {
			// Create New BFSD User & User Vendor Profile
			if (userManagementDao.getUserVendorProfile(null, null, userVendorProfileBean.getEmailId()) != null) {
				throw new BFLBusinessException("UMS-029", env.getProperty("UMS-029"));
			}
			userBean.setUserVendorProfile(userVendorProfileBean);
			userBean.setIsActive(BigDecimal.ONE);

			bfsdUser = userManagementDao.createUser(userBean);
			createEventMessage(UserManagementConstants.USER_EVENT_CREATED,bfsdUser);			
			
			// Send reset password link.
		} else if (userVendorProfileBean.getVendorProfileKey() == 0) {
			// Get existing BFSD User & create New User Vendor Profile
			userVendorProfile = new UserProfile();

			bfsdUser = userManagementDao.getEntity(BfsdUser.class, userVendorProfileBean.getUserKey());
			if (bfsdUser == null) {
				throw new BFLBusinessException("UMS-027", env.getProperty("UMS-027"));
			}
			if (userManagementDao.getUserVendorProfile(null, null, userVendorProfileBean.getEmailId()) != null) {
				throw new BFLBusinessException("UMS-029", env.getProperty("UMS-029"));
			}

			UserProfile.getEntityFromBean(userVendorProfileBean, userVendorProfile);
			userVendorProfile.setBfsdUser(bfsdUser);
			userVendorProfile.setAssociationdt(UserManagementUtility.getCurrentDateTimeStamp());
			userVendorProfile.setAssociationtype(BigDecimal.valueOf(userVendorProfileBean.getAssociationType()));
			userVendorProfile.setEmailid(userVendorProfileBean.getEmailId());
			userVendorProfile.setIsactive(BigDecimal.ONE);
			userVendorProfile.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
			userVendorProfile.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			if (userVendorProfileBean.getCompanyId() != null && userVendorProfileBean.getCompanyId() != 0) {
				UserProfile parentCompany = userManagementDao.getEntity(UserProfile.class,
						userVendorProfileBean.getCompanyId());
				if (parentCompany != null) {
					userVendorProfile.setParentCompany(parentCompany);
					userVendorProfile.setCompanyname(parentCompany.getCompanyname());
				}
			}
			if (userManagementDao.saveUserVendorProfile(userVendorProfile) < 0) {
				throw new BFLBusinessException("UMS-028", env.getProperty("UMS-028"));
			}

		} else {
			bfsdUser = updateUserVendorProfile(userVendorProfileBean);
		}
		return bfsdUser;
	}

	private BfsdUser updateUserVendorProfile(UserVendorProfileBean userVendorProfileBean) {
		UserProfile userVendorProfile;
		BfsdUser bfsdUser;
		// Update User Vendor Profile

		userVendorProfile = userManagementDao.getUserVendorProfile(userVendorProfileBean.getVendorProfileKey(), 0L,
				null);
		if (userVendorProfile == null) {
			throw new BFLBusinessException("UMS-027", env.getProperty("UMS-027"));
		}
		bfsdUser = userVendorProfile.getBfsdUser();

		if (userVendorProfileBean.getCompanyId() != null && userVendorProfileBean.getCompanyId() != 0) {
			UserProfile parentCompany = userManagementDao.getEntity(UserProfile.class,
					userVendorProfileBean.getCompanyId());
			if (parentCompany != null) {
				userVendorProfile.setParentCompany(parentCompany);
				userVendorProfile.setCompanyname(parentCompany.getCompanyname());
			}
		}

		UserProfile.getEntityFromBean(userVendorProfileBean, userVendorProfile);
		if (userManagementDao.saveUserVendorProfile(userVendorProfile) < 0) {
			throw new BFLBusinessException("UMS-028", env.getProperty("UMS-028"));
		}
		return bfsdUser;
	}

	@Override
	public boolean validateEmail(String emailId, long applicantKey) {

		boolean isExist;

		isExist = userManagementDao.checkApplicantEmail(emailId, applicantKey);

		if (isExist) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"validateEmail - Email id already exists in applicant details - " + emailId);
			throw new BFLBusinessException(UMS_036, env.getProperty(UMS_036));
		}

		userManagementDao.checkLoginEmail(emailId);
		return true;
	}

	@Override
	@Transactional
	public void saveEmail(String newEmail, String oldEmail, long applicantKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "saveEmail - started for -" + applicantKey);
		long currentUserKey = headers.getUserKey();

		boolean isValid = this.validateEmail(newEmail, applicantKey);

		if (!isValid) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"saveEmail - Emaild id already assigned to another user - " + newEmail);
			throw new BFLBusinessException(UMS_036, env.getProperty(UMS_036));
		}

		// Update login email id
		userManagementDao.saveEmail(currentUserKey, oldEmail, newEmail);

		// Update applicant email
		boolean isApplicantUpdated = this.updateApplicantEmail(applicantKey, newEmail, oldEmail);
		if (!isApplicantUpdated) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"saveEmail - Unable to update applicant email for - " + applicantKey);
			throw new BFLBusinessException("UMS-037", env.getProperty("UMS-037"));
		}

		// deactivate any mail on his previous id
		try {
			userManagementDao.exiprePrevLinks(oldEmail, currentUserKey);
		} catch (Exception ex) {
			this.updateApplicantEmail(applicantKey, oldEmail, newEmail);
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"saveEmail - Error while expiring link for - " + oldEmail + " - ex- " + ex);

		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "saveEmail - completed for -" + applicantKey);
	}

	private boolean updateApplicantEmail(long applicantKey, String newEmail, String oldEmail) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "updateApplicantEmail - started");
		Map<String, String> pathParam = new HashMap<>();
		pathParam.put("applicantKey", String.valueOf(applicantKey));
		pathParam.put("fieldName", UserManagementConstants.FIELD_NAME_PERSONAL_EMAIL);

		JSONObject payload = new JSONObject();
		payload.put("newValue", newEmail);
		payload.put("oldValue", oldEmail);

		int updateCount;
		ResponseEntity<ResponseBean> applicantResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.PUT, applicantUpdateUrl, null, ResponseBean.class, pathParam,
						payload.toString(), getHttpHeaders(), null);

		if (applicantResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(applicantResponse.getBody().getStatus().name())) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error while calling applicant service - " + applicantResponse.getBody().getErrorBean());
				return false;
			} else {
				Map<String, Object> response = (Map<String, Object>) applicantResponse.getBody().getPayload();
				updateCount = Integer.parseInt(response.get("updateCount").toString());
			}
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Invalid status received while calling applicant service URL - " + applicantResponse);
			return false;
		}

		if (updateCount != 1) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Invalid update count for oldEmail - " + oldEmail + ", count - " + updateCount);
			return false;
		}

		return true;
	}

	@Component
	public class AsyncClass {

		@Autowired
		private BFLLoggerUtil logger;

		@Value("${api.userprofile.generateResetPasswordLink.POST.url}")
		private String genPasswordUrl;

		@Async
		public void sendMailForUpdatedEmail(String email, String correlId, String userType) {
			logger.setCorrelationID(correlId);

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendMailForUpdatedEmail - started - " + email);
			Map<String, String> pathParam = new HashMap<>();
			pathParam.put("emailId", email);

			JSONObject payload = new JSONObject();
			payload.put("email", email);
			payload.put("userType", userType);

			ResponseEntity<ResponseBean> sendMailResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
					.invokeRestEndpoint(HttpMethod.POST, genPasswordUrl, null, ResponseBean.class, pathParam,
							payload.toString(), getHttpHeaders(), null);

			if (sendMailResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
				if (StatusCode.FAILURE.name().equals(sendMailResponse.getBody().getStatus().name())) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"sendMailForUpdatedEmail - Error while calling user password reset token service - "
									+ sendMailResponse.getBody().getErrorBean());
				}

			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Invalid status received while calling user password reset token serviceL - "
								+ sendMailResponse);

			}

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendMailForUpdatedEmail - completed - " + email);
		}

	}
	
	@Override
	public UserRoleBean getUserRoleInfo(Long userKey, Long roleKey) {
		return userManagementDao.getUserRoleInfo(userKey, roleKey);
	}
	
	
	@Override
	public List<UserName> getUserInfo(Long userRoleKey, Boolean isPrinciple, Boolean isUserkey) {
		 List<UserName> userList = new ArrayList<>();
		 UserName userName = new UserName();
		Long userKey = userManagementDao.getUserKeyFromUserRoleKey(userRoleKey);
		 if(isUserkey){
			 return userManagementDao.getUserInfoByUserKey(userRoleKey);
		} else {
			if (isPrinciple) {
				BfsdUser bfsduser = userManagementDao.getUserType(userKey);
				if (bfsduser != null) {
					userName.setUserType(bfsduser.getUsertype().shortValue());
		 }
					userList.add(userName);
					return userList;
			}else {
				return userManagementDao.getUserInfo(userRoleKey);
			 }
		 }
	}
	
	 private void createEventMessage(String eventName,BfsdUser bfsdUser) {
		 try { 
			logger.debug(CLASS_NAME,BFLLoggerComponent.SERVICE, "Message generating for event  " + eventName);
			BfsdUserDetails request = new BfsdUserDetails();
			request.setUserkey(bfsdUser.getUserkey());
			request.setIsactive(bfsdUser.getIsactive());
			request.setFailedlogincount(null != bfsdUser.getFailedlogincount() ? bfsdUser.getFailedlogincount() : null);
			request.setLstfailedlogindt(null != bfsdUser.getLstfailedlogindt() ? bfsdUser.getLstfailedlogindt() : null);
			request.setLstupdateby(null != bfsdUser.getLstupdateby() ? bfsdUser.getLstupdateby() : null);
			request.setLstupdatedt(null != bfsdUser.getLstupdatedt() ? bfsdUser.getLstupdatedt() : null);
			request.setUsertype(null != bfsdUser.getUsertype() ? bfsdUser.getUsertype() : null);
			request.setUserblockedflg(null != bfsdUser.getUserblockedflg() ? bfsdUser.getUserblockedflg() : null);
			request.setRegistrationdate(null != bfsdUser.getRegistrationdate() ? bfsdUser.getRegistrationdate() : null);
			//request.setParentUserKey(null != String.valueOf(bfsdUser.getBfsdUser().getUserkey()) ? bfsdUser.getBfsdUser().getUserkey() :0 );
			request.setStatuschngreason(null != bfsdUser.getStatuschngreason() ? bfsdUser.getStatuschngreason(): null);
			List<BfsdUserProfileBean> userProfileDetailsList= new ArrayList<BfsdUserProfileBean>();
			List<UserProfile> bfsdList = bfsdUser.getUserProfiles();
			BfsdUserProfileBean profileBean = new BfsdUserProfileBean(); 
			bfsdList.forEach(userProfileItem->{
				profileBean.setAddress(userProfileItem.getAddress());
				profileBean.setAssociationdt(userProfileItem.getAssociationdt());
				profileBean.setAssociationid(userProfileItem.getAssociationid());
				profileBean.setAssociationtype(userProfileItem.getAssociationtype());
				profileBean.setCity(userProfileItem.getCity());
				profileBean.setCompanyname(userProfileItem.getCompanyname());
				profileBean.setContactpersonname(userProfileItem.getContactpersonname());
				profileBean.setDateofbirth(userProfileItem.getDateofbirth());
				profileBean.setDesignation(userProfileItem.getDesignation());
				profileBean.setEmailid(userProfileItem.getEmailid());
				profileBean.setFirstname(userProfileItem.getFirstname());
				profileBean.setGenderkey(userProfileItem.getGenderkey());
				profileBean.setGst(userProfileItem.getGst());
				profileBean.setIsactive(userProfileItem.getIsactive());
				profileBean.setLandline(userProfileItem.getLandline());
				profileBean.setLastname(userProfileItem.getLastname());
				profileBean.setLstupdateby(userProfileItem.getLstupdateby());
				profileBean.setLstupdatedt(userProfileItem.getLstupdatedt());
				profileBean.setMaritalstatuskey(userProfileItem.getMaritalstatuskey());
				profileBean.setMiddlename(userProfileItem.getMiddlename());
				profileBean.setMobileno(userProfileItem.getMobileno());
				profileBean.setPan(userProfileItem.getPan());
				//profileBean.setParentCompany(userPuserProfileItemrof.getParentCompany().getCompanyname());
				profileBean.setParentuseremailid(userProfileItem.getParentuseremailid());
				profileBean.setPartnerkey(userProfileItem.getPartnerkey());
				profileBean.setPan(userProfileItem.getPincode());
				profileBean.setSalutationkey(userProfileItem.getSalutationkey());
				profileBean.setServicekey(userProfileItem.getServicekey());
				profileBean.setUserprofilekey(userProfileItem.getUserprofilekey());
				profileBean.setUserkey(userProfileItem.getBfsdUser().getUserkey());
				userProfileDetailsList.add(profileBean);
			});
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "UserProfile:" + userProfileDetailsList.get(0) +"\nuserPRofileList:"+ bfsdList);
			request.setUserProfiles(userProfileDetailsList);
			EventMessage eventMessage = userManagementHelper.createEventMessage(eventName,request,headers);
			ObjectMapper mapper= new ObjectMapper();
	    	String messageStr = mapper.writeValueAsString(eventMessage);
			senderService.sendToSQS(messageStr); 
			logger.debug(CLASS_NAME,BFLLoggerComponent.SERVICE, "Message send for user replica - " + eventMessage); 
		 }// As this should not impact the flow, used main EXCEPTION class here. 
		 catch(Exception e) { 
			 logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					 "Some techical error occured while sending EVENT MESSAGE ", e); 
			 } 
	}

	 @Override
	public List<UserRoleBean> getUserInfoByEmail(String userEmail) {
		return userManagementDao.getUserInfoByEmail(userEmail);
	}

	 @Override
		public BfsdRoleMasterResponse getRoleMasterByRoleKey(String roleKey) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Start findByRolekey with role key:" + roleKey);
			BfsdRoleMaster bfsdRoleMaster = null;
			BfsdRoleMasterResponse bfsdRoleMasterResponse = null;
			try {
				bfsdRoleMaster = bfsdRoleMasterRepository.findByRolekeyAndIsactive(Long.valueOf(roleKey),BigDecimal.valueOf(1));
				if (bfsdRoleMaster != null) {
					bfsdRoleMasterResponse = new BfsdRoleMasterResponse();
					bfsdRoleMasterResponse.setIsActive(bfsdRoleMaster.getIsactive());
					bfsdRoleMasterResponse.setRoleCode(bfsdRoleMaster.getRolecd());
					bfsdRoleMasterResponse.setRoleKey(bfsdRoleMaster.getRolekey());
					bfsdRoleMasterResponse.setRoleName(bfsdRoleMaster.getRolename());
					if (!bfsdRoleMaster.getBfsdFunctionRoles().isEmpty()) {
						bfsdRoleMasterResponse.setFunctionCode(
								bfsdRoleMaster.getBfsdFunctionRoles().get(0).getBfsdFunction().getFunctioncd());
						bfsdRoleMasterResponse.setFunctionDesc(
								bfsdRoleMaster.getBfsdFunctionRoles().get(0).getBfsdFunction().getFunctiondesc());
					}
				}
			}catch (Exception ex) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"getRoleMasterByRoleKey - Error while fetching role master details for roleKey " + roleKey + " - ex- " + ex);
				throw new BFLTechnicalException("UMS-006", env.getProperty("UMS-006"));

			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Exit fetchRole with roles : " + bfsdRoleMasterResponse);
			return  bfsdRoleMasterResponse;
		}

		@Override
		public List<UserProfileDetails> getUserProfilesByRoleKeys(List<Long> roleKeyList) {
			return userManagementDao.getUserProfilesByRoleKeys(roleKeyList);
		}
		
		@Override
		public List<ReportingManager> getAllReportingManagers(String searchcriteria) {
			logger.debug(CLASS_NAME,BFLLoggerComponent.SERVICE, "Inside UserManagementServiceImpl's getAllReportingManagers method with searchcriteria : " + searchcriteria);
			return userManagementDao.getAllReportingManagers(searchcriteria);
		}
		
		@Override
		public List<UserRoleBean> getUserInfoByAdId(String useradId) {
			return userManagementDao.getUserInfoByAdId(useradId);
		}

		@Override
		public UserRoleBean getUserNameBeanByUserRoleKey(long userRoleKey) {
			return userManagementDao.getUserNameBeanByUserRoleKey(userRoleKey);
		}


}
