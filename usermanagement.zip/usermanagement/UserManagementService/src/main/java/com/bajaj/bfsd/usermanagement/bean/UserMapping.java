package com.bajaj.bfsd.usermanagement.bean;

public class UserMapping {

	private long userKey;
	private long roleKey;
	private String roleName;
	private long userRoleProdKey;
	private String roleCode;
	private long lnProdKey;
	private String lnProdCode;
	private String lnProdDesc;
	private Long l1ProdCode;

	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}

	public long getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(long roleKey) {
		this.roleKey = roleKey;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public long getUserRoleProdKey() {
		return userRoleProdKey;
	}

	public void setUserRoleProdKey(long userRoleProdKey) {
		this.userRoleProdKey = userRoleProdKey;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public long getLnProdKey() {
		return lnProdKey;
	}

	public void setLnProdKey(long lnProdKey) {
		this.lnProdKey = lnProdKey;
	}

	public String getLnProdCode() {
		return lnProdCode;
	}

	public void setLnProdCode(String lnProdCode) {
		this.lnProdCode = lnProdCode;
	}

	public String getLnProdDesc() {
		return lnProdDesc;
	}

	public void setLnProdDesc(String lnProdDesc) {
		this.lnProdDesc = lnProdDesc;
	}

	public Long getL1ProdCode() {
		return l1ProdCode;
	}

	public void setL1ProdCode(Long l1ProdCode) {
		this.l1ProdCode = l1ProdCode;
	}
	

}
