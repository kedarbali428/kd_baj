package com.bajaj.bfsd.usermanagement.bean;

public class RoleMasterBean {

	private Long roleKey;
	private String roleCode;
	private String roleName;
	private Long parentRole;
	private Long activeFlag;
	private Long sysRoleFlag;
	public Long getRoleKey() {
		return roleKey;
	}
	public void setRoleKey(Long roleKey) {
		this.roleKey = roleKey;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public Long getParentRole() {
		return parentRole;
	}
	public void setParentRole(Long parentRole) {
		this.parentRole = parentRole;
	}
	public Long getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(Long activeFlag) {
		this.activeFlag = activeFlag;
	}
	public Long getSysRoleFlag() {
		return sysRoleFlag;
	}
	public void setSysRoleFlag(Long sysRoleFlag) {
		this.sysRoleFlag = sysRoleFlag;
	}
	
	
	
}
