package com.bajaj.bfsd.usermanagement.bean;

import java.util.List;

public class EmployeeRoleDetails {
	private Long prodMastKey;
	private Long prodCatKey;
	private String firstName;
	private String lastName;
	private String phone;
	private String emailId;
	private String creditLimit;
	private List<ProductBean> loanproduct;
	private String supervisorKey;
	private List<String> location;
	private List<String> channelType;
	private List<Long> cityPin;
	private List<String> subProdTypeKey;
	private Long functionKey;
	private boolean highestRole;
	private String rolecd;
	private boolean highestRoleForUser;

	public boolean isHighestRole() {
		return highestRole;
	}

	public void setHighestRole(boolean highestRole) {
		this.highestRole = highestRole;
	}

	public Long getFunctionKey() {
		return functionKey;
	}

	public void setFunctionKey(Long functionKey) {
		this.functionKey = functionKey;
	}

	public Long getProdCatKey() {
		return prodCatKey;
	}

	public void setProdCatKey(Long prodCatKey) {
		this.prodCatKey = prodCatKey;
	}

	public Long getProdMastKey() {
		return prodMastKey;
	}

	public void setProdMastKey(Long prodMastKey) {
		this.prodMastKey = prodMastKey;
	}

	public List<ProductBean> getLoanproduct() {
		return loanproduct;
	}

	public void setLoanproduct(List<ProductBean> loanproduct) {
		this.loanproduct = loanproduct;
	}

	public List<String> getChannelType() {
		return channelType;
	}

	public void setChannelType(List<String> channelType) {
		this.channelType = channelType;
	}

	public String getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(String creditLimit) {
		this.creditLimit = creditLimit;
	}

	public String getSupervisorKey() {
		return supervisorKey;
	}

	public void setSupervisorKey(String supervisorKey) {
		this.supervisorKey = supervisorKey;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	private String designation;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public List<Long> getCityPin() {
		return cityPin;
	}

	public void setCityPin(List<Long> cityPin) {
		this.cityPin = cityPin;
	}

	public List<String> getLocation() {
		return location;
	}

	public void setLocation(List<String> location) {
		this.location = location;
	}

	public List<String> getSubProdTypeKey() {
		return subProdTypeKey;
	}

	public void setSubProdTypeKey(List<String> subProdTypeKey) {
		this.subProdTypeKey = subProdTypeKey;
	}

	public String getRolecd() {
		return rolecd;
	}

	public void setRolecd(String rolecd) {
		this.rolecd = rolecd;
	}

	public boolean isHighestRoleForUser() {
		return highestRoleForUser;
	}

	public void setHighestRoleForUser(boolean highestRoleForUser) {
		this.highestRoleForUser = highestRoleForUser;
	}

}
