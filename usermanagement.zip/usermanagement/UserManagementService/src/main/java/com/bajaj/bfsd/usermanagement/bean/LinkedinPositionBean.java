package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LinkedinPositionBean implements Serializable{
	
	private static final long serialVersionUID = 3203873979299840862L;

	private long positionId;
	
	@JsonProperty("designation")
	private String title;
	
	private String summary;
	
	private Date startDate;
	
	private Date endDate;
	
	private boolean current;
	
	private long companyId;
	
	private long employmentStatusCode;
	
	@JsonProperty("employerName")
	private String companyName;
	@JsonProperty("companyType")
	private String companyType;
	
	private String companyTicker;
	
	private String industryCode;
	
	private String industryDesc;

	public long getPositionId() {
		return positionId;
	}

	public void setPositionId(long positionId) {
		this.positionId = positionId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public boolean isCurrent() {
		return current;
	}

	public void setCurrent(boolean current) {
		this.current = current;
	}

	public long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public String getCompanyTicker() {
		return companyTicker;
	}

	public void setCompanyTicker(String companyTicker) {
		this.companyTicker = companyTicker;
	}

	public String getIndustryCode() {
		return industryCode;
	}

	public void setIndustryCode(String industryCode) {
		this.industryCode = industryCode;
	}

	public String getIndustryDesc() {
		return industryDesc;
	}

	public void setIndustryDesc(String industryDesc) {
		this.industryDesc = industryDesc;
	}

	public long getEmploymentStatusCode() {
		return employmentStatusCode;
	}

	public void setEmploymentStatusCode(long employmentStatusCode) {
		this.employmentStatusCode = employmentStatusCode;
	}
	
}
