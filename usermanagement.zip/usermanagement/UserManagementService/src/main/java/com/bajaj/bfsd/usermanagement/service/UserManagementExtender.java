package com.bajaj.bfsd.usermanagement.service;

public abstract class UserManagementExtender implements UserMgmtIntegration {
	
	UserMgmtIntegration coreCapabilityUserManagement;
	
	public UserManagementExtender(UserMgmtIntegration userMangementInterface){
		coreCapabilityUserManagement=userMangementInterface;
	}
}
