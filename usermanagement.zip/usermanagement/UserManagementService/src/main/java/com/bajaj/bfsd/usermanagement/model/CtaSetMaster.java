package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the CTA_SET_MASTER database table.
 * 
 */
@Entity
@Table(name="CTA_SET_MASTER")
//@NamedQuery(name="CtaSetMaster.findAll", query="SELECT c FROM CtaSetMaster c")
public class CtaSetMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long ctasetkey;

	private BigDecimal ctasetcd;

	private String ctasetname;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to CtaType
	@OneToMany(mappedBy="ctaSetMaster")
	private List<CtaType> ctaTypes;

	public long getCtasetkey() {
		return this.ctasetkey;
	}

	public void setCtasetkey(long ctasetkey) {
		this.ctasetkey = ctasetkey;
	}

	public BigDecimal getCtasetcd() {
		return this.ctasetcd;
	}

	public void setCtasetcd(BigDecimal ctasetcd) {
		this.ctasetcd = ctasetcd;
	}

	public String getCtasetname() {
		return this.ctasetname;
	}

	public void setCtasetname(String ctasetname) {
		this.ctasetname = ctasetname;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public List<CtaType> getCtaTypes() {
		return this.ctaTypes;
	}

	public void setCtaTypes(List<CtaType> ctaTypes) {
		this.ctaTypes = ctaTypes;
	}

	public CtaType addCtaType(CtaType ctaType) {
		getCtaTypes().add(ctaType);
		ctaType.setCtaSetMaster(this);

		return ctaType;
	}

	public CtaType removeCtaType(CtaType ctaType) {
		getCtaTypes().remove(ctaType);
		ctaType.setCtaSetMaster(null);

		return ctaType;
	}

}