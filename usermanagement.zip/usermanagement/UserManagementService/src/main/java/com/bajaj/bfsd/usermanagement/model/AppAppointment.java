package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the APP_APPOINTMENT database table.
 * 
 */
@Entity
@Table(name="APP_APPOINTMENT")
//@NamedQuery(name="AppAppointment.findAll", query="SELECT a FROM AppAppointment a")
public class AppAppointment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long appointmentkey;

	private BigDecimal autoallocateflg;

	private BigDecimal checkinlat;

	private BigDecimal checkinlong;

	private BigDecimal consentflg;

	private BigDecimal isactive;

	private BigDecimal kitstatus;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to AppSchedule
	@ManyToOne
	@JoinColumn(name="SCHEDULEKEY")
	private AppSchedule appSchedule;

	//bi-directional many-to-one association to AppUserAssignment
	@ManyToOne
	@JoinColumn(name="ASSIGNMENTKEY")
	private AppUserAssignment appUserAssignment;

	public long getAppointmentkey() {
		return this.appointmentkey;
	}

	public void setAppointmentkey(long appointmentkey) {
		this.appointmentkey = appointmentkey;
	}

	public BigDecimal getAutoallocateflg() {
		return this.autoallocateflg;
	}

	public void setAutoallocateflg(BigDecimal autoallocateflg) {
		this.autoallocateflg = autoallocateflg;
	}

	public BigDecimal getCheckinlat() {
		return this.checkinlat;
	}

	public void setCheckinlat(BigDecimal checkinlat) {
		this.checkinlat = checkinlat;
	}

	public BigDecimal getCheckinlong() {
		return this.checkinlong;
	}

	public void setCheckinlong(BigDecimal checkinlong) {
		this.checkinlong = checkinlong;
	}

	public BigDecimal getConsentflg() {
		return this.consentflg;
	}

	public void setConsentflg(BigDecimal consentflg) {
		this.consentflg = consentflg;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public BigDecimal getKitstatus() {
		return this.kitstatus;
	}

	public void setKitstatus(BigDecimal kitstatus) {
		this.kitstatus = kitstatus;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public AppSchedule getAppSchedule() {
		return this.appSchedule;
	}

	public void setAppSchedule(AppSchedule appSchedule) {
		this.appSchedule = appSchedule;
	}

	public AppUserAssignment getAppUserAssignment() {
		return this.appUserAssignment;
	}

	public void setAppUserAssignment(AppUserAssignment appUserAssignment) {
		this.appUserAssignment = appUserAssignment;
	}

}