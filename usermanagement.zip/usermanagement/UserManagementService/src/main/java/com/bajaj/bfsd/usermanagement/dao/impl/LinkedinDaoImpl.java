package com.bajaj.bfsd.usermanagement.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLRepository;
import com.bajaj.bfsd.usermanagement.bean.LinkedinPositionBean;
import com.bajaj.bfsd.usermanagement.bean.LinkedinProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserEmail;
import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;
import com.bajaj.bfsd.usermanagement.dao.UserProfileDao;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserSocPrfLnkdinPosition;
import com.bajaj.bfsd.usermanagement.model.UserSocialProfileLinkedin;
import com.bajaj.bfsd.usermanagement.util.UserManagementUtility;
import com.bfl.common.exceptions.BFLBusinessException;

@Repository("linkedin")
public class LinkedinDaoImpl extends BFLRepository implements UserProfileDao{
	
	private static final String THIS_CLASS = LinkedinDaoImpl.class.getName();
	
	@Autowired
	EntityManager entityManager;
	
	@Autowired
	private Environment env;
	
	@Autowired
    private BFLLoggerUtil logger;
	@Override
	public void saveProfile(UserProfileBean profileBean, long userKey, String profileResponse) {
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfile - Linkedin - started");
		
		Timestamp timestamp = UserManagementUtility.getCurrentTimeStamp();

		LinkedinProfileBean linkedinProfile = (LinkedinProfileBean)profileBean;
		
		Query query = entityManager
					.createNativeQuery("delete from USER_SOCIAL_PROFILE_LINKEDIN where userkey = :userKey");
		
		query.setParameter("userKey", userKey);
		query.executeUpdate();
		
		UserSocialProfileLinkedin linkedinEntity = new UserSocialProfileLinkedin();
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(userKey);
		
		linkedinEntity.setBfsdUser(bfsdUser);
		linkedinEntity.setFirstname(linkedinProfile.getFirstName());
		linkedinEntity.setLastname(linkedinProfile.getLastName());
		linkedinEntity.setFormattedname(linkedinProfile.getFormattedName());
		linkedinEntity.setFormattedphoneticname(linkedinProfile.getPhoneticFormattedname());
		linkedinEntity.setHeadline(linkedinProfile.getHeadline());
		linkedinEntity.setIndustrycode(linkedinProfile.getIndustryCode());
		linkedinEntity.setLocationcode(linkedinProfile.getConuntryCode());
		linkedinEntity.setLocationname(linkedinProfile.getLocationName());
		linkedinEntity.setLstupdateby(String.valueOf(userKey));
		linkedinEntity.setLstupdatedt(timestamp);
		linkedinEntity.setMiddlename(linkedinProfile.getMiddleName());
		linkedinEntity.setNoofconnections(linkedinProfile.getNoOfConn());
		linkedinEntity.setPhoneticfname(linkedinProfile.getPhoneticFname());
		linkedinEntity.setPhoneticlname(linkedinProfile.getPhoneticLname());
		linkedinEntity.setPictureurl(linkedinProfile.getPictureUrl());
		linkedinEntity.setPrimaryemailid(linkedinProfile.getPrimaryEmail());
		linkedinEntity.setSecondaryemailid(linkedinProfile.getSecondaryEmail());
		linkedinEntity.setSpecialties(linkedinProfile.getSpeacialities());
		linkedinEntity.setResponsedoc(profileResponse);
		linkedinEntity.setProfilesummary(linkedinProfile.getProfileSummary());
		linkedinEntity.setPublicprofileurl(linkedinProfile.getPublicProfileUrl());
		linkedinEntity.setProfileid(linkedinProfile.getProfileId());
	
		linkedinEntity = entityManager.merge(linkedinEntity);
		
		UserSocPrfLnkdinPosition positionEntity;
		
		for(LinkedinPositionBean position : linkedinProfile.getPositions()){
			positionEntity= new UserSocPrfLnkdinPosition();
			positionEntity.setCompanyid(position.getCompanyId());
			positionEntity.setCompindustrycode(position.getIndustryCode());
			positionEntity.setCompindustrydesc(position.getIndustryDesc());
			positionEntity.setCompname(position.getCompanyName());
			positionEntity.setCompticker(position.getCompanyTicker());
			positionEntity.setComptype(position.getCompanyType());
			positionEntity.setStartdt(position.getStartDate());
			positionEntity.setEnddt(position.getEndDate());
			positionEntity.setTitle(position.getTitle());
			positionEntity.setIscurrent(position.isCurrent() ? (byte)1 : 0);
			positionEntity.setPositionid(position.getPositionId());
			positionEntity.setSummary(position.getSummary());
			positionEntity.setUserSocialProfileLinkedin(linkedinEntity);
			
			entityManager.merge(positionEntity);
		}
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfile - Linkedin - completed");
	}
	@Override
	public UserProfileBean getUserProfile(long userKey) {
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "getUserProfile - Linkedin - started");
		
		LinkedinProfileBean linkedinProfile;
		LinkedinPositionBean linkedinPosition;
		UserSocialProfileLinkedin linkedinEntity;
		List<UserSocPrfLnkdinPosition> positionEntities;
		List<LinkedinPositionBean> linkedinPositions = new ArrayList<>(1);
		UserSocPrfLnkdinPosition positionEntity;
		
		Query query = entityManager
					.createQuery("from UserSocialProfileLinkedin where bfsdUser.userkey = :userKey");
		
		query.setParameter("userKey", userKey);
		
		try {
			linkedinEntity = (UserSocialProfileLinkedin) query.getSingleResult();
		}
		catch (NoResultException ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "getUserProfile - Linkedin - No record found for the user - "+userKey+
						"\n Exception - "+ex);
			return new LinkedinProfileBean();
		}
		catch (NonUniqueResultException ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "getUserProfile - Linkedin - Multiple records found for the user - "+userKey+
						"\n Exception - "+ex);
			throw new BFLBusinessException("UMS-013", env.getProperty("UMS-013"));
		}
		
		
		positionEntities = linkedinEntity.getUserSocPrfLnkdinPositions();
		if(null!=positionEntities && !positionEntities.isEmpty()){
			positionEntity = positionEntities.get(0);
			
			linkedinPosition = new LinkedinPositionBean();
			linkedinPosition.setCompanyId(positionEntity.getCompanyid());
			linkedinPosition.setCompanyName(positionEntity.getCompname());
			linkedinPosition.setCompanyTicker(positionEntity.getCompticker());
			linkedinPosition.setCompanyType(positionEntity.getComptype());
			linkedinPosition.setCurrent(true);
			linkedinPosition.setEmploymentStatusCode(1);
			linkedinPosition.setEndDate(positionEntity.getEnddt());
			linkedinPosition.setStartDate(positionEntity.getStartdt());
			linkedinPosition.setIndustryCode(positionEntity.getCompindustrycode());
			linkedinPosition.setIndustryDesc(positionEntity.getCompindustrydesc());
			linkedinPosition.setPositionId(positionEntity.getPositionid());
			linkedinPosition.setSummary(positionEntity.getSummary());
			linkedinPosition.setTitle(positionEntity.getTitle());
			
			linkedinPositions.add(linkedinPosition);
		}
		
		linkedinProfile = new LinkedinProfileBean();
		
		linkedinProfile.setFirstName(linkedinEntity.getFirstname());
		linkedinProfile.setMiddleName(linkedinEntity.getMiddlename());
		linkedinProfile.setLastName(linkedinEntity.getLastname());
		linkedinProfile.setPrimaryEmail(linkedinEntity.getPrimaryemailid());
		linkedinProfile.setFormattedName(linkedinEntity.getFormattedname());
		linkedinProfile.setHeadline(linkedinEntity.getHeadline());
		linkedinProfile.setConuntryCode(linkedinEntity.getLocationcode());
		linkedinProfile.setIndustryCode(linkedinEntity.getIndustrycode());
		linkedinProfile.setLocationName(linkedinEntity.getLocationname());
		linkedinProfile.setNoOfConn(linkedinEntity.getNoofconnections());
		linkedinProfile.setPhoneticFname(linkedinEntity.getPhoneticfname());
		linkedinProfile.setPhoneticFormattedname(linkedinEntity.getFormattedphoneticname());
		linkedinProfile.setPhoneticLname(linkedinEntity.getPhoneticlname());
		linkedinProfile.setPictureUrl(linkedinEntity.getPictureurl());
		linkedinProfile.setProfileId(linkedinEntity.getProfileid());
		linkedinProfile.setProfileSummary(linkedinEntity.getProfilesummary());
		linkedinProfile.setPublicProfileUrl(linkedinEntity.getPublicprofileurl());
		linkedinProfile.setSecondaryEmail(linkedinEntity.getSecondaryemailid());
		linkedinProfile.setSpeacialities(linkedinEntity.getSpecialties());
		linkedinProfile.setProfileJson(linkedinEntity.getResponsedoc());
		
		List<UserEmail> userEmails = new ArrayList<>(1);
		UserEmail primaryEmail = new UserEmail();
		primaryEmail.setEmailAddress(linkedinProfile.getPrimaryEmail());
		primaryEmail.setType("PERSON1");
		userEmails.add(primaryEmail);
		
		linkedinProfile.setEmailDetails(userEmails);
		
		linkedinProfile.setPositions(linkedinPositions);

		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "getUserProfile - Linkedin - completed");
		
		return linkedinProfile;
	}

}
