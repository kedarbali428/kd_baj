package com.bajaj.bfsd.usermanagement.bean;

import org.springframework.stereotype.Component;

@Component
public class UserManagementResponse {

}
