package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the USER_ROLES database table.
 * 
 */
@Entity
@Table(name = "USER_ROLES")
@NamedQueries({
		@NamedQuery(name = "UserRoleL3.findByEmployeeAndRole", query = "SELECT u FROM UserRoleL3 u where u.isactive = 1 "
				+ "and u.bfsduser.userkey =:userKey " + "and u.bfsdRoleMaster.rolekey =:roleKey"),
		@NamedQuery(name = "UserRoleL3.DeactivateUserRole", query = "UPDATE UserRoleL3 u set u.isactive = 0 "
				+ "WHERE u.isactive = 1 " + "AND u.bfsduser.userkey =:userKey "
				+ "AND u.bfsdRoleMaster.rolekey =:roleKey"),
		@NamedQuery(name = "UserRoleL3.findById", query = "SELECT u FROM UserRoleL3 u where u.userrolekey =:userrolekey and u.isactive =1"),
//		@NamedQuery(name = "UserRoleL3.findAll", query = "SELECT u FROM UserRoleL3 u WHERE u.isactive=1") 
		})

public class UserRoleL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userrolekey;

	private BigDecimal creditlimit;

	private long isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private Long parentuser;

	@ManyToOne
	@JoinColumn(name = "ROLEKEY")
	private BfsdRoleMaster bfsdRoleMaster;

	@ManyToOne
	@JoinColumn(name = "USERKEY")
	private BfsdUser bfsduser;

	@OneToMany(mappedBy="userRole", cascade = {CascadeType.ALL},orphanRemoval = true)
	private List<UserRoleProductL3> userRoleProducts;
	
	public UserRoleL3() {
	}

	public Long getUserrolekey() {
		return this.userrolekey;
	}

	public void setUserrolekey(Long userrolekey) {
		this.userrolekey = userrolekey;
	}

	public BigDecimal getCreditlimit() {
		return this.creditlimit;
	}

	public void setCreditlimit(BigDecimal creditlimit) {
		this.creditlimit = creditlimit;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public long getIsactive() {
		return isactive;
	}

	public void setIsactive(long isactive) {
		this.isactive = isactive;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getParentuser() {
		return parentuser;
	}

	public void setParentuser(Long parentuser) {
		this.parentuser = parentuser;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

	public BfsdUser getBfsduser() {
		return bfsduser;
	}

	public void setBfsduser(BfsdUser bfsduser) {
		this.bfsduser = bfsduser;
	}

	public List<UserRoleProductL3> getUserRoleProducts() {
		return userRoleProducts;
	}

	public void setUserRoleProducts(List<UserRoleProductL3> userRoleProducts) {
		if(this.userRoleProducts==null)
		{
			this.userRoleProducts = userRoleProducts;
		}
		else
		{
			this.userRoleProducts.addAll(userRoleProducts);
		}
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bfsdRoleMaster == null) ? 0 : bfsdRoleMaster.hashCode());
		result = prime * result + ((bfsduser == null) ? 0 : bfsduser.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserRoleL3 other = (UserRoleL3) obj;
		if (bfsdRoleMaster == null) {
			if (other.bfsdRoleMaster != null)
				return false;
		} else if (!bfsdRoleMaster.equals(other.bfsdRoleMaster))
			return false;
		if (bfsduser == null) {
			if (other.bfsduser != null)
				return false;
		} else if (!bfsduser.equals(other.bfsduser))
			return false;
		return true;
	}

}