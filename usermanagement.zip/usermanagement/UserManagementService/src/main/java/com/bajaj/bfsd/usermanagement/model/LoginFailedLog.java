package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the LOGIN_FAILED_LOG database table.
 * 
 */
@Entity
@Table(name="LOGIN_FAILED_LOG")
//@NamedQuery(name="LoginFailedLog.findAll", query="SELECT l FROM LoginFailedLog l")
public class LoginFailedLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long loginfaillogkey;

	private Timestamp attemptdt;

	private String browser;

	private String deviceid;

	private String ipaddress;

	private BigDecimal latitude;

	private String loginid;

	private String loginpwd;

	private BigDecimal longitude;

	private BigDecimal reasoncode;

	private BigDecimal srcwebapp;

	public long getLoginfaillogkey() {
		return this.loginfaillogkey;
	}

	public void setLoginfaillogkey(long loginfaillogkey) {
		this.loginfaillogkey = loginfaillogkey;
	}

	public Timestamp getAttemptdt() {
		return this.attemptdt;
	}

	public void setAttemptdt(Timestamp attemptdt) {
		this.attemptdt = attemptdt;
	}

	public String getBrowser() {
		return this.browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getDeviceid() {
		return this.deviceid;
	}

	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	public String getIpaddress() {
		return this.ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public BigDecimal getLatitude() {
		return this.latitude;
	}

	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	public String getLoginid() {
		return this.loginid;
	}

	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}

	public String getLoginpwd() {
		return this.loginpwd;
	}

	public void setLoginpwd(String loginpwd) {
		this.loginpwd = loginpwd;
	}

	public BigDecimal getLongitude() {
		return this.longitude;
	}

	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	public BigDecimal getReasoncode() {
		return this.reasoncode;
	}

	public void setReasoncode(BigDecimal reasoncode) {
		this.reasoncode = reasoncode;
	}

	public BigDecimal getSrcwebapp() {
		return this.srcwebapp;
	}

	public void setSrcwebapp(BigDecimal srcwebapp) {
		this.srcwebapp = srcwebapp;
	}

}