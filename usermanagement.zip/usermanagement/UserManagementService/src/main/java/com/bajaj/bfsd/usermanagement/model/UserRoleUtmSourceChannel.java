package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the USER_ROLE_UTM_SOURCE_CHANNELS database table. 
 * 
 */
@Entity
@Table(name="USER_ROLE_UTM_SOURCE_CHANNELS")
//@NamedQuery(name="UserRoleUtmSourceChannel.findAll", query="SELECT u FROM UserRoleUtmSourceChannel u")
public class UserRoleUtmSourceChannel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userutmkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal utmsrcchnmastkey;

	//bi-directional many-to-one association to UserRoleProduct
	@ManyToOne
	@JoinColumn(name="USERPRODKEY")
	private UserRoleProductL3 userRoleProduct;

	public UserRoleUtmSourceChannel() {
	}

	public long getUserutmkey() {
		return this.userutmkey;
	}

	public void setUserutmkey(long userutmkey) {
		this.userutmkey = userutmkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getUtmsrcchnmastkey() {
		return this.utmsrcchnmastkey;
	}

	public void setUtmsrcchnmastkey(BigDecimal utmsrcchnmastkey) {
		this.utmsrcchnmastkey = utmsrcchnmastkey;
	}

	public UserRoleProductL3 getUserRoleProduct() {
		return userRoleProduct;
	}

	public void setUserRoleProduct(UserRoleProductL3 userRoleProduct) {
		this.userRoleProduct = userRoleProduct;
	}

	

}