package com.bajaj.openmarkets.usermanagement.bean;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class AuthorizationCodesRequest {

	@NotBlank(message = "client Id cannot be null or blank")
	private String clientId;

	@NotBlank(message = "authorizedClient cannot be null or blank")
	private String authorizedClient;
	
	@NotNull(message = "applicantKey cannot be null")
	private Long applicantKey;

	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getAuthorizedClient() {
		return authorizedClient;
	}
	public void setAuthorizedClient(String authorizedClient) {
		this.authorizedClient = authorizedClient;
	}
	public Long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}
	@Override
	public String toString() {
		return "AuthorizationCodesRequest [clientId=" + clientId + ", applicantKey="
				+ applicantKey + ", authorizedClient=" + authorizedClient + "]";
	}
	
}
