package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the VAS_PRODUCT_TYPES database table.
 * 
 */
@Entity
@Table(name="VAS_PRODUCT_TYPES")
//@NamedQuery(name="VasProductType.findAll", query="SELECT v FROM VasProductType v")
public class VasProductType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long vasprodtypekey;

	private BigDecimal vptisactive;

	private String vptlstupdateby;

	private Timestamp vptlstupdatedt;

	private String vptprodtypecode;

	private String vptprodtypedesc;

	//bi-directional many-to-one association to ProductCategory
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODCATKEY")
	private ProductCategory productCategory;

	public VasProductType() {
	}

	public long getVasprodtypekey() {
		return this.vasprodtypekey;
	}

	public void setVasprodtypekey(long vasprodtypekey) {
		this.vasprodtypekey = vasprodtypekey;
	}

	public BigDecimal getVptisactive() {
		return this.vptisactive;
	}

	public void setVptisactive(BigDecimal vptisactive) {
		this.vptisactive = vptisactive;
	}

	public String getVptlstupdateby() {
		return this.vptlstupdateby;
	}

	public void setVptlstupdateby(String vptlstupdateby) {
		this.vptlstupdateby = vptlstupdateby;
	}

	public Timestamp getVptlstupdatedt() {
		return this.vptlstupdatedt;
	}

	public void setVptlstupdatedt(Timestamp vptlstupdatedt) {
		this.vptlstupdatedt = vptlstupdatedt;
	}

	public String getVptprodtypecode() {
		return this.vptprodtypecode;
	}

	public void setVptprodtypecode(String vptprodtypecode) {
		this.vptprodtypecode = vptprodtypecode;
	}

	public String getVptprodtypedesc() {
		return this.vptprodtypedesc;
	}

	public void setVptprodtypedesc(String vptprodtypedesc) {
		this.vptprodtypedesc = vptprodtypedesc;
	}

	public ProductCategory getProductCategory() {
		return this.productCategory;
	}

	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}

}