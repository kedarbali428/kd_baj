package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the USER_PROFILE_AADHAAR database table.
 * 
 */
@Entity
@Table(name="USER_PROFILE_AADHAAR")
//@NamedQuery(name="UserProfileAadhaar.findAll", query="SELECT u FROM UserProfileAadhaar u")
public class UserProfileAadhaar implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long aadhaarkey;

	private String aadhaarnumber;

	@Temporal(TemporalType.DATE)
	private Date dateofbirth;

	private String firstname;

	private String lastname;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String middlename;

	@Lob
	private String responsedoc;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="USERKEY")
	private BfsdUser bfsdUser;

	//bi-directional many-to-one association to UserProfileAadhaarAddress
	@OneToMany(mappedBy="userProfileAadhaar")
	private List<UserProfileAadhaarAddress> userProfileAadhaarAddresses;

	//bi-directional many-to-one association to UserProfileAadhaarEmail
	@OneToMany(mappedBy="userProfileAadhaar")
	private List<UserProfileAadhaarEmail> userProfileAadhaarEmails;

	//bi-directional many-to-one association to UserProfileAadhaarPhone
	@OneToMany(mappedBy="userProfileAadhaar")
	private List<UserProfileAadhaarPhone> userProfileAadhaarPhones;

	public UserProfileAadhaar() {
	}

	public long getAadhaarkey() {
		return this.aadhaarkey;
	}

	public void setAadhaarkey(long aadhaarkey) {
		this.aadhaarkey = aadhaarkey;
	}

	public String getAadhaarnumber() {
		return this.aadhaarnumber;
	}

	public void setAadhaarnumber(String aadhaarnumber) {
		this.aadhaarnumber = aadhaarnumber;
	}

	public Date getDateofbirth() {
		return this.dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getMiddlename() {
		return this.middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getResponsedoc() {
		return this.responsedoc;
	}

	public void setResponsedoc(String responsedoc) {
		this.responsedoc = responsedoc;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

	public List<UserProfileAadhaarAddress> getUserProfileAadhaarAddresses() {
		return this.userProfileAadhaarAddresses;
	}

	public void setUserProfileAadhaarAddresses(List<UserProfileAadhaarAddress> userProfileAadhaarAddresses) {
		this.userProfileAadhaarAddresses = userProfileAadhaarAddresses;
	}

	public UserProfileAadhaarAddress addUserProfileAadhaarAddress(UserProfileAadhaarAddress userProfileAadhaarAddress) {
		getUserProfileAadhaarAddresses().add(userProfileAadhaarAddress);
		userProfileAadhaarAddress.setUserProfileAadhaar(this);

		return userProfileAadhaarAddress;
	}

	public UserProfileAadhaarAddress removeUserProfileAadhaarAddress(UserProfileAadhaarAddress userProfileAadhaarAddress) {
		getUserProfileAadhaarAddresses().remove(userProfileAadhaarAddress);
		userProfileAadhaarAddress.setUserProfileAadhaar(null);

		return userProfileAadhaarAddress;
	}

	public List<UserProfileAadhaarEmail> getUserProfileAadhaarEmails() {
		return this.userProfileAadhaarEmails;
	}

	public void setUserProfileAadhaarEmails(List<UserProfileAadhaarEmail> userProfileAadhaarEmails) {
		this.userProfileAadhaarEmails = userProfileAadhaarEmails;
	}

	public UserProfileAadhaarEmail addUserProfileAadhaarEmail(UserProfileAadhaarEmail userProfileAadhaarEmail) {
		getUserProfileAadhaarEmails().add(userProfileAadhaarEmail);
		userProfileAadhaarEmail.setUserProfileAadhaar(this);

		return userProfileAadhaarEmail;
	}

	public UserProfileAadhaarEmail removeUserProfileAadhaarEmail(UserProfileAadhaarEmail userProfileAadhaarEmail) {
		getUserProfileAadhaarEmails().remove(userProfileAadhaarEmail);
		userProfileAadhaarEmail.setUserProfileAadhaar(null);

		return userProfileAadhaarEmail;
	}

	public List<UserProfileAadhaarPhone> getUserProfileAadhaarPhones() {
		return this.userProfileAadhaarPhones;
	}

	public void setUserProfileAadhaarPhones(List<UserProfileAadhaarPhone> userProfileAadhaarPhones) {
		this.userProfileAadhaarPhones = userProfileAadhaarPhones;
	}

	public UserProfileAadhaarPhone addUserProfileAadhaarPhone(UserProfileAadhaarPhone userProfileAadhaarPhone) {
		getUserProfileAadhaarPhones().add(userProfileAadhaarPhone);
		userProfileAadhaarPhone.setUserProfileAadhaar(this);

		return userProfileAadhaarPhone;
	}

	public UserProfileAadhaarPhone removeUserProfileAadhaarPhone(UserProfileAadhaarPhone userProfileAadhaarPhone) {
		getUserProfileAadhaarPhones().remove(userProfileAadhaarPhone);
		userProfileAadhaarPhone.setUserProfileAadhaar(null);

		return userProfileAadhaarPhone;
	}

}