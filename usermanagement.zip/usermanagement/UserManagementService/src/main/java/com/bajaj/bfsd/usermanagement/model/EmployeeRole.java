package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the EMPLOYEE_ROLES database table.
 * 
 */
@Entity
@Table(name="EMPLOYEE_ROLES")
//@NamedQuery(name="EmployeeRole.findAll", query="SELECT e FROM EmployeeRole e")
public class EmployeeRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long emprolekey;

	private BigDecimal creditlimit;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;



	//bi-directional many-to-one association to BfsdEmployee
	@ManyToOne
	@JoinColumn(name="EMPSUPERVISOR")
	private BfsdEmployee bfsdEmployee1;

	//bi-directional many-to-one association to BfsdEmployee
	@ManyToOne
	@JoinColumn(name="EMPLOYEEKEY")
	private BfsdEmployee bfsdEmployee2;

	//bi-directional many-to-one association to BfsdRoleMaster
	@ManyToOne
	@JoinColumn(name="ROLEKEY")
	private BfsdRoleMaster bfsdRoleMaster;

	//bi-directional many-to-one association to EmpNotification
	@OneToMany(mappedBy="employeeRole")
	private List<EmpNotification> empNotifications;

	//bi-directional many-to-one association to EmpRoleChannel
	@OneToMany(mappedBy="employeeRole")
	private List<EmpRoleChannel> empRoleChannels;

	//bi-directional many-to-one association to EmpRoleLoanType
	@OneToMany(mappedBy="employeeRole")
	private List<EmpRoleLoanType> empRoleLoanTypes;

	//bi-directional many-to-one association to EmpRoleLocation
	@OneToMany(mappedBy="employeeRole")
	private List<EmpRoleLocation> empRoleLocations;

	//bi-directional many-to-one association to EmpRolePinCode
	@OneToMany(mappedBy="employeeRole")
	private List<EmpRolePinCode> empRolePinCodes;

	public long getEmprolekey() {
		return this.emprolekey;
	}

	public void setEmprolekey(long emprolekey) {
		this.emprolekey = emprolekey;
	}

	public BigDecimal getCreditlimit() {
		return this.creditlimit;
	}

	public void setCreditlimit(BigDecimal creditlimit) {
		this.creditlimit = creditlimit;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	

	public BfsdEmployee getBfsdEmployee1() {
		return this.bfsdEmployee1;
	}

	public void setBfsdEmployee1(BfsdEmployee bfsdEmployee1) {
		this.bfsdEmployee1 = bfsdEmployee1;
	}

	public BfsdEmployee getBfsdEmployee2() {
		return this.bfsdEmployee2;
	}

	public void setBfsdEmployee2(BfsdEmployee bfsdEmployee2) {
		this.bfsdEmployee2 = bfsdEmployee2;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return this.bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

	public List<EmpNotification> getEmpNotifications() {
		return this.empNotifications;
	}

	public void setEmpNotifications(List<EmpNotification> empNotifications) {
		this.empNotifications = empNotifications;
	}

	public EmpNotification addEmpNotification(EmpNotification empNotification) {
		getEmpNotifications().add(empNotification);
		empNotification.setEmployeeRole(this);

		return empNotification;
	}

	public EmpNotification removeEmpNotification(EmpNotification empNotification) {
		getEmpNotifications().remove(empNotification);
		empNotification.setEmployeeRole(null);

		return empNotification;
	}

	public List<EmpRoleChannel> getEmpRoleChannels() {
		return this.empRoleChannels;
	}

	public void setEmpRoleChannels(List<EmpRoleChannel> empRoleChannels) {
		this.empRoleChannels = empRoleChannels;
	}

	public EmpRoleChannel addEmpRoleChannel(EmpRoleChannel empRoleChannel) {
		getEmpRoleChannels().add(empRoleChannel);
		empRoleChannel.setEmployeeRole(this);

		return empRoleChannel;
	}

	public EmpRoleChannel removeEmpRoleChannel(EmpRoleChannel empRoleChannel) {
		getEmpRoleChannels().remove(empRoleChannel);
		empRoleChannel.setEmployeeRole(null);

		return empRoleChannel;
	}

	public List<EmpRoleLoanType> getEmpRoleLoanTypes() {
		return this.empRoleLoanTypes;
	}

	public void setEmpRoleLoanTypes(List<EmpRoleLoanType> empRoleLoanTypes) {
		this.empRoleLoanTypes = empRoleLoanTypes;
	}

	public EmpRoleLoanType addEmpRoleLoanType(EmpRoleLoanType empRoleLoanType) {
		getEmpRoleLoanTypes().add(empRoleLoanType);
		empRoleLoanType.setEmployeeRole(this);

		return empRoleLoanType;
	}

	public EmpRoleLoanType removeEmpRoleLoanType(EmpRoleLoanType empRoleLoanType) {
		getEmpRoleLoanTypes().remove(empRoleLoanType);
		empRoleLoanType.setEmployeeRole(null);

		return empRoleLoanType;
	}

	public List<EmpRoleLocation> getEmpRoleLocations() {
		return this.empRoleLocations;
	}

	public void setEmpRoleLocations(List<EmpRoleLocation> empRoleLocations) {
		this.empRoleLocations = empRoleLocations;
	}

	public EmpRoleLocation addEmpRoleLocation(EmpRoleLocation empRoleLocation) {
		getEmpRoleLocations().add(empRoleLocation);
		empRoleLocation.setEmployeeRole(this);

		return empRoleLocation;
	}

	public EmpRoleLocation removeEmpRoleLocation(EmpRoleLocation empRoleLocation) {
		getEmpRoleLocations().remove(empRoleLocation);
		empRoleLocation.setEmployeeRole(null);

		return empRoleLocation;
	}

	public List<EmpRolePinCode> getEmpRolePinCodes() {
		return this.empRolePinCodes;
	}

	public void setEmpRolePinCodes(List<EmpRolePinCode> empRolePinCodes) {
		this.empRolePinCodes = empRolePinCodes;
	}

	public EmpRolePinCode addEmpRolePinCode(EmpRolePinCode empRolePinCode) {
		getEmpRolePinCodes().add(empRolePinCode);
		empRolePinCode.setEmployeeRole(this);

		return empRolePinCode;
	}

	public EmpRolePinCode removeEmpRolePinCode(EmpRolePinCode empRolePinCode) {
		getEmpRolePinCodes().remove(empRolePinCode);
		empRolePinCode.setEmployeeRole(null);

		return empRolePinCode;
	}

}