package com.bajaj.bfsd.usermanagement.beanmapper;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.usermanagement.bean.UserMappingDeleteResponseBean;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;

@Component
public class BeanMapper extends BFLComponent{

	public UserMappingDeleteResponseBean mapTo(long userKey,long roleKey, boolean isActiveFlag){
		UserMappingDeleteResponseBean bean = new UserMappingDeleteResponseBean();
		bean.setActive(isActiveFlag);
		bean.setRoleKey(roleKey);
		bean.setUserKey(userKey);
		return bean;
	}
	
	public List<UserName> mapToBean(List<Object[]> list) {
		
		List<UserName> userNameList = new ArrayList<>();
		
		for (Object[] obj : list) {
			String name = "";
			UserName userName = new UserName();
			if (obj[0] != null)
				name = name + obj[0] + " ";
			if (obj[1] != null)
				name = name + obj[1] + " ";
			if (obj[2] != null)
				name = name + obj[2];
			if (obj[3] != null) {
				userName.setUserKey(((BigDecimal) obj[3]).longValue());
			}
			if (obj[4] != null) {
				userName.setRoleKey(((BigDecimal) obj[4]).longValue());
			}

			if (obj[5] != null) {
				userName.setUserRoleKey(((BigDecimal) obj[5]).longValue());
			}

			userName.setUserName(name);

			userNameList.add(userName);
		}
		return userNameList;
	}
	
	
	/**
	 * @param list
	 * @return
	 */
	public UserLoginAccount mapToUserLoginAccountBean(List<Object[]> list) {
		UserLoginAccount userLoginAccount = new UserLoginAccount();
		BfsdUser bfsdUser = new BfsdUser();
		for (Object[] obj : list) {
			if (obj[0] != null) {
				userLoginAccount.setLoginpwd(obj[0].toString());
			}
			if (obj[1] != null) {
				bfsdUser.setUserkey(Long.valueOf(obj[1].toString()));
			}
			if (obj[2] != null) {
				bfsdUser.setRegistrationdate(Timestamp.valueOf(obj[2].toString()));
			}
			if (obj[3] != null) {
				bfsdUser.setUsertype(new BigDecimal(obj[3].toString()));
			}
			if (obj[4] != null) {
				bfsdUser.setUserblockedflg(new BigDecimal(obj[4].toString()));
			}
			if (obj[5] != null) {
				bfsdUser.setFailedlogincount(new BigDecimal(obj[5].toString()));
			}
			if (obj[6] != null) {
				bfsdUser.setLstfailedlogindt(Timestamp.valueOf(obj[6].toString()));
			}
			if (obj[7] != null) {
				bfsdUser.setIsactive(new BigDecimal(obj[7].toString()));
			}
			if (obj[8] != null) {
				bfsdUser.setLstupdateby(obj[8].toString());
			}
			if (obj[9] != null) {
				bfsdUser.setLstupdatedt(Timestamp.valueOf(obj[9].toString()));
			}
		}
		userLoginAccount.setBfsdUser(bfsdUser);
		return userLoginAccount;
		
	}
	
}
