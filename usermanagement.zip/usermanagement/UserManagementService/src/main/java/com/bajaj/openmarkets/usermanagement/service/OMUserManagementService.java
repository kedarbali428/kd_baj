package com.bajaj.openmarkets.usermanagement.service;

import com.bajaj.openmarkets.usermanagement.bean.UserRequest;
import com.bajaj.openmarkets.usermanagement.bean.UserResponse;
import com.bajaj.openmarkets.usermanagement.cache.entity.CacheAdditionalInfo;

public interface OMUserManagementService {

	public UserResponse getUser(UserRequest userRequest);

	public CacheAdditionalInfo getUser(long userId);
	
	public CacheAdditionalInfo getUserRoleKey(long userId);
	
}