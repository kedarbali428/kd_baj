package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;



/**
 * The persistent class for the SER_REQ_ROLE_VIEW database table.
 * 
 */
@Entity
@Table(name = "SER_REQ_ROLE_VIEW")
//@NamedQuery(name = "SerReqRoleView.findAll", query = "SELECT s FROM SerReqRoleView s")
public class SerReqRoleView implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long viewrolekey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	@ManyToOne
	@JoinColumn(name = "VIEWKEY")
	private SerReqViewDefinition serReqViewDefinition;

	// bi-directional many-to-one association to BfsdRoleMaster
	@ManyToOne
	@JoinColumn(name = "ROLEKEY")
	private BfsdRoleMaster bfsdRoleMaster;

	// bi-directional many-to-one association to AppUserView
	@OneToMany(mappedBy = "serReqRoleView", cascade = CascadeType.ALL)
	private List<SerReqUserView> serReqUserViews;

	public SerReqViewDefinition getSerReqViewDefinition() {
		return serReqViewDefinition;
	}

	public List<SerReqUserView> getSerReqUserViews() {
		return serReqUserViews;
	}

	public void setSerReqUserViews(List<SerReqUserView> serReqUserViews) {
		this.serReqUserViews = serReqUserViews;
	}

	public void setSerReqViewDefinition(SerReqViewDefinition serReqViewDefinition) {
		this.serReqViewDefinition = serReqViewDefinition;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

	public long getViewrolekey() {
		return this.viewrolekey;
	}

	public void setViewrolekey(long viewrolekey) {
		this.viewrolekey = viewrolekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}