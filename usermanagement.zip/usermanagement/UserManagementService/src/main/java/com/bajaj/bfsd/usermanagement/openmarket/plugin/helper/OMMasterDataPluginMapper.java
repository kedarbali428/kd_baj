package com.bajaj.bfsd.usermanagement.openmarket.plugin.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.bajaj.bfdl.om.impl.EpBauClientImpl;
import com.bajaj.bfdl.om.insurance.impl.EpBauInsuranceClientImpl;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bfsd.om.bean.CityMasterBean;
import com.bfsd.om.bean.UserProductRoleBean;
import com.bfsd.om.bean.UserRoleProductBean;

@Component
public class OMMasterDataPluginMapper {

	@Autowired
	private EpBauClientImpl bauClientImpl;
	@Autowired
	private EpBauInsuranceClientImpl bauInsuranceClientImpl;
	
	private static final String CLASS_NAME = OMMasterDataPluginMapper.class.getName();
	@Autowired
	BFLLoggerUtil logger;

	public List<LocationBean> findSuperVisorLocation(Long userRoleProdKey, HttpHeaders headers) {
		List<CityMasterBean> list = bauClientImpl.findSuperVisorLocation(userRoleProdKey, headers);
		List<LocationBean> locations = new ArrayList<>();
		list.stream().forEach(item -> {
			if (null != item) {
				LocationBean bean = new LocationBean();
				bean.setId(item.getCitykey());
				bean.setName(item.getCityname());
				locations.add(bean);
			}
		});
		return locations;
	}
	
	public List<LocationBean> findInsuranceSuperVisorLocation(Long userRoleProdKey, HttpHeaders headers) {
		List<CityMasterBean> list = bauInsuranceClientImpl.findSuperVisorLocation(userRoleProdKey, headers);
		List<LocationBean> locations = new ArrayList<>();
		list.stream().forEach(item -> {
			if (null != item) {
				LocationBean bean = new LocationBean();
				bean.setId(item.getCitykey());
				bean.setName(item.getCityname());
				locations.add(bean);
			}
		});
		return locations;
	}
	
	public List<LocationBean> findInsuranceSuperVisorLocation(Long userKey, Long prodKey, HttpHeaders headers) {
		List<CityMasterBean> list = bauInsuranceClientImpl.findSuperVisorLocation(userKey, prodKey,headers);
		List<LocationBean> locations = new ArrayList<>();
		list.stream().forEach(item -> {
			if (null != item) {
				LocationBean bean = new LocationBean();
				bean.setId(item.getCitykey());
				bean.setName(item.getCityname());
				locations.add(bean);
			}
		});
		return locations;
	}

	public UserRoleProductBean findUserRoleProduct(Long l1ProdKey, Long l2ProdKey, Long userRoleKey,
			Long userRoleProdKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, " findUserRoleProduct Start::l1ProdKey "+l1ProdKey +" l2ProdKey "+l2ProdKey +"  userRoleKey "+ userRoleKey );
		UserRoleProductBean bean = null;
		try {
			 bean = bauClientImpl.getUserRoleProduct(l1ProdKey, l2ProdKey, userRoleKey, userRoleProdKey,
					headers);
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, " findUserRoleProduct Start::l1ProdKey "+l1ProdKey +" l2ProdKey "+l2ProdKey +"  userRoleKey "+ userRoleKey );
			
		}	
		
		return bean;
	}

	public UserRoleProductBean saveUserRoleMapping(UserRoleProductBean userRoleProduct, HttpHeaders headers) {
		UserRoleProductBean bean = bauClientImpl.saveUserRoleProduct(userRoleProduct, headers);
		return bean;
	}

	public List<SupervisorBean> getUserSuperVisor(long roleKey, long prodKey, String subProdKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "Start::getUserSuperVisor");
		List<com.bfsd.om.bean.SupervisorBean> superVisorList = bauClientImpl.getUserSuperVisorName(roleKey, prodKey,
				String.valueOf(subProdKey), headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "End::getUserSuperVisor");
		return mapOmToBauSupervisorBean(superVisorList);
	}
	
	private List<SupervisorBean> mapOmToBauSupervisorBean(List<com.bfsd.om.bean.SupervisorBean> superVisorList) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "Start::mapOmToBauSupervisorBean");
		List<SupervisorBean> superVList = new ArrayList<>();
		for(com.bfsd.om.bean.SupervisorBean supervisorBean : superVisorList) {
			SupervisorBean supervisor = new SupervisorBean();
			supervisor.setId(supervisorBean.getId());
			supervisor.setName(supervisorBean.getName());
			supervisor.setUserRoleKey(supervisorBean.getUserRoleKey());
			supervisor.setUserRoleProdKey(supervisorBean.getUserRoleProdKey());
			superVList.add(supervisor);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "End::mapOmToBauSupervisorBean");
		return superVList;
		
	}

	public List<UserRoleProductBean> findUserRoleMaapped(List<UserRole> userRoleList, HttpHeaders headers) {
		List<UserRoleProductBean> roles  =  new ArrayList<>();
		try {
			UserProductRoleBean bean = new UserProductRoleBean();
			ArrayList<Long> userKeys  =  new ArrayList<>();
			logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "START plugin ::findUserRoleMaapped");
			userRoleList.stream().forEach(item -> {
				userKeys.add(item.getUserrolekey());
			});
			
			if(null != bean){
				bean.setUserRoleKey(userKeys);
			}
			 roles = bauClientImpl.findUserRoleMapped(bean, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER,
					"findUserRoleMaapped response reseived : :: " + roles.size());
			return roles;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.MAPPER,
					"findUserRoleMaapped Exception : :: ",e);
            return roles;
		}
	}
	
	public List<UserRoleProductBean> findInsuranceUserRoleMaapped(List<UserRole> userRoleList, HttpHeaders headers) {
		List<UserRoleProductBean> roles  =  new ArrayList<>();
		try {
			UserProductRoleBean bean = new UserProductRoleBean();
			ArrayList<Long> userKeys  =  new ArrayList<>();
			logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "START plugin ::findUserRoleMaapped");
			userRoleList.stream().forEach(item -> {
				userKeys.add(item.getUserrolekey());
			});
			
			if(null != bean){
				bean.setUserRoleKey(userKeys);
			}
			 roles = bauInsuranceClientImpl.findUserRoleMapped(bean, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER,
					"findUserRoleMaapped response reseived : :: " + roles.size());
			return roles;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.MAPPER,
					"findUserRoleMaapped Exception : :: ",e);
            return roles;
		}
	}

	public List<SupervisorBean> getMultiOMUserSuperVisor(long roleKey, long prodKey, String oMSubProdKeys,
			HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "Start::getUserSuperVisor");
		List<com.bfsd.om.bean.SupervisorBean> superVisorList = bauClientImpl.getOMMultiUserSuperVisorName(roleKey, prodKey,
				oMSubProdKeys, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "End::getUserSuperVisor");
		return mapOmToBauSupervisorBean(superVisorList);

	}
	
	 public boolean updateUserRoleProduct(Long userRoleProdKey,HttpHeaders headers ) {
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "Start::findUserRoleProduct");
			boolean successFlag =   bauClientImpl.updateUserRoleProduct(userRoleProdKey, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "End::findUserRoleProduct");
			return successFlag;
			
		}
	 
	public List<PinCodeBean> getLocationPinForOM(String locationKey, HttpHeaders headers) {
		List<PinCodeBean> pinCodes = new ArrayList<>();
		String[] locations = locationKey.split(",");
		for (String locationID : locations) {
			List<com.bfsd.om.bean.PinCodeBean> list = bauClientImpl.getLocationPinForOM(new Long(locationID), headers);
			list.stream().forEach(item -> {
				if (null != item) {
					PinCodeBean bean = new PinCodeBean();
					bean.setId(new BigDecimal(item.getPincodeKey()));
					bean.setName(item.getPincode());
					pinCodes.add(bean);
				}
			});
		}
		return pinCodes;
	}
	
}
