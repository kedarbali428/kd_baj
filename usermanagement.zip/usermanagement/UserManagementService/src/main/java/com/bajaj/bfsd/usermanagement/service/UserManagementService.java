package com.bajaj.bfsd.usermanagement.service;

import java.util.List;

import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.usermanagement.bean.AutoRegisterRequest;
import com.bajaj.bfsd.usermanagement.bean.AutoRegisterResponse;
import com.bajaj.bfsd.usermanagement.bean.BfsdRoleMasterResponse;
import com.bajaj.bfsd.usermanagement.bean.ChangePasswordRequest;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.ReportingManager;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.TokenResponse;
import com.bajaj.bfsd.usermanagement.bean.UICredentialsResponse;
import com.bajaj.bfsd.usermanagement.bean.User;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserDetailBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountResponse;
import com.bajaj.bfsd.usermanagement.bean.UserMappingRequest;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.bean.UserProfileDetails;
import com.bajaj.bfsd.usermanagement.bean.UserRoleBean;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;

public interface UserManagementService {

	public BfsdUser createUser(User userBean);

	public String createUserMapping(UserMappingRequest userMappingBean);

	public String updateUserMapping(UserMappingRequest userMappingBean);

	public int deleteUser(UserConfigurationBean userConfig);

	public UserConfigurationBean getUserInformation(UserConfigurationBean userConfig,HttpHeaders headers);

	public UserConfigurationBean getActiveDirectoryUsers(UserConfigurationBean userConfig);

	public int updateUserDetails(UserInfoRequest userInfoRequest);//Added email Id for Partner Portal
	
	public List<SupervisorBean> getuserSuperVisor(String userRole);

	public List<LocationBean> getSuperVisorLocations(String userKey);

	public List<ChannelBean> getSuperVisorChannels(String userRoleKey);

	public List<PinCodeBean> getLocationPin(String locationKey);

	public List roleMapped(long employeeKey, long roleKey);

	public boolean deleteUserMapping(Long userKey, Long roleKey);

	public UICredentialsResponse getUICredentials(String loginId);

	public UserLoginAccountResponse getUserLoginAccount(UserLoginAccountRequest userLoginAccountRequest);

	public UserLoginAccountResponse getUserId(String loginId);

	public UserDetailBean getRolesByUserKey(long userKey);

	public List<UserName> getListOfUserName(long pincode, long function, long role, long tabkey, long subprodkey);
	
	public UserName getUserName(long pincode, long function, long role, Long applicationId, long tabkey, long subprodkey);
	
	public AutoRegisterResponse autoRegister(AutoRegisterRequest request);

	public void changePassword(ChangePasswordRequest passwordRequest, long userKey);
	
	public TokenResponse mergeUsers(long newUserKey, long oldUserKey);
	
	public BfsdUser saveUserVendorProfile(User userBean);
	
	public boolean validateEmail(String emailId, long applicantKey);

	public void saveEmail(String newEmail, String oldEmail, long applicantKey);
    
    public UserRoleBean getUserRoleInfo(Long userKey,Long roleKey);
    
    public List<UserName> getUserInfo(Long userRoleKey, Boolean isPrinciple, Boolean isUserkey);

	public List<UserRoleBean> getUserInfoByEmail(String userEmail);

	public BfsdRoleMasterResponse getRoleMasterByRoleKey(String roleKey);

	public List<UserProfileDetails> getUserProfilesByRoleKeys(List<Long> roleKeyList);

	public List<ReportingManager> getAllReportingManagers(String searchcriteria);
	
	public List<UserRoleBean> getUserInfoByAdId(String useradId);
	
	public UserRoleBean getUserNameBeanByUserRoleKey(long userRoleKey);
}