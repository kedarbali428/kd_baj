package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the INS_PRODUCT_TYPES database table.
 * 
 */
@Entity
@Table(name="INS_PRODUCT_TYPES")
//@NamedQuery(name="InsProductType.findAll", query="SELECT i FROM InsProductType i")
public class InsProductType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long insprodtypekey;

	private String insprodtypecode;

	private String insprodtypedesc;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to InsProductPlan
	@OneToMany(mappedBy="insProductType")
	private List<InsProductPlan> insProductPlans;
	
	@ManyToOne
	@JoinColumn(name="PRODCATKEY")
	private ProductCategory productCategory;

	public InsProductType() {
	}

	public long getInsprodtypekey() {
		return this.insprodtypekey;
	}

	public void setInsprodtypekey(long insprodtypekey) {
		this.insprodtypekey = insprodtypekey;
	}

	public String getInsprodtypecode() {
		return this.insprodtypecode;
	}

	public void setInsprodtypecode(String insprodtypecode) {
		this.insprodtypecode = insprodtypecode;
	}

	public String getInsprodtypedesc() {
		return this.insprodtypedesc;
	}

	public void setInsprodtypedesc(String insprodtypedesc) {
		this.insprodtypedesc = insprodtypedesc;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}


	public List<InsProductPlan> getInsProductPlans() {
		return this.insProductPlans;
	}

	public void setInsProductPlans(List<InsProductPlan> insProductPlans) {
		this.insProductPlans = insProductPlans;
	}

	public InsProductPlan addInsProductPlan(InsProductPlan insProductPlan) {
		getInsProductPlans().add(insProductPlan);
		insProductPlan.setInsProductType(this);

		return insProductPlan;
	}

	public InsProductPlan removeInsProductPlan(InsProductPlan insProductPlan) {
		getInsProductPlans().remove(insProductPlan);
		insProductPlan.setInsProductType(null);

		return insProductPlan;
	}
	public ProductCategory getProductCategory() {
		return this.productCategory;
	}

	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}

}