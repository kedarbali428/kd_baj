package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the EMP_ROLE_CHANNELS database table.
 * 
 */
@Entity
@Table(name="EMP_ROLE_CHANNELS")
//@NamedQuery(name="EmpRoleChannel.findAll", query="SELECT e FROM EmpRoleChannel e")
public class EmpRoleChannel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long empchannelkey;

	private BigDecimal channel;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to EmployeeRole
	@ManyToOne
	@JoinColumn(name="EMPROLEKEY")
	private EmployeeRole employeeRole;

	public long getEmpchannelkey() {
		return this.empchannelkey;
	}

	public void setEmpchannelkey(long empchannelkey) {
		this.empchannelkey = empchannelkey;
	}

	public BigDecimal getChannel() {
		return this.channel;
	}

	public void setChannel(BigDecimal channel) {
		this.channel = channel;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public EmployeeRole getEmployeeRole() {
		return this.employeeRole;
	}

	public void setEmployeeRole(EmployeeRole employeeRole) {
		this.employeeRole = employeeRole;
	}

}