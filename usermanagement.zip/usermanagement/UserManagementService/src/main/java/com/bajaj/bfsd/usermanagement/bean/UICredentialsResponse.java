package com.bajaj.bfsd.usermanagement.bean;

public class UICredentialsResponse {
	String secretKey;

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}
	
}
