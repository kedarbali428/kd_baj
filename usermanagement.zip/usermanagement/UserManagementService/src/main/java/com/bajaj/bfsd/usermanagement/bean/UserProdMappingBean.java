package com.bajaj.bfsd.usermanagement.bean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class UserProdMappingBean {

	private Long userRoleProdKey;
	private Long userRoleKey;
	private Long userKey;
	private BigDecimal creditLimit;
	private BigDecimal pricinglimit;
	private Long supervisorRoleProdKey;
	private Long loanProdKey;
	private Long prodMastKey;
	private Long prodCatKey;
	private Long functionKey;
	private Long roleKey;
	private String roleCode;
	private boolean isHighRole;
	private boolean isHighSupvisorRole;
	private List<Long> userLocKey=new ArrayList<Long>();
	private List<Long> userChannelKey=new ArrayList<Long>();
	private List<Long> userPinCdKey=new ArrayList<Long>();
	private List<Long> loanProductType=new ArrayList<Long>();
	private String employeeType; 

	private List<Long> utmMastKey=new ArrayList<Long>();
	private List<Long> l3ProdKeys=new ArrayList<Long>();

	public List<Long> getL3ProdKeys() {
		return l3ProdKeys;
	}

	public void setL3ProdKeys(List<Long> l3ProdKeys) {
		this.l3ProdKeys = l3ProdKeys;
	}

	public Long getUserRoleProdKey() {
		return userRoleProdKey;
	}

	public void setUserRoleProdKey(Long userRoleProdKey) {
		this.userRoleProdKey = userRoleProdKey;
	}

	public BigDecimal getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(BigDecimal creditLimit) {
		this.creditLimit = creditLimit;
	}

	public Long getSupervisorRoleProdKey() {
		return supervisorRoleProdKey;
	}

	public void setSupervisorRoleProdKey(Long supervisorRoleProdKey) {
		this.supervisorRoleProdKey = supervisorRoleProdKey;
	}

	public Long getLoanProdKey() {
		return loanProdKey;
	}

	public void setLoanProdKey(Long loanProdKey) {
		this.loanProdKey = loanProdKey;
	}

	public Long getProdMastKey() {
		return prodMastKey;
	}

	public void setProdMastKey(Long prodMastKey) {
		this.prodMastKey = prodMastKey;
	}

	public Long getProdCatKey() {
		return prodCatKey;
	}

	public void setProdCatKey(Long prodCatKey) {
		this.prodCatKey = prodCatKey;
	}

	public boolean isHighRole() {
		return isHighRole;
	}

	public void setHighRole(boolean isHighRole) {
		this.isHighRole = isHighRole;
	}

	/**
	 * @return the pricinglimit
	 */
	public BigDecimal getPricinglimit() {
		return pricinglimit;
	}

	/**
	 * @param pricinglimit the pricinglimit to set
	 */
	public void setPricinglimit(BigDecimal pricinglimit) {
		this.pricinglimit = pricinglimit;
	}

	public boolean isHighSupvisorRole() {
		return isHighSupvisorRole;
	}

	public void setHighSupvisorRole(boolean isHighSupvisorRole) {
		this.isHighSupvisorRole = isHighSupvisorRole;
	}

	public List<Long> getUserLocKey() {
		return userLocKey;
	}

	public void setUserLocKey(List<Long> userLocKey) {
		this.userLocKey = userLocKey;
	}

	public List<Long> getUserChannelKey() {
		return userChannelKey;
	}

	public void setUserChannelKey(List<Long> userChannelKey) {
		this.userChannelKey = userChannelKey;
	}

	public List<Long> getUserPinCdKey() {
		return userPinCdKey;
	}

	public void setUserPinCdKey(List<Long> userPinCdKey) {
		this.userPinCdKey = userPinCdKey;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public Long getUserRoleKey() {
		return userRoleKey;
	}

	public void setUserRoleKey(Long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}

	public List<Long> getLoanProductType() {
		return loanProductType;
	}

	public void setLoanProductType(List<Long> loanProductType) {
		this.loanProductType = loanProductType;
	}

	public Long getFunctionKey() {
		return functionKey;
	}

	public void setFunctionKey(Long functionKey) {
		this.functionKey = functionKey;
	}

	public Long getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(Long roleKey) {
		this.roleKey = roleKey;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public Long getUserKey() {
		return userKey;
	}

	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}

	public List<Long> getUtmMastKey() {
		return utmMastKey;
	}

	public void setUtmMastKey(List<Long> utmMastKey) {
		this.utmMastKey = utmMastKey;
	}	
}
