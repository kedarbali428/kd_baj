package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * The persistent class for the BFSD_FUNCTION_PRODUCTS database table.
 * 
 */
@Entity
@Table(name = "BFSD_FUNCTION_PRODUCTS")
//@NamedQuery(name = "BfsdFunctionProduct.findAll", query = "SELECT b FROM BfsdFunctionProduct b")
public class BfsdFunctionProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long prodfunctionkey;

	private BigDecimal isactive;

	private BigDecimal lnprdtypekey;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	// bi-directional many-to-one association to BfsdFunction
	@ManyToOne
	@JoinColumn(name = "FUNCTIONKEY")
	private BfsdFunction bfsdFunction;

	public long getProdfunctionkey() {
		return this.prodfunctionkey;
	}

	public void setProdfunctionkey(long prodfunctionkey) {
		this.prodfunctionkey = prodfunctionkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public BigDecimal getLnprdtypekey() {
		return this.lnprdtypekey;
	}

	public void setLnprdtypekey(BigDecimal lnprdtypekey) {
		this.lnprdtypekey = lnprdtypekey;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BfsdFunction getBfsdFunction() {
		return this.bfsdFunction;
	}

	public void setBfsdFunction(BfsdFunction bfsdFunction) {
		this.bfsdFunction = bfsdFunction;
	}

}