package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the BFSD_USERS database table.
 * 
 */
@Entity
@Table(name = "BFSD_USERS")
public class BfsdUserV2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "USERKEY", insertable = false, updatable = false)
	private long userkey;

	private long usertype;

	@OneToMany
	@JoinColumn(name = "USERKEY")
	private List<UserApplicantV2> userApplicants;

	private Integer isactive; 
	
	public long getUserkey() {
		return userkey;
	}

	public void setUserkey(long userkey) {
		this.userkey = userkey;
	}

	public long getUsertype() {
		return usertype;
	}

	public void setUsertype(long usertype) {
		this.usertype = usertype;
	}

	public List<UserApplicantV2> getUserApplicants() {
		return userApplicants;
	}

	public void setUserApplicants(List<UserApplicantV2> userApplicants) {
		this.userApplicants = userApplicants;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

}