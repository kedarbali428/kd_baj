package com.bajaj.bfsd.usermanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.usermanagement.model.BfsdUser;

@Repository
public interface BfsdUserRepository extends JpaRepository<BfsdUser, Long> {

	BfsdUser findFirstByUserkey(Long userkey); //Added for Partner Portal 
	
	BfsdUser findByUserkey(Long userKey);
}