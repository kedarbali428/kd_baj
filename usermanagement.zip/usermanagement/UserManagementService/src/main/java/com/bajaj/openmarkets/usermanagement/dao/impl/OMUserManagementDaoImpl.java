package com.bajaj.openmarkets.usermanagement.dao.impl;

import static com.bajaj.bfsd.usermanagement.util.QueryConstants.FETCH_LOGIN_USER_DETAILS_WITH_LOGINID;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.LOGINACCTYPE_MOBILEDOB;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.model.UserRole;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.openmarkets.usermanagement.bean.UserRequest;
import com.bajaj.openmarkets.usermanagement.dao.OMUserManagementDao;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
public class OMUserManagementDaoImpl implements OMUserManagementDao {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	EntityManager entityManager;

	@Override
	public UserLoginAccount getUserAccount(UserRequest userRequest) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.DAO, "Inside getUserAccount - start");
		Query query = entityManager.createQuery(FETCH_LOGIN_USER_DETAILS_WITH_LOGINID);

		String loginId = userRequest.getMobile() + "@" + userRequest.getDateOfBirth();

		query.setParameter("loginid", loginId);
		query.setParameter("loginAcctType", BigDecimal.valueOf(LOGINACCTYPE_MOBILEDOB));
		query.setParameter("userType", BigDecimal.valueOf(userRequest.getUserType()));

		try {
			UserLoginAccount userLoginAccount = (UserLoginAccount) query.getSingleResult();
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.DAO, "Inside getUserAccount - end");

			return userLoginAccount;
		} catch (NonUniqueResultException nonUniqureResult) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.DAO,
					"NO UNIQUE USER LOGIN ACCOUNT FOR GIVEN REQUEST: " + userRequest);
			throw new BFLBusinessException("UMS-047", "Non Unique User Account");
		} catch (NoResultException noResult) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.DAO, "USER NOT EXIST PLEASE CHECK");
			throw new BFLBusinessException("UMS-003", "No User Found for the given details");
		} catch (Exception exception) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.DAO,
					"User Fetch failed. Please check the exception: " + exception);
			throw new BFLTechnicalException("UMS-500", "Some technical error occurred");
		}

	}
	
	@SuppressWarnings("unchecked")
	public UserRole getUserRole(long userKey, long roleKey) {
		Query query = entityManager.createNamedQuery("UserRole.findByEmployeeAndRole");
		query.setParameter(UserManagementConstants.PARAM_ROLE_KEY, roleKey);
		query.setParameter(UserManagementConstants.PARAM_USER_KEY, userKey);

		List<UserRole> userRoles = query.getResultList();

		if (userRoles != null && !userRoles.isEmpty()) {
			return userRoles.get(0);
		}
		return new UserRole();
	}
}
