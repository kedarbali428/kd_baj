package com.bajaj.bfsd.usermanagement.bean;

import java.util.ArrayList;
import java.util.List;

public class DeleteUserRoleBean {

	private Long userRoleKey;
	private Long userKey;
	private Long roleKey;
	private List<Long> appViewKeys=new ArrayList<>();
	private List<Long> appUserViewKeys=new ArrayList<>();
	private List<Long> appViewRoleKeys=new ArrayList<>();
	private List<Long> srViewKeys=new ArrayList<>();
	private List<Long> srUserViewKeys=new ArrayList<>();
	private List<Long> srViewRoleKeys=new ArrayList<>();

//	For Application
	
//	select auv.USERROLEKEY,avd.VIEWKEY,auv.USERVIEWKEY,arv.VIEWROLEKEY  from APP_VIEW_DEFINITION avd, APP_ROLE_VIEW arv, APP_USER_VIEW auv 
//	where avd.VIEWKEY=arv.VIEWKEY and arv.VIEWROLEKEY=auv.VIEWROLEKEY and
//	avd.VIEWNAME in ('1085_49_MyAppView','1085_49_AllAppView','1085_49_MyTeamView') 
//	and auv.USERROLEKEY=:userRoleKey;
	
//  For Service Request	
//	select sruv.USERROLEKEY,srvd.VIEWKEY, sruv.USERVIEWKEY,srrv.VIEWROLEKEY  from SER_REQ_VIEW_DEFINITION srvd, SER_REQ_ROLE_VIEW srrv, SER_REQ_USER_VIEW sruv 
//	where srvd.VIEWKEY=srrv.VIEWKEY and srrv.VIEWROLEKEY=sruv.VIEWROLEKEY and
//	srvd.VIEWNAME in ('1085_49_MyAppView','1085_49_AllAppView','1085_49_MyTeamView') 
//	and sruv.USERROLEKEY=113;

	
	
	public Long getUserRoleKey() {
		return userRoleKey;
	}

	public void setUserRoleKey(Long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}

	public Long getUserKey() {
		return userKey;
	}

	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}

	public Long getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(Long roleKey) {
		this.roleKey = roleKey;
	}

	public List<Long> getAppViewKeys() {
		return appViewKeys;
	}

	public void setAppViewKeys(List<Long> appViewKeys) {
		this.appViewKeys = appViewKeys;
	}

	public List<Long> getAppUserViewKeys() {
		return appUserViewKeys;
	}

	public void setAppUserViewKeys(List<Long> appUserViewKeys) {
		this.appUserViewKeys = appUserViewKeys;
	}

	public List<Long> getAppViewRoleKeys() {
		return appViewRoleKeys;
	}

	public void setAppViewRoleKeys(List<Long> appViewRoleKeys) {
		this.appViewRoleKeys = appViewRoleKeys;
	}

	public List<Long> getSrViewKeys() {
		return srViewKeys;
	}

	public void setSrViewKeys(List<Long> srViewKeys) {
		this.srViewKeys = srViewKeys;
	}

	public List<Long> getSrUserViewKeys() {
		return srUserViewKeys;
	}

	public void setSrUserViewKeys(List<Long> srUserViewKeys) {
		this.srUserViewKeys = srUserViewKeys;
	}

	public List<Long> getSrViewRoleKeys() {
		return srViewRoleKeys;
	}

	public void setSrViewRoleKeys(List<Long> srViewRoleKeys) {
		this.srViewRoleKeys = srViewRoleKeys;
	}

}
