/**
 * 
 */
package com.bajaj.bfsd.usermanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.service.UserMgmtIntegration;
import com.bajaj.bfsd.usermanagement.service.UserMgmtProdService;

/**
 * @author deepak.ray
 *
 */
public class UserMgmtServiceCoreImpl implements UserMgmtIntegration{

	@Autowired
	UserMgmtProdService userMgmtProdService;
	@Override
	public UserConfigurationBean getUserAttributes(UserConfigurationBean userConfig, HttpHeaders headers) {
		UserConfigurationBean userConfiguration = userMgmtProdService.getUserDetails(userConfig,headers);
		return userConfiguration;
		
	}

	@Override
	public UserConfigurationBean getAdditionalUserAttributes(UserConfigurationBean userConfiguration) {
		userConfiguration = userMgmtProdService.getAdditionalUserDetails(userConfiguration);
		return userConfiguration;
		
		
	}

}
