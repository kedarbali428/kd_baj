package com.bajaj.bfsd.usermanagement.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;

public interface UserMgmtIntegration {

	public UserConfigurationBean getUserAttributes(UserConfigurationBean userConfig, HttpHeaders headers);
	
	public UserConfigurationBean getAdditionalUserAttributes(UserConfigurationBean userConfiguration);
}
