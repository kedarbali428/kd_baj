package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the PHONE_NUMBER_TYPES database table.
 * 
 */
@Entity
@Table(name="PHONE_NUMBER_TYPES")
//@NamedQuery(name="PhoneNumberType.findAll", query="SELECT p FROM PhoneNumberType p")
public class PhoneNumberType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long phonetypekey;

	private String phonetypecode;

	private String phonetypedesc;

	private BigDecimal phonetypeisactive;

	private String phonetypelstupdateby;

	private Timestamp phonetypelstupdatedt;

	private BigDecimal phonetypepriority;

	//bi-directional many-to-one association to ApplicantPhoneNumber
	@OneToMany(mappedBy="phoneNumberType")
	private List<ApplicantPhoneNumber> applicantPhoneNumbers;

	public PhoneNumberType() {
	}

	public long getPhonetypekey() {
		return this.phonetypekey;
	}

	public void setPhonetypekey(long phonetypekey) {
		this.phonetypekey = phonetypekey;
	}

	public String getPhonetypecode() {
		return this.phonetypecode;
	}

	public void setPhonetypecode(String phonetypecode) {
		this.phonetypecode = phonetypecode;
	}

	public String getPhonetypedesc() {
		return this.phonetypedesc;
	}

	public void setPhonetypedesc(String phonetypedesc) {
		this.phonetypedesc = phonetypedesc;
	}

	public BigDecimal getPhonetypeisactive() {
		return this.phonetypeisactive;
	}

	public void setPhonetypeisactive(BigDecimal phonetypeisactive) {
		this.phonetypeisactive = phonetypeisactive;
	}

	public String getPhonetypelstupdateby() {
		return this.phonetypelstupdateby;
	}

	public void setPhonetypelstupdateby(String phonetypelstupdateby) {
		this.phonetypelstupdateby = phonetypelstupdateby;
	}

	public Timestamp getPhonetypelstupdatedt() {
		return this.phonetypelstupdatedt;
	}

	public void setPhonetypelstupdatedt(Timestamp phonetypelstupdatedt) {
		this.phonetypelstupdatedt = phonetypelstupdatedt;
	}

	public BigDecimal getPhonetypepriority() {
		return this.phonetypepriority;
	}

	public void setPhonetypepriority(BigDecimal phonetypepriority) {
		this.phonetypepriority = phonetypepriority;
	}

	public List<ApplicantPhoneNumber> getApplicantPhoneNumbers() {
		return this.applicantPhoneNumbers;
	}

	public void setApplicantPhoneNumbers(List<ApplicantPhoneNumber> applicantPhoneNumbers) {
		this.applicantPhoneNumbers = applicantPhoneNumbers;
	}

	public ApplicantPhoneNumber addApplicantPhoneNumber(ApplicantPhoneNumber applicantPhoneNumber) {
		getApplicantPhoneNumbers().add(applicantPhoneNumber);
		applicantPhoneNumber.setPhoneNumberType(this);

		return applicantPhoneNumber;
	}

	public ApplicantPhoneNumber removeApplicantPhoneNumber(ApplicantPhoneNumber applicantPhoneNumber) {
		getApplicantPhoneNumbers().remove(applicantPhoneNumber);
		applicantPhoneNumber.setPhoneNumberType(null);

		return applicantPhoneNumber;
	}

}