package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the APP_VIEW_DEFINITION database table.
 * 
 */
@Entity
@Table(name="APP_VIEW_DEFINITION")
//@NamedQuery(name="AppViewDefinition.findAll", query="SELECT a FROM AppViewDefinition a")
public class AppViewDefinition implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long viewkey;

	private String condition;

	private String createdby;

	private Timestamp createddt;

	@Lob
	@Column(name="FILTERCONDTIONJASON")
	private Blob filtercondtionjason;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal viewaccess;

	private String viewname;

	private String wherecluase;

	//bi-directional many-to-one association to AppRoleView
	@OneToMany(mappedBy="appViewDefinition",cascade=CascadeType.ALL)
	private List<AppRoleView> appRoleViews;

	//bi-directional many-to-one association to AppViewParamLoan
	@OneToMany(mappedBy="appViewDefinition")
	private List<AppViewParamLoan> appViewParamLoans;

	//bi-directional many-to-one association to AppViewSummaryField
	@OneToMany(mappedBy="appViewDefinition")
	private List<AppViewSummaryField> appViewSummaryFields;

	public long getViewkey() {
		return this.viewkey;
	}

	public void setViewkey(long viewkey) {
		this.viewkey = viewkey;
	}

	public String getCondition() {
		return this.condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getCreatedby() {
		return this.createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public Timestamp getCreateddt() {
		return this.createddt;
	}

	public void setCreateddt(Timestamp createddt) {
		this.createddt = createddt;
	}

	

	public Blob getFiltercondtionjason() {
		return filtercondtionjason;
	}

	public void setFiltercondtionjason(Blob filtercondtionjason) {
		this.filtercondtionjason = filtercondtionjason;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getViewaccess() {
		return this.viewaccess;
	}

	public void setViewaccess(BigDecimal viewaccess) {
		this.viewaccess = viewaccess;
	}

	public String getViewname() {
		return this.viewname;
	}

	public void setViewname(String viewname) {
		this.viewname = viewname;
	}

	public String getWherecluase() {
		return this.wherecluase;
	}

	public void setWherecluase(String wherecluase) {
		this.wherecluase = wherecluase;
	}

	public List<AppRoleView> getAppRoleViews() {
		return this.appRoleViews;
	}

	public void setAppRoleViews(List<AppRoleView> appRoleViews) {
		this.appRoleViews = appRoleViews;
	}

	public AppRoleView addAppRoleView(AppRoleView appRoleView) {
		getAppRoleViews().add(appRoleView);
		appRoleView.setAppViewDefinition(this);

		return appRoleView;
	}

	public AppRoleView removeAppRoleView(AppRoleView appRoleView) {
		getAppRoleViews().remove(appRoleView);
		appRoleView.setAppViewDefinition(null);

		return appRoleView;
	}

	public List<AppViewParamLoan> getAppViewParamLoans() {
		return this.appViewParamLoans;
	}

	public void setAppViewParamLoans(List<AppViewParamLoan> appViewParamLoans) {
		this.appViewParamLoans = appViewParamLoans;
	}

	public AppViewParamLoan addAppViewParamLoan(AppViewParamLoan appViewParamLoan) {
		getAppViewParamLoans().add(appViewParamLoan);
		appViewParamLoan.setAppViewDefinition(this);

		return appViewParamLoan;
	}

	public AppViewParamLoan removeAppViewParamLoan(AppViewParamLoan appViewParamLoan) {
		getAppViewParamLoans().remove(appViewParamLoan);
		appViewParamLoan.setAppViewDefinition(null);

		return appViewParamLoan;
	}

	public List<AppViewSummaryField> getAppViewSummaryFields() {
		return this.appViewSummaryFields;
	}

	public void setAppViewSummaryFields(List<AppViewSummaryField> appViewSummaryFields) {
		this.appViewSummaryFields = appViewSummaryFields;
	}

	public AppViewSummaryField addAppViewSummaryField(AppViewSummaryField appViewSummaryField) {
		getAppViewSummaryFields().add(appViewSummaryField);
		appViewSummaryField.setAppViewDefinition(this);

		return appViewSummaryField;
	}

	public AppViewSummaryField removeAppViewSummaryField(AppViewSummaryField appViewSummaryField) {
		getAppViewSummaryFields().remove(appViewSummaryField);
		appViewSummaryField.setAppViewDefinition(null);

		return appViewSummaryField;
	}

}