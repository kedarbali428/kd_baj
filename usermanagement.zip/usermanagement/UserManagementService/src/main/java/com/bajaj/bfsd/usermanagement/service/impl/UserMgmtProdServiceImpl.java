package com.bajaj.bfsd.usermanagement.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserProdMappingBean;
import com.bajaj.bfsd.usermanagement.dao.UserMgmtProdDao;
import com.bajaj.bfsd.usermanagement.model.BfsdRoleMaster;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.InsProductType;
import com.bajaj.bfsd.usermanagement.model.InvestmentProduct;
import com.bajaj.bfsd.usermanagement.model.LoanProduct;
import com.bajaj.bfsd.usermanagement.model.ProductMaster;
import com.bajaj.bfsd.usermanagement.model.UserRoleChannelL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleLocationL3;
import com.bajaj.bfsd.usermanagement.model.UserRolePinCode;
import com.bajaj.bfsd.usermanagement.model.UserRolePinCodeL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleProduct;
import com.bajaj.bfsd.usermanagement.model.UserRoleProductL3;
import com.bajaj.bfsd.usermanagement.model.UserRoleProductType;
import com.bajaj.bfsd.usermanagement.model.UserRoleUtmSourceChannel;
import com.bajaj.bfsd.usermanagement.model.UtmSourceChannelMaster;
import com.bajaj.bfsd.usermanagement.model.VasProductType;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataInsurancePluginMapper;
import com.bajaj.bfsd.usermanagement.openmarket.plugin.helper.OMMasterDataPluginMapper;
import com.bajaj.bfsd.usermanagement.service.UserMgmtProdService;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.bfsd.usermanagement.util.UserManagementUtility;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfsd.om.bean.UserRoleChannelTypeBean;
import com.bfsd.om.bean.UserRoleLocationsBean;
import com.bfsd.om.bean.UserRolePincodeBean;
import com.bfsd.om.bean.UserRoleProductBean;
import com.bfsd.om.bean.UserRoleProductTypeBean;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;

@RefreshScope
@Service
public class UserMgmtProdServiceImpl extends BFLComponent implements UserMgmtProdService {

	private static final String PRINCIPAL_USER = "principalUser";

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	Environment env;

	@Autowired
	UserMgmtProdDao userMgmtProdDao;

	@Autowired
	UserProfileBean upb;

	@Autowired
	OMMasterDataPluginMapper omMasterDataPluginMapper;

	@Autowired
	OMMasterDataInsurancePluginMapper oMMasterDataInsurancePluginMapper;
	
	@Autowired
	EntityManager entityManager;

	private static final String CLASS_NAME = UserMgmtProdServiceImpl.class.getName();
	private static final String QRY_GET_USERROLE = "SELECT u FROM UserRoleL3 u where u.userrolekey = :userroleKey and u.isactive = 1 ";

	@Override
	public UserConfigurationBean getUserDetails(UserConfigurationBean userConfig, HttpHeaders headers) {
		return userMgmtProdDao.getUserDetails(userConfig, headers);
	}

	@SuppressWarnings("unused")
	@Override
	@Transactional
	public long saveUserMapping(UserProdMappingBean inputBean, HttpHeaders headers) {
		long userRoleProdkey = inputBean.getUserRoleProdKey();
		List<UserRoleProductL3> l3RoleProdList = new ArrayList<>();
		List<UserRoleProductL3> roleProdListL3 = new ArrayList<>();
		UserRoleL3 userRole;
		UserRoleL3 deactiveUserRole;
		UserRoleProductL3 userRoleProduct;
		UserRoleProductBean userRoleProductBean;
		if (userRoleProdkey < 0) {
			return userRoleProdkey;
		}

		if (userRoleProdkey == 0) {
			// Create New user-role-product mapping
			userRole = userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), inputBean.getRoleKey());

			if (userRole == null) {
				// User Role does not exist So Also create new UserRole Entry
				userRole = new UserRoleL3();
				BfsdRoleMaster bfsdRoleMaster = userMgmtProdDao.getEntity(BfsdRoleMaster.class, inputBean.getRoleKey());
				BfsdUser bfsdUser = userMgmtProdDao.getEntity(BfsdUser.class, inputBean.getUserKey());
				userRole.setBfsdRoleMaster(bfsdRoleMaster);
				userRole.setBfsduser(bfsdUser);
				userRole.setIsactive(1);
				userRole.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
				userRole.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
			} else {
				// If UserRole already exist, then check for UserRoleProduct and UTM Source
				// exist or not
				List<UserRoleProductL3> existingUserRoles = userMgmtProdDao.getUserProdMapping(
						userRole.getUserrolekey(), inputBean.getLoanProdKey(), inputBean.getProdMastKey());

				if (existingUserRoles != null && !existingUserRoles.isEmpty()) {
					throw new BFLBusinessException("UMS-005", env.getProperty("UMS-005"));
				}
			}

			userRoleProduct = new UserRoleProductL3();
			userRoleProduct.setIsactive(1);
			userRoleProduct.setCreditlimit(inputBean.getCreditLimit());
			userRoleProduct.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
			userRoleProduct.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			userRoleProduct.setProdmastkey(inputBean.getProdMastKey());
			userRoleProduct.setSubprodkey(inputBean.getLoanProdKey());
			userRoleProduct.setUserRole(userRole);
			userRoleProduct.setPricinglimit(inputBean.getPricinglimit());
			roleProdListL3.add(userRoleProduct);
			userRole.setUserRoleProducts(roleProdListL3);

		} else {
			// Update user-role-product mapping
			userRoleProduct = userMgmtProdDao.getEntity(UserRoleProductL3.class, userRoleProdkey);
			if (userRoleProduct == null) {
				// Check for OM
				// ADD OM GET CALL HERE
				userRoleProductBean = omMasterDataPluginMapper.findUserRoleProduct(null, null, null, userRoleProdkey,
						headers);
				if (userRoleProductBean == null) {
				throw new BFLBusinessException("UMS-038", env.getProperty("UMS-038"));
			}

				// ADDDED call for om service
				userRole = userMgmtProdDao.findUserRoleKey(userRoleProductBean.getUserrolekey());

			long rolekey = userRole.getBfsdRoleMaster().getRolekey();
			inputBean.setUserRoleKey(userRole.getUserrolekey());
			inputBean.setUserKey(userRole.getBfsduser().getUserkey());
			if(userRole.getBfsdRoleMaster().getRolekey()!=inputBean.getRoleKey()){
				userRole = bfsdRoleMasterRoleKeyMismatchWithInputRoleKey(inputBean, rolekey);
				}
				mapUserRoleProductWhenUserProdKeyNotZero(inputBean, userRole, userRoleProductBean);
				setUserRoleOmLocations(inputBean, userRoleProductBean);
	
				userRoleProductBean = omMasterDataPluginMapper.saveUserRoleMapping(userRoleProductBean, headers);
				return userRoleProductBean.getUserprodkey();
			}
			if (userRoleProduct == null) {
				throw new BFLBusinessException("UMS-038", env.getProperty("UMS-038"));
			}
				
			userRole = userRoleProduct.getUserRole();
			long rolekey = userRole.getBfsdRoleMaster().getRolekey();
			inputBean.setUserRoleKey(userRole.getUserrolekey());
			inputBean.setUserKey(userRole.getBfsduser().getUserkey());
			if (userRole.getBfsdRoleMaster().getRolekey() != inputBean.getRoleKey()) {
				userRole = bfsdRoleMasterRoleKeyMismatchWithInputRoleKey(inputBean, rolekey);
			}
			
		}
		
		if ((inputBean.getEmployeeType().equals(UserManagementConstants.EMPLOYEE))
				&& (inputBean.isHighRole() || inputBean.isHighSupvisorRole())) {
			// If Role is highest or supervisor role is highest
			inputBean.setUserLocKey(userMgmtProdDao.getAllLocations());
			inputBean.setUserChannelKey(userMgmtProdDao.getAllChannels());
		}

		if (inputBean.getSupervisorRoleProdKey() != null && inputBean.getSupervisorRoleProdKey() > 0) {
			// If supervisor selected with other than top role
			UserRoleProductL3 parentUserRoleProduct = userMgmtProdDao.getEntity(UserRoleProductL3.class,
					inputBean.getSupervisorRoleProdKey());
			if (parentUserRoleProduct == null) {
				throw new BFLBusinessException("UMS-040", env.getProperty("UMS-040"));
			}
			userRoleProduct.setParentUserRoleProduct(parentUserRoleProduct);
		}
 
		userRoleProduct.setUserRole(userRole);
		userRoleProduct.setIsactive(1);
		userRoleProduct.setCreditlimit(inputBean.getCreditLimit());
		userRoleProduct.setPricinglimit(inputBean.getPricinglimit());
		userRoleProduct.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
		userRoleProduct.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
		userRoleProduct.setProdmastkey(inputBean.getProdMastKey());
		userRoleProduct.setSubprodkey(inputBean.getLoanProdKey());
		setUserRoleProdTypes(inputBean, userRoleProduct);
		setUserRoleLocations(inputBean, userRoleProduct);
		setUserRoleChannels(inputBean, userRoleProduct);
		setUserRolePincodes(inputBean, userRoleProduct);
		setUTMSource(inputBean, userRole, userRoleProduct);

		l3RoleProdList.add(userRoleProduct);
		userRole.setUserRoleProducts(l3RoleProdList);
		userRole = userMgmtProdDao.saveUserMapping(userRole);
		if (userRole == null) {
			throw new BFLBusinessException("UMS-041", env.getProperty("UMS-041"));
		}
		for (UserRoleProductL3 userRoleProductL3 : userRole.getUserRoleProducts()) {
			if (userRoleProductL3.equals(userRoleProduct)) {
				userRoleProdkey = userRoleProductL3.getUserprodkey();
			}
		}
		return userRoleProdkey;
	}

	private void setUserRolePincodes(UserProdMappingBean inputBean, UserRoleProductL3 userRoleProduct) {
		// Set UserRoleProductPincodes
		List<UserRolePinCodeL3> existingObjs = userRoleProduct.getUserRolePinCodes();
		List<Long> inputKeys = inputBean.getUserPinCdKey();
		List<UserRolePinCodeL3> deleteList = new ArrayList<>();

		for (UserRolePinCodeL3 obj : existingObjs) {
			if (!inputKeys.contains(obj.getPincodekey())) {
				deleteList.add(obj);
			} else {
				inputKeys.remove(inputKeys.indexOf(obj.getPincodekey()));
			}
		}

		for (Long pincdKey : inputKeys) {
			UserRolePinCodeL3 userRolePincode = new UserRolePinCodeL3();
			userRolePincode.setPincodekey(pincdKey);
			userRolePincode.setUserRoleProduct(userRoleProduct);
			userRolePincode.setIsactive(1);
			userRolePincode.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			userRolePincode.setLstupdateby(UserManagementConstants.UPDATED_BY_SYSTEM);
			existingObjs.add(userRolePincode);
		}

		for (UserRolePinCodeL3 obj : deleteList) {
			existingObjs.remove(obj);
		}

		userRoleProduct.setUserRolePinCodes(existingObjs);
	}
	
	private void setUTMSource(UserProdMappingBean inputBean, UserRoleL3 userRole, UserRoleProductL3 userRoleProduct) {
		// Set UserRoleProductLocations
		List<UserRoleUtmSourceChannel> existingUserRoleUtmSourceChannels = userRoleProduct
				.getUserRoleUtmSourceChannels();
		List<Long> inputKeys = inputBean.getUtmMastKey();
 
		// If user role pr supervisor role is highest then

		List<UserRoleUtmSourceChannel> deleteList = new ArrayList<>();
		if (existingUserRoleUtmSourceChannels != null && !existingUserRoleUtmSourceChannels.isEmpty()) {
			for (UserRoleUtmSourceChannel obj : existingUserRoleUtmSourceChannels) {
				if (!inputKeys.contains(obj.getUtmsrcchnmastkey().longValue())) {
					deleteList.add(obj);
				} else {
					inputKeys.remove(inputKeys.indexOf(obj.getUtmsrcchnmastkey().longValue()));
				}
			}
		}
			
		for (Long utmsrcchnmastkey : inputKeys) {
			UserRoleUtmSourceChannel userRoleUtmSourceChannel = new UserRoleUtmSourceChannel();
			
			userRoleUtmSourceChannel.setUserRoleProduct(userRoleProduct);
			userRoleUtmSourceChannel.setIsactive(BigDecimal.ONE);
			userRoleUtmSourceChannel.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			userRoleUtmSourceChannel.setLstupdateby(UserManagementConstants.UPDATED_BY_SYSTEM);
			UtmSourceChannelMaster utmSourceChannelMaster = userMgmtProdDao.getEntity(UtmSourceChannelMaster.class,
					utmsrcchnmastkey);
			userRoleUtmSourceChannel.setUtmsrcchnmastkey(new BigDecimal(utmsrcchnmastkey));
			existingUserRoleUtmSourceChannels.add(userRoleUtmSourceChannel);
		}
		for (UserRoleUtmSourceChannel obj : deleteList) {
			existingUserRoleUtmSourceChannels.remove(obj);
		}
		userRoleProduct.setUserRoleUtmSourceChannels(existingUserRoleUtmSourceChannels);
	}

	private void setUserRoleChannels(UserProdMappingBean inputBean, UserRoleProductL3 userRoleProduct) {
		// Set UserRoleProductChannels
		List<UserRoleChannelL3> existingObjs = userRoleProduct.getUserRoleChannels();
		List<Long> inputKeys = inputBean.getUserChannelKey();
		List<UserRoleChannelL3> deleteList = new ArrayList<>();

		for (UserRoleChannelL3 obj : existingObjs) {
			if (!inputKeys.contains(obj.getChanneltypekey())) {
				deleteList.add(obj);
			} else {
				inputKeys.remove(inputKeys.indexOf(obj.getChanneltypekey()));
			}
		}

		for (Long channelKey : inputKeys) {
			UserRoleChannelL3 userRoleChannel = new UserRoleChannelL3();
			userRoleChannel.setChanneltypekey(channelKey);
			userRoleChannel.setUserRoleProduct(userRoleProduct);
			userRoleChannel.setIsactive(1);
			userRoleChannel.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			userRoleChannel.setLstupdateby(UserManagementConstants.UPDATED_BY_SYSTEM);
			existingObjs.add(userRoleChannel);
		}

		for (UserRoleChannelL3 obj : deleteList) {
			existingObjs.remove(obj);
		}

		userRoleProduct.setUserRoleChannels(existingObjs);
	}

	private void setUserRoleProdTypes(UserProdMappingBean inputBean, UserRoleProductL3 userRoleProduct) {

		List<UserRoleProductType> existingObjs = userRoleProduct.getUserRoleProductTypes();
		List<Long> inputKeys = inputBean.getLoanProductType();
		List<UserRoleProductType> deleteList = new ArrayList<>();

		for (UserRoleProductType obj : existingObjs) {
			if (!inputKeys.contains(obj.getSubprodtypekey())) {
				deleteList.add(obj);
			} else {
				inputKeys.remove(inputKeys.indexOf(obj.getSubprodtypekey()));
			}
		}
		// Set UserRoleProductTypes
		for (Long key : inputKeys) {
			UserRoleProductType usrpt = new UserRoleProductType();
			usrpt.setSubprodtypekey(key);
			usrpt.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			usrpt.setUserRoleProduct(userRoleProduct);
			usrpt.setIsactive(1);
			existingObjs.add(usrpt);
		}
		for (UserRoleProductType obj : deleteList) {
			existingObjs.remove(obj);
		}
		userRoleProduct.setUserRoleProductTypes(existingObjs);
	}

	private void setUserRoleLocations(UserProdMappingBean inputBean, UserRoleProductL3 userRoleProduct) {
		// Set UserRoleProductLocations
		List<UserRoleLocationL3> existingRoleLocations = userRoleProduct.getUserRoleLocations();
		List<Long> inputKeys = inputBean.getUserLocKey();

		// If user role pr supervisor role is highest then

		List<UserRoleLocationL3> deleteList = new ArrayList<>();

		for (UserRoleLocationL3 obj : existingRoleLocations) {
			if (!inputKeys.contains(obj.getBflbranchkey())) {
				deleteList.add(obj);
			} else {
				inputKeys.remove(inputKeys.indexOf(obj.getBflbranchkey()));
			}
		}
		for (Long branchKey : inputKeys) {
			UserRoleLocationL3 userRoleLoc = new UserRoleLocationL3();
			userRoleLoc.setBflbranchkey(branchKey);
			userRoleLoc.setUserRoleProduct(userRoleProduct);
			userRoleLoc.setIsactive(1);
			userRoleLoc.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			userRoleLoc.setLstupdateby(UserManagementConstants.UPDATED_BY_SYSTEM);
			existingRoleLocations.add(userRoleLoc);
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"setUserRoleLocations existingRoleLocations-" + branchKey);
		}
		for (UserRoleLocationL3 obj : deleteList) {
			existingRoleLocations.remove(obj);
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"setUserRoleLocations deletlist-" + obj.getUserlockey());
		}
		userRoleProduct.setUserRoleLocations(existingRoleLocations);
	}

	private void setUserRoleOmProdTypes(UserProdMappingBean inputBean, UserRoleProductBean userRoleProduct) {

		List<UserRoleProductTypeBean> existingObjs = userRoleProduct.getUserRoleProductTypes();
		List<Long> inputKeys = inputBean.getLoanProductType();
		List<UserRoleProductTypeBean> deleteList = new ArrayList<>();

		for (UserRoleProductTypeBean obj : existingObjs) {
			if (!inputKeys.contains(obj.getSubprodtypekey())) {
				deleteList.add(obj);
			} else {
				inputKeys.remove(inputKeys.indexOf(obj.getSubprodtypekey()));
			}
		}
		// Set UserRoleProductTypes
		for (Long key : inputKeys) {
			UserRoleProductTypeBean usrpt = new UserRoleProductTypeBean();
			//usrpt.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			usrpt.setSubprodtypekey(key.intValue());
			usrpt.setIsactive(new BigDecimal(1));
			existingObjs.add(usrpt);
		}
		for (UserRoleProductTypeBean obj : deleteList) {
			existingObjs.remove(obj);
		}
		userRoleProduct.setUserRoleProductTypes(existingObjs);
	}

	private void setUserRoleOmLocations(UserProdMappingBean inputBean, UserRoleProductBean userRoleProduct) {
		// Set UserRoleProductLocations
		List<UserRoleLocationsBean> existingRoleLocations = userRoleProduct.getUserRoleLocations();
		List<Long> inputKeys = inputBean.getUserLocKey();

		// If user role pr supervisor role is highest then

		List<UserRoleLocationsBean> deleteList = new ArrayList<>();

		for (UserRoleLocationsBean obj : existingRoleLocations) {
			if (!inputKeys.contains(obj.getCitykey())) {
				deleteList.add(obj);
			} else {
				inputKeys.remove(inputKeys.indexOf(obj.getCitykey()));
			}
		}

		for (Long cityKey : inputKeys) {
			UserRoleLocationsBean userRoleLoc = new UserRoleLocationsBean();
			userRoleLoc.setCitykey(cityKey);
			userRoleLoc.setIsactive(new Long(1));
			//userRoleLoc.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			userRoleLoc.setLstupdateby(UserManagementConstants.UPDATED_BY_SYSTEM);
			existingRoleLocations.add(userRoleLoc);
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"setUserRoleLocations existingRoleLocations-" + cityKey);
		}

		for (UserRoleLocationsBean obj : deleteList) {
			existingRoleLocations.remove(obj);
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"setUserRoleLocations deletlist-" + obj.getUserlockey());
		}
		userRoleProduct.setUserRoleLocations(existingRoleLocations);
	}

	@Override
	public List<SupervisorBean> getUserSuperVisor(long roleKey, long prodKey, long subProdKey) {
		return userMgmtProdDao.getUserSuperVisor(roleKey, prodKey, subProdKey);
	}

	@Override
	public List<LocationBean> getSuperVisorLocations(long userRoleProdKey) {
		return userMgmtProdDao.getSuperVisorLocations(userRoleProdKey);
	}

	@Override
	public List<ChannelBean> getSuperVisorChannels(long userRoleProdKey) {
		return userMgmtProdDao.getSuperVisorChannels(userRoleProdKey);
	}

	@Override
	public List<UserProdMappingBean> getUserMappingDetails(long userRoleProdKey, HttpHeaders headers) {

		UserRoleProductL3 userRoleProduct = userMgmtProdDao.getEntity(UserRoleProductL3.class, userRoleProdKey);
		UserRoleL3 userRole1;
		UserRoleProductBean userRoleProductBean;
		List<UserProdMappingBean> userProuctMappingBeans = new ArrayList<>();
			mapResponseForBAU(userRoleProdKey, userRoleProduct, userProuctMappingBeans);
		return userProuctMappingBeans;
	}

	private List<UserProdMappingBean> mapResponseForOm(Long userRoleProdKey, UserRoleProductBean userRoleProductBean,
			List<UserProdMappingBean> userProuctMappingBeans) {
		UserProdMappingBean result = new UserProdMappingBean();
		// ADDDED call for om service
		UserRoleL3 userRole = userMgmtProdDao.findUserRoleKey(userRoleProductBean.getUserrolekey());
		result.setUserRoleProdKey(userRoleProdKey);
		result.setUserRoleKey(userRoleProductBean.getUserrolekey());
		if (null != userRole.getBfsduser()) {
			result.setUserKey(userRole.getBfsduser().getUserkey());
		}

		result.setL3ProdKeys(userRoleProductBean.getL3Products());

		setLoanProductTypeOM(userRoleProductBean, result);
		setUserLocationsOM(userRoleProductBean, result);
		setUserPincodeOM(userRoleProductBean, result);
		//setUserLocationsOM(userRoleProductBean, result);
		setUserChannelsOM(userRoleProductBean, result);
		setUserUtmSourceChannelOM(userRoleProductBean, result);
	     result.setSupervisorRoleProdKey(userRoleProductBean.getSuperViosrRole());
		result.setProdMastKey(userRoleProductBean.getProdmastkey());
		result.setProdCatKey(userRoleProductBean.getProdCatKey());
		result.setLoanProdKey(userRoleProductBean.getUserRoleProductTypes().size()>0 ?(userRoleProductBean.getUserRoleProductTypes().get(0).getSubprodtypekey().longValue()):0L);
        //result.setCreditLimit(userRoleProductBean.getCreditlimit() != null ?userRoleProductBean.getCreditlimit():0L);
        result.setCreditLimit(userRoleProductBean.getCreditlimit() != null? (userRoleProductBean.getCreditlimit()): BigDecimal.ZERO);
        result.setPricinglimit(userRoleProductBean.getPricinglimit() != null? (userRoleProductBean.getPricinglimit()): BigDecimal.ZERO);
        result.setHighRole(userRoleProductBean.isHighRole());
        result.setHighSupvisorRole(userRoleProductBean.isHighRole());
        if (userRole.getBfsdRoleMaster() != null) {
			result.setFunctionKey(
					userRole.getBfsdRoleMaster().getBfsdFunctionRoles().get(0).getBfsdFunction().getFunctionkey());
			result.setRoleKey(userRole.getBfsdRoleMaster().getRolekey());
			result.setRoleCode(userRole.getBfsdRoleMaster().getRolecd());
		}

		List<Object[]> userProfiles = userMgmtProdDao.getUserProfileByUserKey(userRole.getBfsduser().getUserkey());
		if (!userProfiles.isEmpty()) {
			Object[] userProfile = userProfiles.get(0);
			if (userProfile[4] != null) {
				if (((BigDecimal) userProfile[4]).longValue() == 1) {
					result.setEmployeeType(UserManagementConstants.EMPLOYEE);
				} else if (((BigDecimal) userProfile[4]).longValue() == 2) {
					result.setEmployeeType(UserManagementConstants.VENDOR_INDIVIDUAL);
				} else if (((BigDecimal) userProfile[4]).longValue() == 3) {
					result.setEmployeeType(UserManagementConstants.VENDOR_COMPANY);
				}
			}
		}

		userProuctMappingBeans.add(result);

		return userProuctMappingBeans;
	}

	private void setUserPincodeOM(UserRoleProductBean userRoleProductBean, UserProdMappingBean result) {
		List<Long> keyList = new ArrayList<>();
		for (UserRolePincodeBean userRolePincodeBean : userRoleProductBean.getUserRolePincodes()) {
			if (userRolePincodeBean.getIsactive() == 1) {
				keyList.add(userRolePincodeBean.getPincodekey());
			}
		}
		result.setUserPinCdKey(keyList);
	}
	
	private void setUserUtmSourceChannelOM(UserRoleProductBean userRoleProductBean, UserProdMappingBean result) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "setUserUtmSourceChannelOM - started");
		List<Long> keyList = new ArrayList<>();
		if(null != userRoleProductBean.getUserRoleUtmSourceChannels())
		for (com.bfsd.om.bean.UserRoleUtmSourceChannel channel : userRoleProductBean.getUserRoleUtmSourceChannels()) {
				keyList.add(channel.getUtmsrcchnmastkey());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "setUserChannelsOM - ended");
		result.setUtmMastKey(keyList);		
	}

	private void setUserChannelsOM(UserRoleProductBean userRoleProductBean, UserProdMappingBean result) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "setUserChannelsOM - started");
		List<Long> keyList = new ArrayList<>();
		if(null != userRoleProductBean.getUserRoleUtmSourceChannels())
		for (com.bfsd.om.bean.UserRoleChannelTypeBean channel : userRoleProductBean.getChannels()) {
				keyList.add(channel.getChanneltypekey());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "setUserChannelsOM - ended");
		result.setUserChannelKey(keyList);		
		}

	private void mapResponseForBAU(long userRoleProdKey, UserRoleProductL3 userRoleProduct,
			List<UserProdMappingBean> userProuctMappingBeans) {
		UserProdMappingBean result = new UserProdMappingBean();
		result.setUserRoleProdKey(userRoleProdKey);
		result.setUserRoleKey(userRoleProduct.getUserRole().getUserrolekey());
		result.setCreditLimit(userRoleProduct.getCreditlimit());
		result.setProdMastKey(userRoleProduct.getProdmastkey());
		result.setPricinglimit(userRoleProduct.getPricinglimit());
		ProductMaster productMaster=userMgmtProdDao.getEntity(ProductMaster.class, userRoleProduct.getProdmastkey());
		
		if (productMaster.getProdmastcode().equals(UserManagementConstants.LOAN)) {
		LoanProduct lp = userMgmtProdDao.getEntity(LoanProduct.class, userRoleProduct.getSubprodkey());
		result.setProdCatKey(lp.getProductCategory().getProdcatkey());
		}else if(productMaster.getProdmastcode().equals(UserManagementConstants.INSURANCE)){
			InsProductType lp = userMgmtProdDao.getEntity(InsProductType.class, userRoleProduct.getSubprodkey());
			result.setProdCatKey(lp.getProductCategory().getProdcatkey());
			
		} else if(productMaster.getProdmastcode().equals(UserManagementConstants.VAS)){
			VasProductType lp = userMgmtProdDao.getEntity(VasProductType.class, userRoleProduct.getSubprodkey());
			result.setProdCatKey(lp.getProductCategory().getProdcatkey());
		} else if(productMaster.getProdmastcode().equals(UserManagementConstants.INVESTMENT)){
			InvestmentProduct ipt = userMgmtProdDao.getEntity(InvestmentProduct.class, userRoleProduct.getSubprodkey());
			result.setProdCatKey(ipt.getProductCategory().getProdcatkey());
		}
		
		result.setLoanProdKey(userRoleProduct.getSubprodkey());
		setLoanProductType(userRoleProduct, result);
		setUserLocations(userRoleProduct, result);
		setUserChannels(userRoleProduct, result);
		setUserPincode(userRoleProduct, result);
		setRoleUtmSourceChannel(userRoleProduct, result);
		
		// Set is high role
		result.setHighRole(false);
		UserRoleL3 userRole = userRoleProduct.getUserRole();
		BfsdRoleMaster roleMaster = userRole.getBfsdRoleMaster();
		if (roleMaster != null && roleMaster.getBfsdRoleMaster() != null
				&& roleMaster.getBfsdRoleMaster().getBfsdRoleMaster() == null) {
			result.setHighRole(true);
		}

		if (userRole.getBfsdRoleMaster() != null) {
			result.setFunctionKey(
					userRole.getBfsdRoleMaster().getBfsdFunctionRoles().get(0).getBfsdFunction().getFunctionkey());
			result.setRoleKey(userRole.getBfsdRoleMaster().getRolekey());
			result.setRoleCode(userRole.getBfsdRoleMaster().getRolecd());
		}

		List<Object[]> userProfiles = userMgmtProdDao.getUserProfileByUserKey(userRole.getBfsduser().getUserkey());
		if (!userProfiles.isEmpty()) {
			Object[] userProfile = userProfiles.get(0);
			if (userProfile[4] != null) {
				if (((BigDecimal) userProfile[4]).longValue() == 1) {
					result.setEmployeeType(UserManagementConstants.EMPLOYEE);
				}else if (((BigDecimal) userProfile[4]).longValue() == 2) {
					result.setEmployeeType(UserManagementConstants.VENDOR_INDIVIDUAL);
				} else if (((BigDecimal) userProfile[4]).longValue() == 3) {
					result.setEmployeeType(UserManagementConstants.VENDOR_COMPANY);
				}
			}
		}
		if(userRoleProduct.getParentUserRoleProduct()!=null){
		result.setSupervisorRoleProdKey(userRoleProduct.getParentUserRoleProduct().getUserprodkey());
		}
		result.setUserKey(userRole.getBfsduser().getUserkey());
		userProuctMappingBeans.add(result);
	}


	private void setUserPincode(UserRoleProductL3 userRoleProduct, UserProdMappingBean result) {
		List<Long> keyList= new ArrayList<>();
		for (UserRolePinCodeL3 userRolePinCode : userRoleProduct.getUserRolePinCodes()) {
			if (userRolePinCode.getIsactive() == 1) {
				keyList.add(userRolePinCode.getPincodekey());
			}
		}
		result.setUserPinCdKey(keyList);
	}
	
	private void setRoleUtmSourceChannel(UserRoleProductL3 userRoleProduct, UserProdMappingBean result) {
		List<BigDecimal> keyList= new ArrayList<>();
		for (UserRoleUtmSourceChannel userRoleUtmSourceChannel : userRoleProduct.getUserRoleUtmSourceChannels()) {
			if (userRoleUtmSourceChannel.getIsactive().intValue() == 1) {
				keyList.add(userRoleUtmSourceChannel.getUtmsrcchnmastkey());
			}
		}
		result.setUtmMastKey(keyList.stream().map(BigDecimal::longValue).collect(Collectors.toList()));
	}

	private void setUserChannels(UserRoleProductL3 userRoleProduct, UserProdMappingBean result) {
		List<Long> keyList = new ArrayList<>();
		for (UserRoleChannelL3 userRoleChannel : userRoleProduct.getUserRoleChannels()) {
			if (userRoleChannel.getIsactive() == 1) {
				keyList.add(userRoleChannel.getChanneltypekey());
			}
		}
		result.setUserChannelKey(keyList);
	}

	private void setUserLocations(UserRoleProductL3 userRoleProduct, UserProdMappingBean result) {
		List<Long> keyList = new ArrayList<>();
		for (UserRoleLocationL3 userRoleLocation : userRoleProduct.getUserRoleLocations()) {
			if (userRoleLocation.getIsactive() == 1) {
				keyList.add(userRoleLocation.getBflbranchkey());
			}
		}
		result.setUserLocKey(keyList);
	}

	private void setUserLocationsOM(UserRoleProductBean userRoleProduct, UserProdMappingBean result) {
		List<Long> keyList = new ArrayList<>();
		for (UserRoleLocationsBean userRoleLocation : userRoleProduct.getUserRoleLocations()) {
			if (userRoleLocation.getIsactive() == 1) {
				keyList.add(userRoleLocation.getCitykey());
			}
		}
		result.setUserLocKey(keyList);
	}
	
	private void setLoanProductType(UserRoleProductL3 userRoleProduct, UserProdMappingBean result) {
		List<Long> keyList = new ArrayList<>();
		for (UserRoleProductType userRoleProductType : userRoleProduct.getUserRoleProductTypes()) {
			if (userRoleProductType.getIsactive() == 1) {
				keyList.add(userRoleProductType.getSubprodtypekey());
			}
		}
		result.setLoanProductType(keyList);
	}

	private void setLoanProductTypeOM(UserRoleProductBean userRoleProductBean, UserProdMappingBean result) {
		List<Long> keyList = new ArrayList<>();
		for (UserRoleProductTypeBean userRoleProductType : userRoleProductBean.getUserRoleProductTypes()) {
			if (userRoleProductType.getIsactive().compareTo(BigDecimal.ONE) == 0) {
				keyList.add(Long.valueOf(userRoleProductType.getSubprodtypekey()));

			}
		}
		keyList = keyList.stream().distinct().collect(Collectors.toList());
		result.setLoanProductType(keyList);
	}

	@Override
	@Transactional
	public boolean deleteUserMapping(long userRoleProdKey, long prodMastKey, HttpHeaders headers)  {
		boolean isDeleted = false;
		boolean isSupervisor = userMgmtProdDao.getSupervisor(userRoleProdKey);
		if(isSupervisor){
		throw new BFLBusinessException("UMS-043", env.getProperty("UMS-043"));
		}
		
		List<ProductMaster> masterProducts = getAllMasterProducts();
		Optional<ProductMaster> optMaster = masterProducts.stream().filter(item -> item.getProdmastkey() == prodMastKey)
				.findFirst();
		if (optMaster.isPresent()) {
			ProductMaster master = optMaster.get();

			if ((master.getProdmastcode()).equals("OMCREDIT")) {
				isDeleted = deleteUserMappingForOMCredit(userRoleProdKey, headers);
			}
			
			else if ((master.getProdmastcode()).equals("OMINS")) {
				isDeleted = deleteUserMappingForOMInsurance(userRoleProdKey, headers);
			}
			
			
			else {
		UserRoleProductL3 userRoleProduct = userMgmtProdDao.getEntity(UserRoleProductL3.class, userRoleProdKey);
				if (null != userRoleProduct) {
		UserRoleL3 userRole = userRoleProduct.getUserRole();
		if (userRole.getUserRoleProducts().size() == 1) {
			// This is the last mapping of user so delete userRole also.
			userRole.setIsactive(0);
			
		} 
		userRole.getUserRoleProducts().remove(userRoleProduct);
					if (userMgmtProdDao.saveUserMapping(userRole) != null) {
			
			isDeleted=true;
		}
				}
			}

		}
				
		return isDeleted;
	}

	@Override
	public long savePrincipalUserMapping(UserProdMappingBean inputBean,HttpHeaders headers) {
		if(inputBean.getEmployeeType().equalsIgnoreCase(PRINCIPAL_USER)){
			inputBean.getL3ProdKeys().stream().forEach(item -> {
		long userRoleProdkey = inputBean.getUserRoleProdKey();
		UserRoleL3 userRole;
				UserRoleProductBean userRoleProduct = null;
		if (userRoleProdkey == 0) {
			// Create New user-role-product mapping
			userRole = userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), inputBean.getRoleKey());
			if (userRole == null) {
				userRole = proceedWithUserRoleNotFound(inputBean);
			} else {
						UserRoleProductBean omBean = omMasterDataPluginMapper.findUserRoleProduct(
								inputBean.getProdMastKey(), item, userRole.getUserrolekey(), null,
								headers);
						if (omBean != null && 0 !=omBean.getProdmastkey()) {
					throw new BFLBusinessException("UMS-005", env.getProperty("UMS-005"));
				}
			}
			userRoleProduct = mapUserRoleProductWhenUserRoleProdKeyIsZero(inputBean, userRole);
					mapUserRoleProductFieldForPrincipalUser(inputBean, item, userRoleProduct);
			userRoleProduct = omMasterDataPluginMapper.saveUserRoleMapping(userRoleProduct, headers);
		} else {
			// ADD OM GET CALL HERE
					userRoleProduct = omMasterDataPluginMapper.findUserRoleProduct(null, null, null, userRoleProdkey,
							headers);
					if (userRoleProduct == null) {
						throw new BFLBusinessException("UMS-038", env.getProperty("UMS-038"));
					}
					// ADDDED call for om service
					userRole = userMgmtProdDao.findUserRoleKey(userRoleProduct.getUserrolekey());

					long rolekey = userRole.getBfsdRoleMaster().getRolekey();
					inputBean.setUserRoleKey(userRole.getUserrolekey());
					inputBean.setUserKey(userRole.getBfsduser().getUserkey());
					if (userRole.getBfsdRoleMaster().getRolekey() != inputBean.getRoleKey()) {
						userRole = bfsdRoleMasterRoleKeyMismatchWithInputRoleKey(inputBean, rolekey);
					}
					mapUserRoleProductWhenUserProdKeyNotZero(inputBean, userRole, userRoleProduct);
					mapUserRoleProductFieldForPrincipalUser(inputBean, item, userRoleProduct);
					userRole = userMgmtProdDao.saveUserMapping(userRole);
					userRoleProduct = omMasterDataPluginMapper.saveUserRoleMapping(userRoleProduct, headers);
					if (userRole == null) {
						throw new BFLBusinessException("UMS-041", env.getProperty("UMS-041"));
					}
				}
			});
		}
		else{
			UserRoleL3 userRole = null;
			UserRoleProductBean userRoleProduct = null;
			long userRoleProdkey = inputBean.getUserRoleProdKey();
			if (userRoleProdkey == 0) {
				userRole = userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), inputBean.getRoleKey());
				if (userRole == null) {
					userRole = proceedWithUserRoleNotFound(inputBean);
				} else {
					UserRoleProductBean omBean = omMasterDataPluginMapper.findUserRoleProduct(
							inputBean.getProdMastKey(), inputBean.getProdCatKey(), userRole.getUserrolekey(), null,
							headers);
					if (omBean != null && 0 !=omBean.getProdmastkey()) {
						throw new BFLBusinessException("UMS-005", env.getProperty("UMS-005"));
					}
				}
				
				userRoleProduct = mapUserRoleProductWhenUserRoleProdKeyIsZero(inputBean, userRole);
				userRoleProduct.setSubprodkey(inputBean.getProdCatKey());
				userRoleProduct.setProdCatKey(inputBean.getProdCatKey());
				userRoleProduct.setSuperViosrRole(inputBean.getSupervisorRoleProdKey());

				setUserRoleOmLocations(inputBean, userRoleProduct);
				setUserRoleUtmSource(inputBean, userRoleProduct);
				setUserRoleChannelType(inputBean, userRoleProduct,null);
				setUserRoleOmPincodes(inputBean, userRoleProduct);
				userRoleProduct.setCreditlimit(inputBean.getCreditLimit() != null ? inputBean.getCreditLimit() : null);
				userRoleProduct.setPricinglimit(inputBean.getPricinglimit() != null ? inputBean.getPricinglimit() : null);
				for (Long item : inputBean.getLoanProductType()) {
					setUserRoleProductTypeSource(inputBean, userRoleProduct, item);
				}
				userRoleProduct = omMasterDataPluginMapper.saveUserRoleMapping(userRoleProduct, headers);
			}
			else{
				userRoleProduct = omMasterDataPluginMapper.findUserRoleProduct(null, null, null, userRoleProdkey,
						headers);
			if (userRoleProduct == null) {
				throw new BFLBusinessException("UMS-038", env.getProperty("UMS-038"));
			}
			// ADDDED call for om service
			userRole = userMgmtProdDao.findUserRoleKey(userRoleProduct.getUserrolekey());

			long rolekey = userRole.getBfsdRoleMaster().getRolekey();
			inputBean.setUserRoleKey(userRole.getUserrolekey());
			inputBean.setUserKey(userRole.getBfsduser().getUserkey());
			if (userRole.getBfsdRoleMaster().getRolekey() != inputBean.getRoleKey()) {
				userRole = bfsdRoleMasterRoleKeyMismatchWithInputRoleKey(inputBean, rolekey);
			}
		mapUserRoleProductWhenUserProdKeyNotZero(inputBean, userRole, userRoleProduct);
				userRoleProduct.setSubprodkey(inputBean.getProdCatKey());
				userRoleProduct.setProdCatKey(inputBean.getProdCatKey());
				userRoleProduct.setSuperViosrRole(inputBean.getSupervisorRoleProdKey());
		        setUserRoleOmLocations(inputBean, userRoleProduct);
				//setUserRoleUtmSource(inputBean, userRoleProduct);
				setUserRoleOmPincodes(inputBean, userRoleProduct);
				setUserRoleChannelType(inputBean, userRoleProduct,null);
				for (Long item : inputBean.getLoanProductType()) {
					setUserRoleProductTypeSource(inputBean, userRoleProduct, item);
				}
				userRoleProduct.setCreditlimit(inputBean.getCreditLimit() != null ? inputBean.getCreditLimit() : null);
				userRoleProduct
						.setPricinglimit(inputBean.getPricinglimit() != null ? inputBean.getPricinglimit() : null);

		userRole = userMgmtProdDao.saveUserMapping(userRole);
		userRoleProduct = omMasterDataPluginMapper.saveUserRoleMapping(userRoleProduct, headers);
		if (userRole == null) {
			throw new BFLBusinessException("UMS-041", env.getProperty("UMS-041"));
		}
		}
	}
		return 0;
	}

	private void mapUserRoleProductFieldForPrincipalUser(UserProdMappingBean inputBean, Long item, UserRoleProductBean userRoleProduct) {
		userRoleProduct.setSubprodkey(item!= null ?item:0L);
		userRoleProduct.setProdCatKey(item!= null ?item:0L);
		userRoleProduct.setSuperViosrRole(inputBean.getSupervisorRoleProdKey());
		setUserRoleOmLocations(inputBean, userRoleProduct);
		setUserRoleUtmSource(inputBean, userRoleProduct);
		setUserRoleChannelType(inputBean, userRoleProduct,item);
		setUserRoleOmPincodes(inputBean, userRoleProduct);
		//
		List<Long> productTypes = inputBean.getLoanProductType();
		if(!productTypes.isEmpty()){
			setUserRoleProductTypeSource(inputBean, userRoleProduct,productTypes.get(0));
			productTypes.remove(productTypes.get(0));
		}
		userRoleProduct.setCreditlimit(inputBean.getCreditLimit() != null ? inputBean.getCreditLimit() : null);
		userRoleProduct
				.setPricinglimit(inputBean.getPricinglimit() != null ? inputBean.getPricinglimit() : null);
	}
	
	
	private void setUserRoleOmPincodes(UserProdMappingBean inputBean, UserRoleProductBean userRoleProduct) {
		// Set UserRoleProductPincodes
		List<UserRolePincodeBean> existingRolePincodes = userRoleProduct.getUserRolePincodes();
		List<Long> inputKeys = inputBean.getUserPinCdKey();

		List<UserRolePincodeBean> deleteList = new ArrayList<>();

		for (UserRolePincodeBean obj : existingRolePincodes) {
			if (!inputKeys.contains(obj.getPincodekey())) {
				deleteList.add(obj);
			} else {
				inputKeys.remove(inputKeys.indexOf(obj.getPincodekey()));
			}
		}

		for (Long pinCodeKey : inputKeys) {
			UserRolePincodeBean userRolePincodeBean = new UserRolePincodeBean();
			userRolePincodeBean.setPincodekey(pinCodeKey);
			userRolePincodeBean.setIsactive(new Long(1));
			// userRoleLoc.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			userRolePincodeBean.setLstupdateby(UserManagementConstants.UPDATED_BY_SYSTEM);
			existingRolePincodes.add(userRolePincodeBean);
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"setUserRolePincodes existingRolePincodes-" + pinCodeKey);
		}

		for (UserRolePincodeBean obj : deleteList) {
			existingRolePincodes.remove(obj);
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"setUserRoleLocations deletlist-" + obj.getUserpincodekey());
		}
		userRoleProduct.setUserRolePincodes(existingRolePincodes);
	
	}

	private void mapUserRoleProductWhenUserProdKeyNotZero(UserProdMappingBean inputBean, UserRoleL3 userRole,
			UserRoleProductBean userRoleProduct) {
		userRoleProduct.setUserrolekey(userRole.getUserrolekey());
		userRoleProduct.setIsactive(new BigDecimal(1));
		userRoleProduct.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
		userRoleProduct.setProdmastkey(inputBean.getProdMastKey());
		userRoleProduct.setSubprodkey(inputBean.getLoanProdKey());
		setUserRoleOmProdTypes(inputBean, userRoleProduct);
	}

	private UserRoleL3 bfsdRoleMasterRoleKeyMismatchWithInputRoleKey(UserProdMappingBean inputBean, long rolekey) {
		UserRoleL3 userRole;
		UserRoleL3 deactiveUserRole;
		// In case of update mapping- Role changed
		userRole = userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), inputBean.getRoleKey());

		deactiveUserRole = userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), rolekey);
		if (deactiveUserRole != null) {
			deactiveUserRole.setIsactive(0);
			userMgmtProdDao.saveUserMapping(deactiveUserRole);
		}
		if (userRole == null) {
			userRole = proceedWithUserRoleNotFound(inputBean);
		}
		return userRole;
	}

	private UserRoleProductBean mapUserRoleProductWhenUserRoleProdKeyIsZero(UserProdMappingBean inputBean,
			UserRoleL3 userRole) {
		UserRoleProductBean userRoleProduct;
		userRoleProduct = new UserRoleProductBean();
		userRoleProduct.setIsactive(new BigDecimal(1));
		userRoleProduct.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
		userRoleProduct.setProdmastkey(inputBean.getProdMastKey());
		userRoleProduct.setSubprodkey(inputBean.getLoanProdKey());
		userRoleProduct.setUserrolekey(userRole.getUserrolekey());
		return userRoleProduct;
	}

	private UserRoleL3 proceedWithUserRoleNotFound(UserProdMappingBean inputBean) {
		UserRoleL3 userRole;
		// User Role does not exist So Also create new UserRole Entry
		userRole = new UserRoleL3();
		BfsdRoleMaster bfsdRoleMaster = userMgmtProdDao.getEntity(BfsdRoleMaster.class, inputBean.getRoleKey());
		BfsdUser bfsdUser = userMgmtProdDao.getEntity(BfsdUser.class, inputBean.getUserKey());
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		userRole.setBfsduser(bfsdUser);
		userRole.setIsactive(1);
		userRole.setLstupdatedt(UserManagementUtility.getCurrentTimeStamp());
		userRole.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
		userRole = userMgmtProdDao.saveUserMapping(userRole);
		return userRole;
	}

	@Override
	public List<ProductMaster> getAllMasterProducts() {
		return userMgmtProdDao.findAllMasterProducts();
	}

	@Override
	public long saveUserMappingForOMInsurance(UserProdMappingBean inputBean, HttpHeaders headers) {// OM
		UserRoleProductBean userRoleProduct = null;
		UserRoleL3 userRole = null;
		long userRoleProdkey = inputBean.getUserRoleProdKey();
		if (userRoleProdkey == 0) {
			// Create New user-role-product mapping
			userRole = userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), inputBean.getRoleKey());
			if (userRole == null) {
				userRole = proceedWithUserRoleNotFound(inputBean);
			} else {
				UserRoleProductBean omBean = oMMasterDataInsurancePluginMapper.findUserRoleProduct(
						inputBean.getProdMastKey(), inputBean.getProdCatKey(), userRole.getUserrolekey(), null,
						headers);
				if (omBean != null && 0 != omBean.getProdmastkey()) {
					throw new BFLBusinessException("UMS-005", env.getProperty("UMS-005"));
				}
			}
			userRoleProduct = mapUserRoleProductWhenUserRoleProdKeyIsZero(inputBean, userRole);
			mapUserRoleProductFields(inputBean, userRoleProduct);
			userRoleProduct = oMMasterDataInsurancePluginMapper.saveUserRoleMapping(userRoleProduct, headers);
		} else {
			// ADD OM GET CALL HERE
			userRoleProduct = oMMasterDataInsurancePluginMapper.findUserRoleProduct(null, null, null, userRoleProdkey,
					headers);
			if (userRoleProduct == null) {
				throw new BFLBusinessException("UMS-038", env.getProperty("UMS-038"));
			}
			// ADDDED call for om service
			userRole = userMgmtProdDao.findUserRoleKey(userRoleProduct.getUserrolekey());

			long rolekey = userRole.getBfsdRoleMaster().getRolekey();
			inputBean.setUserRoleKey(userRole.getUserrolekey());
			inputBean.setUserKey(userRole.getBfsduser().getUserkey());
			if (userRole.getBfsdRoleMaster().getRolekey() != inputBean.getRoleKey()) {
				userRole = bfsdRoleMasterRoleKeyMismatchWithInputRoleKeyForInsurance(inputBean, rolekey);
			}
			mapUserRoleProductWhenUserProdKeyNotZeroForInsurance(inputBean, userRole,userRoleProduct);
			mapUserRoleProductFieldsForInsurance(inputBean, userRoleProduct);
		userRole = userMgmtProdDao.saveUserMapping(userRole);
		if (userRole == null) {
			throw new BFLBusinessException("UMS-041", env.getProperty("UMS-041"));
		}
			userRoleProduct = oMMasterDataInsurancePluginMapper.saveUserRoleMapping(userRoleProduct, headers);
		}
		return 0;
	}

	private void mapUserRoleProductFields(UserProdMappingBean inputBean, UserRoleProductBean userRoleProduct) {
		userRoleProduct.setSubprodkey(inputBean.getProdCatKey());
		userRoleProduct.setProdCatKey(inputBean.getProdCatKey());
		userRoleProduct.setSuperViosrRole(inputBean.getSupervisorRoleProdKey());

		setUserRoleOmLocations(inputBean, userRoleProduct);
		setUserRoleUtmSource(inputBean, userRoleProduct);
		setUserRoleChannelType(inputBean, userRoleProduct,null);
		setUserRoleOmPincodes(inputBean, userRoleProduct);
		userRoleProduct.setCreditlimit(inputBean.getCreditLimit() != null ? inputBean.getCreditLimit() : null);
		userRoleProduct.setPricinglimit(inputBean.getPricinglimit() != null ? inputBean.getPricinglimit() : null);
		for (Long item : inputBean.getL3ProdKeys()) {
			setUserRoleProductTypeSource(inputBean, userRoleProduct, item);
		}
	}

	@Override
	public List<SupervisorBean> getUserSuperVisorForOmInsurance(long roleKey, long prodKey, String OMSubProdKeys,
			HttpHeaders headers) {
		 logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start::getUserSuperVisorForOmInsurance");
		List<SupervisorBean> supervisorList = oMMasterDataInsurancePluginMapper.getUserSuperVisor(roleKey, prodKey,
				OMSubProdKeys, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End::getUserSuperVisorForOmInsurance");
		if(CollectionUtils.isEmpty(supervisorList)) {
			// No Supervisor exist for above role
			throw new BFLBusinessException("UMS-020", env.getProperty("UMS-020"));
		}
		return supervisorList;
	}

	@Override
	public List<SupervisorBean> getUserSuperVisorForOmCredit(long roleKey, long prodKey, String subProdKey,
			HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start::getUserSuperVisorForOmCredit");
		List<SupervisorBean> supervisorList = omMasterDataPluginMapper.getUserSuperVisor(roleKey, prodKey, subProdKey,
				headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start::getUserSuperVisorForOmCredit");
		return supervisorList;
	}

	@Override
	public UserConfigurationBean getAdditionalUserDetails(UserConfigurationBean userConfig) {
		return userMgmtProdDao.getAdditionalUserDetails(userConfig);
	}

	@Override
	public List<SupervisorBean> getOMUserSuperVisorForOmCredit(long roleKey, long prodKey, String oMSubProdKeys,
			HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start::getUserSuperVisorForOmCredit");
		List<SupervisorBean> supervisorList = omMasterDataPluginMapper.getMultiOMUserSuperVisor(roleKey, prodKey,
				oMSubProdKeys, headers);
		 logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start::getUserSuperVisorForOmCredit");
		return supervisorList;
	}

	private void setUserRoleUtmSource(UserProdMappingBean inputBean, UserRoleProductBean userRoleProduct) {
		// Set setUserRoleUtmSource
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start::setUserRoleUtmSource");

		List<com.bfsd.om.bean.UserRoleUtmSourceChannel> existingRoleUtms = userRoleProduct
				.getUserRoleUtmSourceChannels();
		inputBean.getUtmMastKey().stream().forEach(item->{
			com.bfsd.om.bean.UserRoleUtmSourceChannel utm  =  new com.bfsd.om.bean.UserRoleUtmSourceChannel();
			utm.setUtmsrcchnmastkey(item);
			userRoleProduct.getUserRoleUtmSourceChannels().add(utm);
		});
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "END ::setUserRoleUtmSource "+userRoleProduct.getUserRoleUtmSourceChannels().size());
	}
	
	private void setUserRoleChannelType(UserProdMappingBean inputBean, UserRoleProductBean userRoleProduct, Long l3Key) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start::setUserRoleProductTypeSource");
		inputBean.getUserChannelKey().stream().forEach(item1->{
			com.bfsd.om.bean.UserRoleChannelTypeBean channel  =  new com.bfsd.om.bean.UserRoleChannelTypeBean();
			channel.setChanneltypekey(item1);
			userRoleProduct.getChannels().add(channel);
		});
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "END ::setUserRoleProductTypeSource ");
}

	private void setUserRoleProductTypeSource(UserProdMappingBean inputBean, UserRoleProductBean userRoleProduct,
			Long l3prodkey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start::setUserRoleProductTypeSource");
			com.bfsd.om.bean.UserRoleProductTypeBean utm  =  new com.bfsd.om.bean.UserRoleProductTypeBean();
			utm.setSubprodtypekey(l3prodkey.intValue());
			userRoleProduct.getUserRoleProductTypes().add(utm);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "END ::setUserRoleProductTypeSource "+l3prodkey);
	}

	@Override
	public List<UserProdMappingBean> getOMUserMappingDetails(long userRoleProdKey, HttpHeaders headers) {
		UserRoleProductBean userRoleProductBean;
		List<UserProdMappingBean> userProuctMappingBeans = new ArrayList<>();
		userRoleProductBean = omMasterDataPluginMapper.findUserRoleProduct(null, null, null, userRoleProdKey,
				headers);
		if (userRoleProductBean == null) {
			throw new BFLBusinessException("UMS-038", env.getProperty("UMS-038"));
		}
		mapResponseForOm(userRoleProdKey, userRoleProductBean, userProuctMappingBeans);
		return userProuctMappingBeans;
	}

	@Override
	public List<UserProdMappingBean> getOMInsuranceUserMappingDetails(long userRoleProdKey, HttpHeaders headers) {
		UserRoleProductBean userRoleProductBean;
		List<UserProdMappingBean> userProuctMappingBeans = new ArrayList<>();
		userRoleProductBean = oMMasterDataInsurancePluginMapper.findUserRoleProduct(null, null, null, userRoleProdKey,
				headers);
		if (userRoleProductBean == null) {
			throw new BFLBusinessException("UMS-038", env.getProperty("UMS-038"));
		}
		mapResponseForOm(userRoleProdKey, userRoleProductBean, userProuctMappingBeans);
		return userProuctMappingBeans;
	}
	
     public boolean deleteUserMappingForOMInsurance(long userRoleProdKey,HttpHeaders headers) {
		
		boolean isDeleted = false;
		UserRoleProductBean userRoleProductBean = oMMasterDataInsurancePluginMapper.findUserRoleProduct(null, null,
				null, userRoleProdKey, headers);
		if (null != userRoleProductBean) {

			UserRoleL3 userRole = new UserRoleL3();
			
			userRole = (UserRoleL3) entityManager.createQuery(QRY_GET_USERROLE)
					.setParameter("userroleKey", userRoleProductBean.getUserrolekey()).getSingleResult();

			if (userRole.getUserRoleProducts().size() == 1) {
				// This is the last mapping of user so delete userRole also.
				userRole.setIsactive(0);
			}
			boolean successFlag = oMMasterDataInsurancePluginMapper.updateUserRoleProduct(userRoleProdKey, headers);
			if (userMgmtProdDao.saveUserMapping(userRole) != null && successFlag == true) {

				isDeleted = true;
			}

		}
		return isDeleted;
	
}
	
	public boolean deleteUserMappingForOMCredit(long userRoleProdKey, HttpHeaders headers) {

		boolean isDeleted = false;
		UserRoleProductBean userRoleProductBean = omMasterDataPluginMapper.findUserRoleProduct(null, null,
				null, userRoleProdKey, headers);
		if (null != userRoleProductBean) {

			UserRoleL3 userRole = new UserRoleL3();
			userRole = (UserRoleL3) entityManager.createQuery(QRY_GET_USERROLE)
					.setParameter("userroleKey", userRoleProductBean.getUserrolekey()).getSingleResult();

			if (userRole.getUserRoleProducts().size() == 1) {
				// This is the last mapping of user so delete userRole also.
				userRole.setIsactive(0);
			}
			boolean successFlag = omMasterDataPluginMapper.updateUserRoleProduct(userRoleProdKey, headers);
			if (userMgmtProdDao.saveUserMapping(userRole) != null && successFlag == true) {

				isDeleted = true;
			}

		}
		return isDeleted;

	}
	
	private void mapUserRoleProductFieldsForInsurance(UserProdMappingBean inputBean, UserRoleProductBean userRoleProduct) {
		userRoleProduct.setSubprodkey(inputBean.getProdCatKey());
		userRoleProduct.setProdCatKey(inputBean.getProdCatKey());
		userRoleProduct.setSuperViosrRole(inputBean.getSupervisorRoleProdKey());

		setUserRoleOmLocations(inputBean, userRoleProduct);
		//setUserRoleUtmSource(inputBean, userRoleProduct);
		setUserRoleChannelType(inputBean, userRoleProduct,null);
		setUserRoleOmPincodes(inputBean, userRoleProduct);
		userRoleProduct.setCreditlimit(inputBean.getCreditLimit() != null ? inputBean.getCreditLimit() : null);
		userRoleProduct.setPricinglimit(inputBean.getPricinglimit() != null ? inputBean.getPricinglimit() : null);
		
		
}
	private void setUserRoleOmProdTypesForInsurance(UserProdMappingBean inputBean, UserRoleProductBean userRoleProduct) {

		List<UserRoleProductTypeBean> existingObjs = userRoleProduct.getUserRoleProductTypes();
		List<Long> inputKeys = inputBean.getL3ProdKeys();
		List<UserRoleProductTypeBean> deleteList = new ArrayList<>();

		for (UserRoleProductTypeBean obj : existingObjs) {
			if (!inputKeys.contains(obj.getSubprodtypekey())) {
				deleteList.add(obj);
			} else {
				inputKeys.remove(inputKeys.indexOf(obj.getSubprodtypekey()));
			}
		}
		// Set UserRoleProductTypes
		for (Long key : inputKeys) {
			UserRoleProductTypeBean usrpt = new UserRoleProductTypeBean();
			// usrpt.setLstupdatedt(UserManagementUtility.getCurrentDateTimeStamp());
			usrpt.setSubprodtypekey(key.intValue());
			usrpt.setIsactive(new BigDecimal(1));
			existingObjs.add(usrpt);
		}
		for (UserRoleProductTypeBean obj : deleteList) {
			existingObjs.remove(obj);
		}
		userRoleProduct.setUserRoleProductTypes(existingObjs);
	}
	
	private void mapUserRoleProductWhenUserProdKeyNotZeroForInsurance(UserProdMappingBean inputBean, UserRoleL3 userRole,
			UserRoleProductBean userRoleProduct) {
		userRoleProduct.setUserrolekey(userRole.getUserrolekey());
		userRoleProduct.setIsactive(new BigDecimal(1));
		userRoleProduct.setLstupdateby(String.valueOf(upb.getUserRoleKey()));
		userRoleProduct.setProdmastkey(inputBean.getProdMastKey());
		userRoleProduct.setSubprodkey(inputBean.getLoanProdKey());
		setUserRoleOmProdTypesForInsurance(inputBean, userRoleProduct);
	}
	
	private UserRoleL3 bfsdRoleMasterRoleKeyMismatchWithInputRoleKeyForInsurance(UserProdMappingBean inputBean, long rolekey) {
		UserRoleL3 userRole;
		UserRoleL3 deactiveUserRole;
		// In case of update mapping- Role changed
		userRole = userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), inputBean.getRoleKey());

		deactiveUserRole = userMgmtProdDao.fetchUserRole(inputBean.getUserKey(), rolekey);
		if (deactiveUserRole != null) {
			//deactiveUserRole.setIsactive(0);
			//userMgmtProdDao.saveUserMapping(deactiveUserRole);
		}
		if (userRole == null) {
			userRole = proceedWithUserRoleNotFound(inputBean);
		}
		return userRole;
	}
	

}
