package com.bajaj.bfsd.usermanagement.bean;

import java.util.List;

public class UserGetRecordResponceBean {

	private String employeeId;
	private String firstName;
	private String lastName;
	private String designation;
	private String emailId;
	private String mobileNumber;
	private String creditLimit;
	private boolean statusIfExist;
	private long employeeKey;

	public long getEmployeeKey() {
		return employeeKey;
	}

	public void setEmployeeKey(long employeeKey) {
		this.employeeKey = employeeKey;
	}

	private List<UserGetRoleResponceBean> empRoleList;

	public boolean getStatusIfExist() {
		return statusIfExist;
	}

	public void setStatusIfExist(boolean statusIfExist) {
		this.statusIfExist = statusIfExist;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(String creditLimit) {
		this.creditLimit = creditLimit;
	}

	public List<UserGetRoleResponceBean> getEmpRoleList() {
		return empRoleList;
	}

	public void setEmpRoleList(List<UserGetRoleResponceBean> empRoleList) {
		this.empRoleList = empRoleList;
	}

	@Override
	public String toString() {
		return "UserGetRecordResponceBean [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", designation=" + designation + ", emailId=" + emailId + ", mobileNumber=" + mobileNumber
				+ ", creditLimit=" + creditLimit + ", statusIfExist=" + statusIfExist + ", empRoleList=" + empRoleList
				+ "]";
	}

}
