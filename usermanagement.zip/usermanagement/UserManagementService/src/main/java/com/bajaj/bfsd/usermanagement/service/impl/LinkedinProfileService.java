package com.bajaj.bfsd.usermanagement.service.impl;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.MapperFactory;
import com.bajaj.bfsd.usermanagement.bean.LinkedinProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileSaveRequest;
import com.bajaj.bfsd.usermanagement.dao.UserProfileDao;
import com.bajaj.bfsd.usermanagement.deserializer.LinkedinResponseDeserializer;
import com.bajaj.bfsd.usermanagement.service.UserProfileService;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

@Service
public class LinkedinProfileService implements UserProfileService{
	
	private static final String THIS_CLASS = LinkedinProfileService.class.getSimpleName();
	
	@Autowired
    private BFLLoggerUtil logger;
	
	@Autowired
	@Qualifier("linkedin")
	private UserProfileDao linkedinDao;
	
	
	@Override
	@Transactional
	public void saveUserProfile(UserProfileSaveRequest profileSaveRequest) {
		
		LinkedinProfileBean linkedinProfile;
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfile - Linkedin - started");
		
		String profileJson = profileSaveRequest.getProfileJson();
		
		ObjectMapper mapper = MapperFactory.getInstance();
		SimpleModule module = new SimpleModule();
		module.addDeserializer(LinkedinProfileBean.class, new LinkedinResponseDeserializer());
		mapper.registerModule(module);
		
		try {
			linkedinProfile = mapper.readValue(profileSaveRequest.getProfileJson(),LinkedinProfileBean.class);
		} catch (IOException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Unable to parse linkedin profile json - "+profileJson+
						"\n Exception - "+e);
			throw new BFLTechnicalException("UMS-011", e);
		}
		
		linkedinDao.saveProfile(linkedinProfile, profileSaveRequest.getUserKey(), profileJson);
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfile - Linkedin - completed");
	}

	@Override
	public UserProfileBean getUserProfile(long userKey) {
		
		return linkedinDao.getUserProfile(userKey);
		
	}

}
