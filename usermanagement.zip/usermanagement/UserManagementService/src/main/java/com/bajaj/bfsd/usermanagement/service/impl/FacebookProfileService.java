package com.bajaj.bfsd.usermanagement.service.impl;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.FacebookProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserProfileSaveRequest;
import com.bajaj.bfsd.usermanagement.dao.UserProfileDao;
import com.bajaj.bfsd.usermanagement.deserializer.FacebookResponseDeserializer;
import com.bajaj.bfsd.usermanagement.service.UserProfileService;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

@Service
public class FacebookProfileService implements UserProfileService{

	private static final String THIS_CLASS = FacebookProfileBean.class.getSimpleName();
	
	@Autowired
    private BFLLoggerUtil logger;
	
	@Autowired
	@Qualifier("facebook")
	private UserProfileDao facebookDao;
		
	@Override
	@Transactional
	public void saveUserProfile(UserProfileSaveRequest profileSaveRequest) {
		
		FacebookProfileBean facebookProfileBean;
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfile - started");
		
		String profileJson = profileSaveRequest.getProfileJson();
		
		ObjectMapper mapper = new ObjectMapper();
		SimpleModule module = new SimpleModule();
		module.addDeserializer(FacebookProfileBean.class, new FacebookResponseDeserializer());
		mapper.registerModule(module);
		
		try {
			facebookProfileBean = mapper.readValue(profileSaveRequest.getProfileJson(),FacebookProfileBean.class);
		} catch (IOException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Unable to parse facebook profile json - "+profileJson+
						"\n Exception - "+e);
			throw new BFLTechnicalException("UMS-011", e);
		}
		
		facebookDao.saveProfile(facebookProfileBean, profileSaveRequest.getUserKey(), profileJson);
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfile - completed");
	}

	@Override
	public UserProfileBean getUserProfile(long userKey) {
		
		return facebookDao.getUserProfile(userKey);
		
	}

}
