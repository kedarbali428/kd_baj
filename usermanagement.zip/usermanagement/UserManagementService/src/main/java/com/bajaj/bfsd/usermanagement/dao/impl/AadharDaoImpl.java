package com.bajaj.bfsd.usermanagement.dao.impl;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.AadharProfileBean;
import com.bajaj.bfsd.usermanagement.bean.UserAddress;
import com.bajaj.bfsd.usermanagement.bean.UserEmail;
import com.bajaj.bfsd.usermanagement.bean.UserPhone;
import com.bajaj.bfsd.usermanagement.bean.UserProfileBean;
import com.bajaj.bfsd.usermanagement.dao.UserProfileDao;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserProfileAadhaar;
import com.bajaj.bfsd.usermanagement.model.UserProfileAadhaarAddress;
import com.bajaj.bfsd.usermanagement.model.UserProfileAadhaarEmail;
import com.bajaj.bfsd.usermanagement.model.UserProfileAadhaarPhone;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.bfsd.usermanagement.util.UserManagementUtility;
import com.bfl.common.exceptions.BFLBusinessException;

@Repository("aadhar")
public class AadharDaoImpl implements UserProfileDao{

private static final String THIS_CLASS = AadharDaoImpl.class.getName();
	
	@Autowired
	EntityManager entityManager;
	
	@Autowired
    private BFLLoggerUtil logger;
	
	@Autowired
	private Environment env;
	@Override
	public void saveProfile(UserProfileBean profileBean, long userKey, String profileResponse) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfile - Aadhar - started");
		Timestamp timestamp = UserManagementUtility.getCurrentTimeStamp();
		
		AadharProfileBean aadharProfile = (AadharProfileBean)profileBean;
		
		Query query = entityManager
				.createNativeQuery("delete from USER_PROFILE_AADHAAR where userkey = :userKey");
		
		query.setParameter("userKey", userKey);
		query.executeUpdate();
		
		UserProfileAadhaar userProfileAadhaar = new UserProfileAadhaar();
		
		BfsdUser user = new BfsdUser();
		user.setUserkey(userKey);
		
		userProfileAadhaar.setAadhaarnumber(aadharProfile.getProfileId());
		userProfileAadhaar.setBfsdUser(user);
		userProfileAadhaar.setFirstname(aadharProfile.getFirstName());
		userProfileAadhaar.setMiddlename(aadharProfile.getMiddleName());
		userProfileAadhaar.setLastname(aadharProfile.getLastName());
		userProfileAadhaar.setDateofbirth(aadharProfile.getDob());
		userProfileAadhaar.setResponsedoc(profileResponse);
		userProfileAadhaar.setLstupdateby(UserManagementConstants.UPDATED_BY_SYSTEM);
		userProfileAadhaar.setLstupdatedt(timestamp);
		
		entityManager.persist(userProfileAadhaar);
		
		List<UserEmail> userEmails = aadharProfile.getEmailDetails();
		UserProfileAadhaarEmail aadharEmail;
		for(UserEmail email : userEmails){
			aadharEmail = new UserProfileAadhaarEmail();
			aadharEmail.setEmailaddress(email.getEmailAddress());
			aadharEmail.setEmailtype(email.getType());
			aadharEmail.setLstupdateby(UserManagementConstants.UPDATED_BY_SYSTEM);
			aadharEmail.setLstupdatedt(timestamp);
			aadharEmail.setUserProfileAadhaar(userProfileAadhaar);
			
			entityManager.persist(aadharEmail);
		}
		
		List<UserAddress> userAddress = aadharProfile.getAddressDetails();
		UserProfileAadhaarAddress aadharAddress;
		for(UserAddress address : userAddress){
			aadharAddress = new UserProfileAadhaarAddress();
			aadharAddress.setAddrline1(address.getAddrLine1());
			aadharAddress.setAddrline2(address.getAddrLine2());
			aadharAddress.setAddrtype(address.getAddrType());
			aadharAddress.setCity(address.getCity());
			aadharAddress.setCountry(address.getCountry());
			aadharAddress.setState(address.getState());
			aadharAddress.setPincode(Long.parseLong(address.getPin()));
			aadharAddress.setLstupdateby(UserManagementConstants.UPDATED_BY_SYSTEM);
			aadharAddress.setLstupdatedt(timestamp);
			aadharAddress.setUserProfileAadhaar(userProfileAadhaar);
			
			entityManager.persist(aadharAddress);
		}
		
		List<UserPhone> userPhones = aadharProfile.getPhoneNumberDetails();
		UserProfileAadhaarPhone aadharPhone;
		for(UserPhone phone : userPhones){
			aadharPhone = new UserProfileAadhaarPhone();
			aadharPhone.setAreacode(phone.getAreaCode());
			aadharPhone.setCountrycode(phone.getCountryCode());
			aadharPhone.setPhnnumber(phone.getPhnNumber());
			aadharPhone.setPhntype(phone.getPhnType());
			aadharPhone.setLstupdateby(UserManagementConstants.UPDATED_BY_SYSTEM);
			aadharPhone.setLstupdatedt(timestamp);
			aadharPhone.setUserProfileAadhaar(userProfileAadhaar);
			
			entityManager.persist(aadharPhone);
		}
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfile - Aadhar - completed");
	}

	@Override
	public UserProfileBean getUserProfile(long userKey) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "getUserProfile - Aadhar - start");
		
		UserProfileAadhaar aadharEntity;

		AadharProfileBean aadharProfileBean;
		
		Query query = entityManager
				.createQuery("from UserProfileAadhaar where bfsdUser.userkey = :userKey and bfsdUser.isactive=1");
	
		query.setParameter("userKey", userKey);
		
		try {
			aadharEntity = (UserProfileAadhaar) query.getSingleResult();
		}
		catch (NoResultException ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "getUserProfile - Aadhar - No record found for the user - "+userKey+
						"\n Exception - "+ex);
			return new AadharProfileBean();
		}
		catch (NonUniqueResultException ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "getUserProfile - Aadhar - Multiple records found for the user - "+userKey+
						"\n Exception - "+ex);
			throw new BFLBusinessException("UMS-013", env.getProperty("UMS-013"));
		}
		
		aadharProfileBean = new AadharProfileBean();
		
		aadharProfileBean.setFirstName(aadharEntity.getFirstname());
		aadharProfileBean.setMiddleName(aadharEntity.getMiddlename());
		aadharProfileBean.setLastName(aadharEntity.getLastname());
		aadharProfileBean.setProfileId(aadharEntity.getAadhaarnumber().toString());
		aadharProfileBean.setProfileJson(aadharEntity.getResponsedoc());
		aadharProfileBean.setDob(aadharEntity.getDateofbirth());
		aadharProfileBean.setAadharNumber(aadharEntity.getAadhaarnumber().toString());
				
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "getUserProfile - Aadhar - end");
		return aadharProfileBean;
	}

}
