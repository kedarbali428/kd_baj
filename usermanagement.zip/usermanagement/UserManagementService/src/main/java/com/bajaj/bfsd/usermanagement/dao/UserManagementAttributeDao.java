package com.bajaj.bfsd.usermanagement.dao;

import com.bajaj.bfsd.usermanagement.bean.UserInfoBean;

public interface UserManagementAttributeDao {
	void getUserProfileDetails(UserInfoBean userInfoBean, long userKey);
	
	void getUserAdditionalAttributeDetails(UserInfoBean userInfoBean, long userKey);
	
	void getEmployeeTypeAndStatusChangeReason(UserInfoBean userInfoBean, long userKey);
	
}