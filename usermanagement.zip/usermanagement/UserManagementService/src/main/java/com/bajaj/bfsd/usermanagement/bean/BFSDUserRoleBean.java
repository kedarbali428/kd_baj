package com.bajaj.bfsd.usermanagement.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

public class BFSDUserRoleBean {
	private long userrolekey;

	private BigDecimal creditlimit;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal parentuser;

	private long userKey;

	private BfsdUserDetails userDetails;
	
	private BFSDRoleMasterBean roledetails;

	public long getUserrolekey() {
		return userrolekey;
	}

	public void setUserrolekey(long userrolekey) {
		this.userrolekey = userrolekey;
	}

	public BigDecimal getCreditlimit() {
		return creditlimit;
	}

	public void setCreditlimit(BigDecimal creditlimit) {
		this.creditlimit = creditlimit;
	}

	public BigDecimal getIsactive() {
		return isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getParentuser() {
		return parentuser;
	}

	public void setParentuser(BigDecimal parentuser) {
		this.parentuser = parentuser;
	}

	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}

	public BFSDRoleMasterBean getRoledetails() {
		return roledetails;
	}

	public void setRoledetails(BFSDRoleMasterBean roledetails) {
		this.roledetails = roledetails;
	}

	public BfsdUserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(BfsdUserDetails userDetails) {
		this.userDetails = userDetails;
	}
	
}
