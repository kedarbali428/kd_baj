package com.bajaj.bfsd.usermanagement.service;

import java.util.List;

import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserProdMappingBean;
import com.bajaj.bfsd.usermanagement.model.ProductMaster;

public interface UserMgmtProdService {

	public long saveUserMapping(UserProdMappingBean userMappingBean, HttpHeaders headers);

	public List<SupervisorBean> getUserSuperVisor(long roleKey,long prodKey, long subProdKey);
	
	public List<LocationBean> getSuperVisorLocations(long userRoleProdKey);

	public List<ChannelBean> getSuperVisorChannels(long userRoleProdKey);

	public UserConfigurationBean getUserDetails(UserConfigurationBean userConfig, HttpHeaders headers);

	public List<UserProdMappingBean> getUserMappingDetails(long userRoleProdKey, HttpHeaders headers);

	public boolean deleteUserMapping(long userRoleProdKey,long prodMastKey, HttpHeaders headers);
	
	public <T> long savePrincipalUserMapping(UserProdMappingBean userMappingBean,HttpHeaders headers);

	public List<ProductMaster> getAllMasterProducts();

	public UserConfigurationBean getAdditionalUserDetails(UserConfigurationBean userConfig);
	
	public long saveUserMappingForOMInsurance(UserProdMappingBean userMappingBean, HttpHeaders headers);

	public List<SupervisorBean> getUserSuperVisorForOmInsurance(long roleKey, long prodKey, String OMSubProdKeys,
			HttpHeaders headers);

	public List<SupervisorBean> getUserSuperVisorForOmCredit(long roleKey, long prodKey, String subProdKey,
			HttpHeaders headers);

	public List<SupervisorBean> getOMUserSuperVisorForOmCredit(long roleKey, long prodKey, String oMSubProdKeys,
			HttpHeaders headers);

	public List<UserProdMappingBean> getOMUserMappingDetails(long userRoleProdKey, HttpHeaders headers);

	public List<UserProdMappingBean> getOMInsuranceUserMappingDetails(long userRoleProdKey, HttpHeaders headers);
	

}