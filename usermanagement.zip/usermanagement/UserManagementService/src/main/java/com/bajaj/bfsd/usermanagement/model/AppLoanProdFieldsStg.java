package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the APP_LOAN_PROD_FIELDS_STG database table.
 * 
 */
@Entity
@Table(name="APP_LOAN_PROD_FIELDS_STG")
//@NamedQuery(name="AppLoanProdFieldsStg.findAll", query="SELECT a FROM AppLoanProdFieldsStg a")
public class AppLoanProdFieldsStg implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private Long dummyId;

	private BigDecimal fieldcd;

	private String fielddatatype;

	private String fieldinput;

	private String fieldname;

	private String fieldtype;

	private String sectionname;

	public BigDecimal getFieldcd() {
		return this.fieldcd;
	}

	public void setFieldcd(BigDecimal fieldcd) {
		this.fieldcd = fieldcd;
	}

	public String getFielddatatype() {
		return this.fielddatatype;
	}

	public void setFielddatatype(String fielddatatype) {
		this.fielddatatype = fielddatatype;
	}

	public String getFieldinput() {
		return this.fieldinput;
	}

	public void setFieldinput(String fieldinput) {
		this.fieldinput = fieldinput;
	}

	public String getFieldname() {
		return this.fieldname;
	}

	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}

	public String getFieldtype() {
		return this.fieldtype;
	}

	public void setFieldtype(String fieldtype) {
		this.fieldtype = fieldtype;
	}

	public String getSectionname() {
		return this.sectionname;
	}

	public void setSectionname(String sectionname) {
		this.sectionname = sectionname;
	}

}