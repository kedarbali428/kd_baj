package com.bajaj.bfsd.usermanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.usermanagement.model.BfsdUserV2;

@Repository
public interface BfsdUserV2Repository extends JpaRepository<BfsdUserV2, Long> {

	List<BfsdUserV2> findByUserkeyAndUsertypeNot(Long userKey, Long usertype);// For VAPT

	@Query(value = "select u from BfsdUserV2 u JOIN FETCH u.userApplicants a "
			+ "INNER JOIN a.applicant b where u.userkey = :userKey and u.usertype = :userType "
			+ "and u.isactive = 1 and b.apltisactive = 1")
	BfsdUserV2 findByUserkeyAndUsertype(@Param("userKey")Long userKey, @Param("userType")long userType);

}