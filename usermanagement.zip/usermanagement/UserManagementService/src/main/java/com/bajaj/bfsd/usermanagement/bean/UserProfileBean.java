package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
/**
 * This is a bean class for User profile details from sources e.g.
 * Facebook, Twitter, Aadhaar etc.
 *
 * @author 582602
 * 
 * Version      BugId           UserId           Date            Description
 * 1.0                          Upwan G          17/05/2017      Initial Version
 */
public class UserProfileBean implements Serializable{
	
	private static final long serialVersionUID = 4944459161182847764L;

	@JsonProperty("journeySourceKey")
	private String profileId;
	
	private String firstName;
	
	private String middleName;
	
	private String lastName;
	
	private List<UserEmail> emailDetails;
	
	private List<UserAddress> addressDetails;
	
	private List<UserPhone> phoneNumberDetails;
	
	private String profileJson;
	

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getProfileJson() {
		return profileJson;
	}

	public void setProfileJson(String profileJson) {
		this.profileJson = profileJson;
	}

	public List<UserEmail> getEmailDetails() {
		return emailDetails;
	}

	public void setEmailDetails(List<UserEmail> emailDetails) {
		this.emailDetails = emailDetails;
	}
	
	public List<UserPhone> getPhoneNumberDetails() {
		return phoneNumberDetails;
	}

	public void setPhoneNumberDetails(List<UserPhone> phoneNumberDetails) {
		this.phoneNumberDetails = phoneNumberDetails;
	}

	public List<UserAddress> getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(List<UserAddress> addressDetails) {
		this.addressDetails = addressDetails;
	}
	
}