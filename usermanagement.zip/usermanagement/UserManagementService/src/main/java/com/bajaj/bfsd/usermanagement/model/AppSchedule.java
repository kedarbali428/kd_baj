package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the APP_SCHEDULE database table.
 * 
 */
@Entity
@Table(name="APP_SCHEDULE")
//@NamedQuery(name="AppSchedule.findAll", query="SELECT a FROM AppSchedule a")
public class AppSchedule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long schedulekey;

	private BigDecimal apltaddrkey;

	private BigDecimal applicationkey;

	private BigDecimal initiatedby;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal phonenumber;

	private BigDecimal placeofvisit;

	private String reasonforappnt;

	@Temporal(TemporalType.DATE)
	private Date schdldate;

	private String schdlendtm;

	private BigDecimal schdlstatus;

	private Timestamp schdlstatustm;

	private String schdlstrttm;

	//bi-directional many-to-one association to AppAppointment
	@OneToMany(mappedBy="appSchedule")
	private List<AppAppointment> appAppointments;

	public long getSchedulekey() {
		return this.schedulekey;
	}

	public void setSchedulekey(long schedulekey) {
		this.schedulekey = schedulekey;
	}

	public BigDecimal getApltaddrkey() {
		return this.apltaddrkey;
	}

	public void setApltaddrkey(BigDecimal apltaddrkey) {
		this.apltaddrkey = apltaddrkey;
	}

	public BigDecimal getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(BigDecimal applicationkey) {
		this.applicationkey = applicationkey;
	}

	public BigDecimal getInitiatedby() {
		return this.initiatedby;
	}

	public void setInitiatedby(BigDecimal initiatedby) {
		this.initiatedby = initiatedby;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getPhonenumber() {
		return this.phonenumber;
	}

	public void setPhonenumber(BigDecimal phonenumber) {
		this.phonenumber = phonenumber;
	}

	public BigDecimal getPlaceofvisit() {
		return this.placeofvisit;
	}

	public void setPlaceofvisit(BigDecimal placeofvisit) {
		this.placeofvisit = placeofvisit;
	}

	public String getReasonforappnt() {
		return this.reasonforappnt;
	}

	public void setReasonforappnt(String reasonforappnt) {
		this.reasonforappnt = reasonforappnt;
	}

	public Date getSchdldate() {
		return this.schdldate;
	}

	public void setSchdldate(Date schdldate) {
		this.schdldate = schdldate;
	}

	public String getSchdlendtm() {
		return this.schdlendtm;
	}

	public void setSchdlendtm(String schdlendtm) {
		this.schdlendtm = schdlendtm;
	}

	public BigDecimal getSchdlstatus() {
		return this.schdlstatus;
	}

	public void setSchdlstatus(BigDecimal schdlstatus) {
		this.schdlstatus = schdlstatus;
	}

	public Timestamp getSchdlstatustm() {
		return this.schdlstatustm;
	}

	public void setSchdlstatustm(Timestamp schdlstatustm) {
		this.schdlstatustm = schdlstatustm;
	}

	public String getSchdlstrttm() {
		return this.schdlstrttm;
	}

	public void setSchdlstrttm(String schdlstrttm) {
		this.schdlstrttm = schdlstrttm;
	}

	public List<AppAppointment> getAppAppointments() {
		return this.appAppointments;
	}

	public void setAppAppointments(List<AppAppointment> appAppointments) {
		this.appAppointments = appAppointments;
	}

	public AppAppointment addAppAppointment(AppAppointment appAppointment) {
		getAppAppointments().add(appAppointment);
		appAppointment.setAppSchedule(this);

		return appAppointment;
	}

	public AppAppointment removeAppAppointment(AppAppointment appAppointment) {
		getAppAppointments().remove(appAppointment);
		appAppointment.setAppSchedule(null);

		return appAppointment;
	}

}