package com.bajaj.bfsd.usermanagement.bean;

public class UserLoginAccountResponse {
	long userId;
	short loginFailCount;
	boolean failedRequest;
	short userType;
	String loginId;
	short accountStatus;
	
	public short getUserType() {
		return userType;
	}
	public void setUserType(short userType) {
		this.userType = userType;
	}
	
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public short getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(short accountStatus) {
		this.accountStatus = accountStatus;
	}	
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public short getLoginFailCount() {
		return loginFailCount;
	}
	public void setLoginFailCount(short loginFailCount) {
		this.loginFailCount = loginFailCount;
	}
	public boolean isFailedRequest() {
		return failedRequest;
	}
	public void setFailedRequest(boolean failedRequest) {
		this.failedRequest = failedRequest;
	}
}
