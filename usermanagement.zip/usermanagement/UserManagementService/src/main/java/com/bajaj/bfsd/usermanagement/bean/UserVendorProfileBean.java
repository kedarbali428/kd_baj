package com.bajaj.bfsd.usermanagement.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "firstName", "lastName", "companyName", "emailId" })
public class UserVendorProfileBean {

	private long vendorProfileKey;

	private String address;

	private Date associationDt;

	private Long associationType;

	private Long city;

	private Long companyId;

	private String companyName;

	private String contactPersonName;

	private String emailId;

	private String firstName;

	private String gst;

	private Long isActive;

	private String landline;

	private String lastName;

	private String middleName;

	private String mobileNo;

	private String pan;

	private String parentUserEmailId;

	private String partnerKey;

	private String serviceKey;

	private long userKey;

	private String employeeType;

	private String pincode;

	private String cityName;

	private Long principalUserId;
	
	private String principalUserName;
	
	private List<UserMapping> empRoleList = new ArrayList<>();

	public long getVendorProfileKey() {
		return vendorProfileKey;
	}

	public void setVendorProfileKey(long vendorProfileKey) {
		this.vendorProfileKey = vendorProfileKey;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getAssociationDt() {
		return associationDt;
	}

	public void setAssociationDt(Date associationDt) {
		this.associationDt = associationDt;
	}

	public Long getAssociationType() {
		return associationType;
	}

	public void setAssociationType(Long associationType) {
		this.associationType = associationType;
	}

	public Long getCity() {
		return city;
	}

	public void setCity(Long city) {
		this.city = city;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGst() {
		return gst;
	}

	public void setGst(String gst) {
		this.gst = gst;
	}

	public Long getIsActive() {
		return isActive;
	}

	public void setIsActive(Long isActive) {
		this.isActive = isActive;
	}

	public String getLandline() {
		return landline;
	}

	public void setLandline(String landline) {
		this.landline = landline;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getParentUserEmailId() {
		return parentUserEmailId;
	}

	public void setParentUserEmailId(String parentUserEmailId) {
		this.parentUserEmailId = parentUserEmailId;
	}

	public String getPartnerKey() {
		return partnerKey;
	}

	public void setPartnerKey(String partnerKey) {
		this.partnerKey = partnerKey;
	}

	public String getServiceKey() {
		return serviceKey;
	}

	public void setServiceKey(String serviceKey) {
		this.serviceKey = serviceKey;
	}

	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public List<UserMapping> getEmpRoleList() {
		return empRoleList;
	}

	public void setEmpRoleList(List<UserMapping> empRoleList) {
		this.empRoleList = empRoleList;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Long getPrincipalUserId() {
		return principalUserId;
	}

	public void setPrincipalUserId(Long principalUserId) {
		this.principalUserId = principalUserId;
	}

	public String getPrincipalUserName() {
		return principalUserName;
	}

	public void setPrincipalUserName(String principalUserName) {
		this.principalUserName = principalUserName;
	}

}