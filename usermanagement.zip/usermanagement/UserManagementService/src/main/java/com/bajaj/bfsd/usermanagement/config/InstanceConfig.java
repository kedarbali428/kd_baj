package com.bajaj.bfsd.usermanagement.config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bajaj.bfsd.usermanagement.service.UserMgmtIntegration;
import com.bajaj.bfsd.usermanagement.service.impl.UserMgmtServiceBFLImpl;
import com.bajaj.bfsd.usermanagement.service.impl.UserMgmtServiceCoreImpl;

	@Configuration
	public class InstanceConfig {

		private static final Logger LOGGER = LoggerFactory.getLogger(InstanceConfig.class);
		UserMgmtIntegration usermgmtIntegration;
		
		
		@Bean (name = "userMgmtIntService")
		@ConditionalOnProperty(name = "INSTANCE_TYPE",havingValue = "BFDL")
		public UserMgmtIntegration createBFDLCustomerService() {
			LOGGER.info("Validated BFDL instance.");
			return new UserMgmtServiceCoreImpl();
		}
		
		@Bean (name = "userMgmtIntService")
		@ConditionalOnProperty(name = "INSTANCE_TYPE",havingValue = "BFL")
		public UserMgmtIntegration createBFLCustomerService() {
			LOGGER.info("Validated BFL instance.");
			return new UserMgmtServiceBFLImpl(usermgmtIntegration);
		}
		

}
