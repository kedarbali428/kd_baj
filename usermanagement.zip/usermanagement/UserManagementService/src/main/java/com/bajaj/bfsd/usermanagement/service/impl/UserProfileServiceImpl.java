package com.bajaj.bfsd.usermanagement.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.model.Applicant;
import com.bajaj.bfsd.usermanagement.model.ApplicantPhoneNumber;
import com.bajaj.bfsd.usermanagement.model.ApplicantPhoneNumberV2;
import com.bajaj.bfsd.usermanagement.model.ApplicantV2;
import com.bajaj.bfsd.usermanagement.model.ApplicationApplicant;
import com.bajaj.bfsd.usermanagement.model.ApplicationApplicantV2;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.BfsdUserV2;
import com.bajaj.bfsd.usermanagement.model.UserApplicant;
import com.bajaj.bfsd.usermanagement.model.UserApplicantV2;
import com.bajaj.bfsd.usermanagement.model.UserProfileEntity;
import com.bajaj.bfsd.usermanagement.repository.ApplicationApplicantRepository;
import com.bajaj.bfsd.usermanagement.repository.BfsdUserRepository;
import com.bajaj.bfsd.usermanagement.repository.BfsdUserV2Repository;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
public class UserProfileServiceImpl {
	
	@Autowired
	BFLLoggerUtil logger;
	
	@Autowired
	BfsdUserV2Repository bfsdUserRepositoryV2;

	@Autowired
	BfsdUserRepository bfsdUserRepository;
	
	@Autowired
	ApplicationApplicantRepository applicationApplicantRepository;
	
	@Value("${LIMITONE}")
	private String limitOne;
	
	@Value("${LIMITTWO}")
	private String limitTwo;
	
	private static final String THIS_CLASS = UserProfileServiceImpl.class.getCanonicalName();

	public UserProfileEntity loadUserProfileV2(long userId) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside loadUserProfile method" + userId);
		UserProfileEntity userProfileEntity = new UserProfileEntity();

		List<String> mobileNumbersTemp = new ArrayList<String>();
		List<Long> applicationIdsTemp = new ArrayList<Long>();
		List<Long> applicationApplicantIdsTemp = new ArrayList<Long>();
		List<String> appProcessIdsTemp = new ArrayList<String>();
		List<Long> applicantIdsTemp = new ArrayList<Long>();
		List<String> dateOfBirthsTemp = new ArrayList<String>();
		
		try {
			//Getting List of Users from DB for userid and userType<>0
			List<BfsdUserV2> bfsdusers = bfsdUserRepositoryV2.findByUserkeyAndUsertypeNot(userId, 0L);

			for (BfsdUserV2 bfsdUser : bfsdusers) {
				
				List<UserApplicantV2> userApplicants = bfsdUser.getUserApplicants();

				for (UserApplicantV2 userApplicant : userApplicants) {

					applicantIdsTemp.add(userApplicant.getApplicantkey());

					ApplicantV2 applicant = userApplicant.getApplicant();

					userProfileEntity.setApplicantId(applicant.getApplicantkey());

					// Setting Date Of Birth
					if (applicant.getApltdateofbirth() != null) {
						if (StringUtils.isBlank(userProfileEntity.getDateOfBirth())) {
							userProfileEntity.setDateOfBirth(applicant.getApltdateofbirth().toString());
						}
						dateOfBirthsTemp.add(applicant.getApltdateofbirth().toString());
					}

					// Setting Mobile Number in UserProfileBean
					for (ApplicantPhoneNumberV2 applicantPhoneNumber : applicant.getApplicantPhoneNumbers()) {
						mobileNumbersTemp.add(applicantPhoneNumber.getApltphnumnumber());

						if (StringUtils.isBlank(userProfileEntity.getMobileNumber()))
							userProfileEntity.setMobileNumber(applicantPhoneNumber.getApltphnumnumber());
					}

					// Setting ApplicationIds, AppApplicantIds, AddProcessIds
					for (ApplicationApplicantV2 applicationApplicant : applicant.getApplicationApplicants()) {
						applicationApplicantIdsTemp.add(applicationApplicant.getAppapltkey());
						applicationIdsTemp.add(applicationApplicant.getApplicationkey());
						appProcessIdsTemp.add(applicationApplicant.getApplication().getAppprocessidentifier());
					}
				}
			}
			
			long limitOneL=Long.parseLong(limitOne);
			long limitTwoL=Long.parseLong(limitTwo);

			userProfileEntity.setApplicationApplicantIds(applicationApplicantIdsTemp.stream().distinct().limit(limitTwoL)
					.filter(x -> x != null).collect(Collectors.toList()));

			userProfileEntity.setApplicationIds(applicationIdsTemp.stream().distinct().limit(limitTwoL).filter(x -> x != null)
					.collect(Collectors.toList()));

			userProfileEntity.setAppProcessIds(appProcessIdsTemp.stream().distinct().limit(limitTwoL).filter(x -> x != null)
					.collect(Collectors.toList()));

			userProfileEntity.setApplicantIds(
					applicantIdsTemp.stream().distinct().limit(limitOneL).filter(x -> x != null).collect(Collectors.toList()));

			userProfileEntity.setMobileNumbers(mobileNumbersTemp.stream().distinct().limit(limitOneL).filter(x -> x != null)
					.collect(Collectors.toList()));

			userProfileEntity.setDateOfBirths(
					dateOfBirthsTemp.stream().distinct().limit(limitOneL).filter(x -> x != null).collect(Collectors.toList()));

		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error in loadUserProfile method" , e);
			throw new BFLTechnicalException("UMS-019", "Error creating Profile Bean");
		}

		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exit from loadUserProfile method");
		return userProfileEntity;

	}

	public UserProfileEntity loadUserProfile(long userId) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside loadUserProfile method"+userId);
		UserProfileEntity userProfileEntity = null;
		try{
			BfsdUser bfsdUser = bfsdUserRepository.findOne(userId);
			if(null != bfsdUser){
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Loading BFSD User against userkey--"+userId);
				UserApplicant userApplicant = bfsdUser.getUserApplicants().get(0);
				if(null!=userApplicant)
				{
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "userApplicant is not null--"+userApplicant.getApplicantkey());
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "userApplicant is not null--"+userApplicant.getBfsdUser().getUserkey());
				List<ApplicationApplicant> appApplicantList = applicationApplicantRepository.findByApplicant(userApplicant.getApplicantkey().longValue());
				if(null != appApplicantList && !appApplicantList.isEmpty()){
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "appApplicantList size is--"+appApplicantList.size());
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "get applicationApplicant for applicantkey--"+userApplicant.getApplicantkey());
					//Assuming fectching the isactive profile for application applicant which is should be one.
					ApplicationApplicant applicationApplicant = appApplicantList.get(0);
					Applicant applicant = applicationApplicant.getApplicant();
					String appltPhoneNumber = null;
					List<ApplicantPhoneNumber> applicantPhoneNumbers= applicant.getApplicantPhoneNumbers();
					for(ApplicantPhoneNumber applicantPhoneNumber:applicantPhoneNumbers ){
						if(BigDecimal.ONE.equals(applicantPhoneNumber.getApltphnumisactive()) && "MOBILE".equalsIgnoreCase(applicantPhoneNumber.getPhoneNumberType().getPhonetypecode()) ){
							appltPhoneNumber = applicantPhoneNumber.getApltphnumnumber();
							logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "get applicantPhoneNumber.getApltphnumnumber()--"+appltPhoneNumber);
						}
					}
					userProfileEntity = new UserProfileEntity();
					userProfileEntity.setApplicantId(userApplicant.getApplicantkey().longValue());
					userProfileEntity.setDateOfBirth(applicant.getApltdateofbirth().toString());
					userProfileEntity.setMobileNumber(appltPhoneNumber);

					List<Long> applicationIds= new ArrayList<Long>();
					List<Long> applicationApplicantIds= new ArrayList<Long>();
					List<String> appProcessIds = new ArrayList<String>();
					for (ApplicationApplicant applicationApplicant2 : appApplicantList) {
						applicationApplicantIds.add(applicationApplicant2.getAppapltkey());
						if(null!=applicationApplicant2.getApplication()) {
							applicationIds.add(applicationApplicant2.getApplication().getApplicationkey());
							if(null!=applicationApplicant2.getApplication().getAppprocessidentifier())
								appProcessIds.add(applicationApplicant2.getApplication().getAppprocessidentifier());
						}
					}
					userProfileEntity.setApplicationApplicantIds(applicationApplicantIds);
					userProfileEntity.setApplicationIds(applicationIds);
					userProfileEntity.setAppProcessIds(appProcessIds);
				  }
				}else{
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "UserApplicant is null for userId =="+userId);
				}
				
			}else{
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "BfsdUser is null for userId =="+userId);
			}
		}catch(Exception e){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exception from loadUserProfile method"+e);
		}
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exit from loadUserProfile method");
		return userProfileEntity;
	}

}