package com.bajaj.bfsd.usermanagement.openmarket.plugin.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.bajaj.bfdl.om.insurance.impl.EpBauInsuranceClientImpl;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bfsd.om.bean.UserRoleProductBean;

@Component
public class OMMasterDataInsurancePluginMapper {
	
	private static final String CLASS_NAME = OMMasterDataInsurancePluginMapper.class.getName();

	@Autowired
	private EpBauInsuranceClientImpl epBauInsuranceClientImpl;
	
	@Autowired
	BFLLoggerUtil logger;
	
	
	public UserRoleProductBean findUserRoleProduct(Long l1ProdKey, Long l3ProdKey,Long  userRoleKey, Long userRoleProdKey,HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "Start::findUserRoleProduct");
		userRoleProdKey	 = (null ==userRoleProdKey)?0:userRoleProdKey;
		l3ProdKey = null == l3ProdKey?0:l3ProdKey;
		l1ProdKey =null == l1ProdKey?0:userRoleKey;
		userRoleKey = (null  == userRoleKey)?0:userRoleKey;
		UserRoleProductBean bean =   epBauInsuranceClientImpl.getUserRoleProduct(l1ProdKey, l3ProdKey, userRoleKey, userRoleProdKey, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "End::findUserRoleProduct");
		return bean;
	}

	public UserRoleProductBean saveUserRoleMapping(UserRoleProductBean userRoleProduct,HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "Start::saveUserRoleMapping");
		UserRoleProductBean bean =   epBauInsuranceClientImpl.saveUserRoleProduct(userRoleProduct, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "End::saveUserRoleMapping");
		return bean;
	}
	public List<SupervisorBean> getUserSuperVisor(long roleKey, long prodKey, String OMSubProdKeys, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "Start::getUserSuperVisor");
		 List<com.bfsd.om.bean.SupervisorBean> superVisorList =   epBauInsuranceClientImpl.getUserSuperVisorName(roleKey, prodKey, OMSubProdKeys, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "End::getUserSuperVisor");
		return mapOmToBauSupervisorBean(superVisorList);
	}
	private List<SupervisorBean> mapOmToBauSupervisorBean(List<com.bfsd.om.bean.SupervisorBean> superVisorList) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "Start::mapOmToBauSupervisorBean");
		List<SupervisorBean> superVList = new ArrayList<>();
		for(com.bfsd.om.bean.SupervisorBean supervisorBean : superVisorList) {
			SupervisorBean supervisor = new SupervisorBean();
			supervisor.setId(supervisorBean.getId());
			supervisor.setName(supervisorBean.getName());
			supervisor.setUserRoleKey(supervisorBean.getUserRoleKey());
			supervisor.setUserRoleProdKey(supervisorBean.getUserRoleProdKey());
			superVList.add(supervisor);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "End::mapOmToBauSupervisorBean");
		return superVList;
		
	}
	
     public boolean updateUserRoleProduct(Long userRoleProdKey,HttpHeaders headers ) {
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "Start::findUserRoleProduct");
		boolean successFlag =   epBauInsuranceClientImpl.updateUserRoleProduct(userRoleProdKey, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER, "End::findUserRoleProduct");
		return successFlag;
		
	}
     
}
