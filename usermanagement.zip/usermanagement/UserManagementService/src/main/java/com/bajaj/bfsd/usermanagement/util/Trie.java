package com.bajaj.bfsd.usermanagement.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Trie<Response> {
	private TrieNode root;
	Map<String, List<Response>> mapData = new HashMap<>();

	public Trie() {
		this.root = new TrieNode(' ');
	}

	public void insert(String expresion, Response responseObj) {
		for (String token : expresion.split(" ")) {
			if (mapData.containsKey(token.toLowerCase())) {
				createMapEntryForNewExpresion(responseObj, token.toLowerCase());
			} else {
				insertToExistingEntry(responseObj, token.toLowerCase());
			}
			root.insert(token.toLowerCase());

		}

	}

	private void insertToExistingEntry(Response responseObj, String token) {
		List<Response> trieResponse = new ArrayList<Response>();
		trieResponse.add(responseObj);
		mapData.put(token, trieResponse);
	}

	private void createMapEntryForNewExpresion(Response responseObj, String token) {
		List<Response> existingList = mapData.get(token);
		existingList.add(responseObj);
		mapData.put(token, existingList);
	}

	public List<Response> search(String prefix) {

		List<Response> res = new ArrayList<Response>();
		TrieNode lastNode = root;
		StringBuffer curr = new StringBuffer();
		for (char c : prefix.toLowerCase().toCharArray()) {
			lastNode = lastNode.children.get(c);
			if (lastNode == null)
				return res;
			curr.append(c);
		}
		res = helper(lastNode, res, curr);
		return res;

	}

	private List<Response> helper(TrieNode node, List<Response> res, StringBuffer prefix) {

		if (node == null) {
			return res;
		}

		if (node.isEndOfWord) {
			res.addAll(mapData.get(prefix.toString()));
			return res;
		}
		for (Character ch : node.children.keySet()) {
			res = helper(node.children.get(ch), res, prefix.append(node.children.get(ch).data));
			prefix.setLength(prefix.length() - 1);
		}
		return res;
	}

	public boolean isEmpty() {
		return root == null;
	}

}