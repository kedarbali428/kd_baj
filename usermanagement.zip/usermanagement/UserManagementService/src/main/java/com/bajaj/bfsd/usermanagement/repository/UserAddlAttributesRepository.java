package com.bajaj.bfsd.usermanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bajaj.bfsd.usermanagement.model.UserAddlAttributes;

public interface UserAddlAttributesRepository extends JpaRepository<UserAddlAttributes, Long>{

	public List<UserAddlAttributes> findByAttrrkeyAndIsactive(Long attrrkey,Integer isactive);
}
