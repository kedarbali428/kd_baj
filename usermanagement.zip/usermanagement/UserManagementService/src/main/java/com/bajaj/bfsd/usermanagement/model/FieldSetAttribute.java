package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the FIELD_SET_ATTRIBUTES database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_ATTRIBUTES")
//@NamedQuery(name="FieldSetAttribute.findAll", query="SELECT f FROM FieldSetAttribute f")
public class FieldSetAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long fieldkey;

	private BigDecimal dfltvwsummaryorder;

	private BigDecimal fieldcd;

	private BigDecimal fielddatatype;

	private String fieldname;

	private BigDecimal fieldtype;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String physicalcolumn;

	private String physicaltable;

	private BigDecimal setfilterflg;

	private BigDecimal sourcecd;

	

	//bi-directional many-to-one association to FieldSetSection
	@ManyToOne
	@JoinColumn(name="SECTIONKEY")
	private FieldSetSection fieldSetSection;

	//bi-directional many-to-one association to FieldSetRole
	@OneToMany(mappedBy="fieldSetAttribute")
	private List<FieldSetRole> fieldSetRoles;

	public long getFieldkey() {
		return this.fieldkey;
	}

	public void setFieldkey(long fieldkey) {
		this.fieldkey = fieldkey;
	}

	public BigDecimal getDfltvwsummaryorder() {
		return this.dfltvwsummaryorder;
	}

	public void setDfltvwsummaryorder(BigDecimal dfltvwsummaryorder) {
		this.dfltvwsummaryorder = dfltvwsummaryorder;
	}

	public BigDecimal getFieldcd() {
		return this.fieldcd;
	}

	public void setFieldcd(BigDecimal fieldcd) {
		this.fieldcd = fieldcd;
	}

	public BigDecimal getFielddatatype() {
		return this.fielddatatype;
	}

	public void setFielddatatype(BigDecimal fielddatatype) {
		this.fielddatatype = fielddatatype;
	}

	public String getFieldname() {
		return this.fieldname;
	}

	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}

	public BigDecimal getFieldtype() {
		return this.fieldtype;
	}

	public void setFieldtype(BigDecimal fieldtype) {
		this.fieldtype = fieldtype;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getPhysicalcolumn() {
		return this.physicalcolumn;
	}

	public void setPhysicalcolumn(String physicalcolumn) {
		this.physicalcolumn = physicalcolumn;
	}

	public String getPhysicaltable() {
		return this.physicaltable;
	}

	public void setPhysicaltable(String physicaltable) {
		this.physicaltable = physicaltable;
	}

	public BigDecimal getSetfilterflg() {
		return this.setfilterflg;
	}

	public void setSetfilterflg(BigDecimal setfilterflg) {
		this.setfilterflg = setfilterflg;
	}

	public BigDecimal getSourcecd() {
		return this.sourcecd;
	}

	public void setSourcecd(BigDecimal sourcecd) {
		this.sourcecd = sourcecd;
	}

	
	public FieldSetSection getFieldSetSection() {
		return this.fieldSetSection;
	}

	public void setFieldSetSection(FieldSetSection fieldSetSection) {
		this.fieldSetSection = fieldSetSection;
	}

	public List<FieldSetRole> getFieldSetRoles() {
		return this.fieldSetRoles;
	}

	public void setFieldSetRoles(List<FieldSetRole> fieldSetRoles) {
		this.fieldSetRoles = fieldSetRoles;
	}

	public FieldSetRole addFieldSetRole(FieldSetRole fieldSetRole) {
		getFieldSetRoles().add(fieldSetRole);
		fieldSetRole.setFieldSetAttribute(this);

		return fieldSetRole;
	}

	public FieldSetRole removeFieldSetRole(FieldSetRole fieldSetRole) {
		getFieldSetRoles().remove(fieldSetRole);
		fieldSetRole.setFieldSetAttribute(null);

		return fieldSetRole;
	}

}