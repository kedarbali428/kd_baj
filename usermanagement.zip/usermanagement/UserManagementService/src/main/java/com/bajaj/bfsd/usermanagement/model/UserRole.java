package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the USER_ROLES database table.
 * 
 */
@Entity
@Table(name = "USER_ROLES")
@NamedQueries({
		@NamedQuery(name = "UserRole.findByEmployeeAndRole", query = "SELECT u FROM UserRole u where u.isactive = 1 "
				+ "and u.bfsduser.userkey =:userKey " + "and u.bfsdRoleMaster.rolekey =:roleKey"),
		@NamedQuery(name = "UserRole.DeactivateUserRole", query = "UPDATE UserRole u set u.isactive = 0 "
				+ "WHERE u.isactive = 1 " + "AND u.bfsduser.userkey =:userKey "
				+ "AND u.bfsdRoleMaster.rolekey =:roleKey"),
		@NamedQuery(name = "UserRole.findById", query = "SELECT u FROM UserRole u where u.userrolekey =:userrolekey and u.isactive =1"),
//		@NamedQuery(name = "UserRole.findAll", query = "SELECT u FROM UserRole u WHERE u.isactive=1") 
		})
public class UserRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userrolekey;

	private BigDecimal creditlimit;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal parentuser;

	// private BigDecimal userkey;

	@ManyToOne
	@JoinColumn(name = "USERKEY")
	private BfsdUser bfsduser;

	public BfsdUser getBfsduser() {
		return bfsduser;
	}

	public void setBfsduser(BfsdUser bfsduser) {
		this.bfsduser = bfsduser;
	}

	// bi-directional many-to-one association to AppUserView
	@OneToMany(mappedBy = "userRole")
	private List<AppUserView> appUserViews;

	// bi-directional many-to-one association to CaseAssignment
	@OneToMany(mappedBy = "userRole")
	private List<CaseAssignment> caseAssignments;

	// bi-directional many-to-one association to UserNotification
	@OneToMany(mappedBy = "userRole")
	private List<UserNotification> userNotifications;

	// bi-directional many-to-one association to BfsdRoleMaster
	@ManyToOne
	@JoinColumn(name = "ROLEKEY")
	private BfsdRoleMaster bfsdRoleMaster;

	// bi-directional many-to-one association to UserRoleChannel
	@OneToMany(mappedBy = "userRole", cascade = CascadeType.ALL)
	private List<UserRoleChannel> userRoleChannels;

	// bi-directional many-to-one association to UserRoleLocation
	@OneToMany(mappedBy = "userRole", cascade = CascadeType.ALL)
	private List<UserRoleLocation> userRoleLocations;

	// bi-directional many-to-one association to UserRolePinCode
	@OneToMany(mappedBy = "userRole", cascade = CascadeType.ALL)
	private List<UserRolePinCode> userRolePinCodes;

	// bi-directional many-to-one association to UserRoleProduct
	@OneToMany(mappedBy = "userRole", cascade = CascadeType.ALL)
	private List<UserRoleProduct> userRoleProducts;


	public long getUserrolekey() {
		return this.userrolekey;
	}

	public void setUserrolekey(long userrolekey) {
		this.userrolekey = userrolekey;
	}

	public BigDecimal getCreditlimit() {
		return this.creditlimit;
	}

	public void setCreditlimit(BigDecimal creditlimit) {
		this.creditlimit = creditlimit;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getParentuser() {
		return this.parentuser;
	}

	public void setParentuser(BigDecimal parentuser) {
		this.parentuser = parentuser;
	}

	/*
	 * public BigDecimal getUserkey() { return this.userkey; }
	 * 
	 * public void setUserkey(BigDecimal userkey) { this.userkey = userkey; }
	 */

	public List<AppUserView> getAppUserViews() {
		return this.appUserViews;
	}

	public void setAppUserViews(List<AppUserView> appUserViews) {
		this.appUserViews = appUserViews;
	}

	public AppUserView addAppUserView(AppUserView appUserView) {
		getAppUserViews().add(appUserView);
		appUserView.setUserRole(this);

		return appUserView;
	}

	public AppUserView removeAppUserView(AppUserView appUserView) {
		getAppUserViews().remove(appUserView);
		appUserView.setUserRole(null);

		return appUserView;
	}

	public List<CaseAssignment> getCaseAssignments() {
		return this.caseAssignments;
	}

	public void setCaseAssignments(List<CaseAssignment> caseAssignments) {
		this.caseAssignments = caseAssignments;
	}

	public CaseAssignment addCaseAssignment(CaseAssignment caseAssignment) {
		getCaseAssignments().add(caseAssignment);
		caseAssignment.setUserRole(this);

		return caseAssignment;
	}

	public CaseAssignment removeCaseAssignment(CaseAssignment caseAssignment) {
		getCaseAssignments().remove(caseAssignment);
		caseAssignment.setUserRole(null);

		return caseAssignment;
	}

	public List<UserNotification> getUserNotifications() {
		return this.userNotifications;
	}

	public void setUserNotifications(List<UserNotification> userNotifications) {
		this.userNotifications = userNotifications;
	}

	public UserNotification addUserNotification(UserNotification userNotification) {
		getUserNotifications().add(userNotification);
		userNotification.setUserRole(this);

		return userNotification;
	}

	public UserNotification removeUserNotification(UserNotification userNotification) {
		getUserNotifications().remove(userNotification);
		userNotification.setUserRole(null);

		return userNotification;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return this.bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

	public List<UserRoleChannel> getUserRoleChannels() {
		return this.userRoleChannels;
	}

	public void setUserRoleChannels(List<UserRoleChannel> userRoleChannels) {
		this.userRoleChannels = userRoleChannels;
	}

	public UserRoleChannel addUserRoleChannel(UserRoleChannel userRoleChannel) {
		getUserRoleChannels().add(userRoleChannel);
		userRoleChannel.setUserRole(this);

		return userRoleChannel;
	}

	public UserRoleChannel removeUserRoleChannel(UserRoleChannel userRoleChannel) {
		getUserRoleChannels().remove(userRoleChannel);
		userRoleChannel.setUserRole(null);

		return userRoleChannel;
	}

	public List<UserRoleLocation> getUserRoleLocations() {
		return this.userRoleLocations;
	}

	public void setUserRoleLocations(List<UserRoleLocation> userRoleLocations) {
		this.userRoleLocations = userRoleLocations;
	}

	public UserRoleLocation addUserRoleLocation(UserRoleLocation userRoleLocation) {
		getUserRoleLocations().add(userRoleLocation);
		userRoleLocation.setUserRole(this);

		return userRoleLocation;
	}

	public UserRoleLocation removeUserRoleLocation(UserRoleLocation userRoleLocation) {
		getUserRoleLocations().remove(userRoleLocation);
		userRoleLocation.setUserRole(null);

		return userRoleLocation;
	}

	public List<UserRolePinCode> getUserRolePinCodes() {
		return this.userRolePinCodes;
	}

	public void setUserRolePinCodes(List<UserRolePinCode> userRolePinCodes) {
		this.userRolePinCodes = userRolePinCodes;
	}

	public UserRolePinCode addUserRolePinCode(UserRolePinCode userRolePinCode) {
		getUserRolePinCodes().add(userRolePinCode);
		userRolePinCode.setUserRole(this);

		return userRolePinCode;
	}

	public UserRolePinCode removeUserRolePinCode(UserRolePinCode userRolePinCode) {
		getUserRolePinCodes().remove(userRolePinCode);
		userRolePinCode.setUserRole(null);

		return userRolePinCode;
	}

	public List<UserRoleProduct> getUserRoleProducts() {
		return this.userRoleProducts;
	}

	public void setUserRoleProducts(List<UserRoleProduct> userRoleProducts) {
		this.userRoleProducts = userRoleProducts;
	}

	public UserRoleProduct addUserRoleProduct(UserRoleProduct userRoleProduct) {
		getUserRoleProducts().add(userRoleProduct);
		userRoleProduct.setUserRole(this);

		return userRoleProduct;
	}

	public UserRoleProduct removeUserRoleProduct(UserRoleProduct userRoleProduct) {
		getUserRoleProducts().remove(userRoleProduct);
		userRoleProduct.setUserRole(null);
		return userRoleProduct;
	}

//	public UserRoleProduct getUserRoleProduct() {
//		return userRoleProduct;
//	}
//
//	public void setUserRoleProduct(UserRoleProduct userRoleProduct) {
//		this.userRoleProduct = userRoleProduct;
//	}

}