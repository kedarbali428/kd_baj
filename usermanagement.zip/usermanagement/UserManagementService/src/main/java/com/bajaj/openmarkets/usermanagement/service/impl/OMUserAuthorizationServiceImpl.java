package com.bajaj.openmarkets.usermanagement.service.impl;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.usermanagement.model.ApplicantPhoneNumberV2;
import com.bajaj.bfsd.usermanagement.model.ApplicantV2;
import com.bajaj.bfsd.usermanagement.model.BfsdUserV2;
import com.bajaj.bfsd.usermanagement.model.PhoneNumberType;
import com.bajaj.bfsd.usermanagement.model.UserApplicantV2;
import com.bajaj.bfsd.usermanagement.repository.ApplicantPhoneNumberV2Repository;
import com.bajaj.bfsd.usermanagement.repository.BfsdUserV2Repository;
import com.bajaj.bfsd.usermanagement.util.UserManagementConstants;
import com.bajaj.openmarkets.usermanagement.bean.AuthorizationCodesRequest;
import com.bajaj.openmarkets.usermanagement.bean.AuthorizationCodesResponse;
import com.bajaj.openmarkets.usermanagement.bean.FederatedLoginRequest;
import com.bajaj.openmarkets.usermanagement.bean.ValidateTokenResponse;
import com.bajaj.openmarkets.usermanagement.exceptions.OMUserManagementException;
import com.bajaj.openmarkets.usermanagement.service.OMUserAuthorizationService;
import com.bajaj.openmarkets.usermanagement.util.TokenValidationUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class OMUserAuthorizationServiceImpl implements OMUserAuthorizationService {

	private static final String CLASS_NAME = OMUserAuthorizationServiceImpl.class.getCanonicalName();
	
	@Autowired
	private Environment env;
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Value("${app.bfdl.marketsapp.clientsecret}")
	private String bfdlMarketsClientSecret;
	
	@Value("${app.bfdl.marketsapp.clientId}")
	private String bfdlMarketsClientId;

	@Value("${api.authentication.federatedlogin.POST.url}")
	private String authenticationUrl;
	
	@Value("${api.tokenmanagement.validatetoken.GET.url}")
	private String validateTokenUrl;
		
	@Autowired
	private TokenValidationUtil tokenValidator;
	
	@Autowired
	@Qualifier("OMUserManagementRestTemplate")
	private RestTemplate restTemplate;
	
	@Autowired
	private BfsdUserV2Repository bfsdUserV2Repository;
	
	@Autowired 
	private ApplicantPhoneNumberV2Repository appltPhnNumV2Repository;
	
	@Override
	public AuthorizationCodesResponse getAuthorizationTokenCode(AuthorizationCodesRequest authorizationRequest,
			String authToken) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getAuthorizationTokenCode request: "+authorizationRequest); 
		try {
			AuthorizationCodesResponse codeResponse = null;
			ValidateTokenResponse validatedToken = tokenValidator.getValidatedToken(authToken);
			UserApplicantV2 applicantDetails = getApplicantDetails(validatedToken.getUserId(), authorizationRequest.getApplicantKey());
			boolean isVerified = verifyApplicantLoginDetails(applicantDetails, validatedToken.getLoginId());
			if(isVerified) {
				codeResponse = getAuthorizationCodes(authorizationRequest, validatedToken.getLoginId());
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getAuthorizationTokenCode response: "+codeResponse); 
			}else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "getAuthorizationTokenCode: Applicant details could not be verified"); 
				ErrorBean errors = new ErrorBean("UMS-103", env.getProperty("UMS-103"));
				throw new OMUserManagementException(HttpStatus.UNAUTHORIZED, errors);
			}
			return codeResponse;
		}catch(OMUserManagementException ex) {
			throw ex;
		}catch(Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured", e);
			ErrorBean errors = new ErrorBean("UMSA_000", env.getProperty("USMA_000"));
			throw new OMUserManagementException(HttpStatus.INTERNAL_SERVER_ERROR, errors);
		}
	}
	
	private UserApplicantV2 getApplicantDetails(Long userKey, Long applicantKey) {
		try {
			BfsdUserV2 applicantsByUserKey = bfsdUserV2Repository.findByUserkeyAndUsertype(userKey, UserManagementConstants.USERTYPE_CUSTOMER);
			UserApplicantV2 applicantDetail = null;
			for(UserApplicantV2 user: applicantsByUserKey.getUserApplicants() ) {
				if( applicantKey == user.getApplicantkey()) {
					applicantDetail = user;
					break;
				}
			}
			return applicantDetail;
		}catch(Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "getApplicantDetails: Applicant details does not exist"); 
			ErrorBean errors = new ErrorBean("UMS-103", env.getProperty("UMS-103"));
			throw new OMUserManagementException(HttpStatus.UNAUTHORIZED, errors);
		}
	}
	
	private boolean verifyApplicantLoginDetails(UserApplicantV2 applicantBean, String loginId) {
		try {
			boolean status = false;
			PhoneNumberType phoneType = new PhoneNumberType();
			phoneType.setPhonetypekey(UserManagementConstants.PHONETYPE_MOBILE);
			phoneType.setPhonetypecode(UserManagementConstants.PHONE_MOBILE_TYPE);
			ApplicantV2 applicant = applicantBean.getApplicant();
			List<ApplicantPhoneNumberV2> applicantPhoneNumbers = appltPhnNumV2Repository.
					findByApplicantkeyAndPhoneNumberTypeAndApltphnumisactive(applicant.getApplicantkey(),
							phoneType, (int)UserManagementConstants.ISACTIVE);	
			for(ApplicantPhoneNumberV2 phoneNumber: applicantPhoneNumbers) {
				if( loginId.equals(phoneNumber.getApltphnumnumber()) ){
					status = true;
					break;
				}
			}
			return status;
		}catch(Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "verifyApplicantDetails: Applicant details could not be verified"); 
			ErrorBean errors = new ErrorBean("UMS-103", env.getProperty("UMS-103"));
			throw new OMUserManagementException(HttpStatus.UNAUTHORIZED, errors);
		}
	}

	private AuthorizationCodesResponse getAuthorizationCodes(AuthorizationCodesRequest authorizationRequest, String mobile) throws JsonParseException, JsonMappingException, IOException {
		try {
			FederatedLoginRequest loginRequest = new FederatedLoginRequest();
			loginRequest.setAuthorizedClient(authorizationRequest.getAuthorizedClient());
			loginRequest.setClientId(authorizationRequest.getClientId());
			if(authorizationRequest.getClientId().equals(bfdlMarketsClientId)) {
				String clientSecret = new String(Base64.getDecoder().decode(bfdlMarketsClientSecret));
				loginRequest.setClientSecret(clientSecret);
			}
			loginRequest.setPartnerCustomerId(authorizationRequest.getApplicantKey().intValue());
			loginRequest.setCustomerFlag(1);
			loginRequest.setMobile(mobile);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getAuthorizationCodes request url: "+authenticationUrl);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getAuthorizationCodes request started with request body: "+loginRequest);
			HttpEntity<?> entity = new HttpEntity<>(loginRequest);
			AuthorizationCodesResponse federatedResponse = null;
			ResponseEntity<?> federatedAuthResponse = null;
		
			federatedAuthResponse = restTemplate.exchange(authenticationUrl, HttpMethod.POST, entity, String.class);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getAuthorizationCodes request ended with response body: "+federatedAuthResponse);
			if( null != federatedAuthResponse 
					&& null != federatedAuthResponse.getBody() && HttpStatus.OK == federatedAuthResponse.getStatusCode()) {
				ObjectMapper responseMapper = new ObjectMapper();
				JSONObject responseBean = new JSONObject(federatedAuthResponse.getBody().toString());
				federatedResponse = responseMapper.readValue(responseBean.get("payload").toString(), AuthorizationCodesResponse.class);
			}		
			return federatedResponse;
		}catch(Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "getAuthorizationCodes: excpetion occured ", e);
			ErrorBean errors = new ErrorBean("UMS-102", env.getProperty("UMS-102"));
			throw new OMUserManagementException(HttpStatus.UNAUTHORIZED, errors);

		}
	}
	

}
