package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * The persistent class for the SER_REQ_VIEW_SUMMARY_FIELDS database table.
 * 
 */
@Entity
@Table(name = "SER_REQ_VIEW_SUMMARY_FIELDS")
//@NamedQuery(name = "SerReqViewSummaryField.findAll", query = "SELECT s FROM SerReqViewSummaryField s")
public class SerReqViewSummaryField implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long viewfieldkey;

	private BigDecimal displayorder;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	// bi-directional many-to-one association to SerReqViewDefinition
	@ManyToOne
	@JoinColumn(name = "VIEWKEY")
	private SerReqViewDefinition serReqViewDefinition;

	// bi-directional many-to-one association to FieldSetAttribute
	@ManyToOne
	@JoinColumn(name = "FIELDKEY")
	private FieldSetAttribute fieldSetAttribute;
	

	public FieldSetAttribute getFieldSetAttribute() {
		return fieldSetAttribute;
	}

	public void setFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		this.fieldSetAttribute = fieldSetAttribute;
	}

	public long getViewfieldkey() {
		return this.viewfieldkey;
	}

	public void setViewfieldkey(long viewfieldkey) {
		this.viewfieldkey = viewfieldkey;
	}

	public BigDecimal getDisplayorder() {
		return this.displayorder;
	}

	public void setDisplayorder(BigDecimal displayorder) {
		this.displayorder = displayorder;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public SerReqViewDefinition getSerReqViewDefinition() {
		return this.serReqViewDefinition;
	}

	public void setSerReqViewDefinition(SerReqViewDefinition serReqViewDefinition) {
		this.serReqViewDefinition = serReqViewDefinition;
	}

}