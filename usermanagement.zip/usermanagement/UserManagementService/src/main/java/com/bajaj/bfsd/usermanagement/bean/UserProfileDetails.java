package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;

public class UserProfileDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long userRoleKey;
	
	private String fullName;
	public Long getUserRoleKey() {
		return userRoleKey;
	}
	public void setUserRoleKey(Long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	

}
