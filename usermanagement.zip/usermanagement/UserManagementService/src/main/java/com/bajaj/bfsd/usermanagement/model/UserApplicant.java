package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the USER_APPLICANT database table.
 * 
 */
@Entity
@Table(name="USER_APPLICANT")
//@NamedQuery(name="UserApplicant.findAll", query="SELECT u FROM UserApplicant u")
public class UserApplicant implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long userapplicantkey;

	private java.math.BigDecimal applicantkey;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="USERKEY")
	private BfsdUser bfsdUser;

	public long getUserapplicantkey() {
		return this.userapplicantkey;
	}

	public void setUserapplicantkey(long userapplicantkey) {
		this.userapplicantkey = userapplicantkey;
	}

	public java.math.BigDecimal getApplicantkey() {
		return this.applicantkey;
	}

	public void setApplicantkey(java.math.BigDecimal applicantkey) {
		this.applicantkey = applicantkey;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

}