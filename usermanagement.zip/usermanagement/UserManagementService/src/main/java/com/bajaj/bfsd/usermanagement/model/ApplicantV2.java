package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the APPLICANTS database table.
 * 
 */
@Entity
@Table(name = "APPLICANTS")
//@NamedQuery(name="Applicant.findAll", query="SELECT a FROM Applicant a")
public class ApplicantV2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "APPLICANTKEY", insertable = false, updatable = false)
	private long applicantkey;

	@Temporal(TemporalType.DATE)
	private Date apltdateofbirth;

	@OneToMany
	@JoinColumn(name = "APPLICANTKEY")
	private List<ApplicationApplicantV2> applicationApplicants;

	@OneToMany
	@JoinColumn(name = "APPLICANTKEY")
	private List<ApplicantPhoneNumberV2> applicantPhoneNumbers;

	private Integer apltisactive;
	
	public Date getApltdateofbirth() {
		return apltdateofbirth;
	}

	public void setApltdateofbirth(Date apltdateofbirth) {
		this.apltdateofbirth = apltdateofbirth;
	}

	public List<ApplicationApplicantV2> getApplicationApplicants() {
		return applicationApplicants;
	}

	public void setApplicationApplicants(List<ApplicationApplicantV2> applicationApplicants) {
		this.applicationApplicants = applicationApplicants;
	}

	public List<ApplicantPhoneNumberV2> getApplicantPhoneNumbers() {
		return applicantPhoneNumbers;
	}

	public void setApplicantPhoneNumbers(List<ApplicantPhoneNumberV2> applicantPhoneNumbers) {
		this.applicantPhoneNumbers = applicantPhoneNumbers;
	}

	public long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public Integer getApltisactive() {
		return apltisactive;
	}

	public void setApltisactive(Integer apltisactive) {
		this.apltisactive = apltisactive;
	}

}