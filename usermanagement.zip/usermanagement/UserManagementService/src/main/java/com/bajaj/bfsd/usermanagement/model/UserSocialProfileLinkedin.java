package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Where;


/**
 * The persistent class for the USER_SOCIAL_PROFILE_LINKEDIN database table.
 * 
 */
@Entity
@Table(name="USER_SOCIAL_PROFILE_LINKEDIN")
//@NamedQuery(name="UserSocialProfileLinkedin.findAll", query="SELECT u FROM UserSocialProfileLinkedin u")
public class UserSocialProfileLinkedin implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false, precision=20)
	private long usrsocprflnkkey;

	@Column(length=100)
	private String firstname;

	@Column(length=100)
	private String formattedname;

	@Column(length=100)
	private String formattedphoneticname;

	@Column(length=200)
	private String headline;

	@Column(length=5)
	private String industrycode;

	@Column(length=50)
	private String lastname;

	@Column(length=5)
	private String locationcode;

	@Column(length=100)
	private String locationname;

	@Column(length=20)
	private String lstupdateby;

	private Timestamp lstupdatedt;

	@Column(length=50)
	private String middlename;

	@Column(precision=5)
	private long noofconnections;

	@Column(length=100)
	private String phoneticfname;

	@Column(length=50)
	private String phoneticlname;

	@Column(length=100)
	private String pictureurl;

	@Column(length=100)
	private String primaryemailid;

	@Column(length=100)
	private String profileid;

	@Column(length=1000)
	private String profilesummary;

	@Column(length=100)
	private String publicprofileurl;

	@Lob
	private String responsedoc;

	@Column(length=100)
	private String secondaryemailid;

	@Column(length=500)
	private String specialties;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="USERKEY", nullable=false)
	private BfsdUser bfsdUser;

	//bi-directional many-to-one association to UserSocPrfLnkdinPosition
	@OneToMany(mappedBy="userSocialProfileLinkedin")
	@Where(clause = " iscurrent = 1")
	private List<UserSocPrfLnkdinPosition> userSocPrfLnkdinPositions;

	public long getUsrsocprflnkkey() {
		return this.usrsocprflnkkey;
	}

	public void setUsrsocprflnkkey(long usrsocprflnkkey) {
		this.usrsocprflnkkey = usrsocprflnkkey;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getFormattedname() {
		return this.formattedname;
	}

	public void setFormattedname(String formattedname) {
		this.formattedname = formattedname;
	}

	public String getFormattedphoneticname() {
		return this.formattedphoneticname;
	}

	public void setFormattedphoneticname(String formattedphoneticname) {
		this.formattedphoneticname = formattedphoneticname;
	}

	public String getHeadline() {
		return this.headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public String getIndustrycode() {
		return this.industrycode;
	}

	public void setIndustrycode(String industrycode) {
		this.industrycode = industrycode;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getLocationcode() {
		return this.locationcode;
	}

	public void setLocationcode(String locationcode) {
		this.locationcode = locationcode;
	}

	public String getLocationname() {
		return this.locationname;
	}

	public void setLocationname(String locationname) {
		this.locationname = locationname;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getMiddlename() {
		return this.middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public long getNoofconnections() {
		return this.noofconnections;
	}

	public void setNoofconnections(long noofconnections) {
		this.noofconnections = noofconnections;
	}

	public String getPhoneticfname() {
		return this.phoneticfname;
	}

	public void setPhoneticfname(String phoneticfname) {
		this.phoneticfname = phoneticfname;
	}

	public String getPhoneticlname() {
		return this.phoneticlname;
	}

	public void setPhoneticlname(String phoneticlname) {
		this.phoneticlname = phoneticlname;
	}

	public String getPictureurl() {
		return this.pictureurl;
	}

	public void setPictureurl(String pictureurl) {
		this.pictureurl = pictureurl;
	}

	public String getPrimaryemailid() {
		return this.primaryemailid;
	}

	public void setPrimaryemailid(String primaryemailid) {
		this.primaryemailid = primaryemailid;
	}

	public String getProfileid() {
		return this.profileid;
	}

	public void setProfileid(String profileid) {
		this.profileid = profileid;
	}

	public String getProfilesummary() {
		return this.profilesummary;
	}

	public void setProfilesummary(String profilesummary) {
		this.profilesummary = profilesummary;
	}

	public String getPublicprofileurl() {
		return this.publicprofileurl;
	}

	public void setPublicprofileurl(String publicprofileurl) {
		this.publicprofileurl = publicprofileurl;
	}

	public String getResponsedoc() {
		return this.responsedoc;
	}

	public void setResponsedoc(String responsedoc) {
		this.responsedoc = responsedoc;
	}

	public String getSecondaryemailid() {
		return this.secondaryemailid;
	}

	public void setSecondaryemailid(String secondaryemailid) {
		this.secondaryemailid = secondaryemailid;
	}

	public String getSpecialties() {
		return this.specialties;
	}

	public void setSpecialties(String specialties) {
		this.specialties = specialties;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

	public List<UserSocPrfLnkdinPosition> getUserSocPrfLnkdinPositions() {
		return this.userSocPrfLnkdinPositions;
	}

	public void setUserSocPrfLnkdinPositions(List<UserSocPrfLnkdinPosition> userSocPrfLnkdinPositions) {
		this.userSocPrfLnkdinPositions = userSocPrfLnkdinPositions;
	}

	public UserSocPrfLnkdinPosition addUserSocPrfLnkdinPosition(UserSocPrfLnkdinPosition userSocPrfLnkdinPosition) {
		getUserSocPrfLnkdinPositions().add(userSocPrfLnkdinPosition);
		userSocPrfLnkdinPosition.setUserSocialProfileLinkedin(this);

		return userSocPrfLnkdinPosition;
	}

	public UserSocPrfLnkdinPosition removeUserSocPrfLnkdinPosition(UserSocPrfLnkdinPosition userSocPrfLnkdinPosition) {
		getUserSocPrfLnkdinPositions().remove(userSocPrfLnkdinPosition);
		userSocPrfLnkdinPosition.setUserSocialProfileLinkedin(null);

		return userSocPrfLnkdinPosition;
	}

}