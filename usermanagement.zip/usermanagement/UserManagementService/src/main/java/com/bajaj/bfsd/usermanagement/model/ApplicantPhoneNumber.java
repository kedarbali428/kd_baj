package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.DynamicUpdate;


/**
 * The persistent class for the APPLICANT_PHONE_NUMBERS database table.
 * 
 */
@Entity
@Table(name = "APPLICANT_PHONE_NUMBERS")
@DynamicUpdate
//@NamedQuery(name = "ApplicantPhoneNumber.findAll", query = "SELECT a FROM ApplicantPhoneNumber a")
public class ApplicantPhoneNumber implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long apltphnumkey;

	private String apltphnumareacode;

	private String apltphnumcountrycode;

	@Temporal(TemporalType.DATE)
	private Date apltphnumenddt;

	private BigDecimal apltphnumisactive;

	private BigDecimal apltphnumisdndactive;

	private BigDecimal apltphnumispreferred;

	private BigDecimal apltphnumisverified;

	private String apltphnumlstupdateby;

	private Timestamp apltphnumlstupdatedt;

	private String apltphnumnumber;

	@Temporal(TemporalType.DATE)
	private Date apltphnumstartdt;

	private Timestamp apltphnumverifydt;

	//bi-directional many-to-one association to Applicant
	@ManyToOne
	@JoinColumn(name="APPLICANTKEY")
	private Applicant applicant;

	//bi-directional many-to-one association to PhoneNumberType
	@ManyToOne
	@JoinColumn(name="PHONETYPEKEY")
	private PhoneNumberType phoneNumberType;

	//bi-directional many-to-one association to ApplicationApltAttribute
	@OneToMany(mappedBy="applicantPhoneNumber")
	private List<ApplicationApltAttribute> applicationApltAttributes;
	
	//bi-directional many-to-one association to ApplicationApltPhoneNumber
	@OneToMany(mappedBy="applicantPhoneNumber")
	private List<ApplicationApltPhoneNumber> applicationApltPhoneNumbers;

	public ApplicantPhoneNumber() {
	}

	public Long getApltphnumkey() {
		return this.apltphnumkey;
	}

	public void setApltphnumkey(Long apltphnumkey) {
		this.apltphnumkey = apltphnumkey;
	}

	public String getApltphnumareacode() {
		return this.apltphnumareacode;
	}

	public void setApltphnumareacode(String apltphnumareacode) {
		this.apltphnumareacode = apltphnumareacode;
	}

	public String getApltphnumcountrycode() {
		return this.apltphnumcountrycode;
	}

	public void setApltphnumcountrycode(String apltphnumcountrycode) {
		this.apltphnumcountrycode = apltphnumcountrycode;
	}

	public Date getApltphnumenddt() {
		return this.apltphnumenddt;
	}

	public void setApltphnumenddt(Date apltphnumenddt) {
		this.apltphnumenddt = apltphnumenddt;
	}

	public BigDecimal getApltphnumisactive() {
		return this.apltphnumisactive;
	}

	public void setApltphnumisactive(BigDecimal apltphnumisactive) {
		this.apltphnumisactive = apltphnumisactive;
	}

	public BigDecimal getApltphnumisdndactive() {
		return this.apltphnumisdndactive;
	}

	public void setApltphnumisdndactive(BigDecimal apltphnumisdndactive) {
		this.apltphnumisdndactive = apltphnumisdndactive;
	}

	public BigDecimal getApltphnumispreferred() {
		return this.apltphnumispreferred;
	}

	public void setApltphnumispreferred(BigDecimal apltphnumispreferred) {
		this.apltphnumispreferred = apltphnumispreferred;
	}

	public BigDecimal getApltphnumisverified() {
		return this.apltphnumisverified;
	}

	public void setApltphnumisverified(BigDecimal apltphnumisverified) {
		this.apltphnumisverified = apltphnumisverified;
	}

	public String getApltphnumlstupdateby() {
		return this.apltphnumlstupdateby;
	}

	public void setApltphnumlstupdateby(String apltphnumlstupdateby) {
		this.apltphnumlstupdateby = apltphnumlstupdateby;
	}

	public Timestamp getApltphnumlstupdatedt() {
		return this.apltphnumlstupdatedt;
	}

	public void setApltphnumlstupdatedt(Timestamp apltphnumlstupdatedt) {
		this.apltphnumlstupdatedt = apltphnumlstupdatedt;
	}

	public String getApltphnumnumber() {
		return this.apltphnumnumber;
	}

	public void setApltphnumnumber(String apltphnumnumber) {
		this.apltphnumnumber = apltphnumnumber;
	}

	public Date getApltphnumstartdt() {
		return this.apltphnumstartdt;
	}

	public void setApltphnumstartdt(Date apltphnumstartdt) {
		this.apltphnumstartdt = apltphnumstartdt;
	}

	public Timestamp getApltphnumverifydt() {
		return this.apltphnumverifydt;
	}

	public void setApltphnumverifydt(Timestamp apltphnumverifydt) {
		this.apltphnumverifydt = apltphnumverifydt;
	}

	public Applicant getApplicant() {
		return this.applicant;
	}

	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}

	public PhoneNumberType getPhoneNumberType() {
		return this.phoneNumberType;
	}

	public void setPhoneNumberType(PhoneNumberType phoneNumberType) {
		this.phoneNumberType = phoneNumberType;
	}

	public List<ApplicationApltAttribute> getApplicationApltAttributes() {
		return this.applicationApltAttributes;
	}

	public void setApplicationApltAttributes(List<ApplicationApltAttribute> applicationApltAttributes) {
		this.applicationApltAttributes = applicationApltAttributes;
	}

	public ApplicationApltAttribute addApplicationApltAttribute(ApplicationApltAttribute applicationApltAttribute) {
		getApplicationApltAttributes().add(applicationApltAttribute);
		applicationApltAttribute.setApplicantPhoneNumber(this);

		return applicationApltAttribute;
	}

	public ApplicationApltAttribute removeApplicationApltAttribute(ApplicationApltAttribute applicationApltAttribute) {
		getApplicationApltAttributes().remove(applicationApltAttribute);
		applicationApltAttribute.setApplicantPhoneNumber(null);

		return applicationApltAttribute;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((apltphnumisdndactive == null) ? 0 : apltphnumisdndactive.hashCode());
		result = prime * result + ((apltphnumispreferred == null) ? 0 : apltphnumispreferred.hashCode());
		result = prime * result + ((apltphnumisverified == null) ? 0 : apltphnumisverified.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApplicantPhoneNumber other = (ApplicantPhoneNumber) obj;
		if (apltphnumareacode == null) {
			if (other.apltphnumareacode != null)
				return false;
		} else if (!apltphnumareacode.equals(other.apltphnumareacode))
			return false;
		if (apltphnumcountrycode == null) {
			if (other.apltphnumcountrycode != null)
				return false;
		} else if (!apltphnumcountrycode.equals(other.apltphnumcountrycode))
			return false;
		if (apltphnumnumber == null) {
			if (other.apltphnumnumber != null)
				return false;
		} else if (!apltphnumnumber.equals(other.apltphnumnumber))
			return false;
		if (phoneNumberType == null) {
			if (other.phoneNumberType != null)
				return false;
		} else if (phoneNumberType.getPhonetypekey() != (other.phoneNumberType.getPhonetypekey()))
			return false;
		return true;
	}

	
	public boolean equalsOtherParam(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApplicantPhoneNumber other = (ApplicantPhoneNumber) obj;
		if (apltphnumisdndactive == null) {
			if (other.apltphnumisdndactive != null)
				return false;
		} else if (!apltphnumisdndactive.equals(other.apltphnumisdndactive))
			return false;
		if (apltphnumispreferred == null) {
			if (other.apltphnumispreferred != null)
				return false;
		} else if (!apltphnumispreferred.equals(other.apltphnumispreferred))
			return false;
		if (apltphnumisverified == null) {
			if (other.apltphnumisverified != null)
				return false;
		} else if (!apltphnumisverified.equals(other.apltphnumisverified))
			return false;
		return true;
	}

	/**
	 * @return the applicationApltPhoneNumbers
	 */
	public List<ApplicationApltPhoneNumber> getApplicationApltPhoneNumbers() {
		return applicationApltPhoneNumbers;
	}

	/**
	 * @param applicationApltPhoneNumbers the applicationApltPhoneNumbers to set
	 */
	public void setApplicationApltPhoneNumbers(List<ApplicationApltPhoneNumber> applicationApltPhoneNumbers) {
		this.applicationApltPhoneNumbers = applicationApltPhoneNumbers;
	}
	
}