package com.bajaj.bfsd.usermanagement.util;

import java.util.HashMap;

public class TrieNode {
	char data;
	HashMap<Character, TrieNode> children;
	boolean isEndOfWord = false;

	TrieNode(char c) {
		this.data = c;
		children = new HashMap<>();

	}

	public char getData() {
		return data;
	}

	public void setData(char data) {
		this.data = data;
	}

	public HashMap<Character, TrieNode> getChildren() {
		return children;
	}

	public void setChildren(HashMap<Character, TrieNode> children) {
		this.children = children;
	}

	public boolean isEndOfWord() {
		return isEndOfWord;
	}

	public void setEndOfWord(boolean isEndOfWord) {
		this.isEndOfWord = isEndOfWord;
	}

	public void insert(String word) {
		if (word == null || word.isEmpty())
			return;
		char firstChar = word.charAt(0);
		TrieNode child = children.get(firstChar);
		if (child == null) {
			child = new TrieNode(firstChar);
			children.put(firstChar, child);
		}

		if (word.length() > 1)
			child.insert(word.substring(1));
		else
			child.isEndOfWord = true;
	}
}
