package com.bajaj.openmarkets.usermanagement.validator;

import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.DATE_FORMATE;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.USERTYPE_CUSTOMER;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.USERTYPE_PSEUDO_CUSTOMER;
import static com.bajaj.bfsd.usermanagement.util.UserManagementConstants.USERTYPE_PSEUDO_VERIFIED_CUSTOMER;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.bajaj.openmarkets.usermanagement.bean.UserRequest;

public class RequestValidator {

	public static boolean validateUserRequest(UserRequest userRequest) {
		boolean validRequest = false;
		short userType = userRequest.getUserType();

		if (null != userRequest.getDateOfBirth() && !userRequest.getDateOfBirth().isEmpty()) {
			SimpleDateFormat dateFormatter = new SimpleDateFormat(DATE_FORMATE);
			dateFormatter.setLenient(false);
			try {
				dateFormatter.parse(userRequest.getDateOfBirth());
			} catch (ParseException e) {
				return false;
			}
		}

		switch (userType) {
		case USERTYPE_CUSTOMER:
			if (null != userRequest.getMobile() && null != userRequest.getDateOfBirth()) {
				return true;
			}
			break;

		case USERTYPE_PSEUDO_CUSTOMER:
			if (null != userRequest.getMobile() && null != userRequest.getApplicationKey()) {
				return true;
			}
			break;

		case USERTYPE_PSEUDO_VERIFIED_CUSTOMER:
			if (null != userRequest.getMobile() && null != userRequest.getApplicationKey()) {
				return true;
			}
			break;

		default:
			break;
		}

		return validRequest;
	}
}
