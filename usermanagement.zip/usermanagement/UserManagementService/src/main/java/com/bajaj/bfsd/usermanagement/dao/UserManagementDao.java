package com.bajaj.bfsd.usermanagement.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.usermanagement.bean.AutoRegisterRequest;
import com.bajaj.bfsd.usermanagement.bean.ChannelBean;
import com.bajaj.bfsd.usermanagement.bean.LocationBean;
import com.bajaj.bfsd.usermanagement.bean.PinCodeBean;
import com.bajaj.bfsd.usermanagement.bean.ReportingManager;
import com.bajaj.bfsd.usermanagement.bean.SupervisorBean;
import com.bajaj.bfsd.usermanagement.bean.User;
import com.bajaj.bfsd.usermanagement.bean.UserConfigurationBean;
import com.bajaj.bfsd.usermanagement.bean.UserInfoRequest;
import com.bajaj.bfsd.usermanagement.bean.UserLoginAccountRequest;
import com.bajaj.bfsd.usermanagement.bean.UserMappingRequest;
import com.bajaj.bfsd.usermanagement.bean.UserName;
import com.bajaj.bfsd.usermanagement.bean.UserProfileDetails;
import com.bajaj.bfsd.usermanagement.bean.UserRoleBean;
import com.bajaj.bfsd.usermanagement.bean.ValidateTokenBean;
import com.bajaj.bfsd.usermanagement.model.AppContactAuthRequest;
import com.bajaj.bfsd.usermanagement.model.BfsdUser;
import com.bajaj.bfsd.usermanagement.model.UserLoginAccount;
import com.bajaj.bfsd.usermanagement.model.UserProfile;
import com.bajaj.bfsd.usermanagement.model.UserRole;

public interface UserManagementDao {

	public BfsdUser createUser(User userBean);

	public String createUserMapping(UserMappingRequest userMappingBean);

	public String updateUserMapping(UserMappingRequest userMappingBean);

	public int deleteUser(UserConfigurationBean userConfig);

	public int updateUserDetails(UserInfoRequest userInfoRequest);//Added for Partner Portal
	
	public List<SupervisorBean> getuserSuperVisor(String roleKey);

	public List<LocationBean> getSuperVisorLocations(String userRoleKey);

	public List<ChannelBean> getSuperVisorChannels(String userRoleKey);

	public List<PinCodeBean> getLocationPin(String locationKey);

	public List details(long employeeKey, long rolekey);

	public Boolean deleteUserMapping(Long employeeKey, Long roleKey);

	public UserLoginAccount getUserLoginAccount(UserLoginAccountRequest userLoginAccountRequest);

	public UserLoginAccount getUserId(String loginId);

	public BfsdUser updateFailedCount(BfsdUser bfsdUser, short failedCount,short userType);

	public UserConfigurationBean getUserInformation(UserConfigurationBean userConfig,HttpHeaders headers);

	public List<UserRole> getRolesByUserKey(long userKey);

	public List<UserName> getListOfUserName(long pincode, long functionKey, long roleKey, long tabkey, long subprodkey);

	public UserProfile getUserProfileByUserKey(long userKey);

	public void assignRoleToUser(BfsdUser currentUser, short loginType, short userType);

	public boolean autoRegister(AutoRegisterRequest request);

	public void savePassword(String hashedPassword, String hashOldPassword, long userKey);

	public UserLoginAccount mergeUsers(long newUserKey, long oldUserKey);

	public List<UserProfile> searchUser(UserConfigurationBean userConfigurationBean);
	
	public UserProfile getUserVendorProfile(Long vendorProfileKey,Long userKey, String emailId);
	
	public int saveUserVendorProfile(UserProfile userVendorProfile);
	
	public <T> T getEntity(Class<T> clazz, Long key);

	public boolean checkLoginEmail(String emailId);

	public boolean checkApplicantEmail(String emailId, long applicantKey);

	public void saveEmail(long userKey, String oldEmail, String newEmail);

	public void exiprePrevLinks(String oldEmail, long currentUserKey);
	
	public List<Object[]> getUserRoleProductsByUserKey(long userKey);

	public void updateTokenStatus(ValidateTokenBean bean, AppContactAuthRequest authRequest, Timestamp timestamp,
			BigDecimal authStatus);

	public AppContactAuthRequest validateToken(ValidateTokenBean bean);
	
	public List<UserLoginAccount> getSystemUsers();

    public UserRoleBean getUserRoleInfo(Long userKey, Long roleKey);

    
    public List<UserName> getUserInfo(Long userKey);
    
    public long getUserKeyFromUserRoleKey(long userRoleKey);
    
	public BfsdUser getUserType(Long userKey); // added new method for get User type  for Partner Portal

	public List<UserName> getUserInfoByUserKey(Long userRoleKey);

	public List<UserRoleBean> getUserInfoByEmail(String userEmail);

	public List<UserProfileDetails> getUserProfilesByRoleKeys(List<Long> roleKeyList);
	
	public List<ReportingManager> getAllReportingManagers(String searchcriteria);

	public List<UserRoleBean> getUserInfoByAdId(String useradId);
	
	public UserRoleBean getUserNameBeanByUserRoleKey(long userRoleKey);
}
