package com.bajaj.bfsd.usermanagement.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.usermanagement.model.BfsdRoleMaster;

@Repository
public interface BfsdRoleMasterRepository extends JpaRepository<BfsdRoleMaster, Long>{

	BfsdRoleMaster findByRolekeyAndIsactive(Long rolekey, BigDecimal isactive);

}
