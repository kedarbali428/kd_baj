package com.bajaj.bfsd.usermanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the APP_CTA_PRODUCT database table.
 * 
 */
@Entity
@Table(name="APP_CTA_PRODUCT")
//@NamedQuery(name="AppCtaProduct.findAll", query="SELECT a FROM AppCtaProduct a")
public class AppCtaProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long ctaprodkey;

	private BigDecimal isactive;

	private BigDecimal lnprodkey;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to AppCtaType
	@ManyToOne
	@JoinColumn(name="CTAKEY")
	private AppCtaType appCtaType;

	//bi-directional many-to-one association to AppCtaRole
	@OneToMany(mappedBy="appCtaProduct")
	private List<AppCtaRole> appCtaRoles;

	public long getCtaprodkey() {
		return this.ctaprodkey;
	}

	public void setCtaprodkey(long ctaprodkey) {
		this.ctaprodkey = ctaprodkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public BigDecimal getLnprodkey() {
		return this.lnprodkey;
	}

	public void setLnprodkey(BigDecimal lnprodkey) {
		this.lnprodkey = lnprodkey;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public AppCtaType getAppCtaType() {
		return this.appCtaType;
	}

	public void setAppCtaType(AppCtaType appCtaType) {
		this.appCtaType = appCtaType;
	}

	public List<AppCtaRole> getAppCtaRoles() {
		return this.appCtaRoles;
	}

	public void setAppCtaRoles(List<AppCtaRole> appCtaRoles) {
		this.appCtaRoles = appCtaRoles;
	}

	public AppCtaRole addAppCtaRole(AppCtaRole appCtaRole) {
		getAppCtaRoles().add(appCtaRole);
		appCtaRole.setAppCtaProduct(this);

		return appCtaRole;
	}

	public AppCtaRole removeAppCtaRole(AppCtaRole appCtaRole) {
		getAppCtaRoles().remove(appCtaRole);
		appCtaRole.setAppCtaProduct(null);

		return appCtaRole;
	}

}