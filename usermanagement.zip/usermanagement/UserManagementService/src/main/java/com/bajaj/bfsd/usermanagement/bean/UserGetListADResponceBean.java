package com.bajaj.bfsd.usermanagement.bean;

import java.util.List;

public class UserGetListADResponceBean {
	
	List<UserGetRecordResponceBean> userADList;

	public List<UserGetRecordResponceBean> getUserADList() {
		return userADList;
	}

	public void setUserADList(List<UserGetRecordResponceBean> userADList) {
		this.userADList = userADList;
	}

	@Override
	public String toString() {
		return "UserGetListADResponceBean [userADList=" + userADList + "]";
	}
	

}
