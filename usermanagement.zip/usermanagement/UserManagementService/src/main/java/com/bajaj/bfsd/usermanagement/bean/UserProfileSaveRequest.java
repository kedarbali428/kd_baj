package com.bajaj.bfsd.usermanagement.bean;

import java.io.Serializable;

public class UserProfileSaveRequest implements Serializable{
	
	private static final long serialVersionUID = -4891676592834362188L;

	private long userKey;
	
	private String profileJson;

	public String getProfileJson() {
		return profileJson;
	}

	public void setProfileJson(String profileJson) {
		this.profileJson = profileJson;
	}

	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}

}
