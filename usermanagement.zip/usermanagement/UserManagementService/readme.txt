#TODO

1> We will be integrating mongo-db to track all the activities of user.
2> We will restrict the generation of pseudo customer token to only once as we are allowing customer on our platform
   through pseudo token and if customer is again returning then he should only use customer token for any activities.
