package com.bajaj.bfsd.bean;

import java.io.Serializable;

public class CibilObligation implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;

	private String customerId;
	private Boolean errorFlag;
	private Obligation obligationSummary;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Boolean getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(Boolean errorFlag) {
		this.errorFlag = errorFlag;
	}

	public Obligation getObligationSummary() {
		return obligationSummary;
	}

	public void setObligationSummary(Obligation obligationSummary) {
		this.obligationSummary = obligationSummary;
	}

}
