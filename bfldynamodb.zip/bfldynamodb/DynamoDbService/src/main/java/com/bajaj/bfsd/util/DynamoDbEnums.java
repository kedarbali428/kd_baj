package com.bajaj.bfsd.util;

public enum DynamoDbEnums {
	DYDB_01("DYDB_01"),
	DYDB_02("DYDB_02"),
	DYDB_03("DYDB_03"),
	DYDB_04("DYDB_04"),
	DYDB_05("DYDB_05"),
	DYDB_06("DYDB_06"),
	DYDB_07("DYDB_07"),
	CHM("CHM"),
	PERFIOS("PERFIOS"),
	EXT_API_REQUEST("MEDLIFE"),
	
	REPORT_APPLICATION_ID("Application Id"),
	REPORT_APPLICANT_ID("Applicant Id"),
	REPORT_PRODUCT("Product"),
	REPORT_PERFIOS_TRANSACTION_ID("Perfios Transaction Id"),
	REPORT_REQUEST_TIME("Request Time"),
	REPORT_CSV_SAPERATOR(", "),
	REPORT_LINE_SAPERATOR("\n"),
	REPORT_FILE_TIME("ddMMuuuuHHmmss"),
	REPORT_TEMP_FILE_PATH("../temp.csv"),
	REPORT_S3_FILE_PREFIX("PERFIOS_EXTERNAL_COUNT_"),
	REPORT_S3_FILE_FORMAT(".csv"),
	
	DYDB_PERFIOS_STATUS_RESPONSE("resPayload"),
	DYDB_SCAN_REQ_TIME_FORMAT("YYYY-MM-DD HH:MM:SS"),
	
	DYDB_INDEX_NAME("sourcetype-REQTIMESTAMP-index"),
	
	DYDB_QUERY_KEY_EXPR("sourcetype = :sourcetypevalue and REQTIMESTAMP >= :requestTimestampValue"),
	DYDB_QUERY_FILTER_EXPR("contains(resPayload, :status)"),
	DYDB_PROJECTION_EXPRESSION("ID, applicantId, appnId, reqDate, resPayload"),
	
	DYDB_EXPR_REPORT_START_DATE(":reportStartDate"),
	DYDB_EXPR_REPORT_END_DATE(":reportEndDate"),
	DYDB_EXPR_REPORT_REQ_DATE(":requestDate"),
	DYDB_EXPR_REPORT_REQ_TIMESTAMP(":requestTimestampValue"),
	DYDB_EXPR_REPORT_REQ_SOURCETYPE(":sourcetypevalue"),
	DYDB_EXPR_REPORT_STATUS(":status"),
	DYDB_EXPR_REPORT_STATUS_STRING("</Status>"),
	
	PERFIOS_APPLICATION_ID_COL("appnId"),
	PERFIOS_APPLICANT_ID_COL("applicantId"),
	PERFIOS_RESPONSE_PAYLOAD_COL("resPayload"),
	PERFIOS_REQUEST_DATE_COL("reqDate"),
	
	RESPONSE_XML_NODE_ELEMENT("Part"),
	
	CIBIL_DYDB_QUERY_KEY_EXPR("ID = :id and REQTIMESTAMP > :reqTimeStamp"),
	CIBIL_DYDB_QUERY_ALTERNATE_KEY_EXPR("ID = :id"),
	CIBIL_DYDB_QUERY_FILTER_EXPR("sourcetype = :sourcetype"),
	CIBIL_DYDB_QUERY_REQ_ID(":id"),
	CIBIL_DYDB_QUERY_REQ_TIMESTAMP(":reqTimeStamp"),
	CIBIL_DYDB_QUERY_REQ_SOURCETYPE(":sourcetype"), 
	CIBIL_DYDB_INDEX_NAME("applicationId-REQTIMESTAMP-index"),
	CIBIL_DYDB_INDEX_APPLICATIONID(":applicationId"),
	CIBIL_DYDB_INDEX_QUERY_KEY_EXPR("applicationId = :applicationId and REQTIMESTAMP >= :reqTimeStamp");
	
	
	private String val;
	
	private DynamoDbEnums(String val) {
		this.val = val;
	}
	
	public String value() {
        return val;
    }
}
