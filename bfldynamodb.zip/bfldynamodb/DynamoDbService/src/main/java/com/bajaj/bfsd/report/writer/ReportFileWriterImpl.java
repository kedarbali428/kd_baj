package com.bajaj.bfsd.report.writer;

import java.io.Closeable;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.util.DynamoDbEnums;

@Component
public class ReportFileWriterImpl implements ReportWriter {

	@Override
	public Writer init(File file) throws IOException {
		return new FileWriter(file);
	}

	@Override
	public Writer addHeader(Writer writer, List<String> headerColumns) throws IOException {
		Iterator<String> iterator = headerColumns.iterator();
		while(iterator.hasNext()) {
			String headerColumn = iterator.next();
			writer.append(headerColumn);
			if(iterator.hasNext())
				writer.append(DynamoDbEnums.REPORT_CSV_SAPERATOR.value());
		}
		writer.append(DynamoDbEnums.REPORT_LINE_SAPERATOR.value());
		return writer;
	}

	@Override
	public Writer appendRow(Writer writer, List<String> columnValues) throws IOException{
		Iterator<String> iterator = columnValues.iterator();
		while(iterator.hasNext()) {
			String column = iterator.next();
			writer.append(column);
			if(iterator.hasNext())
				writer.append(DynamoDbEnums.REPORT_CSV_SAPERATOR.value());
		}
		writer.append(DynamoDbEnums.REPORT_LINE_SAPERATOR.value());
		return writer;
	}

	@Override
	public void close(Writer writer) throws IOException {
		writer.close();
	}

}
