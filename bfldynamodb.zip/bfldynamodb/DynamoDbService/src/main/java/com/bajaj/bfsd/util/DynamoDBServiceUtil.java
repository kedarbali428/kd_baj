package com.bajaj.bfsd.util;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;

@Component
public class DynamoDBServiceUtil extends BFLComponent {

	/**
	 * Convert time to long value
	 * @param requestTimestamp
	 * @return
	 */
	public Long getTimeInLong(String requestTimestamp) {
		Timestamp tts = Timestamp.valueOf(requestTimestamp);

		return tts.getTime();
	}

}