package com.bajaj.bfsd.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.bajaj.bfsd.DynamoDBConfig;
import com.bajaj.bfsd.MapperFactory;
import com.bajaj.bfsd.bean.CibilOblicationResponse;
import com.bajaj.bfsd.bean.CibilObligation;
import com.bajaj.bfsd.bean.DynamoDbBean;
import com.bajaj.bfsd.bean.DynamoDbBeanBalic;
import com.bajaj.bfsd.bean.DynamoDbCibilBean;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLDao;
import com.bajaj.bfsd.dao.DynamoDbDao;
import com.bajaj.bfsd.report.writer.CsvReportGeneration;
import com.bajaj.bfsd.util.DynamoDBServiceUtil;
import com.bajaj.bfsd.util.DynamoDbEnums;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class DynamoDbDaoImpl extends BFLDao implements DynamoDbDao {

	@Value("${db.env.suffix}")
	private String dbEnvSuffix;

	@Autowired
	DynamoDBConfig dynamoDBConfig;

	@Autowired
	Environment env;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	DynamoDBServiceUtil dynamoDBServiceUtil;

	@Autowired
	DynamoDB dynamo;

	@Autowired
	CsvReportGeneration csvReportGeneration;

	@Value("${report.period:1}")
	private int reportPeriod;

	private static final String CLASS_NAME = DynamoDbDaoImpl.class.getName();

	private static final String RESPONSE_PAYLOAD = "resPayload";
	private static final String REQUEST_PAYLOAD = "reqPayload";

	/**
	 * method to return requested table
	 * 
	 * @param tableName
	 * @return
	 */
	private Table getNoSqlDBTable(String tableName) {
		if (null == dynamo) {
			dynamo = dynamoDBConfig.dynamoDB();
		}
		return dynamo.getTable(tableName + dbEnvSuffix);
	}

	public boolean isJSONValid(String responseString) {
		logger.info(CLASS_NAME, BFLLoggerComponent.DAO, "JSON Validation initiated!");
		try {
			Gson gson = new Gson();
			gson.fromJson(responseString, Object.class);
		} catch (Exception ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "DynamoDB service : Invaid JSON format", ex);
			return false;
		}
		return true;
	}

	@Override
	public List<DynamoDbBean> get(String applicationId, String source, String type) {
		logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
				"DynamoDB read initiated for applicationId: " + applicationId + " and source:" + source);
		List<DynamoDbBean> dynamoResultList = new ArrayList<>();
		DynamoDbBean dynamoDbBean = null;
		try {
			Table table = getNoSqlDBTable(source);
			String key = null;
			if (applicationId != null && source != null) {
				key = applicationId + "-" + source;
			}

			QuerySpec spec = null;
			if (null != type) {
				spec = new QuerySpec().withKeyConditionExpression("ID = :id and REQTIMESTAMP > :reqTimeStamp")
						.withFilterExpression("sourcetype = :sourcetype")
						.withValueMap(new ValueMap().withString(":id", key)
								.withNumber(":reqTimeStamp", new BigDecimal(0)).withString(":sourcetype", type));
			} else {
				spec = new QuerySpec().withKeyConditionExpression("ID = :id")
						.withValueMap(new ValueMap().withString(":id", key));
			}

			ItemCollection<QueryOutcome> items = table.query(spec);
			Iterator<Item> iterator = items.iterator();
			Item item;
			Gson gson;
			while (iterator.hasNext()) {
				item = iterator.next();
				Object responsePayload;
				gson = new Gson();
				if (item.get(RESPONSE_PAYLOAD) == null) {
					continue;
				}
				if (isJSONValid(item.get(RESPONSE_PAYLOAD).toString())) {
					responsePayload = gson.fromJson(item.get(RESPONSE_PAYLOAD).toString(), Object.class);
				} else {
					responsePayload = item.get(RESPONSE_PAYLOAD).toString();
				}

				dynamoDbBean = new DynamoDbBean();
				dynamoDbBean.setSource(source);
				dynamoDbBean.setApplicantId((String) item.get("applicantId"));
				dynamoDbBean.setAppnId((String) item.get("appnId"));
				dynamoDbBean.setRawResUrl((String) item.get("rawResUrl"));
				dynamoDbBean.setReqTimeStamp((String) item.get("reqTime"));
				if (null != item.get(REQUEST_PAYLOAD)) {
					dynamoDbBean.setReqPayload((String) item.get(REQUEST_PAYLOAD));
					if (isJSONValid(item.get(REQUEST_PAYLOAD).toString())) {
						Object requestObjPayload = gson.fromJson(item.get(REQUEST_PAYLOAD).toString(), Object.class);
						dynamoDbBean.setReqObjPayload(requestObjPayload);
						logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
								"Request read DynamoDB for applicationId: " + applicationId + " and source:" + source);
					}
				}
				dynamoDbBean.setResPayload(responsePayload);
				dynamoDbBean.setResTimeStamp((String) item.get("resTimeStamp"));
				if (null != item.get("type")) {
					dynamoDbBean.setSourcetype((String) item.get("type"));
				}
				dynamoResultList.add(dynamoDbBean);
			}

			logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
					"DynamoDB read initiated for applicationId: " + applicationId + " and source:" + source
							+ " finished, and records size is: " + dynamoResultList.size());
			return dynamoResultList;
		} catch (Exception ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Exception occured while reading data from dynamo Db ",
					ex);
			throw new BFLTechnicalException("Exception occured fetching records from dynamo Db. ", ex);
		}
	}

	@Override
	public void insertRecord(DynamoDbBean dynamoDbBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
				"DynamoDbDAO insert Invoked; Input Payload: " + dynamoDbBean.toString());
		String key = dynamoDbBean.getAppnId() + "-" + dynamoDbBean.getSource();
		Timestamp ts = Timestamp.valueOf(dynamoDbBean.getReqTimeStamp());
		long reqDate = ts.getTime();

		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.S");
		String reqTime = sdf.format(ts);

		try {
			Table table = getNoSqlDBTable(dynamoDbBean.getSource());
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "DynamoDbController - Dynamo insert Table: " + table);
			Item item = new Item().withPrimaryKey("ID", key, "REQTIMESTAMP", reqDate);
			item.withString("appnId", dynamoDbBean.getAppnId());
			item.withString("source", dynamoDbBean.getSource());
			if (null != dynamoDbBean.getApplicantId()) {
				item.withString("applicantId", dynamoDbBean.getApplicantId());
			}
			item.with("reqDate", dynamoDbBean.getReqTimeStamp());
			item.withString("reqTime", reqTime);
			if (null != dynamoDbBean.getResPayload()) {
				item.with(RESPONSE_PAYLOAD, dynamoDbBean.getResPayload());
			}
			if (null != dynamoDbBean.getRawResUrl()) {
				item.withString("rawResUrl", dynamoDbBean.getRawResUrl());
			}
			item.withString("resTimeStamp", dynamoDbBean.getResTimeStamp());

			if (null != dynamoDbBean.getSourcetype()) {
				item.withString("sourcetype", dynamoDbBean.getSourcetype());
			}
			if (!StringUtils.isEmpty(dynamoDbBean.getReqPayload())) {
				item.withString("reqPayload", dynamoDbBean.getReqPayload());
			}
			table.putItem(item);
		} catch (Exception ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO,
					"DynamoDbDaoImpl : Exception occured while inserting data into dynamo Db " + key + ts + ex);
			throw new BFLTechnicalException("Exception occured inserting into dynamo Db. ", ex);
		}
	}

	@Override
	public List<CibilOblicationResponse> getcibilObligationDetails(String applicationId, String source) {
		logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
				"CIBIL Obligation invoked for application id : " + applicationId + " and source: " + source);
		CibilObligation oblication = new CibilObligation();
		List<CibilObligation> cibilObligations = new ArrayList<>();
		List<CibilOblicationResponse> response = new ArrayList<>();
		try {
			Table table = getNoSqlDBTable(source);
			String key = null;
			String responsePayload = null;
			if (null != applicationId && null != source) {
				key = applicationId + "-" + source;
			}

			QuerySpec spec = new QuerySpec().withKeyConditionExpression("ID = :id")
					.withValueMap(new ValueMap().withString(":id", key));

			ItemCollection<QueryOutcome> items = table.query(spec);
			Iterator<Item> iterator = items.iterator();
			ObjectMapper mapper = MapperFactory.getInstance();
			Item item;

			while (iterator.hasNext()) {
				item = iterator.next();

				if (null != item.get(RESPONSE_PAYLOAD)) {
					responsePayload = (item.get(RESPONSE_PAYLOAD)).toString();
				}
				oblication = mapper.readValue(responsePayload, CibilObligation.class);
				cibilObligations.add(oblication);

			}
			if (!cibilObligations.isEmpty()) {
				cibilBean(cibilObligations.get(cibilObligations.size() - 1), response);
			}
			logger.info(CLASS_NAME, BFLLoggerComponent.DAO, env.getProperty("DYDB_06"));
			return response;

		} catch (Exception exception) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, env.getProperty("DYDB_05"));
			throw new BFLTechnicalException(env.getProperty("DYDB_05"), exception);
		}

	}

	private void cibilBean(CibilObligation oblication, List<CibilOblicationResponse> response) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, env.getProperty("DYDB_10"));
		if (null != oblication.getObligationSummary().getEmiList()
				&& !oblication.getObligationSummary().getEmiList().isEmpty()) {
			for (int i = 0; i < oblication.getObligationSummary().getEmiList().size(); i++) {
				CibilOblicationResponse cibil = new CibilOblicationResponse();
				String dateOpenedOrDisbursed;
				String dateReportedAndCert;
				String dateClosed;
				if (!"0".equals(oblication.getObligationSummary().getEmiList().get(i).getEmiCap())) {
					cibil.setMonthlyemi(oblication.getObligationSummary().getEmiList().get(i).getEmiCap());

					cibil.setPrincipaloutstanding(
							oblication.getObligationSummary().getEmiList().get(i).getCurrentBalance());
					cibil.setLoanType(oblication.getObligationSummary().getEmiList().get(i).getLoanType());
					dateOpenedOrDisbursed = dateFormat(
							oblication.getObligationSummary().getEmiList().get(i).getDateOpenedOrDisbursed());
					cibil.setLoanstartdateordisburseddate(dateOpenedOrDisbursed);
					cibil.setTotalloansanctioned(
							oblication.getObligationSummary().getEmiList().get(i).getHighCreditSanctionAmt());
					dateReportedAndCert = dateFormat(
							oblication.getObligationSummary().getEmiList().get(i).getDateReportedAndCert());
					cibil.setLastreporteddate(dateReportedAndCert);
					cibil.setTotaltenure(oblication.getObligationSummary().getEmiList().get(i).getTenureCap());
					dateClosed = dateFormat(oblication.getObligationSummary().getEmiList().get(i).getDateClosed());
					cibil.setLoanenddate(dateClosed);
					cibil.setRoi(oblication.getObligationSummary().getEmiList().get(i).getIrrCap());
					response.add(cibil);
				}
			}
		}
	}

	private String dateFormat(String date) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, env.getProperty("DYDB_09"));
		SimpleDateFormat object = new SimpleDateFormat("ddMMyyyy");
		SimpleDateFormat object1 = new SimpleDateFormat("dd-MM-YYYY");
		try {
			if (null != date && !date.isEmpty() && !"0".equals(date)) {
				Date date1 = object.parse(date);
				return object1.format(date1);
			}
			return date;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, env.getProperty("DYDB_08"));
			throw new BFLTechnicalException(env.getProperty("DYDB_08"), e);
		}
	}

	/**
	 * This method will save details to dynamo DB for given applicationKey and
	 * source.
	 * 
	 * @author 686009
	 * @param dynamoDbBean
	 */
	@Override
	public void insertRecord(DynamoDbBeanBalic dynamoDbBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.DAO, "Inside insertRecord(): " + dynamoDbBean.toString());
		String key = dynamoDbBean.getApplicationKey() + "-" + dynamoDbBean.getSource();
		Timestamp ts = Timestamp.valueOf(dynamoDbBean.getTimeStamp());
		long reqDate = ts.getTime();

		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.S");
		String reqTime = sdf.format(ts);

		try {
			Table table = getNoSqlDBTable(dynamoDbBean.getSource());
			logger.info(CLASS_NAME, BFLLoggerComponent.DAO, "Dynamo Db Table created: " + table);
			Item item = new Item().withPrimaryKey("ID", key, "REQTIMESTAMP", reqDate);
			item.withString("applicationkey", dynamoDbBean.getApplicationKey());
			item.withString("balicAppKey", dynamoDbBean.getBalicAppKey());
			item.withString("fileName", dynamoDbBean.getFileName());
			item.withString("docType", dynamoDbBean.getDocType());
			item.withString("docCategory", dynamoDbBean.getDocCategory());
			item.withString("fileKey", dynamoDbBean.getFileKey());
			item.withString("source", dynamoDbBean.getSource());
			item.with("reqDate", dynamoDbBean.getTimeStamp());
			item.withString("reqTime", reqTime);
			if (null != dynamoDbBean.getSourcetype()) {
				item.withString("sourcetype", dynamoDbBean.getSourcetype());
			}
			table.putItem(item);
			logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
					"Inserting data into dynamo Db table completed successfully: " + table);
		} catch (Exception ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO,
					"DynamoDbDaoImpl : Exception occured while inserting data into dynamo Db " + key + ts + ex);
			throw new BFLTechnicalException("Exception occured inserting into dynamo Db. ", ex);
		}
	}

	/**
	 * This method will get details from dynamo db table for given applicationKey,
	 * source and sourcetypes
	 * 
	 * @author 686009
	 * @param applicationKey
	 * @param source
	 * @param sourcetype
	 * @return List<DynamoDbBeanBalic>
	 */
	@Override
	public List<DynamoDbBeanBalic> getBalicDocUploadRequestDetailsRecord(String applicationKey, String source,
			String sourcetype) {
		logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
				"Inside getBalicDocUploadRequestDetailsRecord().. DynamoDB read initiated for applicationKey: "
						+ applicationKey + " and source:" + source);
		List<DynamoDbBeanBalic> dynamoResultList = new ArrayList<>();
		DynamoDbBeanBalic dynamoDbBeanBalic = null;
		try {
			Table table = getNoSqlDBTable(source);

			QuerySpec spec = null;
			if (!StringUtils.isEmpty(sourcetype)) {
				spec = new QuerySpec()
						.withKeyConditionExpression("applicationkey = :applicationkey and REQTIMESTAMP > :reqTimeStamp")
						.withFilterExpression("sourcetype = :sourcetype")
						.withValueMap(new ValueMap().withString(":applicationkey", applicationKey)
								.withNumber(":reqTimeStamp", new BigDecimal(0)).withString(":sourcetype", sourcetype));
			} else {
				spec = new QuerySpec().withKeyConditionExpression("applicationkey = :applicationkey")
						.withValueMap(new ValueMap().withString(":applicationkey", applicationKey));
			}

			ItemCollection<QueryOutcome> items = table.query(spec);
			Iterator<Item> iterator = items.iterator();
			Item item;
			while (iterator.hasNext()) {
				logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
						"Inside while(-) getBalicDocUploadRequestDetailsRecord().. DynamoDB read initiated for applicationKey: "
								+ applicationKey + " and source:" + source);
				item = iterator.next();
				dynamoDbBeanBalic = new DynamoDbBeanBalic();
				dynamoDbBeanBalic.setSource(source);
				dynamoDbBeanBalic.setApplicationKey((String) item.get("applicationkey"));
				dynamoDbBeanBalic.setBalicAppKey((String) item.get("balicAppKey"));
				dynamoDbBeanBalic.setFileName((String) item.get("fileName"));
				dynamoDbBeanBalic.setDocCategory((String) item.get("docCategory"));
				dynamoDbBeanBalic.setDocType((String) item.get("docType"));
				dynamoDbBeanBalic.setFileKey((String) item.get("fileKey"));
				dynamoResultList.add(dynamoDbBeanBalic);
			}

			logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
					"Exit From getBalicDocUploadRequestDetailsRecord().. DynamoDB read initiated for applicationKey: "
							+ applicationKey + " and source:" + source + " finished, and records size is: "
							+ dynamoResultList.size());
			return dynamoResultList;
		} catch (Exception ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO,
					"Exception occured while reading data from dynamo Db inside getBalicDocUploadRequestDetailsRecord()",
					ex);
			throw new BFLTechnicalException("Exception occured fetching records from dynamo Db. ", ex);
		}

	}

	@Override
	public Long fetchExternalApiRequestsAndGenerateCsv(String source) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Inside fetchExternalApiRequestsAndGenerateCsv started.");

		Table table = getNoSqlDBTable(source);

		LocalDateTime currentDate = LocalDateTime.now();
		DateTimeFormatter currentDateFormatter = DateTimeFormatter.ofPattern(DynamoDbEnums.REPORT_FILE_TIME.value());
		String currentDateString = currentDate.format(currentDateFormatter);

		LocalDateTime reportFetchDate = currentDate.minusDays(reportPeriod);
		long reportFetchDateMillis = reportFetchDate.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();

		logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Report fetch from date: " + reportFetchDate.toString());

		QuerySpec spec = new QuerySpec().withKeyConditionExpression(DynamoDbEnums.DYDB_QUERY_KEY_EXPR.value())
				.withFilterExpression(DynamoDbEnums.DYDB_QUERY_FILTER_EXPR.value())
				.withProjectionExpression(DynamoDbEnums.DYDB_PROJECTION_EXPRESSION.value())
				.withValueMap(new ValueMap().withString(DynamoDbEnums.DYDB_EXPR_REPORT_REQ_SOURCETYPE.value(), source)
						.withNumber(DynamoDbEnums.DYDB_EXPR_REPORT_REQ_TIMESTAMP.value(), reportFetchDateMillis)
						.withString(DynamoDbEnums.DYDB_EXPR_REPORT_STATUS.value(),
								DynamoDbEnums.DYDB_EXPR_REPORT_STATUS_STRING.value()))
				.withMaxPageSize(1000);
		Index index = table.getIndex(DynamoDbEnums.DYDB_INDEX_NAME.value());
		ItemCollection<QueryOutcome> items = index.query(spec);

		Iterator<Item> iterator = items.iterator();

		Spliterator<Item> spliterator = Spliterators.spliteratorUnknownSize(iterator, Spliterator.ORDERED);
		long currentTime = System.currentTimeMillis();
		List<Item> filteredItems = StreamSupport.stream(spliterator, true).collect(Collectors.toList());

		logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Time taken for fetching " + filteredItems.size()
				+ " items is: " + (System.currentTimeMillis() - currentTime) + " milliseconds");

		return csvReportGeneration.generateReportForPerfios(filteredItems, currentDateString);
	}

	@Override
	public void insertRecord(DynamoDbCibilBean requestBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
				"insertRecord - insert cibil data in dynamo db based on applicantKey :  " + requestBean.toString());
		String key = requestBean.getApplicantId() + "-" + requestBean.getSource();
		Timestamp ts = Timestamp.valueOf(requestBean.getReqTimeStamp());
		long reqDate = ts.getTime();

		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.S");
		String reqTime = sdf.format(ts);

		try {
			Table table = getNoSqlDBTable(requestBean.getSource());
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "insertRecord - Dynamo db insert Table: " + table);
			Item item = new Item().withPrimaryKey("ID", key, "REQTIMESTAMP", reqDate);
			item.withString("source", requestBean.getSource());
			item.withString("applicantId", requestBean.getApplicantId());
			
			if (null != requestBean.getApplicationId()) {
			item.withString("applicationId", requestBean.getApplicationId());
			}
			
			if (null != requestBean.getReqTimeStamp()) {
				item.with("reqDate", requestBean.getReqTimeStamp());
			}
		
			item.withString("reqTime", reqTime);
			
			if(null != requestBean.getRawResponseUrl()) {
				item.withString("rawRespUrl", requestBean.getRawResponseUrl());
			}
			
			if(null != requestBean.getRequestPayload()) {
				item.with(REQUEST_PAYLOAD,requestBean.getRequestPayload());
			}
				
			if (null != requestBean.getResponsePayload()) {
				item.with(RESPONSE_PAYLOAD, requestBean.getResponsePayload());
			}
			
			if(null != requestBean.getResTimeStamp()) {
				item.withString("resTimeStamp", requestBean.getResTimeStamp());
			}

			if (null != requestBean.getSourcetype()) {
				item.withString("sourcetype", requestBean.getSourcetype());
			}else {
				item.withString("sourcetype", requestBean.getSource());
			}
			table.putItem(item);
		}catch(Exception ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO,
					"DynamoDbDaoImpl : Exception occured while inserting data into dynamo Db based on applicantKey" + key + ts + ex);
			throw new BFLTechnicalException("DYDB_16",env.getProperty("DYDB_16") +  ex);
		
		}
	}

	@Override
	public List<DynamoDbCibilBean> get(String applicantId, String applicationId, String source, String type) {
		logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
				"DynamoDB read cibil v1 data for applicantId: " + applicantId + " and source:" + source + " , applicationId -" +applicationId 
				+ " , type-" + type);
		List<DynamoDbCibilBean> dynamoResultList = new ArrayList<>();
		DynamoDbCibilBean dynamoDbCibilBean = null;
		ItemCollection<QueryOutcome> items;
		try {
			Table table = getNoSqlDBTable(source);
			String key = null;
			if (applicantId != null && source != null) {
				key = applicantId + "-" + source;
			}
			
			QuerySpec spec = null;
			if (null != type) {
				spec = new QuerySpec().withKeyConditionExpression(DynamoDbEnums.CIBIL_DYDB_QUERY_KEY_EXPR.value())
						.withFilterExpression(DynamoDbEnums.CIBIL_DYDB_QUERY_FILTER_EXPR.value())
						.withValueMap(new ValueMap().withString(DynamoDbEnums.CIBIL_DYDB_QUERY_REQ_ID.value(), key)
								.withNumber(DynamoDbEnums.CIBIL_DYDB_QUERY_REQ_TIMESTAMP.value(), new BigDecimal(0)).withString(DynamoDbEnums.CIBIL_DYDB_QUERY_REQ_SOURCETYPE.value(), type));
			} else {
				spec = new QuerySpec().withKeyConditionExpression(DynamoDbEnums.CIBIL_DYDB_QUERY_ALTERNATE_KEY_EXPR.value())
						.withValueMap(new ValueMap().withString(DynamoDbEnums.CIBIL_DYDB_QUERY_REQ_ID.value(), key));
			}

			if(null != applicationId) {
				spec = new QuerySpec().withKeyConditionExpression(DynamoDbEnums.CIBIL_DYDB_INDEX_QUERY_KEY_EXPR.value())
						.withFilterExpression(DynamoDbEnums.CIBIL_DYDB_QUERY_ALTERNATE_KEY_EXPR.value())
						.withValueMap(new ValueMap().withString(DynamoDbEnums.CIBIL_DYDB_INDEX_APPLICATIONID.value(), applicationId)
						.withNumber(DynamoDbEnums.CIBIL_DYDB_QUERY_REQ_TIMESTAMP.value() , new BigDecimal(0))
					    .withString(DynamoDbEnums.CIBIL_DYDB_QUERY_REQ_ID.value(), key));
				Index index = table.getIndex(DynamoDbEnums.CIBIL_DYDB_INDEX_NAME.value());
				items = index.query(spec);
			}else {
				items = table.query(spec);
			}
			Iterator<Item> iterator = items.iterator();
			Item item;
			while (iterator.hasNext()) {
				item = iterator.next();
				DynamoDbCibilBean dynamodbCibilBean = new DynamoDbCibilBean();
				dynamodbCibilBean.setSource(source);
				dynamodbCibilBean.setApplicantId((String) item.get("applicantId"));
				dynamodbCibilBean.setApplicationId((String) item.get("applicationId"));
				dynamodbCibilBean.setRawResponseUrl((String) item.get("rawResUrl"));
				dynamodbCibilBean.setReqTimeStamp((String) item.get("reqTime"));
				if (null != item.get(REQUEST_PAYLOAD)) {
					dynamodbCibilBean.setRequestPayload((String) item.get(REQUEST_PAYLOAD));
				}
				if (null != item.get(RESPONSE_PAYLOAD)) {
					dynamodbCibilBean.setResponsePayload(item.get(RESPONSE_PAYLOAD).toString());
				}
			
				dynamodbCibilBean.setResTimeStamp((String) item.get("resTimeStamp"));
				if (null != item.get("type")) {
					dynamodbCibilBean.setSourcetype((String) item.get("type"));
				}
				dynamoResultList.add(dynamodbCibilBean);
			}

			logger.info(CLASS_NAME, BFLLoggerComponent.DAO,
					"DynamoDB read initiated for applicationId: " + applicationId + " and source:" + source
							+ " finished, and records size is: " + dynamoResultList.size());
			return dynamoResultList;
		} catch (Exception ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Exception occured while reading data from dynamo Db ",
					ex);
			throw new BFLTechnicalException("Exception occured fetching records from dynamo Db. ", ex);
		}

	}

}
