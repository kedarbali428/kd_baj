package com.bajaj.bfsd.report.writer;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.util.List;

public interface ReportWriter {

	public Writer init(File file) throws IOException;
	
	public Writer addHeader(Writer writer, List<String> headerColumns) throws IOException;
	
	public Writer appendRow(Writer writer, List<String> columnValues) throws IOException;
	
	public void close(Writer writer) throws IOException ;
}
