package com.bajaj.bfsd.bean;

import javax.validation.constraints.NotNull;

public class DynamoDbCibilBean {
	
	private static final long serialVersionUID = 1L;
	
	@NotNull(message="DYDB_15")
	private String applicantId;
	
	private String applicationId;
	
	@NotNull(message="DYDB_14")
	private String source;
	
	private String responsePayload;
	
	private String requestPayload;
	
	private String reqTimeStamp;
	
	private String resTimeStamp;
	
	private String rawResponseUrl;
	
	private String sourcetype;
	
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getResponsePayload() {
		return responsePayload;
	}
	public void setResponsePayload(String responsePayload) {
		this.responsePayload = responsePayload;
	}
	public String getRequestPayload() {
		return requestPayload;
	}
	public void setRequestPayload(String requestPayload) {
		this.requestPayload = requestPayload;
	}
	public String getReqTimeStamp() {
		return reqTimeStamp;
	}
	public void setReqTimeStamp(String reqTimeStamp) {
		this.reqTimeStamp = reqTimeStamp;
	}
	public String getResTimeStamp() {
		return resTimeStamp;
	}
	public void setResTimeStamp(String resTimeStamp) {
		this.resTimeStamp = resTimeStamp;
	}
	public String getRawResponseUrl() {
		return rawResponseUrl;
	}
	public void setRawResponseUrl(String rawResponseUrl) {
		this.rawResponseUrl = rawResponseUrl;
	}
	public String getSourcetype() {
		return sourcetype;
	}
	public void setSourcetype(String sourcetype) {
		this.sourcetype = sourcetype;
	}
	@Override
	public String toString() {
		return "DynamoDbCibilBean [applicantId=" + applicantId + ", applicationId=" + applicationId + ", source="
				+ source + ", responsePayload=" + responsePayload + ", requestPayload=" + requestPayload
				+ ", reqTimeStamp=" + reqTimeStamp + ", resTimeStamp=" + resTimeStamp + ", rawResponseUrl="
				+ rawResponseUrl + ", sourcetype=" + sourcetype + "]";
	}
	
}
