package com.bajaj.bfsd.bean;

import java.io.Serializable;

import org.springframework.http.HttpStatus;

public class ResponseBean  implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;
	
	private Object payload;
	private String status;
	private String code;
	private String message;

	public ResponseBean(Object payload) {
		super();
		this.code = HttpStatus.OK.toString();
		this.status = "success";
		this.payload = payload;
	}

	public ResponseBean(String code, String message) {
		super();
		this.status = "fail";
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
