package com.bajaj.bfsd.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.bean.ApplicantDynamoDbBean;
import com.bajaj.bfsd.bean.CibilOblicationResponse;
import com.bajaj.bfsd.bean.DynamoDbBean;
import com.bajaj.bfsd.bean.DynamoDbBeanBalic;
import com.bajaj.bfsd.bean.DynamoDbCibilBean;
import com.bajaj.bfsd.bean.DynamoDbResponseBean;
import com.bajaj.bfsd.bean.DynamoDbResponseBeanBalic;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.service.DynamoDbService;
import com.bajaj.bfsd.util.DynamoDbEnums;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * This Controller is used to expose DynamoDB service. It used to take the whole
 * JSon input and persist in respective DynamoDB tables.
 *
 */
@RefreshScope
@RestController
public class DynamoDbController extends BFLController {

	@Autowired
	DynamoDbService dynamoDBService;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;

	private static final String CLASS_NAME = DynamoDbController.class.getName();

	@CrossOrigin
	@RequestMapping(value = "${api.nosql.audit.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Fetch latest Record based on application id ", notes = "Fetch latest Record based on application id ", httpMethod = "GET")
	public ResponseEntity<ResponseBean> get(@RequestParam("applicationId") String applicationId,
			@RequestParam("source") String source, @RequestHeader HttpHeaders headers) {
		return getReportsRecord(applicationId, source, null);
	}
	
	@CrossOrigin
	@RequestMapping(value = "${api.nosql.audit.bre.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Fetch latest BRE Record based on application id ", notes = "Fetch latest BRE Record based on application id ", httpMethod = "GET")
	public ResponseEntity<ResponseBean> getBRERecord(@RequestParam("applicationId") String applicationId,
			@RequestParam("source") String source,@RequestParam("sourcetype") String sourcetype, @RequestHeader HttpHeaders headers) {
		return getReportsRecord(applicationId, source, sourcetype);
	}

	/**
	 * method to get report.
	 * @param applicationId
	 * @param source
	 * @param sourcetype
	 * @return
	 */
	private ResponseEntity<ResponseBean> getReportsRecord(String applicationId, String source, String sourcetype) {
		ResponseBean responseBean = null;
		List<DynamoDbBean> dynamoDbBean = null;
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Fetching response from dynamo Db with application id :" 
					+ applicationId + " and Source : " + source+ " and SourceType : "+ sourcetype);
			dynamoDbBean = dynamoDBService.read(applicationId, source, sourcetype);
			if (null != dynamoDbBean && !dynamoDbBean.isEmpty()) {
				if (DynamoDbEnums.CHM.value().equals(source)) {
					responseBean = new ResponseBean(getLastResponse(dynamoDbBean, "INQUIRY-STATUS") != null
							? getLastResponse(dynamoDbBean, "INQUIRY-STATUS").getResPayload() : null);
				} else if (DynamoDbEnums.PERFIOS.value().equals(source)) {
					responseBean = new ResponseBean(getLastResponse(dynamoDbBean, "<Status files") != null
							? getLastResponse(dynamoDbBean, "<Status files").getResPayload() : null);
				}else if (DynamoDbEnums.EXT_API_REQUEST.value().equalsIgnoreCase(source)) { //medlife,COMGPA,COMGTL
					responseBean = new ResponseBean(dynamoDbBean.get(dynamoDbBean.size() - 1).getReqObjPayload()); //requestpayload
				}
				else {
					responseBean = new ResponseBean(dynamoDbBean.get(dynamoDbBean.size() - 1).getResPayload());
				}
				logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Fetching response from dynamo Db Completed");
			} else {
				logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
						"No record found for for ApplicationId: " + applicationId + " and Source: " + source);
				throw new BFLBusinessException("NSQL_0001", "No record Found with Application Id:" + applicationId);

			}
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Response for ApplicationId: " + applicationId
					+ " and Source: " + source + " is : " + responseBean);
		} catch (BFLBusinessException exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, exception.getCode(), exception);
			throw exception;
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"DynamoDbController : GET: Exception occured while fetching response from dynamo Db with application id",
					exception);
			throw new BFLBusinessException("NSQL_0003", exception.getCause(), null);
		}
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	/**
	 * returns latest response
	 * 
	 * @param dynamoDbBeans
	 * @param pattern
	 * @return DynamoDbBean
	 */
	private DynamoDbBean getLastResponse(List<DynamoDbBean> dynamoDbBeans, String pattern) {
		String response;
		if (null != dynamoDbBeans && !dynamoDbBeans.isEmpty()) {
			for (int cnt = dynamoDbBeans.size() - 1; cnt >= 0; cnt--) {
				response = dynamoDbBeans.get(cnt).toString();
				if (!(response).contains(pattern)) {
					return dynamoDbBeans.get(cnt);
				}
			}
		}
		return new DynamoDbBean();
	}

	/**
	 * @param bean
	 *            of the type {@link DynamoDbBean} which is used to persist in
	 *            DynamoDB.
	 * @return
	 */
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "${api.nosql.audit.POST.uri}")
	@ApiOperation(value = "Insert into NoSQL DynamoDB", notes = "Insert into NoSQL DynamoDB", httpMethod = "POST")
	public ResponseEntity<ResponseBean> create(@Valid @RequestBody DynamoDbBean bean,
			@RequestHeader HttpHeaders headers, BindingResult result) {
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"DynamoDbController create invoked, Input Payload is:-" + bean.toString());
		List<ErrorBean> errorBeans;
		DynamoDbResponseBean dynamoDbResponseBean;
		ResponseBean responseBean = new ResponseBean();
		List<ErrorBean> errorBeanList = new ArrayList<>();
		if (result.hasErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Input bean validation error occurred!");
			for (FieldError fieldError : result.getFieldErrors()) {
				logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Binding result has errors:" + fieldError);
				ErrorBean errorBean = new ErrorBean();
				errorBean.setErrorCode("NSQL-0004");
				errorBean.setErrorMessage("Input data validation occurered for : " + fieldError.getField() + " Code:"
						+ fieldError.getCode());
				errorBeanList.add(errorBean);
			}
			responseBean.setErrorBean(errorBeanList);
			return new ResponseEntity<>(responseBean, HttpStatus.BAD_REQUEST);
		}

		if (null == bean.getResPayload() && null != bean.getResPayloadStr()) {
			bean.setResPayload(bean.getResPayloadStr());
		}
		/*
		 * if sourcetype will be null, we will pass source value to sourcetype
		 * as sourcetype is secondary index key which can not be null
		 */
		if(null == bean.getSourcetype()){ 
			bean.setSourcetype(bean.getSource());
		}
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Entry made into create request of DynamoDbController");
			dynamoDbResponseBean = dynamoDBService.create(bean);
			if (null != dynamoDbResponseBean && (null != dynamoDbResponseBean.getApplicantId()
					|| null != dynamoDbResponseBean.getApplicationId())) {
				responseBean.setPayload(dynamoDbResponseBean);
				responseBean.setStatus(StatusCode.SUCCESS);
			}
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Create request of DynamoDbController successfully completed");
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Error occurred while creating dynamoDB entry for application id: " + bean.getAppnId()
							+ " and source : " + bean.getSource() + ", : StackTrace: " + exception.getStackTrace(),exception.getCause());
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode("NSQL_0002");
			errorBean.setErrorMessage("Error while creating no sql entry for application id: " + bean.getAppnId()
							+ " and source : " + bean.getSource());
			errorBeans = new ArrayList<>();
			errorBeans.add(errorBean);
			responseBean.setErrorBean(errorBeans);
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exception occured while inserting into dynamo DB.",
					exception);
		}
		return new ResponseEntity<>(responseBean, HttpStatus.CREATED);
	}

	@CrossOrigin
	@RequestMapping(value = "/nosqldata/audit/fetchall", method =RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Fetch all Records based on application id ", notes = "Fetch all Records based on application id ", httpMethod = "GET")
	public ResponseEntity<ResponseBean> fetchresponseList(@RequestParam("applicationId") String applicationId,
			@RequestParam("source") String source, @RequestHeader HttpHeaders headers) {

		ResponseBean responseBean;

		List<DynamoDbBean> dynamoDbBean = null;
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Fetching response from dynamo Db with application id :" + applicationId);
			dynamoDbBean = dynamoDBService.read(applicationId, source, null);
			responseBean = new ResponseBean(dynamoDbBean);
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"DynamoDbController : FETCH-ALL : Exception occured while fetching response from dynamo Db with application id",
					exception);
			throw new BFLTechnicalException(
					"Exception occured while fetching (FETCH-ALL) response from dynamo Db with application id",
					exception);
		}
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	@CrossOrigin
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@ApiOperation(notes = "fetch cibil oblication details", value = "fetch cibil oblication details", httpMethod = "GET")
	@RequestMapping(value = "${api.nosql.cibil.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> cibilObligationDetails(@RequestHeader HttpHeaders headers,
			@RequestParam("applicationId") String applicationId, @RequestParam("source") String tablename) {
		ResponseBean bean = new ResponseBean();
		List<CibilOblicationResponse> response = new ArrayList<>();
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, env.getProperty(DynamoDbEnums.DYDB_01.value()));
			response = dynamoDBService.getcibilObligationDetails(applicationId, tablename);
			bean = new ResponseBean(response);
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, env.getProperty(DynamoDbEnums.DYDB_07.value()), exception);
			throw new BFLBusinessException(DynamoDbEnums.DYDB_07.value(), env.getProperty(DynamoDbEnums.DYDB_07.value()));
		}
		return new ResponseEntity<>(bean, HttpStatus.OK);
	}

	@CrossOrigin
	@RequestMapping(value = "${api.nosql.audit.applicant.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Fetch all Records based on application id ", notes = "Fetch all Records based on application id ", httpMethod = "POST")
	public ResponseEntity<ResponseBean> fetchResponseForApplicant(@RequestBody ApplicantDynamoDbBean bean,
			@RequestHeader HttpHeaders headers) {
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"fetchResponseForApplicant()--Starts for ApplicationId" + bean.getAppnId());
		ResponseBean responseBean;

		DynamoDbBean dynamoDbBean = null;
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Fetching response from dynamo Db with application id :" + bean.getAppnId());
			dynamoDbBean = dynamoDBService.readForApplicant(bean);
			responseBean = new ResponseBean(dynamoDbBean.getResPayload());
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"DynamoDbController : FETCH-ALL : Exception occured while fetching response from dynamo Db with application id",
					exception);
			throw new BFLBusinessException("DYDB_13","Error occurred while reading record for applicant id.");
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"fetchResponseForApplicant()--Ends for ApplicationId" + bean.getAppnId());
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	/**
	 * @author 686009
	 * @param bean of the type {@link DynamoDbBeanBalic} which is used to persist in DynamoDB.
	 * @param headers
	 * @param result
	 * @return
	 */
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "${api.nosql.balicdocs.POST.uri}")
	@ApiOperation(value = "Insert into NoSQL DynamoDB", notes = "Insert into NoSQL DynamoDB", httpMethod = "POST")
	public ResponseEntity<ResponseBean> createEntriesInDynamoDB(@Valid @RequestBody DynamoDbBeanBalic bean,
			@RequestHeader HttpHeaders headers, BindingResult result) {
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "DynamoDbController createEntriesInDynamoDB() invoked, Input Payload is:-" + bean.toString());
		List<ErrorBean> errorBeans;
		DynamoDbResponseBeanBalic dynamoDbResponseBean;
		ResponseBean responseBean = new ResponseBean();
		List<ErrorBean> errorBeanList = new ArrayList<>();
		if (result.hasErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Input bean validation error occurred!");
			for (FieldError fieldError : result.getFieldErrors()) {
				logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Binding result has errors:" + fieldError);
				ErrorBean errorBean = new ErrorBean();
				errorBean.setErrorCode("NSQL-0004");
				errorBean.setErrorMessage("Input data validation occurered for : " + fieldError.getField() + " Code:" + fieldError.getCode());
				errorBeanList.add(errorBean);
			}
			responseBean.setErrorBean(errorBeanList);
			return new ResponseEntity<>(responseBean, HttpStatus.BAD_REQUEST);
		}
		//if sourcetype will be null, we will pass source value to sourcetype as sourcetype is secondary index key which can not be null
		if(null == bean.getSourcetype()){ 
			bean.setSourcetype(bean.getSource());
		}
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Entry made into createEntriesInDynamoDB() request of DynamoDbController");
			dynamoDbResponseBean = dynamoDBService.createEntriesInDynamoDB(bean);
			if (!ObjectUtils.isEmpty(dynamoDbResponseBean) &&  !StringUtils.isEmpty(dynamoDbResponseBean.getApplicationKey())) {
				responseBean.setPayload(dynamoDbResponseBean);
				responseBean.setStatus(StatusCode.SUCCESS);
			}
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "createEntriesInDynamoDB() request of DynamoDbController successfully completed");
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Error occurred while creating dynamoDB entry for application id: " + bean.getApplicationKey()
							+ " and source : " + bean.getSource() + ", : StackTrace: " + exception.getStackTrace(),exception.getCause());
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode("NSQL_0002");
			errorBean.setErrorMessage("Error while creating no sql entry for application id: " + bean.getApplicationKey()
							+ " and source : " + bean.getSource());
			errorBeans = new ArrayList<>();
			errorBeans.add(errorBean);
			responseBean.setErrorBean(errorBeans);
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exception occured while inserting into dynamo DB.", exception);
		}
		return new ResponseEntity<>(responseBean, HttpStatus.CREATED);
	}
	
	/**
	 * @author 686009
	 * @param applicationKey
	 * @param source
	 * @param sourcetype
	 * @param headers
	 * @return
	 */
	@CrossOrigin
	@RequestMapping(value = "${api.nosql.balicdocs.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Fetch latest BALIC upload policy document request details based on application key.", notes = "Fetch latest BALIC upload policy document request details based on application key.", httpMethod = "GET")
	public ResponseEntity<ResponseBean> getBalicDocUploadRequestDetails(@RequestParam("applicationKey") String applicationKey,
			@RequestParam("source") String source,@RequestParam("sourcetype") String sourcetype, @RequestHeader HttpHeaders headers) {
		return getBalicDocUploadRequestDetailsRecord(applicationKey, source, sourcetype);
	}
	
	/**
	 * 
	 * @param applicationKey
	 * @param source
	 * @param sourcetype
	 * @return
	 */
	private ResponseEntity<ResponseBean> getBalicDocUploadRequestDetailsRecord(String applicationKey, String source, String sourcetype) {
		ResponseBean responseBean = null;
		List<DynamoDbBeanBalic> dynamoDbBeanBalicList = null;
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Inside getBalicDocUploadRequestDetailsRecord().. Fetching response from dynamo Db with application id :"
							+ applicationKey + " and Source : " + source + " and SourceType : " + sourcetype);
			dynamoDbBeanBalicList = dynamoDBService.readBalicDocUploadRequestDetailsRecord(applicationKey, source, sourcetype);
			if (!CollectionUtils.isEmpty(dynamoDbBeanBalicList)) {
					responseBean = new ResponseBean(dynamoDbBeanBalicList.get(dynamoDbBeanBalicList.size() - 1));
				logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
						"Inside getBalicDocUploadRequestDetailsRecord().. Fetching response from dynamo Db Completed");
			} else {
				logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
						"Inside getBalicDocUploadRequestDetailsRecord().. No record found in dynamoDB for ApplicationKey : "
								+ applicationKey + " and Source: " + source);
				throw new BFLBusinessException("NSQL_0001", "No record Found with ApplicationKey :" + applicationKey);

			}
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Inside getBalicDocUploadRequestDetailsRecord().. Response for ApplicationKey : " + applicationKey
					+ " and Source: " + source + " is : " + responseBean);
		} catch (BFLBusinessException exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, exception.getCode(), exception);
			throw exception;
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Inside DynamoDbController getBalicDocUploadRequestDetailsRecord(): Exception occured while fetching response from dynamo Db with ApplicationKey ",
					exception);
			throw new BFLBusinessException("NSQL_0003", exception.getCause(), null);
		}
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	@CrossOrigin
	@RequestMapping(value = "${api.nosql.externalapi.reports.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Creating report of external perfios api calls and uploading to S3 bucket", notes = "Creating report of external perfios api calls and uploading to S3 bucket", httpMethod = "GET")
	public ResponseEntity<ResponseBean> uploadExternalApiStatusToS3(@PathVariable("source") String source,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "started-API Count endpoint call.");
		ResponseBean responseBean = dynamoDBService.uploadExternalApiStatusToS3(source);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "ended-API Count endpoint call.");
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	
	@CrossOrigin
	@RequestMapping(value = "${api.nosql.validation.cibil.versiondata.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiImplicitParams({@ApiImplicitParam(name ="authtoken" ,required = true ,dataType="string" ,paramType="header"),
                        @ApiImplicitParam(name="guardtoken" ,required = true ,dataType="string" , paramType="header"),
                        @ApiImplicitParam(name="cmptcorrid" ,required = true ,dataType="string" , paramType="header")})
	@ApiOperation(value = "Insert cibil v1 data in dynamodb based on applicantId",notes = "Insert cibil data  in dynamo based on applicantId" ,httpMethod = "POST")
	public ResponseEntity<ResponseBean> saveCibilDataBasedOnApplicantId(@PathVariable("v1") String version,@Valid @RequestBody DynamoDbCibilBean dynamoDbCibilBean,BindingResult result,
			@RequestHeader HttpHeaders headers) {
		ResponseBean responseBean = new ResponseBean();
		List<ErrorBean> errorBeanList = new ArrayList<>();
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "started-saveCibilDataBasedOnApplicantId." + dynamoDbCibilBean.toString());
		if(result.hasErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "saveCibilDataBasedOnApplicantId - Error in field validation");
			for (FieldError fieldError : result.getFieldErrors()) {
				logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Binding result has errors:" + fieldError);
				ErrorBean errorBean = new ErrorBean();
				errorBean.setErrorCode("NSQL-0004");
				errorBean.setErrorMessage("Input data validation occurered for : " + fieldError.getField() + " Code:" + fieldError.getCode());
				errorBeanList.add(errorBean);
			}
			responseBean.setErrorBean(errorBeanList);
			return new ResponseEntity<>(responseBean, HttpStatus.BAD_REQUEST);
		}
		try {
			DynamoDbResponseBean dynamoDbResponseBean = dynamoDBService.insertCibilDataWithApplicantId(dynamoDbCibilBean);
			if (null != dynamoDbResponseBean && (null != dynamoDbResponseBean.getApplicantId()
					|| null != dynamoDbResponseBean.getApplicationId())) {
				responseBean.setPayload(dynamoDbResponseBean);
				responseBean.setStatus(StatusCode.SUCCESS);
			}
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,"Create request of DynamoDbController successfully completed");
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "ended-saveCibilDataBasedOnApplicantId.");
		}catch(Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,"Error occurred while creating dynamoDB entry for application id: " + dynamoDbCibilBean.getApplicantId()
							+ " and source : " + dynamoDbCibilBean.getSource() + ", : StackTrace: " + exception.getStackTrace(),exception.getCause());
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode("DYDB_16");
			errorBean.setErrorMessage(env.getProperty("DYDB_16") + dynamoDbCibilBean.getApplicantId()
							+ " and source : " + dynamoDbCibilBean.getSource());
			errorBeanList = new ArrayList<>();
			errorBeanList.add(errorBean);
			responseBean.setErrorBean(errorBeanList);
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exception occured while inserting into dynamo DB.",
					exception);
		}
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	@CrossOrigin
	@RequestMapping(value = "${api.nosql.validation.cibil.versiondata.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get cibil v1 data from dynamo based on applicantId",notes = "Get cibil v1 data from dynamo based on applicantId" ,httpMethod = "GET")
	@ApiImplicitParams({@ApiImplicitParam(name ="authtoken" ,required = true ,dataType="string" ,paramType="header"),
                        @ApiImplicitParam(name="guardtoken" ,required = true ,dataType="string" , paramType="header"),
                        @ApiImplicitParam(name="cmptcorrid" ,required = true ,dataType="string" , paramType="header")})
	public ResponseEntity<ResponseBean> getCibilDataBasedOnApplicantId(@PathVariable String v1, @PathVariable String applicantId,
																		@QueryParam("source") String source,
																		@QueryParam("applicationId") String applicationId,
																		@RequestHeader HttpHeaders headers) {
		ResponseBean responseBean = new ResponseBean();
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "started-getCibilDataBasedOnApplicantId for applicantId -" + applicantId + " ,applicantId"
				+ applicationId + " , source- " + source + " , version-" + v1);
		try {
				if(null == source) {
					throw new BFLBusinessException("DYDB_14",env.getProperty("DYDB_14"));
				}
				if(null== applicantId) {
					throw new BFLBusinessException("DYDB_15",env.getProperty("DYDB_15"));
				}
				
				DynamoDbCibilBean dynamoDbResponseBean = dynamoDBService.fetchCibilDataWithApplicantId(applicantId,applicationId,source);
				
				if (null != dynamoDbResponseBean && null != dynamoDbResponseBean.getApplicantId()) {
					responseBean.setPayload(dynamoDbResponseBean);
					responseBean.setStatus(StatusCode.SUCCESS);
				}else {
					logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
							"Inside getCibilDataBasedOnApplicantId()- No record found in dynamoDB for ApplicantId : "
									+ applicantId + " and Source: " + source);
					throw new BFLBusinessException("NSQL_0001", env.getProperty("DYDB_17") + applicantId);	
				}
				
				logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
						"Get request of DynamoDbController-getCibilDataBasedOnApplicantId successfully completed");
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"DynamoDbController : GET: Exception occured while fetching response from dynamo Db with applicantId",exception);
			throw new BFLBusinessException("DYDB_13", env.getProperty("DYDB_13"));
		}
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
}
