package com.bajaj.bfsd.report.writer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.model.Application;
import com.bajaj.bfsd.model.LoanApplication;
import com.bajaj.bfsd.repository.ApplicationRepository;
import com.bajaj.bfsd.repository.LoanApplicationRepository;
import com.bajaj.bfsd.util.DynamoDbEnums;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
public class CsvReportGeneration {

	@Value("${aws.s3.bucket.report-external-api-count:bfltestbucket-javateam/templates}")
	private String bucketName;

	@Autowired
	private AmazonS3Client amazonS3Client;

	@Autowired
	Environment env;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	LoanApplicationRepository loanApplicationRepo;

	@Autowired
	ApplicationRepository applicationRepo;

	@Autowired
	ReportWriter reportWriter;

	private static final String CLASS_NAME = CsvReportGeneration.class.getName();

	public Long generateReportForPerfios(List<Item> items, String currentDateString) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Started - Inside generateReportForPerfios()");
		long currenttime = System.currentTimeMillis();
		Long count = 0L;
		File temp = new File(DynamoDbEnums.REPORT_TEMP_FILE_PATH.value());
		List<String> headerColumns = buildHeaderColumns();
		Writer writer = null;

		try {
			writer = reportWriter.init(temp);
			reportWriter.addHeader(writer, headerColumns);

			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

			for (Item item : items) {
				long applicationId = 0l;
				if (null != item.get(DynamoDbEnums.PERFIOS_APPLICATION_ID_COL.value())) {
					applicationId = Long
							.parseLong(item.get(DynamoDbEnums.PERFIOS_APPLICATION_ID_COL.value()).toString());
				}
				LoanApplication loanApplication = loanApplicationRepo.findByApplicationKey(applicationId);
				String product = null;
				if (null != loanApplication && null != loanApplication.getLoanProduct())
					product = loanApplication.getLoanProduct().getLnproddesc();
				else {
					Application application = applicationRepo.findOne(applicationId);
					if (null != application && null != application.getProductCategory())
						product = application.getProductCategory().getProdcatdesc();
				}
				if (null != item.get(DynamoDbEnums.PERFIOS_RESPONSE_PAYLOAD_COL.value())) {
					Document doc = documentBuilder.parse(new InputSource(
							new StringReader(item.get(DynamoDbEnums.PERFIOS_RESPONSE_PAYLOAD_COL.value()).toString())));
					NodeList nodeList = doc.getElementsByTagName(DynamoDbEnums.RESPONSE_XML_NODE_ELEMENT.value());
					for (int nodeNum = 0; nodeNum < nodeList.getLength(); nodeNum++) {
						Node node = nodeList.item(nodeNum);
						List<String> columnValues = new ArrayList<String>();
						columnValues.add(item.get(DynamoDbEnums.PERFIOS_APPLICATION_ID_COL.value()).toString());
						columnValues.add(item.get(DynamoDbEnums.PERFIOS_APPLICANT_ID_COL.value()).toString());
						columnValues.add(product);
						columnValues.add(node.getAttributes().item(1).getNodeValue());
						columnValues.add(item.get(DynamoDbEnums.PERFIOS_REQUEST_DATE_COL.value()).toString());
						reportWriter.appendRow(writer, columnValues);
					}
				}
				count++;
			}
			writer.flush();
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Ended - Inside generateReportForPerfios() in: " + (System.currentTimeMillis() - currenttime));
			uploadToS3(temp, currentDateString);
		} catch (IOException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "File read/write exception. " + e);
			throw new BFLTechnicalException("File could not be read/write. ", e);
		} catch (SAXException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "XML response parsing failed. " + e);
			throw new BFLTechnicalException("Response Payload could not be parsed. ", e);
		} catch (ParserConfigurationException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Parser instantiation failure. " + e);
			throw new BFLTechnicalException("Parser did not instantited correctly. ", e);
		} finally {
			try {
				reportWriter.close(writer);
			} catch (IOException e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "error occured while closing the writer. " + e);
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Inside fetchExternalApiRequestsAndGenerateCsv started. Read count: " + count);
		return count;
	}

	private void uploadToS3(File tempFile, String currentDateTime) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Started - Inside uploadToS3");
		InputStream inputStream;
		try {
			inputStream = new FileInputStream(tempFile);
			byte[] bytes = IOUtils.toByteArray(inputStream);
			String fileName = DynamoDbEnums.REPORT_S3_FILE_PREFIX.value() + currentDateTime
					+ DynamoDbEnums.REPORT_S3_FILE_FORMAT.value();
			PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, fileName, tempFile);
			ObjectMetadata objectMetadata = new ObjectMetadata();
			objectMetadata.setContentLength(bytes.length);
			objectMetadata.setContentType("plain/text");
			objectMetadata.addUserMetadata("filename", fileName);
			putObjectRequest.setMetadata(objectMetadata);
			amazonS3Client.putObject(putObjectRequest);
			IOUtils.closeQuietly(inputStream);
			logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Ended - Inside uploadToS3");
		} catch (IOException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "File upload failed with exception: " + e);
			throw new BFLTechnicalException("File upload failed. ", e);
		}
	}

	private List<String> buildHeaderColumns() {
		List<String> headerColumns = new ArrayList<String>();
		headerColumns.add(DynamoDbEnums.REPORT_APPLICATION_ID.value());
		headerColumns.add(DynamoDbEnums.REPORT_APPLICANT_ID.value());
		headerColumns.add(DynamoDbEnums.REPORT_PRODUCT.value());
		headerColumns.add(DynamoDbEnums.REPORT_PERFIOS_TRANSACTION_ID.value());
		headerColumns.add(DynamoDbEnums.REPORT_REQUEST_TIME.value());
		return headerColumns;
	}
}
