package com.bajaj.bfsd.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the LOAN_PRODUCTS database table.
 * 
 */
@Entity
@Table(name="LOAN_PRODUCTS")
@NamedQuery(name="LoanProduct.findAll", query="SELECT l FROM LoanProduct l")
public class LoanProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long lnprodkey;

	private String lnprodcode;

	private String lnproddesc;

	private String lnprodisactive;

	private String lnprodlstupdateby;

	private Timestamp lnprodlstupdatedt;

	//bi-directional many-to-one association to LoanApplication
	@OneToMany(mappedBy="loanProduct")
	private List<LoanApplication> loanApplications;

	//bi-directional many-to-one association to ProductCategory
	@ManyToOne
	@JoinColumn(name="PRODCATKEY")
	private ProductCategory productCategory;

	public LoanProduct() {
	}

	public long getLnprodkey() {
		return this.lnprodkey;
	}

	public void setLnprodkey(long lnprodkey) {
		this.lnprodkey = lnprodkey;
	}

	public String getLnprodcode() {
		return this.lnprodcode;
	}

	public void setLnprodcode(String lnprodcode) {
		this.lnprodcode = lnprodcode;
	}

	public String getLnproddesc() {
		return this.lnproddesc;
	}

	public void setLnproddesc(String lnproddesc) {
		this.lnproddesc = lnproddesc;
	}

	public String getLnprodisactive() {
		return this.lnprodisactive;
	}

	public void setLnprodisactive(String lnprodisactive) {
		this.lnprodisactive = lnprodisactive;
	}

	public String getLnprodlstupdateby() {
		return this.lnprodlstupdateby;
	}

	public void setLnprodlstupdateby(String lnprodlstupdateby) {
		this.lnprodlstupdateby = lnprodlstupdateby;
	}

	public Timestamp getLnprodlstupdatedt() {
		return this.lnprodlstupdatedt;
	}

	public void setLnprodlstupdatedt(Timestamp lnprodlstupdatedt) {
		this.lnprodlstupdatedt = lnprodlstupdatedt;
	}

	public List<LoanApplication> getLoanApplications() {
		return this.loanApplications;
	}

	public void setLoanApplications(List<LoanApplication> loanApplications) {
		this.loanApplications = loanApplications;
	}

	public LoanApplication addLoanApplication(LoanApplication loanApplication) {
		getLoanApplications().add(loanApplication);
		loanApplication.setLoanProduct(this);

		return loanApplication;
	}

	public LoanApplication removeLoanApplication(LoanApplication loanApplication) {
		getLoanApplications().remove(loanApplication);
		loanApplication.setLoanProduct(null);

		return loanApplication;
	}

	public ProductCategory getProductCategory() {
		return this.productCategory;
	}

	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}

}