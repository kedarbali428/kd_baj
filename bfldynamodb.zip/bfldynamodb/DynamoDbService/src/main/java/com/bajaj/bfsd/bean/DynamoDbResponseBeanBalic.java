package com.bajaj.bfsd.bean;

import java.io.Serializable;

/**
 * 
 * @author 686009
 *
 */
public class DynamoDbResponseBeanBalic implements Serializable{

private static final long serialVersionUID = 1L;
	
	private String applicationKey;
	private String status;
	/**
	 * @return the applicationKey
	 */
	public String getApplicationKey() {
		return applicationKey;
	}
	/**
	 * @param applicationKey the applicationKey to set
	 */
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DynamoDbResponseBeanBalic [applicationKey=" + applicationKey + ", status=" + status + "]";
	}
	
	
}
