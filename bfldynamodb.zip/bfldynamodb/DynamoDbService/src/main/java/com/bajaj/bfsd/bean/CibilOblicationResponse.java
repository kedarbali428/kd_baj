package com.bajaj.bfsd.bean;

import java.io.Serializable;

public class CibilOblicationResponse implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;
	
	private String monthlyemi;
	private String principaloutstanding;
	private String loanType;
	private String loanstartdateordisburseddate;
	private String totalloansanctioned;
	private String lastreporteddate;
	private String totaltenure;
	private String loanenddate;
	private String roi;
	public String getMonthlyemi() {
		return monthlyemi;
	}
	public void setMonthlyemi(String monthlyemi) {
		this.monthlyemi = monthlyemi;
	}
	public String getPrincipaloutstanding() {
		return principaloutstanding;
	}
	public void setPrincipaloutstanding(String principaloutstanding) {
		this.principaloutstanding = principaloutstanding;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public String getLoanstartdateordisburseddate() {
		return loanstartdateordisburseddate;
	}
	public void setLoanstartdateordisburseddate(String loanstartdateordisburseddate) {
		this.loanstartdateordisburseddate = loanstartdateordisburseddate;
	}
	public String getTotalloansanctioned() {
		return totalloansanctioned;
	}
	public void setTotalloansanctioned(String totalloansanctioned) {
		this.totalloansanctioned = totalloansanctioned;
	}
	public String getLastreporteddate() {
		return lastreporteddate;
	}
	public void setLastreporteddate(String lastreporteddate) {
		this.lastreporteddate = lastreporteddate;
	}
	public String getTotaltenure() {
		return totaltenure;
	}
	public void setTotaltenure(String totaltenure) {
		this.totaltenure = totaltenure;
	}
	public String getLoanenddate() {
		return loanenddate;
	}
	public void setLoanenddate(String loanenddate) {
		this.loanenddate = loanenddate;
	}
	public String getRoi() {
		return roi;
	}
	public void setRoi(String roi) {
		this.roi = roi;
	}
	
}
