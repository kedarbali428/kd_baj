package com.bajaj.bfsd.bean;

import java.io.Serializable;
import java.util.List;

public class Obligation  implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;
	
	private List<EmiList> emiList;

	public List<EmiList> getEmiList() {
		return emiList;
	}

	public void setEmiList(List<EmiList> emiList) {
		this.emiList = emiList;
	}
	
	

}
