package com.bajaj.bfsd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

import com.bajaj.bfsd.common.business.baseclasses.BFLAsyncBusinessApplication;


@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan("com.bajaj.bfsd")
@PropertySource("application.properties")
@PropertySource("error.properties")
public class DynamoDbApplication extends BFLAsyncBusinessApplication {
	
	public static void main(String[] args) {
        SpringApplication.run(DynamoDbApplication.class, args);
	}
}
