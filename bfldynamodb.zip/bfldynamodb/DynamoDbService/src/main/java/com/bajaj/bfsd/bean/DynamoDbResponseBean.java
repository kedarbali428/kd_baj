package com.bajaj.bfsd.bean;

import java.io.Serializable;

public class DynamoDbResponseBean implements Serializable{

private static final long serialVersionUID = 1L;
	
	private String applicationId;
	private String applicantId;
	private String rawResponseUrl;
	
		/**
	 * @return the applicationId
	 */
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * @return the applicantId
	 */
	public String getApplicantId() {
		return applicantId;
	}

	/**
	 * @param applicantId the applicantId to set
	 */
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}

	/**
	 * @return the rawResponseUrl
	 */
	public String getRawResponseUrl() {
		return rawResponseUrl;
	}

	/**
	 * @param rawResponseUrl the rawResponseUrl to set
	 */
	public void setRawResponseUrl(String rawResponseUrl) {
		this.rawResponseUrl = rawResponseUrl;
	}


	@Override
	public String toString() {
		return "DynamoDbResponseBean [applicantId=" + applicantId + ", applicationKey=" + applicationId + "]";
	}

}
