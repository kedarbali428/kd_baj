package com.bajaj.bfsd.dao;

import java.util.List;

import com.bajaj.bfsd.bean.CibilOblicationResponse;
import com.bajaj.bfsd.bean.DynamoDbBean;
import com.bajaj.bfsd.bean.DynamoDbBeanBalic;
import com.bajaj.bfsd.bean.DynamoDbCibilBean;


public interface DynamoDbDao {

	public List<DynamoDbBean> get(String applicationId, String source, String type);
	
	public void insertRecord(DynamoDbBean dynamoDbBean);

	public List<CibilOblicationResponse> getcibilObligationDetails(String applicationId, String source);
	public void insertRecord(DynamoDbBeanBalic bean);

	public List<DynamoDbBeanBalic> getBalicDocUploadRequestDetailsRecord(String applicationKey, String source,
			String sourcetype);
	
	public Long fetchExternalApiRequestsAndGenerateCsv(String source);

	public void insertRecord(DynamoDbCibilBean requestBean);
	
	public List<DynamoDbCibilBean> get(String applicantId, String applicationId, String source , String type);
	
}
