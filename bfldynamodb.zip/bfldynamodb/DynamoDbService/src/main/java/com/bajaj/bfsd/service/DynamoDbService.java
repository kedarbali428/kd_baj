package com.bajaj.bfsd.service;

import java.util.List;

import com.bajaj.bfsd.bean.ApplicantDynamoDbBean;
import com.bajaj.bfsd.bean.CibilOblicationResponse;
import com.bajaj.bfsd.bean.DynamoDbBean;
import com.bajaj.bfsd.bean.DynamoDbBeanBalic;
import com.bajaj.bfsd.bean.DynamoDbCibilBean;
import com.bajaj.bfsd.bean.DynamoDbResponseBean;
import com.bajaj.bfsd.bean.DynamoDbResponseBeanBalic;
import com.bajaj.bfsd.common.domain.ResponseBean;

public interface DynamoDbService {

	public List<DynamoDbBean> read(String applicationId, String source, String type);

	public DynamoDbResponseBean create(DynamoDbBean applicantBean);
	
	public List<CibilOblicationResponse> getcibilObligationDetails(String applicationId, String source);

	public DynamoDbBean readForApplicant(ApplicantDynamoDbBean bean);
	public DynamoDbResponseBeanBalic createEntriesInDynamoDB(DynamoDbBeanBalic bean);
	List<DynamoDbBeanBalic> readBalicDocUploadRequestDetailsRecord(String applicationId, String source, String sourcetype);
	
	public ResponseBean uploadExternalApiStatusToS3(String source);

	public DynamoDbResponseBean insertCibilDataWithApplicantId(DynamoDbCibilBean requestBean);

	public DynamoDbCibilBean fetchCibilDataWithApplicantId(String applicantId, String applicationId, String source);
}
	

