package com.bajaj.bfsd;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.s3.AmazonS3Client;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;

/**
 * 
 * This class is used for DynamoDb configuration which will be fetched from
 * aplication.properties file.
 *
 */
@Configuration
public class DynamoDBConfig {

	@Autowired
	DynamoDBPropertiesConfigurer dynamoDBPropertiesConfigurer;

	@Autowired
	BFLLoggerUtil logger;
	
	@Value("${aws.s3.region}")
	private String region;

	private static final String CLASS_NAME = DynamoDBConfig.class.getName();

	@RefreshScope
	@Bean
	public AmazonDynamoDB amazonDynamoDB() {
		AmazonDynamoDB amazonDynamoDB;
		if ("Y".equals(dynamoDBPropertiesConfigurer.getDynamoDBProxyReuqired())) {
			amazonDynamoDB = new AmazonDynamoDBClient(clientConfiguration());
			logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Dynamo DB instance initialized with Proxy settings " + dynamoDBPropertiesConfigurer.getProxyHost() + " Proxy port:"
							+ dynamoDBPropertiesConfigurer.getProxyPort());
		} else {
			amazonDynamoDB = new AmazonDynamoDBClient();
		}

		if (!StringUtils.isEmpty(dynamoDBPropertiesConfigurer.getAmazonDynamoDBEndpoint())) {
			amazonDynamoDB.setEndpoint(dynamoDBPropertiesConfigurer.getAmazonDynamoDBEndpoint());
		}

		return amazonDynamoDB;
	}

	@RefreshScope
	@Bean
	public AWSCredentials amazonAWSCredentials() {
		return new BasicAWSCredentials(dynamoDBPropertiesConfigurer.getAmazonAWSAccessKey(),
				dynamoDBPropertiesConfigurer.getAmazonAWSSecretKey());
	}

	@RefreshScope
	@Bean
	public ClientConfiguration clientConfiguration() {
		ClientConfiguration clientConfiguration = new ClientConfiguration();
		clientConfiguration.setProxyHost(dynamoDBPropertiesConfigurer.getProxyHost());
		clientConfiguration.setProxyPort(dynamoDBPropertiesConfigurer.getProxyPort());

		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Setting proxy configuration Proxy Host:" + dynamoDBPropertiesConfigurer.getProxyHost() + " Proxy port:"
						+ dynamoDBPropertiesConfigurer.getProxyPort());
		return clientConfiguration;
	}

	@RefreshScope
	@Bean
	public DynamoDB dynamoDB() {
		return new DynamoDB(amazonDynamoDB());
	}
	
	@RefreshScope
	@Bean 
	public AmazonS3Client amazonS3Client(){
		AmazonS3Client amazonS3Client = new AmazonS3Client();
		amazonS3Client.setRegion(Region.getRegion(Regions.fromName(region)));
		return amazonS3Client;
	}
}