package com.bajaj.bfsd.bean;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DynamoDbBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String appnId; //Application Key

	private String applicantId;

	//@NotNull(message = "Source must not be null")
	private String source;

	@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
	private transient Object resPayload;
	
	private String resPayloadStr;

	// DynamoDB do not support Timestamp data type
	private String reqTimeStamp;

	private String resTimeStamp;

	private String rawResUrl;
	
	private String sourcetype;
	
	private String reqPayload;
	@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
	@JsonInclude(Include.NON_EMPTY)
	private Object reqObjPayload;

	public String getAppnId() {
		return appnId;
	}

	public void setAppnId(String appnId) {
		this.appnId = appnId;
	}

	public String getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Object getResPayload() {
		return resPayload;
	}

	public void setResPayload(Object resPayload) {
		this.resPayload = resPayload;
	}

	public String getReqTimeStamp() {
		return reqTimeStamp;
	}

	public void setReqTimeStamp(String reqTimeStamp) {
		this.reqTimeStamp = reqTimeStamp;
	}

	public String getResTimeStamp() {
		return resTimeStamp;
	}

	public void setResTimeStamp(String resTimeStamp) {
		this.resTimeStamp = resTimeStamp;
	}

	public String getRawResUrl() {
		return rawResUrl;
	}

	public void setRawResUrl(String rawResUrl) {
		this.rawResUrl = rawResUrl;
	}
	
	public String getResPayloadStr() {
		return resPayloadStr;
	}

	public void setResPayloadStr(String resPayloadStr) {
		this.resPayloadStr = resPayloadStr;
	}
	
	public String getSourcetype() {
		return sourcetype;
	}

	public void setSourcetype(String sourcetype) {
		this.sourcetype = sourcetype;
	}

	public String getReqPayload() {
		return reqPayload;
	}

	public void setReqPayload(String reqPayload) {
		this.reqPayload = reqPayload;
	}
	
	public Object getReqObjPayload() {
		return reqObjPayload;
	}

	public void setReqObjPayload(Object reqObjPayload) {
		this.reqObjPayload = reqObjPayload;
	}

	@Override
	public String toString() {
		return "DynamoDbBean [appnId=" + appnId + ", applicantId=" + applicantId + ", source=" + source
				+ ", resPayload=" + resPayload + ", resPayloadStr=" + resPayloadStr + ", reqTimeStamp=" + reqTimeStamp
				+ ", resTimeStamp=" + resTimeStamp + ", rawResUrl=" + rawResUrl + ", sourcetype=" + sourcetype
				+ ", reqPayload=" + reqPayload + ", reqObjPayload=" + reqObjPayload + "]";
	}

}
