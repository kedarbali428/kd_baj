package com.bajaj.bfsd.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the PRODUCT_CATEGORIES database table.
 * 
 */
@Entity
@Table(name="PRODUCT_CATEGORIES")
@NamedQuery(name="ProductCategory.findAll", query="SELECT p FROM ProductCategory p")
public class ProductCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long prodcatkey;

	private String prodcatcode;

	private String prodcatdesc;

	private BigDecimal prodcatisactive;

	private String prodcatlstupdateby;

	private Timestamp prodcatlstupdatedt;

	//bi-directional many-to-one association to Application
	@OneToMany(mappedBy="productCategory")
	private List<Application> applications;

	public ProductCategory() {
	}

	public long getProdcatkey() {
		return this.prodcatkey;
	}

	public void setProdcatkey(long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public String getProdcatcode() {
		return this.prodcatcode;
	}

	public void setProdcatcode(String prodcatcode) {
		this.prodcatcode = prodcatcode;
	}

	public String getProdcatdesc() {
		return this.prodcatdesc;
	}

	public void setProdcatdesc(String prodcatdesc) {
		this.prodcatdesc = prodcatdesc;
	}

	public BigDecimal getProdcatisactive() {
		return this.prodcatisactive;
	}

	public void setProdcatisactive(BigDecimal prodcatisactive) {
		this.prodcatisactive = prodcatisactive;
	}

	public String getProdcatlstupdateby() {
		return this.prodcatlstupdateby;
	}

	public void setProdcatlstupdateby(String prodcatlstupdateby) {
		this.prodcatlstupdateby = prodcatlstupdateby;
	}

	public Timestamp getProdcatlstupdatedt() {
		return this.prodcatlstupdatedt;
	}

	public void setProdcatlstupdatedt(Timestamp prodcatlstupdatedt) {
		this.prodcatlstupdatedt = prodcatlstupdatedt;
	}


	public List<Application> getApplications() {
		return this.applications;
	}

	public void setApplications(List<Application> applications) {
		this.applications = applications;
	}

	public Application addApplication(Application application) {
		getApplications().add(application);
		application.setProductCategory(this);

		return application;
	}

	public Application removeApplication(Application application) {
		getApplications().remove(application);
		application.setProductCategory(null);

		return application;
	}

}