package com.bajaj.bfsd.bean;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * 
 * @author 686009
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
@JsonInclude(Include.NON_EMPTY)
public class DynamoDbBeanBalic implements Serializable {

	private static final long serialVersionUID = 1L;

	private String applicationKey;

	private String balicAppKey;
	
	private String fileName;

	private String docType;

	private String docCategory;

	private String fileKey;

	private String timeStamp;

	private String source;

	private String sourcetype;

	public DynamoDbBeanBalic() {
		super();
	}

	/**
	 * @return the applicationKey
	 */
	public String getApplicationKey() {
		return applicationKey;
	}

	/**
	 * @param applicationKey
	 *            the applicationKey to set
	 */
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	/**
	 * @return the balicAppKey
	 */
	public String getBalicAppKey() {
		return balicAppKey;
	}

	/**
	 * @param balicAppKey
	 *            the balicAppKey to set
	 */
	public void setBalicAppKey(String balicAppKey) {
		this.balicAppKey = balicAppKey;
	}
	
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the docType
	 */
	public String getDocType() {
		return docType;
	}

	/**
	 * @param docType
	 *            the docType to set
	 */
	public void setDocType(String docType) {
		this.docType = docType;
	}

	/**
	 * @return the docCategory
	 */
	public String getDocCategory() {
		return docCategory;
	}

	/**
	 * @param docCategory
	 *            the docCategory to set
	 */
	public void setDocCategory(String docCategory) {
		this.docCategory = docCategory;
	}

	/**
	 * @return the fileKey
	 */
	public String getFileKey() {
		return fileKey;
	}

	/**
	 * @param fileKey
	 *            the fileKey to set
	 */
	public void setFileKey(String fileKey) {
		this.fileKey = fileKey;
	}

	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp
	 *            the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source
	 *            the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return the sourcetype
	 */
	public String getSourcetype() {
		return sourcetype;
	}

	/**
	 * @param sourcetype
	 *            the sourcetype to set
	 */
	public void setSourcetype(String sourcetype) {
		this.sourcetype = sourcetype;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DynamoDbBeanBalic [applicationKey=" + applicationKey + ", balicAppKey=" + balicAppKey + ", docType="
				+ docType + ", docCategory=" + docCategory + ", fileKey=" + fileKey + ", timeStamp=" + timeStamp
				+ ", source=" + source + " , sourcetype=" + sourcetype + "]";
	}

}
