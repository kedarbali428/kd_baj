package com.bajaj.bfsd.bean;

import java.io.Serializable;

public class EmiList  implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;
	
	private String emiCap;
	private String currentBalance;
	private String loanType;
	private String dateOpenedOrDisbursed;
	private String highCreditSanctionAmt;
	private String dateReportedAndCert;
	private String tenureCap;
	private String dateClosed;
	private String irrCap;

	public String getEmiCap() {
		return emiCap;
	}

	public void setEmiCap(String emiCap) {
		this.emiCap = emiCap;
	}

	public String getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getDateOpenedOrDisbursed() {
		return dateOpenedOrDisbursed;
	}

	public void setDateOpenedOrDisbursed(String dateOpenedOrDisbursed) {
		this.dateOpenedOrDisbursed = dateOpenedOrDisbursed;
	}

	public String getHighCreditSanctionAmt() {
		return highCreditSanctionAmt;
	}

	public void setHighCreditSanctionAmt(String highCreditSanctionAmt) {
		this.highCreditSanctionAmt = highCreditSanctionAmt;
	}

	public String getDateReportedAndCert() {
		return dateReportedAndCert;
	}

	public void setDateReportedAndCert(String dateReportedAndCert) {
		this.dateReportedAndCert = dateReportedAndCert;
	}

	public String getTenureCap() {
		return tenureCap;
	}

	public void setTenureCap(String tenureCap) {
		this.tenureCap = tenureCap;
	}

	public String getDateClosed() {
		return dateClosed;
	}

	public void setDateClosed(String dateClosed) {
		this.dateClosed = dateClosed;
	}

	public String getIrrCap() {
		return irrCap;
	}

	public void setIrrCap(String irrCap) {
		this.irrCap = irrCap;
	}
}
