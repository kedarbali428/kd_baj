package com.bajaj.bfsd.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the LOAN_APPLICATIONS database table.
 * 
 */
@Entity
@Table(name="LOAN_APPLICATIONS")
@NamedQuery(name="LoanApplication.findAll", query="SELECT l FROM LoanApplication l")
public class LoanApplication implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long lnapplicationkey;

	//bi-directional many-to-one association to Application
	@ManyToOne
	@JoinColumn(name="APPLICATIONKEY")
	private Application application;

	//bi-directional many-to-one association to LoanProduct
	@ManyToOne
	@JoinColumn(name="LNPRODKEY")
	private LoanProduct loanProduct;

	public LoanApplication() {
	}

	public long getLnapplicationkey() {
		return lnapplicationkey;
	}

	public void setLnapplicationkey(long lnapplicationkey) {
		this.lnapplicationkey = lnapplicationkey;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public LoanProduct getLoanProduct() {
		return loanProduct;
	}

	public void setLoanProduct(LoanProduct loanProduct) {
		this.loanProduct = loanProduct;
	}
	
}