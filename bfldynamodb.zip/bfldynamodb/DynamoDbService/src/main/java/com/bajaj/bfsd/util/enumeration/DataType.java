package com.bajaj.bfsd.util.enumeration;

public enum DataType {

    REQUEST("Request"),

    RESPONSE("Response");

	private String value;
		
	private DataType(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return this.value;
	}
}