package com.bajaj.bfsd.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.bean.ApplicantDynamoDbBean;
import com.bajaj.bfsd.bean.CibilOblicationResponse;
import com.bajaj.bfsd.bean.DynamoDbBean;
import com.bajaj.bfsd.bean.DynamoDbBeanBalic;
import com.bajaj.bfsd.bean.DynamoDbCibilBean;
import com.bajaj.bfsd.bean.DynamoDbResponseBean;
import com.bajaj.bfsd.bean.DynamoDbResponseBeanBalic;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLService;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.controller.DynamoDbController;
import com.bajaj.bfsd.dao.DynamoDbDao;
import com.bajaj.bfsd.service.DynamoDbService;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
public class DynamoDbServiceImpl extends BFLService implements DynamoDbService {

	@Autowired
	DynamoDbDao dynamodbDao;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;

	private static final String CLASS_NAME = DynamoDbController.class.getName();

	@Override
	public List<DynamoDbBean> read(String applicationId, String source, String sourcetype) {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Dynamo DB read operation initiated for application id:" + applicationId + " and source-value: " + source);
		List<DynamoDbBean> responseBean;
		try {
			responseBean = dynamodbDao.get(applicationId, source, sourcetype);
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occured while reading data from dynamo DB  for application id " + applicationId
							+ " and source : " + source + " Exception: " + exception,
					exception.getCause());
			throw new BFLTechnicalException("Exception occured reading data from dynamo DB for application id "
					+ applicationId + " and source : " + source, exception);
		}

		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Fetching details for dynamodb completed for application id:" + applicationId + " and source: " + source
						+ " Response is: " + responseBean);
		return responseBean;
	}

	@Override
	public DynamoDbResponseBean create(DynamoDbBean dynamoDbBean) {
		
		DynamoDbResponseBean responseBean = new DynamoDbResponseBean();

		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"DynamoDbController - DynamoDbServiceImpl Invoked: " + dynamoDbBean.toString());
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"DynamoDB create operation initiated for application id " + dynamoDbBean.getAppnId()
							+ " and source : " + dynamoDbBean.getSource());
			dynamodbDao.insertRecord(dynamoDbBean);
			responseBean.setApplicantId(dynamoDbBean.getApplicantId());
			responseBean.setApplicationId(dynamoDbBean.getAppnId());
			responseBean.setRawResponseUrl(dynamoDbBean.getRawResUrl());
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Create request of DynamoDbService completed");
			return responseBean;
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occured while inserting data into dynamo DB  for application id "
							+ dynamoDbBean.getAppnId() + " and source : " + dynamoDbBean.getSource() + " Exception: "
							+ exception,
					exception.getCause());
			throw new BFLTechnicalException("Exception occured inserting into dynamo Dbfor application id "
					+ dynamoDbBean.getAppnId() + " and source : " + dynamoDbBean.getSource(), exception);
		}
	}

	@Override
	public List<CibilOblicationResponse> getcibilObligationDetails(String applicationId, String source) {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Get cibil Obligation Details service method gets invoked for Application id :" + applicationId
						+ " and sournce-value : " + source);
		List<CibilOblicationResponse> bean;
		try {
			bean = dynamodbDao.getcibilObligationDetails(applicationId, source);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					env.getProperty("DYDB_04") + "for Application id :" + applicationId + " and sournce : " + source);
			throw e;
		}

		return bean;
	}

	@Override
	public DynamoDbBean readForApplicant(ApplicantDynamoDbBean bean) {
		DynamoDbBean dynamoDbBean;
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "readForApplicant()--Starts");
		if (null == bean.getApplicantId()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Invalid input. Mandatory parameter Applicant ID does not exist");
			throw new BFLBusinessException("DYDB_12", "Invalid input. Mandatory parameter Applicant ID does not exist");
		}
		List<DynamoDbBean> responseBean = dynamodbDao.get(bean.getAppnId(), bean.getSource(), null);
		if (null != responseBean && !responseBean.isEmpty()) {
			dynamoDbBean = fetchRequiredResponse(bean, responseBean);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,"Record for applicant does not exist for Application ID: " + bean.getAppnId() + " and source: "	+ bean.getSource());
			throw new BFLBusinessException("DYDB_11", "Record for applicant does not exist for Application ID: " + bean.getAppnId() + " and source: " + bean.getSource());
		}

		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "readForApplicant()--Ends");
		return dynamoDbBean;
	}

	/**
	 * @param bean
	 * @param dynamoDbBean
	 * @param responseBean
	 * @return
	 */
	private DynamoDbBean fetchRequiredResponse(ApplicantDynamoDbBean bean, List<DynamoDbBean> responseBean) {
		DynamoDbBean dynamoDbBean = null;
		/*if(null!=bean.getType() && !bean.getType().isEmpty() && (!bean.getSource().equalsIgnoreCase(bean.getType()))) {
			for (int cnt = responseBean.size()-1; cnt >= 0; cnt--) {
				if (bean.getType().equalsIgnoreCase(responseBean.get(cnt).getSourcetype())) {
					dynamoDbBean = responseBean.get(cnt);
					break;
				}
			}
		} else {*/
			for (int cnt = responseBean.size()-1; cnt >= 0; cnt--) {
				if (bean.getApplicantId().equalsIgnoreCase(responseBean.get(cnt).getApplicantId())) {
					dynamoDbBean = responseBean.get(cnt);
					break;
				}
			}
		//}
		return dynamoDbBean;
	}

	/**
	 * @author 686009
	 * @param bean
	 * @return DynamoDbResponseBeanBalic
	 */
	@Override
	public DynamoDbResponseBeanBalic createEntriesInDynamoDB(DynamoDbBeanBalic bean) {
		
		DynamoDbResponseBeanBalic responseBean = new DynamoDbResponseBeanBalic();
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "createEntriesInDynamoDB() Invoked: " + bean.toString());
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"DynamoDB create operation initiated for application id " + bean.getApplicationKey()
							+ " and source : " + bean.getSource());
			dynamodbDao.insertRecord(bean);
			responseBean.setApplicationKey(bean.getApplicationKey());
			responseBean.setStatus(StatusCode.SUCCESS.toString());
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Create request of DynamoDbService completed");
			return responseBean;
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occured while inserting data into dynamo DB  for application id "
							+ bean.getApplicationKey() + " and source : " + bean.getSource() + " Exception: " + exception, exception.getCause());
			throw new BFLTechnicalException("Exception occured while inserting data into dynamo Db for application id "
					+ bean.getApplicationKey() + " and source : " + bean.getSource(), exception);
		}
	}
	
	/**
	 * @author 686009
	 * @param applicationKey
	 * @param source
	 * @param sourcetype
	 * @return List<DynamoDbBeanBalic>
	 * 
	 */
	@Override
	public List<DynamoDbBeanBalic> readBalicDocUploadRequestDetailsRecord(String applicationKey, String source, String sourcetype) {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside readBalicDocUploadRequestDetailsRecord().. Dynamo DB read operation initiated for applicationKey: "
						+ applicationKey + " and source-value: " + source);
		List<DynamoDbBeanBalic> dynamoDbBeanBalic;
		try {
			dynamoDbBeanBalic = dynamodbDao.getBalicDocUploadRequestDetailsRecord(applicationKey, source, sourcetype);
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Inside readBalicDocUploadRequestDetailsRecord().. Exception occured while reading data from dynamo DB  for application id "
							+ applicationKey + " and source : " + source + " Exception: " + exception,
					exception.getCause());
			throw new BFLTechnicalException("Exception occured while reading data from dynamo DB for applicationKey: "
					+ applicationKey + " and source : " + source, exception);
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Exit From readBalicDocUploadRequestDetailsRecord().. Fetching details for dynamodb completed for applicationKey: "
						+ applicationKey + " and source: " + source + " Response is: " + dynamoDbBeanBalic);
		return dynamoDbBeanBalic;
	}
	
	@Override
	public ResponseBean uploadExternalApiStatusToS3(String source) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside uploadExternalApiStatusToS3 started.");
		Long count = dynamodbDao.fetchExternalApiRequestsAndGenerateCsv(source);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside uploadExternalApiStatusToS3 ended.");
		return new ResponseBean(count);
	}

	@Override
	public DynamoDbResponseBean insertCibilDataWithApplicantId(DynamoDbCibilBean dynamoDbCibilBean) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Creating dynamo db entry for cibil with applicantId" + dynamoDbCibilBean.getApplicantId() + 
				                   "and source- " + dynamoDbCibilBean.getSource());
		try {
			DynamoDbResponseBean responseBean = new DynamoDbResponseBean();
		    dynamodbDao.insertRecord(dynamoDbCibilBean);
			responseBean.setApplicantId(dynamoDbCibilBean.getApplicantId());
			responseBean.setApplicationId(dynamoDbCibilBean.getApplicationId());
			responseBean.setRawResponseUrl(dynamoDbCibilBean.getRawResponseUrl());
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Dynamo db entry created for applicantId-" + dynamoDbCibilBean.getApplicantId());
			return responseBean;
		}catch(Exception ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occured while inserting data into dynamo DB  for applicantid "
							+ dynamoDbCibilBean.getApplicantId()+ " and source : " + dynamoDbCibilBean.getSource() + " Exception: "
							+ ex,ex.getCause());
			throw new BFLTechnicalException("DYDB_16",env.getProperty("DYDB_16") + ex);
		}
	}

	@Override
	public DynamoDbCibilBean fetchCibilDataWithApplicantId(String applicantId, String applicationId, String source) {
		DynamoDbCibilBean dynamoCibilBean;
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchCibilDataWithApplicantId() - starts applicantId- "+
		applicantId + " , source- " + source);
		List<DynamoDbCibilBean> dynamoDbCibilBeanList= dynamodbDao.get(applicantId,applicationId, source,null);
		if (null != dynamoDbCibilBeanList && !dynamoDbCibilBeanList.isEmpty()) {
			dynamoCibilBean = fetchRequiredDataFromList(applicantId, dynamoDbCibilBeanList);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,"Record does not exist for applicantId: " + applicantId + " and source: "	+ source);
			throw new BFLBusinessException("DYDB_11", env.getProperty("DYDB_11") + applicantId+ " and source: " + source);
		}

		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchCibilDataWithApplicantId()--Ends");
		return dynamoCibilBean;

	}

	private DynamoDbCibilBean fetchRequiredDataFromList(String applicantId, List<DynamoDbCibilBean> dynamoDbCibilBeanList) {
		DynamoDbCibilBean dynamoCibilBean = null;
		for (int cnt = dynamoDbCibilBeanList.size()-1; cnt >= 0; cnt--) {
			if (applicantId.equalsIgnoreCase(dynamoDbCibilBeanList.get(cnt).getApplicantId())) {
				dynamoCibilBean = dynamoDbCibilBeanList.get(cnt);
				break;
			}
		}
		return dynamoCibilBean;
	}
}
