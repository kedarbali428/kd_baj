package com.bajaj.bfsd;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;

/**
 * 
 * This class is used for DynamoDb configuration which will be fetched from
 * aplication.properties file.
 *
 */
@RefreshScope
@Component
public class DynamoDBPropertiesConfigurer extends BFLComponent {

	@Value("${amazon.dynamodb.endpoint}")
	private String amazonDynamoDBEndpoint;
	
	@Value("${amazon.aws.accesskey}")
	private String amazonAWSAccessKey;
	
	@Value("${amazon.aws.secretkey}")
	private String amazonAWSSecretKey;
	
	@Value("${dynamoDB.proxy.required}")
	private String dynamoDBProxyReuqired;
	
	@Value("${proxy.address}")
	private String proxyHost;
	
	@Value("${proxy.port}")
	private Integer proxyPort;

	public String getAmazonDynamoDBEndpoint() {
		return amazonDynamoDBEndpoint;
	}

	public void setAmazonDynamoDBEndpoint(String amazonDynamoDBEndpoint) {
		this.amazonDynamoDBEndpoint = amazonDynamoDBEndpoint;
	}

	public String getAmazonAWSAccessKey() {
		return amazonAWSAccessKey;
	}

	public void setAmazonAWSAccessKey(String amazonAWSAccessKey) {
		this.amazonAWSAccessKey = amazonAWSAccessKey;
	}

	public String getAmazonAWSSecretKey() {
		return amazonAWSSecretKey;
	}

	public void setAmazonAWSSecretKey(String amazonAWSSecretKey) {
		this.amazonAWSSecretKey = amazonAWSSecretKey;
	}

	public String getDynamoDBProxyReuqired() {
		return dynamoDBProxyReuqired;
	}

	public void setDynamoDBProxyReuqired(String dynamoDBProxyReuqired) {
		this.dynamoDBProxyReuqired = dynamoDBProxyReuqired;
	}

	public String getProxyHost() {
		return proxyHost;
	}

	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}

	public Integer getProxyPort() {
		return proxyPort;
	}

	public void setProxyPort(Integer proxyPort) {
		this.proxyPort = proxyPort;
	}

}