package com.bajaj.bfsd.bean;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ApplicantDynamoDbBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String appnId; //Application Key

	private String applicantId;

	private String source;

	public String getAppnId() {
		return appnId;
	}

	public void setAppnId(String appnId) {
		this.appnId = appnId;
	}

	public String getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Override
	public String toString() {
		return "DynamoDbBean [appnId=" + appnId + ", applicantId=" + applicantId + ", source=" + source
				+  "]";
	}

}
