package com.bajaj.bfsd.controller;

import static org.mockito.Matchers.anyLong;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.internal.IteratorSupport;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.s3.AmazonS3Client;
import com.bajaj.bfsd.bean.ApplicantDynamoDbBean;
import com.bajaj.bfsd.bean.CibilOblicationResponse;
import com.bajaj.bfsd.bean.DynamoDbBean;
import com.bajaj.bfsd.bean.DynamoDbBeanBalic;
import com.bajaj.bfsd.bean.DynamoDbCibilBean;
import com.bajaj.bfsd.bean.DynamoDbResponseBean;
import com.bajaj.bfsd.bean.DynamoDbResponseBeanBalic;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLExceptionHandler;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.dao.DynamoDbDao;
import com.bajaj.bfsd.dao.impl.DynamoDbDaoImpl;
import com.bajaj.bfsd.model.Application;
import com.bajaj.bfsd.model.LoanApplication;
import com.bajaj.bfsd.model.LoanProduct;
import com.bajaj.bfsd.model.ProductCategory;
import com.bajaj.bfsd.report.writer.CsvReportGeneration;
import com.bajaj.bfsd.report.writer.ReportFileWriterImpl;
import com.bajaj.bfsd.report.writer.ReportWriter;
import com.bajaj.bfsd.repository.ApplicationRepository;
import com.bajaj.bfsd.repository.LoanApplicationRepository;
import com.bajaj.bfsd.service.DynamoDbService;
import com.bajaj.bfsd.service.impl.DynamoDbServiceImpl;
import com.bajaj.bfsd.util.DynamoDbEnums;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@SpringBootTest(classes = { BFLCommonRestClient.class })
@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:bootstrap.properties", "classpath:error.properties" })
public class DynamoDbControllerTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;

	@InjectMocks
	DynamoDbController dynamoDbController;

	@Mock
	DynamoDbService dynamoDBService;

	@Mock
	HttpHeaders header;

	@Mock
	BindingResult result;

	@Mock
	DynamoDB dynamoDb;

	@Mock
	AmazonS3Client amazonS3Client;

	@Mock
	Table table;

	@Mock
	private LoanApplicationRepository loanApplicationRepo;

	@Mock
	private ApplicationRepository applicationRepo;

	BFLExceptionHandler exceptionHandler;

	private MockMvc mockMvc;

	private DynamoDbService dynamoDbService2;
	private DynamoDbDao dynamoDBDao;
	private CsvReportGeneration csvReportGeneration;
	private ReportWriter reportWriter;

	private static final String FETCH_LATEST_RECORD = "api.nosql.audit.GET.uri";
	private static final String FETCH_LATEST_BRE_RECORD = "api.nosql.audit.bre.GET.uri";
	private static final String INSERT_NOSQL_DYNAMODB = "api.nosql.audit.POST.uri";
	private static final String DYNAMODB_FOR_SUBSECTION = "api.dynamoDB.subsection.POST.uri";
	private static final String FETCH_CIBIL_OBLICATION = "api.nosql.cibil.GET.uri";
	private static final String FETCH_ALL_RECORDS = "api.nosql.audit.applicant.POST.uri";
	private static final String SUBSECTION_CODE = "api.dynamoDB.subsection.GET.uri";
	private static final String INSERT_INTO_DYNAMODB = "api.nosql.balicdocs.POST.uri";
	private static final String FETCH_LATEST_BALIC = "api.nosql.balicdocs.GET.uri";
	private static final String FETCH_ALL_RECORDS_ID = "/nosqldata/audit/fetchall";
	private static final String REPORT_EXTERNAL_API = "api.nosql.externalapi.reports.GET.uri";
	private static final String CIBIL_VERSION_DATA_BY_APPLICANTID = "api.nosql.validation.cibil.versiondata.POST.uri";
	private static final String FETCH_CIBIL_VERSION_DATA_BY_APPLICANTID = "api.nosql.validation.cibil.versiondata.GET.uri";

	@Before
	public void setUp() {
		dynamoDbController = new DynamoDbController();
		exceptionHandler = new BFLExceptionHandler();

		this.mockMvc = MockMvcBuilders.standaloneSetup(dynamoDbController).setControllerAdvice(exceptionHandler)
				.addPlaceholderValue(FETCH_LATEST_RECORD, env.getProperty(FETCH_LATEST_RECORD))
				.addPlaceholderValue(FETCH_LATEST_BRE_RECORD, env.getProperty(FETCH_LATEST_BRE_RECORD))
				.addPlaceholderValue(INSERT_NOSQL_DYNAMODB, env.getProperty(INSERT_NOSQL_DYNAMODB))
				.addPlaceholderValue(FETCH_CIBIL_OBLICATION, env.getProperty(FETCH_CIBIL_OBLICATION))
				.addPlaceholderValue(FETCH_ALL_RECORDS, env.getProperty(FETCH_ALL_RECORDS))
				.addPlaceholderValue(INSERT_INTO_DYNAMODB, env.getProperty(INSERT_INTO_DYNAMODB))
				.addPlaceholderValue(FETCH_LATEST_BALIC, env.getProperty(FETCH_LATEST_BALIC))
				.addPlaceholderValue(FETCH_ALL_RECORDS_ID, FETCH_ALL_RECORDS_ID)
				.addPlaceholderValue(REPORT_EXTERNAL_API, env.getProperty(REPORT_EXTERNAL_API))
				.addPlaceholderValue(CIBIL_VERSION_DATA_BY_APPLICANTID, env.getProperty(CIBIL_VERSION_DATA_BY_APPLICANTID))
				.addPlaceholderValue(FETCH_CIBIL_VERSION_DATA_BY_APPLICANTID, env.getProperty(FETCH_CIBIL_VERSION_DATA_BY_APPLICANTID)).build();
		ReflectionTestUtils.setField(dynamoDbController, "logger", logger);
		ReflectionTestUtils.setField(dynamoDbController, "env", env);
		ReflectionTestUtils.setField(dynamoDbController, "dynamoDBService", dynamoDBService);
		ReflectionTestUtils.setField(exceptionHandler, "env", env);
	}

	@Test
	public void get_test() throws Exception {
		String sourcetype = "Gen";
		List<DynamoDbBean> dynamoDbBean = new ArrayList<DynamoDbBean>();
		DynamoDbBean dynamo = new DynamoDbBean();
		dynamoDbBean.add(dynamo);
		Mockito.when(dynamoDBService.read(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(dynamoDbBean);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(env.getProperty(FETCH_LATEST_RECORD));
		request.param("applicationId", "111");
		request.param("source", "CHM");
		ResultActions result = mockMvc.perform(request);
		result.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	}

	@Test
	public void getBRERecord_test() throws Exception {
		List<DynamoDbBean> dynamoDbBean = new ArrayList<DynamoDbBean>();
		DynamoDbBean dynamo = new DynamoDbBean();
		dynamoDbBean.add(dynamo);
		Mockito.when(dynamoDBService.read(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(dynamoDbBean);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(env.getProperty(FETCH_LATEST_BRE_RECORD));
		request.param("applicationId", "111");
		request.param("source", "CHM");
		request.param("sourcetype", "GEN");
		ResultActions result = mockMvc.perform(request);
		result.andReturn();
	}

	@Test
	public void get_testElse() throws Exception {
		String sourcetype = "Gen";
		List<DynamoDbBean> dynamoDbBean = new ArrayList<DynamoDbBean>();
		DynamoDbBean dynamo = new DynamoDbBean();
		dynamoDbBean.add(dynamo);
		Mockito.when(dynamoDBService.read(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(dynamoDbBean);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(env.getProperty(FETCH_LATEST_RECORD));
		request.param("applicationId", "111");
		request.param("source", "PERFIOS");
		ResultActions result = mockMvc.perform(request);
		result.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	}

	@Test
	public void get_testElseIf() throws Exception {
		String sourcetype = "Gen";
		List<DynamoDbBean> dynamoDbBean = new ArrayList<DynamoDbBean>();
		DynamoDbBean dynamo = new DynamoDbBean();
		dynamoDbBean.add(dynamo);
		Mockito.when(dynamoDBService.read(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(dynamoDbBean);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(env.getProperty(FETCH_LATEST_RECORD));
		request.param("applicationId", "111");
		request.param("source", "MEDLIFE");
		ResultActions result = mockMvc.perform(request);
		result.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	}

	@Test
	public void create_test() throws Exception {
		String resPayloadStr = "{\r\n" + "	\"applicationKey\": \"11\",\r\n" + "	\"balicAppKey\": \"22\",\r\n"
				+ "	\"docCategory\": \"nom\",\r\n" + "	\"docType\": \"aaa\",\r\n" + "	\"fileKey\": \"bbb\",\r\n"
				+ "	\"fileName\": \"ccc\",\r\n" + "	\"source\": \"ddd\",\r\n" + "	\"timeStamp\": \"22-11\"\r\n" + "}";
		DynamoDbBean bean = new DynamoDbBean();
		bean.setResPayloadStr(resPayloadStr);
		DynamoDbResponseBean dbResponseBean = new DynamoDbResponseBean();
		Mockito.when(dynamoDBService.create(Mockito.any())).thenReturn(dbResponseBean);
		dbResponseBean.setApplicantId("221");
		dbResponseBean.setApplicationId("AA1");
		dbResponseBean.setRawResponseUrl("abc.com");
		ResponseBean responseBean = new ResponseBean();
		List<ErrorBean> errorBeanList = new ArrayList<>();
		ErrorBean ebean = new ErrorBean();
		errorBeanList.add(ebean);
		this.mockMvc.perform(post(env.getProperty(INSERT_NOSQL_DYNAMODB)).content(resPayloadStr)
				.contentType(MediaType.APPLICATION_JSON)).andReturn();
	}

	@Test
	public void create_testExcep() throws Exception {
		String request = "{\r\n" + "	\"applicationKey\": \"11\",\r\n" + "	\"balicAppKey\": \"22\",\r\n"
				+ "	\"docCategory\": \"nom\",\r\n" + "	\"docType\": \"aaa\",\r\n" + "	\"fileKey\": \"bbb\",\r\n"
				+ "	\"fileName\": \"ccc\",\r\n" + "	\"source\": \"ddd\",\r\n" + "	\"timeStamp\": \"22-11\"\r\n" + "}";
		DynamoDbBean bean = new DynamoDbBean();
		Mockito.when(result.hasErrors()).thenReturn(true);
		DynamoDbResponseBean dbResponseBean = new DynamoDbResponseBean();
		Mockito.when(dynamoDBService.create(Mockito.any())).thenThrow(Exception.class);
		this.mockMvc.perform(
				post(env.getProperty(INSERT_NOSQL_DYNAMODB)).content(request).contentType(MediaType.APPLICATION_JSON))
				.andReturn();
	}

	@Test
	public void fetchresponseList_test() throws Exception {
		List<DynamoDbBean> dynamoDbBean = new ArrayList<DynamoDbBean>();
		Mockito.when(dynamoDBService.read(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(dynamoDbBean);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/nosqldata/audit/fetchall");
		request.param("applicationId", "111");
		request.param("source", "MEDLIFE");
		ResultActions result = mockMvc.perform(request);
		result.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	}

	@Test
	public void fetchresponseList_testExcep() throws Exception {
		List<DynamoDbBean> dynamoDbBean = new ArrayList<DynamoDbBean>();
		Mockito.when(dynamoDBService.read(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(BFLTechnicalException.class);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/nosqldata/audit/fetchall");
		request.param("applicationId", "111");
		request.param("source", "MEDLIFE");
		ResultActions result = mockMvc.perform(request);
		result.andReturn();
	}

	@Test
	public void cibilObligationDetails_test() throws Exception {
		ResponseBean bean = new ResponseBean();
		List<CibilOblicationResponse> response = new ArrayList<>();
		Mockito.when(dynamoDBService.getcibilObligationDetails(Mockito.any(), Mockito.any())).thenReturn(response);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(env.getProperty(FETCH_CIBIL_OBLICATION));
		request.param("applicationId", "111");
		request.param("source", "MEDLIFE");
		ResultActions result = mockMvc.perform(request);
		result.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	}

	@Test
	public void cibilObligationDetails_testExcep() throws Exception {
		ResponseBean bean = new ResponseBean();
		List<CibilOblicationResponse> response = new ArrayList<>();
		Mockito.when(dynamoDBService.getcibilObligationDetails(Mockito.any(), Mockito.any()))
				.thenThrow(BFLBusinessException.class);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(env.getProperty(FETCH_CIBIL_OBLICATION));
		request.param("applicationId", "111");
		request.param("source", "MEDLIFE");
		ResultActions result = mockMvc.perform(request);
		result.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	}

	@Test
	public void fetchResponseForApplicant_test() throws Exception {
		ResponseBean responseBean = new ResponseBean();
		DynamoDbBean dynamoDbBean = new DynamoDbBean();
		String request = "{\r\n" + "	\"applicantId\": \"11\",\r\n" + "	\"appnId\": \"A1\",\r\n"
				+ "	\"source\": \"test\"\r\n" + "}";
		ApplicantDynamoDbBean bean = new ApplicantDynamoDbBean();
		Mockito.when(dynamoDBService.readForApplicant(Mockito.any())).thenReturn(dynamoDbBean);
		this.mockMvc.perform(
				post(env.getProperty(FETCH_ALL_RECORDS)).content(request).contentType(MediaType.APPLICATION_JSON))
				.andReturn();
	}

	@Test
	public void fetchResponseForApplicant_testExcep() throws Exception {
		ResponseBean responseBean = new ResponseBean();
		DynamoDbBean dynamoDbBean = new DynamoDbBean();
		String request = "{\r\n" + "	\"applicantId\": \"11\",\r\n" + "	\"appnId\": \"A1\",\r\n"
				+ "	\"source\": \"test\"\r\n" + "}";
		ApplicantDynamoDbBean bean = new ApplicantDynamoDbBean();
		Mockito.when(dynamoDBService.readForApplicant(Mockito.any())).thenThrow(BFLBusinessException.class);
		this.mockMvc.perform(
				post(env.getProperty(FETCH_ALL_RECORDS)).content(request).contentType(MediaType.APPLICATION_JSON))
				.andReturn();
	}

	@Test
	public void createEntriesInDynamoDB_test() throws Exception {
		String request = "{\r\n" + "	\"applicationKey\": \"11\",\r\n" + "	\"balicAppKey\": \"22\",\r\n"
				+ "	\"docCategory\": \"nom\",\r\n" + "	\"docType\": \"aaa\",\r\n" + "	\"fileKey\": \"bbb\",\r\n"
				+ "	\"fileName\": \"ccc\",\r\n" + "	\"source\": \"ddd\",\r\n" + "	\"timeStamp\": \"22-11\"\r\n" + "}";
		List<ErrorBean> errorBeans;
		ResponseBean responseBean = new ResponseBean();
		List<ErrorBean> errorBeanList = new ArrayList<>();
		DynamoDbBeanBalic bean = new DynamoDbBeanBalic();
		DynamoDbResponseBeanBalic dynamoDbResponseBean = new DynamoDbResponseBeanBalic();
		Mockito.when(dynamoDBService.createEntriesInDynamoDB(Mockito.any())).thenReturn(dynamoDbResponseBean);
		this.mockMvc.perform(
				post(env.getProperty(INSERT_INTO_DYNAMODB)).content(request).contentType(MediaType.APPLICATION_JSON))
				.andReturn();
	}

	@Test
	public void createEntriesInDynamoDB_testExcp() throws Exception {
		String request = "{\r\n" + "	\"applicationKey\": \"11\",\r\n" + "	\"balicAppKey\": \"22\",\r\n"
				+ "	\"docCategory\": \"nom\",\r\n" + "	\"docType\": \"aaa\",\r\n" + "	\"fileKey\": \"bbb\",\r\n"
				+ "	\"fileName\": \"ccc\",\r\n" + "	\"source\": \"ddd\",\r\n" + "	\"timeStamp\": \"22-11\"\r\n" + "}";
		List<ErrorBean> errorBeans;
		ResponseBean responseBean = new ResponseBean();
		List<ErrorBean> errorBeanList = new ArrayList<>();
		DynamoDbBeanBalic bean = new DynamoDbBeanBalic();
		DynamoDbResponseBeanBalic dynamoDbResponseBean = new DynamoDbResponseBeanBalic();
		Mockito.when(dynamoDBService.createEntriesInDynamoDB(Mockito.any())).thenThrow(Exception.class);
		this.mockMvc.perform(
				post(env.getProperty(INSERT_INTO_DYNAMODB)).content(request).contentType(MediaType.APPLICATION_JSON))
				.andReturn();
	}

	@Test
	public void getBalicDocUploadRequestDetails_test() throws Exception {
		ResponseBean responseBean = null;
		List<DynamoDbBeanBalic> dynamoDbBeanBalicList = new ArrayList<>();
		DynamoDbBeanBalic dbBeanBalic = new DynamoDbBeanBalic();
		dynamoDbBeanBalicList.add(dbBeanBalic);
		Mockito.when(
				dynamoDBService.readBalicDocUploadRequestDetailsRecord(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(dynamoDbBeanBalicList);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(env.getProperty(FETCH_LATEST_BALIC));
		request.param("applicationKey", "12A");
		request.param("source", "MEDLIFE");
		request.param("sourcetype", "Test");
		ResultActions result = mockMvc.perform(request);
		result.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	}

	@Test
	public void getBalicDocUploadRequestDetails_testElse() throws Exception {
		ResponseBean responseBean = null;
		List<DynamoDbBeanBalic> dynamoDbBeanBalicList = null;
		Mockito.when(
				dynamoDBService.readBalicDocUploadRequestDetailsRecord(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(dynamoDbBeanBalicList);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(env.getProperty(FETCH_LATEST_BALIC));
		request.param("applicationKey", "12A");
		request.param("source", "MEDLIFE");
		request.param("sourcetype", "Test");
		ResultActions result = mockMvc.perform(request);
		result.andReturn();
	}

	@Test
	public void getBalicDocUploadRequestDetails_testExcep() throws Exception {
		ResponseBean responseBean = null;
		List<DynamoDbBeanBalic> dynamoDbBeanBalicList = null;
		Mockito.when(
				dynamoDBService.readBalicDocUploadRequestDetailsRecord(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(Exception.class);
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(env.getProperty(FETCH_LATEST_BALIC));
		request.param("applicationKey", "12A");
		request.param("source", "MEDLIFE");
		request.param("sourcetype", "Test");
		ResultActions result = mockMvc.perform(request);
		result.andReturn();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void uploadExternalApiStatusToS3_test() throws Exception {
		initEndToEndTest();
		Item item = buildTestData();
		LoanApplication loanApplication = new LoanApplication();
		LoanProduct loanProduct = new LoanProduct();
		loanProduct.setLnproddesc("Personal Loan");
		loanApplication.setLoanProduct(loanProduct);
		
		ItemCollection<QueryOutcome> items = Mockito.mock(ItemCollection.class);
		IteratorSupport<Item, QueryOutcome> iterator = Mockito.mock(IteratorSupport.class);
		Index index = Mockito.mock(Index.class);
		Mockito.when(dynamoDb.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(table.getIndex(Mockito.anyString())).thenReturn(index);
		Mockito.when(index.query(Mockito.any(QuerySpec.class))).thenReturn(items);
		Mockito.when(items.iterator()).thenReturn(iterator);
		Mockito.when(iterator.hasNext()).thenReturn(true).thenReturn(false);
		Mockito.when(iterator.next()).thenReturn(item);
		Mockito.when(loanApplicationRepo.findByApplicationKey(anyLong())).thenReturn(loanApplication);
		String source = "PERFIOS";
		this.mockMvc.perform(get(env.getProperty(REPORT_EXTERNAL_API), source).header("cmptcorrid", "correlationid"))
				.andExpect(status().isOk());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void uploadExternalApiStatusToS3_test_L3() throws Exception {
		initEndToEndTest();
		Item item = buildTestData();
		Application application = new Application();
		ProductCategory prodCat = new ProductCategory();
		prodCat.setProdcatdesc("Fixed Deposite");
		application.setProductCategory(prodCat);

		ItemCollection<QueryOutcome> items = Mockito.mock(ItemCollection.class);
		IteratorSupport<Item, QueryOutcome> iterator = Mockito.mock(IteratorSupport.class);
		Index index = Mockito.mock(Index.class);
		Mockito.when(dynamoDb.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(table.getIndex(Mockito.anyString())).thenReturn(index);
		Mockito.when(index.query(Mockito.any(QuerySpec.class))).thenReturn(items);
		Mockito.when(items.iterator()).thenReturn(iterator);
		Mockito.when(iterator.hasNext()).thenReturn(true).thenReturn(false);
		Mockito.when(iterator.next()).thenReturn(item);
		Mockito.when(applicationRepo.findOne(anyLong())).thenReturn(application);
		String source = "PERFIOS";
		this.mockMvc.perform(get(env.getProperty(REPORT_EXTERNAL_API), source).header("cmptcorrid", "correlationid"))
				.andExpect(status().isOk());
	}

	private void initEndToEndTest() {
		dynamoDbService2 = new DynamoDbServiceImpl();
		dynamoDBDao = new DynamoDbDaoImpl();
		csvReportGeneration = new CsvReportGeneration();
		reportWriter = new ReportFileWriterImpl();

		ReflectionTestUtils.setField(csvReportGeneration, "amazonS3Client", amazonS3Client);
		ReflectionTestUtils.setField(csvReportGeneration, "loanApplicationRepo", loanApplicationRepo);
		ReflectionTestUtils.setField(csvReportGeneration, "applicationRepo", applicationRepo);
		ReflectionTestUtils.setField(csvReportGeneration, "reportWriter", reportWriter);
		ReflectionTestUtils.setField(csvReportGeneration, "reportWriter", reportWriter);
		ReflectionTestUtils.setField(csvReportGeneration, "logger", logger);
		ReflectionTestUtils.setField(dynamoDBDao, "csvReportGeneration", csvReportGeneration);
		ReflectionTestUtils.setField(dynamoDBDao, "dynamo", dynamoDb);
		ReflectionTestUtils.setField(dynamoDBDao, "logger", logger);
		ReflectionTestUtils.setField(dynamoDbService2, "logger", logger);
		ReflectionTestUtils.setField(dynamoDbService2, "dynamodbDao", dynamoDBDao);
		ReflectionTestUtils.setField(dynamoDbController, "dynamoDBService", dynamoDbService2);
	}

	private Item buildTestData() {
		Item item = new Item();
		String applicationId = "1234";
		String applicantId = "1234";
		String status = "<Status files=\"available\" parts=\"7\" processing=\"pending\" txnId=\"26173\">\r\n"
				+ "  <Part errorCode=\"E_NO_ERROR\" perfiosTransactionId=\"KLFT1523955263386\" reason=\"\" status=\"success\"/>\r\n"
				+ "  <Part errorCode=\"E_USER_SESSION_EXPIRED\" perfiosTransactionId=\"XX6M1523955521842\" reason=\"Session expired.\" status=\"failure\"/>\r\n"
				+ "  <Part errorCode=\"E_USER_CANCELLED\" perfiosTransactionId=\"AQRG1523955531045\" reason=\"Cancelled by user.\" status=\"failure\"/>\r\n"
				+ "  <Part errorCode=\"E_USER_CANCELLED\" perfiosTransactionId=\"4FYN1523955546506\" reason=\"Cancelled by user.\" status=\"failure\"/>\r\n"
				+ "  <Part errorCode=\"E_NO_ERROR\" perfiosTransactionId=\"LCKE1523955562693\" reason=\"\" status=\"pending\"/>\r\n"
				+ "  <Part errorCode=\"E_USER_CANCELLED\" perfiosTransactionId=\"XGA81523955715808\" reason=\"Cancelled by user.\" status=\"failure\"/>\r\n"
				+ "  <Part errorCode=\"E_NO_ERROR\" perfiosTransactionId=\"XE661523955723860\" reason=\"\" status=\"success\"/>\r\n"
				+ "</Status>";
		long currentTimeInMillis = System.currentTimeMillis();
		Date currentDate = new Date(currentTimeInMillis);
		SimpleDateFormat sdf = new SimpleDateFormat(DynamoDbEnums.DYDB_SCAN_REQ_TIME_FORMAT.value());
		String requestDate = sdf.format(currentDate);

		item.with(DynamoDbEnums.PERFIOS_APPLICATION_ID_COL.value(), applicationId);
		item.with(DynamoDbEnums.PERFIOS_APPLICANT_ID_COL.value(), applicantId);
		item.with(DynamoDbEnums.PERFIOS_RESPONSE_PAYLOAD_COL.value(), status);
		item.with(DynamoDbEnums.PERFIOS_REQUEST_DATE_COL.value(), requestDate);

		return item;
	}
	
	@Test
	public void test_saveCibilDataBasedOnApplicantId() throws Exception {
		DynamoDbCibilBean requestBean = new DynamoDbCibilBean();
		requestBean.setApplicantId("1233");
		requestBean.setApplicationId("1231265");
		requestBean.setRawResponseUrl("");
		requestBean.setReqTimeStamp("20:43:12.556");
		requestBean.setResTimeStamp("2020-04-27 20:43:12.556");
		requestBean.setRequestPayload("APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000");
		requestBean.setResponsePayload(null);
		requestBean.setSource("CONSUMER_CIBIL_V3TOV1");
		requestBean.setSourcetype("CONSUMER_CIBIL_V3TOV1");
		String requestJson ="{\r\n" + 
				"  \"applicantId\": \"1213\",\r\n" + 
				"  \"applicationId\": \"1312434\",\r\n" + 
				"  \"rawResponseUrl\": \"\",\r\n" + 
				"  \"reqTimeStamp\": \"20:43:12.556\",\r\n" + 
				"  \"requestPayload\": \"\",\r\n" + 
				"  \"resTimeStamp\": \"20:43:12.556\",\r\n" + 
				"  \"responsePayload\": \"APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000\",\r\n" + 
				"  \"source\": \"CONSUMER_CIBIL_V3TOV1\",\r\n" + 
				"  \"sourcetype\": \"CONSUMER_CIBIL_V3TOV1\"\r\n" + 
				"}";
		DynamoDbResponseBean responseBean = new DynamoDbResponseBean();
		responseBean.setApplicantId("1233");
		responseBean.setApplicationId("1231265");
		Mockito.when(dynamoDBService.insertCibilDataWithApplicantId(Mockito.any())).thenReturn(responseBean);
		this.mockMvc.perform(MockMvcRequestBuilders.post(env.getProperty(CIBIL_VERSION_DATA_BY_APPLICANTID),"v1")
				.content(requestJson).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());
	}
	
	@Test
	public void test_saveCibilDataBasedOnApplicantId_Exception() throws Exception {
		DynamoDbCibilBean requestBean = new DynamoDbCibilBean();
		requestBean.setApplicantId("1233");
		requestBean.setApplicationId("1231265");
		requestBean.setRawResponseUrl("");
		requestBean.setReqTimeStamp("20:43:12.556");
		requestBean.setResTimeStamp("2020-04-27 20:43:12.556");
		requestBean.setRequestPayload("APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000");
		requestBean.setResponsePayload(null);
		requestBean.setSource("CONSUMER_CIBIL_V3TOV1");
		requestBean.setSourcetype("CONSUMER_CIBIL_V3TOV1");
		String requestJson ="{\r\n" + 
				"  \"applicantId\": \"1213\",\r\n" + 
				"  \"applicationId\": \"1312434\",\r\n" + 
				"  \"rawResponseUrl\": \"\",\r\n" + 
				"  \"reqTimeStamp\": \"20:43:12.556\",\r\n" + 
				"  \"requestPayload\": \"\",\r\n" + 
				"  \"resTimeStamp\": \"20:43:12.556\",\r\n" + 
				"  \"responsePayload\": \"APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000\",\r\n" + 
				"  \"source\": \"CONSUMER_CIBIL_V3TOV1\",\r\n" + 
				"  \"sourcetype\": \"CONSUMER_CIBIL_V3TOV1\"\r\n" + 
				"}";
		DynamoDbResponseBean responseBean = new DynamoDbResponseBean();
		responseBean.setApplicantId("1233");
		responseBean.setApplicationId("1231265");
		Mockito.when(dynamoDBService.insertCibilDataWithApplicantId(Mockito.any())).thenThrow(new BFLTechnicalException());
		this.mockMvc.perform(MockMvcRequestBuilders.post(env.getProperty(CIBIL_VERSION_DATA_BY_APPLICANTID),"v1")
				.content(requestJson).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());
	}
	
	@Test
	public void test_saveCibilDataBasedOnApplicantId_ErrorInRequesy() throws Exception {
		DynamoDbCibilBean requestBean = new DynamoDbCibilBean();
		requestBean.setApplicantId("1233");
		requestBean.setApplicationId("1231265");
		requestBean.setRawResponseUrl("");
		requestBean.setReqTimeStamp("20:43:12.556");
		requestBean.setResTimeStamp("2020-04-27 20:43:12.556");
		requestBean.setRequestPayload("APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000");
		requestBean.setResponsePayload(null);
		requestBean.setSource("CONSUMER_CIBIL_V3TOV1");
		requestBean.setSourcetype("CONSUMER_CIBIL_V3TOV1");
		String requestJson ="{\r\n" + 
				"  \"applicantId\": null,\r\n" + 
				"  \"applicationId\": \"1312434\",\r\n" + 
				"  \"rawResponseUrl\": null,\r\n" + 
				"  \"reqTimeStamp\": \"2020-04-27 20:43:12.556\",\r\n" + 
				"  \"requestPayload\": null,\r\n" + 
				"  \"resTimeStamp\": \"2020-04-27 20:43:12.556\",\r\n" + 
				"  \"responsePayload\": \"APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000\",\r\n" + 
				"  \"source\": \"CONSUMER_CIBIL_V3TOV1\",\r\n" + 
				"  \"sourcetype\": \"CONSUMER_CIBIL_V3TOV1\"\r\n" + 
				"}";
		DynamoDbResponseBean responseBean = new DynamoDbResponseBean();
		responseBean.setApplicantId("1233");
		responseBean.setApplicationId("1231265");
		Mockito.when(dynamoDBService.insertCibilDataWithApplicantId(Mockito.any())).thenThrow(new BFLTechnicalException());
		this.mockMvc.perform(MockMvcRequestBuilders.post(env.getProperty(CIBIL_VERSION_DATA_BY_APPLICANTID),"v1")
				.content(requestJson).contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isBadRequest());
	}
	
	
	@Test
	public void getCibilDataBasedOnApplicantId() throws Exception {
		DynamoDbCibilBean dynamoCibilBean = new DynamoDbCibilBean();
		dynamoCibilBean.setApplicantId("1233");
		dynamoCibilBean.setApplicationId("1231265");
		dynamoCibilBean.setRawResponseUrl("");
		dynamoCibilBean.setReqTimeStamp("20:43:12.556");
		dynamoCibilBean.setResTimeStamp("2020-04-27 20:43:12.556");
		dynamoCibilBean.setRequestPayload("APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000");
		dynamoCibilBean.setResponsePayload(null);
		dynamoCibilBean.setSource("CONSUMER_CIBIL_V3TOV1");
		dynamoCibilBean.setSourcetype("CONSUMER_CIBIL_V3TOV1");
		Mockito.when(dynamoDBService.fetchCibilDataWithApplicantId(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(dynamoCibilBean);
		this.mockMvc.perform(MockMvcRequestBuilders.get(env.getProperty(FETCH_CIBIL_VERSION_DATA_BY_APPLICANTID),"v1","1233")
				.param("source", "CONSUMER_CIBIL_V3TOV1")
				.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());
	}
	
	@Test
	public void getCibilDataBasedOnApplicantId_witNoSourcePassed() throws Exception {
		DynamoDbCibilBean dynamoCibilBean = new DynamoDbCibilBean();
		dynamoCibilBean.setApplicantId("1233");
		dynamoCibilBean.setApplicationId("1231265");
		dynamoCibilBean.setRawResponseUrl("");
		dynamoCibilBean.setReqTimeStamp("20:43:12.556");
		dynamoCibilBean.setResTimeStamp("2020-04-27 20:43:12.556");
		dynamoCibilBean.setRequestPayload("APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000");
		dynamoCibilBean.setResponsePayload(null);
		dynamoCibilBean.setSource("CONSUMER_CIBIL_V3TOV1");
		dynamoCibilBean.setSourcetype("CONSUMER_CIBIL_V3TOV1");
		Mockito.when(dynamoDBService.fetchCibilDataWithApplicantId(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(dynamoCibilBean);
		this.mockMvc.perform(MockMvcRequestBuilders.get(env.getProperty(FETCH_CIBIL_VERSION_DATA_BY_APPLICANTID),"v1","1233")
				.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());
	}
	
	@Test
	public void getCibilDataBasedOnApplicantId_serviceResponseNull() throws Exception {
		Mockito.when(dynamoDBService.fetchCibilDataWithApplicantId(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		this.mockMvc.perform(MockMvcRequestBuilders.get(env.getProperty(FETCH_CIBIL_VERSION_DATA_BY_APPLICANTID),"v1","1233")
				.param("source", "CONSUMER_CIBIL_V3TOV1")
				.param("applicationId", "12345")
				.contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());
	}
}


