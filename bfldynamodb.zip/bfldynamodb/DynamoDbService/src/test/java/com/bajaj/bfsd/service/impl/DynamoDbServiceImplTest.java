package com.bajaj.bfsd.service.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.internal.IteratorSupport;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.bajaj.bfsd.DynamoDBConfig;
import com.bajaj.bfsd.bean.ApplicantDynamoDbBean;
import com.bajaj.bfsd.bean.CibilOblicationResponse;
import com.bajaj.bfsd.bean.DynamoDbBean;
import com.bajaj.bfsd.bean.DynamoDbBeanBalic;
import com.bajaj.bfsd.bean.DynamoDbCibilBean;
import com.bajaj.bfsd.bean.DynamoDbResponseBean;
import com.bajaj.bfsd.bean.DynamoDbResponseBeanBalic;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.dao.DynamoDbDao;
import com.bajaj.bfsd.dao.impl.DynamoDbDaoImpl;
import com.bajaj.bfsd.report.writer.CsvReportGeneration;
import com.bajaj.bfsd.report.writer.ReportFileWriterImpl;
import com.bajaj.bfsd.util.DynamoDbEnums;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@SpringBootTest(classes = { BFLCommonRestClient.class }, value = { "classpath:logger.properties",
"classpath:error.properties" })
@RunWith(SpringJUnit4ClassRunner.class)
public class DynamoDbServiceImplTest {
	@InjectMocks
	DynamoDbServiceImpl dynamoDbServiceImpl;
	
	@Mock
	DynamoDbDao dynamodbDao;

	@Mock
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;
	
	@Mock
	DynamoDB dynamo;

	@Mock
	Table table;

	@Mock
	DynamoDBConfig dynamoDBConfig;
	
	@Before
	public void setUp() {
		dynamoDbServiceImpl = new DynamoDbServiceImpl();
		ReflectionTestUtils.setField(dynamoDbServiceImpl, "logger", logger);
		ReflectionTestUtils.setField(dynamoDbServiceImpl, "env", env);
	}
	@Test
	public void read_test() {
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		String applicationId="121";
		String source="test";
		String sourcetype="Jtest";
		List<DynamoDbBean> responseBean=new ArrayList<DynamoDbBean>();
		Mockito.when(dynamodbDao.get(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(responseBean);
		dynamoDbServiceImpl.read(applicationId, source, sourcetype);	
	}
	@Test(expected=BFLTechnicalException.class)
	public void read_testExcep() {
		String applicationId="";
		String source="";
		String sourcetype="";
		dynamoDbServiceImpl.read(applicationId, source, sourcetype);	
	}
	@Test
	public void create_test() {
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		DynamoDbBean dynamoDbBean=new DynamoDbBean();
		DynamoDbResponseBean responseBean = new DynamoDbResponseBean();
		dynamoDbServiceImpl.create(dynamoDbBean);
	}
	@Test(expected=BFLTechnicalException.class)
	public void create_testExcep() {
		DynamoDbBean dynamoDbBean=new DynamoDbBean();
		DynamoDbResponseBean responseBean = new DynamoDbResponseBean();
		dynamoDbServiceImpl.create(dynamoDbBean);
	}
	@Test
	public void getcibilObligationDetails_test() {
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		String applicationId="AA1";
		String source="test";
		List<CibilOblicationResponse> bean=new ArrayList<>();
		CibilOblicationResponse cibilOblicationResponse=new CibilOblicationResponse();
		bean.add(cibilOblicationResponse);
		Mockito.when(dynamodbDao.getcibilObligationDetails(Mockito.any(),Mockito.any())).thenReturn(bean);
		dynamoDbServiceImpl.getcibilObligationDetails(applicationId, source);
	}
	@Test(expected=Exception.class)
	public void getcibilObligationDetails_testExcep() {
		String applicationId="AA1";
		String source="test";
		List<CibilOblicationResponse> bean=new ArrayList<>();
		CibilOblicationResponse cibilOblicationResponse=new CibilOblicationResponse();
		bean.add(cibilOblicationResponse);
		dynamoDbServiceImpl.getcibilObligationDetails(applicationId, source);
	}
	@Test(expected=BFLBusinessException.class )
	public void readForApplicant_testExcep() {
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		ApplicantDynamoDbBean bean=new ApplicantDynamoDbBean();
		dynamoDbServiceImpl.readForApplicant(bean);
	}
	@Test
	public void readForApplicant_test() {
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		ApplicantDynamoDbBean bean=new ApplicantDynamoDbBean();
		bean.setApplicantId("110");
		bean.setAppnId("avb");
		bean.setSource("test");
		List<DynamoDbBean> responseBean=new ArrayList<>();
		DynamoDbBean dynamoDbBean=new DynamoDbBean();
		responseBean.add(dynamoDbBean);
		Mockito.when(dynamodbDao.get(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(responseBean);
		dynamoDbServiceImpl.readForApplicant(bean);
	}
	@Test(expected=BFLBusinessException.class )
	public void readForApplicant_testBFL() {
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		ApplicantDynamoDbBean bean=new ApplicantDynamoDbBean();
		bean.setApplicantId("110");
		bean.setAppnId("avb");
		bean.setSource("test");
		dynamoDbServiceImpl.readForApplicant(bean);
	}
	@Test
	public void createEntriesInDynamoDB_test() {
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		DynamoDbBeanBalic bean=new DynamoDbBeanBalic();
		DynamoDbResponseBeanBalic responseBean = new DynamoDbResponseBeanBalic();
		dynamoDbServiceImpl.createEntriesInDynamoDB(bean);
	}
	@Test(expected=BFLTechnicalException.class)
	public void createEntriesInDynamoDB_testExcep() {
		DynamoDbBeanBalic bean=new DynamoDbBeanBalic();
		DynamoDbResponseBeanBalic responseBean = new DynamoDbResponseBeanBalic();
		dynamoDbServiceImpl.createEntriesInDynamoDB(bean);
	}
	@Test
	public void readBalicDocUploadRequestDetailsRecord_test() {
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		String applicationKey="1213";
		String source="test";
		String sourcetype="jtest";
		List<DynamoDbBeanBalic> dynamoDbBeanBalic=new ArrayList<>();
		DynamoDbBeanBalic dbBeanBalic=new DynamoDbBeanBalic();
		dynamoDbBeanBalic.add(dbBeanBalic);
		Mockito.when(dynamodbDao.getBalicDocUploadRequestDetailsRecord(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(dynamoDbBeanBalic);
		dynamoDbServiceImpl.readBalicDocUploadRequestDetailsRecord(applicationKey, source, sourcetype);
	}
	@Test(expected=BFLTechnicalException.class)
	public void readBalicDocUploadRequestDetailsRecord_testExcep() {
		String applicationKey="1213";
		String source="test";
		String sourcetype="jtest";
		dynamoDbServiceImpl.readBalicDocUploadRequestDetailsRecord(applicationKey, source, sourcetype);
	}

	@Test
	public void test_insertCibilDataWithApplicantId() {
		dynamodbDao = new DynamoDbDaoImpl();
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		ReflectionTestUtils.setField(dynamodbDao,"logger", logger);
		ReflectionTestUtils.setField(dynamodbDao,"env", env);
		ReflectionTestUtils.setField(dynamodbDao, "dynamoDBConfig", dynamoDBConfig);
		ReflectionTestUtils.setField(dynamodbDao, "dynamo", dynamo);
		DynamoDbCibilBean dynamoCibilBean = new DynamoDbCibilBean();
		dynamoCibilBean.setApplicantId("1233");
		dynamoCibilBean.setApplicationId("1231265");
		dynamoCibilBean.setRawResponseUrl(null);
		dynamoCibilBean.setReqTimeStamp("2020-04-27 20:43:12.556");
		dynamoCibilBean.setResTimeStamp("2020-04-27 20:43:12.556");
		dynamoCibilBean.setRequestPayload(null);
		dynamoCibilBean.setResponsePayload("APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000");
		dynamoCibilBean.setSource("CONSUMER_CIBIL_V3TOV1");
		dynamoCibilBean.setSourcetype("CONSUMER_CIBIL_V3TOV1");
		Table table = Mockito.mock(Table.class);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamo);
		Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		DynamoDbResponseBean responseBean = dynamoDbServiceImpl.insertCibilDataWithApplicantId(dynamoCibilBean);
	    assertNotNull(responseBean);
	}

	@Test(expected=BFLTechnicalException.class)
	public void test_insertCibilDataWithApplicantId_Exception() {
		dynamodbDao = new DynamoDbDaoImpl();
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		ReflectionTestUtils.setField(dynamodbDao,"logger", logger);
		ReflectionTestUtils.setField(dynamodbDao,"env", env);
		ReflectionTestUtils.setField(dynamodbDao, "dynamoDBConfig", dynamoDBConfig);
		ReflectionTestUtils.setField(dynamodbDao, "dynamo", dynamo);
		DynamoDbCibilBean dynamoCibilBean = new DynamoDbCibilBean();
		dynamoCibilBean.setApplicantId("1233");
		dynamoCibilBean.setApplicationId("1231265");
		dynamoCibilBean.setRawResponseUrl("");
		dynamoCibilBean.setReqTimeStamp("20:43:12.556");
		dynamoCibilBean.setResTimeStamp("2020-04-27 20:43:12.556");
		dynamoCibilBean.setRequestPayload(null);
		dynamoCibilBean.setResponsePayload("APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000");
		dynamoCibilBean.setSource("CONSUMER_CIBIL_V3TOV1");
		dynamoCibilBean.setSourcetype("CONSUMER_CIBIL_V3TOV1");
		Table table = Mockito.mock(Table.class);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamo);
				Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		DynamoDbResponseBean responseBean = dynamoDbServiceImpl.insertCibilDataWithApplicantId(dynamoCibilBean);
	    assertNotNull(responseBean);
	}

	@Test(expected = BFLTechnicalException.class)
	public void test_fetchCibilDataWithApplicantId_Exception() {
		dynamodbDao = new DynamoDbDaoImpl();
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		ReflectionTestUtils.setField(dynamodbDao,"logger", logger);
		ReflectionTestUtils.setField(dynamodbDao,"env", env);
		ReflectionTestUtils.setField(dynamodbDao, "dynamoDBConfig", dynamoDBConfig);
		ReflectionTestUtils.setField(dynamodbDao, "dynamo", dynamo);
		String applicantId="1213";
		String source = "CONSUMER_CIBIL_V3TOV1";
		DynamoDbCibilBean  dynamoCibilBean = dynamoDbServiceImpl.fetchCibilDataWithApplicantId(applicantId, null, source);
		
	}
	
	@Test
	public void test_fetchCibilDataWithApplicantId() {
		dynamodbDao = new DynamoDbDaoImpl();
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		ReflectionTestUtils.setField(dynamodbDao,"logger", logger);
		ReflectionTestUtils.setField(dynamodbDao,"env", env);
		ReflectionTestUtils.setField(dynamodbDao, "dynamoDBConfig", dynamoDBConfig);
		ReflectionTestUtils.setField(dynamodbDao, "dynamo", dynamo);
		String applicantId="1213";
		String source = "CONSUMER_CIBIL_V3TOV1";
		Table table = Mockito.mock(Table.class);
		Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamo);
		ItemCollection<QueryOutcome> items = Mockito.mock(ItemCollection.class);
		IteratorSupport<Item, QueryOutcome> iterator = Mockito.mock(IteratorSupport.class);
		Item item = Mockito.mock(Item.class);
		Mockito.when(table.query(Mockito.any(QuerySpec.class))).thenReturn(items);
		Mockito.when(items.iterator()).thenReturn(iterator);
		Mockito.when(iterator.hasNext()).thenReturn(true).thenReturn(false);
		Item  returnItem= new Item();
		returnItem.with("applicationId","1234");
		returnItem.with("applicantId", "1213");
		returnItem.with("reqTime", "2020-04-27 20:43:12.556");
		returnItem.with("rawResUrl", null);
		returnItem.with("resTimeStamp", "2020-04-27 20:43:12.556");
		returnItem.with("resPayload", "APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000");
		Mockito.when(iterator.next()).thenReturn(returnItem);
		DynamoDbCibilBean  dynamoCibilBean = dynamoDbServiceImpl.fetchCibilDataWithApplicantId(applicantId, null, source);
		assertNotNull(dynamoCibilBean);
	}
	
	@Test
	public void test_fetchCibilDataWithApplicantId_WithApplicationId() {
		dynamodbDao = new DynamoDbDaoImpl();
		ReflectionTestUtils.setField(dynamoDbServiceImpl,"dynamodbDao", dynamodbDao);
		ReflectionTestUtils.setField(dynamodbDao,"logger", logger);
		ReflectionTestUtils.setField(dynamodbDao,"env", env);
		ReflectionTestUtils.setField(dynamodbDao, "dynamoDBConfig", dynamoDBConfig);
		ReflectionTestUtils.setField(dynamodbDao, "dynamo", dynamo);
		String applicantId="1213";
		String applicationId="1234";
		String source = "CONSUMER_CIBIL_V3TOV1";
		Table table = Mockito.mock(Table.class);
		Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamo);
		ItemCollection<QueryOutcome> items = Mockito.mock(ItemCollection.class);
		IteratorSupport<Item, QueryOutcome> iterator = Mockito.mock(IteratorSupport.class);
		Item item = Mockito.mock(Item.class);
		Mockito.when(table.query(Mockito.any(QuerySpec.class))).thenReturn(items);
		Index index = Mockito.mock(Index.class);
		Mockito.when(table.getIndex(Mockito.anyString())).thenReturn(index);
		Mockito.when(index.query(Mockito.any(QuerySpec.class))).thenReturn(items);
			Item  returnItem= new Item();
		returnItem.with("applicationId","1234");
		returnItem.with("applicantId", "1213");
		returnItem.with("reqTime", "2020-04-27 20:43:12.556");
		returnItem.with("rawResUrl", null);
		returnItem.with("resTimeStamp", "2020-04-27 20:43:12.556");
		returnItem.with("resPayload", "APPLICATION_310000000003927/CONSUMERCIBIL_V1_84bbd852-d1ed-465b-beb5-42853dcdfeaf_445000000");
		Mockito.when(items.iterator()).thenReturn(iterator);
		Mockito.when(iterator.hasNext()).thenReturn(true).thenReturn(false);
		Mockito.when(iterator.next()).thenReturn(returnItem);
		DynamoDbCibilBean  dynamoCibilBean = dynamoDbServiceImpl.fetchCibilDataWithApplicantId(applicantId, applicationId, source);
		assertNotNull(dynamoCibilBean);
	}
	
}
