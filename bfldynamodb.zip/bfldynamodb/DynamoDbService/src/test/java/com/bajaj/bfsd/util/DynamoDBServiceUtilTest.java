package com.bajaj.bfsd.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.authentication.util.DateTimeUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;

@SpringBootTest(classes = { BFLCommonRestClient.class }, value = { "classpath:logger.properties",
		"classpath:error.properties" })
@RunWith(SpringJUnit4ClassRunner.class)
public class DynamoDBServiceUtilTest {

	@InjectMocks
	DynamoDBServiceUtil dynamoDBServiceUtil;

	@Test
	public void getTimeInLong_test() {
		String requestTimestamp = DateTimeUtil.getCurrentDate().toString();
		dynamoDBServiceUtil.getTimeInLong(requestTimestamp);
	}
	
}
