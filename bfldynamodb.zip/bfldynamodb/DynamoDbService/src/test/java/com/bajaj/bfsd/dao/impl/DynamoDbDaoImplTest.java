package com.bajaj.bfsd.dao.impl;

import static org.junit.Assert.assertNotNull;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.internal.IteratorSupport;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.bajaj.bfsd.DynamoDBConfig;
import com.bajaj.bfsd.authentication.util.DateTimeUtil;
import com.bajaj.bfsd.bean.CibilOblicationResponse;
import com.bajaj.bfsd.bean.CibilObligation;
import com.bajaj.bfsd.bean.DynamoDbBean;
import com.bajaj.bfsd.bean.DynamoDbBeanBalic;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.util.DynamoDBServiceUtil;
import com.bfl.common.exceptions.BFLTechnicalException;

@SpringBootTest(classes = { BFLCommonRestClient.class }, value = { "classpath:logger.properties",
		"classpath:error.properties" })
@RunWith(SpringJUnit4ClassRunner.class)
public class DynamoDbDaoImplTest {
	@InjectMocks
	DynamoDbDaoImpl dynamoDbDaoImpl;

	@Mock
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;

	@Mock
	Query query;

	@Mock
	DynamoDBConfig dynamoDBConfig;

	@Mock
	DynamoDBServiceUtil dynamoDBServiceUtil;

	@Mock
	DynamoDB dynamo;

	private boolean initialized = false;
	@Value("${db.env.suffix}")
	private String dbEnvSuffix;
	private static final String RESPONSE_PAYLOAD = "resPayload";

	@Before
	public void setup() {
		dynamoDbDaoImpl = new DynamoDbDaoImpl();
		ReflectionTestUtils.setField(dynamoDbDaoImpl, "env", env);
		ReflectionTestUtils.setField(dynamoDbDaoImpl, "logger", logger);
		ReflectionTestUtils.setField(dynamoDbDaoImpl, "dynamoDBConfig", dynamoDBConfig);
		ReflectionTestUtils.setField(dynamoDbDaoImpl, "dynamo", dynamo);
	}

	@Test
	public void test_isJSONValid() {
		String responseString = "abc123";
		dynamoDbDaoImpl.isJSONValid(responseString);
	}

	@Test
	public void get_test() {
		String applicationId = "A123";
		String source = "test";
		String type = "SampleTest";
		String tableName = "TEST";
		DynamoDB dynamoDB = Mockito.mock(DynamoDB.class);
		Table table = Mockito.mock(Table.class);
		ItemCollection<QueryOutcome> items = Mockito.mock(ItemCollection.class);
		IteratorSupport<Item, QueryOutcome> iterator = Mockito.mock(IteratorSupport.class);
		Item item = Mockito.mock(Item.class);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamoDB);
		Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(table.query(Mockito.any(QuerySpec.class))).thenReturn(items);
		Mockito.when(items.iterator()).thenReturn(iterator);
		Mockito.when(iterator.hasNext()).thenReturn(true).thenReturn(false);
		Mockito.when(iterator.next()).thenReturn(item);
		Mockito.when(item.get(Mockito.anyString())).thenReturn("123");
		List<DynamoDbBean>  e=dynamoDbDaoImpl.get(applicationId, source, type);
		assertNotNull(e);
	}

	@Test
	public void get_test1() {
		String applicationId = "A123";
		String source = "test";
		String type = "SampleTest";
		String tableName = "TEST";
		Object responsePayload = "resPayload";
		DynamoDB dynamoDB = Mockito.mock(DynamoDB.class);
		Table table = Mockito.mock(Table.class);
		ItemCollection<QueryOutcome> items = Mockito.mock(ItemCollection.class);
		IteratorSupport<Item, QueryOutcome> iterator = Mockito.mock(IteratorSupport.class);
		Item item = Mockito.mock(Item.class);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamoDB);
		Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(table.query(Mockito.any(QuerySpec.class))).thenReturn(items);
		Mockito.when(items.iterator()).thenReturn(iterator);
		Mockito.when(iterator.hasNext()).thenReturn(true).thenReturn(false);
		Mockito.when(iterator.next()).thenReturn(item);
		Mockito.when(item.get(Mockito.anyString())).thenReturn(responsePayload);
		dynamoDbDaoImpl.get(applicationId, source, type);

	}

	@Test(expected = BFLTechnicalException.class)
	public void get_testExcep() {
		String applicationId = "A123";
		String source = "test";
		String type = "SampleTest";
		String tableName = "TEST";
		DynamoDB dynamoDB = Mockito.mock(DynamoDB.class);
		Table table = Mockito.mock(Table.class);
		dynamoDbDaoImpl.get(applicationId, source, type);
	}

	@Test
	public void insertRecord_test() throws ParseException {
		DynamoDbBean dynamoDbBean = new DynamoDbBean();
		String resPayload = "{\r\n" + "  \"applicationKey\": \"string\",\r\n" + "  \"balicAppKey\": \"string\",\r\n"
				+ "  \"docCategory\": \"string\",\r\n" + "  \"docType\": \"string\",\r\n"
				+ "  \"fileKey\": \"string\",\r\n" + "  \"fileName\": \"string\",\r\n" + "  \"source\": \"string\",\r\n"
				+ "  \"sourcetype\": \"string\",\r\n" + "  \"timeStamp\": \"string\"\r\n" + "}";
		DateTimeUtil.getCurrentDate();
		dynamoDbBean.setReqTimeStamp(DateTimeUtil.getCurrentDate().toString());
		Table table = Mockito.mock(Table.class);
		DynamoDB dynamoDB = Mockito.mock(DynamoDB.class);
		Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamoDB);
		dynamoDbBean.setAppnId("12A");
		dynamoDbBean.setSource("vghv");
		dynamoDbBean.setApplicantId("121A");
		dynamoDbBean.setResPayload(resPayload);
		dynamoDbBean.setRawResUrl("abc.com");
		dynamoDbBean.setSourcetype("Test");
		dynamoDbBean.setResTimeStamp("11");
		dynamoDbDaoImpl.insertRecord(dynamoDbBean);
	}

	@Test(expected = BFLTechnicalException.class)
	public void insertRecord_testExcep() throws ParseException {
		DynamoDbBean dynamoDbBean = new DynamoDbBean();
		DateTimeUtil.getCurrentDate();
		dynamoDbBean.setReqTimeStamp(DateTimeUtil.getCurrentDate().toString());
		dynamoDbDaoImpl.insertRecord(dynamoDbBean);
	}

	@Test
	public void getcibilObligationDetails_test() {
		String applicationId = "abc11";
		String source = "test";
		List<CibilObligation> cibilObligation = new ArrayList<>();
		CibilObligation cibil = new CibilObligation();
		cibilObligation.add(cibil);
		List<CibilOblicationResponse> response = new ArrayList<>();
		Table table = Mockito.mock(Table.class);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamo);
		ItemCollection<QueryOutcome> items = Mockito.mock(ItemCollection.class);
		Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(table.query(Mockito.any(QuerySpec.class))).thenReturn(items);
		IteratorSupport<Item, QueryOutcome> iterator = Mockito.mock(IteratorSupport.class);
		Mockito.when(items.iterator()).thenReturn(iterator);
		Mockito.when(iterator.hasNext()).thenReturn(true).thenReturn(false);
		Item item = new Item();
		item.withString(RESPONSE_PAYLOAD, "{\r\n" + "	\"obligationSummary\": {\r\n" + "		\"emiList\": [{\r\n"
				+ "			\"emiCap\": \"100\",\r\n" + "			\"currentBalance\": \"1Lakh\",\r\n"
				+ "			\"loanType\": \"reg\",\r\n" + "			\"dateOpenedOrDisbursed\": \"12-01-2019\",\r\n"
				+ "			\"highCreditSanctionAmt\": \"100\",\r\n"
				+ "			\"dateReportedAndCert\": \"02-04-2019\",\r\n" + "			\"tenureCap\": \"100000\",\r\n"
				+ "			\"dateClosed\": \"20-12-2019\",\r\n" + "			\"irrCap\": \"12300\"\r\n"
				+ "		}]\r\n" + "	},\r\n" + "	\"customerId\": \"111\",\r\n" + "	\"errorFlag\": \"True\"\r\n" + "}");
		Mockito.when(iterator.next()).thenReturn(item);
		dynamoDbDaoImpl.getcibilObligationDetails(applicationId, source);
	}

	@Test(expected = BFLTechnicalException.class)
	public void getcibilObligationDetails_testExcep() {
		String applicationId = "abc11";
		String source = "test";
		dynamoDbDaoImpl.getcibilObligationDetails(applicationId, source);
	}

	@Test
	public void insertRecordBalic_test() {
		DynamoDbBeanBalic dynamoDbBean = new DynamoDbBeanBalic();
		dynamoDbBean.setApplicationKey("AA1");
		dynamoDbBean.setBalicAppKey("BA1");
		dynamoDbBean.setDocCategory("test");
		dynamoDbBean.setDocType("NORM");
		dynamoDbBean.setFileKey("A!");
		dynamoDbBean.setFileName("testfile");
		dynamoDbBean.setSource("acb");
		dynamoDbBean.setSourcetype("gen");
		DateTimeUtil.getCurrentDate();
		dynamoDbBean.setTimeStamp(DateTimeUtil.getCurrentDate().toString());
		Table table = Mockito.mock(Table.class);
		DynamoDB dynamoDB = Mockito.mock(DynamoDB.class);
		Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamoDB);
		dynamoDbDaoImpl.insertRecord(dynamoDbBean);

	}

	@Test(expected = BFLTechnicalException.class)
	public void insertRecordBalic_testExcep() {
		DynamoDbBeanBalic dynamoDbBean = new DynamoDbBeanBalic();
		DateTimeUtil.getCurrentDate();
		dynamoDbBean.setTimeStamp(DateTimeUtil.getCurrentDate().toString());
		dynamoDbDaoImpl.insertRecord(dynamoDbBean);
	}

	@Test
	public void getBalicDocUploadRequestDetailsRecord_test() {
		String applicationKey = "A123";
		String source = "gen";
		String sourcetype = "test";
		List<DynamoDbBeanBalic> dynamoResultList = new ArrayList<>();
		Table table = Mockito.mock(Table.class);
		DynamoDB dynamoDB = Mockito.mock(DynamoDB.class);
		Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamoDB);
		ItemCollection<QueryOutcome> items = Mockito.mock(ItemCollection.class);
		IteratorSupport<Item, QueryOutcome> iterator = Mockito.mock(IteratorSupport.class);
		Item item = Mockito.mock(Item.class);
		Mockito.when(dynamoDBConfig.dynamoDB()).thenReturn(dynamoDB);
		Mockito.when(dynamo.getTable(Mockito.anyString())).thenReturn(table);
		Mockito.when(table.query(Mockito.any(QuerySpec.class))).thenReturn(items);
		Mockito.when(items.iterator()).thenReturn(iterator);
		Mockito.when(iterator.hasNext()).thenReturn(true).thenReturn(false);
		Mockito.when(iterator.next()).thenReturn(item);
		dynamoDbDaoImpl.getBalicDocUploadRequestDetailsRecord(applicationKey, source, sourcetype);
	}

	@Test(expected = BFLTechnicalException.class)
	public void getBalicDocUploadRequestDetailsRecord_testExcep() {
		String applicationKey = "A123";
		String source = "gen";
		String sourcetype = "test";
		List<DynamoDbBeanBalic> dynamoResultList = new ArrayList<>();
		dynamoDbDaoImpl.getBalicDocUploadRequestDetailsRecord(applicationKey, source, sourcetype);
	}
}