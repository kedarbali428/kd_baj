package com.bajaj.bfsd.common.repository.baseclasses;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * @author: prashantbadadhe
 * @create @date: Apr 24, 2018
 * @review @by: nasirkhansirajbhai
 * @review @date: Apr 24, 2018
 * @Desc :BFL common spring data jpa crud repository. 
 */
@NoRepositoryBean
public interface BFLDataRepository<T,ID extends Serializable> extends CrudRepository<T,ID> {

}