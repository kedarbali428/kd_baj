package com.bajaj.bfsd.common.repository.baseclasses;

import java.io.Serializable;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @author: prashantbadadhe
 * @create @date: Apr 24, 2018
 * @review @by: nasirkhansirajbhai
 * @review @date: Apr 24, 2018
 * @Desc : BFL common spring data jpa repository for paging & sorting.
 */
@NoRepositoryBean
public interface BFLDataPagingRepository<T,ID extends Serializable> extends PagingAndSortingRepository<T,ID> {

}