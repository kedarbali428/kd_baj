package com.bajaj.bfsd.common.Db;//NOSONAR

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;

import org.hibernate.SessionFactory;
import org.hibernate.event.service.spi.EventListenerRegistry;
import org.hibernate.event.spi.EventSource;
import org.hibernate.event.spi.EventType;
import org.hibernate.event.spi.PostDeleteEvent;
import org.hibernate.event.spi.PostDeleteEventListener;
import org.hibernate.event.spi.PostInsertEvent;
import org.hibernate.event.spi.PostInsertEventListener;
import org.hibernate.event.spi.PostUpdateEvent;
import org.hibernate.event.spi.PostUpdateEventListener;
import org.hibernate.event.spi.PreDeleteEvent;
import org.hibernate.event.spi.PreDeleteEventListener;
import org.hibernate.event.spi.PreInsertEvent;
import org.hibernate.event.spi.PreInsertEventListener;
import org.hibernate.event.spi.PreUpdateEvent;
import org.hibernate.event.spi.PreUpdateEventListener;
import org.hibernate.internal.SessionFactoryImpl;
import org.hibernate.internal.SessionImpl;
import org.hibernate.persister.entity.EntityPersister;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DBAuditor implements PreInsertEventListener, PreUpdateEventListener, PreDeleteEventListener,
		PostInsertEventListener, PostUpdateEventListener, PostDeleteEventListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1029923225968444005L;

	@Autowired
	transient EntityManager entityManager;

	@Autowired
	transient DBAuditConfig auditConfig;
	
	public boolean onPreInsert(PreInsertEvent event) {
		setClientInfoOnConnection(event.getSession());
		return false;
	}

	//@Override
	public boolean onPreUpdate(PreUpdateEvent event) {
		setClientInfoOnConnection(event.getSession());
		return false;
	}

	//@Override
	public boolean onPreDelete(PreDeleteEvent event) {
		setClientInfoOnConnection(event.getSession());
		return false;
	}

	//@Override
	public void onPostDelete(PostDeleteEvent event) {
		reSetClientInfo(event.getSession());
	}

	//@Override
	public void onPostUpdate(PostUpdateEvent event) {		
		reSetClientInfo(event.getSession());
	}

	//@Override
	public void onPostInsert(PostInsertEvent event) {
		reSetClientInfo(event.getSession());
	}

	//@Override
	public boolean requiresPostCommitHanding(EntityPersister event) {
		return false;
	}

	private void setClientInfoOnConnection(EventSource eventSource) {
		SessionImpl session = null;
		if (null != eventSource) {
			session = (SessionImpl) eventSource;
		}
		if (null != session) {			
			// Previous client info can't be stored
			auditConfig.setClientInfo(session);
		}
	}

	private void reSetClientInfo(EventSource eventSource) {
		SessionImpl session = null;
		if (null != eventSource) {
			session = (SessionImpl) eventSource;
		}
		if (null != session) {
			auditConfig.resetClientInfo(session);
		}	
	}

	@PostConstruct
	public void registerListeners() {		
		entityManager = entityManager.getEntityManagerFactory().createEntityManager();
		SessionImpl session = entityManager.unwrap(SessionImpl.class);
		SessionFactory sessionFactory = session.getSessionFactory();
		if (null != sessionFactory && session.getSessionFactory().getDialect().toString().toLowerCase().contains("oracle")) {
			final EventListenerRegistry registry = ((SessionFactoryImpl) sessionFactory).getServiceRegistry()
					.getService(EventListenerRegistry.class);
			registry.getEventListenerGroup(EventType.PRE_DELETE).appendListener(this);
			registry.getEventListenerGroup(EventType.PRE_INSERT).appendListener(this);
			registry.getEventListenerGroup(EventType.PRE_UPDATE).appendListener(this);
			registry.getEventListenerGroup(EventType.POST_DELETE).appendListener(this);
			registry.getEventListenerGroup(EventType.POST_INSERT).appendListener(this);
			registry.getEventListenerGroup(EventType.POST_UPDATE).appendListener(this);
		}
	}
}
