package com.bajaj.bfsd.common.Db;//NOSONAR

import java.sql.Connection;
import java.util.Arrays;

import javax.persistence.EntityManager;

import org.hibernate.internal.SessionImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;

import oracle.jdbc.driver.OracleConnection;

@Configuration
@PropertySource("logger.properties")
public class DBAuditConfig {

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	CustomDefaultHeaders custmHeader;
	
	@Autowired
	EntityManager entityManager;
	
	@Value("${spring.application.name}")
	String serviceName;

	private static final String CLASSNAME = DBAuditConfig.class.getCanonicalName();

	public String[] setClientInfo(String... module) {
		OracleConnection conn = getOracleConnection(entityManager);
		return setMetricsOnConnection(conn, module);
	}

	public void resetClientInfo(String[] prevMetrics) {
		OracleConnection conn = getOracleConnection(entityManager);
		resetMetricsOnConnection(conn, prevMetrics);
	}

	public void resetClientInfo() {
		String[] metrics = new String[OracleConnection.END_TO_END_STATE_INDEX_MAX];

		metrics[OracleConnection.END_TO_END_ACTION_INDEX] = "";
		metrics[OracleConnection.END_TO_END_MODULE_INDEX] = "";
		metrics[OracleConnection.END_TO_END_CLIENTID_INDEX] = "";

		OracleConnection conn = getOracleConnection(entityManager);
		resetMetricsOnConnection(conn, metrics);
	}

	private String[] getMetrics(String... module) {
		String[] metrics = new String[OracleConnection.END_TO_END_STATE_INDEX_MAX];

		metrics[OracleConnection.END_TO_END_ACTION_INDEX] = "";
		
		String actualModule = "BFLDBCore";
		if(null != serviceName && serviceName.length() > 0)
			actualModule = serviceName;
		else if (null != module && module.length > 0)
			actualModule = Arrays.toString(module);
				
		metrics[OracleConnection.END_TO_END_MODULE_INDEX] = actualModule;
		Long userKey = 0L;
		if (null != custmHeader) {
			userKey = custmHeader.getUserKey();			
		}
		if (userKey == 0L)
			userKey = 1L;

		metrics[OracleConnection.END_TO_END_CLIENTID_INDEX] = userKey.toString();

		return metrics;
	}

	private String[] setMetricsOnConnection(OracleConnection conn, String... module) {
		String[] prevMetrics = null;
		String[] metrics = getMetrics(module);

		try {
			if (null != conn) {
				prevMetrics = conn.getEndToEndMetrics();
				conn.setEndToEndMetrics(metrics, (short) 0);
			}
		} catch (Exception ex) {
			// handle the exception here
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Could not set EndToEndMertic - " + ex.getMessage(), ex);
		}

		return prevMetrics;
	}

	private void resetMetricsOnConnection(OracleConnection conn, String[] prevMetrics) {
		try {
			if (null != conn) {
				conn.setEndToEndMetrics(prevMetrics, (short) 0);
			}
		} catch (Exception ex) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Could not reset EndToEndMertic - " + ex.getMessage(), ex);
		}
	}	

	private OracleConnection getOracleConnection(EntityManager entityManager) {
		Connection conn = entityManager.unwrap(SessionImpl.class).connection();
	
		try {
			if (null != conn) {
				return conn.unwrap(OracleConnection.class);
			}
		} catch (Exception ex) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Could not get oracle connection - " + ex.getMessage(), ex);
		}
		return null;
	}

	private OracleConnection getOracleConnection(SessionImpl session) {

		if (null != session) {
			Connection conn = session.connection();
			try {
				if (null != conn) {
					return conn.unwrap(OracleConnection.class);
				}
			} catch (Exception ex) {
				logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Could not get oracle connection - " + ex.getMessage(), ex);
			}
		}
		return null;
	}

	public void setClientInfo(SessionImpl session, String... module) {
		OracleConnection conn = getOracleConnection(session);
		setMetricsOnConnection(conn, module);		
	}

	public void resetClientInfo(SessionImpl session) {
		OracleConnection conn = getOracleConnection(session);
		String[] metrics = new String[OracleConnection.END_TO_END_STATE_INDEX_MAX];

		metrics[OracleConnection.END_TO_END_ACTION_INDEX] = "";
		metrics[OracleConnection.END_TO_END_MODULE_INDEX] = "";
		metrics[OracleConnection.END_TO_END_CLIENTID_INDEX] = "";
		resetMetricsOnConnection(conn, metrics);
	}
}
