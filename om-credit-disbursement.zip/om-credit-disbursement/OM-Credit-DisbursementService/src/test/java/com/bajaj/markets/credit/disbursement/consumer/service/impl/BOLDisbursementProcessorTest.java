package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.json.JsonParseException;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationDetail;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.google.gson.Gson;

@SpringBootConfiguration
@SpringBootTest
public class BOLDisbursementProcessorTest {
	@InjectMocks
	private BOLDisbursementProcessor bolDisbProcessor;

	@Mock
	BFLLoggerUtil logger;

	@Mock
	PublisherService publisherService;

	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Mock
	LoanProcessor loanProcessor;

	@Mock
	BeneficiaryProcessor beneficiaryProcessor;
	
	@Mock
	DisbursementUtil disbursementUtil;

	@Mock
	CustomerProcessor customerProcessor;

	@Mock
	CollateralProcessor collateralProcessor;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(bolDisbProcessor, "disbtopicArn", "disbtopicArn");
	}

	@Test
	public void processDisbursementTest() {
		DisbursementEventRequestBean request = new DisbursementEventRequestBean();
		request.setApplicationId("1100000000006221");
		request.setProductCode("BFLBOL");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken", "authtoken");
		request.setHeaders(headers);
		validateRequest();
		fetchApplicationns();
		bolDisbProcessor.processDisbursement(request);
	}

	public void validateRequest() {
		when(disbursementUtil.validateRequest(DataPopulator.fetchGlobalData())).thenReturn(true);
	}

	private void fetchApplicationns() {
		Gson gson = new Gson();
		String str = "{\"applicationKey\":\"1100000000006221\",\"parentApplicationKey\":\"1100000000006217\",\"mobile\":123,\"dateofbirth\":123,\"applicantKey\":123,\"l2ProductKey\":10002,\"l2ProductCode\":\"OMPL\",\"l3ProductKey\":10,\"l3ProductCode\":\"BFLBOL\",\"l4ProductKey\":10,\"l4ProductCode\":\"BFLBOLTL\",\"principalKey\":3,\"applicationStatus\":1,\"riskoffertype\":123,\"inProcessing\":true}";
		ApplicationDetail appDtl = gson.fromJson(str, ApplicationDetail.class);
		when(disbursementUtil.fetchApplicationDetails(DataPopulator.fetchGlobalData())).thenReturn(appDtl);
	}
	
	public void saveError() {
		List<DisbursementTrackerBean> disbursementTrackerBeanLst = new ArrayList<DisbursementTrackerBean>();
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		disbursementTrackerBeanLst.add(disbursementTrackerBean);
		when(disbursementUtil.saveDisbursementErrorDetails(Mockito.any(), Mockito.any()))
				.thenReturn(disbursementTrackerBean);

	}


}
