package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.awaitility.core.ConditionTimeoutException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCustomerPennantRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreditReviewStatusBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.EmailInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.PersonalInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.PhoneInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBean;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementMapperUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.LMSHelper;
import com.bajaj.markets.credit.disbursement.repository.MongoDBRepository;

@SpringBootTest
public class CustomerProcessorTest {
	@InjectMocks
	private CustomerProcessor customerProcessor;

	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Mock
	DisbursementUtil disbursementUtil;

	@Mock
	DisbursementMapperUtil disbursementMapperUtil;
	
	@Mock
	MongoOperations disbursementMongoTemplate;

	@Mock
	MongoDBRepository mongoDbRepo;

	@Mock
	LMSHelper lmsHelper;

	@Mock
	BFLLoggerUtil logger;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(customerProcessor, "updateAppSysCodeUrl", "updateAppSysCodeUrl");
		ReflectionTestUtils.setField(customerProcessor, "getUserProfilesUrl", "http://omcreditapplicationservice.qa.bfsgodirect.com/v1/creditapplication/applications/{applicationid}/userprofiles");
		ReflectionTestUtils.setField(customerProcessor, "updateOccupationForEntityCif", "updateOccupationForEntityCif");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void processCustomerRequestForSOLTest() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();
		String userProfileStr = "[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("userprofiles"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(userProfileStr, HttpStatus.OK));

		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchApplicationDetails());

		String custDisbstr = "{\"langKey\":1,\"nationalityKey\":1,\"custcategorycdkey\":1,\"applicantAddresses\":[{\"addrtypkey\":46,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null},{\"addrtypkey\":50,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null}],\"phones\":[{\"phoneTypeKey\":45,\"phoneCountryCode\":\"91\",\"phoneAreaCode\":\"91\",\"phoneNumber\":\"9899999999\"}],\"emails\":[{\"emailtypekey\":67,\"emailaddress\":\"kjgsglsgsk@bajajfinserv.in\",\"emailpriority\":5},{\"emailtypekey\":70,\"emailaddress\":\"jgklsjgks@gmail.com\",\"emailpriority\":4}]}";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCustomerDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(custDisbstr, HttpStatus.OK));

		when(disbursementUtil.fetchBankDetails(Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchBankDetailsResponse());

		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails=new ArrayList<EmailInfo>();
		EmailInfo emailInfo=new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		when(disbursementMapperUtil.mapCustomerPennantRequestForSOL(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(request);

		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(
						"{\"dedupReq\":true,\"returnStatus\":{\"returnCode\":\"90343\",\"returnText\":\"Customer dedup found.\"},\"dedup\":[{\"cif\":\"207948\",\"categoryCode\":\"RETAIL\",\"defaultBranch\":\"320\",\"firstName\":\"TSEting\",\"lastName\":\"test\",\"shortName \":\"TSEting test\",\"dateofBirth\":\"1989-09-05T00:00:00\",\"custPAN\":\"LKJPO0987Y\",\"sector \":\"17\"}]}");

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateAppSysCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateOccupationForEntityCif"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when(mongoDbRepo.insertDocumentDB(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("");
		customerProcessor.processCustomerRequestForSOL(data);
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected=DisbursementServiceException.class)
	public void processCustomerRequestForSOLTest1() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();
		String userProfileStr = "[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("userprofiles"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(userProfileStr, HttpStatus.OK));

		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchApplicationDetails());

		String custDisbstr = "{\"langKey\":1,\"nationalityKey\":1,\"custcategorycdkey\":1,\"applicantAddresses\":[{\"addrtypkey\":46,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null},{\"addrtypkey\":50,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null}],\"phones\":[{\"phoneTypeKey\":45,\"phoneCountryCode\":\"91\",\"phoneAreaCode\":\"91\",\"phoneNumber\":\"9899999999\"}],\"emails\":[{\"emailtypekey\":67,\"emailaddress\":\"kjgsglsgsk@bajajfinserv.in\",\"emailpriority\":5},{\"emailtypekey\":70,\"emailaddress\":\"jgklsjgks@gmail.com\",\"emailpriority\":4}]}";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCustomerDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(custDisbstr, HttpStatus.OK));

		when(disbursementUtil.fetchBankDetails(Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchBankDetailsResponse());

		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails=new ArrayList<EmailInfo>();
		EmailInfo emailInfo=new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		when(disbursementMapperUtil.mapCustomerPennantRequestForSOL(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(request);
		RetryRegistrationBean existingRecords= null;
		 List<TranchBean> trnchLst =new ArrayList<TranchBean>();
		 TranchBean bean = new TranchBean();
		 bean.setTranchkey(123l);
		 trnchLst.add(bean);
				 when(disbursementUtil.fetchTranchDetails(Mockito.any(), Mockito.any())).thenReturn(trnchLst);
		when(disbursementUtil.fetchExistingTransaction(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(existingRecords);
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
		.thenThrow(ConditionTimeoutException.class);
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateAppSysCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateOccupationForEntityCif"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when(mongoDbRepo.insertDocumentDB(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("");
		customerProcessor.processCustomerRequestForSOL(data);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void processCustomerRequestForBOLTest() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();
		String userProfileStr = "[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244},{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"2\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("userprofiles"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(userProfileStr, HttpStatus.OK));

		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchApplicationDetailsBOL());

		String custDisbstr = "{\"langKey\":1,\"nationalityKey\":1,\"custcategorycdkey\":1,\"applicantAddresses\":[{\"addrtypkey\":46,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null},{\"addrtypkey\":50,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null}],\"phones\":[{\"phoneTypeKey\":45,\"phoneCountryCode\":\"91\",\"phoneAreaCode\":\"91\",\"phoneNumber\":\"9899999999\"}],\"emails\":[{\"emailtypekey\":67,\"emailaddress\":\"kjgsglsgsk@bajajfinserv.in\",\"emailpriority\":5},{\"emailtypekey\":70,\"emailaddress\":\"jgklsjgks@gmail.com\",\"emailpriority\":4}]}";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCustomerDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(custDisbstr, HttpStatus.OK));

		when(disbursementUtil.fetchBankDetails(Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchBankDetailsResponse());

		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails=new ArrayList<EmailInfo>();
		EmailInfo emailInfo=new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		PersonalInfo personalInfo=new PersonalInfo();
		personalInfo.setType("1");
		request.setPersonalInfo(personalInfo);
		when(disbursementMapperUtil.mapCustomerPennantRequestForBOL(Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(request);

		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(
						"{\"dedupReq\":true,\"returnStatus\":{\"returnCode\":\"90343\",\"returnText\":\"Customer dedup found.\"},\"dedup\":[{\"cif\":\"207948\",\"categoryCode\":\"RETAIL\",\"defaultBranch\":\"320\",\"firstName\":\"TSEting\",\"lastName\":\"test\",\"shortName \":\"TSEting test\",\"dateofBirth\":\"1989-09-05T00:00:00\",\"custPAN\":\"LKJPO0987Y\",\"sector \":\"17\"}]}");

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateAppSysCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateOccupationForEntityCif"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));
		
		CreditReviewStatusBean creditReviewStatusBean = new CreditReviewStatusBean();
		creditReviewStatusBean.setEntityCoapplicantRequired("1");
		creditReviewStatusBean.setIndividualCoapplicantRequired("1");
		when(disbursementUtil.getCreditReviewDetails(Mockito.any(),Mockito.any()))
						.thenReturn(creditReviewStatusBean);

		when(mongoDbRepo.insertDocumentDB(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("");
		customerProcessor.processCustomerRequestForBOL(data);
	}
	
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void processCustomerRequestForBOLTest1() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();
		String userProfileStr = "[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244},{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"2\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("userprofiles"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(userProfileStr, HttpStatus.OK));
		when(disbursementUtil.fetchApplicationDetailsForCoApplicant(Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(DataPopulator.fetchApplicationDetailsBOL());
		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchApplicationDetailsBOL());

		when(disbursementUtil.fetchApplicationDetailsForCoApplicant(Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(DataPopulator.fetchApplicationDetailsBOL());
		
		String custDisbstr = "{\"langKey\":1,\"nationalityKey\":1,\"custcategorycdkey\":1,\"applicantAddresses\":[{\"addrtypkey\":46,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null},{\"addrtypkey\":50,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null}],\"phones\":[{\"phoneTypeKey\":45,\"phoneCountryCode\":\"91\",\"phoneAreaCode\":\"91\",\"phoneNumber\":\"9899999999\"}],\"emails\":[{\"emailtypekey\":67,\"emailaddress\":\"kjgsglsgsk@bajajfinserv.in\",\"emailpriority\":5},{\"emailtypekey\":70,\"emailaddress\":\"jgklsjgks@gmail.com\",\"emailpriority\":4}]}";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCustomerDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(custDisbstr, HttpStatus.OK));

		when(disbursementUtil.fetchBankDetails(Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchBankDetailsResponse());

		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails=new ArrayList<EmailInfo>();
		EmailInfo emailInfo=new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		PersonalInfo personalInfo=new PersonalInfo();
		personalInfo.setType("1");
		request.setPersonalInfo(personalInfo);
		when(disbursementMapperUtil.mapCustomerPennantRequestForBOL(Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(request);

		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(
						"{\"cif\":\"208036\",\"dedupReq\":true,\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateAppSysCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateOccupationForEntityCif"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));
		CreditReviewStatusBean creditReviewStatusBean = new CreditReviewStatusBean();
		creditReviewStatusBean.setEntityCoapplicantRequired("1");
		creditReviewStatusBean.setIndividualCoapplicantRequired("1");
		when(disbursementUtil.getCreditReviewDetails(Mockito.any(),Mockito.any()))
			.thenReturn(creditReviewStatusBean);

		when(mongoDbRepo.insertDocumentDB(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("");
		customerProcessor.processCustomerRequestForBOL(data);
	}
	
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void processCustomerRequestForBOLTest2() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();
		String userProfileStr = "[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244},{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"2\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("userprofiles"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(userProfileStr, HttpStatus.OK));

		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchApplicationDetailsBOL());

		when(disbursementUtil.fetchApplicationDetailsForCoApplicant(Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(DataPopulator.fetchApplicationDetailsBOL());
		
		String custDisbstr = "{\"langKey\":1,\"nationalityKey\":1,\"custcategorycdkey\":1,\"applicantAddresses\":[{\"addrtypkey\":46,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null},{\"addrtypkey\":50,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null}],\"phones\":[{\"phoneTypeKey\":45,\"phoneCountryCode\":\"91\",\"phoneAreaCode\":\"91\",\"phoneNumber\":\"9899999999\"}],\"emails\":[{\"emailtypekey\":67,\"emailaddress\":\"kjgsglsgsk@bajajfinserv.in\",\"emailpriority\":5},{\"emailtypekey\":70,\"emailaddress\":\"jgklsjgks@gmail.com\",\"emailpriority\":4}]}";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCustomerDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(custDisbstr, HttpStatus.OK));
		when(disbursementUtil.fetchApplicationDetailsForCoApplicant(Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(DataPopulator.fetchApplicationDetailsBOL());
		when(disbursementUtil.fetchBankDetails(Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchBankDetailsResponse());

		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails=new ArrayList<EmailInfo>();
		EmailInfo emailInfo=new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		PersonalInfo personalInfo=new PersonalInfo();
		personalInfo.setType("1");
		request.setPersonalInfo(personalInfo);
		when(disbursementMapperUtil.mapCustomerPennantRequestForBOL(Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(request);

		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(
						"{\"dedupReq\":false,\"returnStatus\":{\"returnCode\":\"90108\",\"returnText\":\"Invalid customer type code: 7 for RETAIL customer.\"}}");

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateAppSysCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateOccupationForEntityCif"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));
		CreditReviewStatusBean creditReviewStatusBean = new CreditReviewStatusBean();
		creditReviewStatusBean.setEntityCoapplicantRequired("1");
		creditReviewStatusBean.setIndividualCoapplicantRequired("1");
		when(disbursementUtil.getCreditReviewDetails(Mockito.any(),Mockito.any()))
			.thenReturn(creditReviewStatusBean);
		when(mongoDbRepo.insertDocumentDB(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("");
		customerProcessor.processCustomerRequestForBOL(data);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void processCustomerRequestForFundedTest1() {

		FundedDisbursementEventRequestBean bean = DataPopulator.fetchRequestForFunded();
		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails = new ArrayList<EmailInfo>();
		EmailInfo emailInfo = new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		PersonalInfo personalInfo = new PersonalInfo();
		personalInfo.setType("1");
		request.setPersonalInfo(personalInfo);
		when(disbursementMapperUtil.mapCustomerPennatRequestForFunded(Mockito.any())).thenReturn(request);

		when(lmsHelper.executeLmsRequest(Mockito.eq(DisbursementConstants.LMS_CUSTOMER_SOURCE), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
						"{\"cif\":\"208036\",\"dedupReq\":true,\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateAppSysCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when(mongoDbRepo.insertDocumentDB(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("");
		
		DisbursementBean bean1 = new DisbursementBean();
		bean1.getDisbursementParty();
		bean1.getDisbursementType();
		bean1.getDisbursementDate();
		bean1.getDisbursementAmount();
		bean1.getBankCode();
		bean1.getBankName();
		bean1.getIfscCode();
		bean1.getBranchCode();
		bean1.getAccountNo();
		bean1.getAccountHolderName();
		bean1.getPhoneNumber();
		bean1.getDescription();
		bean1.setDisbursementParty("");
		bean1.setDisbursementType("");
		bean1.setDisbursementDate("");
		bean1.setDisbursementAmount(new Double(1));
		bean1.setBankCode("");
		bean1.setBankName("");
		bean1.setIfscCode("");
		bean1.setBranchCode("");
		bean1.setAccountNo("");
		bean1.setAccountHolderName("");
		bean1.setPhoneNumber("");
		bean1.setDescription("");

		customerProcessor.processCustomerRequestForFunded(bean);
	}

	@Test(expected = DisbursementServiceException.class)
	public void processCustomerRequestForFundedTest2() {

		FundedDisbursementEventRequestBean bean = DataPopulator.fetchRequestForFunded();
		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails = new ArrayList<EmailInfo>();
		EmailInfo emailInfo = new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		PersonalInfo personalInfo = new PersonalInfo();
		personalInfo.setType("1");
		request.setPersonalInfo(personalInfo);
		when(disbursementMapperUtil.mapCustomerPennatRequestForFunded(Mockito.any())).thenReturn(request);

		when(lmsHelper.executeLmsRequest(Mockito.eq(DisbursementConstants.LMS_CUSTOMER_SOURCE), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
						"{\"dedupReq\":false,\"returnStatus\":{\"returnCode\":\"90108\",\"returnText\":\"Invalid customer type code: 7 for RETAIL customer.\"}}");

		customerProcessor.processCustomerRequestForFunded(bean);
	}

	@Test(expected = DisbursementServiceException.class)
	public void processCustomerRequestForFundedTest3() {

		FundedDisbursementEventRequestBean bean = DataPopulator.fetchRequestForFunded();
		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails = new ArrayList<EmailInfo>();
		EmailInfo emailInfo = new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		PersonalInfo personalInfo = new PersonalInfo();
		personalInfo.setType("1");
		request.setPersonalInfo(personalInfo);
		when(disbursementMapperUtil.mapCustomerPennatRequestForFunded(Mockito.any())).thenReturn(request);

		when(lmsHelper.executeLmsRequest(Mockito.eq(DisbursementConstants.LMS_CUSTOMER_SOURCE), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
						"{\"dedupReq\":true,\"returnStatus\":{\"returnCode\":\"90434\",\"returnText\":\"Customer dedup found and updated successfully.\"},\"dedup\":[{\"cif\":\"212903\",\"categoryCode\":\"RETAIL\",\"defaultBranch\":\"320\",\"firstName\":\"Mukubhai\",\"lastName\":\"Ambani\",\"shortName \":\"Mukubhai Ambani\",\"dateofBirth\":\"1992-11-03T00:00:00\",\"custPAN\":\"ABHPA2524H\",\"sector \":\"17\"}]}");
		when(mongoDbRepo.insertDocumentDB(Mockito.any(), Mockito.any(), Mockito.any()))
		.thenThrow(NumberFormatException.class);
		customerProcessor.processCustomerRequestForFunded(bean);
	}

	@Test
	public void processCustomerRequestForPROLTest() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();
		String userProfileStr = "[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244},{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"2\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("userprofiles"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(userProfileStr, HttpStatus.OK));
		when(disbursementUtil.fetchApplicationDetailsForCoApplicant(Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(DataPopulator.fetchApplicationDetails());
		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchApplicationDetailsBOL());

		String custDisbstr = "{\"langKey\":1,\"nationalityKey\":1,\"custcategorycdkey\":1,\"applicantAddresses\":[{\"addrtypkey\":46,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null},{\"addrtypkey\":50,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null}],\"phones\":[{\"phoneTypeKey\":45,\"phoneCountryCode\":\"91\",\"phoneAreaCode\":\"91\",\"phoneNumber\":\"9899999999\"}],\"emails\":[{\"emailtypekey\":67,\"emailaddress\":\"kjgsglsgsk@bajajfinserv.in\",\"emailpriority\":5},{\"emailtypekey\":70,\"emailaddress\":\"jgklsjgks@gmail.com\",\"emailpriority\":4}]}";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCustomerDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(custDisbstr, HttpStatus.OK));

		when(disbursementUtil.fetchBankDetails(Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchBankDetailsResponse());

		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails=new ArrayList<EmailInfo>();
		EmailInfo emailInfo=new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		PersonalInfo personalInfo=new PersonalInfo();
		personalInfo.setType("1");
		request.setPersonalInfo(personalInfo);
		when(disbursementMapperUtil.mapCustomerPennantRequestForPROL(Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(request);

		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(
						"{\"cif\":\"208036\",\"dedupReq\":true,\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateAppSysCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateOccupationForEntityCif"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));
		CreditReviewStatusBean creditReviewStatusBean = new CreditReviewStatusBean();
		creditReviewStatusBean.setEntityCoapplicantRequired("1");
		creditReviewStatusBean.setIndividualCoapplicantRequired("1");
		when(disbursementUtil.getCreditReviewDetails(Mockito.any(),Mockito.any())).thenReturn(creditReviewStatusBean);

		when(mongoDbRepo.insertDocumentDB(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("");
		customerProcessor.processCustomerRequestForPROL(data);
	}
	
	@Test
	public void processCustomerRequestForPROLTestExe() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();
		String userProfileStr = "[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244},{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"2\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("userprofiles"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(userProfileStr, HttpStatus.OK));
		when(disbursementUtil.fetchApplicationDetailsForCoApplicant(Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(DataPopulator.fetchApplicationDetails());
		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchApplicationDetails());

		when(disbursementUtil.fetchApplicationDetailsForCoApplicant(Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(DataPopulator.fetchApplicationDetailsBOL());
		String custDisbstr = "{\"langKey\":1,\"nationalityKey\":1,\"custcategorycdkey\":1,\"applicantAddresses\":[{\"addrtypkey\":46,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null},{\"addrtypkey\":50,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null}],\"phones\":[{\"phoneTypeKey\":45,\"phoneCountryCode\":\"91\",\"phoneAreaCode\":\"91\",\"phoneNumber\":\"9899999999\"}],\"emails\":[{\"emailtypekey\":67,\"emailaddress\":\"kjgsglsgsk@bajajfinserv.in\",\"emailpriority\":5},{\"emailtypekey\":70,\"emailaddress\":\"jgklsjgks@gmail.com\",\"emailpriority\":4}]}";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCustomerDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(custDisbstr, HttpStatus.OK));

		when(disbursementUtil.fetchBankDetails(Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchBankDetailsResponse());

		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails=new ArrayList<EmailInfo>();
		EmailInfo emailInfo=new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		PersonalInfo personalInfo=new PersonalInfo();
		personalInfo.setType("1");
		request.setPersonalInfo(personalInfo);
		when(disbursementMapperUtil.mapCustomerPennantRequestForPROL(Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(request);

		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ConditionTimeoutException.class);
		
		List<TranchBean> trnchLst = new ArrayList<>();
		TranchBean tranchBean = new TranchBean();
		tranchBean.setTranchkey(1L);
		trnchLst.add(tranchBean);
		when(disbursementUtil.fetchTranchDetails(Mockito.any(), Mockito.any())).thenReturn(trnchLst);
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateAppSysCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateOccupationForEntityCif"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));
		
		
		when(mongoDbRepo.insertDocumentDB(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("");
		
		customerProcessor.processCustomerRequestForPROL(data);
	}
	
	@Test(expected = DisbursementServiceException.class)
	public void processCustomerRequestForSOLTestExe() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();
		String userProfileStr = "[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("userprofiles"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(userProfileStr, HttpStatus.OK));

		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchApplicationDetails());

		String custDisbstr = "{\"langKey\":1,\"nationalityKey\":1,\"custcategorycdkey\":1,\"applicantAddresses\":[{\"addrtypkey\":46,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null},{\"addrtypkey\":50,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null}],\"phones\":[{\"phoneTypeKey\":45,\"phoneCountryCode\":\"91\",\"phoneAreaCode\":\"91\",\"phoneNumber\":\"9899999999\"}],\"emails\":[{\"emailtypekey\":67,\"emailaddress\":\"kjgsglsgsk@bajajfinserv.in\",\"emailpriority\":5},{\"emailtypekey\":70,\"emailaddress\":\"jgklsjgks@gmail.com\",\"emailpriority\":4}]}";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCustomerDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(custDisbstr, HttpStatus.OK));
		when(disbursementUtil.fetchBankDetails(Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchBankDetailsResponse());

		CreateCustomerPennantRequest request = new CreateCustomerPennantRequest();
		List<PhoneInfo> phones = new ArrayList<PhoneInfo>();
		PhoneInfo e = new PhoneInfo();
		e.setPhoneNumber("9875435790");
		phones.add(e);
		request.setPhones(phones);
		List<EmailInfo> emails=new ArrayList<EmailInfo>();
		EmailInfo emailInfo=new EmailInfo();
		emailInfo.setCustEMail("abc@gamil.com");
		emailInfo.setCustEMailTypeCode("PERSONAL");
		emails.add(emailInfo);
		request.setEmails(emails);
		when(disbursementMapperUtil.mapCustomerPennantRequestForSOL(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(request);

		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ConditionTimeoutException.class);
		
		List<TranchBean> trnchLst = new ArrayList<>();
		TranchBean tranchBean = new TranchBean();
		tranchBean.setTranchkey(1L);
		trnchLst.add(tranchBean);
		when(disbursementUtil.fetchTranchDetails(Mockito.any(), Mockito.any())).thenReturn(trnchLst);

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateAppSysCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateOccupationForEntityCif"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		CreditReviewStatusBean creditReviewStatusBean = new CreditReviewStatusBean();
		creditReviewStatusBean.setEntityCoapplicantRequired("0");
		creditReviewStatusBean.setIndividualCoapplicantRequired("0");
		when(disbursementUtil.getCreditReviewDetails(Mockito.any(),Mockito.any())).thenReturn(creditReviewStatusBean);

		when(mongoDbRepo.insertDocumentDB(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("");
		customerProcessor.processCustomerRequestForSOL(data);
	}
}
