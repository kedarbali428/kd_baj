package com.bajaj.markets.credit.disbursement.consumer.util;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.BankDetailsResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.CustomerDisbDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.UserProfile;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;

@SpringBootTest
public class DisbursementMapperUtilTest {

	@InjectMocks
	private DisbursementMapperUtil util;

	@Mock
	BFLLoggerUtil logger;

	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Mock
	DisbursementUtil disbursementUtil;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(util, "getBflBranchesCodeUrl", "getBflBranchesCodeUrl");
		ReflectionTestUtils.setField(util, "getSalutationDetailsUrl", "getSalutationDetailsUrl");
		ReflectionTestUtils.setField(util, "getLanguageDetailsUrl", "getLanguageDetailsUrl");
		ReflectionTestUtils.setField(util, "getNationalityDetailsUrl", "getNationalityDetailsUrl");
		ReflectionTestUtils.setField(util, "getGenderDetailsUrl", "getGenderDetailsUrl");
		ReflectionTestUtils.setField(util, "getMaritalStatusDetailsUrl", "getMaritalStatusDetailsUrl");
		ReflectionTestUtils.setField(util, "getBflRefCodeUrl", "getBflRefCodeUrl");
		ReflectionTestUtils.setField(util, "getCityDetailsUrl", "getCityDetailsUrl");
		ReflectionTestUtils.setField(util, "getBranchDetailsUrl", "getBranchDetailsUrl");
		ReflectionTestUtils.setField(util, "getBankMasterCodeUrl", "getBankMasterCodeUrl");
		ReflectionTestUtils.setField(util, "getIndustryDetailsUrl", "getIndustryDetailsUrl");
		ReflectionTestUtils.setField(util, "getpincodeUrl", "getpincodeUrl");
		ReflectionTestUtils.setField(util, "servicesmasterUrl", "servicesmasterUrl");
		

	}

	@SuppressWarnings("unchecked")
	@Test
	public void mapCustomerPennantRequestForSOLTest() {
		HttpHeaders headers = new HttpHeaders();

		String bflBranch = "{\"bflbranchkey\":1,\"bflbranchcode\":\"320\",\"citykey\":1784}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflBranchesCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bflBranch, HttpStatus.OK));

		String salutation = "{\"salutationkey\":21,\"salutationcode\":\"DR\",\"salutationdec\":\"Doctor\",\"salutationgendercode\":\"MALE\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getSalutationDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(salutation, HttpStatus.OK));

		String lang = "{\"langkey\":21,\"langcode\":\"HINDI\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getLanguageDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(lang, HttpStatus.OK));

		String nationality = "{\"nationalitykey\":11,\"nationalitycode\":\"INDIAN\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getNationalityDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(nationality, HttpStatus.OK));

		String gender = "[{\"genderKey\":21,\"genderCode\":\"F\",\"genderValue\":\"Female\",\"isactive\":1},{\"genderKey\":22,\"genderCode\":\"M\",\"genderValue\":\"Male\",\"isactive\":1}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getGenderDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(gender, HttpStatus.OK));

		String maritalStatus = "[{\"maritalStatusKey\":27,\"maritalStatusCode\":\"M\",\"maritalStatusValue\":\"MARRIED\",\"isactive\":1},{\"maritalStatusKey\":28,\"maritalStatusCode\":\"S\",\"maritalStatusValue\":\"SINGLE\",\"isactive\":1},{\"maritalStatusKey\":29,\"maritalStatusCode\":\"D\",\"maritalStatusValue\":\"DIVORCEE\",\"isactive\":1},{\"maritalStatusKey\":30,\"maritalStatusCode\":\"W\",\"maritalStatusValue\":\"WIDOW/WIDOWER\",\"isactive\":1},{\"maritalStatusKey\":31,\"maritalStatusCode\":\"O\",\"maritalStatusValue\":\"OTHER\",\"isactive\":1}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getMaritalStatusDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(maritalStatus, HttpStatus.OK));

		String addtype = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"address type\",\"omCode\":\"46\",\"refCode\":\"OFFICE\"}";
		String addtypereq = "{\"systemCode\":\"BFL\",\"omLable\":\"address type\",\"omCode\":\"46\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(addtypereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(addtype, HttpStatus.OK));

		String pincode = "411027";
		when(disbursementUtil.fetchPincodeDetails(Mockito.any(), Mockito.any())).thenReturn(pincode);

		String city = "{\"pincodeKey\":\"411027\",\"citycategory\":\"A\",\"citycode\":\"1948\",\"cityname\":\"PUNE\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCityDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(city, HttpStatus.OK));

		String addtype2 = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"address type\",\"omCode\":\"50\",\"refCode\":\"CURRES\"}";
		String addtypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"address type\",\"omCode\":\"50\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(addtypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(addtype2, HttpStatus.OK));

		String email = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"email type\",\"omCode\":\"67\",\"refCode\":\"OFFICE\"}";
		String emailtypereq = "{\"systemCode\":\"BFL\",\"omLable\":\"email type\",\"omCode\":\"67\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(emailtypereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(email, HttpStatus.OK));
		
		String email2 = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"email type\",\"omCode\":\"70\",\"refCode\":\"PERSONAL\"}";
		String emailtypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"email type\",\"omCode\":\"70\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(emailtypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(email2, HttpStatus.OK));
		
		String bankacc = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"account type\",\"omCode\":\"22\",\"refCode\":\"SA\"}";
		String accypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"account type\",\"omCode\":\"22\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(accypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bankacc, HttpStatus.OK));
		
		String branch = "[{\"branchKey\":28830,\"bankMasterKey\":240,\"branchCode\":\"28830\",\"branchIfscCode\":\"HDFC0000007\",\"branchMicrCode\":\"411240002\",\"branchName\":\"LAUKIK APARTMENTS BHANDARKAR ROAD PUNE\",\"cityKey\":1784,\"pincodeKey\":null,\"stateKey\":257,\"countryKey\":91,\"bankName\":\"HDFC BANK LTD\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBranchDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(branch, HttpStatus.OK));
		
		String bank = "[{\"bankMasterKey\":240,\"bankCode\":\"240\",\"bankName\":\"HDFC BANK LTD\",\"isActive\":1,\"btFacilityAvailable\":1,\"preferredMode\":\"DD\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBankMasterCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bank, HttpStatus.OK));
		
		String pincodevalue = "{\"pinservicekey\":240,\"sourcecode\":\"240\",\"cityname\":\"PUNE\",\"isActive\":1}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getpincodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(pincodevalue, HttpStatus.OK));

		String bankref = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"bank master\",\"omCode\":\"240\",\"refCode\":\"240\"}";
		String bankrefreq = "{\"systemCode\":\"BFL\",\"omLable\":\"bank master\",\"omCode\":\"240\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(bankrefreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bankref, HttpStatus.OK));

		String res = "{\"bflbranchkey\":240,\"prodcatkey\":123,\"isActive\":1}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("servicesmasterUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(res, HttpStatus.OK));
		
		assertNotNull(util.mapCustomerPennantRequestForSOL(DataPopulator.fetchUserProfile(), DataPopulator.fetchApplicationDetails(), DataPopulator.fetchCustomerDisbDetails(), DataPopulator.fetchBankDetailsResponse(),
				1l,1l,headers));
		
	}

	
	@SuppressWarnings("unchecked")
	@Test
	public void mapCustomerPennantRequestForBOLTest() {
		HttpHeaders headers = new HttpHeaders();

		String bflBranch = "{\"bflbranchkey\":1,\"bflbranchcode\":\"320\",\"citykey\":1784}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflBranchesCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bflBranch, HttpStatus.OK));

		String salutation = "{\"salutationkey\":21,\"salutationcode\":\"DR\",\"salutationdec\":\"Doctor\",\"salutationgendercode\":\"MALE\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getSalutationDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(salutation, HttpStatus.OK));

		String lang = "{\"langkey\":21,\"langcode\":\"HINDI\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getLanguageDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(lang, HttpStatus.OK));

		String nationality = "{\"nationalitykey\":11,\"nationalitycode\":\"INDIAN\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getNationalityDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(nationality, HttpStatus.OK));

		String gender = "[{\"genderKey\":21,\"genderCode\":\"F\",\"genderValue\":\"Female\",\"isactive\":1},{\"genderKey\":22,\"genderCode\":\"M\",\"genderValue\":\"Male\",\"isactive\":1}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getGenderDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(gender, HttpStatus.OK));

		String maritalStatus = "[{\"maritalStatusKey\":27,\"maritalStatusCode\":\"M\",\"maritalStatusValue\":\"MARRIED\",\"isactive\":1},{\"maritalStatusKey\":28,\"maritalStatusCode\":\"S\",\"maritalStatusValue\":\"SINGLE\",\"isactive\":1},{\"maritalStatusKey\":29,\"maritalStatusCode\":\"D\",\"maritalStatusValue\":\"DIVORCEE\",\"isactive\":1},{\"maritalStatusKey\":30,\"maritalStatusCode\":\"W\",\"maritalStatusValue\":\"WIDOW/WIDOWER\",\"isactive\":1},{\"maritalStatusKey\":31,\"maritalStatusCode\":\"O\",\"maritalStatusValue\":\"OTHER\",\"isactive\":1}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getMaritalStatusDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(maritalStatus, HttpStatus.OK));

		String addtype = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"address type\",\"omCode\":\"46\",\"refCode\":\"OFFICE\"}";
		String addtypereq = "{\"systemCode\":\"BFL\",\"omLable\":\"address type\",\"omCode\":\"46\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(addtypereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(addtype, HttpStatus.OK));

		String pincode = "411027";
		when(disbursementUtil.fetchPincodeDetails(Mockito.any(), Mockito.any())).thenReturn(pincode);

		String city = "{\"pincodeKey\":\"411027\",\"citycategory\":\"A\",\"citycode\":\"1948\",\"cityname\":\"PUNE\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCityDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(city, HttpStatus.OK));

		String addtype2 = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"address type\",\"omCode\":\"50\",\"refCode\":\"CURRES\"}";
		String addtypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"address type\",\"omCode\":\"50\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(addtypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(addtype2, HttpStatus.OK));

		String email = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"email type\",\"omCode\":\"67\",\"refCode\":\"OFFICE\"}";
		String emailtypereq = "{\"systemCode\":\"BFL\",\"omLable\":\"email type\",\"omCode\":\"67\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(emailtypereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(email, HttpStatus.OK));
		
		String email2 = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"email type\",\"omCode\":\"70\",\"refCode\":\"PERSONAL\"}";
		String emailtypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"email type\",\"omCode\":\"70\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(emailtypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(email2, HttpStatus.OK));
		
		String bankacc = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"account type\",\"omCode\":\"22\",\"refCode\":\"SA\"}";
		String accypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"account type\",\"omCode\":\"22\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(accypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bankacc, HttpStatus.OK));
		
		String branch = "[{\"branchKey\":28830,\"bankMasterKey\":240,\"branchCode\":\"28830\",\"branchIfscCode\":\"HDFC0000007\",\"branchMicrCode\":\"411240002\",\"branchName\":\"LAUKIK APARTMENTS BHANDARKAR ROAD PUNE\",\"cityKey\":1784,\"pincodeKey\":null,\"stateKey\":257,\"countryKey\":91,\"bankName\":\"HDFC BANK LTD\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBranchDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(branch, HttpStatus.OK));
		
		String bank = "[{\"bankMasterKey\":240,\"bankCode\":\"240\",\"bankName\":\"HDFC BANK LTD\",\"isActive\":1,\"btFacilityAvailable\":1,\"preferredMode\":\"DD\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBankMasterCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bank, HttpStatus.OK));

		String bankref = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"bank master\",\"omCode\":\"240\",\"refCode\":\"240\"}";
		String bankrefreq = "{\"systemCode\":\"BFL\",\"omLable\":\"bank master\",\"omCode\":\"240\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(bankrefreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bankref, HttpStatus.OK));

		String businesstype = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"business master\",\"omCode\":\"2\",\"refCode\":\"4\"}";
		String businessrefreq = "{\"systemCode\":\"BFL\",\"omLable\":\"business master\",\"omCode\":\"2\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(businessrefreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(businesstype, HttpStatus.OK));

		String sector = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"nature of business\",\"omCode\":\"3\",\"refCode\":\"2\"}";
		String sectorereq = "{\"systemCode\":\"BFL\",\"omLable\":\"nature of business\",\"omCode\":\"3\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(sectorereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(sector, HttpStatus.OK));

		String subindustry = "{\"subindmastkey\":11,\"indmastkey\":645}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getIndustryDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(subindustry, HttpStatus.OK));
		
		String industry = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"industry master\",\"omCode\":\"645\",\"refCode\":\"1\"}";
		String industryreq = "{\"systemCode\":\"BFL\",\"omLable\":\"industry master\",\"omCode\":\"645\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(industryreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(industry, HttpStatus.OK));

		String businessMasterreq = "{\"systemCode\":\"BFL\",\"omLable\":\"business master\",\"omCode\":\"1\"}";
		String businessMaster = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"business master\",\"omCode\":\"1\",\"refCode\":\"7\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(businessMasterreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(businessMaster, HttpStatus.OK));
		
		String pincodevalue = "{\"pinservicekey\":240,\"sourcecode\":\"240\",\"cityname\":\"PUNE\",\"isActive\":1}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getpincodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(pincodevalue, HttpStatus.OK));

		String nobReq = "{\"systemCode\":\"BFL\",\"omLable\":\"nature of business\",\"omCode\":\"1\"}";
		String nob = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"nature of business\",\"omCode\":\"1\",\"refCode\":\"7\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(nobReq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(nob, HttpStatus.OK));
		
		String res = "{\"bflbranchkey\":240,\"prodcatkey\":123,\"isActive\":1}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("servicesmasterUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(res, HttpStatus.OK));
		
		assertNotNull(util.mapCustomerPennantRequestForBOL(DataPopulator.fetchUserProfile(), DataPopulator.fetchApplicationDetailsBOL(), DataPopulator.fetchCustomerDisbDetails(), DataPopulator.fetchBankDetailsResponse(),true,
				1l,1l,headers));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void mapCollateralPennantRequestTest() {
		String branch= "[{\"branchKey\":28830,\"bankMasterKey\":240,\"branchCode\":\"28830\",\"branchIfscCode\":\"HDFC0000007\",\"branchMicrCode\":\"411240002\",\"branchName\":\"LAUKIK APARTMENTS BHANDARKAR ROAD PUNE\",\"cityKey\":1784,\"pincodeKey\":null,\"stateKey\":257,\"countryKey\":91,\"bankName\":\"HDFC BANK LTD\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBranchDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(branch, HttpStatus.OK));
		
		String bank = "[{\"bankMasterKey\":240,\"bankCode\":\"240\",\"bankName\":\"HDFC BANK LTD\",\"isActive\":1,\"btFacilityAvailable\":1,\"preferredMode\":\"DD\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBankMasterCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bank, HttpStatus.OK));

		String bankref = "{\"bflRefSysCodeKey\":24024,\"systemKey\":5,\"omLable\":\"branch master\",\"omCode\":\"28830\",\"refCode\":\"28830\"}";
		String bankrefreq = "{\"systemCode\":\"BFL\",\"omLable\":\"branch master\",\"omCode\":\"28830\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(bankrefreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bankref, HttpStatus.OK));
		
		String bankref1 = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"bank master\",\"omCode\":\"240\",\"refCode\":\"240\"}";
		String bankrefreq1= "{\"systemCode\":\"BFL\",\"omLable\":\"bank master\",\"omCode\":\"240\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(bankrefreq1), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bankref1, HttpStatus.OK));
		
		assertNotNull(util.mapCollateralPennantRequest("27019", DataPopulator.fetchBankDetailsResponse(), DataPopulator.fetchCollateralDisbDetails(), new HttpHeaders()));
	}


	@SuppressWarnings("unchecked")
	@Test
	public void mapCustomerPennantRequestForBOLTest1() {
		UserProfile userProfile = DataPopulator.fetchUserProfile();
		HttpHeaders headers = new HttpHeaders();
		CustomerDisbDetails customerDisbDetails = DataPopulator.fetchCustomerDisbDetails();
		customerDisbDetails.getApplicantAddresses().get(0).setAddrLine1("1202,society,near SBI bank, pimple saudagar, pune, pune");
		List<BankDetailsResponse> bankDetailsList = DataPopulator.fetchBankDetailsResponse();

		String bflBranch = "{\"bflbranchkey\":1,\"bflbranchcode\":\"320\",\"citykey\":1784}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflBranchesCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bflBranch, HttpStatus.OK));

		String salutation = "{\"salutationkey\":21,\"salutationcode\":\"DR\",\"salutationdec\":\"Doctor\",\"salutationgendercode\":\"MALE\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getSalutationDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(salutation, HttpStatus.OK));

		String lang = "{\"langkey\":21,\"langcode\":\"HINDI\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getLanguageDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(lang, HttpStatus.OK));

		String nationality = "{\"nationalitykey\":11,\"nationalitycode\":\"INDIAN\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getNationalityDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(nationality, HttpStatus.OK));

		String gender = "[{\"genderKey\":21,\"genderCode\":\"F\",\"genderValue\":\"Female\",\"isactive\":1},{\"genderKey\":22,\"genderCode\":\"M\",\"genderValue\":\"Male\",\"isactive\":1}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getGenderDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(gender, HttpStatus.OK));

		String maritalStatus = "[{\"maritalStatusKey\":27,\"maritalStatusCode\":\"M\",\"maritalStatusValue\":\"MARRIED\",\"isactive\":1},{\"maritalStatusKey\":28,\"maritalStatusCode\":\"S\",\"maritalStatusValue\":\"SINGLE\",\"isactive\":1},{\"maritalStatusKey\":29,\"maritalStatusCode\":\"D\",\"maritalStatusValue\":\"DIVORCEE\",\"isactive\":1},{\"maritalStatusKey\":30,\"maritalStatusCode\":\"W\",\"maritalStatusValue\":\"WIDOW/WIDOWER\",\"isactive\":1},{\"maritalStatusKey\":31,\"maritalStatusCode\":\"O\",\"maritalStatusValue\":\"OTHER\",\"isactive\":1}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getMaritalStatusDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(maritalStatus, HttpStatus.OK));

		String addtype = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"address type\",\"omCode\":\"46\",\"refCode\":\"OFFICE\"}";
		String addtypereq = "{\"systemCode\":\"BFL\",\"omLable\":\"address type\",\"omCode\":\"46\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(addtypereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(addtype, HttpStatus.OK));

		String pincode = "411027";
		when(disbursementUtil.fetchPincodeDetails(Mockito.any(), Mockito.any())).thenReturn(pincode);

		String city = "{\"pincodeKey\":\"411027\",\"citycategory\":\"A\",\"citycode\":\"1948\",\"cityname\":\"PUNE\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCityDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(city, HttpStatus.OK));

		String addtype2 = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"address type\",\"omCode\":\"50\",\"refCode\":\"CURRES\"}";
		String addtypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"address type\",\"omCode\":\"50\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(addtypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(addtype2, HttpStatus.OK));

		String email = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"email type\",\"omCode\":\"67\",\"refCode\":\"OFFICE\"}";
		String emailtypereq = "{\"systemCode\":\"BFL\",\"omLable\":\"email type\",\"omCode\":\"67\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(emailtypereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(email, HttpStatus.OK));
		
		String email2 = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"email type\",\"omCode\":\"70\",\"refCode\":\"PERSONAL\"}";
		String emailtypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"email type\",\"omCode\":\"70\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(emailtypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(email2, HttpStatus.OK));
		
		String bankacc = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"account type\",\"omCode\":\"22\",\"refCode\":\"SA\"}";
		String accypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"account type\",\"omCode\":\"22\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(accypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bankacc, HttpStatus.OK));
		
		String branch = "[{\"branchKey\":28830,\"bankMasterKey\":240,\"branchCode\":\"28830\",\"branchIfscCode\":\"HDFC0000007\",\"branchMicrCode\":\"411240002\",\"branchName\":\"LAUKIK APARTMENTS BHANDARKAR ROAD PUNE\",\"cityKey\":1784,\"pincodeKey\":null,\"stateKey\":257,\"countryKey\":91,\"bankName\":\"HDFC BANK LTD\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBranchDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(branch, HttpStatus.OK));
		
		String bank = "[{\"bankMasterKey\":240,\"bankCode\":\"240\",\"bankName\":\"HDFC BANK LTD\",\"isActive\":1,\"btFacilityAvailable\":1,\"preferredMode\":\"DD\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBankMasterCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bank, HttpStatus.OK));

		String bankref = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"bank master\",\"omCode\":\"240\",\"refCode\":\"240\"}";
		String bankrefreq = "{\"systemCode\":\"BFL\",\"omLable\":\"bank master\",\"omCode\":\"240\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(bankrefreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bankref, HttpStatus.OK));

		String businesstype = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"business master\",\"omCode\":\"2\",\"refCode\":\"4\"}";
		String businessrefreq = "{\"systemCode\":\"BFL\",\"omLable\":\"business master\",\"omCode\":\"2\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(businessrefreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(businesstype, HttpStatus.OK));

		String sector = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"nature of business\",\"omCode\":\"3\",\"refCode\":\"2\"}";
		String sectorereq = "{\"systemCode\":\"BFL\",\"omLable\":\"nature of business\",\"omCode\":\"3\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(sectorereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(sector, HttpStatus.OK));

		String subindustry = "{\"subindmastkey\":11,\"indmastkey\":645}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getIndustryDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(subindustry, HttpStatus.OK));
		
		String industry = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"industry master\",\"omCode\":\"645\",\"refCode\":\"1\"}";
		String industryreq = "{\"systemCode\":\"BFL\",\"omLable\":\"industry master\",\"omCode\":\"645\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(industryreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(industry, HttpStatus.OK));
		
		String businessMasterreq = "{\"systemCode\":\"BFL\",\"omLable\":\"business master\",\"omCode\":\"1\"}";
		String businessMaster = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"business master\",\"omCode\":\"1\",\"refCode\":\"7\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(businessMasterreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(businessMaster, HttpStatus.OK));
		String pincodevalue = "{\"pinservicekey\":240,\"sourcecode\":\"240\",\"cityname\":\"PUNE\",\"isActive\":1}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getpincodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(pincodevalue, HttpStatus.OK));

		String nobReq = "{\"systemCode\":\"BFL\",\"omLable\":\"nature of business\",\"omCode\":\"1\"}";
		String nob = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"nature of business\",\"omCode\":\"1\",\"refCode\":\"7\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(nobReq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(nob, HttpStatus.OK));
		
		String res = "{\"bflbranchkey\":240,\"prodcatkey\":123,\"isActive\":1}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("servicesmasterUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(res, HttpStatus.OK));
		
		assertNotNull(util.mapCustomerPennantRequestForBOL(userProfile, DataPopulator.fetchApplicationDetailsBOL(), customerDisbDetails, bankDetailsList,false,
				1l,1l,headers));
		
	}

	@Test
	public void mapCustomerPennantRequestForFundedTest1() {
		
		util.mapCustomerPennatRequestForFunded(DataPopulator.fetchRequestForFunded());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void mapCustomerPennantRequestForPROLTest() {
		HttpHeaders headers = new HttpHeaders();

		String bflBranch = "{\"bflbranchkey\":1,\"bflbranchcode\":\"320\",\"citykey\":1784}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflBranchesCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bflBranch, HttpStatus.OK));

		String salutation = "{\"salutationkey\":21,\"salutationcode\":\"DR\",\"salutationdec\":\"Doctor\",\"salutationgendercode\":\"MALE\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getSalutationDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(salutation, HttpStatus.OK));

		String lang = "{\"langkey\":21,\"langcode\":\"HINDI\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getLanguageDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(lang, HttpStatus.OK));

		String nationality = "{\"nationalitykey\":11,\"nationalitycode\":\"INDIAN\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getNationalityDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(nationality, HttpStatus.OK));

		String gender = "[{\"genderKey\":21,\"genderCode\":\"F\",\"genderValue\":\"Female\",\"isactive\":1},{\"genderKey\":22,\"genderCode\":\"M\",\"genderValue\":\"Male\",\"isactive\":1}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getGenderDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(gender, HttpStatus.OK));

		String maritalStatus = "[{\"maritalStatusKey\":27,\"maritalStatusCode\":\"M\",\"maritalStatusValue\":\"MARRIED\",\"isactive\":1},{\"maritalStatusKey\":28,\"maritalStatusCode\":\"S\",\"maritalStatusValue\":\"SINGLE\",\"isactive\":1},{\"maritalStatusKey\":29,\"maritalStatusCode\":\"D\",\"maritalStatusValue\":\"DIVORCEE\",\"isactive\":1},{\"maritalStatusKey\":30,\"maritalStatusCode\":\"W\",\"maritalStatusValue\":\"WIDOW/WIDOWER\",\"isactive\":1},{\"maritalStatusKey\":31,\"maritalStatusCode\":\"O\",\"maritalStatusValue\":\"OTHER\",\"isactive\":1}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getMaritalStatusDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(maritalStatus, HttpStatus.OK));

		String addtype = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"address type\",\"omCode\":\"46\",\"refCode\":\"OFFICE\"}";
		String addtypereq = "{\"systemCode\":\"BFL\",\"omLable\":\"address type\",\"omCode\":\"46\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(addtypereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(addtype, HttpStatus.OK));

		String pincode = "411027";
		when(disbursementUtil.fetchPincodeDetails(Mockito.any(), Mockito.any())).thenReturn(pincode);

		String city = "{\"pincodeKey\":\"411027\",\"citycategory\":\"A\",\"citycode\":\"1948\",\"cityname\":\"PUNE\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCityDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(city, HttpStatus.OK));

		String addtype2 = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"address type\",\"omCode\":\"50\",\"refCode\":\"CURRES\"}";
		String addtypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"address type\",\"omCode\":\"50\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(addtypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(addtype2, HttpStatus.OK));

		String email = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"email type\",\"omCode\":\"67\",\"refCode\":\"OFFICE\"}";
		String emailtypereq = "{\"systemCode\":\"BFL\",\"omLable\":\"email type\",\"omCode\":\"67\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(emailtypereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(email, HttpStatus.OK));
		
		String email2 = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"email type\",\"omCode\":\"70\",\"refCode\":\"PERSONAL\"}";
		String emailtypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"email type\",\"omCode\":\"70\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(emailtypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(email2, HttpStatus.OK));
		
		String bankacc = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"account type\",\"omCode\":\"22\",\"refCode\":\"SA\"}";
		String accypereq2 = "{\"systemCode\":\"BFL\",\"omLable\":\"account type\",\"omCode\":\"22\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(accypereq2), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bankacc, HttpStatus.OK));
		
		String branch = "[{\"branchKey\":28830,\"bankMasterKey\":240,\"branchCode\":\"28830\",\"branchIfscCode\":\"HDFC0000007\",\"branchMicrCode\":\"411240002\",\"branchName\":\"LAUKIK APARTMENTS BHANDARKAR ROAD PUNE\",\"cityKey\":1784,\"pincodeKey\":null,\"stateKey\":257,\"countryKey\":91,\"bankName\":\"HDFC BANK LTD\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBranchDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(branch, HttpStatus.OK));
		
		String bank = "[{\"bankMasterKey\":240,\"bankCode\":\"240\",\"bankName\":\"HDFC BANK LTD\",\"isActive\":1,\"btFacilityAvailable\":1,\"preferredMode\":\"DD\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBankMasterCodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bank, HttpStatus.OK));

		String bankref = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"bank master\",\"omCode\":\"240\",\"refCode\":\"240\"}";
		String bankrefreq = "{\"systemCode\":\"BFL\",\"omLable\":\"bank master\",\"omCode\":\"240\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(bankrefreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bankref, HttpStatus.OK));

		String sector = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"nature of business\",\"omCode\":\"3\",\"refCode\":\"2\"}";
		String sectorereq = "{\"systemCode\":\"BFL\",\"omLable\":\"nature of business\",\"omCode\":\"3\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(sectorereq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(sector, HttpStatus.OK));

		String subindustry = "{\"subindmastkey\":11,\"indmastkey\":645}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getIndustryDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(subindustry, HttpStatus.OK));
		
		String industry = "{\"bflRefSysCodeKey\":171,\"systemKey\":5,\"omLable\":\"industry master\",\"omCode\":\"645\",\"refCode\":\"1\"}";
		String industryreq = "{\"systemCode\":\"BFL\",\"omLable\":\"industry master\",\"omCode\":\"645\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(industryreq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(industry, HttpStatus.OK));
		
		String pincodevalue = "{\"pinservicekey\":240,\"sourcecode\":\"240\",\"cityname\":\"PUNE\",\"isActive\":1}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getpincodeUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(pincodevalue, HttpStatus.OK));

		String nobReq = "{\"systemCode\":\"BFL\",\"omLable\":\"nature of business\",\"omCode\":\"1\"}";
		String nob = "{\"bflRefSysCodeKey\":null,\"systemKey\":5,\"omLable\":\"nature of business\",\"omCode\":\"1\",\"refCode\":\"7\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBflRefCodeUrl"), Mockito.any(), Mockito.any(), Mockito.eq(nobReq), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(nob, HttpStatus.OK));
		
		assertNotNull(util.mapCustomerPennantRequestForPROL(DataPopulator.fetchUserProfile(), DataPopulator.fetchApplicationDetailsBOL(), DataPopulator.fetchCustomerDisbDetails(), DataPopulator.fetchBankDetailsResponse(),true,
				1l,headers));
	}
}
