package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.bflawsutil.helper.BFLAwsS3Helper;
import com.bajaj.markets.credit.disbursement.consumer.bean.AppBundleDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.AppPlanDetCostBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCustomerPennantRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.EmailInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.NotificationTemplateDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.OccupationAttribute;
import com.bajaj.markets.credit.disbursement.consumer.bean.PhoneInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.PricingDetail;
import com.bajaj.markets.credit.disbursement.consumer.bean.PricingFees;
import com.bajaj.markets.credit.disbursement.consumer.bean.ProductTypeBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.Reference;
import com.bajaj.markets.credit.disbursement.consumer.bean.VasPricingCheckBean;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;

@SpringBootTest
public class NotificationProcessorTest {

	@InjectMocks
	private NotificationProcessor notificationProcessor;

	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Mock
	BFLAwsS3Helper helper;

	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	LoanProcessor loanProcessor;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(notificationProcessor, "custPortalLink", "custPortalLink");
		ReflectionTestUtils.setField(notificationProcessor, "getDocListUrl", "getDocListUrl");
		ReflectionTestUtils.setField(notificationProcessor, "notificationUrl", "notificationUrl");
		ReflectionTestUtils.setField(notificationProcessor, "bucketName", "bucketName");
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void sendNotificationsTest() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();
		
		NotificationTemplateDataBean notificationTemplateBean=new NotificationTemplateDataBean();
		notificationTemplateBean.setApplicationId("");
		notificationTemplateBean.setCustomerName("");
		notificationTemplateBean.setProductName("");
		notificationTemplateBean.setLanNumber("");
		notificationTemplateBean.setAmount("");
		notificationTemplateBean.setRoi("");
		notificationTemplateBean.setTenor("12");
		notificationTemplateBean.setHybridFlexi(true);
		notificationTemplateBean.setFirstEmiAmt("1800");
		notificationTemplateBean.setIsTenure("");
		notificationTemplateBean.setIsEmiAmt("");
		notificationTemplateBean.setDroplineTenure("");
		notificationTemplateBean.setDropLineEmiAmt("");
		notificationTemplateBean.setEmiCycleDay("");
		notificationTemplateBean.setFirstEMIdt("");
		notificationTemplateBean.setPhoneNumber("");
		notificationTemplateBean.setRecipientEmailId("");
		
		ProductTypeBean productTypeBean = new ProductTypeBean();
		productTypeBean.setDisplayproductname("BOL");
		productTypeBean.setDisplayloantypename("Term Loan");
		
		AppBundleDetails appBundleDetails = new  AppBundleDetails();
		appBundleDetails.setAppBundleKey(1L);
		appBundleDetails.setApplicationKey(1000L);
		appBundleDetails.setBundlePlanKey(5);
		
		List<AppPlanDetCostBean> appPlanDetCostBeanList = new ArrayList<>();
		AppPlanDetCostBean appPlanDetCostBean = new AppPlanDetCostBean();
		appPlanDetCostBean.setActualPrice(18000);
		appPlanDetCostBeanList.add(appPlanDetCostBean);
		
		Reference ref = new Reference();
		ref.setKey(1L);
		OccupationAttribute occupationAttribute = new OccupationAttribute();
		occupationAttribute.setOcupationType(ref);
		
		Map<String, String> occupationType = new HashMap<String, String>();
		occupationType.put("1", "Salaried");
		ReflectionTestUtils.setField(notificationProcessor, "occupationType", occupationType);
		
		List<PricingFees> fees = new ArrayList<PricingFees>();
		PricingFees fee = new PricingFees();
		fee.setAppLoanPricingKey(1L);
		fee.setFeeCode("PROCFEE");
        fee.setFeesInAmount(BigDecimal.TEN);
        fees.add(fee);
		PricingDetail pricingDetail = new PricingDetail();
		pricingDetail.setAppLoanPricingKey("1");
		pricingDetail.setFees(fees);
		List<PricingDetail> pricingDetailLst = new ArrayList<PricingDetail>();
		pricingDetailLst.add(pricingDetail);
		when(loanProcessor.fetchPricingDetails(Mockito.any(),Mockito.any())).thenReturn(pricingDetailLst);
		
		VasPricingCheckBean latestPricing = new VasPricingCheckBean();
		latestPricing.setAppLoanPricingKey(1L);
		when(loanProcessor.fetchLatestPricingDetails(Mockito.any(),Mockito.any())).thenReturn(latestPricing);
		
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("notificationUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("success", HttpStatus.OK));

		when(disbursementBusinessHelper.getOccupationDetails(Mockito.any(), Mockito.any())).thenReturn(occupationAttribute);
				
		when(disbursementBusinessHelper.getProductTypeDetails(Mockito.any(), Mockito.any())).thenReturn(productTypeBean);
		
		when(disbursementBusinessHelper.fetchBundleDetails(Mockito.any(), Mockito.any())).thenReturn(appBundleDetails);
		
		when(disbursementBusinessHelper.fetchPricingDetails(Mockito.any(), Mockito.any())).thenReturn(appPlanDetCostBeanList);
				
		when(helper.generatePresignedURL(Mockito.eq("bucketName"), Mockito.any())).thenReturn("resultStr");
		
		notificationProcessor.sendNotifications(notificationTemplateBean,data);
	}
	@SuppressWarnings("unchecked")
	@Test
	public void sendSanctionLetterTest() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();
		
		NotificationTemplateDataBean notificationTemplateBean=new NotificationTemplateDataBean();
		notificationTemplateBean.setApplicationId("");
		notificationTemplateBean.setCustomerName("");
		notificationTemplateBean.setProductName("");
		notificationTemplateBean.setLanNumber("");
		notificationTemplateBean.setAmount("");
		notificationTemplateBean.setRoi("");
		notificationTemplateBean.setTenor("12");
		notificationTemplateBean.setHybridFlexi(true);
		notificationTemplateBean.setFirstEmiAmt("1800");
		notificationTemplateBean.setIsTenure("");
		notificationTemplateBean.setIsEmiAmt("");
		notificationTemplateBean.setDroplineTenure("");
		notificationTemplateBean.setDropLineEmiAmt("");
		notificationTemplateBean.setEmiCycleDay("");
		notificationTemplateBean.setFirstEMIdt("");
		notificationTemplateBean.setPhoneNumber("");
		notificationTemplateBean.setRecipientEmailId("");
		
		ProductTypeBean productTypeBean = new ProductTypeBean();
		productTypeBean.setDisplayproductname("BOL");
		productTypeBean.setDisplayloantypename("Term Loan");
		
		AppBundleDetails appBundleDetails = new  AppBundleDetails();
		appBundleDetails.setAppBundleKey(1L);
		appBundleDetails.setApplicationKey(1000L);
		appBundleDetails.setBundlePlanKey(5);
		
		List<AppPlanDetCostBean> appPlanDetCostBeanList = new ArrayList<>();
		AppPlanDetCostBean appPlanDetCostBean = new AppPlanDetCostBean();
		appPlanDetCostBean.setActualPrice(18000);
		appPlanDetCostBeanList.add(appPlanDetCostBean);
		
		Reference ref = new Reference();
		ref.setKey(1L);
		OccupationAttribute occupationAttribute = new OccupationAttribute();
		occupationAttribute.setOcupationType(ref);
		
		Map<String, String> occupationType = new HashMap<String, String>();
		occupationType.put("1", "Salaried");
		ReflectionTestUtils.setField(notificationProcessor, "occupationType", occupationType);
		
		List<PricingFees> fees = new ArrayList<PricingFees>();
		PricingFees fee = new PricingFees();
		fee.setAppLoanPricingKey(1L);
		fee.setFeeCode("PROCFEE");
        fee.setFeesInAmount(BigDecimal.TEN);
        fees.add(fee);
		PricingDetail pricingDetail = new PricingDetail();
		pricingDetail.setAppLoanPricingKey("1");
		pricingDetail.setFees(fees);
		List<PricingDetail> pricingDetailLst = new ArrayList<PricingDetail>();
		pricingDetailLst.add(pricingDetail);
		when(loanProcessor.fetchPricingDetails(Mockito.any(),Mockito.any())).thenReturn(pricingDetailLst);
		
		VasPricingCheckBean latestPricing = new VasPricingCheckBean();
		latestPricing.setAppLoanPricingKey(1L);
		when(loanProcessor.fetchLatestPricingDetails(Mockito.any(),Mockito.any())).thenReturn(latestPricing);
		
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("notificationUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("success", HttpStatus.OK));

		when(disbursementBusinessHelper.getOccupationDetails(Mockito.any(), Mockito.any())).thenReturn(occupationAttribute);
				
		when(disbursementBusinessHelper.getProductTypeDetails(Mockito.any(), Mockito.any())).thenReturn(productTypeBean);
		
		when(disbursementBusinessHelper.fetchBundleDetails(Mockito.any(), Mockito.any())).thenReturn(appBundleDetails);
		
		when(disbursementBusinessHelper.fetchPricingDetails(Mockito.any(), Mockito.any())).thenReturn(appPlanDetCostBeanList);
				
		when(helper.generatePresignedURL(Mockito.eq("bucketName"), Mockito.any())).thenReturn("resultStr");
		
		notificationProcessor.sendSanctionLetter(notificationTemplateBean,data);
	}
	
}
