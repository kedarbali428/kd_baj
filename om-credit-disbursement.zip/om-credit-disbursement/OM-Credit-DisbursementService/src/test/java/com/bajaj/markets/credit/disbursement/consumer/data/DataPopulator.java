package com.bajaj.markets.credit.disbursement.consumer.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bajaj.markets.credit.disbursement.consumer.bean.AddressInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicantDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.BankDetailsResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCollateralDisbDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.CustomerBankInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.CustomerDisbDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedAddressRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedApplicationDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedMandateDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.NomineeDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.PaymentDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.UserProfile;
import com.google.gson.Gson;

public class DataPopulator {
	public static List<BankDetailsResponse> fetchBankDetailsResponse() {
		List<BankDetailsResponse> beanList = new ArrayList<>();
		Gson gson = new Gson();
		String str = "{\"bankDetailsKey\":570,\"accoutNumber\":\"100000111\",\"userAttributeKey\":\"9244\",\"branchKey\":\"28830\",\"impsStatus\":null,\"impsKey\":null,\"source\":\"EP\",\"bankAccountTypeKey\":\"22\",\"impsNameMatch\":null,\"finalMandateKey\":null,\"systemSelectedMandateKey\":\"46\",\"bankAccountCatagory\":\"Disbursement\",\"beneficiaryType\":\"CUSTOMER\",\"preferedBank\":true,\"beneficiaryNames\":\"Test\",\"holderName\":\"Test\",\"bankMasterKey\":null,\"mandateAddedBy\":null,\"paymentMode\":\"IMPS\"}";
		BankDetailsResponse bean = gson.fromJson(str, BankDetailsResponse.class);
		beanList.add(bean);
		return beanList;
	}

	public static CustomerDisbDetails fetchCustomerDisbDetails() {
		CustomerDisbDetails bean;
		Gson gson = new Gson();
		String str = "{\"langKey\":1,\"prefferedflg\":1,\"nationalityKey\":1,\"custcategorycdkey\":1,\"applicantAddresses\":[{\"addressKey\":\"20554\",\"addrtypkey\":46,\"buildingNo\":null,\"addrLine1\":\"pune\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null},{\"addressKey\":\"7539\",\"addrtypkey\":50,\"buildingNo\":null,\"addrLine1\":\"addrLine1\",\"addrLine2\":\"pune\",\"flatNo\":null,\"street\":null}],\"phones\":[{\"phoneTypeKey\":45,\"phoneCountryCode\":\"91\",\"phoneAreaCode\":\"91\",\"phoneNumber\":\"9899999999\"}],\"emails\":[{\"emailtypekey\":67,\"emailaddress\":\"kjgsglsgsk@bajajfinserv.in\",\"emailpriority\":5},{\"emailtypekey\":70,\"emailaddress\":\"jgklsjgks@gmail.com\",\"emailpriority\":4}]}";
		bean = gson.fromJson(str, CustomerDisbDetails.class);
		return bean;
	}

	public static UserProfile fetchUserProfile() {
		UserProfile userProfile;
		Gson gson = new Gson();
		String userProfileStr = "{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}";
		userProfile = gson.fromJson(userProfileStr, UserProfile.class);
		return userProfile;

	}

	public static ApplicationDetails fetchApplicationDetails() {
		ApplicationDetails applicationDetails;
		Gson gson = new Gson();
		String applicationDetailStr = "{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"manager\"},\"experience\":\"116\",\"netSalary\":\"98999\",\"employerType\":68671,\"workExperienceInMonths\":null,\"principalIndustry\":null,\"totalExperience\":null,\"decNetSalary\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":null,\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null},\"presentBusinessVintage\":null,\"cif\":null,\"officetype\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":\"LKJPO0987Y\",\"applicantKey\":123795},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[\"LENRNC\"],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"Pune\",\"tier\":\"Tier 1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"Pune\",\"tier\":\"Tier 1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"20554\",\"addressTypeKey\":\"46\",\"resiType\":\"1\",\"addressLine1\":\"addressLine1\",\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"115432\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null},{\"addressKey\":\"7539\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":\"addressLinE1\",\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"115432\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":98999}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":90,\"obligationAmount\":null,\"btBankMasterKey\":\"null\",\"btsSegment\":null}";
		applicationDetails = gson.fromJson(applicationDetailStr, ApplicationDetails.class);
		return applicationDetails;
	}

	public static CreateCollateralDisbDetails fetchCollateralDisbDetails() {
		CreateCollateralDisbDetails bean;
		Gson gson = new Gson();
		String str = "{\"spdcDetails\":{\"pdcnumber1\":\"1\",\"pdcamount1\":1,\"pdcnumber2\":\"2\",\"pdcamount2\":2,\"pdcnumber3\":\"3\",\"pdcamount3\":3,\"pdcnumber4\":\"4\",\"pdcamount4\":4}}";
		bean = gson.fromJson(str, CreateCollateralDisbDetails.class);
		return bean;
	}

	public static ApplicationDetails fetchApplicationDetailsBOL() {
		ApplicationDetails applicationDetails;
		Gson gson = new Gson();
		String applicationDetailsForBOL ="{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":2,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":null,\"experience\":null,\"netSalary\":null,\"employerType\":null,\"workExperienceInMonths\":null,\"principalIndustry\":null},\"businessOwnerDetails\":{\"businessName\":\"Construction\",\"businessType\":{\"key\":2,\"code\":null,\"value\":null},\"natureOfBusiness\":{\"key\":1,\"code\":null,\"value\":null},\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":\"More than 15 Cr.\"},\"netMonthlyIncome\":null,\"businessVintage\":\"190\",\"proprieterName\":null,\"businessPan\":\"ALAFA6762C\",\"gstNumber\":\"27alacc6762c2w2\",\"subindumastkey\":{\"key\":7,\"code\":null,\"value\":null},\"profitAfterTax\":898900.00000,\"averageBankBalance\":1562345.00000,\"companyType\":null,\"presentBusinessVintage\":null,\"cif\":null,\"officetype\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"null\"},\"userProfile\":{\"applicationKey\":null,\"applicantKey\":12,\"applicationUserAttributeKey\":123,\"applicationUserAttributeType\":null,\"mobile\":\"7276806030\",\"dateOfBirth\":\"1983-05-26\",\"name\":{\"firstName\":\"suresh\",\"middleName\":\"kumar\",\"lastName\":\"hyb\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"mother kumar\",\"fatherName\":\"father kumar\",\"panNumber\":\"BOQPK3545V\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"Pune\",\"tier\":\"Tier 1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"Pune\",\"tier\":\"Tier 1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"20554\",\"addressTypeKey\":\"46\",\"resiType\":\"1\",\"addressLine1\":\"addressLIne1\",\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"113606\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null},{\"addressKey\":\"7539\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":\"addressLine1\",\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"113548\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":null}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":93,\"obligationAmount\":null,\"btBankMasterKey\":\"null\",\"btsSegment\":null}";
		applicationDetails = gson.fromJson(applicationDetailsForBOL, ApplicationDetails.class);
		return applicationDetails;
	}
	
	public static GlobalDataBean fetchGlobalData() {
		GlobalDataBean data = new GlobalDataBean();
		data.setAppAtrKey("1");
		data.setApplicantKey("1");
		data.setApplicationKey("1");
		data.setApplicationStatus(1);
		data.setAppOccupationKey("1");
		data.setBusinessPan("1");
		data.setCoApplicantKey("11");
		data.setL2ProductCode("BFLSOL");
		data.setL2ProductKey(123l);
		data.setL4ProductCode("BFL");
		data.setL3ProductCode("BFLSOL");
		data.setParentApplicationKey("123");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken", "authtoken");
		headers.put("cmptcorrid", "cmptcorrid");
		headers.put("guardtoken", "guardtoken");
		data.setHeaders(headers);
		return data;
	}
	
	public static FundedDisbursementEventRequestBean fetchRequestForFunded() {
		FundedDisbursementEventRequestBean bean=new FundedDisbursementEventRequestBean();
		bean.setApplicationId("18340");
		FundedApplicationDetails applicationDetails=new FundedApplicationDetails();
		applicationDetails.setApplicationNo("18340");
		applicationDetails.setQuoteNumber("QT-18340-13831");
		applicationDetails.setL2ProductKey("10");
		applicationDetails.setL3ProductCode("CPPCP");
		applicationDetails.setBusinessVertical("INSURANCE_TELEBINDING");
		applicationDetails.setPoType("INSPB");
		applicationDetails.setPolicyType("NEW");
		applicationDetails.setL2ProductCode("OMPL");
		applicationDetails.setL3ProductCode("BFLSOL");
		applicationDetails.setL4ProductCode("SOLTL");
		applicationDetails.setNetPremiumAmount("1000");
		applicationDetails.setPaymentQuoteId("1111");
		NomineeDetails nomineeDetail=new NomineeDetails();
		nomineeDetail.setNomAddress1("akola");
		nomineeDetail.setNomDob1("23-05-2000");
		nomineeDetail.setNomMob1("8999999999");
		nomineeDetail.setNomName1("Dev");
		nomineeDetail.setNomRel1("BROTHER");
		List<NomineeDetails> nomineeDetails=new ArrayList<NomineeDetails>();
		nomineeDetails.add(nomineeDetail);
		applicationDetails.setNomineeDetails(nomineeDetails);
		FundedDetails fundingDetails=new FundedDetails();
		fundingDetails.setFundingAmount("222222");
		fundingDetails.setFundingROI("4");
		fundingDetails.setFundingType("PARTIAL");
		fundingDetails.setFundingTenor("60");
		fundingDetails.setPolicyTenore("2");
		fundingDetails.setSumAssured("222222");
		applicationDetails.setFundingDetails(fundingDetails);
		PaymentDetails paymentDetails=new PaymentDetails();
		paymentDetails.setAmount("1000");
		paymentDetails.setTransactionRef("dfgt45");
		paymentDetails.setValueDate("");
		applicationDetails.setPaymentDetails(paymentDetails);
		FundedMandateDetails mandateDetails=new FundedMandateDetails();
		mandateDetails.setExistingMandate("true");
		mandateDetails.setMandateRef("1052142111");
		mandateDetails.setMandateType("S");
		mandateDetails.setIfsc("HDFC0000212");
		mandateDetails.setMicr("400240037");
		mandateDetails.setAccType("10");
		mandateDetails.setAccHolderName("bala");
		mandateDetails.setAccNumber("02121020001680");
		mandateDetails.setOpenMandate(true);
		mandateDetails.setExpiryDate("2035-03-12T00:00:00");
		applicationDetails.setMandateDetails(mandateDetails);
		bean.setApplicationDetails(applicationDetails);
		ApplicantDetails applicantDetails=new ApplicantDetails();
		applicantDetails.setFirstName("Vaishnavi");
		applicantDetails.setLastName("Deshmukh");
		applicantDetails.setDateOfBirth("1995-05-24");
		applicantDetails.setGender("F");
		applicantDetails.setMaritalStatus("S");
		applicantDetails.setMobileNumber("9989999888");
		applicantDetails.setFinnoneCustId("123451");
		applicantDetails.setApplicantPan("HECPD1234L");
		applicantDetails.setPersonalEmailId("abcccc@gmail.com");
		applicantDetails.setOfficialEmailId("bacccc@gmail.com");
		List<FundedAddressRequest> addresses=new ArrayList<>();
		FundedAddressRequest addr=new FundedAddressRequest();
		addr.setBuildingNo("12");
		addr.setAddrType("CURRES");
		addr.setStreet("1 st back");
		addr.setState("5");
		addr.setCity("1948");
		addr.setPinCode("411014");
		addr.setCountry("IN");
		addresses.add(addr);
		applicantDetails.setAddresses(addresses);
		bean.setApplicantDetails(applicantDetails);
		CustomerBankInfo bank=new CustomerBankInfo();
		bank.setBankName("240");
		bank.setAccountType("SA");
		bank.setAccountNumber("50100101678898");
		bean.setBankDetails(bank);
		Map<String, String> header = new HashMap<>();
		header.put("authtoken", "vcxvc");
		bean.setHeaders(header);
		return bean;
	}
}
