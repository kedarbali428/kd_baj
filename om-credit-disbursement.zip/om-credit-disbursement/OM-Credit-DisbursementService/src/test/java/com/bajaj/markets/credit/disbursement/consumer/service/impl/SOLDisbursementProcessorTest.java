package com.bajaj.markets.credit.disbursement.consumer.service.impl;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationDetail;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.google.gson.Gson;

@SpringBootConfiguration
@SpringBootTest
public class SOLDisbursementProcessorTest {
	
	@InjectMocks
	private SOLDisbursementProcessor solDisbProcessor;

	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	DisbursementUtil disbursementUtil;
	
	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;
	
	@Mock
	LoanProcessor loanProcessor;

	@Mock
	BeneficiaryProcessor beneficiaryProcessor;

	@Mock
	CustomerProcessor customerProcessor;

	@Mock
	CollateralProcessor collateralProcessor;
	
	@Mock
	SOLErrorHandlingProcessor sOLErrorHandlingProcessor;
	
	private String getDisbErrorUrl="getDisbErrorUrl";
	
	
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(solDisbProcessor, "getDisbErrorUrl", "getDisbErrorUrl");
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void processDisbursementTest() {
		DisbursementEventRequestBean request = new DisbursementEventRequestBean();
		request.setApplicationId("1100000000006221");
		request.setProductCode("BFLSOL");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		request.setHeaders(headers);
		when(disbursementUtil.raiseEvent(Mockito.any(), Mockito.any())).thenReturn(true);
		validateRequest();
		fetchApplicationns();
		generateTrancheDetails();
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq(getDisbErrorUrl), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
						new ResponseEntity<String>("[{\"disbursmentstage\":\"CREATE_CUSTOMER\"}]", HttpStatus.OK));
		solDisbProcessor.processDisbursement(request);
	}

	public void generateTrancheDetails() {
		TranchBean tranchBean = new TranchBean();
		tranchBean.setTranchkey(123l);
		List<TranchBean> trnchLst = new ArrayList<TranchBean>();
		trnchLst.add(tranchBean);
		when(loanProcessor.fetchTranchDetails(Mockito.any(), Mockito.any())).thenReturn(trnchLst);

	}
	
	public void validateRequest() {
		when(disbursementUtil.validateRequest(DataPopulator.fetchGlobalData())).thenReturn(true);
		}
	
	private void fetchApplicationns() {
		Gson gson=new Gson();
		String str="{\"applicationKey\":\"1100000000006221\",\"parentApplicationKey\":\"1100000000006217\",\"mobile\":123,\"dateofbirth\":123,\"applicantKey\":123,\"l2ProductKey\":10002,\"l2ProductCode\":\"OMPL\",\"l3ProductKey\":10,\"l3ProductCode\":\"BFLSOL\",\"l4ProductKey\":10,\"l4ProductCode\":\"BFLSOLTL\",\"principalKey\":3,\"applicationStatus\":1,\"riskoffertype\":123,\"inProcessing\":true}";
		ApplicationDetail appDtl=gson.fromJson(str, ApplicationDetail.class);
		when(disbursementUtil.fetchApplicationDetails(DataPopulator.fetchGlobalData())).thenReturn(appDtl);
	}
	
	
}