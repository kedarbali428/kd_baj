package com.bajaj.markets.credit.disbursement.repository;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.MongoDBConfig;

@SpringBootTest
public class MongoDBConfigTest {

	@InjectMocks
	private MongoDBConfig mongoDBConfig;
	
	@Mock
	private BFLLoggerUtil logger;

	private String domainName = "domain.com";

	private String port = "8080";

	private String disbursementDBName = "dbname";

	private String userName = "username";

	private String password = "password";

	private String readPreference = "secondary";

	private String trustStore = "truststore";

	private String trustStorePassword = "trustStorePassword";
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		
		ReflectionTestUtils.setField(mongoDBConfig, "domainName", domainName);
		ReflectionTestUtils.setField(mongoDBConfig, "port", port);
		ReflectionTestUtils.setField(mongoDBConfig, "disbursementDBName", disbursementDBName);
		ReflectionTestUtils.setField(mongoDBConfig, "userName", userName);
		ReflectionTestUtils.setField(mongoDBConfig, "password", password);
		ReflectionTestUtils.setField(mongoDBConfig, "readPreference", readPreference);
		ReflectionTestUtils.setField(mongoDBConfig, "trustStore", trustStore);
		ReflectionTestUtils.setField(mongoDBConfig, "trustStorePassword", trustStorePassword);
	}
	
	@Test
	public void disbursementMongoClienttest() {
		mongoDBConfig.disbursementMongoClient();
	}
	
	@Test
	public void testImportTLS() throws FileNotFoundException {
		mongoDBConfig.importTLS();
	}
}
