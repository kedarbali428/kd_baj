package com.bajaj.markets.credit.disbursement.consumer.util;

import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.insurance.remoteapitrackinglib.service.impl.RemoteApiTrackingImpl;

@SpringBootTest
public class LMSHelperTest {

	@InjectMocks
	private LMSHelper helper;
	
	@Mock
	BFLLoggerUtil logger;

	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Mock
	private RemoteApiTrackingImpl remoteApiTrackingImpl;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(helper, "lmsGatewayUrl", "lmsGatewayUrl");
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = DisbursementServiceException.class)
	public void executeLmsRequestTest() {
		String tranch = "{\"loanAmount\":100000,\"netDisburseAmount\":94751,\"amountDisbursedTillNow\":5249,\"loanAccountNumber\":\"8989888999\",\"applicationId\":1100000000009782,\"applicationTranches\":[{\"tranchkey\":96,\"accountHolderName\":\"Test\",\"accountHolderType\":3,\"accountNumber\":100000111,\"accountTypeKey\":22,\"disbursementDate\":\"2020/07/04\",\"disbursementMode\":\"IMPS\",\"trancheAmount\":7000,\"trancheStatus\":\"Disbursement Initiated\",\"tranchenum\":null,\"trancheDate\":\"2020/07/04\",\"beneficiaryTypeKey\":3,\"ifsccode\":\"HDFC0000007\",\"applicationBankDetKey\":570}],\"zeroAmtDisbursement\":false}";
		
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("lmsGatewayUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(tranch, HttpStatus.OK));

		helper.executeLmsRequest("PNT_CUST","BFLSOL","","11",new HttpHeaders());
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = DisbursementServiceException.class)
	public void executeLMSTimeOutRequestforLoanTest() {
		String tranch = "{\"loanAmount\":100000,\"netDisburseAmount\":94751,\"amountDisbursedTillNow\":5249,\"loanAccountNumber\":\"8989888999\",\"applicationId\":1100000000009782,\"applicationTranches\":[{\"tranchkey\":96,\"accountHolderName\":\"Test\",\"accountHolderType\":3,\"accountNumber\":100000111,\"accountTypeKey\":22,\"disbursementDate\":\"2020/07/04\",\"disbursementMode\":\"IMPS\",\"trancheAmount\":7000,\"trancheStatus\":\"Disbursement Initiated\",\"tranchenum\":null,\"trancheDate\":\"2020/07/04\",\"beneficiaryTypeKey\":3,\"ifsccode\":\"HDFC0000007\",\"applicationBankDetKey\":570}],\"zeroAmtDisbursement\":false}";
		
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("lmsGatewayUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(tranch, HttpStatus.OK));

		helper.executeLMSTimeOutRequestforLoan("PNT_CUST","BFLSOL","","11",new HttpHeaders());
	}
}
