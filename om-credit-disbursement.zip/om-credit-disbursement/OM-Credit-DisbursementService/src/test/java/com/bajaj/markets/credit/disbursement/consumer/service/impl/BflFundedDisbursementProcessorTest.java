package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;

@SpringBootTest
public class BflFundedDisbursementProcessorTest {

	@InjectMocks
	private BflFundedDisbursementProcessor bflFundedDisbProcessor;

	@Mock
	BFLLoggerUtil logger;

	@Mock
	DisbursementUtil disbursementUtil;

	@Mock
	LoanProcessor loanProcessor;

	@Mock
	CustomerProcessor customerProcessor;

	@Mock
	BflFundedErrorHandlingProcessor bflFundedErrorHandlingProcessor;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void processDisbursementTest() {
		FundedDisbursementEventRequestBean request = new FundedDisbursementEventRequestBean();
		request.setApplicationId("123");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		request.setHeaders(headers);
		bflFundedDisbProcessor.processDisbursement(request);
	}
}
