/**
 * 
 */
package com.bajaj.markets.credit.disbursement.consumer.controller;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.disbursement.consumer.bean.PrincipalFileUploadRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.LoanProcessor;

@SpringBootTest
public class DmsDocumentPushControllerTest {

	@InjectMocks
	DmsDocumentPushController dmsDocumentPushController;

	@Mock
	LoanProcessor loanProcessor;

	@Mock
	CustomDefaultHeaders customHeaders;
	@Mock
	private BFLLoggerUtil logger;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void initiateSuccessDisbEventTest() {
		HttpHeaders headers = new HttpHeaders();
		Mockito.when(loanProcessor.initiateSuccessDisbEventForDmsDocPush(Mockito.any())).thenReturn(true);
		PrincipalFileUploadRequestBean principalFileUploadRequestBean = new PrincipalFileUploadRequestBean();
		dmsDocumentPushController.initiateSuccessDisbEvent("1111", principalFileUploadRequestBean, headers);
		Assert.assertTrue(true);
	}
}