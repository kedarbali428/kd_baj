package com.bajaj.markets.credit.disbursement.consumer.service.impl;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.awaitility.core.ConditionTimeoutException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateMandateExternalResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.LoanProcessorVariables;
import com.bajaj.markets.credit.disbursement.consumer.bean.NotificationTemplateDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.Occupation;
import com.bajaj.markets.credit.disbursement.consumer.bean.PartnerProductMapMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.PennantMandateBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.PennantSystemDate;
import com.bajaj.markets.credit.disbursement.consumer.bean.PrincipalFileUploadRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.Reference;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.VasBean;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementMapperUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.LMSHelper;
import com.bajaj.markets.credit.disbursement.repository.MongoDBRepository;
import com.google.gson.Gson;


@SpringBootTest
public class LoanProcessorTest {
	
	@InjectMocks
	private LoanProcessor loanProcessor;
	
	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;
	
	@Mock
	DisbursementUtil disbursementUtil;
	
	@Mock
	DisbursementMapperUtil disbursementMapperUtil;
	
	@Mock
	MongoOperations disbursementMongoTemplate;
	
	@Mock
	MongoDBRepository mongoDbRepo;
	
	@Mock
	LMSHelper lmsHelper;
	
	@Mock
	VasProcessor vasProcessor;
	
	@Mock
	NotificationProcessor notificationProcessor;
	
	@Mock
	BFLLoggerUtil logger;
	
	private String tranchDetailsUrl="tranchDetailsUrl";
	
	private String bankDetailsUrl="bankDetailsUrl";

	private String branchDetailsUrl="branchDetailsUrl";
	
	private String addressDetailsUrl="addressDetailsUrl";
	
	private String getUserProfilesUrl="getUserProfilesUrl";
	
	private String pricingDetailsUrl="pricingDetailsUrl";
	
	private String pricingLatestDetailsUrl="pricingLatestDetailsUrl";
	
	private String mandateDetailsUrl="mandateDetailsUrl";
	
	private String repayDetailsUrl="repayDetailsUrl";
	
	private String repayEmandateUrl="repayEmandateUrl";
	
	private String breDueDateURL="breDueDateURL";
	
	private String subStageUrl="subStageUrl";
	
	private String statusUrl="statusUrl";
	
	private String updateApplicationForLAN="updateApplicationForLAN";
	
	private String subRepayModeDtl ="subRepayModeDtl";
	
	private String lmsUrl="lmsUrl";
	
	private String accountLoanURL="accountLoanURL";
	
	private String format = "T00:00:00";
	
	private String hybridflexiloantypes="DHPL";
	
	private String solloantypes="BFLSOL";
	
	private String bolloantypes="BFLBOL";
	
	private String epMandateRefNo="123";

	//private List<String> bflProductCodes;
	
	private String prolloantypes="BFLCAL";
	
	private NotificationTemplateDataBean notificationTemplateBean;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(loanProcessor, "tranchDetailsUrl", "tranchDetailsUrl");
		ReflectionTestUtils.setField(loanProcessor, "bankDetailsUrl", "bankDetailsUrl");
		ReflectionTestUtils.setField(loanProcessor, "branchDetailsUrl", "branchDetailsUrl");
		ReflectionTestUtils.setField(loanProcessor, "lmsUrl", "lmsUrl");
		ReflectionTestUtils.setField(loanProcessor, "pricingDetailsUrl", "pricingDetailsUrl");
		ReflectionTestUtils.setField(loanProcessor, "pricingLatestDetailsUrl", "pricingLatestDetailsUrl");
		ReflectionTestUtils.setField(loanProcessor, "getUserProfilesUrl", "getUserProfilesUrl");
		ReflectionTestUtils.setField(loanProcessor, "addressDetailsUrl", "addressDetailsUrl");
		ReflectionTestUtils.setField(loanProcessor, "hybridflexiloantypes", "hybridflexiloantypes");
		ReflectionTestUtils.setField(loanProcessor, "mandateDetailsUrl", "mandateDetailsUrl");
		ReflectionTestUtils.setField(loanProcessor, "subRepayModeDtl", "subRepayModeDtl");
		ReflectionTestUtils.setField(loanProcessor, "repayDetailsUrl", "repayDetailsUrl");
		ReflectionTestUtils.setField(loanProcessor, "repayEmandateUrl", "repayEmandateUrl");
		ReflectionTestUtils.setField(loanProcessor, "breDueDateURL", "breDueDateURL");
		ReflectionTestUtils.setField(loanProcessor, "subStageUrl", "subStageUrl");
		ReflectionTestUtils.setField(loanProcessor, "statusUrl", "statusUrl");
		ReflectionTestUtils.setField(loanProcessor, "updateApplicationForLAN", "updateApplicationForLAN");
		ReflectionTestUtils.setField(loanProcessor, "solloantypes", "BFLSOL");
		ReflectionTestUtils.setField(loanProcessor, "bolloantypes", "BFLBOL");
		ReflectionTestUtils.setField(loanProcessor, "prolloantypes", "BFLSOL");
		//bflProductCodes = new ArrayList<String>();
		//bflProductCodes.add("BFLSOL");
		//bflProductCodes.add("BFLBOL");
		//ReflectionTestUtils.setField(loanProcessor, "bflProductCodes", bflProductCodes);
	}
	
	@Test
	public void processLoanRequestTest() {
		GlobalDataBean data = new GlobalDataBean();
		data.setAppAtrKey("123");
		data.setApplicantKey("123");
		data.setApplicationKey("123");
		data.setL2ProductCode("BFLSOL");
		data.setL2ProductKey(123l);
		data.setL4ProductCode("BFL");
		data.setL3ProductCode("BFLSOL");
		data.setEmail("abc@gmail.com");
		data.setParentApplicationKey("345");
		data.setEmail("abc@gmail.com");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		data.setHeaders(headers);
		generateTrancheDetails();
		fetchBankDetails();
		fetchBranchDetails();
		PennantSystemDate callPennantForSystemDate= new PennantSystemDate();
		callPennantForSystemDate.setAppDate("12-12-2020");
		callPennantForSystemDate.setValueDate("12-12-2020");
		when(disbursementUtil.callPennantForSystemDate(Mockito.any(), Mockito.any())).thenReturn(callPennantForSystemDate);
		when(disbursementMapperUtil.mapBflBankRefCode(Mockito.any(), Mockito.any())).thenReturn("123");
		List<DisbursementMongoObject> disbursementMongoObjectList = new ArrayList<DisbursementMongoObject>();
		DisbursementMongoObject disbursementMongoObject = new DisbursementMongoObject();
		disbursementMongoObject.setCif("123");
		disbursementMongoObject.setBeneficiaryID("123");
		disbursementMongoObject.setApplicationKey(123L);
		disbursementMongoObjectList.add(disbursementMongoObject);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(disbursementMongoObjectList);
		when(disbursementMapperUtil.fetchDefaultBranch(Mockito.any(), Mockito.any())).thenReturn("123");
		fetchPricingDetails();
		fetchLatestDetails();
		fetchUserProfile();
		fetchAddressDetails();
		fetchMandateRegDetails();
		fetchPaymentMode();
		mapBre();
		List<VasBean> vas = new ArrayList<VasBean>();
		VasBean vasBean = new VasBean();
		vasBean.setFee("RS");
		vas.add(vasBean);
		updateApplicationForLAN();
		vasEvent();
		//when(disbursementMapperUtil.fetchbflbranchServicesMaster(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(1l);
		//when(disbursementMapperUtil.fetchBrchbyBranchKey(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn("123");
		ApplicationDetails applicationDetails = new ApplicationDetails();
		Occupation occupation = new Occupation();
		Reference ocupationType = new Reference();
		ocupationType.setKey(123l);
		occupation.setOcupationType(ocupationType);
		applicationDetails.setOccupation(occupation);
		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(applicationDetails);
		when(vasProcessor.getVasList(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(vas);
		String lmsRes="{\"finReference\":\"P402SOL0378659\",\"stp\":true,\"financeSchedule\":{\"financeDetail\":{\"applicationNo\":\"1100000000046351\",\"cif\":\"214138\",\"finType\":\"SOLTL\",\"finCcy\":\"INR\",\"finBranch\":\"320\",\"profitDaysBasis\":\"A/A_365L\",\"finAmount\":205235,\"finAssetValue\":205235,\"downPayBank\":0,\"downPaySupl\":0,\"finRepayMethod\":\"DDM\",\"finStartDate\":\"2021-03-15\",\"allowGrcPeriod\":false,\"tdsApplicable\":false,\"manualSchedule\":false,\"planDeferCount\":0,\"stepFinance\":false,\"alwManualSteps\":false,\"grcTerms\":0,\"grcPeriodEndDate\":\"2021-03-15\",\"grcRateBasis\":\"#\",\"grcPftRate\":0,\"grcMargin\":0,\"grcProfitDaysBasis\":\"A/A_365L\",\"nextGrcPftRvwDate\":\"2021-03-15\",\"nextGrcCpzDate\":\"2021-03-15\",\"allowGrcRepay\":false,\"grcSchdMthd\":\"EQUAL\",\"grcMinRate\":0,\"grcMaxRate\":0,\"grcAdvPftRate\":0,\"grcAdvMargin\":0,\"numberOfTerms\":36,\"reqRepayAmount\":0,\"repayRateBasis\":\"R\",\"repayPftRate\":14.25,\"repayMargin\":0,\"scheduleMethod\":\"EQUAL\",\"repayFrq\":\"M0002\",\"nextRepayDate\":\"2022-01-02\",\"repayPftFrq\":\"M0002\",\"nextRepayPftDate\":\"2022-01-02\",\"repayRvwFrq\":\"M0002\",\"nextRepayRvwDate\":\"2021-05-02\",\"nextRepayCpzDate\":\"2024-12-02\",\"maturityDate\":\"2024-12-02\",\"finRepayPftOnFrq\":true,\"repayMinRate\":0,\"repayMaxRate\":0,\"repayAdvPftRate\":0,\"repayAdvMargin\":0,\"supplementRent\":0,\"increasedCost\":0,\"finContractDate\":\"2021-03-15\",\"relationshipOfficer\":\"DEFAULT\",\"quickDisb\":false,\"unPlanEMIHLockPeriod\":0,\"unPlanEMICpz\":false,\"reAgeCpz\":false,\"maxUnplannedEmi\":0,\"maxReAgeHolidays\":0,\"alwBpiTreatment\":true,\"dftBpiTreatment\":\"E\",\"bpiPftDaysBasis\":\"A/A_365L\",\"planEMIHAlw\":false,\"planEMIHMethod\":\"\",\"planEMIHMaxPerYear\":0,\"planEMIHMax\":0,\"planEMIHLockPeriod\":0,\"planEMICpz\":false,\"alwFlexi\":false,\"topUpAmount\":0,\"finCategoryType\":\"NORMALFIN\",\"noOfAdvanceEMI\":0},\"fees\":[{\"feeCategory\":\"FC\",\"feeCode\":\"PROCFEE\",\"feeTypeDesc\":\"PROCESSING FEE\",\"feeAmount\":4617,\"waiverAmount\":0,\"paidAmount\":4617,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]},{\"feeCategory\":\"FC\",\"feeCode\":\"CONV\",\"feeTypeDesc\":\"CONVENIENCE FEES\",\"feeAmount\":4499,\"waiverAmount\":0,\"paidAmount\":4499,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]},{\"feeCategory\":\"FC\",\"feeCode\":\"STAMPFEE\",\"feeTypeDesc\":\"STAMP FEES\",\"feeAmount\":0,\"waiverAmount\":0,\"paidAmount\":0,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]},{\"feeCategory\":\"FC\",\"feeCode\":\"VAS2201800003\",\"feeAmount\":5235,\"waiverAmount\":0,\"paidAmount\":5235,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]}],\"feeDues\":[],\"insurance\":[],\"step\":[],\"schedules\":[{\"schDate\":\"2021-03-15\",\"pftAmount\":0,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-04-02\",\"pftAmount\":1442,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-05-02\",\"pftAmount\":2404,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-06-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-07-02\",\"pftAmount\":2404,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-08-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-09-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-10-02\",\"pftAmount\":2403,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-11-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-12-02\",\"pftAmount\":2404,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-01-02\",\"pftAmount\":2484,\"schdPft\":9133,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":9133,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-02-02\",\"pftAmount\":2484,\"schdPft\":7691,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-03-02\",\"pftAmount\":2243,\"schdPft\":7691,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-04-02\",\"pftAmount\":2484,\"schdPft\":6173,\"schdPftPaid\":0,\"schdPri\":1518,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":203717,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-05-02\",\"pftAmount\":2386,\"schdPft\":2386,\"schdPftPaid\":0,\"schdPri\":5305,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":198412,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-06-02\",\"pftAmount\":2402,\"schdPft\":2402,\"schdPftPaid\":0,\"schdPri\":5289,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":193123,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-07-02\",\"pftAmount\":2262,\"schdPft\":2262,\"schdPftPaid\":0,\"schdPri\":5429,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":187694,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-08-02\",\"pftAmount\":2271,\"schdPft\":2271,\"schdPftPaid\":0,\"schdPri\":5420,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":182274,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-09-02\",\"pftAmount\":2206,\"schdPft\":2206,\"schdPftPaid\":0,\"schdPri\":5485,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":176789,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-10-02\",\"pftAmount\":2071,\"schdPft\":2071,\"schdPftPaid\":0,\"schdPri\":5620,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":171169,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-11-02\",\"pftAmount\":2071,\"schdPft\":2071,\"schdPftPaid\":0,\"schdPri\":5620,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":165549,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-12-02\",\"pftAmount\":1939,\"schdPft\":1939,\"schdPftPaid\":0,\"schdPri\":5752,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":159797,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-01-02\",\"pftAmount\":1934,\"schdPft\":1934,\"schdPftPaid\":0,\"schdPri\":5757,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":154040,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-02-02\",\"pftAmount\":1865,\"schdPft\":1865,\"schdPftPaid\":0,\"schdPri\":5826,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":148214,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-03-02\",\"pftAmount\":1620,\"schdPft\":1620,\"schdPftPaid\":0,\"schdPri\":6071,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":142143,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-04-02\",\"pftAmount\":1720,\"schdPft\":1720,\"schdPftPaid\":0,\"schdPri\":5971,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":136172,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-05-02\",\"pftAmount\":1595,\"schdPft\":1595,\"schdPftPaid\":0,\"schdPri\":6096,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":130076,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-06-02\",\"pftAmount\":1574,\"schdPft\":1574,\"schdPftPaid\":0,\"schdPri\":6117,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":123959,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-07-02\",\"pftAmount\":1452,\"schdPft\":1452,\"schdPftPaid\":0,\"schdPri\":6239,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":117720,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-08-02\",\"pftAmount\":1425,\"schdPft\":1425,\"schdPftPaid\":0,\"schdPri\":6266,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":111454,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-09-02\",\"pftAmount\":1349,\"schdPft\":1349,\"schdPftPaid\":0,\"schdPri\":6342,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":105112,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-10-02\",\"pftAmount\":1231,\"schdPft\":1231,\"schdPftPaid\":0,\"schdPri\":6460,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":98652,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-11-02\",\"pftAmount\":1194,\"schdPft\":1194,\"schdPftPaid\":0,\"schdPri\":6497,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":92155,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-12-02\",\"pftAmount\":1079,\"schdPft\":1079,\"schdPftPaid\":0,\"schdPri\":6612,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":85543,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-01-02\",\"pftAmount\":1033,\"schdPft\":1033,\"schdPftPaid\":0,\"schdPri\":6658,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":78885,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-02-02\",\"pftAmount\":952,\"schdPft\":952,\"schdPftPaid\":0,\"schdPri\":6739,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":72146,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-03-02\",\"pftAmount\":814,\"schdPft\":814,\"schdPftPaid\":0,\"schdPri\":6877,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":65269,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-04-02\",\"pftAmount\":788,\"schdPft\":788,\"schdPftPaid\":0,\"schdPri\":6903,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":58366,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-05-02\",\"pftAmount\":682,\"schdPft\":682,\"schdPftPaid\":0,\"schdPri\":7009,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":51357,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-06-02\",\"pftAmount\":620,\"schdPft\":620,\"schdPftPaid\":0,\"schdPri\":7071,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":44286,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-07-02\",\"pftAmount\":517,\"schdPft\":517,\"schdPftPaid\":0,\"schdPri\":7174,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":37112,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-08-02\",\"pftAmount\":448,\"schdPft\":448,\"schdPftPaid\":0,\"schdPri\":7243,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":29869,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-09-02\",\"pftAmount\":360,\"schdPft\":360,\"schdPftPaid\":0,\"schdPri\":7331,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":22538,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-10-02\",\"pftAmount\":264,\"schdPft\":264,\"schdPftPaid\":0,\"schdPri\":7427,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":15111,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-11-02\",\"pftAmount\":182,\"schdPft\":182,\"schdPftPaid\":0,\"schdPri\":7509,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":7602,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-12-02\",\"pftAmount\":89,\"schdPft\":89,\"schdPftPaid\":0,\"schdPri\":7602,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":0,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0}],\"planEMIHmonths\":[],\"planEMIHDates\":[],\"overdueCharges\":[],\"summary\":{\"effectiveRateOfReturn\":18.819365459,\"totalGracePft\":0,\"totalGraceCpz\":0,\"totalGrossGrcPft\":0,\"totalCpz\":0,\"totalProfit\":73083,\"totalRepayAmt\":278318,\"feeChargeAmount\":14351,\"numberOfTerms\":36,\"loanTenor\":44,\"maturityDate\":\"2024-12-02\",\"firstDisbDate\":\"2021-03-15T00:00:00\",\"lastDisbDate\":\"2021-03-15T00:00:00\",\"firstEmiAmount\":9133,\"nextSchDate\":\"2022-02-02\",\"nextRepayAmount\":7691,\"futureInst\":35,\"futureTenor\":34,\"firstInstDate\":\"2022-01-02\",\"paidTotal\":0,\"paidPri\":0,\"paidPft\":0,\"lastRepayDate\":\"2022-01-02\",\"outstandingTotal\":278318,\"outstandingPri\":205235,\"outstandingPft\":73083,\"overdueTotal\":0,\"overduePri\":0,\"overduePft\":0,\"overdueInst\":0,\"overdueCharges\":[],\"advPaymentAmount\":0,\"finActiveStatus\":\"A\",\"fullyDisb\":true,\"limitDrop\":0,\"currentDroplineLimit\":0,\"utilisation\":0,\"availableLimit\":0,\"graceInst\":0,\"graceTenor\":0,\"futureGraceInst\":0,\"finReference\":\"P402SOL0378659\",\"finType\":\"SOLTL\",\"finStartDate\":\"2021-03-15\",\"futureGraceTenor\":0,\"advEmi\":[{\"instNo\":2,\"instAmount\":7691},{\"instNo\":3,\"instAmount\":7691},{\"instNo\":4,\"instAmount\":7691},{\"instNo\":5,\"instAmount\":7691},{\"instNo\":6,\"instAmount\":7691},{\"instNo\":7,\"instAmount\":7691},{\"instNo\":8,\"instAmount\":7691},{\"instNo\":9,\"instAmount\":7691},{\"instNo\":10,\"instAmount\":7691},{\"instNo\":11,\"instAmount\":7691},{\"instNo\":12,\"instAmount\":7691},{\"instNo\":13,\"instAmount\":7691},{\"instNo\":14,\"instAmount\":7691},{\"instNo\":15,\"instAmount\":7691},{\"instNo\":16,\"instAmount\":7691},{\"instNo\":17,\"instAmount\":7691},{\"instNo\":18,\"instAmount\":7691},{\"instNo\":19,\"instAmount\":7691},{\"instNo\":20,\"instAmount\":7691},{\"instNo\":21,\"instAmount\":7691},{\"instNo\":22,\"instAmount\":7691},{\"instNo\":23,\"instAmount\":7691},{\"instNo\":24,\"instAmount\":7691},{\"instNo\":25,\"instAmount\":7691},{\"instNo\":26,\"instAmount\":7691},{\"instNo\":27,\"instAmount\":7691},{\"instNo\":28,\"instAmount\":7691},{\"instNo\":29,\"instAmount\":7691},{\"instNo\":30,\"instAmount\":7691},{\"instNo\":31,\"instAmount\":7691},{\"instNo\":32,\"instAmount\":7691},{\"instNo\":33,\"instAmount\":7691},{\"instNo\":34,\"instAmount\":7691},{\"instNo\":35,\"instAmount\":7691},{\"instNo\":36,\"instAmount\":7691}],\"odInstalments\":0,\"odPenalty\":0,\"entityCode\":\"1\",\"finAmount\":205235,\"alwFlexi\":false,\"bounceCharges\":0,\"repayAmount\":7691,\"pftOnTerm\":15626,\"totalDues\":0,\"totalRefunds\":0,\"netReceivable\":0,\"pendingInsts\":7691,\"nextInstNumber\":2,\"noOfUnpaidInst\":35,\"branchId\":\"320\",\"noPaidInst\":0,\"futurePri\":0,\"otherRefunds\":0,\"refund\":0,\"npaStageId\":\"S\",\"overDueTds\":0,\"futureTds\":0,\"isInActionProcess\":false,\"roi\":0,\"feeAmount\":0,\"custPosAmtRecLmt\":0,\"amcDue\":0,\"lppDue\":0,\"lpiDue\":0,\"otherDue\":0},\"vas\":[],\"outstandingPri\":205235,\"intervalFee\":[],\"isUpfrontAuto\":true},\"collaterals\":[],\"transactions\":[],\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"},\"receiptId\":0,\"disbSeqId\":0}";
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsRes);
		doNothing().when(notificationProcessor).sendNotifications(Mockito.any(),Mockito.any());
		loanProcessor.processLoanRequest(data);
		
	}
	
	
	@Test(expected = DisbursementServiceException.class)
	public void processLoanRequestTest1() {
		GlobalDataBean data = new GlobalDataBean();
		data.setAppAtrKey("123");
		data.setApplicantKey("123");
		data.setApplicationKey("123");
		data.setL2ProductCode("BFLSOL");
		data.setL2ProductKey(123l);
		data.setL4ProductCode("BFL");
		data.setL3ProductCode("BFLSOL");
		data.setParentApplicationKey("345");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		data.setHeaders(headers);
		generateTrancheDetails();
		fetchBankDetails();
		fetchBranchDetails();
		PennantSystemDate callPennantForSystemDate= new PennantSystemDate();
		callPennantForSystemDate.setAppDate("12-12-2020");
		callPennantForSystemDate.setValueDate("12-12-2020");
		when(disbursementUtil.callPennantForSystemDate(Mockito.any(), Mockito.any())).thenReturn(callPennantForSystemDate);
		when(disbursementMapperUtil.mapBflBankRefCode(Mockito.any(), Mockito.any())).thenReturn("123");
		List<DisbursementMongoObject> disbursementMongoObjectList = new ArrayList<DisbursementMongoObject>();
		DisbursementMongoObject disbursementMongoObject = new DisbursementMongoObject();
		disbursementMongoObject.setCif("123");
		disbursementMongoObject.setBeneficiaryID("123");
		disbursementMongoObject.setApplicationKey(123L);
		disbursementMongoObjectList.add(disbursementMongoObject);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(disbursementMongoObjectList);
		when(disbursementMapperUtil.fetchDefaultBranch(Mockito.any(), Mockito.any())).thenReturn("123");
		fetchPricingDetails();
		fetchLatestDetails();
		fetchUserProfile();
		fetchAddressDetails();
		fetchMandateRegDetails();
		fetchPaymentMode();
		mapBre();
		List<VasBean> vas = new ArrayList<VasBean>();
		VasBean vasBean = new VasBean();
		vasBean.setFee("RS");
		vas.add(vasBean);
		RetryRegistrationBean existingRecords= null;
		 List<TranchBean> trnchLst =new ArrayList<TranchBean>();
		 TranchBean bean = new TranchBean();
		 bean.setTranchkey(123l);
		 trnchLst.add(bean);
				 when(disbursementUtil.fetchTranchDetails(Mockito.any(), Mockito.any())).thenReturn(trnchLst);
		when(disbursementUtil.fetchExistingTransaction(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(existingRecords);
		//when(disbursementMapperUtil.fetchbflbranchServicesMaster(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(1l);
		//when(disbursementMapperUtil.fetchBrchbyBranchKey(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn("123");
		ApplicationDetails applicationDetails = new ApplicationDetails();
		Occupation occupation = new Occupation();
		Reference ocupationType = new Reference();
		ocupationType.setKey(123l);
		occupation.setOcupationType(ocupationType);
		applicationDetails.setOccupation(occupation);
		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(applicationDetails);
		when(vasProcessor.getVasList(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(vas);
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenThrow(ConditionTimeoutException.class);
		doNothing().when(notificationProcessor).sendNotifications(Mockito.any(),Mockito.any());
		String lmsRes="{\"finReference\":\"1100000000006221\",\"firstEmiAmount\":34794}";
		when(lmsHelper.executeLMSTimeOutRequestforLoan(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsRes);
		updateApplicationForLAN();
		vasEvent();
		loanProcessor.processLoanRequest(data);
		
	}
	
	@Test
	public void getRepayBankDetailsTest() {
		fetchRepayDetails();
		GlobalDataBean data = new GlobalDataBean();
		data.setAppAtrKey("123");
		data.setApplicantKey("123");
		data.setApplicationKey("123");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		HttpHeaders headerss = new HttpHeaders();
		
		assertNotNull(loanProcessor.getRepayBankDetails("123",headerss,new LoanProcessorVariables()));
	}
	
	@Test
	public void getRepayEmandateDetailsTest() {
		fetchEmandateDetails();
		GlobalDataBean data = new GlobalDataBean();
		data.setAppAtrKey("123");
		data.setApplicantKey("123");
		data.setApplicationKey("123");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		HttpHeaders headerss = new HttpHeaders();
		
		assertNotNull(loanProcessor.getRepayEmandateDetails("123",headerss));
	}
	
	@Test
	public void getRepayEmandateDetailsTest1() {
		fetchEmandateDetails();
		GlobalDataBean data = new GlobalDataBean();
		data.setAppAtrKey("123");
		data.setApplicantKey("123");
		data.setApplicationKey("123");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		HttpHeaders headerss = new HttpHeaders();
		
		loanProcessor.getRepayEmandateDetails("123",headerss);
	}
	
	@Test
	public void getMandateIdFromListTest() {
		CreateMandateExternalResponse extResponse = new CreateMandateExternalResponse();
		
		List<PennantMandateBean> mandates = new ArrayList();
		PennantMandateBean pennantMandateBean = new PennantMandateBean();
		pennantMandateBean.setBarCodeNumber("12");
		pennantMandateBean.setMandateID(BigDecimal.ONE);
		extResponse.setMandates(mandates);
		mandates.add(pennantMandateBean);
		loanProcessor.getMandateIdFromList(extResponse,getProcessorVariables());
	}
	
	private LoanProcessorVariables getProcessorVariables() {
		LoanProcessorVariables processorVariables=new LoanProcessorVariables();
		processorVariables.setBarCode("12");
		processorVariables.setBarCodeMatched(true);
		processorVariables.setChanelMandateRefId("12");
		processorVariables.setSOLLoan(true);
		processorVariables.setEmandateFlg(false);
		processorVariables.setEpMandateRefNo("123");
		return processorVariables;
	}

	@Test(expected=DisbursementServiceException.class)
	public void setMandateIdFromPennantTest() {
		HttpHeaders headers=new HttpHeaders();
		loanProcessor.setMandateIdFromPennant("123","123","SOL",headers,getProcessorVariables());
	}
	@Test
	public void setMandateIdFromPennantTest1() {
		HttpHeaders headers=new HttpHeaders();
		List<DisbursementMongoObject> disbursementMongoObjectList = new ArrayList<DisbursementMongoObject>();
		DisbursementMongoObject disbursementMongoObject = new DisbursementMongoObject();
		disbursementMongoObject.setCif("123");
		disbursementMongoObject.setBeneficiaryID("123");
		disbursementMongoObject.setApplicationKey(123L);
		disbursementMongoObjectList.add(disbursementMongoObject);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(disbursementMongoObjectList);
		String lmsRes="{\"finReference\":\"1100000000006221\",\"returnStatus\":{\"returnCode\":\"00000\",\"returnText\":\"Success\"}}";
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsRes);
		
		loanProcessor.setMandateIdFromPennant("123","123","SOL",headers,getProcessorVariables());
	}
	
	@Test
	public void getMandateIdFromListForUMRNtest() {
		CreateMandateExternalResponse extResponse = new CreateMandateExternalResponse();
		
		List<PennantMandateBean> mandates = new ArrayList();
		PennantMandateBean pennantMandateBean = new PennantMandateBean();
		pennantMandateBean.setBarCodeNumber("123");
		mandates.add(pennantMandateBean);
		loanProcessor.getMandateIdFromListForUMRN(extResponse,getProcessorVariables());
	}
	
	@Test
	public void processLmsResponseTest() {
		String lmsRes="{\"finReference\":\"1100000000006221\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}";
		loanProcessor.processLmsResponse(lmsRes,getProcessorVariables());
	}
	@Test
	public void processLmsResponseTest1() {
		
		String lmsRes="{\"finReference\":\"1100000000006221\",\"returnStatus\":{\"returnCode\":\"90304\",\"returnText\":\"Success\"}}";
		LoanProcessorVariables variables=getProcessorVariables();
		variables.setPhysicalMandateFlg(true);
		variables.setSOLLoan(false);
		variables.setBOLLoan(true);
		loanProcessor.processLmsResponse(lmsRes,variables);
	}
	@Test
	public void updateApplicationStageDetailsTest() {
		HttpHeaders headerss = new HttpHeaders();
		generatesubStageUrl();
		loanProcessor.updateApplicationStageDetails("123",headerss);
	}
	
	@Test
	public void updateApplicationStatusDetailsTest() {
		HttpHeaders headerss = new HttpHeaders();
		generatestatuseUrl();
		loanProcessor.updateApplicationStatusDetails("123",headerss);
	}
	public void  vasEvent(){
		 when(vasProcessor.vasDisbursementInitEventRaiseExt(Mockito.any(),Mockito.any())).thenReturn("Success");	

		 
	 }
	@SuppressWarnings("unchecked")
	public void updateApplicationForLAN() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(updateApplicationForLAN), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"applicationId\":\"120371\",\"applicationTranches\":[{\"trancheKey\":\"105\",\"trancheAmount\":\"123\",\"applicationBankDetKey\":\"123\",\"beneficiaryType\":\"1\"}]}", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void generatesubStageUrl() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(subStageUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"applicationId\":\"120371\",\"applicationTranches\":[{\"trancheKey\":\"105\",\"trancheAmount\":\"123\",\"applicationBankDetKey\":\"123\",\"beneficiaryType\":\"1\"}]}", HttpStatus.OK));	

		}
	@SuppressWarnings("unchecked")
	public void generatestatuseUrl() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(statusUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"statusKey\":\"120371\",\"statusValue\":\"Disbursed\"}}", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void generateTrancheDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(tranchDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"applicationId\":\"120371\",\"applicationTranches\":[{\"trancheKey\":\"105\",\"trancheAmount\":\"123\",\"applicationBankDetKey\":\"123\",\"beneficiaryType\":\"1\"}]}", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void fetchBankDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(bankDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"bankDetailsKey\":123,\"accoutNumber\":\"1100000000006217\",\"branchKey\":\"123\",\"userAttributeKey\":\"123\"}", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void mapBre() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(breDueDateURL), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"arcduedateOutput\":{\"dueDateDetails\":[{\"dueDate\":2,\"firstDueDate\":\"2020-12-02\"}],\"nextDueDateDetails\":[{\"graceTerm\":2,\"nextDueDate\":\"2020-12-02\"}]},\"Action\":true}", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void fetchBranchDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(branchDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(" [{ \"branchKey\":6, \"bankMasterKey\": 1, \"branchCode\": \"6\" ,\"branchIfscCode\": \"6\",\"branchMicrCode\": \"6\",\"branchName\": \"abc\",\"cityKey\":6,\"pincodeKey\": 6}]", HttpStatus.OK));	

		}
	
	
	@SuppressWarnings("unchecked")
	public void fetchAddressDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(addressDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"addressKey\":\"1100000000006221\",\"addressTypeKey\":\"1100000000006217\",\"addressLine1\":\"OMPL\",\"addressLine2\":\"BFLSOL\",\"pincode\":\"123\",\"pincodeKey\":\"123\",\"cityKey\":\"123\",\"stateKey\":\"123\"}", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void fetchUserProfile() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getUserProfilesUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]", HttpStatus.OK));	

		}
	
	
	@SuppressWarnings("unchecked")
	public void fetchPricingDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(pricingDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(" [{ \"applicationKey\":\"123\",\"appLoanPricingKey\":\"123\", \"loanAmount\":123,\"prodCategoryCode\":\"1\",\"isTenure\":12,\"finalRoi\":12,\"pennantLoanType\":DHPL,\"nextDueDate\":\"2020-10-31T00:00:00\",\"firstDueDate\":\"2020-10-31\",\"droplineTenure\":12,\"fees\":[{\"feesKey\":105,\"appLoanPricingKey\":123,\"feesInPercent\":123,\"feesInAmount\":123,\"feeCode\":12}],\"baseRateCode\": \"4323426\",\"finalLoanAmount\":12 ,\"droplineTenure\":1,\"droplineEmi\":1,\"dueDay\":1}]", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void fetchLatestDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(pricingLatestDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(" { \"applicationKey\":\"123\", \"bundleApplicationKey\":123, \"appLoanPricingKey\":123,\"loanAmount\":123}", HttpStatus.OK));	

		}
	
	
	
	@SuppressWarnings("unchecked")
	public void fetchMandateRegDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(mandateDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"emandateRegKey\":123,\"applicationKey\":123,\"applicantKey\":123,\"mandatExpiryDate\":2020-12-02,\"accountNumber\":1234,\"modeofpayment\":\"Test\"}", HttpStatus.OK));	

		}
	 
	@SuppressWarnings("unchecked")
	public void fetchPaymentMode() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(subRepayModeDtl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("[{\"emandatepaymentmodekey\":123,\"emandatepartner\":\"Test\",\"emandatemode\":\"Test\",\"emandatesubrepaymode\":\"Test\"}]", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void fetchRepayDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(repayDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("[{\"bankDetailsKey\":123,\"bankAccountCatagory\":\"Repayment\",\"paymentMode\":\"1\"}]", HttpStatus.OK));	

		}
	
		
	@SuppressWarnings("unchecked")
	public void fetchEmandateDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(repayEmandateUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"mandateReference\":\"123\",\"mandateBitlyUrl\":\"1\"}", HttpStatus.OK));	

		}
	
	
	
	
	@Test
	public void processLoanRequestBOLTest() {
		GlobalDataBean data = new GlobalDataBean();
		data.setAppAtrKey("123");
		data.setApplicantKey("123");
		data.setApplicationKey("123");
		data.setL2ProductCode("BFLBOL");
		data.setL2ProductKey(123l);
		data.setL4ProductCode("BFL");
		data.setL3ProductCode("BFLBOL");
		data.setParentApplicationKey("345");
		data.setEmail("abc@gmail.com");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		data.setHeaders(headers);
		data.setEmail("abc@gmail.com");
		generateTrancheDetails();
		fetchBankDetails();
		fetchBranchDetails();
		PennantSystemDate callPennantForSystemDate= new PennantSystemDate();
		callPennantForSystemDate.setAppDate("12-12-2020");
		callPennantForSystemDate.setValueDate("12-12-2020");
		when(disbursementUtil.callPennantForSystemDate(Mockito.any(), Mockito.any())).thenReturn(callPennantForSystemDate);
		when(disbursementMapperUtil.mapBflBankRefCode(Mockito.any(), Mockito.any())).thenReturn("123");
		List<DisbursementMongoObject> disbursementMongoObjectList = new ArrayList<DisbursementMongoObject>();
		DisbursementMongoObject disbursementMongoObject = new DisbursementMongoObject();
		disbursementMongoObject.setCif("123");
		disbursementMongoObject.setBeneficiaryID("123");
		disbursementMongoObject.setApplicationKey(123L);
		disbursementMongoObjectList.add(disbursementMongoObject);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(disbursementMongoObjectList);
		when(disbursementMapperUtil.fetchDefaultBranch(Mockito.any(), Mockito.any())).thenReturn("123");
		fetchPricingDetails();
		fetchLatestDetails();
		fetchUserProfile();
		fetchAddressDetails();
		mapBre();
		fetchMandateRegDetails();
		fetchPaymentMode();
		List<VasBean> vas = new ArrayList<VasBean>();
		VasBean vasBean = new VasBean();
		vasBean.setFee("RS");
		vas.add(vasBean);
		when(vasProcessor.getVasList(Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(vas);
		String lmsRes="{\"finReference\":\"1100000000006221\",\"returnStatus\":{\"returnCode\":\"00000\",\"returnText\":\"Success\"}}";
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsRes);
		
		ApplicationDetails applicationDetailsBOL = DataPopulator.fetchApplicationDetailsBOL();
		when(disbursementUtil.fetchApplicationDetails(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(applicationDetailsBOL);
		when(disbursementUtil.fetchCustomerDisbDetails(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(DataPopulator.fetchCustomerDisbDetails());
		
		when(disbursementUtil.fetchPincodeDetails(Mockito.any(),Mockito.any())).thenReturn("411027");
		when(disbursementUtil.fetchLocalityDetails(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("Pune");
		doNothing().when(notificationProcessor).sendNotifications(Mockito.any(),Mockito.any());
		loanProcessor.processLoanRequest(data);
		
	}
	@SuppressWarnings("unchecked")
	@Test
	public void fetchPricingDetailsTest() {
		HttpHeaders headerss = new HttpHeaders();
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(pricingDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("[{\"appLoanPricingKey\":\"123\",\"applicationKey\":\"1\"}]", HttpStatus.OK));	
		loanProcessor.fetchPricingDetails("123",headerss);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchLatestPricingDetailsTest() {
		HttpHeaders headerss = new HttpHeaders();
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(pricingLatestDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"l2ProductCategoryCode\":\"123\",\"l3ProductCode\":\"1\"}", HttpStatus.OK));	
		loanProcessor.fetchLatestPricingDetails("123",headerss);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchDisbursementDetailsTest() {
		HttpHeaders headerss = new HttpHeaders();
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(accountLoanURL), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("{\"mobileNumber\":\"123\",\"eventType\":\"1\"}", HttpStatus.OK));	
		loanProcessor.fetchDisbursementDetails("123","123",headerss);
	}

	@Test
	public void processLoanRequestTest2() {
		GlobalDataBean data = new GlobalDataBean();
		data.setAppAtrKey("123");
		data.setApplicantKey("123");
		data.setApplicationKey("123");
		data.setL2ProductCode("BFLSOL");
		data.setL2ProductKey(123l);
		data.setL4ProductCode("BFL");
		data.setL3ProductCode("BFLSOL");
		data.setParentApplicationKey("345");
		data.setEmail("abc@gmail.com");
		data.setErrFlg(true);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		data.setHeaders(headers);
		generateTrancheDetails();
		fetchBankDetails();
		fetchBranchDetails();
		PennantSystemDate callPennantForSystemDate= new PennantSystemDate();
		callPennantForSystemDate.setAppDate("12-12-2020");
		callPennantForSystemDate.setValueDate("12-12-2020");
		when(disbursementUtil.callPennantForSystemDate(Mockito.any(), Mockito.any())).thenReturn(callPennantForSystemDate);
		when(disbursementMapperUtil.mapBflBankRefCode(Mockito.any(), Mockito.any())).thenReturn("123");
		List<DisbursementMongoObject> disbursementMongoObjectList = new ArrayList<DisbursementMongoObject>();
		DisbursementMongoObject disbursementMongoObject = new DisbursementMongoObject();
		disbursementMongoObject.setCif("123");
		disbursementMongoObject.setBeneficiaryID("123");
		disbursementMongoObject.setApplicationKey(123L);
		disbursementMongoObjectList.add(disbursementMongoObject);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(disbursementMongoObjectList);
		when(disbursementMapperUtil.fetchDefaultBranch(Mockito.any(), Mockito.any())).thenReturn("123");
		fetchPricingDetails();
		fetchLatestDetails();
		fetchUserProfile();
		fetchAddressDetails();
		fetchMandateRegDetails();
		fetchPaymentMode();
		mapBre();
		List<VasBean> vas = new ArrayList<VasBean>();
		VasBean vasBean = new VasBean();
		vasBean.setFee("RS");
		vas.add(vasBean);
		updateApplicationForLAN();
		vasEvent();
		//when(disbursementMapperUtil.fetchbflbranchServicesMaster(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(1l);
		//when(disbursementMapperUtil.fetchBrchbyBranchKey(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn("123");
		ApplicationDetails applicationDetails = new ApplicationDetails();
		Occupation occupation = new Occupation();
		Reference ocupationType = new Reference();
		ocupationType.setKey(123l);
		occupation.setOcupationType(ocupationType);
		applicationDetails.setOccupation(occupation);
		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(applicationDetails);
		when(vasProcessor.getVasList(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(vas);
		String lmsRes="{\"finReference\":\"P402SOL0378659\",\"stp\":true,\"financeSchedule\":{\"financeDetail\":{\"applicationNo\":\"1100000000046351\",\"cif\":\"214138\",\"finType\":\"SOLTL\",\"finCcy\":\"INR\",\"finBranch\":\"320\",\"profitDaysBasis\":\"A/A_365L\",\"finAmount\":205235,\"finAssetValue\":205235,\"downPayBank\":0,\"downPaySupl\":0,\"finRepayMethod\":\"DDM\",\"finStartDate\":\"2021-03-15\",\"allowGrcPeriod\":false,\"tdsApplicable\":false,\"manualSchedule\":false,\"planDeferCount\":0,\"stepFinance\":false,\"alwManualSteps\":false,\"grcTerms\":0,\"grcPeriodEndDate\":\"2021-03-15\",\"grcRateBasis\":\"#\",\"grcPftRate\":0,\"grcMargin\":0,\"grcProfitDaysBasis\":\"A/A_365L\",\"nextGrcPftRvwDate\":\"2021-03-15\",\"nextGrcCpzDate\":\"2021-03-15\",\"allowGrcRepay\":false,\"grcSchdMthd\":\"EQUAL\",\"grcMinRate\":0,\"grcMaxRate\":0,\"grcAdvPftRate\":0,\"grcAdvMargin\":0,\"numberOfTerms\":36,\"reqRepayAmount\":0,\"repayRateBasis\":\"R\",\"repayPftRate\":14.25,\"repayMargin\":0,\"scheduleMethod\":\"EQUAL\",\"repayFrq\":\"M0002\",\"nextRepayDate\":\"2022-01-02\",\"repayPftFrq\":\"M0002\",\"nextRepayPftDate\":\"2022-01-02\",\"repayRvwFrq\":\"M0002\",\"nextRepayRvwDate\":\"2021-05-02\",\"nextRepayCpzDate\":\"2024-12-02\",\"maturityDate\":\"2024-12-02\",\"finRepayPftOnFrq\":true,\"repayMinRate\":0,\"repayMaxRate\":0,\"repayAdvPftRate\":0,\"repayAdvMargin\":0,\"supplementRent\":0,\"increasedCost\":0,\"finContractDate\":\"2021-03-15\",\"relationshipOfficer\":\"DEFAULT\",\"quickDisb\":false,\"unPlanEMIHLockPeriod\":0,\"unPlanEMICpz\":false,\"reAgeCpz\":false,\"maxUnplannedEmi\":0,\"maxReAgeHolidays\":0,\"alwBpiTreatment\":true,\"dftBpiTreatment\":\"E\",\"bpiPftDaysBasis\":\"A/A_365L\",\"planEMIHAlw\":false,\"planEMIHMethod\":\"\",\"planEMIHMaxPerYear\":0,\"planEMIHMax\":0,\"planEMIHLockPeriod\":0,\"planEMICpz\":false,\"alwFlexi\":false,\"topUpAmount\":0,\"finCategoryType\":\"NORMALFIN\",\"noOfAdvanceEMI\":0},\"fees\":[{\"feeCategory\":\"FC\",\"feeCode\":\"PROCFEE\",\"feeTypeDesc\":\"PROCESSING FEE\",\"feeAmount\":4617,\"waiverAmount\":0,\"paidAmount\":4617,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]},{\"feeCategory\":\"FC\",\"feeCode\":\"CONV\",\"feeTypeDesc\":\"CONVENIENCE FEES\",\"feeAmount\":4499,\"waiverAmount\":0,\"paidAmount\":4499,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]},{\"feeCategory\":\"FC\",\"feeCode\":\"STAMPFEE\",\"feeTypeDesc\":\"STAMP FEES\",\"feeAmount\":0,\"waiverAmount\":0,\"paidAmount\":0,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]},{\"feeCategory\":\"FC\",\"feeCode\":\"VAS2201800003\",\"feeAmount\":5235,\"waiverAmount\":0,\"paidAmount\":5235,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]}],\"feeDues\":[],\"insurance\":[],\"step\":[],\"schedules\":[{\"schDate\":\"2021-03-15\",\"pftAmount\":0,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-04-02\",\"pftAmount\":1442,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-05-02\",\"pftAmount\":2404,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-06-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-07-02\",\"pftAmount\":2404,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-08-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-09-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-10-02\",\"pftAmount\":2403,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-11-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-12-02\",\"pftAmount\":2404,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-01-02\",\"pftAmount\":2484,\"schdPft\":9133,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":9133,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-02-02\",\"pftAmount\":2484,\"schdPft\":7691,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-03-02\",\"pftAmount\":2243,\"schdPft\":7691,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-04-02\",\"pftAmount\":2484,\"schdPft\":6173,\"schdPftPaid\":0,\"schdPri\":1518,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":203717,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-05-02\",\"pftAmount\":2386,\"schdPft\":2386,\"schdPftPaid\":0,\"schdPri\":5305,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":198412,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-06-02\",\"pftAmount\":2402,\"schdPft\":2402,\"schdPftPaid\":0,\"schdPri\":5289,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":193123,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-07-02\",\"pftAmount\":2262,\"schdPft\":2262,\"schdPftPaid\":0,\"schdPri\":5429,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":187694,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-08-02\",\"pftAmount\":2271,\"schdPft\":2271,\"schdPftPaid\":0,\"schdPri\":5420,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":182274,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-09-02\",\"pftAmount\":2206,\"schdPft\":2206,\"schdPftPaid\":0,\"schdPri\":5485,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":176789,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-10-02\",\"pftAmount\":2071,\"schdPft\":2071,\"schdPftPaid\":0,\"schdPri\":5620,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":171169,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-11-02\",\"pftAmount\":2071,\"schdPft\":2071,\"schdPftPaid\":0,\"schdPri\":5620,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":165549,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-12-02\",\"pftAmount\":1939,\"schdPft\":1939,\"schdPftPaid\":0,\"schdPri\":5752,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":159797,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-01-02\",\"pftAmount\":1934,\"schdPft\":1934,\"schdPftPaid\":0,\"schdPri\":5757,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":154040,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-02-02\",\"pftAmount\":1865,\"schdPft\":1865,\"schdPftPaid\":0,\"schdPri\":5826,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":148214,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-03-02\",\"pftAmount\":1620,\"schdPft\":1620,\"schdPftPaid\":0,\"schdPri\":6071,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":142143,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-04-02\",\"pftAmount\":1720,\"schdPft\":1720,\"schdPftPaid\":0,\"schdPri\":5971,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":136172,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-05-02\",\"pftAmount\":1595,\"schdPft\":1595,\"schdPftPaid\":0,\"schdPri\":6096,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":130076,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-06-02\",\"pftAmount\":1574,\"schdPft\":1574,\"schdPftPaid\":0,\"schdPri\":6117,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":123959,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-07-02\",\"pftAmount\":1452,\"schdPft\":1452,\"schdPftPaid\":0,\"schdPri\":6239,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":117720,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-08-02\",\"pftAmount\":1425,\"schdPft\":1425,\"schdPftPaid\":0,\"schdPri\":6266,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":111454,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-09-02\",\"pftAmount\":1349,\"schdPft\":1349,\"schdPftPaid\":0,\"schdPri\":6342,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":105112,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-10-02\",\"pftAmount\":1231,\"schdPft\":1231,\"schdPftPaid\":0,\"schdPri\":6460,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":98652,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-11-02\",\"pftAmount\":1194,\"schdPft\":1194,\"schdPftPaid\":0,\"schdPri\":6497,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":92155,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-12-02\",\"pftAmount\":1079,\"schdPft\":1079,\"schdPftPaid\":0,\"schdPri\":6612,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":85543,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-01-02\",\"pftAmount\":1033,\"schdPft\":1033,\"schdPftPaid\":0,\"schdPri\":6658,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":78885,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-02-02\",\"pftAmount\":952,\"schdPft\":952,\"schdPftPaid\":0,\"schdPri\":6739,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":72146,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-03-02\",\"pftAmount\":814,\"schdPft\":814,\"schdPftPaid\":0,\"schdPri\":6877,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":65269,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-04-02\",\"pftAmount\":788,\"schdPft\":788,\"schdPftPaid\":0,\"schdPri\":6903,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":58366,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-05-02\",\"pftAmount\":682,\"schdPft\":682,\"schdPftPaid\":0,\"schdPri\":7009,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":51357,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-06-02\",\"pftAmount\":620,\"schdPft\":620,\"schdPftPaid\":0,\"schdPri\":7071,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":44286,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-07-02\",\"pftAmount\":517,\"schdPft\":517,\"schdPftPaid\":0,\"schdPri\":7174,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":37112,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-08-02\",\"pftAmount\":448,\"schdPft\":448,\"schdPftPaid\":0,\"schdPri\":7243,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":29869,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-09-02\",\"pftAmount\":360,\"schdPft\":360,\"schdPftPaid\":0,\"schdPri\":7331,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":22538,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-10-02\",\"pftAmount\":264,\"schdPft\":264,\"schdPftPaid\":0,\"schdPri\":7427,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":15111,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-11-02\",\"pftAmount\":182,\"schdPft\":182,\"schdPftPaid\":0,\"schdPri\":7509,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":7602,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-12-02\",\"pftAmount\":89,\"schdPft\":89,\"schdPftPaid\":0,\"schdPri\":7602,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":0,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0}],\"planEMIHmonths\":[],\"planEMIHDates\":[],\"overdueCharges\":[],\"summary\":{\"effectiveRateOfReturn\":18.819365459,\"totalGracePft\":0,\"totalGraceCpz\":0,\"totalGrossGrcPft\":0,\"totalCpz\":0,\"totalProfit\":73083,\"totalRepayAmt\":278318,\"feeChargeAmount\":14351,\"numberOfTerms\":36,\"loanTenor\":44,\"maturityDate\":\"2024-12-02\",\"firstDisbDate\":\"2021-03-15T00:00:00\",\"lastDisbDate\":\"2021-03-15T00:00:00\",\"firstEmiAmount\":9133,\"nextSchDate\":\"2022-02-02\",\"nextRepayAmount\":7691,\"futureInst\":35,\"futureTenor\":34,\"firstInstDate\":\"2022-01-02\",\"paidTotal\":0,\"paidPri\":0,\"paidPft\":0,\"lastRepayDate\":\"2022-01-02\",\"outstandingTotal\":278318,\"outstandingPri\":205235,\"outstandingPft\":73083,\"overdueTotal\":0,\"overduePri\":0,\"overduePft\":0,\"overdueInst\":0,\"overdueCharges\":[],\"advPaymentAmount\":0,\"finActiveStatus\":\"A\",\"fullyDisb\":true,\"limitDrop\":0,\"currentDroplineLimit\":0,\"utilisation\":0,\"availableLimit\":0,\"graceInst\":0,\"graceTenor\":0,\"futureGraceInst\":0,\"finReference\":\"P402SOL0378659\",\"finType\":\"SOLTL\",\"finStartDate\":\"2021-03-15\",\"futureGraceTenor\":0,\"advEmi\":[{\"instNo\":2,\"instAmount\":7691},{\"instNo\":3,\"instAmount\":7691},{\"instNo\":4,\"instAmount\":7691},{\"instNo\":5,\"instAmount\":7691},{\"instNo\":6,\"instAmount\":7691},{\"instNo\":7,\"instAmount\":7691},{\"instNo\":8,\"instAmount\":7691},{\"instNo\":9,\"instAmount\":7691},{\"instNo\":10,\"instAmount\":7691},{\"instNo\":11,\"instAmount\":7691},{\"instNo\":12,\"instAmount\":7691},{\"instNo\":13,\"instAmount\":7691},{\"instNo\":14,\"instAmount\":7691},{\"instNo\":15,\"instAmount\":7691},{\"instNo\":16,\"instAmount\":7691},{\"instNo\":17,\"instAmount\":7691},{\"instNo\":18,\"instAmount\":7691},{\"instNo\":19,\"instAmount\":7691},{\"instNo\":20,\"instAmount\":7691},{\"instNo\":21,\"instAmount\":7691},{\"instNo\":22,\"instAmount\":7691},{\"instNo\":23,\"instAmount\":7691},{\"instNo\":24,\"instAmount\":7691},{\"instNo\":25,\"instAmount\":7691},{\"instNo\":26,\"instAmount\":7691},{\"instNo\":27,\"instAmount\":7691},{\"instNo\":28,\"instAmount\":7691},{\"instNo\":29,\"instAmount\":7691},{\"instNo\":30,\"instAmount\":7691},{\"instNo\":31,\"instAmount\":7691},{\"instNo\":32,\"instAmount\":7691},{\"instNo\":33,\"instAmount\":7691},{\"instNo\":34,\"instAmount\":7691},{\"instNo\":35,\"instAmount\":7691},{\"instNo\":36,\"instAmount\":7691}],\"odInstalments\":0,\"odPenalty\":0,\"entityCode\":\"1\",\"finAmount\":205235,\"alwFlexi\":false,\"bounceCharges\":0,\"repayAmount\":7691,\"pftOnTerm\":15626,\"totalDues\":0,\"totalRefunds\":0,\"netReceivable\":0,\"pendingInsts\":7691,\"nextInstNumber\":2,\"noOfUnpaidInst\":35,\"branchId\":\"320\",\"noPaidInst\":0,\"futurePri\":0,\"otherRefunds\":0,\"refund\":0,\"npaStageId\":\"S\",\"overDueTds\":0,\"futureTds\":0,\"isInActionProcess\":false,\"roi\":0,\"feeAmount\":0,\"custPosAmtRecLmt\":0,\"amcDue\":0,\"lppDue\":0,\"lpiDue\":0,\"otherDue\":0},\"vas\":[],\"outstandingPri\":205235,\"intervalFee\":[],\"isUpfrontAuto\":true},\"collaterals\":[],\"transactions\":[],\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"},\"receiptId\":0,\"disbSeqId\":0}";
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsRes);
		String lmsTimedoutRes="{\"finances\":[{\"finReference\":\"P404DSE0376828\",\"finType\":\"DSEPLCSH\",\"product\":\"DPLCS\",\"division\":\"BFSD\",\"finCcy\":\"INR\",\"finAmount\":500000,\"finAssetValue\":500000,\"finStartDate\":\"2021-12-07T00:00:00\",\"applicationNo\":\"123\",\"numberOfTerms\":36,\"loanTenor\":36,\"maturityDate\":\"2024-12-02T00:00:00\",\"firstEmiAmount\":17394,\"nextRepayAmount\":14605,\"paidTotal\":127505,\"paidPri\":110000,\"paidPft\":17505,\"outstandingTotal\":481962,\"outstandingPri\":390000,\"outstandingPft\":91962,\"futureInst\":33,\"finStatus\":\"A\",\"disbStatus\":\"Fully Disbursed\",\"coApplicants\":[]}],\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}";
		when(lmsHelper.executeLMSTimeOutRequestforLoan(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsTimedoutRes);
		doNothing().when(notificationProcessor).sendNotifications(Mockito.any(),Mockito.any());
		RetryRegistrationBean retryBean=new RetryRegistrationBean();
		retryBean.setCurrentRetryCount(1L);
		when(disbursementUtil.fetchExistingTransaction(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(retryBean);
		when(disbursementUtil.saveretrytransaction(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(retryBean);
		List<TranchBean> trnchLst = new ArrayList<TranchBean>();
		TranchBean bean = new TranchBean();
		bean.setTranchkey(123l);
		trnchLst.add(bean);
		when(disbursementUtil.fetchTranchDetails(Mockito.any(), Mockito.any())).thenReturn(trnchLst);
		loanProcessor.processLoanRequest(data);
		
	}
	
	@Test
	public void processLoanRequestTest3() {
		GlobalDataBean data = new GlobalDataBean();
		data.setAppAtrKey("123");
		data.setApplicantKey("123");
		data.setApplicationKey("123");
		data.setL2ProductCode("OMPL");
		data.setL2ProductKey(123l);
		data.setL4ProductCode("BFL");
		data.setL3ProductCode("BFLBOL");
		data.setParentApplicationKey("345");
		data.setEmail("abc@gmail.com");
		data.setErrFlg(true);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		data.setHeaders(headers);
		generateTrancheDetails();
		fetchBankDetails();
		fetchBranchDetails();
		PennantSystemDate callPennantForSystemDate= new PennantSystemDate();
		callPennantForSystemDate.setAppDate("12-12-2020");
		callPennantForSystemDate.setValueDate("12-12-2020");
		when(disbursementUtil.callPennantForSystemDate(Mockito.any(), Mockito.any())).thenReturn(callPennantForSystemDate);
		when(disbursementMapperUtil.mapBflBankRefCode(Mockito.any(), Mockito.any())).thenReturn("123");
		List<DisbursementMongoObject> disbursementMongoObjectList = new ArrayList<DisbursementMongoObject>();
		DisbursementMongoObject disbursementMongoObject = new DisbursementMongoObject();
		disbursementMongoObject.setCif("123");
		disbursementMongoObject.setBeneficiaryID("123");
		disbursementMongoObject.setApplicationKey(123L);
		disbursementMongoObjectList.add(disbursementMongoObject);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(disbursementMongoObjectList);
		when(disbursementMapperUtil.fetchDefaultBranch(Mockito.any(), Mockito.any())).thenReturn("123");
		fetchPricingDetails();
		fetchLatestDetails();
		fetchUserProfile();
		fetchAddressDetails();
		fetchMandateRegDetails();
		fetchPaymentMode();
		mapBre();
		List<VasBean> vas = new ArrayList<VasBean>();
		VasBean vasBean = new VasBean();
		vasBean.setFee("RS");
		vas.add(vasBean);
		updateApplicationForLAN();
		vasEvent();
		//when(disbursementMapperUtil.fetchbflbranchServicesMaster(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(1l);
		//when(disbursementMapperUtil.fetchBrchbyBranchKey(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn("123");
		String appDtlStr="{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":82,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"no designation\"},\"experience\":\"39\",\"netSalary\":\"100000\",\"employerType\":null,\"workExperienceInMonths\":null,\"principalIndustry\":null,\"averageBankBalance\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":{\"key\":null,\"code\":null,\"value\":null},\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":null,\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":null,\"presentBusinessVintage\":null,\"cif\":null,\"officetype\":null,\"caRegistrationNumber\":null,\"certificateOfPracticeYear\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"null\"},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9175177307\",\"dateOfBirth\":\"1981-02-01\",\"name\":{\"firstName\":\"Shruti\",\"middleName\":null,\"lastName\":\"Taparia\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"ahkshdad kajsd\",\"fatherName\":\"kjasdaskajsd asdkasd\",\"panNumber\":\"ALAPK8237J\",\"coapplicantObligation\":null,\"applicantKey\":null,\"workEmailRequired\":null,\"verifications\":null},\"prodCategory\":{\"prodcatkey\":10002,\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":3,\"partnerDetailsJson\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":3,\"partnerDetailsJson\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":3,\"partnerDetailsJson\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":3,\"partnerDetailsJson\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":3,\"partnerDetailsJson\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":3,\"partnerDetailsJson\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"Pune\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":7,\"partnerDetailsJson\":null},{\"principleProductCode\":\"LKBOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":11,\"partnerDetailsJson\":null},{\"principleProductCode\":\"BFLMB\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null,\"city\":null,\"tier\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":3,\"partnerDetailsJson\":null},{\"principleProductCode\":\"BFLPLCSIC\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null,\"city\":null,\"tier\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":3,\"partnerDetailsJson\":null},{\"principleProductCode\":\"BFLSOLICR\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null,\"city\":null,\"tier\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":3,\"partnerDetailsJson\":null},{\"principleProductCode\":\"PAYSSOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"REST\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":\"Super A\",\"employerSubCat\":\"Diamond\",\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":15,\"partnerDetailsJson\":null},{\"principleProductCode\":\"BFLPLCSSE\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":3,\"partnerDetailsJson\":null},{\"principleProductCode\":\"ABFLSOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":22,\"partnerDetailsJson\":null},{\"principleProductCode\":\"CVSOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE CITY\",\"tier\":\"\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":24,\"partnerDetailsJson\":null},{\"principleProductCode\":\"NEOBOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":23,\"partnerDetailsJson\":null},{\"principleProductCode\":\"MTSOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":25,\"partnerDetailsJson\":null},{\"principleProductCode\":\"CVBOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE CITY\",\"tier\":\"\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":24,\"partnerDetailsJson\":null},{\"principleProductCode\":\"AXISSOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"TIER1\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"employerSubCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":26,\"partnerDetailsJson\":null},{\"principleProductCode\":\"PAYBOL\",\"rejectionList\":null,\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"REST\"},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":\"Super A\",\"employerSubCat\":\"Diamond\",\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null,\"loanApprovalDetails\":null,\"principleKey\":15,\"partnerDetailsJson\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"20554\",\"addressTypeKey\":\"46\",\"resiType\":\"1\",\"addressLine1\":\"A 19/1 S4 48 NALLJABAD ROAD ,ORAGADAM ,,\",\"addressLine2\":\", , CHENNAI \",\"pincode\":null,\"pincodeKey\":\"7539\",\"cityKey\":\"1432\",\"stateKey\":\"267\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":\"JOURNEY\",\"localitykey\":null,\"numberOfMonths\":null,\"preferredFlag\":false},{\"addressKey\":\"73781\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":\"kjasd kajs as dk\",\"addressLine2\":\"kjas dka s askjd akjs dkjasd\",\"pincode\":null,\"pincodeKey\":\"113548\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":\"JOURNEY\",\"localitykey\":null,\"numberOfMonths\":null,\"preferredFlag\":true}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":96,\"obligationAmount\":null,\"officialEmailId\":\"krushna.kalaskar@bizsupporta.com\",\"btBankMasterKey\":\"null\",\"btsSegment\":null,\"hlProductIntent\":null,\"creditObligation\":null,\"coapplicantObligation\":null,\"coApplicantIncome\":null,\"deactivateOfferList\":[],\"cityKey\":1784,\"bflBranchKey\":1,\"propertyIdentifiedFlag\":null,\"appCreationDate\":\"2021-04-27 13:20:43\",\"applicationStatusDesc\":\"Inprogress\",\"creditStatus\":{\"creditDisbursementStatus\":\"1\",\"creditEligibilityStatus\":\"1\",\"approvalStatus\":null,\"rejectCode\":null},\"dispositionDetails\":null,\"appSegmentation\":null,\"applicationLoanDetails\":null,\"registrationNumber\":null,\"yrOfAttainingCertificate\":null}";
		Gson gson=new Gson();
		ApplicationDetails applicationDetails7=gson.fromJson(appDtlStr, ApplicationDetails.class);
		when(disbursementUtil.fetchApplicationDetails(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(applicationDetails7);
		when(vasProcessor.getVasList(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(vas);
		String lmsRes="{\"finReference\":\"P402SOL0378659\",\"stp\":true,\"financeSchedule\":{\"financeDetail\":{\"applicationNo\":\"1100000000046351\",\"cif\":\"214138\",\"finType\":\"SOLTL\",\"finCcy\":\"INR\",\"finBranch\":\"320\",\"profitDaysBasis\":\"A/A_365L\",\"finAmount\":205235,\"finAssetValue\":205235,\"downPayBank\":0,\"downPaySupl\":0,\"finRepayMethod\":\"DDM\",\"finStartDate\":\"2021-03-15\",\"allowGrcPeriod\":false,\"tdsApplicable\":false,\"manualSchedule\":false,\"planDeferCount\":0,\"stepFinance\":false,\"alwManualSteps\":false,\"grcTerms\":0,\"grcPeriodEndDate\":\"2021-03-15\",\"grcRateBasis\":\"#\",\"grcPftRate\":0,\"grcMargin\":0,\"grcProfitDaysBasis\":\"A/A_365L\",\"nextGrcPftRvwDate\":\"2021-03-15\",\"nextGrcCpzDate\":\"2021-03-15\",\"allowGrcRepay\":false,\"grcSchdMthd\":\"EQUAL\",\"grcMinRate\":0,\"grcMaxRate\":0,\"grcAdvPftRate\":0,\"grcAdvMargin\":0,\"numberOfTerms\":36,\"reqRepayAmount\":0,\"repayRateBasis\":\"R\",\"repayPftRate\":14.25,\"repayMargin\":0,\"scheduleMethod\":\"EQUAL\",\"repayFrq\":\"M0002\",\"nextRepayDate\":\"2022-01-02\",\"repayPftFrq\":\"M0002\",\"nextRepayPftDate\":\"2022-01-02\",\"repayRvwFrq\":\"M0002\",\"nextRepayRvwDate\":\"2021-05-02\",\"nextRepayCpzDate\":\"2024-12-02\",\"maturityDate\":\"2024-12-02\",\"finRepayPftOnFrq\":true,\"repayMinRate\":0,\"repayMaxRate\":0,\"repayAdvPftRate\":0,\"repayAdvMargin\":0,\"supplementRent\":0,\"increasedCost\":0,\"finContractDate\":\"2021-03-15\",\"relationshipOfficer\":\"DEFAULT\",\"quickDisb\":false,\"unPlanEMIHLockPeriod\":0,\"unPlanEMICpz\":false,\"reAgeCpz\":false,\"maxUnplannedEmi\":0,\"maxReAgeHolidays\":0,\"alwBpiTreatment\":true,\"dftBpiTreatment\":\"E\",\"bpiPftDaysBasis\":\"A/A_365L\",\"planEMIHAlw\":false,\"planEMIHMethod\":\"\",\"planEMIHMaxPerYear\":0,\"planEMIHMax\":0,\"planEMIHLockPeriod\":0,\"planEMICpz\":false,\"alwFlexi\":false,\"topUpAmount\":0,\"finCategoryType\":\"NORMALFIN\",\"noOfAdvanceEMI\":0},\"fees\":[{\"feeCategory\":\"FC\",\"feeCode\":\"PROCFEE\",\"feeTypeDesc\":\"PROCESSING FEE\",\"feeAmount\":4617,\"waiverAmount\":0,\"paidAmount\":4617,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]},{\"feeCategory\":\"FC\",\"feeCode\":\"CONV\",\"feeTypeDesc\":\"CONVENIENCE FEES\",\"feeAmount\":4499,\"waiverAmount\":0,\"paidAmount\":4499,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]},{\"feeCategory\":\"FC\",\"feeCode\":\"STAMPFEE\",\"feeTypeDesc\":\"STAMP FEES\",\"feeAmount\":0,\"waiverAmount\":0,\"paidAmount\":0,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]},{\"feeCategory\":\"FC\",\"feeCode\":\"VAS2201800003\",\"feeAmount\":5235,\"waiverAmount\":0,\"paidAmount\":5235,\"feeMethod\":\"DISB\",\"scheduleTerms\":0,\"feeBalance\":0,\"finFeeReceipts\":[]}],\"feeDues\":[],\"insurance\":[],\"step\":[],\"schedules\":[{\"schDate\":\"2021-03-15\",\"pftAmount\":0,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-04-02\",\"pftAmount\":1442,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-05-02\",\"pftAmount\":2404,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-06-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-07-02\",\"pftAmount\":2404,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-08-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-09-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-10-02\",\"pftAmount\":2403,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-11-02\",\"pftAmount\":2484,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2021-12-02\",\"pftAmount\":2404,\"schdPft\":0,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":0,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-01-02\",\"pftAmount\":2484,\"schdPft\":9133,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":9133,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-02-02\",\"pftAmount\":2484,\"schdPft\":7691,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-03-02\",\"pftAmount\":2243,\"schdPft\":7691,\"schdPftPaid\":0,\"schdPri\":0,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":205235,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-04-02\",\"pftAmount\":2484,\"schdPft\":6173,\"schdPftPaid\":0,\"schdPri\":1518,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":203717,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-05-02\",\"pftAmount\":2386,\"schdPft\":2386,\"schdPftPaid\":0,\"schdPri\":5305,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":198412,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-06-02\",\"pftAmount\":2402,\"schdPft\":2402,\"schdPftPaid\":0,\"schdPri\":5289,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":193123,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-07-02\",\"pftAmount\":2262,\"schdPft\":2262,\"schdPftPaid\":0,\"schdPri\":5429,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":187694,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-08-02\",\"pftAmount\":2271,\"schdPft\":2271,\"schdPftPaid\":0,\"schdPri\":5420,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":182274,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-09-02\",\"pftAmount\":2206,\"schdPft\":2206,\"schdPftPaid\":0,\"schdPri\":5485,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":176789,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-10-02\",\"pftAmount\":2071,\"schdPft\":2071,\"schdPftPaid\":0,\"schdPri\":5620,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":171169,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-11-02\",\"pftAmount\":2071,\"schdPft\":2071,\"schdPftPaid\":0,\"schdPri\":5620,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":165549,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2022-12-02\",\"pftAmount\":1939,\"schdPft\":1939,\"schdPftPaid\":0,\"schdPri\":5752,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":159797,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-01-02\",\"pftAmount\":1934,\"schdPft\":1934,\"schdPftPaid\":0,\"schdPri\":5757,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":154040,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-02-02\",\"pftAmount\":1865,\"schdPft\":1865,\"schdPftPaid\":0,\"schdPri\":5826,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":148214,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-03-02\",\"pftAmount\":1620,\"schdPft\":1620,\"schdPftPaid\":0,\"schdPri\":6071,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":142143,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-04-02\",\"pftAmount\":1720,\"schdPft\":1720,\"schdPftPaid\":0,\"schdPri\":5971,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":136172,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-05-02\",\"pftAmount\":1595,\"schdPft\":1595,\"schdPftPaid\":0,\"schdPri\":6096,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":130076,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-06-02\",\"pftAmount\":1574,\"schdPft\":1574,\"schdPftPaid\":0,\"schdPri\":6117,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":123959,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-07-02\",\"pftAmount\":1452,\"schdPft\":1452,\"schdPftPaid\":0,\"schdPri\":6239,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":117720,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-08-02\",\"pftAmount\":1425,\"schdPft\":1425,\"schdPftPaid\":0,\"schdPri\":6266,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":111454,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-09-02\",\"pftAmount\":1349,\"schdPft\":1349,\"schdPftPaid\":0,\"schdPri\":6342,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":105112,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-10-02\",\"pftAmount\":1231,\"schdPft\":1231,\"schdPftPaid\":0,\"schdPri\":6460,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":98652,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-11-02\",\"pftAmount\":1194,\"schdPft\":1194,\"schdPftPaid\":0,\"schdPri\":6497,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":92155,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2023-12-02\",\"pftAmount\":1079,\"schdPft\":1079,\"schdPftPaid\":0,\"schdPri\":6612,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":85543,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-01-02\",\"pftAmount\":1033,\"schdPft\":1033,\"schdPftPaid\":0,\"schdPri\":6658,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":78885,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-02-02\",\"pftAmount\":952,\"schdPft\":952,\"schdPftPaid\":0,\"schdPri\":6739,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":72146,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-03-02\",\"pftAmount\":814,\"schdPft\":814,\"schdPftPaid\":0,\"schdPri\":6877,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":65269,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-04-02\",\"pftAmount\":788,\"schdPft\":788,\"schdPftPaid\":0,\"schdPri\":6903,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":58366,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-05-02\",\"pftAmount\":682,\"schdPft\":682,\"schdPftPaid\":0,\"schdPri\":7009,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":51357,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-06-02\",\"pftAmount\":620,\"schdPft\":620,\"schdPftPaid\":0,\"schdPri\":7071,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":44286,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-07-02\",\"pftAmount\":517,\"schdPft\":517,\"schdPftPaid\":0,\"schdPri\":7174,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":37112,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-08-02\",\"pftAmount\":448,\"schdPft\":448,\"schdPftPaid\":0,\"schdPri\":7243,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":29869,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-09-02\",\"pftAmount\":360,\"schdPft\":360,\"schdPftPaid\":0,\"schdPri\":7331,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":22538,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-10-02\",\"pftAmount\":264,\"schdPft\":264,\"schdPftPaid\":0,\"schdPri\":7427,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":15111,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-11-02\",\"pftAmount\":182,\"schdPft\":182,\"schdPftPaid\":0,\"schdPri\":7509,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":7602,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0},{\"schDate\":\"2024-12-02\",\"pftAmount\":89,\"schdPft\":89,\"schdPftPaid\":0,\"schdPri\":7602,\"schdPriPaid\":0,\"feeSchd\":0,\"tDSAmount\":0,\"totalAmount\":7691,\"endBal\":0,\"limitDrop\":0,\"dropLineLimit\":0,\"availableLimit\":0}],\"planEMIHmonths\":[],\"planEMIHDates\":[],\"overdueCharges\":[],\"summary\":{\"effectiveRateOfReturn\":18.819365459,\"totalGracePft\":0,\"totalGraceCpz\":0,\"totalGrossGrcPft\":0,\"totalCpz\":0,\"totalProfit\":73083,\"totalRepayAmt\":278318,\"feeChargeAmount\":14351,\"numberOfTerms\":36,\"loanTenor\":44,\"maturityDate\":\"2024-12-02\",\"firstDisbDate\":\"2021-03-15T00:00:00\",\"lastDisbDate\":\"2021-03-15T00:00:00\",\"firstEmiAmount\":9133,\"nextSchDate\":\"2022-02-02\",\"nextRepayAmount\":7691,\"futureInst\":35,\"futureTenor\":34,\"firstInstDate\":\"2022-01-02\",\"paidTotal\":0,\"paidPri\":0,\"paidPft\":0,\"lastRepayDate\":\"2022-01-02\",\"outstandingTotal\":278318,\"outstandingPri\":205235,\"outstandingPft\":73083,\"overdueTotal\":0,\"overduePri\":0,\"overduePft\":0,\"overdueInst\":0,\"overdueCharges\":[],\"advPaymentAmount\":0,\"finActiveStatus\":\"A\",\"fullyDisb\":true,\"limitDrop\":0,\"currentDroplineLimit\":0,\"utilisation\":0,\"availableLimit\":0,\"graceInst\":0,\"graceTenor\":0,\"futureGraceInst\":0,\"finReference\":\"P402SOL0378659\",\"finType\":\"SOLTL\",\"finStartDate\":\"2021-03-15\",\"futureGraceTenor\":0,\"advEmi\":[{\"instNo\":2,\"instAmount\":7691},{\"instNo\":3,\"instAmount\":7691},{\"instNo\":4,\"instAmount\":7691},{\"instNo\":5,\"instAmount\":7691},{\"instNo\":6,\"instAmount\":7691},{\"instNo\":7,\"instAmount\":7691},{\"instNo\":8,\"instAmount\":7691},{\"instNo\":9,\"instAmount\":7691},{\"instNo\":10,\"instAmount\":7691},{\"instNo\":11,\"instAmount\":7691},{\"instNo\":12,\"instAmount\":7691},{\"instNo\":13,\"instAmount\":7691},{\"instNo\":14,\"instAmount\":7691},{\"instNo\":15,\"instAmount\":7691},{\"instNo\":16,\"instAmount\":7691},{\"instNo\":17,\"instAmount\":7691},{\"instNo\":18,\"instAmount\":7691},{\"instNo\":19,\"instAmount\":7691},{\"instNo\":20,\"instAmount\":7691},{\"instNo\":21,\"instAmount\":7691},{\"instNo\":22,\"instAmount\":7691},{\"instNo\":23,\"instAmount\":7691},{\"instNo\":24,\"instAmount\":7691},{\"instNo\":25,\"instAmount\":7691},{\"instNo\":26,\"instAmount\":7691},{\"instNo\":27,\"instAmount\":7691},{\"instNo\":28,\"instAmount\":7691},{\"instNo\":29,\"instAmount\":7691},{\"instNo\":30,\"instAmount\":7691},{\"instNo\":31,\"instAmount\":7691},{\"instNo\":32,\"instAmount\":7691},{\"instNo\":33,\"instAmount\":7691},{\"instNo\":34,\"instAmount\":7691},{\"instNo\":35,\"instAmount\":7691},{\"instNo\":36,\"instAmount\":7691}],\"odInstalments\":0,\"odPenalty\":0,\"entityCode\":\"1\",\"finAmount\":205235,\"alwFlexi\":false,\"bounceCharges\":0,\"repayAmount\":7691,\"pftOnTerm\":15626,\"totalDues\":0,\"totalRefunds\":0,\"netReceivable\":0,\"pendingInsts\":7691,\"nextInstNumber\":2,\"noOfUnpaidInst\":35,\"branchId\":\"320\",\"noPaidInst\":0,\"futurePri\":0,\"otherRefunds\":0,\"refund\":0,\"npaStageId\":\"S\",\"overDueTds\":0,\"futureTds\":0,\"isInActionProcess\":false,\"roi\":0,\"feeAmount\":0,\"custPosAmtRecLmt\":0,\"amcDue\":0,\"lppDue\":0,\"lpiDue\":0,\"otherDue\":0},\"vas\":[],\"outstandingPri\":205235,\"intervalFee\":[],\"isUpfrontAuto\":true},\"collaterals\":[],\"transactions\":[],\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"},\"receiptId\":0,\"disbSeqId\":0}";
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsRes);
		String lmsTimedoutRes="{\"finances\":[{\"finReference\":\"P404DSE0376828\",\"finType\":\"DSEPLCSH\",\"product\":\"DPLCS\",\"division\":\"BFSD\",\"finCcy\":\"INR\",\"finAmount\":500000,\"finAssetValue\":500000,\"finStartDate\":\"2021-12-07T00:00:00\",\"applicationNo\":\"123\",\"numberOfTerms\":36,\"loanTenor\":36,\"maturityDate\":\"2024-12-02T00:00:00\",\"firstEmiAmount\":17394,\"nextRepayAmount\":14605,\"paidTotal\":127505,\"paidPri\":110000,\"paidPft\":17505,\"outstandingTotal\":481962,\"outstandingPri\":390000,\"outstandingPft\":91962,\"futureInst\":33,\"finStatus\":\"A\",\"disbStatus\":\"Fully Disbursed\",\"coApplicants\":[]}],\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}";
		when(lmsHelper.executeLMSTimeOutRequestforLoan(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsTimedoutRes);
		doNothing().when(notificationProcessor).sendNotifications(Mockito.any(),Mockito.any());
		RetryRegistrationBean retryBean=new RetryRegistrationBean();
		retryBean.setCurrentRetryCount(1L);
		when(disbursementUtil.fetchExistingTransaction(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(retryBean);
		when(disbursementUtil.saveretrytransaction(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(retryBean);
		List<TranchBean> trnchLst = new ArrayList<TranchBean>();
		TranchBean bean = new TranchBean();
		bean.setTranchkey(123l);
		trnchLst.add(bean);
		when(disbursementUtil.fetchTranchDetails(Mockito.any(), Mockito.any())).thenReturn(trnchLst);
		when(disbursementUtil.fetchCustomerDisbDetails(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(DataPopulator.fetchCustomerDisbDetails());
		
		loanProcessor.processLoanRequest(data);
		
	}
	
	@Test
	public void initiateSuccessDisbEventForDmsDocPushTest() {
		Mockito.when(disbursementUtil.raiseDisbursementSuccessEventForDmsDocPush(Mockito.any())).thenReturn(true);
		PrincipalFileUploadRequestBean principalFileUploadRequestBean = new PrincipalFileUploadRequestBean();
		principalFileUploadRequestBean.setApplicationId("123");
		principalFileUploadRequestBean.setParentApplicationId("2424");
		loanProcessor.initiateSuccessDisbEventForDmsDocPush(principalFileUploadRequestBean );
	}
	
	@Test(expected=DisbursementServiceException.class)
	public void fetchFundedLoanPennantRequestTest1() {
		loanProcessor.processLoanRequestForFunded(DataPopulator.fetchRequestForFunded(),false);
	}
	
	@Test
	public void fetchFundedLoanPennantRequestTest2() throws Exception {
		Gson gson=new Gson();
		PartnerProductMapMaster partnerProduct=gson.fromJson("{\"partnerproductmapkey\":98,\"productcode\":\"CPPCP\",\"businessverticalmastkey\":22,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":421,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"CARDP\",\"pennatvasfee\":\"CARDP\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Wallet & Card Protection\",\"policytype\":\"New\",\"finnoneglcode\":null}", PartnerProductMapMaster.class);
		when(disbursementUtil.fetchPartnerProductMap(Mockito.any())).thenReturn(partnerProduct);
		when(disbursementMapperUtil.fetchPartnerProductMap(Mockito.any())).thenReturn(partnerProduct);
		when(disbursementUtil.fetchFundedCifId(Mockito.any(), Mockito.any())).thenReturn("29112");
		PennantSystemDate callPennantForSystemDate= new PennantSystemDate();
		callPennantForSystemDate.setAppDate("12-12-2020");
		callPennantForSystemDate.setValueDate("12-12-2020");
		when(disbursementUtil.callPennantForSystemDate(Mockito.any(), Mockito.any())).thenReturn(callPennantForSystemDate);
		mapBre();
		List<VasBean> vasList = new ArrayList<>();
		VasBean vas=new VasBean();
		vasList.add(vas);
		when(vasProcessor.getVasListForFunded(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(vasList);
		String lmsRes="{\"finReference\":\"1100000000006221\",\"returnStatus\":{\"returnCode\":\"00000\",\"returnText\":\"Success\"}}";
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsRes);
		loanProcessor.processLoanRequestForFunded(DataPopulator.fetchRequestForFunded(),false);
	}
	
	@Test
	public void fetchFundedLoanPennantRequestTest3() throws Exception {
		Gson gson=new Gson();
		PartnerProductMapMaster partnerProduct=gson.fromJson("{\"partnerproductmapkey\":98,\"productcode\":\"CPPCP\",\"businessverticalmastkey\":22,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":421,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"CARDP\",\"pennatvasfee\":\"CARDP\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Wallet & Card Protection\",\"policytype\":\"New\",\"finnoneglcode\":null}", PartnerProductMapMaster.class);
		when(disbursementUtil.fetchPartnerProductMap(Mockito.any())).thenReturn(partnerProduct);
		when(disbursementMapperUtil.fetchPartnerProductMap(Mockito.any())).thenReturn(partnerProduct);
		when(disbursementUtil.fetchFundedCifId(Mockito.any(), Mockito.any())).thenReturn("29112");
		PennantSystemDate callPennantForSystemDate= new PennantSystemDate();
		callPennantForSystemDate.setAppDate("12-12-2020");
		callPennantForSystemDate.setValueDate("12-12-2020");
		when(disbursementUtil.callPennantForSystemDate(Mockito.any(), Mockito.any())).thenReturn(callPennantForSystemDate);
		mapBre();
		List<VasBean> vasList = new ArrayList<>();
		VasBean vas=new VasBean();
		vasList.add(vas);
		when(vasProcessor.getVasListForFunded(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(vasList);
		String lmsRes="{\"finReference\":\"1100000000006221\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}";
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsRes);
		loanProcessor.processLoanRequestForFunded(DataPopulator.fetchRequestForFunded(),false);
	}
	
	@Test
	public void fetchFundedLoanPennantRequestTest4() throws Exception {
		Gson gson=new Gson();
		PartnerProductMapMaster partnerProduct=gson.fromJson("{\"partnerproductmapkey\":98,\"productcode\":\"CPPCP\",\"businessverticalmastkey\":22,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":421,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"CARDP\",\"pennatvasfee\":\"CARDP\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Wallet & Card Protection\",\"policytype\":\"New\",\"finnoneglcode\":null}", PartnerProductMapMaster.class);
		when(disbursementUtil.fetchPartnerProductMap(Mockito.any())).thenReturn(partnerProduct);
		when(disbursementMapperUtil.fetchPartnerProductMap(Mockito.any())).thenReturn(partnerProduct);
		when(disbursementUtil.fetchFundedCifId(Mockito.any(), Mockito.any())).thenReturn("29112");
		PennantSystemDate callPennantForSystemDate= new PennantSystemDate();
		callPennantForSystemDate.setAppDate("12-12-2020");
		callPennantForSystemDate.setValueDate("12-12-2020");
		when(disbursementUtil.callPennantForSystemDate(Mockito.any(), Mockito.any())).thenReturn(callPennantForSystemDate);
		mapBre();
		List<VasBean> vasList = new ArrayList<>();
		VasBean vas=new VasBean();
		vasList.add(vas);
		when(vasProcessor.getVasListForFunded(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(vasList);
		String lmsRes="{\"finReference\":\"1100000000006221\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}";
		String lmsRes1="{\"finances\":[{\"finReference\":\"P405SOF0218244\",\"finType\":\"SOFL\",\"product\":\"SOL\",\"division\":\"BFSD\",\"finCcy\":\"INR\",\"finAmount\":730517,\"finAssetValue\":730517,\"finStartDate\":\"2018-10-13T00:00:00\",\"applicationNo\":\"18340\",\"numberOfTerms\":60,\"loanTenor\":10,\"maturityDate\":\"2019-08-04T00:00:00\",\"firstEmiAmount\":7971,\"nextRepayAmount\":0,\"paidTotal\":1858586,\"paidPri\":1816718.95,\"paidPft\":41867.05,\"outstandingTotal\":0,\"outstandingPri\":0,\"outstandingPft\":0,\"futureInst\":0,\"finStatus\":\"E\",\"disbStatus\":\"Partially Disbursed\",\"coApplicants\":[]},{\"finReference\":\"P405SOF0127970\",\"finType\":\"SOFL\",\"product\":\"SOL\",\"division\":\"BFSD\",\"finCcy\":\"INR\",\"finAmount\":205947,\"finAssetValue\":205947,\"finStartDate\":\"2018-06-21T00:00:00\",\"applicationNo\":\"3565213\",\"numberOfTerms\":60,\"loanTenor\":61,\"maturityDate\":\"2023-07-05T00:00:00\",\"firstEmiAmount\":204947,\"nextRepayAmount\":11,\"paidTotal\":2368159,\"paidPri\":2365947,\"paidPft\":2212,\"outstandingTotal\":1421,\"outstandingPri\":1000,\"outstandingPft\":421,\"futureInst\":13,\"finStatus\":\"A\",\"disbStatus\":\"Partially Disbursed\",\"coApplicants\":[]}],\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}";
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsRes);
		when(lmsHelper.executeLMSTimeOutRequestforLoan(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(lmsRes1);
		loanProcessor.processLoanRequestForFunded(DataPopulator.fetchRequestForFunded(),true);
	}
}