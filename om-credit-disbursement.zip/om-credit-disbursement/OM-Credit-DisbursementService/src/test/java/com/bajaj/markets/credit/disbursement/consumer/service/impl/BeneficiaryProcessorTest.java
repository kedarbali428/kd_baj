package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.awaitility.core.ConditionTimeoutException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoOperations;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.BeneficiaryBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.BranchDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementMapperUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.LMSHelper;
import com.bajaj.markets.credit.disbursement.repository.MongoDBRepository;
import com.mongodb.client.result.UpdateResult;

@SpringBootTest
public class BeneficiaryProcessorTest {

	@InjectMocks
	private BeneficiaryProcessor beneficiaryProcessor;

	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Mock
	DisbursementUtil disbursementUtil;

	@Mock
	DisbursementMapperUtil disbursementMapperUtil;

	@Mock
	MongoOperations disbursementMongoTemplate;

	@Mock
	MongoDBRepository mongoDbRepo;

	@Mock
	LMSHelper lmsHelper;

	@Mock
	BFLLoggerUtil logger;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void processBeneficiaryRequestTest() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();

		BeneficiaryBean beneficiaryBean = new BeneficiaryBean();
		beneficiaryBean.setAcHolderName(" aaa ");
		when(disbursementBusinessHelper.getCreateBeneficiaryDetails(Mockito.any(), Mockito.any()))
				.thenReturn(beneficiaryBean);
		List<DisbursementMongoObject> mongolist = new ArrayList<>();
		DisbursementMongoObject e = new DisbursementMongoObject();
		e.setCif("27190");
		e.setApplicationKey(1L);
		mongolist.add(e);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(mongolist);
		beneficiaryBean.setBranchKey("1");

		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(
						"{\"beneficiaryID\":34794,\"returnStatus\":{\"returnCode\":\"30550\",\"returnText\":\"Account Number : 100000111 already exists for Customer CIF : 207948   \"},\"beneficiaryActive\":false,\"defaultBeneficiary\":false}");
		UpdateResult mongoresult = null;
		when(mongoDbRepo.updateFieldByApplicationKeyAndApplicantKey(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(mongoresult);

		BranchDetails branch = new BranchDetails();
		branch.setBranchIfscCode("ifsc");
		branch.setBranchMicrCode("micr");
		when(disbursementMapperUtil.fetchBrachDetails(Mockito.any(), Mockito.any())).thenReturn(branch);
		beneficiaryProcessor.processBeneficiaryRequest(data);
	}

	@Test
	public void processBeneficiaryRequestTest11() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();

		BeneficiaryBean beneficiaryBean = new BeneficiaryBean();
		beneficiaryBean.setAcHolderName(" aaa ");
		when(disbursementBusinessHelper.getCreateBeneficiaryDetails(Mockito.any(), Mockito.any()))
				.thenReturn(beneficiaryBean);
		List<DisbursementMongoObject> mongolist = new ArrayList<>();
		DisbursementMongoObject e = new DisbursementMongoObject();
		e.setCif("27190");
		e.setApplicationKey(1L);
		mongolist.add(e);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(mongolist);
		beneficiaryBean.setBranchKey("1");

		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(
						"<406 Not Acceptable,status : FAILURE, payload: [{\"faultCode\":\"9009\",\"faultMessage\":\"accHolderName invalid. Allowed Characters are [a-z A-Z 0-9 Space and special characters are & ( ) - .] and must starts with [a-z A-Z 0-9].\"}] error:[errorCode : CORE-001, errorMessage: org.springframework.web.client.HttpClientErrorException: 406 Not Acceptable] ,{}>");
		UpdateResult mongoresult = null;
		when(mongoDbRepo.updateFieldByApplicationKeyAndApplicantKey(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(mongoresult);

		BranchDetails branch = new BranchDetails();
		branch.setBranchIfscCode("ifsc");
		branch.setBranchMicrCode("micr");
		when(disbursementMapperUtil.fetchBrachDetails(Mockito.any(), Mockito.any())).thenReturn(branch);
		beneficiaryProcessor.processBeneficiaryRequest(data);
	}

	@Test
	public void processBeneficiaryRequestTest10() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();

		BeneficiaryBean beneficiaryBean = new BeneficiaryBean();
		beneficiaryBean.setAcHolderName(" aaa ");
		when(disbursementBusinessHelper.getCreateBeneficiaryDetails(Mockito.any(), Mockito.any()))
				.thenReturn(beneficiaryBean);
		List<DisbursementMongoObject> mongolist = new ArrayList<>();
		DisbursementMongoObject e = new DisbursementMongoObject();
		e.setCif("27190");
		e.setApplicationKey(1L);
		mongolist.add(e);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(mongolist);
		beneficiaryBean.setBranchKey("1");

		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(
						"{\"beneficiaryID\":34794,\"returnStatus\":{\"returnCode\":\"123\",\"returnText\":\"Account Number : 100000111 already exists for Customer CIF : 207948   \"},\"beneficiaryActive\":false,\"defaultBeneficiary\":false}");
		UpdateResult mongoresult = null;
		when(mongoDbRepo.updateFieldByApplicationKeyAndApplicantKey(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(mongoresult);

		BranchDetails branch = new BranchDetails();
		branch.setBranchIfscCode("ifsc");
		branch.setBranchMicrCode("micr");
		when(disbursementMapperUtil.fetchBrachDetails(Mockito.any(), Mockito.any())).thenReturn(branch);
		beneficiaryProcessor.processBeneficiaryRequest(data);
	}

	@Test
	public void processBeneficiaryRequestTest1() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();

		BeneficiaryBean beneficiaryBean = new BeneficiaryBean();
		beneficiaryBean.setAcHolderName(" aaa ");
		when(disbursementBusinessHelper.getCreateBeneficiaryDetails(Mockito.any(), Mockito.any()))
				.thenReturn(beneficiaryBean);
		List<DisbursementMongoObject> mongolist = new ArrayList<>();
		DisbursementMongoObject e = new DisbursementMongoObject();
		e.setCif("27190");
		e.setApplicationKey(1L);
		mongolist.add(e);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(mongolist);
		beneficiaryBean.setBranchKey("1");

		RetryRegistrationBean existingRecords = null;
		List<TranchBean> trnchLst = new ArrayList<TranchBean>();
		TranchBean bean = new TranchBean();
		bean.setTranchkey(123l);
		trnchLst.add(bean);
		when(disbursementUtil.fetchTranchDetails(Mockito.any(), Mockito.any())).thenReturn(trnchLst);
		when(disbursementUtil.fetchExistingTransaction(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(existingRecords);
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ConditionTimeoutException.class);
		UpdateResult mongoresult = null;
		when(mongoDbRepo.updateFieldByApplicationKeyAndApplicantKey(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(mongoresult);

		BranchDetails branch = new BranchDetails();
		branch.setBranchIfscCode("ifsc");
		branch.setBranchMicrCode("micr");
		when(disbursementMapperUtil.fetchBrachDetails(Mockito.any(), Mockito.any())).thenReturn(branch);
		beneficiaryProcessor.processBeneficiaryRequest(data);

	}
}
