/**
 * 
 */
package com.bajaj.markets.credit.disbursement.consumer.controller;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.BOLErrorHandlingProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.PROLErrorHandlingProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.SOLErrorHandlingProcessor;

@SpringBootTest
public class CreditDisbursementControllerTest {

	@InjectMocks
	CreditDisbursementController creditDisbursementController;

	@Mock
	@Qualifier("SOLErrorHandlingProcessor")
	SOLErrorHandlingProcessor SOLErrorHandlingProcessor;

	@Mock
	@Qualifier("BOLErrorHandlingProcessor")
	BOLErrorHandlingProcessor BOLErrorHandlingProcessor;
	
	@Mock
	@Qualifier("PROLErrorHandlingProcessor")
	PROLErrorHandlingProcessor PROLErrorHandlingProcessor;
	
	@Mock
	BFLLoggerUtil logger;

	@Mock
	CustomDefaultHeaders customHeaders;

	private String solloantypes = "BFLSOL";

	private String bolloantypes = "BFLBOL";
	
	private String prolloantypes = "BFLCAL";

	//@Mock
	//private BFLLoggerUtilExt logger;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

		/*
		 * ReflectionTestUtils.setField(creditDisbursementController,
		 * "SOLErrorHandlingProcessor", SOLErrorHandlingProcessor);
		 * ReflectionTestUtils.setField(creditDisbursementController,
		 * "BOLErrorHandlingProcessor", BOLErrorHandlingProcessor);
		 */
		//ReflectionTestUtils.setField(creditDisbursementController, "customHeaders", customHeaders);
		ReflectionTestUtils.setField(creditDisbursementController, "solloantypes", solloantypes);
		ReflectionTestUtils.setField(creditDisbursementController, "bolloantypes", bolloantypes);
		ReflectionTestUtils.setField(creditDisbursementController, "prolloantypes", prolloantypes);
		//ReflectionTestUtils.setField(creditDisbursementController, "logger", logger);

	}

	@Test
	public void testInitiateDisbursement1() {
		HttpHeaders headers = new HttpHeaders();
		DisbursementRequestBean bean = new DisbursementRequestBean();
		bean.setProductCode("BFLBOL");
		Mockito.doNothing().when(SOLErrorHandlingProcessor).processRetryErrors(Mockito.any());
		creditDisbursementController.initiateDisbursement(bean, headers);

	}
	
	
	@Test
	public void testInitiateDisbursement() {
		HttpHeaders headers = new HttpHeaders();
		DisbursementRequestBean bean =new DisbursementRequestBean();
		bean.setProductCode("BFLSOL");
		Mockito.doNothing().when(SOLErrorHandlingProcessor).processRetryErrors(Mockito.any());
		creditDisbursementController.initiateDisbursement(bean, headers);
		
	}
	
	@Test
	public void testInitiateDisbursement2() {
		HttpHeaders headers = new HttpHeaders();
		DisbursementRequestBean bean =new DisbursementRequestBean();
		bean.setProductCode("BFLCAL");
		Mockito.doNothing().when(PROLErrorHandlingProcessor).processRetryErrors(Mockito.any());
		creditDisbursementController.initiateDisbursement(bean, headers);
		
	} 
}