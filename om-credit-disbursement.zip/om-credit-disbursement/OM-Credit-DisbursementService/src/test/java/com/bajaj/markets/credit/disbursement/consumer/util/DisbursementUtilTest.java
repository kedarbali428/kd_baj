package com.bajaj.markets.credit.disbursement.consumer.util;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.sns.model.PublishResult;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateLoanResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FinanceScheduleBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.LoanProcessorVariables;
import com.bajaj.markets.credit.disbursement.consumer.bean.PrincipalFileUploadRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ReturnStatusBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.SummaryBean;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.repository.MongoDBRepository;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.bajaj.markets.referencedataclientlib.service.CommonCacheService;
import com.mongodb.client.result.UpdateResult;

@SpringBootTest
public class DisbursementUtilTest {
	
	@InjectMocks
	private DisbursementUtil util;

	@Mock
	BFLLoggerUtil logger;

	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;
	
	@Mock
	LMSHelper lmsHelper;
	
	@Mock
	MongoDBRepository mongoDbRepo;

	@Mock
	private CustomDefaultHeaders customDefaultHeaders;
	
	@Mock
	PublisherService publisherService;
	
	@Mock
	CommonCacheService commonCacheService;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(util, "updateAppTranchUrl", "updateAppTranchUrl");
		ReflectionTestUtils.setField(util, "getTrachDetailsURL", "getTrachDetailsURL");
		ReflectionTestUtils.setField(util, "getBankDetailsUrl", "getBankDetailsUrl");
		ReflectionTestUtils.setField(util, "getApplicationDetailsUrl", "getApplicationDetailsUrl");
		ReflectionTestUtils.setField(util, "getPincodeDetailsUrl", "getPincodeDetailsUrl");
		ReflectionTestUtils.setField(util, "getLocalityDetailsUrl", "getLocalityDetailsUrl");
		ReflectionTestUtils.setField(util, "getCustomerDetailsFromCreditApplicationUrl", "getCustomerDetailsFromCreditApplicationUrl");
		ReflectionTestUtils.setField(util, "getretrytransaction", "getretrytransaction");
		ReflectionTestUtils.setField(util, "saveretrytransaction", "saveretrytransaction");
		ReflectionTestUtils.setField(util, "addressDetailsUrl", "addressDetailsUrl");
		ReflectionTestUtils.setField(util, "smartechSNSTopic",
				"smartechSNSTopic");
		ReflectionTestUtils.setField(util, "activityid", "activityid");
		ReflectionTestUtils.setField(util, "applicationDetailsUrl", "applicationDetailsUrl");
		ReflectionTestUtils.setField(util, "getApplicationUtmSourcesUrl", "getApplicationUtmSourcesUrl");
		ReflectionTestUtils.setField(util, "getUserProfilesUrl", "http://omcreditapplicationservice.qa.bfsgodirect.com/v1/creditapplication/applications/{applicationid}/userprofiles");
		ReflectionTestUtils.setField(util, "getGenderDetailsUrl", "getGenderDetailsUrl");
		ReflectionTestUtils.setField(util, "validateRequestUrl", "validateRequestUrl");
		ReflectionTestUtils.setField(util, "getCreditReviewStatus", "getCreditReviewStatus");
	}
	
	@Test
	public void callPennantForSystemDateTest() {
		when(lmsHelper.execute(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("{\"appDate\":\"2020-10-31\",\"valueDate\":\"2020-10-31\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");
		assertNotNull(util.callPennantForSystemDate(DataPopulator.fetchGlobalData(), "lms"));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void updateAppTranchTest() {
		LoanProcessorVariables processorVariables = new LoanProcessorVariables();
		processorVariables.setDisbAmount(12112);
		processorVariables.setBundleApplicationPlanCode("FPP");
		when(lmsHelper.execute(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("{\"appDate\":\"2020-10-31\",\"valueDate\":\"2020-10-31\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");
		
		String tranch = "{\"loanAmount\":100000,\"netDisburseAmount\":94751,\"amountDisbursedTillNow\":5249,\"loanAccountNumber\":\"8989888999\",\"applicationId\":1100000000009782,\"applicationTranches\":[{\"tranchkey\":96,\"accountHolderName\":\"Test\",\"accountHolderType\":3,\"accountNumber\":100000111,\"accountTypeKey\":22,\"disbursementDate\":\"2020/07/04\",\"disbursementMode\":\"IMPS\",\"trancheAmount\":7000,\"trancheStatus\":\"Disbursement Initiated\",\"tranchenum\":null,\"trancheDate\":\"2020/07/04\",\"beneficiaryTypeKey\":3,\"ifsccode\":\"HDFC0000007\",\"applicationBankDetKey\":570}],\"zeroAmtDisbursement\":false}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getTrachDetailsURL"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(tranch, HttpStatus.OK));
		
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("updateAppTranchUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("", HttpStatus.OK));

		util.updateAppTranch("1100000121", "Pending", 0, null,1,new HttpHeaders());
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = DisbursementServiceException.class)
	public void updateAppTranchTest2() {
		when(lmsHelper.execute(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("{\"appDate\":\"2020-10-31\",\"valueDate\":\"2020-10-31\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");
		
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getTrachDetailsURL"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenThrow(NullPointerException.class);
		
		util.updateAppTranch("1100000121", "Pending", 0, null,null,new HttpHeaders());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchBankDetailsTest() {
		when(lmsHelper.execute(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("{\"appDate\":\"2020-10-31\",\"valueDate\":\"2020-10-31\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");
		
		String tranch = "{\"loanAmount\":100000,\"netDisburseAmount\":94751,\"amountDisbursedTillNow\":5249,\"loanAccountNumber\":\"8989888999\",\"applicationId\":1100000000009782,\"applicationTranches\":[{\"tranchkey\":96,\"accountHolderName\":\"Test\",\"accountHolderType\":3,\"accountNumber\":100000111,\"accountTypeKey\":22,\"disbursementDate\":\"2020/07/04\",\"disbursementMode\":\"IMPS\",\"trancheAmount\":7000,\"trancheStatus\":\"Disbursement Initiated\",\"tranchenum\":null,\"trancheDate\":\"2020/07/04\",\"beneficiaryTypeKey\":3,\"ifsccode\":\"HDFC0000007\",\"applicationBankDetKey\":570}],\"zeroAmtDisbursement\":false}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getTrachDetailsURL"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(tranch, HttpStatus.OK));
		
		String bank = "{\"bankDetailsKey\":570,\"accoutNumber\":\"100000111\",\"userAttributeKey\":\"9244\",\"branchKey\":\"28830\",\"impsStatus\":null,\"impsKey\":null,\"source\":\"EP\",\"bankAccountTypeKey\":\"22\",\"impsNameMatch\":null,\"finalMandateKey\":null,\"systemSelectedMandateKey\":\"46\",\"bankAccountCatagory\":\"Disbursement\",\"beneficiaryType\":\"CUSTOMER\",\"preferedBank\":true,\"beneficiaryNames\":\"Test\",\"holderName\":\"Test\",\"bankMasterKey\":null,\"mandateAddedBy\":null,\"paymentMode\":\"IMPS\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getBankDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(bank, HttpStatus.OK));

		assertNotNull(util.fetchBankDetails("1100000121", new HttpHeaders()));
	}
	
	@Test
	public void addDisbursementRecordsTest() {
		UpdateResult mongoresult = null;
		when(mongoDbRepo.insertDocumentDB(Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(mongoresult);
		util.addDisbursementRecords("1100000121","1100000121", "1100000121","1100000121","1100000121","1100000121","1100000121");
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchApplicationDetailsTest() {
		when(lmsHelper.execute(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("{\"appDate\":\"2020-10-31\",\"valueDate\":\"2020-10-31\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");

		String applicationDetailStr = "{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"manager\"},\"experience\":\"116\",\"netSalary\":\"98999\",\"employerType\":68671,\"workExperienceInMonths\":null,\"principalIndustry\":null,\"totalExperience\":null,\"decNetSalary\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":null,\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null},\"presentBusinessVintage\":null,\"cif\":null,\"officetype\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":\"LKJPO0987Y\",\"applicantKey\":123795},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[\"LENRNC\"],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"PUNE\",\"tier\":\"Tier1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"Pune\",\"tier\":\"Tier 1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null,\"city\":\"Pune\",\"tier\":\"Tier 1\"},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":[],\"bflApplicableLocationFlag\":null,\"propertyPincode\":null,\"isBTBankServicebaleFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"7541\",\"addressTypeKey\":\"46\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"115432\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null},{\"addressKey\":\"7539\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"115432\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":98999}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":90,\"obligationAmount\":null,\"btBankMasterKey\":\"null\",\"btsSegment\":null}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getApplicationDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(applicationDetailStr, HttpStatus.OK));

		assertNotNull(util.fetchApplicationDetails("1100000121",null, new HttpHeaders()));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchCustomerDisbDetailsteTest() {

		String applicationDetailStr = "{\"langKey\":570,\"nationalityKey\":1}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCustomerDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(applicationDetailStr, HttpStatus.OK));

		assertNotNull(util.fetchCustomerDisbDetails("123","123", new HttpHeaders()));
	}
	
	@Test(expected=Exception.class)
	public void logDisbErrorsTest() {
		String payload="{payload={\"beneficiaryID\":35692,\"returnStatus\":{\"returnCode\":\"30550\",\"returnText\":\"Account Number : 50100101678898 already exists for Customer CIF : 212175   \"},\"beneficiaryActive\":false,\"defaultBeneficiary\":false}, status=SUCCESS, errorBean=null}";
		util.logDisbErrors("123",payload);
	}
	
	@Test
	public void logBeneficiaryDisbErrorsTest() {

		String payload="<406 Not Acceptable,status : FAILURE, payload: [{\"faultCode\":\"9009\",\"faultMessage\":\"accHolderName invalid. Allowed Characters are [a-z A-Z 0-9 Space and special characters are & ( ) - .] and must starts with [a-z A-Z 0-9].\"}] error:[errorCode : CORE-001, errorMessage: org.springframework.web.client.HttpClientErrorException: 406 Not Acceptable] ,{}>";
		assertNotNull(util.logBeneficiaryDisbErrors("123",payload));
	}
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchExistingTransactionTest() {

		String applicationDetailStr = "{\"retryStatus\":\"Success\",\"transactionId\":1}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getretrytransaction"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(applicationDetailStr, HttpStatus.OK));

		assertNotNull(util.fetchExistingTransaction("123","123", new HttpHeaders()));
	}
	@SuppressWarnings("unchecked")
	@Test
	public void saveretrytransaction() {
		RetryRegistrationBean bean= new RetryRegistrationBean();
		bean.setErrorCode("123");
		String applicationDetailStr = "{\"retryStatus\":\"Success\",\"transactionId\":1}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("saveretrytransaction"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(applicationDetailStr, HttpStatus.OK));

		assertNotNull(util.saveretrytransaction("123","123",bean, new HttpHeaders()));
	}
	@SuppressWarnings("unchecked")
	@Test
	public void fetchPincodeDetailsTest() {
		when(lmsHelper.execute(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("{\"appDate\":\"2020-10-31\",\"valueDate\":\"2020-10-31\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");

		String pincode = "{\"pincodeKey\":115432,\"pincode\":\"411027\",\"cityKey\":1784,\"cityCode\":\"1948\",\"cityName\":\"PUNE\",\"stateKey\":257,\"stateName\":\"MAHARASHTRA\",\"countryKey\":91,\"countryCode\":\"IN\",\"countryName\":\"INDIA\",\"pinNegativeAreaFlg\":0,\"pinOglFlg\":0,\"stateCode\":\"MH\"}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getPincodeDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(pincode, HttpStatus.OK));

		assertNotNull(util.fetchPincodeDetails(115432L, new HttpHeaders()));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchLocalityDetailsTest() {
		when(lmsHelper.execute(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("{\"appDate\":\"2020-10-31\",\"valueDate\":\"2020-10-31\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");

		String locality = "[{\"id\":1,\"displayName\":\"Pune\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getLocalityDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(locality, HttpStatus.OK));

		assertNotNull(util.fetchLocalityDetails(115432L,"1", new HttpHeaders()));
	}
	
	@Test
	public void generateHeadersTest() {
		GlobalDataBean data = new GlobalDataBean();
	
		Map<String, String> header = new HashMap<>();
		header.put("authtoken", "abc");
		header.put("cmptcorrid", "abc");
		header.put("guardtoken", "abc");
		data.setHeaders(header);
		assertNotNull(util.generateHeaders(data));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchApplicationDetailsForCoApplicantTest1() {
		String address="{\"addressKey\":\"37217\",\"addressTypeKey\":\"50\",\"resiType\":null,\"addressLine1\":\"SERIOUSLY WHY\",\"addressLine2\":\"IS THIS NEEDED\",\"pincode\":null,\"pincodeKey\":\"113548\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("addressDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(address, HttpStatus.OK));
		
		util.fetchApplicationDetailsForCoApplicant("1100000121", "1234",new HttpHeaders());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void saveDisbursementErrorDetailsTest() {
		GlobalDataBean data = new GlobalDataBean();
		
		Map<String, String> header = new HashMap<>();
		header.put("authtoken", "abc");
		header.put("cmptcorrid", "abc");
		header.put("guardtoken", "abc");
		data.setHeaders(header);
		data.setApplicationKey("123");
		data.setParentApplicationKey("123");
		DisbursementTrackerBean dataToSav = new DisbursementTrackerBean();
		dataToSav.setDisbursmentstage("Test");
		when(lmsHelper.execute(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn("{\"appDate\":\"2020-10-31\",\"valueDate\":\"2020-10-31\",\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");
		
		String tranch = "{\"loanAmount\":100000,\"netDisburseAmount\":94751,\"amountDisbursedTillNow\":5249,\"loanAccountNumber\":\"8989888999\",\"applicationId\":1100000000009782,\"applicationTranches\":[{\"tranchkey\":96,\"accountHolderName\":\"Test\",\"accountHolderType\":3,\"accountNumber\":100000111,\"accountTypeKey\":22,\"disbursementDate\":\"2020/07/04\",\"disbursementMode\":\"IMPS\",\"trancheAmount\":7000,\"trancheStatus\":\"Disbursement Initiated\",\"tranchenum\":null,\"trancheDate\":\"2020/07/04\",\"beneficiaryTypeKey\":3,\"ifsccode\":\"HDFC0000007\",\"applicationBankDetKey\":570}],\"zeroAmtDisbursement\":false}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getTrachDetailsURL"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(tranch, HttpStatus.OK));
		
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("saveDisbErrorUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("{\"appdisbursmenttrackkey\":100000,\"apptranchedetkey\":94751}", HttpStatus.OK));

		util.saveDisbursementErrorDetails(data,dataToSav);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void sendSmartechNotificationTest() {
		GlobalDataBean data = new GlobalDataBean();
		
		Map<String, String> header = new HashMap<>();
		header.put("authtoken", "abc");
		header.put("cmptcorrid", "abc");
		header.put("guardtoken", "abc");
		data.setHeaders(header);
		data.setApplicationKey("123");
		data.setParentApplicationKey("123");
		String applicationDetailStr = "{\"applicationKey\":\"1100000000006221\",\"parentApplicationKey\":\"1100000000006217\",\"mobile\":123,\"dateofbirth\":123,\"applicantKey\":123,\"l2ProductKey\":10002,\"l2ProductCode\":\"OMPL\",\"l3ProductKey\":10,\"l3ProductCode\":\"BFLSOL\",\"l4ProductKey\":10,\"l4ProductCode\":\"BFLSOLTL\",\"principalKey\":3,\"applicationStatus\":1,\"riskoffertype\":123,\"inProcessing\":true}";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("applicationDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(applicationDetailStr, HttpStatus.OK));
		// \"createdt\": \"2021-02-12 16:53:20.214\" ,
		String locality = "[{\"utmsource\":\"Organic\"}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getApplicationUtmSourcesUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(locality, HttpStatus.OK));
		
		when(publisherService.publish(Mockito.any(), Mockito.any())).thenReturn(null);
		util.sendSmartechNotification("122111", data);
	}
	@Test(expected=Exception.class)
	public void fetchcif() {
		List<DisbursementMongoObject> mongolist = new ArrayList<>();
		DisbursementMongoObject e = new DisbursementMongoObject();
		e.setCif("27190");
		e.setApplicationKey(1L);
		mongolist.add(e);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(mongolist);
		assertNotNull(util.fetchCifId(123l,123l));
	}
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchUserProf() {
		
		String userProfileStr = "[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("userprofiles"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(userProfileStr, HttpStatus.OK));
		assertNotNull(util.getUserDetails("123",new HttpHeaders()));
	}
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchGenderInfo() {
		
		String genderStr = "[{\"genderCode\":\"1\",\"genderKey\":1}]";
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("getGenderDetailsUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>(genderStr, HttpStatus.OK));
		assertNotNull(util.fetchGenderDescDetails(1l,new HttpHeaders()));
	}
	
	@Test
	public void fetchPartnerProductMapTest() throws Exception{
	
		when(commonCacheService.findAll(Mockito.any())).thenReturn("[{\"businessverticalmastkey\":21,\"businessverticalcode\":\"INSURANCE_DISTRIBUTION\",\"businessverticalname\":\"Insurance Distribution\",\"potypecode\":\"INSD\",\"potype\":\"Insurance Distribution\"},{\"businessverticalmastkey\":26,\"businessverticalcode\":\"DIGITAL_INSURANCE\",\"businessverticalname\":\"Digital Insurance\",\"potypecode\":\"DIGINS\",\"potype\":\"Digital Insurance\"},{\"businessverticalmastkey\":22,\"businessverticalcode\":\"INSURANCE_TELEBINDING\",\"businessverticalname\":\"Insurance Telebinding\",\"potypecode\":\"INSPB\",\"potype\":\"Insurance Phone Binding\"}]")
		.thenReturn("[{\"partnerproductmapkey\":1,\"productcode\":\"BAGIC2WCI\",\"businessverticalmastkey\":21,\"finnoneloanprodcode\":null,\"finnonecompanyid\":16,\"finnonetypeid\":null,\"finnoneschemecode\":null,\"finnoneinsflag\":null,\"finnoneuploadflag\":null,\"finnonedme\":null,\"finnonedsa\":null,\"finnonecreditprogram\":null,\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":null,\"policytype\":null,\"finnoneglcode\":null},{\"partnerproductmapkey\":2,\"productcode\":\"BAGICTXCI\",\"businessverticalmastkey\":21,\"finnoneloanprodcode\":null,\"finnonecompanyid\":16,\"finnonetypeid\":null,\"finnoneschemecode\":null,\"finnoneinsflag\":null,\"finnoneuploadflag\":null,\"finnonedme\":null,\"finnonedsa\":null,\"finnonecreditprogram\":null,\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":null,\"policytype\":null,\"finnoneglcode\":null},{\"partnerproductmapkey\":3,\"productcode\":\"BAGICCVCI\",\"businessverticalmastkey\":21,\"finnoneloanprodcode\":null,\"finnonecompanyid\":16,\"finnonetypeid\":null,\"finnoneschemecode\":null,\"finnoneinsflag\":null,\"finnoneuploadflag\":null,\"finnonedme\":null,\"finnonedsa\":null,\"finnonecreditprogram\":null,\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":null,\"policytype\":null,\"finnoneglcode\":null},{\"partnerproductmapkey\":4,\"productcode\":\"BFHLVASCHSP\",\"businessverticalmastkey\":21,\"finnoneloanprodcode\":null,\"finnonecompanyid\":16,\"finnonetypeid\":null,\"finnoneschemecode\":null,\"finnoneinsflag\":null,\"finnoneuploadflag\":null,\"finnonedme\":null,\"finnonedsa\":null,\"finnonecreditprogram\":null,\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":null,\"policytype\":null,\"finnoneglcode\":null},{\"partnerproductmapkey\":5,\"productcode\":\"CPPWP\",\"businessverticalmastkey\":21,\"finnoneloanprodcode\":null,\"finnonecompanyid\":16,\"finnonetypeid\":null,\"finnoneschemecode\":null,\"finnoneinsflag\":null,\"finnoneuploadflag\":null,\"finnonedme\":null,\"finnonedsa\":null,\"finnonecreditprogram\":null,\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":null,\"policytype\":null,\"finnoneglcode\":null},{\"partnerproductmapkey\":38,\"productcode\":\"BFHLVASCHSP\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":null,\"finnonecompanyid\":16,\"finnonetypeid\":null,\"finnoneschemecode\":null,\"finnoneinsflag\":null,\"finnoneuploadflag\":null,\"finnonedme\":null,\"finnonedsa\":null,\"finnonecreditprogram\":null,\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":null,\"policytype\":null,\"finnoneglcode\":null},{\"partnerproductmapkey\":97,\"productcode\":\"MAXBUPHCOM\",\"businessverticalmastkey\":22,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":25,\"finnonetypeid\":729,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":\"Health Insurance & Solutions\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":98,\"productcode\":\"CPPCP\",\"businessverticalmastkey\":22,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":421,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"CARDP\",\"pennatvasfee\":\"CARDP\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Wallet & Card Protection\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":99,\"productcode\":\"CPPFC\",\"businessverticalmastkey\":22,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Asset Insurance & Solutions\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":100,\"productcode\":\"CPPFC\",\"businessverticalmastkey\":22,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":3723,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"OUTWE\",\"pennatvasfee\":\"OUTWE\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Asset Insurance & Solutions\",\"policytype\":\"New\",\"finnoneglcode\":\"OOWCPPTBAA\"},{\"partnerproductmapkey\":101,\"productcode\":\"MAXBUPHCOM\",\"businessverticalmastkey\":22,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":25,\"finnonetypeid\":729,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":\"Health Insurance & Solutions\",\"policytype\":\"Renewal\",\"finnoneglcode\":null},{\"partnerproductmapkey\":102,\"productcode\":\"MAXBUPHCOM\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":25,\"finnonetypeid\":729,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":\"Health Insurance & Solutions\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":103,\"productcode\":\"CPPFC\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Asset Insurance & Solutions\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":104,\"productcode\":\"CPPFC\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":3723,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"OUTWE\",\"pennatvasfee\":\"OUTWE\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Asset Insurance & Solutions\",\"policytype\":\"New\",\"finnoneglcode\":\"OOWCPPTBAA\"},{\"partnerproductmapkey\":106,\"productcode\":\"MAXBUPHCOM\",\"businessverticalmastkey\":21,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":25,\"finnonetypeid\":729,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":\"Health Insurance & Solutions\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":107,\"productcode\":\"CPPFC\",\"businessverticalmastkey\":21,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Asset Insurance & Solutions\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":108,\"productcode\":\"CPPFC\",\"businessverticalmastkey\":21,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":3723,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"OUTWE\",\"pennatvasfee\":\"OUTWE\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Asset Insurance & Solutions\",\"policytype\":\"New\",\"finnoneglcode\":\"OOWCPPTBAA\"},{\"partnerproductmapkey\":105,\"productcode\":\"MAXBUPHCOM\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":25,\"finnonetypeid\":729,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":\"Health Insurance & Solutions\",\"policytype\":\"Renewal\",\"finnoneglcode\":\"\"},{\"partnerproductmapkey\":109,\"productcode\":\"MAXBUPHCOM\",\"businessverticalmastkey\":21,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":25,\"finnonetypeid\":729,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":null,\"pennantvasproduct\":null,\"pennatvasfee\":null,\"pennantvasmanufacturer\":null,\"pennantaccountingset\":null,\"pennantpromotion\":null,\"pennantstp\":null,\"uicategory\":\"Health Insurance & Solutions\",\"policytype\":\"Renewal\",\"finnoneglcode\":null},{\"partnerproductmapkey\":110,\"productcode\":\"ADVENTURE_COVER\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Pocket\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":111,\"productcode\":\"COVID-19_INSURANCE\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Pocket\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":112,\"productcode\":\"ASSISTANCE_COVER\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Pocket\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":113,\"productcode\":\"ATM_ASSAULT_COVER\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Pocket\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":114,\"productcode\":\"LIFESTYLE_COVER\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Pocket\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":115,\"productcode\":\"AC_INSURANCE\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Pocket\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":116,\"productcode\":\"HEALTH_COVER_INS\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Pocket\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":117,\"productcode\":\"LOCAL_TRAVEL_INSURANCE\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Pocket\",\"policytype\":\"New\",\"finnoneglcode\":null},{\"partnerproductmapkey\":118,\"productcode\":\"HOSPITAL_CASH_COVER_01\",\"businessverticalmastkey\":26,\"finnoneloanprodcode\":\"VAS\",\"finnonecompanyid\":27,\"finnonetypeid\":4021,\"finnoneschemecode\":20329,\"finnoneinsflag\":1,\"finnoneuploadflag\":\"I\",\"finnonedme\":1,\"finnonedsa\":1,\"finnonecreditprogram\":\"Cash Ins\",\"pennantloantype\":\"GIP\",\"pennantvasproduct\":\"FONEC\",\"pennatvasfee\":\"FONEC\",\"pennantvasmanufacturer\":\"CPP\",\"pennantaccountingset\":null,\"pennantpromotion\":790,\"pennantstp\":1,\"uicategory\":\"Pocket\",\"policytype\":\"New\",\"finnoneglcode\":null}]");
		FundedDisbursementEventRequestBean requestForFunded = DataPopulator.fetchRequestForFunded();
		requestForFunded.getApplicationDetails().setL3ProductCode("MAXBUPHCOM");
		assertNotNull(util.fetchPartnerProductMap(requestForFunded));
	}
	
	@Test
	public void raiseInsuranceEventPostDisbursementTest(){
		ReturnStatusBean returnStatusBean = new ReturnStatusBean();
		returnStatusBean.setReturnCode("0000");
		returnStatusBean.setReturnText("Success");
		CreateLoanResponseBean createLoanResponseBean=new CreateLoanResponseBean();
		createLoanResponseBean.setFinReference("P34234234");
		FinanceScheduleBean financeSchedule=new FinanceScheduleBean();
		SummaryBean summary=new SummaryBean();
		summary.setFirstEmiAmount(BigDecimal.TEN);
		financeSchedule.setSummary(summary);
		createLoanResponseBean.setFinanceSchedule(financeSchedule);
		assertNotNull(util.raiseInsuranceEventPostDisbursement(DataPopulator.fetchRequestForFunded(), createLoanResponseBean, returnStatusBean, "CREATE_LOAN", "21344", DisbursementConstants.DISBURSEMENT_COMPLETED));
	}
	
	@Test
	public void fetchFundedCifIdTest(){
		List<FundedDisbursementMongoObject> list=new ArrayList<FundedDisbursementMongoObject>();
		FundedDisbursementMongoObject e=new FundedDisbursementMongoObject();
		e.setQuoteNumber("QT-18340-13831");
		e.setCif("12312");
		list.add(e);
		when(mongoDbRepo.fetchFundedObjectByKey(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(list);
		assertNotNull(util.fetchFundedCifId(1L, "QT-18340-13831"));
	}
	
	@Test
	public void addFundedDisbursementRecordsTest() {
		UpdateResult mongoresult = null;
		when(mongoDbRepo.insertDocumentDB(Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(mongoresult);
		util.addFundedDisbursementRecords("1100000121","1100000121", "1100000121","1100000121","1100000121","1100000121","1100000121");
	}
	
	@Test
	public void raiseDisbursementSuccessEventForDmsDocPushTest() {
		Mockito.when(publisherService.publish(Mockito.anyString(), Mockito.any())).thenReturn(new PublishResult());
		PrincipalFileUploadRequestBean principalFileUploadRequestBean = new PrincipalFileUploadRequestBean();
		principalFileUploadRequestBean.setApplicationId("123");
		principalFileUploadRequestBean.setParentApplicationId("2424");
		util.raiseDisbursementSuccessEventForDmsDocPush(principalFileUploadRequestBean);
		Assert.assertTrue(true);
	}
	
	@Test
	public void raiseDisbursementSuccessEventForDmsDocPushTest_Exc() {
		Mockito.when(publisherService.publish(Mockito.anyString(), Mockito.any())).thenThrow(NullPointerException.class);
		PrincipalFileUploadRequestBean principalFileUploadRequestBean = new PrincipalFileUploadRequestBean();
		principalFileUploadRequestBean.setApplicationId("123");
		principalFileUploadRequestBean.setParentApplicationId("2424");
		util.raiseDisbursementSuccessEventForDmsDocPush(principalFileUploadRequestBean);
	}
	
	@Test
	public void fetchFundedDisbRequestForRetryTest() {
		List<FundedDisbursementEventRequestMongoObject> mongoresult = new ArrayList<FundedDisbursementEventRequestMongoObject>();
		FundedDisbursementEventRequestMongoObject e=new FundedDisbursementEventRequestMongoObject();
		e.setApplicationKey(111L);
		e.setQuoteNumber("1224");
		e.setTimestamp(new Timestamp(System.currentTimeMillis()));
		mongoresult.add(e);
		when(mongoDbRepo.fetchFundedEventRequestByKey(Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(mongoresult);
		FundedDisbursementRequestBean request=new FundedDisbursementRequestBean();
		request.setApplicationId("111");
		request.setQuoteNumber("1224");
		util.fetchFundedDisbRequestForRetry(request);
	}
	
	@Test
	public void saveFundedEventRequestTest() {
		UpdateResult mongoresult = null;
		when(mongoDbRepo.insertDocumentDB(Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(mongoresult);
		util.saveFundedEventRequest(DataPopulator.fetchRequestForFunded());
	}
	
	@SuppressWarnings("unchecked")
	public void validateRequestexc() {
		Mockito.when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("{\"validFlg\":true}", HttpStatus.OK));
	}

	@SuppressWarnings("unchecked")
	public void validateRequest() {
		Mockito.when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("validateRequestUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("true", HttpStatus.OK));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void getCreditReviewDetailsTest() {
		String responseJson ="{\r\n" + 
				"  \"individualCoapplicantRequired\": \"1\",\r\n" + 
				"  \"entityCoapplicantRequired\": \"1\"\r\n" + 
				"}";
		Mockito.when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.contains("getCreditReviewStatus"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity<String>(responseJson, HttpStatus.OK));
		
		util.getCreditReviewDetails("11000", new HttpHeaders());
	}
}
