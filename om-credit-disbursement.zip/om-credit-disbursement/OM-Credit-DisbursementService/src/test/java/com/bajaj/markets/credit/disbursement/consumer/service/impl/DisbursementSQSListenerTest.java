package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazon.sqs.javamessaging.message.SQSTextMessage;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.disbursement.consumer.service.DisbursementSQSListener;
import com.bajaj.markets.om.consumer.model.SubEventMessage;
import com.google.gson.Gson;

@SpringBootTest
public class DisbursementSQSListenerTest {
	
	@InjectMocks
	DisbursementSQSListener disbursementSQSListener;

	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	@Qualifier("SOLDisbursementProcessor")
	SOLDisbursementProcessor solDisbursementProcessor;
	
	@Mock
	@Qualifier("BOLDisbursementProcessor")
	BOLDisbursementProcessor bolDisbursementProcessor;
	
	@Mock
	@Qualifier("SOLErrorHandlingProcessor")
	SOLErrorHandlingProcessor solErrorHandlingProcessor;
	
	@Mock
	@Qualifier("BOLErrorHandlingProcessor")
	BOLErrorHandlingProcessor bolErrorHandlingProcessor;
	
	@Mock
	BflFundedDisbursementProcessor fundedProcessor;
	
	@Value("${solloantypes}")
	private String solloantypes;
	
	@Value("${bolloantypes}")
	private String bolloantypes;
	
	@Value("${prolloantypes}")
	private String prolloantypes;
	
	@Mock
	@Qualifier("PROLDisbursementProcessor")
	PROLDisbursementProcessor prolDisbursementProcessor;
	
	@Mock
	@Qualifier("PROLErrorHandlingProcessor")
	PROLErrorHandlingProcessor prolErrorHandlingProcessor;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(disbursementSQSListener, "solloantypes", "BFLSOL");
		ReflectionTestUtils.setField(disbursementSQSListener, "bolloantypes", "BFLBOL");
		ReflectionTestUtils.setField(disbursementSQSListener, "prolloantypes", "BFLSOL");
	}
	
	@Test
	public void testMessage() throws JMSException {
		TextMessage txtMessage = new SQSTextMessage();
		txtMessage.setText("{\"Message\": {\"eventName\":\"CREDIT_DISBURSEMENT_TOPIC_QA\",\"eventType\":\"INITIATE_DISBURSEMENT\",\"payload\":\r\n{\"applicationId\":\"1100000000019973\",\"applicantId\":\"144846\",\"productCode\":\"BFLSOL\",\"eventType\":\"DISBURSEMENT_INITIATED\"}\r\n,\"headers\":{}},MessageAttributes: {}}");
		disbursementSQSListener.onMessage(txtMessage);
	}
	
	@Test
	public void testMessageFailed() throws JMSException {
		TextMessage txtMessage = new SQSTextMessage();
		txtMessage.setText("{\"Message\": {\"eventName\":\"CREDIT_DISBURSEMENT_TOPIC_QA\",\"eventType\":\"DISBURSEMENT_FAILED\",\"payload\":\r\n{\"applicationId\":\"1100000000019973\",\"applicantId\":\"144846\",\"productCode\":\"BFLSOL\",\"eventType\":\"DISBURSEMENT_INITIATED\"}\r\n,\"headers\":{}},MessageAttributes: {}}");
		disbursementSQSListener.onMessage(txtMessage);
	}
	
	@Test
	public void testMessageFunded() throws JMSException {
		TextMessage txtMessage = new SQSTextMessage();
		txtMessage.setText("{\"Message\":{\"eventName\":\"CREDIT_DISBURSEMENT_TOPIC_QA\",\"eventType\":\"BFLIM_INITIATE_DISBURSEMENT\",\"payload\": {\"applicantDetails\":{\"firstName\":\"Praful\",\"lastName\":\"Testing\",\"dateOfBirth\":\"1976-03-07\",\"gender\":\"M\",\"maritalStatus\":\"S\",\"mobileNumber\":\"8796715275\",\"personalEmailId\":\"sfdsfdsf@gmail.com\",\"officialEmailId\":\"sfdsfdsf@gmail.com\",\"finnoneCustId\":\"26852\",\"addresses\":[rn{\"addrType\":\"CURRES\",\"buildingNo\":\"sdfsdfsdf sdfsdf\",\"street\":\"lkjkljklj lkjkl\",\"state\":\"257\",\"city\":\"1784\",\"pinCode\":\"411014\"}rn]},\"bankDetails\":{\"bankName\":\"229\",\"accountNumber\":\"693101500776\",\"accountType\":\"SA\"},\"applicationDetails\":{\"applicationNo\":\"22292001\",\"quoteNumber\":\"29184001\",\"l2ProductKey\":\"1\",\"l2ProductCode\":\"HGI\",\"l3ProductKey\":\"63\",\"l3ProductCode\":\"ABHIACTIVA\",\"l4ProductKey\":\"59\",\"l4ProductCode\":\"ABHIACTIVA1\",\"disbInitiatedby\":\"8796715275\",\"netPremiumAmount\":\"7162.00\",\"policyType\":\"New\",\"businessVertical\":\"DIGITAL_INSURANCE\",\"poType\":\"DIGINS\",\"paymentQuoteId\":\"10874\",\"fundingDetails\":rnrn{\"fundingType\":\"FULLF\",\"sumAssured\":\"500000.00\",\"policyTenore\":\"1\",\"fundingAmount\":\"8452\",\"fundingROI\":\"0\",\"fundingTenor\":\"6\"}rn,\"nomineeDetails\":[{\"nomName1\":\"dsfsdf\",\"nomRel1\":\"BROTHER\",\"nomAddress1\":\"sdfsdfsdf sdfsdf\",\"nomMob1\":\"8796715275\"}],\"mandateDetails\":{\"mandateRef\":\"4550CD17990310\",\"mandateType\":\"E\",\"ifsc\":\"ICIC0006931\",\"micr\":\"313229019\",\"accType\":\"10\",\"accNumber\":\"693101500776\",\"accHolderName\":\"KESAR NAGDA\",\"openMandate\":true,\"startDate\":\"2020-10-24\",\"expiryDate\":\"2035-12-31\",\"maxLimit\":\"45588.0\",\"existingMandate\":true},\"paymentDetails\":{\"amount\":\"NA\",\"valueDate\":\"2021-05-20\",\"favourName\":\"NA\",\"transactionRef\":\"NA\"}}}}}");
		disbursementSQSListener.onMessage(txtMessage);
	}
}
