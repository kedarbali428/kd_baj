package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationDetail;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCollateralResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCustomerResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.google.gson.Gson;

@SpringBootConfiguration
@SpringBootTest
public class PROLErrorHandlingProcessorTest {

	@InjectMocks
	@Qualifier("PROLErrorHandlingProcessor")
	private PROLErrorHandlingProcessor prolErrorHandlingProcessor;

	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Mock
	BFLLoggerUtil logger;

	@Mock
	LoanProcessor loanProcessor;

	@Mock
	DisbursementUtil disbursementUtil;

	@Mock
	CustomerProcessor customerProcessor;

	@Mock
	BeneficiaryProcessor beneficiaryProcessor;

	@Mock
	CollateralProcessor collateralProcessor;

	private String getDisbErrorUrl = "getDisbErrorUrl";
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(prolErrorHandlingProcessor, "getDisbErrorUrl", "getDisbErrorUrl");
		ReflectionTestUtils.setField(prolErrorHandlingProcessor, "getUserProfilesUrl", "getUserProfilesUrl");
	}

	@Test
	public void processDisbursementTestException() {
		DisbursementEventRequestBean request = new DisbursementEventRequestBean();
		request.setApplicationId("123");
		request.setProductCode("BFLSOL");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken", "authtoken");
		request.setHeaders(headers);
		fetchDisbursementErrorDetails();
		fetchuserprofile();
		generateTrancheDetails();
		fetchApplicationns();
		saveError();
		prolErrorHandlingProcessor.processPROLDisbursementErrors(request);

	}

	@Test
	public void processDisbursementTest1() {
		DisbursementEventRequestBean request = new DisbursementEventRequestBean();
		request.setApplicationId("123");
		request.setProductCode("BFLSOL");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken", "authtoken");
		request.setHeaders(headers);
		fetchDisbursementErrorDetails1();
		fetchuserprofile();
		generateTrancheDetails();
		fetchApplicationns();
		saveError();
		prolErrorHandlingProcessor.processPROLDisbursementErrors(request);

	}

	@Test
	public void processDisbursement2() {
		DisbursementEventRequestBean request = new DisbursementEventRequestBean();
		request.setApplicationId("123");
		request.setProductCode("BFLSOL");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken", "authtoken");
		request.setHeaders(headers);
		fetchDisbursementErrorDetails2();
		fetchuserprofile();
		generateTrancheDetails();
		fetchApplicationns();
		saveError();
		prolErrorHandlingProcessor.processPROLDisbursementErrors(request);

	}

	@Test
	public void processDisbursementTest3() {
		DisbursementEventRequestBean request = new DisbursementEventRequestBean();
		request.setApplicationId("123");
		request.setProductCode("BFLSOL");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken", "authtoken");
		request.setHeaders(headers);
		fetchDisbursementErrorDetails3();
		fetchuserprofile();
		generateTrancheDetails();
		fetchApplicationns();
		saveError();
		prolErrorHandlingProcessor.processPROLDisbursementErrors(request);

	}

	@Test
	public void processDisbursementTest4() {
		DisbursementEventRequestBean request = new DisbursementEventRequestBean();
		request.setApplicationId("123");
		request.setProductCode("BFLSOL");
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken", "authtoken");
		request.setHeaders(headers);
		fetchDisbursementErrorDetails4();
		fetchuserprofile();
		generateTrancheDetails();
		fetchApplicationns();
		saveError();
		prolErrorHandlingProcessor.processPROLDisbursementErrors(request);

	}
	@SuppressWarnings("unchecked")
	public void fetchuserprofile() {
	String userProfileStr = "[{\"applicationKey\":\"1100000000009782\",\"applicationUserAttributeKey\":\"9244\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9852859999\",\"dateOfBirth\":\"1989-09-05\",\"name\":{\"firstName\":\"TSEting\",\"middleName\":\"\",\"lastName\":\"test\",\"salutationKey\":21,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":\"Hey mother\",\"fatherName\":\"Heyy father\",\"panNumber\":null,\"applicantKey\":9244}]";

	when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
			Mockito.eq("getUserProfilesUrl"), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
					.thenReturn(new ResponseEntity<String>(userProfileStr, HttpStatus.OK));
	}
	
	@SuppressWarnings("unchecked")
	public void fetchDisbursementErrorDetails1() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq(getDisbErrorUrl), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
						new ResponseEntity<String>("[{\"disbursmentstage\":\"CREATE_CUSTOMER\"}]", HttpStatus.OK));

		createCustomer();
		createBeneficiary();
		createCollateral();
		createLoan();
	}

	@SuppressWarnings("unchecked")
	public void fetchDisbursementErrorDetails2() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq(getDisbErrorUrl), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
						new ResponseEntity<String>("[{\"disbursmentstage\":\"CREATE_BENEFICIARY\"}]", HttpStatus.OK));

		createCustomer();
		createBeneficiary();
		createCollateral();
		createLoan();
	}

	@SuppressWarnings("unchecked")
	public void fetchDisbursementErrorDetails3() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq(getDisbErrorUrl), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
						new ResponseEntity<String>("[{\"disbursmentstage\":\"CREATE_COLATERAL\"}]", HttpStatus.OK));
		createCustomer();
		createBeneficiary();
		createCollateral();
		createLoan();
	}

	@SuppressWarnings("unchecked")
	public void fetchDisbursementErrorDetails4() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq(getDisbErrorUrl), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(
						new ResponseEntity<String>("[{\"disbursmentstage\":\"CREATE_LOAN\"}]", HttpStatus.OK));
		createCustomer();
		createBeneficiary();
		createCollateral();
		createLoan();
	}

	@SuppressWarnings("unchecked")
	public void fetchDisbursementErrorDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq(getDisbErrorUrl), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
						.thenReturn(new ResponseEntity<String>("[{\"disbursmentstage\":\"DISBURSMENT_PRECHECKS\"}]",
								HttpStatus.OK));
	}

	public void generateTrancheDetails() {
		TranchBean tranchBean = new TranchBean();
		tranchBean.setTranchkey(123l);
		List<TranchBean> trnchLst = new ArrayList<TranchBean>();
		trnchLst.add(tranchBean);
		when(loanProcessor.fetchTranchDetails(Mockito.any(), Mockito.any())).thenReturn(trnchLst);

	}

	public void saveError() {
		List<DisbursementTrackerBean> disbursementTrackerBeanLst = new ArrayList<DisbursementTrackerBean>();
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		disbursementTrackerBeanLst.add(disbursementTrackerBean);
		when(disbursementUtil.saveDisbursementErrorDetails(Mockito.any(), Mockito.any()))
				.thenReturn(disbursementTrackerBean);

	}

	private void fetchApplicationns() {
		Gson gson = new Gson();
		String str = "{\"applicationKey\":\"1100000000006221\",\"parentApplicationKey\":\"1100000000006217\",\"mobile\":123,\"dateofbirth\":123,\"applicantKey\":123,\"l2ProductKey\":10002,\"l2ProductCode\":\"OMPL\",\"l3ProductKey\":10,\"l3ProductCode\":\"BFLSOL\",\"l4ProductKey\":10,\"l4ProductCode\":\"BFLSOLTL\",\"principalKey\":3,\"applicationStatus\":1,\"riskoffertype\":123,\"inProcessing\":true}";
		ApplicationDetail appDtl = gson.fromJson(str, ApplicationDetail.class);
		when(disbursementUtil.fetchApplicationDetails(DataPopulator.fetchGlobalData())).thenReturn(appDtl);
	}

	public void createCustomer() {
		CreateCustomerResponseBean createCustomerResponseBean = new CreateCustomerResponseBean();
		when(customerProcessor.processCustomerRequestForSOL(Mockito.any())).thenReturn(createCustomerResponseBean);

	}

	public void createBeneficiary() {
		doNothing().when(beneficiaryProcessor).processBeneficiaryRequest(Mockito.any());
	}

	public void createCollateral() {
		CreateCollateralResponseBean createCollateralResponseBean = new CreateCollateralResponseBean();
		when(collateralProcessor.processCollateralRequest(Mockito.any())).thenReturn(createCollateralResponseBean);

	}

	public void createLoan() {
		doNothing().when(loanProcessor).processLoanRequest(Mockito.any());

	}
}
