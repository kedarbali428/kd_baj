package com.bajaj.markets.credit.disbursement.consumer.util;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.awaitility.core.ConditionTimeoutException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCollateralExternalRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.CollateralProcessor;
import com.bajaj.markets.credit.disbursement.repository.MongoDBRepository;
import com.mongodb.client.result.UpdateResult;

@SpringBootTest
public class CollateralProcessorTest {
	@InjectMocks
	private CollateralProcessor collateralProcessor;

	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Mock
	DisbursementUtil disbursementUtil;

	@Mock
	DisbursementMapperUtil disbursementMapperUtil;

	@Mock
	MongoOperations disbursementMongoTemplate;

	@Mock
	MongoDBRepository mongoDbRepo;

	
	@Mock
	LMSHelper lmsHelper;

	@Mock
	BFLLoggerUtil logger;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(collateralProcessor, "getCollateralDetailsFromCreditApplicationUrl",
				"getCollateralDetailsFromCreditApplicationUrl");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void processCollateralRequestTest() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();

		String str = "{\"spdcDetails\":{\"pdcnumber1\":\"1\",\"pdcamount1\":1,\"pdcnumber2\":\"2\",\"pdcamount2\":2,\"pdcnumber3\":\"3\",\"pdcamount3\":3,\"pdcnumber4\":\"4\",\"pdcamount4\":4}}";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCollateralDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(str, HttpStatus.OK));

		when(disbursementUtil.fetchBankDetails(Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchBankDetailsResponse());

		List<DisbursementMongoObject> mongolist = new ArrayList<>();
		DisbursementMongoObject e = new DisbursementMongoObject();
		e.setCif("27190");
		e.setApplicationKey(1L);
		mongolist.add(e);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(mongolist);
		CreateCollateralExternalRequest request = new CreateCollateralExternalRequest();
		when(disbursementMapperUtil.mapCollateralPennantRequest(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(request);
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(
						"{\"collateralRef\":\"CT2030500001\",\"maxCollateralValue\":0,\"splLtv\":0,\"alwMultiLoanAssign\":false,\"alwThirdPartyAssign\":false,\"returnStatus\":{\"returnCode\":\"0000\",\"returnText\":\"Success\"}}");
		UpdateResult mongoresult = null;
		when(mongoDbRepo.updateFieldByApplicationKeyAndApplicantKey(Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(mongoresult);
	collateralProcessor.processCollateralRequest(data);
	}
	
	@Test
	public void processCollateralRequestTest1() {
		GlobalDataBean data = DataPopulator.fetchGlobalData();

		String str = "{\"spdcDetails\":{\"pdcnumber1\":\"1\",\"pdcamount1\":1,\"pdcnumber2\":\"2\",\"pdcamount2\":2,\"pdcnumber3\":\"3\",\"pdcamount3\":3,\"pdcnumber4\":\"4\",\"pdcamount4\":4}}";

		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(),
				Mockito.eq("getCollateralDetailsFromCreditApplicationUrl"), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>(str, HttpStatus.OK));

		when(disbursementUtil.fetchBankDetails(Mockito.any(), Mockito.any()))
				.thenReturn(DataPopulator.fetchBankDetailsResponse());

		List<DisbursementMongoObject> mongolist = new ArrayList<>();
		DisbursementMongoObject e = new DisbursementMongoObject();
		e.setCif("27190");
		e.setApplicationKey(1L);
		mongolist.add(e);
		when(mongoDbRepo.fetchObjectByKey(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(mongolist);
		CreateCollateralExternalRequest request = new CreateCollateralExternalRequest();
		when(disbursementMapperUtil.mapCollateralPennantRequest(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(request);
		RetryRegistrationBean existingRecords= null;
		 List<TranchBean> trnchLst =new ArrayList<TranchBean>();
		 TranchBean bean = new TranchBean();
		 bean.setTranchkey(123l);
		 trnchLst.add(bean);
				 when(disbursementUtil.fetchTranchDetails(Mockito.any(), Mockito.any())).thenReturn(trnchLst);
		when(disbursementUtil.fetchExistingTransaction(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(existingRecords);
		when(lmsHelper.executeLmsRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ConditionTimeoutException.class);
		UpdateResult mongoresult = null;
		when(mongoDbRepo.updateFieldByApplicationKeyAndApplicantKey(Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(mongoresult);
		collateralProcessor.processCollateralRequest(data);
	}

}
