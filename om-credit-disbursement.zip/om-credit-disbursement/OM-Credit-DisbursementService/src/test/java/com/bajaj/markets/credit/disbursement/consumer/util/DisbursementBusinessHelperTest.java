package com.bajaj.markets.credit.disbursement.consumer.util;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;

@SpringBootTest
public class DisbursementBusinessHelperTest {

	@InjectMocks
	private DisbursementBusinessHelper helper;

	@Mock
	BFLLoggerUtil logger;

	@Mock
	private RestTemplate restTemplate;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(helper, "getBeneficiaryUrl", "getBeneficiaryUrl");
		ReflectionTestUtils.setField(helper, "getProductTypeDetailsUrl", "getProductTypeDetailsUrl");
		ReflectionTestUtils.setField(helper, "restTemplate", restTemplate);
		ReflectionTestUtils.setField(helper, "bundleDetailsUrl", "bundleDetailsUrl");
		ReflectionTestUtils.setField(helper, "vasDetailsUrl", "vasDetailsUrl");
		ReflectionTestUtils.setField(helper, "occupationDetailsUrl", "occupationDetailsUrl");
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void getCreateBeneficiaryDetailsTest() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationId", "1000000121");
		when(restTemplate.exchange("getBeneficiaryUrl", HttpMethod.GET, entity, String.class,params))
				.thenReturn(new ResponseEntity("{\"cif\":null,\"beneficiaryID\":null,\"bankCode\":null,\"branchKey\":\"28830\",\"ifsc\":null,\"accountNo\":\"100000111\",\"acHolderName\":\"Test\",\"phoneCountryCode\":\"+91\",\"phoneAreaCode\":\"+91\",\"phoneNumber\":\"9852859999\",\"micr\":null,\"city\":\"1948\",\"email\":\"jgklsjgks@gmail.com\",\"beneficiaryActive\":true,\"defaultBeneficiary\":false,\"disbDescription\":null,\"disbursementmode\":null,\"ifsccode\":null}", header, HttpStatus.OK));
		assertNotNull(helper.getCreateBeneficiaryDetails("1000000121", new HttpHeaders()));
	}
	
	@Test(expected = DisbursementServiceException.class)
	public void getCreateBeneficiaryDetailsTest2() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationId", "1000000121");
		when(restTemplate.exchange("getBeneficiaryUrl", HttpMethod.GET, entity, String.class,params))
				.thenThrow(NullPointerException.class);
		assertNotNull(helper.getCreateBeneficiaryDetails("1000000121", new HttpHeaders()));
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testInvokeRestEndpoint() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		when(restTemplate.exchange("http://www.goggle.com", HttpMethod.GET, entity, String.class))
				.thenReturn(new ResponseEntity("", header, HttpStatus.OK));
		helper.invokeRestEndpoint(HttpMethod.GET, "http://www.goggle.com", String.class, null, null, new HttpHeaders());
	}
	
	@Test(expected = DisbursementServiceException.class)
	public void testInvokeRestEndpoint_Exception() {
		helper.invokeRestEndpoint(HttpMethod.GET, "http://www.goggle.com", String.class, new HashMap<>(), null,
				new HttpHeaders());
	}

	@Test(expected = DisbursementServiceException.class)
	public void testInvokeRestEndpoint_HttpClientErrorException() {
		HttpEntity<Object> entity = new HttpEntity<>(null, null);
		when(restTemplate.exchange("http://www.goggle.com", HttpMethod.GET, entity, String.class))
				.thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));
		helper.invokeRestEndpoint(HttpMethod.GET, "http://www.goggle.com", String.class, null, null, new HttpHeaders());
	}

	@Test(expected = DisbursementServiceException.class)
	public void testInvokeRestEndpoint_HttpServerErrorException() {
		HttpEntity<Object> entity = new HttpEntity<>(null, null);
		when(restTemplate.exchange("http://www.goggle.com", HttpMethod.GET, entity, String.class))
				.thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));
		helper.invokeRestEndpoint(HttpMethod.GET, "http://www.goggle.com", String.class, null, null, new HttpHeaders());
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(expected = DisbursementServiceException.class)
	public void getProductTypeDetailsTest() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationkey", "1000000121");
		when(restTemplate.exchange("getProductTypeDetailsUrl", HttpMethod.GET, entity, String.class,params))
		.thenReturn(new ResponseEntity("{\"prodtypekey\":101,\"prodkey\":10,\"prodtypecode\":\"BFLSOLTL\",\"prodtypedesc\":\"BFL SOL Term loan\",\"displayname\":\"BFL SOL\"}", header, HttpStatus.OK));
		assertNotNull(helper.getProductTypeDetails("1000000121", new HttpHeaders()));
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test(expected = DisbursementServiceException.class)
	public void getProductTypeDetailsTest1() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationkey", "1000000121");
		when(restTemplate.exchange("getProductTypeDetailsUrl", HttpMethod.GET, entity, String.class,params))
				.thenReturn(new ResponseEntity(null, header, HttpStatus.OK));
		assertNotNull(helper.getProductTypeDetails("1000000121", new HttpHeaders()));
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void fetchBundleDetailsTest() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationid", "123");
		when(restTemplate.exchange("bundleDetailsUrl", HttpMethod.GET, entity, String.class ,params))
		.thenReturn(new ResponseEntity("[{\"applicationKey\":123,\"source\":\"EP\",\"status\":\"APPROVED\",\"bundleSelected\":true,\"bundleApplicationKey\":123}]", header, HttpStatus.OK));
		assertNotNull(helper.fetchBundleDetails("123", new HttpHeaders()));
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void fetchBundleDetailsTest1() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationid", "123");
		when(restTemplate.exchange("bundleDetailsUrl", HttpMethod.GET, entity, String.class ,params))
		.thenReturn(new ResponseEntity("[{\"applicationKey\":123,\"source\":\"JOURNEY\",\"status\":\"APPROVED\",\"bundleSelected\":true,\"bundleApplicationKey\":123}]", header, HttpStatus.OK));
		assertNotNull(helper.fetchBundleDetails("123", new HttpHeaders()));
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(expected = DisbursementServiceException.class)
	public void fetchBundleDetailsTest2() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationid", "123");
		when(restTemplate.exchange("bundleDetailsUrl", HttpMethod.GET, entity, String.class ,params))
		.thenReturn(new ResponseEntity(null, header, HttpStatus.OK));
		assertNotNull(helper.fetchBundleDetails("123", new HttpHeaders()));
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void fetchPricingDetailsTest() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationKey", "123");
		when(restTemplate.exchange("vasDetailsUrl", HttpMethod.GET, entity, String.class ,params))
		.thenReturn(new ResponseEntity("[{\"applicationKey\":123,\"source\":\"EMPLOYEE_PORTAL\",\"status\":\"APPROVED\"}]", header, HttpStatus.OK));
		assertNotNull(helper.fetchPricingDetails(123L, new HttpHeaders()));
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void fetchPricingDetailsTest1() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationKey", "123");
		when(restTemplate.exchange("vasDetailsUrl", HttpMethod.GET, entity, String.class ,params))
		.thenReturn(new ResponseEntity("[{\"applicationKey\":123,\"source\":\"JOURNEY\",\"status\":\"APPROVED\"}]", header, HttpStatus.OK));
		assertNotNull(helper.fetchPricingDetails(123L, new HttpHeaders()));
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(expected = DisbursementServiceException.class)
	public void fetchPricingDetailsTest2() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationKey", "123");
		when(restTemplate.exchange("vasDetailsUrl", HttpMethod.GET, entity, String.class ,params))
		.thenReturn(new ResponseEntity(null, header, HttpStatus.OK));
		assertNotNull(helper.fetchPricingDetails(123L, new HttpHeaders()));
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(expected = DisbursementServiceException.class)
	public void getOccupationDetailsTest() {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Object> entity = new HttpEntity<>(null, header);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationid","123");
		params.put("userattributekey","123");
		when(restTemplate.exchange("occupationDetailsUrl", HttpMethod.GET, entity, String.class ,params))
		.thenReturn(new ResponseEntity("{\"prodtypekey\":101,\"prodkey\":10,\"prodtypecode\":\"BFLSOLTL\",\"prodtypedesc\":\"BFL SOL Term loan\",\"displayproductname\":\"BFL SOL\"}", header, HttpStatus.OK));
		helper.getOccupationDetails(new GlobalDataBean(), new HttpHeaders());
	}
	
}
