package com.bajaj.markets.credit.disbursement.consumer.service.impl;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.AddressInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCustomerPennantRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.ExtendedDetailBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ExtendedFieldBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FeeDetailsBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.UserProfile;
import com.bajaj.markets.credit.disbursement.consumer.bean.VasBean;
import com.bajaj.markets.credit.disbursement.consumer.data.DataPopulator;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;


@SpringBootTest
public class VasProcessorTest {
	
	@InjectMocks
	VasProcessor vasProcessor;
	
	
	@Mock
	private BFLLoggerUtil logger;
	
	@Mock
	CustomerProcessor customerProcessor;
	
	@Mock
	DisbursementUtil disbursementUtil;
	
	@Mock
	DisbursementBusinessHelper disbursementBusinessHelper;
	
    private String bundleDetailsUrl="bundleDetailsUrl";
	
	private String vasDetailsUrl="vasDetailsUrl";
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(vasProcessor, "bundleDetailsUrl", "bundleDetailsUrl");
		ReflectionTestUtils.setField(vasProcessor, "vasDetailsUrl", "vasDetailsUrl");
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testVasDisbursementInitEventRaiseExt() {
		Mockito.when(disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn((ResponseEntity) new ResponseEntity<String>(
						"Success", HttpStatus.OK));
		String resp = vasProcessor.vasDisbursementInitEventRaiseExt("2200000000000063", new HttpHeaders());
		assertEquals("Success", resp);
	}

	@Test
	public void testVasDisbursementInitEventRaiseExt_Exception() {
		Mockito.when(disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(null);
		vasProcessor.vasDisbursementInitEventRaiseExt("2200000000000063", new HttpHeaders());
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testVasDisbursementInitEventRaiseExt_InvalidStatusException() {
		Mockito.when(disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn((ResponseEntity) new ResponseEntity<String>("", HttpStatus.BAD_REQUEST));
		vasProcessor.vasDisbursementInitEventRaiseExt("2200000000000063",new HttpHeaders());
	}
	
	@Test
	public void getVasListTest() {
		GlobalDataBean data = new GlobalDataBean();
		List<FeeDetailsBean> feeDetailslst=new ArrayList<FeeDetailsBean>();
		String pennantDt="12-12-2020";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		data.setHeaders(headers);
		data.setApplicationKey("123");
		data.setApplicantKey("123");
		fetchbundleDetails();
		fetchVASDetails();
		fetchCif();
		getUserProf();
		CreateCustomerPennantRequest cp =new CreateCustomerPennantRequest();
		List<AddressInfo> addressList = new ArrayList<AddressInfo>();
		AddressInfo info = new AddressInfo();
		info.setAddrType("50");
	    info.setAddrLine1("Test");
	    info.setCity("Test");
	    info.setCountry("Test");
	    info.setState("Test");
	    info.setPinCode("123");
	    addressList.add(info);
		cp.setAddresses(addressList);
		Mockito.when(customerProcessor.fetchCustomerPennantRequestForSOL(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any()))
				.thenReturn(cp);
		getGender();
		assertNotNull(vasProcessor.getVasList(data,feeDetailslst,pennantDt));
	}
	
	@Test
	public void getVasListTest2() {
		GlobalDataBean data = new GlobalDataBean();
		List<FeeDetailsBean> feeDetailslst=new ArrayList<FeeDetailsBean>();
		String pennantDt="12-12-2020";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		data.setHeaders(headers);
		data.setL3ProductCode("VASFFR01");
		data.setHeaders(headers);
		data.setApplicationKey("123");
		data.setApplicantKey("123");
		fetchbundleDetails2();
		fetchVASDetails2();
		fetchCif();
		CreateCustomerPennantRequest cp =new CreateCustomerPennantRequest();
		List<AddressInfo> addressList = new ArrayList<AddressInfo>();
		AddressInfo info = new AddressInfo();
		info.setAddrType("50");
	    info.setAddrLine1("Test");
	    info.setCity("Test");
	    info.setCountry("Test");
	    info.setState("Test");
	    info.setPinCode("123");
	    addressList.add(info);
		cp.setAddresses(addressList);
		Mockito.when(customerProcessor.fetchCustomerPennantRequestForSOL(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any()))
				.thenReturn(cp);
		getUserProf();
		getGender();
		assertNotNull(vasProcessor.getVasList(data,feeDetailslst,pennantDt));
	}
	
	@Test
	public void mapInsuranceFieldsTest() {
		GlobalDataBean data = new GlobalDataBean();
		List<ExtendedDetailBean> vasExtendedDetailList = new ArrayList<ExtendedDetailBean>();
		List<ExtendedFieldBean> vasExtendedFieldList= new ArrayList<ExtendedFieldBean>();
		ExtendedDetailBean extendedDetailBean=new ExtendedDetailBean();
		VasBean vas = new VasBean();
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		data.setHeaders(headers);
		data.setApplicationKey("123");
		data.setApplicantKey("123");
		data.setL3ProductCode("VASFFR01");
		fetchCif();
		getUserProf();
		CreateCustomerPennantRequest cp =new CreateCustomerPennantRequest();
		List<AddressInfo> addressList = new ArrayList<AddressInfo>();
		AddressInfo info = new AddressInfo();
		info.setAddrType("50");
	    info.setAddrLine1("Test");
	    info.setCity("Test");
	    info.setCountry("Test");
	    info.setState("Test");
	    info.setPinCode("123");
	    addressList.add(info);
		cp.setAddresses(addressList);
		Mockito.when(customerProcessor.fetchCustomerPennantRequestForSOL(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any()))
				.thenReturn(cp);
		getGender();
		vasProcessor.mapInsuranceFields(vasExtendedDetailList, vasExtendedFieldList, extendedDetailBean, vas, data);
	}
	
	
	@SuppressWarnings("unchecked")
	public void fetchCif() {
		when(disbursementUtil.fetchCifId(Mockito.any(), Mockito.any())).thenReturn("1");	

		}
	
	@SuppressWarnings("unchecked")
	public void getUserProf() {
		List<UserProfile> userProfileList  = new ArrayList<UserProfile>();
		UserProfile us = new UserProfile();
		us.setApplicationKey("123");
		us.setApplicationUserAttributeKey("1");
		us.setApplicationUserAttributeType("1");
		userProfileList.add(us);
		when(disbursementUtil.getUserDetails(Mockito.any(), Mockito.any())).thenReturn(userProfileList);	

		}
	
	@SuppressWarnings("unchecked")
	public void getGender() {
		List<UserProfile> userProfileList  = new ArrayList<UserProfile>();
		when(disbursementUtil.fetchGenderDescDetails(Mockito.any(), Mockito.any())).thenReturn("1");	

		}
	@SuppressWarnings("unchecked")
	public void fetchbundleDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(bundleDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("[{\"applicationKey\":123,\"source\":\"EP\",\"status\":\"APPROVED\",\"bundleSelected\":true,\"bundleApplicationKey\":123}]", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void fetchVASDetails() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(vasDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("[{\"applicationKey\":123,\"source\":\"EMPLOYEE_PORTAL\",\"status\":\"APPROVED\"}]", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void fetchbundleDetails2() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(bundleDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("[{\"applicationKey\":123,\"source\":\"JOURNEY\",\"status\":\"APPROVED\",\"bundleSelected\":true,\"bundleApplicationKey\":123}]", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void fetchVASDetails2() {
		when((ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(vasDetailsUrl), Mockito.any(), Mockito.any(),Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity<String>("[{\"applicationKey\":123,\"source\":\"JOURNEY\",\"status\":\"APPROVED\"}]", HttpStatus.OK));	

		}
	
	@SuppressWarnings("unchecked")
	public void mapAddressTest() {
		GlobalDataBean data = new GlobalDataBean();
		data.setApplicationKey("123");		
		data.setL2ProductKey(1l);
		data.setL3ProductKey(1l);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("authtoken","authtoken");
		headers.put("cmptcorrid","cmptcorrid");
		headers.put("guardtoken","guardtoken");
		data.setHeaders(headers);
		CreateCustomerPennantRequest cp =new CreateCustomerPennantRequest();
		List<AddressInfo> addressList = new ArrayList<AddressInfo>();
		AddressInfo info = new AddressInfo();
		info.setAddrType("50");
	    info.setAddrLine1("Test");
	    info.setCity("Test");
	    info.setCountry("Test");
	    info.setState("Test");
	    info.setPinCode("123");
	    addressList.add(info);
		cp.setAddresses(addressList);
		Mockito.when(customerProcessor.fetchCustomerPennantRequestForSOL(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any()))
				.thenReturn(cp);
		vasProcessor.mapAddress(data);
		}
	
	@Test
	public void getVasListForFundedTest() {
		GlobalDataBean data = new GlobalDataBean();
		data.setApplicationKey("123");		
		data.setL2ProductKey(1l);
		data.setL3ProductKey(1l);
		List<FeeDetailsBean> feeDetailslst=new ArrayList<FeeDetailsBean>();
		FeeDetailsBean fee=new FeeDetailsBean();
		feeDetailslst.add(fee);
		vasProcessor.getVasListForFunded(data, feeDetailslst, "", DataPopulator.fetchRequestForFunded());
	}
}