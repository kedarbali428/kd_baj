package com.bajaj.markets.credit.disbursement.consumer.bean;


import java.util.List;

public class Loan {

	private List<FinanceBean> finances;

	public List<FinanceBean> getFinances() {
		return finances;
	}

	public void setFinances(List<FinanceBean> finances) {
		this.finances = finances;
	}
	
	
	
}