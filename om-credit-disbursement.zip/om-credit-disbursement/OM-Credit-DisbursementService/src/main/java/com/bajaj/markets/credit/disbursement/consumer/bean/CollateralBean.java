/**
 * 
 */
package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

/**
 * @author pranoti.pandole
 *
 */
public class CollateralBean {
	private String collateralRef;
	private BigDecimal assignPerc;
	public String getCollateralRef() {
		return collateralRef;
	}
	public void setCollateralRef(String collateralRef) {
		this.collateralRef = collateralRef;
	}
	public BigDecimal getAssignPerc() {
		return assignPerc;
	}
	public void setAssignPerc(BigDecimal assignPerc) {
		this.assignPerc = assignPerc;
	}
	
	
}
