package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class CreateLoanExternalRequest {

	private String finReference;
	private FinanceScheduleBean financeSchedule;
	private List<DisbursementBean> disbursement;// Done
	private MandateBean mandateDetail;
	private List<DocumentInfoBean> documents;
	private List<CollateralBean> collaterals;
	private Boolean stp;
	private String processStage;
	private BeneficiaryBean beneficiary;
	private GstDetailBean gstDetail;
	private List<CoapplicantBean> coApplicants;
	private FundingDetails imd;

	public String getFinReference() {
		return finReference;
	}

	public void setFinReference(String finReference) {
		this.finReference = finReference;
	}

	public FinanceScheduleBean getFinanceSchedule() {
		return financeSchedule;
	}

	public void setFinanceSchedule(FinanceScheduleBean financeSchedule) {
		this.financeSchedule = financeSchedule;
	}

	public List<DisbursementBean> getDisbursement() {
		return disbursement;
	}

	public void setDisbursement(List<DisbursementBean> disbursement) {
		this.disbursement = disbursement;
	}

	public MandateBean getMandateDetail() {
		return mandateDetail;
	}

	public void setMandateDetail(MandateBean mandateDetail) {
		this.mandateDetail = mandateDetail;
	}

	public List<DocumentInfoBean> getDocuments() {
		return documents;
	}

	public void setDocuments(List<DocumentInfoBean> documents) {
		this.documents = documents;
	}

	public List<CollateralBean> getCollaterals() {
		return collaterals;
	}

	public void setCollaterals(List<CollateralBean> collaterals) {
		this.collaterals = collaterals;
	}

	public Boolean getStp() {
		return stp;
	}

	public void setStp(Boolean stp) {
		this.stp = stp;
	}

	public String getProcessStage() {
		return processStage;
	}

	public void setProcessStage(String processStage) {
		this.processStage = processStage;
	}

	public BeneficiaryBean getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(BeneficiaryBean beneficiary) {
		this.beneficiary = beneficiary;
	}

	public GstDetailBean getGstDetail() {
		return gstDetail;
	}

	public void setGstDetail(GstDetailBean gstDetail) {
		this.gstDetail = gstDetail;
	}

	public List<CoapplicantBean> getCoApplicants() {
		return coApplicants;
	}

	public void setCoApplicants(List<CoapplicantBean> list) {
		this.coApplicants = list;
	}

	public FundingDetails getImd() {
		return imd;
	}

	public void setImd(FundingDetails imd) {
		this.imd = imd;
	}

}
