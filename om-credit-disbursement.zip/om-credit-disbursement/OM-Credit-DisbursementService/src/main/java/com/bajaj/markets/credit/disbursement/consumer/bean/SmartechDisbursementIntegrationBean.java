package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

public class SmartechDisbursementIntegrationBean {

	private String activityid;
	
	private String identity;
	
	@JsonProperty("activity_params")
	private List<SmartechDisbursementNotificationDetailsBean> activityParams;

	public String getActivityid() {
		return activityid;
	}

	public void setActivityid(String activityid) {
		this.activityid = activityid;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public List<SmartechDisbursementNotificationDetailsBean> getActivityParams() {
		return activityParams;
	}

	public void setActivityParams(List<SmartechDisbursementNotificationDetailsBean> activityParams) {
		this.activityParams = activityParams;
	}

	@Override
	public String toString() {
		return "DispositionNotificationeEventBean [activityid=" + activityid + ", identity=" + identity
				+ ", activityParams=" + activityParams + "]";
	}

}
