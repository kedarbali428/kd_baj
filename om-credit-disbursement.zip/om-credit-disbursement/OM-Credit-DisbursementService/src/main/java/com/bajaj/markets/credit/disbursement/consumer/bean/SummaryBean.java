package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class SummaryBean {

	private BigDecimal firstEmiAmount;
	
	private String firstDisbDate;

	public BigDecimal getFirstEmiAmount() {
		return firstEmiAmount;
	}

	public void setFirstEmiAmount(BigDecimal firstEmiAmount) {
		this.firstEmiAmount = firstEmiAmount;
	}

	public String getFirstDisbDate() {
		return firstDisbDate;
	}

	public void setFirstDisbDate(String firstDisbDate) {
		this.firstDisbDate = firstDisbDate;
	}

	
}
