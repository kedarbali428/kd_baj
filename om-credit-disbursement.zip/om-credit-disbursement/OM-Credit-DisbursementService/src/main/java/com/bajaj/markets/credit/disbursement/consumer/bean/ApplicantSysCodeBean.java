package com.bajaj.markets.credit.disbursement.consumer.bean;

public class ApplicantSysCodeBean {

	private Long applicantKey;

	private String refCode;

	private String pennantCode;

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getRefCode() {
		return refCode;
	}

	public void setRefCode(String refCode) {
		this.refCode = refCode;
	}

	public String getPennantCode() {
		return pennantCode;
	}

	public void setPennantCode(String pennantCode) {
		this.pennantCode = pennantCode;
	}
}
