package com.bajaj.markets.credit.disbursement.consumer.bean;

public class DocumentInfo {

	private String docCategory;
	private String custDocTitle;
	private String custDocIssuedCountry;
	private String docPurpose;
	private String docName;
	private String docFormat;
	private String custDocExpDate;
	private String custDocIssuedOn;
	private String custDocIssuedAuth;
	private String docRefId;
	
	public String getDocCategory() {
		return docCategory;
	}
	public void setDocCategory(String docCategory) {
		this.docCategory = docCategory;
	}
	public String getCustDocTitle() {
		return custDocTitle;
	}
	public void setCustDocTitle(String custDocTitle) {
		this.custDocTitle = custDocTitle;
	}
	public String getCustDocIssuedCountry() {
		return custDocIssuedCountry;
	}
	public void setCustDocIssuedCountry(String custDocIssuedCountry) {
		this.custDocIssuedCountry = custDocIssuedCountry;
	}
	public String getDocPurpose() {
		return docPurpose;
	}
	public void setDocPurpose(String docPurpose) {
		this.docPurpose = docPurpose;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDocFormat() {
		return docFormat;
	}
	public void setDocFormat(String docFormat) {
		this.docFormat = docFormat;
	}
	public String getCustDocExpDate() {
		return custDocExpDate;
	}
	public void setCustDocExpDate(String custDocExpDate) {
		this.custDocExpDate = custDocExpDate;
	}
	public String getCustDocIssuedOn() {
		return custDocIssuedOn;
	}
	public void setCustDocIssuedOn(String custDocIssuedOn) {
		this.custDocIssuedOn = custDocIssuedOn;
	}
	public String getCustDocIssuedAuth() {
		return custDocIssuedAuth;
	}
	public void setCustDocIssuedAuth(String custDocIssuedAuth) {
		this.custDocIssuedAuth = custDocIssuedAuth;
	}
	public String getDocRefId() {
		return docRefId;
	}
	public void setDocRefId(String docRefId) {
		this.docRefId = docRefId;
	}
}
