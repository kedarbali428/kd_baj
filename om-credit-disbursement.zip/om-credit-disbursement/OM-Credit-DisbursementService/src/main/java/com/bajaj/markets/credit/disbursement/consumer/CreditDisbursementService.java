package  com.bajaj.markets.credit.disbursement.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.retry.annotation.EnableRetry;

@SpringBootApplication
@RefreshScope
@ComponentScan(basePackages = "com.bajaj.*")
@EnableRetry
@EnableAutoConfiguration(exclude={MongoAutoConfiguration.class})
public class CreditDisbursementService {
	
    public static void main(String[] args){
    	SpringApplication.run(CreditDisbursementService.class, args);
    }
 
}