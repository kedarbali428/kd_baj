package com.bajaj.markets.credit.disbursement.consumer.bean;

public class DocumentInfoBean {
	
	private String docCategory;

	public String getDocCategory() {
		return docCategory;
	}
	public void setDocCategory(String docCategory) {
		this.docCategory = docCategory;
	}
	
}
