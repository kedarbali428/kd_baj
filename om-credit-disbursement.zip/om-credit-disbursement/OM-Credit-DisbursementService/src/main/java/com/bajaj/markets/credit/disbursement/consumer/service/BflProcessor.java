package com.bajaj.markets.credit.disbursement.consumer.service;

import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;

/**
 * @author pranoti.pandole
 *
 */

public abstract class BflProcessor {
public abstract void createCustomer(GlobalDataBean data);
public abstract void createBeneficiary(GlobalDataBean data);
public abstract void createCollateral(GlobalDataBean data);
public abstract void createLoan(GlobalDataBean data);
}
