package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FundedMandateDetails {

	private String mandateRef;
	private String mandateType;
	private String ifsc;
	private String micr;
	private String accType;
	private String accNumber;
	private String accHolderName;
	private Boolean openMandate;
	private String startDate;
	private String expiryDate;
	private BigDecimal maxLimit;
  	@JsonProperty("subRepayMode")
	private String subRepayMode;
	private String existingMandate;

	public String getMandateRef() {
		return mandateRef;
	}

	public void setMandateRef(String mandateRef) {
		this.mandateRef = mandateRef;
	}

	public String getMandateType() {
		return mandateType;
	}

	public void setMandateType(String mandateType) {
		this.mandateType = mandateType;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getMicr() {
		return micr;
	}

	public void setMicr(String micr) {
		this.micr = micr;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public Boolean getOpenMandate() {
		return openMandate;
	}

	public void setOpenMandate(Boolean openMandate) {
		this.openMandate = openMandate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public BigDecimal getMaxLimit() {
		return maxLimit;
	}

	public void setMaxLimit(BigDecimal maxLimit) {
		this.maxLimit = maxLimit;
	}

	public String getSubrepaymode() {
		return subRepayMode;
	}

	public void setSubrepaymode(String subrepaymode) {
		this.subRepayMode = subrepaymode;
	}

	public String getExistingMandate() {
		return existingMandate;
	}

	public void setExistingMandate(String existingMandate) {
		this.existingMandate = existingMandate;
	}

}
