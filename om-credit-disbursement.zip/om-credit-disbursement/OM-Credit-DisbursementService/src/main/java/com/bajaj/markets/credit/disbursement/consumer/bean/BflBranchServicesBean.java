package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.Date;

public class BflBranchServicesBean {

private Long bflbranchservicekey;
	
    private Long prodcatkey;
    
    private Long prodkey;
    
    private Long occupationkey;
    
    private Long bflbranchkey;
    
    private Long citykey;
    
    private Integer bflserviceflg;
    
    private Integer bfsdserviceflg;
    
    private Integer isactive;
    
    private Long lstupdateby;
    
    private Date lstupdatedt;

	public Long getBflbranchservicekey() {
		return bflbranchservicekey;
	}

	public void setBflbranchservicekey(Long bflbranchservicekey) {
		this.bflbranchservicekey = bflbranchservicekey;
	}

	public Long getProdcatkey() {
		return prodcatkey;
	}

	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public Long getOccupationkey() {
		return occupationkey;
	}

	public void setOccupationkey(Long occupationkey) {
		this.occupationkey = occupationkey;
	}

	public Long getBflbranchkey() {
		return bflbranchkey;
	}

	public void setBflbranchkey(Long bflbranchkey) {
		this.bflbranchkey = bflbranchkey;
	}

	public Long getCitykey() {
		return citykey;
	}

	public void setCitykey(Long citykey) {
		this.citykey = citykey;
	}

	public Integer getBflserviceflg() {
		return bflserviceflg;
	}

	public void setBflserviceflg(Integer bflserviceflg) {
		this.bflserviceflg = bflserviceflg;
	}

	public Integer getBfsdserviceflg() {
		return bfsdserviceflg;
	}

	public void setBfsdserviceflg(Integer bfsdserviceflg) {
		this.bfsdserviceflg = bfsdserviceflg;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Date getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Date lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
    
    
    
}
