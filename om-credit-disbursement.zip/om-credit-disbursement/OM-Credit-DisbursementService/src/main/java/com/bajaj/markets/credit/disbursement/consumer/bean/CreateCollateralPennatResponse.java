package com.bajaj.markets.credit.disbursement.consumer.bean;

public class CreateCollateralPennatResponse {
	private String collateralRef;
	private ReturnStatusBean returnStatus;
	public String getCollateralRef() {
		return collateralRef;
	}
	public void setCollateralRef(String collateralRef) {
		this.collateralRef = collateralRef;
	}
	public ReturnStatusBean getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(ReturnStatusBean returnStatus) {
		this.returnStatus = returnStatus;
	}
}
