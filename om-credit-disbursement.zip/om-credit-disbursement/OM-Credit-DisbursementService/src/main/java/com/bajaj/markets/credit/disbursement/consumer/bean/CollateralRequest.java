package com.bajaj.markets.credit.disbursement.consumer.bean;

public class CollateralRequest {

	private Long applicationId;
	private String collateralRefNum;
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public String getCollateralRefNum() {
		return collateralRefNum;
	}
	public void setCollateralRefNum(String collateralRefNum) {
		this.collateralRefNum = collateralRefNum;
	}
}
