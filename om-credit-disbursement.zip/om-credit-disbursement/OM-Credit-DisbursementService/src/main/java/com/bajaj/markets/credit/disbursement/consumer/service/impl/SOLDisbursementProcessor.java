/**
 * 
 */
package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.service.BflProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.DisbursementProcessor;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.LMSHelper;
import com.google.gson.Gson;

/**
 * @author pranoti.pandole
 *
 */
@Component("SOLDisbursementProcessor")
public class SOLDisbursementProcessor extends BflProcessor implements DisbursementProcessor {

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Value("${api.omcreditapplicationservice.getDisbError.GET.url}")
	private String getDisbErrorUrl;
	
	@Value("${erroScenarioFlg}")
	private String erroScenarioFlg;

	
	@Autowired
	DisbursementUtil disbursementUtil;

	@Autowired
	LMSHelper lmsHelper;

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	LoanProcessor loanProcessor;

	@Autowired
	BeneficiaryProcessor beneficiaryProcessor;

	@Autowired
	CustomerProcessor customerProcessor;

	@Autowired
	CollateralProcessor collateralProcessor;
	
	@Autowired
	@Qualifier("SOLErrorHandlingProcessor")
	SOLErrorHandlingProcessor sOLErrorHandlingProcessor;
	
	

	private static final String CLASS_NAME = SOLDisbursementProcessor.class.getCanonicalName();

	@Override
	public void processDisbursement(DisbursementEventRequestBean request) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  SOLProcessor processDisbursement ApplicationID: " + request.getApplicationId());
		GlobalDataBean data = new GlobalDataBean();
		data.setApplicationKey(request.getApplicationId());
		data.setHeaders(request.getHeaders());
		if (prechecks(data)) {
			if ("Y".equals(erroScenarioFlg)) {
				DisbursementTrackerBean disbursementTrackerBean = fetchDisbursementErrorDetails(data);
				if (null != disbursementTrackerBean.getDisbursmentstage()) {
					sOLErrorHandlingProcessor.processSOLDisbursementErrors(request);
				}else {
					createCustomer(data);
					createBeneficiary(data);
					createCollateral(data);
					createLoan(data);	
				}
			} else {
				createCustomer(data);
				createBeneficiary(data);
				createCollateral(data);
				createLoan(data);
			}
		}
	}
	
	


	@Override
	public Boolean prechecks(GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  SOLProcessor prechecks ApplicationID: " + data.getApplicationKey());
		Boolean precheckflg = false;
		try {
		
		Boolean isvalidRequest = disbursementUtil.validateRequest(data);
		if (isvalidRequest)
			disbursementUtil.mapGlobalData(disbursementUtil.fetchApplicationDetails(data),data);
		DisbursementEventRequestBean disbursementEventRequestBean = new DisbursementEventRequestBean();
		disbursementEventRequestBean.setApplicantId(data.getApplicantKey());
		disbursementEventRequestBean.setApplicationId(data.getApplicationKey());
		disbursementEventRequestBean.setEventType("DISBURSEMENT_INITIATED");
		disbursementEventRequestBean.setProductCode(data.getL3ProductCode());
		disbursementEventRequestBean.setHeaders(data.getHeaders());
		boolean eventflg =disbursementUtil.raiseEvent(disbursementEventRequestBean,DisbursementConstants.DISBURSEMENT_INITIATED);
		if (eventflg)
			precheckflg = true;
		}catch(Exception e) {
			saveDisbursementError(data, data.getApplicationKey());
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CDS-001", "Prechecks Failed"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside  SOLProcessor precheckflg ApplicationID: "
				+ data.getApplicationKey() + " precheckflg :" + precheckflg);
		return precheckflg;
	}

	private void saveDisbursementError(GlobalDataBean data, String applicationId) {
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		disbursementTrackerBean.setApplicationId(Long.parseLong(applicationId));
		disbursementTrackerBean.setDisbursmentstage(DisbursementConstants.CREATE_CUSTOMER);
		disbursementTrackerBean.setError(DisbursementConstants.CREATE_CUSTOMER_FAILED);
		disbursementTrackerBean.setErrorreason("");
		disbursementTrackerBean.setErrorretryable(1l);
		disbursementTrackerBean.setIsActive(1l);
		disbursementTrackerBean.setStatus("CREATED");
		disbursementUtil.saveDisbursementErrorDetails(data,disbursementTrackerBean);
	}
	public void createCustomer(GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  SOLProcessor createCustomer ApplicationID: " + data.getApplicationKey());
		customerProcessor.processCustomerRequestForSOL(data);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End of  SOLProcessor createCustomer ApplicationID: " + data.getApplicationKey());
	}

	public void createBeneficiary(GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside SOLProcessor createBeneficiary  ApplicationID: " + data.getApplicationKey());
		beneficiaryProcessor.processBeneficiaryRequest(data);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End of SOLProcessor createBeneficiary  ApplicationID: " + data.getApplicationKey());
	}

	public void createCollateral(GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside SOLProcessor createCollateral  ApplicationID: " + data.getApplicationKey());
		collateralProcessor.processCollateralRequest(data);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End of SOLProcessor createCollateral  ApplicationID: " + data.getApplicationKey());
	}

	public void createLoan(GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  SOLProcessor createLoan ApplicationID: " + data.getApplicationKey());
		loanProcessor.processLoanRequest(data);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End of  SOLProcessor createLoan ApplicationID: " + data.getApplicationKey());

	}

	@SuppressWarnings("unchecked")
	public DisbursementTrackerBean fetchDisbursementErrorDetails(GlobalDataBean appInfo) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  fetchDisbursementErrorDetails: " + appInfo.getApplicationKey());
		List<TranchBean> trnchLst = loanProcessor.fetchTranchDetails(appInfo.getApplicationKey(),
				loanProcessor.generateHeaders(appInfo));
		Long activeTranchKey = trnchLst.get(0).getTranchkey();
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  fetchDisbursementErrorDetails Starts for tranch: " + activeTranchKey);
		Map<String, String> params = new HashMap<>();
		params.put("tranchKey", activeTranchKey.toString());
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(
				HttpMethod.GET, getDisbErrorUrl, String.class, params, null, loanProcessor.generateHeaders(appInfo));
		Gson gson = new Gson();
		List<DisbursementTrackerBean> disbursementTrackerBeanLst = new ArrayList<DisbursementTrackerBean>();
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				DisbursementTrackerBean[] list = gson.fromJson(excuteRestCall.getBody().toString(),
						DisbursementTrackerBean[].class);
				disbursementTrackerBeanLst.addAll(Arrays.asList(list));
				if(!disbursementTrackerBeanLst.isEmpty())
				return disbursementTrackerBeanLst.get(0);
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchDisbursementErrorDetails .");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  fetchDisbursementErrorDetails Ends for tranch: " + activeTranchKey);
		return disbursementTrackerBean;
	}

}
