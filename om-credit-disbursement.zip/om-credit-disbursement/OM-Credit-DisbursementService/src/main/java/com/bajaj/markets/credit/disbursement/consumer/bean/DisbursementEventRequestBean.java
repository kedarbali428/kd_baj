/**
 * 
 */
package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.io.Serializable;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author pranoti.pandole
 *
 */
 @JsonIgnoreProperties(ignoreUnknown = true)
public class DisbursementEventRequestBean  implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String applicationId;
	private String applicantId;
	private String productCode;
	private String productCategory;
	private String disbursmentKey;
	private String eventType;
	private Map<String, String> headers;
	private String principalName;
	
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public void setDisbursmentKey(String disbursmentKey) {
		this.disbursmentKey = disbursmentKey;
	}
	
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getProductCode() {
		return productCode;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public Map<String, String> getHeaders() {
		return headers;
	}
	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}
	public String getApplicationId() {
		return applicationId;
	}
	public String getPrincipalName() {
		return principalName;
	}
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}
	public String getApplicantId() {
		return applicantId;
	}
	public String getDisbursmentKey() {
		return disbursmentKey;
	}
	
	
	

}
