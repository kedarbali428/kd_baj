package com.bajaj.markets.credit.disbursement.consumer.bean;

public class BflErrorProcessorVariables {

	private boolean errorFlag;

	public boolean isErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(boolean errorFlag) {
		this.errorFlag = errorFlag;
	}

}
