package com.bajaj.markets.credit.disbursement.consumer.bean;

public class CustomerDetailsMasterDetails {

	private String salutationcode;
	
	private String langcode;
	
	private String nationalitycode;
	
	private String accounttypecode;
	
	public String getAccounttypecode() {
		return accounttypecode;
	}

	public void setAccounttypecode(String accounttypecode) {
		this.accounttypecode = accounttypecode;
	}

	public String getNationalitycode() {
		return nationalitycode;
	}

	public void setNationalitycode(String nationalitycode) {
		this.nationalitycode = nationalitycode;
	}

	public String getLangcode() {
		return langcode;
	}

	public void setLangcode(String langcode) {
		this.langcode = langcode;
	}

	public String getSalutationcode() {
		return salutationcode;
	}

	public void setSalutationcode(String salutationcode) {
		this.salutationcode = salutationcode;
	}
	
	
}
