package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class MandateSchedule {

	private String repaymentRefKey;
	
	private boolean isRecurring;
	
	private String frequency;
	
	private String firstCollectionDate;
	
	private String status;
	
	private Integer numberOfPayments;
	
	private BigDecimal ammount;
	
	private String validThrough;
	
	private ProductInfo productInfo;
	
	public boolean getIsRecurring() {
		return isRecurring;
	}
	public void setIsRecurring(boolean isRecurring) {
		this.isRecurring = isRecurring;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getFirstCollectionDate() {
		return firstCollectionDate;
	}
	public void setFirstCollectionDate(String firstCollectionDate) {
		this.firstCollectionDate = firstCollectionDate;
	}
	public Integer getNumberOfPayments() {
		return numberOfPayments;
	}
	public void setNumberOfPayments(Integer numberOfPayments) {
		this.numberOfPayments = numberOfPayments;
	}
	public BigDecimal getAmmount() {
		return ammount;
	}
	public void setAmmount(BigDecimal ammount) {
		this.ammount = ammount;
	}
	public String getValidThrough() {
		return validThrough;
	}
	public void setValidThrough(String validThrough) {
		this.validThrough = validThrough;
	}
	public ProductInfo getProductInfo() {
		return productInfo;
	}
	public void setProductInfo(ProductInfo productInfo) {
		this.productInfo = productInfo;
	}
	
	public String getRepaymentRefKey() {
		return repaymentRefKey;
	}
	public void setRepaymentRefKey(String repaymentRefKey) {
		this.repaymentRefKey = repaymentRefKey;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "RepaymentSchedule [repaymentRefKey=" + repaymentRefKey + ", isRecurring=" + isRecurring + ", frequency="
				+ frequency + ", firstCollectionDate=" + firstCollectionDate + ", status=" + status
				+ ", numberOfPayments=" + numberOfPayments + ", ammount=" + ammount + ", validThrough=" + validThrough
				+ ", productInfo=" + productInfo + "]";
	}

}


