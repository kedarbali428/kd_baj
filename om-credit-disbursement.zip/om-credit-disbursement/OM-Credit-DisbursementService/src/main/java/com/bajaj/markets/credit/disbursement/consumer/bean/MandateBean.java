package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class MandateBean {
	
	private String cif;
	private Boolean useExisting;
	private BigDecimal mandateID;
	private String mandateRef;
	private String mandateType;
	private String ifsc;
	private String micr;
	private String accType;
	private String accNumber;
	private String accHolderName;
	private Boolean openMandate;
	private String startDate;
	private String expiryDate;
	private BigDecimal maxLimit;
	private String periodicity;
	private String status;
	private Boolean active;
	private String barCodeNumber;
	private Boolean externalMandate;
	private String eMandateRefNo;
	private String eMandateSource;
	
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public Boolean getUseExisting() {
		return useExisting;
	}
	public void setUseExisting(Boolean useExisting) {
		this.useExisting = useExisting;
	}
	public BigDecimal getMandateID() {
		return mandateID;
	}
	public void setMandateID(BigDecimal mandateID) {
		this.mandateID = mandateID;
	}
	public String getMandateRef() {
		return mandateRef;
	}
	public void setMandateRef(String mandateRef) {
		this.mandateRef = mandateRef;
	}
	public String getMandateType() {
		return mandateType;
	}
	public void setMandateType(String mandateType) {
		this.mandateType = mandateType;
	}
	
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getMicr() {
		return micr;
	}
	public void setMicr(String micr) {
		this.micr = micr;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	public String getAccHolderName() {
		return accHolderName;
	}
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	
	public Boolean getOpenMandate() {
		return openMandate;
	}
	public void setOpenMandate(Boolean openMandate) {
		this.openMandate = openMandate;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public BigDecimal getMaxLimit() {
		return maxLimit;
	}
	public void setMaxLimit(BigDecimal maxLimit) {
		this.maxLimit = maxLimit;
	}
	public String getPeriodicity() {
		return periodicity;
	}
	public void setPeriodicity(String periodicity) {
		this.periodicity = periodicity;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBarCodeNumber() {
		return barCodeNumber;
	}
	public void setBarCodeNumber(String barCodeNumber) {
		this.barCodeNumber = barCodeNumber;
	}
	public Boolean getExternalMandate() {
		return externalMandate;
	}
	public void setExternalMandate(Boolean externalMandate) {
		this.externalMandate = externalMandate;
	}
	/**
	 * @return the eMandateRefNo
	 */
	public String geteMandateRefNo() {
		return eMandateRefNo;
	}
	/**
	 * @param eMandateRefNo the eMandateRefNo to set
	 */
	public void seteMandateRefNo(String eMandateRefNo) {
		this.eMandateRefNo = eMandateRefNo;
	}
	
	public String geteMandateSource() {
		return eMandateSource;
	}
	public void seteMandateSource(String eMandateSource) {
		this.eMandateSource = eMandateSource;
	}
	
}
