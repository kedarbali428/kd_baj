/**
 * 
 */
package com.bajaj.markets.credit.disbursement.consumer.util;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;

/**
 * @author pranoti.pandole
 *
 */
@Aspect
@Configuration
public class DisbursementLoggerAspect {
@Autowired
BFLLoggerUtil logger;

private static final String CLASS_NAME = DisbursementLoggerAspect.class.getName();

@Before(" execution(* com.bajaj.markets.credit.disbursement.consumer.*.*.*.*(..))")
public void before(JoinPoint joinPoint) {
	String className = joinPoint.getSignature().getDeclaringTypeName();
	String methodName = joinPoint.getSignature().getName();
	logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,"BEFORE Execution of :- "+className+" ##################### Method ###################### :-  "+methodName );
}

@After(" execution(* com.bajaj.markets.credit.disbursement.consumer.*.*.*.*(..))")
public void after(JoinPoint joinPoint) {
	String className = joinPoint.getSignature().getDeclaringTypeName();
	String methodName = joinPoint.getSignature().getName();
	logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,"AFTER Execution of :- "+className+" ######################### Method ########################### :-  "+methodName );
}

@AfterThrowing (pointcut = "execution(* com.bajaj.markets.credit.disbursement.consumer.*.*.*.*(..)))", throwing = "ex")
public void logAfterThrowingAllMethods(Exception ex) throws Throwable 
{
	logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,"*****************Exception Dtetails ******** "+ ex);
}


}
