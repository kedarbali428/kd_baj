package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class ArcduedateInput {
	private Long childApplicationId;
	private Long parentApplicationId;
	private String omL2Product;
	private String omL3Product;
	private String omL4Product;
	private String source;
	private String purpose;
	private Integer  tenor;
	private List<OfferDetailsBRE> offerDetails;
	public Long getChildApplicationId() {
		return childApplicationId;
	}
	public void setChildApplicationId(Long childApplicationId) {
		this.childApplicationId = childApplicationId;
	}
	public Long getParentApplicationId() {
		return parentApplicationId;
	}
	public void setParentApplicationId(Long parentApplicationId) {
		this.parentApplicationId = parentApplicationId;
	}
	public String getOmL2Product() {
		return omL2Product;
	}
	public void setOmL2Product(String omL2Product) {
		this.omL2Product = omL2Product;
	}
	public String getOmL3Product() {
		return omL3Product;
	}
	public void setOmL3Product(String omL3Product) {
		this.omL3Product = omL3Product;
	}
	public String getOmL4Product() {
		return omL4Product;
	}
	public void setOmL4Product(String omL4Product) {
		this.omL4Product = omL4Product;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public Integer getTenor() {
		return tenor;
	}
	public void setTenor(Integer tenor) {
		this.tenor = tenor;
	}
	public List<OfferDetailsBRE> getOfferDetails() {
		return offerDetails;
	}
	public void setOfferDetails(List<OfferDetailsBRE> offerDetails) {
		this.offerDetails = offerDetails;
	}

}
