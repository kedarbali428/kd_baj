package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class FeeDetailsBean {
	
	private String feeCode;
	private BigDecimal feeAmount;
	private BigDecimal waiverAmount;
	private BigDecimal paidAmount;
	private String feeMethod;
	private Integer scheduleTerms;
	private String reference;
	public String getFeeCode() {
		return feeCode;
	}
	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}
	public BigDecimal getFeeAmount() {
		return feeAmount;
	}
	public void setFeeAmount(BigDecimal feeAmount) {
		this.feeAmount = feeAmount;
	}
	public BigDecimal getWaiverAmount() {
		return waiverAmount;
	}
	public void setWaiverAmount(BigDecimal waiverAmount) {
		this.waiverAmount = waiverAmount;
	}
	public BigDecimal getPaidAmount() {
		return paidAmount;
	}
	public void setPaidAmount(BigDecimal paidAmount) {
		this.paidAmount = paidAmount;
	}
	public String getFeeMethod() {
		return feeMethod;
	}
	public void setFeeMethod(String feeMethod) {
		this.feeMethod = feeMethod;
	}
	public Integer getScheduleTerms() {
		return scheduleTerms;
	}
	public void setScheduleTerms(Integer scheduleTerms) {
		this.scheduleTerms = scheduleTerms;
	}
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}

}
