package com.bajaj.markets.credit.disbursement.consumer.bean;

public class OccupationTypeVerification {
	private Reference ocupationType;
	private Verification verification;

	public Reference getOcupationType() {
		return ocupationType;
	}

	public void setOcupationType(Reference ocupationType) {
		this.ocupationType = ocupationType;
	}

	public Verification getVerification() {
		return verification;
	}

	public void setVerification(Verification verification) {
		this.verification = verification;
	}

}
