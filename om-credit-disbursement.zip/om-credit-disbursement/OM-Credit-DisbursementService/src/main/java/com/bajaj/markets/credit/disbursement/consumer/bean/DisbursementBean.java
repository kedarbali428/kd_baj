package com.bajaj.markets.credit.disbursement.consumer.bean;

public class DisbursementBean {
	
	private String disbParty;
	private String disbType;
	private String disbDate;
	private Double disbAmount;
	private String remarks;
	private String issueBank;
	private String valueDate;
	private String ifsc;
	private String accountNo;
	private String acHolderName;
	private String phoneCountryCode;
	private String phoneAreaCode;
	private String phoneNumber;
	private String partnerBankId;
	private String micr;
	
	public String getPartnerBankId() {
		return partnerBankId;
	}
	public void setPartnerBankId(String partnerBankId) {
		this.partnerBankId = partnerBankId;
	}
	public String getDisbParty() {
		return disbParty;
	}
	public void setDisbParty(String disbParty) {
		this.disbParty = disbParty;
	}
	public String getDisbType() {
		return disbType;
	}
	public void setDisbType(String disbType) {
		this.disbType = disbType;
	}
	public String getDisbDate() {
		return disbDate;
	}
	public void setDisbDate(String disbDate) {
		this.disbDate = disbDate;
	}
	public Double getDisbAmount() {
		return disbAmount;
	}
	public void setDisbAmount(Double disbAmount) {
		this.disbAmount = disbAmount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getIssueBank() {
		return issueBank;
	}
	public void setIssueBank(String issueBank) {
		this.issueBank = issueBank;
	}

	public String getValueDate() {
		return valueDate;
	}
	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAcHolderName() {
		return acHolderName;
	}
	public void setAcHolderName(String acHolderName) {
		this.acHolderName = acHolderName;
	}
	public String getPhoneCountryCode() {
		return phoneCountryCode;
	}
	public void setPhoneCountryCode(String phoneCountryCode) {
		this.phoneCountryCode = phoneCountryCode;
	}
	public String getPhoneAreaCode() {
		return phoneAreaCode;
	}
	public void setPhoneAreaCode(String phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	/**
	 * @return the micr
	 */
	public String getMicr() {
		return micr;
	}
	/**
	 * @param micr the micr to set
	 */
	public void setMicr(String micr) {
		this.micr = micr;
	}
	@Override
	public String toString() {
		return "DisbursementBean [disbParty=" + disbParty + ", disbType=" + disbType + ", disbDate=" + disbDate
				+ ", disbAmount=" + disbAmount + ", remarks=" + remarks + ", issueBank=" + issueBank + ", valueDate="
				+ valueDate + ", ifsc=" + ifsc + ", accountNo=" + accountNo + ", acHolderName=" + acHolderName
				+ ", phoneCountryCode=" + phoneCountryCode + ", phoneAreaCode=" + phoneAreaCode + ", phoneNumber="
				+ phoneNumber + ", partnerBankId=" + partnerBankId + ", micr=" + micr + "]";
	}

}
