package com.bajaj.markets.credit.disbursement.consumer.bean;

public class NextDueDateDetails {
	private Integer graceTerm;
	private String nextDueDate;
	public Integer getGraceTerm() {
		return graceTerm;
	}
	public void setGraceTerm(Integer graceTerm) {
		this.graceTerm = graceTerm;
	}
	public String getNextDueDate() {
		return nextDueDate;
	}
	public void setNextDueDate(String nextDueDate) {
		this.nextDueDate = nextDueDate;
	}

}
