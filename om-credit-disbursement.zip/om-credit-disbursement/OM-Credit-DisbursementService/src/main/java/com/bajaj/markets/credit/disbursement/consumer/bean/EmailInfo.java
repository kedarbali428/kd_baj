package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class EmailInfo {

	private String custEMailTypeCode;
	private String custEMail;
	private BigDecimal custEMailPriority;
	
	public String getCustEMailTypeCode() {
		return custEMailTypeCode;
	}
	public void setCustEMailTypeCode(String custEMailTypeCode) {
		this.custEMailTypeCode = custEMailTypeCode;
	}
	public String getCustEMail() {
		return custEMail;
	}
	public void setCustEMail(String custEMail) {
		this.custEMail = custEMail;
	}
	public BigDecimal getCustEMailPriority() {
		return custEMailPriority;
	}
	public void setCustEMailPriority(BigDecimal custEMailPriority) {
		this.custEMailPriority = custEMailPriority;
	}

}
