package com.bajaj.markets.credit.disbursement.consumer.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

public class SmartechDisbursementNotificationDetailsBean {

	@JsonProperty("s^applicationid")
	private String applicationid;

	@JsonProperty("s^l2prodcode")
	private String l2prodcode;

	@JsonProperty("s^prodcode")
	private String prodcode;

	@JsonProperty("s^prodname")
	private String prodname;

	@JsonProperty("s^prodcategory")
	private String prodcategory;

	@JsonProperty("i^prodquantity")
	private Integer prodquantity;

	@JsonProperty("f^revenue")
	private Long revenue;

	@JsonProperty("s^utmsource")
	private String utmSource;

	@JsonProperty("s^principal_name")
	private String principalName;
	
	@JsonProperty("s^principal_code")
	private String principalCode;

	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	public String getL2prodcode() {
		return l2prodcode;
	}

	public void setL2prodcode(String l2prodcode) {
		this.l2prodcode = l2prodcode;
	}

	public String getProdcode() {
		return prodcode;
	}

	public void setProdcode(String prodcode) {
		this.prodcode = prodcode;
	}

	public String getProdname() {
		return prodname;
	}

	public void setProdname(String prodname) {
		this.prodname = prodname;
	}

	public String getProdcategory() {
		return prodcategory;
	}

	public void setProdcategory(String prodcategory) {
		this.prodcategory = prodcategory;
	}

	public Integer getProdquantity() {
		return prodquantity;
	}

	public void setProdquantity(Integer prodquantity) {
		this.prodquantity = prodquantity;
	}

	public Long getRevenue() {
		return revenue;
	}

	public void setRevenue(Long revenue) {
		this.revenue = revenue;
	}

	public String getUtmSource() {
		return utmSource;
	}

	public void setUtmSource(String utmSource) {
		this.utmSource = utmSource;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getPrincipalCode() {
		return principalCode;
	}

	public void setPrincipalCode(String principalCode) {
		this.principalCode = principalCode;
	}

	@Override
	public String toString() {
		return "SmartechDisbursementNotificationDetailsBean [applicationid=" + applicationid + ", l2prodcode="
				+ l2prodcode + ", prodcode=" + prodcode + ", prodname=" + prodname + ", prodcategory=" + prodcategory
				+ ", prodquantity=" + prodquantity + ", revenue=" + revenue + ", utmSource=" + utmSource
				+ ", principalName=" + principalName + ", principalCode=" + principalCode + "]";
	}

}
