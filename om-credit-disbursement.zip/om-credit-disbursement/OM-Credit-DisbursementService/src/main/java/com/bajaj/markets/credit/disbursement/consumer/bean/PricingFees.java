package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class PricingFees {

   private Long feesKey;
	
    private Long appLoanPricingKey;
    
    private BigDecimal feesInPercent;
    
    private BigDecimal feesInAmount;
    
    private String feeCode;

	public Long getFeesKey() {
		return feesKey;
	}

	public void setFeesKey(Long feesKey) {
		this.feesKey = feesKey;
	}

	public Long getAppLoanPricingKey() {
		return appLoanPricingKey;
	}

	public void setAppLoanPricingKey(Long appLoanPricingKey) {
		this.appLoanPricingKey = appLoanPricingKey;
	}

	public BigDecimal getFeesInPercent() {
		return feesInPercent;
	}

	public void setFeesInPercent(BigDecimal feesInPercent) {
		this.feesInPercent = feesInPercent;
	}

	public BigDecimal getFeesInAmount() {
		return feesInAmount;
	}

	public void setFeesInAmount(BigDecimal feesInAmount) {
		this.feesInAmount = feesInAmount;
	}

	public String getFeeCode() {
		return feeCode;
	}

	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}
	
}
