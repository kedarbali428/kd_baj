package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class CreateCollateralExternalRequest {
	
	private String cif;
	private String collateralRef;
	private String collateralType;
	private String collateralCcy;
	private Boolean alwMultiLoanAssign;
	private Boolean alwThirdPartyAssign;
	private String remarks;
	private String entityCode;
	private List<ExtendedDetailBean> extendedDetails;
	private List<Object> coOwnerDetails;
	
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public String getCollateralRef() {
		return collateralRef;
	}
	public void setCollateralRef(String collateralRef) {
		this.collateralRef = collateralRef;
	}
	public String getCollateralType() {
		return collateralType;
	}
	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}
	public String getCollateralCcy() {
		return collateralCcy;
	}
	public void setCollateralCcy(String collateralCcy) {
		this.collateralCcy = collateralCcy;
	}
	public Boolean getAlwMultiLoanAssign() {
		return alwMultiLoanAssign;
	}
	public void setAlwMultiLoanAssign(Boolean alwMultiLoanAssign) {
		this.alwMultiLoanAssign = alwMultiLoanAssign;
	}
	public Boolean getAlwThirdPartyAssign() {
		return alwThirdPartyAssign;
	}
	public void setAlwThirdPartyAssign(Boolean alwThirdPartyAssign) {
		this.alwThirdPartyAssign = alwThirdPartyAssign;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getEntityCode() {
		return entityCode;
	}
	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}
	public List<ExtendedDetailBean> getExtendedDetails() {
		return extendedDetails;
	}
	public void setExtendedDetails(List<ExtendedDetailBean> extendedDetails) {
		this.extendedDetails = extendedDetails;
	}
	public List<Object> getCoOwnerDetails() {
		return coOwnerDetails;
	}
	public void setCoOwnerDetails(List<Object> coOwnerDetails) {
		this.coOwnerDetails = coOwnerDetails;
	}

}
