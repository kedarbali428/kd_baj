package com.bajaj.markets.credit.disbursement.consumer.bean;

public class PrincipalFileUploadRequestBean {
	
	private String applicationId;
	private String parentApplicationId;
	private String l1ProductMasterKey;
	private String l3ProductCode;
	private Long l3ProductKey;
	private Long principalKey;
	private String productRefNo;
	private String principleCustRefId;
	
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getParentApplicationId() {
		return parentApplicationId;
	}
	public void setParentApplicationId(String parentApplicationId) {
		this.parentApplicationId = parentApplicationId;
	}
	public String getL3ProductCode() {
		return l3ProductCode;
	}
	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}
	public String getProductRefNo() {
		return productRefNo;
	}
	public void setProductRefNo(String productRefNo) {
		this.productRefNo = productRefNo;
	}
	public Long getPrincipalKey() {
		return principalKey;
	}
	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}
	public String getPrincipleCustRefId() {
		return principleCustRefId;
	}
	public void setPrincipleCustRefId(String principleCustRefId) {
		this.principleCustRefId = principleCustRefId;
	}
	public String getL1ProductMasterKey() {
		return l1ProductMasterKey;
	}
	public void setL1ProductMasterKey(String l1ProductMasterKey) {
		this.l1ProductMasterKey = l1ProductMasterKey;
	}
	public Long getL3ProductKey() {
		return l3ProductKey;
	}
	public void setL3ProductKey(Long l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}
	@Override
	public String toString() {
		return "PrincipalFileUploadRequestBean [applicationId=" + applicationId + ", parentApplicationId="
				+ parentApplicationId + ", l1ProductMasterKey=" + l1ProductMasterKey + ", l3ProductCode="
				+ l3ProductCode + ", l3ProductKey=" + l3ProductKey + ", principalKey=" + principalKey
				+ ", productRefNo=" + productRefNo + ", principleCustRefId=" + principleCustRefId + "]";
	}
}