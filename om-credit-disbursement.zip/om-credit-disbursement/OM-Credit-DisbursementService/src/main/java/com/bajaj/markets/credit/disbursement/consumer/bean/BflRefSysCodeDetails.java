package com.bajaj.markets.credit.disbursement.consumer.bean;

public class BflRefSysCodeDetails {
	private Long bflRefSysCodeKey;
	private Long systemKey;
	private String omLable;
	private String omCode;
	private String refCode;
	public Long getBflRefSysCodeKey() {
		return bflRefSysCodeKey;
	}
	public void setBflRefSysCodeKey(Long bflRefSysCodeKey) {
		this.bflRefSysCodeKey = bflRefSysCodeKey;
	}
	public Long getSystemKey() {
		return systemKey;
	}
	public void setSystemKey(Long systemKey) {
		this.systemKey = systemKey;
	}
	public String getOmLable() {
		return omLable;
	}
	public void setOmLable(String omLable) {
		this.omLable = omLable;
	}
	public String getOmCode() {
		return omCode;
	}
	public void setOmCode(String omCode) {
		this.omCode = omCode;
	}
	public String getRefCode() {
		return refCode;
	}
	public void setRefCode(String refCode) {
		this.refCode = refCode;
	}
}
