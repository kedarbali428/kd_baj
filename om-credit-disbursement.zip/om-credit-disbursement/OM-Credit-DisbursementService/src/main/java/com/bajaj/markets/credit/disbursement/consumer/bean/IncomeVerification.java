package com.bajaj.markets.credit.disbursement.consumer.bean;

public class IncomeVerification {
	private String netSalary;
	private Reference anualTurnover;
	private Verification verification;

	public String getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(String netSalary) {
		this.netSalary = netSalary;
	}

	public Verification getVerification() {
		return verification;
	}

	public void setVerification(Verification verification) {
		this.verification = verification;
	}

	public Reference getAnualTurnover() {
		return anualTurnover;
	}

	public void setAnualTurnover(Reference anualTurnover) {
		this.anualTurnover = anualTurnover;
	}

}
