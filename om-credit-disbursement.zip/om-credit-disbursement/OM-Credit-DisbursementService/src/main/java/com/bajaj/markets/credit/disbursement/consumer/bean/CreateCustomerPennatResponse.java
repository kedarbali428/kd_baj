package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class CreateCustomerPennatResponse {

	private String dedupReq;
	private String cif;
	private ReturnStatusBean returnStatus;
	private List<DedupeBean> dedup;
	
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public ReturnStatusBean getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(ReturnStatusBean returnStatus) {
		this.returnStatus = returnStatus;
	}
	public String getDedupReq() {
		return dedupReq;
	}
	public void setDedupReq(String dedupReq) {
		this.dedupReq = dedupReq;
	}
	public List<DedupeBean> getDedup() {
		return dedup;
	}
	public void setDedup(List<DedupeBean> dedup) {
		this.dedup = dedup;
	}

}
