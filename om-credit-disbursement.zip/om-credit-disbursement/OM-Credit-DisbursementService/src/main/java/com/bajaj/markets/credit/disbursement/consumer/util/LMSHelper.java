package com.bajaj.markets.credit.disbursement.consumer.util;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.LmsIntegrationRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.insurance.remoteapitrackinglib.bean.TypedRemoteApiTrackingVO;
import com.bajaj.markets.insurance.remoteapitrackinglib.service.impl.RemoteApiTrackingImpl;
import com.google.gson.Gson;

@Component
public class LMSHelper {
	@Value("${api.v2.lms.gateway.POST.url}")
	private String lmsGatewayUrl;

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	Environment env;

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Autowired
	private RemoteApiTrackingImpl remoteApiTrackingImpl;

	private static final String CLASS_NAME = LMSHelper.class.getCanonicalName();

	public Object executeLmsRequest(String source, String l2ProductCode, String requestPayload, String applicationId,
			HttpHeaders headers) {
		Gson gson = new Gson();
		Long appid = Long.parseLong(applicationId);
		LmsIntegrationRequestBean lmsIntegrationRequestBean = new LmsIntegrationRequestBean();
		lmsIntegrationRequestBean.setHttpMethod(HttpMethod.POST);
		lmsIntegrationRequestBean.setProductCode(l2ProductCode);
		lmsIntegrationRequestBean.setRequestPayload(requestPayload);
		lmsIntegrationRequestBean.setSource(source);
		lmsIntegrationRequestBean.setApplicationId(appid);
		String request = gson.toJson(lmsIntegrationRequestBean, LmsIntegrationRequestBean.class);
		return execute(request, headers, applicationId);
	}

	public Object executeLMSTimeOutRequestforLoan(String source, String l2ProductCode, String requestPayload,
			String applicationId, HttpHeaders headers) {
		Gson gson = new Gson();
		Long appid = Long.parseLong(applicationId);
		LmsIntegrationRequestBean lmsIntegrationRequestBean = new LmsIntegrationRequestBean();
		lmsIntegrationRequestBean.setHttpMethod(HttpMethod.POST);
		lmsIntegrationRequestBean.setProductCode(l2ProductCode);
		lmsIntegrationRequestBean.setRequestPayload(requestPayload);
		lmsIntegrationRequestBean.setSource(source);
		lmsIntegrationRequestBean.setApplicationId(appid);
		String request = gson.toJson(lmsIntegrationRequestBean, LmsIntegrationRequestBean.class);
		return executeLms(request, headers, applicationId);
	}

	public Object executeLms(String request, HttpHeaders headers, String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"****************************************************************************** PENNANT LMS REQUEST:  "
						+ request);
		Object responsePayload = null;
		headers.setContentType(MediaType.APPLICATION_JSON);
		Long requestDateTime = System.currentTimeMillis();
		Long responseDateTime = null;
		HashMap<String, String> params = new HashMap<>();
		try {
			ResponseEntity<?> response = disbursementBusinessHelper.invokeRestEndpoint(HttpMethod.POST, lmsGatewayUrl,
					Object.class, params, request, headers);
			responseDateTime = System.currentTimeMillis();
			if (null != response && null != response.getBody()) {
				Object responseObject = response.getBody();
				JSONObject responseJson = getJsonObject(responseObject);
				responsePayload = (String) responseJson.get("payload");

				apiTracking(applicationId, request, responsePayload.toString(), DisbursementConstants.SUCCESS,
						lmsGatewayUrl, null, DisbursementConstants.API_REPORT_SOURCE,
						DisbursementConstants.API_REPORT_TARGET, requestDateTime, responseDateTime,
						logger.getCorrelationID());
			}

			else {
				logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occured while invoking LMSIntegration Service");
				throw new DisbursementServiceException();

			}
		} catch (Exception e) {
			apiTracking(applicationId, request, null, DisbursementConstants.FAILURE, lmsGatewayUrl, e.getMessage(),
					DisbursementConstants.API_REPORT_SOURCE, DisbursementConstants.API_REPORT_TARGET, requestDateTime,
					responseDateTime, logger.getCorrelationID());

			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"callLMSService() : Exception occured while calling LMS Service", e);
			throw new DisbursementServiceException();

		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"****************************************************************************** PENNANT LMS RESPONSE:  "
						+ responsePayload);
		return responsePayload;
	}

	public Object execute(String request, HttpHeaders headers, String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"****************************************************************************** PENNANT LMS REQUEST:  "
						+ request);
		Object responsePayload = null;
		headers.setContentType(MediaType.APPLICATION_JSON);
		Long requestDateTime = System.currentTimeMillis();
		Long responseDateTime = null;
		HashMap<String, String> params = new HashMap<>();
		try {
			ResponseEntity<?> response = disbursementBusinessHelper.invokeRestEndpoint(HttpMethod.POST, lmsGatewayUrl,
					Object.class, params, request, headers);
			responseDateTime = System.currentTimeMillis();
			if (null != response && null != response.getBody()) {
				Object responseObject = response.getBody();
				JSONObject responseJson = getJsonObject(responseObject);
				responsePayload = (String) responseJson.get("payload");
				apiTracking(applicationId, request, responsePayload.toString(), DisbursementConstants.SUCCESS,
						lmsGatewayUrl, null, DisbursementConstants.API_REPORT_SOURCE,
						DisbursementConstants.API_REPORT_TARGET, requestDateTime, responseDateTime,
						logger.getCorrelationID());
			}

			else {
				logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occured while invoking LMSIntegration Service");
				throw new DisbursementServiceException();

			}
		} catch (Exception e) {
			apiTracking(applicationId, request, null, DisbursementConstants.FAILURE, lmsGatewayUrl, e.getMessage(),
					DisbursementConstants.API_REPORT_SOURCE, DisbursementConstants.API_REPORT_TARGET, requestDateTime,
					responseDateTime, logger.getCorrelationID());

			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"callLMSService() : Exception occured while calling LMS Service", e);
			throw new DisbursementServiceException();

		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"****************************************************************************** PENNANT LMS RESPONSE:  "
						+ responsePayload);
		return responsePayload;
	}

	@SuppressWarnings("rawtypes")
	private JSONObject getJsonObject(Object object) {
		JSONObject jsonObject = new JSONObject();
		try {
			if (object instanceof JSONObject) {
				jsonObject = (JSONObject) object;
			} else if (object instanceof LinkedHashMap) {
				jsonObject = new JSONObject((Map) object);
			} else {
				Object obj = new JSONObject(object.toString());
				jsonObject = (JSONObject) obj;
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Error occured while parsing :", e);
		}
		return jsonObject;
	}

	public void apiTracking(String applicationId, String request, String response, String status, String url,
			String error, String source, String target, Long requestDateTime, Long responseDateTime,
			String cmptCorrId) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "apiTracking start");
		TypedRemoteApiTrackingVO remoteApiTrackingBean = new TypedRemoteApiTrackingVO();
		remoteApiTrackingBean.setApplicationId(null != applicationId ? Long.valueOf(applicationId) : null);
		remoteApiTrackingBean.setRequestPayload(request);
		remoteApiTrackingBean.setRequestTimeStamp(requestDateTime);
		remoteApiTrackingBean.setResponsePayload(response);
		remoteApiTrackingBean.setResponseTimeStamp(responseDateTime);
		remoteApiTrackingBean.setSource(source);
		remoteApiTrackingBean.setTarget(target);
		remoteApiTrackingBean.setStatus(status);
		remoteApiTrackingBean.setTargetApi(url);
		remoteApiTrackingBean.setError(error);
		remoteApiTrackingBean.setCorrelationId(cmptCorrId);
		try {
			remoteApiTrackingImpl.saveRemoteRequestResponse(remoteApiTrackingBean);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "apiTracking end");
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Error occured while api tracking for: " + applicationId, e);
		}
	}
}
