package com.bajaj.markets.credit.disbursement.consumer.util;

public class DisbursementConstants {

	public static final Integer IS_ACTIVE = 1;
	public static final Integer TRANCH_STATUS_ZERO = 0;
	public static final String CUSTOMER_CATEGORY_RETAIL = "RETAIL";
	public static final String CUSTOMER_CATEGORY_CORP = "CORP";
	public static final String BASE_CURRENCY = "INR";
	public static final String PRIMARY_RELATION_OFFICER = "DEFAULT";
	public static final String LMS_CUSTOMER_SOURCE = "PNT_CUST_CREATE";
	public static final String COUNTRY_OF_BIRTH_IND = "IN";
	public static final String DEFAULT_TYPE = "1";
	public static final String DEFAULT_SECTOR = "17";
	public static final String DEFAULT_INDUSTRY = "60";
	public static final String INCOME_INFO_CAT_SALARIED = "SALARIED";
	public static final String INCOME_EXPENSES = "INCOME";
	public static final String CUST_INCOME_TYPE_BS = "BS";
	public static final String DOC_CATEGORY_PAN_CARD = "03";
	public static final String DOC_REF_ID_PAN_CARD = "PAN_CARD";
	public static final String DOC_FILE_NAME_PAN_CARD = "PAN_CARD.PDF";
	public static final String DOC_ISSUE_DATE = "2020-08-11T00:00:00";
	public static final String DOC_EXP_DATE = "2030-11-11T00:00:00";
	public static final String DOC_FORMAT_PDF = "PDF";
	public static final String DOC_ISSUED_AUTH_IN = "IN";
	public static final String DOC_ISSUED_COUNTRY_IN = "IN";
	public static final String HTTP_METHOD_POST = "POST";
	public static final String SERVICE_RECORD = "servicerecord";
	public static final String MAIN_APPLICANT = "1";
	public static final String COLLATERAL_CCY = "INR";
	public static final String REMARK = "Testing from API";
	public static final String DEFAULT_VALUATER = "PE";
	public static final String PHONE_TYPE = "MOBILE";
	public static final String DISBURSEMENT_RECORDS = "disbursement_records";
	public static final Long ADDRESS_CURR_PREFERRED_FLAG = 1L;

	// Collateral Constants
	public static final String EXT_FIELD_AC_NO = "ACNO";
	public static final String EXT_FIELD_AC_HOLDER_NAME = "ACHOLDNAME";
	public static final String EXT_FIELD_IFSC = "IFSC";
	public static final String EXT_FIELD_CHEQUE_NO = "CHEQUENO";
	public static final String EXT_FIELD_CHEQUE_AMT = "CHEQUEAMT";
	public static final String EXT_FIELD_BANK = "BANK";
	public static final String EXT_FIELD_BANK_BRANCH = "BANKBR";
	public static final String EXT_FIELD_BRANCH_MICR = "MICR";
	public static final String EXT_FIELD_NO_OF_UNITS = "NOOFUNITS";
	public static final String EXT_FIELD_UNIT_PRICE = "UNITPRICE";
	public static final String LMS_CREATE_COLLATERAL_SOURCE = "PNT_COLTRL_CREATE";

	public static final String PENNANT_SUCCES_CODE = "0000";
	public static final String PENNANT_BENE_EXISTS_CODE = "30550";
	public static final String PENNAT_CUST_DEDUPE_RESP_CODE = "90434";
	public static final String PENNANT_SYSTEMCODE = "PLF";
	public static final String BANK_MASTER = "bank master";
	public static final String BRANCH_MASTER = "branch master";
	public static final String COLLATERAL_REF_NUM = "collateralRef";
	public static final Integer DISB_FAILURE_FLAG = 0;
	public static final Integer DISB_SUCCESS_FLAG = 1;
	public static final String TRANCHE_STATUS_PENDING = "Pending";
	public static final String TRANCHE_STATUS_DISBURSED = "Disbursed";
	public static final String TRANCHE_STATUS_PROGRESS = "Disbursement Initiated";
	public static final String TRANCHE_STATUS_FAILED = "Failed";

//Loan details
	public static final String COUNTRY_CODE_IND = "91";
	public static final String AREA_CODE_IND = "91";
	public static final String DISB_TYPE = "IMPS";
	public static final String DISB_PARTY = "CS";
	public static final String AUTH_TOKEN = "authtoken";
	public static final String SOL_PROD = "BFLSOL";
	public static final String LMS_CREATE_LOAN_SOURCE = "PNT_LOAN_CREATE";
	public static final String LMS_LOAN_CUSTOMER = "LOANCUSTOMER";
	public static final String LOAN_APPLICATION_EXIST_IN_PENNANT_CODE = "41001";
	public static final String FINANCE = "Finance";
	public static final String FEE_PAYMENT_MODE_CASH = "Cash";
	public static final String EXT_FIELD_PREMIUM = "PREMIUM";
	public static final String EXT_FIELD_TENOR = "TENOR";
	public static final String EXT_FIELD_POLSTARTDT = "POLSTARTDT";
	public static final String EXT_FIELD_SA = "SA";
	public static final String EXT_FIELD_SAD = "SAD";
	public static final String EXT_FIELD_PRDATE = "PRDATE";
	public static final String INS_PROD_CODE_GCPPLI = "GCPPLI";
	public static final String INS_PROD_CODE_GPGI = "GPGI";
	public static final String VAS_PROD_CODE_VASFFR01 = "VASFFR01";
	public static final String VAS_PROD_CODE_VASPD01 = "VASPD01";
	public static final String PROCESS_STAGE_BLANK = "";
	public static final String MODE_DDM = "DDM";
	public static final String MODE_NACH = "NACH";
	public static final String ACCOUNT_TYPE_CURRENT = "11";
	public static final String ACCOUNT_TYPE_CODE_BTTP = "BTTP";
	public static final String ACCOUNT_TYPE_SAVING = "10";
	public static final String ACCOUNT_TYPE_CODE_SA = "SA";
	public static final String FAILURE = "FAILURE";

	public static final String LMS_LIMIT_SOURCE = "PNT_LMT_CREATE";
	public static final String PENNAT_LIMIT_DEDUPE_RESP_CODE = "90806";
	public static final String LMS_BENEFICIARY_SOURCE = "PNT_BENF_CREATE";
	public static final String BENEFICIARY_ID = "beneficiaryID";

	public static final String LMS_PENNANT_MANDATE_SOURCE = "GETMANDATE";

	public static final String ERROR_MANDATE_CUST_NOT_FOUND = "90101";
	public static final String ERROR_MANDATE_NOT_FOUND = "90304";
	public static final String DOB_DATE_FORMAT = "yyyy-MM-dd'T'00:00:00";
	public static final String SUCCESS = "SUCCESS";
	// BOL
	public static final String BOL = "BFLBOL";
	public static final Integer CUSTOMER_CATEGORY_KEY_CORP = 1;
	public static final String PENNAT_BUSINESS_TYPE_PROPRIETORSHIP = "7";
	public static final String CO_APPLICANT = "2";
	public static final String ADDRESS_TYPE_OFFICE = "OFFICE";
	public static final String ADDRESS_TYPE_CURRENT = "CURRES";
	public static final String ADDRESS_TYPE_PERM = "PERM";
	public static final String ADDRESS_TYPE_OFFICE_KEY = "46";
	public static final String ADDRESS_TYPE_OTHERS_KEY = "52";
	public static final String ADDRESS_TYPE_DOCKUP_KEY = "54";
	public static final String ADDRESS_TYPE_CURRENT_KEY = "50";
	public static final String ADDRESS_TYPE_PERMANENT_KEY = "48";
	public static final String ADDRESS_TYPE_DELIVERY = "DELIVERY";
	public static final String APPLICABLE_PRIMARY = "P";
	public static final String APPLICABLE_ENTITY = "C";
	public static final Long BUSINESS_KEY_PROPRIETORSHIP = 1L; // From dmmaster
	public static final String PRINCIPAL_CODE_BFL = "BFL";
	public static final String ADDRESS_TYPE_OTHERS = "OTHERS";
	public static final String ADDRESS_TYPE_DOCPKUP = "DOCPKUP";
	public static final String ACCOUNT_TYPE = "account type";
	public static final String EMAIL_TYPE = "email type";
	public static final String ADDRESS_TYPE = "address type";
	public static final String INDUSTRY_MASTER = "industry master";
	public static final String NATURE_OF_BUSINESS = "nature of business";
	public static final String BUSINESS_TYPE = "business master";
	public static final String PAYLOAD = "payload";
	public static final String CUSTOMER_PORTAL_PDF = "CustomerPortalGuide.pdf";
	public static final String CONS_ESIGNED_DOC = "CONS_ESIGNED_DOC";
	public static final String PRODUCT_REF_NO = "productrefno";
	public static final String DISB_SUCCESS = "SUCCESS";
	public static final String DISBURSEMENT_COMPLETED = "DISBURSEMENT_COMPLETED";
	public static final String DISBURSEMENT_FAILED = "DISBURSEMENT_FAILED";
	public static final String DISBURSEMENT_INITIATED = "DISBURSEMENT_INITIATED";
	public static final String INITIATE_DISBURSEMENT = "INITIATE_DISBURSEMENT";

	// Error Scenarios

	public static final String DISBURSMENT_PRECHECKS = "DISBURSMENT_PRECHECKS";
	public static final String CREATE_CUSTOMER = "CREATE_CUSTOMER";
	public static final String CREATE_BENEFICIARY = "CREATE_BENEFICIARY";
	public static final String CREATE_COLATERAL = "CREATE_COLATERAL";
	public static final String CREATE_LOAN = "CREATE_LOAN";
	public static final String IN_PROGRESS = "IN_PROGRESS";
	public static final String SUCCESSFULL = "SUCCESSFULL";
	public static final String FAILED = "FAILED";
	public static final String CREATED = "CREATED";
	public static final String CREATE_CUSTOMER_FAILED = "CREATE_CUSTOMER_FAILED";
	public static final String CREATE_BENEFICIARY_FAILED = "CREATE_BENEFICIARY_FAILED";
	public static final String CREATE_COLATERAL_FAILED = "CREATE_COLATERAL_FAILED";
	public static final String CREATE_LOAN_FAILED = "CREATE_LOAN_FAILED";

	public static final String BFDL_LOANS_SOURCE = "BFDL_DISBURSEMENT";
	public static final Integer SMARTECH_PRODUCT_QUANTITY = 1;
	public static final String PRINICIPAL_CODE_BFL = "BFL";
	public static final Long PRINICIPAL_KEY_BFL = 3L;
	public static final String PRINICIPAL_NAME_BFL = "Bajaj Finance Limited";

	// Insurance Details
	public static final String INSURANCEID = "INSURANCEID";
	public static final String INSUR_FORM_NO = "INSUR_FORM_NO";
	public static final String APPLICANTTYPE = "APPLICANTTYPE";
	public static final String CIF = "CIF";
	public static final String DOB = "DOB";
	public static final String AGE = "AGE";
	public static final String GENDER = "GENDER";
	public static final String SUMASSURED = "SUMASSURED";
	public static final String POLICY_TERM = "POLICY_TERM";
	public static final String BR_DISPATCH_DATE = "BR_DISPATCH_DATE";
	public static final String CRITICALILLNESS = "CRITICALILLNESS";
	public static final String DGH = "DGH";
	public static final String INSUR_PARTY_TYPE = "INSUR_PARTY_TYPE";
	public static final String POLICY_NO = "POLICY_NO";
	public static final String HEIGHT = "HEIGHT";
	public static final String WEIGHT = "WEIGHT";
	public static final String ADDRESS = "ADDRESS";
	public static final String NOM_NAME1 = "NOM_NAME1";
	public static final String NON_REL1 = "NON_REL1";
	public static final String NOM_DOB1 = "NOM_DOB1";
	public static final String NOM_AGE1 = "NOM_AGE1";
	public static final String NOM_ADDRESS1 = "NOM_ADDRESS1";
	public static final String NOM_MOB1 = "NOM_MOB1";
	public static final String APPOINTEENAME1 = "APPOINTEENAME1";
	public static final String APPOINTEE_REL1 = "APPOINTEE_REL1";
	public static final String APPOINTEEDOB1 = "APPOINTEEDOB1";
	public static final String APPOINTEE_AGE1 = "APPOINTEE_AGE1";
	public static final String APPOINTEE_ADDRESS1 = "APPOINTEE_ADDRESS1";
	public static final String APPOINTEE_MOB = "APPOINTEE_MOB";
	public static final String NOM_NAME2 = "NOM_NAME2";
	public static final String NOM_RELATION2 = "NOM_RELATION2";
	public static final String NOM_DOB2 = "NOM_DOB2";
	public static final String NOM_AGE2 = "NOM_AGE2";
	public static final String NOM_ADDRESS2 = "NOM_ADDRESS2";
	public static final String NOM_MOB2 = "NOM_MOB2";
	public static final String APPOINTEE_NAME2 = "APPOINTEE_NAME2";
	public static final String APPOINTEE_REL2 = "APPOINTEE_REL2";
	public static final String APPOINTEE_DOB2 = "APPOINTEE_DOB2";
	public static final String APPOINTEE_AGE2 = "APPOINTEE_AGE2";
	public static final String APPOINTEE_ADDRESS2 = "APPOINTEE_ADDRESS2";
	public static final String APPOINTEE_MOB2 = "APPOINTEE_MOB2";
	public static final String PRIMARY_APPLICANT = "PRIMARY";

	// BFL FUNDED CONSTANTS
	public static final String BFL_INITIATE_DISBURSEMENT = "BFLIM_INITIATE_DISBURSEMENT";
	public static final String DEFAULT_BRANCH_PUNE = "320";
	public static final String EMAIL_TYPE_OFFICE = "OFFICE";
	public static final String EMAIL_TYPE_PERSONAL = "PERSONAL";
	public static final String DOC_CATEGORY_OTH = "OTH";
	public static final String BFL_DISBURSEMENT_COMPLETED = "BFLIM_DISBURSEMENT_COMPLETED";
	public static final String BFL_DISBURSEMENT_FAILED = "BFLIM_DISBURSEMENT_FAILED";
	public static final String BFL_DISBURSEMENT_STATUS = "BFLIM_DISBURSEMENT_STATUS";
	public static final String DOC_TITLE_PANCARD = "PANCARD";
	public static final String BFL_LOANS_SOURCE = "BFL_DISBURSEMENT";
	public static final String DISB_REQUEST_TRACKING_TABLE = "disbursement_request_tracking";
	public static final String TIMESTAMP_FORMAT = "T00:00:00";

	public static final String MODE_EMANDATE = "S";
	public static final String ACCOUNT_TYPE_CODE_SAVINGS = "SAVINGS";
	public static final String API_REPORT_SOURCE = "CREDIT";
	public static final String API_REPORT_TARGET = "DISBURSEMENT";
}
