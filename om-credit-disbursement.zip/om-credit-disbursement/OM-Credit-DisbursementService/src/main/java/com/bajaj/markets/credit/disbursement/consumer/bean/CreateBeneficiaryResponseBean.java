package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class CreateBeneficiaryResponseBean {
	
	private BigDecimal beneficiaryID;
	private Status status;
	private ReturnStatusBean returnStatus;

	public BigDecimal getBeneficiaryID() {
		return beneficiaryID;
	}

	public void setBeneficiaryID(BigDecimal beneficiaryID) {
		this.beneficiaryID = beneficiaryID;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public ReturnStatusBean getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(ReturnStatusBean returnStatus) {
		this.returnStatus = returnStatus;
	}
}
