package com.bajaj.markets.credit.disbursement.consumer.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.Address;
import com.bajaj.markets.credit.disbursement.consumer.bean.AddressInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicantAddressInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicantEmailInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.BFLRefCodeDetailsRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.BankDetailsResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.BankMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.BflBranchesMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.BflRefSysCodeDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.BranchDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.BusinessVerticalMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.CityMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCollateralDisbDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCollateralExternalRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCustomerPennantRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.CustomerBankInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.CustomerDisbDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.DocumentInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.EmailInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ExtendedDetailBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ExtendedFieldBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedAddressRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GenderMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.IncomeInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.LanguageMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.MaritalStatusMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.NationalityMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.PartnerProductMapMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.PersonalInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.PhoneInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.PinCodeServiceableBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.SPDCDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.SubIndustriesMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.UserProfile;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.google.gson.Gson;

@Component
public class DisbursementMapperUtil {

	@Value("${api.omreferencedatareferencedataservice.salutation.GET.url}")
	private String getSalutationDetailsUrl;

	@Value("${api.omreferencedatareferencedataservice.language.GET.url}")
	private String getLanguageDetailsUrl;

	@Value("${api.omreferencedatareferencedataservice.nationality.GET.url}")
	private String getNationalityDetailsUrl;

	@Value("${api.omreferencedatareferencedataservice.gender.GET.url}")
	private String getGenderDetailsUrl;

	@Value("${api.omreferencedatareferencedataservice.maritalstatus.GET.url}")
	private String getMaritalStatusDetailsUrl;

	@Value("${api.omreferencedatareferencedataservice.city.GET.url}")
	private String getCityDetailsUrl;

	@Value("${api.omreferencedatareferencedataservice.banks.GET.url}")
	private String getBranchDetailsUrl;

	@Value("${api.referencedata.banks.bankname.GET.url}")
	private String getBankMasterCodeUrl;

	@Value("${api.omcreditapplicationservice.bflrefcode.POST.url}")
	private String getBflRefCodeUrl;

	@Value("${api.omreferencedatareferencedataservice.bflbranches.GET.url}")
	private String getBflBranchesCodeUrl;

	@Value("${api.omreferencedatareferencedataservice.subindustries.GET.url}")
	private String getIndustryDetailsUrl;

	@Value("${api.omcreditapplicationservice.pincode.GET.url}")
	private String getpincodeUrl;

	@Value("${api.omcreditapplicationservice.servicesmaster.GET.url}")
	private String servicesmasterUrl;

	@Value("${api.referencedata.businessverticals.GET.url}")
	private String getBusinessVerticleURL;

	@Value("${api.referencedata.partnerproductmap.GET.url}")
	private String getPartnerProductMapUrl;

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Autowired
	DisbursementUtil disbursementUtil;

	private static final String CLASS_NAME = DisbursementMapperUtil.class.getCanonicalName();

	public CreateCustomerPennantRequest mapCustomerPennantRequestForSOL(UserProfile userProfile,
			ApplicationDetails applicationDetails, CustomerDisbDetails customerDisbDetails,
			List<BankDetailsResponse> bankDetailsList, Long l3ProdKey, Long prodcatKey, HttpHeaders headers) {
		CreateCustomerPennantRequest customerPennantRequest = new CreateCustomerPennantRequest();

		customerPennantRequest.setCategoryCode(DisbursementConstants.CUSTOMER_CATEGORY_RETAIL);
		List<Address> currentAddresses = applicationDetails.getAddressList().stream()
				.filter(x -> (x.getAddressTypeKey().equals(DisbursementConstants.ADDRESS_TYPE_CURRENT_KEY)))
				.collect(Collectors.toList());

		List<ApplicantAddressInfo> currentAdds = customerDisbDetails.getApplicantAddresses().stream()
				.filter(x -> (x.getAddrtypkey().equals(Long.parseLong(DisbursementConstants.ADDRESS_TYPE_CURRENT_KEY))))
				.collect(Collectors.toList());

		ApplicantAddressInfo currentAdd = currentAdds.stream()
				.filter(x -> (currentAdds.size() > 1
						? (null != x.getPrefferedflg()
								&& DisbursementConstants.ADDRESS_CURR_PREFERRED_FLAG == x.getPrefferedflg())
						: (null == x.getPrefferedflg() || 0L == x.getPrefferedflg() || 1L == x.getPrefferedflg())))
				.findFirst().orElse(new ApplicantAddressInfo());

		Address currentAddress = currentAddresses.stream()
				.filter(x -> x.getAddressKey().equalsIgnoreCase(currentAdd.getAddressKey())).findFirst()
				.orElse(new Address());
		/*
		 * Long branchKey=fetchbflbranchServicesMaster(Long.parseLong(currentAddress.
		 * getCityKey()),applicationDetails.getOccupation().getOcupationType().getKey(),
		 * l3ProdKey,prodcatKey, headers); customerPennantRequest
		 * .setDefaultBranch(fetchBrchbyBranchKey(branchKey,currentAddress.getCityKey(),
		 * headers));
		 */
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "mapCustomerPennantRequestForSOL : currentAdd :"
				+ currentAdd.getAddressKey() + " and currentAddress:" + currentAddress.getAddressKey());
		String cityName = fetchPinCodeServiceableMaster(currentAddress.getPincodeKey(), l3ProdKey, headers);
		customerPennantRequest.setDefaultBranch(fetchBrchbyCity(cityName, currentAddress.getCityKey(), headers));
		customerPennantRequest.setBaseCurrency(DisbursementConstants.BASE_CURRENCY);
		customerPennantRequest.setPrimaryRelationOfficer(DisbursementConstants.PRIMARY_RELATION_OFFICER);
		customerPennantRequest.setPersonalInfo(mapPersonalInfo(userProfile, customerDisbDetails, headers));
		customerPennantRequest.setDedupReq(true);
		customerPennantRequest.setAddresses(mapAddressDetails(applicationDetails.getAddressList(),
				customerDisbDetails.getApplicantAddresses(), headers));
		customerPennantRequest.setPhones(mapPhoneDetails(userProfile.getMobile()));
		customerPennantRequest.setEmails(mapEmailInfo(customerDisbDetails.getEmails(), headers));
		if (null != applicationDetails.getOccupation().getBusinessOwnerDetails()
				&& null != applicationDetails.getOccupation().getBusinessOwnerDetails().getNetMonthlyIncome())
			customerPennantRequest.setCustomersIncome(mapCustomersIncome(
					applicationDetails.getOccupation().getBusinessOwnerDetails().getNetMonthlyIncome()));
		customerPennantRequest.setDocuments(mapDocumentsInfo(applicationDetails.getUserProfile().getPanNumber()));
		customerPennantRequest.setCustomersBankInfo(mapCustomersBankInfo(bankDetailsList, headers));
		return customerPennantRequest;
	}

	@SuppressWarnings("unchecked")
	public String fetchDefaultBranch(String cityKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchDefaultBranch : Start :" + cityKey);
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		BflBranchesMaster bflBranchesMaster = null;
		String code = "";
		params.put("citykey", cityKey);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getBflBranchesCodeUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			bflBranchesMaster = gson.fromJson(response.getBody(), BflBranchesMaster.class);
			code = bflBranchesMaster.getBflbranchcode();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchDefaultBranch : End :" + code);
		return code;
	}
	/*
	 * @SuppressWarnings("unchecked") public String fetchBrchbyBranchKey(Long
	 * branchKey,String cityKey, HttpHeaders headers) { logger.debug(CLASS_NAME,
	 * BFLLoggerComponent.SERVICE, "fetchDefaultBranch : Start :" + cityKey);
	 * HashMap<String, String> params = new HashMap<>(); Gson gson = new Gson();
	 * BflBranchesMaster bflBranchesMaster = null; String code = "";
	 * params.put("citykey", cityKey); params.put("branchKey",
	 * branchKey.toString()); ResponseEntity<String> response =
	 * (ResponseEntity<String>) disbursementBusinessHelper
	 * .invokeRestEndpoint(HttpMethod.GET, getBflBranchesCodeUrl, String.class,
	 * params, null, headers); if (null != response.getBody()) { bflBranchesMaster =
	 * gson.fromJson(response.getBody(), BflBranchesMaster.class); code =
	 * bflBranchesMaster.getBflbranchcode(); } logger.debug(CLASS_NAME,
	 * BFLLoggerComponent.SERVICE, "fetchDefaultBranch : End :" + code); return
	 * code; }
	 * 
	 * @SuppressWarnings("unchecked") public Long fetchbflbranchServicesMaster(Long
	 * cityKey,Long occupationKey,Long prodKey,Long prodcatKey, HttpHeaders headers)
	 * { logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
	 * "fetchPinCodeServiceableMaster : cityKey :" +
	 * cityKey+" occupationKey :"+occupationKey+" prodKey :"+prodKey+" prodcatKey :"
	 * +prodcatKey); HashMap<String, String> params = new HashMap<>();
	 * params.put("cityKey", cityKey.toString()); params.put("occupationKey",
	 * occupationKey.toString()); params.put("prodcatKey", prodKey.toString());
	 * params.put("prodKey", prodcatKey.toString()); Gson gson = new Gson();
	 * BflBranchServicesBean bflBranchServicesBean = new BflBranchServicesBean();
	 * Long branchKey=null; ResponseEntity<String> response =
	 * (ResponseEntity<String>) disbursementBusinessHelper
	 * .invokeRestEndpoint(HttpMethod.GET, servicesmasterUrl, String.class, params,
	 * null, headers); if (null != response.getBody()) { bflBranchServicesBean =
	 * gson.fromJson(response.getBody(), BflBranchServicesBean.class); branchKey =
	 * bflBranchServicesBean.getBflbranchkey(); } logger.debug(CLASS_NAME,
	 * BFLLoggerComponent.SERVICE, "fetchPinCodeServiceableMaster : End  cityKey :"
	 * +
	 * cityKey+" occupationKey :"+occupationKey+" prodKey :"+prodKey+" prodcatKey :"
	 * +prodcatKey); return branchKey; }
	 */

	@SuppressWarnings("unchecked")
	public String fetchPinCodeServiceableMaster(String pinCdKey, Long l3ProdKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"fetchPinCodeServiceableMaster : pinCdKey :" + pinCdKey + " l3ProdKey :" + l3ProdKey);
		HashMap<String, String> params = new HashMap<>();
		params.put("pincodekey", pinCdKey);
		params.put("prodkey", l3ProdKey.toString());
		Gson gson = new Gson();
		PinCodeServiceableBean pinCodeServiceableBean = new PinCodeServiceableBean();
		String cityName = null;
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getpincodeUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			pinCodeServiceableBean = gson.fromJson(response.getBody(), PinCodeServiceableBean.class);
			cityName = pinCodeServiceableBean.getCityname();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"fetchPinCodeServiceableMaster : End pinCdKey :" + pinCdKey + " l3ProdKey :" + l3ProdKey);
		return cityName;
	}

	@SuppressWarnings("unchecked")
	public String fetchBrchbyCity(String cityName, String cityKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchDefaultBranch : Start :" + cityKey);
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		BflBranchesMaster bflBranchesMaster = null;
		String code = "";
		params.put("citykey", cityKey);
		params.put("cityName", cityName);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getBflBranchesCodeUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			bflBranchesMaster = gson.fromJson(response.getBody(), BflBranchesMaster.class);
			code = bflBranchesMaster.getBflbranchcode();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchDefaultBranch : End :" + code);
		return code;
	}

	private List<CustomerBankInfo> mapCustomersBankInfo(List<BankDetailsResponse> bankDetailsList,
			HttpHeaders headers) {
		List<CustomerBankInfo> bankInfos = new ArrayList<>();
		for (BankDetailsResponse bank : bankDetailsList) {
			CustomerBankInfo info = new CustomerBankInfo();
			info.setAccountNumber(bank.getAccoutNumber());
			info.setAccountType(
					fetchBflRefCode(DisbursementConstants.ACCOUNT_TYPE, bank.getBankAccountTypeKey(), headers));
			String bankMasterKey = (null != bank.getBankMasterKey() ? bank.getBankMasterKey()
					: fetchBrachDetails(bank.getBranchKey(), headers).getBankMasterKey().toString());
			info.setBankName(mapBflBankRefCode(bankMasterKey, headers));
			bankInfos.add(info);
		}
		return bankInfos;
	}

	public String mapBflBankRefCode(String bankMasterKey, HttpHeaders headers) {
		String OMBankCode = fetchOMBankCode(bankMasterKey, headers);
		return fetchBflRefCode(DisbursementConstants.BANK_MASTER, OMBankCode, headers);
	}

	@SuppressWarnings("unchecked")
	private String fetchOMBankCode(String bankMasterKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchOMBankCode : Start :");
		Gson gson = new Gson();
		BankMaster bankMaster = null;
		String code = "";
		HashMap<String, String> params = new HashMap<>();
		params.put("bankMasterKey", bankMasterKey);
		params.put("bankName", null);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getBankMasterCodeUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			BankMaster[] bankList = gson.fromJson(response.getBody(), BankMaster[].class);
			for (BankMaster bnkMaster : bankList) {
				if (bnkMaster.getBankMasterKey().toString().equalsIgnoreCase(bankMasterKey)) {
					bankMaster = bnkMaster;
					code = bankMaster.getBankCode();
					break;
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchOMBankCode : End : ");
		return code;
	}

	private List<DocumentInfo> mapDocumentsInfo(String panNumber) {
		List<DocumentInfo> docInfoList = new ArrayList<>();
		DocumentInfo panInfo = new DocumentInfo();
		panInfo.setCustDocIssuedOn(DisbursementConstants.DOC_ISSUE_DATE);
		panInfo.setCustDocExpDate(DisbursementConstants.DOC_EXP_DATE);
		panInfo.setDocFormat(DisbursementConstants.DOC_FORMAT_PDF);
		panInfo.setCustDocIssuedAuth(DisbursementConstants.DOC_ISSUED_AUTH_IN);
		panInfo.setCustDocIssuedCountry(DisbursementConstants.DOC_ISSUED_COUNTRY_IN);
		panInfo.setCustDocTitle(panNumber);
		panInfo.setDocCategory(DisbursementConstants.DOC_CATEGORY_PAN_CARD);
		panInfo.setDocName(DisbursementConstants.DOC_FILE_NAME_PAN_CARD);
		panInfo.setDocRefId(DisbursementConstants.DOC_REF_ID_PAN_CARD);

		docInfoList.add(panInfo);
		return docInfoList;
	}

	private List<IncomeInfo> mapCustomersIncome(String netMonthlyIncome) {
		List<IncomeInfo> incomeInfoList = new ArrayList<>();
		IncomeInfo incomeInfo = new IncomeInfo();
		incomeInfo.setCategory(DisbursementConstants.INCOME_INFO_CAT_SALARIED);
		incomeInfo.setIncomeExpense(DisbursementConstants.INCOME_EXPENSES);
		incomeInfo.setCustIncomeType(DisbursementConstants.CUST_INCOME_TYPE_BS);
		incomeInfo.setCustIncome(null != netMonthlyIncome ? new BigDecimal(netMonthlyIncome) : null); // PennantAmountField
		incomeInfoList.add(incomeInfo);
		return incomeInfoList;
	}

	public List<EmailInfo> mapEmailInfo(List<ApplicantEmailInfo> emails, HttpHeaders headers) {
		List<EmailInfo> emailInfoList = new ArrayList<>();
		Long priority = 5L;
		for (ApplicantEmailInfo email : emails) {
			EmailInfo info = new EmailInfo();
			info.setCustEMail(email.getEmailaddress());
			info.setCustEMailPriority(priority > 1 ? BigDecimal.valueOf(priority) : BigDecimal.ONE);
			info.setCustEMailTypeCode(
					fetchBflRefCode(DisbursementConstants.EMAIL_TYPE, email.getEmailtypekey().toString(), headers));
			priority--;
			emailInfoList.add(info);
		}
		return emailInfoList;
	}

	private List<PhoneInfo> mapPhoneDetails(String mobNumber) {
		List<PhoneInfo> phoneInfoList = new ArrayList<>();
		Integer priority = 5;
		PhoneInfo phoneInfo = new PhoneInfo();
		phoneInfo.setPhoneTypeCode(DisbursementConstants.PHONE_TYPE);
		phoneInfo.setPhoneCountryCode(DisbursementConstants.COUNTRY_CODE_IND);
		phoneInfo.setPhoneAreaCode(DisbursementConstants.AREA_CODE_IND);
		phoneInfo.setPhoneNumber(mobNumber);
		phoneInfo.setPriority(priority);
		phoneInfoList.add(phoneInfo);
		return phoneInfoList;
	}

	private List<AddressInfo> mapAddressDetails(List<Address> addressList,
			List<ApplicantAddressInfo> applicantAddresses, HttpHeaders headers) {
		List<AddressInfo> addressInfoList = new ArrayList<>();
		for (Address addr : addressList) {
			AddressInfo addressInfo = new AddressInfo();
			String addressTypeCode = fetchBflRefCode(DisbursementConstants.ADDRESS_TYPE, addr.getAddressTypeKey(),
					headers);
			addressInfo.setAddrType(addressTypeCode);
			if (((DisbursementConstants.ADDRESS_TYPE_OFFICE.equals(addressTypeCode))
					|| (DisbursementConstants.ADDRESS_TYPE_CURRENT.equals(addressTypeCode))
					|| (DisbursementConstants.ADDRESS_TYPE_PERM.equals(addressTypeCode)))) {

				ApplicantAddressInfo appAddress = applicantAddresses.stream()
						.filter(x -> (x.getAddrtypkey().equals(Long.parseLong(addr.getAddressTypeKey()))
								&& x.getAddressKey().equalsIgnoreCase(addr.getAddressKey())))
						.findFirst().orElse(null);
				if (DisbursementConstants.ADDRESS_TYPE_CURRENT.equals(addressTypeCode)
						&& (null == appAddress || null == appAddress.getAddressKey()))
					continue;
				setAddressInfo(addr, appAddress, addressInfo, false, headers);
				addressInfoList.add(addressInfo);
			}
		}
		return addressInfoList;
	}

	private Integer getPriority(String addressTypeKey, boolean isBusinessEntity) {
		switch (addressTypeKey) {
		case DisbursementConstants.ADDRESS_TYPE_CURRENT_KEY:
			return 5;
		case DisbursementConstants.ADDRESS_TYPE_PERMANENT_KEY:
			return 4;
		case DisbursementConstants.ADDRESS_TYPE_OFFICE_KEY:
			return isBusinessEntity ? 5 : 3;
		case DisbursementConstants.ADDRESS_TYPE_OTHERS_KEY:
			return 2;
		default:
			return 1;
		}

	}

	private Integer getPriorityOnAddrCode(String addressTypeCode) {
		switch (addressTypeCode) {
		case DisbursementConstants.ADDRESS_TYPE_CURRENT:
			return 5;
		case DisbursementConstants.ADDRESS_TYPE_PERM:
			return 4;
		case DisbursementConstants.ADDRESS_TYPE_OFFICE:
			return 3;
		case DisbursementConstants.ADDRESS_TYPE_OTHERS:
			return 2;
		default:
			return 1;
		}

	}

	private PersonalInfo mapPersonalInfo(UserProfile userProfile, CustomerDisbDetails customerDisbDetails,
			HttpHeaders headers) {
		PersonalInfo personalInfo = new PersonalInfo();
		personalInfo.setFirstName(userProfile.getName().getFirstName());
		personalInfo.setMiddleName(userProfile.getName().getMiddleName());
		personalInfo.setLastName(userProfile.getName().getLastName());

		personalInfo.setSalutation("DR");
		personalInfo.setLanguage(
				null != customerDisbDetails.getLangKey() ? fetchLangcode(customerDisbDetails.getLangKey(), headers)
						: null);
		personalInfo.setDateofBirth(userProfile.getDateOfBirth() + "T00:00:00");
		personalInfo.setCountryofBirth(DisbursementConstants.COUNTRY_OF_BIRTH_IND);
		personalInfo.setNationality(null != customerDisbDetails.getNationalityKey()
				? fetchNationalitycode(customerDisbDetails.getNationalityKey(), headers)
				: null);
		personalInfo.setGender(fetchGenderCodeDetails(userProfile.getGenderKey(), headers));
		personalInfo.setMaritalStatus(fetchMaritalStatusCodeDetails(userProfile.getMaritalStatusKey(), headers));
		personalInfo.setType(DisbursementConstants.DEFAULT_TYPE);
		personalInfo.setSector(DisbursementConstants.DEFAULT_SECTOR);
		personalInfo.setIndustry(DisbursementConstants.DEFAULT_INDUSTRY);
		// personalInfo.setShortName(userProfile.getName().getLastName()); FOR L3=SPPL
		// personalInfo.setEmiCardEligibilityAmt(emiCardEligibilityAmt);
		// //PennantAmountField
		return personalInfo;
	}

	private PersonalInfo mapPROLPersonalInfo(UserProfile userProfile, CustomerDisbDetails customerDisbDetails,
			HttpHeaders headers) {
		String applicantType = userProfile.getApplicationUserAttributeType();
		PersonalInfo personalInfo = new PersonalInfo();
		personalInfo.setFirstName(userProfile.getName().getFirstName());
		personalInfo.setMiddleName(userProfile.getName().getMiddleName());
		personalInfo.setLastName(userProfile.getName().getLastName());
		personalInfo.setSalutation("DR");
		personalInfo.setLanguage(
				null != customerDisbDetails.getLangKey() ? fetchLangcode(customerDisbDetails.getLangKey(), headers)
						: null);
		personalInfo.setCountryofBirth(DisbursementConstants.COUNTRY_OF_BIRTH_IND);
		personalInfo.setNationality(null != customerDisbDetails.getNationalityKey()
				? fetchNationalitycode(customerDisbDetails.getNationalityKey(), headers)
				: null);
		personalInfo.setGender(fetchGenderCodeDetails(userProfile.getGenderKey(), headers));
		personalInfo.setMaritalStatus(fetchMaritalStatusCodeDetails(userProfile.getMaritalStatusKey(), headers));
		personalInfo.setDateofBirth(userProfile.getDateOfBirth() + "T00:00:00");
		personalInfo.setType(DisbursementConstants.DEFAULT_TYPE);
		personalInfo.setSector(DisbursementConstants.DEFAULT_SECTOR);
		personalInfo.setIndustry(DisbursementConstants.DEFAULT_INDUSTRY);
		// personalInfo.setEmiCardEligibilityAmt(emiCardEligibilityAmt);
		// //PennantAmountField
		return personalInfo;
	}

	private PersonalInfo mapBOLPersonalInfo(UserProfile userProfile, CustomerDisbDetails customerDisbDetails,
			ApplicationDetails applicationDetails, Boolean isBusinessEntity, HttpHeaders headers) {
		String applicantType = userProfile.getApplicationUserAttributeType();
		PersonalInfo personalInfo = new PersonalInfo();

		boolean solePropritership = !isBusinessEntity && applicantType.equals(DisbursementConstants.MAIN_APPLICANT)
				&& applicationDetails.getOccupation().getBusinessOwnerDetails().getBusinessType().getKey()
						.equals(DisbursementConstants.BUSINESS_KEY_PROPRIETORSHIP);

		if (!isBusinessEntity) {
			personalInfo.setFirstName(userProfile.getName().getFirstName());
			personalInfo.setMiddleName(userProfile.getName().getMiddleName());
			personalInfo.setLastName(userProfile.getName().getLastName());
			personalInfo.setSalutation("DR");
			personalInfo.setLanguage(
					null != customerDisbDetails.getLangKey() ? fetchLangcode(customerDisbDetails.getLangKey(), headers)
							: null);
			personalInfo.setCountryofBirth(DisbursementConstants.COUNTRY_OF_BIRTH_IND);
			personalInfo.setNationality(null != customerDisbDetails.getNationalityKey()
					? fetchNationalitycode(customerDisbDetails.getNationalityKey(), headers)
					: null);
			personalInfo.setGender(fetchGenderCodeDetails(userProfile.getGenderKey(), headers));
			personalInfo.setMaritalStatus(fetchMaritalStatusCodeDetails(userProfile.getMaritalStatusKey(), headers));
		}

		personalInfo.setDateofBirth(isBusinessEntity
				? fetchDobForBolEntity(
						Long.valueOf(applicationDetails.getOccupation().getBusinessOwnerDetails().getBusinessVintage()))
				: userProfile.getDateOfBirth() + "T00:00:00");

		String industry = null, sector = null, type = null;
		if (null != applicationDetails.getOccupation()) {
			type = fetchBflRefCode(DisbursementConstants.BUSINESS_TYPE,
					applicationDetails.getOccupation().getBusinessOwnerDetails().getBusinessType().getKey().toString(),
					headers);
			sector = fetchBflRefCode(DisbursementConstants.NATURE_OF_BUSINESS, applicationDetails.getOccupation()
					.getBusinessOwnerDetails().getNatureOfBusiness().getKey().toString(), headers);

			industry = fetchBflRefCode(DisbursementConstants.INDUSTRY_MASTER,
					fetchIndustryMastKey(
							applicationDetails.getOccupation().getBusinessOwnerDetails().getSubindumastkey().getKey(),
							headers),
					headers);
		}

		personalInfo.setType((null != customerDisbDetails.getCustcategorycdkey()
				&& customerDisbDetails.getCustcategorycdkey().equals(DisbursementConstants.CUSTOMER_CATEGORY_KEY_CORP))
				|| isBusinessEntity ? type : DisbursementConstants.DEFAULT_TYPE);

		personalInfo.setSector(solePropritership || isBusinessEntity ? sector : DisbursementConstants.DEFAULT_SECTOR);
		personalInfo
				.setIndustry(solePropritership || isBusinessEntity ? industry : DisbursementConstants.DEFAULT_INDUSTRY);
		// personalInfo.setEmiCardEligibilityAmt(emiCardEligibilityAmt);
		// //PennantAmountField
		if (isBusinessEntity || solePropritership)
			personalInfo
					.setShortName(null != applicationDetails.getOccupation().getBusinessOwnerDetails().getBusinessName()
							? applicationDetails.getOccupation().getBusinessOwnerDetails().getBusinessName()
							: userProfile.getName().getLastName());
		return personalInfo;
	}

	private String fetchDobForBolEntity(Long businessVintage) {
		SimpleDateFormat format = new SimpleDateFormat(DisbursementConstants.DOB_DATE_FORMAT);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		String entityDOBStr;
		if (0 != businessVintage.intValue()) {
			calendar.add(Calendar.MONTH, -businessVintage.intValue());
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found. ");

			throw new DisbursementServiceException(HttpStatus.NOT_FOUND,
					new ErrorBean("CDS", "Business Vintage not found."));
		}
		Date entityDOB = calendar.getTime();
		entityDOBStr = format.format(entityDOB);
		return entityDOBStr;
	}

	@SuppressWarnings("unchecked")
	private String fetchIndustryMastKey(Long subIndustryMastkey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchIndustryMastKey : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		SubIndustriesMaster subIndustriesMaster = null;
		String code = "";
		params.put("subindmastkey", subIndustryMastkey.toString());
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getIndustryDetailsUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			subIndustriesMaster = gson.fromJson(response.getBody(), SubIndustriesMaster.class);
			code = subIndustriesMaster.getIndmastkey().toString();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchIndustryMastKey : End : " + code);
		return code;
	}

	@SuppressWarnings("unchecked")
	private String fetchCityDetails(String pincode, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchCityDetails : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		CityMaster cityMaster = null;
		String code = "";
		// PinCode is required and not PincodeKey
		params.put("pincode", pincode.toString());
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getCityDetailsUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			cityMaster = gson.fromJson(response.getBody(), CityMaster.class);
			code = cityMaster.getCityname();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchCityDetails : End : " + code);
		return code;
	}

	@SuppressWarnings("unchecked")
	private String fetchGenderCodeDetails(Long genderKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchGenderCodeDetails : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		List<GenderMaster> genderCodeDtlsList = new ArrayList<>();
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getGenderDetailsUrl, String.class, params, null, headers);

		if (null != response.getBody()) {
			GenderMaster[] genderCodeDtlsResponse = gson.fromJson(response.getBody(), GenderMaster[].class);
			genderCodeDtlsList = Arrays.asList(genderCodeDtlsResponse);
		}

		String genderCode = "";
		for (GenderMaster genderMaster : genderCodeDtlsList) {
			if (genderMaster.getGenderKey().equals(genderKey))
				genderCode = genderMaster.getGenderCode();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchGenderCodeDetails : End : ");
		return genderCode;
	}

	@SuppressWarnings("unchecked")
	private String fetchNationalitycode(Long nationalityKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchNationalitycode : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		NationalityMaster nationalityMaster = null;
		String code = "";
		params.put("nationalitykey", nationalityKey.toString());
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getNationalityDetailsUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			nationalityMaster = gson.fromJson(response.getBody(), NationalityMaster.class);
			code = nationalityMaster.getNationalitycode();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchNationalitycode : End : " + code);
		return code;
	}

	@SuppressWarnings("unchecked")
	private String fetchLangcode(Long langKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchLangcode : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		LanguageMaster languageMaster = null;
		String langcode = "";
		params.put("langkey", langKey.toString());
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getLanguageDetailsUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			languageMaster = gson.fromJson(response.getBody(), LanguageMaster.class);
			langcode = languageMaster.getLangcode();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchLangcode : End : " + langcode);

		return langcode;
	}

	@SuppressWarnings("unchecked")
	private String fetchMaritalStatusCodeDetails(Long maritalStatusKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchGenderCodeDetails : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		List<MaritalStatusMaster> maritalStatusDtlsList = new ArrayList<>();
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getMaritalStatusDetailsUrl, String.class, params, null, headers);

		if (null != response.getBody()) {
			MaritalStatusMaster[] maritalStatusDtlsResponse = gson.fromJson(response.getBody(),
					MaritalStatusMaster[].class);
			maritalStatusDtlsList = Arrays.asList(maritalStatusDtlsResponse);
		}
		String maritalStatusCode = "";
		for (MaritalStatusMaster master : maritalStatusDtlsList) {
			if (master.getMaritalStatusKey().equals(maritalStatusKey))
				maritalStatusCode = master.getMaritalStatusCode();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchGenderCodeDetails : End : ");
		return maritalStatusCode;
	}

	@SuppressWarnings("unchecked")
	public BranchDetails fetchBrachDetails(String branchKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchBrachDetails : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		BranchDetails branchDetails = null;

		params.put("branchKey", branchKey);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getBranchDetailsUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			BranchDetails[] branchDetailsList = gson.fromJson(response.getBody(), BranchDetails[].class);
			branchDetails = Arrays.asList(branchDetailsList).get(0);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchBrachDetails : End : ");
		return branchDetails;
	}

	public CreateCollateralExternalRequest mapCollateralPennantRequest(String cif,
			List<BankDetailsResponse> bankDetails, CreateCollateralDisbDetails collateralDisbDetails,
			HttpHeaders headers) {
		CreateCollateralExternalRequest collateralExternalRequest = new CreateCollateralExternalRequest();
		collateralExternalRequest.setCif(cif);
		collateralExternalRequest.setCollateralType("SPDC");
		collateralExternalRequest.setCollateralCcy(DisbursementConstants.COLLATERAL_CCY);
		collateralExternalRequest.setAlwMultiLoanAssign(true);
		collateralExternalRequest.setAlwThirdPartyAssign(false);
		collateralExternalRequest.setEntityCode("1");// For Unsecured
		collateralExternalRequest.setRemarks(DisbursementConstants.REMARK);
		collateralExternalRequest
				.setExtendedDetails(mapExtendedDetails(bankDetails, collateralDisbDetails.getSpdcDetails(), headers));
		collateralExternalRequest.setCoOwnerDetails(new ArrayList<>());
		return collateralExternalRequest;
	}

	private List<ExtendedDetailBean> mapExtendedDetails(List<BankDetailsResponse> bankDetails, SPDCDetails spdcDetails,
			HttpHeaders headers) {
		BankDetailsResponse bank = bankDetails.get(0);
		List<ExtendedDetailBean> extDetails = new ArrayList<>();
		List<ExtendedFieldBean> extFields = new ArrayList<>();
		BranchDetails branchMaster = fetchBrachDetails(bank.getBranchKey(), headers);

		ExtendedFieldBean extField1 = new ExtendedFieldBean();
		extField1.setFieldName(DisbursementConstants.EXT_FIELD_AC_NO);
		extField1.setFieldValue(bank.getAccoutNumber());
		extFields.add(extField1);

		ExtendedFieldBean extField2 = new ExtendedFieldBean();
		extField2.setFieldName(DisbursementConstants.EXT_FIELD_AC_HOLDER_NAME);
		extField2.setFieldValue(bank.getHolderName());
		extFields.add(extField2);

		ExtendedFieldBean extField3 = new ExtendedFieldBean();
		extField3.setFieldName(DisbursementConstants.EXT_FIELD_IFSC);
		extField3.setFieldValue(branchMaster.getBranchIfscCode());
		extFields.add(extField3);

		ExtendedFieldBean extField4 = new ExtendedFieldBean();
		extField4.setFieldName(DisbursementConstants.EXT_FIELD_NO_OF_UNITS);
		extField4.setFieldValue("1");
		extFields.add(extField4);

		ExtendedFieldBean extField5 = new ExtendedFieldBean();
		extField5.setFieldName(DisbursementConstants.EXT_FIELD_UNIT_PRICE);
		extField5.setFieldValue("10000000000");
		extFields.add(extField5);

		int pdcCount = 1;
		if (null != spdcDetails.getPdcnumber1() && !spdcDetails.getPdcnumber1().isEmpty()) {
			ExtendedFieldBean extFieldNum = new ExtendedFieldBean();
			extFieldNum.setFieldName(DisbursementConstants.EXT_FIELD_CHEQUE_NO + pdcCount);
			extFieldNum.setFieldValue(spdcDetails.getPdcnumber1());
			extFields.add(extFieldNum);

			ExtendedFieldBean extFieldAmt = new ExtendedFieldBean();
			extFieldAmt.setFieldName(DisbursementConstants.EXT_FIELD_CHEQUE_AMT + pdcCount); // PennantAmountField
			extFieldAmt.setFieldValue(spdcDetails.getPdcamount1().toString());
			extFields.add(extFieldAmt);

			pdcCount++;
		}

		if (null != spdcDetails.getPdcnumber2() && !spdcDetails.getPdcnumber2().isEmpty()) {
			ExtendedFieldBean extFieldNum = new ExtendedFieldBean();
			extFieldNum.setFieldName(DisbursementConstants.EXT_FIELD_CHEQUE_NO + pdcCount);
			extFieldNum.setFieldValue(spdcDetails.getPdcnumber2());
			extFields.add(extFieldNum);

			ExtendedFieldBean extFieldAmt = new ExtendedFieldBean();
			extFieldAmt.setFieldName(DisbursementConstants.EXT_FIELD_CHEQUE_AMT + pdcCount); // PennantAmountField
			extFieldAmt.setFieldValue(spdcDetails.getPdcamount2().toString());
			extFields.add(extFieldAmt);

			pdcCount++;
		}

		if (null != spdcDetails.getPdcnumber3() && !spdcDetails.getPdcnumber3().isEmpty()) {
			ExtendedFieldBean extFieldNum = new ExtendedFieldBean();
			extFieldNum.setFieldName(DisbursementConstants.EXT_FIELD_CHEQUE_NO + pdcCount);
			extFieldNum.setFieldValue(spdcDetails.getPdcnumber3());
			extFields.add(extFieldNum);

			ExtendedFieldBean extFieldAmt = new ExtendedFieldBean();
			extFieldAmt.setFieldName(DisbursementConstants.EXT_FIELD_CHEQUE_AMT + pdcCount); // PennantAmountField
			extFieldAmt.setFieldValue(spdcDetails.getPdcamount3().toString());
			extFields.add(extFieldAmt);

			pdcCount++;
		}

		if (null != spdcDetails.getPdcnumber4() && !spdcDetails.getPdcnumber4().isEmpty()) {
			ExtendedFieldBean extFieldNum = new ExtendedFieldBean();
			extFieldNum.setFieldName(DisbursementConstants.EXT_FIELD_CHEQUE_NO + pdcCount);
			extFieldNum.setFieldValue(spdcDetails.getPdcnumber4());
			extFields.add(extFieldNum);

			ExtendedFieldBean extFieldAmt = new ExtendedFieldBean();
			extFieldAmt.setFieldName(DisbursementConstants.EXT_FIELD_CHEQUE_AMT + pdcCount); // PennantAmountField
			extFieldAmt.setFieldValue(spdcDetails.getPdcamount4().toString());
			extFields.add(extFieldAmt);

			pdcCount++;
		}

		ExtendedFieldBean extField6 = new ExtendedFieldBean();
		extField6.setFieldName(DisbursementConstants.EXT_FIELD_BANK);
		extField6.setFieldValue(mapBflBankRefCode(branchMaster.getBankMasterKey().toString(), headers));
		extFields.add(extField6);

		ExtendedFieldBean extField8 = new ExtendedFieldBean();
		extField8.setFieldName(DisbursementConstants.EXT_FIELD_BRANCH_MICR);
		extField8.setFieldValue(branchMaster.getBranchMicrCode());
		extFields.add(extField8);

		ExtendedDetailBean extDetail = new ExtendedDetailBean();
		extDetail.setExtendedFields(extFields);
		extDetails.add(extDetail);
		return extDetails;
	}

	@SuppressWarnings("unchecked")
	private String fetchBflRefCode(String omLable, String omCode, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchBflBranchRefCode : Start :");
		BFLRefCodeDetailsRequest pennatRefCodeDetailsRequest = new BFLRefCodeDetailsRequest();
		pennatRefCodeDetailsRequest.setSystemCode(DisbursementConstants.PRINCIPAL_CODE_BFL);
		pennatRefCodeDetailsRequest.setOmLable(omLable);
		pennatRefCodeDetailsRequest.setOmCode(omCode);

		BflRefSysCodeDetails bflRefSysCode = null;
		String refcode = "";
		Gson gson = new Gson();
		String pennatDetailsRequestStr = gson.toJson(pennatRefCodeDetailsRequest, BFLRefCodeDetailsRequest.class);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(
				HttpMethod.POST, getBflRefCodeUrl, String.class, null, pennatDetailsRequestStr, headers);

		if (null != response.getBody()) {
			bflRefSysCode = gson.fromJson(response.getBody(), BflRefSysCodeDetails.class);
			refcode = bflRefSysCode.getRefCode();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchBflBranchRefCode : End : " + refcode);
		return refcode;
	}

	public CreateCustomerPennantRequest mapCustomerPennantRequestForBOL(UserProfile userProfile,
			ApplicationDetails applicationDetails, CustomerDisbDetails customerDisbDetails,
			List<BankDetailsResponse> bankDetailsList, Boolean isBusinessEntity, Long l3ProdKey, Long prodcatKey,
			HttpHeaders headers) {
		String applicantType = userProfile.getApplicationUserAttributeType();
		CreateCustomerPennantRequest customerPennantRequest = new CreateCustomerPennantRequest();
		customerPennantRequest.setCategoryCode((null != customerDisbDetails.getCustcategorycdkey()
				&& customerDisbDetails.getCustcategorycdkey().equals(DisbursementConstants.CUSTOMER_CATEGORY_KEY_CORP))
				|| isBusinessEntity ? DisbursementConstants.CUSTOMER_CATEGORY_CORP
						: DisbursementConstants.CUSTOMER_CATEGORY_RETAIL);
		List<Address> currentAddresses = applicationDetails.getAddressList().stream()
				.filter(x -> (x.getAddressTypeKey().equals(DisbursementConstants.ADDRESS_TYPE_CURRENT_KEY)))
				.collect(Collectors.toList());

		List<ApplicantAddressInfo> currentAdds = customerDisbDetails.getApplicantAddresses().stream()
				.filter(x -> (x.getAddrtypkey().equals(Long.parseLong(DisbursementConstants.ADDRESS_TYPE_CURRENT_KEY))))
				.collect(Collectors.toList());

		ApplicantAddressInfo currentAdd = currentAdds.stream()
				.filter(x -> (currentAdds.size() > 1
						? (null != x.getPrefferedflg()
								&& DisbursementConstants.ADDRESS_CURR_PREFERRED_FLAG == x.getPrefferedflg())
						: (null == x.getPrefferedflg() || 0L == x.getPrefferedflg() || 1L == x.getPrefferedflg())))
				.findFirst().orElse(new ApplicantAddressInfo());

		Address currentAddress = currentAddresses.stream()
				.filter(x -> x.getAddressKey().equalsIgnoreCase(currentAdd.getAddressKey())).findFirst()
				.orElse(new Address());
		/*
		 * Long branchKey=fetchbflbranchServicesMaster(Long.parseLong(currentAddress.
		 * getCityKey()),applicationDetails.getOccupation().getOcupationType().getKey(),
		 * l3ProdKey,prodcatKey, headers); customerPennantRequest
		 * .setDefaultBranch(fetchBrchbyBranchKey(branchKey,currentAddress.getCityKey(),
		 * headers));
		 */
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "mapCustomerPennantRequestForBOL : currentAdd :"
				+ currentAdd.getAddressKey() + " and currentAddress:" + currentAddress.getAddressKey());
		String cityName = fetchPinCodeServiceableMaster(currentAddress.getPincodeKey(), l3ProdKey, headers);
		customerPennantRequest.setDefaultBranch(fetchBrchbyCity(cityName, currentAddress.getCityKey(), headers));
		customerPennantRequest.setBaseCurrency(DisbursementConstants.BASE_CURRENCY);
		customerPennantRequest.setPrimaryRelationOfficer(DisbursementConstants.PRIMARY_RELATION_OFFICER);
		customerPennantRequest.setPersonalInfo(
				mapBOLPersonalInfo(userProfile, customerDisbDetails, applicationDetails, isBusinessEntity, headers));
		customerPennantRequest.setDedupReq(true);
		customerPennantRequest.setAddresses(isBusinessEntity
				? mapAddressDetailsForBolEntity(applicationDetails.getAddressList(),
						customerDisbDetails.getApplicantAddresses(), headers)
				: mapAddressDetails(applicationDetails.getAddressList(), customerDisbDetails.getApplicantAddresses(),
						headers));
		customerPennantRequest.setPhones(mapPhoneDetails(userProfile.getMobile()));
		customerPennantRequest.setEmails(mapEmailInfo(customerDisbDetails.getEmails(), headers));
		customerPennantRequest.setDocuments(mapDocumentsInfo(
				isBusinessEntity ? applicationDetails.getOccupation().getBusinessOwnerDetails().getBusinessPan()
						: applicantType.equals(DisbursementConstants.CO_APPLICANT) ? userProfile.getPanNumber()
								: applicationDetails.getUserProfile().getPanNumber()));
		if (applicantType.equals(DisbursementConstants.MAIN_APPLICANT)) {
			customerPennantRequest.setCustomersBankInfo(mapCustomersBankInfo(bankDetailsList, headers));
		}
		return customerPennantRequest;
	}

	public List<AddressInfo> mapAddressDetailsForBolEntity(List<Address> addressList,
			List<ApplicantAddressInfo> applicantAddresses, HttpHeaders headers) {
		List<AddressInfo> addressInfoList = new ArrayList<>();
		AddressInfo addressInfo = new AddressInfo();

		String addressKeyForOffice = DisbursementConstants.ADDRESS_TYPE_OFFICE_KEY;
		String addressCodeForOffice = DisbursementConstants.ADDRESS_TYPE_OFFICE;
		Address addr = addressList.stream().filter(x -> x.getAddressTypeKey().equals(addressKeyForOffice)).findFirst()
				.orElse(new Address());

		addressInfo.setAddrType(addressCodeForOffice);

		ApplicantAddressInfo appAddress = applicantAddresses.stream()
				.filter(x -> x.getAddrtypkey().equals(Long.parseLong(addr.getAddressTypeKey()))).findFirst()
				.orElse(null);
		setAddressInfo(addr, appAddress, addressInfo, true, headers);
		addressInfoList.add(addressInfo);

		if (addressInfoList.isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred : Failed to build Address Info ");
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred : Failed to build Address Info");
		}

		return addressInfoList;

	}

	private void setAddressInfo(Address addr, ApplicantAddressInfo appAddress, AddressInfo addressInfo,
			boolean isBusinessEntity, HttpHeaders headers) {
		addressInfo.setPinCode(disbursementUtil.fetchPincodeDetails(Long.valueOf(addr.getPincodeKey()), headers));
		addressInfo.setPriority(getPriority(
				null != appAddress && null != appAddress.getAddrtypkey() ? appAddress.getAddrtypkey().toString()
						: (null != addr && null != addr.getAddressTypeKey()) ? addr.getAddressTypeKey() : "",
				isBusinessEntity));
		if (null != appAddress && null != appAddress.getBuildingNo() && !appAddress.getBuildingNo().isEmpty()
				&& null != appAddress.getFlatNo() && !appAddress.getFlatNo().isEmpty() && null != appAddress.getStreet()
				&& !appAddress.getStreet().isEmpty()) {
			addressInfo.setBuildingNo(appAddress.getBuildingNo());
			addressInfo.setFlatNo(appAddress.getFlatNo());
			addressInfo.setStreet(appAddress.getStreet());
		} else if (null != appAddress && (null != appAddress.getAddrLine1() || null != appAddress.getAddrLine2())) {
			extractAddress(addressInfo, appAddress, headers);
		} else if (null == appAddress && null != addr) {
			appAddress = new ApplicantAddressInfo();
			appAddress.setAddressKey(addr.getAddressKey());
			appAddress.setAddrLine1(null != addr.getAddressLine1() ? addr.getAddressLine1() : "");
			appAddress.setAddrLine2(null != addr.getAddressLine2() ? addr.getAddressLine2() : "");
			extractAddress(addressInfo, appAddress, headers);
		}
	}

	private void extractAddress(AddressInfo addressInfo, ApplicantAddressInfo appAddress, HttpHeaders headers) {
		String address = getCompleteAddress(appAddress);
		String[] defaultArray = prepareAddress(addressInfo, address, headers);

		if (null != defaultArray[0] && !defaultArray[0].isEmpty()) {
			addressInfo.setBuildingNo(defaultArray[0]);
		}
		if (null != defaultArray[1] && !defaultArray[1].isEmpty()) {
			addressInfo.setStreet(defaultArray[1]);
		}
		if (null != defaultArray[2] && !defaultArray[2].isEmpty()) {
			addressInfo.setFlatNo(defaultArray[2]);
		}
		if (null != defaultArray[3] && !defaultArray[3].isEmpty()) {
			addressInfo.setAddrLine1(defaultArray[3]);
		}
		if (null != defaultArray[4] && !defaultArray[4].isEmpty()) {
			addressInfo.setAddrLine2(defaultArray[4]);
		}
	}

	private String[] prepareAddress(AddressInfo addressInfo, String addressStr, HttpHeaders headers) {
		/** Prepare Address for customer */
		try {
			String[] defaultArray = new String[5];
			for (int k = 0; k <= (defaultArray.length) - 1; k++) {
				defaultArray[k] = StringUtils.EMPTY;
			}
			int pos = 0;
			int j = 0;
			while (addressStr.length() > 0) {
				int i = 0;
				while ((i = addressStr.indexOf(' ', i) + 1) > 0) {
					if (i > 50) {
						break;
					} else {
						pos = i;
					}
				}
				if (addressStr.length() <= 50) {
					defaultArray[j] = addressStr;
					defaultArray[j + 1] = fetchCityDetails(addressInfo.getPinCode(), headers);
					break;
				} else {
					defaultArray[j] = addressStr.substring(0, pos - 1);
					String addr = addressStr.substring(pos, addressStr.length());
					addressStr = addr;
					pos = 0;
				}
				j++;
			}
			return defaultArray;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred : Failed To Extract Address ", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred : Failed To Extract Address");
		}
	}

	private String getCompleteAddress(ApplicantAddressInfo appAddress) {
		String completeAddress = ""
				.concat((null != appAddress.getAddrLine1() && !appAddress.getAddrLine1().isBlank())
						? appAddress.getAddrLine1()
						: "")
				.concat((null != appAddress.getAddrLine2() && !appAddress.getAddrLine2().isBlank())
						? appAddress.getAddrLine2()
						: "");
		return completeAddress;

	}

	public CreateCustomerPennantRequest mapCustomerPennantRequestForPROL(UserProfile userProfile,
			ApplicationDetails applicationDetails, CustomerDisbDetails customerDisbDetails,
			List<BankDetailsResponse> bankDetailsList, Boolean isBusinessEntity, Long l3ProdKey, HttpHeaders headers) {
		String applicantType = userProfile.getApplicationUserAttributeType();
		CreateCustomerPennantRequest customerPennantRequest = new CreateCustomerPennantRequest();
		customerPennantRequest.setCategoryCode((null != customerDisbDetails.getCustcategorycdkey()
				&& customerDisbDetails.getCustcategorycdkey().equals(DisbursementConstants.CUSTOMER_CATEGORY_KEY_CORP))
				|| isBusinessEntity ? DisbursementConstants.CUSTOMER_CATEGORY_CORP
						: DisbursementConstants.CUSTOMER_CATEGORY_RETAIL);
		Address currentAddress = applicationDetails.getAddressList().stream()
				.filter(x -> x.getAddressTypeKey().equals(DisbursementConstants.ADDRESS_TYPE_CURRENT_KEY)).findFirst()
				.orElse(new Address());
		String cityName = fetchPinCodeServiceableMaster(currentAddress.getPincodeKey(), l3ProdKey, headers);
		customerPennantRequest.setDefaultBranch(fetchBrchbyCity(cityName, currentAddress.getCityKey(), headers));
		customerPennantRequest.setBaseCurrency(DisbursementConstants.BASE_CURRENCY);
		customerPennantRequest.setPrimaryRelationOfficer(DisbursementConstants.PRIMARY_RELATION_OFFICER);
		customerPennantRequest.setPersonalInfo(mapPROLPersonalInfo(userProfile, customerDisbDetails, headers));
		customerPennantRequest.setDedupReq(true);
		customerPennantRequest.setAddresses(isBusinessEntity
				? mapAddressDetailsForBolEntity(applicationDetails.getAddressList(),
						customerDisbDetails.getApplicantAddresses(), headers)
				: mapAddressDetails(applicationDetails.getAddressList(), customerDisbDetails.getApplicantAddresses(),
						headers));
		customerPennantRequest.setPhones(mapPhoneDetails(userProfile.getMobile()));
		customerPennantRequest.setEmails(mapEmailInfo(customerDisbDetails.getEmails(), headers));
		customerPennantRequest.setDocuments(
				mapDocumentsInfo(applicantType.equals(DisbursementConstants.CO_APPLICANT) ? userProfile.getPanNumber()
						: applicationDetails.getUserProfile().getPanNumber()));
		if (applicantType.equals(DisbursementConstants.MAIN_APPLICANT)) {
			customerPennantRequest.setCustomersBankInfo(mapCustomersBankInfo(bankDetailsList, headers));
		}
		return customerPennantRequest;
	}

	public CreateCustomerPennantRequest mapCustomerPennatRequestForFunded(
			FundedDisbursementEventRequestBean fundedRequest) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "mapCustomerPennatRequestForFunded : Start");
		CreateCustomerPennantRequest customerRequest = new CreateCustomerPennantRequest();
		customerRequest.setCategoryCode(DisbursementConstants.CUSTOMER_CATEGORY_RETAIL);
		customerRequest.setDefaultBranch(DisbursementConstants.DEFAULT_BRANCH_PUNE);
		customerRequest.setBaseCurrency(DisbursementConstants.BASE_CURRENCY);
		customerRequest.setPrimaryRelationOfficer(DisbursementConstants.PRIMARY_RELATION_OFFICER);
		customerRequest.setPersonalInfo(mapPersonalInfoForFunded(fundedRequest));
		customerRequest.setDedupReq(true);
		customerRequest.setAddresses(mapFundedAddressDetails(fundedRequest.getApplicantDetails().getAddresses()));
		customerRequest.setPhones(mapPhoneDetails(fundedRequest.getApplicantDetails().getMobileNumber()));
		customerRequest.setEmails(mapFundedEmailInfo(fundedRequest.getApplicantDetails().getOfficialEmailId(),
				fundedRequest.getApplicantDetails().getPersonalEmailId()));
		customerRequest.setCustomersIncome(null); // Confirm
		customerRequest.setDocuments(mapFundedDocumentsInfo(fundedRequest.getApplicantDetails().getFinnoneCustId()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "mapCustomerPennatRequestForFunded : End");
		return customerRequest;
	}

	private List<EmailInfo> mapFundedEmailInfo(String officialEmailId, String personalEmailId) {
		List<EmailInfo> emailInfoList = new ArrayList<EmailInfo>();
		// Personal Email Id
		EmailInfo personalInfo = new EmailInfo();
		personalInfo.setCustEMail(personalEmailId);
		personalInfo.setCustEMailPriority(new BigDecimal(5));
		personalInfo.setCustEMailTypeCode(DisbursementConstants.EMAIL_TYPE_PERSONAL);
		emailInfoList.add(personalInfo);
		return emailInfoList;
	}

	private List<DocumentInfo> mapFundedDocumentsInfo(String finCustId) {
		List<DocumentInfo> docInfoList = new ArrayList<>();
		DocumentInfo panInfo = new DocumentInfo();
		panInfo.setCustDocIssuedOn(DisbursementConstants.DOC_ISSUE_DATE);
		panInfo.setCustDocExpDate(DisbursementConstants.DOC_EXP_DATE);
		panInfo.setDocFormat(DisbursementConstants.DOC_FORMAT_PDF);
		panInfo.setCustDocIssuedAuth(DisbursementConstants.DOC_ISSUED_AUTH_IN);
		panInfo.setCustDocIssuedCountry(DisbursementConstants.DOC_ISSUED_COUNTRY_IN);
		panInfo.setCustDocTitle(DisbursementConstants.DOC_TITLE_PANCARD);
		panInfo.setDocCategory(DisbursementConstants.DOC_CATEGORY_OTH);
		panInfo.setDocName(finCustId + ".PDF");
		panInfo.setDocRefId(finCustId);
		docInfoList.add(panInfo);
		return docInfoList;
	}

	private List<AddressInfo> mapFundedAddressDetails(List<FundedAddressRequest> list) {
		List<AddressInfo> pennantAddr = new ArrayList<AddressInfo>();
		list.stream().forEach(x -> {
			AddressInfo addr = new AddressInfo();
			addr.setAddrType(x.getAddrType());
			addr.setBuildingNo(x.getBuildingNo());
			addr.setStreet(x.getStreet());
			addr.setPinCode(x.getPinCode());
			addr.setState("");
			addr.setCountry("");
			addr.setPriority(getPriorityOnAddrCode(x.getAddrType()));
			pennantAddr.add(addr);
		});
		return pennantAddr;
	}

	private PersonalInfo mapPersonalInfoForFunded(FundedDisbursementEventRequestBean fundedRequest) {
		PersonalInfo personalInfo = new PersonalInfo();
		personalInfo.setFirstName(fundedRequest.getApplicantDetails().getFirstName());
		personalInfo.setLastName(fundedRequest.getApplicantDetails().getLastName());
		personalInfo.setSalutation("DR");
		personalInfo.setDateofBirth(fundedRequest.getApplicantDetails().getDateOfBirth() + "T00:00:00");
		personalInfo.setCountryofBirth(DisbursementConstants.COUNTRY_OF_BIRTH_IND);
		personalInfo.setGender(fundedRequest.getApplicantDetails().getGender());
		personalInfo.setMaritalStatus(fundedRequest.getApplicantDetails().getMaritalStatus());
		personalInfo.setType(DisbursementConstants.DEFAULT_TYPE);
		personalInfo.setSector(DisbursementConstants.DEFAULT_SECTOR);
		personalInfo.setIndustry(DisbursementConstants.DEFAULT_INDUSTRY);
		return personalInfo;
	}

	@SuppressWarnings("unchecked")
	public PartnerProductMapMaster fetchPartnerProductMap(FundedDisbursementEventRequestBean fundedRequest) {
		List<BusinessVerticalMaster> verticals = new ArrayList<BusinessVerticalMaster>();
		List<PartnerProductMapMaster> productMap = new ArrayList<PartnerProductMapMaster>();
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getBusinessVerticleURL, String.class, params, null, headers);

		if (null != response.getBody()) {
			BusinessVerticalMaster[] genderCodeDtlsResponse = gson.fromJson(response.getBody(),
					BusinessVerticalMaster[].class);
			verticals = Arrays.asList(genderCodeDtlsResponse);
		}

		ResponseEntity<String> response1 = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getPartnerProductMapUrl, String.class, params, null, headers);

		if (null != response1.getBody()) {
			PartnerProductMapMaster[] mapsResponse = gson.fromJson(response1.getBody(),
					PartnerProductMapMaster[].class);
			productMap = Arrays.asList(mapsResponse);
		}

		Long businessMastKey = verticals.stream()
				.filter(x -> x.getBusinessverticalcode()
						.equalsIgnoreCase(fundedRequest.getApplicationDetails().getBusinessVertical())
						&& x.getPotypecode().equalsIgnoreCase(fundedRequest.getApplicationDetails().getPoType()))
				.findFirst().get().getBusinessverticalmastkey();
		PartnerProductMapMaster partnerProduct = productMap.stream()
				.filter(x -> businessMastKey == x.getBusinessverticalmastkey().longValue()
						&& x.getPolicytype().equalsIgnoreCase(fundedRequest.getApplicationDetails().getPolicyType())
						&& x.getProductcode()
								.equalsIgnoreCase(fundedRequest.getApplicationDetails().getL3ProductCode()))
				.findFirst().get();
		return partnerProduct;
	}

}
