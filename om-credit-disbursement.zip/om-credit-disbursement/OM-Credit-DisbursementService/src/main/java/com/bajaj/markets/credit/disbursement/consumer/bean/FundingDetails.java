package com.bajaj.markets.credit.disbursement.consumer.bean;

public class FundingDetails {

	private String reference;
	private String entityCode;
	private String amount;
	private String paymentMode;
	private String valueDate;
	private String stpProcess;
	private String reqType;
	private FundingReceiptDetail receiptDetail;

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getEntityCode() {
		return entityCode;
	}

	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public String getStpProcess() {
		return stpProcess;
	}

	public void setStpProcess(String stpProcess) {
		this.stpProcess = stpProcess;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public FundingReceiptDetail getReceiptDetail() {
		return receiptDetail;
	}

	public void setReceiptDetail(FundingReceiptDetail receiptDetail) {
		this.receiptDetail = receiptDetail;
	}

}
