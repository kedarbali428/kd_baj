package com.bajaj.markets.credit.disbursement.consumer.bean;

public class ApplicationStageDetails {
	
	private Integer stageKey;
	
	private Integer subStageKey;
	
	private Integer statusKey;
	
	private Integer percentageCompletion;

	public Integer getStageKey() {
		return stageKey;
	}
	public void setStageKey(Integer stageKey) {
		this.stageKey = stageKey;
	}

	public Integer getSubStageKey() {
		return subStageKey;
	}
	public void setSubStageKey(Integer subStageKey) {
		this.subStageKey = subStageKey;
	}
	
	public Integer getStatusKey() {
		return statusKey;
	}
	public void setStatusKey(Integer statusKey) {
		this.statusKey = statusKey;
	}
	
	public Integer getPercentageCompletion() {
		return percentageCompletion;
	}
	public void setPercentageCompletion(Integer percentageCompletion) {
		this.percentageCompletion = percentageCompletion;
	}
	
	@Override
	public String toString() {
		return "ApplicationStageDetails [stageKey=" + stageKey + ", subStageKey=" + subStageKey + ", statusKey="
				+ statusKey + ", percentageCompletion=" + percentageCompletion + "]";
	}

}
