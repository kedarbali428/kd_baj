package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class BeneficiaryBean {
	
	private String cif;
	private BigDecimal beneficiaryID;
	private String bankCode;
	private String branchKey;
	private String ifsc;
	private String accountNo;
	private String acHolderName;
	private String phoneCountryCode;
	private String phoneAreaCode;
	private String phoneNumber;
	private String micr;
	private String city;
	private String email;	
	private Boolean beneficiaryActive;	
	private Boolean defaultBeneficiary;
	
	private String disbDescription;
	
	private BigDecimal disbursementmode;
	private String ifsccode;
	
	private String flexiMobileNumber;
	
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public BigDecimal getBeneficiaryID() {
		return beneficiaryID;
	}
	public void setBeneficiaryID(BigDecimal beneficiaryID) {
		this.beneficiaryID = beneficiaryID;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getBranchKey() {
		return branchKey;
	}
	public void setBranchKey(String branchKey) {
		this.branchKey = branchKey;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAcHolderName() {
		return acHolderName;
	}
	public void setAcHolderName(String acHolderName) {
		this.acHolderName = acHolderName;
	}
	public String getPhoneCountryCode() {
		return phoneCountryCode;
	}
	public void setPhoneCountryCode(String phoneCountryCode) {
		this.phoneCountryCode = phoneCountryCode;
	}
	public String getPhoneAreaCode() {
		return phoneAreaCode;
	}
	public void setPhoneAreaCode(String phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public BigDecimal getDisbursementmode() {
		return disbursementmode;
	}
	public void setDisbursementmode(BigDecimal disbursementmode) {
		this.disbursementmode = disbursementmode;
	}
	public String getIfsccode() {
		return ifsccode;
	}
	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}
	public String getDisbDescription() {
		return disbDescription;
	}
	public void setDisbDescription(String disbDescription) {
		this.disbDescription = disbDescription;
	}
	/**
	 * @return the micr
	 */
	public String getMicr() {
		return micr;
	}
	/**
	 * @param micr the micr to set
	 */
	public void setMicr(String micr) {
		this.micr = micr;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Boolean getBeneficiaryActive() {
		return beneficiaryActive;
	}
	public void setBeneficiaryActive(Boolean beneficiaryActive) {
		this.beneficiaryActive = beneficiaryActive;
	}
	public Boolean getDefaultBeneficiary() {
		return defaultBeneficiary;
	}
	public void setDefaultBeneficiary(Boolean defaultBeneficiary) {
		this.defaultBeneficiary = defaultBeneficiary;
	}
	public String getFlexiMobileNumber() {
		return flexiMobileNumber;
	}
	public void setFlexiMobileNumber(String flexiMobileNumber) {
		this.flexiMobileNumber = flexiMobileNumber;
	}	

}
