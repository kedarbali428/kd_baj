
/**
 * 
 */
package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.awaitility.Awaitility;
import org.awaitility.core.ConditionTimeoutException;
import org.awaitility.pollinterval.FibonacciPollInterval;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.AdditionalParameterDetail;
import com.bajaj.markets.credit.disbursement.consumer.bean.Address;
import com.bajaj.markets.credit.disbursement.consumer.bean.AppTranchResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicantAddressInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationParameter;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationStageDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationStatus;
import com.bajaj.markets.credit.disbursement.consumer.bean.ArcduedateInput;
import com.bajaj.markets.credit.disbursement.consumer.bean.BankDetailsReponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.BeneficiaryBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.BflEmandatePaymentModeBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.BranchDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.BreDueDateRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.BreDueDateResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.CoapplicantBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CollateralBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CollateralRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateLoanExternalRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateLoanResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateMandateExternalResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateMandateResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreditReviewStatusBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CustomerDisbDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DocumentInfoBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.EmailInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.EmandateRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.EmandateResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FeeDetailsBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FinanceBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FinanceDetailBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FinanceScheduleBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundingDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundingReceiptDetail;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GstDetailBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.IntervalFeeBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.Loan;
import com.bajaj.markets.credit.disbursement.consumer.bean.LoanAccountResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.LoanCustomerRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.LoanProcessorVariables;
import com.bajaj.markets.credit.disbursement.consumer.bean.MandateBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.Name;
import com.bajaj.markets.credit.disbursement.consumer.bean.NotificationTemplateDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.OfferDetailsBRE;
import com.bajaj.markets.credit.disbursement.consumer.bean.PartnerProductMapMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.PennantMandateBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.PennantSystemDate;
import com.bajaj.markets.credit.disbursement.consumer.bean.PlanEMIHMonthsBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.PricingDetail;
import com.bajaj.markets.credit.disbursement.consumer.bean.PricingFees;
import com.bajaj.markets.credit.disbursement.consumer.bean.PrincipalFileUploadRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.UserProfile;
import com.bajaj.markets.credit.disbursement.consumer.bean.VasPricingCheckBean;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementMapperUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.LMSHelper;
import com.bajaj.markets.credit.disbursement.repository.MongoDBRepository;
import com.google.gson.Gson;

/**
 * @author pranoti.pandole
 *
 */
@Component
public class LoanProcessor {
	@Autowired
	DisbursementUtil disbursementUtil;

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Value("${erroScenarioFlg}")
	private String erroScenarioFlg;

	@Autowired
	LMSHelper lmsHelper;

	@Autowired
	MongoDBRepository mongoDbRepo;

	@Autowired
	VasProcessor vasProcessor;

	@Autowired
	DisbursementMapperUtil disbursementMapperUtil;

	@Autowired
	@Qualifier("disbursementMongoTemplate")
	MongoOperations disbursementMongoTemplate;

	@Value("${api.v2.lms.gateway.POST.url}")
	private String lmsUrl;

	@Value("${api.omcreditemployeeportalservice.tranchDetails.get.url}")
	private String tranchDetailsUrl;

	@Value("${api.omcreditapplicationservice.bankDetails.get.url}")
	private String bankDetailsUrl;

	@Value("${api.ommasterreferencedataservice.branchDetails.get.url}")
	private String branchDetailsUrl;

	@Value("${api.omcreditapplicationservice.pricingDetails.get.url}")
	private String pricingDetailsUrl;

	@Value("${api.omcreditapplicationservice.pricingcheck.get.url}")
	private String pricingLatestDetailsUrl;

	@Value("${api.omcreditapplicationservice.applicationDetails.get.url}")
	private String applicationDetailsUrl;

	@Value("${api.omcreditapplicationservice.addressDetails.get.url}")
	private String addressDetailsUrl;

	@Value("${hybridflexiloantypes}")
	private String hybridflexiloantypes;

	@Value("${api.ompaymentsemandatedomain.mandatDeRegetails.get.url}")
	private String mandateDetailsUrl;

	@Value("${api.omcreditapplicationservice.userprofiles.GET.url}")
	private String getUserProfilesUrl;

	@Value("${api.omcreditapplicationservice.mandatedetails.get.url}")
	private String repayEmandateUrl;

	@Value("${api.omcreditapplicationservice.repaybankDetails.get.url}")
	private String repayDetailsUrl;

	@Value("${api.omcreditapplicationservice.substage.put.url}")
	private String subStageUrl;

	@Value("${api.omcreditapplicationservice.status.put.url}")
	private String statusUrl;

	@Value("${bre-auth-type}")
	private String authtype;

	@Value("${bre-auth-userName}")
	private String authuserName;

	@Value("${bre-auth-password}")
	private String authpassword;

	@Value("${api.omcreditapplication.bre.POST.url}")
	private String breDueDateURL;

	@Value("${api.omcreditapplicationservice.creditapplication.PUT.url}")
	private String updateApplicationForLAN;

	@Value("${api.omreferencedatareferencedataservice.subrepaymode.GET.url}")
	private String subRepayModeDtl;

	@Value("${initiateDisbUrl}")
	private String initiateDisbUrl;

	@Value("${solloantypes}")
	private String solloantypes;

	@Value("${bolloantypes}")
	private String bolloantypes;

	@Value("${prolloantypes}")
	private String prolloantypes;

	@Value("${api.loanaccountservice.accountLoans.GET.url}")
	private String accountLoanURL;

	@Value("${initiateBflDisbUrl}")
	private String initiateBflDisbUrl;

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	NotificationProcessor notificationProcessor;

	private static final String CLASS_NAME = LoanProcessor.class.getCanonicalName();

	public void processLoanRequest(GlobalDataBean data) {
		try {
			LoanProcessorVariables processorVariables = new LoanProcessorVariables();
			if(null==data.getEmail() || data.getEmail().isEmpty())
				fetchEmail(data);
			NotificationTemplateDataBean notificationTemplateBean = new NotificationTemplateDataBean();
			processorVariables.setNotificationTemplateBean(notificationTemplateBean);
			processorVariables.setL3product(data.getL3ProductCode());
			CreateLoanExternalRequest createLoanExternalRequest = fetchLoanPennantRequest(data, processorVariables);
			Long startTime = null;
			Long stopTime = null;
			try {
				startTime = System.currentTimeMillis();
				FibonacciPollInterval fibonacci = new FibonacciPollInterval(TimeUnit.SECONDS);
				Awaitility.setDefaultTimeout(300, TimeUnit.SECONDS);
				Awaitility.with().pollInterval(fibonacci).await().atMost(300, TimeUnit.SECONDS)
						.until(() -> null != (executeLMSRequestforLoan(data.getApplicationKey(),
								data.getL2ProductCode(), createLoanExternalRequest, generateHeaders(data),
								processorVariables)));
				stopTime = System.currentTimeMillis();
			} catch (ConditionTimeoutException e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Time out flow of CreateLoan ::");
				saveRetryDetails(data, false, "Pending");
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Time out flow of CreateLoan ends::");
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, " loan request in progress :" + data.getErrFlg());
			if (data.getErrFlg()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						" loan request in progress fetching cif for:" + data.getApplicationKey());
				String cif = fetchCifId(Long.valueOf(data.getApplicationKey()), Long.parseLong(data.getApplicantKey()));
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, " loan request in progress cif:" + cif);
				LoanCustomerRequestBean bean = new LoanCustomerRequestBean();
				bean.setCif(cif);
				String response = executeLMSTimeOutRequestforLoan(data.getApplicationKey(), data.getL2ProductCode(),
						bean, generateHeaders(data));
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						" loan request in progress fetching finreference:");
				String lanNumber = null;
				String firstEmiAmnt = null;
				processorVariables.setLoanResponseString(response);
				Gson gson = new Gson();
				Loan loan = gson.fromJson(response.toString(), Loan.class);
				List<FinanceBean> finBeanLst = loan.getFinances();
				for (FinanceBean finBean : finBeanLst) {
					if (finBean.getApplicationNo().toString().equalsIgnoreCase(data.getApplicationKey())) {
						lanNumber = finBean.getFinReference();
						firstEmiAmnt = finBean.getFirstEmiAmount().toString();
					}
				}

				processorVariables.getNotificationTemplateBean().setLanNumber(lanNumber);
				processorVariables.getNotificationTemplateBean().setFirstEmiAmt(firstEmiAmnt);
				updateServiceRecordForLoan(data.getApplicationKey(), data.getApplicantKey(), lanNumber);
				updateApplicationForLAN(data.getApplicationKey(), lanNumber, generateHeaders(data));
				disbursementUtil.updateAppTranch(data.getApplicationKey(),
						DisbursementConstants.TRANCHE_STATUS_DISBURSED, DisbursementConstants.DISB_SUCCESS_FLAG, null,
						processorVariables.getDisbAmount(), generateHeaders(data));
				saveRetryDetails(data, false, "Success");
				// LEN-970 : If Policy issued successfully, then proceed to issue Vas
				// application.
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Starting Vas Policy Issue Init event." + data.getApplicationKey());
				String vasDisbEvent = vasProcessor.vasDisbursementInitEventRaiseExt(data.getApplicationKey(),
						generateHeaders(data));
				// vasDisbEvent = Either "Success" or "Failure"
				if ("Success".equals(vasDisbEvent)) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
							"Vas Policy Issue Init event raised successfully." + data.getApplicationKey());
				} else {
					logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
							"Vas Policy Issue Init event raise failed." + data.getApplicationKey());
				}
				updateApplicationStageDetails(data.getApplicationKey(), generateHeaders(data));
				updateApplicationStageDetails(data.getParentApplicationKey(), generateHeaders(data));
				updateApplicationStatusDetails(data.getApplicationKey(), generateHeaders(data));
				DisbursementEventRequestBean disbursementEventRequestBean = new DisbursementEventRequestBean();
				disbursementEventRequestBean.setApplicantId(data.getApplicantKey());
				disbursementEventRequestBean.setApplicationId(data.getApplicationKey());
				disbursementEventRequestBean.setEventType(DisbursementConstants.DISBURSEMENT_COMPLETED);
				disbursementEventRequestBean.setProductCode(data.getL3ProductCode());
				disbursementEventRequestBean.setHeaders(data.getHeaders());
				boolean eventflg = disbursementUtil.raiseEvent(disbursementEventRequestBean,
						DisbursementConstants.DISBURSEMENT_COMPLETED);
				processorVariables.setRetryMechanism(true);
				notificationProcessor.sendNotifications(processorVariables.getNotificationTemplateBean(), data);
				disbursementUtil.sendSmartechNotification(processorVariables.getNotificationTemplateBean().getAmount(),
						data);
				disbursementUtil.raiseFinnoneIdEvent(data,lanNumber);
			}
			if (null != processorVariables.getLoanResponseString()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Inside loanResponseString not null and isRetryMechanism:"
								+ processorVariables.isRetryMechanism() + " for" + data.getApplicationKey());
				if (!processorVariables.isRetryMechanism()) {
					disbursementUtil.addDisbursementRecords(data.getApplicationKey(), data.getApplicantKey(),
							mapToJson(createLoanExternalRequest), processorVariables.getLoanResponseString(),
							DisbursementConstants.LMS_CREATE_LOAN_SOURCE,
							null != startTime ? startTime.toString() : null,
							null != stopTime ? stopTime.toString() : null);
					String status = processLoanLmsResponse(data, processorVariables.getLoanResponseString(),
							generateHeaders(data), processorVariables);
					logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
							"Inside loanResponseString not null and status:" + status);
					logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
							"Inside loanResponseString not null and isRetryMechanism:"
									+ processorVariables.isRetryMechanism() + " and status:" + status + " for"
									+ data.getApplicationKey());
					if (status.equalsIgnoreCase(DisbursementConstants.DISB_SUCCESS)) {
						logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
								"Inside loanResponseString not null and success status for" + data.getApplicationKey());
						notificationProcessor.sendNotifications(processorVariables.getNotificationTemplateBean(), data);
						disbursementUtil.sendSmartechNotification(
								processorVariables.getNotificationTemplateBean().getAmount(), data);
					}
				}
			}

		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception occurred in Loan Call");
		}
	}

	private void fetchEmail(GlobalDataBean data) {
		CustomerDisbDetails customerDisbDetails = disbursementUtil.fetchCustomerDisbDetails(data.getApplicationKey(),
				data.getAppAtrKey(), generateHeaders(data));
		List<EmailInfo> emails=disbursementMapperUtil.mapEmailInfo(customerDisbDetails.getEmails(), generateHeaders(data));
		Optional<EmailInfo> personalEmailInfo = emails.stream()
				.filter(x -> x.getCustEMailTypeCode().equalsIgnoreCase("PERSONAL")).findAny();
		data.setEmail(personalEmailInfo.get().getCustEMail());
	}

	private String processLoanLmsResponse(GlobalDataBean data, String loanResponseString, HttpHeaders headers,
			LoanProcessorVariables processorVariables) {
		String status = null;
		Gson gson = new Gson();
		CreateLoanResponseBean createLoanResponseBean = gson.fromJson(loanResponseString, CreateLoanResponseBean.class);
		String returnCode = createLoanResponseBean.getReturnStatus().getReturnCode();
		String finReference = null;
		String firstEmiAmount = null;
		if (DisbursementConstants.PENNANT_SUCCES_CODE.equals(returnCode)) {
			finReference = createLoanResponseBean.getFinReference();
			firstEmiAmount = null != createLoanResponseBean.getFinanceSchedule()
					? createLoanResponseBean.getFinanceSchedule().getSummary().getFirstEmiAmount().toBigInteger()
							.toString()
					: null;
			processorVariables.getNotificationTemplateBean().setLanNumber(finReference);
			// processorVariables.getNotificationTemplateBean().setFirstEmiAmt(firstEmiAmount);
			updateServiceRecordForLoan(data.getApplicationKey(), data.getApplicantKey(), finReference);
			status = processLoanDisbSuccess(data, headers, finReference, processorVariables);
		} else if (DisbursementConstants.LOAN_APPLICATION_EXIST_IN_PENNANT_CODE.equals(returnCode)) {
			LoanCustomerRequestBean bean = new LoanCustomerRequestBean();
			bean.setCif(fetchCifId(Long.valueOf(data.getApplicationKey()), Long.parseLong(data.getApplicantKey())));
			String response = executeLMSTimeOutRequestforLoan(data.getApplicationKey(), data.getL2ProductCode(), bean,
					generateHeaders(data));
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					" loan request in progress fetching finreference for Dedupe:");
			loanResponseString = response;
			Loan loan = gson.fromJson(response.toString(), Loan.class);
			List<FinanceBean> finBeanLst = loan.getFinances();
			for (FinanceBean finBean : finBeanLst) {
				if (finBean.getApplicationNo().toString().equalsIgnoreCase(data.getApplicationKey())) {
					finReference = finBean.getFinReference();
					Integer firstEmiAmnyWithoutDecimal = finBean.getFirstEmiAmount().intValue();
					firstEmiAmount = firstEmiAmnyWithoutDecimal.toString();
				}
			}

			if (null != finReference) {
				processorVariables.getNotificationTemplateBean().setLanNumber(finReference);
				// processorVariables.getNotificationTemplateBean().setFirstEmiAmt(firstEmiAmount);
				updateServiceRecordForLoan(data.getApplicationKey(), data.getApplicantKey(), finReference);
				status = processLoanDisbSuccess(data, headers, finReference, processorVariables);
			} else {
				status = processLoanDisbFailure(data, loanResponseString, headers);
			}
		} else {
			status = processLoanDisbFailure(data, loanResponseString, headers);
		}
		return status;
	}

	private String processLoanDisbSuccess(GlobalDataBean data, HttpHeaders headers, String finReference,
			LoanProcessorVariables processorVariables) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, " processLoanDisbSuccess : " + data.getApplicationKey());
		String status;
		status = "Success";
		updateApplicationForLAN(data.getApplicationKey(), finReference, headers);
		disbursementUtil.updateAppTranch(data.getApplicationKey(), DisbursementConstants.TRANCHE_STATUS_DISBURSED,
				DisbursementConstants.DISB_SUCCESS_FLAG, null, processorVariables.getDisbAmount(), headers);
		// LEN-970 : If Policy issued successfully, then proceed to issue Vas
		// application.
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Starting Vas Policy Issue Init event." + data.getApplicationKey());
		String vasDisbEvent = vasProcessor.vasDisbursementInitEventRaiseExt(data.getApplicationKey(), headers);
		// vasDisbEvent = Either "Success" or "Failure"
		if ("Success".equals(vasDisbEvent)) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Vas Policy Issue Init event raised successfully." + data.getApplicationKey());
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Vas Policy Issue Init event raise failed." + data.getApplicationKey());
		}
		updateApplicationStageDetails(data.getApplicationKey(), generateHeaders(data));
		updateApplicationStageDetails(data.getParentApplicationKey(), generateHeaders(data));
		updateApplicationStatusDetails(data.getApplicationKey(), generateHeaders(data));
		DisbursementEventRequestBean disbursementEventRequestBean = new DisbursementEventRequestBean();
		disbursementEventRequestBean.setApplicantId(data.getApplicantKey());
		disbursementEventRequestBean.setApplicationId(data.getApplicationKey());
		disbursementEventRequestBean.setEventType("DISBURSEMENT_COMPLETED");
		disbursementEventRequestBean.setProductCode(data.getL3ProductCode());
		disbursementEventRequestBean.setHeaders(data.getHeaders());
		boolean eventflg = disbursementUtil.raiseEvent(disbursementEventRequestBean,
				DisbursementConstants.DISBURSEMENT_COMPLETED);
		disbursementUtil.raiseFinnoneIdEvent(data,finReference);
		return status;
	}

	private String processLoanDisbFailure(GlobalDataBean data, String loanResponseString, HttpHeaders headers) {
		String status;
		status = "Failure";
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, " processLoanDisbFailure : " + data.getApplicationKey());
		disbursementUtil.updateAppTranch(data.getApplicationKey(), DisbursementConstants.TRANCHE_STATUS_FAILED,
				DisbursementConstants.DISB_FAILURE_FLAG, null, null, headers);
		if ("Y".equals(erroScenarioFlg)) {
			saveDisbursementError(data, data.getApplicationKey(), loanResponseString);
			DisbursementEventRequestBean disbursementEventRequestBean = new DisbursementEventRequestBean();
			disbursementEventRequestBean.setApplicantId(data.getApplicantKey());
			disbursementEventRequestBean.setApplicationId(data.getApplicationKey());
			disbursementEventRequestBean.setEventType("CREATE_LOAN_FAILED");
			disbursementEventRequestBean.setProductCode(data.getL3ProductCode());
			disbursementEventRequestBean.setHeaders(data.getHeaders());
			disbursementUtil.raiseEvent(disbursementEventRequestBean, DisbursementConstants.DISBURSEMENT_FAILED);
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "CREATE_LOAN_FAILED  failed: ");
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "CREATE_LOAN_FAILED  failed: ");
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CDS-200", "CREATE_LOAN_FAILED"));
		}
		return status;
	}

	private void saveDisbursementError(GlobalDataBean data, String applicationId, String loanResponseString) {
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		disbursementTrackerBean.setApplicationId(Long.parseLong(applicationId));
		disbursementTrackerBean.setDisbursmentstage(DisbursementConstants.CREATE_LOAN);
		disbursementTrackerBean.setError(DisbursementConstants.CREATE_LOAN_FAILED);
		String errorReason = disbursementUtil.logDisbErrors(applicationId, loanResponseString);
		disbursementTrackerBean.setErrorreason(errorReason);
		disbursementTrackerBean.setErrorretryable(1l);
		disbursementTrackerBean.setIsActive(1l);
		disbursementTrackerBean.setStatus("CREATED");
		disbursementUtil.saveDisbursementErrorDetails(data, disbursementTrackerBean);
	}

	@SuppressWarnings("unchecked")
	private void updateApplicationForLAN(String applicationId, String finRefNo, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "updateApplicationForLAN : Start :");
		ApplicationParameter applicationParameter = new ApplicationParameter();
		Map<String, String> applicationParameters = new HashMap<>();
		applicationParameters.put(DisbursementConstants.PRODUCT_REF_NO, finRefNo);
		applicationParameter.setApplicationParameters(applicationParameters);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		Gson gson = new Gson();
		String inputStr = gson.toJson(applicationParameter, ApplicationParameter.class);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.PUT, updateApplicationForLAN, String.class, params, inputStr, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"updateApplicationForLAN : End : " + response.getStatusCodeValue());
	}

	public void updateServiceRecordForLoan(String applicationKey, String applicantKey, String finRefId) {
		mongoDbRepo.updateFieldByApplicationKeyAndApplicantKey(disbursementMongoTemplate, Long.valueOf(applicationKey),
				Long.valueOf(applicantKey), "customerLoanId", finRefId, DisbursementConstants.SERVICE_RECORD);
	}

	private String executeLMSRequestforLoan(String applicationId, String prodCode,
			CreateLoanExternalRequest loanRequest, HttpHeaders headers, LoanProcessorVariables processorVariables) {
		String loanRequestStr = mapToJson(loanRequest);
		Object response = lmsHelper.executeLmsRequest(DisbursementConstants.LMS_CREATE_LOAN_SOURCE, prodCode,
				loanRequestStr, applicationId, headers);
		processorVariables.setLoanResponseString(response.toString());
		return response.toString();
	}

	private String executeLMSTimeOutRequestforLoan(String applicationId, String prodCode, LoanCustomerRequestBean bean,
			HttpHeaders headers) {
		String loanRequestStr = mapToJson(bean);
		Object response = lmsHelper.executeLMSTimeOutRequestforLoan(DisbursementConstants.LMS_LOAN_CUSTOMER, prodCode,
				loanRequestStr, applicationId, headers);
		return response.toString();
	}

	public <T> String mapToJson(T object) {
		Gson gson = new Gson();
		return gson.toJson(object);
	}

	public CreateLoanExternalRequest fetchLoanPennantRequest(GlobalDataBean data,
			LoanProcessorVariables processorVariables) {
		CreateLoanExternalRequest createLoanExternalRequest = new CreateLoanExternalRequest();
		List<DisbursementBean> disbursementlst = processDisbursementAgrregate(data, processorVariables);// Done
		FinanceScheduleBean financeScheduleBean = new FinanceScheduleBean();
		FinanceDetailBean financeDetail = processFinanceDetails(data, processorVariables);
		List<CollateralBean> collateralLst = processCollataeralAggregate(data);
		List<FeeDetailsBean> feeDetailslst = processFees(data, financeScheduleBean, processorVariables);
		MandateBean mandateBean = processMandateDisbAggregate(data, disbursementlst.get(0), financeDetail,
				processorVariables);
		List<DocumentInfoBean> docList = new ArrayList<DocumentInfoBean>();
		createLoanExternalRequest.setDocuments(docList);
		List<PlanEMIHMonthsBean> emiMonths = new ArrayList<>();
		financeScheduleBean.setPlanEMIHmonths(emiMonths);// TO DO :need to check if mandatory in pennant all request
		PennantSystemDate callPennantForSystemDate = disbursementUtil.callPennantForSystemDate(data, lmsUrl);
		financeScheduleBean.setVas(vasProcessor.getVasList(data, feeDetailslst,
				callPennantForSystemDate.getAppDate() + DisbursementConstants.TIMESTAMP_FORMAT));
		financeScheduleBean.setFees(feeDetailslst);
		financeScheduleBean.setFinanceDetail(financeDetail);
		BeneficiaryBean beneficiaryBean = new BeneficiaryBean();
		beneficiaryBean
				.setBeneficiaryID(new BigDecimal(fetchBeneficiaryId(data.getApplicationKey(), data.getApplicantKey())));
		beneficiaryBean.setFlexiMobileNumber(data.getMobile());
		createLoanExternalRequest.setBeneficiary(beneficiaryBean);
		createLoanExternalRequest.setCollaterals(collateralLst);
		createLoanExternalRequest.setDisbursement(disbursementlst);
		createLoanExternalRequest.setFinanceSchedule(financeScheduleBean);
		createLoanExternalRequest.setMandateDetail(mandateBean);
		createLoanExternalRequest.setBeneficiary(beneficiaryBean);
		createLoanExternalRequest.setStp(true);
		createLoanExternalRequest.setProcessStage(DisbursementConstants.PROCESS_STAGE_BLANK);
		CreditReviewStatusBean creditReviewStatusBean = disbursementUtil
				.getCreditReviewDetails(data.getApplicationKey(), generateHeaders(data));
		boolean businessEntityReq = false;
		boolean indvCoApplicantReq = false;
		if (null != creditReviewStatusBean) {
			if(null != creditReviewStatusBean.getEntityCoapplicantRequired()
					&& creditReviewStatusBean.getEntityCoapplicantRequired().equals("1"))
				businessEntityReq = true;
			if(null != creditReviewStatusBean.getIndividualCoapplicantRequired()
					&& creditReviewStatusBean.getIndividualCoapplicantRequired().equals("1"))
				indvCoApplicantReq = true;
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"LoanProcessor Coapplicant Details "+data.getApplicationKey()+" - businessEntityReq : " + businessEntityReq + "indvCoApplicantReq :"+ indvCoApplicantReq);
		if (fetchBolFlag(data.getL3ProductCode())) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"fetchLoanPennantRequest Inside fetchBolFlag " + data.getApplicationKey());
			if (businessEntityReq)
				createLoanExternalRequest.setGstDetail(fetchGstDetails(data));

			if (businessEntityReq || indvCoApplicantReq)
				createLoanExternalRequest.setCoApplicants(fetchCoApplicantsCif(data));

		} else if (fetchProlFlag(data.getL3ProductCode()) && indvCoApplicantReq) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"fetchLoanPennantRequest 3" + data.getApplicationKey());
			createLoanExternalRequest.setCoApplicants(fetchCoApplicantsCif(data));
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"fetchLoanPennantRequest 4" + data.getApplicationKey());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchLoanPennantRequest 5" + data.getApplicationKey());
		return createLoanExternalRequest;
	}

	private List<CoapplicantBean> fetchCoApplicantsCif(GlobalDataBean data) {
		List<CoapplicantBean> coApplicantCifList = new ArrayList<>();
		if (null != data.getCoApplicantKey()) {
			CoapplicantBean coApplicantBean = new CoapplicantBean();
			coApplicantBean.setCif(fetchCifForApplicant(data.getApplicationKey(), data.getCoApplicantKey()));
			coApplicantCifList.add(coApplicantBean);
		}
		if (null != data.getBusinessPan()) {
			CoapplicantBean entityBean = new CoapplicantBean();
			entityBean.setCif(fetchCifForBusinessEntity(data.getApplicationKey(), data.getBusinessPan()));
			coApplicantCifList.add(entityBean);
		}
		return coApplicantCifList;
	}

	private GstDetailBean fetchGstDetails(GlobalDataBean data) {
		GstDetailBean gstDetails = new GstDetailBean();
		ApplicationDetails applicationDetails = disbursementUtil.fetchApplicationDetails(data.getApplicationKey(),
				data.getAppAtrKey(), generateHeaders(data));
		Address officeAddress1 = applicationDetails.getAddressList().stream()
				.filter(x -> x.getAddressTypeKey().equals(DisbursementConstants.ADDRESS_TYPE_OFFICE_KEY)).findFirst()
				.orElse(null);
		CustomerDisbDetails customerDisbDetails = disbursementUtil.fetchCustomerDisbDetails(data.getApplicationKey(),
				data.getAppAtrKey(), generateHeaders(data));
		ApplicantAddressInfo officeAddress2 = customerDisbDetails.getApplicantAddresses().stream()
				.filter(x -> x.getAddrtypkey().toString().equals(DisbursementConstants.ADDRESS_TYPE_OFFICE_KEY))
				.findFirst().orElse(null);
		gstDetails.setTaxNumber(StringUtils
				.defaultIfBlank(applicationDetails.getOccupation().getBusinessOwnerDetails().getGstNumber(), ""));
		gstDetails.setPinCode(disbursementUtil.fetchPincodeDetails(Long.valueOf(officeAddress1.getPincodeKey()),
				generateHeaders(data)));
		gstDetails.setAddrLine1(officeAddress2.getAddrLine1());
		gstDetails.setAddrLine2(officeAddress2.getAddrLine2());
		if (null != officeAddress1.getLocalitykey()) {
			gstDetails.setAddrLine3(disbursementUtil.fetchLocalityDetails(Long.valueOf(officeAddress1.getCityKey()),
					officeAddress1.getLocalitykey(), generateHeaders(data)));
		}
		gstDetails.setAddrLine4(null);
		gstDetails.setProvince("");
		gstDetails.setTaxExempted(false);
		if (DisbursementConstants.BUSINESS_KEY_PROPRIETORSHIP
				.equals(applicationDetails.getOccupation().getBusinessOwnerDetails().getBusinessType().getKey())) {
			gstDetails.setCustomerRef(fetchCifForApplicant(data.getApplicationKey(), data.getApplicantKey()));
			gstDetails.setApplicableFor(DisbursementConstants.APPLICABLE_PRIMARY);
		} else {
			gstDetails.setCustomerRef(fetchCifForBusinessEntity(data.getApplicationKey(), data.getBusinessPan()));
			gstDetails.setApplicableFor(DisbursementConstants.APPLICABLE_ENTITY);
		}
		return gstDetails;
	}

	private String fetchCifForBusinessEntity(String applicationKey, String businessPan) {
		List<DisbursementMongoObject> disbursementMongoObjectList = mongoDbRepo.fetchObjectByKey(
				disbursementMongoTemplate, "businessPan", businessPan, DisbursementConstants.SERVICE_RECORD);
		DisbursementMongoObject result = disbursementMongoObjectList.stream()
				.filter(x -> x.getApplicationKey().equals(Long.valueOf(applicationKey))).findFirst().orElse(null);
		return result.getCif();
	}

	private String fetchCifForApplicant(String applicationKey, String applicantKey) {
		List<DisbursementMongoObject> disbursementMongoObjectList = mongoDbRepo.fetchObjectByKey(
				disbursementMongoTemplate, "applicantKey", Long.valueOf(applicantKey),
				DisbursementConstants.SERVICE_RECORD);
		DisbursementMongoObject result = disbursementMongoObjectList.stream()
				.filter(x -> x.getApplicationKey().equals(Long.valueOf(applicationKey))).findFirst().orElse(null);
		return result.getCif();
	}

	public FinanceDetailBean processFinanceDetails(GlobalDataBean data, LoanProcessorVariables processorVariables) {
		String typeKeyForAddrTypeCurrent = DisbursementConstants.ADDRESS_TYPE_CURRENT_KEY;
		PricingDetail activepricingDetail = new PricingDetail();
		List<PricingDetail> pricingDetailLst = fetchPricingDetails(data.getApplicationKey(), generateHeaders(data));
		VasPricingCheckBean latestPricing = fetchLatestPricingDetails(data.getApplicationKey(), generateHeaders(data));
		if (null != pricingDetailLst && !pricingDetailLst.isEmpty()) {
			for (PricingDetail pricingDetail : pricingDetailLst) {
				if (pricingDetail.getAppLoanPricingKey()
						.equalsIgnoreCase(latestPricing.getAppLoanPricingKey().toString())) {
					activepricingDetail = pricingDetail;
					break;
				}
			}
		}
		FinanceDetailBean financeDetailBean = new FinanceDetailBean();
		financeDetailBean.setApplicationNo(data.getApplicationKey());
		String cif = fetchCifId(Long.valueOf(data.getApplicationKey()), Long.parseLong(data.getApplicantKey()));
		financeDetailBean.setCif(cif);
		financeDetailBean.setFinType(activepricingDetail.getPennantLoanType());
		financeDetailBean.setFinCcy("INR");
		financeDetailBean.setDownPayBank("0");
		financeDetailBean.setDownPaySupl("0");
		financeDetailBean.setTdsApplicable("false");
		financeDetailBean.setManualSchedule("false");
		financeDetailBean.setPlanDeferCount("0");
		financeDetailBean.setGrcPftFrq("M0002");
		financeDetailBean.setAllowGrcPeriod("false");
		financeDetailBean.setGrcSchdMthd("PFT");
		financeDetailBean.setReqRepayAmount("0");
		financeDetailBean.setRepayRateBasis("R");
		financeDetailBean.setScheduleMethod("EQUAL");
		financeDetailBean.setRepayFrq("M0002");
		financeDetailBean.setRepayPftFrq("M0002");
		financeDetailBean.setFinRepayPftOnFrq("true");
		financeDetailBean.setRepayMinRate("0");
		financeDetailBean.setRepayMaxRate("0");
		financeDetailBean.setAlwBpiTreatment("true");
		PennantSystemDate callPennantForSystemDate = disbursementUtil.callPennantForSystemDate(data, lmsUrl);
		financeDetailBean
				.setFinStartDate(callPennantForSystemDate.getAppDate() + DisbursementConstants.TIMESTAMP_FORMAT);
		UserProfile userprof = fetchUserProfile(data);
		Address address = fetchAddressDetails(data.getApplicationKey(), userprof.getApplicationUserAttributeKey(),
				typeKeyForAddrTypeCurrent, generateHeaders(data));
		/*
		 * ApplicationDetails applicationDetails =
		 * disbursementUtil.fetchApplicationDetails(data.getApplicationKey(),
		 * data.getAppAtrKey(), generateHeaders(data));
		 */
		/*
		 * Long branchKey =
		 * disbursementMapperUtil.fetchbflbranchServicesMaster(Long.parseLong(address.
		 * getCityKey()),
		 * applicationDetails.getOccupation().getOcupationType().getKey(),data.
		 * getL3ProductKey(),data.getL2ProductKey(), generateHeaders(data));
		 * financeDetailBean.setFinBranch(
		 * disbursementMapperUtil.fetchBrchbyBranchKey(branchKey, address.getCityKey(),
		 * generateHeaders(data)));
		 */
		String cityName = disbursementMapperUtil.fetchPinCodeServiceableMaster(address.getPincodeKey(),
				data.getL3ProductKey(), generateHeaders(data));
		financeDetailBean.setFinBranch(
				disbursementMapperUtil.fetchBrchbyCity(cityName, address.getCityKey(), generateHeaders(data)));
		if (null != activepricingDetail) {
			Integer finAmt = activepricingDetail.getFinalLoanAmount().intValue();
			financeDetailBean.setFinAmount(finAmt.toString());
			financeDetailBean.setFinAssetValue(finAmt.toString());
		}
		processorVariables.setHybridFlexi(fetchHybridFlexiFlag(financeDetailBean.getFinType()));
		if (null != activepricingDetail)
			financeDetailBean.setGrcTerms(
					processorVariables.isHybridFlexi() ? activepricingDetail.getIsTenure().toString() : null);
		if (null != activepricingDetail.getFinalRoi())
			financeDetailBean.setGrcPftRate(activepricingDetail.getFinalRoi().toString());
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		Date eminextDt = null;
		Date emifirstDt = null;
		String eminextDtfmt = null;
		String emifirstDtfmt = null;
		BreDueDateResponse breRes = callBRE(data, activepricingDetail, generateHeaders(data),
				processorVariables.isHybridFlexi());
		try {
			if (null != breRes.getArcduedateOutput().getNextDueDateDetails()
					&& !breRes.getArcduedateOutput().getNextDueDateDetails().isEmpty()) {
				eminextDt = new SimpleDateFormat("yyyy-MM-dd")
						.parse(breRes.getArcduedateOutput().getNextDueDateDetails().get(0).getNextDueDate());
				eminextDtfmt = df.format(eminextDt);
			}
			if (null != breRes.getArcduedateOutput().getDueDateDetails()
					&& !breRes.getArcduedateOutput().getDueDateDetails().isEmpty()) {
				emifirstDt = new SimpleDateFormat("yyyy-MM-dd")
						.parse(breRes.getArcduedateOutput().getDueDateDetails().get(0).getFirstDueDate());
				emifirstDtfmt = df.format(emifirstDt);
			}
			if (processorVariables.isHybridFlexi()) {
				financeDetailBean.setNextGrcPftDate(emifirstDtfmt);
				financeDetailBean.setNextRepayDate(eminextDtfmt);
				financeDetailBean.setNextRepayPftDate(eminextDtfmt);
			} else {
				financeDetailBean.setNextRepayDate(emifirstDtfmt);
				financeDetailBean.setNextRepayPftDate(emifirstDtfmt);
			}
		} catch (ParseException e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing NextGrcPftDate.");
		}
		Integer numterms = activepricingDetail.getDroplineTenure();
		financeDetailBean.setNumberOfTerms(numterms.toString());
		if (null != activepricingDetail.getFinalRoi())
			financeDetailBean.setRepayPftRate(activepricingDetail.getFinalRoi().toString());
		financeDetailBean.setRelationshipOfficer("DEFAULT");
		if (processorVariables.isHybridFlexi()) {
			financeDetailBean.setAlwFlexi("true");
			financeDetailBean.setAllowGrcPeriod("true");
			financeDetailBean.setAllowGrcRepay("true");
			if (financeDetailBean.getFinType().equalsIgnoreCase("SOFL"))
				financeDetailBean.setFlexiType("P");
			else
				financeDetailBean.setFlexiType("H");
		} else {
			financeDetailBean.setAlwFlexi("false");
		}
		if (null != processorVariables.getFinRepaymethod())
			financeDetailBean.setFinRepayMethod(processorVariables.getFinRepaymethod().toString());
		processorVariables.setBundleApplicationPlanCode(null != latestPricing.getBundleApplicationPlanCode() ? latestPricing.getBundleApplicationPlanCode() : null);
		mapNotificationTemplateData(data, activepricingDetail, processorVariables.isHybridFlexi(), userprof.getName(),processorVariables.getNotificationTemplateBean());
		return financeDetailBean;
	}

	private void mapNotificationTemplateData(GlobalDataBean data, PricingDetail pricingDetail, boolean isHybridFlexi,
			Name name, NotificationTemplateDataBean notificationTemplateBean) {
		notificationTemplateBean.setApplicationId(data.getApplicationKey());
		notificationTemplateBean.setCustomerName(name.getFirstName().concat(" ").concat(name.getLastName()));
		notificationTemplateBean.setProductName(data.getL3ProductCode());
		notificationTemplateBean.setAmount(pricingDetail.getFinalLoanAmount().toBigInteger().toString());
		notificationTemplateBean
				.setRoi(null != pricingDetail.getFinalRoi() ? pricingDetail.getFinalRoi().toString() : null);
		Integer tenor = (null != pricingDetail.getIsTenure()
				? (pricingDetail.getDroplineTenure() + pricingDetail.getIsTenure())
				: pricingDetail.getDroplineTenure());
		notificationTemplateBean.setTenor(tenor.toString());
		notificationTemplateBean.setHybridFlexi(isHybridFlexi);
		notificationTemplateBean
				.setIsTenure(null != pricingDetail.getIsTenure() ? pricingDetail.getIsTenure().toString() : null);
		notificationTemplateBean.setIsEmiAmt(null != pricingDetail.getIsEmi() ? pricingDetail.getIsEmi() : null);
		notificationTemplateBean.setDroplineTenure(
				null != pricingDetail.getDroplineTenure() ? pricingDetail.getDroplineTenure().toString() : null);
		notificationTemplateBean.setDropLineEmiAmt(
				null != pricingDetail.getDroplineEmi() ? pricingDetail.getDroplineEmi().toBigInteger().toString()
						: null);
		notificationTemplateBean
				.setEmiCycleDay(null != pricingDetail.getDueDay() ? pricingDetail.getDueDay().toString() : null);
		SimpleDateFormat oldFormat = new SimpleDateFormat("yyyy-MM-dd");
		String firstEmiDateFormatted = null;
		try {
			Date date = oldFormat.parse(pricingDetail.getFirstDueDate());
			SimpleDateFormat newFormat = new SimpleDateFormat("dd-MM-yyyy");
			firstEmiDateFormatted = newFormat.format(date);

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"LoanProcessor : mapNotificationTemplateData() : Unable to parse String date", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"LoanProcessor : mapNotificationTemplateData() : Unable to parse String date");
		}
		notificationTemplateBean.setFirstEMIdt(null != firstEmiDateFormatted ? firstEmiDateFormatted : null);

		String mobile = data.getMobile();
		String maskedMobile = mobile.replaceAll("(\\d{2})\\d{6}(\\d{2})", "$1******$2");
		notificationTemplateBean.setPhoneNumber(maskedMobile);
		notificationTemplateBean.setRecipientEmailId(data.getEmail());
		notificationTemplateBean.setFirstEmiAmt(null != pricingDetail.getEmiAmount() ? pricingDetail.getEmiAmount().intValue()+"" : null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "LoanProcessor : mapNotificationTemplateData : "
				+ "Old Format Date:" + pricingDetail.getFirstDueDate() + "New Format Date:" + firstEmiDateFormatted);
	}

	private BreDueDateResponse callBRE(GlobalDataBean data, PricingDetail pricingDetails, HttpHeaders headers,
			boolean hybridFlexiFlg) {
		return callBRE(data, pricingDetails, headers, hybridFlexiFlg, false, null, null);
	}

	private BreDueDateResponse callBRE(GlobalDataBean data, PricingDetail pricingDetails, HttpHeaders headers,
			boolean hybridFlexiFlg, boolean fundedDisbursement, Integer fundedTenure, String quoteNumber) {
		BreDueDateRequest bean = new BreDueDateRequest();
		ArcduedateInput input = new ArcduedateInput();
		Integer tenure;
		input.setChildApplicationId(
				fundedDisbursement ? Long.valueOf(quoteNumber) : Long.parseLong(data.getApplicationKey()));
		input.setParentApplicationId(Long.parseLong(data.getParentApplicationKey()));
		input.setOmL2Product(data.getL2ProductCode());
		input.setOmL3Product(data.getL3ProductCode());
		input.setSource("EMPLOYEEPORTAL");
		input.setPurpose("Pricing");
		input.setOmL4Product(fundedDisbursement ? data.getL4ProductCode() : pricingDetails.getPennantLoanType());
		if (hybridFlexiFlg) {
			tenure = pricingDetails.getIsTenure() + pricingDetails.getDroplineTenure();
		} else if (!hybridFlexiFlg && fundedDisbursement) {
			tenure = fundedTenure;
		} else {
			tenure = pricingDetails.getDroplineTenure();
		}
		input.setTenor(tenure);
		OfferDetailsBRE offerDetail = new OfferDetailsBRE();
		List<OfferDetailsBRE> listOffer = new ArrayList<>();
		listOffer.add(offerDetail);
		input.setOfferDetails(listOffer);
		AdditionalParameterDetail additional = new AdditionalParameterDetail();
		List<AdditionalParameterDetail> additionalParameterDetails = new ArrayList<>();
		additionalParameterDetails.add(additional);
		bean.setAdditionalParameterDetail(additionalParameterDetails);
		bean.setArcduedateInput(input);
		BreDueDateResponse response = new BreDueDateResponse();
		Gson gson = new Gson();
		String jsonRequest = objectToJson(bean);
		if (headers == null)
			headers = new HttpHeaders();
		headers.add(HttpHeaders.AUTHORIZATION, getAuthDetails());
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.POST, breDueDateURL, String.class, null, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				response = gson.fromJson(excuteRestCall.getBody(), BreDueDateResponse.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"LoanProcessor : callBRE() : Unable to  get BRE  due dates details from journey api", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from OM Service.");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "LoanProcessor : callBRE() : " + response.toString());
		return response;
	}

	private String getAuthDetails() {
		String auth;
		String userNamePwd = authuserName + ":" + authpassword;
		auth = Base64.getEncoder().encodeToString(userNamePwd.getBytes());
		auth = authtype + " " + auth;
		return auth;
	}

	public static String objectToJson(Object o) {
		Gson gson = new Gson();
		return gson.toJson(o);
	}

	public List<CollateralBean> processCollataeralAggregate(GlobalDataBean data) {
		List<CollateralBean> collateralLst = new ArrayList<CollateralBean>();
		VasPricingCheckBean latestPricing = fetchLatestPricingDetails(data.getApplicationKey(), generateHeaders(data));
		CollateralBean activeCollateral = new CollateralBean();
		String colateralRef = fetchCollateralRef(Long.parseLong(data.getApplicationKey()),
				Long.parseLong(data.getApplicantKey()));
		activeCollateral.setCollateralRef(colateralRef);
		activeCollateral.setAssignPerc(calculateAssignPerc(latestPricing.getLoanAmount()));
		collateralLst.add(activeCollateral);
		return collateralLst;
	}

	public MandateBean processMandateDisbAggregate(GlobalDataBean data, DisbursementBean dibBean,
			FinanceDetailBean financeDetail, LoanProcessorVariables processorVariables) {
		String ePayStatus = null;
		String eMandateRefId = null;
		String umrn = null;
		String eMandateMode = null;
		String ePartner = null;
		MandateBean mandateBean = new MandateBean();
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"inside processMandateDisbAggregate 1" + data.getApplicationKey());
		mandateBean = resetUnsecuredLoanParameters(generateHeaders(data), mandateBean, data.getApplicationKey(),
				data.getParentApplicationKey(), financeDetail, processorVariables);
		mandateBean.setOpenMandate(true);
		PennantSystemDate callPennantForSystemDate = disbursementUtil.callPennantForSystemDate(data, lmsUrl);
		mandateBean.setStartDate(callPennantForSystemDate.getAppDate() + DisbursementConstants.TIMESTAMP_FORMAT);
		mandateBean.setPeriodicity("M0001");
		mandateBean.setActive(true);
		mandateBean.setBarCodeNumber(processorVariables.getBarCode());
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside processMandateDisbAggregate 2"
				+ data.getApplicationKey() + " umrnValue  :" + processorVariables.getUmrnValue());
		umrn = processorVariables.getUmrnValue();
		if (processorVariables.isEmandateFlg()) {
			eMandateRefId = mandateBean.getMandateRef();
			ePayStatus = mandateBean.getStatus();
			eMandateMode = processorVariables.getMandatePayMode();
			ePartner = "";// to do from table
			umrn = processorVariables.getUmrnValue();
		}
		if (!processorVariables.isFinnOneMandateFlg() && (StringUtils.isNotBlank(mandateBean.getBarCodeNumber())
				|| (processorVariables.isSOLLoan() && !processorVariables.isEmandateFlg())
				|| ((DisbursementConstants.SOL_PROD.equalsIgnoreCase(processorVariables.getL3product()))
						&& (null != ePayStatus) && !(ePayStatus.equalsIgnoreCase("ACTIVE"))))) {
			setMandateIdFromPennant(data.getApplicantKey(), data.getApplicationKey(), data.getL2ProductCode(),
					generateHeaders(data), processorVariables);
		}
		String cif = fetchCifId(Long.valueOf(data.getApplicationKey()), Long.parseLong(data.getApplicantKey()));
		mandateBean.setCif(cif.toString());
		if (processorVariables.isBarCodeMatched()
				|| (processorVariables.isSOLLoan() && processorVariables.isUMRNMatched())) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"inside processMandateDisbAggregate 3" + data.getApplicationKey());
			mandateBean.setUseExisting(true);
			mandateBean.setMandateID(
					null != processorVariables.getMandatesId() ? new BigDecimal(processorVariables.getMandatesId())
							: null);
		} else {

			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"inside processMandateDisbAggregate 4 :" + processorVariables.isEmandateFlg()
							+ "physicalMandateFlg : " + processorVariables.isPhysicalMandateFlg());
			setMandateBankDetails(mandateBean, data);
			if ((processorVariables.isSOLLoan() || processorVariables.isBOLLoan() || processorVariables.isPROLLoan())
					&& !processorVariables.isEmandateFlg() && !processorVariables.isPhysicalMandateFlg()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"inside processMandateDisbAggregate BMR 5" + data.getApplicationKey());
				mandateBean.setExternalMandate(true);
				mandateBean.setMandateRef(processorVariables.getUmrnValue());
			} else if (processorVariables.isEmandateFlg()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"inside processMandateDisbAggregate emandateFlg 6" + data.getApplicationKey());
				if (null != ePayStatus && ePayStatus.equalsIgnoreCase("ACTIVE")) {
					mandateBean.setMandateType("S");
					mandateBean.setExternalMandate(false);
					financeDetail.setFinRepayMethod("S");
					mandateBean.setMandateRef(umrn);
					mandateBean.setBarCodeNumber(null);
					if (!StringUtils.isEmpty(eMandateRefId) && !eMandateRefId.isBlank()) {
						mandateBean.seteMandateRefNo(eMandateRefId);
					} else if (!StringUtils.isEmpty(processorVariables.getChanelMandateRefId())
							&& !processorVariables.getChanelMandateRefId().isBlank()) {
						mandateBean.seteMandateRefNo(processorVariables.getChanelMandateRefId());
					} else {
						mandateBean.seteMandateRefNo(umrn);
					}
				}
			} else if (processorVariables.isSOLLoan() && processorVariables.isPhysicalMandateFlg()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"inside processMandateDisbAggregate physicalMandateFlg 7" + data.getApplicationKey());
				mandateBean.setBarCodeNumber(processorVariables.getBarCode());
			}
		}
		mandateBean.setStatus("NEW");
		MandateBean requiredMandate = maprequiredMandate(mandateBean, financeDetail, processorVariables);
		return requiredMandate;
	}

	private MandateBean maprequiredMandate(MandateBean mandateBean, FinanceDetailBean financeDetail,
			LoanProcessorVariables processorVariables) {
		MandateBean mandateDtl = new MandateBean();
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"inside maprequiredMandate 1 emandateFlg:" + processorVariables.isEmandateFlg()
						+ "physicalMandateFlg : " + processorVariables.isPhysicalMandateFlg());
		if (null != mandateBean.getUseExisting() && mandateBean.getUseExisting()) {
			mandateDtl.setCif(mandateBean.getCif());
			mandateDtl.setUseExisting(mandateBean.getUseExisting());
			mandateDtl.setMandateID(mandateBean.getMandateID());
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside maprequiredMandate useexiting 2");
		} else {
			if (processorVariables.isEmandateFlg()) {
				mandateDtl.setExternalMandate(mandateBean.getExternalMandate());
				mandateDtl.seteMandateRefNo(mandateBean.geteMandateRefNo());
				mandateDtl.seteMandateSource(mandateBean.geteMandateSource());
				mandateDtl.setMandateRef(mandateBean.getMandateRef());
				mapCommonFields(mandateBean, mandateDtl);
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside maprequiredMandate emandate 3");
			} else if (processorVariables.isPhysicalMandateFlg()) {
				mandateDtl.setBarCodeNumber(mandateBean.getBarCodeNumber());
				mapCommonFields(mandateBean, mandateDtl);
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"inside maprequiredMandate physicalMandateFlg 4");
			} else if (!processorVariables.isEmandateFlg() && !processorVariables.isPhysicalMandateFlg()) {
				mandateDtl.setExternalMandate(mandateBean.getExternalMandate());
				mandateDtl.setExternalMandate(mandateBean.getExternalMandate());
				mapCommonFields(mandateBean, mandateDtl);
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside maprequiredMandate BMR 5");
			}
		}
		return mandateDtl;
	}

	private void mapCommonFields(MandateBean mandateBean, MandateBean mandateDtl) {
		mandateDtl.setCif(mandateBean.getCif());
		mandateDtl.setMandateType(mandateBean.getMandateType());
		mandateDtl.setIfsc(mandateBean.getIfsc());
		mandateDtl.setMicr(mandateBean.getMicr());
		mandateDtl.setAccType(mandateBean.getAccType());
		mandateDtl.setAccNumber(mandateBean.getAccNumber());
		mandateDtl.setAccHolderName(mandateBean.getAccHolderName());
		mandateDtl.setOpenMandate(mandateBean.getOpenMandate());
		mandateDtl.setStartDate(mandateBean.getStartDate());
		mandateDtl.setExpiryDate(mandateBean.getExpiryDate());
		mandateDtl.setMaxLimit(mandateBean.getMaxLimit());
		mandateDtl.setPeriodicity(mandateBean.getPeriodicity());
		mandateDtl.setStatus(mandateBean.getStatus());
		mandateDtl.setActive(mandateBean.getActive());
	}

	public String fetchCifId(Long applicationKey, Long applicantKey) {
		List<DisbursementMongoObject> disbursementMongoObjectList = mongoDbRepo.fetchObjectByKey(
				disbursementMongoTemplate, "applicantKey", Long.valueOf(applicantKey),
				DisbursementConstants.SERVICE_RECORD);
		DisbursementMongoObject result = disbursementMongoObjectList.stream()
				.filter(x -> x.getApplicationKey().equals(applicationKey)).findFirst().orElse(null);
		return result.getCif();
	}

	public String fetchCollateralRef(Long applicationKey, Long applicantKey) {
		List<DisbursementMongoObject> disbursementMongoObjectList = mongoDbRepo.fetchObjectByKey(
				disbursementMongoTemplate, "applicantKey", Long.valueOf(applicantKey),
				DisbursementConstants.SERVICE_RECORD);
		DisbursementMongoObject result = disbursementMongoObjectList.stream()
				.filter(x -> x.getApplicationKey().equals(applicationKey)).findFirst().orElse(null);
		return result.getCollateralRef();
	}

	public String fetchBeneficiaryId(String applicationKey, String applicantId) {
		Long applicantKey = Long.parseLong(applicantId);
		List<DisbursementMongoObject> disbursementMongoObjectList = mongoDbRepo.fetchObjectByKey(
				disbursementMongoTemplate, "applicantKey", Long.valueOf(applicantKey),
				DisbursementConstants.SERVICE_RECORD);
		DisbursementMongoObject result = disbursementMongoObjectList.stream()
				.filter(x -> x.getApplicationKey().equals(Long.valueOf(applicationKey))).findFirst().orElse(null);
		return result.getBeneficiaryID();
	}

	private void setMandateBankDetails(MandateBean request, GlobalDataBean data) {
		EmandateRegistrationBean emandateRegistrationBean = fetchMandateRegDetails(data.getApplicationKey(),
				generateHeaders(data));
		if (emandateRegistrationBean != null) {
			request.setAccType(DisbursementConstants.ACCOUNT_TYPE_CURRENT);
			request.setIfsc(request.getIfsc());
			request.setMicr(request.getMicr());
			if (DisbursementConstants.ACCOUNT_TYPE_CODE_SA.equals(emandateRegistrationBean.getAccountType())
					|| DisbursementConstants.ACCOUNT_TYPE_CODE_BTTP.equals(emandateRegistrationBean.getAccountType())) {
				request.setAccType(DisbursementConstants.ACCOUNT_TYPE_SAVING);
			}
			request.setAccNumber(emandateRegistrationBean.getAccountNumber());
			request.setMaxLimit(emandateRegistrationBean.getLimit());
		}
	}

	private BigDecimal calculateAssignPerc(BigDecimal lnAmnt) {
		BigDecimal assignPerc = lnAmnt.divide(new BigDecimal(1000000));
		DecimalFormat df = new DecimalFormat("0.00");
		df.setRoundingMode(RoundingMode.UP);
		assignPerc = new BigDecimal(df.format(assignPerc));
		return assignPerc;
	}

	public List<FeeDetailsBean> processFees(GlobalDataBean data, FinanceScheduleBean financeScheduleBean,
			LoanProcessorVariables processorVariables) {
		List<FeeDetailsBean> feeDtlLst = new ArrayList<FeeDetailsBean>();
		List<PricingDetail> pricingDetailLst = fetchPricingDetails(data.getApplicationKey(), generateHeaders(data));
		List<PricingFees> pricingFeeLst = new ArrayList<PricingFees>();
		VasPricingCheckBean latestPricing = fetchLatestPricingDetails(data.getApplicationKey(), generateHeaders(data));
		if (null != pricingDetailLst && !pricingDetailLst.isEmpty()) {
			for (PricingDetail pricingDetail : pricingDetailLst) {
				if (pricingDetail.getAppLoanPricingKey()
						.equalsIgnoreCase(latestPricing.getAppLoanPricingKey().toString())) {
					pricingFeeLst = pricingDetail.getFees();
					break;
				}
			}
		}
		pricingFeeLst.forEach(item -> {
			if(!item.getFeeCode().equalsIgnoreCase("AMCCHG")) {
			FeeDetailsBean bean = new FeeDetailsBean();
			bean.setFeeAmount(item.getFeesInAmount());
			bean.setFeeCode(item.getFeeCode());
			bean.setFeeMethod("DISB");
			bean.setWaiverAmount(new BigDecimal(0));
			bean.setPaidAmount(new BigDecimal(0));
			feeDtlLst.add(bean);
			}
		});
		setHybridflexiParameters(pricingFeeLst, financeScheduleBean, processorVariables);
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Outside setHybridflexiParameters - for AMCCHG in intervalfee");
		return feeDtlLst;
	}

	public void setHybridflexiParameters(List<PricingFees> pricingFeeLst, FinanceScheduleBean financeScheduleBean,
			LoanProcessorVariables processorVariables) {
	logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Inside setHybridflexiParameters - for AMCCHG in intervalfee");

		if (processorVariables.isHybridFlexi()) {
			for (PricingFees fee : pricingFeeLst) {
				if (fee.getFeeCode().equalsIgnoreCase("AMCCHG")) {
					IntervalFeeBean intFee = new IntervalFeeBean();
					intFee.setFeeAmount(fee.getFeesInAmount());
					intFee.setFeeCode("AMCCHG");
					intFee.setPaidAmount(new BigDecimal(0));
					intFee.setWaiverAmount(new BigDecimal(0));
					intFee.setActive(true);
					List<IntervalFeeBean> intervalFeelist = new ArrayList<>();
					intervalFeelist.add(intFee);
					financeScheduleBean.setIntervalFee(intervalFeelist);
					//fees.remove(fee);
				}
			}
		}
	}

	public List<DisbursementBean> processDisbursementAgrregate(GlobalDataBean data,
			LoanProcessorVariables processorVariables) {
		List<DisbursementBean> disbLst = new ArrayList<DisbursementBean>();
		List<TranchBean> activeTranchLst = fetchTranchDetails(data.getApplicationKey(), generateHeaders(data));
		for (TranchBean trnch : activeTranchLst) {
			DisbursementBean disbursement = new DisbursementBean();
			disbursement.setDisbParty(DisbursementConstants.DISB_PARTY);
			disbursement.setDisbType(DisbursementConstants.DISB_TYPE);
			disbursement.setDisbAmount(trnch.getTrancheAmount().doubleValue());
			processorVariables.setDisbAmount(trnch.getTrancheAmount());
			disbursement.setRemarks(StringUtils.EMPTY);
			Long appBankDetKey = trnch.getApplicationBankDetKey();
			BankDetailsReponse bankDetailsReponse = fetchBankDetails(data.getApplicationKey(), appBankDetKey.toString(),
					generateHeaders(data));
			String accountNum = bankDetailsReponse.getAccoutNumber();
			String bnkHolderNm = bankDetailsReponse.getHolderName();
			if (null != bankDetailsReponse.getMandatereqdflg())
				processorVariables.setMandateReqFlg(bankDetailsReponse.getMandatereqdflg().toString());
			disbursement.setAccountNo(accountNum);
			disbursement.setAcHolderName(bnkHolderNm);
			String brnchKey = bankDetailsReponse.getBranchKey();
			BranchDetails branchDetails = fetchBranchDetails(brnchKey, generateHeaders(data));
			String ifsCode = branchDetails.getBranchIfscCode();
			String micr = branchDetails.getBranchMicrCode();
			disbursement.setIfsc(ifsCode);
			disbursement.setMicr(micr);
			PennantSystemDate callPennantForSystemDate = disbursementUtil.callPennantForSystemDate(data, lmsUrl);
			disbursement.setDisbDate(callPennantForSystemDate.getAppDate() + DisbursementConstants.TIMESTAMP_FORMAT);
			disbursement.setValueDate(callPennantForSystemDate.getAppDate() + DisbursementConstants.TIMESTAMP_FORMAT);
			disbursement.setIssueBank(disbursementMapperUtil
					.mapBflBankRefCode(branchDetails.getBankMasterKey().toString(), generateHeaders(data)));
			disbursement.setPhoneAreaCode(DisbursementConstants.AREA_CODE_IND);
			disbursement.setPhoneCountryCode(DisbursementConstants.COUNTRY_CODE_IND);
			disbursement.setPhoneNumber(data.getMobile());
			disbursement.setPartnerBankId("");
			disbLst.add(disbursement);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Loan Processor Disbursement Aggregate:" + disbLst.toString());
		return disbLst;
	}

	public MandateBean resetUnsecuredLoanParameters(HttpHeaders headers, MandateBean mandateBean,
			String childapplicationKey, String parentAppKey, FinanceDetailBean financeDetailBean,
			LoanProcessorVariables processorVariables) {
		processorVariables.setUMRNMatched(false);
		processorVariables.setSOLLoan(false);
		processorVariables.setEmandateFlg(false);
		processorVariables.setPhysicalMandateFlg(false);
		processorVariables.setBOLLoan(false);
		processorVariables.setPROLLoan(false);
		if (fetchSolFlag(processorVariables.getL3product()))
			processorVariables.setSOLLoan(true);
		else if (fetchBolFlag(processorVariables.getL3product()))
			processorVariables.setBOLLoan(true);
		else if (fetchProlFlag(processorVariables.getL3product()))
			processorVariables.setPROLLoan(true);
		BankDetailsReponse bankDetailsReponse = getRepayBankDetails(childapplicationKey, headers, processorVariables);
		EmandateResponse emandateResponse = getRepayEmandateDetails(bankDetailsReponse.getFinalMandateKey(), headers);
		processorVariables.setUmrnValue(emandateResponse.getUmrn());
		processorVariables.setChanelMandateRefId(emandateResponse.getChanelMandateRefId());
		if (null != emandateResponse.getMandateCreationSource()
				&& emandateResponse.getMandateCreationSource().equalsIgnoreCase("EPEMANDATE")) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"inside resetUnsecuredLoanParameters 1 emandate" + childapplicationKey);
			processorVariables.setEmandateFlg(true);
			if (!StringUtils.isEmpty(mandateBean.getMandateRef())) {
				processorVariables.setEpMandateRefNo(emandateResponse.getChanelMandateRefId());
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"inside resetUnsecuredLoanParameters 2 emandate" + childapplicationKey);
			} else if (null != processorVariables.getChanelMandateRefId()) {
				processorVariables.setEpMandateRefNo(processorVariables.getChanelMandateRefId());
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"inside resetUnsecuredLoanParameters 3 emandate" + childapplicationKey);
			} else {
				processorVariables.setEpMandateRefNo(processorVariables.getUmrnValue());
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"inside resetUnsecuredLoanParameters 4 emandate" + childapplicationKey);
			}

		} else if (null != emandateResponse.getMandateCreationSource()
				&& emandateResponse.getMandateCreationSource().equalsIgnoreCase("EPPHYSICAL")) {
			processorVariables.setPhysicalMandateFlg(true);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"inside resetUnsecuredLoanParameters 5 physicalMandate" + childapplicationKey);
		} else {
			processorVariables.setEpMandateRefNo(processorVariables.getUmrnValue());
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"inside resetUnsecuredLoanParameters 6 BMR" + childapplicationKey);
		}
		EmandateRegistrationBean emandateRegistrationBean = fetchMandateRegDetails(childapplicationKey, headers);
		mandateBean.seteMandateRefNo(emandateRegistrationBean.getMandateReference());
		List<BflEmandatePaymentModeBean> payModeLst = fetchPaymentMode(headers);
		List<String> eMandateSource = new ArrayList<>();
		for (BflEmandatePaymentModeBean bflEmandatePaymentModeBean : payModeLst) {
			if (null != emandateRegistrationBean.getModeofpayment()) {
				if (emandateRegistrationBean.getModeofpayment()
						.equalsIgnoreCase(bflEmandatePaymentModeBean.getEmandatemode())
						&& !bflEmandatePaymentModeBean.getEmandatepartner().equalsIgnoreCase("PricipalEmandate")) {
					eMandateSource.add(bflEmandatePaymentModeBean.getEmandatesubrepaymode());
					logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
							"inside resetUnsecuredLoanParameters 7" + childapplicationKey);
				}
			}
		}
		if (!eMandateSource.isEmpty()) {
			mandateBean.seteMandateSource(eMandateSource.get(0));
		}
		BranchDetails branchDetails = fetchBranchDetails(bankDetailsReponse.getBranchKey(), headers);
		mandateBean.setMicr(branchDetails.getBranchMicrCode());
		mandateBean.setIfsc(branchDetails.getBranchIfscCode());
		mandateBean.setAccNumber(bankDetailsReponse.getAccoutNumber());
		mandateBean.setAccHolderName(bankDetailsReponse.getHolderName());
		mandateBean.setAccType("11");
		mandateBean.setStatus(emandateRegistrationBean.getStatus());
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		String expDate = df.format(emandateRegistrationBean.getMandatExpiryDate());
		mandateBean.setExpiryDate(expDate);
		processorVariables.setFinRepaymethod(bankDetailsReponse.getPaymentMode());
		if ("DD".equalsIgnoreCase(processorVariables.getMandatePayMode())) {
			mandateBean.setMandateType(DisbursementConstants.MODE_DDM);
			financeDetailBean.setFinRepayMethod(DisbursementConstants.MODE_DDM);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"inside resetUnsecuredLoanParameters 8 DDM" + childapplicationKey);
		} else if ("ECS".equalsIgnoreCase(processorVariables.getMandatePayMode())
				|| "NACH".equalsIgnoreCase(processorVariables.getMandatePayMode())) {
			mandateBean.setMandateType(DisbursementConstants.MODE_NACH);
			financeDetailBean.setFinRepayMethod(DisbursementConstants.MODE_NACH);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"inside resetUnsecuredLoanParameters 9 NACH" + childapplicationKey);
		}

		processorVariables.setBarCode(emandateRegistrationBean.getBarcode());
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "barCode: " + processorVariables.getBarCode());
		return mandateBean;
	}

	@SuppressWarnings("unchecked")
	public EmandateRegistrationBean fetchMandateRegDetails(String appId, HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", appId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, mandateDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "appId: " + appId);
		EmandateRegistrationBean emandate = new EmandateRegistrationBean();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				emandate = gson.fromJson(excuteRestCall.getBody().toString(), EmandateRegistrationBean.class);
				return emandate;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchMandateRegDetails .");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "emandate: " + emandate.getBarcode());
		return emandate;
	}

	@SuppressWarnings("unchecked")
	public List<TranchBean> fetchTranchDetails(String applicationId, HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("tranchApplicationKey", applicationId);

		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, tranchDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();
		List<TranchBean> list = new ArrayList<TranchBean>();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {

				AppTranchResponse tranchBeanlst = gson.fromJson(excuteRestCall.getBody().toString(),
						AppTranchResponse.class);
				list = tranchBeanlst.getApplicationTranches();
				return list;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  cfetchTranchDetails .");
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	public BankDetailsReponse fetchBankDetails(String applicationId, String bankDetailKey, HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationId);
		params.put("bankdetailskey", bankDetailKey);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, bankDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();
		BankDetailsReponse bankDetailsReponse = new BankDetailsReponse();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				bankDetailsReponse = gson.fromJson(excuteRestCall.getBody().toString(), BankDetailsReponse.class);
				return bankDetailsReponse;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  BankDetailsReponse .");
		}
		return bankDetailsReponse;
	}

	@SuppressWarnings("unchecked")
	public BranchDetails fetchBranchDetails(String branchKey, HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("branchKey", branchKey);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, branchDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();
		BranchDetails branchDetails = new BranchDetails();
		List<BranchDetails> list = new ArrayList<BranchDetails>();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				BranchDetails[] branchBeanlst = gson.fromJson(excuteRestCall.getBody().toString(),
						BranchDetails[].class);
				list.addAll(Arrays.asList(branchBeanlst));
				return list.get(0);
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchBranchDetails .");
		}
		return branchDetails;
	}

	@SuppressWarnings("unchecked")
	public List<BflEmandatePaymentModeBean> fetchPaymentMode(HttpHeaders headers) {

		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, subRepayModeDtl, String.class, null, null, headers);
		Gson gson = new Gson();
		List<BflEmandatePaymentModeBean> bflEmandatePaymentModelst = new ArrayList<BflEmandatePaymentModeBean>();

		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				BflEmandatePaymentModeBean[] lst = gson.fromJson(excuteRestCall.getBody().toString(),
						BflEmandatePaymentModeBean[].class);
				bflEmandatePaymentModelst.addAll(Arrays.asList(lst));
				return bflEmandatePaymentModelst;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchPayMentMode .");
		}
		return bflEmandatePaymentModelst;
	}

	@SuppressWarnings("unchecked")
	public BankDetailsReponse getRepayBankDetails(String applicationKey, HttpHeaders headers,
			LoanProcessorVariables processorVariables) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, repayDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();
		BankDetailsReponse repayBank = new BankDetailsReponse();
		List<BankDetailsReponse> list = new ArrayList<BankDetailsReponse>();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				BankDetailsReponse[] branchBeanlst = gson.fromJson(excuteRestCall.getBody().toString(),
						BankDetailsReponse[].class);
				list.addAll(Arrays.asList(branchBeanlst));
				for (BankDetailsReponse activeBank : branchBeanlst) {
					if (null != activeBank.getBankAccountCatagory()
							&& activeBank.getBankAccountCatagory().equalsIgnoreCase("Repayment")) {
						repayBank = activeBank;
						processorVariables.setMandatePayMode(repayBank.getPaymentMode());
						break;
					}
				}
				return repayBank;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response for RepayBank Details.");
		}
		return repayBank;
	}

	@SuppressWarnings("unchecked")
	public void updateApplicationStageDetails(String applicationId, HttpHeaders headers) {
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		ApplicationStageDetails subStageDetails = new ApplicationStageDetails();
		subStageDetails.setPercentageCompletion(100);
		String stageJsonrequest = gson.toJson(subStageDetails);
		disbursementBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, subStageUrl, String.class, params,
				stageJsonrequest, headers);

	}

	@SuppressWarnings("unchecked")
	public void updateApplicationStatusDetails(String applicationId, HttpHeaders headers) {
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		ApplicationStatus applicationStatus = new ApplicationStatus();
		applicationStatus.setStatusValue("Disbursed");
		String statusJsonrequest = gson.toJson(applicationStatus);
		disbursementBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, statusUrl, String.class, params,
				statusJsonrequest, headers);
	}

	@SuppressWarnings("unchecked")
	public EmandateResponse getRepayEmandateDetails(String finalMandateKey, HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("mandateRefference", finalMandateKey);
		ResponseEntity<String> excuteRestCall = null;
		Gson gson = new Gson();
		EmandateResponse emanRes = new EmandateResponse();
		try {
			excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					repayEmandateUrl, String.class, params, null, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"after repayEmandateUrl call for finalmandatekey " + finalMandateKey);
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				emanRes = gson.fromJson(excuteRestCall.getBody().toString(), EmandateResponse.class);
				return emanRes;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"No data found for mandatereference.");
		}
		return emanRes;
	}

	public boolean fetchHybridFlexiFlag(String productType) {
		boolean hyBridFlexiFlag = false;
		List<String> loanHybridFlexiList = Arrays.asList(hybridflexiloantypes.split(","));
		boolean hyBridFlexiMatchFound = loanHybridFlexiList.stream().anyMatch(productType::equals);
		if (hyBridFlexiMatchFound) {
			hyBridFlexiFlag = true;
		}
		return hyBridFlexiFlag;
	}

	@SuppressWarnings("unchecked")
	public List<PricingDetail> fetchPricingDetails(String appId, HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", appId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, pricingDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();
		List<PricingDetail> list = new ArrayList<PricingDetail>();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				PricingDetail[] pricingDetail = gson.fromJson(excuteRestCall.getBody().toString(),
						PricingDetail[].class);
				list.addAll(Arrays.asList(pricingDetail));
				return list;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchPricingDetails .");
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	public VasPricingCheckBean fetchLatestPricingDetails(String appId, HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", appId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, pricingLatestDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();
		VasPricingCheckBean latestBean = new VasPricingCheckBean();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				latestBean = gson.fromJson(excuteRestCall.getBody().toString(), VasPricingCheckBean.class);
				return latestBean;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchPricingDetails .");
		}
		return latestBean;
	}

	@SuppressWarnings("unchecked")
	private UserProfile fetchUserProfile(GlobalDataBean data) {
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		List<UserProfile> userProfileList = new ArrayList<>();
		UserProfile userProfileDetails = null;
		params.put("applicationid", data.getApplicationKey());
		ResponseEntity<String> userProfileResponse = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getUserProfilesUrl, String.class, params, null,
						generateHeaders(data));
		if (null != userProfileResponse.getBody()) {
			UserProfile[] userDetails = gson.fromJson(userProfileResponse.getBody(), UserProfile[].class);
			userProfileList = Arrays.asList(userDetails);
		}
		for (UserProfile userProfile : userProfileList) {
			if (userProfile.getApplicationUserAttributeType().equals("1")) {
				userProfileDetails = userProfile;
				data.setAppAtrKey(userProfileDetails.getApplicationUserAttributeKey());
				data.setMobile(userProfileDetails.getMobile());
			}
		}
		return userProfileDetails;
	}

	@SuppressWarnings("unchecked")
	public Address fetchAddressDetails(String appId, String appAttrKey, String typeKey, HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", appId);
		params.put("userattributekey", appAttrKey);
		params.put("typeKey", typeKey);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, addressDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();
		Address address = new Address();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				address = gson.fromJson(excuteRestCall.getBody().toString(), Address.class);
				return address;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchBranchDetails .");
		}
		return address;
	}

	public void setMandateIdFromPennant(String applicantKey, String applicationId, String prodCode, HttpHeaders headers,
			LoanProcessorVariables processorVariables) {
		Long startTime = null;
		Long stopTime = null;
		try {
			CollateralRequestBean collateralRequestBean = new CollateralRequestBean();
			String cif = fetchCifId(Long.valueOf(applicationId), Long.parseLong(applicantKey));
			collateralRequestBean.setCif(cif);
			startTime = System.currentTimeMillis();
			String responseStr = executeLMSRequestforMandate(applicationId, prodCode, collateralRequestBean, headers);
			startTime = System.currentTimeMillis();
			disbursementUtil.addDisbursementRecords(applicationId, applicantKey, mapToJson(collateralRequestBean),
					responseStr, DisbursementConstants.LMS_PENNANT_MANDATE_SOURCE,
					null != startTime ? startTime.toString() : null, null != stopTime ? stopTime.toString() : null);
			processLmsResponse(responseStr, processorVariables);
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred in Mandate pennant Call");
		}
	}

	public void processLmsResponse(String responseString, LoanProcessorVariables processorVariables) {
		CreateMandateResponseBean finalResponse = new CreateMandateResponseBean();
		try {

			Gson gson = new Gson();
			CreateMandateExternalResponse extResponse = gson.fromJson(responseString,
					CreateMandateExternalResponse.class);
			if (extResponse != null) {
				String returnCode = extResponse.getReturnStatus().getReturnCode();
				if (DisbursementConstants.PENNANT_SUCCES_CODE.equals(returnCode)) {
					finalResponse.setStatus(DisbursementConstants.SUCCESS);
					String mandateId;
					if (processorVariables.isSOLLoan() && !processorVariables.isEmandateFlg()) {// TO DO
						logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Customer not found with CIF ");
						mandateId = getMandateIdFromListForUMRN(extResponse, processorVariables);
						if (StringUtils.isNotEmpty(mandateId)) {
							finalResponse.setMandateID(new BigDecimal(mandateId));
							processorVariables.setMandatesId(mandateId);

						}
					} else if (processorVariables.isPhysicalMandateFlg()) {
						mandateId = getMandateIdFromList(extResponse, processorVariables);
						if (StringUtils.isNotEmpty(mandateId)) {
							finalResponse.setMandateID(new BigDecimal(mandateId));
							processorVariables.setMandatesId(mandateId);
						}
					}
				}
				if (DisbursementConstants.ERROR_MANDATE_CUST_NOT_FOUND.equals(returnCode)) {
					finalResponse.setReturnStatus(extResponse.getReturnStatus());
					logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Customer not found with CIF ");
					throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
							"Mandate Customer Not Found .");
				} else if (DisbursementConstants.ERROR_MANDATE_NOT_FOUND.equals(returnCode)) {
					finalResponse.setReturnStatus(extResponse.getReturnStatus());
					logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "No records found with cif  ");
				} else {
					finalResponse.setReturnStatus(extResponse.getReturnStatus());
					finalResponse.setStatus(DisbursementConstants.FAILURE);
				}
			} else {
				throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
						"Error in Mandate Pennant Call.");
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Exception occured in LMS Creating Mandate", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR, "Error in Mandate Pennant Call.");
		}
	}

	public String getMandateIdFromList(CreateMandateExternalResponse extResponse,
			LoanProcessorVariables processorVariables) {
		String mandateId = null;
		List<PennantMandateBean> pennantMandatBean = extResponse.getMandates();
		String barcode = processorVariables.getBarCode();
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"getMandateIdFromList externalResponse :" + extResponse.toString());
		if (StringUtils.isNotBlank(barcode)) {
			for (PennantMandateBean resp : pennantMandatBean) {
				if (StringUtils.isNotBlank(resp.getBarCodeNumber()) && resp.getBarCodeNumber().equals(barcode)) {
					mandateId = resp.getMandateID().toString();
					processorVariables.setBarCodeMatched(true);
				}
			}
		}
		return mandateId;
	}

	public String getMandateIdFromListForUMRN(CreateMandateExternalResponse extResponse,
			LoanProcessorVariables processorVariables) {
		List<PennantMandateBean> pennantMandatBean = extResponse.getMandates();
		if (StringUtils.isNotBlank(processorVariables.getEpMandateRefNo()) && pennantMandatBean != null) {
			for (PennantMandateBean resp : pennantMandatBean) {
				if (StringUtils.isNotBlank(resp.getMandateRef())
						&& resp.getMandateRef().equals(processorVariables.getEpMandateRefNo())) {
					processorVariables.setUMRNMatched(true);
					return resp.getMandateID().toString();
				}
			}
		}
		return null;
	}

	private String executeLMSRequestforMandate(String applicationId, String prodCode,
			CollateralRequestBean mandateRequest, HttpHeaders headers) {
		String requestStr = mapToJson(mandateRequest);
		Object response = lmsHelper.executeLmsRequest(DisbursementConstants.LMS_PENNANT_MANDATE_SOURCE, prodCode,
				requestStr, applicationId, headers);
		return response.toString();
	}

	public HttpHeaders generateHeaders(GlobalDataBean data) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("authtoken", data.getHeaders().get("authtoken"));
		headers.add("cmptcorrid", data.getHeaders().get("cmptcorrid"));
		headers.add("guardtoken", data.getHeaders().get("guardtoken"));
		return headers;
	}

	public boolean fetchSolFlag(String productType) {
		boolean solFlag = false;
		List<String> solList = Arrays.asList(solloantypes.split(","));
		boolean solMatchFound = solList.stream().anyMatch(productType::equals);
		if (solMatchFound) {
			solFlag = true;
		}
		return solFlag;
	}

	public boolean fetchBolFlag(String productType) {
		boolean bolFlag = false;
		List<String> bolList = Arrays.asList(bolloantypes.split(","));
		boolean bolMatchFound = bolList.stream().anyMatch(productType::equals);
		if (bolMatchFound) {
			bolFlag = true;
		}
		return bolFlag;
	}

	public boolean fetchProlFlag(String productType) {
		boolean bolFlag = false;
		List<String> bolList = Arrays.asList(prolloantypes.split(","));
		boolean bolMatchFound = bolList.stream().anyMatch(productType::equals);
		if (bolMatchFound) {
			bolFlag = true;
		}
		return bolFlag;
	}

	public void saveRetryDetails(GlobalDataBean data, Boolean retrySuccessFlg, String status) {
		Date date = new Date();
		List<TranchBean> trnchLst = disbursementUtil.fetchTranchDetails(data.getApplicationKey(),
				generateHeaders(data));
		Long activeTranchKey = trnchLst.get(0).getTranchkey();
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Time out flow of CreateLoan activeTranchKey :: " + activeTranchKey);
		RetryRegistrationBean existingRecords = null;
		existingRecords = disbursementUtil.fetchExistingTransaction(activeTranchKey.toString(),
				data.getApplicationKey(), generateHeaders(data));
		DisbursementRequestBean rquestBean = new DisbursementRequestBean();
		rquestBean.setApplicantId(data.getApplicantKey());
		rquestBean.setApplicationId(data.getApplicationKey());
		rquestBean.setProductCode(data.getL3ProductCode());
		RetryRegistrationBean bean = new RetryRegistrationBean();
		bean.setActiveFlg(true);
		if (null != existingRecords) {
			bean.setCurrentRetryCount(existingRecords.getCurrentRetryCount() + 1l);
		} else {
			bean.setCurrentRetryCount(1l);
		}
		rquestBean.setStage("CREATE_LOAN");
		rquestBean.setTransactionId(activeTranchKey.toString());
		bean.setErrorCode("DISBURSEMENT_CREATE_LOAN");
		bean.setNextReryTime(new Timestamp(date.getTime()).toString());
		bean.setRetryClass("CreditDisbursementController");
		bean.setRetryMechanism("Endpoint");
		bean.setRetryMethod(initiateDisbUrl);
		bean.setRetryPayload(disbursementUtil.objectToJson(rquestBean));
		bean.setRetryStatus(status);
		bean.setSource("OM-Credit-Disbursement");
		bean.setTimestamp(new Timestamp(date.getTime()).toString());
		bean.setTransactionId(activeTranchKey);
		bean.setErrorKey(data.getApplicationKey() + activeTranchKey);
		bean.setRetrySuccessFlg(retrySuccessFlg);
		if (bean.getCurrentRetryCount() > 5) {
			bean.setRetryStatus("Failed");
			bean.setActiveFlg(false);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Time out flow of CreateLoan before save activeTranchKey :: " + activeTranchKey);

		disbursementUtil.saveretrytransaction(activeTranchKey.toString(), data.getApplicationKey(), bean,
				generateHeaders(data));
	}

	@SuppressWarnings("unchecked")
	public LoanAccountResponseBean fetchDisbursementDetails(String appId, String applicantid, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "fetchDisbursementDetails: " + appId);
		Map<String, String> params = new HashMap<>();
		params.put("customerId", applicantid);
		headers.add("applicantid", applicantid);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, accountLoanURL, String.class, params, null, headers);
		Gson gson = new Gson();
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "appId: " + appId);
		LoanAccountResponseBean loanAcc = new LoanAccountResponseBean();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				loanAcc = gson.fromJson(excuteRestCall.getBody().toString(), LoanAccountResponseBean.class);
				return loanAcc;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchDisbursementDetails .");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "fetchDisbursementDetails ENDS: " + appId);
		return loanAcc;
	}

	public Boolean initiateSuccessDisbEventForDmsDocPush(
			PrincipalFileUploadRequestBean principalFileUploadRequestBean) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Start initiateSuccessDisbEvent, disbursementEventRequestBean" + principalFileUploadRequestBean);
		boolean eventflg = disbursementUtil.raiseDisbursementSuccessEventForDmsDocPush(principalFileUploadRequestBean);
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End initiateSuccessDisbEvent, disbursementEventRequestBean : " + principalFileUploadRequestBean
						+ ", eventflg : " + eventflg);
		return eventflg;
	}

	public void processLoanRequestForFunded(FundedDisbursementEventRequestBean request, Boolean errorFlag) {

		try {
			GlobalDataBean fundedData = new GlobalDataBean();
			fundedData.setHeaders(request.getHeaders());
			fundedData.setApplicationKey(request.getApplicationId());
			fundedData.setParentApplicationKey(request.getApplicationId());
			fundedData.setL2ProductCode(request.getApplicationDetails().getL2ProductCode());
			fundedData.setL3ProductCode(request.getApplicationDetails().getL3ProductCode());

			LoanProcessorVariables processorVariables = new LoanProcessorVariables();
			CreateLoanExternalRequest createLoanExternalRequest = fetchFundedLoanPennantRequest(fundedData, request,
					processorVariables);
			HttpHeaders headers = new HttpHeaders();
			Long startTime = null;
			Long stopTime = null;
			try {
				startTime = System.currentTimeMillis();
				FibonacciPollInterval fibonacci = new FibonacciPollInterval(TimeUnit.SECONDS);
				Awaitility.setDefaultTimeout(300, TimeUnit.SECONDS);
				Awaitility.with().pollInterval(fibonacci).await().atMost(300, TimeUnit.SECONDS)
						.until(() -> null != (executeLMSRequestforLoan(fundedData.getApplicationKey(),
								fundedData.getL2ProductCode(), createLoanExternalRequest, headers,
								processorVariables)));
				stopTime = System.currentTimeMillis();
			} catch (ConditionTimeoutException e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Time out flow of CreateLoan ::");
				saveFundedRetryDetails(request, false, "Pending");
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Time out flow of CreateLoan ends::");
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, " loan request in progress :" + errorFlag);
			if (errorFlag) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						" loan request in progress fetching cif for:" + request.getApplicationDetails());
				String cif = disbursementUtil.fetchFundedCifId(Long.valueOf(request.getApplicationId()),
						request.getApplicationDetails().getQuoteNumber());
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, " loan request in progress cif:" + cif);
				LoanCustomerRequestBean bean = new LoanCustomerRequestBean();
				bean.setCif(cif);
				String response = executeLMSTimeOutRequestforLoan(request.getApplicationId(),
						request.getApplicationDetails().getL2ProductCode(), bean, new HttpHeaders());
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						" loan request in progress fetching finreference:");
				String lanNumber = null;
				processorVariables.setLoanResponseString(response);
				Gson gson = new Gson();
				Loan loan = gson.fromJson(response.toString(), Loan.class);
				List<FinanceBean> finBeanLst = loan.getFinances();
				for (FinanceBean finBean : finBeanLst) {
					if (finBean.getApplicationNo().toString().equalsIgnoreCase(request.getApplicationId())) {
						lanNumber = finBean.getFinReference();
					}
				}

				disbursementUtil.updateServiceRecordForFundedLoan(Long.valueOf(request.getApplicationId()),
						request.getApplicationDetails().getQuoteNumber(), lanNumber);
				saveFundedRetryDetails(request, false, "Success");
				CreateLoanResponseBean createLoanResponseBean = gson
						.fromJson(processorVariables.getLoanResponseString(), CreateLoanResponseBean.class);
				boolean eventFlag = disbursementUtil.raiseInsuranceEventPostDisbursement(request,
						createLoanResponseBean, createLoanResponseBean.getReturnStatus(), "CREATE_LOAN",
						disbursementUtil.fetchFundedCifId(Long.valueOf(request.getApplicationId()),
								request.getApplicationDetails().getQuoteNumber()),
						DisbursementConstants.BFL_DISBURSEMENT_STATUS);
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"End processLoanLmsResponseForFunded EventFlag:" + eventFlag);
				processorVariables.setRetryMechanism(true);

			}

			if (null != processorVariables.getLoanResponseString()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Inside loanResponseString not null for" + fundedData.getApplicationKey());
				disbursementUtil.addDisbursementRecords(request.getApplicationId(),
						request.getApplicationDetails().getQuoteNumber(), mapToJson(createLoanExternalRequest),
						processorVariables.getLoanResponseString(), DisbursementConstants.LMS_CREATE_LOAN_SOURCE,
						startTime.toString(), stopTime.toString());
				String status = processLoanLmsResponseForFunded(request, processorVariables.getLoanResponseString(),
						headers);
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Inside loanResponseString not null and status:" + status);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Exception occurred : Funded Create Loan Call ", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred in Funded Create Loan Call");

		}
	}

	public void saveFundedRetryDetails(FundedDisbursementEventRequestBean request, Boolean retrySuccessFlg,
			String status) {
		Date date = new Date();
		Long activeTranchKey = Long.valueOf(request.getApplicationDetails().getPaymentQuoteId());
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Time out flow of CreateLoan activeTranchKey :: " + activeTranchKey);
		RetryRegistrationBean existingRecords = null;
		existingRecords = disbursementUtil.fetchExistingTransaction(activeTranchKey.toString(),
				request.getApplicationId(), new HttpHeaders());
		FundedDisbursementRequestBean rquestBean = new FundedDisbursementRequestBean();
		rquestBean.setApplicationId(request.getApplicationId());
		rquestBean.setProductCode(request.getApplicationDetails().getL3ProductCode());
		rquestBean.setQuoteNumber(request.getApplicationDetails().getQuoteNumber());

		RetryRegistrationBean bean = new RetryRegistrationBean();
		bean.setActiveFlg(true);
		if (null != existingRecords) {
			bean.setCurrentRetryCount(existingRecords.getCurrentRetryCount() + 1l);
		} else {
			bean.setCurrentRetryCount(1l);
		}
		rquestBean.setStage("CREATE_LOAN");
		rquestBean.setTransactionId(activeTranchKey.toString());
		bean.setErrorCode("BFL_DISBURSEMENT_CREATE_LOAN");
		bean.setNextReryTime(new Timestamp(date.getTime()).toString());
		bean.setRetryClass("FundedDisbursementController");
		bean.setRetryMechanism("Endpoint");
		bean.setRetryMethod(initiateBflDisbUrl);
		bean.setRetryPayload(disbursementUtil.objectToJson(rquestBean));
		bean.setRetryStatus(status);
		bean.setSource("OM-Insurance-Disbursement");
		bean.setTimestamp(new Timestamp(date.getTime()).toString());
		bean.setTransactionId(activeTranchKey);
		bean.setErrorKey(request.getApplicationId() + activeTranchKey);
		bean.setRetrySuccessFlg(retrySuccessFlg);
		if (bean.getCurrentRetryCount() > 5) {
			bean.setRetryStatus("Failed");
			bean.setActiveFlg(false);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Time out flow of CreateLoan before save activeTranchKey :: " + activeTranchKey);

		disbursementUtil.saveretrytransaction(activeTranchKey.toString(), request.getApplicationId(), bean,
				new HttpHeaders());
	}

	private CreateLoanExternalRequest fetchFundedLoanPennantRequest(GlobalDataBean fundedData,
			FundedDisbursementEventRequestBean fundedRequest, LoanProcessorVariables processorVariables) {
		CreateLoanExternalRequest createLoanExternalRequest = new CreateLoanExternalRequest();
		FinanceScheduleBean financeScheduleBean = new FinanceScheduleBean();
		PartnerProductMapMaster partnerProduct = new PartnerProductMapMaster();
		try {
			// partnerProduct = disbursementUtil.fetchPartnerProductMap(fundedRequest);
			// Remove below method once Data client issue is resolved
			partnerProduct = disbursementMapperUtil.fetchPartnerProductMap(fundedRequest);
			fundedData.setL4ProductCode(partnerProduct.getPennantloantype());
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Exception occurred : Funded Create Loan Call mapMasterDataForLoanRequest", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred in Funded Create Loan Call");
		}

		FinanceDetailBean financeDetail = processFundedFinanceDetails(fundedData, fundedRequest, processorVariables);
		List<FeeDetailsBean> feeDetailslst = processFundedFees(fundedRequest);
		MandateBean mandateBean = processFundedMandateDisbAggregate(fundedData, fundedRequest);
		List<DocumentInfoBean> docList = new ArrayList<DocumentInfoBean>();
		createLoanExternalRequest.setDocuments(docList);
		List<PlanEMIHMonthsBean> emiMonths = new ArrayList<>();
		financeScheduleBean.setPlanEMIHmonths(emiMonths);
		PennantSystemDate callPennantForSystemDate = disbursementUtil.callPennantForSystemDate(fundedData, lmsUrl);
		financeScheduleBean.setVas(vasProcessor.getVasListForFunded(fundedData, feeDetailslst,
				callPennantForSystemDate.getAppDate() + DisbursementConstants.TIMESTAMP_FORMAT, fundedRequest)); // TODO
		financeScheduleBean.setFees(feeDetailslst);
		financeDetail.setFinRepayMethod(mandateBean.getMandateType());
		financeScheduleBean.setFinanceDetail(financeDetail);
		BeneficiaryBean beneficiaryBean = new BeneficiaryBean();
		createLoanExternalRequest.setBeneficiary(beneficiaryBean);
		createLoanExternalRequest.setCollaterals(new ArrayList<CollateralBean>());
		createLoanExternalRequest.setDisbursement(null);
		createLoanExternalRequest.setFinanceSchedule(financeScheduleBean);
		createLoanExternalRequest.setMandateDetail(mandateBean);
		createLoanExternalRequest.setBeneficiary(beneficiaryBean);
		if ("PARTIAL".equalsIgnoreCase(fundedRequest.getApplicationDetails().getFundingDetails().getFundingType()))
			createLoanExternalRequest.setImd(mapPartialFundedAggregate(fundedRequest));
		createLoanExternalRequest.setStp(true);
		createLoanExternalRequest.setProcessStage(DisbursementConstants.PROCESS_STAGE_BLANK);
		createLoanExternalRequest.setDisbursement(new ArrayList<>());
		mapMasterDataForLoanRequest(createLoanExternalRequest, fundedRequest, partnerProduct);
		return createLoanExternalRequest;
	}

	private FundingDetails mapPartialFundedAggregate(FundedDisbursementEventRequestBean fundedRequest) {
		FundingDetails imd = new FundingDetails();
		imd.setAmount(fundedRequest.getApplicationDetails().getPaymentDetails().getAmount());
		imd.setValueDate(fundedRequest.getApplicationDetails().getPaymentDetails().getValueDate()
				+ DisbursementConstants.TIMESTAMP_FORMAT);
		FundingReceiptDetail receiptDetail = new FundingReceiptDetail();
		receiptDetail.setFavourName(fundedRequest.getApplicantDetails().getFirstName() + " "
				+ fundedRequest.getApplicantDetails().getLastName());
		receiptDetail.setTransactionRef(fundedRequest.getApplicationDetails().getPaymentDetails().getTransactionRef());
		imd.setReceiptDetail(receiptDetail);
		return imd;
	}

	private void mapMasterDataForLoanRequest(CreateLoanExternalRequest loanExternalRequest,
			FundedDisbursementEventRequestBean fundedRequest, PartnerProductMapMaster partnerProduct) {
		loanExternalRequest.getFinanceSchedule().getFinanceDetail().setFinType(partnerProduct.getPennantloantype());
		loanExternalRequest.getFinanceSchedule().getFinanceDetail().setPromotionCode(
				null != partnerProduct.getPennantpromotion() ? partnerProduct.getPennantpromotion().toString() : null);
		loanExternalRequest.getFinanceSchedule().getVas().get(0).setProduct(partnerProduct.getPennantvasproduct());
		loanExternalRequest.getFinanceSchedule().getFees().get(0)
				.setFeeCode("{" + partnerProduct.getPennatvasfee() + "}");

	}

	private MandateBean processFundedMandateDisbAggregate(GlobalDataBean fundedData,
			FundedDisbursementEventRequestBean fundedRequest) {
		MandateBean mandateBean = new MandateBean();
		mandateBean.setCif(disbursementUtil.fetchFundedCifId(Long.valueOf(fundedRequest.getApplicationId()),
				fundedRequest.getApplicationDetails().getQuoteNumber())); // TODO
		mandateBean.setExternalMandate(true);
		mandateBean.setMandateID(null); // TODO
		mandateBean.setMandateRef(fundedRequest.getApplicationDetails().getMandateDetails().getMandateRef());
		if ("S".equalsIgnoreCase(fundedRequest.getApplicationDetails().getMandateDetails().getMandateType())) {
			// Emandate
			mandateBean.setMandateType(fundedRequest.getApplicationDetails().getMandateDetails().getMandateType());
		} else if ("A".equalsIgnoreCase(fundedRequest.getApplicationDetails().getMandateDetails().getMandateType())) {
			// Auto Debit
			mandateBean.setMandateType(DisbursementConstants.MODE_DDM);
		} else if ("E".equalsIgnoreCase(fundedRequest.getApplicationDetails().getMandateDetails().getMandateType())
				|| "Z".equalsIgnoreCase(fundedRequest.getApplicationDetails().getMandateDetails().getMandateType())) {
			// ECS(E) OR NACH(Z)
			mandateBean.setMandateType(DisbursementConstants.MODE_NACH);
		}
		mandateBean.setIfsc(fundedRequest.getApplicationDetails().getMandateDetails().getIfsc());
		mandateBean.setMicr(fundedRequest.getApplicationDetails().getMandateDetails().getMicr());
		mandateBean.setAccType(fundedRequest.getApplicationDetails().getMandateDetails().getAccType());
		mandateBean.setAccNumber(fundedRequest.getApplicationDetails().getMandateDetails().getAccNumber());
		mandateBean.setAccHolderName(fundedRequest.getApplicationDetails().getMandateDetails().getAccHolderName());
		mandateBean.setOpenMandate(fundedRequest.getApplicationDetails().getMandateDetails().getOpenMandate());
		PennantSystemDate callPennantForSystemDate = disbursementUtil.callPennantForSystemDate(fundedData, lmsUrl);
		mandateBean.setStartDate(callPennantForSystemDate.getAppDate() + DisbursementConstants.TIMESTAMP_FORMAT);
		mandateBean.setExpiryDate(fundedRequest.getApplicationDetails().getMandateDetails().getExpiryDate()
				+ DisbursementConstants.TIMESTAMP_FORMAT);
		mandateBean.setMaxLimit(fundedRequest.getApplicationDetails().getMandateDetails().getMaxLimit());
		mandateBean.setPeriodicity("M0001");
		mandateBean.setActive(true);
		mandateBean.setStatus("NEW");
		// mandateBean.seteMandateRefNo(fundedRequest.getApplicationDetails().getMandateDetails().getMandateRef());
		mandateBean.seteMandateSource(fundedRequest.getApplicationDetails().getMandateDetails().getSubrepaymode());
		return mandateBean;
	}

	private List<FeeDetailsBean> processFundedFees(FundedDisbursementEventRequestBean request) {
		List<FeeDetailsBean> feeDtlLst = new ArrayList<FeeDetailsBean>();
		FeeDetailsBean bean = new FeeDetailsBean();
		bean.setFeeAmount(new BigDecimal(request.getApplicationDetails().getFundingDetails().getFundingAmount()));
		bean.setFeeMethod("DISB");
		bean.setWaiverAmount(new BigDecimal(0));
		bean.setPaidAmount(new BigDecimal(0));
		bean.setScheduleTerms(0);
		feeDtlLst.add(bean);
		return feeDtlLst;
	}

	private FinanceDetailBean processFundedFinanceDetails(GlobalDataBean fundedData,
			FundedDisbursementEventRequestBean request, LoanProcessorVariables processorVariables) {
		FinanceDetailBean financeDetailBean = new FinanceDetailBean();
		financeDetailBean.setApplicationNo(request.getApplicationDetails().getQuoteNumber());
		String cif = disbursementUtil.fetchFundedCifId(Long.valueOf(request.getApplicationDetails().getApplicationNo()),
				request.getApplicationDetails().getQuoteNumber()); // TODO
		financeDetailBean.setCif(cif);
		financeDetailBean.setFinCcy("INR");
		financeDetailBean.setDownPayBank("0");
		financeDetailBean.setDownPaySupl("0");
		financeDetailBean.setTdsApplicable("false");
		financeDetailBean.setManualSchedule("false");
		financeDetailBean.setPlanDeferCount("0");
		financeDetailBean.setGrcPftFrq("M0002");
		financeDetailBean.setAllowGrcPeriod("false");
		// financeDetailBean.setGrcSchdMthd("PFT");
		financeDetailBean.setReqRepayAmount("0");
		financeDetailBean.setRepayRateBasis("R");
		financeDetailBean.setScheduleMethod("EQUAL");
		financeDetailBean.setRepayFrq("M0002");
		financeDetailBean.setRepayPftFrq("M0002");
		financeDetailBean.setFinRepayPftOnFrq("false");
		financeDetailBean.setRepayMinRate("0");
		financeDetailBean.setRepayMaxRate("0");
		financeDetailBean.setAlwBpiTreatment("false");
		PennantSystemDate callPennantForSystemDate = disbursementUtil.callPennantForSystemDate(fundedData, lmsUrl);
		financeDetailBean
				.setFinStartDate(callPennantForSystemDate.getAppDate() + DisbursementConstants.TIMESTAMP_FORMAT);
		financeDetailBean.setFinBranch(DisbursementConstants.DEFAULT_BRANCH_PUNE);
		financeDetailBean.setFinAmount(request.getApplicationDetails().getFundingDetails().getFundingAmount());
		financeDetailBean.setFinAssetValue(request.getApplicationDetails().getFundingDetails().getFundingAmount());
		financeDetailBean.setGrcTerms(null);
		financeDetailBean.setGrcPftRate(null);// request.getApplicationDetails().getFundingDetails().getFundingROI());
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		Date eminextDt = null;
		Date emifirstDt = null;
		String emifirstDtfmt = null;
		String eminextDtfmt = null;
		BreDueDateResponse breRes = callBRE(fundedData, null, new HttpHeaders(), processorVariables.isHybridFlexi(),
				true, Integer.valueOf(request.getApplicationDetails().getFundingDetails().getFundingTenor()),
				fetchQuoteNumberForBRE(request.getApplicationDetails().getQuoteNumber()));
		try {
			if (null != breRes.getArcduedateOutput().getNextDueDateDetails()
					&& !breRes.getArcduedateOutput().getNextDueDateDetails().isEmpty()) {
				eminextDt = new SimpleDateFormat("yyyy-MM-dd")
						.parse(breRes.getArcduedateOutput().getNextDueDateDetails().get(0).getNextDueDate());
				eminextDtfmt = df.format(eminextDt);
			}
			if (null != breRes.getArcduedateOutput().getDueDateDetails()
					&& !breRes.getArcduedateOutput().getDueDateDetails().isEmpty()) {
				emifirstDt = new SimpleDateFormat("yyyy-MM-dd")
						.parse(breRes.getArcduedateOutput().getDueDateDetails().get(0).getFirstDueDate());
				emifirstDtfmt = df.format(emifirstDt);
			}
			financeDetailBean.setNextRepayDate(emifirstDtfmt); // TODO
			financeDetailBean.setNextRepayPftDate(emifirstDtfmt); // TODO
		} catch (ParseException e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing NextGrcPftDate.");
		}
		financeDetailBean.setNumberOfTerms(request.getApplicationDetails().getFundingDetails().getFundingTenor());
		financeDetailBean.setRepayPftRate(null);// request.getApplicationDetails().getFundingDetails().getFundingROI());
		financeDetailBean.setRelationshipOfficer("DEFAULT");
		financeDetailBean.setAlwFlexi("false");
		return financeDetailBean;
	}

	private String fetchQuoteNumberForBRE(String quoteNumber) {
		String quote = quoteNumber.replaceAll("[^0-9]", "");
		return quote;
	}

	private String processLoanLmsResponseForFunded(FundedDisbursementEventRequestBean request,
			String loanResponseString, HttpHeaders headers) {
		String status = null;
		Gson gson = new Gson();
		CreateLoanResponseBean createLoanResponseBean = gson.fromJson(loanResponseString, CreateLoanResponseBean.class);
		String returnCode = createLoanResponseBean.getReturnStatus().getReturnCode();
		if (DisbursementConstants.PENNANT_SUCCES_CODE.equals(returnCode)
				|| DisbursementConstants.LOAN_APPLICATION_EXIST_IN_PENNANT_CODE.equals(returnCode)) {
			disbursementUtil.updateServiceRecordForFundedLoan(Long.valueOf(request.getApplicationId()),
					request.getApplicationDetails().getQuoteNumber(), createLoanResponseBean.getFinReference());
			status = "Success";
		} else {
			status = "Failure";
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "CREATE_LOAN_FAILED  failed: ");
		}

		boolean eventFlag = disbursementUtil.raiseInsuranceEventPostDisbursement(request, createLoanResponseBean,
				createLoanResponseBean.getReturnStatus(), "CREATE_LOAN",
				disbursementUtil.fetchFundedCifId(Long.valueOf(request.getApplicationId()),
						request.getApplicationDetails().getQuoteNumber()),
				DisbursementConstants.BFL_DISBURSEMENT_STATUS);
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End processLoanLmsResponseForFunded status:" + status + " EventFlag:" + eventFlag);
		return status;
	}

}
