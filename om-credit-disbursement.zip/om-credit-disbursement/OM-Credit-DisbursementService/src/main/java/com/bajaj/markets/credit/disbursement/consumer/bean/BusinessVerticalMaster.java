package com.bajaj.markets.credit.disbursement.consumer.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessVerticalMaster {

	private Long businessVerticalMastkey;

	private String businessVerticalCode;

	private String businessVerticalName;

	private String poTypeCode;

	private String poType;

	public Long getBusinessverticalmastkey() {
		return businessVerticalMastkey;
	}

	public void setBusinessverticalmastkey(Long businessVerticalMastkey) {
		this.businessVerticalMastkey = businessVerticalMastkey;
	}

	public String getBusinessverticalcode() {
		return businessVerticalCode;
	}

	public void setBusinessverticalcode(String businessverticalcode) {
		this.businessVerticalCode = businessverticalcode;
	}

	public String getBusinessverticalname() {
		return businessVerticalName;
	}

	public void setBusinessverticalname(String businessverticalname) {
		this.businessVerticalName = businessverticalname;
	}

	public String getPotypecode() {
		return poTypeCode;
	}

	public void setPotypecode(String potypecode) {
		this.poTypeCode = potypecode;
	}

	public String getPotype() {
		return poType;
	}

	public void setPotype(String potype) {
		this.poType = potype;
	}

	@Override
	public String toString() {
		return "BusinessVerticalMaster [businessverticalmastkey=" + businessVerticalMastkey + ", businessverticalcode="
				+ businessVerticalCode + ", businessverticalname=" + businessVerticalName + ", potypecode=" + poTypeCode
				+ ", potype=" + poType + "]";
	}

}
