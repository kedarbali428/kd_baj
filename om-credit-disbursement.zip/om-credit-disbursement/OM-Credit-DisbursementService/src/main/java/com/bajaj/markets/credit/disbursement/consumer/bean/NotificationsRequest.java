package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.Map;

public class NotificationsRequest {

	private String notificationTypeCode;

	private String templateCode;

	private long userKey;

	private Map<String, Object> templateDataMap;

	public String getNotificationTypeCode() {
		return notificationTypeCode;
	}

	public void setNotificationTypeCode(String notificationTypeCode) {
		this.notificationTypeCode = notificationTypeCode;
	}

	public String getTemplateCode() {
		return templateCode;
	}

	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}

	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}

	public Map<String, Object> getTemplateDataMap() {
		return templateDataMap;
	}

	public void setTemplateDataMap(Map<String, Object> templateDataMap) {
		this.templateDataMap = templateDataMap;
	}
	
}
