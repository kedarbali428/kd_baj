package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class FeeDetails {

	private Long feesKey;
	private BigDecimal feesInPercent;	
	private BigDecimal feesInAmount;
	private String feeCode;
	
	public Long getFeesKey() {
		return feesKey;
	}
	public void setFeesKey(Long feesKey) {
		this.feesKey = feesKey;
	}
	public BigDecimal getFeesInPercent() {
		return feesInPercent;
	}
	public void setFeesInPercent(BigDecimal feesInPercent) {
		this.feesInPercent = feesInPercent;
	}
	public BigDecimal getFeesInAmount() {
		return feesInAmount;
	}
	public void setFeesInAmount(BigDecimal feesInAmount) {
		this.feesInAmount = feesInAmount;
	}
	public String getFeeCode() {
		return feeCode;
	}
	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}
	@Override
	public String toString() {
		return "FeeDetails [feesKey=" + feesKey + ", feesInPercent=" + feesInPercent + ", feesInAmount=" + feesInAmount
				+ ", feeCode=" + feeCode + "]";
	}
}