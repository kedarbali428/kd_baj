package com.bajaj.markets.credit.disbursement.consumer.bean;

public class SubIndustriesMaster {

	private Integer subindmastkey;

	private Integer indmastkey;

	public Integer getSubindmastkey() {
		return subindmastkey;
	}

	public void setSubindmastkey(Integer subindmastkey) {
		this.subindmastkey = subindmastkey;
	}

	public Integer getIndmastkey() {
		return indmastkey;
	}

	public void setIndmastkey(Integer indmastkey) {
		this.indmastkey = indmastkey;
	}

}
