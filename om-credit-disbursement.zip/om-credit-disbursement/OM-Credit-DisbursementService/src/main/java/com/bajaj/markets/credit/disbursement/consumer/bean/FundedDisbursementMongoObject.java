package com.bajaj.markets.credit.disbursement.consumer.bean;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class FundedDisbursementMongoObject {

	@Id
	private String id;

	@Indexed
	private Long applicationKey;

	private String quoteNumber;

	private String cif;

	private String customerLoanId;
	
	private String disbursementStatus;
	
	private String disbDate;
	
	private String disbInitiatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getQuoteNumber() {
		return quoteNumber;
	}

	public void setQuoteNumber(String quoteNumber) {
		this.quoteNumber = quoteNumber;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getCustomerLoanId() {
		return customerLoanId;
	}

	public void setCustomerLoanId(String customerLoanId) {
		this.customerLoanId = customerLoanId;
	}

	public String getDisbursementStatus() {
		return disbursementStatus;
	}

	public void setDisbursementStatus(String disbursementStatus) {
		this.disbursementStatus = disbursementStatus;
	}

	public String getDisbDate() {
		return disbDate;
	}

	public void setDisbDate(String disbDate) {
		this.disbDate = disbDate;
	}

	public String getDisbInitiatedBy() {
		return disbInitiatedBy;
	}

	public void setDisbInitiatedBy(String disbInitiatedBy) {
		this.disbInitiatedBy = disbInitiatedBy;
	}

}
