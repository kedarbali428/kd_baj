package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class CreateLimitResponseBean {
	
		private BigDecimal limitId;
		private ReturnStatusBean returnStatus;
		private Status status;
		
		public BigDecimal getLimitId() {
			return limitId;
		}
		public void setLimitId(BigDecimal limitId) {
			this.limitId = limitId;
		}
		public Status getStatus() {
			return status;
		}
		public void setStatus(Status status) {
			this.status = status;
		}
		public ReturnStatusBean getReturnStatus() {
			return returnStatus;
		}
		public void setReturnStatus(ReturnStatusBean returnStatus) {
			this.returnStatus = returnStatus;
		}

}
