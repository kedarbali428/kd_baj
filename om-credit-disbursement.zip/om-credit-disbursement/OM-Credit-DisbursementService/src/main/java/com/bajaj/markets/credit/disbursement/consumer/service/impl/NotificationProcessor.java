package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.bflawsutil.helper.BFLAwsS3Helper;
import com.bajaj.markets.credit.disbursement.consumer.bean.AppBundleDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.AppPlanDetCostBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationBFLDocsRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationBFLDocsResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.BFLDocument;
import com.bajaj.markets.credit.disbursement.consumer.bean.FeeDetailsBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.NotificationTemplateDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.NotificationsRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.OccupationAttribute;
import com.bajaj.markets.credit.disbursement.consumer.bean.PricingDetail;
import com.bajaj.markets.credit.disbursement.consumer.bean.PricingFees;
import com.bajaj.markets.credit.disbursement.consumer.bean.ProductTypeBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.VasPricingCheckBean;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class NotificationProcessor {

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Autowired
	BFLLoggerUtil logger;

	@Value("${bfsd.web.customer.portal.url}")
	private String custPortalLink;

	@Value("${api.documents.applications.POST.url}")
	private String getDocListUrl;

	@Value("${api.notifications.sendnotifications.POST.url}")
	private String notificationUrl;

	@Value("${aws.s3.bucketName}")
	private String bucketName;
	
	@Value("#{${occupationType.map}}")
	private Map<String,String> occupationType;
	
	@Autowired
    private BFLAwsS3Helper helper;
	
	@Autowired
	LoanProcessor loanProcessor;

	private static final String CLASS_NAME = CollateralProcessor.class.getCanonicalName();

	public void sendNotifications(NotificationTemplateDataBean notificationTemplateBean, GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendNotifications : Start : ");
		Map<String, Object> templateDataMap = mapTemplateData(notificationTemplateBean, data);
		NotificationsRequest notificationRequest = new NotificationsRequest();
		notificationRequest.setNotificationTypeCode("OMPLDISBURSEMENT");
		notificationRequest.setTemplateDataMap(templateDataMap);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendNotifications : notificationRequest : "+notificationRequest);
		if(null!=templateDataMap.get("attachmentLink")) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendNotifications : attachmentLink : "+templateDataMap.get("attachmentLink"));
		}
		boolean isSent = execute(notificationRequest, data);
		if (isSent) {
			NotificationsRequest notificationsRequest1 = new NotificationsRequest();
			notificationsRequest1.setNotificationTypeCode("OMPLDISBWELCOMELTR");
			notificationsRequest1.setTemplateDataMap(templateDataMap);

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendNotifications : notificationsRequest1 : "+notificationsRequest1);
			if(null!=templateDataMap.get("attachmentLink")) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendNotifications : attachmentLink : "+templateDataMap.get("attachmentLink"));
			}
			isSent = execute(notificationsRequest1, data);

			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "isSent 2nd mail isSent" + isSent);
		} else {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"disbursment welcome letter: Failed to sent notifications. ");
		}

	}

	@SuppressWarnings("unchecked")
	private boolean execute(NotificationsRequest notificationRequest, GlobalDataBean data) {
		boolean result = false;
		Gson gson = new Gson();
		String inputStr = gson.toJson(notificationRequest, NotificationsRequest.class);
		try {
			ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper

					.invokeRestEndpoint(HttpMethod.POST, notificationUrl, String.class, null, inputStr,
							generateHeaders(data));

			if (response != null && response.getStatusCode().equals(HttpStatus.OK)
					&& response.getStatusCode().equals(HttpStatus.OK)) {
				logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY,
						"Notification Success Response: " + response.getBody());
				result = true;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Exception occurred : Send Notification ", e);
			logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"NotificationClient-Failed to execute notification request: " + e);
		}
		return result;

	}

	private Map<String, Object> mapTemplateData(NotificationTemplateDataBean notificationTemplateBean,
			GlobalDataBean data) {
		Map<String, Object> templateDataMap = new HashMap<>();
		templateDataMap.put("applicationNo", data.getApplicationKey());
		templateDataMap.put("amount", notificationTemplateBean.getAmount());
		
		OccupationAttribute occupationAttribute = disbursementBusinessHelper.getOccupationDetails(data, generateHeaders(data));
		if(null!=occupationAttribute) {
			templateDataMap.put("occupationType",occupationType.get(occupationAttribute.getOcupationType().getKey().toString()));
		}
        ProductTypeBean productTypeBean = disbursementBusinessHelper.getProductTypeDetails(data.getApplicationKey(),generateHeaders(data));
        AppBundleDetails appBundleDetails = disbursementBusinessHelper.fetchBundleDetails(data.getApplicationKey(),generateHeaders(data));
        List<AppPlanDetCostBean> appPlanDetCostBeanList = new ArrayList<>();
        if(null != appBundleDetails.getBundleApplicationKey()) {
           appPlanDetCostBeanList = disbursementBusinessHelper.fetchPricingDetails(appBundleDetails.getBundleApplicationKey(),generateHeaders(data));
        }
        
        List<FeeDetailsBean> feeDtlLst = new ArrayList<FeeDetailsBean>();
        feeDtlLst = processFees(data.getApplicationKey(),generateHeaders(data));
        if (null != feeDtlLst) {
			for (FeeDetailsBean fees : feeDtlLst) {
				if (fees.getFeeCode().equals("PROCFEE")) {
					templateDataMap.put("processingFees", fees.getFeeAmount());
				} else if (fees.getFeeCode().equals("STAMPFEE")) {
					templateDataMap.put("stampFees", fees.getFeeAmount());
				} else if (fees.getFeeCode().equals("CONV")) {
					templateDataMap.put("ConvenienceFees", fees.getFeeAmount());
				}
			}
		}
		templateDataMap.put("loanType",productTypeBean.getDisplayloantypename());
		templateDataMap.put("recipientEmailId", notificationTemplateBean.getRecipientEmailId());
		templateDataMap.put("phoneNumber", notificationTemplateBean.getPhoneNumber());
		templateDataMap.put("customerName", notificationTemplateBean.getCustomerName());
		templateDataMap.put("name", notificationTemplateBean.getCustomerName());
		templateDataMap.put("lanNumber", notificationTemplateBean.getLanNumber());
		templateDataMap.put("customerPortalUrl", custPortalLink);
		
		fetchDocumentAttachmentLink(data, templateDataMap);
      
		templateDataMap.put("tenor",
				null != notificationTemplateBean.getTenor() ? notificationTemplateBean.getTenor() : "-NA-");
		
		if (null != appPlanDetCostBeanList && !appPlanDetCostBeanList.isEmpty()) {
		if(appBundleDetails.getBundlePlanKey()== 5) {
			templateDataMap.put("isFpp", "true");
			templateDataMap.put("fpp", (int)appPlanDetCostBeanList.get(0).getActualPrice());
		}
		else {
			templateDataMap.put("fppLite", (int)appPlanDetCostBeanList.get(0).getActualPrice());
		}
		}
		templateDataMap.put("roi",
				null != notificationTemplateBean.getRoi() ? notificationTemplateBean.getRoi() : "-NA-");

		templateDataMap.put("firstEMIdt",
				null != notificationTemplateBean.getFirstEMIdt() ? notificationTemplateBean.getFirstEMIdt() : "-NA-");
		templateDataMap.put("emiCycleDay",
				null != notificationTemplateBean.getEmiCycleDay() ? notificationTemplateBean.getEmiCycleDay() : "-NA-");

		templateDataMap.put("productName",productTypeBean.getDisplayproductname());

		templateDataMap.put("isHybridFlexi", notificationTemplateBean.isHybridFlexi());
		templateDataMap.put("firstEmiAmt",
				null != notificationTemplateBean.getFirstEmiAmt() ? Integer.valueOf(notificationTemplateBean.getFirstEmiAmt()) : "-NA-");

		templateDataMap.put("isTenure",
				null != notificationTemplateBean.getIsTenure() ? notificationTemplateBean.getIsTenure() : "-NA-");
		templateDataMap.put("isEmiAmt",
				null != notificationTemplateBean.getIsEmiAmt() ? notificationTemplateBean.getIsEmiAmt() : "-NA-");

		templateDataMap.put("droplineTenure",
				null != notificationTemplateBean.getDroplineTenure() ? notificationTemplateBean.getDroplineTenure()
						: "-NA-");

		templateDataMap.put("dropLineEmiAmt",
				null != notificationTemplateBean.getDropLineEmiAmt() ? notificationTemplateBean.getDropLineEmiAmt()
						: "-NA-");

		return templateDataMap;
	}

	@SuppressWarnings("unchecked")
	private void fetchDocumentAttachmentLink(GlobalDataBean data, Map<String, Object> templateDataMap) {
		/*
		 * Get the url of disbursement document of journey and attachment it with
		 * Disbursement mail
		 */
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchDocumentAttachmentLink : Start : ");
		ApplicationBFLDocsRequestBean inputBean = new ApplicationBFLDocsRequestBean();
		inputBean.setApplicantId(Long.valueOf(data.getApplicantKey()));
		inputBean.setApplicationId(Long.valueOf(data.getApplicationKey()));
		inputBean.setDocListType("ALL");

		Gson gson = new Gson();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String inputBeanStr = gson.toJson(inputBean, ApplicationBFLDocsRequestBean.class);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.POST, getDocListUrl, String.class, null, inputBeanStr, generateHeaders(data));

		ApplicationBFLDocsResponseBean res = null;
		if (response != null && response.getBody() != null && response.getBody() != null) {
			res = gson.fromJson(getPayloadResponseString(response.getBody().toString()),
					ApplicationBFLDocsResponseBean.class);
		}

		if (res != null && res.getDocList() != null && !res.getDocList().isEmpty()) {
			for (BFLDocument doc : res.getDocList()) {
				if (DisbursementConstants.CONS_ESIGNED_DOC.equals(doc.getDocCategoryCode())) {
					templateDataMap.put("attachmentLink", doc.getUrl());
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "EsignDocumentLink : " + doc.getUrl());
					break;
				}
			}
		}
	}

	private String getPayloadResponseString(String jsonInString) {
		JsonNode rootNode = null;

		try {
			ObjectMapper mapper = new ObjectMapper();
			rootNode = mapper.readTree(jsonInString);
		} catch (JsonProcessingException e) {
			throw new DisbursementServiceException(e);
		} catch (IOException e) {
			throw new DisbursementServiceException(e);
		}
		JsonNode keyNode = rootNode.findValue(DisbursementConstants.PAYLOAD);
		keyNode.toString();
		keyNode.asText();
		keyNode.textValue();

		return keyNode.toString();
	}

	public HttpHeaders generateHeaders(GlobalDataBean data) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("authtoken", data.getHeaders().get("authtoken"));
		headers.add("cmptcorrid", data.getHeaders().get("cmptcorrid"));
		headers.add("guardtoken", data.getHeaders().get("guardtoken"));
		return headers;
	}
	public void sendSanctionLetter(NotificationTemplateDataBean notificationTemplateBean, GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendSanctionLetter : Start : ");
		Map<String, Object> templateDataMap = mapTemplateData(notificationTemplateBean, data);
		NotificationsRequest notificationRequest = new NotificationsRequest();
		notificationRequest.setNotificationTypeCode("SANCTIONLETTER");
		notificationRequest.setTemplateDataMap(templateDataMap);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendSanctionLetter : notificationRequest : "+notificationRequest);
		boolean isSent = execute(notificationRequest, data);
		if(isSent) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendSanctionLetter : Success : ");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendSanctionLetter : End : ");
	}
	
	public List<FeeDetailsBean> processFees(String applicationKey,HttpHeaders headers) {
		List<FeeDetailsBean> feeDtlLst = new ArrayList<FeeDetailsBean>();
		List<PricingDetail> pricingDetailLst = loanProcessor.fetchPricingDetails(applicationKey,headers);
		List<PricingFees> pricingFeeLst = new ArrayList<PricingFees>();
		VasPricingCheckBean latestPricing = loanProcessor.fetchLatestPricingDetails(applicationKey,headers);
		if (null != pricingDetailLst && !pricingDetailLst.isEmpty()) {
			for (PricingDetail pricingDetail : pricingDetailLst) {
				if (pricingDetail.getAppLoanPricingKey()
						.equalsIgnoreCase(latestPricing.getAppLoanPricingKey().toString())) {
					pricingFeeLst = pricingDetail.getFees();
					break;
				}
			}
		}
		pricingFeeLst.forEach(item -> {
			FeeDetailsBean bean = new FeeDetailsBean();
			bean.setFeeAmount(item.getFeesInAmount());
			bean.setFeeCode(item.getFeeCode());
			bean.setFeeMethod("DISB");
			bean.setWaiverAmount(new BigDecimal(0));
			bean.setPaidAmount(new BigDecimal(0));
			feeDtlLst.add(bean);
		});
		return feeDtlLst;
	}

}
