package com.bajaj.markets.credit.disbursement.consumer.bean;

public class PinCodeMaster {

	private Long pincodekey;

	private String pincode;

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

}
