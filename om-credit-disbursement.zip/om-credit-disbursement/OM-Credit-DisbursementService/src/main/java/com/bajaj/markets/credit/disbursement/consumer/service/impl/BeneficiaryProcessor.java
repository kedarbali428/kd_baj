package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.awaitility.Awaitility;
import org.awaitility.core.ConditionTimeoutException;
import org.awaitility.pollinterval.FibonacciPollInterval;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.BeneficiaryBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.BeneficiaryProcessorVariables;
import com.bajaj.markets.credit.disbursement.consumer.bean.BranchDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateBeneficiaryExternalResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateBeneficiaryResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.Status;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementMapperUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.LMSHelper;
import com.bajaj.markets.credit.disbursement.repository.MongoDBRepository;
import com.google.gson.Gson;

/**
 * @author pranoti.pandole
 *
 */

@Component
public class BeneficiaryProcessor {

	@Autowired
	BFLLoggerUtil logger;

	@Value("${erroScenarioFlg}")
	private String erroScenarioFlg;

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Autowired
	DisbursementMapperUtil disbursementMapperUtil;

	@Autowired
	LMSHelper lmsHelper;

	@Autowired
	DisbursementUtil disbursementUtil;

	@Autowired
	MongoDBRepository mongoDbRepo;

	@Autowired
	@Qualifier("disbursementMongoTemplate")
	MongoOperations disbursementMongoTemplate;

	@Value("${initiateDisbUrl}")
	private String initiateDisbUrl;

	@Autowired
	Environment env;

	private static final String CLASS_NAME = BeneficiaryProcessor.class.getCanonicalName();
	
	@SuppressWarnings("static-access")
	public void processBeneficiaryRequest(GlobalDataBean data) {
		CreateBeneficiaryResponseBean response = new CreateBeneficiaryResponseBean();
		BeneficiaryProcessorVariables processorVariables=new BeneficiaryProcessorVariables();
		try {
			BeneficiaryBean beneficiaryRequest = getBeneficiaryDetails(data, generateHeaders(data));
		     Long startTime=null;
		     Long stopTime=null;
			try {
				 startTime = System.currentTimeMillis();
				FibonacciPollInterval fibonacci = new FibonacciPollInterval(TimeUnit.SECONDS);
				Awaitility.setDefaultTimeout(300, TimeUnit.SECONDS);
				Awaitility.with().pollInterval(fibonacci).await().atMost(300, TimeUnit.SECONDS)
						.until(() -> null != (executeLMSRequestforBeneficiary(
								data.getApplicationKey(), data.getL2ProductCode(), beneficiaryRequest,
								generateHeaders(data), processorVariables)));
				 stopTime = System.currentTimeMillis();
			} catch (ConditionTimeoutException e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Timeout flow of  CreateBeneficiary ::");
				List<TranchBean> trnchLst = disbursementUtil.fetchTranchDetails(data.getApplicationKey(),
						generateHeaders(data));
				Long activeTranchKey = trnchLst.get(0).getTranchkey();
				RetryRegistrationBean existingRecords = null;
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Timeout flow of  CreateBeneficiary for activeTranchKey :: " + activeTranchKey);
				existingRecords = disbursementUtil.fetchExistingTransaction(activeTranchKey.toString(),
						data.getApplicationKey(), generateHeaders(data));
				DisbursementRequestBean rquestBean = new DisbursementRequestBean();
				rquestBean.setApplicantId(data.getApplicantKey());
				rquestBean.setApplicationId(data.getApplicationKey());
				rquestBean.setProductCode(data.getL3ProductCode());
				RetryRegistrationBean bean = new RetryRegistrationBean();
				bean.setActiveFlg(true);
				if (null != existingRecords) {
					bean.setCurrentRetryCount(existingRecords.getCurrentRetryCount() + 1l);
				} else {
					bean.setCurrentRetryCount(1l);
				}
				rquestBean.setStage("CREATE_BENEFICIARY");
				rquestBean.setTransactionId(activeTranchKey.toString());
				bean.setErrorCode("DISBURSEMENT_CREATE_BENEFICIARY");
				bean.setNextReryTime(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(5)).toString());
				bean.setRetryClass("CreditDisbursementController");
				bean.setRetryMechanism("Endpoint");
				bean.setRetryMethod(initiateDisbUrl);
				bean.setRetryPayload(disbursementUtil.objectToJson(rquestBean));
				bean.setRetryStatus("Pending");
				bean.setSource("OM-Credit-Disbursement");
				Date date = new Date();
				bean.setTimestamp(new Timestamp(date.getTime()).toString());
				bean.setTransactionId(activeTranchKey);
				if (bean.getCurrentRetryCount() > 5) {
					bean.setRetryStatus("Failed");
					bean.setActiveFlg(false);
				}
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Timeout flow of  CreateBeneficiary before Save for activeTranchKey :: " + activeTranchKey);
				processorVariables.setRetryMechanism(true);
				disbursementUtil.saveretrytransaction(activeTranchKey.toString(), data.getApplicationKey(), bean,
						generateHeaders(data));
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Completed beneficiaryResponseString :");

			if (null !=  processorVariables.getBeneficiaryResponseString() && !processorVariables.isRetryMechanism()) {
				disbursementUtil.addDisbursementRecords(data.getApplicationKey(), data.getApplicantKey(), mapToJson(beneficiaryRequest),  processorVariables.getBeneficiaryResponseString(), DisbursementConstants.LMS_BENEFICIARY_SOURCE,
						null!=startTime?startTime.toString():null, null!=stopTime?stopTime.toString():null);
				response = processBeneficiaryLmsResponse(data,  processorVariables.getBeneficiaryResponseString(), generateHeaders(data));
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred : processBeneficiaryRequest Call ",
					e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred in processBeneficiaryRequest Call");
		}
	}

	private CreateBeneficiaryResponseBean processBeneficiaryLmsResponse(GlobalDataBean data,
			String beneficiaryResponseString, HttpHeaders headers) {
		Gson gson = new Gson();
		CreateBeneficiaryExternalResponse beneficiaryPennatResponse=null;
		if(!beneficiaryResponseString.contains("faultCode")) {
		 beneficiaryPennatResponse = gson.fromJson(beneficiaryResponseString,
				CreateBeneficiaryExternalResponse.class);
		}
		CreateBeneficiaryResponseBean finalResponse = new CreateBeneficiaryResponseBean();

		if (beneficiaryPennatResponse != null) {
			String returnCode = beneficiaryPennatResponse.getReturnStatus().getReturnCode();
			if (DisbursementConstants.PENNANT_SUCCES_CODE.equals(returnCode)
					|| DisbursementConstants.PENNANT_BENE_EXISTS_CODE.equals(returnCode)) {
				finalResponse.setBeneficiaryID(beneficiaryPennatResponse.getBeneficiaryID());
				finalResponse.setStatus(Status.SUCCESS);
				// Update Mongo
				updateServiceRecordForBeneficiary(data.getApplicationKey(), data.getApplicantKey(),
						beneficiaryPennatResponse.getBeneficiaryID().toString());
				// update Aurora
				disbursementUtil.updateAppTranch(data.getApplicationKey(),
						DisbursementConstants.TRANCHE_STATUS_PROGRESS, DisbursementConstants.DISB_SUCCESS_FLAG, null,
						null, headers);
			} 
			else {
				finalResponse.setStatus(Status.FAILURE);
				disbursementUtil.updateAppTranch(data.getApplicationKey(), DisbursementConstants.TRANCHE_STATUS_FAILED,
						DisbursementConstants.DISB_FAILURE_FLAG, null, null, headers);
				DisbursementEventRequestBean disbursementEventRequestBean = new DisbursementEventRequestBean();
				if ("Y".equals(erroScenarioFlg)) {
					saveDisbursementError(data, data.getApplicationKey(), beneficiaryResponseString);
					disbursementEventRequestBean.setApplicantId(data.getApplicantKey());
					disbursementEventRequestBean.setApplicationId(data.getApplicationKey());
					disbursementEventRequestBean.setEventType("DISBURSEMENT_FAILED");
					disbursementEventRequestBean.setProductCode(data.getL3ProductCode());
					disbursementEventRequestBean.setHeaders(data.getHeaders());
					disbursementUtil.raiseEvent(disbursementEventRequestBean,
							DisbursementConstants.DISBURSEMENT_FAILED);
					logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "CREATE_BENEFICIARY_FAILED  failed: ");
					logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "CREATE_BENEFICIARY_FAILED  failed: ");
					throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
							new ErrorBean("CDS-200", "CREATE_BENEFICIARY_FAILED"));
				}
			}
		}else {
			finalResponse.setStatus(Status.FAILURE);
			disbursementUtil.updateAppTranch(data.getApplicationKey(), DisbursementConstants.TRANCHE_STATUS_FAILED,
					DisbursementConstants.DISB_FAILURE_FLAG, null, null, headers);
			DisbursementEventRequestBean disbursementEventRequestBean = new DisbursementEventRequestBean();
			if ("Y".equals(erroScenarioFlg)) {
				saveBeneficiaryError(data, data.getApplicationKey(), beneficiaryResponseString);
				disbursementEventRequestBean.setApplicantId(data.getApplicantKey());
				disbursementEventRequestBean.setApplicationId(data.getApplicationKey());
				disbursementEventRequestBean.setEventType("DISBURSEMENT_FAILED");
				disbursementEventRequestBean.setProductCode(data.getL3ProductCode());
				disbursementEventRequestBean.setHeaders(data.getHeaders());
				disbursementUtil.raiseEvent(disbursementEventRequestBean,
						DisbursementConstants.DISBURSEMENT_FAILED);
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "CREATE_BENEFICIARY_FAILED  failed: ");
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "CREATE_BENEFICIARY_FAILED  failed: ");
				throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
						new ErrorBean("CDS-200", "CREATE_BENEFICIARY_FAILED"));
			}
		}
		return finalResponse;
	}

	private void saveDisbursementError(GlobalDataBean data, String applicationId, String beneficiaryResponseString) {
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		disbursementTrackerBean.setApplicationId(Long.parseLong(applicationId));
		disbursementTrackerBean.setDisbursmentstage(DisbursementConstants.CREATE_BENEFICIARY);
		disbursementTrackerBean.setError(DisbursementConstants.CREATE_BENEFICIARY_FAILED);
		String errorReason = disbursementUtil.logDisbErrors(applicationId, beneficiaryResponseString);
		disbursementTrackerBean.setErrorreason(errorReason);
		disbursementTrackerBean.setErrorretryable(1l);
		disbursementTrackerBean.setIsActive(1l);
		disbursementTrackerBean.setStatus("CREATED");
		disbursementUtil.saveDisbursementErrorDetails(data, disbursementTrackerBean);
	}
	
	private void saveBeneficiaryError(GlobalDataBean data, String applicationId, String beneficiaryResponseString) {
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		disbursementTrackerBean.setApplicationId(Long.parseLong(applicationId));
		disbursementTrackerBean.setDisbursmentstage(DisbursementConstants.CREATE_BENEFICIARY);
		disbursementTrackerBean.setError(DisbursementConstants.CREATE_BENEFICIARY_FAILED);
		String errorReason = disbursementUtil.logBeneficiaryDisbErrors(applicationId, beneficiaryResponseString);
		disbursementTrackerBean.setErrorreason(errorReason);
		disbursementTrackerBean.setErrorretryable(1l);
		disbursementTrackerBean.setIsActive(1l);
		disbursementTrackerBean.setStatus("CREATED");
		disbursementUtil.saveDisbursementErrorDetails(data, disbursementTrackerBean);
	}

	public void updateServiceRecordForBeneficiary(String applicationKey, String applicantKey, String beneficiaryID) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "updateServiceRecordForBeneficiary : Start : ");
		mongoDbRepo.updateFieldByApplicationKeyAndApplicantKey(disbursementMongoTemplate, Long.valueOf(applicationKey),
				Long.valueOf(applicantKey), DisbursementConstants.BENEFICIARY_ID, beneficiaryID,
				DisbursementConstants.SERVICE_RECORD);

	}

	private String executeLMSRequestforBeneficiary(String applicationId, String prodCode,
			BeneficiaryBean beneficiaryRequest, HttpHeaders headers, BeneficiaryProcessorVariables processorVariables) {
		String beneficiaryRequestStr = mapToJson(beneficiaryRequest);
		Object response = lmsHelper.executeLmsRequest(DisbursementConstants.LMS_BENEFICIARY_SOURCE, prodCode,
				beneficiaryRequestStr, applicationId, headers);
		processorVariables.setBeneficiaryResponseString(response.toString());
		return response.toString();
	}

	public BeneficiaryBean getBeneficiaryDetails(GlobalDataBean data, HttpHeaders header) {
		try {
			BeneficiaryBean beneficiaryBean = disbursementBusinessHelper
					.getCreateBeneficiaryDetails(data.getApplicationKey(), header);
			if(null!=beneficiaryBean.getAcHolderName())
			beneficiaryBean.setAcHolderName(beneficiaryBean.getAcHolderName().trim());
			beneficiaryBean
					.setCif(fetchCifId(Long.valueOf(data.getApplicationKey()), Long.valueOf(data.getApplicantKey())));
			BranchDetails branchMaster = disbursementMapperUtil.fetchBrachDetails(beneficiaryBean.getBranchKey(),
					header);
			beneficiaryBean.setIfsc(branchMaster.getBranchIfscCode());
			beneficiaryBean.setMicr(branchMaster.getBranchMicrCode());
			beneficiaryBean.setBranchKey(null);
			return beneficiaryBean;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"getUnclassifiedLimit : Unable to get getBeneficiaryDetails", e);
			throw new DisbursementServiceException();
		}
	}

	
	public String fetchCifId(Long applicationKey, Long applicantKey) {
		List<DisbursementMongoObject> disbursementMongoObjectList = mongoDbRepo.fetchObjectByKey(
				disbursementMongoTemplate, "applicantKey", applicantKey, DisbursementConstants.SERVICE_RECORD);
		DisbursementMongoObject result = disbursementMongoObjectList.stream()
				.filter(x -> x.getApplicationKey().equals(applicationKey)).findFirst().orElse(null);
		return result.getCif();
	}

	public HttpHeaders generateHeaders(GlobalDataBean data) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("authtoken", data.getHeaders().get("authtoken"));
		headers.add("cmptcorrid", data.getHeaders().get("cmptcorrid"));
		headers.add("guardtoken", data.getHeaders().get("guardtoken"));
		return headers;
	}

	public <T> String mapToJson(T object) {
		Gson gson = new Gson();
		return gson.toJson(object);
	}

}