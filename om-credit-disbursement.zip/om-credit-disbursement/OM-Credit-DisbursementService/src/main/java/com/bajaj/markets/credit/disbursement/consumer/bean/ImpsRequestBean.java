package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.io.Serializable;

public class ImpsRequestBean implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String beneAccNo;
	private String beneIFSC;
	private String applicantId;
	private String applicationId;
	private String accountHolderName;
	private String productCode;
	private String applicationBankDetKey;
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getBeneAccNo() {
		return beneAccNo;
	}
	public void setBeneAccNo(String beneAccNo) {
		this.beneAccNo = beneAccNo;
	}
	public String getBeneIFSC() {
		return beneIFSC;
	}
	public void setBeneIFSC(String beneIFSC) {
		this.beneIFSC = beneIFSC;
	}
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	
	/**
	 * @return the accountHolderName
	 */
	public String getAccountHolderName() {
		return accountHolderName;
	}
	/**
	 * @param accountHolderName the accountHolderName to set
	 */
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	
	public String getApplicationBankDetKey() {
		return applicationBankDetKey;
	}
	public void setApplicationBankDetKey(String applicationBankDetKey) {
		this.applicationBankDetKey = applicationBankDetKey;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ImpsRequestMetadata [beneAccNo=" + beneAccNo + ", beneIFSC=" + beneIFSC + ", applicantId=" + applicantId
				+ ", applicationId=" + applicationId + ", accountHolderName=" + accountHolderName + ", productCode=" + productCode +  "]";
	}
	

}
