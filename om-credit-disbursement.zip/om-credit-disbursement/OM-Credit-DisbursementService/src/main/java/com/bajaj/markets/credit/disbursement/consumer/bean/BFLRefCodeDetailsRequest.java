package com.bajaj.markets.credit.disbursement.consumer.bean;

public class BFLRefCodeDetailsRequest {

	private String systemCode;
	private String omLable;
	private String omCode;

	public String getSystemCode() {
		return systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	public String getOmLable() {
		return omLable;
	}

	public void setOmLable(String omLable) {
		this.omLable = omLable;
	}

	public String getOmCode() {
		return omCode;
	}

	public void setOmCode(String omCode) {
		this.omCode = omCode;
	}

}
