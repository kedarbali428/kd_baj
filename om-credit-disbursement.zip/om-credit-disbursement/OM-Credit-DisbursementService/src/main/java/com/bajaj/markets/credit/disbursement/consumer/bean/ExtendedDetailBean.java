package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class ExtendedDetailBean {
	private List<ExtendedFieldBean> extendedFields;

	public void setExtendedFields(List<ExtendedFieldBean> extendedFields) {
		this.extendedFields = extendedFields;
	}

}
