package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class BflEmandatePaymentModeBean implements Serializable{

	private static final long serialVersionUID = 1L;

	
	private Long emandatepaymentmodekey;
	
	private String emandatepartner;
	
	private String emandatemode;
	
	private String emandatesubrepaymode;
	
	private Integer isactive;

	public Long getEmandatepaymentmodekey() {
		return emandatepaymentmodekey;
	}

	public void setEmandatepaymentmodekey(Long emandatepaymentmodekey) {
		this.emandatepaymentmodekey = emandatepaymentmodekey;
	}

	public String getEmandatepartner() {
		return emandatepartner;
	}

	public void setEmandatepartner(String emandatepartner) {
		this.emandatepartner = emandatepartner;
	}

	public String getEmandatemode() {
		return emandatemode;
	}

	public void setEmandatemode(String emandatemode) {
		this.emandatemode = emandatemode;
	}

	public String getEmandatesubrepaymode() {
		return emandatesubrepaymode;
	}

	public void setEmandatesubrepaymode(String emandatesubrepaymode) {
		this.emandatesubrepaymode = emandatesubrepaymode;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	
}
