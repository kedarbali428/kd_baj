package com.bajaj.markets.credit.disbursement.consumer.bean;

public class BranchDetails {

	private Long branchKey;
	private Long bankMasterKey;
	private String branchCode;
	private String branchIfscCode;
	private String branchMicrCode;
	private String branchName;
	private Long cityKey;
	private Long pincodeKey;
	private Long stateKey;
	private Long countryKey;
	private String bankName;
	
	public Long getBranchKey() {
		return branchKey;
	}
	public void setBranchKey(Long branchKey) {
		this.branchKey = branchKey;
	}
	public Long getBankMasterKey() {
		return bankMasterKey;
	}
	public void setBankMasterKey(Long bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getBranchIfscCode() {
		return branchIfscCode;
	}
	public void setBranchIfscCode(String branchIfscCode) {
		this.branchIfscCode = branchIfscCode;
	}
	public String getBranchMicrCode() {
		return branchMicrCode;
	}
	public void setBranchMicrCode(String branchMicrCode) {
		this.branchMicrCode = branchMicrCode;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public Long getCityKey() {
		return cityKey;
	}
	public void setCityKey(Long cityKey) {
		this.cityKey = cityKey;
	}
	public Long getPincodeKey() {
		return pincodeKey;
	}
	public void setPincodeKey(Long pincodeKey) {
		this.pincodeKey = pincodeKey;
	}
	public Long getStateKey() {
		return stateKey;
	}
	public void setStateKey(Long stateKey) {
		this.stateKey = stateKey;
	}
	public Long getCountryKey() {
		return countryKey;
	}
	public void setCountryKey(Long countryKey) {
		this.countryKey = countryKey;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
}
