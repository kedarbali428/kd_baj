package com.bajaj.markets.credit.disbursement.consumer.bean;

public class CityMaster {

	private String pincodeKey;
	private String citycode;
	private String cityname;

	public String getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(String pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public String getCitycode() {
		return citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	
	
	
}
