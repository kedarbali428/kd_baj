package com.bajaj.markets.credit.disbursement.consumer.exception;

import org.springframework.http.HttpStatus;

import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;


public class DisbursementServiceException extends RuntimeException{

private static final long serialVersionUID = 1L;
	
	private HttpStatus code;
	private ErrorBean errorBean;
	private Object payload;
	
	public DisbursementServiceException() {
		super();
	}
	
	public DisbursementServiceException(HttpStatus code, ErrorBean errorBean) {
		super();
		this.code = code;
		this.errorBean = errorBean;
	}
	
	public DisbursementServiceException(HttpStatus code, Object payload) {
		super();
		this.code = code;
		this.payload = payload;
	}

	public DisbursementServiceException(Throwable cause){
		super(cause);
	}

	public HttpStatus getCode() {
		return code;
	}

	public ErrorBean getErrorBean() {
		return errorBean;
	}
}
