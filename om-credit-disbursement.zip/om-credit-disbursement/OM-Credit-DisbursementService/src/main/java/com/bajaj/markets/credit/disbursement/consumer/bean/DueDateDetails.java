package com.bajaj.markets.credit.disbursement.consumer.bean;

public class DueDateDetails {
	private Integer dueDate;
	private String firstDueDate;

	public Integer getDueDate() {
		return dueDate;
	}

	public void setDueDate(Integer dueDate) {
		this.dueDate = dueDate;
	}

	public String getFirstDueDate() {
		return firstDueDate;
	}

	public void setFirstDueDate(String firstDueDate) {
		this.firstDueDate = firstDueDate;
	}

}
