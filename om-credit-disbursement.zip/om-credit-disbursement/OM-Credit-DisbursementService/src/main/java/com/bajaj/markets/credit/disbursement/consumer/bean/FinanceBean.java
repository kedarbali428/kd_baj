package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class FinanceBean {
	private String finReference;
	
	private String finType;
	
	private String product;
	
	private String finCcy;
	
	private Number finAmount;
	
	private Number finAssetValue;
	
	private Number numberOfTerms;
	
	private Number loanTenor;
	
	private String maturityDate;
	
	private Number firstEmiAmount;
	
	private Number nextRepayAmount;
	
	private Number paidTotal;
	
	private Number paidPri;
	
	private Number paidPft;
	
	private Number outstandingTotal;
	
	private Number outstandingPri;
	
	private Number outstandingPft;
	
	private Number futureInst;
	
	private String finStatus;
	
	private String disbStatus;
	
	private String finStartDate;
	
	private Number applicationNo;
	
	private List<CoApplicant> coApplicants;

	public String getFinReference() {
		return finReference;
	}

	public void setFinReference(String finReference) {
		this.finReference = finReference;
	}

	public String getFinType() {
		return finType;
	}

	public void setFinType(String finType) {
		this.finType = finType;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getFinCcy() {
		return finCcy;
	}

	public void setFinCcy(String finCcy) {
		this.finCcy = finCcy;
	}

	public Number getFinAmount() {
		return finAmount;
	}

	public void setFinAmount(Number finAmount) {
		this.finAmount = finAmount;
	}

	public Number getFinAssetValue() {
		return finAssetValue;
	}

	public void setFinAssetValue(Number finAssetValue) {
		this.finAssetValue = finAssetValue;
	}

	public Number getNumberOfTerms() {
		return numberOfTerms;
	}

	public void setNumberOfTerms(Number numberOfTerms) {
		this.numberOfTerms = numberOfTerms;
	}

	public Number getLoanTenor() {
		return loanTenor;
	}

	public void setLoanTenor(Number loanTenor) {
		this.loanTenor = loanTenor;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public Number getFirstEmiAmount() {
		return firstEmiAmount;
	}

	public void setFirstEmiAmount(Number firstEmiAmount) {
		this.firstEmiAmount = firstEmiAmount;
	}

	public Number getNextRepayAmount() {
		return nextRepayAmount;
	}

	public void setNextRepayAmount(Number nextRepayAmount) {
		this.nextRepayAmount = nextRepayAmount;
	}

	public Number getPaidTotal() {
		return paidTotal;
	}

	public void setPaidTotal(Number paidTotal) {
		this.paidTotal = paidTotal;
	}

	public Number getPaidPri() {
		return paidPri;
	}

	public void setPaidPri(Number paidPri) {
		this.paidPri = paidPri;
	}

	public Number getPaidPft() {
		return paidPft;
	}

	public void setPaidPft(Number paidPft) {
		this.paidPft = paidPft;
	}

	public Number getOutstandingTotal() {
		return outstandingTotal;
	}

	public void setOutstandingTotal(Number outstandingTotal) {
		this.outstandingTotal = outstandingTotal;
	}

	public Number getOutstandingPri() {
		return outstandingPri;
	}

	public void setOutstandingPri(Number outstandingPri) {
		this.outstandingPri = outstandingPri;
	}

	public Number getOutstandingPft() {
		return outstandingPft;
	}

	public void setOutstandingPft(Number outstandingPft) {
		this.outstandingPft = outstandingPft;
	}

	public Number getFutureInst() {
		return futureInst;
	}

	public void setFutureInst(Number futureInst) {
		this.futureInst = futureInst;
	}

	public String getFinStatus() {
		return finStatus;
	}

	public void setFinStatus(String finStatus) {
		this.finStatus = finStatus;
	}

	public String getDisbStatus() {
		return disbStatus;
	}

	public void setDisbStatus(String disbStatus) {
		this.disbStatus = disbStatus;
	}

	public String getFinStartDate() {
		return finStartDate;
	}

	public void setFinStartDate(String finStartDate) {
		this.finStartDate = finStartDate;
	}

	public Number getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(Number applicationNo) {
		this.applicationNo = applicationNo;
	}

	public List<CoApplicant> getCoApplicants() {
		return coApplicants;
	}

	public void setCoApplicants(List<CoApplicant> coApplicants) {
		this.coApplicants = coApplicants;
	}

	
}
