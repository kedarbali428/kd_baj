package com.bajaj.markets.credit.disbursement.consumer.bean;

public class CoapplicantBean {
	private String cif;

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}
	
}
