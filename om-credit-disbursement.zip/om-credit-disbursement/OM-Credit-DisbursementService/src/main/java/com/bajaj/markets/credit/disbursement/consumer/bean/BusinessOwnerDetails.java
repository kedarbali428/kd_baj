package com.bajaj.markets.credit.disbursement.consumer.bean;


public class BusinessOwnerDetails {

	private Reference natureOfBusiness;

	private Reference subindumastkey;

	private String netMonthlyIncome;
	
	private Reference businessType;
	
	private String businessVintage;
	
	private String businessPan;

	private String gstNumber;
	
	private String cif;
	
	private String businessName;

	public Reference getNatureOfBusiness() {
		return natureOfBusiness;
	}

	public void setNatureOfBusiness(Reference natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}

	public Reference getSubindumastkey() {
		return subindumastkey;
	}

	public void setSubindumastkey(Reference subindumastkey) {
		this.subindumastkey = subindumastkey;
	}

	public String getNetMonthlyIncome() {
		return netMonthlyIncome;
	}

	public void setNetMonthlyIncome(String netMonthlyIncome) {
		this.netMonthlyIncome = netMonthlyIncome;
	}

	public Reference getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Reference businessType) {
		this.businessType = businessType;
	}

	public String getBusinessVintage() {
		return businessVintage;
	}

	public void setBusinessVintage(String businessVintage) {
		this.businessVintage = businessVintage;
	}

	public String getBusinessPan() {
		return businessPan;
	}

	public void setBusinessPan(String businessPan) {
		this.businessPan = businessPan;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	
}
