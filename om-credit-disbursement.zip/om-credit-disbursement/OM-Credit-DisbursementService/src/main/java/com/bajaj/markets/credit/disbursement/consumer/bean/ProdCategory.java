package com.bajaj.markets.credit.disbursement.consumer.bean;

public class ProdCategory {
	private String prodCatCode;

	private String prodCatDesc;

	public String getProdCatCode() {
		return prodCatCode;
	}

	public void setProdCatCode(String prodCatCode) {
		this.prodCatCode = prodCatCode;
	}

	public String getProdCatDesc() {
		return prodCatDesc;
	}

	public void setProdCatDesc(String prodCatDesc) {
		this.prodCatDesc = prodCatDesc;
	}

}
