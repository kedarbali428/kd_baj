package com.bajaj.markets.credit.disbursement.consumer.service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.BOLDisbursementProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.BOLErrorHandlingProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.BflFundedDisbursementProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.PROLDisbursementProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.PROLErrorHandlingProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.SOLDisbursementProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.SOLErrorHandlingProcessor;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.bajaj.markets.om.consumer.model.SubEventMessage;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author pranoti.pandole
 *
 */

@Component
public class DisbursementSQSListener {

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	@Qualifier("SOLDisbursementProcessor")
	SOLDisbursementProcessor solDisbursementProcessor;

	@Autowired
	@Qualifier("BOLDisbursementProcessor")
	BOLDisbursementProcessor bolDisbursementProcessor;

	@Autowired
	@Qualifier("SOLErrorHandlingProcessor")
	SOLErrorHandlingProcessor solErrorHandlingProcessor;

	@Autowired
	@Qualifier("BOLErrorHandlingProcessor")
	BOLErrorHandlingProcessor bolErrorHandlingProcessor;

	@Autowired
	@Qualifier("BflFundedDisbursementProcessor")
	BflFundedDisbursementProcessor fundedProcessor;

	@Value("${solloantypes}")
	private String solloantypes;

	@Value("${bolloantypes}")
	private String bolloantypes;

	@Value("${prolloantypes}")
	private String prolloantypes;

	@Autowired
	@Qualifier("PROLDisbursementProcessor")
	PROLDisbursementProcessor prolDisbursementProcessor;

	@Autowired
	@Qualifier("PROLErrorHandlingProcessor")
	PROLErrorHandlingProcessor prolErrorHandlingProcessor;

	private static final String CLASS_NAME = DisbursementSQSListener.class.getName();

	@JmsListener(destination = "${aws.listener.sqs.disbursement.queuename}", containerFactory = "getJmsListenerFactory")
	public void onMessage(Message message) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside onMessage DisbursementSQSListener ,message: " + message);

		if (message instanceof TextMessage) {
			try {
				String strMsg = ((TextMessage) message).getText();
				JSONObject obj = new JSONObject(strMsg);
				String messageDetail = obj.getString("Message");
				ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
						false);
				SubEventMessage eventMessage = mapper.readValue(messageDetail, SubEventMessage.class);
				setCorrelationID(eventMessage.getHeaders());
				if (eventMessage.getEventType().equalsIgnoreCase(DisbursementConstants.INITIATE_DISBURSEMENT)) {
					message.acknowledge();
					String payloadjson = eventMessage.getPayload().toString().replace("=", ":");
					JSONObject obj1 = new JSONObject(payloadjson);
					String eventMsg = obj1.toString();
					DisbursementEventRequestBean request = mapper.readValue(eventMsg,
							DisbursementEventRequestBean.class);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Inside onMessage DisbursementSQSListener ,productcode: " + request.getProductCode()
									+ " ApplicationId: " + request.getApplicationId());
					request.setHeaders(eventMessage.getHeaders());
					if (fetchSolFlag(request.getProductCode())) {
						solDisbursementProcessor.processDisbursement(request);
					} else if (fetchBolFlag(request.getProductCode())) {
						bolDisbursementProcessor.processDisbursement(request);
					} else if (fetchProlFlag(request.getProductCode())) {
						prolDisbursementProcessor.processDisbursement(request);
					}
				} else if (eventMessage.getEventType().equalsIgnoreCase(DisbursementConstants.DISBURSEMENT_FAILED)) {
					message.acknowledge();
					String payloadjson = eventMessage.getPayload().toString().replace("=", ":");
					JSONObject obj1 = new JSONObject(payloadjson);
					String eventMsg = obj1.toString();
					DisbursementEventRequestBean request = mapper.readValue(eventMsg,
							DisbursementEventRequestBean.class);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Inside DISBURSEMENT_FAILED onMessage DisbursementSQSListener ,productcode: "
									+ request.getProductCode() + " ApplicationId: " + request.getApplicationId());
					request.setHeaders(eventMessage.getHeaders());
					if (fetchSolFlag(request.getProductCode())) {
						solErrorHandlingProcessor.processSOLDisbursementErrors(request);
					} else if (fetchBolFlag(request.getProductCode())) {
						bolErrorHandlingProcessor.processBOLDisbursementErrors(request);
					} else if (fetchProlFlag(request.getProductCode())) {
						prolErrorHandlingProcessor.processPROLDisbursementErrors(request);
					}
				} else if (eventMessage.getEventType()
						.equalsIgnoreCase(DisbursementConstants.BFL_INITIATE_DISBURSEMENT)) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Inside onMessage DisbursementSQSListener ,payload before: " + eventMessage.toString());
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Inside onMessage DisbursementSQSListener ,payload before: " + eventMessage.getPayload());
					String payloadjson = mapper.writeValueAsString(eventMessage.getPayload());
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Inside onMessage DisbursementSQSListener ,payload: " + payloadjson);
					FundedDisbursementEventRequestBean request = mapper.readValue(payloadjson,
							FundedDisbursementEventRequestBean.class);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Inside onMessage FundedDisbursementSQSListener ,productcode: "
									+ request.getApplicationDetails().getL4ProductCode() + " ApplicationId: "
									+ request.getApplicationId());
					request.setApplicationId(request.getApplicationDetails().getApplicationNo());
					message.acknowledge();
					fundedProcessor.processDisbursement(request);
				}
			} catch (DisbursementServiceException exception) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Inside onMessage method forDisbursementSQSListener,Exception occurred: ", exception);
			} catch (Exception exception) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Inside onMessage method for DisbursementSQSListener ,exception occurred: ", exception);
			}
		}
	}

	private void setCorrelationID(Map<String, String> headers) {
		logger.setCorrelationID(null!=headers && null!=headers.get("cmptcorrid") ? headers.get("cmptcorrid") : null);
	}

	public boolean fetchSolFlag(String productType) {
		boolean solFlag = false;
		List<String> solList = Arrays.asList(solloantypes.split(","));
		boolean solMatchFound = solList.stream().anyMatch(productType::equals);
		if (solMatchFound) {
			solFlag = true;
		}
		return solFlag;
	}

	public boolean fetchBolFlag(String productType) {
		boolean bolFlag = false;
		List<String> bolList = Arrays.asList(bolloantypes.split(","));
		boolean bolMatchFound = bolList.stream().anyMatch(productType::equals);
		if (bolMatchFound) {
			bolFlag = true;
		}
		return bolFlag;
	}

	public boolean fetchProlFlag(String productType) {
		List<String> prolList = Arrays.asList(prolloantypes.split(","));
		return prolList.stream().anyMatch(productType::equals);
	}

}
