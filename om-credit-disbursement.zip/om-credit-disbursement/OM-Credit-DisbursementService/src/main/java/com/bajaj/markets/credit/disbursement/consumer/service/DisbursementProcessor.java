package com.bajaj.markets.credit.disbursement.consumer.service;

import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;

/**
 * @author pranoti.pandole
 *
 */
public interface DisbursementProcessor {
	
	public Boolean prechecks(GlobalDataBean data);
	public void processDisbursement(DisbursementEventRequestBean request);

}
