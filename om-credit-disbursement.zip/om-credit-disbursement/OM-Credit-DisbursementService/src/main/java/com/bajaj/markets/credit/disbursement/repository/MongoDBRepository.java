package com.bajaj.markets.credit.disbursement.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.mongodb.client.result.UpdateResult;

@Component
public class MongoDBRepository {

	public Object insertDocumentDB(MongoOperations mongoTemplate, Object obj, String collectionName) {
		try {
			return mongoTemplate.save(obj, collectionName);
		} catch (Exception ex) {
			throw new DisbursementServiceException(HttpStatus.EXPECTATION_FAILED,
					new ErrorBean("CAS-1023", "Failed to update/save requested data"));
		}
	}

	public List<DisbursementMongoObject> fetchObjectByKey(MongoOperations mongoTemplate, String key, Object value,
			String collectionName) {
		Query query = new Query();
		query.addCriteria(Criteria.where(key).is(value));
		try {
			return mongoTemplate.find(query, DisbursementMongoObject.class, collectionName);
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.EXPECTATION_FAILED,
					new ErrorBean("CAS-1023", "Failed to get requested data"));
		}
	}

	public List<FundedDisbursementMongoObject> fetchFundedObjectByKey(MongoOperations mongoTemplate, String key,
			Object value, String collectionName) {
		Query query = new Query();
		query.addCriteria(Criteria.where(key).is(value));
		try {
			return mongoTemplate.find(query, FundedDisbursementMongoObject.class, collectionName);
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.EXPECTATION_FAILED,
					new ErrorBean("CAS-1023", "Failed to get requested data"));
		}
	}

	public List<FundedDisbursementEventRequestMongoObject> fetchFundedEventRequestByKey(MongoOperations mongoTemplate,
			String key, Object value, String collectionName) {
		Query query = new Query();
		query.addCriteria(Criteria.where(key).is(value));
		try {
			return mongoTemplate.find(query, FundedDisbursementEventRequestMongoObject.class, collectionName);
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.EXPECTATION_FAILED,
					new ErrorBean("CAS-1023", "Failed to get requested data"));
		}
	}

	public UpdateResult updateFieldByApplicationKeyAndApplicantKey(MongoOperations mongoTemplate, Long applicationKey,
			Long applicantKey, String fieldName, String value, String collectionName) {
		Query query = new Query();
		List<Criteria> criteriaList = new ArrayList<>();
		Criteria c1 = new Criteria();
		c1.and("applicantKey").is(applicantKey);
		criteriaList.add(c1);
		Criteria c2 = new Criteria();
		c2.and("applicationKey").is(applicationKey);
		criteriaList.add(c2);
		Criteria criteria = new Criteria();
		query.addCriteria(criteria.andOperator(criteriaList.toArray(new Criteria[criteriaList.size()])));
		Update update = new Update();
		update.set(fieldName, value);
		try {
			return mongoTemplate.upsert(query, update, collectionName);
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.EXPECTATION_FAILED,
					new ErrorBean("CAS-1023", "Failed to update requested data"));
		}
	}

	public UpdateResult updateFieldByApplicationKeyAndQuote(MongoOperations mongoTemplate, Long applicationKey,
			String quoteNumber, String fieldName, String value, String collectionName) {
		Query query = new Query();
		List<Criteria> criteriaList = new ArrayList<>();
		Criteria c1 = new Criteria();
		c1.and("quoteNumber").is(quoteNumber);
		criteriaList.add(c1);
		Criteria c2 = new Criteria();
		c2.and("applicationKey").is(applicationKey);
		criteriaList.add(c2);
		Criteria criteria = new Criteria();
		query.addCriteria(criteria.andOperator(criteriaList.toArray(new Criteria[criteriaList.size()])));
		Update update = new Update();
		update.set(fieldName, value);
		try {
			return mongoTemplate.upsert(query, update, collectionName);
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.EXPECTATION_FAILED,
					new ErrorBean("CAS-1023", "Failed to update requested data"));
		}

	}
}