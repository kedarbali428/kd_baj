package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.io.Serializable;

public class ProductTypeBean implements Serializable {
	
	private Long prodtypekey;
	
    private Long prodkey;
    
    private String prodtypecode;
    
    private String prodtypedesc;
    
    private String displayproductname;
    
    private String displayloantypename;

	public Long getProdtypekey() {
		return prodtypekey;
	}

	public void setProdtypekey(Long prodtypekey) {
		this.prodtypekey = prodtypekey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getProdtypecode() {
		return prodtypecode;
	}

	public void setProdtypecode(String prodtypecode) {
		this.prodtypecode = prodtypecode;
	}

	public String getProdtypedesc() {
		return prodtypedesc;
	}

	public void setProdtypedesc(String prodtypedesc) {
		this.prodtypedesc = prodtypedesc;
	}

	public String getDisplayproductname() {
		return displayproductname;
	}

	public void setDisplayproductname(String displayproductname) {
		this.displayproductname = displayproductname;
	}

	public String getDisplayloantypename() {
		return displayloantypename;
	}

	public void setDisplayloantypename(String displayloantypename) {
		this.displayloantypename = displayloantypename;
	}
}
