package com.bajaj.markets.credit.disbursement.consumer.bean;

public class OccupationAttribute {
	private Reference ocupationType;

	private SalariedDetail salariedDetail;

	private BusinessOwnerDetails businessOwnerDetails;

	private OccupationTypeVerification occupationTypeVerification;

	private ProfessionDetail profession;

	public Reference getOcupationType() {
		return ocupationType;
	}

	public void setOcupationType(Reference ocupationType) {
		this.ocupationType = ocupationType;
	}

	public BusinessOwnerDetails getBusinessOwnerDetails() {
		return businessOwnerDetails;
	}

	public void setBusinessOwnerDetails(BusinessOwnerDetails businessOwnerDetails) {
		this.businessOwnerDetails = businessOwnerDetails;
	}

	public OccupationTypeVerification getOccupationTypeVerification() {
		return occupationTypeVerification;
	}

	public void setOccupationTypeVerification(OccupationTypeVerification occupationTypeVerification) {
		this.occupationTypeVerification = occupationTypeVerification;
	}

	public ProfessionDetail getProfession() {
		return profession;
	}

	public void setProfession(ProfessionDetail profession) {
		this.profession = profession;
	}

	public SalariedDetail getSalariedDetail() {
		return salariedDetail;
	}

	public void setSalariedDetail(SalariedDetail salariedDetail) {
		this.salariedDetail = salariedDetail;
	}

}
