package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class CreateLoanResponseBean {

	private String finReference;
	private FinanceScheduleBean financeSchedule;
	private List<CollateralBean> collaterals;
	private Status status;
	private ReturnStatusBean returnStatus;
	
	public ReturnStatusBean getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(ReturnStatusBean returnStatus) {
		this.returnStatus = returnStatus;
	}
	public String getFinReference() {
		return finReference;
	}
	public void setFinReference(String finReference) {
		this.finReference = finReference;
	}
	public FinanceScheduleBean getFinanceSchedule() {
		return financeSchedule;
	}
	public void setFinanceSchedule(FinanceScheduleBean financeSchedule) {
		this.financeSchedule = financeSchedule;
	}
	public List<CollateralBean> getCollaterals() {
		return collaterals;
	}
	public void setCollaterals(List<CollateralBean> collaterals) {
		this.collaterals = collaterals;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	
}
