package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class AppFinEligibilityBean {
	private BigDecimal eligibilityamount;

	public BigDecimal getEligibilityamount() {
		return eligibilityamount;
	}

	public void setEligibilityamount(BigDecimal eligibilityamount) {
		this.eligibilityamount = eligibilityamount;
	} 
	
	
}
