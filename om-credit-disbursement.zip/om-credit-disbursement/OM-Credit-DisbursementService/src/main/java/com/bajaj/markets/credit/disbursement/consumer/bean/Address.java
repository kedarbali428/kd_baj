package com.bajaj.markets.credit.disbursement.consumer.bean;

public class Address {

	private String addressKey;
	private String addressTypeKey;
	private String addressLine1;
	private String addressLine2;
	private String pincode;
	private String pincodeKey;
	private String cityKey;
	private String stateKey;
	private String countryKey;
	private String localitykey;
	public String getAddressKey() {
		return addressKey;
	}

	public void setAddressKey(String addressKey) {
		this.addressKey = addressKey;
	}

	public String getAddressTypeKey() {
		return addressTypeKey;
	}

	public void setAddressTypeKey(String addressTypeKey) {
		this.addressTypeKey = addressTypeKey;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(String pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public String getCityKey() {
		return cityKey;
	}

	public void setCityKey(String cityKey) {
		this.cityKey = cityKey;
	}

	public String getStateKey() {
		return stateKey;
	}

	public void setStateKey(String stateKey) {
		this.stateKey = stateKey;
	}

	public String getCountryKey() {
		return countryKey;
	}

	public void setCountryKey(String countryKey) {
		this.countryKey = countryKey;
	}

	public String getLocalitykey() {
		return localitykey;
	}

	public void setLocalitykey(String localitykey) {
		this.localitykey = localitykey;
	}

}
