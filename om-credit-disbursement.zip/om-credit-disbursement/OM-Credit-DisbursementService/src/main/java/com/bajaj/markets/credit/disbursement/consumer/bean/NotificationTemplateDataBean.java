package com.bajaj.markets.credit.disbursement.consumer.bean;

public class NotificationTemplateDataBean {

	private String applicationId;
	private String customerName;
	private String productName;
	private String lanNumber;
	private String amount;
	private String roi;
	private String tenor;
	private boolean isHybridFlexi;
	private String firstEmiAmt;
	private String isTenure;
	private String isEmiAmt;
	private String droplineTenure;
	private String dropLineEmiAmt;
	private String emiCycleDay;
	private String firstEMIdt;
	private String phoneNumber;
	private String recipientEmailId;
	
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getLanNumber() {
		return lanNumber;
	}
	public void setLanNumber(String lanNumber) {
		this.lanNumber = lanNumber;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getRoi() {
		return roi;
	}
	public void setRoi(String roi) {
		this.roi = roi;
	}
	public String getTenor() {
		return tenor;
	}
	public void setTenor(String tenor) {
		this.tenor = tenor;
	}
	public boolean isHybridFlexi() {
		return isHybridFlexi;
	}
	public void setHybridFlexi(boolean isHybridFlexi) {
		this.isHybridFlexi = isHybridFlexi;
	}
	public String getFirstEmiAmt() {
		return firstEmiAmt;
	}
	public void setFirstEmiAmt(String firstEmiAmt) {
		this.firstEmiAmt = firstEmiAmt;
	}
	public String getIsTenure() {
		return isTenure;
	}
	public void setIsTenure(String isTenure) {
		this.isTenure = isTenure;
	}
	public String getIsEmiAmt() {
		return isEmiAmt;
	}
	public void setIsEmiAmt(String isEmiAmt) {
		this.isEmiAmt = isEmiAmt;
	}
	public String getDroplineTenure() {
		return droplineTenure;
	}
	public void setDroplineTenure(String droplineTenure) {
		this.droplineTenure = droplineTenure;
	}
	public String getDropLineEmiAmt() {
		return dropLineEmiAmt;
	}
	public void setDropLineEmiAmt(String dropLineEmiAmt) {
		this.dropLineEmiAmt = dropLineEmiAmt;
	}
	public String getEmiCycleDay() {
		return emiCycleDay;
	}
	public void setEmiCycleDay(String emiCycleDay) {
		this.emiCycleDay = emiCycleDay;
	}
	public String getFirstEMIdt() {
		return firstEMIdt;
	}
	public void setFirstEMIdt(String firstEMIdt) {
		this.firstEMIdt = firstEMIdt;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getRecipientEmailId() {
		return recipientEmailId;
	}
	public void setRecipientEmailId(String recipientEmailId) {
		this.recipientEmailId = recipientEmailId;
	}
}
