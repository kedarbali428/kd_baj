package com.bajaj.markets.credit.disbursement.consumer.bean;


public class CoApplicant {

	private String cif;
	
	private String shortName;
	
	private boolean includeRepay;
	
	private String repayAccountId;

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public boolean isIncludeRepay() {
		return includeRepay;
	}

	public void setIncludeRepay(boolean includeRepay) {
		this.includeRepay = includeRepay;
	}

	public String getRepayAccountId() {
		return repayAccountId;
	}

	public void setRepayAccountId(String repayAccountId) {
		this.repayAccountId = repayAccountId;
	}

	@Override
	public String toString() {
		return "CoApplicant [cif=" + cif + ", shortName=" + shortName + ", includeRepay=" + includeRepay
				+ ", repayAccountId=" + repayAccountId + "]";
	}
	
	
}