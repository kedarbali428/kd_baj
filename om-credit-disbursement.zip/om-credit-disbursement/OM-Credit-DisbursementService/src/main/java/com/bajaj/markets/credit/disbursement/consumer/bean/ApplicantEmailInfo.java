package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class ApplicantEmailInfo {

	private Long emailtypekey;

	private String emailaddress;

	private BigDecimal emailpriority;

	public Long getEmailtypekey() {
		return emailtypekey;
	}

	public void setEmailtypekey(Long emailtypekey) {
		this.emailtypekey = emailtypekey;
	}

	public String getEmailaddress() {
		return emailaddress;
	}

	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}

	public BigDecimal getEmailpriority() {
		return emailpriority;
	}

	public void setEmailpriority(BigDecimal emailpriority) {
		this.emailpriority = emailpriority;
	}

}
