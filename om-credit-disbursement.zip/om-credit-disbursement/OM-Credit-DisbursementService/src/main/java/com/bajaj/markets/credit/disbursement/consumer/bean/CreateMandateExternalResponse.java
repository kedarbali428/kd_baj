package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;
import java.util.List;

public class CreateMandateExternalResponse {

	private Boolean useExisting;
	private BigDecimal mandateID;
	private Boolean openMandate;
	private String status;
	private Boolean active;
	private ReturnStatusBean returnStatus;
	private List<PennantMandateBean> mandates;

	public Boolean getUseExisting() {
		return useExisting;
	}

	public void setUseExisting(Boolean useExisting) {
		this.useExisting = useExisting;
	}

	public BigDecimal getMandateID() {
		return mandateID;
	}

	public void setMandateID(BigDecimal mandateID) {
		this.mandateID = mandateID;
	}

	public Boolean getOpenMandate() {
		return openMandate;
	}

	public void setOpenMandate(Boolean openMandate) {
		this.openMandate = openMandate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public ReturnStatusBean getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(ReturnStatusBean returnStatus) {
		this.returnStatus = returnStatus;
	}

	public List<PennantMandateBean> getMandates() {
		return mandates;
	}

	public void setMandates(List<PennantMandateBean> mandates) {
		this.mandates = mandates;
	}

}
