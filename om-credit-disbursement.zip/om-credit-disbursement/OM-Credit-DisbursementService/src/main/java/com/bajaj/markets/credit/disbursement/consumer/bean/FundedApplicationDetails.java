package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FundedApplicationDetails {

	private String applicationNo;
	private String quoteNumber;
	private String l2ProductKey;
	private String l2ProductCode;
	private String l3ProductKey;
	private String l3ProductCode;
	private String l4ProductKey;
	private String l4ProductCode;
	private String disbInitiatedBy;
	private String branch;
	private String netPremiumAmount;
	private String policyType;
	private String businessVertical;
	private String poType;
	private String paymentQuoteId;
	private FundedDetails fundingDetails;
	private List<NomineeDetails> nomineeDetails;
	private FundedMandateDetails mandateDetails;
	private PaymentDetails paymentDetails;

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getQuoteNumber() {
		return quoteNumber;
	}

	public void setQuoteNumber(String quoteNumber) {
		this.quoteNumber = quoteNumber;
	}

	public String getL2ProductKey() {
		return l2ProductKey;
	}

	public void setL2ProductKey(String l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}

	public String getL2ProductCode() {
		return l2ProductCode;
	}

	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}

	public String getL3ProductKey() {
		return l3ProductKey;
	}

	public void setL3ProductKey(String l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public String getL4ProductKey() {
		return l4ProductKey;
	}

	public void setL4ProductKey(String l4ProductKey) {
		this.l4ProductKey = l4ProductKey;
	}

	public String getL4ProductCode() {
		return l4ProductCode;
	}

	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}

	public String getDisbInitiatedBy() {
		return disbInitiatedBy;
	}

	public void setDisbInitiatedBy(String disbInitiatedBy) {
		this.disbInitiatedBy = disbInitiatedBy;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getNetPremiumAmount() {
		return netPremiumAmount;
	}

	public void setNetPremiumAmount(String netPremiumAmount) {
		this.netPremiumAmount = netPremiumAmount;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getBusinessVertical() {
		return businessVertical;
	}

	public void setBusinessVertical(String businessVertical) {
		this.businessVertical = businessVertical;
	}

	public String getPoType() {
		return poType;
	}

	public void setPoType(String poType) {
		this.poType = poType;
	}

	public String getPaymentQuoteId() {
		return paymentQuoteId;
	}

	public void setPaymentQuoteId(String paymentQuoteId) {
		this.paymentQuoteId = paymentQuoteId;
	}

	public FundedDetails getFundingDetails() {
		return fundingDetails;
	}

	public void setFundingDetails(FundedDetails fundingDetails) {
		this.fundingDetails = fundingDetails;
	}

	public List<NomineeDetails> getNomineeDetails() {
		return nomineeDetails;
	}

	public void setNomineeDetails(List<NomineeDetails> nomineeDetails) {
		this.nomineeDetails = nomineeDetails;
	}

	public FundedMandateDetails getMandateDetails() {
		return mandateDetails;
	}

	public void setMandateDetails(FundedMandateDetails mandateDetails) {
		this.mandateDetails = mandateDetails;
	}

	public PaymentDetails getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(PaymentDetails paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

}
