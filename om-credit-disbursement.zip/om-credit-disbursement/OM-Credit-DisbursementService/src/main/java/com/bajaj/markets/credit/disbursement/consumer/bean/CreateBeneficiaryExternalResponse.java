package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class CreateBeneficiaryExternalResponse {
	
	private BigDecimal beneficiaryID;
	private ReturnStatusBean returnStatus;
	
	public BigDecimal getBeneficiaryID() {
		return beneficiaryID;
	}
	public void setBeneficiaryID(BigDecimal beneficiaryID) {
		this.beneficiaryID = beneficiaryID;
	}
	public ReturnStatusBean getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(ReturnStatusBean returnStatus) {
		this.returnStatus = returnStatus;
	}
	
}
