package com.bajaj.markets.credit.disbursement.consumer.util;

public enum SmartechProductCodeEnum {

	Health_Insurance("Health Insurance", "HGI"), Two_Wheeler_Insurance("Two Wheeler Insurance", "TWGI"),
	Four_Wheeler_Insurance("Four Wheeler Insurance", "FWGI"), Business_Loan("BFLBOL", "BOL"),
	Salaried_Personal_Loan("BFLSOL","SOL"), Salaried_Personal_Loan_PLCS("BFLPLCS","SOL"),
	Salaried_Personal_Loan_FLDG("BFLSOLFLDG","SOL"),Business_Loan_PLCS("BFLPLCSSE","BOL"),
	PROFESSIONAL_LOAN_DOC("BFLDOL","PROL"), PROFESSIONAL_LOAN_CA("BFLCAL","PROL");

	private String productCategoryCode;
	private String productCodeValue;

	private SmartechProductCodeEnum(String productCategoryCode, String productCodeValue) {
		this.productCategoryCode = productCategoryCode;
		this.productCodeValue = productCodeValue;
	}

	public String getProductCategoryCode() {
		return productCategoryCode;
	}

	public String getProductCodeValue() {
		return productCodeValue;
	}

	public static String getValueOfProductCode(String productCategoryCode) {
		for (SmartechProductCodeEnum map : SmartechProductCodeEnum.values()) {
			if (map.productCategoryCode.equals(productCategoryCode)) {
				return map.productCodeValue;
			}
		}
		return null;
	}

}
