package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class ArcduedateOutput {
	private List<DueDateDetails> dueDateDetails;
	private List<NextDueDateDetails> nextDueDateDetails;

	public List<DueDateDetails> getDueDateDetails() {
		return dueDateDetails;
	}

	public void setDueDateDetails(List<DueDateDetails> dueDateDetails) {
		this.dueDateDetails = dueDateDetails;
	}

	public List<NextDueDateDetails> getNextDueDateDetails() {
		return nextDueDateDetails;
	}

	public void setNextDueDateDetails(List<NextDueDateDetails> nextDueDateDetails) {
		this.nextDueDateDetails = nextDueDateDetails;
	}

}
