package com.bajaj.markets.credit.disbursement.consumer.controller;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.disbursement.consumer.bean.PrincipalFileUploadRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.LoanProcessor;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;

@RestController
public class DmsDocumentPushController {
	@Autowired
	LoanProcessor loanProcessor;

	@Autowired
	private BFLLoggerUtil logger;

	@Autowired
	CustomDefaultHeaders customHeaders;

	private static final String CLASS_NAME = DmsDocumentPushController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.EMPLOYEE, Role.SYSTEM, Role.INTERNAL, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@CrossOrigin
	@PostMapping(path = "/v1/credit/applications/{applicationKey}/disbursement", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> initiateSuccessDisbEvent(
			@PathVariable("applicationKey") @NotBlank(message = "ApplicationKey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "ApplicationKey should be numeric & should not exceeds size") String applicationKey,
			@RequestBody PrincipalFileUploadRequestBean principalFileUploadRequestBean,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"In initiateSuccessDisbEvent method for ApplicationId" + applicationKey);
		principalFileUploadRequestBean.setApplicationId(applicationKey);
		Boolean eventRaiseflag = loanProcessor.initiateSuccessDisbEventForDmsDocPush(principalFileUploadRequestBean);
		JSONObject resp = new JSONObject();
		resp.put("isEventRaised", eventRaiseflag);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"END initiateSuccessDisbEvent method for  ApplicationId" + principalFileUploadRequestBean.getApplicationId() + ", Response : "+resp);
		return new ResponseEntity<>(resp, HttpStatus.OK);
	}

}