package com.bajaj.markets.credit.disbursement.consumer.bean;

public class PhoneMaster {

	private Long phonetypekey;

	private String phonetypecode;

	public Long getPhonetypekey() {
		return phonetypekey;
	}

	public void setPhonetypekey(Long phonetypekey) {
		this.phonetypekey = phonetypekey;
	}

	public String getPhonetypecode() {
		return phonetypecode;
	}

	public void setPhonetypecode(String phonetypecode) {
		this.phonetypecode = phonetypecode;
	}
	
	
}
