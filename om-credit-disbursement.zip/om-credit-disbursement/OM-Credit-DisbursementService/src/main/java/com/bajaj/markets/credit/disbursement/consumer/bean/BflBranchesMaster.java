package com.bajaj.markets.credit.disbursement.consumer.bean;

public class BflBranchesMaster {

	private Long bflbranchkey;

	private String bflbranchcode;

	private Long citykey;

	public Long getBflbranchkey() {
		return bflbranchkey;
	}

	public void setBflbranchkey(Long bflbranchkey) {
		this.bflbranchkey = bflbranchkey;
	}

	public String getBflbranchcode() {
		return bflbranchcode;
	}

	public void setBflbranchcode(String bflbranchcode) {
		this.bflbranchcode = bflbranchcode;
	}

	public Long getCitykey() {
		return citykey;
	}

	public void setCitykey(Long citykey) {
		this.citykey = citykey;
	}
	
}
