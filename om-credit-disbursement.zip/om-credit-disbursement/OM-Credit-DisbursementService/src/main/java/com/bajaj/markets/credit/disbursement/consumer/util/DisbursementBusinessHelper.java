package com.bajaj.markets.credit.disbursement.consumer.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.AppBundleDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.AppPlanDetCostBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.BeneficiaryBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.OccupationAttribute;
import com.bajaj.markets.credit.disbursement.consumer.bean.ProductTypeBean;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class DisbursementBusinessHelper {

	private RestTemplate restTemplate;

	@Autowired
	BFLLoggerUtil logger;
	
	@Value("${api.omcreditapplicationservice.beneficiary.GET.uri}")
	private String getBeneficiaryUrl;
	
	@Value("${api.omcreditapplicationservice.ProductTypeDetails.GET.uri}")
	private String getProductTypeDetailsUrl;
	

	@Value("${api.omcreditapplicationservice.bundleDetails.get.url}")
	private String bundleDetailsUrl;

	@Value("${api.omvasapplicationservice.costDetails.get.url}")
	private String vasDetailsUrl;
	
	@Value("${api.omcreditapplicationservice.application.userprofiles.occupation.GET.url}")
	private String occupationDetailsUrl;
	
	@PostConstruct
	public void init() {
		restTemplate = RestTemplateInstance.getRestTemplateInstance();
	}

	private static final String CLASS_NAME = DisbursementBusinessHelper.class.getCanonicalName();

	public RestTemplate getRestTemplate() {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start getRestTemplate");
		SimpleClientHttpRequestFactory simpleClientHttpRequestFactory = new SimpleClientHttpRequestFactory();
		restTemplate.setRequestFactory(simpleClientHttpRequestFactory);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "End getRestTemplate");
		return restTemplate;

	}

	public ResponseEntity<?> invokeRestEndpoint(HttpMethod httpMethod, String url, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start invokeRestEndpoint");
		headers.add("Content-Type", "application/json");
		HttpEntity<Object> entity = null;
		ResponseEntity<?> responseEntity = null;
		RestTemplate restTemplateInstance = null;
		try {
			entity = new HttpEntity<>(requestJson, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "RequestEndpoint : " + url);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request JSON : " + requestJson);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "params : " + params);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request Type : " + httpMethod);
			restTemplateInstance = getRestTemplate();
			if (params != null) {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType);
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Response from endpoint : " + responseEntity.toString());
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "End excuteRestCall");
			return new ResponseEntity<>(responseEntity.getBody(), responseEntity.getHeaders(),
					responseEntity.getStatusCode());
		} catch (RestClientException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					" RestClientException during " + url + " call for" + requestJson + e);
			throw new DisbursementServiceException(HttpStatus.EXPECTATION_FAILED,
					new ErrorBean("DISB-101", "Call for RestEndpoint failed"));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					" Exception during " + url + " call for" + requestJson + e);
			throw new DisbursementServiceException(HttpStatus.EXPECTATION_FAILED,
					new ErrorBean("DISB-101", "Call for RestEndpoint failed"));
		}
	}
	
	public BeneficiaryBean getCreateBeneficiaryDetails(String applicationId, HttpHeaders headers)
	{
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Inside getCreateBeneficiaryDetails - Start");
		BeneficiaryBean beneficiaryBean = null;
		HashMap<String, String> params = new HashMap<>();
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			params.put("applicationId", applicationId);
			ResponseEntity<?> cityResponseBeanResp = invokeRestEndpoint(HttpMethod.GET, getBeneficiaryUrl, String.class, params, null, headers);
			if (cityResponseBeanResp.getStatusCode().equals(HttpStatus.OK)) {
				beneficiaryBean = mapper.readValue(cityResponseBeanResp.getBody().toString(),
						new TypeReference<BeneficiaryBean>(){});
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in getCreateBeneficiaryDetails service call"
								+ cityResponseBeanResp.getBody().toString());
				throw new DisbursementServiceException();
			}
		
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"executeLmsRequest : Unable to fetch getCreateBeneficiaryDetails Service", e);
			throw new DisbursementServiceException();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Inside getEmandateRegistrationDetails - End. " + "Response String : " + beneficiaryBean.toString());
		
		return beneficiaryBean;
		
	}
	
	public ProductTypeBean getProductTypeDetails(String applicationkey, HttpHeaders headers)
	{
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Inside getProductTypeDetails - Start");
		ProductTypeBean productTypeBean = null;
		HashMap<String, String> params = new HashMap<>();
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			params.put("applicationkey", applicationkey);
			ResponseEntity<?> responseBean = invokeRestEndpoint(HttpMethod.GET, getProductTypeDetailsUrl, String.class, params, null, headers);
			if (null!= responseBean.getBody()) {
				productTypeBean = mapper.readValue(responseBean.getBody().toString(),
						new TypeReference<ProductTypeBean>(){});
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in getProductTypeDetails service call"
								+ responseBean.getBody().toString());
				throw new DisbursementServiceException();
			}
		
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"executeLmsRequest : Unable to fetch getProductTypeDetails Service", e);
			throw new DisbursementServiceException();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Inside getProductTypeDetails - End. " + "Response String : " + productTypeBean.toString());
		
		return productTypeBean;
		
	}
	
	@SuppressWarnings("unchecked")
	public AppBundleDetails fetchBundleDetails(String applicationkey, HttpHeaders headers) {
		AppBundleDetails appBundleDetails = new AppBundleDetails();
		List<AppBundleDetails> appBundleDetailsLst = new ArrayList<AppBundleDetails>();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationkey);
		
		try {
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) invokeRestEndpoint(HttpMethod.GET,
				bundleDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();
		
			AppBundleDetails[] applst = gson.fromJson(excuteRestCall.getBody().toString(), AppBundleDetails[].class);
			appBundleDetailsLst.addAll(Arrays.asList(applst));
			for (AppBundleDetails activeDetail : appBundleDetailsLst) {
				if (activeDetail.getBundleSelected()) {
					if (activeDetail.getSource().equalsIgnoreCase("EP")
							&& activeDetail.getStatus().equalsIgnoreCase("APPROVED")) {
						appBundleDetails = activeDetail;
						break;
					} else if (activeDetail.getSource().equalsIgnoreCase("JOURNEY")
							&& activeDetail.getStatus().equalsIgnoreCase("APPROVED")) {
						appBundleDetails = appBundleDetailsLst.get(0);
					}
				}
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchPricingDetails .");
		}

		return appBundleDetails;
	}

	@SuppressWarnings("unchecked")
	public List<AppPlanDetCostBean> fetchPricingDetails(Long applicationkey, HttpHeaders headers) {
		List<AppPlanDetCostBean> listAppPlanDetCostBean = new ArrayList<AppPlanDetCostBean>();
		List<AppPlanDetCostBean> latestEntries = new ArrayList<AppPlanDetCostBean>();
		Gson gson = new Gson();

		Map<String, String> param = new HashMap<>();
		param.put("applicationKey", applicationkey.toString());

		try {
			ResponseEntity<String> excutevasRestCall = (ResponseEntity<String>) invokeRestEndpoint(HttpMethod.GET,
					vasDetailsUrl, String.class, param, null, headers);
			AppPlanDetCostBean[] lst = gson.fromJson(excutevasRestCall.getBody().toString(),
					AppPlanDetCostBean[].class);
			listAppPlanDetCostBean.addAll(Arrays.asList(lst));
			for (AppPlanDetCostBean latestEntry : listAppPlanDetCostBean) {
				if (latestEntry.getSource().equalsIgnoreCase("EMPLOYEE_PORTAL")
						&& latestEntry.getStatus().equalsIgnoreCase("APPROVED")) {
					latestEntries.add(latestEntry);
					break;
				} else if (latestEntry.getSource().equalsIgnoreCase("JOURNEY")
						&& latestEntry.getStatus().equalsIgnoreCase("APPROVED")) {
					latestEntries.add(latestEntry);
					break;
				}

			}

		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchPricingDetails .");
		}

		return latestEntries;
	}
	
	@SuppressWarnings("unchecked")
	public OccupationAttribute getOccupationDetails(GlobalDataBean dataBean, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Start - getOccupationDetails for applicationKey: " + dataBean.getApplicationKey());
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		params.put("applicationid", dataBean.getApplicationKey());
		params.put("userattributekey", dataBean.getAppAtrKey());
		ResponseEntity<String> ocupationResponse = (ResponseEntity<String>) invokeRestEndpoint(HttpMethod.GET,
				occupationDetailsUrl, String.class, params, null, headers);
		OccupationAttribute occupation = gson.fromJson(ocupationResponse.getBody(), OccupationAttribute.class);
		if (Objects.nonNull(occupation)) {
			return occupation;
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End - getOccupationDetails for applicationKey: " + dataBean.getApplicationKey());
		return null;
	}
}
