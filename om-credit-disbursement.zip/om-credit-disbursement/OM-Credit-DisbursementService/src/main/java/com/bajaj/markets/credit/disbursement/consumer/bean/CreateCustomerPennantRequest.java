package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class CreateCustomerPennantRequest {

	private String categoryCode;
	private String defaultBranch;
	private String baseCurrency;
	private String primaryRelationOfficer;
	private PersonalInfo personalInfo;
	private boolean dedupReq;
	private List<AddressInfo> addresses;
	private List<PhoneInfo> phones;
	private List<EmailInfo> emails;
	private List<IncomeInfo> customersIncome;
	private List<DocumentInfo> documents;
	private List<CustomerBankInfo> customersBankInfo;
	
	public String getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	public String getDefaultBranch() {
		return defaultBranch;
	}
	public void setDefaultBranch(String defaultBranch) {
		this.defaultBranch = defaultBranch;
	}
	public String getBaseCurrency() {
		return baseCurrency;
	}
	public void setBaseCurrency(String baseCurrency) {
		this.baseCurrency = baseCurrency;
	}
	public String getPrimaryRelationOfficer() {
		return primaryRelationOfficer;
	}
	public void setPrimaryRelationOfficer(String primaryRelationOfficer) {
		this.primaryRelationOfficer = primaryRelationOfficer;
	}
	public PersonalInfo getPersonalInfo() {
		return personalInfo;
	}
	public void setPersonalInfo(PersonalInfo personalInfo) {
		this.personalInfo = personalInfo;
	}
	public boolean isDedupReq() {
		return dedupReq;
	}
	public void setDedupReq(boolean dedupReq) {
		this.dedupReq = dedupReq;
	}
	public List<AddressInfo> getAddresses() {
		return addresses;
	}
	public void setAddresses(List<AddressInfo> addresses) {
		this.addresses = addresses;
	}
	public List<PhoneInfo> getPhones() {
		return phones;
	}
	public void setPhones(List<PhoneInfo> phones) {
		this.phones = phones;
	}
	public List<EmailInfo> getEmails() {
		return emails;
	}
	public void setEmails(List<EmailInfo> emails) {
		this.emails = emails;
	}
	public List<IncomeInfo> getCustomersIncome() {
		return customersIncome;
	}
	public void setCustomersIncome(List<IncomeInfo> customersIncome) {
		this.customersIncome = customersIncome;
	}
	public List<DocumentInfo> getDocuments() {
		return documents;
	}
	public void setDocuments(List<DocumentInfo> documents) {
		this.documents = documents;
	}
	public List<CustomerBankInfo> getCustomersBankInfo() {
		return customersBankInfo;
	}
	public void setCustomersBankInfo(List<CustomerBankInfo> customersBankInfo) {
		this.customersBankInfo = customersBankInfo;
	}
	
}
