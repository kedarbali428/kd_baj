package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.Date;

public class Verification {

	private Boolean isVerified;
	private String verificationSource;
	private String verifiedFor;
	private Date verificationDate;
	private Long verificationReference;

	public Long getVerificationReference() {
		return verificationReference;
	}
	public void setVerificationReference(Long verificationReference) {
		this.verificationReference = verificationReference;
	}
	public Boolean getIsVerified() {
		return isVerified;
	}
	public void setIsVerified(Boolean isVerified) {
		this.isVerified = isVerified;
	}
	public String getVerificationSource() {
		return verificationSource;
	}
	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}
	public String getVerifiedFor() {
		return verifiedFor;
	}
	public void setVerifiedFor(String verifiedFor) {
		this.verifiedFor = verifiedFor;
	}
	public Date getVerificationDate() {
		return verificationDate;
	}
	public void setVerificationDate(Date verificationDate) {
		this.verificationDate = verificationDate;
	}
}
