package com.bajaj.markets.credit.disbursement.consumer.bean;

public class ApplicationBFLDocsRequestBean {

	private Long applicantId;
	private Long applicationId;
	private String docListType;

	public Long getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public String getDocListType() {
		return docListType;
	}

	public void setDocListType(String docListType) {
		this.docListType = docListType;
	}

}
