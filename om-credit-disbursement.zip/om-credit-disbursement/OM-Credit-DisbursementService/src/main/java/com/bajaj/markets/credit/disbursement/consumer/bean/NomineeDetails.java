package com.bajaj.markets.credit.disbursement.consumer.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NomineeDetails {

	private String nomName1;
	private String nomRel1;
	private String nomDob1;
	private String nomAddress1;
	private String nomMob1;

	public String getNomName1() {
		return nomName1;
	}

	public void setNomName1(String nomName1) {
		this.nomName1 = nomName1;
	}

	public String getNomRel1() {
		return nomRel1;
	}

	public void setNomRel1(String nomRel1) {
		this.nomRel1 = nomRel1;
	}

	public String getNomDob1() {
		return nomDob1;
	}

	public void setNomDob1(String nomDob1) {
		this.nomDob1 = nomDob1;
	}

	public String getNomAddress1() {
		return nomAddress1;
	}

	public void setNomAddress1(String nomAddress1) {
		this.nomAddress1 = nomAddress1;
	}

	public String getNomMob1() {
		return nomMob1;
	}

	public void setNomMob1(String nomMob1) {
		this.nomMob1 = nomMob1;
	}

}
