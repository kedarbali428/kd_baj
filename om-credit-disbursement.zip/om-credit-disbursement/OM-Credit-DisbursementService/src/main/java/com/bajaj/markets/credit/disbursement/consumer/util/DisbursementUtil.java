package com.bajaj.markets.credit.disbursement.consumer.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.amazonaws.services.sns.model.PublishResult;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.disbursement.consumer.bean.Address;
import com.bajaj.markets.credit.disbursement.consumer.bean.AppTranchResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationDetail;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationUtmParameter;
import com.bajaj.markets.credit.disbursement.consumer.bean.BankDetailsResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.BusinessVerticalMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateLoanResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreditReviewStatusBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CustomerDisbDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementRecordsObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.EventRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementRecordsObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GenderMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.Header;
import com.bajaj.markets.credit.disbursement.consumer.bean.LmsIntegrationRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.MasterDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.Metadata;
import com.bajaj.markets.credit.disbursement.consumer.bean.PartnerProductMapMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.PennantSystemDate;
import com.bajaj.markets.credit.disbursement.consumer.bean.PinCodeMaster;
import com.bajaj.markets.credit.disbursement.consumer.bean.PrincipalFileUploadRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ReturnStatusBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.SmartechDisbursementIntegrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.SmartechDisbursementNotificationDetailsBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.UserProfile;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.repository.MongoDBRepository;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.bajaj.markets.referencedataclientlib.bean.CacheServiceException;
import com.bajaj.markets.referencedataclientlib.helper.MasterDataEnumConstants;
import com.bajaj.markets.referencedataclientlib.service.CommonCacheService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * @author pranoti.pandole
 *
 */
@Component
public class DisbursementUtil {

	@Value("${api.omcreditapplicationservice.tranches.PUT.url}")
	private String updateAppTranchUrl;

	@Value("${api.omcreditemployeeportalservice.tranches.GET.url}")
	private String getTrachDetailsURL;

	@Value("${api.creditapplication.bankdetails.GET.url}")
	private String getBankDetailsUrl;

	@Value("${api.omcreditapplicationservice.details.GET.url}")
	private String getApplicationDetailsUrl;

	@Value("${api.omreferencedatareferencedataservice.pincode.GET.url}")
	private String getPincodeDetailsUrl;

	@Value("${api.omreferencedata.city.location.GET.url}")
	private String getLocalityDetailsUrl;

	@Value("${api.omcreditapplicationservice.customerdetails.GET.url}")
	private String getCustomerDetailsFromCreditApplicationUrl;

	@Value("${api.omcreditapplicationservice.saveDisbError.POST.url}")
	private String saveDisbErrorUrl;

	@Value("${api.omretryregistrationservice.getretrytransaction.GET.url}")
	private String getretrytransaction;

	@Value("${api.omretryregistrationservice.saveretrytransaction.POST.url}")
	private String saveretrytransaction;

	@Value("${api.omcreditapplicationservice.addressDetails.get.url}")
	private String addressDetailsUrl;

	@Autowired
	PublisherService publisherService;

	@Value("${disb.sns.topic}")
	private String disbEventName;

	@Value("${aws.publisher.disb.topic.arn}")
	private String disbtopicArn;

	@Autowired
	MongoDBRepository mongoDbRepo;

	@Autowired
	@Qualifier("disbursementMongoTemplate")
	MongoOperations disbursementMongoTemplate;

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	LMSHelper lmsHelper;

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Value("${aws.publisher.smartech.topic.arn}")
	private String smartechSNSTopic;

	@Value("${netcore.smartech.activityid}")
	private String activityid;

	@Value("${api.omcreditapplicationservice.applicationDetails.get.url}")
	private String applicationDetailsUrl;

	@Value("${api.omcreditapplicationservice.applicationutmparameters.GET.url}")
	private String getApplicationUtmSourcesUrl;

	@Value("${api.omcreditapplicationservice.userprofiles.GET.url}")
	private String getUserProfilesUrl;

	@Value("${api.omreferencedatareferencedataservice.gender.GET.url}")
	private String getGenderDetailsUrl;

	@Value("${api.omcreditapplicationservice.validaterequest.get.url}")
	private String validateRequestUrl;
	
	@Value("${api.omcreditemployeeportalservice.creditreviewstatus.GET.url}")
	private String getCreditReviewStatus;
	
	@Value("${insDisbursementMongoDBTable}")
	private String insDisbursementMongoDB;
	
	@Value("${finnone.sqs.topic}")
	private String finnoneIdQueueName;

	@Autowired
	private CommonCacheService commonCacheService;

	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;

	private static final String CLASS_NAME = DisbursementUtil.class.getCanonicalName();

	public PennantSystemDate callPennantForSystemDate(GlobalDataBean data, String lmsURL) {
		PennantSystemDate penSystDate = null;
		Gson gson = new Gson();
		ObjectMapper mapper = new ObjectMapper();
		try {

			LmsIntegrationRequestBean lmsIntegrationRequestBean = new LmsIntegrationRequestBean();
			lmsIntegrationRequestBean.setHttpMethod(HttpMethod.POST);
			lmsIntegrationRequestBean.setProductCode(data.getL2ProductCode());
			lmsIntegrationRequestBean.setSource("SYSTEMDATE");
			String pennantSystDateReq = gson.toJson(lmsIntegrationRequestBean, LmsIntegrationRequestBean.class);

			logger.info("DisbursementUtil", BFLLoggerComponent.SERVICE, "Lms Request String : " + pennantSystDateReq);

			Object responsePayload = lmsHelper.execute(pennantSystDateReq, generateHeaders(data),
					data.getApplicationKey());
			penSystDate = mapper.readValue(responsePayload.toString(), PennantSystemDate.class);
		} catch (Exception e) {
			logger.error("DisbursementUtil", BFLLoggerComponent.UTILITY,
					"RepaymentScheduleUtil : hitLmsToGetPennantSystemDate() : Unable to invoke LMSIntegration Service for Pennant System Date",
					e);
			throw new DisbursementServiceException(HttpStatus.EXPECTATION_FAILED,
					new ErrorBean("DISB-100", "Call for SYSDATE failed"));
		}
		return penSystDate;
	}

	@SuppressWarnings("unchecked")
	public void updateAppTranch(String applicationId, String trancheStatus, Integer disbursementFailureFlg,
			String disbursementError, Integer disbAmount, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "updateAppTranch : Start :");
		try {
			List<TranchBean> appTranchBeanList = fetchTranchDetails(applicationId, headers);
			for (TranchBean inputTranch : appTranchBeanList) {
				TranchBean tranchBeanRequest = new TranchBean();
				tranchBeanRequest.setAccountNumber(inputTranch.getAccountNumber());
				tranchBeanRequest.setBeneficiaryTypeKey(inputTranch.getBeneficiaryTypeKey());
				tranchBeanRequest.setOmDisbursementFlag(true);
				tranchBeanRequest.setTrancheStatus(null != trancheStatus ? trancheStatus : null);
				tranchBeanRequest.setDisbursementError(null != disbursementError ? disbursementError : null);
				tranchBeanRequest.setDisbursementFailureFlg(disbursementFailureFlg);
				tranchBeanRequest.setTotalDisubursedAmt(null != disbAmount ? disbAmount : null);
				Long trnchKey = inputTranch.getTranchkey();
				HashMap<String, String> params = new HashMap<>();
				params.put("applicationKey", applicationId);
				params.put("tranchKey", trnchKey.toString());
				Gson gson = new Gson();
				String requestStr = gson.toJson(tranchBeanRequest, TranchBean.class);
				ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
						.invokeRestEndpoint(HttpMethod.PUT, updateAppTranchUrl, String.class, params, requestStr,
								headers);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occurred while updating App Tranch Status: Collateral Call ", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred while updating App Tranch Status in Collateral Call");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "updateAppTranch : End : ");
	}

	@SuppressWarnings("unchecked")
	public List<TranchBean> fetchTranchDetails(String applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"fetchTranchDetails : Start : applicationId :" + applicationId);
		AppTranchResponse appTranchResponse = null;
		List<TranchBean> applicationTranches = new ArrayList<>();
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		params.put("tranchApplicationKey", applicationId);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getTrachDetailsURL, String.class, params, null, headers);
		if (null != response.getBody()) {
			appTranchResponse = gson.fromJson(response.getBody(), AppTranchResponse.class);
			applicationTranches = appTranchResponse.getApplicationTranches();
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"fetchTranchDetails : End : applicationId: " + applicationId);
		return applicationTranches;
	}

	@SuppressWarnings("unchecked")
	public List<BankDetailsResponse> fetchBankDetails(String applicationId, HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"fetchEmailDetails : Start : applicationId :" + applicationId);
		List<BankDetailsResponse> bankDetailsList = new ArrayList<>();
		Gson gson = new Gson();
		List<TranchBean> tranchDetailsList = fetchTranchDetails(applicationId, headers);

		for (TranchBean tranch : tranchDetailsList) {
			BankDetailsResponse bank = new BankDetailsResponse();
			HashMap<String, String> params = new HashMap<>();
			params.put("applicationKey", applicationId);
			params.put("bankdetailskey", tranch.getApplicationBankDetKey().toString());
			ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, getBankDetailsUrl, String.class, params, null, headers);
			if (null != response.getBody()) {
				bank = gson.fromJson(response.getBody(), BankDetailsResponse.class);
				bankDetailsList.add(bank);
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"fetchEmailDetails : End : applicationId: " + applicationId);
		return bankDetailsList;
	}

	@SuppressWarnings("unchecked")
	public ApplicationDetails fetchApplicationDetails(String applicationId, String userAttributeKey,
			HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchApplicationDetails : Start : applicationId :"
				+ applicationId + " userAttributeKey :" + userAttributeKey);
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		ApplicationDetails applicationDetails = null;

		params.put("applicationid", applicationId);
		params.put("userattributekey", userAttributeKey);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getApplicationDetailsUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			applicationDetails = gson.fromJson(response.getBody(), ApplicationDetails.class);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchApplicationDetails : End : applicationId: "
				+ applicationId + " userAttributeKey :" + userAttributeKey);
		return applicationDetails;
	}

	@SuppressWarnings("unchecked")
	public String fetchPincodeDetails(Long pincodeKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchPincodeDetails : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		PinCodeMaster pinCodeMaster = null;
		String code = "";
		params.put("pincodeKey", pincodeKey.toString());
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getPincodeDetailsUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			pinCodeMaster = gson.fromJson(response.getBody(), PinCodeMaster.class);
			code = pinCodeMaster.getPincode();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchPincodeDetails : End : " + code);
		return code;
	}

	@SuppressWarnings("unchecked")
	public String fetchLocalityDetails(Long cityKey, String localityKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchLocalityDetails : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		List<MasterDataBean> masterDataBeanList = new ArrayList<>();

		params.put("citycode", cityKey.toString());
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getLocalityDetailsUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			MasterDataBean[] masterDataBeanResponse = gson.fromJson(response.getBody(), MasterDataBean[].class);
			masterDataBeanList = Arrays.asList(masterDataBeanResponse);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchLocalityDetails : End : ");
		MasterDataBean localityDescBean = masterDataBeanList.stream().filter(x -> x.getId().equals(localityKey))
				.findFirst().orElse(null);
		return ((null != localityDescBean && null != localityDescBean.getDisplayName())
				? localityDescBean.getDisplayName()
				: null);
	}

	public boolean raiseEvent(DisbursementEventRequestBean disbursementEventRequestBean, String eventType) {
		boolean flag = false;
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Inside LoanProcessor raiseEvent DISBURSEMENT_COMPLETED ApplicationID: "
							+ disbursementEventRequestBean.getApplicationId());
			com.bajaj.markets.credit.bean.EventMessage eventMessage = createEventMessage(disbursementEventRequestBean,
					eventType);
			publisherService.publish(disbtopicArn, eventMessage);
			if (DisbursementConstants.DISBURSEMENT_COMPLETED.equalsIgnoreCase(eventType)) {
				docPushEventRaise(eventType, eventMessage, disbursementEventRequestBean.getApplicationId());
			}
			flag = true;
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside  DisbursementUtil raiseEvent ApplicationID: "
					+ disbursementEventRequestBean.getApplicationId() + " flag: " + flag);
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while raising DISBURSEMENT_COMPLETED event");
		}
		return flag;
	}

	private com.bajaj.markets.credit.bean.EventMessage createEventMessage(
			DisbursementEventRequestBean disbursementEventRequestBean, String eventType) {
		Map<String, String> headers = new HashMap<>();
		headers.put("authtoken", disbursementEventRequestBean.getHeaders().get("authtoken"));
		headers.put("cmptcorrid", disbursementEventRequestBean.getHeaders().get("cmptcorrid"));
		com.bajaj.markets.credit.bean.EventMessage eventMessage = new com.bajaj.markets.credit.bean.EventMessage();
		eventMessage.setEventName(disbEventName);
		eventMessage.setEventType(eventType);
		// eventMessage.setPrincipalName("BFL");
		// eventMessage.setProductCode(data.getL3ProductCode());
		eventMessage.setPayload(disbursementEventRequestBean);
		eventMessage.setHeaders(headers);
		return eventMessage;
	}

	@SuppressWarnings("unchecked")
	public CustomerDisbDetails fetchCustomerDisbDetails(String applicationId, String userAttributeKey,
			HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "fetchCustomerDisbDetails : Start : applicationId :"
				+ applicationId + " userAttributeKey :" + userAttributeKey);
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		CustomerDisbDetails customerDisbDetails = null;

		params.put("applicationkey", applicationId);
		params.put("userattrkey", userAttributeKey);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(
				HttpMethod.GET, getCustomerDetailsFromCreditApplicationUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			customerDisbDetails = gson.fromJson(response.getBody(), CustomerDisbDetails.class);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "fetchCustomerDisbDetails : End : applicationId: "
				+ applicationId + " userAttributeKey :" + userAttributeKey);
		return customerDisbDetails;
	}

	@SuppressWarnings("unchecked")
	public DisbursementTrackerBean saveDisbursementErrorDetails(GlobalDataBean appInfo,
			DisbursementTrackerBean dataToSave) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  saveDisbursementErrorDetails: " + appInfo.getApplicationKey());
		List<TranchBean> trnchLst = fetchTranchDetails(appInfo.getApplicationKey(), generateHeaders(appInfo));
		Long activeTranchKey = trnchLst.get(0).getTranchkey();
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  saveDisbursementErrorDetails Starts for tranch: " + activeTranchKey);
		Map<String, String> params = new HashMap<>();
		params.put("tranchKey", activeTranchKey.toString());
		String jsonRequest = objectToJson(dataToSave);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(
				HttpMethod.POST, saveDisbErrorUrl, String.class, params, jsonRequest, generateHeaders(appInfo));
		Gson gson = new Gson();
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				disbursementTrackerBean = gson.fromJson(excuteRestCall.getBody().toString(),
						DisbursementTrackerBean.class);

			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  saveDisbursementErrorDetails .");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  saveDisbursementErrorDetails Ends for tranch: " + activeTranchKey);
		return disbursementTrackerBean;
	}

	public String logDisbErrors(String applicationId, String responsePayload) {
		String errorReason = null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  logDisbErrors Ends for applicationId: " + applicationId);
		if (null != responsePayload) {
			if (responsePayload.contains("returnCode")) {
				org.json.JSONObject payldJsn = (org.json.JSONObject) new org.json.JSONObject(responsePayload);
				String code = payldJsn.getJSONObject("returnStatus").get("returnCode").toString();
				if (!code.equals("0000")) {
					String text = payldJsn.getJSONObject("returnStatus").get("returnText").toString();
					errorReason = code.concat(": " + text);
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End  logDisbErrors Ends for applicationId: " + applicationId + " errorReason: " + errorReason);
		return errorReason;
	}

	public String logBeneficiaryDisbErrors(String applicationId, String responsePayload) {
		String errorReason = null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  logBeneficiaryDisbErrors Ends for applicationId: " + applicationId);
		responsePayload = responsePayload.substring(responsePayload.indexOf("[") + 1);
		responsePayload = responsePayload.substring(0, responsePayload.indexOf("error") - 2);
		if (null != responsePayload) {
			if (null != responsePayload) {
				if (responsePayload.contains("faultCode")) {
					org.json.JSONObject payldJsn = (org.json.JSONObject) new org.json.JSONObject(responsePayload);
					String code = payldJsn.get("faultCode").toString();
					if (!code.equals("0000")) {
						String text = payldJsn.get("faultMessage").toString();
						errorReason = code.concat(": " + text);
					}
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End  logBeneficiaryDisbErrors Ends for applicationId: "
				+ applicationId + " errorReason: " + errorReason);
		return errorReason;
	}

	@SuppressWarnings("unchecked")
	public RetryRegistrationBean fetchExistingTransaction(String tranchId, String appId, HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"fetchExistingTransaction : Start : applicationId :" + appId + " tranchId :" + tranchId);
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		RetryRegistrationBean retryRegistrationBean = null;

		params.put("transactionId", tranchId);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getretrytransaction, String.class, params, null, headers);
		if (null != response.getBody()) {
			retryRegistrationBean = gson.fromJson(response.getBody(), RetryRegistrationBean.class);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"fetchExistingTransaction : ENDS : applicationId :" + appId + " tranchId :" + tranchId);
		return retryRegistrationBean;
	}

	@SuppressWarnings("unchecked")
	public RetryRegistrationBean saveretrytransaction(String tranchId, String appId, RetryRegistrationBean bean,
			HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"saveretrytransaction : Start : applicationId :" + appId + " tranchId :" + tranchId);
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		RetryRegistrationBean retryRegistrationBean = null;
		String jsonRequest = objectToJson(bean);
		params.put("transactionId", tranchId);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.POST, saveretrytransaction, String.class, params, jsonRequest, headers);
		if (null != response.getBody()) {
			retryRegistrationBean = gson.fromJson(response.getBody(), RetryRegistrationBean.class);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"saveretrytransaction : ENDS : applicationId :" + appId + " tranchId :" + tranchId);
		return retryRegistrationBean;
	}

	public static String objectToJson(Object o) {
		Gson gson = new Gson();
		return gson.toJson(o);
	}

	public void addDisbursementRecords(String applicationKey, String applicantKey, String requestPayload,
			String responsePayload, String target, String reqTimestmp, String resTimestmp) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"addDisbursementRecords : Start : resTimestmp-" + resTimestmp);
		DisbursementRecordsObject disbRecord = new DisbursementRecordsObject();
		disbRecord.setApplicantKey(applicantKey);
		disbRecord.setApplicationKey(applicationKey);
		disbRecord.setRequestPayload(requestPayload);
		disbRecord.setRequestTimeStamp(reqTimestmp);
		disbRecord.setResponsePayload(responsePayload);
		disbRecord.setResponseTimeStamp(resTimestmp);
		disbRecord.setSource(DisbursementConstants.BFDL_LOANS_SOURCE);
		disbRecord.setStatus(DisbursementConstants.DISB_SUCCESS);
		disbRecord.setTarget(target);
		mongoDbRepo.insertDocumentDB(disbursementMongoTemplate, disbRecord, DisbursementConstants.DISBURSEMENT_RECORDS);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "addDisbursementRecords : END : ");

	}

	public HttpHeaders generateHeaders(GlobalDataBean data) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("authtoken", data.getHeaders().get("authtoken"));
		headers.add("cmptcorrid", data.getHeaders().get("cmptcorrid"));
		headers.add("guardtoken", data.getHeaders().get("guardtoken"));
		return headers;
	}

	@SuppressWarnings("unchecked")
	public ApplicationDetails fetchApplicationDetailsForCoApplicant(String parentApplicationKey,
			String applicationUserAttributeKey, HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", parentApplicationKey);
		params.put("userattributekey", applicationUserAttributeKey);
		params.put("typeKey", DisbursementConstants.ADDRESS_TYPE_CURRENT_KEY);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, addressDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();
		Address address = new Address();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				address = gson.fromJson(excuteRestCall.getBody().toString(), Address.class);
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchBranchDetails .");
		}
		ApplicationDetails applicationDetails = new ApplicationDetails();
		List<Address> addressListForCoapplicant = new ArrayList<Address>();
		addressListForCoapplicant.add(address);
		applicationDetails.setAddressList(addressListForCoapplicant);
		return applicationDetails;
	}

	public void sendSmartechNotification(String loanAmount, GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendSmartechNotification : Start");
		SmartechDisbursementIntegrationBean integrationBean = new SmartechDisbursementIntegrationBean();
		integrationBean.setActivityid(activityid);
		integrationBean.setIdentity(data.getMobile());
		integrationBean.setActivityParams(FetachActivityParams(loanAmount, data));
		try {
			EventRequest eventRequest = mapSmartechEventRequest(integrationBean, data);
			PublishResult publishResult = publisherService.publish(smartechSNSTopic, eventRequest);

			if (null != publishResult)
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"In pushEventToTopic() for applicationId : " + data.getApplicationKey()
								+ " Event Pushed to Topic Successfully. MessageId : " + publishResult.getMessageId());
		} catch (JsonProcessingException e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while raising Smartech DISBURSEMENT_COMPLETED event");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendSmartechNotification : End");

	}

	private List<SmartechDisbursementNotificationDetailsBean> FetachActivityParams(String loanAmount,
			GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "FetachActivityParams : Start");
		List<SmartechDisbursementNotificationDetailsBean> activityParams = new ArrayList<SmartechDisbursementNotificationDetailsBean>();
		SmartechDisbursementNotificationDetailsBean detailsBean = new SmartechDisbursementNotificationDetailsBean();
		ApplicationDetail appDetails = fetchApplicationDetails(data);
		ApplicationUtmParameter applicationUtmParameter = fetchUTMParams(data.getParentApplicationKey(),
				generateHeaders(data));
		detailsBean.setApplicationid(data.getParentApplicationKey());
		detailsBean.setProdcode(SmartechProductCodeEnum.getValueOfProductCode(appDetails.getL3ProductCode()));
		detailsBean.setL2prodcode(appDetails.getL2ProductDesc());
		detailsBean.setProdname(appDetails.getL3ProductDesc());
		detailsBean.setUtmSource(applicationUtmParameter.getUtmsource());
		detailsBean.setProdquantity(DisbursementConstants.SMARTECH_PRODUCT_QUANTITY);
		detailsBean.setRevenue(Long.valueOf(loanAmount));
		detailsBean.setProdcategory("Loans");
		detailsBean.setPrincipalCode(appDetails.getPrincipalKey().equals(DisbursementConstants.PRINICIPAL_KEY_BFL)
				? DisbursementConstants.PRINCIPAL_CODE_BFL
				: null);
		detailsBean.setPrincipalName(appDetails.getPrincipalKey().equals(DisbursementConstants.PRINICIPAL_KEY_BFL)
				? DisbursementConstants.PRINICIPAL_NAME_BFL
				: null);
		activityParams.add(detailsBean);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "FetachActivityParams : End");
		return activityParams;
	}

	@SuppressWarnings("unchecked")
	private ApplicationUtmParameter fetchUTMParams(String applicationKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchUTMParams : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		List<ApplicationUtmParameter> applicationUtmParameterList = new ArrayList<>();
		params.put("applicationid", applicationKey);
		params.put("event", null);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getApplicationUtmSourcesUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			ApplicationUtmParameter[] masterDataBeanResponse = gson.fromJson(response.getBody(),
					ApplicationUtmParameter[].class);
			applicationUtmParameterList = Arrays.asList(masterDataBeanResponse);
			if (null != applicationUtmParameterList && 0 < applicationUtmParameterList.size()) {
				applicationUtmParameterList.sort(Comparator.comparing(ApplicationUtmParameter::getCreatedt).reversed());
				return applicationUtmParameterList.get(0);
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchUTMParams : End : ");
		return null;
	}

	private EventRequest mapSmartechEventRequest(
			SmartechDisbursementIntegrationBean smartechDisbursementIntegrationBean, GlobalDataBean data)
			throws JsonProcessingException {
		logger.debug(CLASS_NAME, BFLLoggerComponent.MAPPER,
				"In mapDispositionBeanToEventRequest() for applicationId : " + data.getParentApplicationKey());
		Header header = new Header();
		header.setDataType("JSON");
		header.setEventActor("SYSTEM");
		header.setEventName("APPLICATION_DISPOSITION_STATUS");
		header.setEventSource("OM-CREDIT");
		header.setEventType("OPERATION");
		header.setTimestamp(getCurrentDateTime());

		Metadata metadata = new Metadata();
		metadata.setPartner("NETCORE");

		EventRequest eventRequest = new EventRequest();
		eventRequest.setTags(new String[] { "DISBURSEMENT-INTEGRATION" });
		ObjectMapper mapper = new ObjectMapper();
		String dispositionStr = mapper.writeValueAsString(smartechDisbursementIntegrationBean);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"In mapSmartechEventRequest() dispositionRequest: " + dispositionStr);
		eventRequest.setData(dispositionStr);
		eventRequest.setHeader(header);
		eventRequest.setMetadata(metadata);
		eventRequest.setApplicationId(data.getParentApplicationKey());
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "In mapSmartechEventRequest() cmptcorrId: ");
		eventRequest.setCmptcorrid(
				null != data.getHeaders().get("cmptcorrid") ? data.getHeaders().get("cmptcorrid") : null);

		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Out mapSmartechEventRequest() for applicationId : " + data);
		return eventRequest;
	}

	private String getCurrentDateTime() {
		Date date = Calendar.getInstance().getTime();
		return new Timestamp(date.getTime()).toString();
	}

	@SuppressWarnings("unchecked")
	public ApplicationDetail fetchApplicationDetails(GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  DisbUtil fetchApplicationDetails ApplicationID: " + data.getApplicationKey());
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", data.getApplicationKey());
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		header.add("authtoken", data.getHeaders().get("authtoken"));
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, applicationDetailsUrl, String.class, params, null, header);
		Gson gson = new Gson();
		ApplicationDetail appDtl = new ApplicationDetail();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				appDtl = gson.fromJson(excuteRestCall.getBody().toString(), ApplicationDetail.class);
				return appDtl;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchApplicationDetails .");
		}
		return appDtl;
	}

	public void mapGlobalData(ApplicationDetail appDtl, GlobalDataBean data) {
		data.setApplicantKey(appDtl.getApplicantKey());
		data.setApplicationKey(appDtl.getApplicationKey());
		data.setApplicationStatus(appDtl.getApplicationStatus());
		data.setL2ProductCode(appDtl.getL2ProductCode());
		data.setL2ProductKey(appDtl.getL2ProductKey());
		data.setL3ProductCode(appDtl.getL3ProductCode());
		data.setL3ProductKey(appDtl.getL3ProductKey());
		data.setL4ProductCode(appDtl.getL4ProductCode());
		data.setL4ProductKey(appDtl.getL4ProductKey());
		data.setParentApplicationKey(appDtl.getParentApplicationKey());
	}

	public String fetchCifId(Long applicationKey, Long applicantKey) {
		List<DisbursementMongoObject> disbursementMongoObjectList = mongoDbRepo.fetchObjectByKey(
				disbursementMongoTemplate, "applicantKey", Long.valueOf(applicantKey),
				DisbursementConstants.SERVICE_RECORD);
		DisbursementMongoObject result = disbursementMongoObjectList.stream()
				.filter(x -> x.getApplicationKey().equals(applicationKey)).findFirst().orElse(null);
		return result.getCif();
	}

	@SuppressWarnings("unchecked")
	public List<UserProfile> getUserDetails(String applicationId, HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getUserDetails : Start : " + applicationId);
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		List<UserProfile> userProfileList = new ArrayList<>();
		params.put("applicationid", applicationId);
		ResponseEntity<String> userProfileResponse = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getUserProfilesUrl, String.class, params, null, headers);
		if (null != userProfileResponse.getBody()) {
			UserProfile[] userDetails = gson.fromJson(userProfileResponse.getBody(), UserProfile[].class);
			userProfileList = Arrays.asList(userDetails);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getUserDetails : End : " + applicationId);
		return userProfileList;
	}

	@SuppressWarnings("unchecked")
	public String fetchGenderDescDetails(Long genderKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchGenderCodeDetails : Start :");
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		List<GenderMaster> genderCodeDtlsList = new ArrayList<>();
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getGenderDetailsUrl, String.class, params, null, headers);

		if (null != response.getBody()) {
			GenderMaster[] genderCodeDtlsResponse = gson.fromJson(response.getBody(), GenderMaster[].class);
			genderCodeDtlsList = Arrays.asList(genderCodeDtlsResponse);
		}

		String genderDesc = "";
		for (GenderMaster genderMaster : genderCodeDtlsList) {
			if (genderMaster.getGenderKey().equals(genderKey))
				genderDesc = genderMaster.getGenderCode();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchGenderCodeDetails : End : ");
		return genderDesc;
	}

	public boolean raiseDisbursementSuccessEventForDmsDocPush(
			PrincipalFileUploadRequestBean principalFileUploadRequestBean) {
		boolean flag = false;
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"START - raiseDisbursementSuccessEventForDmsDocPush after DISBURSEMENT_COMPLETED, ApplicationID: "
							+ principalFileUploadRequestBean.getApplicationId());
			Map<String, String> headers = new HashMap<>();
			headers.put("authtoken", customDefaultHeaders.getAuthtoken());
			headers.put("cmptcorrid", customDefaultHeaders.getCmptcorrid());
			com.bajaj.markets.credit.bean.EventMessage eventMessage = new com.bajaj.markets.credit.bean.EventMessage();
			eventMessage.setEventName(disbEventName);
			eventMessage.setEventType(DisbursementConstants.DISBURSEMENT_COMPLETED);
			eventMessage.setPayload(principalFileUploadRequestBean);
			eventMessage.setHeaders(headers);
			publisherService.publish(disbtopicArn, eventMessage);
			docPushEventRaise(DisbursementConstants.DISBURSEMENT_COMPLETED, eventMessage,
					principalFileUploadRequestBean.getApplicationId());
			flag = true;
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"END - raiseDisbursementSuccessEventForDmsDocPush after DISBURSEMENT_COMPLETED, ApplicationID: "
							+ principalFileUploadRequestBean.getApplicationId() + " and event raise flag : " + flag);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception while raising DISBURSEMENT_COMPLETED event for DMS_DOC_PUSH, ApplicationID : "
							+ principalFileUploadRequestBean.getApplicationId());
		}
		return flag;
	}

	public <T> T findAllCommonMasters(MasterDataEnumConstants.MasterName masterData, Map<String, Object> params,
			Class<T> responseType) throws CacheServiceException, JsonMappingException, JsonProcessingException {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, " Inside findAllCommonMasters = " + masterData);
		Object response = commonCacheService.findAll(masterData);
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		if (response != null && response instanceof String)
			return mapper.readValue(response.toString(), responseType);
		Gson gson = new GsonBuilder().disableHtmlEscaping().serializeNulls().create();
		return mapper.readValue(gson.toJson(response), responseType);
	}

	public PartnerProductMapMaster fetchPartnerProductMap(FundedDisbursementEventRequestBean fundedRequest)
			throws JsonMappingException, JsonProcessingException {
		List<BusinessVerticalMaster> verticals = new ArrayList<>();
		List<PartnerProductMapMaster> productMap = new ArrayList<>();
		/*
		 * //TO BE REVERTED verticals =
		 * Arrays.asList(findAllCommonMasters(MasterDataEnumConstants.MasterName.
		 * BUSINESSSVERTICAL, null, BusinessVerticalMaster[].class)); productMap =
		 * Arrays.asList(findAllCommonMasters(MasterDataEnumConstants.MasterName.
		 * PARTNERPRODUCTMAP, null, PartnerProductMapMaster[].class));
		 */
		Long businessMastKey = verticals.stream()
				.filter(x -> x.getBusinessverticalcode()
						.equalsIgnoreCase(fundedRequest.getApplicationDetails().getBusinessVertical())
						&& x.getPotypecode().equalsIgnoreCase(fundedRequest.getApplicationDetails().getPoType()))
				.findFirst().get().getBusinessverticalmastkey();
		PartnerProductMapMaster partnerProduct = productMap.stream()
				.filter(x -> businessMastKey == x.getBusinessverticalmastkey().longValue()
						&& x.getPolicytype().equalsIgnoreCase(fundedRequest.getApplicationDetails().getPolicyType())
						&& x.getProductcode()
								.equalsIgnoreCase(fundedRequest.getApplicationDetails().getL3ProductCode()))
				.findFirst().get();
		return partnerProduct;
	}

	public String fetchFundedCifId(Long applicationKey, String quoteNumber) {
		List<FundedDisbursementMongoObject> disbursementMongoObjectList = mongoDbRepo.fetchFundedObjectByKey(
				disbursementMongoTemplate, "applicationKey", Long.valueOf(applicationKey), insDisbursementMongoDB);
		FundedDisbursementMongoObject result = disbursementMongoObjectList.stream()
				.filter(x -> x.getQuoteNumber().equalsIgnoreCase(quoteNumber)).findFirst().orElse(null);
		return result.getCif();
	}

	public void updateServiceRecordForFundedLoan(Long applicationKey, String quoteNumber, String finRefId) {
		mongoDbRepo.updateFieldByApplicationKeyAndQuote(disbursementMongoTemplate, applicationKey, quoteNumber,
				"customerLoanId", finRefId, insDisbursementMongoDB);
		mongoDbRepo.updateFieldByApplicationKeyAndQuote(disbursementMongoTemplate, applicationKey, quoteNumber,
				"disbursementStatus", "success", insDisbursementMongoDB);
		mongoDbRepo.updateFieldByApplicationKeyAndQuote(disbursementMongoTemplate, applicationKey, quoteNumber,
				"disbDate", new Date(System.currentTimeMillis()).toString(), insDisbursementMongoDB);
	}

	public boolean raiseInsuranceEventPostDisbursement(FundedDisbursementEventRequestBean request,
			CreateLoanResponseBean createLoanResponseBean, ReturnStatusBean returnStatusBean, String stage, String cif,
			String eventType) {
		boolean flag = false;
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Inside Util raiseInsuranceEventPostDisbursement ApplicationID: " + request.getApplicationId());
			com.bajaj.markets.credit.bean.EventMessage eventMessage = new com.bajaj.markets.credit.bean.EventMessage();
			eventMessage.setEventName(disbEventName);
			eventMessage.setEventType(eventType);
			Map<String, Object> responseMap = new HashMap<String, Object>();
			responseMap.put("applicationNo", request.getApplicationDetails().getApplicationNo());
			responseMap.put("quoteNumber", request.getApplicationDetails().getQuoteNumber());
			responseMap.put("paymentQuoteId", request.getApplicationDetails().getPaymentQuoteId());
			String lanNumber = null != createLoanResponseBean && null != createLoanResponseBean.getFinReference()
					? createLoanResponseBean.getFinReference()
					: "";
			responseMap.put("pennantLAN", lanNumber);
			responseMap.put("pennantDisbDate",
					null != createLoanResponseBean && null != createLoanResponseBean.getFinanceSchedule()
							&& null != createLoanResponseBean.getFinanceSchedule().getSummary()
									? createLoanResponseBean.getFinanceSchedule().getSummary().getFirstDisbDate()
									: "");
			responseMap.put("pennantCif", cif != null ? cif : "");
			responseMap.put("stage", stage);

			responseMap.put("disbursementStatus",
					"CREATE_LOAN".equalsIgnoreCase(stage) && null != lanNumber && !lanNumber.isEmpty() ? "Success"
							: "Failed");
			if (!DisbursementConstants.PENNANT_SUCCES_CODE.equalsIgnoreCase(returnStatusBean.getReturnCode()))
				responseMap.put("pennantErrorMessage", returnStatusBean);
			responseMap.put("firstEmiAmt",
					null != createLoanResponseBean && null != createLoanResponseBean.getFinanceSchedule()
							&& null != createLoanResponseBean.getFinanceSchedule().getSummary().getFirstEmiAmount()
									? createLoanResponseBean.getFinanceSchedule().getSummary().getFirstEmiAmount()
											.toString()
									: null);
			eventMessage.setPayload(responseMap);
			eventMessage.setHeaders(null);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Inside LoanProcessor raiseInsuranceEventPostDisbursement: " + eventMessage);
			publisherService.publish(disbtopicArn, eventMessage);
			flag = true;
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside DisbursementUtil raiseEvent ApplicationID: "
					+ request.getApplicationId() + " flag: " + flag);
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while raising BFLIM_DISBURSEMENT_STATUS event");
		}
		return flag;

	}

	public void addFundedDisbursementRecords(String applicationKey, String quoteNumber, String requestPayload,
			String responsePayload, String target, String reqTimestmp, String resTimestmp) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"addFundedDisbursementRecords : Start : resTimestmp-" + resTimestmp + "for target " + target);
		FundedDisbursementRecordsObject disbRecord = new FundedDisbursementRecordsObject();
		disbRecord.setQuoteNumber(quoteNumber);
		disbRecord.setApplicationKey(applicationKey);
		disbRecord.setRequestPayload(requestPayload);
		disbRecord.setRequestTimeStamp(reqTimestmp);
		disbRecord.setResponsePayload(responsePayload);
		disbRecord.setResponseTimeStamp(resTimestmp);
		disbRecord.setSource(DisbursementConstants.BFL_LOANS_SOURCE);
		disbRecord.setStatus(DisbursementConstants.DISB_SUCCESS);
		disbRecord.setTarget(target);
		mongoDbRepo.insertDocumentDB(disbursementMongoTemplate, disbRecord, DisbursementConstants.DISBURSEMENT_RECORDS);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "addFundedDisbursementRecords : END : ");

	}
	private void docPushEventRaise(String eventType, EventMessage eventMessage, String applicationId) {
		if (DisbursementConstants.DISBURSEMENT_COMPLETED.equalsIgnoreCase(eventType)) {
			Map<String, String> messageFilterAttributes = new HashMap<>();
			messageFilterAttributes.put("EventType", DisbursementConstants.DISBURSEMENT_COMPLETED);
			messageFilterAttributes.put("functionDone", "DMS_DOC_PUSH");
			eventMessage.setMessageFilterAttributes(messageFilterAttributes);
			publisherService.publish(disbtopicArn, eventMessage);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"After DISBURSEMENT_COMPLETED, event for DMS_DOC_PUSH is raised successfully for applicationId: "
							+ applicationId);
		}
	}

	public FundedDisbursementEventRequestBean fetchFundedDisbRequestForRetry(FundedDisbursementRequestBean request) {
		Gson gson = new Gson();
		List<FundedDisbursementEventRequestMongoObject> list = mongoDbRepo.fetchFundedEventRequestByKey(
				disbursementMongoTemplate, "applicationKey", Long.valueOf(request.getApplicationId()),
				DisbursementConstants.DISB_REQUEST_TRACKING_TABLE);
		List<FundedDisbursementEventRequestMongoObject> list1 = list.stream()
				.filter(x -> x.getQuoteNumber().equalsIgnoreCase(request.getQuoteNumber()))
				.collect(Collectors.toList());
		String fundedReq = list1.stream()
				.sorted(Comparator.comparing(FundedDisbursementEventRequestMongoObject::getTimestamp).reversed())
				.collect(Collectors.toList()).get(0).getEventRequest();
		return gson.fromJson(fundedReq, FundedDisbursementEventRequestBean.class);
	}

	public void saveFundedEventRequest(FundedDisbursementEventRequestBean request) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "saveFundedEventRequest : Start :");
		FundedDisbursementEventRequestMongoObject disbRecord = new FundedDisbursementEventRequestMongoObject();
		disbRecord.setQuoteNumber(request.getApplicationDetails().getQuoteNumber());
		disbRecord.setApplicationKey(Long.valueOf(request.getApplicationId()));
		Gson gson = new Gson();
		disbRecord.setEventRequest(gson.toJson(request));
		disbRecord.setTimestamp(new Timestamp(System.currentTimeMillis()));
		mongoDbRepo.insertDocumentDB(disbursementMongoTemplate, disbRecord,
				DisbursementConstants.DISB_REQUEST_TRACKING_TABLE);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "saveFundedEventRequest : END : ");
	}

	@SuppressWarnings("unchecked")
	public Boolean validateRequest(GlobalDataBean data) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  PROLDisbursementProcessor validateRequest ApplicationID: " + data.getApplicationKey());
		Map<String, String> params = new HashMap<>();
		params.put("applicationId", data.getApplicationKey());
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		header.add("authtoken", data.getHeaders().get("authtoken"));
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, validateRequestUrl, String.class, params, null, header);
		Gson gson = new Gson();
		Boolean isvalidRequest = false;
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				isvalidRequest = gson.fromJson(excuteRestCall.getBody().toString(), Boolean.class);
				return isvalidRequest;
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  validateRequest .");
		}
		return isvalidRequest;
	}

	@SuppressWarnings("unchecked")
	public CreditReviewStatusBean getCreditReviewDetails(String applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getCreditReviewDetails : Start : " + applicationId);
		CreditReviewStatusBean creditReviewStatusBean = null;
		Gson gson = new Gson();
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		ResponseEntity<String> creditReviewResponse = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getCreditReviewStatus, String.class, params, null, headers);
		if (null != creditReviewResponse.getBody()) {
			creditReviewStatusBean = gson.fromJson(creditReviewResponse.getBody(), CreditReviewStatusBean.class);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getCreditReviewDetails : End : " + applicationId);
		return creditReviewStatusBean;
	}
	
	public void raiseFinnoneIdEvent(GlobalDataBean data, String lanNumber) {
		boolean flag = false;
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Inside raiseFinnoneIdEvent raiseEvent FETCH_FINNONEID ApplicationID: "
							+ data.getApplicationKey());
			
			Map<String, String> payload = new HashMap<>();
			payload.put("applicationId", data.getParentApplicationKey());
			payload.put("l3ProductCode", data.getL3ProductCode());
			payload.put("finReference", lanNumber);
			ApplicationDetail appDetails=fetchApplicationDetails(data);
			payload.put("principalKey", appDetails.getPrincipalKey().toString());
			EventMessage eventMessage = new EventMessage();
          	eventMessage.setHeaders(data.getHeaders());
			eventMessage.setEventType("FETCH_FINNONEID");
			eventMessage.setEventName("FINNONE_DISB_INTEGRATION");
			eventMessage.setPayload(payload);
			
			publisherService.publishToQueue(finnoneIdQueueName, eventMessage);
			flag = true;
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Inside raiseFinnoneIdEvent raiseEvent FETCH_FINNONEID ApplicationID: "
							+ data.getApplicationKey() + " flag: " + flag);
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while raising FETCH_FINNONEID event");
		}
	}
}
