package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.Map;

public class GlobalDataBean {

	private String applicationKey;
	
	private String parentApplicationKey;
	
	private String applicantKey;
	
	private String coApplicantKey;
	
	private String appOccupationKey;
	
	private Long l2ProductKey;
	
	private String l2ProductCode;
	
	private Long l3ProductKey;
	
	private String l3ProductCode;
	
	private Long l4ProductKey;
	
	private String l4ProductCode;
	
	private Integer applicationStatus;
	
	private Map<String, String> headers;
	
	private String mobile;
	
	private String email;
	
	private String appAtrKey;
	
	private String businessPan;
	
	private boolean errFlg;

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getParentApplicationKey() {
		return parentApplicationKey;
	}

	public void setParentApplicationKey(String parentApplicationKey) {
		this.parentApplicationKey = parentApplicationKey;
	}

	public String getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getCoApplicantKey() {
		return coApplicantKey;
	}

	public void setCoApplicantKey(String coApplicantKey) {
		this.coApplicantKey = coApplicantKey;
	}

	public String getAppOccupationKey() {
		return appOccupationKey;
	}

	public void setAppOccupationKey(String appOccupationKey) {
		this.appOccupationKey = appOccupationKey;
	}

	public Long getL2ProductKey() {
		return l2ProductKey;
	}

	public void setL2ProductKey(Long l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}

	public String getL2ProductCode() {
		return l2ProductCode;
	}

	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}

	public Long getL3ProductKey() {
		return l3ProductKey;
	}

	public void setL3ProductKey(Long l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public Long getL4ProductKey() {
		return l4ProductKey;
	}

	public void setL4ProductKey(Long l4ProductKey) {
		this.l4ProductKey = l4ProductKey;
	}

	public String getL4ProductCode() {
		return l4ProductCode;
	}

	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}

	public Integer getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(Integer applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}

	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAppAtrKey() {
		return appAtrKey;
	}

	public void setAppAtrKey(String appAtrKey) {
		this.appAtrKey = appAtrKey;
	}

	public String getBusinessPan() {
		return businessPan;
	}

	public void setBusinessPan(String businessPan) {
		this.businessPan = businessPan;
	}

	public boolean getErrFlg() {
		return errFlg;
	}

	public void setErrFlg(boolean errFlg) {
		this.errFlg = errFlg;
	}
	
}
