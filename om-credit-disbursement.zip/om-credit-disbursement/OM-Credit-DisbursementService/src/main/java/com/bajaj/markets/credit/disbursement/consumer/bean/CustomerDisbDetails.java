package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class CustomerDisbDetails {

	// Personal Info
		private Long langKey;
		private Long nationalityKey;
		private Integer custcategorycdkey;
		
		//Address Info
		private List<ApplicantAddressInfo> applicantAddresses;
		
		private List<ApplicantPhoneInfo> phones;

		private List<ApplicantEmailInfo> emails;

		public Long getLangKey() {
			return langKey;
		}

		public void setLangKey(Long langKey) {
			this.langKey = langKey;
		}

		public Long getNationalityKey() {
			return nationalityKey;
		}

		public void setNationalityKey(Long nationalityKey) {
			this.nationalityKey = nationalityKey;
		}

		public List<ApplicantAddressInfo> getApplicantAddresses() {
			return applicantAddresses;
		}

		public void setApplicantAddresses(List<ApplicantAddressInfo> applicantAddresses) {
			this.applicantAddresses = applicantAddresses;
		}

		public List<ApplicantPhoneInfo> getPhones() {
			return phones;
		}

		public void setPhones(List<ApplicantPhoneInfo> phones) {
			this.phones = phones;
		}

		public List<ApplicantEmailInfo> getEmails() {
			return emails;
		}

		public void setEmails(List<ApplicantEmailInfo> emails) {
			this.emails = emails;
		}

		public Integer getCustcategorycdkey() {
			return custcategorycdkey;
		}

		public void setCustcategorycdkey(Integer custcategorycdkey) {
			this.custcategorycdkey = custcategorycdkey;
		}

}
