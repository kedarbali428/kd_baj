package com.bajaj.markets.credit.disbursement.consumer.bean;

public class LoanProcessorVariables {

	String loanResponseString;
	private boolean isRetryMechanism;
	boolean isHybridFlexi;
	private String finRepaymethod;
	private boolean isUMRNMatched;
	private boolean isSOLLoan;
	private boolean emandateFlg;
	private boolean physicalMandateFlg;
	private boolean finnOneMandateFlg;
	private String finnOneRepayMode;
	private String finnOneSubRepayMode;
	private String epMandateRefNo;
	private String chanelMandateRefId;
	private String l3product;
	private String mandateReqFlg;
	private String mandatePayMode;
	private String umrnValue;
	private String barCode;
	private String mandatesId;
	private boolean isBarCodeMatched;
	private Integer disbAmount;
	private boolean isBOLLoan;
	private boolean isPROLLoan;
	NotificationTemplateDataBean notificationTemplateBean;
	private String bundleApplicationPlanCode;

	public String getLoanResponseString() {
		return loanResponseString;
	}

	public void setLoanResponseString(String loanResponseString) {
		this.loanResponseString = loanResponseString;
	}

	public boolean isRetryMechanism() {
		return isRetryMechanism;
	}

	public void setRetryMechanism(boolean isRetryMechanism) {
		this.isRetryMechanism = isRetryMechanism;
	}

	public boolean isHybridFlexi() {
		return isHybridFlexi;
	}

	public void setHybridFlexi(boolean isHybridFlexi) {
		this.isHybridFlexi = isHybridFlexi;
	}

	public String getFinRepaymethod() {
		return finRepaymethod;
	}

	public void setFinRepaymethod(String finRepaymethod) {
		this.finRepaymethod = finRepaymethod;
	}

	public boolean isUMRNMatched() {
		return isUMRNMatched;
	}

	public void setUMRNMatched(boolean isUMRNMatched) {
		this.isUMRNMatched = isUMRNMatched;
	}

	public boolean isSOLLoan() {
		return isSOLLoan;
	}

	public void setSOLLoan(boolean isSOLLoan) {
		this.isSOLLoan = isSOLLoan;
	}

	public boolean isEmandateFlg() {
		return emandateFlg;
	}

	public void setEmandateFlg(boolean emandateFlg) {
		this.emandateFlg = emandateFlg;
	}

	public boolean isPhysicalMandateFlg() {
		return physicalMandateFlg;
	}

	public void setPhysicalMandateFlg(boolean physicalMandateFlg) {
		this.physicalMandateFlg = physicalMandateFlg;
	}

	public boolean isFinnOneMandateFlg() {
		return finnOneMandateFlg;
	}

	public void setFinnOneMandateFlg(boolean finnOneMandateFlg) {
		this.finnOneMandateFlg = finnOneMandateFlg;
	}

	public String getFinnOneRepayMode() {
		return finnOneRepayMode;
	}

	public void setFinnOneRepayMode(String finnOneRepayMode) {
		this.finnOneRepayMode = finnOneRepayMode;
	}

	public String getFinnOneSubRepayMode() {
		return finnOneSubRepayMode;
	}

	public void setFinnOneSubRepayMode(String finnOneSubRepayMode) {
		this.finnOneSubRepayMode = finnOneSubRepayMode;
	}

	public String getEpMandateRefNo() {
		return epMandateRefNo;
	}

	public void setEpMandateRefNo(String epMandateRefNo) {
		this.epMandateRefNo = epMandateRefNo;
	}

	public String getChanelMandateRefId() {
		return chanelMandateRefId;
	}

	public void setChanelMandateRefId(String chanelMandateRefId) {
		this.chanelMandateRefId = chanelMandateRefId;
	}

	public String getL3product() {
		return l3product;
	}

	public void setL3product(String l3product) {
		this.l3product = l3product;
	}

	public String getMandateReqFlg() {
		return mandateReqFlg;
	}

	public void setMandateReqFlg(String mandateReqFlg) {
		this.mandateReqFlg = mandateReqFlg;
	}

	public String getMandatePayMode() {
		return mandatePayMode;
	}

	public void setMandatePayMode(String mandatePayMode) {
		this.mandatePayMode = mandatePayMode;
	}

	public String getUmrnValue() {
		return umrnValue;
	}

	public void setUmrnValue(String umrnValue) {
		this.umrnValue = umrnValue;
	}

	public String getBarCode() {
		return barCode;
	}

	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}

	public String getMandatesId() {
		return mandatesId;
	}

	public void setMandatesId(String mandatesId) {
		this.mandatesId = mandatesId;
	}

	public boolean isBarCodeMatched() {
		return isBarCodeMatched;
	}

	public void setBarCodeMatched(boolean isBarCodeMatched) {
		this.isBarCodeMatched = isBarCodeMatched;
	}

	public Integer getDisbAmount() {
		return disbAmount;
	}

	public void setDisbAmount(Integer disbAmount) {
		this.disbAmount = disbAmount;
	}

	public boolean isBOLLoan() {
		return isBOLLoan;
	}

	public void setBOLLoan(boolean isBOLLoan) {
		this.isBOLLoan = isBOLLoan;
	}

	public boolean isPROLLoan() {
		return isPROLLoan;
	}

	public void setPROLLoan(boolean isPROLLoan) {
		this.isPROLLoan = isPROLLoan;
	}

	public NotificationTemplateDataBean getNotificationTemplateBean() {
		return notificationTemplateBean;
	}

	public void setNotificationTemplateBean(NotificationTemplateDataBean notificationTemplateBean) {
		this.notificationTemplateBean = notificationTemplateBean;
	}

	public String getBundleApplicationPlanCode() {
		return bundleApplicationPlanCode;
	}

	public void setBundleApplicationPlanCode(String bundleApplicationPlanCode) {
		this.bundleApplicationPlanCode = bundleApplicationPlanCode;
	}

}
