package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.io.Serializable;

public class BreDueDateResponse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArcduedateOutput arcduedateOutput;
	private String Action;
	
	public String getAction() {
		return Action;
	}
	public void setAction(String action) {
		Action = action;
	}
	public ArcduedateOutput getArcduedateOutput() {
		return arcduedateOutput;
	}
	public void setArcduedateOutput(ArcduedateOutput arcduedateOutput) {
		this.arcduedateOutput = arcduedateOutput;
	}
}
