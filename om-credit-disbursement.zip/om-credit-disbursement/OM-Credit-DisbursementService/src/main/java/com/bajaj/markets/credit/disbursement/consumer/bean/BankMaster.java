package com.bajaj.markets.credit.disbursement.consumer.bean;


public class BankMaster {

	private Long bankMasterKey;
	
	private String bankCode;
	private String bankName;
	private Integer isActive;
	private Integer btFacilityAvailable;
	private String preferredMode; 

	public Long getBankMasterKey() {
		
		return bankMasterKey;
	}

	public void setBankMasterKey(Long bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public Integer getBtFacilityAvailable() {
		return btFacilityAvailable;
	}

	public void setBtFacilityAvailable(Integer btFacilityAvailable) {
		this.btFacilityAvailable = btFacilityAvailable;
	}

	public String getPreferredMode() {
		return preferredMode;
	}

	public void setPreferredMode(String preferredMode) {
		this.preferredMode = preferredMode;
	}
	
	
}
