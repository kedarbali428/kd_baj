package com.bajaj.markets.credit.disbursement.consumer.bean;

public class UserInfo {

	private String name;
	private String applicantKey;
	private Long mobileNumber;
	private String emailId;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}
	
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "UserInfo [name=" + name + ", applicantKey=" + applicantKey + ", mobileNumber=" + mobileNumber
				+ ", emailId=" + emailId + "]";
	}
	
}
