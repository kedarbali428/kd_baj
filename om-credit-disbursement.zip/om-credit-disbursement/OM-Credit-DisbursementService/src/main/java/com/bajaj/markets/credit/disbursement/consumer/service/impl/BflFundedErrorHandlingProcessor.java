package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.BflErrorProcessorVariables;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.google.gson.Gson;

@Component("BflFundedErrorHandlingProcessor")
public class BflFundedErrorHandlingProcessor extends BflFundedDisbursementProcessor {

	@Value("${api.ominsuranceapplicationdomainservice.getDisbError.GET.url}")
	private String getDisbErrorUrl;

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	private static final String CLASS_NAME = BflFundedErrorHandlingProcessor.class.getCanonicalName();

	public void processBFLFundedDisbursementErrors(FundedDisbursementRequestBean request) {

		BflErrorProcessorVariables processorVariables = new BflErrorProcessorVariables();
		FundedDisbursementEventRequestBean fundedRequest = disbursementUtil.fetchFundedDisbRequestForRetry(request);
		DisbursementTrackerBean disbursementTrackerBean = fetchDisbursementErrorDetails(fundedRequest);
		String disbFailedStage = disbursementTrackerBean.getDisbursmentstage();
		switch (disbFailedStage) {

		case DisbursementConstants.CREATE_CUSTOMER:
			handlefromCustomerFailure(null, disbursementTrackerBean, request, processorVariables);
			break;

		case DisbursementConstants.CREATE_LOAN:
			handlefromLoanFailure(null, disbursementTrackerBean, request, processorVariables);
			break;

		}

	}

	public void processRetryErrors(FundedDisbursementRequestBean bean) {
		BflErrorProcessorVariables processorVariables=new BflErrorProcessorVariables() ;
		processorVariables.setErrorFlag(true);
		FundedDisbursementEventRequestBean fundedRequest = preRetryErrorProcess(bean);
		switch (bean.getStage()) {
		case DisbursementConstants.CREATE_CUSTOMER:
			handlefromCustomerFailure(fundedRequest, null, bean, processorVariables);
			break;

		case DisbursementConstants.CREATE_LOAN:
			handlefromLoanFailure(fundedRequest, null, bean, processorVariables);
			break;
		}

	}

	public void handlefromCustomerFailure(FundedDisbursementEventRequestBean request,
			DisbursementTrackerBean disbursementTrackerBean, FundedDisbursementRequestBean retryBean, BflErrorProcessorVariables processorVariables) {
		if (null != disbursementTrackerBean) {
			createCustomer(request);
			createLoan(request, processorVariables.isErrorFlag());
		} else {
			preRetryErrorProcess(retryBean);
			createCustomer(request);
			createLoan(request, processorVariables.isErrorFlag());
			postRetryErrorProcess(retryBean);
		}
	}

	public void handlefromLoanFailure(FundedDisbursementEventRequestBean request,
			DisbursementTrackerBean disbursementTrackerBean, FundedDisbursementRequestBean retryBean, BflErrorProcessorVariables processorVariables) {

		if (null != disbursementTrackerBean) {
			createLoan(request, processorVariables.isErrorFlag());
		} else {
			processorVariables.setErrorFlag(true);
			createLoan(request, processorVariables.isErrorFlag());
			postRetryErrorProcess(retryBean);
		}
	}

	public FundedDisbursementEventRequestBean preRetryErrorProcess(FundedDisbursementRequestBean retryBean) {
		return disbursementUtil.fetchFundedDisbRequestForRetry(retryBean);
	}

	@SuppressWarnings("unchecked")
	public DisbursementTrackerBean fetchDisbursementErrorDetails(FundedDisbursementEventRequestBean request) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  fetchDisbursementErrorDetails: " + request.getApplicationId());
		String activeTranchKey = request.getApplicationDetails().getPaymentQuoteId();
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  fetchDisbursementErrorDetails Starts for tranch: " + activeTranchKey);
		Map<String, String> params = new HashMap<>();
		params.put("tranchKey", activeTranchKey);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getDisbErrorUrl, String.class, params, null, new HttpHeaders());
		Gson gson = new Gson();
		List<DisbursementTrackerBean> disbursementTrackerBeanLst = new ArrayList<DisbursementTrackerBean>();
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody() && !excuteRestCall.getBody().isEmpty()
					&& excuteRestCall.getBody().contains("disbursmentstage")) {
				DisbursementTrackerBean[] list = gson.fromJson(excuteRestCall.getBody().toString(),
						DisbursementTrackerBean[].class);
				disbursementTrackerBeanLst.addAll(Arrays.asList(list));
				return disbursementTrackerBeanLst.get(0);
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchDisbursementErrorDetails .");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  fetchDisbursementErrorDetails Ends for tranch: " + activeTranchKey);
		return disbursementTrackerBean;
	}

	public void postRetryErrorProcess(FundedDisbursementRequestBean retryBean) {
		RetryRegistrationBean existingRecords = null;
		existingRecords = disbursementUtil.fetchExistingTransaction(retryBean.getTransactionId(),
				retryBean.getApplicationId(), new HttpHeaders());
		if (null != existingRecords) {
			existingRecords.setErrorKey(existingRecords.getErrorKey());
			existingRecords.setRetrySuccessFlg(true);
			existingRecords.setActiveFlg(false);
			disbursementUtil.saveretrytransaction(retryBean.getTransactionId(), retryBean.getApplicationId(),
					existingRecords, new HttpHeaders());
		}
	}

}
