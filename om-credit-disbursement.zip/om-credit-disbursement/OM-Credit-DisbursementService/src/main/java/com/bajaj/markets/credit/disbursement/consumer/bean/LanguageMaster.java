package com.bajaj.markets.credit.disbursement.consumer.bean;

public class LanguageMaster {

	private Long langkey;

	private String langcode;

	public Long getLangkey() {
		return langkey;
	}

	public void setLangkey(Long langkey) {
		this.langkey = langkey;
	}

	public String getLangcode() {
		return langcode;
	}

	public void setLangcode(String langcode) {
		this.langcode = langcode;
	}
	
	
}
