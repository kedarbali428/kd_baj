package com.bajaj.markets.credit.disbursement.consumer.bean;

public class MaritalStatusMaster {

	private Long maritalStatusKey;

	private String maritalStatusCode;

	public Long getMaritalStatusKey() {
		return maritalStatusKey;
	}

	public void setMaritalStatusKey(Long maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}

	public String getMaritalStatusCode() {
		return maritalStatusCode;
	}

	public void setMaritalStatusCode(String maritalStatusCode) {
		this.maritalStatusCode = maritalStatusCode;
	}

}
