package com.bajaj.markets.credit.disbursement.consumer.bean;

public class FinanceDetailBean {

	private String applicationNo;
	private String cif;
	private String finType;
	private String product;
	private String finCcy;
	private String finBranch;
	private String profitDaysBasis;
	private String finAmount;
	private String finAssetValue;
	private String downPayBank;
	private String downPaySupl;
	private String finRepayMethod;
	private String finStartDate;
	private String allowGrcPeriod;
	private String tdsApplicable;
	private String manualSchedule;
	private String planDeferCount;
	private String stepFinance;
	private String alwManualSteps;
	private String stepPolicy;
	private String stepType;
	private String grcTerms;
	private String grcPeriodEndDate;
	private String grcRateBasis;
	private String grcPftRate;
	private String grcBaseRate;
	private String grcSpecialRate;
	private String grcMargin;
	private String grcProfitDaysBasis;
	private String grcPftFrq;
	private String nextGrcPftDate;
	private String grcCpzFrq;
	private String nextGrcCpzDate;
	private String allowGrcRepay;
	private String grcSchdMthd;
	private String grcMinRate;
	private String grcMaxRate;
	private String grcAdvPftRate;
	private String grcAdvBaseRate;
	private String grcAdvMargin;
	private String numberOfTerms;
	private String reqRepayAmount;
	private String repayRateBasis;
	private String repaySpecialRate;
	private String repayMargin;
	private String scheduleMethod;
	private String repayBaseRate;
	private String repayPftRate;
	private String repayFrq;
	private String nextRepayDate;
	private String repayPftFrq;
	private String nextRepayPftDate;
	private String repayRvwFrq;
	private String nextRepayRvwDate;
	private String repayCpzFrq;
	private String nextRepayCpzDate;
	private String maturityDate;
	private String finRepayPftOnFrq;
	private String repayMinRate;
	private String repayMaxRate;
	private String repayAdvPftRate;
	private String repayAdvBaseRate;
	private String repayAdvMargin;
	private String supplementRent;
	private String increasedCost;
	private String rolloverFrq;
	private String nextRolloverDate;
	private String alwBpiTreatment;
	private String dftBpiTreatment;
	private String planEMIHAlw;
	private String planEMIHMethod;
	private String planEMIHMaxPerYear;
	private String planEMIHMax;
	private String planEMIHLockPeriod;
	private String planEMICpz;
	private String finContractDate;
	private String finPurpose;
	private String finLimitRef;
	private String finCommitmentRef;
	private String repayAccountId;
	private String depreciationFrq;
	private String dsaCode;
	private String salesDepartment;
	private String dmaCode;
	private String accountsOfficer;
	private String referralId;
	private String quickDisb;
	private String unPlanEMIHLockPeriod;
	private String unPlanEMICpz;
	private String reAgeCpz;
	private String maxUnplannedEmi;
	private String maxReAgeHolidays;
	private String alwFlexi;
	private String flexiType;
	private String relationshipOfficer;
	private String promotionCode;

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getFinType() {
		return finType;
	}

	public void setFinType(String finType) {
		this.finType = finType;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getFinCcy() {
		return finCcy;
	}

	public void setFinCcy(String finCcy) {
		this.finCcy = finCcy;
	}

	public String getFinBranch() {
		return finBranch;
	}

	public void setFinBranch(String finBranch) {
		this.finBranch = finBranch;
	}

	public String getProfitDaysBasis() {
		return profitDaysBasis;
	}

	public void setProfitDaysBasis(String profitDaysBasis) {
		this.profitDaysBasis = profitDaysBasis;
	}

	public String getFinAmount() {
		return finAmount;
	}

	public void setFinAmount(String finAmount) {
		this.finAmount = finAmount;
	}

	public String getFinAssetValue() {
		return finAssetValue;
	}

	public void setFinAssetValue(String finAssetValue) {
		this.finAssetValue = finAssetValue;
	}

	public String getDownPayBank() {
		return downPayBank;
	}

	public void setDownPayBank(String downPayBank) {
		this.downPayBank = downPayBank;
	}

	public String getDownPaySupl() {
		return downPaySupl;
	}

	public void setDownPaySupl(String downPaySupl) {
		this.downPaySupl = downPaySupl;
	}

	public String getFinStartDate() {
		return finStartDate;
	}

	public void setFinStartDate(String finStartDate) {
		this.finStartDate = finStartDate;
	}

	public String getAllowGrcPeriod() {
		return allowGrcPeriod;
	}

	public void setAllowGrcPeriod(String allowGrcPeriod) {
		this.allowGrcPeriod = allowGrcPeriod;
	}

	public String getTdsApplicable() {
		return tdsApplicable;
	}

	public void setTdsApplicable(String tdsApplicable) {
		this.tdsApplicable = tdsApplicable;
	}

	public String getManualSchedule() {
		return manualSchedule;
	}

	public void setManualSchedule(String manualSchedule) {
		this.manualSchedule = manualSchedule;
	}

	public String getPlanDeferCount() {
		return planDeferCount;
	}

	public void setPlanDeferCount(String planDeferCount) {
		this.planDeferCount = planDeferCount;
	}

	public String getStepFinance() {
		return stepFinance;
	}

	public void setStepFinance(String stepFinance) {
		this.stepFinance = stepFinance;
	}

	public String getAlwManualSteps() {
		return alwManualSteps;
	}

	public void setAlwManualSteps(String alwManualSteps) {
		this.alwManualSteps = alwManualSteps;
	}

	public String getStepPolicy() {
		return stepPolicy;
	}

	public void setStepPolicy(String stepPolicy) {
		this.stepPolicy = stepPolicy;
	}

	public String getStepType() {
		return stepType;
	}

	public void setStepType(String stepType) {
		this.stepType = stepType;
	}

	public String getGrcTerms() {
		return grcTerms;
	}

	public void setGrcTerms(String grcTerms) {
		this.grcTerms = grcTerms;
	}

	public String getGrcPeriodEndDate() {
		return grcPeriodEndDate;
	}

	public void setGrcPeriodEndDate(String grcPeriodEndDate) {
		this.grcPeriodEndDate = grcPeriodEndDate;
	}

	public String getGrcRateBasis() {
		return grcRateBasis;
	}

	public void setGrcRateBasis(String grcRateBasis) {
		this.grcRateBasis = grcRateBasis;
	}

	public String getGrcPftRate() {
		return grcPftRate;
	}

	public void setGrcPftRate(String grcPftRate) {
		this.grcPftRate = grcPftRate;
	}

	public String getGrcBaseRate() {
		return grcBaseRate;
	}

	public void setGrcBaseRate(String grcBaseRate) {
		this.grcBaseRate = grcBaseRate;
	}

	public String getGrcSpecialRate() {
		return grcSpecialRate;
	}

	public void setGrcSpecialRate(String grcSpecialRate) {
		this.grcSpecialRate = grcSpecialRate;
	}

	public String getGrcMargin() {
		return grcMargin;
	}

	public void setGrcMargin(String grcMargin) {
		this.grcMargin = grcMargin;
	}

	public String getGrcProfitDaysBasis() {
		return grcProfitDaysBasis;
	}

	public void setGrcProfitDaysBasis(String grcProfitDaysBasis) {
		this.grcProfitDaysBasis = grcProfitDaysBasis;
	}

	public String getGrcPftFrq() {
		return grcPftFrq;
	}

	public void setGrcPftFrq(String grcPftFrq) {
		this.grcPftFrq = grcPftFrq;
	}

	public String getNextGrcPftDate() {
		return nextGrcPftDate;
	}

	public void setNextGrcPftDate(String nextGrcPftDate) {
		this.nextGrcPftDate = nextGrcPftDate;
	}

	public String getGrcCpzFrq() {
		return grcCpzFrq;
	}

	public void setGrcCpzFrq(String grcCpzFrq) {
		this.grcCpzFrq = grcCpzFrq;
	}

	public String getNextGrcCpzDate() {
		return nextGrcCpzDate;
	}

	public void setNextGrcCpzDate(String nextGrcCpzDate) {
		this.nextGrcCpzDate = nextGrcCpzDate;
	}

	public String getAllowGrcRepay() {
		return allowGrcRepay;
	}

	public void setAllowGrcRepay(String allowGrcRepay) {
		this.allowGrcRepay = allowGrcRepay;
	}

	public String getGrcSchdMthd() {
		return grcSchdMthd;
	}

	public void setGrcSchdMthd(String grcSchdMthd) {
		this.grcSchdMthd = grcSchdMthd;
	}

	public String getGrcMinRate() {
		return grcMinRate;
	}

	public void setGrcMinRate(String grcMinRate) {
		this.grcMinRate = grcMinRate;
	}

	public String getGrcMaxRate() {
		return grcMaxRate;
	}

	public void setGrcMaxRate(String grcMaxRate) {
		this.grcMaxRate = grcMaxRate;
	}

	public String getGrcAdvPftRate() {
		return grcAdvPftRate;
	}

	public void setGrcAdvPftRate(String grcAdvPftRate) {
		this.grcAdvPftRate = grcAdvPftRate;
	}

	public String getGrcAdvBaseRate() {
		return grcAdvBaseRate;
	}

	public void setGrcAdvBaseRate(String grcAdvBaseRate) {
		this.grcAdvBaseRate = grcAdvBaseRate;
	}

	public String getGrcAdvMargin() {
		return grcAdvMargin;
	}

	public void setGrcAdvMargin(String grcAdvMargin) {
		this.grcAdvMargin = grcAdvMargin;
	}

	public String getNumberOfTerms() {
		return numberOfTerms;
	}

	public void setNumberOfTerms(String numberOfTerms) {
		this.numberOfTerms = numberOfTerms;
	}

	public String getReqRepayAmount() {
		return reqRepayAmount;
	}

	public void setReqRepayAmount(String reqRepayAmount) {
		this.reqRepayAmount = reqRepayAmount;
	}

	public String getRepayRateBasis() {
		return repayRateBasis;
	}

	public void setRepayRateBasis(String repayRateBasis) {
		this.repayRateBasis = repayRateBasis;
	}

	public String getRepaySpecialRate() {
		return repaySpecialRate;
	}

	public void setRepaySpecialRate(String repaySpecialRate) {
		this.repaySpecialRate = repaySpecialRate;
	}

	public String getRepayMargin() {
		return repayMargin;
	}

	public void setRepayMargin(String repayMargin) {
		this.repayMargin = repayMargin;
	}

	public String getScheduleMethod() {
		return scheduleMethod;
	}

	public void setScheduleMethod(String scheduleMethod) {
		this.scheduleMethod = scheduleMethod;
	}

	public String getRepayBaseRate() {
		return repayBaseRate;
	}

	public void setRepayBaseRate(String repayBaseRate) {
		this.repayBaseRate = repayBaseRate;
	}

	public String getRepayPftRate() {
		return repayPftRate;
	}

	public void setRepayPftRate(String repayPftRate) {
		this.repayPftRate = repayPftRate;
	}

	public String getRepayFrq() {
		return repayFrq;
	}

	public void setRepayFrq(String repayFrq) {
		this.repayFrq = repayFrq;
	}

	public String getNextRepayDate() {
		return nextRepayDate;
	}

	public void setNextRepayDate(String nextRepayDate) {
		this.nextRepayDate = nextRepayDate;
	}

	public String getRepayPftFrq() {
		return repayPftFrq;
	}

	public void setRepayPftFrq(String repayPftFrq) {
		this.repayPftFrq = repayPftFrq;
	}

	public String getNextRepayPftDate() {
		return nextRepayPftDate;
	}

	public void setNextRepayPftDate(String nextRepayPftDate) {
		this.nextRepayPftDate = nextRepayPftDate;
	}

	public String getRepayRvwFrq() {
		return repayRvwFrq;
	}

	public void setRepayRvwFrq(String repayRvwFrq) {
		this.repayRvwFrq = repayRvwFrq;
	}

	public String getNextRepayRvwDate() {
		return nextRepayRvwDate;
	}

	public void setNextRepayRvwDate(String nextRepayRvwDate) {
		this.nextRepayRvwDate = nextRepayRvwDate;
	}

	public String getRepayCpzFrq() {
		return repayCpzFrq;
	}

	public void setRepayCpzFrq(String repayCpzFrq) {
		this.repayCpzFrq = repayCpzFrq;
	}

	public String getNextRepayCpzDate() {
		return nextRepayCpzDate;
	}

	public void setNextRepayCpzDate(String nextRepayCpzDate) {
		this.nextRepayCpzDate = nextRepayCpzDate;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getFinRepayPftOnFrq() {
		return finRepayPftOnFrq;
	}

	public void setFinRepayPftOnFrq(String finRepayPftOnFrq) {
		this.finRepayPftOnFrq = finRepayPftOnFrq;
	}

	public String getRepayMinRate() {
		return repayMinRate;
	}

	public void setRepayMinRate(String repayMinRate) {
		this.repayMinRate = repayMinRate;
	}

	public String getRepayMaxRate() {
		return repayMaxRate;
	}

	public void setRepayMaxRate(String repayMaxRate) {
		this.repayMaxRate = repayMaxRate;
	}

	public String getRepayAdvPftRate() {
		return repayAdvPftRate;
	}

	public void setRepayAdvPftRate(String repayAdvPftRate) {
		this.repayAdvPftRate = repayAdvPftRate;
	}

	public String getRepayAdvBaseRate() {
		return repayAdvBaseRate;
	}

	public void setRepayAdvBaseRate(String repayAdvBaseRate) {
		this.repayAdvBaseRate = repayAdvBaseRate;
	}

	public String getRepayAdvMargin() {
		return repayAdvMargin;
	}

	public void setRepayAdvMargin(String repayAdvMargin) {
		this.repayAdvMargin = repayAdvMargin;
	}

	public String getSupplementRent() {
		return supplementRent;
	}

	public void setSupplementRent(String supplementRent) {
		this.supplementRent = supplementRent;
	}

	public String getIncreasedCost() {
		return increasedCost;
	}

	public void setIncreasedCost(String increasedCost) {
		this.increasedCost = increasedCost;
	}

	public String getRolloverFrq() {
		return rolloverFrq;
	}

	public void setRolloverFrq(String rolloverFrq) {
		this.rolloverFrq = rolloverFrq;
	}

	public String getNextRolloverDate() {
		return nextRolloverDate;
	}

	public void setNextRolloverDate(String nextRolloverDate) {
		this.nextRolloverDate = nextRolloverDate;
	}

	public String getAlwBpiTreatment() {
		return alwBpiTreatment;
	}

	public void setAlwBpiTreatment(String alwBpiTreatment) {
		this.alwBpiTreatment = alwBpiTreatment;
	}

	public String getDftBpiTreatment() {
		return dftBpiTreatment;
	}

	public void setDftBpiTreatment(String dftBpiTreatment) {
		this.dftBpiTreatment = dftBpiTreatment;
	}

	public String getPlanEMIHAlw() {
		return planEMIHAlw;
	}

	public void setPlanEMIHAlw(String planEMIHAlw) {
		this.planEMIHAlw = planEMIHAlw;
	}

	public String getPlanEMIHMethod() {
		return planEMIHMethod;
	}

	public void setPlanEMIHMethod(String planEMIHMethod) {
		this.planEMIHMethod = planEMIHMethod;
	}

	public String getPlanEMIHMaxPerYear() {
		return planEMIHMaxPerYear;
	}

	public void setPlanEMIHMaxPerYear(String planEMIHMaxPerYear) {
		this.planEMIHMaxPerYear = planEMIHMaxPerYear;
	}

	public String getPlanEMIHMax() {
		return planEMIHMax;
	}

	public void setPlanEMIHMax(String planEMIHMax) {
		this.planEMIHMax = planEMIHMax;
	}

	public String getPlanEMIHLockPeriod() {
		return planEMIHLockPeriod;
	}

	public void setPlanEMIHLockPeriod(String planEMIHLockPeriod) {
		this.planEMIHLockPeriod = planEMIHLockPeriod;
	}

	public String getPlanEMICpz() {
		return planEMICpz;
	}

	public void setPlanEMICpz(String planEMICpz) {
		this.planEMICpz = planEMICpz;
	}

	public String getUnPlanEMIHLockPeriod() {
		return unPlanEMIHLockPeriod;
	}

	public void setUnPlanEMIHLockPeriod(String unPlanEMIHLockPeriod) {
		this.unPlanEMIHLockPeriod = unPlanEMIHLockPeriod;
	}

	public String getUnPlanEMICpz() {
		return unPlanEMICpz;
	}

	public void setUnPlanEMICpz(String unPlanEMICpz) {
		this.unPlanEMICpz = unPlanEMICpz;
	}

	public String getReAgeCpz() {
		return reAgeCpz;
	}

	public void setReAgeCpz(String reAgeCpz) {
		this.reAgeCpz = reAgeCpz;
	}

	public String getMaxUnplannedEmi() {
		return maxUnplannedEmi;
	}

	public void setMaxUnplannedEmi(String maxUnplannedEmi) {
		this.maxUnplannedEmi = maxUnplannedEmi;
	}

	public String getMaxReAgeHolidays() {
		return maxReAgeHolidays;
	}

	public void setMaxReAgeHolidays(String maxReAgeHolidays) {
		this.maxReAgeHolidays = maxReAgeHolidays;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getFinContractDate() {
		return finContractDate;
	}

	public void setFinContractDate(String finContractDate) {
		this.finContractDate = finContractDate;
	}

	public String getFinPurpose() {
		return finPurpose;
	}

	public void setFinPurpose(String finPurpose) {
		this.finPurpose = finPurpose;
	}

	public String getFinLimitRef() {
		return finLimitRef;
	}

	public void setFinLimitRef(String finLimitRef) {
		this.finLimitRef = finLimitRef;
	}

	public String getFinCommitmentRef() {
		return finCommitmentRef;
	}

	public void setFinCommitmentRef(String finCommitmentRef) {
		this.finCommitmentRef = finCommitmentRef;
	}

	public String getFinRepayMethod() {
		return finRepayMethod;
	}

	public void setFinRepayMethod(String finRepayMethod) {
		this.finRepayMethod = finRepayMethod;
	}

	public String getRepayAccountId() {
		return repayAccountId;
	}

	public void setRepayAccountId(String repayAccountId) {
		this.repayAccountId = repayAccountId;
	}

	public String getDepreciationFrq() {
		return depreciationFrq;
	}

	public void setDepreciationFrq(String depreciationFrq) {
		this.depreciationFrq = depreciationFrq;
	}

	public String getDsaCode() {
		return dsaCode;
	}

	public void setDsaCode(String dsaCode) {
		this.dsaCode = dsaCode;
	}

	public String getSalesDepartment() {
		return salesDepartment;
	}

	public void setSalesDepartment(String salesDepartment) {
		this.salesDepartment = salesDepartment;
	}

	public String getDmaCode() {
		return dmaCode;
	}

	public void setDmaCode(String dmaCode) {
		this.dmaCode = dmaCode;
	}

	public String getAccountsOfficer() {
		return accountsOfficer;
	}

	public void setAccountsOfficer(String accountsOfficer) {
		this.accountsOfficer = accountsOfficer;
	}

	public String getReferralId() {
		return referralId;
	}

	public void setReferralId(String referralId) {
		this.referralId = referralId;
	}

	public String getQuickDisb() {
		return quickDisb;
	}

	public void setQuickDisb(String quickDisb) {
		this.quickDisb = quickDisb;
	}

	public String getAlwFlexi() {
		return alwFlexi;
	}

	public void setAlwFlexi(String alwFlexi) {
		this.alwFlexi = alwFlexi;
	}

	public String getFlexiType() {
		return flexiType;
	}

	public void setFlexiType(String flexiType) {
		this.flexiType = flexiType;
	}

	public String getRelationshipOfficer() {
		return relationshipOfficer;
	}

	public void setRelationshipOfficer(String relationshipOfficer) {
		this.relationshipOfficer = relationshipOfficer;
	}

	public String getPromotionCode() {
		return promotionCode;
	}

	public void setPromotionCode(String promotionCode) {
		this.promotionCode = promotionCode;
	}

	@Override
	public String toString() {
		return "FinanceDetailBean [applicationNo=" + applicationNo + ", cif=" + cif + ", finType=" + finType
				+ ", product=" + product + ", finCcy=" + finCcy + ", finBranch=" + finBranch + ", profitDaysBasis="
				+ profitDaysBasis + ", finAmount=" + finAmount + ", finAssetValue=" + finAssetValue + ", downPayBank="
				+ downPayBank + ", downPaySupl=" + downPaySupl + ", finRepayMethod=" + finRepayMethod
				+ ", finStartDate=" + finStartDate + ", allowGrcPeriod=" + allowGrcPeriod + ", tdsApplicable="
				+ tdsApplicable + ", manualSchedule=" + manualSchedule + ", planDeferCount=" + planDeferCount
				+ ", stepFinance=" + stepFinance + ", alwManualSteps=" + alwManualSteps + ", stepPolicy=" + stepPolicy
				+ ", stepType=" + stepType + ", grcTerms=" + grcTerms + ", grcPeriodEndDate=" + grcPeriodEndDate
				+ ", grcRateBasis=" + grcRateBasis + ", grcPftRate=" + grcPftRate + ", grcBaseRate=" + grcBaseRate
				+ ", grcSpecialRate=" + grcSpecialRate + ", grcMargin=" + grcMargin + ", grcProfitDaysBasis="
				+ grcProfitDaysBasis + ", grcPftFrq=" + grcPftFrq + ", nextGrcPftDate=" + nextGrcPftDate
				+ ", grcCpzFrq=" + grcCpzFrq + ", nextGrcCpzDate=" + nextGrcCpzDate + ", allowGrcRepay=" + allowGrcRepay
				+ ", grcSchdMthd=" + grcSchdMthd + ", grcMinRate=" + grcMinRate + ", grcMaxRate=" + grcMaxRate
				+ ", grcAdvPftRate=" + grcAdvPftRate + ", grcAdvBaseRate=" + grcAdvBaseRate + ", grcAdvMargin="
				+ grcAdvMargin + ", numberOfTerms=" + numberOfTerms + ", reqRepayAmount=" + reqRepayAmount
				+ ", repayRateBasis=" + repayRateBasis + ", repaySpecialRate=" + repaySpecialRate + ", repayMargin="
				+ repayMargin + ", scheduleMethod=" + scheduleMethod + ", repayBaseRate=" + repayBaseRate
				+ ", repayPftRate=" + repayPftRate + ", repayFrq=" + repayFrq + ", nextRepayDate=" + nextRepayDate
				+ ", repayPftFrq=" + repayPftFrq + ", nextRepayPftDate=" + nextRepayPftDate + ", repayRvwFrq="
				+ repayRvwFrq + ", nextRepayRvwDate=" + nextRepayRvwDate + ", repayCpzFrq=" + repayCpzFrq
				+ ", nextRepayCpzDate=" + nextRepayCpzDate + ", maturityDate=" + maturityDate + ", finRepayPftOnFrq="
				+ finRepayPftOnFrq + ", repayMinRate=" + repayMinRate + ", repayMaxRate=" + repayMaxRate
				+ ", repayAdvPftRate=" + repayAdvPftRate + ", repayAdvBaseRate=" + repayAdvBaseRate
				+ ", repayAdvMargin=" + repayAdvMargin + ", supplementRent=" + supplementRent + ", increasedCost="
				+ increasedCost + ", rolloverFrq=" + rolloverFrq + ", nextRolloverDate=" + nextRolloverDate
				+ ", alwBpiTreatment=" + alwBpiTreatment + ", dftBpiTreatment=" + dftBpiTreatment + ", planEMIHAlw="
				+ planEMIHAlw + ", planEMIHMethod=" + planEMIHMethod + ", planEMIHMaxPerYear=" + planEMIHMaxPerYear
				+ ", planEMIHMax=" + planEMIHMax + ", planEMIHLockPeriod=" + planEMIHLockPeriod + ", planEMICpz="
				+ planEMICpz + ", finContractDate=" + finContractDate + ", finPurpose=" + finPurpose + ", finLimitRef="
				+ finLimitRef + ", finCommitmentRef=" + finCommitmentRef + ", repayAccountId=" + repayAccountId
				+ ", depreciationFrq=" + depreciationFrq + ", dsaCode=" + dsaCode + ", salesDepartment="
				+ salesDepartment + ", dmaCode=" + dmaCode + ", accountsOfficer=" + accountsOfficer + ", referralId="
				+ referralId + ", quickDisb=" + quickDisb + ", unPlanEMIHLockPeriod=" + unPlanEMIHLockPeriod
				+ ", unPlanEMICpz=" + unPlanEMICpz + ", reAgeCpz=" + reAgeCpz + ", maxUnplannedEmi=" + maxUnplannedEmi
				+ ", maxReAgeHolidays=" + maxReAgeHolidays + ", alwFlexi=" + alwFlexi + ", flexiType=" + flexiType
				+ ", relationshipOfficer=" + relationshipOfficer + ", promotionCode=" + promotionCode + "]";
	}

}
