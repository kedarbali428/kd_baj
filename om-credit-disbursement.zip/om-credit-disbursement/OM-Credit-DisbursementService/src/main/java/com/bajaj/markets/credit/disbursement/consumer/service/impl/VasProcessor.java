package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.AddressInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.AppBundleDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.AppPlanDetCostBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCustomerPennantRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.ExtendedDetailBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ExtendedFieldBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FeeDetailsBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedAddressRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.UserProfile;
import com.bajaj.markets.credit.disbursement.consumer.bean.VasBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.VasProcessorVariables;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class VasProcessor {

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Value("${api.omcreditapplicationservice.bundleDetails.get.url}")
	private String bundleDetailsUrl;

	@Value("${api.omvasapplicationservice.costDetails.get.url}")
	private String vasDetailsUrl;

	@Value("${api.omcreditapplicationservice.vas.disbursementeventraise.PUT.url}")
	private String vasDisbursementInitEventRaiseUrl;

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	DisbursementUtil disbursementUtil;

	@Autowired
	CustomerProcessor customerProcessor;

	private static final String CLASS_NAME = VasProcessor.class.getName();

	public List<VasBean> getVasList(GlobalDataBean data, List<FeeDetailsBean> feeDetailslst, String pennantDt) {
		VasProcessorVariables processorVariables = new VasProcessorVariables();
		List<VasBean> vasList = getVasForVasApplications(data, feeDetailslst, pennantDt, processorVariables);
		return vasList;
	}

	@SuppressWarnings("unchecked")
	public List<AppPlanDetCostBean> fetchPricingDetails(GlobalDataBean data, List<FeeDetailsBean> feeDetailslst,
			VasProcessorVariables processorVariables) {
		AppBundleDetails appBundleDetails = new AppBundleDetails();
		List<AppBundleDetails> appBundleDetailsLst = new ArrayList<AppBundleDetails>();
		List<AppPlanDetCostBean> listAppPlanDetCostBean = new ArrayList<AppPlanDetCostBean>();
		List<AppPlanDetCostBean> latestEntries = new ArrayList<AppPlanDetCostBean>();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", data.getApplicationKey());
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("authtoken", data.getHeaders().get("authtoken"));
		headers.add("cmptcorrid", data.getHeaders().get("cmptcorrid"));
		headers.add("guardtoken", data.getHeaders().get("guardtoken"));
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, bundleDetailsUrl, String.class, params, null, headers);
		Gson gson = new Gson();

		try {
			AppBundleDetails[] applst = gson.fromJson(excuteRestCall.getBody().toString(), AppBundleDetails[].class);
			appBundleDetailsLst.addAll(Arrays.asList(applst));
			for (AppBundleDetails activeDetail : appBundleDetailsLst) {
				if (activeDetail.getBundleSelected()) {
					processorVariables.setIsFpp(true);
					;
					if (activeDetail.getSource().equalsIgnoreCase("EP")
							&& activeDetail.getStatus().equalsIgnoreCase("APPROVED")) {
						appBundleDetails = activeDetail;
						break;
					} else if (activeDetail.getSource().equalsIgnoreCase("JOURNEY")
							&& activeDetail.getStatus().equalsIgnoreCase("APPROVED")) {
						appBundleDetails = appBundleDetailsLst.get(0);
					}
				}
			}

			if (null != appBundleDetails.getBundleApplicationKey()) {
				Map<String, String> param = new HashMap<>();
				param.put("applicationKey", appBundleDetails.getBundleApplicationKey().toString());
				ResponseEntity<String> excutevasRestCall = (ResponseEntity<String>) disbursementBusinessHelper
						.invokeRestEndpoint(HttpMethod.GET, vasDetailsUrl, String.class, param, null, headers);
				AppPlanDetCostBean[] lst = gson.fromJson(excutevasRestCall.getBody().toString(),
						AppPlanDetCostBean[].class);
				listAppPlanDetCostBean.addAll(Arrays.asList(lst));
				for (AppPlanDetCostBean latestEntry : listAppPlanDetCostBean) {
					if (latestEntry.getSource().equalsIgnoreCase("EMPLOYEE_PORTAL")
							&& latestEntry.getStatus().equalsIgnoreCase("APPROVED")) {
						if (!latestEntries.isEmpty()) {
							latestEntries.remove(0);
						}
						latestEntries.add(latestEntry);
						break;
					} else if (latestEntry.getSource().equalsIgnoreCase("JOURNEY")
							&& latestEntry.getStatus().equalsIgnoreCase("APPROVED")) {
						latestEntries.add(latestEntry);
					}

				}

				return latestEntries;
			}

		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchPricingDetails .");
		}

		return listAppPlanDetCostBean;
	}

	private List<VasBean> getVasForVasApplications(GlobalDataBean data, List<FeeDetailsBean> feeDetailslst,
			String pennantDt, VasProcessorVariables processorVariables) {
		List<VasBean> vasList = new ArrayList<>();
		VasBean vas;
		List<AppPlanDetCostBean> vasApplications = fetchPricingDetails(data, feeDetailslst, processorVariables);

		if (null != vasApplications && !vasApplications.isEmpty()) {
			List<ExtendedDetailBean> vasExtendedDetailList = new ArrayList<>();
			ExtendedDetailBean extendedDetailBean = new ExtendedDetailBean();
			ExtendedFieldBean vasExtendedField = new ExtendedFieldBean();
			List<ExtendedFieldBean> vasExtendedFieldList = new ArrayList<>();
			for (AppPlanDetCostBean vasApplication : vasApplications) {
				vas = new VasBean();
				vas.setProduct("FPP");
				vas.setPostingAgainst(DisbursementConstants.FINANCE);
				vas.setFee(String.valueOf(vasApplication.getActualPrice()));
				vas.setFeePaymentMode(DisbursementConstants.FEE_PAYMENT_MODE_CASH);
				if (DisbursementConstants.VAS_PROD_CODE_VASFFR01.equals(data.getL3ProductCode())
						|| DisbursementConstants.VAS_PROD_CODE_VASPD01.equals(data.getL3ProductCode())) {
					vasExtendedField.setFieldName(DisbursementConstants.EXT_FIELD_PRDATE);
					vasExtendedField.setFieldValue(pennantDt);
					vasExtendedFieldList.add(vasExtendedField);
					extendedDetailBean.setExtendedFields(vasExtendedFieldList);
					vasExtendedDetailList.add(extendedDetailBean);
					vas.setExtendedDetails(vasExtendedDetailList);
				}
				if (processorVariables.getIsFpp()) {
					FeeDetailsBean fee = new FeeDetailsBean();
					fee.setFeeCode("{FPP}");
					fee.setFeeAmount(new BigDecimal(vasApplication.getActualPrice()));
					fee.setFeeMethod("DISB");
					fee.setWaiverAmount(new BigDecimal(0));
					fee.setPaidAmount(new BigDecimal(0));
					feeDetailslst.add(fee);
				}

				mapInsuranceFields(vasExtendedDetailList, vasExtendedFieldList, extendedDetailBean, vas, data);
				vasList.add(vas);
			}
		}
		return vasList;
	}

	@SuppressWarnings("unchecked")
	public String vasDisbursementInitEventRaiseExt(String applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Start - vasDisbursementInitEventRaiseExt. applicationId : " + applicationId);
		String vasDisbEventResp = null;
		try {
			HashMap<String, String> params = new HashMap<>();
			params.put("applicationKey", applicationId);
			ObjectMapper mapper = new ObjectMapper();
			mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

			ResponseEntity<String> vasDisbEventExtRespEntity = (ResponseEntity<String>) disbursementBusinessHelper
					.invokeRestEndpoint(HttpMethod.PUT, vasDisbursementInitEventRaiseUrl, String.class, params, null,
							headers);
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Response of vasDisbursementInitEventRaiseExt external service call : "
							+ vasDisbEventExtRespEntity);
			if (vasDisbEventExtRespEntity.getStatusCode().equals(HttpStatus.OK)) {
				vasDisbEventResp = vasDisbEventExtRespEntity.getBody().toString();
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Invalid status from vasDisbursementInitEventRaiseExt Ext : "
								+ vasDisbEventExtRespEntity.getStatusCode());
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Vas Policy Issue Init event raise failed");
				// No exception thrown to ensure no flow break
			}
		} catch (DisbursementServiceException e) {
			// No exception thrown to ensure no flow break
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Exception occurred in vasDisbursementInitEventRaiseExt call: " + e);
			// throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Exception occurred in vasDisbursementInitEventRaiseExt call: " + e);
			// No exception thrown to ensure no flow break
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"End - vasDisbursementInitEventRaiseExt." + "\n Response String : " + vasDisbEventResp);
		return vasDisbEventResp;
	}

	public void mapInsuranceFields(List<ExtendedDetailBean> vasExtendedDetailList,
			List<ExtendedFieldBean> vasExtendedFieldList, ExtendedDetailBean extendedDetailBean, VasBean vas,
			GlobalDataBean data) {

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("authtoken", data.getHeaders().get("authtoken"));
		headers.add("cmptcorrid", data.getHeaders().get("cmptcorrid"));
		headers.add("guardtoken", data.getHeaders().get("guardtoken"));

		ExtendedFieldBean vasExtendedField = new ExtendedFieldBean();
		/*
		 * vasExtendedField.setFieldName(DisbursementConstants.INSURANCEID);
		 * vasExtendedField.setFieldValue(data.getApplicationKey());
		 * vasExtendedFieldList.add(vasExtendedField);
		 */

		/*
		 * vasExtendedField.setFieldName(DisbursementConstants.INSUR_FORM_NO);
		 * vasExtendedField.setFieldValue("");
		 */

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.APPLICANTTYPE);
		vasExtendedField.setFieldValue(DisbursementConstants.PRIMARY_APPLICANT);
		vasExtendedFieldList.add(vasExtendedField);

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.CIF);
		vasExtendedField.setFieldValue(disbursementUtil.fetchCifId(Long.valueOf(data.getApplicationKey()),
				Long.parseLong(data.getApplicantKey())));
		vasExtendedFieldList.add(vasExtendedField);

		vasExtendedField = new ExtendedFieldBean();
		List<UserProfile> userProfileList = disbursementUtil.getUserDetails(data.getApplicationKey(), headers);
		UserProfile primary = userProfileList.stream()
				.filter(x -> x.getApplicationUserAttributeType().equals(DisbursementConstants.MAIN_APPLICANT))
				.collect(Collectors.toList()).get(0);
		vasExtendedField.setFieldName(DisbursementConstants.DOB);
		vasExtendedField.setFieldValue(primary.getDateOfBirth() + "T00:00:00");
		vasExtendedFieldList.add(vasExtendedField);

		/*
		 * if (null != primary.getDateOfBirth()) { DateFormat dateFormat = new
		 * SimpleDateFormat("yyyy-MM-dd"); String strDate = primary.getDateOfBirth();
		 * LocalDate birthDate = LocalDate.parse(strDate); vasExtendedField = new
		 * ExtendedFieldBean();
		 * vasExtendedField.setFieldName(DisbursementConstants.AGE);
		 * vasExtendedField.setFieldValue(Integer.toString(Period.between(birthDate,
		 * LocalDate.now()).getYears())); vasExtendedFieldList.add(vasExtendedField); }
		 */

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.GENDER);
		vasExtendedField.setFieldValue(disbursementUtil.fetchGenderDescDetails(primary.getGenderKey(), headers));
		vasExtendedFieldList.add(vasExtendedField);

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.SUMASSURED);
		vasExtendedField.setFieldValue("1");
		vasExtendedFieldList.add(vasExtendedField);

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.POLICY_TERM);
		vasExtendedField.setFieldValue("1");
		vasExtendedFieldList.add(vasExtendedField);

		/*
		 * vasExtendedField.setFieldName(DisbursementConstants.BR_DISPATCH_DATE);
		 * vasExtendedField.setFieldValue("");
		 * vasExtendedFieldList.add(vasExtendedField);
		 * vasExtendedField.setFieldName(DisbursementConstants.CRITICALILLNESS);
		 * vasExtendedField.setFieldValue("");
		 * vasExtendedFieldList.add(vasExtendedField);
		 * vasExtendedField.setFieldName(DisbursementConstants.DGH);
		 * vasExtendedField.setFieldValue("");
		 * vasExtendedFieldList.add(vasExtendedField);
		 */
		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.INSUR_PARTY_TYPE);
		vasExtendedField.setFieldValue("PARTY TO LOAN");
		vasExtendedFieldList.add(vasExtendedField);

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.ADDRESS);
		String address = mapAddress(data);
		if (null != address) {
			if (address.length() > 100)
				vasExtendedField.setFieldValue(address.substring(0, 99).trim());
			else
				vasExtendedField.setFieldValue(address.trim());
		} else {
			vasExtendedField.setFieldValue("");
		}
		vasExtendedFieldList.add(vasExtendedField);

		extendedDetailBean.setExtendedFields(vasExtendedFieldList);
		vasExtendedDetailList.add(extendedDetailBean);
		vas.setExtendedDetails(vasExtendedDetailList);
	}

	public String mapAddress(GlobalDataBean data) {
		String address = null;
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("authtoken", data.getHeaders().get("authtoken"));
		headers.add("cmptcorrid", data.getHeaders().get("cmptcorrid"));
		headers.add("guardtoken", data.getHeaders().get("guardtoken"));

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "mapAddress : " + data.getApplicationKey());
		Long prodcatKey = data.getL2ProductKey();
		CreateCustomerPennantRequest customerRequest = customerProcessor.fetchCustomerPennantRequestForSOL(
				data.getApplicationKey(), data.getL3ProductKey(), prodcatKey, headers);

		List<AddressInfo> addressList = customerRequest.getAddresses();
		for (AddressInfo currAddress : addressList) {

			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"mapAddress addressType: " + currAddress.getAddrType());
			if (currAddress.getAddrType().equalsIgnoreCase(DisbursementConstants.ADDRESS_TYPE_CURRENT)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "mapAddress Current addressType: ");
				address = (null != currAddress.getBuildingNo() ? "buildingNo " + currAddress.getBuildingNo() : "")
						+ (null != currAddress.getStreet() ? " Street " + currAddress.getStreet() : "")
						+ (null != currAddress.getFlatNo() ? currAddress.getFlatNo() : "")
						+ (null != currAddress.getAddrLine1() ? " addrLine1 " + currAddress.getAddrLine1() : " ")
						+ (null != currAddress.getAddrLine2() ? " addrLine2 " + currAddress.getAddrLine2() : "") + ""
						+ (null != currAddress.getCountry() ? currAddress.getCountry() : "") + " "
						+ (null != currAddress.getState() ? currAddress.getState() : "") + " "
						+ (null != currAddress.getCity() ? currAddress.getCity() : "") + " "
						+ (null != currAddress.getPinCode() ? currAddress.getPinCode() : "");
			}

		}
		return address;
	}

	public List<VasBean> getVasListForFunded(GlobalDataBean data, List<FeeDetailsBean> feeDetailslst, String pennantDt,
			FundedDisbursementEventRequestBean fundedRequest) {
		List<VasBean> vasList = new ArrayList<>();
		List<ExtendedDetailBean> vasExtendedDetailList = new ArrayList<>();
		List<ExtendedFieldBean> vasExtendedFieldList = new ArrayList<>();
		ExtendedDetailBean extendedDetailBean = new ExtendedDetailBean();
		ExtendedFieldBean vasExtendedField = new ExtendedFieldBean();
		VasBean vas = new VasBean();
		vas.setPostingAgainst(DisbursementConstants.FINANCE);
		vas.setVasReference(fetchInsuranceVasReference(fundedRequest.getApplicationDetails().getQuoteNumber()));
		vas.setFee(fundedRequest.getApplicationDetails().getFundingDetails().getFundingAmount());
		vas.setFeePaymentMode(DisbursementConstants.FEE_PAYMENT_MODE_CASH);
		if (DisbursementConstants.VAS_PROD_CODE_VASFFR01.equals(data.getL3ProductCode())
				|| DisbursementConstants.VAS_PROD_CODE_VASPD01.equals(data.getL3ProductCode())) {

			vasExtendedField.setFieldName(DisbursementConstants.EXT_FIELD_PRDATE);
			vasExtendedField.setFieldValue(pennantDt);
			vasExtendedFieldList.add(vasExtendedField);
			extendedDetailBean.setExtendedFields(vasExtendedFieldList);
			vasExtendedDetailList.add(extendedDetailBean);
			vas.setExtendedDetails(vasExtendedDetailList);
		}

		mapInsuranceDetailsForFunded(vasList, vas, fundedRequest, vasExtendedFieldList, extendedDetailBean,
				vasExtendedDetailList);
		return vasList;
	}

	private String fetchInsuranceVasReference(String quoteNumber) {
		String fundedVasRef = quoteNumber.substring(quoteNumber.indexOf("-", quoteNumber.indexOf("-") + 1) + 1);

		return fundedVasRef;
	}

	public void mapInsuranceDetailsForFunded(List<VasBean> vasList, VasBean vas,
			FundedDisbursementEventRequestBean fundedRequest, List<ExtendedFieldBean> vasExtendedFieldList,
			ExtendedDetailBean extendedDetailBean, List<ExtendedDetailBean> vasExtendedDetailList) {
		ExtendedFieldBean vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.INSUR_FORM_NO);
		vasExtendedField.setFieldValue(fundedRequest.getApplicationDetails().getQuoteNumber());
		vasExtendedFieldList.add(vasExtendedField);

		/*
		 * vasExtendedField.setFieldName(DisbursementConstants.INSUR_FORM_NO);
		 * vasExtendedField.setFieldValue("");
		 */

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.APPLICANTTYPE);
		vasExtendedField.setFieldValue(DisbursementConstants.PRIMARY_APPLICANT);
		vasExtendedFieldList.add(vasExtendedField);

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.CIF);
		vasExtendedField.setFieldValue(disbursementUtil.fetchFundedCifId(Long.valueOf(fundedRequest.getApplicationId()),
				fundedRequest.getApplicationDetails().getQuoteNumber()));
		vasExtendedFieldList.add(vasExtendedField);

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.DOB);
		vasExtendedField.setFieldValue(fundedRequest.getApplicantDetails().getDateOfBirth() + "T00:00:00");
		vasExtendedFieldList.add(vasExtendedField);

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.INSUR_PARTY_TYPE);
		vasExtendedField.setFieldValue("PARTY TO LOAN");
		vasExtendedFieldList.add(vasExtendedField);

		if (null != fundedRequest.getApplicantDetails().getDateOfBirth()) {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String strDate = fundedRequest.getApplicantDetails().getDateOfBirth();
			LocalDate birthDate = LocalDate.parse(strDate);
			vasExtendedField = new ExtendedFieldBean();
			vasExtendedField.setFieldName(DisbursementConstants.AGE);
			vasExtendedField.setFieldValue(Integer.toString(Period.between(birthDate, LocalDate.now()).getYears()));
			vasExtendedFieldList.add(vasExtendedField);
		}

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.GENDER);
		vasExtendedField.setFieldValue(fundedRequest.getApplicantDetails().getGender());
		vasExtendedFieldList.add(vasExtendedField);

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.SUMASSURED);
		vasExtendedField.setFieldValue(fundedRequest.getApplicationDetails().getFundingDetails().getSumAssured());
		vasExtendedFieldList.add(vasExtendedField);

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.POLICY_TERM);
		vasExtendedField.setFieldValue(fundedRequest.getApplicationDetails().getFundingDetails().getPolicyTenore());
		vasExtendedFieldList.add(vasExtendedField);

		if (null != fundedRequest.getApplicationDetails().getNomineeDetails()
				&& !fundedRequest.getApplicationDetails().getNomineeDetails().isEmpty()
				&& null != fundedRequest.getApplicationDetails().getNomineeDetails().get(0)) {
			if (null != fundedRequest.getApplicationDetails().getNomineeDetails().get(0).getNomName1()) {
				vasExtendedField = new ExtendedFieldBean();
				vasExtendedField.setFieldName(DisbursementConstants.NOM_NAME1);
				vasExtendedField
						.setFieldValue(fundedRequest.getApplicationDetails().getNomineeDetails().get(0).getNomName1());
				vasExtendedFieldList.add(vasExtendedField);
			}
			if (null != fundedRequest.getApplicationDetails().getNomineeDetails().get(0).getNomRel1()) {
				vasExtendedField = new ExtendedFieldBean();
				vasExtendedField.setFieldName(DisbursementConstants.NON_REL1);
				vasExtendedField
						.setFieldValue(fundedRequest.getApplicationDetails().getNomineeDetails().get(0).getNomRel1());
				vasExtendedFieldList.add(vasExtendedField);
			}
			if (null != fundedRequest.getApplicationDetails().getNomineeDetails().get(0).getNomDob1()) {
				vasExtendedField = new ExtendedFieldBean();
				vasExtendedField.setFieldName(DisbursementConstants.NOM_DOB1);
				vasExtendedField.setFieldValue(
						fundedRequest.getApplicationDetails().getNomineeDetails().get(0).getNomDob1() + "T00:00:00");
				vasExtendedFieldList.add(vasExtendedField);
			}

			if (null != fundedRequest.getApplicationDetails().getNomineeDetails().get(0).getNomAddress1()) {
				vasExtendedField = new ExtendedFieldBean();
				vasExtendedField.setFieldName(DisbursementConstants.NOM_ADDRESS1);
				vasExtendedField.setFieldValue(
						fundedRequest.getApplicationDetails().getNomineeDetails().get(0).getNomAddress1());
				vasExtendedFieldList.add(vasExtendedField);
			}
			if (null != fundedRequest.getApplicationDetails().getNomineeDetails().get(0).getNomMob1()) {
				vasExtendedField = new ExtendedFieldBean();
				vasExtendedField.setFieldName(DisbursementConstants.NOM_MOB1);
				vasExtendedField
						.setFieldValue(fundedRequest.getApplicationDetails().getNomineeDetails().get(0).getNomMob1());
				vasExtendedFieldList.add(vasExtendedField);
			}
		}
		FundedAddressRequest currAddress = fundedRequest.getApplicantDetails().getAddresses().stream()
				.filter(x -> x.getAddrType().equalsIgnoreCase(DisbursementConstants.ADDRESS_TYPE_CURRENT)).findFirst()
				.get();

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "mapAddress Current addressType: ");
		String address = (null != currAddress.getBuildingNo() ? "buildingNo " + currAddress.getBuildingNo() : "")
				+ (null != currAddress.getStreet() ? " Street " + currAddress.getStreet() : "") + " "
				+ (null != currAddress.getPinCode() ? currAddress.getPinCode() : "");

		vasExtendedField = new ExtendedFieldBean();
		vasExtendedField.setFieldName(DisbursementConstants.ADDRESS);
		vasExtendedField.setFieldValue(address.replaceAll("[^a-zA-Z0-9\\s]", ""));
		vasExtendedFieldList.add(vasExtendedField);

		extendedDetailBean.setExtendedFields(vasExtendedFieldList);
		vasExtendedDetailList.add(extendedDetailBean);
		vas.setExtendedDetails(vasExtendedDetailList);
		vasList.add(vas);
	}

}
