package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;

@Component("BflFundedDisbursementProcessor")
public class BflFundedDisbursementProcessor {

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	LoanProcessor loanProcessor;

	@Autowired
	CustomerProcessor customerProcessor;

	@Autowired
	DisbursementUtil disbursementUtil;

	private static final String CLASS_NAME = BflFundedDisbursementProcessor.class.getCanonicalName();

	public void processDisbursement(FundedDisbursementEventRequestBean request) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside processDisbursement ApplicationID: " + request.getApplicationId());

		// save event request in mongo db
		disbursementUtil.saveFundedEventRequest(request);

		if (precheck(request)) {
			createCustomer(request);
			createLoan(request, false);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"END processDisbursement ApplicationID: " + request.getApplicationId());
	}

	private boolean precheck(FundedDisbursementEventRequestBean request) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside precheck ApplicationID: " + request.getApplicationId());
		// PRE CHECKS for Funded Flow

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"END precheck ApplicationID: " + request.getApplicationId());
		return true;
	}

	public void createCustomer(FundedDisbursementEventRequestBean request) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside createCustomer ApplicationID: " + request.getApplicationId());
		customerProcessor.processCustomerRequestForFunded(request);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End of createCustomer ApplicationID:" + request.getApplicationId());
	}

	public void createLoan(FundedDisbursementEventRequestBean request, boolean errorFlag) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside createLoan ApplicationID: " + request.getApplicationId());
		loanProcessor.processLoanRequestForFunded(request, errorFlag);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End of createLoan ApplicationID:" + request.getApplicationId());
	}

}
