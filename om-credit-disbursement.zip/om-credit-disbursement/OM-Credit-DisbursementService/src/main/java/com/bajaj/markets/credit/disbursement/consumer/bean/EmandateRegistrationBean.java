package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class EmandateRegistrationBean {

	private Long emandateRegKey;
	
	private Long applicationKey;
	
	private Long applicantKey;
	
	private Long prodMastKey;
	
	private Long prodCatKey;
	
	private Long prodKey;
	
	private Long principalKey;
	
	private Long channel;
	
	private String mandateReference;
	
	private String chanelMandateRef;
	
	private String umrn; 
	
	private String status;
	
	private BigDecimal limit;
	
	private BigDecimal availableLimit;
	
	private String  accountNumber;
	
	private String bankName;
	
	private String accountType;
	
	private String micrCode;
	
	private String ifscCode;
	
	private Integer isActive;
	
	private String modeofpayment;
	
	private String barcode;

	private String authMode;
	
	private String accHolderName;
	
	private Timestamp mandatExpiryDate;
	
	private Integer integrationSystemKey;

	private String integrationSystemCode;
	
	private String integrationSystemName;
	
	private String chanelMandateRefId;

	public Long getEmandateRegKey() {
		return emandateRegKey;
	}

	public void setEmandateRegKey(Long emandateRegKey) {
		this.emandateRegKey = emandateRegKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getProdMastKey() {
		return prodMastKey;
	}

	public void setProdMastKey(Long prodMastKey) {
		this.prodMastKey = prodMastKey;
	}

	public Long getProdCatKey() {
		return prodCatKey;
	}

	public void setProdCatKey(Long prodCatKey) {
		this.prodCatKey = prodCatKey;
	}

	public Long getProdKey() {
		return prodKey;
	}

	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public Long getChannel() {
		return channel;
	}

	public void setChannel(Long channel) {
		this.channel = channel;
	}

	public String getMandateReference() {
		return mandateReference;
	}

	public void setMandateReference(String mandateReference) {
		this.mandateReference = mandateReference;
	}

	public String getChanelMandateRef() {
		return chanelMandateRef;
	}

	public void setChanelMandateRef(String chanelMandateRef) {
		this.chanelMandateRef = chanelMandateRef;
	}

	public String getUmrn() {
		return umrn;
	}

	public void setUmrn(String umrn) {
		this.umrn = umrn;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public BigDecimal getLimit() {
		return limit;
	}

	public void setLimit(BigDecimal limit) {
		this.limit = limit;
	}

	public BigDecimal getAvailableLimit() {
		return availableLimit;
	}

	public void setAvailableLimit(BigDecimal availableLimit) {
		this.availableLimit = availableLimit;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public String getModeofpayment() {
		return modeofpayment;
	}

	public void setModeofpayment(String modeofpayment) {
		this.modeofpayment = modeofpayment;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getAuthMode() {
		return authMode;
	}

	public void setAuthMode(String authMode) {
		this.authMode = authMode;
	}

	public Timestamp getMandatExpiryDate() {
		return mandatExpiryDate;
	}

	public void setMandatExpiryDate(Timestamp mandatExpiryDate) {
		this.mandatExpiryDate = mandatExpiryDate;
	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public Integer getIntegrationSystemKey() {
		return integrationSystemKey;
	}

	public void setIntegrationSystemKey(Integer integrationSystemKey) {
		this.integrationSystemKey = integrationSystemKey;
	}

	public String getIntegrationSystemCode() {
		return integrationSystemCode;
	}

	public void setIntegrationSystemCode(String integrationSystemCode) {
		this.integrationSystemCode = integrationSystemCode;
	}

	public String getIntegrationSystemName() {
		return integrationSystemName;
	}

	public void setIntegrationSystemName(String integrationSystemName) {
		this.integrationSystemName = integrationSystemName;
	}

	public String getChanelMandateRefId() {
		return chanelMandateRefId;
	}

	public void setChanelMandateRefId(String chanelMandateRefId) {
		this.chanelMandateRefId = chanelMandateRefId;
	}

	
	
}
