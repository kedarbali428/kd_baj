package com.bajaj.markets.credit.disbursement.consumer.bean;

public class BankDetailsResponse {

	private String accoutNumber;
	private String userAttributeKey;
	private String branchKey;
	private String holderName;
	private String bankAccountTypeKey;
	private String bankMasterKey;
	
	public String getAccoutNumber() {
		return accoutNumber;
	}
	public void setAccoutNumber(String accoutNumber) {
		this.accoutNumber = accoutNumber;
	}
	public String getUserAttributeKey() {
		return userAttributeKey;
	}
	public void setUserAttributeKey(String userAttributeKey) {
		this.userAttributeKey = userAttributeKey;
	}
	public String getBranchKey() {
		return branchKey;
	}
	public void setBranchKey(String branchKey) {
		this.branchKey = branchKey;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public String getBankAccountTypeKey() {
		return bankAccountTypeKey;
	}
	public void setBankAccountTypeKey(String bankAccountTypeKey) {
		this.bankAccountTypeKey = bankAccountTypeKey;
	}
	public String getBankMasterKey() {
		return bankMasterKey;
	}
	public void setBankMasterKey(String bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}
	
}
