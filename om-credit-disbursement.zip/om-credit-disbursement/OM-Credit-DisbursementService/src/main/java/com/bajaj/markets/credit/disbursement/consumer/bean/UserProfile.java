package com.bajaj.markets.credit.disbursement.consumer.bean;

public class UserProfile {

	private String applicationKey;
	
	private Long applicantKey;

	private String applicationUserAttributeKey;

	private String applicationUserAttributeType;

	private String mobile;

	private String dateOfBirth;

	private Name name;

	private Long maritalStatusKey;

	private Long genderKey;

	private String panNumber;

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getApplicationUserAttributeKey() {
		return applicationUserAttributeKey;
	}

	public void setApplicationUserAttributeKey(String applicationUserAttributeKey) {
		this.applicationUserAttributeKey = applicationUserAttributeKey;
	}

	public String getApplicationUserAttributeType() {
		return applicationUserAttributeType;
	}

	public void setApplicationUserAttributeType(String applicationUserAttributeType) {
		this.applicationUserAttributeType = applicationUserAttributeType;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public Long getMaritalStatusKey() {
		return maritalStatusKey;
	}

	public void setMaritalStatusKey(Long maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}

	public Long getGenderKey() {
		return genderKey;
	}

	public void setGenderKey(Long genderKey) {
		this.genderKey = genderKey;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

}
