package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class IncomeInfo {

	private String incomeExpense;
	private String category;
	private String custIncomeType;
	private BigDecimal custIncome;
	
	public String getIncomeExpense() {
		return incomeExpense;
	}
	public void setIncomeExpense(String incomeExpense) {
		this.incomeExpense = incomeExpense;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getCustIncomeType() {
		return custIncomeType;
	}
	public void setCustIncomeType(String custIncomeType) {
		this.custIncomeType = custIncomeType;
	}
	public BigDecimal getCustIncome() {
		return custIncome;
	}
	public void setCustIncome(BigDecimal custIncome) {
		this.custIncome = custIncome;
	}
	
}
