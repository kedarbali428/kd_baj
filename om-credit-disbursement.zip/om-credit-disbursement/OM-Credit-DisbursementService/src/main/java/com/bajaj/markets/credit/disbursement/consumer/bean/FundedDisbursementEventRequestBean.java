package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FundedDisbursementEventRequestBean {

	private String applicationId;
	private ApplicantDetails applicantDetails;
	private CustomerBankInfo bankDetails;
	private FundedApplicationDetails applicationDetails;
	private Map<String, String> headers;

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public ApplicantDetails getApplicantDetails() {
		return applicantDetails;
	}

	public void setApplicantDetails(ApplicantDetails applicantDetails) {
		this.applicantDetails = applicantDetails;
	}


	public FundedApplicationDetails getApplicationDetails() {
		return applicationDetails;
	}

	public void setApplicationDetails(FundedApplicationDetails applicationDetails) {
		this.applicationDetails = applicationDetails;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}

	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}

	/**
	 * @return the bankDetails
	 */
	public CustomerBankInfo getBankDetails() {
		return bankDetails;
	}

	/**
	 * @param bankDetails the bankDetails to set
	 */
	public void setBankDetails(CustomerBankInfo bankDetails) {
		this.bankDetails = bankDetails;
	}

}
