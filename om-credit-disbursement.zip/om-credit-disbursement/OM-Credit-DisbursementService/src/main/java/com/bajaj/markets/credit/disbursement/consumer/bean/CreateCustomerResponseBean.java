package com.bajaj.markets.credit.disbursement.consumer.bean;
import com.bajaj.markets.credit.disbursement.consumer.util.Status;;
public class CreateCustomerResponseBean {

	private String cif;
	private ReturnStatusBean returnStatus;
	private Status status;

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public ReturnStatusBean getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(ReturnStatusBean returnStatus) {
		this.returnStatus = returnStatus;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

}
