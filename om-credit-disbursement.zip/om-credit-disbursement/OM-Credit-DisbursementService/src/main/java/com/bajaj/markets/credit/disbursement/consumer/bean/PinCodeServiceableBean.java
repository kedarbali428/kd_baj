package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class PinCodeServiceableBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long pinservicekey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long pincodekey;

	private Long prodkey;

	private String cityname;

	private String tier;

	private String pennantbvcodesal;

	private String sourcecode;

	private String stdcode;

	private String statename;

	public Long getPinservicekey() {
		return pinservicekey;
	}

	public void setPinservicekey(Long pinservicekey) {
		this.pinservicekey = pinservicekey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public String getPennantbvcodesal() {
		return pennantbvcodesal;
	}

	public void setPennantbvcodesal(String pennantbvcodesal) {
		this.pennantbvcodesal = pennantbvcodesal;
	}

	public String getSourcecode() {
		return sourcecode;
	}

	public void setSourcecode(String sourcecode) {
		this.sourcecode = sourcecode;
	}

	public String getStdcode() {
		return stdcode;
	}

	public void setStdcode(String stdcode) {
		this.stdcode = stdcode;
	}

	public String getStatename() {
		return statename;
	}

	public void setStatename(String statename) {
		this.statename = statename;
	}
	
	
}
