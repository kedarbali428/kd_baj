package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.Map;

public class ApplicationParameter {

	private Map<String, String> applicationParameters;

	public void setApplicationParameters(Map<String, String> applicationParameters) {
		this.applicationParameters = applicationParameters;
	}
}
