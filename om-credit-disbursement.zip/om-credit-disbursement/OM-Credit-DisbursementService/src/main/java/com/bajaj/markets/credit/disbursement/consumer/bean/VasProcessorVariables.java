package com.bajaj.markets.credit.disbursement.consumer.bean;

public class VasProcessorVariables {

	private Boolean isFpp;

	public Boolean getIsFpp() {
		return isFpp;
	}

	public void setIsFpp(Boolean isFpp) {
		this.isFpp = isFpp;
	}

}
