package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.Map;

import com.bajaj.markets.om.consumer.model.SubEventSchema;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EventMessage {

	private String eventName;
	private String eventType;
	private SubEventSchema eventSchema;
	private Object payload;
	private Map<String, String> headers;
	private String productCode;
	private String principalName;
	
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	public SubEventSchema getEventSchema() {
		return eventSchema;
	}
	public void setEventSchema(SubEventSchema eventSchema) {
		this.eventSchema = eventSchema;
	}
	public Object getPayload() {
		return payload;
	}
	public void setPayload(Object payload) {
		this.payload = payload;
	}
	
	public Map<String, String> getHeaders() {
		return headers;
	}
	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}
		public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getPrincipalName() {
		return principalName;
	}
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}
	
	@Override
	public String toString() {
		return "EventMessage [eventName=" + eventName + ", eventType=" + eventType + ", eventSchema=" + eventSchema
				+ ", payload=" + payload + ", headers=" + headers + "]";
	}
}