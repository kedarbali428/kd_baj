package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.awaitility.Awaitility;
import org.awaitility.core.ConditionTimeoutException;
import org.awaitility.pollinterval.FibonacciPollInterval;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicantSysCodeBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ApplicationDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.BankDetailsResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.BusinessOwnerDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCustomerPennantRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCustomerPennatResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCustomerResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreditReviewStatusBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.CustomerDisbDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.CustomerProcessorVariables;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.EmailInfo;
import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.FundedDisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.Occupation;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.UserProfile;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementMapperUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.LMSHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.Status;
import com.bajaj.markets.credit.disbursement.repository.MongoDBRepository;
import com.google.gson.Gson;

import io.jsonwebtoken.lang.Collections;

@Component
public class CustomerProcessor {

	@Value("${api.disbursement.cif.POST.url}")
	private String updateAppSysCodeUrl;

	@Value("${api.omcreditapplicationservice.userprofiles.GET.url}")
	private String getUserProfilesUrl;

	@Value("${api.omcreditapplicationservice.application.userprofiles.occupation.PUT.url}")
	private String updateOccupationForEntityCif;

	@Value("${erroScenarioFlg}")
	private String erroScenarioFlg;

	@Value("${initiateDisbUrl}")
	private String initiateDisbUrl;

	@Value("${insDisbursementMongoDBTable}")
	private String insDisbursementMongoDB;

	@Value("${initiateBflDisbUrl}")
	private String initiateBflDisbUrl;

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Autowired
	DisbursementMapperUtil disbursementMapperUtil;

	@Autowired
	LMSHelper lmsHelper;

	@Autowired
	DisbursementUtil disbursementUtil;

	@Autowired
	MongoDBRepository mongoDbRepo;

	@Autowired
	@Qualifier("disbursementMongoTemplate")
	MongoOperations disbursementMongoTemplate;

	@Autowired
	Environment env;

	private static final String CLASS_NAME = CustomerProcessor.class.getCanonicalName();

	@SuppressWarnings("static-access")
	public CreateCustomerResponseBean processCustomerRequestForSOL(GlobalDataBean data) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Fetching create customer details started:" + data.getApplicationKey());

		CustomerProcessorVariables processorVariables = new CustomerProcessorVariables();
		HttpHeaders headers = generateHeaders(data);
		CreateCustomerResponseBean response = null;
		try {
			Long prodcatKey = data.getL2ProductKey();
			CreateCustomerPennantRequest customerRequest = fetchCustomerPennantRequestForSOL(data.getApplicationKey(),
					data.getL3ProductKey(), prodcatKey, headers);
			data.setMobile(customerRequest.getPhones().get(0).getPhoneNumber());
			Optional<EmailInfo> personalEmailInfo = customerRequest.getEmails().stream()
					.filter(x -> x.getCustEMailTypeCode().equalsIgnoreCase("PERSONAL")).findAny();
			data.setEmail(personalEmailInfo.get().getCustEMail());
			Long startTime = null;
			Long stopTime = null;
			try {
				startTime = System.currentTimeMillis();
				FibonacciPollInterval fibonacci = new FibonacciPollInterval(TimeUnit.SECONDS);
				Awaitility.setDefaultTimeout(300, TimeUnit.SECONDS);

				Awaitility.with().pollInterval(fibonacci).await().atMost(300, TimeUnit.SECONDS)
						.until(() -> null != (executeLMSRequestforCustomerForSOL(customerRequest, data, headers,
								processorVariables)));
				stopTime = System.currentTimeMillis();
			} catch (ConditionTimeoutException e) {
				Date date = new Date();
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "TimeOut Flow in Create CreateCustomer ::");
				List<TranchBean> trnchLst = disbursementUtil.fetchTranchDetails(data.getApplicationKey(), headers);
				Long activeTranchKey = trnchLst.get(0).getTranchkey();
				RetryRegistrationBean existingRecords = null;
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"TimeOut Flow in Create CreateCustomer :: activeTranchKey " + activeTranchKey);

				existingRecords = disbursementUtil.fetchExistingTransaction(activeTranchKey.toString(),
						data.getApplicationKey(), headers);
				DisbursementRequestBean rquestBean = new DisbursementRequestBean();
				rquestBean.setApplicantId(data.getApplicantKey());
				rquestBean.setApplicationId(data.getApplicationKey());
				rquestBean.setProductCode(data.getL3ProductCode());

				RetryRegistrationBean bean = new RetryRegistrationBean();
				bean.setActiveFlg(true);
				if (null != existingRecords) {
					bean.setCurrentRetryCount(existingRecords.getCurrentRetryCount() + 1l);
				} else {
					bean.setCurrentRetryCount(1l);
				}
				rquestBean.setStage("CREATE_CUSTOMER");
				rquestBean.setTransactionId(activeTranchKey.toString());
				bean.setErrorCode("DISBURSEMENT_CREATE_CUSTOMER");
				bean.setNextReryTime(new Timestamp(date.getTime()).toString());
				bean.setRetryClass("CreditDisbursementController");
				bean.setRetryMechanism("Endpoint");
				bean.setRetryMethod(initiateDisbUrl);
				bean.setRetryPayload(disbursementUtil.objectToJson(rquestBean));
				bean.setRetryStatus("Pending");
				bean.setSource("OM-Credit-Disbursement");
				bean.setTimestamp(new Timestamp(date.getTime()).toString());
				bean.setTransactionId(activeTranchKey);
				bean.setErrorKey(data.getApplicationKey() + activeTranchKey);
				if (bean.getCurrentRetryCount() > 5) {
					bean.setRetryStatus("Failed");
					bean.setActiveFlg(false);
				}
				processorVariables.setRetryMechanism(true);
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"TimeOut Flow in Create CreateCustomer before Save  :: activeTranchKey " + activeTranchKey);

				disbursementUtil.saveretrytransaction(activeTranchKey.toString(), data.getApplicationKey(), bean,
						headers);
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Time Out Exception occurred : Create Customer Call ");
				throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
						"Exception occurred in Create Customer Call");
			}

			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Completed CreateCustomerResponseBean ::");
			if (null != processorVariables.getCustomerResponseString() && !processorVariables.isRetryMechanism()) {
				processorVariables.setCustomerResponseString(processorVariables.getCustomerResponseString());
				disbursementUtil.addDisbursementRecords(data.getApplicationKey(), data.getApplicantKey(),
						mapToJson(customerRequest), processorVariables.getCustomerResponseString(),
						DisbursementConstants.LMS_CUSTOMER_SOURCE, null != startTime ? startTime.toString() : null,
						null != stopTime ? stopTime.toString() : null);
				response = processCustomerLmsResponse(data, processorVariables.getCustomerResponseString());
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Exception occurred : Create Customer Call ", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred in Create Customer Call");
		}
		return response;
	}

	private String executeLMSRequestforCustomerForSOL(CreateCustomerPennantRequest customerRequest, GlobalDataBean data,
			HttpHeaders headers, CustomerProcessorVariables processorVariables) {
		String response = executeLMSRequestforCustomer(customerRequest, data.getL3ProductCode(),
				data.getApplicationKey(), headers);
		processorVariables.setCustomerResponseString(response);
		return response;
	}

	private CreateCustomerResponseBean processCustomerLmsResponse(GlobalDataBean data, String customerResponseString) {
		return processCustomerLmsResponse(data, data.getApplicantKey(), customerResponseString, null, false);
	}

	@SuppressWarnings("static-access")
	public void processCustomerRequestForBOL(GlobalDataBean data) {

		CustomerProcessorVariables processorVariables = new CustomerProcessorVariables();
		HttpHeaders headers = generateHeaders(data);
		try {

			List<UserProfile> userProfileList = getUserDetails(data.getApplicationKey(), headers);
			// Main Applicant
			UserProfile userProfile_Primary = userProfileList.stream()
					.filter(x -> x.getApplicationUserAttributeType().equals(DisbursementConstants.MAIN_APPLICANT))
					.collect(Collectors.toList()).get(0);
			data.setAppAtrKey(userProfile_Primary.getApplicationUserAttributeKey());
			CustomerDisbDetails customerDisbDetails = disbursementUtil
					.fetchCustomerDisbDetails(data.getApplicationKey(), data.getAppAtrKey(), headers);
			ApplicationDetails applicationDetails_Primary = disbursementUtil
					.fetchApplicationDetails(data.getApplicationKey(), data.getAppAtrKey(), headers);
			List<BankDetailsResponse> bankDetails = null;
			bankDetails = disbursementUtil.fetchBankDetails(data.getApplicationKey(), headers);
			Long prodcatKey = data.getL2ProductKey();
			CreateCustomerPennantRequest customerRequest_Primary = disbursementMapperUtil
					.mapCustomerPennantRequestForBOL(userProfile_Primary, applicationDetails_Primary,
							customerDisbDetails, bankDetails, false, data.getL3ProductKey(), prodcatKey, headers);
			data.setMobile(customerRequest_Primary.getPhones().get(0).getPhoneNumber());
			Optional<EmailInfo> personalEmailInfo = customerRequest_Primary.getEmails().stream()
					.filter(x -> x.getCustEMailTypeCode().equalsIgnoreCase("PERSONAL")).findAny();
			data.setEmail(personalEmailInfo.get().getCustEMail());
			Long startTime = null;
			Long stopTime = null;
			try {
				startTime = System.currentTimeMillis();
				FibonacciPollInterval fibonacci = new FibonacciPollInterval(TimeUnit.SECONDS);
				Awaitility.setDefaultTimeout(300, TimeUnit.SECONDS);
				Awaitility.with().pollInterval(fibonacci).await().atMost(300, TimeUnit.SECONDS)
						.until(() -> null != (executeLMSRequestforCustomerForPrimary(customerRequest_Primary, data,
								headers, processorVariables)));
				stopTime = System.currentTimeMillis();
			} catch (ConditionTimeoutException e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Completed CreateCustomerResponseBean ::");
				List<TranchBean> trnchLst = disbursementUtil.fetchTranchDetails(data.getApplicationKey(), headers);
				Long activeTranchKey = trnchLst.get(0).getTranchkey();
				DisbursementEventRequestBean rquestBean = new DisbursementEventRequestBean();
				rquestBean.setApplicantId(data.getApplicantKey());
				rquestBean.setApplicationId(data.getApplicationKey());
				rquestBean.setProductCode(data.getL3ProductCode());
				RetryRegistrationBean bean = new RetryRegistrationBean();
				bean.setActiveFlg(true);
				bean.setCurrentRetryCount(0l);
				bean.setErrorCode("DISBURSEMENT_CREATE_CUSTOMER");
				bean.setNextReryTime(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(5)).toString());
				bean.setRetryClass("CreditDisbursementController");
				bean.setRetryMechanism("Endpoint");
				bean.setRetryMethod(initiateDisbUrl);
				bean.setRetryPayload(disbursementUtil.objectToJson(rquestBean));
				bean.setRetryStatus("Pending");
				bean.setSource("OM-Credit-Disbursement");
				Date date = new Date();
				bean.setTimestamp(new Timestamp(date.getTime()).toString());
				bean.setTransactionId(activeTranchKey);
				disbursementUtil.saveretrytransaction(activeTranchKey.toString(), data.getApplicationKey(), bean,
						headers);
			}
			CreateCustomerResponseBean response_Primary = null;
			if (null != processorVariables.getCustomerResponseString_Primary()) {
				disbursementUtil.addDisbursementRecords(data.getApplicationKey(), data.getApplicantKey(),
						mapToJson(customerRequest_Primary), processorVariables.getCustomerResponseString_Primary(),
						DisbursementConstants.LMS_CUSTOMER_SOURCE,
						null != startTime ? new Timestamp(startTime).toString() : null,
						null != stopTime ? new Timestamp(stopTime).toString() : null);
				response_Primary = processCustomerLmsResponse(data, data.getApplicantKey().toString(),
						processorVariables.getCustomerResponseString_Primary(), null, false);
			}
			// Pre checks for entitycoapplicantRequired or individualcoapplicantRequired

			CreditReviewStatusBean creditReviewStatusBean = disbursementUtil.getCreditReviewDetails(data.getApplicationKey(), headers);
			if (null != creditReviewStatusBean) {
				if (null != creditReviewStatusBean.getEntityCoapplicantRequired()
						&& creditReviewStatusBean.getEntityCoapplicantRequired().equals("1")) {
					solPropriterShip(data, headers, userProfile_Primary, customerDisbDetails,
							applicationDetails_Primary, bankDetails, processorVariables);
				}
				if (null != creditReviewStatusBean.getIndividualCoapplicantRequired()
						&& creditReviewStatusBean.getIndividualCoapplicantRequired().equals("1")) {
					individualCoApplicant(data, headers, processorVariables);
				}
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Exception occurred : Create Customer Call ", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred in Create Customer Call");
		}
	}

	private String executeLMSRequestforCustomerForPrimary(CreateCustomerPennantRequest customerRequest_Primary,
			GlobalDataBean data, HttpHeaders headers, CustomerProcessorVariables processorVariables) {
		String response = executeLMSRequestforCustomer(customerRequest_Primary, data.getL3ProductCode(),
				data.getApplicationKey(), headers);
		processorVariables.setCustomerResponseString_Primary(response);
		return response;
	}

	private void individualCoApplicant(GlobalDataBean data, HttpHeaders headers,
			CustomerProcessorVariables processorVariables) {
		// CoApplicant
		Long startTime = null;
		Long stopTime = null;
		List<UserProfile> userProfileListForAll = getUserDetails(data.getParentApplicationKey(), headers);
		List<UserProfile> userProfile_CoApplicantList = userProfileListForAll.stream()
				.filter(x -> x.getApplicationUserAttributeType().equals(DisbursementConstants.CO_APPLICANT))
				.collect(Collectors.toList());
		if (!Collections.isEmpty(userProfile_CoApplicantList) && null != userProfile_CoApplicantList.get(0)) {
			UserProfile userProfile_CoApplicant = userProfile_CoApplicantList.get(0);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Start CreateCustomer for Coapplicant ::ApplicationKey" + data.getApplicationKey() + " ParentApp:"
							+ data.getParentApplicationKey() + " MainApplicant" + data.getApplicantKey()
							+ " CoApplicantKey:" + userProfile_CoApplicant.getApplicantKey());
			ApplicationDetails applicationDetails_Coapplicant = disbursementUtil.fetchApplicationDetailsForCoApplicant(
					data.getParentApplicationKey(), userProfile_CoApplicant.getApplicationUserAttributeKey(), headers);
			data.setCoApplicantKey(userProfile_CoApplicant.getApplicantKey().toString());
			CustomerDisbDetails customerDisbDetails_Coapplicant = disbursementUtil.fetchCustomerDisbDetails(
					data.getParentApplicationKey(), userProfile_CoApplicant.getApplicationUserAttributeKey(), headers);
			Long prodcatKey = data.getL2ProductKey();
			CreateCustomerPennantRequest customerRequest_Coapplicant = disbursementMapperUtil
					.mapCustomerPennantRequestForBOL(userProfile_CoApplicant, applicationDetails_Coapplicant,
							customerDisbDetails_Coapplicant, null, false, data.getL3ProductKey(), prodcatKey, headers);

			try {
				startTime = System.currentTimeMillis();
				FibonacciPollInterval fibonacci = new FibonacciPollInterval(TimeUnit.SECONDS);
				Awaitility.setDefaultTimeout(300, TimeUnit.SECONDS);
				Awaitility.with().pollInterval(fibonacci).await().atMost(300, TimeUnit.SECONDS)
						.until(() -> null != (executeLMSRequestforCustomerForCoApplicant(customerRequest_Coapplicant,
								data, headers, processorVariables)));
				stopTime = System.currentTimeMillis();
			} catch (ConditionTimeoutException e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Completed CreateCustomerResponseBean for BOL Coapplcant  ::");
				List<TranchBean> trnchLst = disbursementUtil.fetchTranchDetails(data.getApplicationKey(), headers);
				Long activeTranchKey = trnchLst.get(0).getTranchkey();
				DisbursementEventRequestBean rquestBean = new DisbursementEventRequestBean();
				rquestBean.setApplicantId(data.getApplicantKey());
				rquestBean.setApplicationId(data.getApplicationKey());
				rquestBean.setProductCode(data.getL3ProductCode());
				RetryRegistrationBean bean = new RetryRegistrationBean();
				bean.setActiveFlg(true);
				bean.setCurrentRetryCount(0l);
				bean.setErrorCode("DISBURSEMENT_CREATE_CUSTOMER_BOL");
				bean.setNextReryTime(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(5)).toString());
				bean.setRetryClass("CreditDisbursementController");
				bean.setRetryMechanism("Endpoint");
				bean.setRetryMethod(initiateDisbUrl);
				bean.setRetryPayload(disbursementUtil.objectToJson(rquestBean));
				bean.setRetryStatus("Pending");
				bean.setSource("OM-Credit-Disbursement");
				Date date = new Date();
				bean.setTimestamp(new Timestamp(date.getTime()).toString());
				bean.setTransactionId(activeTranchKey);
				disbursementUtil.saveretrytransaction(activeTranchKey.toString(), data.getApplicationKey(), bean,
						headers);

			}
			CreateCustomerResponseBean response_Coapplicant = null;
			if (null != processorVariables.getCustomerResponseString_Coapplicant()) {
				disbursementUtil.addDisbursementRecords(data.getApplicationKey(), data.getApplicantKey(),
						mapToJson(customerRequest_Coapplicant),
						processorVariables.getCustomerResponseString_Coapplicant(),
						DisbursementConstants.LMS_CUSTOMER_SOURCE, null != startTime ? startTime.toString() : null,
						null != stopTime ? stopTime.toString() : null);
				response_Coapplicant = processCustomerLmsResponse(data,
						userProfile_CoApplicant.getApplicantKey().toString(),
						processorVariables.getCustomerResponseString_Coapplicant(), null, false);
			}
		}
	}

	private String executeLMSRequestforCustomerForCoApplicant(CreateCustomerPennantRequest customerRequest_Coapplicant,
			GlobalDataBean data, HttpHeaders headers, CustomerProcessorVariables processorVariables) {
		String response = executeLMSRequestforCustomer(customerRequest_Coapplicant, data.getL3ProductCode(),
				data.getApplicationKey(), headers);
		processorVariables.setCustomerResponseString_Coapplicant(response);
		return response;
	}

	private void solPropriterShip(GlobalDataBean data, HttpHeaders headers, UserProfile userProfile_Primary,
			CustomerDisbDetails customerDisbDetails, ApplicationDetails applicationDetails_Primary,
			List<BankDetailsResponse> bankDetails, CustomerProcessorVariables processorVariables) {
		Long startTime = null;
		Long stopTime = null;
		boolean solePropritership = applicationDetails_Primary.getOccupation().getBusinessOwnerDetails()
				.getBusinessType().getKey().equals(DisbursementConstants.BUSINESS_KEY_PROPRIETORSHIP);

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Checking solePropritership for BOL ::"
				+ data.getApplicationKey() + "BusinessType:"
				+ applicationDetails_Primary.getOccupation().getBusinessOwnerDetails().getBusinessType().getKey()
				+ solePropritership);

		if (!solePropritership) {
			// Business Entity as CoApplicant
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Start CreateCustomer for Business Entity Coapplicant :: ApplicationKey" + data.getApplicationKey()
							+ " ParentApp:" + data.getParentApplicationKey() + " MainApplicant" + data.getApplicantKey()
							+ " BusinessPan:"
							+ applicationDetails_Primary.getOccupation().getBusinessOwnerDetails().getBusinessPan());
			data.setBusinessPan(applicationDetails_Primary.getOccupation().getBusinessOwnerDetails().getBusinessPan());

			CreateCustomerPennantRequest customerRequest_Entity = disbursementMapperUtil
					.mapCustomerPennantRequestForBOL(userProfile_Primary, applicationDetails_Primary,
							customerDisbDetails, bankDetails, true, data.getL3ProductKey(), data.getL2ProductKey(),
							headers);

			try {
				startTime = System.currentTimeMillis();

				FibonacciPollInterval fibonacci = new FibonacciPollInterval(TimeUnit.SECONDS);
				Awaitility.setDefaultTimeout(300, TimeUnit.SECONDS);
				Awaitility.with().pollInterval(fibonacci).await().atMost(300, TimeUnit.SECONDS)
						.until(() -> null != (executeLMSRequestforCustomerForEntity(customerRequest_Entity, data,
								headers, processorVariables)));
				stopTime = System.currentTimeMillis();
			} catch (ConditionTimeoutException e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Completed CreateCustomerResponseBean for BOL Coapplcant  ::");
				List<TranchBean> trnchLst = disbursementUtil.fetchTranchDetails(data.getApplicationKey(), headers);
				Long activeTranchKey = trnchLst.get(0).getTranchkey();
				DisbursementEventRequestBean rquestBean = new DisbursementEventRequestBean();
				rquestBean.setApplicantId(data.getApplicantKey());
				rquestBean.setApplicationId(data.getApplicationKey());
				rquestBean.setProductCode(data.getL3ProductCode());
				RetryRegistrationBean bean = new RetryRegistrationBean();
				bean.setActiveFlg(true);
				bean.setCurrentRetryCount(0l);
				bean.setErrorCode("DISBURSEMENT_CREATE_CUSTOMER");
				bean.setNextReryTime(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(5)).toString());
				bean.setRetryClass("CreditDisbursementController");
				bean.setRetryMechanism("Endpoint");
				bean.setRetryMethod(initiateDisbUrl);
				bean.setRetryPayload(disbursementUtil.objectToJson(rquestBean));
				bean.setRetryStatus("Pending");
				bean.setSource("OM-Credit-Disbursement");
				Date date = new Date();
				bean.setTimestamp(new Timestamp(date.getTime()).toString());
				bean.setTransactionId(activeTranchKey);
				disbursementUtil.saveretrytransaction(activeTranchKey.toString(), data.getApplicationKey(), bean,
						headers);

			}
			CreateCustomerResponseBean response_Entity = null;
			if (null != processorVariables.getCustomerResponseString_Entity()) {
				disbursementUtil.addDisbursementRecords(data.getApplicationKey(), data.getApplicantKey(),
						mapToJson(customerRequest_Entity), processorVariables.getCustomerResponseString_Entity(),
						DisbursementConstants.LMS_CUSTOMER_SOURCE, null != startTime ? startTime.toString() : null,
						null != stopTime ? stopTime.toString() : null);
				response_Entity = processCustomerLmsResponse(data, data.getBusinessPan(),
						processorVariables.getCustomerResponseString_Entity(),
						applicationDetails_Primary.getOccupation(), true);
			}
		}
	}

	private String executeLMSRequestforCustomerForEntity(CreateCustomerPennantRequest customerRequest_Entity,
			GlobalDataBean data, HttpHeaders headers, CustomerProcessorVariables processorVariables) {
		String response = executeLMSRequestforCustomer(customerRequest_Entity, data.getL3ProductCode(),
				data.getApplicationKey(), headers);
		processorVariables.setCustomerResponseString_Entity(response);
		return response;
	}

	public HttpHeaders generateHeaders(GlobalDataBean data) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("authtoken", data.getHeaders().get("authtoken"));
		headers.add("cmptcorrid", data.getHeaders().get("cmptcorrid"));
		headers.add("guardtoken", data.getHeaders().get("guardtoken"));
		return headers;
	}

	public <T> String mapToJson(T object) {
		Gson gson = new Gson();
		return gson.toJson(object);
	}

	public CreateCustomerResponseBean processCustomerLmsResponse(GlobalDataBean data, String applicantKey,
			String customerResponseString, Occupation occupation, Boolean isBusinessEntity) {
		Gson gson = new Gson();
		String applicationId = data.getApplicationKey();
		HttpHeaders headers = generateHeaders(data);
		CreateCustomerResponseBean finalResponse = new CreateCustomerResponseBean();
		CreateCustomerPennatResponse customerPennatResponse = gson.fromJson(customerResponseString,
				CreateCustomerPennatResponse.class);
		String returnCode = customerPennatResponse.getReturnStatus().getReturnCode();
		if (DisbursementConstants.PENNANT_SUCCES_CODE.equals(returnCode)) {
			finalResponse.setCif(customerPennatResponse.getCif());
			finalResponse.setStatus(Status.SUCCESS);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside PENNANT_SUCCES_CODE");
			if (!isBusinessEntity) {
				saveServiceRecord(applicationId, applicantKey, null, customerPennatResponse.getCif());
				saveAppSysCode(applicantKey, customerPennatResponse.getCif(), headers);
			} else {
				String businessPan = applicantKey;
				// save cif for BusinessEntity against BusinessPan
				saveServiceRecord(applicationId, null, businessPan, customerPennatResponse.getCif());
				// Update Aurora App_Occupation_Details table for cif
				updateBusinessEntityCif(data, occupation, customerPennatResponse.getCif());
			}
			// Update Aurora DB
			disbursementUtil.updateAppTranch(applicationId, DisbursementConstants.TRANCHE_STATUS_PROGRESS,
					DisbursementConstants.DISB_SUCCESS_FLAG, null, null, headers);
		} else if (DisbursementConstants.PENNAT_CUST_DEDUPE_RESP_CODE.equals(returnCode)) {
			finalResponse.setCif(customerPennatResponse.getDedup().get(0).getCif());
			finalResponse.setStatus(Status.SUCCESS);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside PENNAT_CUST_DEDUPE_RESP_CODE");
			if (!isBusinessEntity) {
				saveServiceRecord(applicationId, applicantKey, null, customerPennatResponse.getDedup().get(0).getCif());
				saveAppSysCode(applicantKey, customerPennatResponse.getDedup().get(0).getCif(), headers);
			} else {
				String businessPan = applicantKey;
				// save cif for BusinessEntity against BusinessPan
				saveServiceRecord(applicationId, null, businessPan, customerPennatResponse.getDedup().get(0).getCif());
				// Update Aurora App_Occupation_Details table for cif
				updateBusinessEntityCif(data, occupation, customerPennatResponse.getDedup().get(0).getCif());
			}
			// Update Aurora DB
			disbursementUtil.updateAppTranch(applicationId, DisbursementConstants.TRANCHE_STATUS_PROGRESS,
					DisbursementConstants.DISB_SUCCESS_FLAG, null, null, headers);
		} else {
			finalResponse.setReturnStatus(customerPennatResponse.getReturnStatus());
			finalResponse.setStatus(Status.FAILURE);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside PENNAT_FAILURE_CODE");
			// Update Aurora DB
			disbursementUtil.updateAppTranch(applicationId, DisbursementConstants.TRANCHE_STATUS_FAILED,
					DisbursementConstants.DISB_FAILURE_FLAG, null, null, headers);
			if ("Y".equals(erroScenarioFlg)) {
				saveDisbursementError(data, applicationId, customerPennatResponse, customerResponseString);
				DisbursementEventRequestBean disbursementEventRequestBean = new DisbursementEventRequestBean();
				disbursementEventRequestBean.setApplicantId(data.getApplicantKey());
				disbursementEventRequestBean.setApplicationId(data.getApplicationKey());
				disbursementEventRequestBean.setEventType("DISBURSEMENT_FAILED");
				disbursementEventRequestBean.setProductCode(data.getL3ProductCode());
				disbursementEventRequestBean.setHeaders(data.getHeaders());
				disbursementUtil.raiseEvent(disbursementEventRequestBean, DisbursementConstants.DISBURSEMENT_FAILED);
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Create Customer  failed: ");
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Create Customer  failed: ");
				throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
						new ErrorBean("CDS-200", "Create Customer  failed:"));
			}
		}

		return finalResponse;

	}

	private void saveDisbursementError(GlobalDataBean data, String applicationId,
			CreateCustomerPennatResponse customerPennatResponse, String customerResponseString) {
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		disbursementTrackerBean.setApplicationId(Long.parseLong(applicationId));
		disbursementTrackerBean.setDisbursmentstage(DisbursementConstants.CREATE_CUSTOMER);
		disbursementTrackerBean.setError(DisbursementConstants.CREATE_CUSTOMER_FAILED);
		String errorReason = disbursementUtil.logDisbErrors(applicationId, customerResponseString);
		disbursementTrackerBean.setErrorreason(errorReason);
		disbursementTrackerBean.setErrorretryable(1l);
		disbursementTrackerBean.setIsActive(1l);
		disbursementTrackerBean.setStatus("CREATED");
		disbursementUtil.saveDisbursementErrorDetails(data, disbursementTrackerBean);
	}

	private void updateBusinessEntityCif(GlobalDataBean data, Occupation occupationIn, String cif) {

		Occupation occupation = new Occupation();
		BusinessOwnerDetails businessOwnerDetails = new BusinessOwnerDetails();
		try {
			occupation.setOcupationType(occupationIn.getOcupationType());
			businessOwnerDetails.setBusinessPan(occupationIn.getBusinessOwnerDetails().getBusinessPan());
			if (null != occupationIn.getBusinessOwnerDetails().getGstNumber())
				businessOwnerDetails.setGstNumber(occupationIn.getBusinessOwnerDetails().getGstNumber());
			businessOwnerDetails.setCif(cif);
			occupation.setBusinessOwnerDetails(businessOwnerDetails);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"updateBusinessEntityCif : Start : " + data.getApplicantKey());
			HashMap<String, String> params = new HashMap<>();
			params.put("applicationid", data.getApplicationKey());
			params.put("userattributekey", data.getAppAtrKey());
			Gson gson = new Gson();
			String occupationStr = gson.toJson(occupation, Occupation.class);
			ResponseEntity<?> response = disbursementBusinessHelper.invokeRestEndpoint(HttpMethod.PUT,
					updateOccupationForEntityCif, String.class, params, occupationStr, generateHeaders(data));
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"updateBusinessEntityCif : End : " + response.getStatusCodeValue());
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "updateBusinessEntityCif  failed: ");
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CDS-200", "Unable to update BusinessEntityCif"));
		}
	}

	private void saveAppSysCode(String applicantKey, String refCode, HttpHeaders headers) {
		ApplicantSysCodeBean appSysCodeRequest = new ApplicantSysCodeBean();
		try {
			appSysCodeRequest.setApplicantKey(Long.valueOf(applicantKey));
			appSysCodeRequest.setRefCode(refCode);
			appSysCodeRequest.setPennantCode(DisbursementConstants.PENNANT_SYSTEMCODE);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "saveAppSysCode : Start : " + applicantKey);
			HashMap<String, String> params = new HashMap<>();
			Gson gson = new Gson();
			String appSysCodeReqStr = gson.toJson(appSysCodeRequest, ApplicantSysCodeBean.class);
			ResponseEntity<?> response = disbursementBusinessHelper.invokeRestEndpoint(HttpMethod.POST,
					updateAppSysCodeUrl, String.class, params, appSysCodeReqStr, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "saveAppSysCode : End : " + response.toString());
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "saveAppSysCode  failed: ");
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CDS-200", "Unable to update AppSysCode"));
		}

	}

	public void saveServiceRecord(String applicationId, String applicantKey, String businessPan, String cif) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "saveServiceRecord : Start : ");
		DisbursementMongoObject disbursementMongoObject = new DisbursementMongoObject();
		try {
			disbursementMongoObject
					.setId(null != businessPan ? (applicationId + businessPan) : (applicationId + applicantKey));
			disbursementMongoObject.setApplicationKey(Long.valueOf(applicationId));
			if (null != applicantKey)
				disbursementMongoObject.setApplicantKey(Long.valueOf(applicantKey));
			else if (null != businessPan) // For BusinessEntity Only
				disbursementMongoObject.setBusinessPan(businessPan);
			disbursementMongoObject.setCif(cif);
			mongoDbRepo.insertDocumentDB(disbursementMongoTemplate, disbursementMongoObject,
					DisbursementConstants.SERVICE_RECORD);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "saveServiceRecord update failed: ");
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CDS-200", "Unable to update Serecordvice R"));
		}

	}

	public String executeLMSRequestforCustomer(CreateCustomerPennantRequest customerRequest, String prodCode,
			String applicationKey, HttpHeaders headers) {
		String customerRequestStr = mapToJson(customerRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "executeLMSRequestforCustomer : Start : ");
		Object response = lmsHelper.executeLmsRequest(DisbursementConstants.LMS_CUSTOMER_SOURCE, prodCode,
				customerRequestStr, applicationKey, headers);
		return response.toString();
	}

	public CreateCustomerPennantRequest fetchCustomerPennantRequestForSOL(String applicationId, Long l3ProdKey,
			Long prodcatKey, HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"fetchCustomerPennantRequestForSOL : Start : " + applicationId);
		CreateCustomerPennantRequest customerRequest = null;

		try {
			List<UserProfile> userProfileList = getUserDetails(applicationId, headers);
			UserProfile userProfile = null;
			for (UserProfile user : userProfileList) {
				if (user.getApplicationUserAttributeType().equals(DisbursementConstants.MAIN_APPLICANT)) {
					userProfile = user;
				} else {
					logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Primary UserApplicantKey Not Found");
					throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
							new ErrorBean("CDS-010", "Primary UserApplicantKey Not Found"));
				}
			}

			String userAttributeKey = userProfile.getApplicationUserAttributeKey();
			ApplicationDetails applicationDetails = disbursementUtil.fetchApplicationDetails(applicationId,
					userAttributeKey, headers);

			CustomerDisbDetails customerDisbDetails = disbursementUtil.fetchCustomerDisbDetails(applicationId,
					userAttributeKey, headers);
			List<BankDetailsResponse> bankDetails = disbursementUtil.fetchBankDetails(applicationId, headers);
			customerRequest = disbursementMapperUtil.mapCustomerPennantRequestForSOL(userProfile, applicationDetails,
					customerDisbDetails, bankDetails, l3ProdKey, prodcatKey, headers);
		} catch (DisbursementServiceException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Exception occured : " + e);
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Resource Not Found. ");
				throw new DisbursementServiceException(HttpStatus.NOT_FOUND,
						new ErrorBean("CDS-002", "Resource not found."));
			}
			throw e;
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Exception occured while Get Credit Parameters" + e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CDS-001", "Exception occured while Get Credit Parameters"));
		}
		return customerRequest;
	}

	@SuppressWarnings("unchecked")
	private List<UserProfile> getUserDetails(String applicationId, HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getUserDetails : Start : " + applicationId);
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		List<UserProfile> userProfileList = new ArrayList<>();
		String uri = null;
		UriComponents builder = null;
		params.put("applicationid", applicationId);
		builder = UriComponentsBuilder.fromHttpUrl(getUserProfilesUrl).queryParam("allApplicantRquired", true).build();
		uri = builder.toUriString();

		ResponseEntity<String> userProfileResponse = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, uri, String.class, params, null, headers);
		if (null != userProfileResponse.getBody()) {
			UserProfile[] userDetails = gson.fromJson(userProfileResponse.getBody(), UserProfile[].class);
			userProfileList = Arrays.asList(userDetails);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getUserDetails : End : " + applicationId);
		return userProfileList;
	}

	public void processCustomerRequestForFunded(FundedDisbursementEventRequestBean request) {
		try {
			CustomerProcessorVariables processorVariables = new CustomerProcessorVariables();
			HttpHeaders headers = new HttpHeaders();
			CreateCustomerPennantRequest customerRequest = disbursementMapperUtil
					.mapCustomerPennatRequestForFunded(request);

			Long startTime = null;
			Long stopTime = null;
			try {
				startTime = System.currentTimeMillis();
				FibonacciPollInterval fibonacci = new FibonacciPollInterval(TimeUnit.SECONDS);
				Awaitility.setDefaultTimeout(300, TimeUnit.SECONDS);
				Awaitility.with().pollInterval(fibonacci).await().atMost(300, TimeUnit.SECONDS)
						.until(() -> null != (executeLMSRequestforCustomerForFunded(customerRequest, request, headers,
								processorVariables)));
				stopTime = System.currentTimeMillis();
			} catch (ConditionTimeoutException e) {
				Date date = new Date();
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "TimeOut Flow in Create CreateCustomer ::");
				RetryRegistrationBean existingRecords = null;
				Long activeTranchKey = Long.valueOf(request.getApplicationDetails().getPaymentQuoteId());
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"TimeOut Flow in Create CreateCustomer :: activeTranchKey " + activeTranchKey);

				existingRecords = disbursementUtil.fetchExistingTransaction(activeTranchKey.toString(),
						request.getApplicationId(), headers);
				FundedDisbursementRequestBean rquestBean = new FundedDisbursementRequestBean();
				rquestBean.setApplicationId(request.getApplicationId());
				rquestBean.setProductCode(request.getApplicationDetails().getL3ProductCode());
				rquestBean.setQuoteNumber(request.getApplicationDetails().getQuoteNumber());

				RetryRegistrationBean bean = new RetryRegistrationBean();
				bean.setActiveFlg(true);
				if (null != existingRecords) {
					bean.setCurrentRetryCount(existingRecords.getCurrentRetryCount() + 1l);
				} else {
					bean.setCurrentRetryCount(1l);
				}
				rquestBean.setStage("CREATE_CUSTOMER");
				rquestBean.setTransactionId(activeTranchKey.toString());
				bean.setErrorCode("BFL_DISBURSEMENT_CREATE_LOAN");
				bean.setNextReryTime(new Timestamp(date.getTime()).toString());
				bean.setRetryClass("FundedDisbursementController");
				bean.setRetryMechanism("Endpoint");
				bean.setRetryMethod(initiateBflDisbUrl);
				bean.setRetryPayload(disbursementUtil.objectToJson(rquestBean));
				bean.setRetryStatus("Pending");
				bean.setSource("OM-Insurance-Disbursement");
				bean.setTimestamp(new Timestamp(date.getTime()).toString());
				bean.setTransactionId(activeTranchKey);
				bean.setErrorKey(request.getApplicationId() + activeTranchKey);
				if (bean.getCurrentRetryCount() > 5) {
					bean.setRetryStatus("Failed");
					bean.setActiveFlg(false);
				}
				processorVariables.setRetryMechanism(true);
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"TimeOut Flow in Create CreateCustomer before Save  :: activeTranchKey " + activeTranchKey);

				disbursementUtil.saveretrytransaction(activeTranchKey.toString(), request.getApplicationId(), bean,
						headers);
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Time Out Exception occurred : Create Customer Call ");
				throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
						"Exception occurred in Create Customer Call");
			}

			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Completed Funded CreateCustomerResponseBean ::");
			if (null != processorVariables.getCustomerResponseString() && !processorVariables.isRetryMechanism()) {
				disbursementUtil.addFundedDisbursementRecords(request.getApplicationId(),
						request.getApplicationDetails().getQuoteNumber(), mapToJson(customerRequest),
						processorVariables.getCustomerResponseString(), DisbursementConstants.LMS_CUSTOMER_SOURCE,
						null != startTime ? startTime.toString() : null, null != stopTime ? stopTime.toString() : null);

				CreateCustomerResponseBean response = processCustomerLmsResponseForFunded(request,
						processorVariables.getCustomerResponseString());
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Exception occurred : Create Funded Customer Call ",
					e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred in Funded Create Customer Call");
		}
	}

	private String executeLMSRequestforCustomerForFunded(CreateCustomerPennantRequest customerRequest,
			FundedDisbursementEventRequestBean request, HttpHeaders headers,
			CustomerProcessorVariables processorVariables) {
		String response = executeLMSRequestforCustomer(customerRequest,
				request.getApplicationDetails().getL3ProductCode(), request.getApplicationId(), headers);
		processorVariables.setCustomerResponseString(response);
		return response;
	}

	private CreateCustomerResponseBean processCustomerLmsResponseForFunded(FundedDisbursementEventRequestBean request,
			String customerResponseString) {
		Gson gson = new Gson();
		String applicationId = request.getApplicationId();
		HttpHeaders headers = new HttpHeaders();
		CreateCustomerResponseBean finalResponse = new CreateCustomerResponseBean();
		CreateCustomerPennatResponse customerPennatResponse = gson.fromJson(customerResponseString,
				CreateCustomerPennatResponse.class);
		String returnCode = customerPennatResponse.getReturnStatus().getReturnCode();
		if (DisbursementConstants.PENNANT_SUCCES_CODE.equals(returnCode)) {
			finalResponse.setCif(customerPennatResponse.getCif());
			finalResponse.setStatus(Status.SUCCESS);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside PENNANT_SUCCES_CODE");
			saveFundedDisbursement(request, customerPennatResponse.getCif());
			saveAppSysCode(applicationId, customerPennatResponse.getCif(), headers);

		} else if (DisbursementConstants.PENNAT_CUST_DEDUPE_RESP_CODE.equals(returnCode)) {
			finalResponse.setCif(customerPennatResponse.getDedup().get(0).getCif());
			finalResponse.setStatus(Status.SUCCESS);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside PENNAT_CUST_DEDUPE_RESP_CODE");
			saveFundedDisbursement(request, customerPennatResponse.getDedup().get(0).getCif());
			saveAppSysCode(applicationId, customerPennatResponse.getDedup().get(0).getCif(), headers);

		} else {
			finalResponse.setReturnStatus(customerPennatResponse.getReturnStatus());
			finalResponse.setStatus(Status.FAILURE);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside PENNAT_FAILURE_CODE");
			// Update Mongo table Disbursement_Records
			// Raise insurance event stage : create customer, pass errorcode/desc
			boolean eventFlag = disbursementUtil.raiseInsuranceEventPostDisbursement(request, null,
					customerPennatResponse.getReturnStatus(), "CREATE_CUSTOMER", null,
					DisbursementConstants.BFL_DISBURSEMENT_STATUS);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"End processCustomerLmsResponseForFunded EventFlag:" + eventFlag);

			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"create Customer Call failed:" + request.getApplicationId());
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CDS-300", "Customer Call Failed"));
		}

		return finalResponse;

	}

	private void saveFundedDisbursement(FundedDisbursementEventRequestBean request, String cif) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside saveFundedDisbursement");
		try {
			FundedDisbursementMongoObject obj = new FundedDisbursementMongoObject();
			obj.setApplicationKey(Long.valueOf(request.getApplicationDetails().getApplicationNo()));
			obj.setQuoteNumber(request.getApplicationDetails().getQuoteNumber());
			obj.setDisbInitiatedBy(request.getApplicationDetails().getDisbInitiatedBy());
			obj.setDisbDate(new Date(System.currentTimeMillis()).toString());
			obj.setDisbursementStatus("INITIATED");
			obj.setId(request.getApplicationDetails().getApplicationNo()
					+ request.getApplicationDetails().getQuoteNumber());
			obj.setCif(cif);
			mongoDbRepo.insertDocumentDB(disbursementMongoTemplate, obj, insDisbursementMongoDB);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "saveFundedDisbursement update failed: ");
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CDS-200", "Unable to update Mongo DB table"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "End saveFundedDisbursement");

	}

	public void processCustomerRequestForPROL(GlobalDataBean data) {

		CustomerProcessorVariables processorVariabes = new CustomerProcessorVariables();
		HttpHeaders headers = generateHeaders(data);
		try {

			List<UserProfile> userProfileList = getUserDetails(data.getApplicationKey(), headers);
			// Main Applicant
			UserProfile userProfile_Primary = userProfileList.stream()
					.filter(x -> x.getApplicationUserAttributeType().equals(DisbursementConstants.MAIN_APPLICANT))
					.collect(Collectors.toList()).get(0);
			data.setAppAtrKey(userProfile_Primary.getApplicationUserAttributeKey());
			CustomerDisbDetails customerDisbDetails = disbursementUtil
					.fetchCustomerDisbDetails(data.getApplicationKey(), data.getAppAtrKey(), headers);
			ApplicationDetails applicationDetails_Primary = disbursementUtil
					.fetchApplicationDetails(data.getApplicationKey(), data.getAppAtrKey(), headers);
			List<BankDetailsResponse> bankDetails = null;
			bankDetails = disbursementUtil.fetchBankDetails(data.getApplicationKey(), headers);
			CreateCustomerPennantRequest customerRequest_Primary = disbursementMapperUtil
					.mapCustomerPennantRequestForPROL(userProfile_Primary, applicationDetails_Primary,
							customerDisbDetails, bankDetails, false, data.getL3ProductKey(), headers);
			data.setMobile(customerRequest_Primary.getPhones().get(0).getPhoneNumber());
			Optional<EmailInfo> personalEmailInfo = customerRequest_Primary.getEmails().stream()
					.filter(x -> x.getCustEMailTypeCode().equalsIgnoreCase("PERSONAL")).findAny();
			data.setEmail(personalEmailInfo.get().getCustEMail());
			Long startTime = null;
			Long stopTime = null;
			try {
				startTime = System.currentTimeMillis();
				FibonacciPollInterval fibonacci = new FibonacciPollInterval(TimeUnit.SECONDS);
				Awaitility.setDefaultTimeout(300, TimeUnit.SECONDS);
				Awaitility.with().pollInterval(fibonacci).await().atMost(300, TimeUnit.SECONDS)
						.until(() -> null != (executeLMSRequestforCustomerForPrimary(customerRequest_Primary, data,
								headers, processorVariabes)));
				stopTime = System.currentTimeMillis();
			} catch (ConditionTimeoutException e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Completed CreateCustomerResponseBean ::");
				List<TranchBean> trnchLst = disbursementUtil.fetchTranchDetails(data.getApplicationKey(), headers);
				Long activeTranchKey = trnchLst.get(0).getTranchkey();
				DisbursementEventRequestBean rquestBean = new DisbursementEventRequestBean();
				rquestBean.setApplicantId(data.getApplicantKey());
				rquestBean.setApplicationId(data.getApplicationKey());
				rquestBean.setProductCode(data.getL3ProductCode());
				RetryRegistrationBean bean = new RetryRegistrationBean();
				bean.setActiveFlg(true);
				bean.setCurrentRetryCount(0l);
				bean.setErrorCode("DISBURSEMENT_CREATE_CUSTOMER");
				bean.setNextReryTime(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(5)).toString());
				bean.setRetryClass("CreditDisbursementController");
				bean.setRetryMechanism("Endpoint");
				bean.setRetryMethod(initiateDisbUrl);
				bean.setRetryPayload(disbursementUtil.objectToJson(rquestBean));
				bean.setRetryStatus("Pending");
				bean.setSource("OM-Credit-Disbursement");
				Date date = new Date();
				bean.setTimestamp(new Timestamp(date.getTime()).toString());
				bean.setTransactionId(activeTranchKey);
				disbursementUtil.saveretrytransaction(activeTranchKey.toString(), data.getApplicationKey(), bean,
						headers);
			}
			CreateCustomerResponseBean response_Primary = null;
			if (null != processorVariabes.getCustomerResponseString_Primary()) {
				disbursementUtil.addDisbursementRecords(data.getApplicationKey(), data.getApplicantKey(),
						mapToJson(customerRequest_Primary), processorVariabes.getCustomerResponseString_Primary(),
						DisbursementConstants.LMS_CUSTOMER_SOURCE, null != startTime ? startTime.toString() : null,
						null != stopTime ? stopTime.toString() : null);
				response_Primary = processCustomerLmsResponse(data, data.getApplicantKey().toString(),
						processorVariabes.getCustomerResponseString_Primary(), null, false);
			}

			CreditReviewStatusBean creditReviewStatusBean = disbursementUtil.getCreditReviewDetails(data.getApplicationKey(), headers);
			if (null != creditReviewStatusBean && null != creditReviewStatusBean.getIndividualCoapplicantRequired()
					&& creditReviewStatusBean.getIndividualCoapplicantRequired().equals("1")) {
				individualCoApplicant(data, headers, processorVariabes);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Exception occurred : Create Customer Call ", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred in Create Customer Call");
		}
	}

}