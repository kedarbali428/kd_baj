package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class LoanDetailBean {
	
	private String loanType;
	
	private String loanTypeId;
	
	private String loanAcctNumber;
	
	private Number loanAmount;
	
	private Number loanISAmount;
	
	private Number outstandingLoanISAmount;

	private Number outstandingLoanAmount;
	
	private Number emiAmount;
	
	private boolean emiFlag;
	
	private Number loanPaidPercent;
	
	private List<LoanDetailBean> linkedLanNo;
	
	private Number emiPaid;
	
	private List<CoApplicant> coApplicant;
	
	private Number overdueEMIAmount;
	
	private Number roi;
	
	private Number remainingTenure;
	
	private Number totalEmi;
	
	private String disbursementDate;
	
	private String repaymentMode;
	
	private boolean changeRepaymentMode;
	
	private Number totalEMIReceived;
	
	private Number EMICylceDate;
	
	private boolean changeEMICycleDate;
	
	private String firstEMIDate;
	
	private String lastEMIDate;
	
	private List<EMIHoliday> emiHoliday;
	
	private List<FeeBean> fees;
	
	private boolean changeHolidayMonth;
	
	private boolean isFreeze;
	
	private boolean isUnderLimitMonth;

	private Integer  limitMonth;
	
	private boolean showSchedule;
	
	private Double totalLimit;
	
	private Double availableAmount;
	
	private boolean isblock;
	
	
	private List<com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBean> disbursement;
	
	private Double totalDisburseAmount;
	
	private Double amountAvailableDisbursement;
	
	private com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBean disbursementBean;
	
	private MissedEMIDetailBean missedEMIDetails;
	
	private Number finAssetValue;
	
	private String nextEmiDate;
	
	private Double loanPaidAmount;
	
	private String loanDisburseStatus;
	
	private String loanStatus;
	
	private String scheduleMethod;
	
	private String productType;
	
	private String productTypeId;
	
	private String loanStartDate;
	
	private String loanMsgFreezeDescription;
	
	private String loanMsgUnderMonthDescription;
	
	private boolean emiBounceIS;
	
	private String emiBounceISDescription;
	
	private Number minimumAmountToPay;

	private Number applicationNo;
	
	private String defaultRecalType;
	
	private Number currentDroplineLimit;
	
	private Number utilisation;
	
	private Number availableLimit;
	
	private String overdueChargesExists;
	
	private List<AdvanceEMIBean> advanceEMIs;
	
	public Number getCurrentDroplineLimit() {
		return currentDroplineLimit;
	}

	public void setCurrentDroplineLimit(Number currentDroplineLimit) {
		this.currentDroplineLimit = currentDroplineLimit;
	}

	public Number getUtilisation() {
		return utilisation;
	}

	public void setUtilisation(Number utilisation) {
		this.utilisation = utilisation;
	}

	public Number getAvailableLimit() {
		return availableLimit;
	}

	public void setAvailableLimit(Number availableLimit) {
		this.availableLimit = availableLimit;
	}

	public String getDefaultRecalType() {
		return defaultRecalType;
	}

	public void setDefaultRecalType(String defaultRecalType) {
		this.defaultRecalType = defaultRecalType;
	}

	public Number getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(Number applicationNo) {
		this.applicationNo = applicationNo;
	}

	public Number getMinimumAmountToPay() {
		return minimumAmountToPay;
	}

	public void setMinimumAmountToPay(Number minimumAmountToPay) {
		this.minimumAmountToPay = minimumAmountToPay;
	}

	public boolean isEmiBounceIS() {
		return emiBounceIS;
	}

	public void setEmiBounceIS(boolean emiBounceIS) {
		this.emiBounceIS = emiBounceIS;
	}

	public String getEmiBounceISDescription() {
		return emiBounceISDescription;
	}

	public void setEmiBounceISDescription(String emiBounceISDescription) {
		this.emiBounceISDescription = emiBounceISDescription;
	}

	public Number getOutstandingLoanISAmount() {
		return outstandingLoanISAmount;
	}

	public void setOutstandingLoanISAmount(Number outstandingLoanISAmount) {
		this.outstandingLoanISAmount = outstandingLoanISAmount;
	}

	public Number getLoanISAmount() {
		return loanISAmount;
	}

	public void setLoanISAmount(Number loanISAmount) {
		this.loanISAmount = loanISAmount;
	}

	public Integer getLimitMonth() {
		return limitMonth;
	}

	public void setLimitMonth(Integer limitMonth) {
		this.limitMonth = limitMonth;
	}

	public String getLoanMsgFreezeDescription() {
		return loanMsgFreezeDescription;
	}

	public void setLoanMsgFreezeDescription(String loanMsgFreezeDescription) {
		this.loanMsgFreezeDescription = loanMsgFreezeDescription;
	}

	public String getLoanMsgUnderMonthDescription() {
		return loanMsgUnderMonthDescription;
	}

	public void setLoanMsgUnderMonthDescription(String loanMsgUnderMonthDescription) {
		this.loanMsgUnderMonthDescription = loanMsgUnderMonthDescription;
	}

	public String getLoanStartDate() {
		return loanStartDate;
	}

	public void setLoanStartDate(String loanStartDate) {
		this.loanStartDate = loanStartDate;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductTypeId() {
		return productTypeId;
	}

	public void setProductTypeId(String productTypeId) {
		this.productTypeId = productTypeId;
	}

	public String getScheduleMethod() {
		return scheduleMethod;
	}

	public void setScheduleMethod(String scheduleMethod) {
		this.scheduleMethod = scheduleMethod;
	}

	public String getLoanStatus() {
		return loanStatus;
	}

	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}

	public String getLoanDisburseStatus() {
		return loanDisburseStatus;
	}

	public void setLoanDisburseStatus(String loanDisburseStatus) {
		this.loanDisburseStatus = loanDisburseStatus;
	}

	public Double getLoanPaidAmount() {
		return loanPaidAmount;
	}

	public void setLoanPaidAmount(Double loanPaidAmount) {
		this.loanPaidAmount = loanPaidAmount;
	}

	public Number getFinAssetValue() {
		return finAssetValue;
	}

	public void setFinAssetValue(Number finAssetValue) {
		this.finAssetValue = finAssetValue;
	}

	public String getLoanTypeId() {
		return loanTypeId;
	}

	public void setLoanTypeId(String loanTypeId) {
		this.loanTypeId = loanTypeId;
	}

	public String getNextEmiDate() {
		return nextEmiDate;
	}

	public void setNextEmiDate(String nextEmiDate) {
		this.nextEmiDate = nextEmiDate;
	}

	public MissedEMIDetailBean getMissedEMIDetails() {
		return missedEMIDetails;
	}

	public void setMissedEMIDetails(MissedEMIDetailBean missedEMIDetails) {
		this.missedEMIDetails = missedEMIDetails;
	}

	public com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBean getDisbursementBean() {
		return disbursementBean;
	}

	public void setDisbursementBean(com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBean disbursementBean) {
		this.disbursementBean = disbursementBean;
	}

	public Double getAmountAvailableDisbursement() {
		return amountAvailableDisbursement;
	}

	public void setAmountAvailableDisbursement(Double amountAvailableDisbursement) {
		this.amountAvailableDisbursement = amountAvailableDisbursement;
	}

	public Double getTotalDisburseAmount() {
		return totalDisburseAmount;
	}

	public void setTotalDisburseAmount(Double totalDisburseAmount) {
		this.totalDisburseAmount = totalDisburseAmount;
	}

	public List<com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBean> getDisbursement() {
		return disbursement;
	}

	public void setDisbursement(List<com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBean> disbursement) {
		this.disbursement = disbursement;
	}

	public Double getTotalLimit() {
		return totalLimit;
	}

	public void setTotalLimit(Double totalLimit) {
		this.totalLimit = totalLimit;
	}

	public Double getAvailableAmount() {
		return availableAmount;
	}

	public void setAvailableAmount(Double availableAmount) {
		this.availableAmount = availableAmount;
	}

	public boolean isIsblock() {
		return isblock;
	}

	public void setIsblock(boolean isblock) {
		this.isblock = isblock;
	}

	public boolean isShowSchedule() {
		return showSchedule;
	}

	public void setShowSchedule(boolean showSchedule) {
		this.showSchedule = showSchedule;
	}

	public Number getTotalEmi() {
		return totalEmi;
	}

	public void setTotalEmi(Number totalEmi) {
		this.totalEmi = totalEmi;
	}

	public boolean isFreeze() {
		return isFreeze;
	}

	public void setFreeze(boolean isFreeze) {
		this.isFreeze = isFreeze;
	}

	public boolean isUnderLimitMonth() {
		return isUnderLimitMonth;
	}

	public void setUnderLimitMonth(boolean isUnderLimitMonth) {
		this.isUnderLimitMonth = isUnderLimitMonth;
	}

	public List<FeeBean> getFees() {
		return fees;
	}

	public void setFees(List<FeeBean> fees) {
		this.fees = fees;
	}

	public String getDisbursementDate() {
		return disbursementDate;
	}

	public void setDisbursementDate(String disbursementDate) {
		this.disbursementDate = disbursementDate;
	}

	public String getRepaymentMode() {
		return repaymentMode;
	}

	public void setRepaymentMode(String repaymentMode) {
		this.repaymentMode = repaymentMode;
	}

	public boolean isChangeRepaymentMode() {
		return changeRepaymentMode;
	}

	public void setChangeRepaymentMode(boolean changeRepaymentMode) {
		this.changeRepaymentMode = changeRepaymentMode;
	}

	public Number getTotalEMIReceived() {
		return totalEMIReceived;
	}

	public void setTotalEMIReceived(Number totalEMIReceived) {
		this.totalEMIReceived = totalEMIReceived;
	}

	public Number getEMICylceDate() {
		return EMICylceDate;
	}

	public void setEMICylceDate(Number eMICylceDate) {
		EMICylceDate = eMICylceDate;
	}

	public boolean isChangeEMICycleDate() {
		return changeEMICycleDate;
	}

	public void setChangeEMICycleDate(boolean changeEMICycleDate) {
		this.changeEMICycleDate = changeEMICycleDate;
	}

	public String getFirstEMIDate() {
		return firstEMIDate;
	}

	public void setFirstEMIDate(String firstEMIDate) {
		this.firstEMIDate = firstEMIDate;
	}

	public String getLastEMIDate() {
		return lastEMIDate;
	}

	public void setLastEMIDate(String lastEMIDate) {
		this.lastEMIDate = lastEMIDate;
	}

	public List<EMIHoliday> getEmiHoliday() {
		return emiHoliday;
	}

	public void setEmiHoliday(List<EMIHoliday> emiHoliday) {
		this.emiHoliday = emiHoliday;
	}

	public boolean isChangeHolidayMonth() {
		return changeHolidayMonth;
	}

	public void setChangeHolidayMonth(boolean changeHolidayMonth) {
		this.changeHolidayMonth = changeHolidayMonth;
	}

	public Number getLoanPaidPercent() {
		return loanPaidPercent;
	}

	public void setLoanPaidPercent(Number loanPaidPercent) {
		this.loanPaidPercent = loanPaidPercent;
	}

	public Number getOverdueEMIAmount() {
		return overdueEMIAmount;
	}

	public void setOverdueEMIAmount(Number overdueEMIAmount) {
		this.overdueEMIAmount = overdueEMIAmount;
	}

	public Number getRoi() {
		return roi;
	}

	public void setRoi(Number roi) {
		this.roi = roi;
	}

	public Number getRemainingTenure() {
		return remainingTenure;
	}

	public void setRemainingTenure(Number remainingTenure) {
		this.remainingTenure = remainingTenure;
	}

	public boolean isEmiFlag() {
		return emiFlag;
	}

	public void setEmiFlag(boolean emiFlag) {
		this.emiFlag = emiFlag;
	}
	
	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public Number getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(Number loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Number getOutstandingLoanAmount() {
		return outstandingLoanAmount;
	}

	public void setOutstandingLoanAmount(Number outstandingLoanAmount) {
		this.outstandingLoanAmount = outstandingLoanAmount;
	}

	public Number getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(Number emiAmount) {
		this.emiAmount = emiAmount;
	}

	public String getLoanAcctNumber() {
		return loanAcctNumber;
	}

	public void setLoanAcctNumber(String loanAcctNumber) {
		this.loanAcctNumber = loanAcctNumber;
	}

	
	public Number getEmiPaid() {
		return emiPaid;
	}

	public void setEmiPaid(Number emiPaid) {
		this.emiPaid = emiPaid;
	}

	public List<CoApplicant> getCoApplicant() {
		return coApplicant;
	}

	public void setCoApplicant(List<CoApplicant> coApplicant) {
		this.coApplicant = coApplicant;
	}

	public List<LoanDetailBean> getLinkedLanNo() {
		return linkedLanNo;
	}

	public void setLinkedLanNo(List<LoanDetailBean> linkedLanNo) {
		this.linkedLanNo = linkedLanNo;
	}

	public String getOverdueChargesExists() {
		return overdueChargesExists;
	}

	public void setOverdueChargesExists(String overdueChargesExists) {
		this.overdueChargesExists = overdueChargesExists;
	}

	public List<AdvanceEMIBean> getAdvanceEMIs() {
		return advanceEMIs;
	}

	public void setAdvanceEMIs(List<AdvanceEMIBean> advanceEMIs) {
		this.advanceEMIs = advanceEMIs;
	}

	@Override
	public String toString() {
		return "LoanDetailBean [loanType=" + loanType + ", loanTypeId=" + loanTypeId + ", loanAcctNumber="
				+ loanAcctNumber + ", loanAmount=" + loanAmount + ", loanISAmount=" + loanISAmount
				+ ", outstandingLoanISAmount=" + outstandingLoanISAmount + ", outstandingLoanAmount="
				+ outstandingLoanAmount + ", emiAmount=" + emiAmount + ", emiFlag=" + emiFlag + ", loanPaidPercent="
				+ loanPaidPercent + ", linkedLanNo=" + linkedLanNo + ", emiPaid=" + emiPaid + ", coApplicant="
				+ coApplicant + ", overdueEMIAmount=" + overdueEMIAmount + ", roi=" + roi + ", remainingTenure="
				+ remainingTenure + ", totalEmi=" + totalEmi + ", disbursementDate=" + disbursementDate
				+ ", repaymentMode=" + repaymentMode + ", changeRepaymentMode=" + changeRepaymentMode
				+ ", totalEMIReceived=" + totalEMIReceived + ", EMICylceDate=" + EMICylceDate + ", changeEMICycleDate="
				+ changeEMICycleDate + ", firstEMIDate=" + firstEMIDate + ", lastEMIDate=" + lastEMIDate
				+ ", emiHoliday=" + emiHoliday + ", fees=" + fees + ", changeHolidayMonth=" + changeHolidayMonth
				+ ", isFreeze=" + isFreeze + ", isUnderLimitMonth=" + isUnderLimitMonth + ", limitMonth=" + limitMonth
				+ ", showSchedule=" + showSchedule + ", totalLimit=" + totalLimit + ", availableAmount="
				+ availableAmount + ", isblock=" + isblock + ", disbursement=" + disbursement + ", totalDisburseAmount="
				+ totalDisburseAmount + ", amountAvailableDisbursement=" + amountAvailableDisbursement
				+ ", disbursementBean=" + disbursementBean + ", missedEMIDetails=" + missedEMIDetails
				+ ", finAssetValue=" + finAssetValue + ", nextEmiDate=" + nextEmiDate + ", loanPaidAmount="
				+ loanPaidAmount + ", loanDisburseStatus=" + loanDisburseStatus + ", loanStatus=" + loanStatus
				+ ", scheduleMethod=" + scheduleMethod + ", productType=" + productType + ", productTypeId="
				+ productTypeId + ", loanStartDate=" + loanStartDate + ", loanMsgFreezeDescription="
				+ loanMsgFreezeDescription + ", loanMsgUnderMonthDescription=" + loanMsgUnderMonthDescription
				+ ", emiBounceIS=" + emiBounceIS + ", emiBounceISDescription=" + emiBounceISDescription
				+ ", minimumAmountToPay=" + minimumAmountToPay + ", applicationNo=" + applicationNo
				+ ", defaultRecalType=" + defaultRecalType + ", currentDroplineLimit=" + currentDroplineLimit
				+ ", utilisation=" + utilisation + ", availableLimit=" + availableLimit + ", overdueChargesExists="
				+ overdueChargesExists + ", advanceEMIs=" + advanceEMIs + "]";
	}

}
