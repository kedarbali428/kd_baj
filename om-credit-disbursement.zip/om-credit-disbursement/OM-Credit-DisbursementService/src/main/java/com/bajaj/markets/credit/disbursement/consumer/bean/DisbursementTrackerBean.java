package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.io.Serializable;

public class DisbursementTrackerBean implements Serializable {
	private static final long serialVersionUID = 6290941142216154768L;
	
	private Long appdisbursmenttrackkey;
	
	private Long apptranchedetkey;
	
	private String status;
	
	private String disbursmentstage;
	
	private String error;
	
	private Long errorretryable;
	
	private String errorreason;
	
	private Long isActive;
	
	private Long applicationId;
	
	public Long getAppdisbursmenttrackkey() {
		return appdisbursmenttrackkey;
	}
	public void setAppdisbursmenttrackkey(Long appdisbursmenttrackkey) {
		this.appdisbursmenttrackkey = appdisbursmenttrackkey;
	}
	public Long getApptranchedetkey() {
		return apptranchedetkey;
	}
	public void setApptranchedetkey(Long apptranchedetkey) {
		this.apptranchedetkey = apptranchedetkey;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDisbursmentstage() {
		return disbursmentstage;
	}
	public void setDisbursmentstage(String disbursmentstage) {
		this.disbursmentstage = disbursmentstage;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	public String getErrorreason() {
		return errorreason;
	}
	public void setErrorreason(String errorreason) {
		this.errorreason = errorreason;
	}
	
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public Long getErrorretryable() {
		return errorretryable;
	}
	public void setErrorretryable(Long errorretryable) {
		this.errorretryable = errorretryable;
	}
	public Long getIsActive() {
		return isActive;
	}
	public void setIsActive(Long isActive) {
		this.isActive = isActive;
	}
	
	
	
	
	
}
