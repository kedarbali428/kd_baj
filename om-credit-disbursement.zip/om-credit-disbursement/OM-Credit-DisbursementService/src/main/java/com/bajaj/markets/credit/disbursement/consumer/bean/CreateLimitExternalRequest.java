package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class CreateLimitExternalRequest {
	
	private String cif;
	private String ccyDesc;
	private String customerGroup;
	private String structureCode;
	private String structureName;
	private String ccy;
	private String expiryDate;
	private String reviewDate;
	private String remarks;
	private Boolean active;
	private List<LimitDetailBean> limitDetail;
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public String getCustomerGroup() {
		return customerGroup;
	}
	public void setCustomerGroup(String customerGroup) {
		this.customerGroup = customerGroup;
	}
	public String getStructureCode() {
		return structureCode;
	}
	public void setStructureCode(String structureCode) {
		this.structureCode = structureCode;
	}
	public String getCcy() {
		return ccy;
	}
	public void setCcy(String ccy) {
		this.ccy = ccy;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getReviewDate() {
		return reviewDate;
	}
	public void setReviewDate(String reviewDate) {
		this.reviewDate = reviewDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	
	public String getCcyDesc() {
		return ccyDesc;
	}
	public void setCcyDesc(String ccyDesc) {
		this.ccyDesc = ccyDesc;
	}
	public String getStructureName() {
		return structureName;
	}
	public void setStructureName(String structureName) {
		this.structureName = structureName;
	}
	public List<LimitDetailBean> getLimitDetail() {
		return limitDetail;
	}
	public void setLimitDetail(List<LimitDetailBean> limitDetail) {
		this.limitDetail = limitDetail;
	}
}
