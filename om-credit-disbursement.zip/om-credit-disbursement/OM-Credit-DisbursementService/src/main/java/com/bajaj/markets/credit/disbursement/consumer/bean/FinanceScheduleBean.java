package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class FinanceScheduleBean {
	
	private FinanceDetailBean financeDetail;
	private List<FeeDetailsBean> fees;
	
	private List<PlanEMIHMonthsBean> planEMIHmonths;
	private List<VasBean> vas;
	private List <IntervalFeeBean> intervalFee;
	
	private SummaryBean summary;
	
	public FinanceDetailBean getFinanceDetail() {
		return financeDetail;
	}
	public List<FeeDetailsBean> getFees() {
		return fees;
	}
	public List<PlanEMIHMonthsBean> getPlanEMIHmonths() {
		return planEMIHmonths;
	}
	public List<VasBean> getVas() {
		return vas;
	}
	public void setFinanceDetail(FinanceDetailBean financeDetail) {
		this.financeDetail = financeDetail;
	}
	public void setFees(List<FeeDetailsBean> fees) {
		this.fees = fees;
	}
	public void setPlanEMIHmonths(List<PlanEMIHMonthsBean> planEMIHmonths) {
		this.planEMIHmonths = planEMIHmonths;
	}
	public void setVas(List<VasBean> vas) {
		this.vas = vas;
	}
	public List<IntervalFeeBean> getIntervalFee() {
		return intervalFee;
	}
	public void setIntervalFee(List<IntervalFeeBean> intervalFee) {
		this.intervalFee = intervalFee;
	}
	public SummaryBean getSummary() {
		return summary;
	}
	public void setSummary(SummaryBean summary) {
		this.summary = summary;
	}
	
}
