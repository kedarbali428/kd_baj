package com.bajaj.markets.credit.disbursement.consumer.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PartnerProductMapMaster {

	private Long partnerproductmapkey;

	private String productcode;

	private Integer businessverticalmastkey;

	private String finnoneloanprodcode;

	private Long finnonecompanyid;

	private Long finnonetypeid;

	private Long finnoneschemecode;

	private Long finnoneinsflag;

	private String finnoneuploadflag;

	private Long finnonedme;

	private Long finnonedsa;

	private String finnonecreditprogram;

	private String pennantloantype;

	private String pennantvasproduct;

	private String pennatvasfee;

	private String pennantvasmanufacturer;

	private String pennantaccountingset;

	private Long pennantpromotion;

	private Long pennantstp;

	private String uicategory;

	private String policytype;

	private String finnoneglcode;

	public Long getPartnerproductmapkey() {
		return partnerproductmapkey;
	}

	public void setPartnerproductmapkey(Long partnerproductmapkey) {
		this.partnerproductmapkey = partnerproductmapkey;
	}

	public String getProductcode() {
		return productcode;
	}

	public void setProductcode(String productcode) {
		this.productcode = productcode;
	}

	public Integer getBusinessverticalmastkey() {
		return businessverticalmastkey;
	}

	public void setBusinessverticalmastkey(Integer businessverticalmastkey) {
		this.businessverticalmastkey = businessverticalmastkey;
	}

	public String getFinnoneloanprodcode() {
		return finnoneloanprodcode;
	}

	public void setFinnoneloanprodcode(String finnoneloanprodcode) {
		this.finnoneloanprodcode = finnoneloanprodcode;
	}

	public Long getFinnonecompanyid() {
		return finnonecompanyid;
	}

	public void setFinnonecompanyid(Long finnonecompanyid) {
		this.finnonecompanyid = finnonecompanyid;
	}

	public Long getFinnonetypeid() {
		return finnonetypeid;
	}

	public void setFinnonetypeid(Long finnonetypeid) {
		this.finnonetypeid = finnonetypeid;
	}

	public Long getFinnoneschemecode() {
		return finnoneschemecode;
	}

	public void setFinnoneschemecode(Long finnoneschemecode) {
		this.finnoneschemecode = finnoneschemecode;
	}

	public Long getFinnoneinsflag() {
		return finnoneinsflag;
	}

	public void setFinnoneinsflag(Long finnoneinsflag) {
		this.finnoneinsflag = finnoneinsflag;
	}

	public String getFinnoneuploadflag() {
		return finnoneuploadflag;
	}

	public void setFinnoneuploadflag(String finnoneuploadflag) {
		this.finnoneuploadflag = finnoneuploadflag;
	}

	public Long getFinnonedme() {
		return finnonedme;
	}

	public void setFinnonedme(Long finnonedme) {
		this.finnonedme = finnonedme;
	}

	public Long getFinnonedsa() {
		return finnonedsa;
	}

	public void setFinnonedsa(Long finnonedsa) {
		this.finnonedsa = finnonedsa;
	}

	public String getFinnonecreditprogram() {
		return finnonecreditprogram;
	}

	public void setFinnonecreditprogram(String finnonecreditprogram) {
		this.finnonecreditprogram = finnonecreditprogram;
	}

	public String getPennantloantype() {
		return pennantloantype;
	}

	public void setPennantloantype(String pennantloantype) {
		this.pennantloantype = pennantloantype;
	}

	public String getPennantvasproduct() {
		return pennantvasproduct;
	}

	public void setPennantvasproduct(String pennantvasproduct) {
		this.pennantvasproduct = pennantvasproduct;
	}

	public String getPennatvasfee() {
		return pennatvasfee;
	}

	public void setPennatvasfee(String pennatvasfee) {
		this.pennatvasfee = pennatvasfee;
	}

	public String getPennantvasmanufacturer() {
		return pennantvasmanufacturer;
	}

	public void setPennantvasmanufacturer(String pennantvasmanufacturer) {
		this.pennantvasmanufacturer = pennantvasmanufacturer;
	}

	public String getPennantaccountingset() {
		return pennantaccountingset;
	}

	public void setPennantaccountingset(String pennantaccountingset) {
		this.pennantaccountingset = pennantaccountingset;
	}

	public Long getPennantpromotion() {
		return pennantpromotion;
	}

	public void setPennantpromotion(Long pennantpromotion) {
		this.pennantpromotion = pennantpromotion;
	}

	public Long getPennantstp() {
		return pennantstp;
	}

	public void setPennantstp(Long pennantstp) {
		this.pennantstp = pennantstp;
	}

	public String getUicategory() {
		return uicategory;
	}

	public void setUicategory(String uicategory) {
		this.uicategory = uicategory;
	}

	public String getPolicytype() {
		return policytype;
	}

	public void setPolicytype(String policytype) {
		this.policytype = policytype;
	}

	public String getFinnoneglcode() {
		return finnoneglcode;
	}

	public void setFinnoneglcode(String finnoneglcode) {
		this.finnoneglcode = finnoneglcode;
	}

	@Override
	public String toString() {
		return "PartnerProductMapMaster [partnerproductmapkey=" + partnerproductmapkey + ", productcode=" + productcode
				+ ", businessverticalmastkey=" + businessverticalmastkey + ", finnoneloanprodcode="
				+ finnoneloanprodcode + ", finnonecompanyid=" + finnonecompanyid + ", finnonetypeid=" + finnonetypeid
				+ ", finnoneschemecode=" + finnoneschemecode + ", finnoneinsflag=" + finnoneinsflag
				+ ", finnoneuploadflag=" + finnoneuploadflag + ", finnonedme=" + finnonedme + ", finnonedsa="
				+ finnonedsa + ", finnonecreditprogram=" + finnonecreditprogram + ", pennantloantype=" + pennantloantype
				+ ", pennantvasproduct=" + pennantvasproduct + ", pennatvasfee=" + pennatvasfee
				+ ", pennantvasmanufacturer=" + pennantvasmanufacturer + ", pennantaccountingset="
				+ pennantaccountingset + ", pennantpromotion=" + pennantpromotion + ", pennantstp=" + pennantstp
				+ ", uicategory=" + uicategory + ", policytype=" + policytype + ", finnoneglcode=" + finnoneglcode
				+ "]";
	}

}
