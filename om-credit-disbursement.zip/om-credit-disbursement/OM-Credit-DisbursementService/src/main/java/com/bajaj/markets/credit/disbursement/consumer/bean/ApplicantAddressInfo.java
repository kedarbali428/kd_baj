package com.bajaj.markets.credit.disbursement.consumer.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicantAddressInfo {

	private Long addrtypkey;
	private String buildingNo;
	private String FlatNo;
	private String Street;
	private String addrLine1;
	private String addrLine2;
	private Long prefferedflg;
	private String addressKey;
	
	public String getBuildingNo() {
		return buildingNo;
	}
	public void setBuildingNo(String buildingNo) {
		this.buildingNo = buildingNo;
	}
	public String getFlatNo() {
		return FlatNo;
	}
	public void setFlatNo(String flatNo) {
		FlatNo = flatNo;
	}
	public String getStreet() {
		return Street;
	}
	public void setStreet(String street) {
		Street = street;
	}
	public String getAddrLine1() {
		return addrLine1;
	}
	public void setAddrLine1(String addrLine1) {
		this.addrLine1 = addrLine1;
	}
	public String getAddrLine2() {
		return addrLine2;
	}
	public void setAddrLine2(String addrLine2) {
		this.addrLine2 = addrLine2;
	}
	public Long getAddrtypkey() {
		return addrtypkey;
	}
	public void setAddrtypkey(Long addrtypkey) {
		this.addrtypkey = addrtypkey;
	}
	public Long getPrefferedflg() {
		return prefferedflg;
	}
	public void setPrefferedflg(Long prefferedflg) {
		this.prefferedflg = prefferedflg;
	}
	public String getAddressKey() {
		return addressKey;
	}
	public void setAddressKey(String addressKey) {
		this.addressKey = addressKey;	
	}
}
