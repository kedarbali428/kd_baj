package com.bajaj.markets.credit.disbursement.consumer.bean;

public class BeneficiaryProcessorVariables {
	private String beneficiaryResponseString;
	private boolean isRetryMechanism;

	public String getBeneficiaryResponseString() {
		return beneficiaryResponseString;
	}

	public void setBeneficiaryResponseString(String beneficiaryResponseString) {
		this.beneficiaryResponseString = beneficiaryResponseString;
	}

	public boolean isRetryMechanism() {
		return isRetryMechanism;
	}

	public void setRetryMechanism(boolean isRetryMechanism) {
		this.isRetryMechanism = isRetryMechanism;
	}

}