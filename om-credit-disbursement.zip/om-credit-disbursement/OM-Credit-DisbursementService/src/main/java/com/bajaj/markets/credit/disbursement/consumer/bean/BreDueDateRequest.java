package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class BreDueDateRequest {
	private ArcduedateInput arcduedateInput;
	private List<AdditionalParameterDetail> additionalParameterDetail;

	public ArcduedateInput getArcduedateInput() {
		return arcduedateInput;
	}

	public void setArcduedateInput(ArcduedateInput arcduedateInput) {
		this.arcduedateInput = arcduedateInput;
	}

	public List<AdditionalParameterDetail> getAdditionalParameterDetail() {
		return additionalParameterDetail;
	}

	public void setAdditionalParameterDetail(List<AdditionalParameterDetail> additionalParameterDetail) {
		this.additionalParameterDetail = additionalParameterDetail;
	}
}