package com.bajaj.markets.credit.disbursement.consumer.bean;

public class AdvanceEMIBean {

	private Integer instNo;
	
	private Number instAmount;

	public Integer getInstNo() {
		return instNo;
	}

	public void setInstNo(Integer instNo) {
		this.instNo = instNo;
	}

	public Number getInstAmount() {
		return instAmount;
	}

	public void setInstAmount(Number instAmount) {
		this.instAmount = instAmount;
	}
	
	
}
