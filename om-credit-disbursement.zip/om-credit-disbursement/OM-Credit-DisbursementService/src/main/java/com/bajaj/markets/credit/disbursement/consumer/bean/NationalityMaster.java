package com.bajaj.markets.credit.disbursement.consumer.bean;

public class NationalityMaster {

	private Long nationalitykey;

	private String nationalitycode;

	public Long getNationalitykey() {
		return nationalitykey;
	}

	public void setNationalitykey(Long nationalitykey) {
		this.nationalitykey = nationalitykey;
	}

	public String getNationalitycode() {
		return nationalitycode;
	}

	public void setNationalitycode(String nationalitycode) {
		this.nationalitycode = nationalitycode;
	}
	
}
