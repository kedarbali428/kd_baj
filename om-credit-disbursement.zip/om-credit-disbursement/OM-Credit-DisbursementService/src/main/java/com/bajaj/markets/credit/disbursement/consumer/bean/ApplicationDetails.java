package com.bajaj.markets.credit.disbursement.consumer.bean;


import java.util.List;

public class ApplicationDetails {

	private Occupation occupation;
	private UserProfile userProfile;
	private ProdCategory prodCategory;
	private List<Address> addressList;
	
	public Occupation getOccupation() {
		return occupation;
	}
	public void setOccupation(Occupation occupation) {
		this.occupation = occupation;
	}
	public UserProfile getUserProfile() {
		return userProfile;
	}
	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}
	public ProdCategory getProdCategory() {
		return prodCategory;
	}
	public void setProdCategory(ProdCategory prodCategory) {
		this.prodCategory = prodCategory;
	}
	public List<Address> getAddressList() {
		return addressList;
	}
	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}
	
}
