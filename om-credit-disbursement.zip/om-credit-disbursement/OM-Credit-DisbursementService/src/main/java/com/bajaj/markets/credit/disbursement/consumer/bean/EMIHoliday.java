package com.bajaj.markets.credit.disbursement.consumer.bean;

public class EMIHoliday {

	private Number holidayMonth;
	
	private String monthName;

	public Number getHolidayMonth() {
		return holidayMonth;
	}

	public void setHolidayMonth(Number holidayMonth) {
		this.holidayMonth = holidayMonth;
	}

	public String getMonthName() {
		return monthName;
	}

	public void setMonthName(String monthName) {
		this.monthName = monthName;
	}

}
