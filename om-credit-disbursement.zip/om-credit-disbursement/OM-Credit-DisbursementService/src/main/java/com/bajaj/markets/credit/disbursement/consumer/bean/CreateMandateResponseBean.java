package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class CreateMandateResponseBean {

	private Boolean useExisting;
	private BigDecimal mandateID;
	private Boolean openMandate;
	private String status;
	private Boolean active;
	private Status status1;
	private ReturnStatusBean returnStatus;
	
	public ReturnStatusBean getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(ReturnStatusBean returnStatus) {
		this.returnStatus = returnStatus;
	}
	public Boolean getUseExisting() {
		return useExisting;
	}
	public void setUseExisting(Boolean useExisting) {
		this.useExisting = useExisting;
	}
	public BigDecimal getMandateID() {
		return mandateID;
	}
	public void setMandateID(BigDecimal mandateID) {
		this.mandateID = mandateID;
	}
	public Boolean getOpenMandate() {
		return openMandate;
	}
	public void setOpenMandate(Boolean openMandate) {
		this.openMandate = openMandate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public Status getStatus1() {
		return status1;
	}
	public void setStatus1(Status status1) {
		this.status1 = status1;
	}
	
}
