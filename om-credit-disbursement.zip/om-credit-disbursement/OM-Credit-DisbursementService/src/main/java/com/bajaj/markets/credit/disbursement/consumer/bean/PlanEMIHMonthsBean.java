package com.bajaj.markets.credit.disbursement.consumer.bean;

public class PlanEMIHMonthsBean {

	private Integer holidayMonth;

	public Integer getHolidayMonth() {
		return holidayMonth;
	}

	public void setHolidayMonth(Integer holidayMonth) {
		this.holidayMonth = holidayMonth;
	}
	
	
}
