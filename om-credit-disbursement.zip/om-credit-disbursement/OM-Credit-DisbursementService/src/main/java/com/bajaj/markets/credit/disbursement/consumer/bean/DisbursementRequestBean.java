/**
 * 
 */
package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.io.Serializable;
import java.util.Map;

/**
 * @author pranoti.pandole
 *
 */
public class DisbursementRequestBean  implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String applicationId;
	private String applicantId;
	private String productCode;
	private String errFlg;
	private String transactionId;
	private String stage;
	private Map<String, String> headers;
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getErrFlg() {
		return errFlg;
	}
	public void setErrFlg(String errFlg) {
		this.errFlg = errFlg;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public Map<String, String> getHeaders() {
		return headers;
	}
	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}
	
	
}
