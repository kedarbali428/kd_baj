package com.bajaj.markets.credit.disbursement.consumer.bean;

public class Email {

	private Long typeKey;
	private String email;
	
	public synchronized Long getTypeKey() {
		return typeKey;
	}
	public synchronized void setTypeKey(Long typeKey) {
		this.typeKey = typeKey;
	}
	public synchronized String getEmail() {
		return email;
	}
	public synchronized void setEmail(String email) {
		this.email = email;
	}
	
}
