package com.bajaj.markets.credit.disbursement.consumer.bean;

public class PersonalInfo {

	private String firstName;
	private String middleName;
	private String lastName;
	private String salutation;
	private String language;
	private String dateofBirth;
	private String countryofBirth;
	private String nationality;
	private String gender;
	private String maritalStatus;
	private String type;
	private String sector;
	private String industry;
	private String emiCardEligibilityAmt;
	private String shortName;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSalutation() {
		return salutation;
	}
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getDateofBirth() {
		return dateofBirth;
	}
	public void setDateofBirth(String dateofBirth) {
		this.dateofBirth = dateofBirth;
	}
	public String getCountryofBirth() {
		return countryofBirth;
	}
	public void setCountryofBirth(String countryofBirth) {
		this.countryofBirth = countryofBirth;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getEmiCardEligibilityAmt() {
		return emiCardEligibilityAmt;
	}
	public void setEmiCardEligibilityAmt(String emiCardEligibilityAmt) {
		this.emiCardEligibilityAmt = emiCardEligibilityAmt;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
}
