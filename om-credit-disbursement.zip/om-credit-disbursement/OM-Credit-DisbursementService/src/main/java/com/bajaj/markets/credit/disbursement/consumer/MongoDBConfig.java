package com.bajaj.markets.credit.disbursement.consumer;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.annotation.PostConstruct;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

@RefreshScope
@Configuration
public class MongoDBConfig {

	private static final String CLASS_NAME = MongoDBConfig.class.getCanonicalName();

	@Autowired
	private BFLLoggerUtil logger;

	@Value("${aws.db.document.domainname}")
	private String domainName;

	@Value("${aws.db.document.port}")
	private String port;

	@Value("${aws.db.document.disbursementdb}")
	private String disbursementDBName;

	@Value("${aws.db.document.username}")
	private String userName;

	@Value("${aws.db.document.password}")
	private String password;

	@Value("${aws.db.document.readPreference}")
	private String readPreference;

	@Value("${aws.db.document.trustStore}")
	private String trustStore;

	@Value("${aws.db.document.trustStorePassword}")
	private String trustStorePassword;

	public MongoClient disbursementMongoClient() {
		String template = "mongodb://%s:%s@%s/%s?ssl=true&replicaSet=rs0&readpreference=%s";
		String clusterEndpoint = domainName + ":" + port;
		String connectionString = String.format(template, userName, password, clusterEndpoint, disbursementDBName,
				readPreference);

		logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Document DB Connection String : " + connectionString);
		logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Trust Store Path : " + trustStore);

		MongoClientURI clientURI = new MongoClientURI(connectionString);

		return new MongoClient(clientURI);
	}

	@SuppressWarnings("deprecation")
	@Bean(name = { "disbursementMongoTemplate" })
	public MongoTemplate disbursementMongoTemplate() {
		return new MongoTemplate(disbursementMongoClient(), disbursementDBName);
	}

	@PostConstruct
	public void importTLS() {
		try(FileInputStream myKeys = new FileInputStream(trustStore)) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start importTLS of DocumentDB." + trustStore);
			TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init((KeyStore) null);

			X509TrustManager defaultTm = null;
			for (TrustManager tm : tmf.getTrustManagers()) {
				if (tm instanceof X509TrustManager) {
					defaultTm = (X509TrustManager) tm;
					break;
				}
			}

			KeyStore myTrustStore = KeyStore.getInstance(KeyStore.getDefaultType());
			myTrustStore.load(myKeys, trustStorePassword.toCharArray());

			tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init(myTrustStore);

			X509TrustManager myTm = null;
			for (TrustManager tm : tmf.getTrustManagers()) {
				if (tm instanceof X509TrustManager) {
					myTm = (X509TrustManager) tm;
					break;
				}
			}

			final X509TrustManager finalDefaultTm = defaultTm;
			final X509TrustManager finalMyTm = myTm;
			X509TrustManager customTm = new X509TrustManager() {

				@Override
				public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					finalDefaultTm.checkClientTrusted(chain, authType);

				}

				@Override
				public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					try {
						finalMyTm.checkServerTrusted(chain, authType);
					} catch (CertificateException e) {
						finalDefaultTm.checkServerTrusted(chain, authType);
					}
				}

				@Override
				public X509Certificate[] getAcceptedIssuers() {
					return finalDefaultTm.getAcceptedIssuers();
				}
			};

			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(null, new TrustManager[] { customTm }, null);

			SSLContext.setDefault(sslContext);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End of importTLS of DocumentDB.");
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Error while importing DocDb cert into JVM. Using System Properties now.", e);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Error while importing DocDb cert into JVM. Using System Properties now.");
			System.setProperty("javax.net.ssl.trustStore", trustStore);
			System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"DocDB Truststore : " + System.getProperty("javax.net.ssl.trustStore"));
		}
	}

}