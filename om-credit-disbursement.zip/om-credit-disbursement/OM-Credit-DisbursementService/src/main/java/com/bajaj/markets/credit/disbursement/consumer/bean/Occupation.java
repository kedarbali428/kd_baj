package com.bajaj.markets.credit.disbursement.consumer.bean;


public class Occupation {
	
	private Reference ocupationType;

	private BusinessOwnerDetails businessOwnerDetails;
	
	public Reference getOcupationType() {
		return ocupationType;
	}

	public void setOcupationType(Reference ocupationType) {
		this.ocupationType = ocupationType;
	}
	
	public BusinessOwnerDetails getBusinessOwnerDetails() {
		return businessOwnerDetails;
	}

	public void setBusinessOwnerDetails(BusinessOwnerDetails businessOwnerDetails) {
		this.businessOwnerDetails = businessOwnerDetails;
	}
	
	
}
