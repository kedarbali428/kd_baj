package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class VasBean {
	
	private String product;
	private String postingAgainst;
	private String primaryLinkRef;
	private String vasReference;
	private String fee;
	private String feePaymentMode;
	private String valueDate;
	private String accrualTillDate;
	private String recurringDate;
	private String dsaId;
	private String dmaId;
	private String fulfilOfficerId;
	private String referralId;
	private String renewalFee;
	private List<ExtendedDetailBean> extendedDetails;
	
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getPostingAgainst() {
		return postingAgainst;
	}
	public void setPostingAgainst(String postingAgainst) {
		this.postingAgainst = postingAgainst;
	}
	public String getPrimaryLinkRef() {
		return primaryLinkRef;
	}
	public void setPrimaryLinkRef(String primaryLinkRef) {
		this.primaryLinkRef = primaryLinkRef;
	}
	public String getVasReference() {
		return vasReference;
	}
	public void setVasReference(String vasReference) {
		this.vasReference = vasReference;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}
	public String getFeePaymentMode() {
		return feePaymentMode;
	}
	public void setFeePaymentMode(String feePaymentMode) {
		this.feePaymentMode = feePaymentMode;
	}
	public String getValueDate() {
		return valueDate;
	}
	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}
	public String getAccrualTillDate() {
		return accrualTillDate;
	}
	public void setAccrualTillDate(String accrualTillDate) {
		this.accrualTillDate = accrualTillDate;
	}
	public String getRecurringDate() {
		return recurringDate;
	}
	public void setRecurringDate(String recurringDate) {
		this.recurringDate = recurringDate;
	}
	public String getDsaId() {
		return dsaId;
	}
	public void setDsaId(String dsaId) {
		this.dsaId = dsaId;
	}
	public String getDmaId() {
		return dmaId;
	}
	public void setDmaId(String dmaId) {
		this.dmaId = dmaId;
	}
	public String getFulfilOfficerId() {
		return fulfilOfficerId;
	}
	public void setFulfilOfficerId(String fulfilOfficerId) {
		this.fulfilOfficerId = fulfilOfficerId;
	}
	public String getReferralId() {
		return referralId;
	}
	public void setReferralId(String referralId) {
		this.referralId = referralId;
	}
	public String getRenewalFee() {
		return renewalFee;
	}
	public void setRenewalFee(String renewalFee) {
		this.renewalFee = renewalFee;
	}
	public List<ExtendedDetailBean> getExtendedDetails() {
		return extendedDetails;
	}
	public void setExtendedDetails(List<ExtendedDetailBean> extendedDetails) {
		this.extendedDetails = extendedDetails;
	}

}
