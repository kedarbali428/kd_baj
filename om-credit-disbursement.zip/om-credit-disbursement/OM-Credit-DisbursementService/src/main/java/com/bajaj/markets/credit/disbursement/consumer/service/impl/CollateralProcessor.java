package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.awaitility.Awaitility;
import org.awaitility.core.ConditionTimeoutException;
import org.awaitility.pollinterval.FibonacciPollInterval;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.disbursement.consumer.bean.BankDetailsResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.CollateralProcessorVariables;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCollateralDisbDetails;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCollateralExternalRequest;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCollateralPennatResponse;
import com.bajaj.markets.credit.disbursement.consumer.bean.CreateCollateralResponseBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementMongoObject;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementBusinessHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementMapperUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.bajaj.markets.credit.disbursement.consumer.util.LMSHelper;
import com.bajaj.markets.credit.disbursement.consumer.util.Status;
import com.bajaj.markets.credit.disbursement.repository.MongoDBRepository;
import com.google.gson.Gson;

@Component
public class CollateralProcessor {

	@Value("${api.omcreditapplicationservice.collateraldetails.GET.url}")
	private String getCollateralDetailsFromCreditApplicationUrl;

	@Value("${erroScenarioFlg}")
	private String erroScenarioFlg;

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	DisbursementBusinessHelper disbursementBusinessHelper;

	@Autowired
	DisbursementMapperUtil disbursementMapperUtil;

	@Autowired
	LMSHelper lmsHelper;

	@Autowired
	DisbursementUtil disbursementUtil;

	@Autowired
	MongoDBRepository mongoDbRepo;

	@Autowired
	@Qualifier("disbursementMongoTemplate")
	MongoOperations disbursementMongoTemplate;

	@Value("${initiateDisbUrl}")
	private String initiateDisbUrl;

	@Autowired
	Environment env;

	private static final String CLASS_NAME = CollateralProcessor.class.getCanonicalName();

	@SuppressWarnings("static-access")
	public CreateCollateralResponseBean processCollateralRequest(GlobalDataBean data) {
		CreateCollateralResponseBean response = null;
		CollateralProcessorVariables processorVariables=new CollateralProcessorVariables();
		try {
			CreateCollateralExternalRequest collateralRequest = fetchCollateralPennatRequest(data.getApplicationKey(),
					data.getApplicantKey(), generateHeaders(data));
			Long startTime=null;
			Long stopTime=null;
			try {
				startTime = System.currentTimeMillis();
				FibonacciPollInterval fibonacci = new FibonacciPollInterval(TimeUnit.SECONDS);
				Awaitility.setDefaultTimeout(300, TimeUnit.SECONDS);
				Awaitility.with().pollInterval(fibonacci).await().atMost(300, TimeUnit.SECONDS)
						.until(() -> null != (executeLMSRequestforCollateral(
								data.getApplicationKey(), data.getL2ProductCode(), collateralRequest,
								generateHeaders(data), processorVariables)));
				stopTime = System.currentTimeMillis();
			} catch (ConditionTimeoutException e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "TimeOut flow for CreateCollateral::");
				List<TranchBean> trnchLst = disbursementUtil.fetchTranchDetails(data.getApplicationKey(),
						generateHeaders(data));
				Long activeTranchKey = trnchLst.get(0).getTranchkey();
				RetryRegistrationBean existingRecords = null;
				existingRecords = disbursementUtil.fetchExistingTransaction(activeTranchKey.toString(),
						data.getApplicationKey(), generateHeaders(data));
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"TimeOut flow for CreateCollateral activeTranchKey:: " + activeTranchKey);
				DisbursementRequestBean rquestBean = new DisbursementRequestBean();
				rquestBean.setApplicantId(data.getApplicantKey());
				rquestBean.setApplicationId(data.getApplicationKey());
				rquestBean.setProductCode(data.getL3ProductCode());
				RetryRegistrationBean bean = new RetryRegistrationBean();
				bean.setActiveFlg(true);
				if (null != existingRecords) {
					bean.setCurrentRetryCount(existingRecords.getCurrentRetryCount() + 1l);
				} else {
					bean.setCurrentRetryCount(1l);
				}

				rquestBean.setStage("CREATE_COLLATERAL");
				rquestBean.setTransactionId(activeTranchKey.toString());
				bean.setErrorCode("DISBURSEMENT_CREATE_COLLATERAL");
				bean.setNextReryTime(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(5)).toString());
				bean.setRetryClass("CreditDisbursementController");
				bean.setRetryMechanism("Endpoint");
				bean.setRetryMethod(initiateDisbUrl);
				bean.setRetryPayload(disbursementUtil.objectToJson(rquestBean));
				bean.setRetryStatus("Pending");
				bean.setSource("OM-Credit-Disbursement");
				Date date = new Date();
				bean.setTimestamp(new Timestamp(date.getTime()).toString());
				bean.setTransactionId(activeTranchKey);
				if (bean.getCurrentRetryCount() > 5) {
					bean.setRetryStatus("Failed");
					bean.setActiveFlg(false);
				}

				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"TimeOut flow for CreateCollateral before save activeTranchKey:: " + activeTranchKey);
				processorVariables.setRetryMechanism(true);
				disbursementUtil.saveretrytransaction(activeTranchKey.toString(), data.getApplicationKey(), bean,
						generateHeaders(data));
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Completed collateralResponseString ::");

			if (null != processorVariables.getCollateralResponseString() && !processorVariables.isRetryMechanism() ) {
				disbursementUtil.addDisbursementRecords(data.getApplicationKey(), data.getApplicantKey(), mapToJson(collateralRequest), processorVariables.getCollateralResponseString(), DisbursementConstants.LMS_CREATE_COLLATERAL_SOURCE,
						null!=startTime?startTime.toString():null, null!=stopTime?stopTime.toString():null);
				response = processCollateralLmsResponse(data, processorVariables.getCollateralResponseString(), generateHeaders(data));
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred : Collateral Call ", e);
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred in Collateral Call");
		}
		return response;

	}

	public HttpHeaders generateHeaders(GlobalDataBean data) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("authtoken", data.getHeaders().get("authtoken"));
		headers.add("cmptcorrid", data.getHeaders().get("cmptcorrid"));
		headers.add("guardtoken", data.getHeaders().get("guardtoken"));
		return headers;
	}

	public <T> String mapToJson(T object) {
		Gson gson = new Gson();
		return gson.toJson(object);
	}

	private CreateCollateralResponseBean processCollateralLmsResponse(GlobalDataBean data,
			String collateralResponseString, HttpHeaders headers) {
		Gson gson = new Gson();
		CreateCollateralPennatResponse collateralPennatResponse = gson.fromJson(collateralResponseString,
				CreateCollateralPennatResponse.class);
		CreateCollateralResponseBean finalResponse = new CreateCollateralResponseBean();

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "~~~extResponse: " + collateralPennatResponse);
		if (collateralPennatResponse != null) {
			String returnCode = collateralPennatResponse.getReturnStatus().getReturnCode();
			if (DisbursementConstants.PENNANT_SUCCES_CODE.equals(returnCode)) {
				finalResponse.setCollateralRef(collateralPennatResponse.getCollateralRef());
				finalResponse.setStatus(Status.SUCCESS);
				// Update Mongo
				updateServiceRecordForCollateral(data.getApplicationKey(), data.getApplicantKey(),
						collateralPennatResponse.getCollateralRef());
				// update Aurora
				disbursementUtil.updateAppTranch(data.getApplicationKey(),
						DisbursementConstants.TRANCHE_STATUS_PROGRESS, DisbursementConstants.DISB_SUCCESS_FLAG, null,
						null, headers);
			} else {
				finalResponse.setReturnStatus(collateralPennatResponse.getReturnStatus());
				disbursementUtil.updateAppTranch(data.getApplicationKey(), DisbursementConstants.TRANCHE_STATUS_FAILED,
						DisbursementConstants.DISB_FAILURE_FLAG, null, null, headers);
				if ("Y".equals(erroScenarioFlg)) {
					saveDisbursementError(data, data.getApplicationKey(), collateralResponseString);
					DisbursementEventRequestBean disbursementEventRequestBean = new DisbursementEventRequestBean();
					disbursementEventRequestBean.setApplicantId(data.getApplicantKey());
					disbursementEventRequestBean.setApplicationId(data.getApplicationKey());
					disbursementEventRequestBean.setEventType("DISBURSEMENT_FAILED");
					disbursementEventRequestBean.setProductCode(data.getL3ProductCode());
					disbursementEventRequestBean.setHeaders(data.getHeaders());
					disbursementUtil.raiseEvent(disbursementEventRequestBean,
							DisbursementConstants.DISBURSEMENT_FAILED);
					logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "CREATE_COLATERAL_FAILED  failed: ");
					logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "CREATE_COLATERAL_FAILED  failed: ");
					throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
							new ErrorBean("CDS-200", "CREATE_COLATERAL_FAILED"));
				}
			}
		}
		return finalResponse;
	}

	private void saveDisbursementError(GlobalDataBean data, String applicationId, String collateralResponseString) {
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		disbursementTrackerBean.setApplicationId(Long.parseLong(applicationId));
		disbursementTrackerBean.setDisbursmentstage(DisbursementConstants.CREATE_COLATERAL);
		disbursementTrackerBean.setError(DisbursementConstants.CREATE_COLATERAL_FAILED);
		String errorReason = disbursementUtil.logDisbErrors(applicationId, collateralResponseString);
		disbursementTrackerBean.setErrorreason(errorReason);
		disbursementTrackerBean.setErrorretryable(1l);
		disbursementTrackerBean.setIsActive(1l);
		disbursementTrackerBean.setStatus("CREATED");
		disbursementUtil.saveDisbursementErrorDetails(data, disbursementTrackerBean);
	}

	public void updateServiceRecordForCollateral(String applicationKey, String applicantKey, String collateralRef) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "updateServiceRecordForCollateral : Start : ");
		mongoDbRepo.updateFieldByApplicationKeyAndApplicantKey(disbursementMongoTemplate, Long.valueOf(applicationKey),
				Long.valueOf(applicantKey), DisbursementConstants.COLLATERAL_REF_NUM, collateralRef,
				DisbursementConstants.SERVICE_RECORD);
	}

	private String executeLMSRequestforCollateral(String applicationId, String prodCode,
			CreateCollateralExternalRequest collateralRequest, HttpHeaders headers, CollateralProcessorVariables processorVariables) {
		String collateralRequestStr = mapToJson(collateralRequest);
		Object response = lmsHelper.executeLmsRequest(DisbursementConstants.LMS_CREATE_COLLATERAL_SOURCE, prodCode,
				collateralRequestStr, applicationId, headers);
		processorVariables.setCollateralResponseString(response.toString());
		return response.toString();
	}

	private CreateCollateralExternalRequest fetchCollateralPennatRequest(String applicationId, String applicantKey,
			HttpHeaders headers) {
		List<BankDetailsResponse> bankDetails = disbursementUtil.fetchBankDetails(applicationId, headers);
		CreateCollateralDisbDetails collateralDisbDetails = fetchCreateCollateralDisbDetails(applicationId, headers);
		String cif = fetchCifId(Long.valueOf(applicationId), Long.valueOf(applicantKey));
		return disbursementMapperUtil.mapCollateralPennantRequest(cif, bankDetails, collateralDisbDetails, headers);
	}

	public String fetchCifId(Long applicationKey, Long applicantKey) {
		List<DisbursementMongoObject> disbursementMongoObjectList = mongoDbRepo.fetchObjectByKey(
				disbursementMongoTemplate, "applicantKey", applicantKey, DisbursementConstants.SERVICE_RECORD);
		DisbursementMongoObject result = disbursementMongoObjectList.stream()
				.filter(x -> x.getApplicationKey().equals(applicationKey)).findFirst().orElse(null);
		return result.getCif();
	}

	@SuppressWarnings("unchecked")
	private CreateCollateralDisbDetails fetchCreateCollateralDisbDetails(String applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"fetchCustomerDisbDetails : Start : applicationId :" + applicationId);
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		CreateCollateralDisbDetails collateralDisbDetails = new CreateCollateralDisbDetails();

		params.put("applicationkey", applicationId);
		ResponseEntity<String> response = (ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(
				HttpMethod.GET, getCollateralDetailsFromCreditApplicationUrl, String.class, params, null, headers);
		if (null != response.getBody()) {
			collateralDisbDetails = gson.fromJson(response.getBody(), CreateCollateralDisbDetails.class);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"fetchCustomerDisbDetails : End : applicationId: " + applicationId);
		return collateralDisbDetails;
	}
}