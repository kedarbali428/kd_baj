/**
 * 
 */
package com.bajaj.markets.credit.disbursement.consumer.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementEventRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementTrackerBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.ErrorBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.GlobalDataBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.RetryRegistrationBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.TranchBean;
import com.bajaj.markets.credit.disbursement.consumer.bean.UserProfile;
import com.bajaj.markets.credit.disbursement.consumer.exception.DisbursementServiceException;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementConstants;
import com.bajaj.markets.credit.disbursement.consumer.util.DisbursementUtil;
import com.google.gson.Gson;

/**
 * @author pranoti.pandole
 *
 */
@Component("SOLErrorHandlingProcessor")
public class SOLErrorHandlingProcessor extends SOLDisbursementProcessor {

	@Value("${api.omcreditapplicationservice.getDisbError.GET.url}")
	private String getDisbErrorUrl;

	@Value("${api.omcreditapplicationservice.userprofiles.GET.url}")
	private String getUserProfilesUrl;

	@Autowired
	DisbursementUtil disbursementUtil;

	private static final String CLASS_NAME = SOLErrorHandlingProcessor.class.getCanonicalName();

	public void processSOLDisbursementErrors(DisbursementEventRequestBean request) {
		GlobalDataBean data = new GlobalDataBean();
		data.setApplicationKey(request.getApplicationId());
		data.setHeaders(request.getHeaders());
		DisbursementTrackerBean disbursementTrackerBean = fetchDisbursementErrorDetails(data);
		String disbFailedStage = disbursementTrackerBean.getDisbursmentstage();
		switch (disbFailedStage) {

		case DisbursementConstants.DISBURSMENT_PRECHECKS:
			handlefromPrecheckFailure(request, disbursementTrackerBean, data);
			break;

		case DisbursementConstants.CREATE_CUSTOMER:
			handlefromCustomerFailure(request, disbursementTrackerBean, null, data);
			break;
		case DisbursementConstants.CREATE_BENEFICIARY:
			handlefromBeneficiaryFailure(request, disbursementTrackerBean, null, data);
			break;

		case DisbursementConstants.CREATE_COLATERAL:
			handlefromCollateralFailure(request, disbursementTrackerBean, null, data);
			break;

		case DisbursementConstants.CREATE_LOAN:
			handlefromLoanFailure(request, disbursementTrackerBean, null, data);
			break;

		}

	}

	public void processRetryErrors(DisbursementRequestBean retryBean) {
		GlobalDataBean data=new GlobalDataBean();
		data.setApplicationKey(retryBean.getApplicationId());
		data.setHeaders(retryBean.getHeaders());
		switch (retryBean.getStage()) {
		case DisbursementConstants.CREATE_CUSTOMER:
			handlefromCustomerFailure(null, null, retryBean, data);
			break;
		case DisbursementConstants.CREATE_BENEFICIARY:
			handlefromBeneficiaryFailure(null, null, retryBean, data);
			break;

		case DisbursementConstants.CREATE_COLATERAL:
			handlefromCollateralFailure(null, null, retryBean, data);
			break;

		case DisbursementConstants.CREATE_LOAN:
			handlefromLoanFailure(null, null, retryBean, data);
			break;
		}

	}

	public void handlefromPrecheckFailure(DisbursementEventRequestBean request,
			DisbursementTrackerBean disbursementTrackerBean, GlobalDataBean data) {
		preErrorManagementProcess(disbursementTrackerBean, data);
		processDisbursement(request);
		postErrorManagementProcess(disbursementTrackerBean, data);
	}

	public void handlefromCustomerFailure(DisbursementEventRequestBean request,
			DisbursementTrackerBean disbursementTrackerBean, DisbursementRequestBean retryBean, GlobalDataBean data) {
		if (null != disbursementTrackerBean) {
			preErrorManagementProcess(disbursementTrackerBean, data);
			createCustomer(data);
			createBeneficiary(data);
			createCollateral(data);
			createLoan(data);
			postErrorManagementProcess(disbursementTrackerBean, data);
		} else {
			preRetryErrorProcess(retryBean, data);
			createCustomer(data);
			postRetryErrorProcess(retryBean, data);
			createBeneficiary(data);
			createCollateral(data);
			createLoan(data);

		}
	}

	public void handlefromBeneficiaryFailure(DisbursementEventRequestBean request,
			DisbursementTrackerBean disbursementTrackerBean, DisbursementRequestBean retryBean, GlobalDataBean data) {
		if (null != disbursementTrackerBean) {
			preErrorManagementProcess(disbursementTrackerBean, data);
			createBeneficiary(data);
			createCollateral(data);
			createLoan(data);
			postErrorManagementProcess(disbursementTrackerBean, data);
		} else {
			preRetryErrorProcess(retryBean, data);
			createBeneficiary(data);
			postRetryErrorProcess(retryBean, data);
			createCollateral(data);
			createLoan(data);

		}
	}

	public void handlefromCollateralFailure(DisbursementEventRequestBean request,
			DisbursementTrackerBean disbursementTrackerBean, DisbursementRequestBean retryBean, GlobalDataBean data) {
		if (null != disbursementTrackerBean) {
			preErrorManagementProcess(disbursementTrackerBean, data);
			createCollateral(data);
			createLoan(data);
			postErrorManagementProcess(disbursementTrackerBean, data);
		} else {
			preRetryErrorProcess(retryBean, data);
			createCollateral(data);
			postRetryErrorProcess(retryBean, data);
			createLoan(data);

		}
	}

	public void handlefromLoanFailure(DisbursementEventRequestBean request,
			DisbursementTrackerBean disbursementTrackerBean, DisbursementRequestBean retryBean, GlobalDataBean data) {
		
		if (null != disbursementTrackerBean) {
			preErrorManagementProcess(disbursementTrackerBean, data);
			getPhoneNumber(data);
			createLoan(data);
			postErrorManagementProcess(disbursementTrackerBean, data);
		} else {
			data.setErrFlg(true);
			preRetryErrorProcess(retryBean, data);
			getPhoneNumber(data);
			createLoan(data);
			postRetryErrorProcess(retryBean, data);
		}
	}

	private void getPhoneNumber(GlobalDataBean data) {
		List<UserProfile> userProfileList = getUserDetails(data.getApplicationKey(),
				loanProcessor.generateHeaders(data));
		UserProfile userProfile = null;
		for (UserProfile user : userProfileList) {
			if (user.getApplicationUserAttributeType().equals(DisbursementConstants.MAIN_APPLICANT)) {
				userProfile = user;
				data.setMobile(userProfile.getMobile());
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Primary UserApplicantKey Not Found");
				throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
						new ErrorBean("CDS-010", "Primary UserApplicantKey Not Found"));
			}
		}
	}

	public void preErrorManagementProcess(DisbursementTrackerBean disbursementTrackerBean, GlobalDataBean data) {
		disbursementUtil.mapGlobalData(disbursementUtil.fetchApplicationDetails(data),data);
		disbursementTrackerBean.setStatus(DisbursementConstants.IN_PROGRESS);
		disbursementUtil.saveDisbursementErrorDetails(data, disbursementTrackerBean);
	}

	public void postErrorManagementProcess(DisbursementTrackerBean disbursementTrackerBean, GlobalDataBean data) {
		disbursementTrackerBean.setStatus(DisbursementConstants.SUCCESSFULL);
		disbursementTrackerBean.setIsActive(0l);
		disbursementUtil.saveDisbursementErrorDetails(data, disbursementTrackerBean);
	}

	public void preRetryErrorProcess(DisbursementRequestBean retryBean, GlobalDataBean data) {
		disbursementUtil.mapGlobalData(disbursementUtil.fetchApplicationDetails(data),data);
	}

	public void postRetryErrorProcess(DisbursementRequestBean retryBean, GlobalDataBean data) {
		RetryRegistrationBean existingRecords = null;
		existingRecords = disbursementUtil.fetchExistingTransaction(retryBean.getTransactionId(),
				data.getApplicationKey(), generateHeaders(data));
		if (null != existingRecords) {
			existingRecords.setErrorKey(existingRecords.getErrorKey());
			existingRecords.setRetrySuccessFlg(true);
			existingRecords.setActiveFlg(false);
			disbursementUtil.saveretrytransaction(retryBean.getTransactionId(), data.getApplicationKey(),
					existingRecords, generateHeaders(data));
		}
	}

	@SuppressWarnings("unchecked")
	public DisbursementTrackerBean fetchDisbursementErrorDetails(GlobalDataBean appInfo) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  fetchDisbursementErrorDetails: " + appInfo.getApplicationKey());
		List<TranchBean> trnchLst = loanProcessor.fetchTranchDetails(appInfo.getApplicationKey(),
				loanProcessor.generateHeaders(appInfo));
		Long activeTranchKey = trnchLst.get(0).getTranchkey();
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  fetchDisbursementErrorDetails Starts for tranch: " + activeTranchKey);
		Map<String, String> params = new HashMap<>();
		params.put("tranchKey", activeTranchKey.toString());
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) disbursementBusinessHelper.invokeRestEndpoint(
				HttpMethod.GET, getDisbErrorUrl, String.class, params, null, loanProcessor.generateHeaders(appInfo));
		Gson gson = new Gson();
		List<DisbursementTrackerBean> disbursementTrackerBeanLst = new ArrayList<DisbursementTrackerBean>();
		DisbursementTrackerBean disbursementTrackerBean = new DisbursementTrackerBean();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody() && !excuteRestCall.getBody().isEmpty()&& excuteRestCall.getBody().contains("disbursmentstage")) {
				DisbursementTrackerBean[] list = gson.fromJson(excuteRestCall.getBody().toString(),
						DisbursementTrackerBean[].class);
				disbursementTrackerBeanLst.addAll(Arrays.asList(list));
				return disbursementTrackerBeanLst.get(0);
			}
		} catch (Exception e) {
			throw new DisbursementServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from  fetchDisbursementErrorDetails .");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside  fetchDisbursementErrorDetails Ends for tranch: " + activeTranchKey);
		return disbursementTrackerBean;
	}

	@SuppressWarnings("unchecked")
	private List<UserProfile> getUserDetails(String applicationId, HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getUserDetails : Start : " + applicationId);
		HashMap<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		List<UserProfile> userProfileList = new ArrayList<>();
		params.put("applicationid", applicationId);
		ResponseEntity<String> userProfileResponse = (ResponseEntity<String>) disbursementBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, getUserProfilesUrl, String.class, params, null, headers);
		if (null != userProfileResponse.getBody()) {
			UserProfile[] userDetails = gson.fromJson(userProfileResponse.getBody(), UserProfile[].class);
			userProfileList = Arrays.asList(userDetails);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getUserDetails : End : " + applicationId);
		return userProfileList;
	}

	public HttpHeaders generateHeaders(GlobalDataBean data) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("authtoken", data.getHeaders().get("authtoken"));
		headers.add("cmptcorrid", data.getHeaders().get("cmptcorrid"));
		headers.add("guardtoken", data.getHeaders().get("guardtoken"));
		return headers;
	}

	
}
