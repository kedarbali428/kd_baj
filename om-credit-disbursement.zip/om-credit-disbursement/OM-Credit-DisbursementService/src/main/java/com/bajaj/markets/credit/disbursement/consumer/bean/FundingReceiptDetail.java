package com.bajaj.markets.credit.disbursement.consumer.bean;

public class FundingReceiptDetail {

	private String remarks;
	private String favourName;
	private String transactionRef;
	private String fundingAccount;
	private String favourNumber;

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getFavourName() {
		return favourName;
	}

	public void setFavourName(String favourName) {
		this.favourName = favourName;
	}

	public String getTransactionRef() {
		return transactionRef;
	}

	public void setTransactionRef(String transactionRef) {
		this.transactionRef = transactionRef;
	}

	public String getFundingAccount() {
		return fundingAccount;
	}

	public void setFundingAccount(String fundingAccount) {
		this.fundingAccount = fundingAccount;
	}

	public String getFavourNumber() {
		return favourNumber;
	}

	public void setFavourNumber(String favourNumber) {
		this.favourNumber = favourNumber;
	}

}
