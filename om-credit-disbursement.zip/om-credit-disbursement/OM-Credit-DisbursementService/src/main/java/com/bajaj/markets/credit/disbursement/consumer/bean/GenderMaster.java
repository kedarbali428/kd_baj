package com.bajaj.markets.credit.disbursement.consumer.bean;

public class GenderMaster {
	private Long genderKey;

	private String genderCode;

	public Long getGenderKey() {
		return genderKey;
	}

	public void setGenderKey(Long genderKey) {
		this.genderKey = genderKey;
	}

	public String getGenderCode() {
		return genderCode;
	}

	public void setGenderCode(String genderCode) {
		this.genderCode = genderCode;
	}

}
