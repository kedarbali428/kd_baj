/**
 * 
 */
package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.sql.Timestamp;

/**
 * @author pranoti.pandole
 *
 */
public class RetryRegistrationBean {
	
    private Object errorKey;
	
	private String timestamp;
	
	private String retryStatus;
	
	private Long transactionId;
	
	private String errorCode;
	
	private String source;
	
	private Long currentRetryCount;
	
	private String nextReryTime;
	
	private String retryPayload;
	
	private String retryClass;
	
	private String retryMethod;
	
	private String retryMechanism;

	private Boolean activeFlg;
	
	private Boolean retrySuccessFlg;
	
	public Object getErrorKey() {
		return errorKey;
	}

	public void setErrorKey(Object errorKey) {
		this.errorKey = errorKey;
	}

	

	public String getRetryStatus() {
		return retryStatus;
	}

	public void setRetryStatus(String retryStatus) {
		this.retryStatus = retryStatus;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Long getCurrentRetryCount() {
		return currentRetryCount;
	}

	public void setCurrentRetryCount(Long currentRetryCount) {
		this.currentRetryCount = currentRetryCount;
	}
	
	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getNextReryTime() {
		return nextReryTime;
	}

	public void setNextReryTime(String nextReryTime) {
		this.nextReryTime = nextReryTime;
	}

	public String getRetryPayload() {
		return retryPayload;
	}

	public void setRetryPayload(String retryPayload) {
		this.retryPayload = retryPayload;
	}

	public String getRetryClass() {
		return retryClass;
	}

	public void setRetryClass(String retryClass) {
		this.retryClass = retryClass;
	}

	public String getRetryMethod() {
		return retryMethod;
	}

	public void setRetryMethod(String retryMethod) {
		this.retryMethod = retryMethod;
	}

	public String getRetryMechanism() {
		return retryMechanism;
	}

	public void setRetryMechanism(String retryMechanism) {
		this.retryMechanism = retryMechanism;
	}

	public Boolean getActiveFlg() {
		return activeFlg;
	}

	public void setActiveFlg(Boolean activeFlg) {
		this.activeFlg = activeFlg;
	}

	public Boolean getRetrySuccessFlg() {
		return retrySuccessFlg;
	}

	public void setRetrySuccessFlg(Boolean retrySuccessFlg) {
		this.retrySuccessFlg = retrySuccessFlg;
	}
	
	
}
