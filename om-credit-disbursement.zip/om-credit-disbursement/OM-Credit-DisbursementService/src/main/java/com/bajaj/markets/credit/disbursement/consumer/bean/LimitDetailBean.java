package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class LimitDetailBean {

	private BigDecimal structureDetailId;
	private String expiryDate;
	private Boolean limitCheck;	
	private String limitChkMethod;
	private BigDecimal limitSanctioned;
	public BigDecimal getStructureDetailId() {
		return structureDetailId;
	}
	public void setStructureDetailId(BigDecimal structureDetailId) {
		this.structureDetailId = structureDetailId;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public Boolean getLimitCheck() {
		return limitCheck;
	}
	public void setLimitCheck(Boolean limitCheck) {
		this.limitCheck = limitCheck;
	}
	public String getLimitChkMethod() {
		return limitChkMethod;
	}
	public void setLimitChkMethod(String limitChkMethod) {
		this.limitChkMethod = limitChkMethod;
	}
	public BigDecimal getLimitSanctioned() {
		return limitSanctioned;
	}
	public void setLimitSanctioned(BigDecimal limitSanctioned) {
		this.limitSanctioned = limitSanctioned;
	}

}
