package com.bajaj.markets.credit.disbursement.consumer.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.disbursement.consumer.bean.DisbursementRequestBean;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.BOLErrorHandlingProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.PROLErrorHandlingProcessor;
import com.bajaj.markets.credit.disbursement.consumer.service.impl.SOLErrorHandlingProcessor;
import com.google.gson.Gson;

@RestController
public class CreditDisbursementController {

	@Autowired
	@Qualifier("SOLErrorHandlingProcessor")
	SOLErrorHandlingProcessor solErrorHandlingProcessor;

	@Autowired
	@Qualifier("BOLErrorHandlingProcessor")
	BOLErrorHandlingProcessor bolErrorHandlingProcessor;
	
	@Autowired
	@Qualifier("PROLErrorHandlingProcessor")
	PROLErrorHandlingProcessor prolErrorHandlingProcessor;

	@Value("${solloantypes}")
	private String solloantypes;

	@Value("${bolloantypes}")
	private String bolloantypes;
	
	@Value("${prolloantypes}")
	private String prolloantypes;

	@Autowired
	private BFLLoggerUtil logger;

	@Autowired
	CustomDefaultHeaders customHeaders;

	private static final String CLASS_NAME = CreditDisbursementController.class.getName();
   
	@Secured(value = { Role.PSEUDO_CUSTOMER,  Role.EMPLOYEE, Role.SYSTEM ,Role.INTERNAL})
	@CrossOrigin
	@PostMapping(path = "/v1/credit/disbursement/product/initiatedisbursement", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public void initiateDisbursement(@RequestBody Object obj, @RequestHeader HttpHeaders headers) {
		String jsonRequest = objectToJson(obj);
		Gson gson = new Gson();
		DisbursementRequestBean bean = gson.fromJson(jsonRequest, DisbursementRequestBean.class);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"In initiateDisb method for  productCode" + bean.getProductCode());
		Map<String, String> header = new HashMap<>();
		header.put("authtoken", customHeaders.getAuthtoken());
		header.put("cmptcorrid", customHeaders.getCmptcorrid());
		header.put("guardtoken", customHeaders.getGuardtoken());
		bean.setHeaders(header); 
		if (fetchSolFlag(bean.getProductCode()))
			solErrorHandlingProcessor.processRetryErrors(bean);
		else if (fetchBolFlag(bean.getProductCode()))
			bolErrorHandlingProcessor.processRetryErrors(bean);
		else if (fetchProlFlag(bean.getProductCode()))
			prolErrorHandlingProcessor.processRetryErrors(bean);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"END initiateDisb method for  productCode" + bean.getProductCode());
	}

	public static String objectToJson(Object o) {
		Gson gson = new Gson();
		return gson.toJson(o);
	}

	public boolean fetchSolFlag(String productType) {
		boolean solFlag = false;
		List<String> solList = Arrays.asList(solloantypes.split(","));
		boolean solMatchFound = solList.stream().anyMatch(productType::equals);
		if (solMatchFound) {
			solFlag = true;
		}
		return solFlag;
	}

	public boolean fetchBolFlag(String productType) {
		boolean bolFlag = false;
		List<String> bolList = Arrays.asList(bolloantypes.split(","));
		boolean solMatchFound = bolList.stream().anyMatch(productType::equals);
		if (solMatchFound) {
			bolFlag = true;
		}
		return bolFlag;
	}
	
	public boolean fetchProlFlag(String productType) {
		List<String> prolList = Arrays.asList(prolloantypes.split(","));
		return prolList.stream().anyMatch(productType::equals);
	}
}