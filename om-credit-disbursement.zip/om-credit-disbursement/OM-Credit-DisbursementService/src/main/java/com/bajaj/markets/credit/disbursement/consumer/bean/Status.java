package com.bajaj.markets.credit.disbursement.consumer.bean;


public enum Status {

    SUCCESS("SUCCESS"),
    PARTIAL_SUCCESS("PARTIALSUCCESS"),
    REJECT("REJECT"),
    INITIATED("INITIATED"),
	FAILURE("FAILURE");
	
	private String value;
	
	private Status(String value) {
		this.value = value;
	}	
	public String getValue() {
		return this.value;
	}
}