package com.bajaj.markets.credit.disbursement.consumer.bean;

public class CollateralProcessorVariables {

	private String collateralResponseString;

	private boolean isRetryMechanism;

	public String getCollateralResponseString() {
		return collateralResponseString;
	}

	public void setCollateralResponseString(String collateralResponseString) {
		this.collateralResponseString = collateralResponseString;
	}

	public boolean isRetryMechanism() {
		return isRetryMechanism;
	}

	public void setRetryMechanism(boolean isRetryMechanism) {
		this.isRetryMechanism = isRetryMechanism;
	}

}