package com.bajaj.markets.credit.disbursement.consumer.bean;

import com.bajaj.markets.credit.disbursement.consumer.util.Status;

public class CreateCollateralResponseBean {

	private String collateralRef;
	private Status status;
	private ReturnStatusBean returnStatus;
	
	public String getCollateralRef() {
		return collateralRef;
	}
	public void setCollateralRef(String collateralRef) {
		this.collateralRef = collateralRef;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public ReturnStatusBean getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(ReturnStatusBean returnStatus) {
		this.returnStatus = returnStatus;
	}
}
