package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.List;

public class RejectionBean {

	private List<String>rejectionCode;
	private Long prodKey;
	private String rejectionSystem;
	public List<String> getRejectionCode() {
		return rejectionCode;
	}
	public void setRejectionCode(List<String> rejectionCode) {
		this.rejectionCode = rejectionCode;
	}
	public Long getProdKey() {
		return prodKey;
	}
	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}
	public String getRejectionSystem() {
		return rejectionSystem;
	}
	public void setRejectionSystem(String rejectionSystem) {
		this.rejectionSystem = rejectionSystem;
	}
	
}
