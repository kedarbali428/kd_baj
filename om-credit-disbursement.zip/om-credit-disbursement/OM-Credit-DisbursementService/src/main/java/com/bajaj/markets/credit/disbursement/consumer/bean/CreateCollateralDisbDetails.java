package com.bajaj.markets.credit.disbursement.consumer.bean;


public class CreateCollateralDisbDetails {

	private SPDCDetails spdcDetails;

	public SPDCDetails getSpdcDetails() {
		return spdcDetails;
	}

	public void setSpdcDetails(SPDCDetails spdcDetails) {
		this.spdcDetails = spdcDetails;
	}
	
	
}
