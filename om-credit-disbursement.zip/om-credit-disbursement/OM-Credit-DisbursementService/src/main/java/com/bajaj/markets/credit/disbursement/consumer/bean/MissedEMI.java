package com.bajaj.markets.credit.disbursement.consumer.bean;

public class MissedEMI {

	private String month;
	
	private String year;
	
	private Double emiAmount;
	
	private Double bounceCharges;
	
	private Double lateFeeAmount;
	
	private Double totalEmiAmount;
	
	private String overdueEMIDate;
	
	public String getOverdueEMIDate() {
		return overdueEMIDate;
	}

	public void setOverdueEMIDate(String overdueEMIDate) {
		this.overdueEMIDate = overdueEMIDate;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public Double getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(Double emiAmount) {
		this.emiAmount = emiAmount;
	}

	public Double getBounceCharges() {
		return bounceCharges;
	}

	public void setBounceCharges(Double bounceCharges) {
		this.bounceCharges = bounceCharges;
	}

	public Double getLateFeeAmount() {
		return lateFeeAmount;
	}

	public void setLateFeeAmount(Double lateFeeAmount) {
		this.lateFeeAmount = lateFeeAmount;
	}

	public Double getTotalEmiAmount() {
		return totalEmiAmount;
	}

	public void setTotalEmiAmount(Double totalEmiAmount) {
		this.totalEmiAmount = totalEmiAmount;
	}
	
	
}
