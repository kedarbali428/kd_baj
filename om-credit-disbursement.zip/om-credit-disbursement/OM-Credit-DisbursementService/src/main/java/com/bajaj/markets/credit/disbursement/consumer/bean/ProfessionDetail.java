package com.bajaj.markets.credit.disbursement.consumer.bean;

public class ProfessionDetail {
	private Reference profession;
	private Verification verification;

	public Reference getProfession() {
		return profession;
	}

	public void setProfession(Reference profession) {
		this.profession = profession;
	}

	public Verification getVerification() {
		return verification;
	}

	public void setVerification(Verification verification) {
		this.verification = verification;
	}
}
