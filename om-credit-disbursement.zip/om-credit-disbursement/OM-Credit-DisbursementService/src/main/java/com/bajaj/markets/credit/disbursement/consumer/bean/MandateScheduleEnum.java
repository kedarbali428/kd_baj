package com.bajaj.markets.credit.disbursement.consumer.bean;

public enum MandateScheduleEnum {
	CREATED("CREATED"), 
	ACTIVE("ACTIVE"),
	TERMINATED("TERMINATED");

	private final String status;
	
	private MandateScheduleEnum(String status) {
		this.status=status;
	}

	public String getStatus() {
		return status;
	}
	
}
