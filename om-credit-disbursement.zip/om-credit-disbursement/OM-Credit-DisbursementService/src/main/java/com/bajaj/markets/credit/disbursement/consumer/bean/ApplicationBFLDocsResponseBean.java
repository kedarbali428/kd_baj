package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;
import java.util.List;


public class ApplicationBFLDocsResponseBean {

	private List<BFLDocument>  docList;
	private List<BFLDocument>  combinedEsignDocList;
	private List <BFLDocument>  physicalCollectionDocList;
	
	private String feeCode;
	private BigDecimal fee;
	
	public List<BFLDocument> getDocList() {
		return docList;
	}
	public void setDocList(List<BFLDocument> docList) {
		this.docList = docList;
	}
	public List<BFLDocument> getCombinedEsignDocList() {
		return combinedEsignDocList;
	}
	public void setCombinedEsignDocList(List<BFLDocument> combinedEsignDocList) {
		this.combinedEsignDocList = combinedEsignDocList;
	}
	public List<BFLDocument> getPhysicalCollectionDocList() {
		return physicalCollectionDocList;
	}
	public void setPhysicalCollectionDocList(List<BFLDocument> physicalCollectionDocList) {
		this.physicalCollectionDocList = physicalCollectionDocList;
	}
	public String getFeeCode() {
		return feeCode;
	}
	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}
	public BigDecimal getFee() {
		return fee;
	}
	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}
}
