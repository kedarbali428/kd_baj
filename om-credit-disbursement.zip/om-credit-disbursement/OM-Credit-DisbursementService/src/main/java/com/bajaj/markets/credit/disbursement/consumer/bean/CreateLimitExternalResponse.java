package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.math.BigDecimal;

public class CreateLimitExternalResponse {
	
	private BigDecimal limitId;
	private ReturnStatusBean returnStatus;
	
	public BigDecimal getLimitId() {
		return limitId;
	}
	public void setLimitId(BigDecimal limitId) {
		this.limitId = limitId;
	}
	public ReturnStatusBean getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(ReturnStatusBean returnStatus) {
		this.returnStatus = returnStatus;
	}


}
