package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.util.Date;

public class FeeBean {

	private String feeCategory;

	private String feeCode;
	
	private Number feeAmount;
	
	private Number paidAmount;
	
	private String feeMethod;
	
	private String feeDescription;
	
	private Number overDueAmount;
	
	private Integer scheduleTerms;
	
	private Number feeBalanceAmount;
	
	private Date schdDate;
	
	public String getFeeCategory() {
		return feeCategory;
	}

	public void setFeeCategory(String feeCategory) {
		this.feeCategory = feeCategory;
	}

	public Date getSchdDate() {
		return schdDate;
	}

	public void setSchdDate(Date schdDate) {
		this.schdDate = schdDate;
	}

	public Integer getScheduleTerms() {
		return scheduleTerms;
	}

	public void setScheduleTerms(Integer scheduleTerms) {
		this.scheduleTerms = scheduleTerms;
	}

	public Number getFeeBalanceAmount() {
		return feeBalanceAmount;
	}

	public void setFeeBalanceAmount(Number feeBalanceAmount) {
		this.feeBalanceAmount = feeBalanceAmount;
	}

	public Number getOverDueAmount() {
		return overDueAmount;
	}

	public void setOverDueAmount(Number overDueAmount) {
		this.overDueAmount = overDueAmount;
	}

	public String getFeeCode() {
		return feeCode;
	}

	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}

	public Number getFeeAmount() {
		return feeAmount;
	}

	public void setFeeAmount(Number feeAmount) {
		this.feeAmount = feeAmount;
	}

	public Number getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(Number paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getFeeMethod() {
		return feeMethod;
	}

	public void setFeeMethod(String feeMethod) {
		this.feeMethod = feeMethod;
	}
	
	public String getFeeDescription() {
		return feeDescription;
	}

	public void setFeeDescription(String feeDescription) {
		this.feeDescription = feeDescription;
	}

	@Override
	public String toString() {
		return "FeeBean [feeCategory=" + feeCategory + ", feeCode=" + feeCode + ", feeAmount=" + feeAmount
				+ ", paidAmount=" + paidAmount + ", feeMethod=" + feeMethod + ", feeDescription=" + feeDescription
				+ ", overDueAmount=" + overDueAmount + ", scheduleTerms=" + scheduleTerms + ", feeBalanceAmount="
				+ feeBalanceAmount + ", schdDate=" + schdDate + "]";
	}

}
