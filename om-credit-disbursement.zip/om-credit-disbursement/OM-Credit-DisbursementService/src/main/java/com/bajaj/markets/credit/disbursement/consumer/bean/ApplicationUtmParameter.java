package com.bajaj.markets.credit.disbursement.consumer.bean;

import java.sql.Timestamp;

public class ApplicationUtmParameter {

	private Long apputmparamkey;

	private Long applicationkey;
	
	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String utmsource;
	
	private Timestamp createdt;

	public Long getApputmparamkey() {
		return apputmparamkey;
	}

	public void setApputmparamkey(Long apputmparamkey) {
		this.apputmparamkey = apputmparamkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getUtmsource() {
		return utmsource;
	}

	public void setUtmsource(String utmsource) {
		this.utmsource = utmsource;
	}

	public Timestamp getCreatedt() {
		return createdt;
	}

	public void setCreatedt(Timestamp createdt) {
		this.createdt = createdt;
	}

	@Override
	public String toString() {
		return "ApplicationUtmParameter [apputmparamkey=" + apputmparamkey + ", applicationkey=" + applicationkey
				+ ", isactive=" + isactive + ", lstupdateby=" + lstupdateby + ", lstupdatedt=" + lstupdatedt
				+ ", utmsource=" + utmsource + ", createdt=" + createdt + "]";
	}
	
}
