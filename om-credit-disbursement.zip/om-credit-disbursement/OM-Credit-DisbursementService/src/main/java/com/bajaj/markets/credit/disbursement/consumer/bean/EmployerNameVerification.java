package com.bajaj.markets.credit.disbursement.consumer.bean;

public class EmployerNameVerification {
	private Reference employerName;

	private Verification verification;

	public Reference getEmployerName() {
		return employerName;
	}

	public void setEmployerName(Reference employerName) {
		this.employerName = employerName;
	}

	public Verification getVerification() {
		return verification;
	}

	public void setVerification(Verification verification) {
		this.verification = verification;
	}

}
