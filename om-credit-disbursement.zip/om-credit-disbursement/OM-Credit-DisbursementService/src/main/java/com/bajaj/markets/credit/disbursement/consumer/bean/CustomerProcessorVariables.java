package com.bajaj.markets.credit.disbursement.consumer.bean;

public class CustomerProcessorVariables {

	private String customerResponseString;
	private String customerResponseString_Coapplicant;
	private String customerResponseString_Entity;
	private String customerResponseString_Primary;
	private boolean isRetryMechanism;

	public String getCustomerResponseString() {
		return customerResponseString;
	}

	public void setCustomerResponseString(String customerResponseString) {
		this.customerResponseString = customerResponseString;
	}

	public String getCustomerResponseString_Coapplicant() {
		return customerResponseString_Coapplicant;
	}

	public void setCustomerResponseString_Coapplicant(String customerResponseString_Coapplicant) {
		this.customerResponseString_Coapplicant = customerResponseString_Coapplicant;
	}

	public String getCustomerResponseString_Entity() {
		return customerResponseString_Entity;
	}

	public void setCustomerResponseString_Entity(String customerResponseString_Entity) {
		this.customerResponseString_Entity = customerResponseString_Entity;
	}

	public String getCustomerResponseString_Primary() {
		return customerResponseString_Primary;
	}

	public void setCustomerResponseString_Primary(String customerResponseString_Primary) {
		this.customerResponseString_Primary = customerResponseString_Primary;
	}

	public boolean isRetryMechanism() {
		return isRetryMechanism;
	}

	public void setRetryMechanism(boolean isRetryMechanism) {
		this.isRetryMechanism = isRetryMechanism;
	}

}
