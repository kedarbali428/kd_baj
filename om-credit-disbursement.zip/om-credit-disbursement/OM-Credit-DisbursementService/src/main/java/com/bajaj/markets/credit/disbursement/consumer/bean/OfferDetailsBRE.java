package com.bajaj.markets.credit.disbursement.consumer.bean;

public class OfferDetailsBRE {
	private String offerSource;
	private String  offerExpiryDate;
	private Integer 	offerAcceptedStatus;
	private String  offerId;
	private String  riskClassification;
	private String  offerProgramCode;
	private Boolean 	isOfferAvailable;
	private String  iskOfferType;
	private String  offerType;
	private Integer offerAmount;
	public String getOfferSource() {
		return offerSource;
	}
	public void setOfferSource(String offerSource) {
		this.offerSource = offerSource;
	}
	public String getOfferExpiryDate() {
		return offerExpiryDate;
	}
	public void setOfferExpiryDate(String offerExpiryDate) {
		this.offerExpiryDate = offerExpiryDate;
	}
	public Integer getOfferAcceptedStatus() {
		return offerAcceptedStatus;
	}
	public void setOfferAcceptedStatus(Integer offerAcceptedStatus) {
		this.offerAcceptedStatus = offerAcceptedStatus;
	}
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	public String getRiskClassification() {
		return riskClassification;
	}
	public void setRiskClassification(String riskClassification) {
		this.riskClassification = riskClassification;
	}
	public String getOfferProgramCode() {
		return offerProgramCode;
	}
	public void setOfferProgramCode(String offerProgramCode) {
		this.offerProgramCode = offerProgramCode;
	}
	public Boolean getIsOfferAvailable() {
		return isOfferAvailable;
	}
	public void setIsOfferAvailable(Boolean isOfferAvailable) {
		this.isOfferAvailable = isOfferAvailable;
	}
	public String getIskOfferType() {
		return iskOfferType;
	}
	public void setIskOfferType(String iskOfferType) {
		this.iskOfferType = iskOfferType;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public Integer getOfferAmount() {
		return offerAmount;
	}
	public void setOfferAmount(Integer offerAmount) {
		this.offerAmount = offerAmount;
	}
		
}
