package com.bajaj.markets.credit.disbursement.consumer.bean;

public class SalutationMaster {

	private Long salutationkey;

	private String salutationcode;

	public Long getSalutationkey() {
		return salutationkey;
	}

	public void setSalutationkey(Long salutationkey) {
		this.salutationkey = salutationkey;
	}

	public String getSalutationcode() {
		return salutationcode;
	}

	public void setSalutationcode(String salutationcode) {
		this.salutationcode = salutationcode;
	}

	
}
