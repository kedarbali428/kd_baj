package com.bajaj.markets.credit.disbursement.consumer.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FundedDetails {

	private String fundingType;
	private String sumAssured;
	private String policyTenore;
	private String fundingAmount;
	private String fundingROI;
	private String fundingTenor;

	public String getFundingType() {
		return fundingType;
	}

	public void setFundingType(String fundingType) {
		this.fundingType = fundingType;
	}

	public String getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}

	public String getPolicyTenore() {
		return policyTenore;
	}

	public void setPolicyTenore(String policyTenore) {
		this.policyTenore = policyTenore;
	}

	public String getFundingAmount() {
		return fundingAmount;
	}

	public void setFundingAmount(String fundingAmount) {
		this.fundingAmount = fundingAmount;
	}

	public String getFundingROI() {
		return fundingROI;
	}

	public void setFundingROI(String fundingROI) {
		this.fundingROI = fundingROI;
	}

	public String getFundingTenor() {
		return fundingTenor;
	}

	public void setFundingTenor(String fundingTenor) {
		this.fundingTenor = fundingTenor;
	}

}
