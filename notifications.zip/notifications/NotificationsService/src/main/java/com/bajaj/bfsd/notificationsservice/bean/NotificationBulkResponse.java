package com.bajaj.bfsd.notificationsservice.bean;

import java.util.List;

import com.bajaj.bfsd.common.domain.ResponseBean;

public class NotificationBulkResponse {
	
	private List<ResponseBean> bulkResponse;

	public List<ResponseBean> getBulkResponse() {
		return bulkResponse;
	}

	public void setBulkResponse(List<ResponseBean> bulkResponse) {
		this.bulkResponse = bulkResponse;
	}
	
	

}
