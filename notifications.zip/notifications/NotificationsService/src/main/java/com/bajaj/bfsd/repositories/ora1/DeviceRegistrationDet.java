package com.bajaj.bfsd.repositories.ora1;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

/**
 * The persistent class for the DEVICE_REGISTRATION_DET database table.
 * 
 */
@Entity
@Table(name="DEVICE_REGISTRATION_DET")
@NamedQuery(name="DeviceRegistrationDet.findAll", query="SELECT d FROM DeviceRegistrationDet d")
public class DeviceRegistrationDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long deviceregkey;

	private String deviceid;

	private BigDecimal deviceplatform;

	private String deviceregcode;

	private BigDecimal devicetype;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private Timestamp registrationdt;

	private BigDecimal registrationstatus;

	private Timestamp releasedt;

	//bi-directional many-to-one association to DeviceAppRegistrationDet
	@OneToMany(mappedBy="deviceRegistrationDet",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<DeviceAppRegistrationDet> deviceAppRegistrationDets;

	//bi-directional many-to-one association to DeviceMobileNumber
	@OneToMany(mappedBy="deviceRegistrationDet",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<DeviceMobileNumber> deviceMobileNumbers;

	public DeviceRegistrationDet() {
		//Empty constructor needed by JPA
	}

	public long getDeviceregkey() {
		return this.deviceregkey;
	}

	public void setDeviceregkey(long deviceregkey) {
		this.deviceregkey = deviceregkey;
	}

	public String getDeviceid() {
		return this.deviceid;
	}

	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	public BigDecimal getDeviceplatform() {
		return this.deviceplatform;
	}

	public void setDeviceplatform(BigDecimal deviceplatform) {
		this.deviceplatform = deviceplatform;
	}

	public String getDeviceregcode() {
		return this.deviceregcode;
	}

	public void setDeviceregcode(String deviceregcode) {
		this.deviceregcode = deviceregcode;
	}

	public BigDecimal getDevicetype() {
		return this.devicetype;
	}

	public void setDevicetype(BigDecimal devicetype) {
		this.devicetype = devicetype;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Timestamp getRegistrationdt() {
		return this.registrationdt;
	}

	public void setRegistrationdt(Timestamp registrationdt) {
		this.registrationdt = registrationdt;
	}

	public BigDecimal getRegistrationstatus() {
		return this.registrationstatus;
	}

	public void setRegistrationstatus(BigDecimal registrationstatus) {
		this.registrationstatus = registrationstatus;
	}

	public Timestamp getReleasedt() {
		return this.releasedt;
	}

	public void setReleasedt(Timestamp releasedt) {
		this.releasedt = releasedt;
	}

	public List<DeviceAppRegistrationDet> getDeviceAppRegistrationDets() {
		return this.deviceAppRegistrationDets;
	}

	public void setDeviceAppRegistrationDets(List<DeviceAppRegistrationDet> deviceAppRegistrationDets) {
		this.deviceAppRegistrationDets = deviceAppRegistrationDets;
	}

	public DeviceAppRegistrationDet addDeviceAppRegistrationDet(DeviceAppRegistrationDet deviceAppRegistrationDet) {
		getDeviceAppRegistrationDets().add(deviceAppRegistrationDet);
		deviceAppRegistrationDet.setDeviceRegistrationDet(this);

		return deviceAppRegistrationDet;
	}

	public DeviceAppRegistrationDet removeDeviceAppRegistrationDet(DeviceAppRegistrationDet deviceAppRegistrationDet) {
		getDeviceAppRegistrationDets().remove(deviceAppRegistrationDet);
		deviceAppRegistrationDet.setDeviceRegistrationDet(null);

		return deviceAppRegistrationDet;
	}

	public List<DeviceMobileNumber> getDeviceMobileNumbers() {
		return this.deviceMobileNumbers;
	}

	public void setDeviceMobileNumbers(List<DeviceMobileNumber> deviceMobileNumbers) {
		this.deviceMobileNumbers = deviceMobileNumbers;
	}

	public DeviceMobileNumber addDeviceMobileNumber(DeviceMobileNumber deviceMobileNumber) {
		getDeviceMobileNumbers().add(deviceMobileNumber);
		deviceMobileNumber.setDeviceRegistrationDet(this);

		return deviceMobileNumber;
	}

	public DeviceMobileNumber removeDeviceMobileNumber(DeviceMobileNumber deviceMobileNumber) {
		getDeviceMobileNumbers().remove(deviceMobileNumber);
		deviceMobileNumber.setDeviceRegistrationDet(null);

		return deviceMobileNumber;
	}
}