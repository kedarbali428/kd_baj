package com.bajaj.bfsd.repositories.pg;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the "USER_NOTIFICATIONS" database table.
 * 
 */
@Entity
@Table(name="\"USER_NOTIFICATIONS\"" ,schema="\"ORGSYSNOTF\"")
@NamedQuery(name="UserNotification.findAll", query="SELECT u FROM UserNotification u")
public class UserNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"USERNOTFKEY\"")
	@SequenceGenerator(name="USER_NOTIFICATIONS_GENERATOR", sequenceName="\"ORGSYSNOTF\".\"USER_NOTIFICATIONS_PK_SEQ\"",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_NOTIFICATIONS_GENERATOR")

	private long usernotfkey;

	@Column(name="\"DOCATTACHMENTFLG\"")
	private Integer docattachmentflg;

	@Column(name="\"NOTFSOURCE\"")
	private String notfsource;

	@ManyToOne
	@JoinColumn(name="\"NOTIFICATIONTYPEKEY\"")
	private NotificationType notificationType;

	@Column(name="\"RAISEDBYUSERKEY\"")
	private Long raisedbyuserkey;

	@Column(name="\"RAISEDT\"")
	private Timestamp raisedt;

	@Column(name="\"USERKEY\"")
	private Long userkey;

	//bi-directional many-to-one association to UserSmsNotification
	@OneToMany(mappedBy="userNotification",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<UserSmsNotification> userSmsNotifications;

/*	//bi-directional many-to-one association to UserWebNotification
	@OneToMany(mappedBy="userNotification",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<UserWhatsAppNotification> userWhatsAppNotifications;*/

	//bi-directional many-to-one association to UserWebNotification
	@OneToMany(mappedBy="userNotification",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<UserWebNotification> userWebNotifications;
	
	@OneToMany(mappedBy="userNotification",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<UserAppNotification> userAppNotifications;

	//bi-directional many-to-one association to UserEmailNotification
	@OneToMany(mappedBy="userNotification",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<UserEmailNotification> userEmailNotifications;
	
	public UserNotification() {
	}

	public long getUsernotfkey() {
		return this.usernotfkey;
	}

	public void setUsernotfkey(long usernotfkey) {
		this.usernotfkey = usernotfkey;
	}

	public Integer getDocattachmentflg() {
		return this.docattachmentflg;
	}

	public void setDocattachmentflg(Integer docattachmentflg) {
		this.docattachmentflg = docattachmentflg;
	}

	public String getNotfsource() {
		return this.notfsource;
	}

	public void setNotfsource(String notfsource) {
		this.notfsource = notfsource;
	}

	public Long getRaisedbyuserkey() {
		return this.raisedbyuserkey;
	}

	public void setRaisedbyuserkey(Long raisedbyuserkey) {
		this.raisedbyuserkey = raisedbyuserkey;
	}

	public Timestamp getRaisedt() {
		return this.raisedt;
	}

	public void setRaisedt(Timestamp raisedt) {
		this.raisedt = raisedt;
	}

	public Long getUserkey() {
		return this.userkey;
	}

	public void setUserkey(Long userkey) {
		this.userkey = userkey;
	}
	

	public NotificationType getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(NotificationType notificationType) {
		this.notificationType = notificationType;
	}

	public List<UserSmsNotification> getUserSmsNotifications() {
		return userSmsNotifications;
	}

	public void setUserSmsNotifications(
			List<UserSmsNotification> userSmsNotifications) {
		this.userSmsNotifications = userSmsNotifications;
	}

	public List<UserWebNotification> getUserWebNotifications() {
		return userWebNotifications;
	}

	public void setUserWebNotifications(
			List<UserWebNotification> userWebNotifications) {
		this.userWebNotifications = userWebNotifications;
	}

	public List<UserAppNotification> getUserAppNotifications() {
		return userAppNotifications;
	}

	public void setUserAppNotifications(List<UserAppNotification> userAppNotifications) {
		this.userAppNotifications = userAppNotifications;
	}

	public List<UserEmailNotification> getUserEmailNotifications() {
		return userEmailNotifications;
	}

	public void setUserEmailNotifications(List<UserEmailNotification> userEmailNotifications) {
		this.userEmailNotifications = userEmailNotifications;
	}

}