package com.bajaj.bfsd.notificationsservice.bean;

public class NotificationsCount {
	
	private Integer noOfCount;
	private Integer readCount;
	private Integer unreadCount;
	
	public Integer getReadCount() {
		return readCount;
	}

	public void setReadCount(Integer readCount) {
		this.readCount = readCount;
	}

	public Integer getUnreadCount() {
		return unreadCount;
	}

	public void setUnreadCount(Integer unreadCount) {
		this.unreadCount = unreadCount;
	}

	

	public Integer getNoOfCount() {
		return noOfCount;
	}

	public void setNoOfCount(Integer noOfCount) {
		this.noOfCount = noOfCount;
	}

	

	
}
