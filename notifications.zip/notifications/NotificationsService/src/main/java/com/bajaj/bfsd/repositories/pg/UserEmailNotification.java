package com.bajaj.bfsd.repositories.pg;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the "USER_EMAIL_NOTIFICATIONS" database table.
 * 
 */
@Entity
@Table(name="\"USER_EMAIL_NOTIFICATIONS\"" ,schema="\"ORGSYSNOTF\"")
@NamedQuery(name="UserEmailNotification.findAll", query="SELECT u FROM UserEmailNotification u")
public class UserEmailNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"USEREMAILNOTFKEY\"")
	@SequenceGenerator(name="USER_EMAIL_NOTIFICATIONS_GENERATOR", sequenceName="\"ORGSYSNOTF\".\"USER_EMAIL_NOTIFICATIONS_PK_SEQ\"",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_EMAIL_NOTIFICATIONS_GENERATOR")
	private long useremailnotfkey;

	@Column(name="\"DOCATTACHMENTFLG\"")
	private BigDecimal docattachmentflg;

	@Column(name="\"EMAILID\"")
	private String emailid;

	@Column(name="\"EXPIRYDATE\"")
	private Timestamp expirydate;

	@Column(name="\"MESSAGETITLE\"")
	private String messagetitle;

	@Column(name="\"READDT\"")
	private Timestamp readdt;

	@Column(name="\"READSTS\"")
	private BigDecimal readsts;

	@Column(name="\"RESPONSEDT\"")
	private Timestamp responsedt;

	@Column(name="\"RESPONSESTS\"")
	private BigDecimal responsests;

	@Column(name="\"SENDATTEMPTCOUNT\"")
	private BigDecimal sendattemptcount;

	@Column(name="\"SENDDT\"")
	private Timestamp senddt;

	@Column(name="\"SENDSTS\"")
	private BigDecimal sendsts;

	@ManyToOne
	@JoinColumn(name="\"USERNOTFKEY\"")
	private UserNotification userNotification;
	
	public UserEmailNotification() {
	}

	public long getUseremailnotfkey() {
		return this.useremailnotfkey;
	}

	public void setUseremailnotfkey(long useremailnotfkey) {
		this.useremailnotfkey = useremailnotfkey;
	}

	public BigDecimal getDocattachmentflg() {
		return this.docattachmentflg;
	}

	public void setDocattachmentflg(BigDecimal docattachmentflg) {
		this.docattachmentflg = docattachmentflg;
	}

	public String getEmailid() {
		return this.emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public Timestamp getExpirydate() {
		return this.expirydate;
	}

	public void setExpirydate(Timestamp expirydate) {
		this.expirydate = expirydate;
	}

	public String getMessagetitle() {
		return this.messagetitle;
	}

	public void setMessagetitle(String messagetitle) {
		this.messagetitle = messagetitle;
	}

	public Timestamp getReaddt() {
		return this.readdt;
	}

	public void setReaddt(Timestamp readdt) {
		this.readdt = readdt;
	}

	public BigDecimal getReadsts() {
		return this.readsts;
	}

	public void setReadsts(BigDecimal readsts) {
		this.readsts = readsts;
	}

	public Timestamp getResponsedt() {
		return this.responsedt;
	}

	public void setResponsedt(Timestamp responsedt) {
		this.responsedt = responsedt;
	}

	public BigDecimal getResponsests() {
		return this.responsests;
	}

	public void setResponsests(BigDecimal responsests) {
		this.responsests = responsests;
	}

	public BigDecimal getSendattemptcount() {
		return this.sendattemptcount;
	}

	public void setSendattemptcount(BigDecimal sendattemptcount) {
		this.sendattemptcount = sendattemptcount;
	}

	public Timestamp getSenddt() {
		return this.senddt;
	}

	public void setSenddt(Timestamp senddt) {
		this.senddt = senddt;
	}

	public BigDecimal getSendsts() {
		return this.sendsts;
	}

	public void setSendsts(BigDecimal sendsts) {
		this.sendsts = sendsts;
	}

	public UserNotification getUserNotification() {
		return userNotification;
	}

	public void setUserNotification(UserNotification userNotification) {
		this.userNotification = userNotification;
	}

}