package com.bajaj.bfsd.repositories.pg;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the "NOTF_CHANNEL_SUBSCRIPTION" database table.
 * 
 */
@Entity
@Table(name="\"NOTF_CHANNEL_SUBSCRIPTION\"" ,schema="\"ORGSYSMSTR\"")
@NamedQuery(name="NotfChannelSubscription.findAll", query="SELECT n FROM NotfChannelSubscription n")
public class NotfChannelSubscription implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"NOTFCHANNELSUBKEY\"")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long notfchannelsubkey;

	@Column(name="\"ISACTIVE\"")
	private BigDecimal isactive;

	@Column(name="\"LSTUPDATEBY\"")
	private String lstupdateby;

	@Column(name="\"LSTUPDATEDT\"")
	private Timestamp lstupdatedt;

	@Column(name="\"MAXSENDATTEMPT\"")
	private BigDecimal maxsendattempt;

	@Column(name="\"NOTIFICATIONGROUPCODE\"")
	private String notificationgroupcode;
	
	@ManyToOne
	@JoinColumn(name="\"NOTFCHANNELTYPEKEY\"")
	private NotfChannelType notfchanneltypekey;

	//bi-directional many-to-one association to NotificationType
	@ManyToOne
	@JoinColumn(name="\"NOTIFICATIONTYPEKEY\"")
	private NotificationType notificationType;
	
	@Column(name="\"SUBSCRIPTIONDT\"")
	private Timestamp subscriptiondt;

	@Column(name="\"TEMPLATEID\"")
	private String templateid;

	public NotfChannelSubscription() {
	}
	
	public NotfChannelType getNotfchanneltypekey() {
		return notfchanneltypekey;
	}

	public void setNotfchanneltypekey(NotfChannelType notfchanneltypekey) {
		this.notfchanneltypekey = notfchanneltypekey;
	}

	public NotificationType getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(NotificationType notificationType) {
		this.notificationType = notificationType;
	}

	public long getNotfchannelsubkey() {
		return this.notfchannelsubkey;
	}

	public void setNotfchannelsubkey(long notfchannelsubkey) {
		this.notfchannelsubkey = notfchannelsubkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getMaxsendattempt() {
		return this.maxsendattempt;
	}

	public void setMaxsendattempt(BigDecimal maxsendattempt) {
		this.maxsendattempt = maxsendattempt;
	}
	
	public String getNotificationgroupcode() {
		return this.notificationgroupcode;
	}

	public void setNotificationgroupcode(String notificationgroupcode) {
		this.notificationgroupcode = notificationgroupcode;
	}
	
	public Timestamp getSubscriptiondt() {
		return this.subscriptiondt;
	}

	public void setSubscriptiondt(Timestamp subscriptiondt) {
		this.subscriptiondt = subscriptiondt;
	}

	public String getTemplateid() {
		return this.templateid;
	}

	public void setTemplateid(String templateid) {
		this.templateid = templateid;
	}
}