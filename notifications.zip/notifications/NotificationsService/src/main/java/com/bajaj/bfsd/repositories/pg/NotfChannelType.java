package com.bajaj.bfsd.repositories.pg;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the "NOTF_CHANNEL_TYPES" database table.
 * 
 */
@Entity
@Table(name="\"NOTF_CHANNEL_TYPES\"" ,schema="\"ORGSYSMSTR\"")
@NamedQuery(name="NotfChannelType.findAll", query="SELECT n FROM NotfChannelType n")
public class NotfChannelType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"NOTFCHANNELTYPEKEY\"")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long notfchanneltypekey;

	@Column(name="\"CHANNELCODE\"")
	private String channelcode;

	@Column(name="\"CHANNELDESC\"")
	private String channeldesc;

	@Column(name="\"ISACTIVE\"")
	private BigDecimal isactive;

	@Column(name="\"LSTUPDATEBY\"")
	private String lstupdateby;

	@Column(name="\"LSTUPDATEDT\"")
	private Timestamp lstupdatedt;
	

	//bi-directional many-to-one association to NotfChannelSubscription
	@OneToMany(mappedBy="notificationType")
	private List<NotfChannelSubscription> notfChannelSubscriptions;

/*	//bi-directional many-to-one association to UserNotification
	@OneToMany(mappedBy="notificationType")
	private List<UserNotification> userNotifications;
*/

	public List<NotfChannelSubscription> getNotfChannelSubscriptions() {
		return notfChannelSubscriptions;
	}

	public void setNotfChannelSubscriptions(List<NotfChannelSubscription> notfChannelSubscriptions) {
		this.notfChannelSubscriptions = notfChannelSubscriptions;
	}

	/*public List<UserNotification> getUserNotifications() {
		return userNotifications;
	}

	public void setUserNotifications(List<UserNotification> userNotifications) {
		this.userNotifications = userNotifications;
	}*/

	public NotfChannelType() {
	}

	public long getNotfchanneltypekey() {
		return this.notfchanneltypekey;
	}

	public void setNotfchanneltypekey(long notfchanneltypekey) {
		this.notfchanneltypekey = notfchanneltypekey;
	}

	public String getChannelcode() {
		return this.channelcode;
	}

	public void setChannelcode(String channelcode) {
		this.channelcode = channelcode;
	}

	public String getChanneldesc() {
		return this.channeldesc;
	}

	public void setChanneldesc(String channeldesc) {
		this.channeldesc = channeldesc;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
}