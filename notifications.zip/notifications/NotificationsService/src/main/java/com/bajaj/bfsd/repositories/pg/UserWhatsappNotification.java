package com.bajaj.bfsd.repositories.pg;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the "USER_WHATSAPP_NOTIFICATIONS" database table.
 * 
 */
@Entity
@Table(name="\"USER_WHATSAPP_NOTIFICATIONS\"" ,schema="\"ORGSYSNOTF\"")
@NamedQuery(name="UserWhatsappNotification.findAll", query="SELECT u FROM UserWhatsappNotification u")
public class UserWhatsappNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"USERWHATSAPPNOTFKEY\"")
	@SequenceGenerator(name="USER_WHATSAPP_NOTIFICATIONS_GENERATOR", sequenceName="\"ORGSYSNOTF\".\"USER_WHATSAPP_NOTIFICATIONS_PK_SEQ\"",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_WHATSAPP_NOTIFICATIONS_GENERATOR")
	
	private long userwhatsappnotfkey;	

	@Column(name="\"EXPIRYDATE\"")
	private Timestamp expirydate;

	@Column(name="\"MESSAGE\"")
	private String message;

	@Column(name="\"MOBILENO\"")
	private String mobileno;

	@Column(name="\"SENDATTEMPTCOUNT\"")
	private Integer sendattemptcount;

	@Column(name="\"SENDDT\"")
	private Timestamp senddt;

	@Column(name="\"SENDSTS\"")
	private Integer sendsts;

	@ManyToOne
	@JoinColumn(name="\"USERNOTFKEY\"")
	private UserNotification userNotification;


	public UserWhatsappNotification() {
	}

	public long getUserwhatsappnotfkey() {
		return this.userwhatsappnotfkey;
	}

	public void setUserwhatsappnotfkey(long userwhatsappnotfkey) {
		this.userwhatsappnotfkey = userwhatsappnotfkey;
	}

	public Timestamp getExpirydate() {
		return this.expirydate;
	}

	public void setExpirydate(Timestamp expirydate) {
		this.expirydate = expirydate;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMobileno() {
		return this.mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public Integer getSendattemptcount() {
		return this.sendattemptcount;
	}

	public void setSendattemptcount(Integer sendattemptcount) {
		this.sendattemptcount = sendattemptcount;
	}

	public Timestamp getSenddt() {
		return this.senddt;
	}

	public void setSenddt(Timestamp senddt) {
		this.senddt = senddt;
	}

	public Integer getSendsts() {
		return this.sendsts;
	}

	public void setSendsts(Integer sendsts) {
		this.sendsts = sendsts;
	}
	

}