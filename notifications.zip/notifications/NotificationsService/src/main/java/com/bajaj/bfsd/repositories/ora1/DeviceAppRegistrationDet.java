package com.bajaj.bfsd.repositories.ora1;



import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DEVICE_APP_REGISTRATION_DET database table.
 * 
 */
@Entity
@Table(name="DEVICE_APP_REGISTRATION_DET")
@NamedQuery(name="DeviceAppRegistrationDet.findAll", query="SELECT d FROM DeviceAppRegistrationDet d")
public class DeviceAppRegistrationDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long deviceappregkey;

	private String applink;

	private Timestamp appregistrationdt;

	private String appregistrationid;

	private BigDecimal appregistrationstatus;

	private Timestamp appreleasedt;

	private BigDecimal apptype;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to DeviceRegistrationDet
	@ManyToOne
	@JoinColumn(name="DEVICEREGKEY")
	private DeviceRegistrationDet deviceRegistrationDet;

	//bi-directional many-to-one association to DeviceAppUser
	@OneToMany(mappedBy="deviceAppRegistrationDet",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<DeviceAppUser> deviceAppUsers;
	
	public DeviceAppRegistrationDet() {
		//Empty constructor needed by JPA
	}

	public long getDeviceappregkey() {
		return this.deviceappregkey;
	}

	public void setDeviceappregkey(long deviceappregkey) {
		this.deviceappregkey = deviceappregkey;
	}

	public String getApplink() {
		return this.applink;
	}

	public void setApplink(String applink) {
		this.applink = applink;
	}

	public Timestamp getAppregistrationdt() {
		return this.appregistrationdt;
	}

	public void setAppregistrationdt(Timestamp appregistrationdt) {
		this.appregistrationdt = appregistrationdt;
	}

	public String getAppregistrationid() {
		return this.appregistrationid;
	}

	public void setAppregistrationid(String appregistrationid) {
		this.appregistrationid = appregistrationid;
	}

	public BigDecimal getAppregistrationstatus() {
		return this.appregistrationstatus;
	}

	public void setAppregistrationstatus(BigDecimal appregistrationstatus) {
		this.appregistrationstatus = appregistrationstatus;
	}

	public Timestamp getAppreleasedt() {
		return this.appreleasedt;
	}

	public void setAppreleasedt(Timestamp appreleasedt) {
		this.appreleasedt = appreleasedt;
	}

	public BigDecimal getApptype() {
		return this.apptype;
	}

	public void setApptype(BigDecimal apptype) {
		this.apptype = apptype;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public DeviceRegistrationDet getDeviceRegistrationDet() {
		return this.deviceRegistrationDet;
	}

	public void setDeviceRegistrationDet(DeviceRegistrationDet deviceRegistrationDet) {
		this.deviceRegistrationDet = deviceRegistrationDet;
	}

	public List<DeviceAppUser> getDeviceAppUsers() {
		return this.deviceAppUsers;
	}

	public void setDeviceAppUsers(List<DeviceAppUser> deviceAppUsers) {
		this.deviceAppUsers = deviceAppUsers;
	}

	public DeviceAppUser addDeviceAppUser(DeviceAppUser deviceAppUser) {
		getDeviceAppUsers().add(deviceAppUser);
		deviceAppUser.setDeviceAppRegistrationDet(this);

		return deviceAppUser;
	}

	public DeviceAppUser removeDeviceAppUser(DeviceAppUser deviceAppUser) {
		getDeviceAppUsers().remove(deviceAppUser);
		deviceAppUser.setDeviceAppRegistrationDet(null);

		return deviceAppUser;
	}

}