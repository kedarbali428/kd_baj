package com.bajaj.bfsd.notificationsservice.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

import com.bajaj.bfsd.common.business.baseclasses.BFLBusinessApplication;

	@PropertySources(value = {@PropertySource("classpath:notificationsservice.properties"),
			@PropertySource("classpath:error.properties"),@PropertySource("classpath:logger.properties")})
	@EntityScan("com")
	public class NotificationsServiceApplication extends BFLBusinessApplication{

		/**
		 * The main method.
		 *
		 * @param args the arguments
		 */
		public static void main(String[] args) {        
			SpringApplication.run(NotificationsServiceApplication.class, args);
		}
		
	}
	
