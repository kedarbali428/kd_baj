/*
 * 
 */
package com.bajaj.bfsd.notificationsservice.controller;

import static com.bajaj.bfsd.common.BFLLoggerComponent.CONTROLLER;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerHeader;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.notificationsservice.bean.NotificationBulkResponse;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsBulkRequest;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsDetails;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsStatus;
import com.bajaj.bfsd.notificationsservice.service.NotificationsService;
import com.bajaj.bfsd.notificationsservice.util.NotificationsServiceConstans;
import com.bajaj.bfsd.notificationsservice.util.NotificationsServiceUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@RestController
public class NotificationsServiceController extends BFLController {

	/** The logger. */
	@Autowired
	private BFLLoggerUtilExt logger;
	/** The Constant THIS_CLASS. */
	private static final String THIS_CLASS = NotificationsServiceController.class.getName();

	/** The loan payment service. */
	@Autowired
	NotificationsService notificationsservice;
	/** The env. */
	@Autowired
	private Environment env;

	/**
	 * Gets the notifications count.
	 * 
	 * @param custID
	 *            the cust ID
	 * @param headers
	 *            the headers
	 * @return the notifications count
	 */
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@ApiOperation(value = "Fetch web notifications count", notes = "fetch web notifications count", httpMethod = "GET")
	@RequestMapping(value = "${api.notifications.getnotificationscount.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getNotificationsCount(@PathVariable("custID") String custID,
			@RequestHeader HttpHeaders headers) {
		NotificationsServiceUtil.setCorelationId(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		try {
			ResponseBean reponseBean = new ResponseBean(notificationsservice.fetchNotificationCount(custID));
			return new ResponseEntity<>(reponseBean, HttpStatus.OK);
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, NotificationsServiceConstans.NOTF_8004, exception);
			throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8004,
					env.getProperty(NotificationsServiceConstans.NOTF_8004));
		}
	}

	/**
	 * Gets the notifications Details.
	 * 
	 * @param custID
	 *            the cust ID
	 * @param headers
	 *            the headers
	 * @return the notifications
	 */
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@ApiOperation(value = "Fetch web notifications details", notes = "fetch web notifications Details", httpMethod = "GET")
	@RequestMapping(value = "${api.notifications.getnotifications.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getNotifications(@PathVariable("custID") String custID,
			@RequestParam(value = "pageNo") int pageNo, @RequestParam(value = "pageSize") int pageSize,
			@RequestHeader HttpHeaders headers) {
		NotificationsServiceUtil.setCorelationId(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		try {
			NotificationsDetails notificationsDetails = notificationsservice.fetchNotificationDetails(custID, pageNo,
					pageSize);
			ResponseBean reponseBean = new ResponseBean(notificationsDetails);
			return new ResponseEntity<>(reponseBean, HttpStatus.OK);
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, NotificationsServiceConstans.NOTF_8001, exception);
			throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8001,
					env.getProperty(NotificationsServiceConstans.NOTF_8001));
		}
	}

	/**
	 * Update notifications status.
	 * 
	 * @param custID
	 *            the cust ID
	 * @param headers
	 *            the headers
	 * @return the response entity
	 */
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@ApiOperation(value = "Update Notification", notes = "Update Notification Status", httpMethod = "PUT")
	@RequestMapping(value = "${api.notifications.updatenotificationsstatus.PUT.uri}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> updateNotificationsStatus(@PathVariable("custID") String custID,
			@PathVariable("notifID") String notifID, @RequestHeader HttpHeaders headers) {
		NotificationsStatus notificationsStatus = new NotificationsStatus();
		NotificationsServiceUtil.setCorelationId(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		try {
			String status = notificationsservice.updateNotificationStatus(custID, notifID);
			notificationsStatus.setStatusUpdated(status);
			ResponseBean reponseBean = new ResponseBean(notificationsStatus);
			return new ResponseEntity<>(reponseBean, HttpStatus.OK);
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, NotificationsServiceConstans.NOTF_8006, exception);
			throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8006,
					env.getProperty(NotificationsServiceConstans.NOTF_8006));
		}
	}

	// Notify
	@RequestMapping(value = "${api.notifications.sendnotifications.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Details for Notification", notes = "Details for Notification", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@CrossOrigin
	public ResponseEntity<ResponseBean> sendNotifications(@RequestBody NotificationsRequest notificationsRequest,
			@RequestHeader HttpHeaders header) {
		ResponseBean reponseBean = null;
		try {
			logger.info(THIS_CLASS, CONTROLLER, "sendNotifications Started");
			reponseBean = notificationsservice.sendNotificationRequest(notificationsRequest);
			logger.info(THIS_CLASS, CONTROLLER, "sendNotifications Completed");
			return new ResponseEntity<>(reponseBean, HttpStatus.OK);
		} catch (BFLBusinessException exception) {
			logger.error(THIS_CLASS, CONTROLLER, "Business Exception occured while sending notifications", exception);
			throw exception;
		} catch (BFLTechnicalException exception) {
			logger.error(THIS_CLASS, CONTROLLER, "Technical Exception occured while sending notifications", exception);
			throw exception;
		} catch (Exception exception) {
			logger.error(THIS_CLASS, CONTROLLER, "Exception occured while sending notifications", exception);
			throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8015,
					env.getProperty(NotificationsServiceConstans.NOTF_8015));
		}
	}

	@RequestMapping(value = "${api.notifications.sendbulknotifications.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Details for Bulk Notification", notes = "Details for Bulk Notification", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@CrossOrigin
	public ResponseEntity<ResponseBean> sendBulkNotifications(
			@RequestBody NotificationsBulkRequest notificationsBulkRequest, @RequestHeader HttpHeaders header) {
		ResponseBean reponseBean = null;
		NotificationBulkResponse notificationBulkResponse;
		try {
			logger.info(THIS_CLASS, CONTROLLER, "Notifications ServiceRequest Started");
			notificationBulkResponse = notificationsservice.sendNotificationBulkRequest(notificationsBulkRequest);
			reponseBean = new ResponseBean(notificationBulkResponse);
			logger.info(THIS_CLASS, CONTROLLER, "Notifications ServiceRequest Completed");
			return new ResponseEntity<>(reponseBean, HttpStatus.OK);
		} catch (BFLBusinessException exception) {
			logger.error(THIS_CLASS, CONTROLLER,
					"Business Exception occured while getting Notifications ServiceRequest", exception);
			throw exception;
		} catch (BFLTechnicalException exception) {
			logger.error(THIS_CLASS, CONTROLLER,
					"Technical Exception occured while getting Notifications ServiceRequest", exception);
			throw exception;
		} catch (Exception exception) {
			logger.error(THIS_CLASS, CONTROLLER, "Exception occured while getting Notifications ServiceRequestnt",
					exception);
			throw new BFLTechnicalException("Exception occured while getting Notifications ServiceRequest", exception);
		}
	}
	
	@RequestMapping(value = "${api.notifications.senduinotifications.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Details for UI Notification", notes = "Details for UI Notification", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@CrossOrigin
	public ResponseEntity<ResponseBean> sendUiNotifications(@RequestBody NotificationsRequest notificationsRequest,
			@RequestHeader HttpHeaders header) {
		ResponseBean reponseBean = null;
		try {
			logger.info(THIS_CLASS, CONTROLLER, "sendUiNotifications Started");
			reponseBean = notificationsservice.sendNotificationRequest(notificationsRequest);
			logger.info(THIS_CLASS, CONTROLLER, "sendUiNotifications Completed");
			return new ResponseEntity<>(reponseBean, HttpStatus.OK);
		} catch (BFLBusinessException exception) {
			logger.error(THIS_CLASS, CONTROLLER, "Business Exception occured while sending UI notifications", exception);
			throw exception;
		} catch (BFLTechnicalException exception) {
			logger.error(THIS_CLASS, CONTROLLER, "Technical Exception occured while sending UI notifications", exception);
			throw exception;
		} catch (Exception exception) {
			logger.error(THIS_CLASS, CONTROLLER, "Exception occured while sending UI notifications", exception);
			throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8022,
					env.getProperty(NotificationsServiceConstans.NOTF_8022));
		}
	}
	

	@ApiOperation(value = "Handle bounce back of undeliverable emails", notes = "Handle bounce back of undeliverable emails", httpMethod = "POST")
	@RequestMapping(method = RequestMethod.POST, value = "${api.notification.bounces.POST.uri}", consumes = MediaType.ALL_VALUE)
	@CrossOrigin
	public void bounceNotification(@RequestBody String notificationText) {
		try {
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "bounceNotification: input:" + notificationText);
			JSONArray notificationArray = new JSONArray(notificationText);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"bounceNotification: json array:" + notificationArray);
			JSONObject notificationObject = notificationArray.getJSONObject(0);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"bounceNotification: json object:" + notificationObject);
			String frmEmailId = notificationObject.has("FROMADDRESS")?notificationObject.getString("FROMADDRESS"):null;
			if (frmEmailId == null || !frmEmailId.contains("noreply")) {
				return;
			}
			String email = notificationObject.getString("EMAIL");
			int bounceType = notificationObject.has("BOUNCE_TYPE") ? notificationObject.getString("BOUNCE_TYPE") != null
					? "SOFTBOUNCE".equals(notificationObject.getString("BOUNCE_TYPE")) ? 2 : 1 : 1 : 1;
			ArrayList<String> bouncedRecepients = new ArrayList<>();
			bouncedRecepients.add(email);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "bounceNotification - email:" + email);
			String result = notificationsservice.bounceNotification(bouncedRecepients, null, bounceType);
			logger.info(THIS_CLASS, CONTROLLER, "bounceNotification Completed - result: " + result);
		} catch (BFLBusinessException exception) {
			logger.error(THIS_CLASS, CONTROLLER, "Business Exception occured while updating bounce notification",
					exception);
			throw exception;
		} catch (Exception exception) {
			logger.error(THIS_CLASS, CONTROLLER,
					"bounceNotification:Exception occured while updating bounce notification.", exception);
			throw new BFLTechnicalException("Exception occured while updating bounce notification", exception);
		}
	}
}
