package com.bajaj.bfsd.notificationsservice.bean;

import java.util.ArrayList;
import java.util.List;

public class NotificationsDetails {
	
	
	List<NotificationDetailsBean>notificationDetails= new ArrayList<>();

	public List<NotificationDetailsBean> getNotificationDetails() {
		return notificationDetails;
	}

	public void setNotificationDetails(List<NotificationDetailsBean> notificationDetails) {
		this.notificationDetails = notificationDetails;
	}
	
	

	
	
	
	
	
}
