package com.bajaj.bfsd.notificationsservice.util;

public class NotificationsServiceQueryConstans {
	 /**
    * Constant for application level logging
    */
	public static final String QUERY_FOR_FETCH_USERKEY = "from UserApplicant ua where ua.applicantkey =:custId ";
	
	public static final String QUERY_FOR_FETCH_NOTIFICATION = "from UserNotification un where un.userkey =:userKey ";
	
	public static final String QUERY_FOR_FETCH_COUNT = "from UserWebNotification web where web.userNotification.usernotfkey =:noteKey and readsts=0";
	public static final String QUERY_FOR_FETCH_UPDATE_COUNT = "from UserWebNotification web where web.userNotification.usernotfkey =:noteKey and readsts=0";
	public static final String QUERY_BY_NOTIFICATION_TYPE_CODE = "from NotificationType nt where nt.notificationtypecode =:notificationtypecode and nt.isactive=:activeFlag";
	public static final String QUERY_BY_NOTIFICATION_TYPE_KEY = "from NotfChannelSubscription ncs where ncs.notificationType =:notificationType and ncs.isactive=:activeFlag";
	public static final String QRY_TO_UPDT_BOUNCE_FLAG = "update ApplicantEmail set emailbounceflg=:bounceType,emailbouncedt=sysdate,apltemaillstupdateby=:updatedBy,apltemaillstupdatedt=sysdate where apltemailaddress in (:emailAddresses) and apltemailisactive=1 and apltemailidisverified!=1 and (emailbounceflg is null OR emailbounceflg!=1)";
	public static final String QUERY_FOR_FETCH_APPLINK = "from DeviceAppUser du where du.userkey=:userkey and du.deviceAppRegistrationDet.apptype=:apptype order by du.appuserregistrationdt desc";
	public static final String UPDATED_BY = "SYSTEM";
	public static final String QUERY_FOR_FETCH_NOTIFICATION_DTLS=" SELECT USERNOTFKEY,SENDDT,READSTS,SENDSTS,MESSAGECONTENT"
			+ " FROM ((SELECT rownum rm,uwn.* FROM(SELECT wn.USERNOTFKEY,wn.SENDDT,wn.READSTS,wn.SENDSTS,wn.MESSAGECONTENT"
			+ " FROM USER_WEB_NOTIFICATIONS wn,USER_NOTIFICATIONS n "
			+ " WHERE wn.USERNOTFKEY = n.USERNOTFKEY AND n.userkey = :userid ORDER BY senddt DESC ) uwn ))"
			+ " WHERE rm BETWEEN :recordfrom AND :recordto"; 
	
	public static final String QUERY_GET_NOTFCHANNELSUBSCRIPTION_BY_CHANNEL_CODE= "from NotfChannelSubscription where notificationgroupcode=:notificationgroupcode "
			+ "AND notfchanneltypekey.channelcode=:channelcode AND notificationType.notificationtypecode=:notificationtypecode AND isactive=:isactive";
  
	
	private NotificationsServiceQueryConstans()
	{
		//private constructor
	}

}
