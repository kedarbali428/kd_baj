package com.bajaj.bfsd.repositories.pg;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the "NOTIFICATION_TYPES" database table.
 * 
 */
@Entity
@Table(name="\"NOTIFICATION_TYPES\"" ,schema="\"ORGSYSMSTR\"")
@NamedQuery(name="NotificationType.findAll", query="SELECT n FROM NotificationType n")
public class NotificationType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"NOTIFICATIONTYPEKEY\"")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long notificationtypekey;

	@Column(name="\"ISACTIVE\"")
	private BigDecimal isactive;

	@Column(name="\"LSTUPDATEBY\"")
	private String lstupdateby;

	@Column(name="\"LSTUPDATEDT\"")
	private Timestamp lstupdatedt;

	@Column(name="\"NOTIFICATIONTYPECODE\"")
	private String notificationtypecode;

	@Column(name="\"NOTIFICATIONTYPEDESC\"")
	private String notificationtypedesc;

	@Column(name="\"TRIGGERTYPECODE\"")
	private BigDecimal triggertypecode;

	@OneToMany(mappedBy="notificationType",fetch = FetchType.EAGER)
	
	private List<NotfChannelSubscription> notfChannelSubscriptions;

	/*//bi-directional many-to-one association to UserNotfSubscription
	@OneToMany(mappedBy="notificationType")
	private List<UserNotfSubscription> userNotfSubscriptions;
*/
	//bi-directional many-to-one association to UserNotification
	@OneToMany(mappedBy="notificationType" )
	private List<UserNotification> userNotifications;
	
	public List<NotfChannelSubscription> getNotfChannelSubscriptions() {
		return notfChannelSubscriptions;
	}

	public void setNotfChannelSubscriptions(List<NotfChannelSubscription> notfChannelSubscriptions) {
		this.notfChannelSubscriptions = notfChannelSubscriptions;
	}

	public List<UserNotification> getUserNotifications() {
		return userNotifications;
	}

	public void setUserNotifications(List<UserNotification> userNotifications) {
		this.userNotifications = userNotifications;
	}

	public NotificationType() {
	}

	public long getNotificationtypekey() {
		return this.notificationtypekey;
	}

	public void setNotificationtypekey(long notificationtypekey) {
		this.notificationtypekey = notificationtypekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getNotificationtypecode() {
		return this.notificationtypecode;
	}

	public void setNotificationtypecode(String notificationtypecode) {
		this.notificationtypecode = notificationtypecode;
	}

	public String getNotificationtypedesc() {
		return this.notificationtypedesc;
	}

	public void setNotificationtypedesc(String notificationtypedesc) {
		this.notificationtypedesc = notificationtypedesc;
	}

	public BigDecimal getTriggertypecode() {
		return this.triggertypecode;
	}

	public void setTriggertypecode(BigDecimal triggertypecode) {
		this.triggertypecode = triggertypecode;
	}
}