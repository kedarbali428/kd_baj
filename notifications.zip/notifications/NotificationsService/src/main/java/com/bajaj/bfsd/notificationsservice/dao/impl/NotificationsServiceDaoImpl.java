package com.bajaj.bfsd.notificationsservice.dao.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.notificationsservice.bean.NotificationDetailsBean;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsCount;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsDetails;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;
import com.bajaj.bfsd.notificationsservice.dao.NotificationsServiceDao;
import com.bajaj.bfsd.notificationsservice.util.NotificationsServiceConstans;
import com.bajaj.bfsd.notificationsservice.util.NotificationsServiceQueryConstans;
import com.bajaj.bfsd.notificationsservice.util.NotificationsServiceUtil;
import com.bajaj.bfsd.repositories.ora1.DeviceAppUser;
import com.bajaj.bfsd.repositories.pg.NotfChannelSubscription;
import com.bajaj.bfsd.repositories.pg.NotfChannelType;
import com.bajaj.bfsd.repositories.pg.NotificationType;
import com.bajaj.bfsd.repositories.pg.UserNotification;
import com.bajaj.bfsd.repositories.pg.UserWebNotification;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
public class NotificationsServiceDaoImpl extends BFLComponent implements NotificationsServiceDao {

	/*@Autowired
	EntityManager entityManager;*/

	@Autowired
	BFLLoggerUtilExt logger; //

	@Autowired
	private Environment env;

	@Autowired
	@Qualifier("miscEntityManager")
	private EntityManager entityManager;

	@Autowired
	@Qualifier("primaryEntityManager")
	private EntityManager primaryEntityManager;

	@Autowired
	protected CustomDefaultHeaders customdefaultheaders;
	
	private static final String THIS_CLASS = NotificationsServiceDaoImpl.class.getName();

	// Fetching the Notification Details.
	@Override
	public NotificationsDetails fetchDetails(String custId, int pageNo, int pageSize) {
		try {
			NotificationsDetails notificationsDetails = new NotificationsDetails();
			long userKey = fetchuserKey();
			if (userKey != 0l) {
				notificationsDetails = getnotificationDetailsList(userKey, pageNo, pageSize);
			}
			return notificationsDetails;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, NotificationsServiceConstans.NOTF_8003, e);
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8003,
					env.getProperty(NotificationsServiceConstans.NOTF_8003));
		}
	}

	@SuppressWarnings("unchecked")
	public NotificationsDetails getnotificationDetailsList(long userKey, int pageNo, int pageSize) {
		NotificationsDetails notificationsList = new NotificationsDetails();
		List<NotificationDetailsBean> notificationDetails = new ArrayList<>();
		NotificationDetailsBean notificationDetailsBean = null;
		List<Object[]> notificationDetailsList;
		try {
			Integer recordfrom = pageNo * pageSize + 1;
			Integer recordto = recordfrom + pageSize - 1;
			StringBuilder strBuilder = new StringBuilder(
					NotificationsServiceQueryConstans.QUERY_FOR_FETCH_NOTIFICATION_DTLS);
			Query query = entityManager.createNativeQuery(strBuilder.toString());
			query.setParameter("recordfrom", recordfrom);
			query.setParameter("recordto", recordto);
			query.setParameter("userid", userKey);
			notificationDetailsList = query.getResultList();
			if (null != notificationDetailsList && !notificationDetailsList.isEmpty())
				for (Object[] object : notificationDetailsList) {
					notificationDetailsBean = new NotificationDetailsBean();
					getnotificationDetailsListHelper(object, notificationDetailsBean);
					notificationDetails.add(notificationDetailsBean);
				}
			notificationsList.setNotificationDetails(notificationDetails);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, NotificationsServiceConstans.NOTF_8003, e);
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8003,
					env.getProperty(NotificationsServiceConstans.NOTF_8003));
		}
		return notificationsList;
	}
	
	private void getnotificationDetailsListHelper(Object[] object,NotificationDetailsBean notificationDetailsBean) throws SQLException, IOException{
		if (object[0] != null) {
			BigDecimal id = (BigDecimal) object[0];
			notificationDetailsBean.setUserNoteId(id.longValueExact());
		}
		if (object[1] != null) {
			Timestamp date = (Timestamp) object[1];
			String senddate = NotificationsServiceUtil.getStampDateWithInString(date);
			notificationDetailsBean.setSenddt(senddate);
		}
		if (object[2] != null) {
			notificationDetailsBean.setReadsts((BigDecimal) object[2]);
		}
		if (object[3] != null) {
			notificationDetailsBean.setSendsts((BigDecimal) object[3]);
		}
		if (object[4] != null) {
			Clob clob = (Clob) object[4];
			InputStream in = clob.getAsciiStream();
			StringWriter w = new StringWriter();
			IOUtils.copy(in, w);
			String clobAsString = w.toString();
			notificationDetailsBean.setMessagecontent(clobAsString);
		}
	}

	// Fetching the No of total web notification count.
	@SuppressWarnings({ "unchecked" })
	@Override
	public NotificationsCount fetchNoOfCount(String custId) {
		NotificationsCount notificationsCount = null;
		try {
			long userKey = fetchuserKey();
			if (userKey != 0l) {
				Query query = entityManager.createQuery(NotificationsServiceQueryConstans.QUERY_FOR_FETCH_NOTIFICATION);
				query.setParameter("userKey", userKey);
				//query.setParameter("activeFlag", NotificationsServiceConstans.ACTIVE_FLAG);
				List<UserNotification> userNotifications = query.getResultList();
				notificationsCount = fetchNoOfCountHelper(userNotifications);
			}
			return notificationsCount;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, NotificationsServiceConstans.NOTF_8005, e);
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8005,
					env.getProperty(NotificationsServiceConstans.NOTF_8005));
		}
	}
	
	private NotificationsCount fetchNoOfCountHelper(List<UserNotification> userNotifications){
		int noOfcount = 0;
		int readCount = 0; 
		for (UserNotification userNotification : userNotifications) {
			userNotification.getUsernotfkey();
			if(!userNotification.getUserWebNotifications().isEmpty()){
				noOfcount++;
				if(BigDecimal.ONE.equals(userNotification.getUserWebNotifications().get(0).getReadsts())){
					readCount++;
				}
			}
		}
		NotificationsCount notificationsCount = new NotificationsCount();
	    notificationsCount.setNoOfCount(noOfcount);
	    notificationsCount.setReadCount(readCount);
	    notificationsCount.setUnreadCount(noOfcount-readCount);
		return notificationsCount;
	}

	// Fetching the user key for based on custID/ApplicantID.
	@SuppressWarnings("unchecked")
	public Long fetchuserKey() {
		try {
			Long userId = 0l;
			if (null != customdefaultheaders && customdefaultheaders.getUserKey()!= -1L ) {
				userId = customdefaultheaders.getUserKey();
			}
			return userId;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, NotificationsServiceConstans.NOTF_8002, e);
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8002,
					env.getProperty(NotificationsServiceConstans.NOTF_8002));
		}
	}

	// Count the no of Web notification based on notification id from
	// UserWebNotification table
	@SuppressWarnings("unchecked")
	public Integer fetchwebNotCount(long noteId) {
		int count = 0;
		try {
			Query query = entityManager.createQuery(NotificationsServiceQueryConstans.QUERY_FOR_FETCH_COUNT);
			query.setParameter("noteKey", noteId);
			List<UserWebNotification> userWebNotification = query.getResultList();
			if (!userWebNotification.isEmpty()) {
				count = 1;
			}
			return count;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, NotificationsServiceConstans.NOTF_8002, e);
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8002,
					env.getProperty(NotificationsServiceConstans.NOTF_8002));
		}
	}

	// Updating read status based on notification id in UserWebNotification
	// table
	@SuppressWarnings("unchecked")
	@Override
	public String updateStatus(String custId, String notifID) {
		try {
			String status;
			Query query = entityManager.createQuery(NotificationsServiceQueryConstans.QUERY_FOR_FETCH_COUNT);
			query.setParameter("noteKey", Long.parseLong(notifID));
			List<UserWebNotification> userWebNotification = query.getResultList();
			UserWebNotification readStatus;
			if (!userWebNotification.isEmpty()) {
				readStatus = userWebNotification.get(0);
				readStatus.setReadsts(NotificationsServiceConstans.READ_STATUS);
				status = NotificationsServiceConstans.STATUS_SUCCESS;
				entityManager.persist(readStatus);
			} else {
				status = NotificationsServiceConstans.STATUS_FAIL;
			}
			return status;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, NotificationsServiceConstans.NOTF_8006, e);
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8006,
					env.getProperty(NotificationsServiceConstans.NOTF_8006));
		}
	}

	// Fetching the NotificationType based on notificationTypeCode.
	@SuppressWarnings("unchecked")
	@Override
	public NotificationType getNotificationTypeKey(String notificationTypeCode) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getNotificationTypeKey - call Started for Notification Type Code: "+notificationTypeCode);
		NotificationType notificationType;
		List<NotificationType> notificationTypes;
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Getting notificationType in NotifyDaoImpl");
			Query query = entityManager.createQuery(NotificationsServiceQueryConstans.QUERY_BY_NOTIFICATION_TYPE_CODE);
			query.setParameter("notificationtypecode", notificationTypeCode);
			query.setParameter("activeFlag", new BigDecimal(1));
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Completed Getting notificationType in NotifyDaoImpl");
			notificationTypes = query.getResultList();
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, NotificationsServiceConstans.NOTF_8011, e);
			throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8016,
					env.getProperty(NotificationsServiceConstans.NOTF_8016));
		}
		if (!notificationTypes.isEmpty()) {
			notificationType = notificationTypes.get(0);
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "Notification Type Code: "+notificationTypeCode+" not found from any available notification Type Code ");
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8011,
					env.getProperty(NotificationsServiceConstans.NOTF_8011));
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getNotificationTypeKey - call Completed for Notification Type Code: "+notificationTypeCode);
		return notificationType;
	}

	@Override
	@Transactional
	public void updateBounceDetails(List<String> bouncedRecepients, String correlationId, int bounceType) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "updateBounceDetails started");
		try {
			Query query = entityManager.createQuery(NotificationsServiceQueryConstans.QRY_TO_UPDT_BOUNCE_FLAG)
					.setParameter("bounceType", new BigDecimal(bounceType))
					.setParameter("emailAddresses", bouncedRecepients)
					.setParameter("updatedBy", NotificationsServiceQueryConstans.UPDATED_BY);
			int rowsUpdated = query.executeUpdate();
			logger.info(THIS_CLASS, BFLLoggerComponent.DAO, "updateBounceDetails:rowsUpdated " + rowsUpdated);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, NotificationsServiceConstans.NOTF_8013, e);
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8013,
					env.getProperty(NotificationsServiceConstans.NOTF_8013));
		}
	}

	@Override
	public String retrieveDeviceAppRegistrationAppLink(String userkey, String apptype) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "retrieveDeviceAppRegistrationAppLink started");
		try {
			Query query = primaryEntityManager.createQuery(NotificationsServiceQueryConstans.QUERY_FOR_FETCH_APPLINK)
					.setParameter("apptype",
							"customer".equalsIgnoreCase(apptype) ? BigDecimal.ONE : BigDecimal.valueOf(2))
					.setParameter("userkey", new BigDecimal(userkey));
			String applink = (query.getResultList() != null && !query.getResultList().isEmpty())
					? ((DeviceAppUser) query.getResultList().get(0)).getDeviceAppRegistrationDet().getApplink() : null;
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
					"retrieveDeviceAppRegistrationAppLink :: applink retrieved" + applink);
			return applink;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, NotificationsServiceConstans.NOTF_8013, e);
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8014,
					env.getProperty(NotificationsServiceConstans.NOTF_8014));
		}
	}

	@Override
	@Transactional
	public NotfChannelSubscription getNotfChanelSubscriptionByChannelCode(NotificationsRequest notificationsRequest, String notificationTypeCode) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getNotfChanelSubscriptionByChannelCode started");
		NotfChannelSubscription notfChannelSubscription = null;
		try{
			Query query = entityManager.createQuery(NotificationsServiceQueryConstans.QUERY_GET_NOTFCHANNELSUBSCRIPTION_BY_CHANNEL_CODE);
			query.setParameter("notificationgroupcode", notificationsRequest.getNotificationGroupCode());
			query.setParameter("channelcode", notificationsRequest.getChannelCode());
			query.setParameter("notificationtypecode", notificationTypeCode);
			query.setParameter("isactive", BigDecimal.ONE);
			List<NotfChannelSubscription> notfChannelSubscriptionList = query.getResultList();
			if(!CollectionUtils.isEmpty(notfChannelSubscriptionList)){
				notfChannelSubscription = notfChannelSubscriptionList.get(0);
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getNotfChanelSubscriptionByChannelCode end");
			return notfChannelSubscription;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, NotificationsServiceConstans.NOTF_8023, e);
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8023,
					env.getProperty(NotificationsServiceConstans.NOTF_8023));
		}
	}
}