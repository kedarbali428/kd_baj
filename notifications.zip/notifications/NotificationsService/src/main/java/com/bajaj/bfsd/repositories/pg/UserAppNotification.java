package com.bajaj.bfsd.repositories.pg;

import java.io.Serializable;
import javax.persistence.*;

import com.bajaj.bfsd.repositories.pg.UserNotification;

import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the "USER_APP_NOTIFICATIONS" database table.
 * 
 */
@Entity
@Table(name="\"USER_APP_NOTIFICATIONS\"" ,schema="\"ORGSYSNOTF\"")
@NamedQuery(name="UserAppNotification.findAll", query="SELECT u FROM UserAppNotification u")
public class UserAppNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"USERAPPNOTFKEY\"")
	@SequenceGenerator(name="USER_APP_NOTIFICATIONS_GENERATOR", sequenceName="\"ORGSYSNOTF\".\"USER_APP_NOTIFICATIONS_PK_SEQ\"",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_APP_NOTIFICATIONS_GENERATOR")

	private long userappnotfkey;

	@Column(name="\"ACKNOWLEDGEMENTDT\"")
	private Timestamp acknowledgementdt;

	@Column(name="\"ACKNOWLEDGEMENTID\"")
	private String acknowledgementid;

	@Column(name="\"DOCATTACHMENTFLG\"")
	private BigDecimal docattachmentflg;

	@Column(name="\"EXPIRYDATE\"")
	private Timestamp expirydate;

	@Column(name="\"MESSAGECONTENT\"")
	private String messagecontent;

	@Column(name="\"MESSAGETITLE\"")
	private String messagetitle;

	@Column(name="\"READDT\"")
	private Timestamp readdt;

	@Column(name="\"READSTS\"")
	private BigDecimal readsts;

	@Column(name="\"SENDATTEMPTCOUNT\"")
	private BigDecimal sendattemptcount;

	@Column(name="\"SENDDT\"")
	private Timestamp senddt;

	@Column(name="\"SENDSTS\"")
	private BigDecimal sendsts;

	@Column(name="\"TARGETDEVICEID\"")
	private String targetdeviceid;

	@ManyToOne
	@JoinColumn(name="\"USERNOTFKEY\"")
	private UserNotification userNotification;

	public UserAppNotification() {
	}

	public long getUserappnotfkey() {
		return this.userappnotfkey;
	}

	public void setUserappnotfkey(long userappnotfkey) {
		this.userappnotfkey = userappnotfkey;
	}

	public Timestamp getAcknowledgementdt() {
		return this.acknowledgementdt;
	}

	public void setAcknowledgementdt(Timestamp acknowledgementdt) {
		this.acknowledgementdt = acknowledgementdt;
	}

	public String getAcknowledgementid() {
		return this.acknowledgementid;
	}

	public void setAcknowledgementid(String acknowledgementid) {
		this.acknowledgementid = acknowledgementid;
	}

	public BigDecimal getDocattachmentflg() {
		return this.docattachmentflg;
	}

	public void setDocattachmentflg(BigDecimal docattachmentflg) {
		this.docattachmentflg = docattachmentflg;
	}

	public Timestamp getExpirydate() {
		return this.expirydate;
	}

	public void setExpirydate(Timestamp expirydate) {
		this.expirydate = expirydate;
	}

	public String getMessagecontent() {
		return this.messagecontent;
	}

	public void setMessagecontent(String messagecontent) {
		this.messagecontent = messagecontent;
	}

	public String getMessagetitle() {
		return this.messagetitle;
	}

	public void setMessagetitle(String messagetitle) {
		this.messagetitle = messagetitle;
	}

	public Timestamp getReaddt() {
		return this.readdt;
	}

	public void setReaddt(Timestamp readdt) {
		this.readdt = readdt;
	}

	public BigDecimal getReadsts() {
		return this.readsts;
	}

	public void setReadsts(BigDecimal readsts) {
		this.readsts = readsts;
	}

	public BigDecimal getSendattemptcount() {
		return this.sendattemptcount;
	}

	public void setSendattemptcount(BigDecimal sendattemptcount) {
		this.sendattemptcount = sendattemptcount;
	}

	public Timestamp getSenddt() {
		return this.senddt;
	}

	public void setSenddt(Timestamp senddt) {
		this.senddt = senddt;
	}

	public BigDecimal getSendsts() {
		return this.sendsts;
	}

	public void setSendsts(BigDecimal sendsts) {
		this.sendsts = sendsts;
	}

	public String getTargetdeviceid() {
		return this.targetdeviceid;
	}

	public void setTargetdeviceid(String targetdeviceid) {
		this.targetdeviceid = targetdeviceid;
	}

	public UserNotification getUserNotification() {
		return userNotification;
	}

	public void setUserNotification(UserNotification userNotification) {
		this.userNotification = userNotification;
	}
}