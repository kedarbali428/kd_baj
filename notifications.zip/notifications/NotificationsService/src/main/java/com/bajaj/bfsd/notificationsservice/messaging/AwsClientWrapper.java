package com.bajaj.bfsd.notificationsservice.messaging;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.amazon.sqs.javamessaging.AmazonSQSMessagingClientWrapper;
import com.amazon.sqs.javamessaging.SQSConnection;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.notificationsservice.util.NotificationsServiceConstans;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
@RefreshScope
public class AwsClientWrapper {
	
	@Autowired
	SQSConnection sqsConnection;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	Environment env;
	
	private AmazonSQSMessagingClientWrapper client;
	private Session session;
	private Map<String , MessageProducer> producerCache;
	
	private static final String CLASSNAME = AwsClientWrapper.class.getName();
	
	
	public Session getSession() {
		return session;
	}
	
	public AmazonSQSMessagingClientWrapper getClient() {
		return client;
	}

	@PostConstruct
	public void initAwsClient(){
		try {
			producerCache = new HashMap<>();
			session = sqsConnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			client = sqsConnection.getWrappedAmazonSQSClient();
		} catch (JMSException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occurred while creating JMS session or Aws client object." + e);
			throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8028, env.getProperty(NotificationsServiceConstans.NOTF_8028));
		}
	}

	public MessageProducer getProducer(String queueName) {

		MessageProducer producer;
		if (producerCache.containsKey(queueName)) {
			producer = producerCache.get(queueName);
		}else {
			try {
				if (!client.queueExists(queueName)) {
					client.createQueue(queueName);
				}
				Queue queue = session.createQueue(queueName);
				producer = session.createProducer(queue);
				producerCache.put(queueName, producer);
			} catch (JMSException e) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occurred while creating JMS Queue or Producer." + e);
				throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8029, env.getProperty(NotificationsServiceConstans.NOTF_8029));
			}
		}
		return producer;
	}

	@PreDestroy
	private void cleanConnections() {
		try {
			if (session != null) {
				session.close();
			}
			if(sqsConnection != null){
				sqsConnection.close();
			}
		} catch (JMSException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occurred while closing session or sqsConnection" + e);
		}
	}
}