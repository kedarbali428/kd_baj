package com.bajaj.bfsd.notificationsservice.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.notificationservice.helper.ConsentNotificatonIntegrationHelper;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;
import com.bajaj.bfsd.notificationsservice.dao.NotificationsServiceDao;
import com.bajaj.bfsd.notificationsservice.messaging.AwsClientWrapper;
import com.bajaj.bfsd.notificationsservice.messaging.NotificationsQueue;
import com.bajaj.bfsd.repositories.pg.NotfChannelSubscription;
import com.bajaj.bfsd.repositories.pg.NotificationType;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLBusinessException;

@RefreshScope
@Component
public class NotificationsMapper extends BFLComponent {

	@Autowired
	Environment env;

	@Value("${aws.s3.bucket.template}")
	private String bucketName;

	@Value("${aws.sqs.sms.queue}")
	private String smsQueueName;
	
	@Value("${aws.sqs.whatsapp.queue}")
	private String whatsappQueueName;

	@Value("${aws.sqs.mail.queue}")
	private String emailQueueName;

	@Value("${aws.sqs.app.queue}")
	private String appQueueName;
	
	@Value("${aws.sqs.web.queue}")
	private String webQueueName;
	
	@Value("${aws.sqs.otpsms.queue}")
	private String highPriorityQueueName;

	@Autowired
	private NotificationsServiceDao notificationsServiceDao;

	@Autowired
	private NotificationsQueue notificationsQueue;

	@Autowired
	private CustomDefaultHeaders customheaders;

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	AwsClientWrapper awsClientWrapper;

	@Autowired
	private ConsentNotificatonIntegrationHelper consentNotificatonIntegrationHelper;

	private static final String THIS_CLASS = NotificationsMapper.class.getName();

	public ResponseBean notificationSend(NotificationType notificationType, NotificationsRequest notificationsRequest) {
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "notificationSend - call Started");
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "notificationsRequest Code---" + notificationsRequest.getNotificationTypeCode());
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "notificationsRequest Map---" + notificationsRequest.getTemplateDataMap());
		ResponseBean notificationsResponse = new ResponseBean();
		List<ErrorBean> errorBean = new ArrayList<>();
		
		//Below condition added for scheduled notifications.
		if(null != notificationsRequest.getChannelCode() && !notificationsRequest.getChannelCode().isEmpty()
				&& null != notificationsRequest.getNotificationGroupCode() && !notificationsRequest.getNotificationGroupCode().isEmpty()){
			//new code for scheduled notifications
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "notificationSend - call Scheduled notification--");
			if(null !=notificationType.getNotificationtypecode()){
				NotfChannelSubscription notfChannelSubscription = notificationsServiceDao.getNotfChanelSubscriptionByChannelCode(notificationsRequest,notificationType.getNotificationtypecode());
				if(null != notfChannelSubscription){
					sendEachNotificationToQueue(notificationType, notificationsRequest, errorBean, notfChannelSubscription);
				}else{
					logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, NotificationsServiceConstans.NOTF_8026);
					throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8026,
							env.getProperty(NotificationsServiceConstans.NOTF_8026));
				}
			}
		}else{
			//Old Code for notifications
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "notificationSend - call triggered notification--");
			for (NotfChannelSubscription notfChannelSubscription : notificationType.getNotfChannelSubscriptions()) {
				sendEachNotificationToQueue(notificationType, notificationsRequest, errorBean, notfChannelSubscription);
			}
		}
		if(!errorBean.isEmpty()){
			notificationsResponse.setErrorBean(errorBean);
			notificationsResponse.setPayload("Failure");
			notificationsResponse.setStatus(StatusCode.FAILURE);
		}
		else{
			notificationsResponse.setErrorBean(null);
			notificationsResponse.setPayload("Success");
			notificationsResponse.setStatus(StatusCode.SUCCESS);
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "notificationSend - call Completed");
		return notificationsResponse;
	}

	/**
	 * Sending message to specific queue on the basis of channel & high priority.
	 * @param notificationTypeCode
	 * @param notificationsRequest
	 * @param errorBean
	 * @param notfChannelSubscription
	 */
	private void sendEachNotificationToQueue(NotificationType notificationType, NotificationsRequest notificationsRequest,List<ErrorBean> errorBean, NotfChannelSubscription notfChannelSubscription){
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "sendEachNotificationToQueue - call Started");
		String channelCode = null;
		if (BigDecimal.ONE.equals(notfChannelSubscription.getNotfchanneltypekey().getIsactive())) {
			channelCode = notfChannelSubscription.getNotfchanneltypekey().getChannelcode();
		}
		
		String templateId = notfChannelSubscription.getTemplateid();
		String templateCode = templateId + ".txt";
		notificationsRequest.setTemplateName(templateCode);
		
		if (customheaders.getUserKey() > 0) {
			notificationsRequest.setUserKey(customheaders.getUserKey());
		}
		
		notificationsRequest.setNotificationTypeKey(notificationType.getNotificationtypekey());
		if (null != channelCode) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Send notification on Channel: " + channelCode);
			try {
				if (NotificationsServiceConstans.SMS_CHANNEL.equals(channelCode)
						&& NotificationsServiceConstans.OTP_TYPE_CODE
								.equalsIgnoreCase(notificationType.getNotificationtypecode())) {
					validateNotificationRequestForSMS(notificationsRequest);
					notificationsQueue.sendMessageToQueue(notificationsRequest, highPriorityQueueName);
				} else if (NotificationsServiceConstans.SMS_CHANNEL.equals(channelCode)
						&& !NotificationsServiceConstans.OTP_TYPE_CODE
								.equalsIgnoreCase(notificationType.getNotificationtypecode())) {
					validateNotificationRequestForSMS(notificationsRequest);
					notificationsQueue.sendMessageToQueue(notificationsRequest, smsQueueName);
				}else if(NotificationsServiceConstans.EMAIL_CHANNEL.equals(channelCode)){
					validateNotificationRequestForEmail(notificationsRequest);
					notificationsQueue.sendMessageToQueue(notificationsRequest, emailQueueName);
				}else if(NotificationsServiceConstans.APP_CHANNEL.equals(channelCode)){
					validateNotificationRequestForApp(notificationsRequest);
					notificationsQueue.sendMessageToQueue(notificationsRequest, appQueueName);
				}else if(NotificationsServiceConstans.WHATSAPP_CHANNEL.equals(channelCode)){
					validateNotificationRequestForSMS(notificationsRequest);
					if (consentNotificatonIntegrationHelper.getConsentAPIResult(notificationsRequest
							.getTemplateDataMap().get(NotificationsServiceConstans.PHONENUMBER).toString())) {
						logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
								" Sending message to whats app queue or validation started " + whatsappQueueName);
						notificationsQueue.sendMessageToQueue(notificationsRequest, whatsappQueueName);
						logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
								" Sending message to whats app queue or validation ended " + whatsappQueueName);
					} else {
						logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
								"  Message to whats app queue is not sent as not subscribed for the mobile number");
					}
				} else if (NotificationsServiceConstans.WEB_CHANNEL.equals(channelCode)) {
					notificationsQueue.sendMessageToQueue(notificationsRequest, webQueueName);
				}
			}catch (Exception e) {
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,
						"Getting Exception while sending message to queue or validation failed" + e);
				ErrorBean errBean = new ErrorBean(NotificationsServiceConstans.NOTF_8030, e.getMessage());
				errorBean.add(errBean);
			}
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "sendEachNotificationToQueue - call Ended");
	}
	
	private void validateNotificationRequestForSMS(NotificationsRequest notificationsRequest){
		if(notificationsRequest.getTemplateDataMap().get(NotificationsServiceConstans.PHONENUMBER)==null){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,"Mobile Number can not be null");
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8018, env.getProperty(NotificationsServiceConstans.NOTF_8018));
		}	
	}
	
	private void validateNotificationRequestForEmail(NotificationsRequest notificationsRequest){
		if(notificationsRequest.getTemplateDataMap().get(NotificationsServiceConstans.MAILID)==null){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,"RecipientEmailId can not be null");
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8019, env.getProperty(NotificationsServiceConstans.NOTF_8019));
		}
	}
	
	private void validateNotificationRequestForApp(NotificationsRequest notificationsRequest){
		Object ukey=notificationsRequest.getTemplateDataMap().get(NotificationsServiceConstans.USERKEY);
		Object apptyp=notificationsRequest.getTemplateDataMap().get(NotificationsServiceConstans.APPTYPE);
		if(null == ukey || "0".equals(ukey.toString()) || null == apptyp){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,"Userkey/App Type can not be null");
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8021, env.getProperty(NotificationsServiceConstans.NOTF_8021));
			}
		String link = getAppEndpointLink(notificationsRequest);
		if(link==null){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,"AppEndpointLink can not be null");
			throw new BFLBusinessException(NotificationsServiceConstans.NOTF_8020, env.getProperty(NotificationsServiceConstans.NOTF_8020));
		}else{
			notificationsRequest.setLink(link);
		}
	}

	private String getAppEndpointLink(NotificationsRequest notificationsRequest) {
		return notificationsServiceDao.retrieveDeviceAppRegistrationAppLink(
				notificationsRequest.getTemplateDataMap().get("userkey").toString(),
				notificationsRequest.getTemplateDataMap().get("apptype").toString());
	}

}
