package com.bajaj.bfsd.notificationsservice.bean;

import java.util.List;

public class NotificationsBulkRequest {

	private List<NotificationsRequest> notificationsRequest;

	public List<NotificationsRequest> getNotificationsRequest() {
		return notificationsRequest;
	}

	public void setNotificationsRequest(List<NotificationsRequest> notificationsRequest) {
		this.notificationsRequest = notificationsRequest;
	}
	
	
}
