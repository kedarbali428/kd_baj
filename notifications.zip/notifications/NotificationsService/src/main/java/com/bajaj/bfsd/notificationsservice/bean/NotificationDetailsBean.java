package com.bajaj.bfsd.notificationsservice.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class NotificationDetailsBean {

	private long userNoteId;//USERNOTFKEY
	private BigDecimal readsts;
	private BigDecimal responsests;
	private Timestamp readdt;
	private String senddt;
	private Timestamp responsedt;
	private BigDecimal sendsts;
	private BigDecimal sendattemptcount;
	private Timestamp expirydate;
	private String messagecontent;
	private String msgstorerefnum;
	private BigDecimal docattachmentflg;
	private String messagetitle;
	private String readdate;
	private String responsedate;
	private String expirydates;
	
	
	public String getReaddate() {
		return readdate;
	}
	public void setReaddate(String readdate) {
		this.readdate = readdate;
	}
	public String getResponsedate() {
		return responsedate;
	}
	public void setResponsedate(String responsedate) {
		this.responsedate = responsedate;
	}
	
	public String getExpirydates() {
		return expirydates;
	}
	public void setExpirydates(String expirydates) {
		this.expirydates = expirydates;
	}
	public long getUserNoteId() {
		return userNoteId;
	}
	public void setUserNoteId(long userNoteId) {
		this.userNoteId = userNoteId;
	}
	
	public String getSenddt() {
		return senddt;
	}
	public void setSenddt(String senddt) {
		this.senddt = senddt;
	}
	public BigDecimal getReadsts() {
		return readsts;
	}
	public void setReadsts(BigDecimal readsts) {
		this.readsts = readsts;
	}
	public BigDecimal getResponsests() {
		return responsests;
	}
	public void setResponsests(BigDecimal responsests) {
		this.responsests = responsests;
	}
	public Timestamp getReaddt() {
		return readdt;
	}
	public void setReaddt(Timestamp readdt) {
		this.readdt = readdt;
	}
	public Timestamp getResponsedt() {
		return responsedt;
	}
	public void setResponsedt(Timestamp responsedt) {
		this.responsedt = responsedt;
	}
	public BigDecimal getSendsts() {
		return sendsts;
	}
	public void setSendsts(BigDecimal sendsts) {
		this.sendsts = sendsts;
	}
	public BigDecimal getSendattemptcount() {
		return sendattemptcount;
	}
	public void setSendattemptcount(BigDecimal sendattemptcount) {
		this.sendattemptcount = sendattemptcount;
	}
	public Timestamp getExpirydate() {
		return expirydate;
	}
	public void setExpirydate(Timestamp expirydate) {
		this.expirydate = expirydate;
	}
	public String getMsgstorerefnum() {
		return msgstorerefnum;
	}
	public void setMsgstorerefnum(String msgstorerefnum) {
		this.msgstorerefnum = msgstorerefnum;
	}
	public BigDecimal getDocattachmentflg() {
		return docattachmentflg;
	}
	public void setDocattachmentflg(BigDecimal docattachmentflg) {
		this.docattachmentflg = docattachmentflg;
	}
	public String getMessagetitle() {
		return messagetitle;
	}
	public void setMessagetitle(String messagetitle) {
		this.messagetitle = messagetitle;
	}
	public String getMessagecontent() {
		return messagecontent;
	}
	public void setMessagecontent(String messagecontent) {
		this.messagecontent = messagecontent;
	}
	












	
}
