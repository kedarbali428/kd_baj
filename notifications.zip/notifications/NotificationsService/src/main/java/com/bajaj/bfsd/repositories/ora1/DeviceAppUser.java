package com.bajaj.bfsd.repositories.ora1;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the DEVICE_APP_USERS database table.
 * 
 */
@Entity
@Table(name="DEVICE_APP_USERS")
@NamedQuery(name="DeviceAppUser.findAll", query="SELECT d FROM DeviceAppUser d")
public class DeviceAppUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long deviceappuserkey;

	private Timestamp appuserregistrationdt;

	private BigDecimal appuserregistrationstatus;

	private Timestamp appuserreleasedt;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal userkey;

	//bi-directional many-to-one association to DeviceAppRegistrationDet
	@ManyToOne
	@JoinColumn(name="DEVICEAPPREGKEY")
	private DeviceAppRegistrationDet deviceAppRegistrationDet;

	public DeviceAppUser() {
		//Empty constructor needed by JPA
	}

	public long getDeviceappuserkey() {
		return this.deviceappuserkey;
	}

	public void setDeviceappuserkey(long deviceappuserkey) {
		this.deviceappuserkey = deviceappuserkey;
	}

	public Timestamp getAppuserregistrationdt() {
		return this.appuserregistrationdt;
	}

	public void setAppuserregistrationdt(Timestamp appuserregistrationdt) {
		this.appuserregistrationdt = appuserregistrationdt;
	}

	public BigDecimal getAppuserregistrationstatus() {
		return this.appuserregistrationstatus;
	}

	public void setAppuserregistrationstatus(BigDecimal appuserregistrationstatus) {
		this.appuserregistrationstatus = appuserregistrationstatus;
	}

	public Timestamp getAppuserreleasedt() {
		return this.appuserreleasedt;
	}

	public void setAppuserreleasedt(Timestamp appuserreleasedt) {
		this.appuserreleasedt = appuserreleasedt;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getUserkey() {
		return this.userkey;
	}

	public void setUserkey(BigDecimal userkey) {
		this.userkey = userkey;
	}

	public DeviceAppRegistrationDet getDeviceAppRegistrationDet() {
		return this.deviceAppRegistrationDet;
	}

	public void setDeviceAppRegistrationDet(DeviceAppRegistrationDet deviceAppRegistrationDet) {
		this.deviceAppRegistrationDet = deviceAppRegistrationDet;
	}

}