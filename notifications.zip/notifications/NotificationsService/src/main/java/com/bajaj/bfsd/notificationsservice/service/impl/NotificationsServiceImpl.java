package com.bajaj.bfsd.notificationsservice.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.notificationsservice.bean.NotificationBulkResponse;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsBulkRequest;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsCount;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsDetails;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;
import com.bajaj.bfsd.notificationsservice.dao.NotificationsServiceDao;
import com.bajaj.bfsd.repositories.pg.NotificationType;
import com.bajaj.bfsd.notificationsservice.service.NotificationsService;
import com.bajaj.bfsd.notificationsservice.util.NotificationsMapper;
import com.bajaj.bfsd.notificationsservice.util.NotificationsServiceConstans;
import com.bfl.common.exceptions.BFLBusinessException;

/**
 * The Class NotificationsViewServiceImpl.
 */
@Component
public class NotificationsServiceImpl extends BFLComponent implements NotificationsService {

	/** The Constant CLASS_NAME. */
	private static final String CLASS_NAME = NotificationsServiceImpl.class.getName();

	/** The notificationsviewservice dao. */
	@Autowired
	NotificationsServiceDao notificationsServiceDao;
	
	@Autowired
	Environment env;

	@Autowired
	NotificationsMapper notificationsMapper;

	@Autowired
	BFLLoggerUtilExt logger;

	@Override
	public NotificationsDetails fetchNotificationDetails(String custId, int pageNo, int pageSize) {
		NotificationsDetails notificationsDetails = notificationsServiceDao.fetchDetails(custId, pageNo, pageSize);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchNotificationDetails");
		return notificationsDetails;
	}

	@Override
	public NotificationsCount fetchNotificationCount(String custId) {
		NotificationsCount notificationsCount = notificationsServiceDao.fetchNoOfCount(custId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchNotificationCount");
		return notificationsCount;
	}

	@Override
	@Transactional
	public String updateNotificationStatus(String custId, String notifID) {
		String status = notificationsServiceDao.updateStatus(custId, notifID);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchNotificationCount");
		return status;
	}

	@Override
	public ResponseBean sendNotificationRequest(NotificationsRequest notificationsRequest) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendNotificationRequest - call Started");
		ResponseBean notificationsResponse;
		if (null != notificationsRequest && null != notificationsRequest.getNotificationTypeCode()) {
			NotificationType notificationType = notificationsServiceDao
					.getNotificationTypeKey(notificationsRequest.getNotificationTypeCode());
			if(null == notificationsRequest.getTemplateDataMap() && notificationsRequest.getTemplateDataMap().isEmpty()){
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "TemplateDataMap is empty or null");
				throw new BFLBusinessException("NOTF_8024", env.getProperty(NotificationsServiceConstans.NOTF_8024));
			}
			notificationsResponse = notificationsMapper.notificationSend(notificationType, notificationsRequest);
		}else{
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Notification Type Code not found");
			throw new BFLBusinessException("NOTF_8023", env.getProperty(NotificationsServiceConstans.NOTF_8023));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendNotificationRequest - call Completed");
		return notificationsResponse;

	}

	@Override
	public NotificationBulkResponse sendNotificationBulkRequest(NotificationsBulkRequest notificationsBulkRequest) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendNotificationBulkRequest - call Started");
		NotificationBulkResponse notificationBulkResponse = new NotificationBulkResponse();
		List<ResponseBean> notificationsResponseList = new ArrayList<>();
		ResponseBean notificationsResponse;
		if (null != notificationsBulkRequest.getNotificationsRequest()
				&& !notificationsBulkRequest.getNotificationsRequest().isEmpty()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,"Size of Bulk request: " +  notificationsBulkRequest.getNotificationsRequest().size());
			for (NotificationsRequest notificationsRequest : notificationsBulkRequest.getNotificationsRequest()) {
				try {
						notificationsResponse = sendNotificationRequest(notificationsRequest);
						notificationsResponseList.add(notificationsResponse);
					} catch (Exception e) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Getting Exception While Sending BulkMessgae " + e);
					throw new BFLBusinessException("NOTF_8007", e.getMessage());
				}
			}
		}
		notificationBulkResponse.setBulkResponse(notificationsResponseList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendNotificationBulkRequest - call Completed");
		return notificationBulkResponse;
	}

	@Override
	public String bounceNotification(List<String> bouncedRecepients, String correlationId, int bounceType) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"bounceNotification - call Started bouncedRecipients:" + bouncedRecepients.toString());
		notificationsServiceDao.updateBounceDetails(bouncedRecepients, correlationId, bounceType);
		return null;
	}

}
