package com.bajaj.bfsd.notificationsservice.bean;

import java.util.Map;

public class NotificationsRequest{

	private String notificationTypeCode;

	private Map<String, Object> templateDataMap;
	
	private String channelCode; //Added for Scheduled notification
	
	private String notificationGroupCode;	//Added for Scheduled notification
	
	private String templateName;
	
	private Long userKey;
	
	private Long notificationTypeKey;
	
	private String link;
	
	private Long applicationkey;

	public String getNotificationTypeCode() {
		return notificationTypeCode;
	}

	public void setNotificationTypeCode(String notificationTypeCode) {
		this.notificationTypeCode = notificationTypeCode;
	}

	public Map<String, Object> getTemplateDataMap() {
		return templateDataMap;
	}

	public void setTemplateDataMap(Map<String, Object> templateDataMap) {
		this.templateDataMap = templateDataMap;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getNotificationGroupCode() {
		return notificationGroupCode;
	}

	public void setNotificationGroupCode(String notificationGroupCode) {
		this.notificationGroupCode = notificationGroupCode;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Long getUserKey() {
		return userKey;
	}

	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}

	public Long getNotificationTypeKey() {
		return notificationTypeKey;
	}

	public void setNotificationTypeKey(Long notificationTypeKey) {
		this.notificationTypeKey = notificationTypeKey;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * @return the applicationkey
	 */
	public Long getApplicationkey() {
		return applicationkey;
	}

	/**
	 * @param applicationkey the applicationkey to set
	 */
	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "NotificationsRequest [notificationTypeCode=" + notificationTypeCode + ", templateDataMap="
				+ templateDataMap + ", channelCode=" + channelCode + ", notificationGroupCode=" + notificationGroupCode
				+ ", templateName=" + templateName + ", userKey=" + userKey + ", notificationTypeKey="
				+ notificationTypeKey + ", link=" + link + ", applicationkey=" + applicationkey + "]";
	}
	
}
