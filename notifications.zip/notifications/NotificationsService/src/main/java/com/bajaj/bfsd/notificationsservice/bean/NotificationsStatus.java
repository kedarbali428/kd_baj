package com.bajaj.bfsd.notificationsservice.bean;

public class NotificationsStatus {
	
	private String  statusUpdated;

	public String getStatusUpdated() {
		return statusUpdated;
	}

	public void setStatusUpdated(String statusUpdated) {
		this.statusUpdated = statusUpdated;
	}

	

	

	
}
