/*
 * 
 */
package com.bajaj.bfsd.notificationsservice.service;

import java.util.List;

import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.notificationsservice.bean.NotificationBulkResponse;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsBulkRequest;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsCount;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsDetails;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;

/**
 * The Interface NotificationsViewService.
 */
public interface NotificationsService {

	/**
	 * Fetch notification details.
	 * 
	 * @param custId
	 *            the cust id
	 * @return the notifications details
	 */
	public NotificationsDetails fetchNotificationDetails(String custId,int pageNo,int pageSize);

	/**
	 * Fetch notification count.
	 * 
	 * @param custIdthe
	 *            cust id
	 * @return the notifications details
	 */
	public NotificationsCount fetchNotificationCount(String custId);

	public String updateNotificationStatus(String custId, String notifID);
	
	public ResponseBean sendNotificationRequest(NotificationsRequest notificationsRequest);
	
	public NotificationBulkResponse sendNotificationBulkRequest(NotificationsBulkRequest notificationsBulkRequest);
	
	public String bounceNotification(List<String> bouncedRecepients, String correlationId, int bounceType);

}
