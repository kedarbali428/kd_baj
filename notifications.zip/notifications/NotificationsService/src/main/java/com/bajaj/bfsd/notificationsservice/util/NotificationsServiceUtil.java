package com.bajaj.bfsd.notificationsservice.util;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NotificationsServiceUtil {
	
	/**
     * Variable to hold value for corelation id.
     */
    private static String corelationId;
    /**
     * Instantiates a new authentication service util.
     */
    private NotificationsServiceUtil(){
        
    } 

    /**
     * Getter method for corelation id.
     *
     * @return corelation id
     */
    public static String getCorelationId() {
        return corelationId;
    }

    /**
     * Sets the value of corelation id.
     *
     * @param corelationId the new corelation id
     */
    public static void setCorelationId(String corelationId) {
    	NotificationsServiceUtil.corelationId = corelationId;
    }
	
    public static String getStampDateWithInString(Date date){
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		return formatter.format(date);
	}
}
