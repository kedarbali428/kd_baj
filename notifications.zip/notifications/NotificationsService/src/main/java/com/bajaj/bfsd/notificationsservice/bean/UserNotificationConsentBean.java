package com.bajaj.bfsd.notificationsservice.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * The persistent class for the "USER_NOTIFICATION_CONSENT" database table.
 * 
 */

public class UserNotificationConsentBean {
	private long usernotifconsentkey;

	private BigDecimal cnsentflg;

	private String consentChannel;

	private String consentIp;

	private String consentProviderType;

	private String consentUrl;

	private Timestamp consentdt;

	private String consentsource;

	private String consentsourceid;

	private String deviceId;

	private String email;

	private Timestamp lsupdatedt;

	private String mobileno;

	private Timestamp revokedt;

	private BigDecimal userkey;

	public UserNotificationConsentBean() {
		//Empty constructor
	}
	
	public long getUsernotifconsentkey() {
		return usernotifconsentkey;
	}

	public void setUsernotifconsentkey(long usernotifconsentkey) {
		this.usernotifconsentkey = usernotifconsentkey;
	}

	public BigDecimal getCnsentflg() {
		return this.cnsentflg;
	}

	public void setCnsentflg(BigDecimal cnsentflg) {
		this.cnsentflg = cnsentflg;
	}

	public String getConsentChannel() {
		return this.consentChannel;
	}

	public void setConsentChannel(String consentChannel) {
		this.consentChannel = consentChannel;
	}

	public String getConsentIp() {
		return this.consentIp;
	}

	public void setConsentIp(String consentIp) {
		this.consentIp = consentIp;
	}

	public String getConsentProviderType() {
		return this.consentProviderType;
	}

	public void setConsentProviderType(String consentProviderType) {
		this.consentProviderType = consentProviderType;
	}

	public String getConsentUrl() {
		return this.consentUrl;
	}

	public void setConsentUrl(String consentUrl) {
		this.consentUrl = consentUrl;
	}

	public Timestamp getConsentdt() {
		return this.consentdt;
	}

	public void setConsentdt(Timestamp consentdt) {
		this.consentdt = consentdt;
	}

	public String getConsentsource() {
		return this.consentsource;
	}

	public void setConsentsource(String consentsource) {
		this.consentsource = consentsource;
	}

	public String getConsentsourceid() {
		return this.consentsourceid;
	}

	public void setConsentsourceid(String consentsourceid) {
		this.consentsourceid = consentsourceid;
	}

	public String getDeviceId() {
		return this.deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Timestamp getLsupdatedt() {
		return this.lsupdatedt;
	}

	public void setLsupdatedt(Timestamp lsupdatedt) {
		this.lsupdatedt = lsupdatedt;
	}

	public String getMobileno() {
		return this.mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public Timestamp getRevokedt() {
		return this.revokedt;
	}

	public void setRevokedt(Timestamp revokedt) {
		this.revokedt = revokedt;
	}

	public BigDecimal getUserkey() {
		return this.userkey;
	}

	public void setUserkey(BigDecimal userkey) {
		this.userkey = userkey;
	}

}