package com.bajaj.bfsd.notificationsservice.messaging;

import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.amazon.sqs.javamessaging.SQSConnection;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;
import com.bajaj.bfsd.notificationsservice.util.NotificationsServiceConstans;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RefreshScope
@Component
public class NotificationsQueue {

	@Autowired
	SQSConnection sqsConnection;

	@Autowired
	Environment env;

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	AwsClientWrapper messageQueueWrapper;

	private static final String CLASS = NotificationsQueue.class.getName();

	public void sendMessageToQueue(NotificationsRequest notificationsRequest, String msgQueue){	
		logger.debug(CLASS, BFLLoggerComponent.UTILITY, "inside sendMessageToQueue - call Started");
		try{
			MessageProducer producer = messageQueueWrapper.getProducer(msgQueue);
			ObjectMapper mapper = new ObjectMapper();
			String reqJson = mapper.writeValueAsString(notificationsRequest);
			TextMessage msg = messageQueueWrapper.getSession().createTextMessage(reqJson);
			logger.debug(CLASS, BFLLoggerComponent.UTILITY, "inside sendMessageToQueue - call Completed");
			producer.send(msg);

		}catch (JsonProcessingException e) {
			logger.error(CLASS, BFLLoggerComponent.UTILITY, "sendMessageToQueue:- Json Parsing or Mapping Failed" + e);
			throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8012, env.getProperty(NotificationsServiceConstans.NOTF_8012));
		}catch (JMSException e) {
			logger.error(CLASS, BFLLoggerComponent.UTILITY,
					"sendMessageToQueue:Getting JMSException While Sending Messgae to SMS_QUEUE" +e);
			throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8009, env.getProperty(NotificationsServiceConstans.NOTF_8009));
		}catch(Exception e){
			logger.error(CLASS, BFLLoggerComponent.UTILITY, "sendMessageToQueue:- Could be size limit exceeds issue while sending message to Queue" +e);
			throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8014, env.getProperty(NotificationsServiceConstans.NOTF_8014));
		}
	}
}