package com.bajaj.bfsd.notificationsservice.dao;

import java.util.List;

import com.bajaj.bfsd.notificationsservice.bean.NotificationsCount;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsDetails;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;
import com.bajaj.bfsd.repositories.pg.NotfChannelSubscription;
import com.bajaj.bfsd.repositories.pg.NotificationType;


/**
 * The Interface NotificationsViewServiceDao.
 */
public interface NotificationsServiceDao {

	/**
	 * Fetch details.
	 *
	 * @param custId
	 *            the cust id
	 * @return the notifications details
	 */
	public NotificationsDetails fetchDetails(String custId,int pageNo,int pageSize);

	/**
	 * Fetch no of count.
	 *
	 * @param custId
	 *            the cust id
	 * @return the integer
	 */
	public NotificationsCount fetchNoOfCount(String custId);

	/**
	 * Status updated.
	 *
	 * @param custId
	 *            the cust id
	 * @param notifID
	 *            the notif ID
	 * @return the string
	 */
	public String updateStatus(String custId, String notifID);

	/**
	 * Gets the notification type key.
	 *
	 * @param notificationTypeCode
	 *            the notification type code
	 * @return the notification type key
	 */
	public NotificationType getNotificationTypeKey(String notificationTypeCode);

	/**
	 * Save user notification.
	 *
	 * @param userNotification
	 *            the user notification
	 * @return the string
	 */

	public void updateBounceDetails(List<String> bouncedRecepients, String correlationId, int bounceType);

	public String retrieveDeviceAppRegistrationAppLink(String userkey, String apptype);
	
	public NotfChannelSubscription getNotfChanelSubscriptionByChannelCode(
			NotificationsRequest notificationsRequest, String notificationTypeCode);

}