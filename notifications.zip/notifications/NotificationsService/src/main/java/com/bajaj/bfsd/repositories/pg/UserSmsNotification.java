package com.bajaj.bfsd.repositories.pg;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the "USER_SMS_NOTIFICATIONS" database table.
 * 
 */
@Entity
@Table(name="\"USER_SMS_NOTIFICATIONS\"" ,schema="\"ORGSYSNOTF\"")
@NamedQuery(name="UserSmsNotification.findAll", query="SELECT u FROM UserSmsNotification u")
public class UserSmsNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"USERSMSNOTFKEY\"")
	@SequenceGenerator(name="USER_SMS_NOTIFICATIONS_GENERATOR", sequenceName="\"ORGSYSNOTF\".\"USER_SMS_NOTIFICATIONS_PK_SEQ\"",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_SMS_NOTIFICATIONS_GENERATOR")

	private long usersmsnotfkey;

	@Column(name="\"EXPIRYDATE\"")
	private Timestamp expirydate;

	@Column(name="\"MESSAGE\"")
	private String message;

	@Column(name="\"MOBILENO\"")
	private String mobileno;

	@Column(name="\"SENDATTEMPTCOUNT\"")
	private BigDecimal sendattemptcount;

	@Column(name="\"SENDDT\"")
	private Timestamp senddt;

	@Column(name="\"SENDSTS\"")
	private BigDecimal sendsts;

	@ManyToOne
	@JoinColumn(name="\"USERNOTFKEY\"")
	private UserNotification userNotification;


	public UserSmsNotification() {
	}

	public long getUsersmsnotfkey() {
		return this.usersmsnotfkey;
	}

	public void setUsersmsnotfkey(long usersmsnotfkey) {
		this.usersmsnotfkey = usersmsnotfkey;
	}

	public Timestamp getExpirydate() {
		return this.expirydate;
	}

	public void setExpirydate(Timestamp expirydate) {
		this.expirydate = expirydate;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMobileno() {
		return this.mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public BigDecimal getSendattemptcount() {
		return this.sendattemptcount;
	}

	public void setSendattemptcount(BigDecimal sendattemptcount) {
		this.sendattemptcount = sendattemptcount;
	}

	public Timestamp getSenddt() {
		return this.senddt;
	}

	public void setSenddt(Timestamp senddt) {
		this.senddt = senddt;
	}

	public BigDecimal getSendsts() {
		return this.sendsts;
	}

	public void setSendsts(BigDecimal sendsts) {
		this.sendsts = sendsts;
	}

	public UserNotification getUserNotification() {
		return userNotification;
	}

	public void setUserNotification(UserNotification userNotification) {
		this.userNotification = userNotification;
	}
}