package com.bajaj.bfsd.repositories.ora1;


import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the DEVICE_MOBILE_NUMBERS database table.
 * 
 */
@Entity
@Table(name="DEVICE_MOBILE_NUMBERS")
@NamedQuery(name="DeviceMobileNumber.findAll", query="SELECT d FROM DeviceMobileNumber d")
public class DeviceMobileNumber implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long devicemobnumkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String mobilenum;

	private String mobileoperator;

	//bi-directional many-to-one association to DeviceRegistrationDet
	@ManyToOne
	@JoinColumn(name="DEVICEREGKEY")
	private DeviceRegistrationDet deviceRegistrationDet;

	public DeviceMobileNumber() {
		//Empty constructor needed by JPA
	}

	public long getDevicemobnumkey() {
		return this.devicemobnumkey;
	}

	public void setDevicemobnumkey(long devicemobnumkey) {
		this.devicemobnumkey = devicemobnumkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getMobilenum() {
		return this.mobilenum;
	}

	public void setMobilenum(String mobilenum) {
		this.mobilenum = mobilenum;
	}

	public String getMobileoperator() {
		return this.mobileoperator;
	}

	public void setMobileoperator(String mobileoperator) {
		this.mobileoperator = mobileoperator;
	}

	public DeviceRegistrationDet getDeviceRegistrationDet() {
		return this.deviceRegistrationDet;
	}

	public void setDeviceRegistrationDet(DeviceRegistrationDet deviceRegistrationDet) {
		this.deviceRegistrationDet = deviceRegistrationDet;
	}

}