package com.bajaj.bfsd.notificationservice.helper;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;

import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.util.MapperFactory;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.notificationsservice.bean.UserNotificationConsentBean;
import com.bajaj.bfsd.notificationsservice.util.NotificationsServiceConstans;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RefreshScope
@Component
public class ConsentNotificatonIntegrationHelper extends BFLComponent {

	private static final String CLASS_NAME = ConsentNotificatonIntegrationHelper.class.getCanonicalName();

	@Autowired
	BFLLoggerUtil logger;

	@Value("${proxy.address}")
	private String proxyAddress;

	@Value("${proxy.port}")
	private String port;

	@Value("${proxy.required}")
	private String proxyRequired;

	@Value("${api.consentnotification.getconsent.POST.url}")
	private String consentUrl;

	@Autowired
	Environment env;

	public Boolean getConsentAPIResult(String mobileNum) {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside getConsentAPIResult method - Start");
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "ConsentAPIResult Payload received : " + mobileNum);
		Boolean response = false;
		ResponseEntity<ResponseBean> whatsAppServcieResponseBean;
		try {
			if (("Y").equalsIgnoreCase(env.getProperty("mockFlag"))) {
				// TO DO : Add Mock Response
			}
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(new MediaType[] { MediaType.APPLICATION_JSON }));
			headers.setContentType(MediaType.APPLICATION_JSON);
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Consent service Request Payload:" + mobileNum);
			String reqMobileJson = prepareRequestJsonForAPICall(mobileNum);
			whatsAppServcieResponseBean = BFLCommonRestClient.create(consentUrl, null, String.class, null,
					reqMobileJson, headers);
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"getConsentAPIResult Response Payload:" + whatsAppServcieResponseBean.toString());
			if (null != whatsAppServcieResponseBean.getBody() && null != whatsAppServcieResponseBean.getBody().getPayload()) {
				String responseJson = whatsAppServcieResponseBean.getBody().getPayload().toString();
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Inside processAPICall() Call for URL-->"
						+ consentUrl + " completed. Response-->" + responseJson);

				JSONObject json = getJsonObject(whatsAppServcieResponseBean.getBody().getPayload())
						.containsKey(NotificationsServiceConstans.PAYLOAD)
								? isValidJSON((new org.json.JSONObject(
										(whatsAppServcieResponseBean.getBody()).getPayload().toString()))
												.get(
														NotificationsServiceConstans.PAYLOAD)
												.toString())
														? getJsonObject((new org.json.JSONObject(
																(whatsAppServcieResponseBean.getBody()).getPayload()
																		.toString()))
																				.get(NotificationsServiceConstans.PAYLOAD)
																				.toString())
														: getJsonObject(
																whatsAppServcieResponseBean.getBody().getPayload())
								: getJsonObject(whatsAppServcieResponseBean.getBody().getPayload());
				UserNotificationConsentBean userNotificationConsentBean = prepareResponseObjectForAPIResponse(
						json.toString());
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "parsed response userNotificationConsentBean-->"
						+ consentUrl + " completed.-->" + userNotificationConsentBean);

				if (null != userNotificationConsentBean && null != userNotificationConsentBean.getCnsentflg()) {
					if (userNotificationConsentBean.getCnsentflg().equals(new BigDecimal(1))) {
						response = true;
					} else {
						response = false;
					}
				} else {
					response = false;
				}
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Inside getConsentAPIResult error occured while converting to String from object", e);
			response = false;
		}
		return response;
	}

	@SuppressWarnings("unchecked")
	public String prepareRequestJsonForAPICall(Object requestObject) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "In prepareRequestJsonForAPICall()");
		JSONObject whatsAppJsonReq = new JSONObject();
		whatsAppJsonReq.put(NotificationsServiceConstans.MOBILENO, requestObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Exit from prepareRequestJsonForAPICall()");
		return whatsAppJsonReq.toString();
	}

	public UserNotificationConsentBean prepareResponseObjectForAPIResponse(String responseJson) {

		Object responseObject = null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Inside prepareResponseObjectForAPIResponse()");

		if (responseJson != null && !responseJson.isEmpty()) {
			try {
				ObjectMapper mapper = MapperFactory.getInstance();
				responseObject = mapper.readValue(responseJson, UserNotificationConsentBean.class);
			} catch (JsonParseException jpe) {
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
						"JsonParseException occurred while parsing API response", jpe);
				throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8031,
						env.getProperty(NotificationsServiceConstans.NOTF_8031));
			} catch (JsonMappingException jme) {
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
						"JsonMappingException occurred while parsing API response", jme);
				throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8031,
						env.getProperty(NotificationsServiceConstans.NOTF_8031));
			} catch (IOException ioe) {
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "IOException occurred while parsing API response",
						ioe);
				throw new BFLTechnicalException(NotificationsServiceConstans.NOTF_8031,
						env.getProperty(NotificationsServiceConstans.NOTF_8031));
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Exit from prepareResponseObjectForAPIResponse() ");
		return (UserNotificationConsentBean) responseObject;
	}

	private JSONObject getJsonObject(Object object) {
		JSONObject jsonObject = new JSONObject();
		try {
			JSONParser parser = new JSONParser();
			if (object instanceof JSONObject) {
				jsonObject = (JSONObject) object;
			} else {
				Object obj = parser.parse(object.toString());
				jsonObject = (JSONObject) obj;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Error occured while parsing in getJsonObject:" + e.getMessage(), e);
		}
		return jsonObject;
	}

	private boolean isValidJSON(String jsonString) {
		try {
			new org.json.JSONObject(jsonString);
		} catch (JSONException ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Error occured while parsing in isValidJSON :" + ex.getMessage(), ex);
		}
		return true;
	}
}
