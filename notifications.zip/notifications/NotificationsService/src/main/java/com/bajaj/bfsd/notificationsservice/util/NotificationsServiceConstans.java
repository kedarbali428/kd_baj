/*
 * 
 */
package com.bajaj.bfsd.notificationsservice.util;

import java.math.BigDecimal;

/**
 * The Class OrchestrationServiceConstans.
 */
public class NotificationsServiceConstans {

	

	/** The Constant for errors */
	public static final String NOTF_8001 = "NOTF-8001";
	public static final String NOTF_8002 = "NOTF_8002";
	public static final String NOTF_8003 = "NOTF_8003";
	public static final String NOTF_8004 = "NOTF_8004";
	public static final String NOTF_8005 = "NOTF_8005";
	public static final String NOTF_8006 = "NOTF_8006";
	public static final String NOTF_8007 = "NOTF_8007";
	public static final String NOTF_8008 = "NOTF_8008";
	public static final String NOTF_8009 = "NOTF_8009";
	public static final String NOTF_8010 = "NOTF_8010";
	public static final String NOTF_8011 = "NOTF_8011";
	public static final String NOTF_8012 = "NOTF_8012";
	public static final String NOTF_8013 = "NOTF_8013";
	public static final String NOTF_8014 = "NOTF_8014";
	public static final String NOTF_8015 = "NOTF_8015";
	public static final String NOTF_8016 = "NOTF_8016";
	public static final String NOTF_8017 = "NOTF_8017";
	public static final String NOTF_8018 = "NOTF_8018";
	public static final String NOTF_8019 = "NOTF_8019";
	public static final String NOTF_8020 = "NOTF_8020";
	public static final String NOTF_8021 = "NOTF_8021";
	public static final String NOTF_8022 = "NOTF_8022";
	public static final String NOTF_8023 = "NOTF_8023";
	public static final String NOTF_8024 = "NOTF_8024";
	public static final String NOTF_8025 = "NOTF_8025";
	public static final String NOTF_8026 = "NOTF_8026";
	public static final String NOTF_8027 = "NOTF_8027";
	public static final String NOTF_8028 = "NOTF_8028";
	public static final String NOTF_8029 = "NOTF_8029";
	public static final String NOTF_8030 = "NOTF_8030";
	public static final String NOTF_8031 = "NOTF_8031";
	
	public static final String NOTIFY_SMS = "notifySms";

	public static final String NOTIFY_EMAIL = "notifyEmail";

	public static final BigDecimal ACTIVE_FLAG = new BigDecimal(1);
	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_FAIL = "FAIL";

	public static final BigDecimal READ_STATUS = new BigDecimal(1);
	
	public static final String SMS_CHANNEL = "SMS";
	public static final String EMAIL_CHANNEL = "EMAIL";
	public static final String APP_CHANNEL = "APP";
	public static final String WEB_CHANNEL = "WEB";
	public static final String WHATSAPP_CHANNEL = "WHATSAPP";
	public static final String OTP_TYPE_CODE = "SMSOTP";
	public static final String PHONENUMBER= "phoneNumber";
	public static final String MAILID= "recipientEmailId";
	public static final String USERKEY = "userkey";
	public static final String APPTYPE = "apptype";
	public static final String PAYLOAD = "payload";
	public static final String MOBILENO = "mobileno";
	
	private NotificationsServiceConstans() {
		//

	}

}
