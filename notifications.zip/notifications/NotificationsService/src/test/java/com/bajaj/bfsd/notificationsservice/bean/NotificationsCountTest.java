package com.bajaj.bfsd.notificationsservice.bean;

import org.junit.Test;


public class NotificationsCountTest {

	private NotificationsCount createTestSubject() {
		return new NotificationsCount();
	}

	//@MethodRef(name = "getReadCount", signature = "()QInteger;")
	@Test
	public void testGetReadCount() throws Exception {
		NotificationsCount testSubject;
		Integer result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getReadCount();
	}

	//@MethodRef(name = "setReadCount", signature = "(QInteger;)V")
	@Test
	public void testSetReadCount() throws Exception {
		NotificationsCount testSubject;
		Integer readCount = 0;

		// default test
		testSubject = createTestSubject();
		testSubject.setReadCount(readCount);
	}

	//@MethodRef(name = "getUnreadCount", signature = "()QInteger;")
	@Test
	public void testGetUnreadCount() throws Exception {
		NotificationsCount testSubject;
		Integer result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUnreadCount();
	}

	//@MethodRef(name = "setUnreadCount", signature = "(QInteger;)V")
	@Test
	public void testSetUnreadCount() throws Exception {
		NotificationsCount testSubject;
		Integer unreadCount = 0;

		// default test
		testSubject = createTestSubject();
		testSubject.setUnreadCount(unreadCount);
	}

	//@MethodRef(name = "getNoOfCount", signature = "()QInteger;")
	@Test
	public void testGetNoOfCount() throws Exception {
		NotificationsCount testSubject;
		Integer result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNoOfCount();
	}

	//@MethodRef(name = "setNoOfCount", signature = "(QInteger;)V")
	@Test
	public void testSetNoOfCount() throws Exception {
		NotificationsCount testSubject;
		Integer noOfCount = 0;

		// default test
		testSubject = createTestSubject();
		testSubject.setNoOfCount(noOfCount);
	}
}