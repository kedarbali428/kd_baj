package com.bajaj.bfsd.notificationsservice.bean;

import java.util.List;

import org.junit.Test;


public class NotificationsBulkRequestTest {

	private NotificationsBulkRequest createTestSubject() {
		return new NotificationsBulkRequest();
	}

	//@MethodRef(name = "getNotificationsRequest", signature = "()QList<QNotificationsRequest;>;")
	@Test
	public void testGetNotificationsRequest() throws Exception {
		NotificationsBulkRequest testSubject;
		List<NotificationsRequest> result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotificationsRequest();
	}

	//@MethodRef(name = "setNotificationsRequest", signature = "(QList<QNotificationsRequest;>;)V")
	@Test
	public void testSetNotificationsRequest() throws Exception {
		NotificationsBulkRequest testSubject;
		List<NotificationsRequest> notificationsRequest = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setNotificationsRequest(notificationsRequest);
	}
}