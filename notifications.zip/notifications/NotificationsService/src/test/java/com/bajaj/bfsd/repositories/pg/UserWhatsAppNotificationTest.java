package com.bajaj.bfsd.repositories.pg;
/*package com.bajaj.bfsd.notificationsservice.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.junit.Test;


public class UserWhatsAppNotificationTest {

	private UserWhatsAppNotification createTestSubject() {
		return new UserWhatsAppNotification();
	}

	//@MethodRef(name = "getUserwhatsappnotfkey", signature = "()J")
	@Test
	public void testGetUserwhatsappnotfkey() throws Exception {
		UserWhatsAppNotification testSubject;
		long result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserwhatsappnotfkey();
	}

	//@MethodRef(name = "setUserwhatsappnotfkey", signature = "(J)V")
	@Test
	public void testSetUserwhatsappnotfkey() throws Exception {
		UserWhatsAppNotification testSubject;
		long userwhatsappnotfkey = 879789;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserwhatsappnotfkey(userwhatsappnotfkey);
	}

	//@MethodRef(name = "getExpirydate", signature = "()QTimestamp;")
	@Test
	public void testGetExpirydate() throws Exception {
		UserWhatsAppNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getExpirydate();
	}

	//@MethodRef(name = "setExpirydate", signature = "(QTimestamp;)V")
	@Test
	public void testSetExpirydate() throws Exception {
		UserWhatsAppNotification testSubject;
		Timestamp expirydate = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setExpirydate(expirydate);
	}

	//@MethodRef(name = "getMessage", signature = "()QString;")
	@Test
	public void testGetMessage() throws Exception {
		UserWhatsAppNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMessage();
	}

	//@MethodRef(name = "setMessage", signature = "(QString;)V")
	@Test
	public void testSetMessage() throws Exception {
		UserWhatsAppNotification testSubject;
		String message = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMessage(message);
	}

	//@MethodRef(name = "getMobileno", signature = "()QString;")
	@Test
	public void testGetMobileno() throws Exception {
		UserWhatsAppNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMobileno();
	}

	//@MethodRef(name = "setMobileno", signature = "(QString;)V")
	@Test
	public void testSetMobileno() throws Exception {
		UserWhatsAppNotification testSubject;
		String mobileno = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMobileno(mobileno);
	}

	//@MethodRef(name = "getSendattemptcount", signature = "()QBigDecimal;")
	@Test
	public void testGetSendattemptcount() throws Exception {
		UserWhatsAppNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendattemptcount();
	}

	//@MethodRef(name = "setSendattemptcount", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendattemptcount() throws Exception {
		UserWhatsAppNotification testSubject;
		BigDecimal sendattemptcount = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendattemptcount(sendattemptcount);
	}

	//@MethodRef(name = "getSenddt", signature = "()QTimestamp;")
	@Test
	public void testGetSenddt() throws Exception {
		UserWhatsAppNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSenddt();
	}

	//@MethodRef(name = "setSenddt", signature = "(QTimestamp;)V")
	@Test
	public void testSetSenddt() throws Exception {
		UserWhatsAppNotification testSubject;
		Timestamp senddt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSenddt(senddt);
	}

	//@MethodRef(name = "getSendsts", signature = "()QBigDecimal;")
	@Test
	public void testGetSendsts() throws Exception {
		UserWhatsAppNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendsts();
	}

	//@MethodRef(name = "setSendsts", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendsts() throws Exception {
		UserWhatsAppNotification testSubject;
		BigDecimal sendsts = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendsts(sendsts);
	}

	//@MethodRef(name = "getUserNotification", signature = "()QUserNotification;")
	@Test
	public void testGetUserNotification() throws Exception {
		UserWhatsAppNotification testSubject;
		UserNotification result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserNotification();
	}

	//@MethodRef(name = "setUserNotification", signature = "(QUserNotification;)V")
	@Test
	public void testSetUserNotification() throws Exception {
		UserWhatsAppNotification testSubject;
		UserNotification userNotification = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserNotification(userNotification);
	}
}*/