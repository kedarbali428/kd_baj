package com.bajaj.bfsd.notificationsservice.bean;

import java.util.List;

import org.junit.Test;


public class NotificationsDetailsTest {

	private NotificationsDetails createTestSubject() {
		return new NotificationsDetails();
	}

	//@MethodRef(name = "getNotificationDetails", signature = "()QList<QNotificationDetailsBean;>;")
	@Test
	public void testGetNotificationDetails() throws Exception {
		NotificationsDetails testSubject;
		List<NotificationDetailsBean> result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotificationDetails();
	}

	//@MethodRef(name = "setNotificationDetails", signature = "(QList<QNotificationDetailsBean;>;)V")
	@Test
	public void testSetNotificationDetails() throws Exception {
		NotificationsDetails testSubject;
		List<NotificationDetailsBean> notificationDetails = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setNotificationDetails(notificationDetails);
	}
}