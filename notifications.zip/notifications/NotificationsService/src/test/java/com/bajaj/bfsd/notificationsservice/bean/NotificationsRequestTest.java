package com.bajaj.bfsd.notificationsservice.bean;

import java.util.Map;

import org.junit.Test;


public class NotificationsRequestTest {

	private NotificationsRequest createTestSubject() {
		return new NotificationsRequest();
	}

	//@MethodRef(name = "getNotificationTypeCode", signature = "()QString;")
	@Test
	public void testGetNotificationTypeCode() throws Exception {
		NotificationsRequest testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotificationTypeCode();
	}

	//@MethodRef(name = "setNotificationTypeCode", signature = "(QString;)V")
	@Test
	public void testSetNotificationTypeCode() throws Exception {
		NotificationsRequest testSubject;
		String notificationTypeCode = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setNotificationTypeCode(notificationTypeCode);
	}

	//@MethodRef(name = "getTemplateDataMap", signature = "()QMap<QString;QObject;>;")
	@Test
	public void testGetTemplateDataMap() throws Exception {
		NotificationsRequest testSubject;
		Map<String, Object> result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getTemplateDataMap();
	}

	//@MethodRef(name = "setTemplateDataMap", signature = "(QMap<QString;QObject;>;)V")
	@Test
	public void testSetTemplateDataMap() throws Exception {
		NotificationsRequest testSubject;
		Map<String, Object> templateDataMap = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setTemplateDataMap(templateDataMap);
	}

	//@MethodRef(name = "getChannelCode", signature = "()QString;")
	@Test
	public void testGetChannelCode() throws Exception {
		NotificationsRequest testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getChannelCode();
	}

	//@MethodRef(name = "setChannelCode", signature = "(QString;)V")
	@Test
	public void testSetChannelCode() throws Exception {
		NotificationsRequest testSubject;
		String channelCode = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setChannelCode(channelCode);
	}

	//@MethodRef(name = "getNotificationGroupCode", signature = "()QString;")
	@Test
	public void testGetNotificationGroupCode() throws Exception {
		NotificationsRequest testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotificationGroupCode();
	}

	//@MethodRef(name = "setNotificationGroupCode", signature = "(QString;)V")
	@Test
	public void testSetNotificationGroupCode() throws Exception {
		NotificationsRequest testSubject;
		String notificationGroupCode = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setNotificationGroupCode(notificationGroupCode);
	}
}