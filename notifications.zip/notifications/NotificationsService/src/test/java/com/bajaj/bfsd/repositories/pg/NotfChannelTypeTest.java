package com.bajaj.bfsd.repositories.pg;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Generated;

import org.junit.Test;

import com.bajaj.bfsd.repositories.pg.NotfChannelSubscription;
import com.bajaj.bfsd.repositories.pg.NotfChannelType;

@Generated(value = "org.junit-tools-1.1.0")
public class NotfChannelTypeTest {

	private NotfChannelType createTestSubject() {
		return new NotfChannelType();
	}

	//@MethodRef(name = "getNotfchanneltypekey", signature = "()J")
	@Test
	public void testGetNotfchanneltypekey() throws Exception {
		NotfChannelType testSubject;
		long result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotfchanneltypekey();
	}

	//@MethodRef(name = "setNotfchanneltypekey", signature = "(J)V")
	@Test
	public void testSetNotfchanneltypekey() throws Exception {
		NotfChannelType testSubject;
		long notfchanneltypekey = 41241;

		// default test
		testSubject = createTestSubject();
		testSubject.setNotfchanneltypekey(notfchanneltypekey);
	}

	//@MethodRef(name = "getChannelcode", signature = "()QString;")
	@Test
	public void testGetChannelcode() throws Exception {
		NotfChannelType testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getChannelcode();
	}

	//@MethodRef(name = "setChannelcode", signature = "(QString;)V")
	@Test
	public void testSetChannelcode() throws Exception {
		NotfChannelType testSubject;
		String channelcode = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setChannelcode(channelcode);
	}

	//@MethodRef(name = "getChanneldesc", signature = "()QString;")
	@Test
	public void testGetChanneldesc() throws Exception {
		NotfChannelType testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getChanneldesc();
	}

	//@MethodRef(name = "setChanneldesc", signature = "(QString;)V")
	@Test
	public void testSetChanneldesc() throws Exception {
		NotfChannelType testSubject;
		String channeldesc = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setChanneldesc(channeldesc);
	}

	//@MethodRef(name = "getIsactive", signature = "()QBigDecimal;")
	@Test
	public void testGetIsactive() throws Exception {
		NotfChannelType testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getIsactive();
	}

	//@MethodRef(name = "setIsactive", signature = "(QBigDecimal;)V")
	@Test
	public void testSetIsactive() throws Exception {
		NotfChannelType testSubject;
		BigDecimal isactive = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setIsactive(isactive);
	}

	//@MethodRef(name = "getLstupdateby", signature = "()QString;")
	@Test
	public void testGetLstupdateby() throws Exception {
		NotfChannelType testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getLstupdateby();
	}

	//@MethodRef(name = "setLstupdateby", signature = "(QString;)V")
	@Test
	public void testSetLstupdateby() throws Exception {
		NotfChannelType testSubject;
		String lstupdateby = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setLstupdateby(lstupdateby);
	}

	//@MethodRef(name = "getLstupdatedt", signature = "()QTimestamp;")
	@Test
	public void testGetLstupdatedt() throws Exception {
		NotfChannelType testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getLstupdatedt();
	}

	//@MethodRef(name = "setLstupdatedt", signature = "(QTimestamp;)V")
	@Test
	public void testSetLstupdatedt() throws Exception {
		NotfChannelType testSubject;
		Timestamp lstupdatedt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setLstupdatedt(lstupdatedt);
	}

	//@MethodRef(name = "getNotfChannelSubscriptions", signature = "()QList<QNotfChannelSubscription;>;")
	@Test
	public void testGetNotfChannelSubscriptions() throws Exception {
		NotfChannelType testSubject;
		List<NotfChannelSubscription> result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotfChannelSubscriptions();
	}

	//@MethodRef(name = "setNotfChannelSubscriptions", signature = "(QList<QNotfChannelSubscription;>;)V")
	@Test
	public void testSetNotfChannelSubscriptions() throws Exception {
		NotfChannelType testSubject;
		List<NotfChannelSubscription> notfChannelSubscriptions = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setNotfChannelSubscriptions(notfChannelSubscriptions);
	}

	

	//@MethodRef(name = "getUserNotfSubscriptions", signature = "()QList<QUserNotfSubscription;>;")
	/*@Test
	public void testGetUserNotfSubscriptions() throws Exception {
		NotfChannelType testSubject;
		List<UserNotfSubscription> result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserNotfSubscriptions();
	}

	//@MethodRef(name = "setUserNotfSubscriptions", signature = "(QList<QUserNotfSubscription;>;)V")
	@Test
	public void testSetUserNotfSubscriptions() throws Exception {
		NotfChannelType testSubject;
		List<UserNotfSubscription> userNotfSubscriptions = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserNotfSubscriptions(userNotfSubscriptions);
	}*/

	
}