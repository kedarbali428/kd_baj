package com.bajaj.bfsd.notificationsservice.bean;

import org.junit.Test;


public class NotificationsStatusTest {

	private NotificationsStatus createTestSubject() {
		return new NotificationsStatus();
	}

	//@MethodRef(name = "getStatusUpdated", signature = "()QString;")
	@Test
	public void testGetStatusUpdated() throws Exception {
		NotificationsStatus testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getStatusUpdated();
	}

	//@MethodRef(name = "setStatusUpdated", signature = "(QString;)V")
	@Test
	public void testSetStatusUpdated() throws Exception {
		NotificationsStatus testSubject;
		String statusUpdated = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setStatusUpdated(statusUpdated);
	}
}