package com.bajaj.bfsd.notificationsservice.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLExceptionHandler;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.notificationsservice.bean.NotificationBulkResponse;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsBulkRequest;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsCount;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsDetails;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;
import com.bajaj.bfsd.notificationsservice.service.NotificationsService;
import com.bajaj.bfsdnotificationService.factory.MapperFactory;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest(classes = { BFLCommonRestClient.class })
@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:error.properties" })
public class NotificationsServiceControllerTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;

	private MockMvc mockMvc;

	BFLExceptionHandler exceptionHandler;

	@Mock
	NotificationsService notificationsservice;

	@InjectMocks
	NotificationsServiceController notificationsServiceController;

	private static final String FAILURE = "FAILURE";
	private static final String SUCCESS = "SUCCESS";
	
	@Value("classpath:SendNotifications/NotificationsRequest.json")
	private Resource sendNotifications;
	
	@Value("classpath:SendNotifications/NotificationsBulkRequest.json")
	private Resource sendBulkNotifications;

	private static final String FETCH_WEB_NOTIFICATIONS_COUNT = "api.notifications.getnotificationscount.GET.uri";
	private static final String FETCH_WEB_NOTIFICATIONS_DETAILS = "api.notifications.getnotifications.GET.uri";
	private static final String UPDATE_NOTIFICATIONS = "api.notifications.updatenotificationsstatus.PUT.uri";
	private static final String DETAILS_FOR_NOTIFICATIONS = "api.notifications.sendnotifications.POST.uri";
	private static final String DETAILS_FOR_BULK_NOTIFICATIONS = "api.notifications.sendbulknotifications.POST.uri";
	private static final String DETAILS_FOR_UI_NOTIFICATIONS = "api.notifications.senduinotifications.POST.uri";
	private static final String UNDELIVERED_EMAILS = "api.notification.bounces.POST.uri";

	@Before
	public void setUp() throws IOException {
		notificationsServiceController = new NotificationsServiceController();
		exceptionHandler = new BFLExceptionHandler();
		this.mockMvc = MockMvcBuilders.standaloneSetup(notificationsServiceController)
				.setControllerAdvice(exceptionHandler)
				.addPlaceholderValue(FETCH_WEB_NOTIFICATIONS_COUNT, env.getProperty(FETCH_WEB_NOTIFICATIONS_COUNT))
				.addPlaceholderValue(FETCH_WEB_NOTIFICATIONS_DETAILS, env.getProperty(FETCH_WEB_NOTIFICATIONS_DETAILS))
				.addPlaceholderValue(UPDATE_NOTIFICATIONS, env.getProperty(UPDATE_NOTIFICATIONS))
				.addPlaceholderValue(DETAILS_FOR_NOTIFICATIONS, env.getProperty(DETAILS_FOR_NOTIFICATIONS))
				.addPlaceholderValue(DETAILS_FOR_BULK_NOTIFICATIONS, env.getProperty(DETAILS_FOR_BULK_NOTIFICATIONS))
				.addPlaceholderValue(DETAILS_FOR_UI_NOTIFICATIONS, env.getProperty(DETAILS_FOR_UI_NOTIFICATIONS))
				.addPlaceholderValue(UNDELIVERED_EMAILS, env.getProperty(UNDELIVERED_EMAILS)).build();

		ReflectionTestUtils.setField(notificationsServiceController, "logger", logger);
		ReflectionTestUtils.setField(notificationsServiceController, "env", env);
		ReflectionTestUtils.setField(exceptionHandler, "env", env);
		ReflectionTestUtils.setField(notificationsServiceController, "notificationsservice", notificationsservice);
	}

	/*
	 * @Test public void test() { fail("Not yet implemented"); }
	 */
	@Test
	public void getNotificationsCountTest() throws Exception {
		String custId = "234234243";
		NotificationsCount notificationsCount = new NotificationsCount();
		Mockito.when(notificationsservice.fetchNotificationCount(Mockito.any())).thenReturn(notificationsCount);

		MvcResult result = this.mockMvc.perform(
				get(env.getProperty(FETCH_WEB_NOTIFICATIONS_COUNT), custId).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andReturn();
		ResponseBean responseBean = MapperFactory.getInstance().readValue(result.getResponse().getContentAsString(),
				ResponseBean.class);
		Assert.assertEquals(SUCCESS, responseBean.getStatus().toString());
	}
	
	@Test
	public void getNotificationsCountTest_ExceptionCccurred() throws Exception {
		String custId = "234234243";
		Mockito.when(notificationsservice.fetchNotificationCount(Mockito.any())).thenThrow(Exception.class);

		MvcResult result = this.mockMvc.perform(
				get(env.getProperty(FETCH_WEB_NOTIFICATIONS_COUNT), custId).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isInternalServerError()).andReturn();
	}

	
	@Ignore
	public void getNotificationsTest() throws Exception {
		String custId = "234234243";

		int pageNo = 11;
		int pageSize = 2;
		NotificationsDetails notificationsDetails = new NotificationsDetails();

		Mockito.when(
				notificationsservice.fetchNotificationDetails(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt()))
				.thenReturn(notificationsDetails);

		this.mockMvc.perform(get(env.getProperty(FETCH_WEB_NOTIFICATIONS_DETAILS) + "?pageNo=1" + "?pageSize=1", custId)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();

	}
	 
	 

	@Test
	public void updateNotificationsStatusTest() throws Exception {
		String custId = "234234243";
		String notifID = "abcd";
		String status = "true";

		Mockito.when(notificationsservice.updateNotificationStatus(Mockito.any(), Mockito.any())).thenReturn(status);

		MvcResult result = this.mockMvc.perform(
				put(env.getProperty(UPDATE_NOTIFICATIONS), custId, notifID).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andReturn();
		ResponseBean responseBean = MapperFactory.getInstance().readValue(result.getResponse().getContentAsString(),
				ResponseBean.class);
		Assert.assertEquals(SUCCESS, responseBean.getStatus().toString());
	}

	@SuppressWarnings("unchecked")
	@Test(expected = NestedServletException.class)
	public void updateNotificationsStatusTest_BFLBusinessException() throws Exception {
		String custId = "234234243";
		String notifID = "abcd";

		Mockito.when(notificationsservice.updateNotificationStatus(Mockito.any(), Mockito.any()))
				.thenThrow(BFLBusinessException.class);
		;

		MvcResult result = this.mockMvc.perform(
				put(env.getProperty(UPDATE_NOTIFICATIONS), custId, notifID).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andReturn();
		ResponseBean responseBean = MapperFactory.getInstance().readValue(result.getResponse().getContentAsString(),
				ResponseBean.class);
		Assert.assertEquals(SUCCESS, responseBean.getStatus().toString());
	}
	
	@Test
	public void updateNotificationsStatusTest_ExceptionOccurred() throws Exception {
		String custId = "234234243";
		String notifID = "abcd";
		String status = "true";

		Mockito.when(notificationsservice.updateNotificationStatus(Mockito.any(), Mockito.any())).thenThrow(Exception.class);

		MvcResult result = this.mockMvc.perform(
				put(env.getProperty(UPDATE_NOTIFICATIONS), custId, notifID).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isInternalServerError()).andReturn();
	}
	
	@Test
	public void sendNotificationsTest() throws Exception {
		NotificationsRequest notificationsRequest = new NotificationsRequest();
		notificationsRequest.setNotificationTypeCode("abc");

		String request = FileUtils.readFileToString(sendNotifications.getFile());

		ResponseBean notificationsResponse = new ResponseBean();
		Mockito.when(notificationsservice.sendNotificationRequest(Mockito.any())).thenReturn(notificationsResponse);
		this.mockMvc.perform(post(env.getProperty(DETAILS_FOR_NOTIFICATIONS)).content(request)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();

	}
	
	@Test
	public void sendNotificationsTest_ExceptionOccurred() throws Exception {
		NotificationsRequest notificationsRequest = new NotificationsRequest();
		notificationsRequest.setNotificationTypeCode("abc");

		String request = FileUtils.readFileToString(sendNotifications.getFile());

		ResponseBean notificationsResponse = new ResponseBean();
		Mockito.when(notificationsservice.sendNotificationRequest(Mockito.any())).thenThrow(Exception.class);
		this.mockMvc.perform(post(env.getProperty(DETAILS_FOR_NOTIFICATIONS)).content(request)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isInternalServerError()).andReturn();

	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = NestedServletException.class)
	public void sendNotificationsTest_Failure() throws Exception {
		NotificationsRequest notificationsRequest = new NotificationsRequest();
		notificationsRequest.setNotificationTypeCode("abc");

		String request = FileUtils.readFileToString(sendNotifications.getFile());
		Mockito.when(notificationsservice.sendNotificationRequest(Mockito.any())).thenThrow(BFLBusinessException.class);
		this.mockMvc.perform(post(env.getProperty(DETAILS_FOR_NOTIFICATIONS)).content(request)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();

	}
	
	@Ignore
	public void sendBulkNotificationsTest() throws Exception {
		
		String request = FileUtils.readFileToString(sendBulkNotifications.getFile());
		NotificationBulkResponse notificationBulkResponse = new NotificationBulkResponse();
		
		Mockito.when(notificationsservice.sendNotificationBulkRequest(Mockito.any())).thenReturn(notificationBulkResponse);
		this.mockMvc.perform(post(env.getProperty(DETAILS_FOR_BULK_NOTIFICATIONS)).content(request)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();

	}
	
	@Test
	public void sendUiNotificationsTest() throws Exception {
		NotificationsRequest notificationsRequest = new NotificationsRequest();
		notificationsRequest.setNotificationTypeCode("abc");

		String request = FileUtils.readFileToString(sendNotifications.getFile());

		ResponseBean notificationsResponse = new ResponseBean();
		Mockito.when(notificationsservice.sendNotificationRequest(Mockito.any())).thenReturn(notificationsResponse);
		this.mockMvc.perform(post(env.getProperty(DETAILS_FOR_UI_NOTIFICATIONS)).content(request)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();

	}
	
	@Test
	public void sendUiNotificationsTest_ExceptionOccurred() throws Exception {
		NotificationsRequest notificationsRequest = new NotificationsRequest();
		notificationsRequest.setNotificationTypeCode("abc");

		String request = FileUtils.readFileToString(sendNotifications.getFile());

		ResponseBean notificationsResponse = new ResponseBean();
		Mockito.when(notificationsservice.sendNotificationRequest(Mockito.any())).thenThrow(Exception.class);
		this.mockMvc.perform(post(env.getProperty(DETAILS_FOR_UI_NOTIFICATIONS)).content(request)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isInternalServerError()).andReturn();

	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = NestedServletException.class)
	public void sendUiNotificationsTest_Failure() throws Exception {
		NotificationsRequest notificationsRequest = new NotificationsRequest();
		notificationsRequest.setNotificationTypeCode("abc");

		String request = FileUtils.readFileToString(sendNotifications.getFile());
		Mockito.when(notificationsservice.sendNotificationRequest(Mockito.any())).thenThrow(BFLBusinessException.class);
		this.mockMvc.perform(post(env.getProperty(DETAILS_FOR_UI_NOTIFICATIONS)).content(request)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();

	}
	
	@Ignore
	public void bounceNotificationTest() throws Exception {
		
		String notificationText ="{EMAIL:noreply,FROM:}";
		String result= "abcdef" ;//= notificationsservice.bounceNotification(bouncedRecepients, null, bounceType);
		List<String> bouncedRecepients =new ArrayList<String>();
		String correlationId = "text";
		int bounceType =0;
		Mockito.when(notificationsservice.bounceNotification(Mockito.anyList(),Mockito.any(),Mockito.any())).thenReturn(result);
		this.mockMvc.perform(post(env.getProperty(UNDELIVERED_EMAILS)).content(notificationText)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();

	}
	
	@Test
	public void testGetNotifications() throws Exception{
		String custID = "123";
		MvcResult result = this.mockMvc.perform(MockMvcRequestBuilders.get(env.getProperty(FETCH_WEB_NOTIFICATIONS_DETAILS),custID).content(custID)				
				.param("pageNo", "1").param("pageSize", "1")
				.contentType(MediaType.APPLICATION_JSON))				
				.andExpect(status().isOk())
				.andReturn();
	}
	
	@Test
	public void testGetNotifications_ExceptionOccurred() throws Exception{
		String custID = "123";
		Mockito.when(notificationsservice.fetchNotificationDetails("123",1,1)).thenThrow(Exception.class);
		MvcResult result = this.mockMvc.perform(MockMvcRequestBuilders.get(env.getProperty(FETCH_WEB_NOTIFICATIONS_DETAILS),custID).content(custID)				
				.param("pageNo", "1").param("pageSize", "1")
				.contentType(MediaType.APPLICATION_JSON))				
				.andExpect(status().isInternalServerError())
				.andReturn();
	}
	
	@Test
	public void testNotificationsBulkRequest() throws Exception{
		String requestStr = prepareRequestJsonString(new NotificationsBulkRequest());
		this.mockMvc.perform(post(env.getProperty(DETAILS_FOR_BULK_NOTIFICATIONS)).content(requestStr)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
	}
	
	@Test
	public void testNotificationsBulkRequest_ExceptionOccurred() throws Exception{
		Mockito.when(notificationsservice.sendNotificationBulkRequest(Mockito.any())).thenThrow(Exception.class);
		String requestStr = prepareRequestJsonString(new NotificationsBulkRequest());
		this.mockMvc.perform(post(env.getProperty(DETAILS_FOR_BULK_NOTIFICATIONS)).content(requestStr)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isInternalServerError()).andReturn();
	}
	
	@Test
	public void testBounceNotification() throws Exception{
		this.mockMvc.perform(post(env.getProperty(UNDELIVERED_EMAILS)).content("123")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isInternalServerError()).andReturn();
	}
	
	private String prepareRequestJsonString(Object requestObject) {
		String requestJson;

		try {
			ObjectMapper mapper = MapperFactory.getInstance();
			requestJson = mapper.writeValueAsString(requestObject);
		} catch (JsonProcessingException e) {
			throw new BFLTechnicalException("JsonProcessingException occurred while preparing requestJson String",e);
		}
		return requestJson;
	}
	
}
