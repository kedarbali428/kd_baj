package com.bajaj.bfsd.notificationsservice.messaging;

import java.util.Map;

import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.amazon.sqs.javamessaging.AmazonSQSMessagingClientWrapper;
import com.amazon.sqs.javamessaging.SQSConnection;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@RunWith(SpringJUnit4ClassRunner.class)
public class AwsClientWrapperTest {

	@InjectMocks
	AwsClientWrapper awsClientWrapper;
	
	@Mock
	SQSConnection sqsConnection;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	Environment env;
	
	@Mock
	Session session;
	
	@Mock
	AmazonSQSMessagingClientWrapper client;
	
	@Mock
	Map<String , MessageProducer> producerCache;
	
	@Test
	public void testGetSession(){
		Assert.assertNotNull(awsClientWrapper.getSession());
	}
	
	@Test
	public void testGetClient(){
		Assert.assertNotNull(awsClientWrapper.getClient());
	}
	
	@Test
	public void testInitAwsClient(){
		awsClientWrapper.initAwsClient();
	}
	
	@Test(expected=Exception.class)
	public void testInitAwsClientWithException() throws JMSException{
		Mockito.when(sqsConnection.createSession(false, Session.AUTO_ACKNOWLEDGE)).thenThrow(JMSException.class);
		awsClientWrapper.initAwsClient();
	}
	
	@Test
	public void testGetProducer(){
		MessageProducer messageProducer = Mockito.mock(MessageProducer.class);
		Mockito.when(producerCache.containsKey("Queue")).thenReturn(true);
		Mockito.when(producerCache.get("Queue")).thenReturn(messageProducer);
		Assert.assertNotNull(awsClientWrapper.getProducer("Queue"));
	}
	
	@Test
	public void testGetProducer1() throws JMSException{
		MessageProducer messageProducer = Mockito.mock(MessageProducer.class);
		Mockito.when(producerCache.containsKey("Queue")).thenReturn(false);
		Mockito.when(client.queueExists("Queue")).thenReturn(false);
		Queue queue = Mockito.mock(Queue.class);
		Mockito.when(session.createQueue("Queue")).thenReturn(queue);
		Mockito.when(session.createProducer(queue)).thenReturn(messageProducer);
		Assert.assertNotNull(awsClientWrapper.getProducer("Queue"));
	}
	
	@Test(expected=Exception.class)
	public void testGetProducerWithException() throws JMSException{
		Mockito.when(producerCache.containsKey("Queue")).thenReturn(false);
		Mockito.when(client.queueExists("Queue")).thenThrow(JMSException.class);
		Assert.assertNotNull(awsClientWrapper.getProducer("Queue"));
	}
	
}
