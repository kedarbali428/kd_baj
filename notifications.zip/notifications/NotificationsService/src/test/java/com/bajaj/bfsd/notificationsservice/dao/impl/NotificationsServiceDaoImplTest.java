package com.bajaj.bfsd.notificationsservice.dao.impl;

import java.io.IOException;

import javax.persistence.EntityManager;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringJUnit4ClassRunner.class)
public class NotificationsServiceDaoImplTest {
	
	@Mock
	private BFLLoggerUtilExt logger;
	
	@Mock
	private Environment env;
	
	@Mock
	EntityManager entityManager;
	
	@InjectMocks
	NotificationsServiceDaoImpl notificationsServiceDaoImpl;
	
	@Before
	public void setUp() throws IOException {
		
	}
	
	@Test
	public void testFetchDetails() {
		notificationsServiceDaoImpl.fetchDetails(null,0, 0);
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testFetchwebNotCount(){
		notificationsServiceDaoImpl.fetchwebNotCount(0);
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testUpdateStatus(){
		notificationsServiceDaoImpl.updateStatus(null, null);
	}
	
	@Test(expected=BFLTechnicalException.class)
	public void testGetNotificationTypeKey(){
		notificationsServiceDaoImpl.getNotificationTypeKey(null);
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testUpdateBounceDetails(){
		notificationsServiceDaoImpl.updateBounceDetails(null, null, 0);
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testRetrieveDeviceAppRegistrationAppLink(){
		notificationsServiceDaoImpl.retrieveDeviceAppRegistrationAppLink(null, null);
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testGetNotfChanelSubscriptionByChannelCode(){
		notificationsServiceDaoImpl.getNotfChanelSubscriptionByChannelCode(null, null);
	}
	
	
	@Test(expected=BFLBusinessException.class)
	public void testGetnotificationDetailsList(){
		notificationsServiceDaoImpl.getnotificationDetailsList(0, 0, 0);
	}
}
