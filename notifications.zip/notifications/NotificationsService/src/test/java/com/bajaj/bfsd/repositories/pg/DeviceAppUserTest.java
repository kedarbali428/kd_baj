package com.bajaj.bfsd.repositories.pg;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.annotation.Generated;

import org.junit.Test;

import com.bajaj.bfsd.repositories.ora1.DeviceAppRegistrationDet;
import com.bajaj.bfsd.repositories.ora1.DeviceAppUser;


@Generated(value = "org.junit-tools-1.1.0")
public class DeviceAppUserTest {

	private DeviceAppUser createTestSubject() {
		return new DeviceAppUser();
	}

	//@MethodRef(name = "getDeviceappuserkey", signature = "()J")
	@Test
	public void testGetDeviceappuserkey() throws Exception {
		DeviceAppUser testSubject;
		long result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getDeviceappuserkey();
	}

	//@MethodRef(name = "setDeviceappuserkey", signature = "(J)V")
	@Test
	public void testSetDeviceappuserkey() throws Exception {
		DeviceAppUser testSubject;
		long deviceappuserkey = 4344;

		// default test
		testSubject = createTestSubject();
		testSubject.setDeviceappuserkey(deviceappuserkey);
	}

	//@MethodRef(name = "getAppuserregistrationdt", signature = "()QTimestamp;")
	@Test
	public void testGetAppuserregistrationdt() throws Exception {
		DeviceAppUser testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getAppuserregistrationdt();
	}

	//@MethodRef(name = "setAppuserregistrationdt", signature = "(QTimestamp;)V")
	@Test
	public void testSetAppuserregistrationdt() throws Exception {
		DeviceAppUser testSubject;
		Timestamp appuserregistrationdt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setAppuserregistrationdt(appuserregistrationdt);
	}

	//@MethodRef(name = "getAppuserregistrationstatus", signature = "()QBigDecimal;")
	@Test
	public void testGetAppuserregistrationstatus() throws Exception {
		DeviceAppUser testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getAppuserregistrationstatus();
	}

	//@MethodRef(name = "setAppuserregistrationstatus", signature = "(QBigDecimal;)V")
	@Test
	public void testSetAppuserregistrationstatus() throws Exception {
		DeviceAppUser testSubject;
		BigDecimal appuserregistrationstatus = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setAppuserregistrationstatus(appuserregistrationstatus);
	}

	//@MethodRef(name = "getAppuserreleasedt", signature = "()QTimestamp;")
	@Test
	public void testGetAppuserreleasedt() throws Exception {
		DeviceAppUser testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getAppuserreleasedt();
	}

	//@MethodRef(name = "setAppuserreleasedt", signature = "(QTimestamp;)V")
	@Test
	public void testSetAppuserreleasedt() throws Exception {
		DeviceAppUser testSubject;
		Timestamp appuserreleasedt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setAppuserreleasedt(appuserreleasedt);
	}

	//@MethodRef(name = "getLstupdateby", signature = "()QString;")
	@Test
	public void testGetLstupdateby() throws Exception {
		DeviceAppUser testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getLstupdateby();
	}

	//@MethodRef(name = "setLstupdateby", signature = "(QString;)V")
	@Test
	public void testSetLstupdateby() throws Exception {
		DeviceAppUser testSubject;
		String lstupdateby = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setLstupdateby(lstupdateby);
	}

	//@MethodRef(name = "getLstupdatedt", signature = "()QTimestamp;")
	@Test
	public void testGetLstupdatedt() throws Exception {
		DeviceAppUser testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getLstupdatedt();
	}

	//@MethodRef(name = "setLstupdatedt", signature = "(QTimestamp;)V")
	@Test
	public void testSetLstupdatedt() throws Exception {
		DeviceAppUser testSubject;
		Timestamp lstupdatedt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setLstupdatedt(lstupdatedt);
	}

	//@MethodRef(name = "getUserkey", signature = "()QBigDecimal;")
	@Test
	public void testGetUserkey() throws Exception {
		DeviceAppUser testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserkey();
	}

	//@MethodRef(name = "setUserkey", signature = "(QBigDecimal;)V")
	@Test
	public void testSetUserkey() throws Exception {
		DeviceAppUser testSubject;
		BigDecimal userkey = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserkey(userkey);
	}

	//@MethodRef(name = "getDeviceAppRegistrationDet", signature = "()QDeviceAppRegistrationDet;")
	@Test
	public void testGetDeviceAppRegistrationDet() throws Exception {
		DeviceAppUser testSubject;
		DeviceAppRegistrationDet result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getDeviceAppRegistrationDet();
	}

	//@MethodRef(name = "setDeviceAppRegistrationDet", signature = "(QDeviceAppRegistrationDet;)V")
	@Test
	public void testSetDeviceAppRegistrationDet() throws Exception {
		DeviceAppUser testSubject;
		DeviceAppRegistrationDet deviceAppRegistrationDet = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setDeviceAppRegistrationDet(deviceAppRegistrationDet);
	}
}