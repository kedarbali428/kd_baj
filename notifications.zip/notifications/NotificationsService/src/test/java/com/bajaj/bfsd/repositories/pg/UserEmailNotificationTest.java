package com.bajaj.bfsd.repositories.pg;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.annotation.Generated;

import org.junit.Test;

import com.bajaj.bfsd.repositories.pg.UserEmailNotification;
import com.bajaj.bfsd.repositories.pg.UserNotification;

@Generated(value = "org.junit-tools-1.1.0")
public class UserEmailNotificationTest {

	private UserEmailNotification createTestSubject() {
		return new UserEmailNotification();
	}

	//@MethodRef(name = "getUseremailnotfkey", signature = "()J")
	@Test
	public void testGetUseremailnotfkey() throws Exception {
		UserEmailNotification testSubject;
		long result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUseremailnotfkey();
	}

	//@MethodRef(name = "setUseremailnotfkey", signature = "(J)V")
	@Test
	public void testSetUseremailnotfkey() throws Exception {
		UserEmailNotification testSubject;
		long useremailnotfkey = 142012;

		// default test
		testSubject = createTestSubject();
		testSubject.setUseremailnotfkey(useremailnotfkey);
	}

	//@MethodRef(name = "getDocattachmentflg", signature = "()QBigDecimal;")
	@Test
	public void testGetDocattachmentflg() throws Exception {
		UserEmailNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getDocattachmentflg();
	}

	//@MethodRef(name = "setDocattachmentflg", signature = "(QBigDecimal;)V")
	@Test
	public void testSetDocattachmentflg() throws Exception {
		UserEmailNotification testSubject;
		BigDecimal docattachmentflg = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setDocattachmentflg(docattachmentflg);
	}

	//@MethodRef(name = "getEmailid", signature = "()QString;")
	@Test
	public void testGetEmailid() throws Exception {
		UserEmailNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getEmailid();
	}

	//@MethodRef(name = "setEmailid", signature = "(QString;)V")
	@Test
	public void testSetEmailid() throws Exception {
		UserEmailNotification testSubject;
		String emailid = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setEmailid(emailid);
	}

	//@MethodRef(name = "getExpirydate", signature = "()QTimestamp;")
	@Test
	public void testGetExpirydate() throws Exception {
		UserEmailNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getExpirydate();
	}

	//@MethodRef(name = "setExpirydate", signature = "(QTimestamp;)V")
	@Test
	public void testSetExpirydate() throws Exception {
		UserEmailNotification testSubject;
		Timestamp expirydate = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setExpirydate(expirydate);
	}

	//@MethodRef(name = "getMessagetitle", signature = "()QString;")
	@Test
	public void testGetMessagetitle() throws Exception {
		UserEmailNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMessagetitle();
	}

	//@MethodRef(name = "setMessagetitle", signature = "(QString;)V")
	@Test
	public void testSetMessagetitle() throws Exception {
		UserEmailNotification testSubject;
		String messagetitle = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMessagetitle(messagetitle);
	}

	//@MethodRef(name = "getReaddt", signature = "()QTimestamp;")
	@Test
	public void testGetReaddt() throws Exception {
		UserEmailNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getReaddt();
	}

	//@MethodRef(name = "setReaddt", signature = "(QTimestamp;)V")
	@Test
	public void testSetReaddt() throws Exception {
		UserEmailNotification testSubject;
		Timestamp readdt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setReaddt(readdt);
	}

	//@MethodRef(name = "getReadsts", signature = "()QBigDecimal;")
	@Test
	public void testGetReadsts() throws Exception {
		UserEmailNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getReadsts();
	}

	//@MethodRef(name = "setReadsts", signature = "(QBigDecimal;)V")
	@Test
	public void testSetReadsts() throws Exception {
		UserEmailNotification testSubject;
		BigDecimal readsts = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setReadsts(readsts);
	}

	//@MethodRef(name = "getResponsedt", signature = "()QTimestamp;")
	@Test
	public void testGetResponsedt() throws Exception {
		UserEmailNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getResponsedt();
	}

	//@MethodRef(name = "setResponsedt", signature = "(QTimestamp;)V")
	@Test
	public void testSetResponsedt() throws Exception {
		UserEmailNotification testSubject;
		Timestamp responsedt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setResponsedt(responsedt);
	}

	//@MethodRef(name = "getResponsests", signature = "()QBigDecimal;")
	@Test
	public void testGetResponsests() throws Exception {
		UserEmailNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getResponsests();
	}

	//@MethodRef(name = "setResponsests", signature = "(QBigDecimal;)V")
	@Test
	public void testSetResponsests() throws Exception {
		UserEmailNotification testSubject;
		BigDecimal responsests = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setResponsests(responsests);
	}

	//@MethodRef(name = "getSendattemptcount", signature = "()QBigDecimal;")
	@Test
	public void testGetSendattemptcount() throws Exception {
		UserEmailNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendattemptcount();
	}

	//@MethodRef(name = "setSendattemptcount", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendattemptcount() throws Exception {
		UserEmailNotification testSubject;
		BigDecimal sendattemptcount = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendattemptcount(sendattemptcount);
	}

	//@MethodRef(name = "getSenddt", signature = "()QTimestamp;")
	@Test
	public void testGetSenddt() throws Exception {
		UserEmailNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSenddt();
	}

	//@MethodRef(name = "setSenddt", signature = "(QTimestamp;)V")
	@Test
	public void testSetSenddt() throws Exception {
		UserEmailNotification testSubject;
		Timestamp senddt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSenddt(senddt);
	}

	//@MethodRef(name = "getSendsts", signature = "()QBigDecimal;")
	@Test
	public void testGetSendsts() throws Exception {
		UserEmailNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendsts();
	}

	//@MethodRef(name = "setSendsts", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendsts() throws Exception {
		UserEmailNotification testSubject;
		BigDecimal sendsts = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendsts(sendsts);
	}

	//@MethodRef(name = "getUserNotification", signature = "()QUserNotification;")
	@Test
	public void testGetUserNotification() throws Exception {
		UserEmailNotification testSubject;
		UserNotification result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserNotification();
	}

	//@MethodRef(name = "setUserNotification", signature = "(QUserNotification;)V")
	@Test
	public void testSetUserNotification() throws Exception {
		UserEmailNotification testSubject;
		UserNotification userNotification = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserNotification(userNotification);
	}
}