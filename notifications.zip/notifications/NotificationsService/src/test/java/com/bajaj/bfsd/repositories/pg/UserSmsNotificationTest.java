package com.bajaj.bfsd.repositories.pg;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.annotation.Generated;

import org.junit.Test;

import com.bajaj.bfsd.repositories.pg.UserNotification;
import com.bajaj.bfsd.repositories.pg.UserSmsNotification;

@Generated(value = "org.junit-tools-1.1.0")
public class UserSmsNotificationTest {

	private UserSmsNotification createTestSubject() {
		return new UserSmsNotification();
	}

	//@MethodRef(name = "getUsersmsnotfkey", signature = "()J")
	@Test
	public void testGetUsersmsnotfkey() throws Exception {
		UserSmsNotification testSubject;
		long result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUsersmsnotfkey();
	}

	//@MethodRef(name = "setUsersmsnotfkey", signature = "(J)V")
	@Test
	public void testSetUsersmsnotfkey() throws Exception {
		UserSmsNotification testSubject;
		long usersmsnotfkey = 7867868;

		// default test
		testSubject = createTestSubject();
		testSubject.setUsersmsnotfkey(usersmsnotfkey);
	}

	//@MethodRef(name = "getExpirydate", signature = "()QTimestamp;")
	@Test
	public void testGetExpirydate() throws Exception {
		UserSmsNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getExpirydate();
	}

	//@MethodRef(name = "setExpirydate", signature = "(QTimestamp;)V")
	@Test
	public void testSetExpirydate() throws Exception {
		UserSmsNotification testSubject;
		Timestamp expirydate = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setExpirydate(expirydate);
	}

	//@MethodRef(name = "getMessage", signature = "()QString;")
	@Test
	public void testGetMessage() throws Exception {
		UserSmsNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMessage();
	}

	//@MethodRef(name = "setMessage", signature = "(QString;)V")
	@Test
	public void testSetMessage() throws Exception {
		UserSmsNotification testSubject;
		String message = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMessage(message);
	}

	//@MethodRef(name = "getMobileno", signature = "()QString;")
	@Test
	public void testGetMobileno() throws Exception {
		UserSmsNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMobileno();
	}

	//@MethodRef(name = "setMobileno", signature = "(QString;)V")
	@Test
	public void testSetMobileno() throws Exception {
		UserSmsNotification testSubject;
		String mobileno = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMobileno(mobileno);
	}

	//@MethodRef(name = "getSendattemptcount", signature = "()QBigDecimal;")
	@Test
	public void testGetSendattemptcount() throws Exception {
		UserSmsNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendattemptcount();
	}

	//@MethodRef(name = "setSendattemptcount", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendattemptcount() throws Exception {
		UserSmsNotification testSubject;
		BigDecimal sendattemptcount = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendattemptcount(sendattemptcount);
	}

	//@MethodRef(name = "getSenddt", signature = "()QTimestamp;")
	@Test
	public void testGetSenddt() throws Exception {
		UserSmsNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSenddt();
	}

	//@MethodRef(name = "setSenddt", signature = "(QTimestamp;)V")
	@Test
	public void testSetSenddt() throws Exception {
		UserSmsNotification testSubject;
		Timestamp senddt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSenddt(senddt);
	}

	//@MethodRef(name = "getSendsts", signature = "()QBigDecimal;")
	@Test
	public void testGetSendsts() throws Exception {
		UserSmsNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendsts();
	}

	//@MethodRef(name = "setSendsts", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendsts() throws Exception {
		UserSmsNotification testSubject;
		BigDecimal sendsts = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendsts(sendsts);
	}

	//@MethodRef(name = "getUserNotification", signature = "()QUserNotification;")
	@Test
	public void testGetUserNotification() throws Exception {
		UserSmsNotification testSubject;
		UserNotification result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserNotification();
	}

	//@MethodRef(name = "setUserNotification", signature = "(QUserNotification;)V")
	@Test
	public void testSetUserNotification() throws Exception {
		UserSmsNotification testSubject;
		UserNotification userNotification = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserNotification(userNotification);
	}
}