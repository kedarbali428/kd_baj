package com.bajaj.bfsd.notificationsservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsBulkRequest;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsCount;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsDetails;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;
import com.bajaj.bfsd.notificationsservice.dao.NotificationsServiceDao;
import com.bajaj.bfsd.notificationsservice.service.impl.NotificationsServiceImpl;
import com.bajaj.bfsd.notificationsservice.util.NotificationsMapper;
import com.bajaj.bfsd.repositories.pg.NotificationType;
import com.bfl.common.exceptions.BFLBusinessException;

@SpringBootTest(classes = { BFLCommonRestClient.class })
@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource({ "classpath:error.properties" })
public class NotificationsServiceTest {
	
	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	private Environment env;
	
	@InjectMocks
	NotificationsServiceImpl notificationsservice;
	
	@Mock
	NotificationsServiceDao notificationsServiceDao;

	@Mock
	NotificationsMapper notificationsMapper;

	@Before
	public void setUp() throws IOException {
		
		notificationsservice = new NotificationsServiceImpl();
		//mapper = MapperFactory.getInstance();
		ReflectionTestUtils.setField(notificationsservice, "logger", logger);
		ReflectionTestUtils.setField(notificationsservice, "notificationsServiceDao", notificationsServiceDao);
		ReflectionTestUtils.setField(notificationsservice, "notificationsMapper", notificationsMapper);
	}

	@Test
	public void fetchNotificationDetailsTest() {
		NotificationsDetails notificationsDetails = new NotificationsDetails();
		String custID="1228";
		int pageNo =1;
		int pageSize =2;
		Mockito.when(notificationsServiceDao.fetchDetails(Mockito.anyString(),Mockito.anyInt(),Mockito.anyInt()))
		.thenReturn(notificationsDetails);
		NotificationsDetails notificationsDtls = notificationsservice.fetchNotificationDetails(custID, pageNo,
				pageSize);
		assertEquals(notificationsDetails,notificationsDtls);
		
	}
	
	@Test
	public void fetchNotificationCountTest() {
		NotificationsCount notificationsCount = new NotificationsCount(); 
		String custID="1228";
		Mockito.when(notificationsServiceDao.fetchNoOfCount(Mockito.anyString()))
		.thenReturn(notificationsCount);
		ResponseBean reponsebean = new ResponseBean(notificationsservice.fetchNotificationCount(custID));
		assertNotNull(reponsebean);
	
	}
		
	@Test
	public void updateNotificationsStatusTest() {
		String custID="1228";
		String notifID ="221";
		String status = "abc";
		Mockito.when(notificationsServiceDao.updateStatus(Mockito.anyString(),Mockito.anyString())).thenReturn(status);
		String stats = notificationsservice.updateNotificationStatus(custID, notifID);
		assertNotNull(stats);
	}
	
	//@Test
	public void testSendNotificationRequest(){
		when(notificationsServiceDao.getNotificationTypeKey(any())).thenReturn(new NotificationType());
		when(notificationsMapper.notificationSend(any(),any())).thenReturn(new ResponseBean());
		assertNotNull(notificationsservice.sendNotificationRequest(new NotificationsRequest()));
	}
	
	//@Test
	public void testSendNotificationBulkRequest(){
		NotificationsBulkRequest notificationsBulkRequest = new NotificationsBulkRequest();
		List<NotificationsRequest> notificationsRequests = new ArrayList<>();
		notificationsRequests.add(new NotificationsRequest());
		notificationsBulkRequest.setNotificationsRequest(notificationsRequests);
		when(notificationsServiceDao.getNotificationTypeKey(any())).thenReturn(new NotificationType());
		when(notificationsMapper.notificationSend(any(),any())).thenReturn(new ResponseBean());
		assertNotNull(notificationsservice.sendNotificationBulkRequest(notificationsBulkRequest).getBulkResponse().get(0));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected=BFLBusinessException.class)
	public void testSendNotificationBulkRequest_exceptionOccurred(){
		NotificationsBulkRequest notificationsBulkRequest = new NotificationsBulkRequest();
		List<NotificationsRequest> notificationsRequests = new ArrayList<>();
		notificationsRequests.add(new NotificationsRequest());
		notificationsBulkRequest.setNotificationsRequest(notificationsRequests);
		when(notificationsServiceDao.getNotificationTypeKey(any())).thenReturn(new NotificationType());
		when(notificationsMapper.notificationSend(any(),any())).thenThrow(BFLBusinessException.class);
		notificationsservice.sendNotificationBulkRequest(notificationsBulkRequest);
		
	}
	
	@Test
	public void testBounceNotification(){
		List<String> bouncedRecepients = new ArrayList<>();
		bouncedRecepients.add("name");
		notificationsservice.bounceNotification(bouncedRecepients, null, 0);
	}
}
