package com.bajaj.bfsd.repositories.pg;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.annotation.Generated;

import org.junit.Test;

import com.bajaj.bfsd.repositories.pg.NotfChannelSubscription;
import com.bajaj.bfsd.repositories.pg.NotfChannelType;
import com.bajaj.bfsd.repositories.pg.NotificationType;

@Generated(value = "org.junit-tools-1.1.0")
public class NotfChannelSubscriptionTest {

	private NotfChannelSubscription createTestSubject() {
		return new NotfChannelSubscription();
	}

	//@MethodRef(name = "getNotfchannelsubkey", signature = "()J")
	@Test
	public void testGetNotfchannelsubkey() throws Exception {
		NotfChannelSubscription testSubject;
		long result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotfchannelsubkey();
	}

	//@MethodRef(name = "setNotfchannelsubkey", signature = "(J)V")
	@Test
	public void testSetNotfchannelsubkey() throws Exception {
		NotfChannelSubscription testSubject;
		long notfchannelsubkey = 1213212;

		// default test
		testSubject = createTestSubject();
		testSubject.setNotfchannelsubkey(notfchannelsubkey);
	}

	//@MethodRef(name = "getIsactive", signature = "()QBigDecimal;")
	@Test
	public void testGetIsactive() throws Exception {
		NotfChannelSubscription testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getIsactive();
	}

	//@MethodRef(name = "setIsactive", signature = "(QBigDecimal;)V")
	@Test
	public void testSetIsactive() throws Exception {
		NotfChannelSubscription testSubject;
		BigDecimal isactive = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setIsactive(isactive);
	}

	//@MethodRef(name = "getLstupdateby", signature = "()QString;")
	@Test
	public void testGetLstupdateby() throws Exception {
		NotfChannelSubscription testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getLstupdateby();
	}

	//@MethodRef(name = "setLstupdateby", signature = "(QString;)V")
	@Test
	public void testSetLstupdateby() throws Exception {
		NotfChannelSubscription testSubject;
		String lstupdateby = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setLstupdateby(lstupdateby);
	}

	//@MethodRef(name = "getLstupdatedt", signature = "()QTimestamp;")
	@Test
	public void testGetLstupdatedt() throws Exception {
		NotfChannelSubscription testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getLstupdatedt();
	}

	//@MethodRef(name = "setLstupdatedt", signature = "(QTimestamp;)V")
	@Test
	public void testSetLstupdatedt() throws Exception {
		NotfChannelSubscription testSubject;
		Timestamp lstupdatedt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setLstupdatedt(lstupdatedt);
	}

	//@MethodRef(name = "getMaxsendattempt", signature = "()QBigDecimal;")
	@Test
	public void testGetMaxsendattempt() throws Exception {
		NotfChannelSubscription testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMaxsendattempt();
	}

	//@MethodRef(name = "setMaxsendattempt", signature = "(QBigDecimal;)V")
	@Test
	public void testSetMaxsendattempt() throws Exception {
		NotfChannelSubscription testSubject;
		BigDecimal maxsendattempt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setMaxsendattempt(maxsendattempt);
	}

	//@MethodRef(name = "getSubscriptiondt", signature = "()QTimestamp;")
	@Test
	public void testGetSubscriptiondt() throws Exception {
		NotfChannelSubscription testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSubscriptiondt();
	}

	//@MethodRef(name = "setSubscriptiondt", signature = "(QTimestamp;)V")
	@Test
	public void testSetSubscriptiondt() throws Exception {
		NotfChannelSubscription testSubject;
		Timestamp subscriptiondt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSubscriptiondt(subscriptiondt);
	}

	//@MethodRef(name = "getTemplateid", signature = "()QString;")
	@Test
	public void testGetTemplateid() throws Exception {
		NotfChannelSubscription testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getTemplateid();
	}

	//@MethodRef(name = "setTemplateid", signature = "(QString;)V")
	@Test
	public void testSetTemplateid() throws Exception {
		NotfChannelSubscription testSubject;
		String templateid = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setTemplateid(templateid);
	}

	//@MethodRef(name = "getNotfChannelType", signature = "()QNotfChannelType;")
	@Test
	public void testGetNotfChannelType() throws Exception {
		NotfChannelSubscription testSubject;
		NotfChannelType result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotfchanneltypekey();
	}

	//@MethodRef(name = "setNotfChannelType", signature = "(QNotfChannelType;)V")
	@Test
	public void testSetNotfChannelType() throws Exception {
		NotfChannelSubscription testSubject;
		NotfChannelType notfChannelType = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setNotfchanneltypekey(notfChannelType);
	}

	//@MethodRef(name = "getNotificationType", signature = "()QNotificationType;")
	@Test
	public void testGetNotificationType() throws Exception {
		NotfChannelSubscription testSubject;
		NotificationType result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotificationType();
	}

	//@MethodRef(name = "setNotificationType", signature = "(QNotificationType;)V")
	@Test
	public void testSetNotificationType() throws Exception {
		NotfChannelSubscription testSubject;
		NotificationType notificationType = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setNotificationType(notificationType);
	}

	//@MethodRef(name = "getNotificationgroupcode", signature = "()QString;")
	@Test
	public void testGetNotificationgroupcode() throws Exception {
		NotfChannelSubscription testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotificationgroupcode();
	}

	//@MethodRef(name = "setNotificationgroupcode", signature = "(QString;)V")
	@Test
	public void testSetNotificationgroupcode() throws Exception {
		NotfChannelSubscription testSubject;
		String notificationgroupcode = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setNotificationgroupcode(notificationgroupcode);
	}
}