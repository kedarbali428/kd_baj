package com.bajaj.bfsd.repositories.pg;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.annotation.Generated;

import org.junit.Test;

import com.bajaj.bfsd.repositories.pg.UserAppNotification;
import com.bajaj.bfsd.repositories.pg.UserNotification;

@Generated(value = "org.junit-tools-1.1.0")
public class UserAppNotificationTest {

	private UserAppNotification createTestSubject() {
		return new UserAppNotification();
	}

	//@MethodRef(name = "getUserappnotfkey", signature = "()J")
	@Test
	public void testGetUserappnotfkey() throws Exception {
		UserAppNotification testSubject;
		long result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserappnotfkey();
	}

	//@MethodRef(name = "setUserappnotfkey", signature = "(J)V")
	@Test
	public void testSetUserappnotfkey() throws Exception {
		UserAppNotification testSubject;
		long userappnotfkey = 54234;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserappnotfkey(userappnotfkey);
	}

	//@MethodRef(name = "getAcknowledgementdt", signature = "()QTimestamp;")
	@Test
	public void testGetAcknowledgementdt() throws Exception {
		UserAppNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getAcknowledgementdt();
	}

	//@MethodRef(name = "setAcknowledgementdt", signature = "(QTimestamp;)V")
	@Test
	public void testSetAcknowledgementdt() throws Exception {
		UserAppNotification testSubject;
		Timestamp acknowledgementdt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setAcknowledgementdt(acknowledgementdt);
	}

	//@MethodRef(name = "getAcknowledgementid", signature = "()QString;")
	@Test
	public void testGetAcknowledgementid() throws Exception {
		UserAppNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getAcknowledgementid();
	}

	//@MethodRef(name = "setAcknowledgementid", signature = "(QString;)V")
	@Test
	public void testSetAcknowledgementid() throws Exception {
		UserAppNotification testSubject;
		String acknowledgementid = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setAcknowledgementid(acknowledgementid);
	}

	//@MethodRef(name = "getDocattachmentflg", signature = "()QBigDecimal;")
	@Test
	public void testGetDocattachmentflg() throws Exception {
		UserAppNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getDocattachmentflg();
	}

	//@MethodRef(name = "setDocattachmentflg", signature = "(QBigDecimal;)V")
	@Test
	public void testSetDocattachmentflg() throws Exception {
		UserAppNotification testSubject;
		BigDecimal docattachmentflg = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setDocattachmentflg(docattachmentflg);
	}

	//@MethodRef(name = "getExpirydate", signature = "()QTimestamp;")
	@Test
	public void testGetExpirydate() throws Exception {
		UserAppNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getExpirydate();
	}

	//@MethodRef(name = "setExpirydate", signature = "(QTimestamp;)V")
	@Test
	public void testSetExpirydate() throws Exception {
		UserAppNotification testSubject;
		Timestamp expirydate = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setExpirydate(expirydate);
	}

	//@MethodRef(name = "getMessagecontent", signature = "()QString;")
	@Test
	public void testGetMessagecontent() throws Exception {
		UserAppNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMessagecontent();
	}

	//@MethodRef(name = "setMessagecontent", signature = "(QString;)V")
	@Test
	public void testSetMessagecontent() throws Exception {
		UserAppNotification testSubject;
		String messagecontent = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMessagecontent(messagecontent);
	}

	//@MethodRef(name = "getMessagetitle", signature = "()QString;")
	@Test
	public void testGetMessagetitle() throws Exception {
		UserAppNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMessagetitle();
	}

	//@MethodRef(name = "setMessagetitle", signature = "(QString;)V")
	@Test
	public void testSetMessagetitle() throws Exception {
		UserAppNotification testSubject;
		String messagetitle = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMessagetitle(messagetitle);
	}

	//@MethodRef(name = "getReaddt", signature = "()QTimestamp;")
	@Test
	public void testGetReaddt() throws Exception {
		UserAppNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getReaddt();
	}

	//@MethodRef(name = "setReaddt", signature = "(QTimestamp;)V")
	@Test
	public void testSetReaddt() throws Exception {
		UserAppNotification testSubject;
		Timestamp readdt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setReaddt(readdt);
	}

	//@MethodRef(name = "getReadsts", signature = "()QBigDecimal;")
	@Test
	public void testGetReadsts() throws Exception {
		UserAppNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getReadsts();
	}

	//@MethodRef(name = "setReadsts", signature = "(QBigDecimal;)V")
	@Test
	public void testSetReadsts() throws Exception {
		UserAppNotification testSubject;
		BigDecimal readsts = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setReadsts(readsts);
	}

	//@MethodRef(name = "getSendattemptcount", signature = "()QBigDecimal;")
	@Test
	public void testGetSendattemptcount() throws Exception {
		UserAppNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendattemptcount();
	}

	//@MethodRef(name = "setSendattemptcount", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendattemptcount() throws Exception {
		UserAppNotification testSubject;
		BigDecimal sendattemptcount = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendattemptcount(sendattemptcount);
	}

	//@MethodRef(name = "getSenddt", signature = "()QTimestamp;")
	@Test
	public void testGetSenddt() throws Exception {
		UserAppNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSenddt();
	}

	//@MethodRef(name = "setSenddt", signature = "(QTimestamp;)V")
	@Test
	public void testSetSenddt() throws Exception {
		UserAppNotification testSubject;
		Timestamp senddt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSenddt(senddt);
	}

	//@MethodRef(name = "getSendsts", signature = "()QBigDecimal;")
	@Test
	public void testGetSendsts() throws Exception {
		UserAppNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendsts();
	}

	//@MethodRef(name = "setSendsts", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendsts() throws Exception {
		UserAppNotification testSubject;
		BigDecimal sendsts = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendsts(sendsts);
	}

	//@MethodRef(name = "getTargetdeviceid", signature = "()QString;")
	@Test
	public void testGetTargetdeviceid() throws Exception {
		UserAppNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getTargetdeviceid();
	}

	//@MethodRef(name = "setTargetdeviceid", signature = "(QString;)V")
	@Test
	public void testSetTargetdeviceid() throws Exception {
		UserAppNotification testSubject;
		String targetdeviceid = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setTargetdeviceid(targetdeviceid);
	}

	//@MethodRef(name = "getUserNotification", signature = "()QUserNotification;")
	@Test
	public void testGetUserNotification() throws Exception {
		UserAppNotification testSubject;
		UserNotification result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserNotification();
	}

	//@MethodRef(name = "setUserNotification", signature = "(QUserNotification;)V")
	@Test
	public void testSetUserNotification() throws Exception {
		UserAppNotification testSubject;
		UserNotification userNotification = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserNotification(userNotification);
	}
}