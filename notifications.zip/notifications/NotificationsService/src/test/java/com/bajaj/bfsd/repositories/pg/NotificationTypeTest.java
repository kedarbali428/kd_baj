package com.bajaj.bfsd.repositories.pg;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Generated;

import org.junit.Test;

import com.bajaj.bfsd.repositories.pg.NotfChannelSubscription;
import com.bajaj.bfsd.repositories.pg.NotificationType;
import com.bajaj.bfsd.repositories.pg.UserNotification;

@Generated(value = "org.junit-tools-1.1.0")
public class NotificationTypeTest {

	private NotificationType createTestSubject() {
		return new NotificationType();
	}

	//@MethodRef(name = "getNotificationtypekey", signature = "()J")
	@Test
	public void testGetNotificationtypekey() throws Exception {
		NotificationType testSubject;
		long result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotificationtypekey();
	}

	//@MethodRef(name = "setNotificationtypekey", signature = "(J)V")
	@Test
	public void testSetNotificationtypekey() throws Exception {
		NotificationType testSubject;
		long notificationtypekey = 11223;

		// default test
		testSubject = createTestSubject();
		testSubject.setNotificationtypekey(notificationtypekey);
	}

	//@MethodRef(name = "getIsactive", signature = "()QBigDecimal;")
	@Test
	public void testGetIsactive() throws Exception {
		NotificationType testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getIsactive();
	}

	//@MethodRef(name = "setIsactive", signature = "(QBigDecimal;)V")
	@Test
	public void testSetIsactive() throws Exception {
		NotificationType testSubject;
		BigDecimal isactive = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setIsactive(isactive);
	}

	//@MethodRef(name = "getLstupdateby", signature = "()QString;")
	@Test
	public void testGetLstupdateby() throws Exception {
		NotificationType testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getLstupdateby();
	}

	//@MethodRef(name = "setLstupdateby", signature = "(QString;)V")
	@Test
	public void testSetLstupdateby() throws Exception {
		NotificationType testSubject;
		String lstupdateby = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setLstupdateby(lstupdateby);
	}

	//@MethodRef(name = "getLstupdatedt", signature = "()QTimestamp;")
	@Test
	public void testGetLstupdatedt() throws Exception {
		NotificationType testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getLstupdatedt();
	}

	//@MethodRef(name = "setLstupdatedt", signature = "(QTimestamp;)V")
	@Test
	public void testSetLstupdatedt() throws Exception {
		NotificationType testSubject;
		Timestamp lstupdatedt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setLstupdatedt(lstupdatedt);
	}

	//@MethodRef(name = "getNotificationtypecode", signature = "()QString;")
	@Test
	public void testGetNotificationtypecode() throws Exception {
		NotificationType testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotificationtypecode();
	}

	//@MethodRef(name = "setNotificationtypecode", signature = "(QString;)V")
	@Test
	public void testSetNotificationtypecode() throws Exception {
		NotificationType testSubject;
		String notificationtypecode = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setNotificationtypecode(notificationtypecode);
	}

	//@MethodRef(name = "getNotificationtypedesc", signature = "()QString;")
	@Test
	public void testGetNotificationtypedesc() throws Exception {
		NotificationType testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotificationtypedesc();
	}

	//@MethodRef(name = "setNotificationtypedesc", signature = "(QString;)V")
	@Test
	public void testSetNotificationtypedesc() throws Exception {
		NotificationType testSubject;
		String notificationtypedesc = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setNotificationtypedesc(notificationtypedesc);
	}

	//@MethodRef(name = "getNotfChannelSubscriptions", signature = "()QList<QNotfChannelSubscription;>;")
	@Test
	public void testGetNotfChannelSubscriptions() throws Exception {
		NotificationType testSubject;
		List<NotfChannelSubscription> result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getNotfChannelSubscriptions();
	}

	//@MethodRef(name = "setNotfChannelSubscriptions", signature = "(QList<QNotfChannelSubscription;>;)V")
	@Test
	public void testSetNotfChannelSubscriptions() throws Exception {
		NotificationType testSubject;
		List<NotfChannelSubscription> notfChannelSubscriptions = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setNotfChannelSubscriptions(notfChannelSubscriptions);
	}

	//@MethodRef(name = "getUserNotfSubscriptions", signature = "()QList<QUserNotfSubscription;>;")
	/*@Test
	public void testGetUserNotfSubscriptions() throws Exception {
		NotificationType testSubject;
		List<UserNotfSubscription> result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserNotfSubscriptions();
	}

	//@MethodRef(name = "setUserNotfSubscriptions", signature = "(QList<QUserNotfSubscription;>;)V")
	@Test
	public void testSetUserNotfSubscriptions() throws Exception {
		NotificationType testSubject;
		List<UserNotfSubscription> userNotfSubscriptions = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserNotfSubscriptions(userNotfSubscriptions);
	}*/

	//@MethodRef(name = "getUserNotifications", signature = "()QList<QUserNotification;>;")
	@Test
	public void testGetUserNotifications() throws Exception {
		NotificationType testSubject;
		List<UserNotification> result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserNotifications();
	}

	//@MethodRef(name = "setUserNotifications", signature = "(QList<QUserNotification;>;)V")
	@Test
	public void testSetUserNotifications() throws Exception {
		NotificationType testSubject;
		List<UserNotification> userNotifications = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserNotifications(userNotifications);
	}

	//@MethodRef(name = "getTriggertypecode", signature = "()QBigDecimal;")
	@Test
	public void testGetTriggertypecode() throws Exception {
		NotificationType testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getTriggertypecode();
	}

	//@MethodRef(name = "setTriggertypecode", signature = "(QBigDecimal;)V")
	@Test
	public void testSetTriggertypecode() throws Exception {
		NotificationType testSubject;
		BigDecimal triggertypecode = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setTriggertypecode(triggertypecode);
	}
}