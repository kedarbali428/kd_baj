package com.bajaj.bfsd.notificationsservice.bean;

import java.util.List;

import javax.annotation.Generated;

import org.junit.Test;

import com.bajaj.bfsd.common.domain.ResponseBean;


public class NotificationBulkResponseTest {

	private NotificationBulkResponse createTestSubject() {
		return new NotificationBulkResponse();
	}

	//@MethodRef(name = "getBulkResponse", signature = "()QList<QResponseBean;>;")
	@Test
	public void testGetBulkResponse() throws Exception {
		NotificationBulkResponse testSubject;
		List<ResponseBean> result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getBulkResponse();
	}

	//@MethodRef(name = "setBulkResponse", signature = "(QList<QResponseBean;>;)V")
	@Test
	public void testSetBulkResponse() throws Exception {
		NotificationBulkResponse testSubject;
		List<ResponseBean> bulkResponse = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setBulkResponse(bulkResponse);
	}
}