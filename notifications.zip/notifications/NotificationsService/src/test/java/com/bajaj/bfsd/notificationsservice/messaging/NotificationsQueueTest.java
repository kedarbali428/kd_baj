package com.bajaj.bfsd.notificationsservice.messaging;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import javax.jms.JMSException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;

@RunWith(SpringJUnit4ClassRunner.class)
public class NotificationsQueueTest {
	
	@InjectMocks
	NotificationsQueue notificationsQueue;
	
	@Mock
	Environment env;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	AwsClientWrapper messageQueueWrapper;
	
	
	@Test(expected=BFLTechnicalException.class)
	public void testSendMessageToQueue(){
		notificationsQueue.sendMessageToQueue(new NotificationsRequest(), "queue");
	}
	
	@Test(expected=BFLTechnicalException.class)
	public void testSendMessageToQueue_NullInput(){
		when(messageQueueWrapper.getProducer(any())).thenThrow(JsonProcessingException.class);
		notificationsQueue.sendMessageToQueue(null, "queue");
	}

	@Test(expected=BFLTechnicalException.class)
	public void testSendMessageToQueue_NullQueueName(){
		when(messageQueueWrapper.getProducer(any())).thenThrow(JMSException.class);
		notificationsQueue.sendMessageToQueue(null, "queue");
	}
}
