package com.bajaj.bfsd.notificationsservice.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.junit.Test;

/**
 * The test case class for UserNotificationConsentBean.
 * 
 */

public class UserNotificationConsentBeanTest {
	
	private UserNotificationConsentBean createTestSubject() {
		return new UserNotificationConsentBean();
	}
	
	@Test
	public void getUsernotifconsentkey() throws Exception{
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.getUsernotifconsentkey();
		
	}
	
	@Test
	public void setUsernotifconsentkey() throws Exception {
		long usernotifconsentkey = 1L;
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setUsernotifconsentkey(usernotifconsentkey);
	}

	@Test
	public void getCnsentflg() throws Exception{
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.getCnsentflg();
	
	}

	@Test
	public void setCnsentflg() throws Exception{
		BigDecimal cnsentflg =  new BigDecimal(1);
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setCnsentflg(cnsentflg);
	}

	@Test
	public void getConsentChannel() throws Exception{
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.getConsentChannel();
	}

	@Test
	public void setConsentChannel( ) throws Exception{
		String consentChannel =  "";
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setConsentChannel(consentChannel);
	}

	@Test
	public void getConsentIp() throws Exception{
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.getConsentIp();
	}

	@Test
	public void setConsentIp() throws Exception{
		String consentIp =  "";
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setConsentIp(consentIp);
	}

	@Test
	public void getConsentProviderType() throws Exception{
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.getConsentProviderType();
	}

	@Test
	public void setConsentProviderType() throws Exception{
		String consentProviderType =  "";
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setConsentProviderType(consentProviderType);
	}

	@Test
	public void getConsentUrl() throws Exception{
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.getConsentUrl();
	}

	@Test
	public void setConsentUrl() throws Exception{
		String consentUrl =  "";
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setConsentUrl(consentUrl);
	}

	@Test
	public void  getConsentdt() throws Exception{
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.getConsentdt();
	}

	@Test
	public void setConsentdt() throws Exception{
		Timestamp consentdt = null;
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setConsentdt(consentdt);
	}

	@Test
	public void getConsentsource() throws Exception{
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.getConsentsource();
	}

	@Test
	public void setConsentsource() throws Exception{
		String consentsource = "";
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setConsentsource(consentsource);
	}

	@Test
	public void  getConsentsourceid() throws Exception{
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.getConsentsourceid();
	}

	@Test
	public void setConsentsourceid() throws Exception{
		String consentsourceid= "";
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setConsentsourceid(consentsourceid);
	}

	@Test
	public void  getDeviceId() throws Exception{
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.getDeviceId();
	}

	@Test
	public void setDeviceId() throws Exception{
		String deviceId= "";
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setDeviceId(deviceId);
	}

	@Test
	public void  getEmail() throws Exception{
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.getEmail();
	}

	@Test
	public void setEmail( )throws Exception {
		String email= "";
		UserNotificationConsentBean ub =null;
		ub = createTestSubject();
		ub.setEmail(email);
	}

	@Test
	public void getLsupdatedt() throws Exception{
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.getLsupdatedt();
	}

	@Test
	public void setLsupdatedt() throws Exception {
		Timestamp lsupdatedt =  null;
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.setLsupdatedt(lsupdatedt);
	}

	@Test
	public void  getMobileno() throws Exception{
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.getMobileno();
	}

	@Test
	public void setMobileno() throws Exception{
		String mobileno =  "";
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.setMobileno(mobileno);
	}

	@Test
	public void getRevokedt() throws Exception{
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.getRevokedt();
	}

	@Test
	public void setRevokedt() throws Exception{
		Timestamp revokedt=  null;
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.setRevokedt(revokedt);
	}

	@Test
	public void  getUserkey() throws Exception{
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.getUserkey();
	}

	@Test
	public void setUserkey() throws Exception{
		BigDecimal userkey =  new BigDecimal(1);
		UserNotificationConsentBean ub = null;
		ub = createTestSubject();
		ub.setUserkey(userkey);
	}

}