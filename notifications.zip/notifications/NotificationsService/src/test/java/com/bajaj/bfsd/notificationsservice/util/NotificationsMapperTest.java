package com.bajaj.bfsd.notificationsservice.util;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.notificationsservice.bean.NotificationsRequest;
import com.bajaj.bfsd.notificationsservice.dao.NotificationsServiceDao;
import com.bajaj.bfsd.notificationsservice.messaging.AwsClientWrapper;
import com.bajaj.bfsd.notificationsservice.messaging.NotificationsQueue;
import com.bajaj.bfsd.repositories.pg.NotfChannelSubscription;
import com.bajaj.bfsd.repositories.pg.NotfChannelType;
import com.bajaj.bfsd.repositories.pg.NotificationType;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;

@RunWith(SpringJUnit4ClassRunner.class)
public class NotificationsMapperTest {

	@InjectMocks
	NotificationsMapper notificationsMapper;
	
	@Mock
	Environment env;
	
	@Mock
	private NotificationsServiceDao notificationsServiceDao;
	
	@Mock
	private NotificationsQueue notificationsQueue;
	
	@Mock
	private CustomDefaultHeaders customheaders;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	AwsClientWrapper awsClientWrapper;
	
	Map<String, Object> templateDataMap;
	
	NotificationsRequest notificationsRequest;
	
	NotificationType notificationType;
	
	NotfChannelSubscription notfChannelSubscription;
	
	NotfChannelType notfchanneltypekey;
	
	@Before
	public void setUp(){
		templateDataMap = new HashMap<>();
		notificationsRequest = new NotificationsRequest();
		notificationType = new NotificationType();
		notfChannelSubscription = new NotfChannelSubscription();
		notfChannelSubscription.setTemplateid(NotificationsServiceConstans.OTP_TYPE_CODE);
		notfchanneltypekey= new NotfChannelType();
	}
	
	@Test
	public void testNotificationSend_highPrioritySms(){
		
		templateDataMap.put(NotificationsServiceConstans.PHONENUMBER, "0123456789"); 
		notificationsRequest.setTemplateDataMap(templateDataMap);
		notificationsRequest.setChannelCode("Name");
		notificationsRequest.setNotificationGroupCode("Name"); 
		notificationType.setNotificationtypecode(NotificationsServiceConstans.OTP_TYPE_CODE);
		notfchanneltypekey.setIsactive(BigDecimal.ONE);
		notfchanneltypekey.setChannelcode(NotificationsServiceConstans.SMS_CHANNEL);
		notfChannelSubscription.setNotfchanneltypekey(notfchanneltypekey);
		when(notificationsServiceDao.getNotfChanelSubscriptionByChannelCode(any(),any())).thenReturn(notfChannelSubscription);
		assertNotNull(notificationsMapper.notificationSend(notificationType, notificationsRequest));
	}
	
	@Test
	public void testNotificationSend_Sms(){
		
		templateDataMap.put(NotificationsServiceConstans.PHONENUMBER, "0123456789"); 
		notificationsRequest.setTemplateDataMap(templateDataMap);
		notificationsRequest.setChannelCode("Name");
		notificationsRequest.setNotificationGroupCode("Name"); 
		notificationType.setNotificationtypecode("Name");
		notfchanneltypekey.setIsactive(BigDecimal.ONE);
		notfchanneltypekey.setChannelcode(NotificationsServiceConstans.SMS_CHANNEL);
		notfChannelSubscription.setNotfchanneltypekey(notfchanneltypekey);
		when(notificationsServiceDao.getNotfChanelSubscriptionByChannelCode(any(),any())).thenReturn(notfChannelSubscription);
		assertNotNull(notificationsMapper.notificationSend(notificationType, notificationsRequest));
	}
	
	@Test
	public void testNotificationSend_Email(){
		
		templateDataMap.put(NotificationsServiceConstans.MAILID, "abc@gmail.com"); 
		notificationsRequest.setTemplateDataMap(templateDataMap);
		notificationsRequest.setChannelCode("Name");
		notificationsRequest.setNotificationGroupCode("Name"); 
		notificationType.setNotificationtypecode("Name");
		notfchanneltypekey.setIsactive(BigDecimal.ONE);
		notfchanneltypekey.setChannelcode(NotificationsServiceConstans.EMAIL_CHANNEL);
		notfChannelSubscription.setNotfchanneltypekey(notfchanneltypekey);
		when(notificationsServiceDao.getNotfChanelSubscriptionByChannelCode(any(),any())).thenReturn(notfChannelSubscription);
		assertNotNull(notificationsMapper.notificationSend(notificationType, notificationsRequest));
	}
	
	@Test
	public void testNotificationSend_App(){
		
		templateDataMap.put(NotificationsServiceConstans.USERKEY, "1");
		templateDataMap.put(NotificationsServiceConstans.APPTYPE, "1");
		notificationsRequest.setTemplateDataMap(templateDataMap);
		notificationsRequest.setChannelCode("Name");
		notificationsRequest.setNotificationGroupCode("Name"); 
		notificationType.setNotificationtypecode("Name");
		notfchanneltypekey.setIsactive(BigDecimal.ONE);
		notfchanneltypekey.setChannelcode(NotificationsServiceConstans.APP_CHANNEL);
		notfChannelSubscription.setNotfchanneltypekey(notfchanneltypekey);
		when(notificationsServiceDao.getNotfChanelSubscriptionByChannelCode(any(),any())).thenReturn(notfChannelSubscription);
		when(notificationsServiceDao.retrieveDeviceAppRegistrationAppLink(any(),any())).thenReturn("Name");
		assertNotNull(notificationsMapper.notificationSend(notificationType, notificationsRequest));
	}
	
	@Test
	public void testNotificationSend_WhatsApp(){
		
		templateDataMap.put(NotificationsServiceConstans.PHONENUMBER, "0123456789"); 
		notificationsRequest.setTemplateDataMap(templateDataMap);
		notificationsRequest.setChannelCode("Name");
		notificationsRequest.setNotificationGroupCode("Name"); 
		notificationType.setNotificationtypecode("Name");
		notfchanneltypekey.setIsactive(BigDecimal.ONE);
		notfchanneltypekey.setChannelcode(NotificationsServiceConstans.WHATSAPP_CHANNEL);
		notfChannelSubscription.setNotfchanneltypekey(notfchanneltypekey);
		when(notificationsServiceDao.getNotfChanelSubscriptionByChannelCode(any(),any())).thenReturn(notfChannelSubscription);
		assertNotNull(notificationsMapper.notificationSend(notificationType, notificationsRequest));
	}
	
	@Test
	public void testNotificationSend_Web(){
		
		templateDataMap.put(NotificationsServiceConstans.PHONENUMBER, "0123456789"); 
		notificationsRequest.setTemplateDataMap(templateDataMap);
		notificationsRequest.setChannelCode("Name");
		notificationsRequest.setNotificationGroupCode("Name"); 
		notificationType.setNotificationtypecode("Name");
		notfchanneltypekey.setIsactive(BigDecimal.ONE);
		notfchanneltypekey.setChannelcode(NotificationsServiceConstans.WEB_CHANNEL);
		notfChannelSubscription.setNotfchanneltypekey(notfchanneltypekey);
		when(notificationsServiceDao.getNotfChanelSubscriptionByChannelCode(any(),any())).thenReturn(notfChannelSubscription);
		assertNotNull(notificationsMapper.notificationSend(notificationType, notificationsRequest));
	}
	
	@Test
	public void testNotificationSend_Sms_ExceptionOccurred(){
		 
		notificationsRequest.setTemplateDataMap(templateDataMap);
		notificationsRequest.setChannelCode("Name");
		notificationsRequest.setNotificationGroupCode("Name"); 
		notificationType.setNotificationtypecode("Name");
		notfchanneltypekey.setIsactive(BigDecimal.ONE);
		notfchanneltypekey.setChannelcode(NotificationsServiceConstans.SMS_CHANNEL);
		notfChannelSubscription.setNotfchanneltypekey(notfchanneltypekey);
		when(notificationsServiceDao.getNotfChanelSubscriptionByChannelCode(any(),any())).thenReturn(notfChannelSubscription);
		assertNotNull(notificationsMapper.notificationSend(notificationType, notificationsRequest));
	}
	
	@Test
	public void testNotificationSend_NoGroupCode(){
		
		templateDataMap.put(NotificationsServiceConstans.PHONENUMBER, "0123456789"); 
		notificationsRequest.setTemplateDataMap(templateDataMap);
		notificationsRequest.setChannelCode("Name");
		notificationsRequest.setNotificationGroupCode(null); 
		notificationType.setNotificationtypecode("Name");
		notfchanneltypekey.setIsactive(BigDecimal.ONE);
		notfchanneltypekey.setChannelcode(NotificationsServiceConstans.SMS_CHANNEL);
		notfChannelSubscription.setNotfchanneltypekey(notfchanneltypekey);
		List<NotfChannelSubscription> notfChannelSubscriptions = new ArrayList<>();
		notfChannelSubscriptions.add(notfChannelSubscription);
		notificationType.setNotfChannelSubscriptions(notfChannelSubscriptions);
		when(notificationsServiceDao.getNotfChanelSubscriptionByChannelCode(any(),any())).thenReturn(notfChannelSubscription);
		assertNotNull(notificationsMapper.notificationSend(notificationType, notificationsRequest));
	}
	
}
