package com.bajaj.bfsd.repositories.pg;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.annotation.Generated;

import org.junit.Test;

import com.bajaj.bfsd.repositories.pg.UserNotification;
import com.bajaj.bfsd.repositories.pg.UserWebNotification;

@Generated(value = "org.junit-tools-1.1.0")
public class UserWebNotificationTest {

	private UserWebNotification createTestSubject() {
		return new UserWebNotification();
	}

	//@MethodRef(name = "getUserwebnotfkey", signature = "()J")
	@Test
	public void testGetUserwebnotfkey() throws Exception {
		UserWebNotification testSubject;
		long result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserwebnotfkey();
	}

	//@MethodRef(name = "setUserwebnotfkey", signature = "(J)V")
	@Test
	public void testSetUserwebnotfkey() throws Exception {
		UserWebNotification testSubject;
		long userwebnotfkey = 7867876;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserwebnotfkey(userwebnotfkey);
	}

	//@MethodRef(name = "getDocattachmentflg", signature = "()QBigDecimal;")
	@Test
	public void testGetDocattachmentflg() throws Exception {
		UserWebNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getDocattachmentflg();
	}

	//@MethodRef(name = "setDocattachmentflg", signature = "(QBigDecimal;)V")
	@Test
	public void testSetDocattachmentflg() throws Exception {
		UserWebNotification testSubject;
		BigDecimal docattachmentflg = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setDocattachmentflg(docattachmentflg);
	}

	//@MethodRef(name = "getExpirydate", signature = "()QTimestamp;")
	@Test
	public void testGetExpirydate() throws Exception {
		UserWebNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getExpirydate();
	}

	//@MethodRef(name = "setExpirydate", signature = "(QTimestamp;)V")
	@Test
	public void testSetExpirydate() throws Exception {
		UserWebNotification testSubject;
		Timestamp expirydate = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setExpirydate(expirydate);
	}

	//@MethodRef(name = "getMessagecontent", signature = "()QString;")
	@Test
	public void testGetMessagecontent() throws Exception {
		UserWebNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMessagecontent();
	}

	//@MethodRef(name = "setMessagecontent", signature = "(QString;)V")
	@Test
	public void testSetMessagecontent() throws Exception {
		UserWebNotification testSubject;
		String messagecontent = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMessagecontent(messagecontent);
	}

	//@MethodRef(name = "getMessagetitle", signature = "()QString;")
	@Test
	public void testGetMessagetitle() throws Exception {
		UserWebNotification testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMessagetitle();
	}

	//@MethodRef(name = "setMessagetitle", signature = "(QString;)V")
	@Test
	public void testSetMessagetitle() throws Exception {
		UserWebNotification testSubject;
		String messagetitle = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMessagetitle(messagetitle);
	}

	//@MethodRef(name = "getReaddt", signature = "()QTimestamp;")
	@Test
	public void testGetReaddt() throws Exception {
		UserWebNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getReaddt();
	}

	//@MethodRef(name = "setReaddt", signature = "(QTimestamp;)V")
	@Test
	public void testSetReaddt() throws Exception {
		UserWebNotification testSubject;
		Timestamp readdt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setReaddt(readdt);
	}

	//@MethodRef(name = "getReadsts", signature = "()QBigDecimal;")
	@Test
	public void testGetReadsts() throws Exception {
		UserWebNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getReadsts();
	}

	//@MethodRef(name = "setReadsts", signature = "(QBigDecimal;)V")
	@Test
	public void testSetReadsts() throws Exception {
		UserWebNotification testSubject;
		BigDecimal readsts = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setReadsts(readsts);
	}

	//@MethodRef(name = "getResponsedt", signature = "()QTimestamp;")
	@Test
	public void testGetResponsedt() throws Exception {
		UserWebNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getResponsedt();
	}

	//@MethodRef(name = "setResponsedt", signature = "(QTimestamp;)V")
	@Test
	public void testSetResponsedt() throws Exception {
		UserWebNotification testSubject;
		Timestamp responsedt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setResponsedt(responsedt);
	}

	//@MethodRef(name = "getResponsests", signature = "()QBigDecimal;")
	@Test
	public void testGetResponsests() throws Exception {
		UserWebNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getResponsests();
	}

	//@MethodRef(name = "setResponsests", signature = "(QBigDecimal;)V")
	@Test
	public void testSetResponsests() throws Exception {
		UserWebNotification testSubject;
		BigDecimal responsests = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setResponsests(responsests);
	}

	//@MethodRef(name = "getSendattemptcount", signature = "()QBigDecimal;")
	@Test
	public void testGetSendattemptcount() throws Exception {
		UserWebNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendattemptcount();
	}

	//@MethodRef(name = "setSendattemptcount", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendattemptcount() throws Exception {
		UserWebNotification testSubject;
		BigDecimal sendattemptcount = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendattemptcount(sendattemptcount);
	}

	//@MethodRef(name = "getSenddt", signature = "()QTimestamp;")
	@Test
	public void testGetSenddt() throws Exception {
		UserWebNotification testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSenddt();
	}

	//@MethodRef(name = "setSenddt", signature = "(QTimestamp;)V")
	@Test
	public void testSetSenddt() throws Exception {
		UserWebNotification testSubject;
		Timestamp senddt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSenddt(senddt);
	}

	//@MethodRef(name = "getSendsts", signature = "()QBigDecimal;")
	@Test
	public void testGetSendsts() throws Exception {
		UserWebNotification testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendsts();
	}

	//@MethodRef(name = "setSendsts", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendsts() throws Exception {
		UserWebNotification testSubject;
		BigDecimal sendsts = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendsts(sendsts);
	}

	//@MethodRef(name = "getUserNotification", signature = "()QUserNotification;")
	@Test
	public void testGetUserNotification() throws Exception {
		UserWebNotification testSubject;
		UserNotification result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserNotification();
	}

	//@MethodRef(name = "setUserNotification", signature = "(QUserNotification;)V")
	@Test
	public void testSetUserNotification() throws Exception {
		UserWebNotification testSubject;
		UserNotification userNotification = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserNotification(userNotification);
	}
}