package com.bajaj.bfsd.notificationsservice.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.junit.Test;


public class NotificationDetailsBeanTest {

	private NotificationDetailsBean createTestSubject() {
		return new NotificationDetailsBean();
	}

	//@MethodRef(name = "getReaddate", signature = "()QString;")
	@Test
	public void testGetReaddate() throws Exception {
		NotificationDetailsBean testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getReaddate();
	}

	//@MethodRef(name = "setReaddate", signature = "(QString;)V")
	@Test
	public void testSetReaddate() throws Exception {
		NotificationDetailsBean testSubject;
		String readdate = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setReaddate(readdate);
	}

	//@MethodRef(name = "getResponsedate", signature = "()QString;")
	@Test
	public void testGetResponsedate() throws Exception {
		NotificationDetailsBean testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getResponsedate();
	}

	//@MethodRef(name = "setResponsedate", signature = "(QString;)V")
	@Test
	public void testSetResponsedate() throws Exception {
		NotificationDetailsBean testSubject;
		String responsedate = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setResponsedate(responsedate);
	}

	//@MethodRef(name = "getExpirydates", signature = "()QString;")
	@Test
	public void testGetExpirydates() throws Exception {
		NotificationDetailsBean testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getExpirydates();
	}

	//@MethodRef(name = "setExpirydates", signature = "(QString;)V")
	@Test
	public void testSetExpirydates() throws Exception {
		NotificationDetailsBean testSubject;
		String expirydates = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setExpirydates(expirydates);
	}

	//@MethodRef(name = "getUserNoteId", signature = "()J")
	@Test
	public void testGetUserNoteId() throws Exception {
		NotificationDetailsBean testSubject;
		long result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getUserNoteId();
	}

	//@MethodRef(name = "setUserNoteId", signature = "(J)V")
	@Test
	public void testSetUserNoteId() throws Exception {
		NotificationDetailsBean testSubject;
		long userNoteId = 12345;

		// default test
		testSubject = createTestSubject();
		testSubject.setUserNoteId(userNoteId);
	}

	//@MethodRef(name = "getSenddt", signature = "()QString;")
	@Test
	public void testGetSenddt() throws Exception {
		NotificationDetailsBean testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSenddt();
	}

	//@MethodRef(name = "setSenddt", signature = "(QString;)V")
	@Test
	public void testSetSenddt() throws Exception {
		NotificationDetailsBean testSubject;
		String senddt = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setSenddt(senddt);
	}

	//@MethodRef(name = "getReadsts", signature = "()QBigDecimal;")
	@Test
	public void testGetReadsts() throws Exception {
		NotificationDetailsBean testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getReadsts();
	}

	//@MethodRef(name = "setReadsts", signature = "(QBigDecimal;)V")
	@Test
	public void testSetReadsts() throws Exception {
		NotificationDetailsBean testSubject;
		BigDecimal readsts = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setReadsts(readsts);
	}

	//@MethodRef(name = "getResponsests", signature = "()QBigDecimal;")
	@Test
	public void testGetResponsests() throws Exception {
		NotificationDetailsBean testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getResponsests();
	}

	//@MethodRef(name = "setResponsests", signature = "(QBigDecimal;)V")
	@Test
	public void testSetResponsests() throws Exception {
		NotificationDetailsBean testSubject;
		BigDecimal responsests = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setResponsests(responsests);
	}

	//@MethodRef(name = "getReaddt", signature = "()QTimestamp;")
	@Test
	public void testGetReaddt() throws Exception {
		NotificationDetailsBean testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getReaddt();
	}

	//@MethodRef(name = "setReaddt", signature = "(QTimestamp;)V")
	@Test
	public void testSetReaddt() throws Exception {
		NotificationDetailsBean testSubject;
		Timestamp readdt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setReaddt(readdt);
	}

	//@MethodRef(name = "getResponsedt", signature = "()QTimestamp;")
	@Test
	public void testGetResponsedt() throws Exception {
		NotificationDetailsBean testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getResponsedt();
	}

	//@MethodRef(name = "setResponsedt", signature = "(QTimestamp;)V")
	@Test
	public void testSetResponsedt() throws Exception {
		NotificationDetailsBean testSubject;
		Timestamp responsedt = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setResponsedt(responsedt);
	}

	//@MethodRef(name = "getSendsts", signature = "()QBigDecimal;")
	@Test
	public void testGetSendsts() throws Exception {
		NotificationDetailsBean testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendsts();
	}

	//@MethodRef(name = "setSendsts", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendsts() throws Exception {
		NotificationDetailsBean testSubject;
		BigDecimal sendsts = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendsts(sendsts);
	}

	//@MethodRef(name = "getSendattemptcount", signature = "()QBigDecimal;")
	@Test
	public void testGetSendattemptcount() throws Exception {
		NotificationDetailsBean testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getSendattemptcount();
	}

	//@MethodRef(name = "setSendattemptcount", signature = "(QBigDecimal;)V")
	@Test
	public void testSetSendattemptcount() throws Exception {
		NotificationDetailsBean testSubject;
		BigDecimal sendattemptcount = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setSendattemptcount(sendattemptcount);
	}

	//@MethodRef(name = "getExpirydate", signature = "()QTimestamp;")
	@Test
	public void testGetExpirydate() throws Exception {
		NotificationDetailsBean testSubject;
		Timestamp result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getExpirydate();
	}

	//@MethodRef(name = "setExpirydate", signature = "(QTimestamp;)V")
	@Test
	public void testSetExpirydate() throws Exception {
		NotificationDetailsBean testSubject;
		Timestamp expirydate = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setExpirydate(expirydate);
	}

	//@MethodRef(name = "getMsgstorerefnum", signature = "()QString;")
	@Test
	public void testGetMsgstorerefnum() throws Exception {
		NotificationDetailsBean testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMsgstorerefnum();
	}

	//@MethodRef(name = "setMsgstorerefnum", signature = "(QString;)V")
	@Test
	public void testSetMsgstorerefnum() throws Exception {
		NotificationDetailsBean testSubject;
		String msgstorerefnum = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMsgstorerefnum(msgstorerefnum);
	}

	//@MethodRef(name = "getDocattachmentflg", signature = "()QBigDecimal;")
	@Test
	public void testGetDocattachmentflg() throws Exception {
		NotificationDetailsBean testSubject;
		BigDecimal result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getDocattachmentflg();
	}

	//@MethodRef(name = "setDocattachmentflg", signature = "(QBigDecimal;)V")
	@Test
	public void testSetDocattachmentflg() throws Exception {
		NotificationDetailsBean testSubject;
		BigDecimal docattachmentflg = null;

		// default test
		testSubject = createTestSubject();
		testSubject.setDocattachmentflg(docattachmentflg);
	}

	//@MethodRef(name = "getMessagetitle", signature = "()QString;")
	@Test
	public void testGetMessagetitle() throws Exception {
		NotificationDetailsBean testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMessagetitle();
	}

	//@MethodRef(name = "setMessagetitle", signature = "(QString;)V")
	@Test
	public void testSetMessagetitle() throws Exception {
		NotificationDetailsBean testSubject;
		String messagetitle = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMessagetitle(messagetitle);
	}

	//@MethodRef(name = "getMessagecontent", signature = "()QString;")
	@Test
	public void testGetMessagecontent() throws Exception {
		NotificationDetailsBean testSubject;
		String result;

		// default test
		testSubject = createTestSubject();
		result = testSubject.getMessagecontent();
	}

	//@MethodRef(name = "setMessagecontent", signature = "(QString;)V")
	@Test
	public void testSetMessagecontent() throws Exception {
		NotificationDetailsBean testSubject;
		String messagecontent = "";

		// default test
		testSubject = createTestSubject();
		testSubject.setMessagecontent(messagecontent);
	}
}