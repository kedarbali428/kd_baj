package com.bajaj.bfsd.mailmodule;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.mailmodule.bean.EmailDetails;
import com.bajaj.bfsd.mailmodule.bean.EmailRequestBean;
import com.bajaj.bfsd.mailmodule.bean.FalconideInputBean;
import com.bajaj.bfsd.mailmodule.bean.MailBody;
import com.bajaj.bfsd.mailmodule.bean.NotificationsRequest;
import com.bajaj.bfsd.mailmodule.bean.Settings;
import com.bajaj.bfsd.mailmodule.dao.MailModuleDao;
import com.bajaj.bfsd.repositories.pg.NotificationRecipientsAcl;
import com.bajaj.bfsd.repositories.pg.UserEmailNotification;
import com.bajaj.bfsd.repositories.pg.UserNotification;
import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.Validator;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.rule.impl.GetterMustExistRule;
import com.openpojo.validation.rule.impl.SetterMustExistRule;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;

@RunWith(SpringJUnit4ClassRunner.class)
public class NotificationRecipientsCfgTest {
	
	@InjectMocks
	NotificationRecipientsCfg notificationRecipientsCfg;

	@Mock
	CacheManager cacheManager;
	
	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	private MailModuleDao mailModuleDao;
	
	@Before
	public void setup(){
		ReflectionTestUtils.setField(notificationRecipientsCfg, "notificationReceipientsAclCheckEnabled", true);
	}
	
	private List<NotificationRecipientsAcl> getNotificationRecipientsAcl() {
		List<NotificationRecipientsAcl> notificationRecipients = new ArrayList<NotificationRecipientsAcl>();
		NotificationRecipientsAcl notificationRecipientsAcl = new NotificationRecipientsAcl();
		notificationRecipientsAcl.setMobile("test@gmail.com");
		notificationRecipientsAcl.setAccess("ALLOW");
		notificationRecipients.add(notificationRecipientsAcl);
		return notificationRecipients;
	}
	
	@Test
	public void isNotificationAllow() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("test@gmail.com", "ALLOW");
		Cache kyc_type_cache = Mockito.mock(Cache.class);
		Cache.ValueWrapper valueWrapper = Mockito.mock(Cache.ValueWrapper.class);		 
		Mockito.when(cacheManager.getCache(Mockito.any())).thenReturn(kyc_type_cache);
		Mockito.when(kyc_type_cache.get(0)).thenReturn(valueWrapper);
		Mockito.when(valueWrapper.get()).thenReturn(map);
		Mockito.when(mailModuleDao.getNotificationRecipientsAcl()).thenReturn(getNotificationRecipientsAcl());
		notificationRecipientsCfg.isNotificationAllow("test@gmail.com");
	}
	@Test
	public void validateBean() {

	    Validator validator = ValidatorBuilder.create()
                .with(new SetterMustExistRule(),
                      new GetterMustExistRule())
                .with(new SetterTester(),
                      new GetterTester())
                .build();
		List<PojoClass> beansList = new ArrayList<>();
	    beansList.add(PojoClassFactory.getPojoClass(EmailDetails.class));
	    beansList.add(PojoClassFactory.getPojoClass(EmailRequestBean.class));
	    beansList.add(PojoClassFactory.getPojoClass(FalconideInputBean.class));
	    beansList.add(PojoClassFactory.getPojoClass(MailBody.class));
	    beansList.add(PojoClassFactory.getPojoClass(NotificationsRequest.class));
	    beansList.add(PojoClassFactory.getPojoClass(UserEmailNotification.class));
	    beansList.add(PojoClassFactory.getPojoClass(UserNotification.class));
	    beansList.add(PojoClassFactory.getPojoClass(com.bajaj.bfsd.mailmodule.model.UserNotification.class));
	    beansList.add(PojoClassFactory.getPojoClass(com.bajaj.bfsd.mailmodule.model.UserEmailNotification.class));
	    beansList.add(PojoClassFactory.getPojoClass(NotificationRecipientsAcl.class));
	    beansList.add(PojoClassFactory.getPojoClass(Settings.class));
	    validator.validate(beansList);
	}
	
}
