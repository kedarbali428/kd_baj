package com.bajaj.bfsd.mailmodule;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.apache.velocity.Template;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.mailmodule.bean.EmailRequestBean;
import com.bajaj.bfsd.mailmodule.bean.MailBody;
import com.bajaj.bfsd.mailmodule.bean.NotificationsRequest;
import com.bajaj.bfsd.mailmodule.model.UserEmailNotification;
import com.bajaj.bfsd.mailmodule.model.UserNotification;
import com.bajaj.bfsd.mailmodule.service.AwsClientWrapper;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringJUnit4ClassRunner.class)
public class SendMailTest {

	@Mock
	BFLCommonRestClient bflClient;
	
	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	private Environment env;
	
	@Mock
	VelocityEngine velocityEngine;
	
	@Mock
	AwsClientWrapper awsClientWrapper;
	
	@Mock
	NotificationRecipientsCfg notificationRecipientsCfg;
	
	@InjectMocks
	SendMail sendMail;
	
	@Test(expected=Exception.class)
	public void testProcessAndSendEmail(){
		NotificationsRequest notificationsRequest = new NotificationsRequest();
		Map<String, Object> templateDataMap = new HashMap<>();
		templateDataMap.put(NotificationMailModuleConstant.RECIPIENTEMAILID, "abc@gmail.com");
		templateDataMap.put(NotificationMailModuleConstant.BCCRECIPIENTS, "abc@gmail.com");
		templateDataMap.put(NotificationMailModuleConstant.ATTACHMENTLINK, "abc@gmail.com");
		notificationsRequest.setTemplateDataMap(templateDataMap);
		Template template = Mockito.mock(Template.class);
		when(velocityEngine.getTemplate(any())).thenReturn(template);
		Mockito.doNothing().when(template).merge(any(), any());
		sendMail.processAndSendEmail(notificationsRequest);
	}
	
	@Test(expected=Exception.class)
	public void testProcessAndSendEmail_ExceptionOccurred(){
		NotificationsRequest notificationsRequest = new NotificationsRequest();
		Map<String, Object> templateDataMap = new HashMap<>();
		templateDataMap.put(NotificationMailModuleConstant.RECIPIENTEMAILID, "abc@gmail.com");
		templateDataMap.put(NotificationMailModuleConstant.BCCRECIPIENTS, "abc@gmail.com");
		templateDataMap.put(NotificationMailModuleConstant.ATTACHMENTLINK, "abc@gmail.com");
		notificationsRequest.setTemplateDataMap(templateDataMap);
		Template template = Mockito.mock(Template.class);
		when(velocityEngine.getTemplate(any())).thenThrow(ResourceNotFoundException.class);
		Mockito.doNothing().when(template).merge(any(), any());
		sendMail.processAndSendEmail(notificationsRequest);
	}
	
	@Test(expected=Exception.class)
	public void testProcessAndSendEmail_ParseException(){
		NotificationsRequest notificationsRequest = new NotificationsRequest();
		Map<String, Object> templateDataMap = new HashMap<>();
		templateDataMap.put(NotificationMailModuleConstant.RECIPIENTEMAILID, "abc@gmail.com");
		templateDataMap.put(NotificationMailModuleConstant.BCCRECIPIENTS, "abc@gmail.com");
		templateDataMap.put(NotificationMailModuleConstant.ATTACHMENTLINK, "abc@gmail.com");
		notificationsRequest.setTemplateDataMap(templateDataMap);
		Template template = Mockito.mock(Template.class);
		when(velocityEngine.getTemplate(any())).thenThrow(ParseErrorException.class);
		Mockito.doNothing().when(template).merge(any(), any());
		sendMail.processAndSendEmail(notificationsRequest);
	}
	
	@Test
	public void testSendEmail(){
		EmailRequestBean mailRequest = new EmailRequestBean();
		mailRequest.setRecipientEmailId("dummy@bajaj.com");
		mailRequest.setMailBody(new MailBody());
		when(bflClient.postForEntity(any(), any(), any(),any(),any(),any())).thenReturn(new ResponseEntity(new ResponseBean("SUCCESS"), HttpStatus.OK));
		when(notificationRecipientsCfg.isNotificationAllow(any())).thenReturn(true);
		assertEquals("Success", sendMail.sendEmail(mailRequest));
	}
	
	@Test(expected=BFLTechnicalException.class)
	public void testSendEmail_ExceptionOccurred(){
		EmailRequestBean mailRequest = new EmailRequestBean();
		mailRequest.setMailBody(new MailBody());
		mailRequest.setAttachmentLink("dummy");
		when(bflClient.postForEntity(any(), any(), any(),any(),any(),any())).thenReturn(new ResponseEntity(new ResponseBean("SUCCESS"), HttpStatus.OK));
		when(notificationRecipientsCfg.isNotificationAllow(any())).thenReturn(true);
		sendMail.sendEmail(mailRequest);
	}
	
	@Test
	public void testSendEmailProxy() {
		UserEmailNotification userEmailNotification = new UserEmailNotification();
		ReflectionTestUtils.setField(sendMail, "isproxyRequired", "Y");
		ReflectionTestUtils.setField(sendMail, "proxyAddress", "");
		ReflectionTestUtils.setField(sendMail, "port", "8080");
		EmailRequestBean mailRequest = new EmailRequestBean();
		mailRequest.setRecipientEmailId("dummy@bajaj.com");
		MailBody mailBody = new MailBody();
		mailBody.setBody("");
		mailBody.setSubject("");
		mailRequest.setMailBody(mailBody);
		userEmailNotification.setDocattachmentflg(BigDecimal.ONE);
		userEmailNotification.setEmailid("");
		userEmailNotification.setExpirydate(new Timestamp(System.currentTimeMillis()));
		userEmailNotification.setMessagetitle("");
		userEmailNotification.setReaddt(new Timestamp(System.currentTimeMillis()));
		userEmailNotification.setReadsts(BigDecimal.ONE);
		userEmailNotification.setResponsests(BigDecimal.ONE);
		userEmailNotification.setSendattemptcount(BigDecimal.ONE);
		userEmailNotification.setSendsts(BigDecimal.ONE);
		userEmailNotification.setUseremailnotfkey(1l);
		UserNotification userNotification = new UserNotification();
		userNotification.setDocattachmentflg(BigDecimal.ONE);
		userNotification.setNotfsource("");
		userNotification.setNotificationtypekey(1l);
		userNotification.setRaisedbyuserkey(BigDecimal.ONE);
		userNotification.setUserkey(BigDecimal.ONE);
		userNotification.setUsernotfkey(1l);
		userEmailNotification.setUserNotification(userNotification);
		when(bflClient.postForEntity(any(), any(), any(), any(), any(), any()))
				.thenReturn(new ResponseEntity(new ResponseBean("SUCCESS"), HttpStatus.OK));
		when(notificationRecipientsCfg.isNotificationAllow(any())).thenReturn(true);
		assertEquals("Success", sendMail.sendEmail(mailRequest));
	}
}
