package com.bajaj.bfsd.mailmodule;

import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;
import javax.jms.JMSException;
import javax.jms.TextMessage;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.mailmodule.bean.EmailRequestBean;
import com.bajaj.bfsd.mailmodule.bean.MailBody;
import com.bajaj.bfsd.mailmodule.bean.NotificationsRequest;
import com.bajaj.bfsd.mailmodule.dao.MailModuleDao;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
public class ReceiverCallbackTest {
	
	@Mock
	private Environment env;
	
	@Mock
	private MailModuleDao mailModuleDao;
	
	@Mock
	SendMail sendMail;	
	
	@InjectMocks
	ReceiverCallback receiverCallback;

	@Test
	public void testonMessage() throws JsonProcessingException, JMSException{
		ObjectMapper mapper = new ObjectMapper();
		NotificationsRequest notificationsRequest= new NotificationsRequest();
		notificationsRequest.setUserKey(1L);
		String text = mapper.writeValueAsString(notificationsRequest);
		TextMessage txtMessage = Mockito.mock(TextMessage.class);
		EmailRequestBean emailRequestBean = new EmailRequestBean();
		emailRequestBean.setStatus(NotificationMailModuleConstant.SUCCESS);
		emailRequestBean.setMailBody(new MailBody());
		when(txtMessage.getText()).thenReturn(text);
		when(sendMail.processAndSendEmail((any()))).thenReturn(emailRequestBean);
		receiverCallback.onMessage(txtMessage);
	}
	
	@Test(expected=BFLTechnicalException.class)
	public void testonMessage_JMSExceptionOccurred() throws JsonProcessingException, JMSException{
		ObjectMapper mapper = new ObjectMapper();
		NotificationsRequest notificationsRequest= new NotificationsRequest();
		notificationsRequest.setUserKey(1L);
		String text = mapper.writeValueAsString(notificationsRequest);
		TextMessage txtMessage = Mockito.mock(TextMessage.class);
		EmailRequestBean emailRequestBean = new EmailRequestBean();
		emailRequestBean.setStatus(NotificationMailModuleConstant.SUCCESS);
		when(txtMessage.getText()).thenReturn(text);
		when(sendMail.processAndSendEmail(any())).thenThrow(JMSException.class);
		receiverCallback.onMessage(txtMessage);
	}
	
	@Test(expected=BFLTechnicalException.class)
	public void testonMessage_ExceptionOccurred() throws JsonProcessingException, JMSException{
		ObjectMapper mapper = new ObjectMapper();
		NotificationsRequest notificationsRequest= new NotificationsRequest();
		notificationsRequest.setUserKey(1L);
		String text = mapper.writeValueAsString(notificationsRequest);
		TextMessage txtMessage = Mockito.mock(TextMessage.class);
		EmailRequestBean emailRequestBean = new EmailRequestBean();
		emailRequestBean.setStatus(NotificationMailModuleConstant.SUCCESS);
		when(txtMessage.getText()).thenReturn(text);
		when(sendMail.processAndSendEmail(any())).thenThrow(Exception.class);
		receiverCallback.onMessage(txtMessage);
	}

}
