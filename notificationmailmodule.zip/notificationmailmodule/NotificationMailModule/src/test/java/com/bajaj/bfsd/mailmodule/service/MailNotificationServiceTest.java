package com.bajaj.bfsd.mailmodule.service;

import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.Session;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.amazon.sqs.javamessaging.SQSConnection;
import com.bajaj.bfsd.mailmodule.ReceiverCallback;

@RunWith(SpringJUnit4ClassRunner.class)
public class MailNotificationServiceTest {
	
	@InjectMocks
	MailNotificationService mailNotificationService;
	
	@Mock
	Environment env;
	
	@Mock
	SQSConnection sqsConnection;
	
	@Mock
	ReceiverCallback receiverCallback;
	
	@Test
	public void testProcessNotifications() throws JMSException{
		Session session = Mockito.mock(Session.class);
		Queue queue = Mockito.mock(Queue.class);
		MessageConsumer consumer = Mockito.mock(MessageConsumer.class);
		Mockito.when(sqsConnection.createSession(false, Session.CLIENT_ACKNOWLEDGE)).thenReturn(session);
		Mockito.when(session.createQueue(null)).thenReturn(queue);
		Mockito.when(session.createConsumer(queue)).thenReturn(consumer);
		mailNotificationService.processNotifications();
	}
	
	@Test(expected=Exception.class)
	public void testProcessNotificationsWithFailure() throws JMSException{
		Session session = Mockito.mock(Session.class);
		Queue queue = Mockito.mock(Queue.class);
		MessageConsumer consumer = Mockito.mock(MessageConsumer.class);
		Mockito.when(sqsConnection.createSession(false, Session.CLIENT_ACKNOWLEDGE)).thenThrow(JMSException.class);
		Mockito.when(session.createQueue(null)).thenReturn(queue);
		Mockito.when(session.createConsumer(queue)).thenReturn(consumer);
		mailNotificationService.processNotifications();
	}
	
	@Test
	public void testCloseResources(){
		mailNotificationService.closeResources();
	}
	
	@Test(expected=Exception.class)
	public void testCloseResourcesWithFailure() throws JMSException{
		Mockito.doThrow(JMSException.class).when(sqsConnection).close();
		mailNotificationService.closeResources();
	}
	
	@Test
	public void testRun() throws Exception{
		Session session = Mockito.mock(Session.class);
		Queue queue = Mockito.mock(Queue.class);
		MessageConsumer consumer = Mockito.mock(MessageConsumer.class);
		Mockito.when(sqsConnection.createSession(false, Session.CLIENT_ACKNOWLEDGE)).thenReturn(session);
		Mockito.when(session.createQueue(null)).thenReturn(queue);
		Mockito.when(session.createConsumer(queue)).thenReturn(consumer);
		mailNotificationService.run(null);
	}

}
