package com.bajaj.bfsd.smsmodule.dao.impl;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.mailmodule.dao.impl.MailModuleDaoImpl;
import com.bajaj.bfsd.repositories.pg.NotificationRecipientsAcl;
import com.bajaj.bfsd.repositories.pg.UserNotification;
import com.bfl.common.exceptions.BFLBusinessException;

@RunWith(SpringJUnit4ClassRunner.class)
public class MailModuleDaoImplTest {

	@Mock
	EntityManager entityManager;
	
	@Mock
	private Environment env;
	
	@Mock
	BFLLoggerUtil logger;
	
	@InjectMocks
	MailModuleDaoImpl mailModuleDaoImpl;
	
	@Test
	public void testSaveUserNotification(){
		UserNotification userNotification = new UserNotification();
		when(entityManager.merge(any())).thenReturn(userNotification);
		mailModuleDaoImpl.saveUserNotification(userNotification);
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testSaveUserNotification_ExceptionOccurred(){
		when(entityManager.merge(any())).thenThrow(Exception.class);
		mailModuleDaoImpl.saveUserNotification(new UserNotification());
	}
	
	
		
	
	
}
