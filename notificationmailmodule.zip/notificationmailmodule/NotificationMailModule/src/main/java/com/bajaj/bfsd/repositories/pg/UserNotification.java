package com.bajaj.bfsd.repositories.pg;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

/**
 * The persistent class for the "USER_NOTIFICATIONS" database table.
 * 
 */
@Entity
@Table(name = "\"USER_NOTIFICATIONS\"", schema = "\"ORGSYSNOTF\"")
//@NamedQuery(name = "UserNotification.findAll", query = "SELECT u FROM UserNotification u")
public class UserNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "\"USERNOTFKEY\"")
	@SequenceGenerator(name="USER_NOTIFICATIONS_GENERATOR", sequenceName="\"ORGSYSNOTF\".\"USER_NOTIFICATIONS_PK_SEQ\"",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_NOTIFICATIONS_GENERATOR")
	private long usernotfkey;

	@Column(name = "\"DOCATTACHMENTFLG\"")
	private Integer docattachmentflg;

	@Column(name = "\"NOTFSOURCE\"")
	private String notfsource;
	
	@Column(name = "\"NOTIFICATIONTYPEKEY\"")
	private Long notificationtypekey;
	
	@Column(name = "\"APPLICATIONKEY\"")
	private Long applicationkey;

	/*
	 * @ManyToOne
	 * 
	 * @JoinColumn(name="\"NOTIFICATIONTYPEKEY\"") private NotificationType
	 * notificationtypekey;
	 */
	// bi-directional many-to-one association to UserAppNotification
	//bi-directional many-to-one association to UserEmailNotification
	@OneToMany(mappedBy="userNotification",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<UserEmailNotification> userEmailNotifications;
	
	@Column(name = "\"RAISEDBYUSERKEY\"")
	private BigDecimal raisedbyuserkey;

	@Column(name = "\"RAISEDT\"")
	private Timestamp raisedt;

	@Column(name = "\"USERKEY\"")
	private BigDecimal userkey;

	public UserNotification() {
	}

	public long getUsernotfkey() {
		return this.usernotfkey;
	}

	public void setUsernotfkey(long usernotfkey) {
		this.usernotfkey = usernotfkey;
	}

	public Integer getDocattachmentflg() {
		return this.docattachmentflg;
	}

	public void setDocattachmentflg(Integer docattachmentflg) {
		this.docattachmentflg = docattachmentflg;
	}

	public String getNotfsource() {
		return this.notfsource;
	}

	public void setNotfsource(String notfsource) {
		this.notfsource = notfsource;
	}

	public List<UserEmailNotification> getUserEmailNotifications() {
		return userEmailNotifications;
	}

	public void setUserEmailNotifications(List<UserEmailNotification> userEmailNotifications) {
		this.userEmailNotifications = userEmailNotifications;
	}

	public BigDecimal getRaisedbyuserkey() {
		return this.raisedbyuserkey;
	}

	public void setRaisedbyuserkey(BigDecimal raisedbyuserkey) {
		this.raisedbyuserkey = raisedbyuserkey;
	}

	public Timestamp getRaisedt() {
		return this.raisedt;
	}

	public void setRaisedt(Timestamp raisedt) {
		this.raisedt = raisedt;
	}

	public BigDecimal getUserkey() {
		return this.userkey;
	}

	public void setUserkey(BigDecimal userkey) {
		this.userkey = userkey;
	}

	public Long getNotificationtypekey() {
		return notificationtypekey;
	}

	public void setNotificationtypekey(Long notificationtypekey) {
		this.notificationtypekey = notificationtypekey;
	}

	/**
	 * @return the applicationkey
	 */
	public Long getApplicationkey() {
		return applicationkey;
	}

	/**
	 * @param applicationkey the applicationkey to set
	 */
	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}
	
}