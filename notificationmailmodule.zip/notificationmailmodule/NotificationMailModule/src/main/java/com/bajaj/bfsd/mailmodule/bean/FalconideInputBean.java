package com.bajaj.bfsd.mailmodule.bean;

import java.util.List;
import java.util.Map;

public class FalconideInputBean {
	
	private String api_key;
	private EmailDetails email_details;
	private String encoding_type;
	private List<String> recipients;
	private List<String> recipients_cc;
	private Settings settings;
	private Map files;
	
	public String getApi_key() {
		return api_key;
	}
	public void setApi_key(String api_key) {
		this.api_key = api_key;
	}
	public EmailDetails getEmail_details() {
		return email_details;
	}
	public void setEmail_details(EmailDetails email_details) {
		this.email_details = email_details;
	}
	public String getEncoding_type() {
		return encoding_type;
	}
	public void setEncoding_type(String encoding_type) {
		this.encoding_type = encoding_type;
	}
	public List<String> getRecipients() {
		return recipients;
	}
	public void setRecipients(List<String> recipients) {
		this.recipients = recipients;
	}
	public List<String> getRecipients_cc() {
		return recipients_cc;
	}
	public void setRecipients_cc(List<String> recipients_cc) {
		this.recipients_cc = recipients_cc;
	}
	public Settings getSettings() {
		return settings;
	}
	public void setSettings(Settings settings) {
		this.settings = settings;
	}
	public Map getFiles() {
		return files;
	}
	public void setFiles(Map files) {
		this.files = files;
	}
	

}
