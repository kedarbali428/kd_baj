package com.bajaj.bfsd.mailmodule.service;

import javax.annotation.PreDestroy;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.amazon.sqs.javamessaging.SQSConnection;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.mailmodule.ReceiverCallback;
import com.bfl.common.exceptions.BFLTechnicalException;

@RefreshScope
@Component
public class MailNotificationService implements ApplicationRunner{
	
	@Value("${aws.sqs.mail.queue}")
	String queueName;	

	private static final String THIS_CLASS = MailNotificationService.class.getCanonicalName();
	
	@Autowired
	Environment env;
	
	@Autowired
	SQSConnection sqsConnection;
	
	@Autowired
	ReceiverCallback receiverCallback;
	
	public void processNotifications(){
		BFLLoggerUtil.debug("MailNotificationService", THIS_CLASS, BFLLoggerComponent.SERVICE, "in processNotification()");
		Session session;
		try {
			session = sqsConnection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
			MessageConsumer consumer = session.createConsumer(session.createQueue(queueName));
			
			consumer.setMessageListener(receiverCallback);
			sqsConnection.start();
		} catch (JMSException e) {
			BFLLoggerUtil.error("processNotifications Method", THIS_CLASS, BFLLoggerComponent.SERVICE, "Error configuring JMS listener: " + e);
			throw new BFLTechnicalException("NOTM-8505", env.getProperty("NOTM-8505"));
		}		
	}


	@Override
	public void run(ApplicationArguments args) throws Exception {
		processNotifications();
	}	
	
	@PreDestroy
	public void closeResources(){
		try {
			sqsConnection.close();
		} catch (JMSException e) {
			BFLLoggerUtil.error("closeResources Method", THIS_CLASS, BFLLoggerComponent.SERVICE, "Error releasing SQS connection: " + e);
			throw new BFLTechnicalException("NOTM-8506", env.getProperty("NOTM-8506"));
		}
	}	
}
