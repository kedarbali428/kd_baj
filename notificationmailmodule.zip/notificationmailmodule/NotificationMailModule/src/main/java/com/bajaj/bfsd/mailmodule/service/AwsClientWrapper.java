package com.bajaj.bfsd.mailmodule.service;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

@Component
@RefreshScope
public class AwsClientWrapper {

	@Value("${aws.s3.region}")
	private String region;
	
	private AmazonS3 amazonS3;
	
	public AmazonS3 getAmazonS3() {
		return amazonS3;
	}
	
	@PostConstruct
	public void initAwsClient(){
		amazonS3 = AmazonS3ClientBuilder.standard().withRegion(region).build();
	}
}
