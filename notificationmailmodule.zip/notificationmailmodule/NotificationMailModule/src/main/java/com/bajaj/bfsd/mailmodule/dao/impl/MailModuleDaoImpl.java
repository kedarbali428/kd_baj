// * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.

package com.bajaj.bfsd.mailmodule.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.AbstractQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.mailmodule.NotificationMailModuleConstant;
import com.bajaj.bfsd.mailmodule.dao.MailModuleDao;
import com.bajaj.bfsd.repositories.pg.NotificationRecipientsAcl;
import com.bajaj.bfsd.repositories.pg.UserNotification;
import com.bfl.common.exceptions.BFLBusinessException;

/**
 * This class is Implementation class for Notification Helper DAO.
 * 
 * @author 493757
 * 
 *         Version BugId UsrId Date Description 1.0 493757 16/11/2016 Initial
 *         Version
 *
 */
@Component
public class MailModuleDaoImpl implements MailModuleDao {

	private static final String CLASS = MailModuleDaoImpl.class.getName();

	@Autowired
	EntityManager entityManager;
	
	@Autowired
	private Environment env;

	@Autowired
	BFLLoggerUtil logger;

	@Override
	//@Scope(proxyMode = ScopedProxyMode.INTERFACES)
	@Transactional
	public UserNotification saveUserNotification(UserNotification userNotification) {
		UserNotification usrNotification = userNotification;
		logger.debug(CLASS, BFLLoggerComponent.DAO, "Inside saveUserNotification Method");
		try {
			usrNotification = entityManager.merge(usrNotification);
		} catch (Exception e) {
			logger.error(CLASS, BFLLoggerComponent.DAO, NotificationMailModuleConstant.NOTM_8611, e);
			throw new BFLBusinessException(NotificationMailModuleConstant.NOTM_8611,
					env.getProperty(NotificationMailModuleConstant.NOTM_8611));
		}
		logger.debug(CLASS, BFLLoggerComponent.DAO, "Completed saveUserNotification Method");
		return usrNotification;
	}

	@Override
	public List<NotificationRecipientsAcl> getNotificationRecipientsAcl() {		
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();  
        AbstractQuery<NotificationRecipientsAcl> abstractQuery = criteriaBuilder.createQuery(NotificationRecipientsAcl.class);  
        Root<NotificationRecipientsAcl> root = abstractQuery.from(NotificationRecipientsAcl.class);  
        abstractQuery.where(criteriaBuilder.in(root.get("isActive")).value(1)) ;  
        abstractQuery.where(criteriaBuilder.in(root.get("access")).value(NotificationMailModuleConstant.ALLOW)) ;
		
        CriteriaQuery<NotificationRecipientsAcl> criteriaQuery = ((CriteriaQuery<NotificationRecipientsAcl>) abstractQuery).select(root);  
        TypedQuery<NotificationRecipientsAcl> typedQuery = entityManager.createQuery(criteriaQuery);  
        return typedQuery.getResultList();  
	}
}
