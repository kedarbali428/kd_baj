package com.bajaj.bfsd.mailmodule;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.cache.CacheBuilder;

@Configuration
@EnableCaching
public class CachingConfig {
	
	@Value("${notification.recipients-acl.cache.expiryInSeconds:86400}")
	private long notificationCacheExpiry = 86400;
	
	@Bean(name="cacheManager") 
	public CacheManager cacheManager() {
		 
		ConcurrentMapCacheManager concurrentMapCacheManager = new ConcurrentMapCacheManager() {
			@Override
			protected Cache createConcurrentMapCache(final String name) {
				return new ConcurrentMapCache(name, CacheBuilder.newBuilder().expireAfterWrite(notificationCacheExpiry, TimeUnit.SECONDS)
						.build().asMap(), false);
			}
		};
		  
		concurrentMapCacheManager.setCacheNames(Arrays.asList(NotificationMailModuleConstant.NOTIFICATION_RECIPIENTS_ACL)); 
		return concurrentMapCacheManager; 
	}
}