package com.bajaj.bfsd.repositories.pg;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the "NOTIFICATION_RECIPIENTS_ACL" database table.
 * 
 */
@Entity
@Table(name="\"NOTIFICATION_RECIPIENTS_ACL\"" ,schema="\"ORGSYSNOTF\"")
public class NotificationRecipientsAcl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"NOTIFICATIONRECIPIENTSACLKEY\"")
	@SequenceGenerator(name="NOTIFICATION_RECIPIENTS_ACL_GENERATOR", sequenceName="ORGSYSNOTF.NOTIFICATION_RECIPIENTS_ACL_PK_SEQ",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="NOTIFICATION_RECIPIENTS_ACL_GENERATOR")
	private long notificationRecipientsAlcKey;
	
	@Column(name="\"MOBILE\"")
	private String mobile;

	@Column(name="\"EMAIL\"")
	private String email;
	
	@Column(name="\"ACCESS\"")
	private String access;

	@Column(name="\"ISACTIVE\"")
	private long isActive;

	@Column(name="\"LSTUPDATEBY\"")
	private BigDecimal lstUpdateBy;

	@Column(name="\"LSTUPDATEDT\"")
	private Timestamp lstUpdateDt;
	
	public long getNotificationRecipientsAlcKey() {
		return notificationRecipientsAlcKey;
	}
	public void setNotificationRecipientsAlcKey(long notificationRecipientsAlcKey) {
		this.notificationRecipientsAlcKey = notificationRecipientsAlcKey;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAccess() {
		return access;
	}
	public void setAccess(String access) {
		this.access = access;
	}
	public long getIsActive() {
		return isActive;
	}
	public void setIsActive(long isActive) {
		this.isActive = isActive;
	}
	public BigDecimal getLstUpdateBy() {
		return lstUpdateBy;
	}
	public void setLstUpdateBy(BigDecimal lstUpdateBy) {
		this.lstUpdateBy = lstUpdateBy;
	}
	public Timestamp getLstUpdateDt() {
		return lstUpdateDt;
	}
	public void setLstUpdateDt(Timestamp lstUpdateDt) {
		this.lstUpdateDt = lstUpdateDt;
	}
}