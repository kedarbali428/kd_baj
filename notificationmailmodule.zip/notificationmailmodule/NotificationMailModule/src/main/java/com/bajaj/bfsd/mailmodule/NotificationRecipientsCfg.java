package com.bajaj.bfsd.mailmodule;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.mailmodule.dao.MailModuleDao;
import com.bajaj.bfsd.repositories.pg.NotificationRecipientsAcl;
import com.bajaj.bfsd.repositories.pg.UserNotification;

@Component
public class NotificationRecipientsCfg {

	@Autowired
	BFLLoggerUtil logger;

	@Value("${notification.receipients-acl-check.enabled:false}")
	private boolean notificationReceipientsAclCheckEnabled = false;

	@Autowired
	CacheManager cacheManager;

	@Autowired
	private MailModuleDao mailModuleDao;

	private static final String CLASS = NotificationRecipientsCfg.class.getCanonicalName();
	
	private Map<String, String> buildNotificationRecipientsAclCache() {
		logger.debug(CLASS, BFLLoggerComponent.SERVICE,
				"Start - buildNotificationRecipientsAclCache method");
		Map<String, String> accessMasterMap = null;
		try {
			List<NotificationRecipientsAcl> notificationRecipients = getNotificationRecipientsAcl();
			if (!CollectionUtils.isEmpty(notificationRecipients)) {
				accessMasterMap = notificationRecipients.stream()
						.collect(Collectors.toMap(NotificationRecipientsAcl::getEmail, NotificationRecipientsAcl::getAccess,
								(oldValue, newValue) -> newValue));
				Cache cache = cacheManager.getCache(NotificationMailModuleConstant.NOTIFICATION_RECIPIENTS_ACL);
				cache.put("accessMaster", accessMasterMap);
			} else {
				logger.debug(CLASS, BFLLoggerComponent.SERVICE,
						"buildNotificationRecipientsAlcCache method - notification recipients alc details not found in the database");
			}
		} catch (Exception e) {
			logger.error(CLASS, BFLLoggerComponent.SERVICE,
					"Exception while fetching records for notification recipients alc deatils", e);
		}
		logger.debug(CLASS, BFLLoggerComponent.SERVICE,
				"End - buildNotificationRecipientsAclCache method, accessMasterMap: "+accessMasterMap);
		return accessMasterMap;
	}

	private List<NotificationRecipientsAcl> getNotificationRecipientsAcl() {
		List<NotificationRecipientsAcl> notificationRecipients = null;
		try {
			logger.debug(CLASS, BFLLoggerComponent.SERVICE,
					"Start - getNotificationRecipientsAcl method - fetching records for notification recipients alc deatils");
			notificationRecipients = mailModuleDao.getNotificationRecipientsAcl();
			logger.debug(CLASS, BFLLoggerComponent.SERVICE,
					"End - getNotificationRecipientsAcl method - fetching records for notification recipients alc deatils");
		} catch (Exception e) {
			logger.error(CLASS, BFLLoggerComponent.SERVICE,
					"Exception while fetching records for notification recipients alc deatils", e);
		}
		return notificationRecipients;
	}

	@SuppressWarnings("unchecked")
	public boolean isNotificationAllow(String email) {
		logger.debug(CLASS, BFLLoggerComponent.SERVICE,
				"Start - isNotificationAllow method - email: "+email);
		boolean isAllowed = true;
		if(notificationReceipientsAclCheckEnabled) {
			Cache cache = cacheManager.getCache(NotificationMailModuleConstant.NOTIFICATION_RECIPIENTS_ACL);
			Map<String, String> accessMasterMap = null;
			synchronized(this) {
				accessMasterMap = cache.get("accessMaster", Map.class);
				if(null == accessMasterMap) {
					accessMasterMap = buildNotificationRecipientsAclCache();
				}
			}
			String aclValue = null != accessMasterMap ? accessMasterMap.get(email) : null;
			if(null == aclValue) {
				isAllowed = false;
			}
		}
		logger.debug(CLASS, BFLLoggerComponent.SERVICE,
				"End - isNotificationAllow method, isAllowed: "+isAllowed);
		return isAllowed;
	}
}