package com.bajaj.bfsd.mailmodule;

import java.io.InputStream;
import java.io.StringWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.RequestScoped;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.apache.velocity.runtime.resource.loader.StringResourceLoader;
import org.apache.velocity.runtime.resource.util.StringResourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.BFLCommonClientBean;
import com.bajaj.bfsd.common.domain.ClientProxyBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.mailmodule.bean.EmailDetails;
import com.bajaj.bfsd.mailmodule.bean.EmailRequestBean;
import com.bajaj.bfsd.mailmodule.bean.FalconideInputBean;
import com.bajaj.bfsd.mailmodule.bean.MailBody;
import com.bajaj.bfsd.mailmodule.bean.NotificationsRequest;
import com.bajaj.bfsd.mailmodule.bean.Settings;
import com.bajaj.bfsd.mailmodule.service.AwsClientWrapper;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RefreshScope
@Component
public class SendMail {

	private static final String CLASS_NAME = SendMail.class.getName();

	@Autowired
	BFLCommonRestClient bflClient;

	@Autowired
	@RequestScoped
	BFLLoggerUtil logger;

	@Autowired
	private Environment env;
	
	@Autowired
    VelocityEngine velocityEngine;
	
	@Autowired
	AwsClientWrapper awsClientWrapper;

	@Value("${external.falconide.url}")
	private String falconideUrl;

	@Value("${falconide.api.key}")
	String apiKey;

	@Value("${falconide.senderId.emailverification}")
	String verificationSenderId;

	@Value("${falconide.senderId.notifications}")
	String senderId;

	@Value("${falconide.senderName}")
	String senderName;

	@Value("${proxy.address}")
	private String proxyAddress;

	@Value("${proxy.port}")
	private String port;

	@Value("${proxy.required}")
	private String isproxyRequired;
	
	@Value("${aws.s3.bucket.template}")
	private String bucketName;

	@Value("#{'${unsubscribe.disabled.recipients}'.split(',')}")
	private List<String> unsubscribeRecipientList;
	
	@Autowired
	NotificationRecipientsCfg notificationRecipientsCfg;
		
	public String sendEmail(EmailRequestBean mailRequest) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Calling sendEmail() in SendMail");
		String result = "Failure";
		if(!notificationRecipientsCfg.isNotificationAllow(mailRequest.getRecipientEmailId())) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside sendEmail - mail notification not sent as no record found in the db for mobile "+mailRequest.getRecipientEmailId());
		} else {
			FalconideInputBean falconideInput = prepareInputForFalconide(mailRequest);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			BFLCommonClientBean bean = new BFLCommonClientBean();
			ObjectMapper mapper = new ObjectMapper();
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
	
			try {
				map.add("data", mapper.writeValueAsString(falconideInput));
			} catch (JsonProcessingException e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "sendEmail: Json Parsing exception", e);
				throw new BFLTechnicalException("NOTM-8508", env.getProperty("NOTM-8508"));
			}
			ResponseEntity<?> response = null;
			if ("Y".equals(isproxyRequired)) {
				ClientProxyBean clientProxyBean = new ClientProxyBean();
				clientProxyBean.setProxyAddress(proxyAddress);
				clientProxyBean.setPort(port);
				bean.setClientProxyBean(clientProxyBean);
				response = bflClient.postForEntity(falconideUrl, map, String.class, null, null, bean);
			} else {
				response = bflClient.postForEntity(falconideUrl, map, String.class, null, null, null);
			}
			String falconideRes = "";
			if(null != response) {
				falconideRes = ((ResponseBean) response.getBody()).getPayload().toString();
			}
			if (falconideRes.contains("SUCCESS")) {
				result = "Success";
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Successfully mail sent with response : " + falconideRes);
			} else{
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Error from falconide while sending mail : " + falconideRes);	
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Exit from sendEmail() in SendMail");
		return result;
	}

	/**
	 * @param input
	 * @return CreditVidyaInput
	 */
	private FalconideInputBean prepareInputForFalconide(EmailRequestBean mailRequest) {
		FalconideInputBean falconideInput = new FalconideInputBean();
		falconideInput.setApi_key(apiKey);
		EmailDetails emailDetails = new EmailDetails();
		if ("UJSENDVERIFLINK".equalsIgnoreCase(mailRequest.getNotificationTypeCode())) {
			emailDetails.setFrom(verificationSenderId);
		} else {
			emailDetails.setFrom(senderId);
		}
		if (null != mailRequest.getAttachmentLink()) {
			try {
				URL url = new URL(mailRequest.getAttachmentLink());
				InputStream in = url.openStream();
				byte[] attachment = IOUtils.toByteArray(in);
				byte[] encoded = Base64.encodeBase64(attachment);
				String encodedString = new String(encoded);
				Map<String, String> attachFiles = new HashMap<>();
				attachFiles.put(NotificationMailModuleConstant.ATTACHMENT, encodedString);
				falconideInput.setFiles(attachFiles);
			} catch (Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.DAO,
						"Exception occured while converting attachment into Base64." + e);
				throw new BFLTechnicalException("NOTM-8507", env.getProperty("NOTM-8507"));
			}
		}
		emailDetails.setFromname(senderName);
		emailDetails.setSubject(mailRequest.getMailBody().getSubject());
		emailDetails.setContent(mailRequest.getMailBody().getBody());
		emailDetails.setReplytoid(mailRequest.getRecipientEmailId());
		falconideInput.setEmail_details(emailDetails);
		falconideInput.setEncoding_type("base64");

		List<String> recipients = new ArrayList<>();
		recipients.add(mailRequest.getRecipientEmailId());
		falconideInput.setRecipients(recipients);
		falconideInput.setRecipients_cc(mailRequest.getCcRecipients());
		Settings settings = new Settings();
		settings.setBcc(mailRequest.getBccRecipients());
		if (null != unsubscribeRecipientList && unsubscribeRecipientList.contains(mailRequest.getRecipientEmailId())) {
			settings.setUnsubscribe("0");
		}
		falconideInput.setSettings(settings);
		return falconideInput;
	}
	
	public EmailRequestBean processAndSendEmail(NotificationsRequest notificationsRequest){
		EmailRequestBean emailRequestBean = new EmailRequestBean();
		emailRequestBean.setRecipientEmailId(notificationsRequest.getTemplateDataMap().get(NotificationMailModuleConstant.RECIPIENTEMAILID).toString());
		if(null != notificationsRequest.getTemplateDataMap().get(NotificationMailModuleConstant.CCRECIPIENTS)){
			emailRequestBean.setCcRecipients((ArrayList<String>)notificationsRequest.getTemplateDataMap().get(NotificationMailModuleConstant.CCRECIPIENTS));
		}
		if(null != notificationsRequest.getTemplateDataMap().get(NotificationMailModuleConstant.BCCRECIPIENTS)){
			emailRequestBean.setBccRecipients(notificationsRequest.getTemplateDataMap().get(NotificationMailModuleConstant.BCCRECIPIENTS).toString());
		}
		emailRequestBean.setNotificationTypeCode(notificationsRequest.getNotificationTypeCode());
		MailBody mailBody = new MailBody();
		mailBody.setBody(prepareMessage(notificationsRequest));
		String mailSubject = mailBody.getBody().substring(mailBody.getBody().lastIndexOf(NotificationMailModuleConstant.TITLE) + 7,
				mailBody.getBody().indexOf(NotificationMailModuleConstant.ENDTITLE));
		mailBody.setSubject(mailSubject);
		if(null != notificationsRequest.getTemplateDataMap().get(NotificationMailModuleConstant.ATTACHMENTLINK)){
			emailRequestBean.setAttachmentLink(notificationsRequest.getTemplateDataMap().get(NotificationMailModuleConstant.ATTACHMENTLINK).toString());
		}
		emailRequestBean.setMailBody(mailBody);
		String status = sendEmail(emailRequestBean);
		if(NotificationMailModuleConstant.SUCCESS.equalsIgnoreCase(status)){
			emailRequestBean.setStatus(NotificationMailModuleConstant.SUCCESS);
		}else{
			emailRequestBean.setStatus(NotificationMailModuleConstant.FAILURE);
		}
		return emailRequestBean;
	}
	
	/**
	 * Using the singleton velocity engine object.
	 * Storing the template in cache, if not available in cache then only fetching it from S3. 
	 * @param notificationsRequest
	 * @param templateCode
	 * @return
	 */
	private String prepareMessage(NotificationsRequest notificationsRequest) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside prepareMessage - call Started");
		String message;
		String templateData = null;
		String templateCode = notificationsRequest.getTemplateName();
		Map<String, Object> notificationMap = notificationsRequest.getTemplateDataMap();
		VelocityContext context = new VelocityContext();
		Template template = null;
		try {
			//Fetch template from cache
			template = velocityEngine.getTemplate(templateCode);
		} catch (ResourceNotFoundException resourceNotFoundException) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Template not found in cache so fetching it from S3" + resourceNotFoundException);

			//Fetching template from S3
			try {
				GetObjectRequest getObjectRequest = new GetObjectRequest(bucketName, templateCode);
				S3Object s3Object = awsClientWrapper.getAmazonS3().getObject(getObjectRequest);
				S3ObjectInputStream objectInputStream = s3Object.getObjectContent();
				byte[] attachment = IOUtils.toByteArray(objectInputStream);
				templateData = new String(attachment);
				StringResourceRepository repo = (StringResourceRepository) velocityEngine
						.getApplicationAttribute(StringResourceLoader.REPOSITORY_NAME_DEFAULT);
				repo.putStringResource(templateCode, templateData);

				template = velocityEngine.getTemplate(templateCode);
				objectInputStream.close();
			} catch (Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,"Getting Exception While Fetching template from S3" + e);
				throw new BFLTechnicalException(NotificationMailModuleConstant.NOTM_8608, env.getProperty(NotificationMailModuleConstant.NOTM_8608));
			}

		} catch (ParseErrorException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,"Template cannot be parsed due to syntax (or other) error." + e);
			throw new BFLTechnicalException(NotificationMailModuleConstant.NOTM_8609, env.getProperty(NotificationMailModuleConstant.NOTM_8609));
		}

		context.put("notificationMap", notificationMap);
		
		try(StringWriter writer = new StringWriter()){
			template.merge(context, writer);
			message = writer.toString();
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,"Getting Exception While merging the template with notification map" + e);
			throw new BFLTechnicalException(NotificationMailModuleConstant.NOTM_8610, env.getProperty(NotificationMailModuleConstant.NOTM_8610));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside prepareMessage - call Completed" + message);
		return message;
	}
}