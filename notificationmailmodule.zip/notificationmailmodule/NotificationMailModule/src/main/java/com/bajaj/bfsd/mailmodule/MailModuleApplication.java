package com.bajaj.bfsd.mailmodule;

import java.util.Properties;

import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.StringResourceLoader;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;

import com.bajaj.bfsd.common.business.baseclasses.BFLBusinessApplication;

/**
 * @Description This class starts the Notify service using spring boot
 * 
 * @author 493757
 *
 */
@EntityScan("com.bajaj.bfsd.repositories.pg")
public class MailModuleApplication extends BFLBusinessApplication{
	
	
	public static void main(String args[]){
		SpringApplication.run(MailModuleApplication.class, args);
	}
	
	@Bean
	public VelocityEngine getVelocityEngine(){
		
		Properties properties = new Properties();
		properties.setProperty(RuntimeConstants.RUNTIME_LOG_LOGSYSTEM_CLASS, "org.apache.velocity.runtime.log.Log4JLogChute");
		properties.setProperty( RuntimeConstants.RESOURCE_MANAGER_DEFAULTCACHE_SIZE, "200" );
		properties.setProperty(Velocity.RESOURCE_LOADER, "string");
		properties.setProperty("string.resource.loader.class", StringResourceLoader.class.getName());
		properties.setProperty("string.resource.loader.cache", Boolean.TRUE.toString());
		properties.setProperty("string.resource.loader.modificationCheckInterval", "-1");
		properties.setProperty("string.resource.loader.repository.static", "false");
		
		VelocityEngine engine = new VelocityEngine(properties);
		
		engine.init();
		
		return engine;
	}

}