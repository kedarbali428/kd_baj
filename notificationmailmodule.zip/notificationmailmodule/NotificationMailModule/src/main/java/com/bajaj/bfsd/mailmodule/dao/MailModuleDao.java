/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.mailmodule.dao;

import java.util.List;

import com.bajaj.bfsd.repositories.pg.NotificationRecipientsAcl;
import com.bajaj.bfsd.repositories.pg.UserNotification;

/**
 * This class is Dao interface for Notification Helper services.
 * 
 * @author 493757
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                         493757          16/11/2016      Initial Version
 *
 */
public interface MailModuleDao {
	
	public UserNotification saveUserNotification(UserNotification userNotification);
	public List<NotificationRecipientsAcl> getNotificationRecipientsAcl();
}
