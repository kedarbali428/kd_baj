package com.bajaj.bfsd.mailmodule;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.mailmodule.bean.EmailRequestBean;
import com.bajaj.bfsd.mailmodule.bean.NotificationsRequest;
import com.bajaj.bfsd.mailmodule.dao.MailModuleDao;
import com.bajaj.bfsd.repositories.pg.UserEmailNotification;
import com.bajaj.bfsd.repositories.pg.UserNotification;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ReceiverCallback implements MessageListener {

	@Autowired
	private Environment env;

	@Autowired
	private MailModuleDao mailModuleDao;

	@Autowired
	SendMail sendMail;

	private static final String THIS_CLASS = ReceiverCallback.class.getCanonicalName();

	@SuppressWarnings("deprecation")
	@Override
	public void onMessage(Message message) {
		try {
			BFLLoggerUtil.debug(NotificationMailModuleConstant.ONMESSAGE, THIS_CLASS, BFLLoggerComponent.UTILITY,"Got message " + message.getJMSMessageID());
			NotificationsRequest notificationsRequest = handleMessage(message);
			EmailRequestBean emailRequestBean = sendMail.processAndSendEmail(notificationsRequest);
			if (NotificationMailModuleConstant.SUCCESS.equalsIgnoreCase(emailRequestBean.getStatus())) {
				message.acknowledge();
				mailModuleDao.saveUserNotification(getUserNotification(notificationsRequest, emailRequestBean, BigDecimal.ONE));
			}else {
				mailModuleDao.saveUserNotification(getUserNotification(notificationsRequest, emailRequestBean, BigDecimal.ZERO));
			}
			BFLLoggerUtil.debug(NotificationMailModuleConstant.ONMESSAGE, THIS_CLASS, BFLLoggerComponent.UTILITY,"Email send completed" + emailRequestBean);
		} catch (JMSException e) {
			BFLLoggerUtil.error(NotificationMailModuleConstant.ONMESSAGE, THIS_CLASS, BFLLoggerComponent.UTILITY,"JMSException while processing message: " + e);
			throw new BFLTechnicalException("NOTM-8501", e.getMessage());
		} catch (Exception e) {
			BFLLoggerUtil.error(NotificationMailModuleConstant.ONMESSAGE, THIS_CLASS, BFLLoggerComponent.UTILITY,"Exception while processing message: " + e);
			throw new BFLTechnicalException("NOTM-8502", e.getMessage());
		}
	}

	@SuppressWarnings("deprecation")
	public NotificationsRequest handleMessage(Message message) throws JMSException {
		BFLLoggerUtil.debug(NotificationMailModuleConstant.HANDLEMESSAGE, THIS_CLASS, BFLLoggerComponent.UTILITY,"Got message Id inside handle message " + message.getJMSMessageID());
		NotificationsRequest notificationsRequest = new NotificationsRequest();
		if (message instanceof TextMessage) {
			TextMessage txtMessage = (TextMessage) message;
			String text = txtMessage.getText();
			ObjectMapper mapper = new ObjectMapper();
			try {
				notificationsRequest = mapper.readValue(text, NotificationsRequest.class);
				BFLLoggerUtil.debug(NotificationMailModuleConstant.HANDLEMESSAGE, THIS_CLASS, BFLLoggerComponent.UTILITY,"Got emailRequestBean " + notificationsRequest);
			} catch (IOException e) {
				BFLLoggerUtil.error(NotificationMailModuleConstant.HANDLEMESSAGE, THIS_CLASS, BFLLoggerComponent.UTILITY,"IOException while handleMessage: " + e);
				throw new BFLTechnicalException("NOTM-8503", e.getMessage());
			}
			BFLLoggerUtil.debug(NotificationMailModuleConstant.HANDLEMESSAGE, THIS_CLASS, BFLLoggerComponent.UTILITY,"Got text message " + txtMessage.getText());
		}
		return notificationsRequest;
	}
	
	private UserNotification getUserNotification(NotificationsRequest notificationsRequest,EmailRequestBean emailRequestBean,BigDecimal sendStatus){
		UserNotification userNotification = new UserNotification();
		BigDecimal userKey = BigDecimal.valueOf(null != notificationsRequest.getUserKey() ? notificationsRequest.getUserKey() : 0l);
		userNotification.setUserkey(userKey);
		userNotification.setApplicationkey(notificationsRequest.getApplicationkey());
		userNotification.setNotificationtypekey(notificationsRequest.getNotificationTypeKey());
		userNotification.setRaisedbyuserkey(userKey);
		Timestamp timestamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		userNotification.setRaisedt(timestamp);
		
		UserEmailNotification userEmailNotification = new UserEmailNotification();
		userEmailNotification.setEmailid(emailRequestBean.getRecipientEmailId());
		userEmailNotification.setMessagetitle(emailRequestBean.getMailBody().getSubject());
		userEmailNotification.setSendsts(sendStatus);
		userEmailNotification.setSenddt(timestamp);
		userEmailNotification.setUserNotification(userNotification);
		List<UserEmailNotification> userEmailNotifications = new ArrayList<>(); 
		userEmailNotifications.add(userEmailNotification);
		userNotification.setUserEmailNotifications(userEmailNotifications);
		
		return userNotification;
	}
}
