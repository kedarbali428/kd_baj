package com.bajaj.bfsd.mailmodule.bean;

import java.util.List;

import javax.validation.constraints.NotNull;


public class EmailRequestBean {

	private long userNotificationKey;

	@NotNull(message = "Mail Body should not be null")
	private MailBody mailBody;
	
	@NotNull(message = "Notification Type Code should not be null")
	private String notificationTypeCode;

	@NotNull(message = "RecipientEmailId should not be null")
	private String recipientEmailId;
	
	private List<String> ccRecipients; 
	
	private String attachmentLink;

	private String bccRecipients;
	
	private String retryInfo;
	
	private String status;


	public String getRetryInfo() {
		return retryInfo;
	}

	public void setRetryInfo(String retryInfo) {
		this.retryInfo = retryInfo;
	}

	public String getRecipientEmailId() {
		return recipientEmailId;
	}

	public void setRecipientEmailId(String recipientEmailId) {
		this.recipientEmailId = recipientEmailId;
	}

	public MailBody getMailBody() {
		return mailBody;
	}

	public void setMailBody(MailBody mailBody) {
		this.mailBody = mailBody;
	}

	public long getUserNotificationKey() {
		return userNotificationKey;
	}

	public void setUserNotificationKey(long userNotificationKey) {
		this.userNotificationKey = userNotificationKey;
	}

	public String getAttachmentLink() {
		return attachmentLink;
	}

	public void setAttachmentLink(String attachmentLink) {
		this.attachmentLink = attachmentLink;
	}

	public String getNotificationTypeCode() {
		return notificationTypeCode;
	}

	public void setNotificationTypeCode(String notificationTypeCode) {
		this.notificationTypeCode = notificationTypeCode;
	}

	public List<String> getCcRecipients() {
		return ccRecipients;
	}

	public void setCcRecipients(List<String> ccRecipients) {
		this.ccRecipients = ccRecipients;
	}

	public String getBccRecipients() {
		return bccRecipients;
	}

	public void setBccRecipients(String bccRecipients) {
		this.bccRecipients = bccRecipients;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "EmailRequestBean [userNotificationKey=" + userNotificationKey + ", mailBody=" + mailBody
				+ ", notificationTypeCode=" + notificationTypeCode + ", recipientEmailId=" + recipientEmailId
				+ ", ccRecipients=" + ccRecipients + ", attachmentLink=" + attachmentLink + ", bccRecipients="
				+ bccRecipients + ", retryInfo=" + retryInfo + ", status=" + status + "]";
	}
	
}
