package com.bajaj.bfsd.mailmodule.bean;

public class Settings {
	
	private String bcc;
	private String unsubscribe;

	public String getBcc() {
		return bcc;
	}

	public void setBcc(String bcc) {
		this.bcc = bcc;
	}

	public String getUnsubscribe() {
		return unsubscribe;
	}

	public void setUnsubscribe(String unsubscribe) {
		this.unsubscribe = unsubscribe;
	}
	
}
