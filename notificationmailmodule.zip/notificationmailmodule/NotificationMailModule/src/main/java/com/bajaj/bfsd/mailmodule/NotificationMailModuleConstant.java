package com.bajaj.bfsd.mailmodule;

public class NotificationMailModuleConstant {

	private NotificationMailModuleConstant(){
	}
	
	public static final String HANDLEMESSAGE = "handleMessage method";
	public static final String NOTM_8608 = "NOTM-8608";
	public static final String NOTM_8609 = "NOTM-8609";
	public static final String NOTM_8610 = "NOTM-8610";
	public static final String NOTM_8611 = "NOTM-8611";
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	public static final String RECIPIENTEMAILID= "recipientEmailId";
	public static final String CCRECIPIENTS= "ccRecipients";
	public static final String BCCRECIPIENTS= "bccRecipients";
	public static final String ENDTITLE= "</title>";
	public static final String TITLE = "<title>";
	public static final String ATTACHMENTLINK= "attachmentLink";
	public static final String ONMESSAGE = "onMessage method";
	public static final String NOTS_8612 = "NOTS-8612";
	public static final String NOTIFICATION_RECIPIENTS_ACL = "notification_recipients_acl";
	public static final String ALLOW = "ALLOW";
	public static final String ATTACHMENT = "attachment.pdf";
}
