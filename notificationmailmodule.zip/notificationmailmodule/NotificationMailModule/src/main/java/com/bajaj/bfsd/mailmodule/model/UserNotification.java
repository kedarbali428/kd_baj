package com.bajaj.bfsd.mailmodule.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the USER_NOTIFICATIONS database table.
 * 
 */
@Entity
@Table(name="USER_NOTIFICATIONS")
//@NamedQuery(name="UserNotification.findAll", query="SELECT u FROM UserNotification u")
public class UserNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long usernotfkey;

	private BigDecimal docattachmentflg;
	
	private Long notificationtypekey;

	private String notfsource;
	
	private BigDecimal raisedbyuserkey;

	private Timestamp raisedt;

	private BigDecimal userkey;

	//bi-directional many-to-one association to UserEmailNotification
	@OneToMany(mappedBy="userNotification",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	private List<UserEmailNotification> userEmailNotifications;

	public UserNotification() {
	}

	public long getUsernotfkey() {
		return this.usernotfkey;
	}

	public void setUsernotfkey(long usernotfkey) {
		this.usernotfkey = usernotfkey;
	}

	public BigDecimal getDocattachmentflg() {
		return this.docattachmentflg;
	}

	public void setDocattachmentflg(BigDecimal docattachmentflg) {
		this.docattachmentflg = docattachmentflg;
	}

	public String getNotfsource() {
		return this.notfsource;
	}

	public void setNotfsource(String notfsource) {
		this.notfsource = notfsource;
	}

	public Timestamp getRaisedt() {
		return this.raisedt;
	}

	public void setRaisedt(Timestamp raisedt) {
		this.raisedt = raisedt;
	}

	

	public List<UserEmailNotification> getUserEmailNotifications() {
		return this.userEmailNotifications;
	}

	public void setUserEmailNotifications(List<UserEmailNotification> userEmailNotifications) {
		this.userEmailNotifications = userEmailNotifications;
	}

	public UserEmailNotification addUserEmailNotification(UserEmailNotification userEmailNotification) {
		getUserEmailNotifications().add(userEmailNotification);
		userEmailNotification.setUserNotification(this);

		return userEmailNotification;
	}

	public UserEmailNotification removeUserEmailNotification(UserEmailNotification userEmailNotification) {
		getUserEmailNotifications().remove(userEmailNotification);
		userEmailNotification.setUserNotification(null);

		return userEmailNotification;
	}

	public Long getNotificationtypekey() {
		return notificationtypekey;
	}

	public void setNotificationtypekey(Long notificationtypekey) {
		this.notificationtypekey = notificationtypekey;
	}

	public BigDecimal getRaisedbyuserkey() {
		return raisedbyuserkey;
	}

	public void setRaisedbyuserkey(BigDecimal raisedbyuserkey) {
		this.raisedbyuserkey = raisedbyuserkey;
	}

	public BigDecimal getUserkey() {
		return userkey;
	}

	public void setUserkey(BigDecimal userkey) {
		this.userkey = userkey;
	}

}