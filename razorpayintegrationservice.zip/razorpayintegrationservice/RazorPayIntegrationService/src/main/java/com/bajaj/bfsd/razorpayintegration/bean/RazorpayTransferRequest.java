package com.bajaj.bfsd.razorpayintegration.bean;

import java.math.BigDecimal;

public class RazorpayTransferRequest {
	
	private String productCode;
	private String paymentId;
	private BigDecimal vendorAmount;
	private BigDecimal amount;
	private String applicationId;
	private String vendorTxId;
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	public BigDecimal getVendorAmount() {
		return vendorAmount;
	}
	public void setVendorAmount(BigDecimal vendorAmount) {
		this.vendorAmount = vendorAmount;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getVendorTxId() {
		return vendorTxId;
	}
	public void setVendorTxId(String vendorTxId) {
		this.vendorTxId = vendorTxId;
	}
	@Override
	public String toString() {
		return "RazorpayTransferRequest [productCode=" + productCode + ", paymentId=" + paymentId + ", vendorAmount="
				+ vendorAmount + ", amount=" + amount + ", applicationId=" + applicationId + ", vendorTxId="
				+ vendorTxId + "]";
	}
	
}
