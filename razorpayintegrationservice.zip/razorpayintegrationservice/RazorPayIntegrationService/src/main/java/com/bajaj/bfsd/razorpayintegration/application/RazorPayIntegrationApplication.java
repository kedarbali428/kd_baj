package  com.bajaj.bfsd.razorpayintegration.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

import com.bajaj.bfsd.common.business.baseclasses.BFLBusinessApplication;

@SpringBootApplication
@PropertySources(value = {@PropertySource("classpath:error.properties")})
@EntityScan("com")
public class RazorPayIntegrationApplication extends BFLBusinessApplication{
 
    public static void main(String[] args) {
    	SpringApplication.run(RazorPayIntegrationApplication.class, args);
    }
 
}