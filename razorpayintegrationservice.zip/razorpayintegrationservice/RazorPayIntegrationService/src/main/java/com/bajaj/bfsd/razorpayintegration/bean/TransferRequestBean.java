package com.bajaj.bfsd.razorpayintegration.bean;

import java.util.List;

public class TransferRequestBean {

	private String productCode;
	private String paymentId;
	private List<Transfer> transfers;
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	public List<Transfer> getTransfers() {
		return transfers;
	}
	public void setTransfers(List<Transfer> transfers) {
		this.transfers = transfers;
	}
	@Override
	public String toString() {
		return "TransferRequestBean [productCode=" + productCode + ", paymentId=" + paymentId + ", transfers="
				+ transfers + "]";
	}
}
