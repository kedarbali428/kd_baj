package com.bajaj.bfsd.razorpayintegration.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class SerReqStprazorDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	private long stpreqkey;

	private String accupdatereqrefnum;

	private BigDecimal accupdatestatus;

	private String paytransrefnum;

	private BigDecimal paytransstatus;
	
	private BigDecimal netamount;
	
	private String stpreqattributes;
	
	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String dateflag;


private BigDecimal transstatus;

	public SerReqStprazorDetail() {
	}

	public long getStpreqkey() {
		return this.stpreqkey;
	}

	public void setStpreqkey(long stpreqkey) {
		this.stpreqkey = stpreqkey;
	}

	public String getAccupdatereqrefnum() {
		return this.accupdatereqrefnum;
	}

	public void setAccupdatereqrefnum(String accupdatereqrefnum) {
		this.accupdatereqrefnum = accupdatereqrefnum;
	}

	public BigDecimal getAccupdatestatus() {
		return this.accupdatestatus;
	}

	public void setAccupdatestatus(BigDecimal accupdatestatus) {
		this.accupdatestatus = accupdatestatus;
	}

	public String getPaytransrefnum() {
		return this.paytransrefnum;
	}

	public void setPaytransrefnum(String paytransrefnum) {
		this.paytransrefnum = paytransrefnum;
	}

	public BigDecimal getPaytransstatus() {
		return this.paytransstatus;
	}

	public void setPaytransstatus(BigDecimal paytransstatus) {
		this.paytransstatus = paytransstatus;
	}

	public BigDecimal getNetamount() {
		return netamount;
	}

	public void setNetamount(BigDecimal netamount) {
		this.netamount = netamount;
	}

	public String getStpreqattributes() {
		return stpreqattributes;
	}

	public void setStpreqattributes(String stpreqattributes) {
		this.stpreqattributes = stpreqattributes;
	}

	public String getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getTransstatus() {
		return transstatus;
	}

	public void setTransstatus(BigDecimal transstatus) {
		this.transstatus = transstatus;
	}

	/**
	 * @return the dateflag
	 */
	public String getDateflag() {
		return dateflag;
	}

	/**
	 * @param dateflag the dateflag to set
	 */
	public void setDateflag(String dateflag) {
		this.dateflag = dateflag;
	}
	
	

}