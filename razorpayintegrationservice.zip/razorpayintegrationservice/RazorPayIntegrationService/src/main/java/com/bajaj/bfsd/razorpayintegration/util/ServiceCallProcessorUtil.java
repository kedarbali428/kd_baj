package com.bajaj.bfsd.razorpayintegration.util;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.factory.MapperFactory;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@RefreshScope
@Component
public class ServiceCallProcessorUtil extends BFLComponent {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;
	
	private static final String CLASSNAME = ServiceCallProcessorUtil.class.getName();

	/**
	 * @author 718314
	 * @param responseJson
	 * @param classType
	 * @return Object
	 */
	public Object getResponseObjectFromResponseJsonString(String responseJson, Class<?> classType) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
				"Inside getResponseObjectFromResponseJsonString() in " + CLASSNAME);
		Object responseObject = null;

		if (null != responseJson && !responseJson.isEmpty() && null != classType) {
			ObjectMapper mapper = MapperFactory.getInstance();
			try {
				responseObject = mapper.readValue(responseJson, classType);
			} catch (JsonParseException jpe) {
				logger.error(CLASSNAME, BFLLoggerComponent.DAO,
						"JsonParseException occurred while parsing response json", jpe);
				throw new BFLTechnicalException("CINS-11302", env.getProperty("CINS-11302"));
			} catch (JsonMappingException jme) {
				logger.error(CLASSNAME, BFLLoggerComponent.DAO,
						"JsonMappingException occurred while parsing response json", jme);
				throw new BFLTechnicalException("CINS-11303", env.getProperty("CINS-11303"));
			} catch (IOException ioe) {
				logger.error(CLASSNAME, BFLLoggerComponent.DAO, "IOException occurred while parsing response json",
						ioe);
				throw new BFLTechnicalException("CINS-11304", env.getProperty("CINS-11304"));
			}
		}

		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
				"Exit from getResponseObjectFromResponseJsonString() in " + CLASSNAME);
		return responseObject;
	}

	/**
	 * @Desc This method is used to get current date
	 * @return Date
	 */
	public static Timestamp getCurrentDate() {
		Date date = Calendar.getInstance().getTime();
		return new Timestamp(date.getTime());
	}
	
	public <T> String mapToJson(T object) {
		Gson gson = new Gson();
		return gson.toJson(object);
	}
	
	public <T> String mapToJsonWithNull(T object) {
		GsonBuilder gsonBuilder = new GsonBuilder();  
		gsonBuilder.serializeNulls();  
		Gson gson = gsonBuilder.create();
		return gson.toJson(object);
	}
	
	@SuppressWarnings("unchecked")
	public ResponseBean getResponse(ResponseEntity responseEntity)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		ResponseBean response = null;
		if (responseEntity.getBody() instanceof HashMap) {
			JSONObject jsonObject = getJsonObject(responseEntity.getBody());

			if (null != jsonObject && "SUCCESS".equals(jsonObject.get("status"))) {
				response = new ResponseBean(jsonObject.get("payload"));
			} else if (null != jsonObject && "PARTIAL_SUCCESS".equals(jsonObject.get("status"))) {
				response = new ResponseBean(jsonObject.get("payload"), (List<ErrorBean>) jsonObject.get("errorBean"));
			} else if (null != jsonObject) {
				response = new ResponseBean((List<ErrorBean>) jsonObject.get("errorBean"));
			}
		} else {
			response = mapper.readValue(responseEntity.getBody().toString(), ResponseBean.class);
		}
		return response;
	}
	public JSONObject getJsonObject(Object object) {
		JSONObject jsonObject = new JSONObject();
		try {

			JSONParser parser = new JSONParser();
			if (object instanceof JSONObject) {
				jsonObject = (JSONObject) object;
			} else if (object instanceof LinkedHashMap) {
				jsonObject = new JSONObject((Map) object);
			} else {
				Object obj = parser.parse(object.toString());
				jsonObject = (JSONObject) obj;
			}

		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Error occured while parsing :", e);
		}
		return jsonObject;
	}

	public String prepareRequestJson(Object requestObject) {
		String requestJson = null;
		try {
			ObjectMapper mapper = MapperFactory.getInstance();
			requestJson = mapper.writeValueAsString(requestObject);
		} catch (JsonProcessingException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Error occured while parsing :", e);
		}
		return requestJson;
	}
	
}
