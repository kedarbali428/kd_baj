/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.razorpayintegration.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.google.gson.annotations.Expose;

/**
 * This class holds list of loan account numbers.
 *
 * @author 582602
 * 
 *         Version BugId UsrId Date Description 1.0 582602 20/02/2017 Initial
 *         Version
 */
@JsonInclude(Include.NON_NULL)
public class ServiceRequestDetails implements Serializable {

	/**
	 * Constant for serialVersionUID.
	 */
	private static final long serialVersionUID = 2049568526457943701L;

	/**
	 * Variable to hold value for sr number.
	 */
	@Expose
	private String srNumber;

	/**
	 * Variable to hold value for sr date.
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date srDate;

	/**
	 * Variable to hold value for sr close date.
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date srCloseDate;

	/**
	 * Variable to hold value for sr reopen flag.
	 */
	private Boolean srReopenFlag;
	/**
	 * Variable to hold value for sr description.
	 */
	private String srDescription;

	/**
	 * Variable to hold value for sr status.
	 */
	private String srStatus;

	/**
	 * Variable to hold value for product code.
	 */
	private String productCode;

	/**
	 * Variable to hold value for sub product name.
	 */
	private String subProductCode;

	/**
	 * Variable to hold value for query type.
	 */
	private String queryType;

	/**
	 * Variable to hold value for query sub type.
	 */
	private String querySubType;

	/**
	 * Variable to hold value for product number.
	 */
	private String productNumber;

	private Long srKey;
	
	private BigDecimal serreqcurstatus;
	
	private String refProdNum;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	public String getSrNumber() {
		return srNumber;
	}

	/**
	 * Sets the value of sr number.
	 *
	 * @param srNumber
	 *            the new sr number
	 */
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}

	/**
	 * Getter method for sr date.
	 *
	 * @return sr date
	 */
	public Date getSrDate() {
		return srDate;
	}

	/**
	 * Sets the value of sr date.
	 *
	 * @param srDate
	 *            the new sr date
	 */
	public void setSrDate(Date srDate) {
		this.srDate = srDate;
	}

	/**
	 * Getter method for sr description.
	 *
	 * @return sr description
	 */
	public String getSrDescription() {
		return srDescription;
	}

	/**
	 * Sets the value of sr description.
	 *
	 * @param srDescription
	 *            the new sr description
	 */
	public void setSrDescription(String srDescription) {
		this.srDescription = srDescription;
	}

	/**
	 * Getter method for sr status.
	 *
	 * @return sr status
	 */
	public String getSrStatus() {
		return srStatus;
	}

	/**
	 * Sets the value of sr status.
	 *
	 * @param srStatus
	 *            the new sr status
	 */
	public void setSrStatus(String srStatus) {
		this.srStatus = srStatus;
	}

	/**
	 * Getter method for product code.
	 *
	 * @return product code
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * Sets the value of product code.
	 *
	 * @param productCode
	 *            the new product code
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * Getter method for sub product code.
	 *
	 * @return sub product code
	 */
	public String getSubProductCode() {
		return subProductCode;
	}

	/**
	 * Sets the value of sub product code.
	 *
	 * @param subProductCode
	 *            the new sub product code
	 */
	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	/**
	 * Getter method for sr close date.
	 *
	 * @return sr close date
	 */
	public Date getSrCloseDate() {
		return srCloseDate;
	}

	/**
	 * Sets the value of sr close date.
	 *
	 * @param srCloseDate
	 *            the new sr close date
	 */
	public void setSrCloseDate(Date srCloseDate) {
		this.srCloseDate = srCloseDate;
	}

	/**
	 * Getter method for sr reopen flag.
	 *
	 * @return sr reopen flag
	 */
	public Boolean getSrReopenFlag() {
		return srReopenFlag;
	}

	/**
	 * Sets the value of sr reopen flag.
	 *
	 * @param srReopenFlag
	 *            the new sr reopen flag
	 */
	public void setSrReopenFlag(Boolean srReopenFlag) {
		this.srReopenFlag = srReopenFlag;
	}

	/**
	 * Getter method for query type.
	 *
	 * @return query type
	 */
	public String getQueryType() {
		return queryType;
	}

	/**
	 * Sets the value of query type.
	 *
	 * @param queryType
	 *            the new query type
	 */
	public void setQueryType(String queryType) {
		this.queryType = queryType;
	}

	/**
	 * Getter method for query sub type.
	 *
	 * @return query sub type
	 */
	public String getQuerySubType() {
		return querySubType;
	}

	/**
	 * Sets the value of query sub type.
	 *
	 * @param querySubType
	 *            the new query sub type
	 */
	public void setQuerySubType(String querySubType) {
		this.querySubType = querySubType;
	}

	/**
	 * Getter method for product number.
	 *
	 * @return product number
	 */
	public String getProductNumber() {
		return productNumber;
	}

	/**
	 * Sets the value of product number.
	 *
	 * @param productNumber
	 *            the new product number
	 */
	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}

	
	public Long getSrKey() {
		return srKey;
	}

	public void setSrKey(Long srKey) {
		this.srKey = srKey;
	}
	
	

	public BigDecimal getSerreqcurstatus() {
		return serreqcurstatus;
	}

	public void setSerreqcurstatus(BigDecimal serreqcurstatus) {
		this.serreqcurstatus = serreqcurstatus;
	}

	
	public String getRefProdNum() {
		return refProdNum;
	}

	public void setRefProdNum(String refProdNum) {
		this.refProdNum = refProdNum;
	}

	
	public String getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	@Override
	public String toString() {
		return "ServiceRequestDetails [srNumber=" + srNumber + ", srDate=" + srDate + ", srCloseDate=" + srCloseDate
				+ ", srReopenFlag=" + srReopenFlag + ", srDescription=" + srDescription + ", srStatus=" + srStatus
				+ ", productCode=" + productCode + ", subProductCode=" + subProductCode + ", queryType=" + queryType
				+ ", querySubType=" + querySubType + ", productNumber=" + productNumber + ", srKey=" + srKey
				+ ", serreqcurstatus=" + serreqcurstatus + ", refProdNum=" + refProdNum + ", lstupdateby=" + lstupdateby
				+ ", lstupdatedt=" + lstupdatedt + "]";
	}

	

	
	
	

}
