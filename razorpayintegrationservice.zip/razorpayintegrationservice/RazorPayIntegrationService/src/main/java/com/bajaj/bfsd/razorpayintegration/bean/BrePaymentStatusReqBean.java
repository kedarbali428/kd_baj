package com.bajaj.bfsd.razorpayintegration.bean;

public class BrePaymentStatusReqBean {
	
	private  String partnername;
    private String txnNumber;
    private String responseStatus;
    private String inqueryType;
    private String paymentMode;
    private String txnMessage;
	public String getPartnername() {
		return partnername;
	}
	public void setPartnername(String partnername) {
		this.partnername = partnername;
	}
	public String getTxnNumber() {
		return txnNumber;
	}
	public void setTxnNumber(String txnNumber) {
		this.txnNumber = txnNumber;
	}
	public String getResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}
	public String getInqueryType() {
		return inqueryType;
	}
	public void setInqueryType(String inqueryType) {
		this.inqueryType = inqueryType;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getTxnMessage() {
		return txnMessage;
	}
	public void setTxnMessage(String txnMessage) {
		this.txnMessage = txnMessage;
	}
	@Override
	public String toString() {
		return "BrePaymentStatusBean [partnername=" + partnername + ", txnNumber=" + txnNumber + ", responseStatus="
				+ responseStatus + ", inqueryType=" + inqueryType + ", paymentMode=" + paymentMode + ", txnMessage="
				+ txnMessage + "]";
	}
    
	
}
