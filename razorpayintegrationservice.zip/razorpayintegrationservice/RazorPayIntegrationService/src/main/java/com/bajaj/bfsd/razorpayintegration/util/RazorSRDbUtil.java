package com.bajaj.bfsd.razorpayintegration.util;


import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.razorpayintegration.bean.RazorServiceRequestDetails;
import com.bajaj.bfsd.razorpayintegration.bean.SerReqStprazorDetail;
import com.bajaj.bfsd.razorpayintegration.bean.ServiceRequestBean;
import com.bajaj.bfsd.razorpayintegration.factory.MapperFactory;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
@Component
public class RazorSRDbUtil {

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private Environment env;

	ResponseEntity<ResponseBean> serviceRequest;

	@Autowired
	BFLCommonRestClient bflCommonRestClientl;
	
	@Value("${api.serreq.getrazorserreq.GET.url}")
	private String getRazorSerReqUrl;
	
	@Value("${api.serreq.updatereqstpdtlref.PUT.url}")
	private String updateReqStpDtlRefUrl;
	
	@Value("${api.serreq.getrazstpdtls.GET.url}")
	private String getRazStpDtlsUrl;
	
	@Value("${api.serreq.getrazorserresol.GET.url}")
	private String getRazorSerResolUrl;
	
	@Value("${api.serreq.updateserresol.PUT.url}")
	private String updateserresolUrl;
	
	@Value("${api.serreq.updtserreqcurst.PUT.url}")
	private String updtserreqcurstUrl;
	
	@Value("${api.serreq.updaterazserreqstp.PUT.url}")
	private String updateRazSerReqStpUrl;
	
	@Value("${api.serreq.getrazservreqnum.GET.url}")
	private String getRazServReqnumUrl;
	
	
	
	

	private static final String THIS_CLASS = RazorSRDbUtil.class.getName();
	
	
	public RazorServiceRequestDetails getSRDetails(String srNumber) {	
		
		HashMap<String,String> paramMap = new HashMap<>();
		paramMap.put("srNumber", srNumber);
		HttpHeaders headers = new HttpHeaders();
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Input passed to getSRDetails srNumber:" + srNumber);
		headers.setContentType(MediaType.APPLICATION_JSON);
		ResponseEntity<ResponseBean> srDetails = BFLCommonRestClient.get(getRazorSerReqUrl, null, ResponseBean.class, paramMap, null, headers);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Call completed getSRDetails "+srDetails.toString());
		
		ResponseBean responseBean = (ResponseBean) srDetails.getBody().getPayload();
		JSONObject json = getJsonObject(responseBean.getPayload());		
		RazorServiceRequestDetails serviceRequestDetails = (RazorServiceRequestDetails) getResponseObjectFromResponseJsonString(json.toString(),
				RazorServiceRequestDetails.class);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getSRDetails Mapping Successfull: ");
		return serviceRequestDetails;
	}
	

	
	public void updateReqStpDtlRefNum(String payTransNum, Long srKey) {
		String requestJson;
		try {
			ServiceRequestBean srBean = new ServiceRequestBean();
			srBean.setPayTransNum(payTransNum);
			srBean.setSrKey(srKey.toString());
			ObjectMapper mapper = MapperFactory.getInstance();
			requestJson = mapper.writeValueAsString(srBean);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Input passed to updateReqStpDtlRefNum srBean:" + srBean.getSrKey()+"srBean.setPayTransNum : "+srBean.getPayTransNum());
		} catch (JsonProcessingException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					" BflDedupeDAOImpl : JsonProcessingException Occured while preparing request json for RazorPaySRDbUtil call in updateReqStpDtlRefNum()");
			throw new BFLTechnicalException("DDPE-3020", e);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		ResponseEntity<ResponseBean> updateSerStpResp = BFLCommonRestClient.update(updateReqStpDtlRefUrl, null,
				String.class, null, requestJson, headers);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Call completed updateReqStpDtlRefNum ");
		
		if (null != updateSerStpResp && updateSerStpResp.getStatusCode().equals(HttpStatus.OK)
				&& updateSerStpResp.getBody().getStatus().equals(StatusCode.SUCCESS)) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Success response for updateReqStpDtlRefNum" );
		} else {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Failure response for updateReqStpDtlRefNum: " + updateSerStpResp);
			throw new BFLTechnicalException("DDPE-3014", "Error in call to SR");
		}
	
	}
	
	
	public JSONObject getJsonObject(Object object) {
		JSONObject jsonObject = new JSONObject();
		try {

			JSONParser parser = new JSONParser();
			if (object instanceof JSONObject) {
				jsonObject = (JSONObject) object;
			} else if (object instanceof LinkedHashMap) {
				jsonObject = new JSONObject((Map) object);
			} else {
				Object obj = parser.parse(object.toString());
				jsonObject = (JSONObject) obj;
			}

		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"Error occured while parsing  :",e);
		}
		return jsonObject;
	}
	
	public SerReqStprazorDetail getRazStpDetails(Long srKey) {				
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HashMap<String,String> paramMap = new HashMap<>();
		paramMap.put("srKey", srKey.toString()); 
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Input passed to getRazStpDetails srKey:" + srKey);
		ResponseEntity<ResponseBean> stpDetails = BFLCommonRestClient.get(getRazStpDtlsUrl, null, ResponseBean.class, paramMap, null, headers);		
		ResponseBean responseBean = (ResponseBean) stpDetails.getBody().getPayload();
		JSONObject json = getJsonObject(responseBean.getPayload());		
		SerReqStprazorDetail serReqStpDetails = (SerReqStprazorDetail) getResponseObjectFromResponseJsonString(json.toString(),SerReqStprazorDetail.class);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Call completed getRazStpDetails ");
		return serReqStpDetails;
	}
	
	public RazorServiceRequestDetails getRazorSerResol(String srKey,String orderId) {		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		Map<String, String> param = new HashMap<>();
		param.put("srKey", srKey);
		param.put("orderId", orderId);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Input passed to getRazorSerResol srKey: " + srKey +" orderId : "+orderId);
		ResponseEntity<ResponseBean> srDetails = BFLCommonRestClient.get(getRazorSerResolUrl, null, ResponseBean.class, param, null, headers);		
		ResponseBean responseBean = (ResponseBean) srDetails.getBody().getPayload();
		JSONObject json = getJsonObject(responseBean.getPayload());		
		RazorServiceRequestDetails serviceRequestDetails = (RazorServiceRequestDetails) getResponseObjectFromResponseJsonString(json.toString(),RazorServiceRequestDetails.class);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Call completed getRazorSerResol ");		
		
		return serviceRequestDetails;
	}	
	

	
	
	public void updateSerResolution(String remarks, String userkey, String serreqresolutionkey) {
		String requestJson;
		try {
			ServiceRequestBean srBean = new ServiceRequestBean();
			srBean.setRemarks(remarks);
			srBean.setUserkey(userkey);
			srBean.setSerreqresolutionkey(serreqresolutionkey);
			ObjectMapper mapper = MapperFactory.getInstance();
			requestJson = mapper.writeValueAsString(srBean);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Input passed to updateSerResolution serreqresolutionkey:" + srBean.getSerreqresolutionkey());
		} catch (JsonProcessingException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					" BflDedupeDAOImpl : JsonProcessingException Occured while preparing request json for RazorPaySRDbUtil call in updateServiceReqStpDetails()");
			throw new BFLTechnicalException("DDPE-3020", e);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		ResponseEntity<ResponseBean> updateSerStpResp = BFLCommonRestClient.update(updateserresolUrl, null,
				String.class, null, requestJson, headers);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Call completed updateSerResolution ");
		
		if (null != updateSerStpResp && updateSerStpResp.getStatusCode().equals(HttpStatus.OK)
				&& updateSerStpResp.getBody().getStatus().equals(StatusCode.SUCCESS)) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Success response for updateSerResolution" );
		} else {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Failure response for updateSerResolution: " + updateSerStpResp);
			throw new BFLTechnicalException("DDPE-3014", "Error in call to SR");
		}
	
	}
	
	
	public void updateSrreqcurStatus(String srKey,String serreqcurstatus,String userKey) {
		String requestJson;
		try {
			ServiceRequestBean srBean = new ServiceRequestBean();
			ObjectMapper mapper = MapperFactory.getInstance();
			srBean.setSrKey(srKey);
			srBean.setSerreqcurstatus(serreqcurstatus);
			srBean.setUserkey(userKey);
			requestJson = mapper.writeValueAsString(srBean);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Input passed to updateSrreqcurStatus getStpreqkey:" +srBean.getSrKey());
		} catch (JsonProcessingException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					" BflDedupeDAOImpl : JsonProcessingException Occured while preparing request json for RazorPaySRDbUtil call in updateSrreqcurStatus()");
			throw new BFLTechnicalException("DDPE-3020", e);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		ResponseEntity<ResponseBean> updateSerStpResp = BFLCommonRestClient.update(updtserreqcurstUrl, null,
				String.class, null, requestJson, headers);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Call completed updateSrreqcurStatus ");
		
		if (null != updateSerStpResp && updateSerStpResp.getStatusCode().equals(HttpStatus.OK)
				&& updateSerStpResp.getBody().getStatus().equals(StatusCode.SUCCESS)) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Success response for updateSrreqcurStatus" );
		} else {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Failure response for updateSrreqcurStatus: "+updateSerStpResp );
			throw new BFLTechnicalException("DDPE-3014", "Error in call to SR");
		}
	
	}
	
	
	
	public void updateServiceReqStpDetails(SerReqStprazorDetail serReqStpDetail) {
		String requestJson;
		try {
			ObjectMapper mapper = MapperFactory.getInstance();
			requestJson = mapper.writeValueAsString(serReqStpDetail);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Input passed to updateServiceReqStpDetails getStpreqkey:" + serReqStpDetail.getStpreqkey());
		} catch (JsonProcessingException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					" BflDedupeDAOImpl : JsonProcessingException Occured while preparing request json for RazorPaySRDbUtil call in updateServiceReqStpDetails()");
			throw new BFLTechnicalException("DDPE-3020", e);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		ResponseEntity<ResponseBean> updateSerStpResp = BFLCommonRestClient.update(updateRazSerReqStpUrl, null,
				String.class, null, requestJson, headers);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Call completed updateServiceReqStpDetails ");
		
		if (null != updateSerStpResp && updateSerStpResp.getStatusCode().equals(HttpStatus.OK)
				&& updateSerStpResp.getBody().getStatus().equals(StatusCode.SUCCESS)) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Success response for updateServiceReqStpDetails" );
		} else {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Failure response for updateServiceReqStpDetails: " + updateSerStpResp);
			throw new BFLTechnicalException("DDPE-3014", "Error in call to SR");
		}
	
	}
	
	
	public RazorServiceRequestDetails getRazServReqnum(String orderId) {		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HashMap<String,String> paramMap = new HashMap<>();
		paramMap.put("orderId", orderId); 
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Input passed to getRazServReqnum orderId:" + orderId);
		ResponseEntity<ResponseBean> stpDetails = BFLCommonRestClient.get(getRazServReqnumUrl, null, ResponseBean.class, paramMap, null, headers);
		ResponseBean responseBean = (ResponseBean) stpDetails.getBody().getPayload();
		JSONObject json = getJsonObject(responseBean.getPayload());		
		RazorServiceRequestDetails razorServiceRequestDetails = (RazorServiceRequestDetails) getResponseObjectFromResponseJsonString(json.toString(),RazorServiceRequestDetails.class);		
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Call completed getRazServReqnum ");		
		return razorServiceRequestDetails;
	}
	
	public Object getResponseObjectFromResponseJsonString(String responseJson, Class<?> classType) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"Inside getResponseObjectFromResponseJsonString() in SMECreditReviewUtility");
		Object responseObject = null;

		if (null != responseJson && !responseJson.isEmpty() && null != classType) {
			ObjectMapper mapper = MapperFactory.getInstance();
			try {
				responseObject = mapper.readValue(responseJson, classType);
			} catch (JsonParseException jpe) {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
						"JsonParseException occurred while parsing BRE response json", jpe);
				throw new BFLTechnicalException("SMECR-10808", env.getProperty("SMECR-10808"));
			} catch (JsonMappingException jme) {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
						"JsonMappingException occurred while parsing BRE response json", jme);
				throw new BFLTechnicalException("SMECR-10809", env.getProperty("SMECR-10809"));
			} catch (IOException ioe) {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "IOException occurred while parsing BRE response json",
						ioe);
				throw new BFLTechnicalException("SMECR-10810", env.getProperty("SMECR-10810"));
			}
		}

		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"Exit from getResponseObjectFromResponseJsonString() in SMECreditReviewUtility");
		return responseObject;
	}	
	
	
	}
	
	
	

	


