package com.bajaj.bfsd.razorpayintegration.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.baseclasses.BFLRepository;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;
import com.bajaj.bfsd.razorpayintegration.dao.RazorPayIntegrationDao;
import com.bajaj.bfsd.razorpayintegration.model.PaymentTransaction;

@Component
public class RazorPayIntegrationRepositoryImpl extends BFLRepository implements RazorPayIntegrationRepository {

	@Autowired
	private RazorPayIntegrationDao razorPayIntegrationDao;

	@Override
	@Transactional
	public String updatePendingTransStatus() {
		String response = RazorPayIntegrationConstants.NO_RECORDS;
		List<PaymentTransaction> lstPendingTransactions = razorPayIntegrationDao.getAllPendingTransactions();
		if (!CollectionUtils.isEmpty(lstPendingTransactions)) {
			response = razorPayIntegrationDao.updatePendingTrans(lstPendingTransactions);
		}
		return response;
	}

}