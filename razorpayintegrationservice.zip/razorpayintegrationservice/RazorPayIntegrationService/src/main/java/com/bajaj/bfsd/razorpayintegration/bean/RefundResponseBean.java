package com.bajaj.bfsd.razorpayintegration.bean;

public class RefundResponseBean {
	private String id;
	private String entity;
	private String amount;
	private String currency;
	private String payment_id;
	private String created_at;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPayment_id() {
		return payment_id;
	}
	public void setPayment_id(String payment_id) {
		this.payment_id = payment_id;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	@Override
	public String toString() {
		return "RefundResponseBean [id=" + id + ", entity=" + entity + ", amount=" + amount + ", currency=" + currency
				+ ", payment_id=" + payment_id + ", created_at=" + created_at + "]";
	}
}
