package com.bajaj.bfsd.razorpayintegration.bean;

public class RedeemConfirmRequest {
	private String paymentId;
	private String dgProviderCode;
	private Double totalAmount;
	private String appSource;

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public String getDgProviderCode() {
		return dgProviderCode;
	}

	public void setDgProviderCode(String dgProviderCode) {
		this.dgProviderCode = dgProviderCode;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getAppSource() {
		return appSource;
	}

	public void setAppSource(String appSource) {
		this.appSource = appSource;
	}

	@Override
	public String toString() {
		return "RedeemConfirmRequest [paymentId=" + paymentId + ", dgProviderCode=" + dgProviderCode + ", totalAmount="
				+ totalAmount + ", appSource=" + appSource + "]";
	}

}
