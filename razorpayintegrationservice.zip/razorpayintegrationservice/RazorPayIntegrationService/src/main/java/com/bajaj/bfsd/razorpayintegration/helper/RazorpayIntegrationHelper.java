package com.bajaj.bfsd.razorpayintegration.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.BFLCommonClientBean;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.BuyProcessRequest;
import com.bajaj.bfsd.razorpayintegration.bean.PartnerDetail;
import com.bajaj.bfsd.razorpayintegration.bean.RedeemConfirmRequest;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;
import com.bajaj.bfsd.razorpayintegration.dao.RazorPayIntegrationDao;
import com.bajaj.bfsd.razorpayintegration.util.ServiceCallProcessorUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.google.gson.Gson;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;

@Component
public class RazorpayIntegrationHelper {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;
	@Autowired
	private RazorPayIntegrationDao integrationDao;

	@Autowired
	private ServiceCallProcessorUtil serviceCallProcessorUtil;

	private static final String CLASS_NAME = RazorpayIntegrationHelper.class.getSimpleName();

	@SuppressWarnings("unchecked")
	public BigDecimal authenticatePartner() {
		BigDecimal userKey = BigDecimal.ZERO;
		String partnerKey = env.getProperty("PARTNER_KEY");
		String secretKey = env.getProperty("PARTNER_SECRET_KEY");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String authUrl = env.getProperty("api.usermanagement.getloginaccount.POST.url");
		ResponseEntity<ResponseBean> responseEntity;
		Gson gson = new Gson();
		PartnerDetail partnerDetail = new PartnerDetail();
		partnerDetail.setLoginId(partnerKey);
		partnerDetail.setPwd(secretKey);
		partnerDetail.setLoginType(5);
		partnerDetail.setUserType(5);
		String reqJson = gson.toJson(partnerDetail);
		responseEntity = (ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST, authUrl,
				null, ResponseBean.class, null, reqJson, headers);
		if (null != responseEntity && HttpStatus.OK.equals(responseEntity.getStatusCode())
				&& null != responseEntity.getBody().getPayload()
				&& CollectionUtils.isEmpty(responseEntity.getBody().getErrorBean())) {
			userKey = integrationDao.getUserKey(partnerKey);
		}
		return userKey;
	}
	
	@SuppressWarnings("unchecked")
	public BigDecimal digitalGoldauthenticatePartner(HttpHeaders headers) {
		BigDecimal userKey = BigDecimal.ZERO;
		String partnerKey = env.getProperty("PARTNER_KEY");
		String secretKey = env.getProperty("PARTNER_SECRET_KEY");
		headers.setContentType(MediaType.APPLICATION_JSON);
		String authUrl = env.getProperty("api.usermanagement.getloginaccount.POST.url");
		ResponseEntity<ResponseBean> responseEntity;
		Gson gson = new Gson();
		PartnerDetail partnerDetail = new PartnerDetail();
		partnerDetail.setLoginId(partnerKey);
		partnerDetail.setPwd(secretKey);
		partnerDetail.setLoginType(5);
		partnerDetail.setUserType(5);
		String reqJson = gson.toJson(partnerDetail);
		responseEntity = (ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST, authUrl,
				null, ResponseBean.class, null, reqJson, headers);
		if (null != responseEntity && HttpStatus.OK.equals(responseEntity.getStatusCode())
				&& null != responseEntity.getBody().getPayload()
				&& CollectionUtils.isEmpty(responseEntity.getBody().getErrorBean())) {
			userKey = integrationDao.getUserKey(partnerKey);
		}
		return userKey;
	}

	/**
	 * Validate the signature recieved from razorpay.
	 * 
	 * @param headers
	 * @param jsonRequest
	 * @param source
	 * @return
	 */
	public boolean validateSignature(String signature, String jsonRequest, String key) {
		boolean isValid = false;
		try {
			isValid = Utils.verifyWebhookSignature(jsonRequest, signature, key);
		} catch (RazorpayException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Signature is not valid.", e);
			throw new BFLTechnicalException(RazorPayIntegrationConstants.ERROR_RPIS_1013,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1013));
		}
		if (!isValid) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Invalid user." + jsonRequest);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1011,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1011));
		}
		return isValid;
	}

	/**
	 * Invoke endpoint on the basis of event and source.
	 * 
	 * @param url
	 * @param requestStr
	 * @param headers
	 * @return
	 */
	public ResponseEntity<ResponseBean> invokeEndpoint(String url, String requestStr, HttpHeaders headers) {
		ResponseEntity<ResponseBean> response;
		BigDecimal userKey;
		userKey = authenticatePartner();
		headers.set("userkey", userKey.toString());
		headers.setContentType(MediaType.APPLICATION_JSON);
		logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Endpoint url: " + url);
		logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Razorpay Integration Request Data: " + requestStr);
		response = BFLCommonRestClient.create(url, null, String.class, null, requestStr, headers);
		logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Razorpay Integration Response Data: " + response);
		if (null != response && HttpStatus.OK.equals(response.getStatusCode())) {
			logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Call to API is successfull. : " + response);
			return response;
		} else {
			// when unable to consume razor pay service.
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Error occured while invoking Service");
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1012,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1012));
		}

	}

	@Async
	@SuppressWarnings({ "unchecked", "deprecation" })
	public Future<ResponseBean> callconfirmService(String postConfirmURL, BuyProcessRequest buyProcessRequest,
			HttpHeaders headers) {
		ResponseBean response = null;
		headers.setContentType(MediaType.APPLICATION_JSON);
		String url = postConfirmURL + "?reqtype=" + buyProcessRequest.getRequestType() + "&vendorID="
				+ buyProcessRequest.getDgProviderCode();
		String requestJson = serviceCallProcessorUtil.prepareRequestJson(buyProcessRequest);
		ResponseEntity<ResponseBean> responseEntity = null;
		BFLCommonClientBean bflCommonClientBean = new BFLCommonClientBean();
		bflCommonClientBean.setHttpMethod(HttpMethod.POST);
		BFLLoggerUtil.debug(null,CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Endpoint url for callconfirmService: " + url);
		BFLLoggerUtil.debug(null,CLASS_NAME, BFLLoggerComponent.PROCESSOR, "callconfirmService Request Data: " + requestJson);
		try {
			responseEntity = (ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST, url,
					null, String.class, null, requestJson, headers, bflCommonClientBean);
			if (null != responseEntity && responseEntity.getStatusCode().equals(HttpStatus.OK)) {
				response = serviceCallProcessorUtil.getResponse(responseEntity);
				BFLLoggerUtil.debug(null,CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Call to callconfirmService API is successfull. : " + response);
			} else {
				List<ErrorBean> errorBean = new ArrayList<>();
				if (null != responseEntity) {
					errorBean.add(new ErrorBean(responseEntity.getStatusCode().toString(),
							responseEntity.getStatusCode().toString()));
				}
				response = new ResponseBean(errorBean);
			}
			BFLLoggerUtil.debug(null,CLASS_NAME, BFLLoggerComponent.PROCESSOR, "callconfirmService Response Data: " + response);
		} catch (Exception exception) {
			BFLLoggerUtil.error(null, CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Error occured while invoking Service: " + exception);
			List<ErrorBean> errorBean = new ArrayList<>();
			errorBean.add(new ErrorBean("ACT_001", "exception while processing."));
			response = new ResponseBean(errorBean);
		}
		return new AsyncResult<>(response);

	}

	@Async
	@SuppressWarnings({ "unchecked", "deprecation" })
	public Future<ResponseBean> callredeemConfirmService(String postRedeemConfirmURL, RedeemConfirmRequest redeemConfirmRequest,
			String orderId, HttpHeaders headers) {
		ResponseBean response = null;
		headers.setContentType(MediaType.APPLICATION_JSON);
		String requestJson = serviceCallProcessorUtil.prepareRequestJson(redeemConfirmRequest);
		//map
		Map<String, String> confirmParam = new HashMap<>();
		confirmParam.put("orderid", orderId);
		ResponseEntity<ResponseBean> responseEntity = null;
		BFLCommonClientBean bflCommonClientBean = new BFLCommonClientBean();
		bflCommonClientBean.setHttpMethod(HttpMethod.POST);
		BFLLoggerUtil.debug(null,CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Endpoint url for callconfirmService: " + postRedeemConfirmURL);
		BFLLoggerUtil.debug(null,CLASS_NAME, BFLLoggerComponent.PROCESSOR, "callconfirmService Request Data: " + requestJson);
		try {
			responseEntity = (ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST, postRedeemConfirmURL,
					null, String.class, confirmParam, requestJson, headers, bflCommonClientBean);
			if (null != responseEntity && responseEntity.getStatusCode().equals(HttpStatus.OK)) {
				response = serviceCallProcessorUtil.getResponse(responseEntity);
				BFLLoggerUtil.debug(null,CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Call to callRedeemConfirmService API is successfull. : " + response);
			} else {
				List<ErrorBean> errorBean = new ArrayList<>();
				if (null != responseEntity) {
					errorBean.add(new ErrorBean(responseEntity.getStatusCode().toString(),
							responseEntity.getStatusCode().toString()));
				}
				response = new ResponseBean(errorBean);
			}
			BFLLoggerUtil.debug(null,CLASS_NAME, BFLLoggerComponent.PROCESSOR, "callRedeemConfirmService Response Data: " + response);
		} catch (Exception exception) {
			BFLLoggerUtil.error(null, CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Error occured while invoking Service" + exception);
			List<ErrorBean> errorBean = new ArrayList<>();
			errorBean.add(new ErrorBean("ACT_001", "exception while processing."));
			response = new ResponseBean(errorBean);
		}
		return new AsyncResult<>(response);
		
	}

}
