package com.bajaj.bfsd.razorpayintegration.controller;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.RazorpayTransferRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusResponse;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;
import com.bajaj.bfsd.razorpayintegration.service.RazorPayIntegrationService;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.razorpay.RazorpayException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RefreshScope
@RestController
public class RazorPayIntegrationController extends BFLController {
	@Autowired
	private RazorPayIntegrationService razorPayIntegrationService;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;

	private static final String CLASS_NAME = RazorPayIntegrationController.class.getSimpleName();

	/**
	 * Generate orderId from razor pay.
	 * 
	 * @param l3ProductId
	 * @param generateOrderIdRequestBean
	 * @param headers
	 * @return
	 */
	@ApiOperation(value = "Fetch orderId from RazorPay", notes = "Returns order id fetching from razorpay payment gateway", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"), })
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "${api.razorpayintegration.getrazorpayorderid.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> getRazorPayOrderId(@PathVariable("l3ProductId") String l3ProductId,
			@RequestBody GenerateOrderIdRequestBean generateOrderIdRequestBean, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				RazorPayIntegrationConstants.GET_RAZORPAYORDER_ID_START);
		generateOrderIdRequestBean.setProductCode(l3ProductId);
		ResponseBean responseBean;
		GenerateOrderIdResponseBean generateOrderIdResponseBean = razorPayIntegrationService
				.initiateBooking(generateOrderIdRequestBean);
		responseBean = new ResponseBean(generateOrderIdResponseBean);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorPayIntegrationConstants.GET_RAZORPAYORDER_ID_END);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	/**
	 * Update Payment status in database and call pennant in case of successful
	 * transaction and in case of mark status as pending.
	 * 
	 * @param updatePaymentStatusRequest
	 * @param headers
	 * @return
	 * @throws RazorpayException
	 */

	@ApiOperation(value = "Update the payment status", notes = "Returns status after updating to pennant", httpMethod = "POST")
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "${api.razorpayintegration.updatepaymentstatus.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> updatePaymentStatus(@RequestBody String jsonRequest,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				RazorPayIntegrationConstants.UPDATE_PAYMENT_STATUS_START);

		ResponseBean responseBean;
		UpdatePaymentStatusResponse paymentStatusResponse;
		try {
			paymentStatusResponse = razorPayIntegrationService.initiateUpdate(jsonRequest);
			responseBean = new ResponseBean(paymentStatusResponse);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					RazorPayIntegrationConstants.UPDATE_PAYMENT_STATUS_EXCEPTION, e);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1009,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1009));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorPayIntegrationConstants.UPDATE_PAYMENT_STATUS_END);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);

	}

	/**
	 * Schedular to update all pending payment status to failed.
	 * 
	 * @param updatePaymentStatusRequest
	 * @param headers
	 * @return
	 */
	@ApiOperation(value = "Update the transaction status which is pending", notes = "Returns status after updating to pennant", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"), })
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "${api.razorpayintegration.updatependingtransaction.POST.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> updatePendingTransStatus(@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				RazorPayIntegrationConstants.UPDATE_PENDING_TRANSSTATUS_START);
		ResponseBean respBean;
		String resp = razorPayIntegrationService.updatePendingTransStatus();
		respBean = new ResponseBean(resp);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				RazorPayIntegrationConstants.UPDATE_PENDING_TRANSSTATUS_END);
		return new ResponseEntity<>(respBean, HttpStatus.OK);
	}

	/**
	 * Webhook handler that navigates incoming request to endpoint based on event
	 * that is triggered.
	 * 
	 * @param headers
	 * @param jsonRequest
	 * @return
	 */
	@ApiOperation(value = "Call appropriate endpoint based on event", notes = "Call appropriate endpoint based on event", httpMethod = "POST")
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "${api.razorpayintegration.webhookhandler.POST.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> callbackHandler(@RequestHeader HttpHeaders headers,
			@RequestBody String jsonRequest, @QueryParam("source") String source) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorPayIntegrationConstants.WEBHOOK_HANDLER_START);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorPayIntegrationConstants.SOURCE + source);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "WebHook Request : " + jsonRequest);
		ResponseEntity<ResponseBean> response = razorPayIntegrationService.selectProcess(headers, jsonRequest, source);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Response : " + response);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorPayIntegrationConstants.WEBHOOK_HANDLER_END);
		return response;
	}

	/**
	 * Webhook handler for DG that navigates incoming request to endpoint based on event that is triggered.
	 * @param headers
	 * @param jsonRequest
	 * @return
	 */
	@ApiOperation(value = "Call appropriate endpoint based on event", notes = "Call appropriate endpoint based on event", httpMethod = "POST")
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "${api.razorpayintegration.webhookhandler.DG.POST.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> digitalGoldCallbackHandler(@RequestHeader HttpHeaders headers,
			@RequestBody String jsonRequest) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorPayIntegrationConstants.WEBHOOK_HANDLER_DG_START);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "WebHook DG Request : " + jsonRequest);
		ResponseEntity<ResponseBean> response = null;

		try {

			response = razorPayIntegrationService.digitalGoldSelectProcess(headers, jsonRequest);

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorPayIntegrationConstants.WEBHOOK_DG_EXCEPTION,
					e);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1017,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1017));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Response : " + response);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorPayIntegrationConstants.WEBHOOK_HANDLER_DG_END);
		return response;

	}
	
	@ApiOperation(value = "Call razorpay transfer api for transferring amount to multiple linked accounts", notes = "Call razorpay transfer api for transferring amount to multiple linked accounts", httpMethod = "POST")
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "${api.razorpayintegration.transferpayment.POST.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> initiateRazorpayTransfer(@RequestHeader HttpHeaders headers,
			@RequestBody RazorpayTransferRequest razorpayTransferRequest) {
		ResponseBean responseBean = null;
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Transfer Request : " + razorpayTransferRequest);
		try {
			responseBean = new ResponseBean(razorPayIntegrationService.initiateTransferProcess(razorpayTransferRequest));
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Response : " + responseBean);
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					RazorPayIntegrationConstants.ERROR_RPIS_1019, exception);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1019,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1019));
		}
		return new ResponseEntity<>(responseBean, HttpStatus.OK);

	}
	
	@ApiOperation(value = "Initiate refund from razorpay", notes = "Initiate refund from razorpay", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"), })
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "${api.razorpayintegration.razorpayrefund.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> initiateRazorpayRefund(@RequestHeader HttpHeaders headers,
			@RequestBody RefundRequestBean refundRequestBean) {
		ResponseBean responseBean = null;
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Refund Request : " + refundRequestBean);
		try {
			responseBean = new ResponseBean(razorPayIntegrationService.initiateRefundProcess(refundRequestBean));
			logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Response : " + responseBean);
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					RazorPayIntegrationConstants.ERROR_RPIS_1021, exception);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1021,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1021));
		}
		return new ResponseEntity<>(responseBean, HttpStatus.OK);

	}
	
	@ApiOperation(value = "Update refund id in payment transaction", notes = "Update refund id in payment transaction", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"), })
	@CrossOrigin
	@RequestMapping(method = RequestMethod.PUT, value = "${api.razorpayintegration.updatepaymenttransaction.PUT.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> updatePaymentRefundId(@RequestParam String paymentId,@RequestParam String refundId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside updatePaymentRefundId method, payment id :"+paymentId + "refund id: "+refundId);
		
		ResponseBean responseBean = null;
		try {
			razorPayIntegrationService.updatePaymentTransactionForRefund(refundId, paymentId);
			responseBean = new ResponseBean("Success");
		}catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		}catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					RazorPayIntegrationConstants.ERROR_RPIS_1022, exception);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1022,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1022));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "updatePaymentRefundId end");
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
}