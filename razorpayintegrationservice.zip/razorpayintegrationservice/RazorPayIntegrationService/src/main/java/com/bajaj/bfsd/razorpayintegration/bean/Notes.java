package com.bajaj.bfsd.razorpayintegration.bean;

public class Notes {

	private String applicationId;
	private String vendorTxId;
	
	public Notes() {
	}
	
	public Notes(String applicationId, String vendorTxId) {
		super();
		this.applicationId = applicationId;
		this.vendorTxId = vendorTxId;
	}
	
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getVendorTxId() {
		return vendorTxId;
	}
	public void setVendorTxId(String vendorTxId) {
		this.vendorTxId = vendorTxId;
	}
	@Override
	public String toString() {
		return "Notes [applicationId=" + applicationId + ", vendorTxId=" + vendorTxId + "]";
	}
}
