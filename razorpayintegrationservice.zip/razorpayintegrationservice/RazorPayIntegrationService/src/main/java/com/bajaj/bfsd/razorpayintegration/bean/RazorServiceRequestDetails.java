/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.razorpayintegration.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;


public class RazorServiceRequestDetails implements Serializable {

private Long srKey;
private Long serreqresolutionkey;

private String refprodnum;
private BigDecimal serreqcurstatus;
private Timestamp closedate;

private String lstupdateby;

private Timestamp lstupdatedt;

private String srnumber;

private BigDecimal paytransstatus;
public Long getSrKey() {
	return srKey;
}
public void setSrKey(Long srKey) {
	this.srKey = srKey;
}
public Long getSerreqresolutionkey() {
	return serreqresolutionkey;
}
public void setSerreqresolutionkey(Long serreqresolutionkey) {
	this.serreqresolutionkey = serreqresolutionkey;
}
public String getRefprodnum() {
	return refprodnum;
}
public void setRefprodnum(String refprodnum) {
	this.refprodnum = refprodnum;
}
public BigDecimal getSerreqcurstatus() {
	return serreqcurstatus;
}
public void setSerreqcurstatus(BigDecimal serreqcurstatus) {
	this.serreqcurstatus = serreqcurstatus;
}
public Timestamp getClosedate() {
	return closedate;
}
public void setClosedate(Timestamp closedate) {
	this.closedate = closedate;
}
public String getLstupdateby() {
	return lstupdateby;
}
public void setLstupdateby(String lstupdateby) {
	this.lstupdateby = lstupdateby;
}
public Timestamp getLstupdatedt() {
	return lstupdatedt;
}
public void setLstupdatedt(Timestamp lstupdatedt) {
	this.lstupdatedt = lstupdatedt;
}
public String getSrnumber() {
	return srnumber;
}
public void setSrnumber(String srnumber) {
	this.srnumber = srnumber;
}
/**
 * @return the paytransstatus
 */
public BigDecimal getPaytransstatus() {
	return paytransstatus;
}
/**
 * @param paytransstatus the paytransstatus to set
 */
public void setPaytransstatus(BigDecimal paytransstatus) {
	this.paytransstatus = paytransstatus;
}


}
