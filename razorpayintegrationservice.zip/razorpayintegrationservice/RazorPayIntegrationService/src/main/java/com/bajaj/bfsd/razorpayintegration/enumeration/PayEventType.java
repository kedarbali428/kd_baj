package com.bajaj.bfsd.razorpayintegration.enumeration;

public enum PayEventType {
	PP(1,"PP"),FC(2,"FC"),DI(5,"DI"),ME(6,"ME"),BDG(7,"BDG"),RDG(8,"RDG"),ADVEMI(9,"ADVEMI");
	
	
	private int value;
	private String name;

	private PayEventType(int value, String name) {
		this.value = value;
		this.name = name;
	}

	public int getValue() {
		return this.value;
	}

	public String getName() {
		return this.name;
	}
}
