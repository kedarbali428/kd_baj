package com.bajaj.bfsd.razorpayintegration.bean;

/**
 * 
 * @author 738768
 *
 */
public class BuyProcessRequest {

	private String requestType;
	private Long dgProviderKey;
	private String dgProviderCode;
	private String customerUserId;
	private Integer customerEnteredAmtGrmFlag;
	private Double providerRate;
	private Double gstAmount;
	private Double convenienceFee;
	private Long rateId;
	private Double partnerRate;
	private Double goldAmount;
	private Double buyPrice;
	private Double totalAmount;
	// Not null
	private Long applicantId;
	private Long applicationId;
	private Long appApplicantId;
	private Long invDgApplicationId;
	private String txId;
	// Not null
	private String pincode;
	// Not null
	private String panNumber;
	private Integer panValidationFlag;

	private String appJourneyStamp;
	private String appSource;
	private Integer appStatus;
	private String productCategoryCode;
	private String appUtmRefCode;
	private String appUtmSource;
	private String appUtmMedium;
	private String appUtmCampaign;
	private String appUtmTerm;
	private String appUtmContent;
	private String bflBranch;
	private String investmentProduct;
	private String paymentMode;
	private String paymentId;
	private Integer panValidationAttempt;
	private String channelType;
	private String orderId;

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getDgProviderCode() {
		return dgProviderCode;
	}

	public void setDgProviderCode(String dgProviderCode) {
		this.dgProviderCode = dgProviderCode;
	}

	public String getCustomerUserId() {
		return customerUserId;
	}

	public void setCustomerUserId(String customerUserId) {
		this.customerUserId = customerUserId;
	}

	public Long getRateId() {
		return rateId;
	}

	public void setRateId(Long rateId) {
		this.rateId = rateId;
	}

	public Double getPartnerRate() {
		return partnerRate;
	}

	public void setPartnerRate(Double partnerRate) {
		this.partnerRate = partnerRate;
	}

	public Double getGoldAmount() {
		return goldAmount;
	}

	public void setGoldAmount(Double goldAmount) {
		this.goldAmount = goldAmount;
	}

	public Double getBuyPrice() {
		return buyPrice;
	}

	public void setBuyPrice(Double buyPrice) {
		this.buyPrice = buyPrice;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Long getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Long getAppApplicantId() {
		return appApplicantId;
	}

	public void setAppApplicantId(Long appApplicantId) {
		this.appApplicantId = appApplicantId;
	}

	public String getTxId() {
		return txId;
	}

	public void setTxId(String txId) {
		this.txId = txId;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public Integer getPanValidationFlag() {
		return panValidationFlag;
	}

	public void setPanValidationFlag(Integer panValidationFlag) {
		this.panValidationFlag = panValidationFlag;
	}

	public String getAppJourneyStamp() {
		return appJourneyStamp;
	}

	public void setAppJourneyStamp(String appJourneyStamp) {
		this.appJourneyStamp = appJourneyStamp;
	}

	public String getAppSource() {
		return appSource;
	}

	public void setAppSource(String appSource) {
		this.appSource = appSource;
	}

	public Integer getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(Integer appStatus) {
		this.appStatus = appStatus;
	}

	public String getProductCategoryCode() {
		return productCategoryCode;
	}

	public void setProductCategoryCode(String productCategoryCode) {
		this.productCategoryCode = productCategoryCode;
	}

	public String getAppUtmRefCode() {
		return appUtmRefCode;
	}

	public void setAppUtmRefCode(String appUtmRefCode) {
		this.appUtmRefCode = appUtmRefCode;
	}

	public String getAppUtmSource() {
		return appUtmSource;
	}

	public void setAppUtmSource(String appUtmSource) {
		this.appUtmSource = appUtmSource;
	}

	public String getAppUtmMedium() {
		return appUtmMedium;
	}

	public void setAppUtmMedium(String appUtmMedium) {
		this.appUtmMedium = appUtmMedium;
	}

	public String getAppUtmCampaign() {
		return appUtmCampaign;
	}

	public void setAppUtmCampaign(String appUtmCampaign) {
		this.appUtmCampaign = appUtmCampaign;
	}

	public String getAppUtmTerm() {
		return appUtmTerm;
	}

	public void setAppUtmTerm(String appUtmTerm) {
		this.appUtmTerm = appUtmTerm;
	}

	public String getAppUtmContent() {
		return appUtmContent;
	}

	public void setAppUtmContent(String appUtmContent) {
		this.appUtmContent = appUtmContent;
	}

	public String getInvestmentProduct() {
		return investmentProduct;
	}

	public void setInvestmentProduct(String investmentProduct) {
		this.investmentProduct = investmentProduct;
	}

	public Long getDgProviderKey() {
		return dgProviderKey;
	}

	public void setDgProviderKey(Long dgProviderKey) {
		this.dgProviderKey = dgProviderKey;
	}

	public Integer getCustomerEnteredAmtGrmFlag() {
		return customerEnteredAmtGrmFlag;
	}

	public void setCustomerEnteredAmtGrmFlag(Integer customerEnteredAmtGrmFlag) {
		this.customerEnteredAmtGrmFlag = customerEnteredAmtGrmFlag;
	}

	public Double getProviderRate() {
		return providerRate;
	}

	public void setProviderRate(Double providerRate) {
		this.providerRate = providerRate;
	}

	public Double getGstAmount() {
		return gstAmount;
	}

	public void setGstAmount(Double gstAmount) {
		this.gstAmount = gstAmount;
	}

	public Double getConvenienceFee() {
		return convenienceFee;
	}

	public void setConvenienceFee(Double convenienceFee) {
		this.convenienceFee = convenienceFee;
	}

	public Long getInvDgApplicationId() {
		return invDgApplicationId;
	}

	public void setInvDgApplicationId(Long invDgApplicationId) {
		this.invDgApplicationId = invDgApplicationId;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public Integer getPanValidationAttempt() {
		return panValidationAttempt;
	}

	public void setPanValidationAttempt(Integer panValidationAttempt) {
		this.panValidationAttempt = panValidationAttempt;
	}

	public String getBflBranch() {
		return bflBranch;
	}

	public void setBflBranch(String bflBranch) {
		this.bflBranch = bflBranch;
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

}
