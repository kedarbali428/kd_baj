package com.bajaj.bfsd.razorpayintegration.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the APPLICANT_SYS_CODES database table.
 * 
 */
@Entity
@Table(name="APPLICANT_SYS_CODES")
@NamedQuery(name="ApplicantSysCode.findAll", query="SELECT a FROM ApplicantSysCode a")
public class ApplicantSysCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long apltsyscdkey;

	private java.math.BigDecimal applicantkey;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String refcode;

	private java.math.BigDecimal systemkey;

	public ApplicantSysCode() {
	}

	public long getApltsyscdkey() {
		return this.apltsyscdkey;
	}

	public void setApltsyscdkey(long apltsyscdkey) {
		this.apltsyscdkey = apltsyscdkey;
	}

	public java.math.BigDecimal getApplicantkey() {
		return this.applicantkey;
	}

	public void setApplicantkey(java.math.BigDecimal applicantkey) {
		this.applicantkey = applicantkey;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getRefcode() {
		return this.refcode;
	}

	public void setRefcode(String refcode) {
		this.refcode = refcode;
	}

	public java.math.BigDecimal getSystemkey() {
		return this.systemkey;
	}

	public void setSystemkey(java.math.BigDecimal systemkey) {
		this.systemkey = systemkey;
	}

}