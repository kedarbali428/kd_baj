package com.bajaj.bfsd.razorpayintegration.bean;

public class TokenResponse {
	
	private String token;
	private String guardKey;
	private String type;
	private String guardToken;
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getGuardKey() {
		return guardKey;
	}
	public void setGuardKey(String guardKey) {
		this.guardKey = guardKey;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getGuardToken() {
		return guardToken;
	}
	public void setGuardToken(String guardToken) {
		this.guardToken = guardToken;
	}
	
}
