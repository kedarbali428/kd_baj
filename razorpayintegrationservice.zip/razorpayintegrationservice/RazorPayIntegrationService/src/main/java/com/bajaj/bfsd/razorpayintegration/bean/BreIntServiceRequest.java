package com.bajaj.bfsd.razorpayintegration.bean;

import java.util.HashMap;
import java.util.Map;

public class BreIntServiceRequest {

	private Object reqObject;
	private String breIntUrl;
	private Class<?> classType;
	private Map<String,String> pathParamMap = new HashMap<>();
	
	
	
	public Object getReqObject() {
		return reqObject;
	}
	public void setReqObject(Object reqObject) {
		this.reqObject = reqObject;
	}
	public String getBreIntUrl() {
		return breIntUrl;
	}
	public void setBreIntUrl(String breIntUrl) {
		this.breIntUrl = breIntUrl;
	}
	
	public Class<?> getClassType() {
		return classType;
	}
	public void setClassType(Class<?> classType) {
		this.classType = classType;
	}
	
	public void addPathParamMap(String pathParamName,String pathParam) {
		pathParamMap.put(pathParamName, pathParam);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((breIntUrl == null) ? 0 : breIntUrl.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BreIntServiceRequest other = (BreIntServiceRequest) obj;
		if (breIntUrl == null) {
			if (other.breIntUrl != null)
				return false;
		} else if (!breIntUrl.equals(other.breIntUrl))
			return false;
		return true;
	}
}
