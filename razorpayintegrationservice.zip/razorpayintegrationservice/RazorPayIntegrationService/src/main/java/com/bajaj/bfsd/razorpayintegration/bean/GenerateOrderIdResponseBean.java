package com.bajaj.bfsd.razorpayintegration.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GenerateOrderIdResponseBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("id")
	private String orderId;
	@JsonProperty("entity")
	private String entity;
	@JsonProperty("amount")
	private BigDecimal amount;
	@JsonProperty("receipt")
	private String receipt;
	@JsonProperty("status")
	private String status;
	@JsonProperty("attempts")
	private int attempts;
	private String createDate;
	private String accessKey;
	

	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getReceipt() {
		return receipt;
	}
	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getAttempts() {
		return attempts;
	}

	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	@Override
	public String toString() {
		return "GenerateOrderIdResponseBean [orderId=" + orderId + ", entity=" + entity + ", amount=" + amount
				+ ", receipt=" + receipt + ", status=" + status + ", attempts=" + attempts + ", createDate="
				+ createDate + ", accessKey=" + accessKey + "]";
	}

	
}
