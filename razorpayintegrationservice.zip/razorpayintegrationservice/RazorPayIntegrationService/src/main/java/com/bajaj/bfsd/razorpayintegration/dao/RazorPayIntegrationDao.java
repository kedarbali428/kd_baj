package com.bajaj.bfsd.razorpayintegration.dao;

import java.math.BigDecimal;
import java.util.List;

import com.bajaj.bfsd.razorpayintegration.bean.RazorServiceRequestDetails;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.model.PayGatewayPartner;
import com.bajaj.bfsd.razorpayintegration.model.PaymentTransaction;

public interface RazorPayIntegrationDao {

	/**
	 * Fetch secret key on the basis of productId provided.
	 * 
	 * @param productId
	 * @return
	 */
	public PayGatewayPartner getSecretApiKey(String productId);

	/**
	 * Update the srKey and orderId mapping in SerReqStpDetail table.
	 * 
	 * @param srKey
	 * @param orderId
	 */
	public void updateOrderId(String srNumber, String orderId);


	/**
	 * @param updatePaymentStatusRequest
	 * @param transSatus
	 */
	public void insertPayTrans(String srNumber,String l3Product); 

	/**
	 * @param cif
	 * @param applicantKey
	 * @param systemKey
	 */
	public void insertAppSysCode(String cif, String orderId);
	
	
	/**
	 * @param srNumber
	 * @return
	 */
	public RazorServiceRequestDetails populateServiceRequest(String srNumber);
	
	/**
	 * @param cif
	 * @param applicantKey
	 * @param systemKey
	 */
	public List<PaymentTransaction> getAllPendingTransactions();
	
	/**
	 * @param paymentTransactionsList
	 * @return 
	 */
	public String updatePendingTrans(List<PaymentTransaction> paymentTransactionsList); 

	/**
	 * @param paymentEntity
	 */
	public void updatePayTrans(UpdatePaymentStatusRequest updatePaymentStatusRequest,String srNumber);
	
	/**
	 * @param orderId
	 * @param payTransStat
	 * @param pennatStat
	 */
	public void updateSerReqStatus(String orderId,BigDecimal payTransStat,BigDecimal pennatStat);
	
	/**
	 * @param orderId
	 * @return
	 */
	public String getSrNumber(String orderId);
	
	/**
	 * @param srNumber
	 * @return 
	 */
	public BigDecimal getApplicationKey(String srNumber);
	
	public BigDecimal getApplicantKey(BigDecimal applicationKey);

	BigDecimal getUserKey(String partnerName);

	BigDecimal getTransStatus(String orderId);

	public void updatePayTransForRefund(String refundId, String paymentId);
	
}