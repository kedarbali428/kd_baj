package com.bajaj.bfsd.razorpayintegration.business.processor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.razorpayintegration.bean.BreIntServiceRequest;
import com.bajaj.bfsd.razorpayintegration.bean.BrePaymentStatusReqBean;
import com.bajaj.bfsd.razorpayintegration.bean.BuyProcessRequest;
import com.bajaj.bfsd.razorpayintegration.bean.DGUpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.Notes;
import com.bajaj.bfsd.razorpayintegration.bean.RazorpayTransferRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RedeemConfirmRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.RefundResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.Transfer;
import com.bajaj.bfsd.razorpayintegration.bean.TransferRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.TransferResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusResponse;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;
import com.bajaj.bfsd.razorpayintegration.dao.RazorPayIntegrationDao;
import com.bajaj.bfsd.razorpayintegration.helper.RazorpayIntegrationHelper;
import com.bajaj.bfsd.razorpayintegration.mapper.RazorPayIntegrationMapper;
import com.bajaj.bfsd.razorpayintegration.repository.RazorPayIntegrationRepository;
import com.bajaj.bfsd.razorpayintegration.util.DynamoDbUtil;
import com.bajaj.bfsd.razorpayintegration.util.ServiceCallProcessorUtil;
import com.bfl.common.exceptions.BFLBusinessException;

@Component
public class RazorPayIntegrationBusinessProcessor extends BaseBusinessProcessor {
	private static final String CLASS_NAME = RazorPayIntegrationBusinessProcessor.class.getSimpleName();
	private static final String ERROR_RPIS_1000 = "RPIS-1000";
	
	@Autowired
	private RazorPayIntegrationMapper razorPayIntegrationMapper;

	@Autowired
	private ServiceCallProcessorUtil serviceCallProcessor;

	@Autowired
	private RazorPayIntegrationDao razorPayIntegrationDao;

	@Autowired
	private DynamoDbUtil dynamoDbUtil;
	
	@Autowired
	private RazorpayIntegrationHelper razorpayIntegrationHelper;

	@Autowired
	private RazorPayIntegrationRepository razorPayIntegrationRepository;
	
	@Value("${api.razorpayintegration.updatepaymentstatus.POST.url}")
	private String postProcessURL;
	
	@Value("${api.digitalgold.buyprocess.POST.url}")
	private String postConfirmURL;
	
	@Value("${api.confirm.digitalgold.redeemprocess.POST.url}")
	private String postRedeemConfirmURL;
	
	@Value("${api.razorpay.emandate.invoicestatus.POST.url}")
	private String saveTokenIdURL;
	
	@Value("${api.razorpay.emandate.paymentauthorized.POST.url}")
	private String savePaymentIdURL;
	
	@Value("${api.razorpay.emandate.tokenstatus.POST.url}")
	private String saveTokenStatusURL;
	
	@Value("${safegoldaccount.digigold}")
	private String safegoldAccountDetail;
	
	@Value("${bajajaccount.digigold}")
	private String bajajAccountDetail;
	
	

	/**
	 * getBookingDetails from razor pay service.
	 * 
	 * @param generateOrderIdRequestBean
	 * @param l3ProductId
	 * @return GenerateOrderIdResponseBean
	 */
	public GenerateOrderIdResponseBean getBookingDetails(GenerateOrderIdRequestBean generateOrderIdRequestBean) {
		GenerateOrderIdResponseBean generateOrderIdResponseBean;
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"getBookingDetails - start" + generateOrderIdRequestBean);
		BigDecimal amount = generateOrderIdRequestBean.getAmount();
		generateOrderIdRequestBean.setCurrency("INR");
		generateOrderIdRequestBean.setPayment_Capture(1);
		generateOrderIdRequestBean.setReciept(null);
		// amount is converted in paise.
		generateOrderIdRequestBean.setAmount(amount.multiply(BigDecimal.valueOf(100)));
		// razor pay wrapper request mapping
		BreIntServiceRequest breIntServiceRequest = razorPayIntegrationMapper
				.mapRazorPayRequest(generateOrderIdRequestBean);
		// calling razor pay service.
		generateOrderIdResponseBean = (GenerateOrderIdResponseBean) callIntegrationServiceLayer(breIntServiceRequest);
		// secret key fetched from db.
		generateOrderIdResponseBean.setAccessKey(
				razorPayIntegrationDao.getSecretApiKey(generateOrderIdRequestBean.getProductCode()).getApikey());
		// call to persist mapping of srKey and OrderId
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"generateOrderIdRequestBean.getSrNumber" + generateOrderIdRequestBean.getSrNumber()+"generateOrderIdResponseBean.getOrderId() "+generateOrderIdResponseBean.getOrderId());
		razorPayIntegrationDao.updateOrderId(generateOrderIdRequestBean.getSrNumber(),
				generateOrderIdResponseBean.getOrderId());
		razorPayIntegrationDao.insertPayTrans(generateOrderIdRequestBean.getSrNumber(),
				generateOrderIdRequestBean.getProductCode());
		/**
		 * As Digital gold application is migrated to postgres db, so application key will not be available at oracle end.
		 * So applicant & application key will be fetched from request object generateOrderIdRequestBean.
		 */
		if(generateOrderIdRequestBean.getProductCode().equalsIgnoreCase(RazorPayIntegrationConstants.DIGIPRODCODE) && 
				!StringUtils.isEmpty(generateOrderIdRequestBean.getLoanAccountNo()) ){
			dynamoDbUtil.persistInDynamo(generateOrderIdRequestBean.getLoanAccountNo(), generateOrderIdRequestBean.getApplicantId(),
					generateOrderIdResponseBean, serviceCallProcessor.mapToJson(breIntServiceRequest.getReqObject()),
					RazorPayIntegrationConstants.RAZORPAY, RazorPayIntegrationConstants.ORDER_ID_SOURCE_TYPE);
		}else {
			// call to get application key
			BigDecimal applicationKey = razorPayIntegrationDao.getApplicationKey(generateOrderIdRequestBean.getSrNumber());

			if (null != applicationKey) {
				// call to get applicant key
				BigDecimal applicantKey = razorPayIntegrationDao.getApplicantKey(applicationKey);
				// dynamo db updation
				if (null != applicantKey) {
					dynamoDbUtil.persistInDynamo(applicationKey.toString(), applicantKey.toString(),
							generateOrderIdResponseBean, serviceCallProcessor.mapToJson(breIntServiceRequest.getReqObject()),
							RazorPayIntegrationConstants.RAZORPAY, RazorPayIntegrationConstants.ORDER_ID_SOURCE_TYPE);
				}
			}	
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getBookingDetails - End" + generateOrderIdResponseBean);
		return generateOrderIdResponseBean;

	}

	@SuppressWarnings("unchecked")
	public UpdatePaymentStatusResponse updatePaymentStatus(String jsonRequest) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				RazorPayIntegrationConstants.UPDATE_PAYMENT_STATUS_START);
		UpdatePaymentStatusResponse paymentStatusResponse = new UpdatePaymentStatusResponse();
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> responseEntity;
		headers.setContentType(MediaType.APPLICATION_JSON);
		if (!StringUtils.isEmpty(jsonRequest)) {
			UpdatePaymentStatusRequest updatePaymentStatusRequest=razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(jsonRequest);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, " updatePaymentStatusRequest.getOrderId() :: "+updatePaymentStatusRequest.getOrderId());
			BigDecimal payTranStat=razorPayIntegrationDao.getTransStatus(updatePaymentStatusRequest.getOrderId());
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, " updatePaymentStatusRequest.payTranStat :: "+payTranStat);
			if(payTranStat.equals(BigDecimal.ZERO)) {
			// call to fetch srNumber on the basis of order Id
			String srNumber = razorPayIntegrationDao.getSrNumber(updatePaymentStatusRequest.getOrderId());

			// call to update payment transaction table for bank name, method and other
			// details.
			razorPayIntegrationDao.updatePayTrans(updatePaymentStatusRequest, srNumber);
			// call to update service request stp detail table for status of transaction
			razorPayIntegrationDao.updateSerReqStatus(updatePaymentStatusRequest.getOrderId(), BigDecimal.ONE, BigDecimal.ZERO);

			// pennant call to update the transaction detail.
			String paymentStatusUrl = env.getProperty("api.lms.paymentstatus.update.POST.url");
			Map<String, String> params = new HashMap<>();
			params.put("srNumber", srNumber);
			BrePaymentStatusReqBean paymentStatusReqBean = razorPayIntegrationMapper.mapBreRequest(updatePaymentStatusRequest.getDescription(),updatePaymentStatusRequest.getPaymentId());
			String breReqString = serviceCallProcessor.mapToJson(paymentStatusReqBean);
			responseEntity = (ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST,
					paymentStatusUrl, null, ResponseBean.class, params, breReqString, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "LMS Request Json :: "+breReqString);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "LMS Response Json :: "+responseEntity);
			// call to get application key
			BigDecimal applicationKey = razorPayIntegrationDao.getApplicationKey(srNumber);

			if (null != applicationKey) {
				// call to get applicant key
				BigDecimal applicantKey = razorPayIntegrationDao.getApplicantKey(applicationKey);
				// dynamo db updation
				if (null != applicantKey) {
					dynamoDbUtil.persistInDynamo(applicationKey.toString(), applicantKey.toString(), responseEntity,jsonRequest, RazorPayIntegrationConstants.RAZORPAY,
							RazorPayIntegrationConstants.PAYMENT_STATUS_UPDATE_TYPE);
				}
			}
			if (null != responseEntity && HttpStatus.OK.equals(responseEntity.getStatusCode())
					&& null != responseEntity.getBody().getPayload()
					&& CollectionUtils.isEmpty(responseEntity.getBody().getErrorBean())) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, " LMS Response Payload :: "+responseEntity.getBody().getPayload().toString());
				LinkedHashMap<String, String> map = (LinkedHashMap<String, String>)responseEntity.getBody().getPayload();
				String returncode = map.get(RazorPayIntegrationConstants.RETURN_CODE);
				String returnStatus=map.get(RazorPayIntegrationConstants.RETURN_STATUS);
				// call to update pennant update status in service request stp detail table.
				if(StringUtils.equals(RazorPayIntegrationConstants.RETURN_CODE_SUCCESS, returncode)) {
				razorPayIntegrationDao.updateSerReqStatus(updatePaymentStatusRequest.getOrderId(), BigDecimal.ONE,
						new BigDecimal("4"));
				paymentStatusResponse.setStatus(RazorPayIntegrationConstants.RESPONSE_SUCCESS);
				}else {
					logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, RazorPayIntegrationConstants.PENNAT_FAIL+returnStatus);
					throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1010,
							env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1010));
				}
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, RazorPayIntegrationConstants.PENNAT_FAIL);
				throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1010,
						env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1010));
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					RazorPayIntegrationConstants.UPDATE_PAYMENT_STATUS_END);
		}else{
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					RazorPayIntegrationConstants.EXCEEDED_TIME_LIMIT);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1014,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1014));
		}
	 } else {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					RazorPayIntegrationConstants.UPDATE_PAYMENT_STATUS_NO_ENTITY);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1008,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1008));
		}
		return paymentStatusResponse;

	}

	/**
	 * Razor pay wrapper service is being consumed and order_id is generated over
	 * here.
	 * 
	 * @param breIntServiceRequest
	 * @return Object
	 */
	private Object callIntegrationServiceLayer(BreIntServiceRequest breIntServiceRequest) {
		Object resObj = new Object();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
		ResponseEntity<ResponseBean> response;
		String requestStr = serviceCallProcessor.mapToJson(breIntServiceRequest.getReqObject());
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, requestStr);
		response = BFLCommonRestClient.create(breIntServiceRequest.getBreIntUrl(), null, String.class, null, requestStr,
				headers);
		if (null != response && HttpStatus.OK.equals(response.getStatusCode())
				&& null != response.getBody().getPayload()) {
			JSONObject json = new JSONObject(response.getBody().getPayload().toString());

			if (null != json.get("payload") && StatusCode.SUCCESS.toString().equals(json.get("status"))) {
				json = new JSONObject(json.get("payload").toString());
				// conversion of response object in required class type.
				resObj = serviceCallProcessor.getResponseObjectFromResponseJsonString(json.toString(),
						breIntServiceRequest.getClassType());
			} else {
				// when status is other than OK
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, response.getBody().getPayload().toString());
				throw new BFLBusinessException(ERROR_RPIS_1000, env.getProperty(ERROR_RPIS_1000));
			}
		} else if (null != response && null != response.getBody() && null != response.getBody().getPayload()) {
			// when unable to consume razor pay service.
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, response.getBody().getPayload().toString());
			throw new BFLBusinessException(ERROR_RPIS_1000, env.getProperty(ERROR_RPIS_1000));
		}
		return resObj;
	}


	/**
	 * @return
	 */
	public String updatePendingTransStatus() {
		return razorPayIntegrationRepository.updatePendingTransStatus();
	}
	
	
	/**Route the web-hook as per source and event.
	 * 
	 * @param headers
	 * @param jsonRequest
	 * @param source
	 * @return
	 */
	public ResponseEntity<ResponseBean> selectProcess(HttpHeaders headers, String jsonRequest,String source) {
		ResponseEntity<ResponseBean> response = null;
		if (null != headers&&null!=headers.get(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE)) {
			String signature = headers.get(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE).get(0);
			if(StringUtils.equals(RazorPayIntegrationConstants.PG_SOURCE, source)) {
				//validate signature and call pg service endpoint.
				razorpayIntegrationHelper.validateSignature(signature, jsonRequest, env.getProperty(RazorPayIntegrationConstants.SECRET_KEY_PG));
				response=razorpayIntegrationHelper.invokeEndpoint(postProcessURL, jsonRequest,headers);
			}else if(StringUtils.equals(RazorPayIntegrationConstants.EM_SOURCE, source)){
				//validate signature and identify the service which need to be called on the basis of event received.
				razorpayIntegrationHelper.validateSignature(signature, jsonRequest, env.getProperty(RazorPayIntegrationConstants.SECRET_KEY_EM));
				JSONObject jsonObject = new JSONObject(jsonRequest);
				String event = jsonObject.getString(RazorPayIntegrationConstants.REQUEST_EVENT);
				String endpointUrl = getEndpoint(event);
				response=razorpayIntegrationHelper.invokeEndpoint(endpointUrl, jsonRequest,headers);
			}
			else {
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Invalid source received : " + source);
				throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1015,
						env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1015));
			}
		}
		return response;
	}
	
	/**
	 * @param event
	 * @return enpoint
	 * @Desc This method returns endpoint depending on event in webhook
	 */
	private String getEndpoint(String event) {
		switch (event) {
		case RazorPayIntegrationConstants.EVENT_INVOICE_PAID:
		case RazorPayIntegrationConstants.EVENT_INVOICE_EXPIRED:
			return saveTokenIdURL;
		case RazorPayIntegrationConstants.EVENT_ORDER_PAID:
		case RazorPayIntegrationConstants.EVENT_PAYMENT_CAPTURED:
		case RazorPayIntegrationConstants.EVENT_PAYMENT_FAILED:
			return savePaymentIdURL;
		case RazorPayIntegrationConstants.EVENT_TOKEN_CONFIRMED:
		case RazorPayIntegrationConstants.EVENT_TOKEN_REJECTED:
			return saveTokenStatusURL;
		default:
			throw new BFLBusinessException();
		}
	}

	public ResponseEntity<ResponseBean> digitalGoldSelectProcess(HttpHeaders headers, String jsonRequest) {
		UpdatePaymentStatusResponse paymentStatusResponse = new UpdatePaymentStatusResponse();
		ResponseBean responseBean = null;
		if (null != headers && null != headers.get(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE)) {
			String signature = headers.get(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE).get(0);

			razorpayIntegrationHelper.validateSignature(signature, jsonRequest,
					env.getProperty(RazorPayIntegrationConstants.SECRET_KEY_DG));
			DGUpdatePaymentStatusRequest updatePaymentStatusRequest = razorPayIntegrationMapper
					.dgMapJsonToUpadatePaymentRequest(jsonRequest);
			getUserKey(headers);
			BigDecimal payTranStat = updateDigitalGoldPaymentStatus(jsonRequest);
			
			if (payTranStat.equals(BigDecimal.ZERO)) {
				if ("buy".equals(updatePaymentStatusRequest.getJourneyType())) {
					BuyProcessRequest buyProcessRequest = razorPayIntegrationMapper.getbuyProcessRequest(updatePaymentStatusRequest);
					razorpayIntegrationHelper.callconfirmService(postConfirmURL, buyProcessRequest, headers);

				} else if ("redeem".equals(updatePaymentStatusRequest.getJourneyType())) {
					RedeemConfirmRequest redeemConfirmRequest = razorPayIntegrationMapper
							.getRedeemConfirmRequest(updatePaymentStatusRequest);
					razorpayIntegrationHelper.callredeemConfirmService(postRedeemConfirmURL, redeemConfirmRequest,
							updatePaymentStatusRequest.getOrderId(), headers);

				} else {
					paymentStatusResponse.setStatus(RazorPayIntegrationConstants.RESPONSE_INVALID_JOURNEYTYPE);
					responseBean = new ResponseBean(paymentStatusResponse);
					return new ResponseEntity<>(responseBean, HttpStatus.OK);
				}

			}
			paymentStatusResponse.setStatus(RazorPayIntegrationConstants.RESPONSE_SUCCESS);
			responseBean = new ResponseBean(paymentStatusResponse);

		}
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	private BigDecimal updateDigitalGoldPaymentStatus(String jsonRequest) {
		BigDecimal payTranStat;
		if (!StringUtils.isEmpty(jsonRequest)) {
			UpdatePaymentStatusRequest updatePaymentStatusRequest = razorPayIntegrationMapper
					.mapJsonToUpadatePaymentRequest(jsonRequest);
			DGUpdatePaymentStatusRequest dgUpdatePaymentStatusRequest = razorPayIntegrationMapper
					.dgMapJsonToUpadatePaymentRequest(jsonRequest);
			payTranStat = razorPayIntegrationDao.getTransStatus(updatePaymentStatusRequest.getOrderId());
			if (payTranStat.equals(BigDecimal.ZERO)) {
				String srNumber = razorPayIntegrationDao.getSrNumber(updatePaymentStatusRequest.getOrderId());
				razorPayIntegrationDao.updatePayTrans(updatePaymentStatusRequest, srNumber);
				razorPayIntegrationDao.updateSerReqStatus(updatePaymentStatusRequest.getOrderId(), BigDecimal.ONE,
						BigDecimal.ZERO);

				if (null != dgUpdatePaymentStatusRequest.getApplicationId()&& null!=dgUpdatePaymentStatusRequest.getApplicantId()) {
						dynamoDbUtil.persistInDynamo(dgUpdatePaymentStatusRequest.getApplicationId(), dgUpdatePaymentStatusRequest.getApplicantId(), null,
								jsonRequest, RazorPayIntegrationConstants.RAZORPAY,
								RazorPayIntegrationConstants.PAYMENT_STATUS_UPDATE_TYPE);
					
				}

			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						RazorPayIntegrationConstants.EXCEEDED_TIME_LIMIT);
				throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1014,
						env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1014));
			}

		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					RazorPayIntegrationConstants.UPDATE_PAYMENT_STATUS_NO_ENTITY);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1008,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1008));
		}
		return payTranStat;

	}
	
	public TransferResponseBean callRazorpayTransferApi(RazorpayTransferRequest razorpayTransferRequest){
		TransferResponseBean transferResponseBean;
		logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"callRazorpayTransferApi - start" + razorpayTransferRequest);
		
		if(null!=razorpayTransferRequest.getProductCode() && null!=razorpayTransferRequest.getPaymentId() 
				&& null!=razorpayTransferRequest.getAmount() && null!=razorpayTransferRequest.getVendorAmount()){
			
			TransferRequestBean transferRequestBean = new TransferRequestBean();
			transferRequestBean.setProductCode(razorpayTransferRequest.getProductCode());
			transferRequestBean.setPaymentId(razorpayTransferRequest.getPaymentId());
			
			Long vendorAmount = (razorpayTransferRequest.getVendorAmount().multiply(BigDecimal.valueOf(100))).longValue();
			Long amount = (razorpayTransferRequest.getAmount().multiply(BigDecimal.valueOf(100))).longValue();
			Notes notes = new Notes(razorpayTransferRequest.getApplicationId(), razorpayTransferRequest.getVendorTxId());
			
			List<Transfer> transfers = new ArrayList<>();
			
			//SafeGold Transfer detail
			Transfer vendorTransferDetail = new Transfer(safegoldAccountDetail, vendorAmount.toString(), "INR", notes);

			//Bajaj Transfer Detail
			Transfer transferDetail = new Transfer(bajajAccountDetail, amount.toString(), "INR", notes);
			
			transfers.add(transferDetail);
			transfers.add(vendorTransferDetail);
			
			transferRequestBean.setTransfers(transfers);
			
			BreIntServiceRequest breIntServiceRequest = razorPayIntegrationMapper
					.mapRazorPayRequestForTransfer(transferRequestBean);
			
			// calling razor pay pg service.
			transferResponseBean = (TransferResponseBean) callIntegrationServiceLayer(breIntServiceRequest);
		}else {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Request object mandatory fields are null" + razorpayTransferRequest);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1018, env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1018));
		}
		
		logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"callRazorpayTransferApi - end. Response:" + transferResponseBean);
		
		return transferResponseBean;
		
	}
	
	public RefundResponseBean callRazorpayRefundApi(RefundRequestBean refundRequestBean){
		RefundResponseBean refundResponseBean;
		logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"callRazorpayRefund - start" + refundRequestBean);
		if(!StringUtils.isEmpty(refundRequestBean.getPaymentId()) && !StringUtils.isEmpty(refundRequestBean.getProductCode())){
			
			BreIntServiceRequest breIntServiceRequest = razorPayIntegrationMapper
					.mapRazorPayRequestForRefund(refundRequestBean);
			
			// calling razor pay pg service.
			refundResponseBean = (RefundResponseBean) callIntegrationServiceLayer(breIntServiceRequest);
		}else{
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Request object mandatory fields are null" + refundRequestBean);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1020, env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1020));
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"callRazorpayRefund - end. Response:" + refundResponseBean);
		
		return refundResponseBean;
	}

	private void getUserKey(HttpHeaders headers) {
		BigDecimal userKey = razorpayIntegrationHelper.digitalGoldauthenticatePartner(headers);
		setHeader(headers, userKey);

	}

	private void setHeader(HttpHeaders headers, BigDecimal userKey) {
		headers.set("userkey", userKey.toString());
		headers.setContentType(MediaType.APPLICATION_JSON);

	}
	
	public void updatePaymentTransactionForRefund(String refundId, String paymentId){
		razorPayIntegrationDao.updatePayTransForRefund(refundId, paymentId);
	}

}