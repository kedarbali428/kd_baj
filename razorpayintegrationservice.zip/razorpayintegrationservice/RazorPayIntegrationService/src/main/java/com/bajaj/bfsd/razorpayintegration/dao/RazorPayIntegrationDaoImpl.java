package com.bajaj.bfsd.razorpayintegration.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLDao;
import com.bajaj.bfsd.razorpayintegration.bean.RazorServiceRequestDetails;
import com.bajaj.bfsd.razorpayintegration.bean.SerReqStprazorDetail;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;
import com.bajaj.bfsd.razorpayintegration.enumeration.PayEventType;
import com.bajaj.bfsd.razorpayintegration.model.ApplicantSysCode;
import com.bajaj.bfsd.razorpayintegration.model.PayGatewayPartner;
import com.bajaj.bfsd.razorpayintegration.model.PaymentTransaction;
import com.bajaj.bfsd.razorpayintegration.model.PgmerchantProductsMapping;
import com.bajaj.bfsd.razorpayintegration.util.RazorSRDbUtil;
import com.bajaj.bfsd.razorpayintegration.util.ServiceCallProcessorUtil;
import com.bfl.common.exceptions.BFLBusinessException;

@Component
@Repository
@SuppressWarnings("unchecked")
public class RazorPayIntegrationDaoImpl extends BFLDao implements RazorPayIntegrationDao {

	private static final String THIS_CLASS = RazorPayIntegrationDaoImpl.class.getSimpleName();
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	EntityManager entityManager;
	@Autowired
	Environment env;
	@Autowired
	RazorSRDbUtil razorSRDbUtil;

	@Override
	public PayGatewayPartner getSecretApiKey(String productId) {
		logger.info(THIS_CLASS, BFLLoggerComponent.DAO, RazorPayIntegrationConstants.GETSECRETKEY_START);

		try {
			// call populate mapping of productId and merchantId on the basis of given
			// product.
			PgmerchantProductsMapping pgmerchantProductsMapping = getPgmerchantProductsMapping(productId);
			Query query = entityManager.createQuery(RazorPayIntegrationConstants.GET_SECRET_KEY_QUERY);
			query.setParameter(RazorPayIntegrationConstants.MERCHANT_ID, pgmerchantProductsMapping.getMerchantid());
			List<PayGatewayPartner> result = query.getResultList();
			if (!CollectionUtils.isEmpty(result)) {
				logger.info(THIS_CLASS, BFLLoggerComponent.DAO,
						RazorPayIntegrationConstants.GETSECRETKEY_END + result.get(0));
				return result.get(0);
			} else {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
						RazorPayIntegrationConstants.GETSECRETKEY_END + productId);
				throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1001,
						env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1001));
			}
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.GETSECRETKEY_EXCEPTION_MESSAGE, e);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1001,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1001));
		}
	}


	@Override
	@Transactional
	public void updateOrderId(String srNumber, String orderId) {
		try {
			//LEN-132
			RazorServiceRequestDetails serviceRequest = populateServiceRequest(srNumber);
			SerReqStprazorDetail serReqStpDetail = new SerReqStprazorDetail();
			serReqStpDetail.setPaytransrefnum(orderId);
			serReqStpDetail.setStpreqkey(serviceRequest.getSrKey());
			razorSRDbUtil.updateReqStpDtlRefNum(serReqStpDetail.getPaytransrefnum(),serReqStpDetail.getStpreqkey());
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.UPDATEORDERID_EXCEPTION_MESSAGE, e);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1002,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1002));
		}
	}
	
	@Transactional
	@Override
	public void insertPayTrans(String srNumber, String l3Product) {

		try {
			//LEN-132
			RazorServiceRequestDetails serviceRequest = populateServiceRequest(srNumber);
			PaymentTransaction paymentTransaction = new PaymentTransaction();
			paymentTransaction.setTransrefnum(srNumber);
			paymentTransaction.setTransresprefnum(StringUtils.EMPTY);
			paymentTransaction.setPaymentdate(getCurrentTimestamp());
			paymentTransaction.setTransstatus(BigDecimal.ZERO);
			JSONObject jsonObject = new JSONObject(getSerReqStpDetail(serviceRequest.getSrKey()).getStpreqattributes());
			paymentTransaction.setPayeventtype(new BigDecimal(PayEventType
					.valueOf(jsonObject.getString(RazorPayIntegrationConstants.PAY_EVENT_TYPE)).getValue()));
			paymentTransaction
					.setAmount(new BigDecimal(getSerReqStpDetail(serviceRequest.getSrKey()).getNetamount().toString()));
			paymentTransaction
					.setPaygatewaypartnerkey(new BigDecimal(getSecretApiKey(l3Product).getPaygatewaypartnerkey()));
			paymentTransaction.setCreatedt(getCurrentTimestamp());
			paymentTransaction.setIsactive(BigDecimal.ONE);
			entityManager.persist(paymentTransaction);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, RazorPayIntegrationConstants.PAYMENT_TRANSACTION_MESSAGE,
					e);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1003,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1003));
		}
	}

	@Transactional
	@Override
	public void updatePayTrans(UpdatePaymentStatusRequest updatePaymentStatusRequest,String srNumber) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "updatePayTrans ::");
		try {
			Query query = entityManager.createQuery(RazorPayIntegrationConstants.UPDATE_PAY_TRANS_QUERY);
			query.setParameter(RazorPayIntegrationConstants.TRANSSTATUS, BigDecimal.ONE);
			query.setParameter(RazorPayIntegrationConstants.PAYMENTBANKNAME, updatePaymentStatusRequest.getPaymentBank());
			query.setParameter(RazorPayIntegrationConstants.PAYMENTMODE, updatePaymentStatusRequest.getPaymentMethod());
			query.setParameter(RazorPayIntegrationConstants.TRANSRESPREFNUM, updatePaymentStatusRequest.getPaymentId());
			query.setParameter(RazorPayIntegrationConstants.TRANSREFNUM, srNumber);
			int rowsUpdated = query.executeUpdate();
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "updatePayTrans rowsUpdated:: "+rowsUpdated);
			if (rowsUpdated > 0) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
						MessageFormat.format(RazorPayIntegrationConstants.UPDATE_PAY_TRANS_SUCCESS, rowsUpdated,
								updatePaymentStatusRequest.getOrderId()));
			} else {
				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
						MessageFormat.format(RazorPayIntegrationConstants.UPDATE_PAY_TRANS_FAILURE, rowsUpdated,
								updatePaymentStatusRequest.getOrderId()));
				throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1005,
						env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1005));
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, RazorPayIntegrationConstants.UPDATE_PAY_TRANS_END);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, MessageFormat
					.format(RazorPayIntegrationConstants.UPDATE_PAY_TRANS_EXCEPTION, updatePaymentStatusRequest.getOrderId()), e);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1005,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1005));
		}

	}

	//LEN-132
	@Override
	@Transactional
	public void updateSerReqStatus(String orderId, BigDecimal payTransStat, BigDecimal pennatStat) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, RazorPayIntegrationConstants.UPDATE_SER_REQ_STP_STATUS_START);
		try {
			SerReqStprazorDetail serReqStpDetail = new SerReqStprazorDetail();
			serReqStpDetail.setTransstatus(pennatStat);
			serReqStpDetail.setPaytransstatus(payTransStat);
			serReqStpDetail.setPaytransrefnum(orderId);
			razorSRDbUtil.updateServiceReqStpDetails(serReqStpDetail);
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.UPDATE_SER_REQ_STATUS_STP_END);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					MessageFormat.format(RazorPayIntegrationConstants.UPDATE_SER_REQ_STATUS_STP_EXCEPTION, orderId),e);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1006,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1006));
		}
	}

	@Override
@Transactional
	public void insertAppSysCode(String cif, String orderId) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
				MessageFormat.format(RazorPayIntegrationConstants.INSERT_APP_SYS_CODE_START, orderId));
		try {
			Query applicantQuery = entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_APPLICANT_KEY_QUERY);
			applicantQuery.setParameter(RazorPayIntegrationConstants.ORDER_ID, orderId);
			BigDecimal applicantKey = (BigDecimal) applicantQuery.getSingleResult();
			Query systemKeyQuery = entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_SYSTEM_KEY_QUERY);
			systemKeyQuery.setParameter(RazorPayIntegrationConstants.ORDER_ID, orderId);
			BigDecimal systmKey = (BigDecimal) systemKeyQuery.getSingleResult();
			ApplicantSysCode applicantSysCode = new ApplicantSysCode();
			applicantSysCode.setRefcode(cif);
			applicantSysCode.setApplicantkey(applicantKey);
			applicantSysCode.setSystemkey(systmKey);
			applicantSysCode.setLstupdatedt(getCurrentTimestamp());
			applicantSysCode.setLstupdateby(RazorPayIntegrationConstants.SYSTEM);
			entityManager.persist(applicantSysCode);
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
					MessageFormat.format(RazorPayIntegrationConstants.INSERT_APP_SYS_CODE_END, orderId));
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					MessageFormat.format(RazorPayIntegrationConstants.INSERT_APP_SYS_CODE_EXCEPTION, orderId),e);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1004,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1004));
		}
	}
		//LEN-132
	@Override
	public String getSrNumber(String orderId) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
				MessageFormat.format(RazorPayIntegrationConstants.GET_SR_NUMBER_START, orderId));
		String srNumber=null;
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,"getSrNumber OrderId : "+orderId);
			RazorServiceRequestDetails razorServiceRequestDetails =razorSRDbUtil.getRazServReqnum(orderId);
			 srNumber = razorServiceRequestDetails.getSrnumber();
			 logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,"getSrNumber OrderId : "+srNumber);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					MessageFormat.format(RazorPayIntegrationConstants.GET_SR_NUMBER_EXCEPTION, orderId),e);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1007,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1007));
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
				MessageFormat.format(RazorPayIntegrationConstants.GET_SR_NUMBER_END, orderId));
		return srNumber;
	}

	//LEN-132
	public SerReqStprazorDetail getSerReqStpDetail(long srKey) {
		return razorSRDbUtil.getRazStpDetails(srKey);

	}

	public static Timestamp getCurrentTimestamp() {
		Date date = Calendar.getInstance().getTime();
		return new Timestamp(date.getTime());
	}

	/**
	 * Populate data of PgmerchantProductsMapping.
	 * 
	 * @param productId
	 * @return
	 */
	private PgmerchantProductsMapping getPgmerchantProductsMapping(String productId) {
		logger.info(THIS_CLASS, BFLLoggerComponent.DAO,
				RazorPayIntegrationConstants.GET_PGMERCHANT_PRODUCTS_MAPPING_START);
		Query query = entityManager.createQuery(RazorPayIntegrationConstants.GET_PGMERCHANTPRODUCTS_MAPPING);
		query.setParameter(RazorPayIntegrationConstants.PRODUCT_ID, productId);
		List<PgmerchantProductsMapping> result = query.getResultList();
		if (!CollectionUtils.isEmpty(result)) {
			logger.info(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.GET_PGMERCHANT_PRODUCTS_MAPPING_END2 + result.get(0));
			return result.get(0);
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.GET_PGMERCHANT_PRODUCTS_MAPPING_END + productId);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1001,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1001));
		}
	}


	@Override
	public RazorServiceRequestDetails populateServiceRequest(String srNumber) {
		logger.info(THIS_CLASS, BFLLoggerComponent.DAO, RazorPayIntegrationConstants.POPULATE_SERVICE_REQUEST_START);
		RazorServiceRequestDetails razorServiceRequestDetails = razorSRDbUtil.getSRDetails(srNumber);

		if (null != razorServiceRequestDetails) {
			logger.info(THIS_CLASS, BFLLoggerComponent.DAO, "populateServiceRequest not null :");
			return razorServiceRequestDetails;
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.POPULATE_SERVICE_REQUEST_NO_RECORD + srNumber);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1001,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1001));

		}

	}

	@Override
	public List<PaymentTransaction> getAllPendingTransactions() {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
				RazorPayIntegrationConstants.GET_ALL_PENDING_TRANSACTIONS_START);
		Query query = entityManager.createQuery(RazorPayIntegrationConstants.GET_PENDING_TRANSACTION);
		List<PaymentTransaction> result = query.getResultList();
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, RazorPayIntegrationConstants.GET_ALL_PENDING_TRANSACTIONS_END);
		return result;
	}

	@Override
	@Transactional
	public String updatePendingTrans(List<PaymentTransaction> paymentTransactionsList) {
		Long allowedDuration = new Long(env.getProperty(RazorPayIntegrationConstants.CHANGE_PMT_STATUS_HOURS_VAL));
		String response = RazorPayIntegrationConstants.RESPONSE_SUCCESS;
		int updateCount = 0;
		for (PaymentTransaction paymentTransaction : paymentTransactionsList) {
			String transRefNum = paymentTransaction.getTransrefnum();
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.UPDATE_PENDINGTRANS_REQUEST + transRefNum);
			LocalDateTime pmtReqDate = null != paymentTransaction.getPaymentdate()
					? new Timestamp(paymentTransaction.getPaymentdate().getTime()).toLocalDateTime()
					: null;

			LocalDateTime currentDate = ServiceCallProcessorUtil.getCurrentDate().toLocalDateTime();

			Duration durationInHours = Duration.between(pmtReqDate, currentDate);
			long hoursElapsed = durationInHours.toHours();

			try {
				if (hoursElapsed > allowedDuration) {
					// payment trans status update in payment transaction table
					paymentTransaction.setLstupdateby(RazorPayIntegrationConstants.SYSTEM);
					paymentTransaction.setLstupdatedt(ServiceCallProcessorUtil.getCurrentDate());
					paymentTransaction.setTransstatus(RazorPayIntegrationConstants.PAY_STS_FAIL);
					entityManager.merge(paymentTransaction);
					logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
							RazorPayIntegrationConstants.UPDATE_PENDINGTRANS_SUCCESS_PAYMENTTRANS + transRefNum);
					// payment trans status and pennant trans stat updation in SerReqStpDetail
					// table.
					updateSerReqStpDetail(transRefNum);
					logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
							RazorPayIntegrationConstants.UPDATE_PENDINGTRANS_SUCCESS_SERREQSTP + transRefNum);
				}
			} catch (Exception e) {
				updateCount++;
				// partial success
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
						RazorPayIntegrationConstants.UPDATE_PENDINGTRANS_EXCEPTION + transRefNum, e);
			}
		}
		if (updateCount > 0) {
			response = RazorPayIntegrationConstants.PARTIAL_SUCCESS;
		}
		return response;

	}

	/**
	 * This method is used by schedular for updating status, pending for more than
	 * 12 hrs
	 * 
	 * @param paymentTransaction
	 * @param transRefNum
	 */
	//LEN-132
	private void updateSerReqStpDetail(String transRefNum) {
		RazorServiceRequestDetails serviceRequestDetails = populateServiceRequest(transRefNum);
		if (null != serviceRequestDetails) {
			//LEN-132
			closeServiceRequest(serviceRequestDetails.getSrKey());
			
			SerReqStprazorDetail serReqStpDetail = getSerReqStpDetail(serviceRequestDetails.getSrKey());
			if (null != serReqStpDetail) {
				serReqStpDetail.setLstupdateby(RazorPayIntegrationConstants.SYSTEM);
				serReqStpDetail.setLstupdatedt(ServiceCallProcessorUtil.getCurrentDate());
				serReqStpDetail.setPaytransstatus(RazorPayIntegrationConstants.PAY_STS_FAIL);
				serReqStpDetail.setTransstatus(RazorPayIntegrationConstants.PENNANT_TRAN_STAT_FAIL);
				serReqStpDetail.setStpreqkey(serviceRequestDetails.getSrKey());
				serReqStpDetail.setDateflag("Y");
				razorSRDbUtil.updateServiceReqStpDetails(serReqStpDetail);

			}else {
				throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1004,
						RazorPayIntegrationConstants.SER_REQ_STP_DETAIL_EXCEPTION + transRefNum);
			}

		} else {
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1004,
					RazorPayIntegrationConstants.SERVICE_REQUEST_EXCEPTION + transRefNum);
		}
	}


	@Override
	public BigDecimal getApplicationKey(String srNumber) {
		logger.info(THIS_CLASS, BFLLoggerComponent.DAO,
				RazorPayIntegrationConstants.GET_APPLICATION_KEY_START );
		try {
			//LEN-132
			RazorServiceRequestDetails serviceRequest = populateServiceRequest(srNumber);
		Query query= entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_APPLICATION_KEY_QUERY);
		query.setParameter(RazorPayIntegrationConstants.REF_PROD_NUM, serviceRequest.getRefprodnum());
		List<BigDecimal> result = query.getResultList();
		if (!CollectionUtils.isEmpty(result)) {
			logger.info(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.GET_APPLICATION_KEY_END );
			return result.get(0);
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.GET_APPLICATION_KEY_NO_RECORDS);
			return null;
		}
		}catch(Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.GET_APPLICATION_KEY_EXCEPTION,e);
			return null;
		}
	}
	
	@Override
	public BigDecimal getApplicantKey(BigDecimal applicationKey) {
		logger.info(THIS_CLASS, BFLLoggerComponent.DAO,
				RazorPayIntegrationConstants.GET_APPLICANT_KEY_START );
		try {
		Query query= entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_APPLICANT_KEY);
		query.setParameter(RazorPayIntegrationConstants.APPLICATION_KEY,applicationKey );
		List<BigDecimal> result = query.getResultList();
		if (!CollectionUtils.isEmpty(result)) {
			logger.info(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.GET_APPLICANT_KEY_END );
			return result.get(0);
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.GET_APPLICANT_KEY_NO_RECORDS);
			return null;
		}
		}catch(Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,
					RazorPayIntegrationConstants.GET_APPLICANT_KEY_EXCEPTION,e);
			return null;
		}
	}
	
	@Override
	public BigDecimal getUserKey(String partnerName) {
		Query query = entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_USER_KEY);
		query.setParameter("partnerName", partnerName);
		List<BigDecimal> result = query.getResultList();
		return result.get(0);
	}
	
	@Override
	public BigDecimal getTransStatus(String orderId) {
		BigDecimal status=null;
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,"getTransStatus orderId : "+ orderId);
		RazorServiceRequestDetails razorServiceRequestDetails=	razorSRDbUtil.getRazorSerResol("NA",orderId);
		 status=razorServiceRequestDetails.getPaytransstatus();
		}catch(Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,"Exception occurred while checking status",e);
			throw new BFLBusinessException("RPIS-1016","Exception occurred while checking transaction status");
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,"getTransStatus status : "+ status);
		return status;
		
	}
	
	@Transactional
	@Override
	public void updatePayTransForRefund(String refundId, String paymentId) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, RazorPayIntegrationConstants.UPDATE_PAY_TRANS_FOR_REFUND_QUERY);
		try {
			Query query = entityManager.createQuery(RazorPayIntegrationConstants.UPDATE_PAY_TRANS_FOR_REFUND_QUERY);
			query.setParameter(RazorPayIntegrationConstants.REFUNDID, refundId);
			query.setParameter(RazorPayIntegrationConstants.REFUNDDATE, ServiceCallProcessorUtil.getCurrentDate());
			query.setParameter(RazorPayIntegrationConstants.TRANSRESPREFNUM, paymentId);
			int rowsUpdated = query.executeUpdate();
			if (rowsUpdated > 0) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,"refund id updated for payment id: "+ paymentId);
			} else {
				logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,"update in payment transaction failed for payment id : " +paymentId);
				throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1005,
						env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1005));
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, RazorPayIntegrationConstants.UPDATE_PAY_TRANS_END);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO,"exception occurred while updating payment transaction", e);
			throw new BFLBusinessException(RazorPayIntegrationConstants.ERROR_RPIS_1005,
					env.getProperty(RazorPayIntegrationConstants.ERROR_RPIS_1005));
		}

	}
	
	//LEN-132
	@Transactional
	public void closeServiceRequest(Long srKey) {

		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Inside closeServiceRequest() - srKey: " + srKey);
		
		RazorServiceRequestDetails razorServiceRequestDetails =razorSRDbUtil.getRazorSerResol(srKey.toString(),"NA");
		
		if (null != razorServiceRequestDetails && null != razorServiceRequestDetails.getSerreqresolutionkey()) {
			updateSerReqResolutions(null, RazorPayIntegrationConstants.SYSTEM,
					razorServiceRequestDetails.getSerreqresolutionkey().toString());
		}
		updateSrreqcurStatus(srKey, new BigDecimal(3), RazorPayIntegrationConstants.SYSTEM);
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Exit from closeServiceRequest()");

	}

		//LEN-132
		@Transactional
		public void updateSerReqResolutions(String remarks, String userkey, String serreqresolutionkey) {

			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
					"Inside updateSerReqResolutions - serreqresolutionkey: " + serreqresolutionkey);
			razorSRDbUtil.updateSerResolution(remarks, userkey, serreqresolutionkey);
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Exit from updateSerReqResolutions()");

		}

	//LEN-132
		@Transactional
		public void updateSrreqcurStatus(Long srKey, BigDecimal serreqcurstatus, String userKey) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO,
					"Inside updateSrreqcurStatus - serreqcurstatus: " + serreqcurstatus);
			razorSRDbUtil.updateSrreqcurStatus(srKey.toString(),serreqcurstatus.toString(),userKey);
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Exit from updateSrreqcurStatus()");

		}

}