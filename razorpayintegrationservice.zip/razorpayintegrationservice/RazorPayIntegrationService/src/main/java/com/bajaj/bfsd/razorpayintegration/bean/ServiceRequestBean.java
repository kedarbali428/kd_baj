package com.bajaj.bfsd.razorpayintegration.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class ServiceRequestBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private String payTransNum;

	private String srKey;

	private String remarks;
	
	private String userkey;
	
	private String serreqresolutionkey;
	
	private String serreqcurstatus;

	public String getPayTransNum() {
		return payTransNum;
	}

	public void setPayTransNum(String payTransNum) {
		this.payTransNum = payTransNum;
	}

	public String getSrKey() {
		return srKey;
	}

	public void setSrKey(String srKey) {
		this.srKey = srKey;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getUserkey() {
		return userkey;
	}

	public void setUserkey(String userkey) {
		this.userkey = userkey;
	}

	public String getSerreqresolutionkey() {
		return serreqresolutionkey;
	}

	public void setSerreqresolutionkey(String serreqresolutionkey) {
		this.serreqresolutionkey = serreqresolutionkey;
	}

	public String getSerreqcurstatus() {
		return serreqcurstatus;
	}

	public void setSerreqcurstatus(String serreqcurstatus) {
		this.serreqcurstatus = serreqcurstatus;
	}

	@Override
	public String toString() {
		return "ServiceRequestBean [payTransNum=" + payTransNum + ", srKey=" + srKey + ", remarks=" + remarks
				+ ", userkey=" + userkey + ", serreqresolutionkey=" + serreqresolutionkey + ", serreqcurstatus="
				+ serreqcurstatus + "]";
	}

	

	
	

}