package com.bajaj.bfsd.razorpayintegration.repository;
@FunctionalInterface
public interface RazorPayIntegrationRepository {

	/**
	 * @return
	 */
	public String updatePendingTransStatus();


}