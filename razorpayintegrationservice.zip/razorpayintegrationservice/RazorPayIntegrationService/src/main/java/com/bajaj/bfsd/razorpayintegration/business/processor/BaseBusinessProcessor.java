package com.bajaj.bfsd.razorpayintegration.business.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLBusinessProcessor;


@RefreshScope
@Component
public class BaseBusinessProcessor extends BFLBusinessProcessor{
	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	Environment env;
	
}
