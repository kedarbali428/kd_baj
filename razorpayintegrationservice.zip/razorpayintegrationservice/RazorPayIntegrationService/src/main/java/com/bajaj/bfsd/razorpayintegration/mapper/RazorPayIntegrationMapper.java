package com.bajaj.bfsd.razorpayintegration.mapper;

import java.util.Base64;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.razorpayintegration.bean.BreIntServiceRequest;
import com.bajaj.bfsd.razorpayintegration.bean.BrePaymentStatusReqBean;
import com.bajaj.bfsd.razorpayintegration.bean.BuyProcessRequest;
import com.bajaj.bfsd.razorpayintegration.bean.DGUpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.RedeemConfirmRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.RefundResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.TransferRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.TransferResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;

@Component
public class RazorPayIntegrationMapper extends BaseMapper {

	/**
	 * Mapper to map the request parameter for razor pay wrapper service.
	 * 
	 * @param generateOrderIdRequestBean
	 * @return BreIntServiceRequest
	 */
	public BreIntServiceRequest mapRazorPayRequest(GenerateOrderIdRequestBean generateOrderIdRequestBean) {
		BreIntServiceRequest breIntServiceRequest = new BreIntServiceRequest();
		breIntServiceRequest.setReqObject(generateOrderIdRequestBean);
		breIntServiceRequest.setBreIntUrl(env.getProperty("api.razorpay.pg.getorderid.POST.url"));
		breIntServiceRequest.setClassType(GenerateOrderIdResponseBean.class);
		return breIntServiceRequest;
	}

	/**
	 * Mapper to map request for pennant call.
	 * 
	 * @param updatePaymentStatusRequest
	 * @return
	 */
	public BrePaymentStatusReqBean mapBreRequest(String description, String paymentId) {
		BrePaymentStatusReqBean paymentStatusReqBean = new BrePaymentStatusReqBean();
		paymentStatusReqBean.setPartnername(RazorPayIntegrationConstants.RAZORPAY);
		paymentStatusReqBean.setInqueryType(RazorPayIntegrationConstants.POST);
		paymentStatusReqBean.setPaymentMode(RazorPayIntegrationConstants.NEFT);
		paymentStatusReqBean.setTxnMessage(description);
		paymentStatusReqBean.setTxnNumber(paymentId);
		if (!StringUtils.isEmpty(paymentId)) {
			paymentStatusReqBean.setResponseStatus("1");
		} else {
			paymentStatusReqBean.setResponseStatus("0");
		}
		return paymentStatusReqBean;
	}

	public UpdatePaymentStatusRequest mapJsonToUpadatePaymentRequest(String jsonRequest) {
		UpdatePaymentStatusRequest updatePaymentStatusRequest = new UpdatePaymentStatusRequest();
		JSONObject jsonObject = new JSONObject(jsonRequest);
		JSONObject payload = (JSONObject) jsonObject.get(RazorPayIntegrationConstants.PAYLOAD);
		JSONObject payment = (JSONObject) payload.get(RazorPayIntegrationConstants.PAYMENT);
		JSONObject entity = (JSONObject) payment.get(RazorPayIntegrationConstants.ENTITY);
		updatePaymentStatusRequest.setOrderId(entity.getString(RazorPayIntegrationConstants.ORDER_IDS));
		updatePaymentStatusRequest.setPaymentId(entity.getString(RazorPayIntegrationConstants.PAYMENT_ID));
		updatePaymentStatusRequest.setPaymentMethod(entity.getString(RazorPayIntegrationConstants.PAYMENT_METHOD));
		if (entity.get(RazorPayIntegrationConstants.BANK) instanceof String)
			updatePaymentStatusRequest.setPaymentBank(entity.getString(RazorPayIntegrationConstants.BANK));
		updatePaymentStatusRequest.setDescription(entity.getString(RazorPayIntegrationConstants.DESCRIPTION));
		return updatePaymentStatusRequest;
	}
	
	public DGUpdatePaymentStatusRequest dgMapJsonToUpadatePaymentRequest(String jsonRequest) {
		DGUpdatePaymentStatusRequest updatePaymentStatusRequest = new DGUpdatePaymentStatusRequest();
		JSONObject jsonObject = new JSONObject(jsonRequest);
		JSONObject payload = (JSONObject) jsonObject.get(RazorPayIntegrationConstants.PAYLOAD);
		JSONObject payment = (JSONObject) payload.get(RazorPayIntegrationConstants.PAYMENT);
		JSONObject entity = (JSONObject) payment.get(RazorPayIntegrationConstants.ENTITY);
		updatePaymentStatusRequest.setOrderId(entity.getString(RazorPayIntegrationConstants.ORDER_IDS));
		updatePaymentStatusRequest.setPaymentId(entity.getString(RazorPayIntegrationConstants.PAYMENT_ID));
		updatePaymentStatusRequest.setPaymentMethod(entity.getString(RazorPayIntegrationConstants.PAYMENT_METHOD));
		if (entity.get(RazorPayIntegrationConstants.BANK) instanceof String)
			updatePaymentStatusRequest.setPaymentBank(entity.getString(RazorPayIntegrationConstants.BANK));
		updatePaymentStatusRequest.setDescription(entity.getString(RazorPayIntegrationConstants.DESCRIPTION));
		updatePaymentStatusRequest.setAmount(Double.valueOf(entity.get(RazorPayIntegrationConstants.PAYMENT_AMOUNT).toString()));
		JSONObject note = (JSONObject) entity.get(RazorPayIntegrationConstants.NOTE);
		updatePaymentStatusRequest.setJourneyType(note.getString(RazorPayIntegrationConstants.JOURNEYTYPE));
		updatePaymentStatusRequest.setApplicationId(note.getString(RazorPayIntegrationConstants.APPLICATIONID));
		updatePaymentStatusRequest.setApplicantId(note.getString(RazorPayIntegrationConstants.APPLICANTID));
		return updatePaymentStatusRequest;
	}

	public BuyProcessRequest getbuyProcessRequest(DGUpdatePaymentStatusRequest updatePaymentStatusRequest) {
		BuyProcessRequest buyProcessRequest = new BuyProcessRequest();
		buyProcessRequest.setOrderId(updatePaymentStatusRequest.getOrderId());
		buyProcessRequest.setPaymentId(updatePaymentStatusRequest.getPaymentId());
		buyProcessRequest.setDgProviderCode("SFGLD");
		buyProcessRequest.setRequestType("confirm");
		String encodedString = Base64.getEncoder().encodeToString(env.getProperty(RazorPayIntegrationConstants.SECRET_KEY_DG).getBytes());
		buyProcessRequest.setAppSource(encodedString);
		buyProcessRequest.setTotalAmount(updatePaymentStatusRequest.getAmount());
		return buyProcessRequest;
	}
	
	public BreIntServiceRequest mapRazorPayRequestForTransfer(TransferRequestBean transferRequestBean) {
		BreIntServiceRequest breIntServiceRequest = new BreIntServiceRequest();
		breIntServiceRequest.setReqObject(transferRequestBean);
		breIntServiceRequest.setBreIntUrl(env.getProperty("api.razorpay.transfer.POST.url"));
		breIntServiceRequest.setClassType(TransferResponseBean.class);
		return breIntServiceRequest;
	}
	
	public BreIntServiceRequest mapRazorPayRequestForRefund(RefundRequestBean refundRequestBean) {
		BreIntServiceRequest breIntServiceRequest = new BreIntServiceRequest();
		breIntServiceRequest.setReqObject(refundRequestBean);
		breIntServiceRequest.setBreIntUrl(env.getProperty("api.razorpay.initiaterefund.POST.url"));
		breIntServiceRequest.setClassType(RefundResponseBean.class);
		return breIntServiceRequest;
	}

	public RedeemConfirmRequest getRedeemConfirmRequest(DGUpdatePaymentStatusRequest updatePaymentStatusRequest) {
		RedeemConfirmRequest redeemConfirmRequest=new RedeemConfirmRequest();
		redeemConfirmRequest.setDgProviderCode("SFGLD");
		redeemConfirmRequest.setPaymentId(updatePaymentStatusRequest.getPaymentId());
		String encodedString = Base64.getEncoder().encodeToString(env.getProperty(RazorPayIntegrationConstants.SECRET_KEY_DG).getBytes());
		redeemConfirmRequest.setAppSource(encodedString);
		redeemConfirmRequest.setTotalAmount(updatePaymentStatusRequest.getAmount());
		return redeemConfirmRequest;
	}

}