package com.bajaj.bfsd.razorpayintegration.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the PAYMENT_TRANSACTIONS database table.
 * 
 */
@Entity
@Table(name = "PAYMENT_TRANSACTIONS")
//@NamedQuery(name = "PaymentTransaction.findAll", query = "SELECT p FROM PaymentTransaction p")
public class PaymentTransaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long transactionkey;

	private BigDecimal amount;

	private String createby;

	private Timestamp createdt;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal payeventtype;

	private BigDecimal paygatewaypartnerkey;

	private String paymentbankname;

	@Temporal(TemporalType.DATE)
	private Date paymentdate;

	private String paymentmode;

	private String transrefnum;

	private String transrespcode;

	private String transrespmsg;

	private String transresprefnum;

	private BigDecimal transstatus;
	
	private Timestamp refundinitdate;
	
	private String refundid;

	public PaymentTransaction() {
	}

	public long getTransactionkey() {
		return this.transactionkey;
	}

	public void setTransactionkey(long transactionkey) {
		this.transactionkey = transactionkey;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCreateby() {
		return this.createby;
	}

	public void setCreateby(String createby) {
		this.createby = createby;
	}

	public Timestamp getCreatedt() {
		return this.createdt;
	}

	public void setCreatedt(Timestamp createdt) {
		this.createdt = createdt;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getPayeventtype() {
		return this.payeventtype;
	}

	public void setPayeventtype(BigDecimal payeventtype) {
		this.payeventtype = payeventtype;
	}

	public BigDecimal getPaygatewaypartnerkey() {
		return this.paygatewaypartnerkey;
	}

	public void setPaygatewaypartnerkey(BigDecimal paygatewaypartnerkey) {
		this.paygatewaypartnerkey = paygatewaypartnerkey;
	}

	public String getPaymentbankname() {
		return this.paymentbankname;
	}

	public void setPaymentbankname(String paymentbankname) {
		this.paymentbankname = paymentbankname;
	}

	public Date getPaymentdate() {
		return this.paymentdate;
	}

	public void setPaymentdate(Date paymentdate) {
		this.paymentdate = paymentdate;
	}

	public String getPaymentmode() {
		return this.paymentmode;
	}

	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}

	public String getTransrefnum() {
		return this.transrefnum;
	}

	public void setTransrefnum(String transrefnum) {
		this.transrefnum = transrefnum;
	}

	public String getTransrespcode() {
		return this.transrespcode;
	}

	public void setTransrespcode(String transrespcode) {
		this.transrespcode = transrespcode;
	}

	public String getTransrespmsg() {
		return this.transrespmsg;
	}

	public void setTransrespmsg(String transrespmsg) {
		this.transrespmsg = transrespmsg;
	}

	public String getTransresprefnum() {
		return this.transresprefnum;
	}

	public void setTransresprefnum(String transresprefnum) {
		this.transresprefnum = transresprefnum;
	}

	public BigDecimal getTransstatus() {
		return this.transstatus;
	}

	public void setTransstatus(BigDecimal transstatus) {
		this.transstatus = transstatus;
	}

	public Timestamp getRefundinitdate() {
		return refundinitdate;
	}

	public String getRefundid() {
		return refundid;
	}

	public void setRefundinitdate(Timestamp refundinitdate) {
		this.refundinitdate = refundinitdate;
	}

	public void setRefundid(String refundid) {
		this.refundid = refundid;
	}

}