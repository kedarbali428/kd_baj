package com.bajaj.bfsd.razorpayintegration.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the PAY_GATEWAY_PARTNERS database table.
 * 
 */
@Entity
@Table(name="PAY_GATEWAY_PARTNERS")
@NamedQuery(name="PayGatewayPartner.findAll", query="SELECT p FROM PayGatewayPartner p")
public class PayGatewayPartner implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long paygatewaypartnerkey;

	private String apikey;

	private String apisecret;

	@Temporal(TemporalType.DATE)
	private Date enddate;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String merchantid;

	private String partnercode;

	private String partnername;

	@Temporal(TemporalType.DATE)
	private Date startdate;

	public PayGatewayPartner() {
	}

	public long getPaygatewaypartnerkey() {
		return this.paygatewaypartnerkey;
	}

	public void setPaygatewaypartnerkey(long paygatewaypartnerkey) {
		this.paygatewaypartnerkey = paygatewaypartnerkey;
	}

	public String getApikey() {
		return this.apikey;
	}

	public void setApikey(String apikey) {
		this.apikey = apikey;
	}

	public String getApisecret() {
		return this.apisecret;
	}

	public void setApisecret(String apisecret) {
		this.apisecret = apisecret;
	}

	public Date getEnddate() {
		return this.enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getMerchantid() {
		return this.merchantid;
	}

	public void setMerchantid(String merchantid) {
		this.merchantid = merchantid;
	}

	public String getPartnercode() {
		return this.partnercode;
	}

	public void setPartnercode(String partnercode) {
		this.partnercode = partnercode;
	}

	public String getPartnername() {
		return this.partnername;
	}

	public void setPartnername(String partnername) {
		this.partnername = partnername;
	}

	public Date getStartdate() {
		return this.startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

}