package com.bajaj.bfsd.razorpayintegration.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the PGMERCHANT_PRODUCTS_MAPPING database table.
 * 
 */
@Entity
@Table(name="PGMERCHANT_PRODUCTS_MAPPING")
@NamedQuery(name="PgmerchantProductsMapping.findAll", query="SELECT p FROM PgmerchantProductsMapping p")
public class PgmerchantProductsMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long merchantproductkey;

	private String merchantid;

	@Column(name="PRODUCT_CODE_L3")
	private String productCodeL3;

	public PgmerchantProductsMapping() {
	}

	public long getMerchantproductkey() {
		return this.merchantproductkey;
	}

	public void setMerchantproductkey(long merchantproductkey) {
		this.merchantproductkey = merchantproductkey;
	}

	public String getMerchantid() {
		return this.merchantid;
	}

	public void setMerchantid(String merchantid) {
		this.merchantid = merchantid;
	}

	public String getProductCodeL3() {
		return this.productCodeL3;
	}

	public void setProductCodeL3(String productCodeL3) {
		this.productCodeL3 = productCodeL3;
	}

}