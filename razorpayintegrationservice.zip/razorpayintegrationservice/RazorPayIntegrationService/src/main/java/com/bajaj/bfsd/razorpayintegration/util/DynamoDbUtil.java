package com.bajaj.bfsd.razorpayintegration.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.DynamoDbBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.TokenRequest;
import com.bajaj.bfsd.razorpayintegration.bean.TokenResponse;
import com.bajaj.bfsd.razorpayintegration.factory.MapperFactory;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class DynamoDbUtil {

	private static final String CONTENT_TYPE = "Content-Type";
	private static final String IO_EXCEPTION_OCCURED = "IOException occured";
	private static final String PAYLOAD = "payload";
	
	@Autowired
	BFLLoggerUtil logger;
	
	@Value("${api.authentication.getsecretkey.GET.url}")
	String secretKeyUrl;
	
	@Value("${api.authentication.clientlogin.POST.url}")
	String tokensUrl;
	
	@Value("${cliendId}")
	String clientId;
	
	@Value("${proxy.required}")
	private String proxyRequired;
	@Value("${proxy.port}")
	private String proxyPort;
	@Value("${proxy.address}")
	private String proxyHost;
	@Value("${api.nosql.audit.POST.url}")
	private String noSQLDataURL;
	
	@Autowired
	Environment env;
	
	private static final String THIS_CLASS = DynamoDbUtil.class.getCanonicalName();
	
	@SuppressWarnings("unchecked")
	public void persistInDynamo(String applicationKey,String applicant, Object jsonObj,String reqJson,String source,String sourceType) {
		ObjectMapper mapper = MapperFactory.getInstance();
		DynamoDbBean dynamoBean = new DynamoDbBean();
		dynamoBean.setSource(source);
		dynamoBean.setSourcetype(sourceType);
		dynamoBean.setApplicantId(applicant);
		dynamoBean.setAppnId(applicationKey);
		dynamoBean.setResPayload(jsonObj);
		dynamoBean.setReqPayload(reqJson);
		if(jsonObj != null){
		dynamoBean.setResPayloadStr(jsonObj.toString());
		}
		dynamoBean.setReqTimeStamp(new Timestamp(Calendar.getInstance().getTime().getTime()).toString());
		dynamoBean.setResTimeStamp(new Timestamp(Calendar.getInstance().getTime().getTime()).toString());
		HttpHeaders headers = new HttpHeaders();
		try {
			String dynamoString = mapper.writeValueAsString(dynamoBean);
			TokenResponse tokenResponse = getSystemTokens();
			headers.add(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
			headers.add(CustomDefaultHeaders.AUTH_TOKEN, tokenResponse.getToken());
			headers.add(CustomDefaultHeaders.GUARD_TOKEN, tokenResponse.getGuardToken());
			ResponseEntity<ResponseBean> responseEntity=(ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST,
					noSQLDataURL, dynamoBean, String.class, null, dynamoString, headers);
			logger.debug(THIS_CLASS,BFLLoggerComponent.SERVICE,"Response from dynamo"+responseEntity);
		}   catch (IOException e) {
			logger.error(THIS_CLASS,BFLLoggerComponent.SERVICE,"IOException occured "+e);
		}
	}
	
	/**
	 * @Desc This method is used to get the System Tokens
	 * @return tokens
	 */
	@SuppressWarnings("unchecked")
	public TokenResponse getSystemTokens() {
		CloseableHttpResponse response = null;
		CloseableHttpClient httpClient = HttpClients.createDefault();
		TokenRequest tokenRequest = new TokenRequest();
		TokenResponse tokenResponse = new TokenResponse();
		String result = null;
		try{
		Object secretKey = getSecretKey();
		HttpPost httpRequest = new HttpPost(tokensUrl);
		httpRequest.addHeader(CONTENT_TYPE,"application/json");
		if(null!=secretKey){
		tokenRequest.setSecretKey(secretKey.toString());
		}
		tokenRequest.setClientId(clientId);
		Gson gson = new Gson();
		String tokenString = gson.toJson(tokenRequest);
		StringEntity params = new StringEntity(tokenString);
		httpRequest.setEntity(params);
		response = httpClient.execute(httpRequest);
		HttpEntity entity = response.getEntity();
		if(entity!=null){
			 InputStream instream = entity.getContent();
			 result = convertStreamToString(instream);
			 instream.close();
		}
		JSONParser parser = new JSONParser(); 
		org.json.simple.JSONObject json = (org.json.simple.JSONObject) parser.parse(result);
		org.json.simple.JSONObject tokenPayload = (org.json.simple.JSONObject) json.get(PAYLOAD);
		List<Object>  tokensArray = (List<Object>) tokenPayload.get("tokens");
		org.json.simple.JSONObject tokens = (org.json.simple.JSONObject) tokensArray.get(0);
		tokenResponse.setToken(tokens.get("token").toString());
		tokenResponse.setGuardKey(tokens.get("guardKey").toString());
		tokenResponse.setType(tokens.get("type").toString());
		long curTime=Calendar.getInstance().getTimeInMillis();
		String salt="B!&1j";
		String guardKey=tokenResponse.getGuardKey();
		String guardToken=salt+"|"+curTime+"|"+guardKey;
		String encryptedGuardToken=java.util.Base64.getEncoder().encodeToString(guardToken.getBytes());
		tokenResponse.setGuardToken(encryptedGuardToken);
		}catch(Exception ex){
			logger.error(THIS_CLASS,BFLLoggerComponent.SERVICE,"Exception while getting secret Key"+ex);
		}finally {
			try{
				httpClient.close();
				if(response != null) {
					response.close();
				}
			} catch(IOException ioe) {
				logger.error(THIS_CLASS,BFLLoggerComponent.SERVICE,"IOException occured while fetching key"+ioe);
			}
		}
		return tokenResponse;
	}	
	
	public String convertStreamToString(InputStream is) {
	    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
	    StringBuilder sb = new StringBuilder();
	    String line = null;
	    try {
	        while ((line = reader.readLine()) != null) {
	            sb.append(line + "\n");
	        }
	    } catch (IOException e) {
	    	logger.error(THIS_CLASS,BFLLoggerComponent.SERVICE,IO_EXCEPTION_OCCURED+e);
	    } finally {
	        try {
	            is.close();
	        } catch (IOException e) {
	        	logger.error(THIS_CLASS,BFLLoggerComponent.SERVICE,IO_EXCEPTION_OCCURED+e);
	        }
	    }
	    return sb.toString();
	}
	
	/**
	 * @Desc This method is used to get secret Key for getting Tokens
	 * @return Date
	 */
	public Object getSecretKey() {
		CloseableHttpResponse response = null;
		CloseableHttpClient httpClient = HttpClients.createDefault();
		String result = null;
		Object secretKey = null;
		try{
		String url = secretKeyUrl.replace("{clientId:.+}", clientId);
		HttpGet httpRequest = new HttpGet(url);
		response = httpClient.execute(httpRequest);
		HttpEntity entity = response.getEntity();
		if(entity!=null){
			 InputStream instream = entity.getContent();
			 result = convertStreamToString(instream);
			 instream.close();
		}
		JSONParser parser = new JSONParser(); 
		org.json.simple.JSONObject json = (org.json.simple.JSONObject) parser.parse(result);
		org.json.simple.JSONObject secretKeyPayload = (org.json.simple.JSONObject) json.get(PAYLOAD);
		secretKey = secretKeyPayload.get("secretKey");
		}catch(Exception ex){
			logger.error(THIS_CLASS,BFLLoggerComponent.SERVICE,"Exception occured"+ex);
		}finally {
			try{
				httpClient.close();
				if(response != null) {
					response.close();
				}
			} catch(IOException ioe) {
				logger.error(THIS_CLASS,BFLLoggerComponent.SERVICE,IO_EXCEPTION_OCCURED+ioe);
			}
		}
		return secretKey;
	}
}
