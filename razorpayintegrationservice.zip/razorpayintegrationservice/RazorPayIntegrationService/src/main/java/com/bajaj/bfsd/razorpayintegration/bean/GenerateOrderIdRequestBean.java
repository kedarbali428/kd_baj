package com.bajaj.bfsd.razorpayintegration.bean;

import java.math.BigDecimal;

public class GenerateOrderIdRequestBean {
	
	private BigDecimal amount;
	private String loanAccountNo;
	private String currency;
	private String reciept;
	private int payment_Capture;
	private String srNumber;
	private String productCode;
	private String applicantId;
	
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getLoanAccountNo() {
		return loanAccountNo;
	}
	public void setLoanAccountNo(String loanAccountNo) {
		this.loanAccountNo = loanAccountNo;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getReciept() {
		return reciept;
	}
	public void setReciept(String reciept) {
		this.reciept = reciept;
	}
	public int getPayment_Capture() {
		return payment_Capture;
	}
	public void setPayment_Capture(int payment_Capture) {
		this.payment_Capture = payment_Capture;
	}
	public String getSrNumber() {
		return srNumber;
	}
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	@Override
	public String toString() {
		return "GenerateOrderIdRequestBean [amount=" + amount + ", loanAccountNo=" + loanAccountNo + ", currency="
				+ currency + ", reciept=" + reciept + ", payment_Capture=" + payment_Capture + ", srNumber=" + srNumber
				+ ", productCode=" + productCode + ", applicantId=" + applicantId + "]";
	}
}
