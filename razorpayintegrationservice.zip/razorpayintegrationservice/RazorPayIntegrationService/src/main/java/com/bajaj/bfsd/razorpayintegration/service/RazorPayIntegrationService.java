package com.bajaj.bfsd.razorpayintegration.service;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.RazorpayTransferRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.RefundResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.TransferResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusResponse;

public interface RazorPayIntegrationService {
	
	
	/**RazorPay payment gateway integration to generate order id.
	 * @param generateOrderIdRequestBean
	 * @param l3ProductId
	 * @return GenerateOrderIdResponseBean
	 */
	public GenerateOrderIdResponseBean initiateBooking(GenerateOrderIdRequestBean generateOrderIdRequestBean);
    
	/**
	 * Update the status to pennant if transaction is success otherwise mark the request in pending state.
	 * 
	 * @param updatePaymentStatusRequest
	 * @return UpdatePaymentStatusResponse
	 */
	public UpdatePaymentStatusResponse initiateUpdate(String jsonRequest);

	/**
	 * @return
	 */
	public String updatePendingTransStatus();
	
	/**
	 * @param headers
	 * @param jsonRequest
	 * @return
	 */
	public ResponseEntity<ResponseBean> selectProcess(HttpHeaders headers, String jsonRequest,String source );

	public ResponseEntity<ResponseBean> digitalGoldSelectProcess(HttpHeaders headers, String jsonRequest);

	public TransferResponseBean initiateTransferProcess(RazorpayTransferRequest razorpayTransferRequest);

	public RefundResponseBean initiateRefundProcess(RefundRequestBean refundRequestBean);

	public void updatePaymentTransactionForRefund(String refundId, String paymentId);

}