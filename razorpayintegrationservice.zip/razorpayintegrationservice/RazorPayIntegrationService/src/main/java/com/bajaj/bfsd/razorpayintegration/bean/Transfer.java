package com.bajaj.bfsd.razorpayintegration.bean;

public class Transfer {
	
	private String account;
	private String amount;
	private String currency;
	private Object notes;
	
	public Transfer(){
	}
	
	public Transfer(String account, String amount, String currency, Object notes) {
		super();
		this.account = account;
		this.amount = amount;
		this.currency = currency;
		this.notes = notes;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Object getNotes() {
		return notes;
	}
	public void setNotes(Object notes) {
		this.notes = notes;
	}

	@Override
	public String toString() {
		return "Transfer [account=" + account + ", amount=" + amount + ", currency=" + currency + ", notes=" + notes
				+ "]";
	}
}
