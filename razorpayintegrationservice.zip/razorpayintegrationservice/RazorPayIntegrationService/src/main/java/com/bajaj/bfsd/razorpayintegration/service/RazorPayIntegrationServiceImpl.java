package com.bajaj.bfsd.razorpayintegration.service; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.RazorpayTransferRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.RefundResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.TransferResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusResponse;
import com.bajaj.bfsd.razorpayintegration.business.processor.RazorPayIntegrationBusinessProcessor; 

@Component
public class RazorPayIntegrationServiceImpl extends BaseService implements RazorPayIntegrationService  {
	
	@Autowired
	private RazorPayIntegrationBusinessProcessor razorPayIntegrationBusinessProcessor;
	
	@Override
	public GenerateOrderIdResponseBean initiateBooking(GenerateOrderIdRequestBean generateOrderIdRequestBean) {
		return razorPayIntegrationBusinessProcessor.getBookingDetails(generateOrderIdRequestBean);
	}
	

	@Override
	public UpdatePaymentStatusResponse initiateUpdate(String jsonRequest) {
	return razorPayIntegrationBusinessProcessor.updatePaymentStatus(jsonRequest);
	}

	@Override
	public String updatePendingTransStatus() {
		return razorPayIntegrationBusinessProcessor.updatePendingTransStatus();
	}


	@Override
	public ResponseEntity<ResponseBean> selectProcess(HttpHeaders headers, String jsonRequest,String source) {
		return razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest,source);
	}


	@Override
	public ResponseEntity<ResponseBean> digitalGoldSelectProcess(HttpHeaders headers, String jsonRequest) {
		return razorPayIntegrationBusinessProcessor.digitalGoldSelectProcess(headers, jsonRequest);
	}
	
	@Override
	public TransferResponseBean initiateTransferProcess(RazorpayTransferRequest razorpayTransferRequest) {
		return razorPayIntegrationBusinessProcessor.callRazorpayTransferApi(razorpayTransferRequest);
	}
	
	@Override
	public RefundResponseBean initiateRefundProcess(RefundRequestBean refundRequestBean) {
		return razorPayIntegrationBusinessProcessor.callRazorpayRefundApi(refundRequestBean);
	}
	
	@Override
	public void updatePaymentTransactionForRefund(String refundId, String paymentId) {
		razorPayIntegrationBusinessProcessor.updatePaymentTransactionForRefund(refundId, paymentId);
	}
}