package com.bajaj.bfsd.razorpayintegration.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLService;


/**
 * @author 691632
 *
 */
@RefreshScope
@Service
public class BaseService extends BFLService{

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	Environment env;
}
