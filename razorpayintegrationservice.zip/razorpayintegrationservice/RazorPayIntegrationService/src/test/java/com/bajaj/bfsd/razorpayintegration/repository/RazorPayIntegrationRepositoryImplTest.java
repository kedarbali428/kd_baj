package com.bajaj.bfsd.razorpayintegration.repository;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bajaj.bfsd.razorpayintegration.dao.RazorPayIntegrationDao;
import com.bajaj.bfsd.razorpayintegration.model.PaymentTransaction;

@RunWith(PowerMockRunner.class)
public class RazorPayIntegrationRepositoryImplTest {

	@InjectMocks
	private RazorPayIntegrationRepositoryImpl razorPayIntegrationRepositoryImpl;
	
	@Mock
	private RazorPayIntegrationDao razorPayIntegrationDao;
	@Test
	public void testUpdatePendingTransStatus() {
		List<PaymentTransaction> lstPendingTransactions= new ArrayList<>();
		PaymentTransaction paymentTransaction = new PaymentTransaction();
		lstPendingTransactions.add(paymentTransaction);
		Mockito.when(razorPayIntegrationDao.getAllPendingTransactions()).thenReturn(lstPendingTransactions);
		Mockito.when(razorPayIntegrationDao.updatePendingTrans(lstPendingTransactions)).thenReturn("SUCCESS");
		//method under test
		razorPayIntegrationRepositoryImpl.updatePendingTransStatus();
	}
	@Test
	public void testUpdatePendingTransStatus2() {
		List<PaymentTransaction> lstPendingTransactions= new ArrayList<>();
		Mockito.when(razorPayIntegrationDao.getAllPendingTransactions()).thenReturn(lstPendingTransactions);
		Mockito.when(razorPayIntegrationDao.updatePendingTrans(lstPendingTransactions)).thenReturn("SUCCESS");
		//method under test
		razorPayIntegrationRepositoryImpl.updatePendingTransStatus();
	}
}
