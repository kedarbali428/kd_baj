package com.bajaj.bfsd.razorpayintegration.util;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.DynamoDbBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.factory.MapperFactory;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MapperFactory.class,HttpClients.class, BFLCommonRestClient.class,StringBuilder.class})
@SuppressWarnings("unchecked")
public class DynamoDbUtilTest {
	@InjectMocks
	private DynamoDbUtil dynamoDbUtil; 
	@Mock
	private HttpGet httpRequest;
	
	@Autowired
	Environment env;
	@Mock
	private CloseableHttpClient httpClient;
	@Mock
	ResponseEntity<?> responseEntity;
	@Mock
	private HttpEntity entity;
	@Mock
	private BufferedReader reader;
	@Mock
	ObjectMapper mapper;
	
	@Mock
	private CloseableHttpResponse response;
	
	@Mock
	InputStream inputStream;
	@Mock
	InputStreamReader inputStreamReader;
	
	@Mock
	StringBuilder sb;
	
	
	@Mock
	BFLLoggerUtil logger;
	@Mock
	JSONParser parser;
	@Mock
	JSONObject json;
	
	@Before
	public void setUp() {
		ReflectionTestUtils.setField(dynamoDbUtil, "secretKeyUrl", "secretKeyUrl");
		ReflectionTestUtils.setField(dynamoDbUtil, "tokensUrl", "tokensUrl");
		ReflectionTestUtils.setField(dynamoDbUtil, "clientId", "clientId");
		ReflectionTestUtils.setField(dynamoDbUtil, "proxyRequired", env);
		ReflectionTestUtils.setField(dynamoDbUtil, "proxyPort", "proxyPort");
		ReflectionTestUtils.setField(dynamoDbUtil, "tokensUrl", "tokensUrl");
		ReflectionTestUtils.setField(dynamoDbUtil, "noSQLDataURL", "noSQLDataURL");
	}
	
	/**Negative test scenario for persisting in dynamo db
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	@Test
	public void testPersistInDynamo() throws ClientProtocolException, IOException {
		GenerateOrderIdResponseBean jsonObj = new GenerateOrderIdResponseBean();
		PowerMockito.mockStatic(MapperFactory.class);
		PowerMockito.when(MapperFactory.getInstance()).thenReturn(mapper);
		PowerMockito.when(mapper.writeValueAsString(Mockito.any(DynamoDbBean.class))).thenReturn("jsonrequest");
		PowerMockito.mockStatic(HttpClients.class);
		Mockito.when(HttpClients.createDefault()).thenReturn(httpClient);
		Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);
		Mockito.when(response.getEntity()).thenReturn(entity);
		ResponseBean responseBean = new ResponseBean(jsonObj);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(any(), any(), any(), any(), any(), any(),any())).thenReturn(response);
		dynamoDbUtil.persistInDynamo("12345","12345", jsonObj,"REQ", "RAZORPAY","");
	}
	
	
	@Test
	public void testPersistInDynamo1() throws ClientProtocolException, IOException {
		String inputSTring="{\"payload\": {\"secretKey\": \"123456\"} }";
		 InputStream targetStream = new ByteArrayInputStream(inputSTring.getBytes());
		GenerateOrderIdResponseBean jsonObj = new GenerateOrderIdResponseBean();
		PowerMockito.mockStatic(MapperFactory.class);
		PowerMockito.when(MapperFactory.getInstance()).thenReturn(mapper);
		PowerMockito.when(mapper.writeValueAsString(Mockito.any(DynamoDbBean.class))).thenReturn("jsonrequest");
		PowerMockito.mockStatic(HttpClients.class);
		Mockito.when(HttpClients.createDefault()).thenReturn(httpClient);
		Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);
		Mockito.when(response.getEntity()).thenReturn(entity);
		Mockito.when(entity.getContent()).thenReturn(targetStream);
		ResponseBean responseBean = new ResponseBean(jsonObj);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(any(), any(), any(), any(), any(), any(),any())).thenReturn(response);
		dynamoDbUtil.persistInDynamo("12345","12345", jsonObj,"REQ", "RAZORPAY","");
	}
	
	@Test
	public void testConvertStreamToString() throws IOException {
		String source = "Test";
		InputStream in = IOUtils.toInputStream(source, "UTF-8");
		assertNotNull(source, dynamoDbUtil.convertStreamToString(in));
	}
	
}
