package com.bajaj.bfsd.razorpayintegration.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;

import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.data.RazorPayTestDataPopulator;
import com.bajaj.bfsd.razorpayintegration.factory.MapperFactory;
import com.bajaj.bfsd.razorpayintegration.helper.RazorpayIntegrationHelper;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.razorpay.Utils;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MapperFactory.class,Utils.class, BFLCommonRestClient.class })
public class ServiceCallProcessorUtilTest {
	@InjectMocks
	private ServiceCallProcessorUtil serviceCallProcessorUtil;

	@Mock
	BFLLoggerUtilExt logger;
	@Mock
	ObjectMapper mapper;

	@Mock
	Environment env;
	@Mock
	Object responseObject;
	@Mock
	RazorpayIntegrationHelper controllerHelper;

	@Test
	public void testGetResponseObjectFromResponseJsonString()
			throws JsonParseException, JsonMappingException, IOException {
		GenerateOrderIdResponseBean bean = new GenerateOrderIdResponseBean();
		String responseJson = "{\"payload\":{\"createDate\":null,\"accessKey\":\"q91JqDWYVwmI2mnAA0xNYynE\",\"id\":\"order_BTbHw2DWNzr0wx\",\"entity\":\"order\",\"amount\":2047200,\"receipt\":null,\"status\":\"created\",\"attempts\":0},\"status\":\"SUCCESS\",\"errorBean\":null}";
		PowerMockito.mockStatic(MapperFactory.class);
		PowerMockito.when(MapperFactory.getInstance()).thenReturn(mapper);
		Mockito.when(mapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(bean);
		//method under test
		bean = (GenerateOrderIdResponseBean) serviceCallProcessorUtil
				.getResponseObjectFromResponseJsonString(responseJson, GenerateOrderIdResponseBean.class);
		assertNotNull(bean);
	}

	@Test
	public void testGetResponseObjectFromResponseJsonStringEmptyRes() {
		String responseJson = "";
		//method under test
		serviceCallProcessorUtil.getResponseObjectFromResponseJsonString(responseJson,
				GenerateOrderIdResponseBean.class);
	}

	@Test(expected = BFLTechnicalException.class)
	public void testGetResponseObjectFromResponseJsonStringJsonExcep()
			throws com.fasterxml.jackson.core.JsonParseException, JsonMappingException, IOException {
		GenerateOrderIdResponseBean bean;
		Class<?> classType = null;
		String responseJson = "{\"payload\":{\"createDate\":null,\"accessKey\":\"q91JqDWYVwmI2mnAA0xNYynE\",\"id\":\"order_BTbHw2DWNzr0wx\",\"entity\":\"order\",\"amount\":2047200,\"receipt\":null,\"status\":\"created\",\"attempts\":0},\"status\":\"SUCCESS\",\"errorBean\":null}";
		PowerMockito.mockStatic(MapperFactory.class);
		PowerMockito.when(MapperFactory.getInstance()).thenReturn(mapper);
		Mockito.when(mapper.readValue(Mockito.anyString(), Mockito.any(Class.class)))
				.thenThrow(new com.fasterxml.jackson.core.JsonParseException(null, responseJson));
		//method under test
		bean = (GenerateOrderIdResponseBean) serviceCallProcessorUtil
				.getResponseObjectFromResponseJsonString(responseJson, GenerateOrderIdResponseBean.class);
	}

	@Test(expected = BFLTechnicalException.class)
	public void testGetResponseObjectFromResponseJsonStringIOExcep()
			throws com.fasterxml.jackson.core.JsonParseException, JsonMappingException, IOException {
		GenerateOrderIdResponseBean bean;
		Class<?> classType = null;
		String responseJson = "{\"payload\":{\"createDate\":null,\"accessKey\":\"q91JqDWYVwmI2mnAA0xNYynE\",\"id\":\"order_BTbHw2DWNzr0wx\",\"entity\":\"order\",\"amount\":2047200,\"receipt\":null,\"status\":\"created\",\"attempts\":0},\"status\":\"SUCCESS\",\"errorBean\":null}";
		PowerMockito.mockStatic(MapperFactory.class);
		PowerMockito.when(MapperFactory.getInstance()).thenReturn(mapper);
		Mockito.when(mapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenThrow(new IOException(""));
		//method under test
		bean = (GenerateOrderIdResponseBean) serviceCallProcessorUtil
				.getResponseObjectFromResponseJsonString(responseJson, GenerateOrderIdResponseBean.class);
	}

	@Test(expected = BFLTechnicalException.class)
	public void testGetResponseObjectFromResponseJsonStringMapExcep()
			throws com.fasterxml.jackson.core.JsonParseException, JsonMappingException, IOException {
		GenerateOrderIdResponseBean bean;
		Class<?> classType = null;
		String responseJson = "{\"payload\":{\"createDate\":null,\"accessKey\":\"q91JqDWYVwmI2mnAA0xNYynE\",\"id\":\"order_BTbHw2DWNzr0wx\",\"entity\":\"order\",\"amount\":2047200,\"receipt\":null,\"status\":\"created\",\"attempts\":0},\"status\":\"SUCCESS\",\"errorBean\":null}";
		PowerMockito.mockStatic(MapperFactory.class);
		PowerMockito.when(MapperFactory.getInstance()).thenReturn(mapper);
		Mockito.when(mapper.readValue(Mockito.anyString(), Mockito.any(Class.class)))
				.thenThrow(new JsonMappingException(""));
		//method under test
		bean = (GenerateOrderIdResponseBean) serviceCallProcessorUtil
				.getResponseObjectFromResponseJsonString(responseJson, GenerateOrderIdResponseBean.class);
	}
	
	@Test
	public void testGetCurrentDate() {
		Date date=Calendar.getInstance().getTime();
		assertEquals(new Timestamp(date.getTime()).getYear(), serviceCallProcessorUtil.getCurrentDate().getYear());
	}
	
	@Test
	public void testMapToJson() {
		UpdatePaymentStatusRequest paymentStatusRequest=RazorPayTestDataPopulator.popUpdatePaymentStatusRequest();
	    assertEquals("{\"orderId\":\"OrderId\",\"paymentId\":\"Id\",\"paymentMethod\":\"UPI\",\"description\":\"desc\",\"paymentBank\":\"IDBI\"}", serviceCallProcessorUtil.mapToJson(paymentStatusRequest));
	}
	
	@Test
	public void testMapToJsonWithNull() {
		UpdatePaymentStatusRequest paymentStatusRequest=new UpdatePaymentStatusRequest();
	    assertEquals("{\"orderId\":null,\"paymentId\":null,\"paymentMethod\":null,\"description\":null,\"paymentBank\":null}", serviceCallProcessorUtil.mapToJsonWithNull(paymentStatusRequest));
	}
	
	@Test
	public void testGetJsonObject() throws ParseException {
		String str = "ABC";
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(str, "1");
		serviceCallProcessorUtil.getJsonObject(jsonObject);
	}

	@Test
	public void testGetJsonObject_Failure() {
		serviceCallProcessorUtil.getJsonObject(new Object());

	}	
	
	
	@Test
	public void testPrepareRequestJson() throws JsonProcessingException
	{
		Mockito.when(mapper.writeValueAsString(Mockito.any())).thenReturn("value");
		serviceCallProcessorUtil.prepareRequestJson(new Object());
	}
	
}
