package com.bajaj.bfsd.razorpayintegration.business.processor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.BreIntServiceRequest;
import com.bajaj.bfsd.razorpayintegration.bean.BuyProcessRequest;
import com.bajaj.bfsd.razorpayintegration.bean.DGUpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.RazorpayTransferRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RedeemConfirmRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.RefundResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.TransferRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.TransferResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusResponse;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;
import com.bajaj.bfsd.razorpayintegration.dao.RazorPayIntegrationDao;
import com.bajaj.bfsd.razorpayintegration.data.RazorPayTestDataPopulator;
import com.bajaj.bfsd.razorpayintegration.helper.RazorpayIntegrationHelper;
import com.bajaj.bfsd.razorpayintegration.mapper.RazorPayIntegrationMapper;
import com.bajaj.bfsd.razorpayintegration.model.PayGatewayPartner;
import com.bajaj.bfsd.razorpayintegration.repository.RazorPayIntegrationRepository;
import com.bajaj.bfsd.razorpayintegration.util.DynamoDbUtil;
import com.bajaj.bfsd.razorpayintegration.util.ServiceCallProcessorUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.razorpay.Utils;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ BFLCommonRestClient.class, Utils.class})
@SuppressWarnings("unchecked")
public class RazorPayIntegrationBusinessProcessorTest {
	@InjectMocks
	private RazorPayIntegrationBusinessProcessor razorPayIntegrationBusinessProcessor;
	@Mock
	BFLLoggerUtilExt logger;
	@Mock
	private RazorPayIntegrationMapper razorPayIntegrationMapper;
	@Mock
	public ServiceCallProcessorUtil serviceCallProcessor;
	@Mock
	BFLCommonRestClient bFLCommonRestClient;
	@Mock
	private RazorPayIntegrationDao razorPayIntegrationDao;

	@Mock
	private RazorPayIntegrationRepository razorPayIntegrationRepository;

	@Mock
	private Environment env;

	@Mock
	private DynamoDbUtil dynamoDbUtil;
	
	@Mock
	private RazorpayIntegrationHelper controlerHelper;
	
	private String jsonRequest="{ \"entity\":\"event\", \"account_id\":\"acc_A6556HA0NhfXAs\", \"event\":\"order.paid\", \"contains\":[ \"payment\", \"order\" ], \"payload\":{ \"payment\":{ \"entity\":{ \"id\":\"pay_Bl4fX7gIqmwxvG\", \"entity\":\"payment\", \"amount\":0, \"currency\":\"INR\", \"status\":\"captured\", \"order_id\":\"order_Bl4ek4Hl4Tcm4V\", \"invoice_id\":\"inv_Bl4ek3NX2XqU0A\", \"international\":false, \"method\":\"emandate\", \"amount_refunded\":0, \"refund_status\":null, \"captured\":true, \"description\":\"Invoice #inv_Bl4ek3NX2XqU0A\", \"card_id\":null, \"bank\":\"ICIC\", \"wallet\":null, \"vpa\":null, \"email\":\"babsbsb@gmail.com\", \"contact\":\"+919892338184\", \"customer_id\":\"cust_BkDS5yAXs1DMYw\", \"token_id\":\"token_Bl4fXBNL32NxXO\", \"notes\":[  ], \"fee\":590, \"tax\":90, \"error_code\":null, \"error_description\":null, \"created_at\":1547720782 } }, \"order\":{ \"entity\":{ \"id\":\"order_Bl4ek4Hl4Tcm4V\", \"entity\":\"order\", \"amount\":0, \"amount_paid\":0, \"amount_due\":0, \"currency\":\"INR\", \"receipt\":null, \"offer_id\":null, \"status\":\"paid\", \"attempts\":1, \"notes\":[  ], \"created_at\":1547720737 } } }, \"created_at\":1547720784 }";

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(razorPayIntegrationMapper, "logger", logger);
		ReflectionTestUtils.setField(razorPayIntegrationBusinessProcessor, "env", env);
	}

	/**
	 * Positive test case for getBookingDetails
	 */
	@Test
	public void testGetBookingDetailsSuccess() {
		GenerateOrderIdResponseBean generateOrderIdResponseBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdResponseBean();
		PayGatewayPartner gatewayPartner = new PayGatewayPartner();
		gatewayPartner.setApikey("abcdefgh");
		ResponseBean responseBean = new ResponseBean(generateOrderIdResponseBean);
		BreIntServiceRequest breIntServiceRequest = RazorPayTestDataPopulator.populateBresIntServRequest();
		GenerateOrderIdRequestBean generateOrderIdRequestBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdRequestBean();
		Mockito.when(razorPayIntegrationMapper.mapRazorPayRequest(generateOrderIdRequestBean))
				.thenReturn(breIntServiceRequest);
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		response.getBody().setPayload(
				"{ \"payload\" : { \"id\" : \"order_BMWCYEEj7DYCNe\", \"entity\" : \"order\", \"amount\" : 1000, \"currency\" : \"INR\", \"receipt\" : null, \"status\" : \"created\", \"attempts\" : 0, \"createdat\" : 0 }, \"status\" : \"SUCCESS\", \"errorBean\" : null }");
		Mockito.when(serviceCallProcessor.getResponseObjectFromResponseJsonString(Mockito.any(), Mockito.any()))
				.thenReturn(generateOrderIdResponseBean);
		Mockito.when(razorPayIntegrationDao.getSecretApiKey(generateOrderIdRequestBean.getProductCode()))
				.thenReturn(gatewayPartner);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.create(any(), any(), any(), any(), any(), any())).thenReturn(response);

		// method under test
		GenerateOrderIdResponseBean res = razorPayIntegrationBusinessProcessor
				.getBookingDetails(generateOrderIdRequestBean);

		assertEquals("abcdefgh", res.getAccessKey());
		assertEquals(new BigDecimal(1000), res.getAmount());
		assertEquals("created", res.getStatus());
	}

	@Test
	public void testGetBookingDetailsSuccess1() {
		GenerateOrderIdResponseBean generateOrderIdResponseBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdResponseBean();
		PayGatewayPartner gatewayPartner = new PayGatewayPartner();
		gatewayPartner.setApikey("abcdefgh");
		ResponseBean responseBean = new ResponseBean(generateOrderIdResponseBean);
		BreIntServiceRequest breIntServiceRequest = RazorPayTestDataPopulator.populateBresIntServRequest();
		GenerateOrderIdRequestBean generateOrderIdRequestBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdRequestBean();
		Mockito.when(razorPayIntegrationMapper.mapRazorPayRequest(generateOrderIdRequestBean))
				.thenReturn(breIntServiceRequest);
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		response.getBody().setPayload(
				"{ \"payload\" : { \"id\" : \"order_BMWCYEEj7DYCNe\", \"entity\" : \"order\", \"amount\" : 1000, \"currency\" : \"INR\", \"receipt\" : null, \"status\" : \"created\", \"attempts\" : 0, \"createdat\" : 0 }, \"status\" : \"SUCCESS\", \"errorBean\" : null }");
		Mockito.when(serviceCallProcessor.getResponseObjectFromResponseJsonString(Mockito.any(), Mockito.any()))
				.thenReturn(generateOrderIdResponseBean);
		Mockito.when(razorPayIntegrationDao.getSecretApiKey(generateOrderIdRequestBean.getProductCode()))
				.thenReturn(gatewayPartner);
		Mockito.when(razorPayIntegrationDao.getApplicationKey(generateOrderIdRequestBean.getSrNumber()))
				.thenReturn(BigDecimal.ONE);
		Mockito.when(razorPayIntegrationDao.getApplicantKey(BigDecimal.ONE)).thenReturn(BigDecimal.ONE);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.create(any(), any(), any(), any(), any(), any())).thenReturn(response);

		// method under test
		GenerateOrderIdResponseBean res = razorPayIntegrationBusinessProcessor
				.getBookingDetails(generateOrderIdRequestBean);

		assertEquals("abcdefgh", res.getAccessKey());
		assertEquals(new BigDecimal(1000), res.getAmount());
		assertEquals("created", res.getStatus());
	}

	@Test
	public void testGetBookingDetailsSuccess2() {
		GenerateOrderIdResponseBean generateOrderIdResponseBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdResponseBean();
		PayGatewayPartner gatewayPartner = new PayGatewayPartner();
		gatewayPartner.setApikey("abcdefgh");
		ResponseBean responseBean = new ResponseBean(generateOrderIdResponseBean);
		BreIntServiceRequest breIntServiceRequest = RazorPayTestDataPopulator.populateBresIntServRequest();
		GenerateOrderIdRequestBean generateOrderIdRequestBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdRequestBean();
		Mockito.when(razorPayIntegrationMapper.mapRazorPayRequest(generateOrderIdRequestBean))
				.thenReturn(breIntServiceRequest);
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		response.getBody().setPayload(
				"{ \"payload\" : { \"id\" : \"order_BMWCYEEj7DYCNe\", \"entity\" : \"order\", \"amount\" : 1000, \"currency\" : \"INR\", \"receipt\" : null, \"status\" : \"created\", \"attempts\" : 0, \"createdat\" : 0 }, \"status\" : \"SUCCESS\", \"errorBean\" : null }");
		Mockito.when(serviceCallProcessor.getResponseObjectFromResponseJsonString(Mockito.any(), Mockito.any()))
				.thenReturn(generateOrderIdResponseBean);
		Mockito.when(razorPayIntegrationDao.getSecretApiKey(generateOrderIdRequestBean.getProductCode()))
				.thenReturn(gatewayPartner);
		Mockito.when(razorPayIntegrationDao.getApplicationKey(generateOrderIdRequestBean.getSrNumber()))
				.thenReturn(BigDecimal.ONE);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.create(any(), any(), any(), any(), any(), any())).thenReturn(response);

		// method under test
		GenerateOrderIdResponseBean res = razorPayIntegrationBusinessProcessor
				.getBookingDetails(generateOrderIdRequestBean);

		assertEquals("abcdefgh", res.getAccessKey());
		assertEquals(new BigDecimal(1000), res.getAmount());
		assertEquals("created", res.getStatus());
	}

	/**
	 * Negative test case for getBookingdetails
	 */
	@Test(expected = BFLBusinessException.class)
	public void testGetBookingDetailsFailure() {
		GenerateOrderIdResponseBean generateOrderIdResponseBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdResponseBean();
		PayGatewayPartner gatewayPartner = new PayGatewayPartner();
		gatewayPartner.setApisecret("abcdefgh");
		ResponseBean responseBean = new ResponseBean(generateOrderIdResponseBean);
		BreIntServiceRequest breIntServiceRequest = RazorPayTestDataPopulator.populateBresIntServRequest();
		GenerateOrderIdRequestBean generateOrderIdRequestBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdRequestBean();
		Mockito.when(razorPayIntegrationMapper.mapRazorPayRequest(generateOrderIdRequestBean))
				.thenReturn(breIntServiceRequest);
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		response.getBody().setPayload(
				"{ \"payload\" : { \"id\" : \"order_BMWCYEEj7DYCNe\", \"entity\" : \"order\", \"amount\" : 1000, \"currency\" : \"INR\", \"receipt\" : null, \"status\" : \"created\", \"attempts\" : 0, \"createdat\" : 0 }, \"status\" : \"FAILURE\", \"errorBean\" : null }");
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.create(any(), any(), any(), any(), any(), any())).thenReturn(response);
		// method under test
		razorPayIntegrationBusinessProcessor.getBookingDetails(generateOrderIdRequestBean);
	}

	/**
	 * Negative test case for getBookingdetails
	 */
	@Test(expected = BFLBusinessException.class)
	public void testGetBookingDetailsFailure1() {
		GenerateOrderIdResponseBean generateOrderIdResponseBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdResponseBean();
		PayGatewayPartner gatewayPartner = new PayGatewayPartner();
		gatewayPartner.setApisecret("abcdefgh");
		ResponseBean responseBean = new ResponseBean(generateOrderIdResponseBean);
		BreIntServiceRequest breIntServiceRequest = RazorPayTestDataPopulator.populateBresIntServRequest();
		GenerateOrderIdRequestBean generateOrderIdRequestBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdRequestBean();
		Mockito.when(razorPayIntegrationMapper.mapRazorPayRequest(generateOrderIdRequestBean))
				.thenReturn(breIntServiceRequest);
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.ACCEPTED);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.create(any(), any(), any(), any(), any(), any())).thenReturn(response);
		// method under test
		razorPayIntegrationBusinessProcessor.getBookingDetails(generateOrderIdRequestBean);
	}

	/**
	 * Poitive test case for testing updatePendingTransStatus method.
	 */
	@Test
	public void testUpdatePendingTransStatus() {
		Mockito.when(razorPayIntegrationRepository.updatePendingTransStatus()).thenReturn("Successfully Updated");
		String res = razorPayIntegrationBusinessProcessor.updatePendingTransStatus();
		assertEquals("Successfully Updated", res);
	}

	/**
	 * Negative test case for testing updatePendingTransStatus method.
	 */
	@Test(expected = BFLBusinessException.class)
	public void testUpdatePendingTransStatusException() {
		Mockito.when(razorPayIntegrationDao.getTransStatus("order_Id")).thenReturn(BigDecimal.ZERO);
		Mockito.when(razorPayIntegrationRepository.updatePendingTransStatus()).thenThrow(new BFLBusinessException());
		razorPayIntegrationBusinessProcessor.updatePendingTransStatus();
	}

	@Test(expected = BFLBusinessException.class)
	public void testUpdatePaymentStatFailure() {
		UpdatePaymentStatusRequest updatePaymentStatusRequest = RazorPayTestDataPopulator
				.popUpdatePaymentStatusRequest();
		UpdatePaymentStatusResponse paymentStatusResponse = new UpdatePaymentStatusResponse();
		Mockito.when(razorPayIntegrationDao.getTransStatus(updatePaymentStatusRequest.getOrderId())).thenReturn(BigDecimal.ZERO);
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(jsonRequest)).thenReturn(updatePaymentStatusRequest);
        Mockito.when(razorPayIntegrationDao.getTransStatus("order_Id")).thenReturn(BigDecimal.ZERO);
		Mockito.when(razorPayIntegrationDao.getSrNumber(Mockito.anyString())).thenReturn("SR123");
		Mockito.when(env.getProperty("api.lms.paymentstatus.update.POST.url")).thenReturn("url");
		ResponseBean responseBean = new ResponseBean(paymentStatusResponse);
		Mockito.when(razorPayIntegrationMapper.mapBreRequest(Mockito.anyString(),Mockito.anyString()))
				.thenReturn(RazorPayTestDataPopulator.popBreRequest());
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.ACCEPTED);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.create(any(), any(), any(), any(), any(), any())).thenReturn(response);
		// method under test
		razorPayIntegrationBusinessProcessor.updatePaymentStatus(jsonRequest);
	}

	@Test(expected = BFLBusinessException.class)
	public void testUpdatePaymentStatFailure1() {
		UpdatePaymentStatusRequest updatePaymentStatusRequest = RazorPayTestDataPopulator
				.popUpdatePaymentStatusRequest();
		List<ErrorBean> errorList = new ArrayList<>();
		errorList.add(new ErrorBean());

		UpdatePaymentStatusResponse paymentStatusResponse = new UpdatePaymentStatusResponse();
		Mockito.when(razorPayIntegrationDao.getTransStatus(updatePaymentStatusRequest.getOrderId())).thenReturn(BigDecimal.ZERO);
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(jsonRequest)).thenReturn(updatePaymentStatusRequest);
		Mockito.when(razorPayIntegrationDao.getApplicationKey("SR123")).thenReturn(BigDecimal.ONE);
		Mockito.when(razorPayIntegrationDao.getApplicantKey(BigDecimal.ONE)).thenReturn(BigDecimal.ONE);
		Mockito.when(razorPayIntegrationDao.getTransStatus("order_Id")).thenReturn(BigDecimal.ZERO);
		Mockito.when(razorPayIntegrationDao.getSrNumber(Mockito.anyString())).thenReturn("SR123");
		Mockito.when(env.getProperty("api.lms.paymentstatus.update.POST.url")).thenReturn("url");
		ResponseBean responseBean = new ResponseBean(paymentStatusResponse);
		responseBean.setErrorBean(errorList);
		Mockito.when(razorPayIntegrationMapper.mapBreRequest(Mockito.anyString(),Mockito.anyString()))
				.thenReturn(RazorPayTestDataPopulator.popBreRequest());
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when((ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(any(), any(), any(),
				any(), any(), any(), any())).thenReturn(response);
		// method under test
		UpdatePaymentStatusResponse res = razorPayIntegrationBusinessProcessor
				.updatePaymentStatus(jsonRequest);
		assertEquals(RazorPayIntegrationConstants.RESPONSE_SUCCESS, res.getStatus());
	}

	@Test
	public void testUpdatePaymentStatSuccess() {
		UpdatePaymentStatusRequest updatePaymentStatusRequest = RazorPayTestDataPopulator
				.popUpdatePaymentStatusRequest();
        Map<String,String> resMap=new LinkedHashMap<>();
        resMap.put(RazorPayIntegrationConstants.RETURN_CODE, "0000");
        resMap.put(RazorPayIntegrationConstants.RETURN_STATUS, "");
		UpdatePaymentStatusResponse paymentStatusResponse = new UpdatePaymentStatusResponse();
		Mockito.when(razorPayIntegrationDao.getApplicationKey("SR123")).thenReturn(BigDecimal.ONE);
		Mockito.when(razorPayIntegrationDao.getApplicantKey(BigDecimal.ONE)).thenReturn(BigDecimal.ONE);
		Mockito.when(razorPayIntegrationDao.getTransStatus(updatePaymentStatusRequest.getOrderId())).thenReturn(BigDecimal.ZERO);
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(jsonRequest)).thenReturn(updatePaymentStatusRequest);
		Mockito.when(razorPayIntegrationDao.getSrNumber(Mockito.anyString())).thenReturn("SR123");
		Mockito.when(env.getProperty("api.lms.paymentstatus.update.POST.url")).thenReturn("url");
		ResponseBean responseBean = new ResponseBean(paymentStatusResponse);
		responseBean.setPayload(resMap);
		Mockito.when(razorPayIntegrationMapper.mapBreRequest(Mockito.anyString(),Mockito.anyString()))
				.thenReturn(RazorPayTestDataPopulator.popBreRequest());
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when((ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(any(), any(), any(),
				any(), any(), any(), any())).thenReturn(response);
		// method under test
		UpdatePaymentStatusResponse res = razorPayIntegrationBusinessProcessor
				.updatePaymentStatus(jsonRequest);
		assertEquals("SUCCESS", res.getStatus());
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testUpdatePaymentStatFailure3() {
		UpdatePaymentStatusRequest updatePaymentStatusRequest = RazorPayTestDataPopulator
				.popUpdatePaymentStatusRequest();
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(jsonRequest)).thenReturn(updatePaymentStatusRequest);
		Mockito.when(razorPayIntegrationDao.getTransStatus(updatePaymentStatusRequest.getOrderId())).thenReturn(BigDecimal.ONE);
		// method under test
		 razorPayIntegrationBusinessProcessor.updatePaymentStatus(jsonRequest);
	}
	
	
	@Test(expected=BFLBusinessException.class)
	public void testUpdatePaymentStatFailure2() {
		UpdatePaymentStatusRequest updatePaymentStatusRequest = RazorPayTestDataPopulator
				.popUpdatePaymentStatusRequest();
        Map<String,String> resMap=new LinkedHashMap<>();
        resMap.put(RazorPayIntegrationConstants.RETURN_CODE, "0009");
        resMap.put(RazorPayIntegrationConstants.RETURN_STATUS, "error");
		UpdatePaymentStatusResponse paymentStatusResponse = new UpdatePaymentStatusResponse();
		Mockito.when(razorPayIntegrationDao.getApplicationKey("SR123")).thenReturn(BigDecimal.ONE);
		Mockito.when(razorPayIntegrationDao.getApplicantKey(BigDecimal.ONE)).thenReturn(BigDecimal.ONE);
		Mockito.when(razorPayIntegrationDao.getTransStatus(updatePaymentStatusRequest.getOrderId())).thenReturn(BigDecimal.ZERO);
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(jsonRequest)).thenReturn(updatePaymentStatusRequest);
		Mockito.when(razorPayIntegrationDao.getSrNumber(Mockito.anyString())).thenReturn("SR123");
		Mockito.when(env.getProperty("api.lms.paymentstatus.update.POST.url")).thenReturn("url");
		ResponseBean responseBean = new ResponseBean(paymentStatusResponse);
		responseBean.setPayload(resMap);
		Mockito.when(razorPayIntegrationMapper.mapBreRequest(Mockito.anyString(),Mockito.anyString()))
				.thenReturn(RazorPayTestDataPopulator.popBreRequest());
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when((ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(any(), any(), any(),
				any(), any(), any(), any())).thenReturn(response);
		// method under test
	razorPayIntegrationBusinessProcessor.updatePaymentStatus(jsonRequest);
	}

	@Test(expected = BFLBusinessException.class)
	public void testUpdatePaymentStatEmptyPayment() {
		// method under test
		razorPayIntegrationBusinessProcessor.updatePaymentStatus("");
	}
	
	@Test
	public void testSelectProcessEMOrder() {
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response=new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "sdfgsdfgjkh");
		Mockito.when(controlerHelper.invokeEndpoint(Mockito.anyString(), Mockito.anyString(),Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "EM");
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	
	@Test
	public void testSelectProcessEMPaymentC() {
		String jsonRequest="{ \"entity\":\"event\", \"account_id\":\"acc_A6556HA0NhfXAs\", \"event\":\"payment.captured\", \"contains\":[ \"payment\", \"order\" ], \"payload\":{ \"payment\":{ \"entity\":{ \"id\":\"pay_Bl4fX7gIqmwxvG\", \"entity\":\"payment\", \"amount\":0, \"currency\":\"INR\", \"status\":\"captured\", \"order_id\":\"order_Bl4ek4Hl4Tcm4V\", \"invoice_id\":\"inv_Bl4ek3NX2XqU0A\", \"international\":false, \"method\":\"emandate\", \"amount_refunded\":0, \"refund_status\":null, \"captured\":true, \"description\":\"Invoice #inv_Bl4ek3NX2XqU0A\", \"card_id\":null, \"bank\":\"ICIC\", \"wallet\":null, \"vpa\":null, \"email\":\"babsbsb@gmail.com\", \"contact\":\"+919892338184\", \"customer_id\":\"cust_BkDS5yAXs1DMYw\", \"token_id\":\"token_Bl4fXBNL32NxXO\", \"notes\":[  ], \"fee\":590, \"tax\":90, \"error_code\":null, \"error_description\":null, \"created_at\":1547720782 } }, \"order\":{ \"entity\":{ \"id\":\"order_Bl4ek4Hl4Tcm4V\", \"entity\":\"order\", \"amount\":0, \"amount_paid\":0, \"amount_due\":0, \"currency\":\"INR\", \"receipt\":null, \"offer_id\":null, \"status\":\"paid\", \"attempts\":1, \"notes\":[  ], \"created_at\":1547720737 } } }, \"created_at\":1547720784 }";
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response=new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "sdfgsdfgjkh");
		Mockito.when(controlerHelper.invokeEndpoint(Mockito.anyString(), Mockito.anyString(),Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "EM");
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	@Test
	public void testSelectProcessEMPaymentFailed() {
		String jsonRequest="{ \"entity\":\"event\", \"account_id\":\"acc_A6556HA0NhfXAs\", \"event\":\"payment.failed\", \"contains\":[ \"payment\", \"order\" ], \"payload\":{ \"payment\":{ \"entity\":{ \"id\":\"pay_Bl4fX7gIqmwxvG\", \"entity\":\"payment\", \"amount\":0, \"currency\":\"INR\", \"status\":\"captured\", \"order_id\":\"order_Bl4ek4Hl4Tcm4V\", \"invoice_id\":\"inv_Bl4ek3NX2XqU0A\", \"international\":false, \"method\":\"emandate\", \"amount_refunded\":0, \"refund_status\":null, \"captured\":true, \"description\":\"Invoice #inv_Bl4ek3NX2XqU0A\", \"card_id\":null, \"bank\":\"ICIC\", \"wallet\":null, \"vpa\":null, \"email\":\"babsbsb@gmail.com\", \"contact\":\"+919892338184\", \"customer_id\":\"cust_BkDS5yAXs1DMYw\", \"token_id\":\"token_Bl4fXBNL32NxXO\", \"notes\":[  ], \"fee\":590, \"tax\":90, \"error_code\":null, \"error_description\":null, \"created_at\":1547720782 } }, \"order\":{ \"entity\":{ \"id\":\"order_Bl4ek4Hl4Tcm4V\", \"entity\":\"order\", \"amount\":0, \"amount_paid\":0, \"amount_due\":0, \"currency\":\"INR\", \"receipt\":null, \"offer_id\":null, \"status\":\"paid\", \"attempts\":1, \"notes\":[  ], \"created_at\":1547720737 } } }, \"created_at\":1547720784 }";
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response=new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "sdfgsdfgjkh");
		Mockito.when(controlerHelper.invokeEndpoint(Mockito.anyString(), Mockito.anyString(),Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "EM");
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	@Test
	public void testSelectProcessEMInvoicePaid() {
		String jsonRequest="{ \"entity\":\"event\", \"account_id\":\"acc_A6556HA0NhfXAs\", \"event\":\"invoice.paid\", \"contains\":[ \"payment\", \"order\" ], \"payload\":{ \"payment\":{ \"entity\":{ \"id\":\"pay_Bl4fX7gIqmwxvG\", \"entity\":\"payment\", \"amount\":0, \"currency\":\"INR\", \"status\":\"captured\", \"order_id\":\"order_Bl4ek4Hl4Tcm4V\", \"invoice_id\":\"inv_Bl4ek3NX2XqU0A\", \"international\":false, \"method\":\"emandate\", \"amount_refunded\":0, \"refund_status\":null, \"captured\":true, \"description\":\"Invoice #inv_Bl4ek3NX2XqU0A\", \"card_id\":null, \"bank\":\"ICIC\", \"wallet\":null, \"vpa\":null, \"email\":\"babsbsb@gmail.com\", \"contact\":\"+919892338184\", \"customer_id\":\"cust_BkDS5yAXs1DMYw\", \"token_id\":\"token_Bl4fXBNL32NxXO\", \"notes\":[  ], \"fee\":590, \"tax\":90, \"error_code\":null, \"error_description\":null, \"created_at\":1547720782 } }, \"order\":{ \"entity\":{ \"id\":\"order_Bl4ek4Hl4Tcm4V\", \"entity\":\"order\", \"amount\":0, \"amount_paid\":0, \"amount_due\":0, \"currency\":\"INR\", \"receipt\":null, \"offer_id\":null, \"status\":\"paid\", \"attempts\":1, \"notes\":[  ], \"created_at\":1547720737 } } }, \"created_at\":1547720784 }";
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response=new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "sdfgsdfgjkh");
		Mockito.when(controlerHelper.invokeEndpoint(Mockito.anyString(), Mockito.anyString(),Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "EM");
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	@Test
	public void testSelectProcessEMInvoiceexpired() {
		String jsonRequest="{ \"entity\":\"event\", \"account_id\":\"acc_A6556HA0NhfXAs\", \"event\":\"invoice.expired\", \"contains\":[ \"payment\", \"order\" ], \"payload\":{ \"payment\":{ \"entity\":{ \"id\":\"pay_Bl4fX7gIqmwxvG\", \"entity\":\"payment\", \"amount\":0, \"currency\":\"INR\", \"status\":\"captured\", \"order_id\":\"order_Bl4ek4Hl4Tcm4V\", \"invoice_id\":\"inv_Bl4ek3NX2XqU0A\", \"international\":false, \"method\":\"emandate\", \"amount_refunded\":0, \"refund_status\":null, \"captured\":true, \"description\":\"Invoice #inv_Bl4ek3NX2XqU0A\", \"card_id\":null, \"bank\":\"ICIC\", \"wallet\":null, \"vpa\":null, \"email\":\"babsbsb@gmail.com\", \"contact\":\"+919892338184\", \"customer_id\":\"cust_BkDS5yAXs1DMYw\", \"token_id\":\"token_Bl4fXBNL32NxXO\", \"notes\":[  ], \"fee\":590, \"tax\":90, \"error_code\":null, \"error_description\":null, \"created_at\":1547720782 } }, \"order\":{ \"entity\":{ \"id\":\"order_Bl4ek4Hl4Tcm4V\", \"entity\":\"order\", \"amount\":0, \"amount_paid\":0, \"amount_due\":0, \"currency\":\"INR\", \"receipt\":null, \"offer_id\":null, \"status\":\"paid\", \"attempts\":1, \"notes\":[  ], \"created_at\":1547720737 } } }, \"created_at\":1547720784 }";
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response=new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "sdfgsdfgjkh");
		Mockito.when(controlerHelper.invokeEndpoint(Mockito.anyString(), Mockito.anyString(),Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "EM");
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	@Test
	public void testSelectProcessEMTokenConfirmed() {
		String jsonRequest="{ \"entity\":\"event\", \"account_id\":\"acc_A6556HA0NhfXAs\", \"event\":\"token.confirmed\", \"contains\":[ \"payment\", \"order\" ], \"payload\":{ \"payment\":{ \"entity\":{ \"id\":\"pay_Bl4fX7gIqmwxvG\", \"entity\":\"payment\", \"amount\":0, \"currency\":\"INR\", \"status\":\"captured\", \"order_id\":\"order_Bl4ek4Hl4Tcm4V\", \"invoice_id\":\"inv_Bl4ek3NX2XqU0A\", \"international\":false, \"method\":\"emandate\", \"amount_refunded\":0, \"refund_status\":null, \"captured\":true, \"description\":\"Invoice #inv_Bl4ek3NX2XqU0A\", \"card_id\":null, \"bank\":\"ICIC\", \"wallet\":null, \"vpa\":null, \"email\":\"babsbsb@gmail.com\", \"contact\":\"+919892338184\", \"customer_id\":\"cust_BkDS5yAXs1DMYw\", \"token_id\":\"token_Bl4fXBNL32NxXO\", \"notes\":[  ], \"fee\":590, \"tax\":90, \"error_code\":null, \"error_description\":null, \"created_at\":1547720782 } }, \"order\":{ \"entity\":{ \"id\":\"order_Bl4ek4Hl4Tcm4V\", \"entity\":\"order\", \"amount\":0, \"amount_paid\":0, \"amount_due\":0, \"currency\":\"INR\", \"receipt\":null, \"offer_id\":null, \"status\":\"paid\", \"attempts\":1, \"notes\":[  ], \"created_at\":1547720737 } } }, \"created_at\":1547720784 }";
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response=new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "sdfgsdfgjkh");
		Mockito.when(controlerHelper.invokeEndpoint(Mockito.anyString(), Mockito.anyString(),Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "EM");
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	@Test
	public void testSelectProcessEMTokenRejected() {
		String jsonRequest="{ \"entity\":\"event\", \"account_id\":\"acc_A6556HA0NhfXAs\", \"event\":\"token.rejected\", \"contains\":[ \"payment\", \"order\" ], \"payload\":{ \"payment\":{ \"entity\":{ \"id\":\"pay_Bl4fX7gIqmwxvG\", \"entity\":\"payment\", \"amount\":0, \"currency\":\"INR\", \"status\":\"captured\", \"order_id\":\"order_Bl4ek4Hl4Tcm4V\", \"invoice_id\":\"inv_Bl4ek3NX2XqU0A\", \"international\":false, \"method\":\"emandate\", \"amount_refunded\":0, \"refund_status\":null, \"captured\":true, \"description\":\"Invoice #inv_Bl4ek3NX2XqU0A\", \"card_id\":null, \"bank\":\"ICIC\", \"wallet\":null, \"vpa\":null, \"email\":\"babsbsb@gmail.com\", \"contact\":\"+919892338184\", \"customer_id\":\"cust_BkDS5yAXs1DMYw\", \"token_id\":\"token_Bl4fXBNL32NxXO\", \"notes\":[  ], \"fee\":590, \"tax\":90, \"error_code\":null, \"error_description\":null, \"created_at\":1547720782 } }, \"order\":{ \"entity\":{ \"id\":\"order_Bl4ek4Hl4Tcm4V\", \"entity\":\"order\", \"amount\":0, \"amount_paid\":0, \"amount_due\":0, \"currency\":\"INR\", \"receipt\":null, \"offer_id\":null, \"status\":\"paid\", \"attempts\":1, \"notes\":[  ], \"created_at\":1547720737 } } }, \"created_at\":1547720784 }";
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response=new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "sdfgsdfgjkh");
		Mockito.when(controlerHelper.invokeEndpoint(Mockito.anyString(), Mockito.anyString(),Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "EM");
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testSelectProcessEMTokenRejectedDefault() {
		String jsonRequest="{ \"entity\":\"event\", \"account_id\":\"acc_A6556HA0NhfXAs\", \"event\":\"token.abc\", \"contains\":[ \"payment\", \"order\" ], \"payload\":{ \"payment\":{ \"entity\":{ \"id\":\"pay_Bl4fX7gIqmwxvG\", \"entity\":\"payment\", \"amount\":0, \"currency\":\"INR\", \"status\":\"captured\", \"order_id\":\"order_Bl4ek4Hl4Tcm4V\", \"invoice_id\":\"inv_Bl4ek3NX2XqU0A\", \"international\":false, \"method\":\"emandate\", \"amount_refunded\":0, \"refund_status\":null, \"captured\":true, \"description\":\"Invoice #inv_Bl4ek3NX2XqU0A\", \"card_id\":null, \"bank\":\"ICIC\", \"wallet\":null, \"vpa\":null, \"email\":\"babsbsb@gmail.com\", \"contact\":\"+919892338184\", \"customer_id\":\"cust_BkDS5yAXs1DMYw\", \"token_id\":\"token_Bl4fXBNL32NxXO\", \"notes\":[  ], \"fee\":590, \"tax\":90, \"error_code\":null, \"error_description\":null, \"created_at\":1547720782 } }, \"order\":{ \"entity\":{ \"id\":\"order_Bl4ek4Hl4Tcm4V\", \"entity\":\"order\", \"amount\":0, \"amount_paid\":0, \"amount_due\":0, \"currency\":\"INR\", \"receipt\":null, \"offer_id\":null, \"status\":\"paid\", \"attempts\":1, \"notes\":[  ], \"created_at\":1547720737 } } }, \"created_at\":1547720784 }";
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response=new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "sdfgsdfgjkh");
		Mockito.when(controlerHelper.invokeEndpoint(Mockito.anyString(), Mockito.anyString(),Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "EM");
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	
	@Test
	public void testSelectProcessPG() {
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response=new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "sdfgsdfgjkh");
		Mockito.when(controlerHelper.invokeEndpoint(Mockito.anyString(), Mockito.anyString(),Mockito.any())).thenReturn(response);
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "PG");
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	
	@Test
	public void testSelectProcessPGSignNull() {
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "PG");
		assertNull(res);
	}
	
	@Test
	public void testSelectProcessPGNullHeader() {
		HttpHeaders headers = null;
		ResponseEntity<ResponseBean> res=razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "PG");
		assertNull(res);
	}
	
	
	
	@Test(expected=BFLBusinessException.class)
	public void testSelectProcessAB() {
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response=new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "sdfgsdfgjkh");
		Mockito.when(controlerHelper.invokeEndpoint(Mockito.anyString(), Mockito.anyString(),Mockito.any())).thenReturn(response);
        razorPayIntegrationBusinessProcessor.selectProcess(headers, jsonRequest, "AB");
	}
	
	@Test
	public void testDigitalGoldSelectProcessBuy() {

		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "TEST");
		Mockito.when(controlerHelper.digitalGoldauthenticatePartner(Mockito.any())).thenReturn(new BigDecimal(2));
		
		Mockito.when(controlerHelper.validateSignature(Mockito.anyString(),Mockito.anyString(),Mockito.anyString()))
			.thenReturn(true);
			
		DGUpdatePaymentStatusRequest updatePaymentStatusRequest = new DGUpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		updatePaymentStatusRequest.setApplicantId("TEST");
		updatePaymentStatusRequest.setApplicationId("TEST");
		updatePaymentStatusRequest.setJourneyType("buy");
		Mockito.when(razorPayIntegrationMapper.dgMapJsonToUpadatePaymentRequest(Mockito.any())).thenReturn(updatePaymentStatusRequest);

		UpdatePaymentStatusRequest updatePaymentStatusRequest1 = new UpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(Mockito.any()))
		.thenReturn(updatePaymentStatusRequest1);
		
		Mockito.doNothing().when(razorPayIntegrationDao).updatePayTrans(Mockito.any(),Mockito.any());
		Mockito.doNothing().when(razorPayIntegrationDao).updateSerReqStatus(Mockito.any(),Mockito.any(),Mockito.any());
		
		Mockito.doNothing().when(dynamoDbUtil).persistInDynamo(Mockito.anyString(),
				Mockito.anyString(),Mockito.any(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		Mockito.when(razorPayIntegrationDao.getTransStatus(Mockito.any())).thenReturn(new BigDecimal(0));
		
		BuyProcessRequest buyProcessRequest = new BuyProcessRequest();
		Mockito.when(razorPayIntegrationMapper.getbuyProcessRequest(Mockito.any())).thenReturn(buyProcessRequest);
		Future<ResponseBean> futureResponseBean=null;
		Mockito.when(controlerHelper.callconfirmService(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(futureResponseBean);
		
		response = razorPayIntegrationBusinessProcessor.digitalGoldSelectProcess(headers,
				"{\"payload\":{\"payment\":{\"entity\":{\"order_id\":\"order_C1hMPYkHNN0ysf\",\"id\":\"22\",\"method\":\"mca\",\"description\":\"xyz\",\"bank\":\"xyz\"}}}}");
		assertNotNull(response);
	}
	@Test
	public void testDigitalGoldSelectProcessRedeem() {

		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "TEST");
		Mockito.when(controlerHelper.digitalGoldauthenticatePartner(Mockito.any())).thenReturn(new BigDecimal(2));
		
		Mockito.when(controlerHelper.validateSignature(Mockito.anyString(),Mockito.anyString(),Mockito.anyString()))
			.thenReturn(true);
			
		DGUpdatePaymentStatusRequest updatePaymentStatusRequest = new DGUpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		updatePaymentStatusRequest.setApplicantId("TEST");
		updatePaymentStatusRequest.setApplicationId("TEST");
		updatePaymentStatusRequest.setJourneyType("redeem");
		Mockito.when(razorPayIntegrationMapper.dgMapJsonToUpadatePaymentRequest(Mockito.any())).thenReturn(updatePaymentStatusRequest);

		UpdatePaymentStatusRequest updatePaymentStatusRequest1 = new UpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(Mockito.any()))
		.thenReturn(updatePaymentStatusRequest1);
		
		Mockito.doNothing().when(razorPayIntegrationDao).updatePayTrans(Mockito.any(),Mockito.any());
		Mockito.doNothing().when(razorPayIntegrationDao).updateSerReqStatus(Mockito.any(),Mockito.any(),Mockito.any());
		
		Mockito.doNothing().when(dynamoDbUtil).persistInDynamo(Mockito.anyString(),
				Mockito.anyString(),Mockito.any(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		Mockito.when(razorPayIntegrationDao.getTransStatus(Mockito.any())).thenReturn(new BigDecimal(0));
		
		RedeemConfirmRequest redeemConfirmRequest = new RedeemConfirmRequest();
		Mockito.when(razorPayIntegrationMapper.getRedeemConfirmRequest(Mockito.any())).thenReturn(redeemConfirmRequest);
		Future<ResponseBean> futureResponseBean=null;
		Mockito.when(controlerHelper.callredeemConfirmService(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(futureResponseBean);
		
		response = razorPayIntegrationBusinessProcessor.digitalGoldSelectProcess(headers,
				"{\"payload\":{\"payment\":{\"entity\":{\"order_id\":\"order_C1hMPYkHNN0ysf\",\"id\":\"22\",\"method\":\"mca\",\"description\":\"xyz\",\"bank\":\"xyz\"}}}}");
		assertNotNull(response);
	}
	@Test
	public void testDigitalGoldSelectProcessInvalid() {

		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "TEST");
		Mockito.when(controlerHelper.digitalGoldauthenticatePartner(Mockito.any())).thenReturn(new BigDecimal(2));
		
		Mockito.when(controlerHelper.validateSignature(Mockito.anyString(),Mockito.anyString(),Mockito.anyString()))
			.thenReturn(true);
			
		DGUpdatePaymentStatusRequest updatePaymentStatusRequest = new DGUpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		updatePaymentStatusRequest.setApplicantId("TEST");
		updatePaymentStatusRequest.setApplicationId("TEST");
		updatePaymentStatusRequest.setJourneyType("Indvalid");
		Mockito.when(razorPayIntegrationMapper.dgMapJsonToUpadatePaymentRequest(Mockito.any())).thenReturn(updatePaymentStatusRequest);

		UpdatePaymentStatusRequest updatePaymentStatusRequest1 = new UpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(Mockito.any()))
		.thenReturn(updatePaymentStatusRequest1);
		
		Mockito.doNothing().when(razorPayIntegrationDao).updatePayTrans(Mockito.any(),Mockito.any());
		Mockito.doNothing().when(razorPayIntegrationDao).updateSerReqStatus(Mockito.any(),Mockito.any(),Mockito.any());
		
		Mockito.doNothing().when(dynamoDbUtil).persistInDynamo(Mockito.anyString(),
				Mockito.anyString(),Mockito.any(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		Mockito.when(razorPayIntegrationDao.getTransStatus(Mockito.any())).thenReturn(new BigDecimal(0));
		
		response = razorPayIntegrationBusinessProcessor.digitalGoldSelectProcess(headers,
				"{\"payload\":{\"payment\":{\"entity\":{\"order_id\":\"order_C1hMPYkHNN0ysf\",\"id\":\"22\",\"method\":\"mca\",\"description\":\"xyz\",\"bank\":\"xyz\"}}}}");
		assertNotNull(response);
	}
	@Test(expected=BFLBusinessException.class)
	public void testDigitalGoldSelectProcessEx1() {

		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "TEST");
		Mockito.when(controlerHelper.digitalGoldauthenticatePartner(Mockito.any())).thenReturn(new BigDecimal(2));
		
		Mockito.when(controlerHelper.validateSignature(Mockito.anyString(),Mockito.anyString(),Mockito.anyString()))
			.thenReturn(true);
			
		DGUpdatePaymentStatusRequest updatePaymentStatusRequest = new DGUpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		updatePaymentStatusRequest.setApplicantId("TEST");
		updatePaymentStatusRequest.setApplicationId("TEST");
		Mockito.when(razorPayIntegrationMapper.dgMapJsonToUpadatePaymentRequest(Mockito.any())).thenReturn(updatePaymentStatusRequest);

		Mockito.when(razorPayIntegrationDao.getTransStatus(Mockito.any())).thenReturn(new BigDecimal(0));
		
		UpdatePaymentStatusRequest updatePaymentStatusRequest1 = new UpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(Mockito.any()))
		.thenReturn(updatePaymentStatusRequest1);
		
		Mockito.doNothing().when(razorPayIntegrationDao).updatePayTrans(Mockito.any(),Mockito.any());
		Mockito.doNothing().when(razorPayIntegrationDao).updateSerReqStatus(Mockito.any(),Mockito.any(),Mockito.any());
		
		Mockito.doThrow(BFLBusinessException.class).when(dynamoDbUtil).persistInDynamo(Mockito.anyString(),
				Mockito.anyString(),Mockito.any(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());

		response = razorPayIntegrationBusinessProcessor.digitalGoldSelectProcess(headers,
				"{\"payload\":{\"payment\":{\"entity\":{\"order_id\":\"order_C1hMPYkHNN0ysf\",\"id\":\"22\",\"method\":\"mca\",\"description\":\"xyz\",\"bank\":\"xyz\"}}}}");
	}
	@Test(expected=BFLBusinessException.class)
	public void testDigitalGoldSelectProcessEx2() {

		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "TEST");
		Mockito.when(controlerHelper.digitalGoldauthenticatePartner(Mockito.any())).thenReturn(new BigDecimal(2));
		
		Mockito.when(controlerHelper.validateSignature(Mockito.anyString(),Mockito.anyString(),Mockito.anyString()))
			.thenReturn(true);
			
		DGUpdatePaymentStatusRequest updatePaymentStatusRequest = new DGUpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		updatePaymentStatusRequest.setApplicantId("TEST");
		updatePaymentStatusRequest.setApplicationId("TEST");
		Mockito.when(razorPayIntegrationMapper.dgMapJsonToUpadatePaymentRequest(Mockito.any())).thenReturn(updatePaymentStatusRequest);

		Mockito.when(razorPayIntegrationDao.getTransStatus(Mockito.any())).thenReturn(new BigDecimal(0));
		
		UpdatePaymentStatusRequest updatePaymentStatusRequest1 = new UpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(Mockito.any()))
		.thenReturn(updatePaymentStatusRequest1);
		
		Mockito.doNothing().when(razorPayIntegrationDao).updatePayTrans(Mockito.any(),Mockito.any());
		Mockito.doNothing().when(razorPayIntegrationDao).updateSerReqStatus(Mockito.any(),Mockito.any(),Mockito.any());
		
		Mockito.doThrow(BFLBusinessException.class).when(dynamoDbUtil).persistInDynamo(Mockito.anyString(),
				Mockito.anyString(),Mockito.any(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());

		response = razorPayIntegrationBusinessProcessor.digitalGoldSelectProcess(headers,
				null);
	}
	@Test(expected=BFLBusinessException.class)
	public void testDigitalGoldSelectProcessEx3() {
 
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(HttpStatus.OK);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "TEST");
		Mockito.when(controlerHelper.digitalGoldauthenticatePartner(Mockito.any())).thenReturn(new BigDecimal(2));
		
		Mockito.when(controlerHelper.validateSignature(Mockito.anyString(),Mockito.anyString(),Mockito.anyString()))
			.thenReturn(true);
			
		DGUpdatePaymentStatusRequest updatePaymentStatusRequest = new DGUpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		updatePaymentStatusRequest.setApplicantId("TEST");
		updatePaymentStatusRequest.setApplicationId("TEST");
		Mockito.when(razorPayIntegrationMapper.dgMapJsonToUpadatePaymentRequest(Mockito.any())).thenReturn(updatePaymentStatusRequest);

		Mockito.when(razorPayIntegrationDao.getTransStatus(Mockito.any())).thenReturn(new BigDecimal(1));
		
		UpdatePaymentStatusRequest updatePaymentStatusRequest1 = new UpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setOrderId("20");
		Mockito.when(razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(Mockito.any()))
		.thenReturn(updatePaymentStatusRequest1);
		
		Mockito.doNothing().when(dynamoDbUtil).persistInDynamo(Mockito.anyString(),
				Mockito.anyString(),Mockito.any(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());

		response = razorPayIntegrationBusinessProcessor.digitalGoldSelectProcess(headers,
				"{\"payload\":{\"payment\":{\"entity\":{\"order_id\":\"order_C1hMPYkHNN0ysf\",\"id\":\"22\",\"method\":\"mca\",\"description\":\"xyz\",\"bank\":\"xyz\"}}}}");
		}
	
	@Test
	public void testCallRazorpayTransferApi(){
		RazorpayTransferRequest razorpayTransferRequest = new RazorpayTransferRequest();
		razorpayTransferRequest.setApplicationId("1");
		razorpayTransferRequest.setPaymentId("pay_C99pGT4wlILj8e");
		razorpayTransferRequest.setAmount(BigDecimal.valueOf(107));
		razorpayTransferRequest.setVendorAmount(BigDecimal.valueOf(900));
		razorpayTransferRequest.setProductCode("DIGIGOLD");
		razorpayTransferRequest.setVendorTxId("123");
		TransferRequestBean transferRequestBean = new TransferRequestBean();
		BreIntServiceRequest breIntServiceRequest = new BreIntServiceRequest();
		breIntServiceRequest.setReqObject(transferRequestBean);
		when(razorPayIntegrationMapper.mapRazorPayRequestForTransfer(any())).thenReturn(breIntServiceRequest);
		when(serviceCallProcessor.mapToJson(any())).thenReturn(transferRequestBean.toString());
		when(serviceCallProcessor.getResponseObjectFromResponseJsonString(any(),any())).thenReturn(new TransferResponseBean());
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(new ResponseBean(), HttpStatus.OK);
		responseEntity.getBody().setPayload(
				"{ \"payload\" : {\"entity\" : \"collection\", \"count\" : 2, \"items\" : []}, \"status\" : \"SUCCESS\", \"errorBean\" : null }");
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.create(any(), any(), any(), any(), any(), any())).thenReturn(responseEntity);
		assertNotNull(razorPayIntegrationBusinessProcessor.callRazorpayTransferApi(razorpayTransferRequest));
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testCallRazorpayTransferApi_FailCase(){
		razorPayIntegrationBusinessProcessor.callRazorpayTransferApi(new RazorpayTransferRequest());
	}
	
	@Test
	public void testcallRazorpayRefundApi(){
		RefundRequestBean refundRequestBean = new RefundRequestBean();
		refundRequestBean.setAmount(BigDecimal.valueOf(10000));
		refundRequestBean.setPaymentId("pay_C99pGT4wlILj8e");
		refundRequestBean.setProductCode("DIGIGOLD");
		BreIntServiceRequest breIntServiceRequest = new BreIntServiceRequest();
		breIntServiceRequest.setReqObject(refundRequestBean);
		when(razorPayIntegrationMapper.mapRazorPayRequestForRefund(any())).thenReturn(breIntServiceRequest);
		when(serviceCallProcessor.mapToJson(any())).thenReturn(refundRequestBean.toString());
		when(serviceCallProcessor.getResponseObjectFromResponseJsonString(any(),any())).thenReturn(new RefundResponseBean());
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(new ResponseBean(), HttpStatus.OK);
		responseEntity.getBody().setPayload(
				"{ \"payload\" : {\"id\" : \"collection\"}, \"status\" : \"SUCCESS\", \"errorBean\" : null }");
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.create(any(), any(), any(), any(), any(), any())).thenReturn(responseEntity);
		assertNotNull(razorPayIntegrationBusinessProcessor.callRazorpayRefundApi(refundRequestBean));
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testcallRazorpayRefundApi_FailCase(){
		razorPayIntegrationBusinessProcessor.callRazorpayRefundApi(new RefundRequestBean());
	}
	
	@Test
	public void testUpdatePaymentTransactionForRefund(){
		Mockito.doNothing().when(razorPayIntegrationDao).updatePayTransForRefund(any(), any());
		razorPayIntegrationBusinessProcessor.updatePaymentTransactionForRefund("rfnd_C6RBoFsr669tRg", "pay_C63kATSb6UYqEN");
	}
}
