package com.bajaj.bfsd.razorpayintegration.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.RazorpayTransferRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.RefundResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.TransferResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusResponse;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;
import com.bajaj.bfsd.razorpayintegration.helper.RazorpayIntegrationHelper;
import com.bajaj.bfsd.razorpayintegration.service.RazorPayIntegrationService;
import com.bajaj.bfsd.razorpayintegration.util.ServiceCallProcessorUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;

@RunWith(PowerMockRunner.class)
@PrepareForTest({Utils.class})
public class RazorPayIntegrationControllerTest {

	@InjectMocks
	private RazorPayIntegrationController razorPayIntegrationController;

	@Mock
	private RazorPayIntegrationService razorPayIntegrationService;

	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	private ServiceCallProcessorUtil util;
	
	@Mock
	RazorpayIntegrationHelper controlerHelper; 
	
	@Mock
	private Environment env;
	
	@Before
	public void setUp() {
		ReflectionTestUtils.setField(razorPayIntegrationController, "env", env);
	}

	/**
	 * Positive test scenario for getRazorPayOrderId. Expected:status code 200
	 * Actual:status code 200
	 */
	@Test
	public void testGetRazorPayOrderId() {
		GenerateOrderIdRequestBean generateOrderIdRequestBean = new GenerateOrderIdRequestBean();
		HttpHeaders header = new HttpHeaders();
		Mockito.when(razorPayIntegrationService.initiateBooking(Mockito.any(GenerateOrderIdRequestBean.class)))
				.thenReturn(new GenerateOrderIdResponseBean());
		// method under test
		ResponseEntity<ResponseBean> res = razorPayIntegrationController.getRazorPayOrderId("FD",
				generateOrderIdRequestBean, header);
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}

	/**
	 * Negative test scenario for getRazorPayOrderId
	 */
	@Test(expected = NullPointerException.class)
	public void testGetRazorPayOrderIdException() {
		GenerateOrderIdRequestBean generateOrderIdRequestBean = new GenerateOrderIdRequestBean();
		HttpHeaders header = new HttpHeaders();
		Mockito.when(razorPayIntegrationService.initiateBooking(Mockito.any(GenerateOrderIdRequestBean.class)))
				.thenThrow(new NullPointerException());
		// method under test
		ResponseEntity<ResponseBean> res = razorPayIntegrationController.getRazorPayOrderId("FD",
				generateOrderIdRequestBean, header);
		assertEquals(HttpStatus.BAD_REQUEST, res.getStatusCode());
	}

	/**
	 * Positive test scenario for getRazorPayOrderId. Expected:status code 200
	 * Actual:status code 200
	 * @throws RazorpayException 
	 */
	@Test
	public void testUpdatePaymentStatus() throws RazorpayException {
		UpdatePaymentStatusRequest updatePaymentStatusRequest = new UpdatePaymentStatusRequest();
		HttpHeaders header = new HttpHeaders();
		PowerMockito.mockStatic(Utils.class);
		header.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "szdghsdg");
		Mockito.when(util.mapToJsonWithNull(updatePaymentStatusRequest)).thenReturn("");
		PowerMockito.when(Utils.verifyWebhookSignature(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(true);
		Mockito.when(razorPayIntegrationService.initiateUpdate(Mockito.anyString()))
				.thenReturn(new UpdatePaymentStatusResponse());
		Mockito.when(controlerHelper.authenticatePartner()).thenReturn(BigDecimal.ONE);
		// method under test
		ResponseEntity<ResponseBean> res = razorPayIntegrationController.updatePaymentStatus("",
				header);
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	
	@Test
	public void testUpdatePaymentStatusFalse() throws RazorpayException {
		UpdatePaymentStatusRequest updatePaymentStatusRequest = new UpdatePaymentStatusRequest();
		HttpHeaders header = new HttpHeaders();
		PowerMockito.mockStatic(Utils.class);
		header.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "szdghsdg");
		Mockito.when(util.mapToJsonWithNull(updatePaymentStatusRequest)).thenReturn("");
		PowerMockito.when(Utils.verifyWebhookSignature(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(false);
		Mockito.when(razorPayIntegrationService.initiateUpdate(Mockito.anyString()))
				.thenReturn(new UpdatePaymentStatusResponse());
		Mockito.when(controlerHelper.authenticatePartner()).thenReturn(BigDecimal.ONE);
		// method under test
		ResponseEntity<ResponseBean> res = razorPayIntegrationController.updatePaymentStatus("",
				header);
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}

	/**
	 * Negative test scenario for updatePaymentStatus
	 * @throws RazorpayException 
	 */
	@SuppressWarnings("unchecked")
	@Test(expected = BFLBusinessException.class)
	public void testUpdatePaymentStatusException() throws RazorpayException {
		UpdatePaymentStatusRequest updatePaymentStatusRequest = new UpdatePaymentStatusRequest();
		HttpHeaders header = new HttpHeaders();
		PowerMockito.mockStatic(Utils.class);
		PowerMockito.when(Utils.verifyWebhookSignature(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(false);
		header.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "szdghsdg");
		Mockito.when(util.mapToJsonWithNull(updatePaymentStatusRequest)).thenReturn("");
		Mockito.when(razorPayIntegrationService.initiateUpdate(Mockito.anyString()))
				.thenThrow(Exception.class);
		// method under test
		razorPayIntegrationController.updatePaymentStatus("", header);
	}

	/**
	 * Positive test scenario for UpdatePendingTransStatus. Expected:status code 200
	 * Actual:status code 200
	 */
	@Test
	public void testUpdatePendingTransStatus() {
		HttpHeaders header = new HttpHeaders();
		// method under test
		ResponseEntity<ResponseBean> res = razorPayIntegrationController.updatePendingTransStatus(header);
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}

	/**
	 * Negative test scenario for UpdatePendingTransStatus
	 */
	@Test(expected = NullPointerException.class)
	public void testUpdatePendingTransStatusException() {
		HttpHeaders header = new HttpHeaders();
		Mockito.when(razorPayIntegrationService.updatePendingTransStatus()).thenThrow(new NullPointerException());
		// method under test
		razorPayIntegrationController.updatePendingTransStatus(header);
	}
	
	/**
	 * Positive test scenario for callbackHandler. Expected:status code 200
	 * Actual:status code 200
	 */
	@Test
	public void testcallbackHandler() {
		ResponseEntity<ResponseBean> response = new ResponseEntity<ResponseBean>(new ResponseBean(), HttpStatus.OK);
		Mockito.when(razorPayIntegrationService.selectProcess(Mockito.any(), Mockito.anyString(), Mockito.anyString())).thenReturn(response);
	}
	
	@Test
	public void testcallbackHandlerNull() {
		Mockito.when(razorPayIntegrationService.selectProcess(Mockito.any(), Mockito.anyString(), Mockito.anyString())).thenReturn(null);
	}
	
	@Test
	public void testcallbackHandlerOne() {
		HttpHeaders header = new HttpHeaders();
		Mockito.when(razorPayIntegrationService.selectProcess(header, "test","")).thenReturn(null);
		razorPayIntegrationController.callbackHandler(header, "test","");
	}
	@Test
	public void testDigitalGoldCallbackHandler(){
		HttpHeaders header = new HttpHeaders();
		Mockito.when(razorPayIntegrationService.digitalGoldSelectProcess(Mockito.any(),Mockito.any())).thenReturn(new ResponseEntity<>(new ResponseBean(), HttpStatus.OK));
		ResponseEntity<ResponseBean> res=razorPayIntegrationController.digitalGoldCallbackHandler(header,"xyz");
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
	
	@Test
	public void testInitiateRazorpayTransfer(){
		when(razorPayIntegrationService.initiateTransferProcess(any())).thenReturn(new TransferResponseBean());
		assertEquals(HttpStatus.OK, razorPayIntegrationController.initiateRazorpayTransfer(null, new RazorpayTransferRequest()).getStatusCode());
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected=BFLBusinessException.class)
	public void testInitiateRazorpayTransfer_FailCase(){
		when(razorPayIntegrationService.initiateTransferProcess(any())).thenThrow(Exception.class);
		razorPayIntegrationController.initiateRazorpayTransfer(null, new RazorpayTransferRequest());
	}
	
	@Test
	public void testinitiateRazorpayRefund(){
		when(razorPayIntegrationService.initiateRefundProcess(any())).thenReturn(new RefundResponseBean());
		assertEquals(HttpStatus.OK, razorPayIntegrationController.initiateRazorpayRefund(null, new RefundRequestBean()).getStatusCode());
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected=BFLBusinessException.class)
	public void testinitiateRazorpayRefund_FailCase(){
		when(razorPayIntegrationService.initiateRefundProcess(any())).thenThrow(Exception.class);
		razorPayIntegrationController.initiateRazorpayRefund(null, new RefundRequestBean());
	}
	
	@Test
	public void testUpdatePaymentRefundId(){
		Mockito.doNothing().when(razorPayIntegrationService).updatePaymentTransactionForRefund(any(), any());
		assertEquals(HttpStatus.OK, razorPayIntegrationController.updatePaymentRefundId("rfnd_C6RBoFsr669tRg","pay_C63kATSb6UYqEN",null).getStatusCode());
	}

	@Test(expected=BFLBusinessException.class)
	public void testUpdatePaymentRefundId_FailCase(){
		Mockito.doThrow(Exception.class).when(razorPayIntegrationService).updatePaymentTransactionForRefund(any(),any());
		razorPayIntegrationController.updatePaymentRefundId("rfnd_C6RBoFsr669tRg","pay_C63kATSb6UYqEN",null);
	}

}
