package com.bajaj.bfsd.razorpayintegration.helper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.BuyProcessRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RedeemConfirmRequest;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;
import com.bajaj.bfsd.razorpayintegration.dao.RazorPayIntegrationDao;
import com.bajaj.bfsd.razorpayintegration.util.ServiceCallProcessorUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;


@RunWith(PowerMockRunner.class)
@PrepareForTest({ BFLCommonRestClient.class,Utils.class })
public class RazorpayIntegrationHelperTest {

	@InjectMocks
	private RazorpayIntegrationHelper razorPayHelper;

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	private Environment env;

	@Mock
	private ServiceCallProcessorUtil util;
	
	@Mock
	private RazorPayIntegrationDao integrationDao;
		
	@Test
	@SuppressWarnings("unchecked")
	public void testAuthenticatePartner() {
		String value = "";
		ResponseBean responseBean = new ResponseBean(value);
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito
				.when((ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(response);
		Mockito.when(integrationDao.getUserKey(Mockito.anyString())).thenReturn(BigDecimal.ONE);
		BigDecimal res = razorPayHelper.authenticatePartner();
		assertEquals(BigDecimal.ONE, res);
	}

	@Test
	@SuppressWarnings("unchecked")
	public void testAuthenticatePartnerBadStatus() {
		String value = "";
		ResponseBean responseBean = new ResponseBean(value);
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.BAD_REQUEST);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito
				.when((ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(response);
		BigDecimal res = razorPayHelper.authenticatePartner();
		assertEquals(BigDecimal.ZERO, res);
	}
	@Test
	public void testValidateSignature() throws RazorpayException {
		PowerMockito.mockStatic(Utils.class);
		Mockito.when(Utils.verifyWebhookSignature(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(true);
	    assertTrue(razorPayHelper.validateSignature(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()));
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testValidateSignatureFalse() throws RazorpayException {
		PowerMockito.mockStatic(Utils.class);
		Mockito.when(Utils.verifyWebhookSignature(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(false);
	    assertTrue(razorPayHelper.validateSignature(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()));
	}
	
	@Test(expected=BFLTechnicalException.class)
	public void testValidateSignatureEx() throws RazorpayException {
		PowerMockito.mockStatic(Utils.class);
		Mockito.when(Utils.verifyWebhookSignature(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenThrow(new RazorpayException(""));
	    assertTrue(razorPayHelper.validateSignature(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()));
	}
	
	
	
	@Test
	public void testselectProcess() throws RazorpayException {
		HttpHeaders headers = new HttpHeaders();
		PowerMockito.mockStatic(Utils.class);
		ResponseBean responseBean = new ResponseBean("SUCCESS");
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "szdghsdg");
		Mockito.when(Utils.verifyWebhookSignature(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(true);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(response);
		
		// method under test
		razorPayHelper.invokeEndpoint("", "", headers);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testselectProcessError() throws RazorpayException {
		HttpHeaders headers = new HttpHeaders();
		PowerMockito.mockStatic(Utils.class);
		ResponseBean responseBean = new ResponseBean("SUCCESS");
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.ACCEPTED);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "szdghsdg");
		Mockito.when(Utils.verifyWebhookSignature(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(true);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(response);
		
		// method under test
		razorPayHelper.invokeEndpoint("", "", headers);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testselectProcessNull() throws RazorpayException {
		HttpHeaders headers = new HttpHeaders();
		PowerMockito.mockStatic(Utils.class);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		headers.set(RazorPayIntegrationConstants.RAZORPAY_SIGNATURE, "szdghsdg");
		Mockito.when(Utils.verifyWebhookSignature(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(true);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(null);
		
		// method under test
		razorPayHelper.invokeEndpoint("", "", headers);
	}
	
	@Test
	@SuppressWarnings("unchecked")
	public void testcallconfirmService() throws JsonParseException, JsonMappingException, IOException {
		BuyProcessRequest buyProcessRequest = new BuyProcessRequest();
		buyProcessRequest.setRequestType("confirm");
		buyProcessRequest.setDgProviderCode("SFGLD");
		ResponseBean responseBean = new ResponseBean();
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when(util.prepareRequestJson(Mockito.any())).thenReturn("");
		Mockito.when(util.getResponse(Mockito.any())).thenReturn(responseBean);
		PowerMockito.when(
				(ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(response);
		Future<ResponseBean> res = razorPayHelper.callconfirmService("", buyProcessRequest, new HttpHeaders());
		assertNotNull(res);
	}

	@Test
	@SuppressWarnings("unchecked")
	public void testcallconfirmService_Fail() throws JsonParseException, JsonMappingException, IOException {
		BuyProcessRequest buyProcessRequest = new BuyProcessRequest();
		buyProcessRequest.setRequestType("confirm");
		buyProcessRequest.setDgProviderCode("SFGLD");
		ResponseBean responseBean = new ResponseBean();
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.BAD_REQUEST);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when(util.prepareRequestJson(Mockito.any())).thenReturn("");
		Mockito.when(util.getResponse(Mockito.any())).thenReturn(responseBean);
		PowerMockito.when(
				(ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(response);
		Future<ResponseBean> res = razorPayHelper.callconfirmService("", buyProcessRequest, new HttpHeaders());
		assertNotNull(res);
	}
	
	@Test
	@SuppressWarnings("unchecked")
	public void testcallconfirmService_Failresponse() {
		BuyProcessRequest buyProcessRequest = new BuyProcessRequest();
		buyProcessRequest.setRequestType("confirm");
		buyProcessRequest.setDgProviderCode("SFGLD");
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		
		PowerMockito.when(
				(ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(Exception.class);
		Future<ResponseBean> res = razorPayHelper.callconfirmService("", buyProcessRequest, new HttpHeaders());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testDigitalGoldauthenticatePartner() {
		ResponseBean bean = new ResponseBean();
		bean.setPayload(bean);
		ResponseBean responseBean1 = new ResponseBean();
		responseBean1.setPayload(bean);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.invokeRestEndpoint(any(), any(), any(), any(), any(), any(), any()))
				.thenReturn(new ResponseEntity(responseBean1, HttpStatus.OK));
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("value");
		razorPayHelper.digitalGoldauthenticatePartner(new HttpHeaders());
		assertNotNull(bean);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCallredeemConfirmService() throws JsonParseException, JsonMappingException, IOException
	{
		RedeemConfirmRequest redeemConfirmRequest = new RedeemConfirmRequest();
		redeemConfirmRequest.setAppSource("appSource");
		redeemConfirmRequest.setDgProviderCode("dgProviderCode");
		ResponseBean responseBean = new ResponseBean();
		ResponseEntity<ResponseBean> response = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(
				(ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(response);
		razorPayHelper.callredeemConfirmService("Value", redeemConfirmRequest, "orderId", new HttpHeaders());
		assertNotNull(redeemConfirmRequest);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCallredeemConfirmService_Fail()
	{
		RedeemConfirmRequest redeemConfirmRequest = new RedeemConfirmRequest();
		redeemConfirmRequest.setAppSource("appSource");
		redeemConfirmRequest.setDgProviderCode("dgProviderCode");
		ResponseBean responseBean = new ResponseBean();
		ResponseEntity<ResponseBean> response = null;
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(
				(ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(response);
		razorPayHelper.callredeemConfirmService("Value", redeemConfirmRequest, "orderId", new HttpHeaders());
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCallredeemConfirmService_Exception()
	{
		RedeemConfirmRequest redeemConfirmRequest = new RedeemConfirmRequest();
		redeemConfirmRequest.setAppSource("appSource");
		redeemConfirmRequest.setDgProviderCode("dgProviderCode");
		ResponseEntity<ResponseBean> response = null;
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(
				(ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(Exception.class);
		
		razorPayHelper.callredeemConfirmService("Value", redeemConfirmRequest, "orderId", new HttpHeaders());
		
	}
}
