package com.bajaj.bfsd.razorpayintegration.enumeration;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
public class PayEventTypeTest {
	@Test
	public void testDI() {
	assertEquals(5, PayEventType.DI.getValue());
	}
	@Test
	public void testFC() {
	assertEquals(2, PayEventType.FC.getValue());
	}
	@Test
	public void testMI() {
	assertEquals(6, PayEventType.ME.getValue());
	}
	@Test
	public void testPP() {
	assertEquals(1, PayEventType.PP.getValue());
	}
	
	@Test
	public void testDIName() {
	assertEquals("DI", PayEventType.DI.getName());
	}
	@Test
	public void testFCName() {
	assertEquals("FC", PayEventType.FC.getName());
	}
	@Test
	public void testMIName() {
	assertEquals("ME", PayEventType.ME.getName());
	}
	@Test
	public void testPPName() {
	assertEquals("PP", PayEventType.PP.getName());
	}

}
