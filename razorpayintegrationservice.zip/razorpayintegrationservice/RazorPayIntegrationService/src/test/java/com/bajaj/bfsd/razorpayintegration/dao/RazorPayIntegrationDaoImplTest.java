package com.bajaj.bfsd.razorpayintegration.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.razorpayintegration.bean.RazorServiceRequestDetails;
import com.bajaj.bfsd.razorpayintegration.bean.SerReqStprazorDetail;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;
import com.bajaj.bfsd.razorpayintegration.data.RazorPayTestDataPopulator;
import com.bajaj.bfsd.razorpayintegration.model.PayGatewayPartner;
import com.bajaj.bfsd.razorpayintegration.model.PaymentTransaction;
import com.bajaj.bfsd.razorpayintegration.model.PgmerchantProductsMapping;
import com.bajaj.bfsd.razorpayintegration.util.RazorSRDbUtil;
import com.bajaj.bfsd.razorpayintegration.util.ServiceCallProcessorUtil;
import com.bfl.common.exceptions.BFLBusinessException;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ ServiceCallProcessorUtil.class ,RazorSRDbUtil.class})
public class RazorPayIntegrationDaoImplTest {
	@InjectMocks
	private RazorPayIntegrationDaoImpl razorPayIntegrationDao;

	@Mock
	BFLLoggerUtilExt logger;
	@Mock
	EntityManager entityManager;
	@Mock
	Environment env;
	@Mock
	private Query query1;

	@Mock
	private Query query;
	
	@Mock
	private RazorSRDbUtil RazorSRDbUtil;

	/**
	 * Negative test case for getsecretkey.
	 */
	
	@Test(expected=BFLBusinessException.class)
	public void testGetSecretApiKey1() {
		List<PgmerchantProductsMapping> count = new ArrayList<PgmerchantProductsMapping>();
		PgmerchantProductsMapping mapping = new PgmerchantProductsMapping();
		mapping.setMerchantid("2");
		count.add(new PgmerchantProductsMapping());
		Mockito.when(entityManager.createQuery("from PgmerchantProductsMapping b where b.productCodeL3=:productId"))
				.thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(count);
		Mockito.when(entityManager.createQuery("from PayGatewayPartner a where a.merchantid =:merchantid"))
				.thenReturn(query1);
		Mockito.when(query1.getResultList()).thenReturn(null);
		razorPayIntegrationDao.getSecretApiKey("FD");

	}
	
	@Test(expected = BFLBusinessException.class)
	public void testGetSecretApiKey2() {
		Mockito.when(entityManager.createQuery("from PgmerchantProductsMapping b where b.productCodeL3=:productId"))
				.thenReturn(query);
		Mockito.when(entityManager.createQuery("from PayGatewayPartner a where a.merchantid =:merchantid"))
				.thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(null);
		razorPayIntegrationDao.getSecretApiKey("FD");

	}

	/**
	 * Negative test case for getsecret key
	 */
	@Test(expected = BFLBusinessException.class)
	public void testGetSecretApiKeyZero() {
		List<PgmerchantProductsMapping> result1 = new ArrayList<PgmerchantProductsMapping>();
		PgmerchantProductsMapping pgmerchantProductsMapping = new PgmerchantProductsMapping();
		pgmerchantProductsMapping.setMerchantid("123");
		result1.add(pgmerchantProductsMapping);
		Mockito.when(entityManager.createQuery("from PgmerchantProductsMapping b where b.productCodeL3=:productId"))
				.thenReturn(query);
		Mockito.when(entityManager.createQuery("from PayGatewayPartner a where a.merchantid =:merchantid"))
				.thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result1);
		// method under test
		razorPayIntegrationDao.getSecretApiKey("FD");

	}

	/**
	 * Positive test case for updateOrderId
	 */
	/*@Test
	public void testUpdateOrderId() {
		List<ServiceRequest> result = new ArrayList<>();
		ServiceRequest serviceRequest = new ServiceRequest();
		serviceRequest.setSrkey(new Long("123541"));
		result.add(serviceRequest);
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.GET_SERVICE_REQUEST)).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.UPDATE_SER_REQ_STP_DETAIL_QUERY))
				.thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(1);
		razorPayIntegrationDao.updateOrderId("104", "asfdhjah");

	}*/
	
	@Test
	public void testUpdateOrderId() {
		PowerMockito.mock(RazorSRDbUtil.class);
		RazorServiceRequestDetails razorServiceRequestDetails=new RazorServiceRequestDetails();
		razorServiceRequestDetails.setSrKey(1L);
		razorServiceRequestDetails.setSrnumber("1");
		PowerMockito.when(RazorSRDbUtil.getSRDetails(Mockito.any())).thenReturn(razorServiceRequestDetails);
		PowerMockito.doNothing().when(RazorSRDbUtil).updateReqStpDtlRefNum(Mockito.any(),Mockito.any());
		razorPayIntegrationDao.updateOrderId("1","TEST");
		
	}
	@Test(expected=BFLBusinessException.class)
	public void testUpdateOrderIdWithException() {
		PowerMockito.mock(RazorSRDbUtil.class);
		PowerMockito.when(RazorSRDbUtil.getSRDetails(Mockito.any())).thenThrow(BFLBusinessException.class);
		razorPayIntegrationDao.updateOrderId("1","TEST");
	}
		

	@Test
	public void testInsertPayTrans() {
		PowerMockito.mock(RazorSRDbUtil.class);
		RazorServiceRequestDetails razorServiceRequestDetails=new RazorServiceRequestDetails();
		razorServiceRequestDetails.setSrKey(1L);
		razorServiceRequestDetails.setSrnumber("1");
		PowerMockito.when(RazorSRDbUtil.getSRDetails(Mockito.any())).thenReturn(razorServiceRequestDetails);
		SerReqStprazorDetail serReqStprazorDetail=new SerReqStprazorDetail();
		serReqStprazorDetail.setStpreqattributes("{\"stpreqattributes\": \"TEST\",\"eventType\": \"PP\"}");
		serReqStprazorDetail.setNetamount(new BigDecimal(1));
		PowerMockito.when(RazorSRDbUtil.getRazStpDetails(Mockito.any())).thenReturn(serReqStprazorDetail);
		
		
		List<PgmerchantProductsMapping> count = new ArrayList<PgmerchantProductsMapping>();
		PgmerchantProductsMapping mapping = new PgmerchantProductsMapping();
		mapping.setMerchantid("2");
		count.add(mapping);
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.GET_PGMERCHANTPRODUCTS_MAPPING))
				.thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(count);
		
		List<PayGatewayPartner> count1 = new ArrayList<PayGatewayPartner>();
		PayGatewayPartner mapping1 = new PayGatewayPartner();
		mapping1.setApikey("1");
		count1.add(mapping1);
		Mockito.when(entityManager.createQuery("from PayGatewayPartner a where a.merchantid =:merchantid"))
				.thenReturn(query1);
		Mockito.when(query1.getResultList()).thenReturn(count1);
		razorPayIntegrationDao.insertPayTrans("1","TEST");
		
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testInsertPayTrans2() {
		
		razorPayIntegrationDao.insertPayTrans("1","TEST");
		
	}
	/*@Test(expected = BFLBusinessException.class)
	public void testUpdateOrderIdNegative1() {
		List<ServiceRequest> result = new ArrayList<>();
		ServiceRequest serviceRequest = new ServiceRequest();
		serviceRequest.setSrkey(new Long("123541"));
		result.add(serviceRequest);
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.GET_SERVICE_REQUEST)).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.UPDATE_SER_REQ_STP_DETAIL_QUERY))
				.thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(0);
		razorPayIntegrationDao.updateOrderId("104", "asfdhjah");

	}*/

	/**
	 * Negative test case for updateOrderId
	 */
/*	@Test(expected = BFLBusinessException.class)
	public void testUpdateOrderIdNegative() {
		List<ServiceRequest> result = new ArrayList<>();
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.GET_SERVICE_REQUEST)).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		razorPayIntegrationDao.updateOrderId("104", "asfdhjah");

	}
*/
	/**
	 * Negative test case for updateOrderId
	 */
	@Test(expected = BFLBusinessException.class)
	public void testUpdateOrderIdException() {
		Mockito.when(entityManager
				.createQuery("update SerReqStpDetail srsd set srsd.paytransrefnum=:orderId where srsd.srkey=:srId"))
				.thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(0);

		razorPayIntegrationDao.updateOrderId("104", "asfdhjah");

	}

	

	@Test
	public void testGetAllPendingTransactions() {
		List<PaymentTransaction> paymentTransList = new ArrayList<>();
		paymentTransList.add(new PaymentTransaction());
		paymentTransList.add(new PaymentTransaction());
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.GET_PENDING_TRANSACTION)).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(paymentTransList);
		List<PaymentTransaction> res = razorPayIntegrationDao.getAllPendingTransactions();
		assertEquals(2, res.size());

	}

	@Test
	public void testUpdatePendingTrans() throws ParseException {
		Date date = Calendar.getInstance().getTime();
		List<PaymentTransaction> paymentTransactionsList = RazorPayTestDataPopulator.paymentTransactionsList();
		Mockito.when(env.getProperty(RazorPayIntegrationConstants.CHANGE_PMT_STATUS_HOURS_VAL)).thenReturn("12");
		RazorServiceRequestDetails razorServiceRequestDetails=new RazorServiceRequestDetails();
		razorServiceRequestDetails.setSrKey(1L);
		razorServiceRequestDetails.setSrnumber("1");
		razorServiceRequestDetails.setSerreqresolutionkey(1L);
		PowerMockito.when(RazorSRDbUtil.getRazorSerResol(Mockito.anyString(),Mockito.anyString())).thenReturn(razorServiceRequestDetails);
		PowerMockito.doNothing().when(RazorSRDbUtil).updateSerResolution(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		Mockito.when(entityManager.merge(Mockito.any())).thenReturn(12);
		Mockito.when(RazorSRDbUtil.getSRDetails(Mockito.any())).thenReturn(razorServiceRequestDetails);
		SerReqStprazorDetail serReqStprazorDetail=new SerReqStprazorDetail();
		serReqStprazorDetail.setStpreqattributes("{\"stpreqattributes\": \"TEST\",\"eventType\": \"PP\"}");
		serReqStprazorDetail.setNetamount(new BigDecimal(1));
		PowerMockito.when(RazorSRDbUtil.getRazStpDetails(Mockito.any())).thenReturn(serReqStprazorDetail);
		Mockito.doNothing().when(RazorSRDbUtil).updateServiceReqStpDetails(Mockito.any());

		// method under test
		razorPayIntegrationDao.updatePendingTrans(paymentTransactionsList);
	}
	@Test
	public void testUpdatePendingTrans2() throws ParseException {
		Date date = Calendar.getInstance().getTime();
		List<PaymentTransaction> paymentTransactionsList = RazorPayTestDataPopulator.paymentTransactionsList();
		Mockito.when(env.getProperty(RazorPayIntegrationConstants.CHANGE_PMT_STATUS_HOURS_VAL)).thenReturn("12");
		PowerMockito.when(RazorSRDbUtil.getRazorSerResol(Mockito.anyString(),Mockito.anyString())).thenReturn(null);
		PowerMockito.doNothing().when(RazorSRDbUtil).updateSrreqcurStatus(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		Mockito.when(entityManager.merge(Mockito.any())).thenReturn(12);
		/*ServiceRequest serviceRequest = new ServiceRequest();
		setServiceRequest(serviceRequest);
		Mockito.when(entityManager.getReference(ServiceRequest.class, 1L)).thenReturn(serviceRequest);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);*/

		// method under test
		razorPayIntegrationDao.updatePendingTrans(paymentTransactionsList);
	}
	

/*	private void setServiceRequest(ServiceRequest serviceRequest) {

		List<SerReqResolution> SerReqResolutionList = new ArrayList<>();
		SerReqResolution serReqResolution = new SerReqResolution();
		serReqResolution.setSerreqresolutionkey(123L);
		SerReqResolutionList.add(serReqResolution);
		serviceRequest.setSerReqResolutions(SerReqResolutionList);

	}*/

/*	@Test
	public void testUpdatePendingTransSuccess() throws ParseException {
		Date date = Calendar.getInstance().getTime();
		List<PaymentTransaction> paymentTransactionsList = RazorPayTestDataPopulator.paymentTransactionsList();
		Mockito.when(env.getProperty(RazorPayIntegrationConstants.CHANGE_PMT_STATUS_HOURS_VAL)).thenReturn("12");
		PowerMockito.mockStatic(ServiceCallProcessorUtil.class);
		PowerMockito.when(ServiceCallProcessorUtil.getCurrentDate()).thenReturn(new Timestamp(date.getTime()));

		ServiceRequest serviceRequest = new ServiceRequest();
		setServiceRequest(serviceRequest);
		Mockito.when(entityManager.getReference(ServiceRequest.class, 1L)).thenReturn(serviceRequest);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		// method under test
		razorPayIntegrationDao.updatePendingTrans(paymentTransactionsList);
	}*/
/*
	@Test(expected = BFLBusinessException.class)
	public void testInsertPayTrans() {
		List<ServiceRequest> serviceReqList = new ArrayList<>();
		serviceReqList.add(new ServiceRequest());
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.GET_SERVICE_REQUEST)).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(serviceReqList);
		razorPayIntegrationDao.insertPayTrans("SR1234", "SOL");
	}
*/
	@Test
	public void testupdatePayTrans() {
		UpdatePaymentStatusRequest updatePaymentStatusRequest=RazorPayTestDataPopulator.popUpdatePaymentStatusRequest();
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.UPDATE_PAY_TRANS_QUERY)).thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(1);
		// method under test
		razorPayIntegrationDao.updatePayTrans(updatePaymentStatusRequest, "SR123");
	}

	@Test(expected = BFLBusinessException.class)
	public void testupdatePayTransError() {
		UpdatePaymentStatusRequest updatePaymentStatusRequest=RazorPayTestDataPopulator.popUpdatePaymentStatusRequest();
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.UPDATE_PAY_TRANS_QUERY)).thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(0);
		// method under test
		razorPayIntegrationDao.updatePayTrans(updatePaymentStatusRequest, "SR123");
	}

	/*@Test
	public void testUpdateSerReqStatus() {
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.UPDATE_SER_REQ_STP_STAT_QUERY))
				.thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(1);
		// method under test
		razorPayIntegrationDao.updateSerReqStatus("orderId", BigDecimal.ONE, BigDecimal.ONE);
	}*/

	@Test
	public void testUpdateSerReqStatusException() {
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.UPDATE_SER_REQ_STP_STAT_QUERY))
				.thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(0);
		// method under test
		razorPayIntegrationDao.updateSerReqStatus("orderId", BigDecimal.ONE, BigDecimal.ONE);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testUpdateSerReqStatusException2() {
		Mockito.doThrow(BFLBusinessException.class).when(RazorSRDbUtil).updateServiceReqStpDetails(Mockito.any());
		razorPayIntegrationDao.updateSerReqStatus("orderId", null, BigDecimal.ONE);
	}

	@Test
	public void testInsertAppSysCode() {
		Mockito.when(entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_APPLICANT_KEY_QUERY))
				.thenReturn(query);
		Mockito.when(entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_SYSTEM_KEY_QUERY))
				.thenReturn(query);
		Mockito.when(query.getSingleResult()).thenReturn(BigDecimal.ONE);
		// method under test
		razorPayIntegrationDao.insertAppSysCode("CIF", "ORDERID");
	}

	@Test(expected = BFLBusinessException.class)
	public void testInsertAppSysCodeException() {
		Mockito.when(entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_APPLICANT_KEY_QUERY))
				.thenReturn(query);
		Mockito.when(entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_SYSTEM_KEY_QUERY))
				.thenReturn(query);
		Mockito.when(query.getSingleResult()).thenThrow(new RuntimeException());
		// method under test
		razorPayIntegrationDao.insertAppSysCode("CIF", "ORDERID");
	}

	@Test
	public void testGetSrNumber() {
		
		RazorServiceRequestDetails razorServiceRequestDetails=new RazorServiceRequestDetails();
		razorServiceRequestDetails.setSrKey(1L);
		razorServiceRequestDetails.setSrnumber("SR123");
		PowerMockito.when(RazorSRDbUtil.getRazServReqnum(Mockito.any()))
				.thenReturn(razorServiceRequestDetails);
		
		String res = razorPayIntegrationDao.getSrNumber("1");
		assertEquals("SR123", res);
	}

	@Test(expected = BFLBusinessException.class)
	public void testGetSrNumberException() {
		Mockito.when(entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_SR_NUMBER_QUERY))
				.thenReturn(query);
		Mockito.when(query.getSingleResult()).thenThrow(new RuntimeException());
		// method under test
		razorPayIntegrationDao.getSrNumber("orderId");
	}

	@Test
	public void testGetApplicationKey() {
 		RazorServiceRequestDetails razorServiceRequestDetails=new RazorServiceRequestDetails();
		razorServiceRequestDetails.setSrKey(1L);
		Mockito.when(RazorSRDbUtil.getSRDetails(Mockito.any())).thenReturn(razorServiceRequestDetails);
		List<BigDecimal> result = new ArrayList<>();
		result.add(BigDecimal.ONE);
		Mockito.when(entityManager.createNativeQuery(Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		razorPayIntegrationDao.getApplicationKey("SR123");
		assertEquals(BigDecimal.ONE, razorPayIntegrationDao.getApplicantKey(BigDecimal.ONE));
	}
	@Test
	public void testGetApplicationKey2() {
 		RazorServiceRequestDetails razorServiceRequestDetails=new RazorServiceRequestDetails();
		razorServiceRequestDetails.setSrKey(1L);
		Mockito.when(RazorSRDbUtil.getSRDetails(Mockito.any())).thenReturn(razorServiceRequestDetails);
		Mockito.when(entityManager.createNativeQuery(Mockito.any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(null);
		BigDecimal out=razorPayIntegrationDao.getApplicationKey("SR123");
		assertNull(out);
	}
	
	@Test
	public void testGetApplicationKey3() {
 		RazorServiceRequestDetails razorServiceRequestDetails=new RazorServiceRequestDetails();
		razorServiceRequestDetails.setSrKey(1L);
		Mockito.when(RazorSRDbUtil.getSRDetails(Mockito.any())).thenReturn(razorServiceRequestDetails);
		Mockito.when(entityManager.createNativeQuery(Mockito.any())).thenThrow(Exception.class);
		BigDecimal out=razorPayIntegrationDao.getApplicationKey("SR123");
		assertNull(out);
	}
	
	@Test
	public void testGetApplicantKey() {
		
		List<BigDecimal> result = new ArrayList<>();
		result.add(BigDecimal.ONE);
		Mockito.when(entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_APPLICANT_KEY)).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		razorPayIntegrationDao.getApplicantKey(new BigDecimal(1));
		assertEquals(BigDecimal.ONE, razorPayIntegrationDao.getApplicantKey(BigDecimal.ONE));
	}
	
	@Test
	public void testGetApplicantKey2() {
		List<BigDecimal> result = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_APPLICANT_KEY)).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		assertNull( razorPayIntegrationDao.getApplicantKey(BigDecimal.ONE));
	}
	
	
	@Test
	public void testGetApplicantKeyEx() {
		Mockito.when(entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_APPLICANT_KEY)).thenReturn(query);
		Mockito.when(query.getResultList()).thenThrow(new BFLBusinessException());
		assertNull( razorPayIntegrationDao.getApplicantKey(BigDecimal.ONE));
	}
	
	@Test
	public void testGetUserKey() {
		List<BigDecimal> result = new ArrayList<>();
		result.add(BigDecimal.TEN);
		Mockito.when(entityManager.createNativeQuery(RazorPayIntegrationConstants.GET_USER_KEY)).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(result);
		assertEquals(BigDecimal.TEN,razorPayIntegrationDao.getUserKey("SR120"));
		
	}
	@Test
	public void testGetTransStatus() {
		RazorServiceRequestDetails razorServiceRequestDetails=new RazorServiceRequestDetails();
		razorServiceRequestDetails.setPaytransstatus(new BigDecimal(1));
		PowerMockito.when(RazorSRDbUtil.getRazorSerResol(Mockito.anyString(),Mockito.anyString())).thenReturn(razorServiceRequestDetails);
		assertEquals(BigDecimal.ONE, razorPayIntegrationDao.getTransStatus("TEST"));
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testGetTransStatusEx() {
	razorPayIntegrationDao.getTransStatus("TEST");
	}
	
	@Test
	public void testUpdatePayTransForRefund() {
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.UPDATE_PAY_TRANS_FOR_REFUND_QUERY)).thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(1);
		// method under test
		razorPayIntegrationDao.updatePayTransForRefund("rfnd_C6RBoFsr669tRg","pay_C1N4hiurZNF7sw");
	}

	@Test(expected = BFLBusinessException.class)
	public void testUpdatePayTransForRefund_ErrorCase() {
		Mockito.when(entityManager.createQuery(RazorPayIntegrationConstants.UPDATE_PAY_TRANS_FOR_REFUND_QUERY)).thenReturn(query);
		Mockito.when(query.executeUpdate()).thenReturn(0);
		// method under test
		razorPayIntegrationDao.updatePayTransForRefund("rfnd_C6RBoFsr669tRg", "pay_C1N4hiurZNF7sw");
	}
	
/*	@Test
	public void closeServiceRequestTest() {

		ServiceRequest serviceRequest = new ServiceRequest();
		setServiceRequest(serviceRequest);
		Mockito.when(entityManager.getReference(Mockito.any(), Mockito.anyLong())).thenReturn(serviceRequest);
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		razorPayIntegrationDao.closeServiceRequest(123L);
	}*/
}
