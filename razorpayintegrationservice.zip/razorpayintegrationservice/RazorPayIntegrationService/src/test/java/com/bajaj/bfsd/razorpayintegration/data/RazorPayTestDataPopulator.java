package com.bajaj.bfsd.razorpayintegration.data;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bajaj.bfsd.razorpayintegration.bean.BreIntServiceRequest;
import com.bajaj.bfsd.razorpayintegration.bean.BrePaymentStatusReqBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.model.PaymentTransaction;

public class RazorPayTestDataPopulator {

	public static GenerateOrderIdRequestBean populateGenerateOrderIdRequestBean() {
		GenerateOrderIdRequestBean generateOrderIdRequestBean = new GenerateOrderIdRequestBean();
		generateOrderIdRequestBean.setAmount(new BigDecimal(1000));
		generateOrderIdRequestBean.setLoanAccountNo("7854692");
		generateOrderIdRequestBean.setCurrency("INR");
		generateOrderIdRequestBean.setPayment_Capture(1);
		generateOrderIdRequestBean.setReciept(null);
		generateOrderIdRequestBean.setSrNumber("A1");
		generateOrderIdRequestBean.setProductCode("SOL");
		return generateOrderIdRequestBean;

	}

	public static BreIntServiceRequest populateBresIntServRequest() {
		BreIntServiceRequest breIntServiceRequest = new BreIntServiceRequest();
		breIntServiceRequest.setClassType(GenerateOrderIdResponseBean.class);
		breIntServiceRequest
				.setBreIntUrl("http://razorpaypgservice.qa.bfsgodirect.com/razorpay/v1/razorpay/pg/getorderid");
		return breIntServiceRequest;
	}

	public static GenerateOrderIdResponseBean populateGenerateOrderIdResponseBean() {
		GenerateOrderIdResponseBean generateOrderIdResponseBean = new GenerateOrderIdResponseBean();
		generateOrderIdResponseBean.setAccessKey("SDGkjhgasD");
		generateOrderIdResponseBean.setAmount(new BigDecimal(1000));
		generateOrderIdResponseBean.setAttempts(1);
		generateOrderIdResponseBean.setCreateDate("02032018");
		generateOrderIdResponseBean.setEntity("ABC");
		generateOrderIdResponseBean.setOrderId("A12");
		generateOrderIdResponseBean.setReceipt("A12");
		generateOrderIdResponseBean.setStatus("created");
		return generateOrderIdResponseBean;
	}

	public static UpdatePaymentStatusRequest popUpdatePaymentStatusRequest() {
		UpdatePaymentStatusRequest updatePaymentStatusRequest = new UpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setDescription("desc");
		updatePaymentStatusRequest.setOrderId("OrderId");
		updatePaymentStatusRequest.setPaymentBank("IDBI");
		updatePaymentStatusRequest.setPaymentId("Id");
		updatePaymentStatusRequest.setPaymentMethod("UPI");
		return updatePaymentStatusRequest;

	}

	public static List<PaymentTransaction> paymentTransactionsList() throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = format.parse("2018/11/25 12:28:30");
		List<PaymentTransaction> list = new ArrayList<>();
		PaymentTransaction paymentTransaction = new PaymentTransaction();
		paymentTransaction.setPaymentdate(date);
		list.add(paymentTransaction);
		return list;
	}

	public static BrePaymentStatusReqBean popBreRequest() {
		BrePaymentStatusReqBean paymentStatusReqBean = new BrePaymentStatusReqBean();
		paymentStatusReqBean.setPartnername("RAZORPAY");
		paymentStatusReqBean.setInqueryType("POST");
		paymentStatusReqBean.setPaymentMode("UPI");
		paymentStatusReqBean.setTxnMessage("Desc");
		paymentStatusReqBean.setTxnNumber("Payment_Id");
		paymentStatusReqBean.setResponseStatus("1");
		return paymentStatusReqBean;
	}
	
}
