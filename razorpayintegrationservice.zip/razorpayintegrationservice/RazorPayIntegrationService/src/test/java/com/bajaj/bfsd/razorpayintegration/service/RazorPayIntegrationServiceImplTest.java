package com.bajaj.bfsd.razorpayintegration.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.RazorpayTransferRequest;
import com.bajaj.bfsd.razorpayintegration.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.RefundResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.TransferResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.business.processor.RazorPayIntegrationBusinessProcessor;
import com.bajaj.bfsd.razorpayintegration.data.RazorPayTestDataPopulator;

@RunWith(PowerMockRunner.class)
public class RazorPayIntegrationServiceImplTest {
	@InjectMocks
	RazorPayIntegrationServiceImpl razorPayIntegrationServiceImpl;

	@Mock
	private RazorPayIntegrationBusinessProcessor razorPayIntegrationBusinessProcessor;

	@Test
	public void testInitiateBooking() {
		GenerateOrderIdRequestBean generateOrderIdRequestBean = RazorPayTestDataPopulator
				.populateGenerateOrderIdRequestBean();
		//method under test
		razorPayIntegrationServiceImpl.initiateBooking(generateOrderIdRequestBean);
		Mockito.verify(razorPayIntegrationBusinessProcessor).getBookingDetails(generateOrderIdRequestBean);
	}
	@Test
	public void testinItiateUpdate() {
		UpdatePaymentStatusRequest updatePaymentStatusRequest=RazorPayTestDataPopulator.popUpdatePaymentStatusRequest();
		//method under test
		razorPayIntegrationServiceImpl.initiateUpdate("");
		Mockito.verify(razorPayIntegrationBusinessProcessor).updatePaymentStatus("");
	}
	@Test
	public void testUpdatePendingTransStatus() {
		//method under test
		razorPayIntegrationServiceImpl.updatePendingTransStatus();
		Mockito.verify(razorPayIntegrationBusinessProcessor).updatePendingTransStatus();
		
	}
	
	@Test
	public void testselectProcess() {
		HttpHeaders headers = new HttpHeaders();
		String jsonRequest = "test";
		//method under test
		razorPayIntegrationServiceImpl.selectProcess(headers, jsonRequest,"");
		Mockito.verify(razorPayIntegrationBusinessProcessor).selectProcess(headers, jsonRequest,"");
	}
	
	@Test
	public void testDigitalGoldSelectProcess() {
		HttpHeaders headers = new HttpHeaders();
		String jsonRequest = "test";
		Mockito.when(razorPayIntegrationBusinessProcessor.digitalGoldSelectProcess(Mockito.any(),Mockito.anyString())).thenReturn(new ResponseEntity<>(new ResponseBean(), HttpStatus.OK));
		ResponseEntity<ResponseBean> res=razorPayIntegrationServiceImpl.digitalGoldSelectProcess(headers, jsonRequest);
		assertNotNull(res);
	}

	@Test
	public void testInitiateTransferProcess(){
		when(razorPayIntegrationBusinessProcessor.callRazorpayTransferApi(any())).thenReturn(new TransferResponseBean());
		assertNotNull(razorPayIntegrationServiceImpl.initiateTransferProcess(new RazorpayTransferRequest()));
	}
	
	@Test
	public void testInitiateRefundProcess(){
		when(razorPayIntegrationBusinessProcessor.callRazorpayRefundApi(any())).thenReturn(new RefundResponseBean());
		assertNotNull(razorPayIntegrationServiceImpl.initiateRefundProcess(new RefundRequestBean()));
	}
	
	@Test
	public void testUpdatePaymentTransactionForRefund(){
		Mockito.doNothing().when(razorPayIntegrationBusinessProcessor).updatePaymentTransactionForRefund(any(), any());
		razorPayIntegrationServiceImpl.updatePaymentTransactionForRefund("rfnd_C6RBoFsr669tRg", "pay_C63kATSb6UYqEN");
	}
}
