package com.bajaj.bfsd.razorpayintegration.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.razorpayintegration.bean.BreIntServiceRequest;
import com.bajaj.bfsd.razorpayintegration.bean.BrePaymentStatusReqBean;
import com.bajaj.bfsd.razorpayintegration.bean.BuyProcessRequest;
import com.bajaj.bfsd.razorpayintegration.bean.DGUpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.GenerateOrderIdResponseBean;
import com.bajaj.bfsd.razorpayintegration.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.TransferRequestBean;
import com.bajaj.bfsd.razorpayintegration.bean.UpdatePaymentStatusRequest;
import com.bajaj.bfsd.razorpayintegration.constant.RazorPayIntegrationConstants;
import com.bajaj.bfsd.razorpayintegration.data.RazorPayTestDataPopulator;
import com.google.gson.JsonObject;

@RunWith(PowerMockRunner.class)
public class RazorPayIntegrationMapperTest {
	@InjectMocks
	RazorPayIntegrationMapper razorPayIntegrationMapper;
	
	@Mock
	Environment env;
	/**
	 * 
	 */
	@Test
	public void testMapRazorPayRequest() {
		GenerateOrderIdRequestBean generateOrderIdRequestBean = RazorPayTestDataPopulator.populateGenerateOrderIdRequestBean();
		BreIntServiceRequest result=razorPayIntegrationMapper.mapRazorPayRequest(generateOrderIdRequestBean);
		assertEquals(GenerateOrderIdResponseBean.class,result.getClassType());
	}
	/**
	 * 
	 */
	@Test
	public void testMapBreRequest() {
		BrePaymentStatusReqBean res=razorPayIntegrationMapper.mapBreRequest("DESC","PayId");
		assertEquals("NEFT", res.getPaymentMode());
		
	}
	
	@Test
	public void testMapBreRequest2() {
		BrePaymentStatusReqBean res=razorPayIntegrationMapper.mapBreRequest("DESC","");
		assertEquals("NEFT", res.getPaymentMode());
		
	}
	@Test
	public void testmapJsonToUpadatePaymentRequest() {
	   String jsonRequest="{ \"entity\":\"event\", \"account_id\":\"acc_A6556HA0NhfXAs\", \"event\":\"order.paid\", \"contains\":[ \"payment\", \"order\" ], \"payload\":{ \"payment\":{ \"entity\":{ \"id\":\"pay_Bl4fX7gIqmwxvG\", \"entity\":\"payment\", \"amount\":0, \"currency\":\"INR\", \"status\":\"captured\", \"order_id\":\"order_Bl4ek4Hl4Tcm4V\", \"invoice_id\":\"inv_Bl4ek3NX2XqU0A\", \"international\":false, \"method\":\"emandate\", \"amount_refunded\":0, \"refund_status\":null, \"captured\":true, \"description\":\"Invoice #inv_Bl4ek3NX2XqU0A\", \"card_id\":null, \"bank\":\"ICIC\", \"wallet\":null, \"vpa\":null, \"email\":\"babsbsb@gmail.com\", \"contact\":\"+919892338184\", \"customer_id\":\"cust_BkDS5yAXs1DMYw\", \"token_id\":\"token_Bl4fXBNL32NxXO\", \"notes\":[  ], \"fee\":590, \"tax\":90, \"error_code\":null, \"error_description\":null, \"created_at\":1547720782 } }, \"order\":{ \"entity\":{ \"id\":\"order_Bl4ek4Hl4Tcm4V\", \"entity\":\"order\", \"amount\":0, \"amount_paid\":0, \"amount_due\":0, \"currency\":\"INR\", \"receipt\":null, \"offer_id\":null, \"status\":\"paid\", \"attempts\":1, \"notes\":[  ], \"created_at\":1547720737 } } }, \"created_at\":1547720784 }";
		UpdatePaymentStatusRequest updatePaymentStatusRequest=razorPayIntegrationMapper.mapJsonToUpadatePaymentRequest(jsonRequest);
	assertEquals("order_Bl4ek4Hl4Tcm4V", updatePaymentStatusRequest.getOrderId());
	assertEquals("pay_Bl4fX7gIqmwxvG", updatePaymentStatusRequest.getPaymentId());
	}
	
	@Test
	public void testGetbuyProcessRequest() {
		Mockito.when(env.getProperty(Mockito.any())).thenReturn("test");
		BuyProcessRequest buyProcessRequest=razorPayIntegrationMapper.getbuyProcessRequest(new DGUpdatePaymentStatusRequest());
		 assertEquals("SFGLD", buyProcessRequest.getDgProviderCode());
	}
	
	@Test
	public void testMapRazorPayRequestForTransfer(){
		assertNotNull(razorPayIntegrationMapper.mapRazorPayRequestForTransfer(new TransferRequestBean()));
	}
	
	@Test
	public void testMapRazorPayRequestForRefund(){
		assertNotNull(razorPayIntegrationMapper.mapRazorPayRequestForRefund(new RefundRequestBean()));
	}

	@Test
	public void testDgMapJsonToUpadatePaymentRequest() {
		String jsonRequest ="{\"entity\":\"event\",\"account_id\":\"acc_C3fYdnpqFs3HF8\",\"event\":\"order.paid\",\"contains\":[\"payment\",\"order\"],\"payload\":{\"payment\":{\"entity\":{\"id\":\"pay_CEITjrrMeStqDS\",\"entity\":\"payment\",\"amount\":100700,\"currency\":\"INR\",\"status\":\"captured\",\"order_id\":\"order_CEITesk70VduxW\",\"invoice_id\":null,\"international\":false,\"method\":\"netbanking\",\"amount_refunded\":0,\"refund_status\":null,\"captured\":true,\"description\":\"Payment Amount\",\"card_id\":null,\"bank\":\"SBIN\",\"wallet\":null,\"vpa\":null,\"email\":\"llllllllllllllllllll@cccccc.com\",\"contact\":\"+918564645645\",\"notes\":{\"ApplicationId\":\"195749\",\"ApplicantId\":\"45878\",\"SR_Number\":\"SR7284\",\"VendorCode\":\"SFGLD\",\"VendorTxId\":\"1206091\",\"JourneyType\":\"buy\"},\"fee\":2376,\"tax\":362,\"error_code\":null,\"error_description\":null,\"created_at\":1554101278}},\"order\":{\"entity\":{\"id\":\"order_CEITesk70VduxW\",\"entity\":\"order\",\"amount\":100700,\"amount_paid\":100700,\"amount_due\":0,\"currency\":\"INR\",\"receipt\":null,\"offer_id\":null,\"status\":\"paid\",\"attempts\":1,\"notes\":[],\"created_at\":1554101273}}},\"created_at\":1554101280}";

		assertNotNull(razorPayIntegrationMapper.dgMapJsonToUpadatePaymentRequest(jsonRequest));
	}
	
	@Test
	public void testGetRedeemConfirmRequest()
	{
		DGUpdatePaymentStatusRequest updatePaymentStatusRequest = new DGUpdatePaymentStatusRequest();
		updatePaymentStatusRequest.setPaymentId("paymentId");
		updatePaymentStatusRequest.setAmount(123545D);
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("value");
		
		assertNotNull(razorPayIntegrationMapper.getRedeemConfirmRequest(updatePaymentStatusRequest));
	}
}
