package com.bajaj.bfsd.authentication.interceptor;

import java.util.HashMap;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.authentication.util.Constants;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicy;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicyMap;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
public class AuthenticationProcessor {
	private static final String CLASS_NAME = AuthenticationProcessor.class.getName();

	@Autowired
	UserProfileBean upb;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private Environment env;

	@Autowired
	CustomDefaultHeaders customHdrs;

	@Autowired
	BFLAuthorizationPolicyMap authMap;

	private boolean isAuthenticationEnabled;

	@Value("${api.tokenmanagement.validatetoken.GET.url}")
	private String authServiceURL;


	public void performAuthentication(String requestURI, HttpServletRequest request) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "In Token validation filter:performAuthentication");
		try {

			if (Objects.isNull(request)) {
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
						"In Token validation filter:performAuthentication - HTTP Request object NULL!!!");
				throw new BFLTechnicalException(Constants.BFSD_500, Constants.BFSD_500_ERR_MSG);
			}

			customHdrs.setCustomHeaders(request);

			if (HttpMethod.OPTIONS.toString().equalsIgnoreCase(request.getMethod())) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Method type is null.");
				return;
			}

			isUserAuthenticated(requestURI, request.getMethod());

			long userId = customHdrs.getUserKey();

			upb.setUserid(userId);
			upb.setDefaultRole(customHdrs.getDefaultRole());

		} catch (BFLTechnicalException | BFLHttpException bfle) {
			switch (bfle.getCode()) {
			case Constants.BFSD_403:
				throw new BFLHttpException(HttpStatus.FORBIDDEN, Constants.BFSD_403, Constants.BFSD_403_ERR_MSG);
			case Constants.BFSD_401:
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED, Constants.BFSD_401, Constants.BFSD_401_ERR_MSG);
			default:
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
						"In Token validation processor:performAuthentication- Issue during performing authentication, try logging in again.",
						bfle);
				throw new BFLTechnicalException(Constants.BFSD_500, Constants.ERR_STRING);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"In Token validation processor:performAuthentication - " + Constants.ERR_STRING);
			throw new BFLTechnicalException(Constants.ERR_STRING, e);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Exit from Token validation filter:performAuthentication");
	}

	public void isUserAuthenticated(String uri, String method) {
		String authenticationFlag = "";

		boolean isAuthenticationRequired = isAuthenticationRequired(uri, method);

		if (isAuthenticationRequired) {
			authenticationFlag = doAuthenticationCheck();
		}

		if (isAuthenticationRequired
				&& (!StringUtils.isEmpty(authenticationFlag) && Constants.BFSD_401.equals(authenticationFlag))) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"In AuthenticationProcessor:performAuthenticationAuthorizationCheck - User"
							+ customHdrs.getUserKey() + " is not authenticated for requestURI - " + uri);
			throw new BFLHttpException(HttpStatus.UNAUTHORIZED, authenticationFlag,
					"You are not authenticated, try logging in again!!");
		}

	}

	private boolean isAuthenticationRequired(String uri, String method) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "In Authentication processor:isAuthenticationRequired");

		if (!env.getProperty("authentication.flag", boolean.class, isAuthenticationEnabled)
				|| (customHdrs.getUserKey() > 0)) {
			return false;
		}

		uri = env.getProperty(uri);
		BFLAuthorizationPolicy policy = authMap.getPolicy(uri + method);
		if (Objects.nonNull(policy)) {
			return policy.getIsAuthenticationRequired();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Exit from Authentication Processor:isAuthenticationRequired");
		return false;
	}

	private String doAuthenticationCheck() {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "doAuthCheck - entering");

		if (StringUtils.isEmpty(customHdrs.getAuthtoken())) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"doAuthCheck - access authentication failure- Security headers missing from request");
			return Constants.BFSD_401;
		}

		HttpHeaders hdrs = new HttpHeaders();

		ResponseEntity<?> validationResponse = BFLCommonRestClient.invokeRestEndpoint(HttpMethod.GET, authServiceURL,
				null, ResponseBean.class, null, null, hdrs);

		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"doAuthCheck - returning from authentication service call");

		if (null == validationResponse || !HttpStatus.OK.equals(validationResponse.getStatusCode())) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, Constants.EXC_STRING);
			return Constants.BFSD_401;
		}

		ResponseBean resBean = (ResponseBean) validationResponse.getBody();
		if (resBean == null || !StatusCode.SUCCESS.equals(resBean.getStatus())) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, Constants.EXC_STRING);
			return Constants.BFSD_401;
		}

		@SuppressWarnings("unchecked")
		HashMap<String, String> payLoad = (HashMap<String, String>) resBean.getPayload();
		if (null == payLoad) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"doAuthCheck - access authentication failure- Authentication Service technical issue - no payload returned");
			return Constants.BFSD_401;
		}
		String tokenStatus = payLoad.get("tokenStatus");
		if (tokenStatus == null || ("EXPIRED".equals(tokenStatus) || "INVALID".equals(tokenStatus))) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"doAuthCheck - access authentication failure- either token has expired or invalid");
			return Constants.BFSD_401;
		} else {
			String userKeyStr = String.valueOf(payLoad.get("userId"));
			customHdrs.setUserkey(Long.valueOf(userKeyStr));
			customHdrs.setDefaultRole(payLoad.get("defaultRole"));
			customHdrs.setLoginid(payLoad.get("loginId"));
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "doAuthCheck - access authentication successful");
			return "SUCCESS";
		}

	}
}
