package com.bajaj.bfsd.authentication.util;

public class Constants {

	public static final String PAYLOAD = "payload";
	public static final String JSON_KEY_STATUS = "status";
	public static final String EXC_STRING = "doAuthCheck - access authentication failure. Authentication Service technical issue.";
	public static final String ERR_STRING = "Issue during performing authentication, try logging in again.";

	public static final String BFSD_500 = "BFSD-500";
	public static final String BFSD_500_ERR_MSG = "Internal Server Error; HTTP request null.";
	public static final String ROLE_CUSTOMER = "customer";
	public static final String BFSD_403="BFSD-403";
	public static final String BFSD_403_ERR_MSG="You are not authorized to use this service.!!";

	public static final String BFSD_401="BFSD-401";
	public static final String BFSD_401_ERR_MSG="You are not authenticated, try logging in again!!";
	private Constants() {

	}
}
