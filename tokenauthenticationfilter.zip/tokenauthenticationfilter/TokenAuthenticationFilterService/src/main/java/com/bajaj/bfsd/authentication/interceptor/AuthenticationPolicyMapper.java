package com.bajaj.bfsd.authentication.interceptor;

import java.util.Map;
import java.util.Objects;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicy;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicyMap;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.fasterxml.jackson.dataformat.csv.CsvSchema.ColumnType;

@Component
@ConfigurationProperties(prefix = "")
public class AuthenticationPolicyMapper {

	private static final String CLASSNAME = AuthenticationPolicyMapper.class.getName();

	@Autowired
	BFLAuthorizationPolicyMap authMap;

	private Map<String, String> policy;

	@Autowired
	private BFLLoggerUtil logger;

	@Autowired
	CustomDefaultHeaders customHdrs;

	@PostConstruct
	public void init() {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
				"In Token validation filter:Create policy authentication map");
		try {
			CsvMapper mapper = new CsvMapper();
			CsvSchema schema = CsvSchema.builder().addColumn("uri", ColumnType.STRING)
					.addColumn("requestMethod", ColumnType.STRING)
					.addColumn("isAuthenticationRequired", ColumnType.STRING_OR_LITERAL)
					.addColumn("isAuthorizationRequired", ColumnType.STRING_OR_LITERAL)
					.addColumn("roles", ColumnType.STRING_OR_LITERAL).setColumnSeparator(';').build();
			ObjectReader r = mapper.reader(BFLAuthorizationPolicy.class).with(schema);
			StringBuilder builder = new StringBuilder();

			if (Objects.isNull(policy)) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Policy is null or Invalid");
				throw new BFLTechnicalException("BFL-101", "Policy is null or invalid");
			}
			for (Map.Entry<String, String> entry : policy.entrySet()) {
				String propValue = entry.getValue();
				builder.append(propValue);
				builder.append('\n');
			}

			String input = builder.toString();

			MappingIterator<BFLAuthorizationPolicy> it = r.readValues(input);
			while (it.hasNext()) {
				BFLAuthorizationPolicy bflpolicy = it.next();
				String key = bflpolicy.getUri() + bflpolicy.getRequestMethod();
				authMap.putPolicy(key, bflpolicy);
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"AuthenticationPolicyMapper.createAuthMap(): Exception :" + e.getMessage());
			throw new BFLTechnicalException("Issue while reading the policies.", e);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
				"Exit from Token validation filter:Create policy authentication map");
	}

	public Map<String, String> getPolicy() {
		return policy;
	}

	public void setPolicy(Map<String, String> policy) {
		this.policy = policy;
	}

}
