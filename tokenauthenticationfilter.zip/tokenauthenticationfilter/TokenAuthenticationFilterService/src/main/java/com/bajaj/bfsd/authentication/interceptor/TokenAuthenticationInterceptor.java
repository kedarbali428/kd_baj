package com.bajaj.bfsd.authentication.interceptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Component
@Order(1)
public class TokenAuthenticationInterceptor extends WebMvcConfigurerAdapter {

	@Autowired
	TokenAuthenticationHandler tokenAuthenticationHandler;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(tokenAuthenticationHandler);
	}

}
