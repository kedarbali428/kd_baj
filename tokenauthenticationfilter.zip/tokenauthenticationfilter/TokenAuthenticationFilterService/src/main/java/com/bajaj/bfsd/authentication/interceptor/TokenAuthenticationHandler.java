package com.bajaj.bfsd.authentication.interceptor;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.bajaj.bfsd.authentication.util.Constants;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@Component
public class TokenAuthenticationHandler implements HandlerInterceptor {
	private static final String CLASS_NAME = TokenAuthenticationHandler.class.getName();

	@Autowired
	private AuthenticationProcessor authenticationProcessor;

	@Autowired
	BFLLoggerUtilExt logger;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "TokenAuthenticationHandler-preHanadle started");
		if (handler instanceof HandlerMethod) {
			try {
				HandlerMethod method = (HandlerMethod) handler;

				RequestMapping mapping = method.getMethodAnnotation(RequestMapping.class);
				String uriPath = Arrays.toString(mapping.value());
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
						"TokenAuthenticationHandler-preHanadle URI-" + uriPath);
				String uri = uriPath.substring(uriPath.indexOf('{') + 1, uriPath.indexOf('}'));
				authenticationProcessor.performAuthentication(uri, request);
			} catch (Exception e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, Constants.BFSD_401_ERR_MSG);
				response.setStatus(401, Constants.BFSD_401_ERR_MSG);
				return false;
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "TokenAuthenticationHandler-preHandle done");
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub

	}

}
