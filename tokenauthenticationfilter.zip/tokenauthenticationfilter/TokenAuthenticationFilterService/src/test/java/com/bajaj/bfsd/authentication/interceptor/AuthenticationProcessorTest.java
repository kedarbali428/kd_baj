package com.bajaj.bfsd.authentication.interceptor;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicy;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicyMap;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(PowerMockRunner.class)
@PrepareForTest({BFLCommonRestClient.class})
public class AuthenticationProcessorTest {
	
	@InjectMocks
	AuthenticationProcessor authenticationProcessor;
	
	@Mock
	UserProfileBean upb;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	private Environment env;

	@Mock
	CustomDefaultHeaders customHdrs;

	@Mock
	BFLAuthorizationPolicyMap authMap;
	
	@Mock
	HttpServletRequest request;
	
	
	@Before
	public void setUp() {
		authenticationProcessor = new AuthenticationProcessor();
		ReflectionTestUtils.setField(authenticationProcessor, "logger", logger);
		ReflectionTestUtils.setField(authenticationProcessor, "env", env);
		ReflectionTestUtils.setField(authenticationProcessor, "authMap", authMap);
		ReflectionTestUtils.setField(authenticationProcessor, "customHdrs", customHdrs);
		ReflectionTestUtils.setField(authenticationProcessor, "upb", upb);
	}

	
	@Test(expected = BFLTechnicalException.class)
	public void testperformAuthenticationWithNullURI() {
		authenticationProcessor.performAuthentication(null, request);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testperformAuthenticationTestFailure() {
		String uri = "https://www.example.com";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setRequestURI(uri);
		BFLAuthorizationPolicy policy = null;
		Mockito.when(authMap.getPolicy(uri)).thenReturn(policy);
		authenticationProcessor.performAuthentication(uri, request);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testperformAuthenticationWithRequestNull() {
		String uri = "https://www.example.com";
		MockHttpServletRequest request = null;
		BFLAuthorizationPolicy policy = null;
		Mockito.when(authMap.getPolicy(uri)).thenReturn(policy);
		authenticationProcessor.performAuthentication(uri, request);
	}
	
	@Test
	public void testperformAuthenticationWithRequestOption() {
		String uri = "https://www.example.com";
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setMethod("OPTIONS");
		request.setRequestURI(uri);
		authenticationProcessor.performAuthentication(uri, request);
	}
	
	@Test
	public void testperformAuthentication() {
		String uri = "https://www.example.com";	
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setRequestURI(uri);
		request.setMethod("GET");
		Mockito.when(env.getProperty(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(false);
		authenticationProcessor.performAuthentication(uri, request);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testperformAuthenticationWithDoAuthTokenEmpty() {
		String uri = "https://www.example.com";	
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setRequestURI(uri);
		request.setMethod("GET");
		Mockito.when(env.getProperty(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		BFLAuthorizationPolicy policy = new BFLAuthorizationPolicy();
		policy.setIsAuthenticationRequired("Y");
		Mockito.when(authMap.getPolicy(Mockito.any())).thenReturn(policy);
		authenticationProcessor.performAuthentication(uri, request);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testperformAuthenticationWithDoAuth() {
		String uri = "https://www.example.com";	
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setRequestURI(uri);
		request.setMethod("GET");
		Mockito.when(env.getProperty(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		BFLAuthorizationPolicy policy = new BFLAuthorizationPolicy();
		policy.setIsAuthenticationRequired("Y");
		Mockito.when(authMap.getPolicy(Mockito.any())).thenReturn(policy);
		Mockito.when(customHdrs.getAuthtoken()).thenReturn("eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJCYWphakZpblNlcnYiLCJleHAiOjE1ODIxNzg5NzcsImlhdCI6MTU4MjE3NzE3Nywic3ViIjoiYXV0aGVudGljYXRpb24iLCJsb2dpbiI6ImRlZXBzaGlraGEubWlzaHJhQGJhamFqZmluc2Vydi5pbiIsInVzZXJUeXBlIjoyfQ.qe6Fk36YTzmua8wIyz1QOR_oeAk_1JFi69Z9lsZ3NHg");
		HashMap<String,String> payload=new HashMap<String,String>();
		payload.put("tokenStatus", "VALID");
		payload.put("userId", "1234");
		payload.put("defaultRole", "ADMIN");
		payload.put("loginId", "1234");
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(
				(ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity<>(new ResponseBean(payload), HttpStatus.OK));
		authenticationProcessor.performAuthentication(uri, request);
	}
}
