package com.bajaj.bfsd.razorpaypgservice.bean;

import java.io.Serializable;

import javax.persistence.Transient;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class FetchTokenRequestBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Min(value=1,message="EMND-7127")
	private long applicantKey;
	@Min(value=1,message="EMND-7128")
	private long applicationKey;
	@NotNull(message="EMND-7135")
	private String customerId;
	@NotNull(message="EMND-7136")
	private String paymentId;
	@NotNull(message="EMND-7132")
	private String productCode;
	
	public long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(long applicantKey) {
		this.applicantKey = applicantKey;
	}
	public long getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(long applicationKey) {
		this.applicationKey = applicationKey;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	
	
	
	
	
	
}
