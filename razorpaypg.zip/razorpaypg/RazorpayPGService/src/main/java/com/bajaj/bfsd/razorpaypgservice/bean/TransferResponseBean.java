package com.bajaj.bfsd.razorpaypgservice.bean;

import java.util.List;

public class TransferResponseBean {
	
	private String entity;
	private Integer count;
	private List<Item> items;
	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	@Override
	public String toString() {
		return "TransferResponseBean [entity=" + entity + ", count=" + count + ", items=" + items + "]";
	}

}
