package com.bajaj.bfsd.razorpaypgservice.bean;

import java.io.Serializable;
import java.util.Map;

public class RazorPayOrderResponseBean implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 5088121976992709293L;

	private String id;
	private String entity;
	private int amount;
	private String currency;
	private String receipt;
	private String status;
	private int attempts;
	//private Map<String, String> notes;
	private int createdat;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getAttempts() {
		return attempts;
	}

	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}

	/*public Map<String, String> getNotes() {
		return notes;
	}

	public void setNotes(Map<String, String> notes) {
		this.notes = notes;
	}*/

	public int getCreatedat() {
		return createdat;
	}

	public void setCreatedat(int createdat) {
		this.createdat = createdat;
	}

}