package com.bajaj.bfsd.razorpaypgservice.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "EMANDATEREGISTRATION")
@NamedQuery(name = "EmandateRegistration.findAll", query = "SELECT d FROM EmandateRegistration d")
public class EmandateRegistration implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long emandatekey;
	
	@Column(name = "APPAPLTKEY")
	private long appapltkey;

	@Column(name = "TOKEN_ID")
	private String token_id;

	@Column(name = "ORDERID")
	private String orderid;

	@Column(name = "PAYMENTID")
	private String paymentid;

	@Column(name = "TOKEN_STATUS")
	private String token_status;

	@Column(name = "MAX_EMI_AMOUNT")
	private String max_emi_amount;

	@Column(name = "DEBIT_FREQUENCY")
	private String debit_frequency;

	@Column(name = "EMANDATE_MODE")
	private String emandate_mode;

	@Column(name = "EMANDATE_PARTNER")
	private String emandate_partner;

	@Column(name = "UMRN")
	private String umrn;

	@Column(name = "PG_STATUS")
	private String pg_status;

	@Column(name = "TXN_MSG")
	private String txn_msg;

	@Column(name = "TXN_DATE_TIME")
	private Date txn_date_time;

	@Column(name = "RP_CUSTOMER_ID")
	private String rp_customer_id;

	@Column(name = "PRODUCTCODE")
	private String productCode;

	@Column(name = "PRESENTMENT_DATE")
	private Date presentment_date;

	@Column(name = "LAST_SUCCESSFUL_PAYMENT_DATE")
	private Date last_successful_payment_date;

	@Column(name = "ACTIVE", insertable = false)
	private String active;

	@Column(name = "STATUS", insertable = false)
	private String status;
	
	@Column(name = "ISACTIVE")
	private long isactive;
	
	@Column(name = "LSTUPDATEBY")
	private String lstupdateby;
	
	@Column(name = "LSTUPDATEDT")
	private Timestamp lstupdatedt;
	
	

	public long getEmandatekey() {
		return emandatekey;
	}

	public void setEmandatekey(long emandatekey) {
		this.emandatekey = emandatekey;
	}

	public long getAppapltkey() {
		return appapltkey;
	}

	public void setAppapltkey(long appapltkey) {
		this.appapltkey = appapltkey;
	}

	public String getToken_id() {
		return token_id;
	}

	public void setToken_id(String token_id) {
		this.token_id = token_id;
	}

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public String getPaymentid() {
		return paymentid;
	}

	public void setPaymentid(String paymentid) {
		this.paymentid = paymentid;
	}

	public String getToken_status() {
		return token_status;
	}

	public void setToken_status(String token_status) {
		this.token_status = token_status;
	}

	public String getMax_emi_amount() {
		return max_emi_amount;
	}

	public void setMax_emi_amount(String max_emi_amount) {
		this.max_emi_amount = max_emi_amount;
	}

	public String getDebit_frequency() {
		return debit_frequency;
	}

	public void setDebit_frequency(String debit_frequency) {
		this.debit_frequency = debit_frequency;
	}

	public String getEmandate_mode() {
		return emandate_mode;
	}

	public void setEmandate_mode(String emandate_mode) {
		this.emandate_mode = emandate_mode;
	}

	public String getEmandate_partner() {
		return emandate_partner;
	}

	public void setEmandate_partner(String emandate_partner) {
		this.emandate_partner = emandate_partner;
	}

	public String getUmrn() {
		return umrn;
	}

	public void setUmrn(String umrn) {
		this.umrn = umrn;
	}

	public String getPg_status() {
		return pg_status;
	}

	public void setPg_status(String pg_status) {
		this.pg_status = pg_status;
	}

	public String getTxn_msg() {
		return txn_msg;
	}

	public void setTxn_msg(String txn_msg) {
		this.txn_msg = txn_msg;
	}

	public Date getTxn_date_time() {
		return txn_date_time;
	}

	public void setTxn_date_time(Date txn_date_time) {
		this.txn_date_time = txn_date_time;
	}

	public String getRp_customer_id() {
		return rp_customer_id;
	}

	public void setRp_customer_id(String rp_customer_id) {
		this.rp_customer_id = rp_customer_id;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Date getPresentment_date() {
		return presentment_date;
	}

	public void setPresentment_date(Date presentment_date) {
		this.presentment_date = presentment_date;
	}

	public Date getLast_successful_payment_date() {
		return last_successful_payment_date;
	}

	public void setLast_successful_payment_date(Date last_successful_payment_date) {
		this.last_successful_payment_date = last_successful_payment_date;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getIsactive() {
		return isactive;
	}

	public void setIsactive(long isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	
	
	
}
