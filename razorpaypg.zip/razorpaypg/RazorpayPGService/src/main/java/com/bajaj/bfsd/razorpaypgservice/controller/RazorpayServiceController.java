package com.bajaj.bfsd.razorpaypgservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.EmandateOrderResponse;
import com.bajaj.bfsd.razorpaypgservice.bean.EmandateRequestOrderBean;
import com.bajaj.bfsd.razorpaypgservice.bean.FetchTokenRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.InvoiceRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.InvoiceResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateCustomerRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateCustomerResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateOrderIdAndCustomerIdRequest;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateOrderIdAndCustomerIdResponse;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayOrderRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayOrderResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayPaymentStatusRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorpayPaymentStatusResponse;
import com.bajaj.bfsd.razorpaypgservice.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.TokenResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.TransferRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.UpiIntentRequestBean;
import com.bajaj.bfsd.razorpaypgservice.dao.Razorpaydao;
import com.bajaj.bfsd.razorpaypgservice.model.ApplicationApplicant;
import com.bajaj.bfsd.razorpaypgservice.model.EmandateRegistration;
import com.bajaj.bfsd.razorpaypgservice.service.RazorpayService;
import com.bajaj.bfsd.razorpaypgservice.util.EmandateServiceConstant;
import com.bajaj.bfsd.razorpaypgservice.util.RazorpayConstants;
import com.bajaj.bfsd.razorpaypgservice.util.RazorpayServiceUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
@RefreshScope
public class RazorpayServiceController {// extends BFLCamelController {

	@Autowired
	RazorpayService razorpayService;

	@Autowired
	BFLLoggerUtil logger;

	@Autowired
	private Environment env;

	@Autowired
	private Razorpaydao razorpaydao;

	private static final String CLASS_NAME = RazorpayServiceController.class.getCanonicalName();

	@SuppressWarnings("deprecation")
	@CrossOrigin
	public ResponseBean getEmandateOrderId(EmandateRequestOrderBean emandateRequestOrderBean, String cmptcorrid) {
		logger.setCorrelationID(cmptcorrid);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getEmandateOrderId started");
		ResponseBean reponseBean;
		EmandateOrderResponse mandateOrderResponse;
		try {
			mandateOrderResponse = razorpayService.createMandateOrder(emandateRequestOrderBean);
			reponseBean = new ResponseBean(mandateOrderResponse);
			return reponseBean;
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			BFLLoggerUtil.error(RazorpayServiceUtil.getCorelationId(), CLASS_NAME, BFLLoggerComponent.DAO,
					EmandateServiceConstant.EMND_7102, exception);
			throw new BFLTechnicalException(EmandateServiceConstant.EMND_7102,
					env.getProperty(EmandateServiceConstant.EMND_7102));
		}
	}

	@SuppressWarnings("deprecation")
	@CrossOrigin
	public ResponseBean getMandateOrderIdAndCutomerId(MandateOrderIdAndCustomerIdRequest orderIdCustomerIdRequest,
			String cmptcorrid) {
		logger.setCorrelationID(cmptcorrid);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "get mandate OrderIDAndCustomerID started");
		validateInput(orderIdCustomerIdRequest);
		ResponseBean reponseBean;
		MandateOrderIdAndCustomerIdResponse mandateOrderIdResponse = new MandateOrderIdAndCustomerIdResponse();
		EmandateRequestOrderBean mandateRequestOrderBean;
		MandateCustomerRequestBean mandateCustomerRequestBean = null;
		MandateCustomerResponseBean mandateCustomerResponseBean = null;
		try {
			mandateRequestOrderBean = RazorpayServiceUtil.mandateOrderRequestBeanMapper(orderIdCustomerIdRequest);
			EmandateOrderResponse mandateOrderResponse = razorpayService.createMandateOrder(mandateRequestOrderBean);
			mandateCustomerRequestBean = RazorpayServiceUtil.mandateCustomerRequestBeanMapper(orderIdCustomerIdRequest);

			ApplicationApplicant applicationApplcant = razorpaydao.getApplicationApplcant(
					orderIdCustomerIdRequest.getApplicantKey(), orderIdCustomerIdRequest.getApplicationKey());
			EmandateRegistration emandReg = null;
			if (applicationApplcant != null) {
				emandReg = razorpaydao.getEmandateReg(applicationApplcant.getAppapltkey(),
						orderIdCustomerIdRequest.getProductNumber());
			}
			mandateOrderIdResponse.setOrderId(mandateOrderResponse.getId());
			if (emandReg == null) {
				mandateCustomerResponseBean = razorpayService.createMandateCustomer(mandateCustomerRequestBean);
				razorpayService.savecustomeridInRegistration(mandateOrderResponse.getId(),
						mandateCustomerResponseBean.getId(), orderIdCustomerIdRequest.getApplicantKey(),
						orderIdCustomerIdRequest.getApplicationKey(), orderIdCustomerIdRequest.getProductNumber());
				mandateOrderIdResponse.setCustomerId(mandateCustomerResponseBean.getId());
			} else {
				mandateOrderIdResponse.setCustomerId(emandReg.getRp_customer_id());
			}
			return new ResponseBean(mandateOrderIdResponse);
			// return new ResponseEntity<>(reponseBean, HttpStatus.OK);
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			BFLLoggerUtil.error(RazorpayServiceUtil.getCorelationId(), CLASS_NAME, BFLLoggerComponent.DAO,
					EmandateServiceConstant.EMND_7102, exception);
			throw new BFLTechnicalException(EmandateServiceConstant.EMND_7102,
					env.getProperty(EmandateServiceConstant.EMND_7102));
		}
	}

	@SuppressWarnings("deprecation")
	@CrossOrigin
	public ResponseBean getMandateToken(FetchTokenRequestBean orderIdCustomerIdRequest, String cmptcorrid) {
		logger.setCorrelationID(cmptcorrid);
		validationfetchtoken(orderIdCustomerIdRequest);
		try {
			TokenResponseBean tokenResponseBean = razorpayService.getRazorPayToken(
					orderIdCustomerIdRequest.getPaymentId(), orderIdCustomerIdRequest.getProductCode());
			if ("VASEC".equalsIgnoreCase(orderIdCustomerIdRequest.getProductCode())) {
				razorpayService.updateTokenInEmandateReg(orderIdCustomerIdRequest, tokenResponseBean);
			}
			return new ResponseBean(tokenResponseBean);
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			BFLLoggerUtil.error(RazorpayServiceUtil.getCorelationId(), CLASS_NAME, BFLLoggerComponent.DAO,
					EmandateServiceConstant.EMND_7103, exception);
			throw new BFLTechnicalException(EmandateServiceConstant.EMND_7103,
					env.getProperty(EmandateServiceConstant.EMND_7103));
		}
	}

	@SuppressWarnings("deprecation")
	@CrossOrigin
	public ResponseBean getEmandateCustomer(MandateCustomerRequestBean mandatecutomerRequestBean, String cmptcorrid) {
		logger.setCorrelationID(cmptcorrid);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getEmandateCustomer started");
		ResponseBean reponseBean;
		MandateCustomerResponseBean mandatecustomerResponse;
		try {
			mandatecustomerResponse = razorpayService.createMandateCustomer(mandatecutomerRequestBean);
			reponseBean = new ResponseBean(mandatecustomerResponse);
			return reponseBean;
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			BFLLoggerUtil.error(RazorpayServiceUtil.getCorelationId(), CLASS_NAME, BFLLoggerComponent.DAO,
					EmandateServiceConstant.EMND_7102, exception);
			throw new BFLTechnicalException(EmandateServiceConstant.EMND_7102,
					env.getProperty(EmandateServiceConstant.EMND_7102));
		}
	}

	@SuppressWarnings("deprecation")
	@CrossOrigin
	public ResponseBean getRazorPayOrderId(RazorPayOrderRequestBean razorPayOrderRequestBean,
			String cmptcorrid) {
		validateRazorpayRequest(razorPayOrderRequestBean);
		logger.setCorrelationID(cmptcorrid);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getRazorPayOrderId started");
		ResponseBean reponseBean;
		RazorPayOrderResponseBean razorpayResponse;
		try {
			razorpayResponse = razorpayService.createRazorPayOrder(razorPayOrderRequestBean);
			return new ResponseBean(razorpayResponse);
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			BFLLoggerUtil.error(RazorpayServiceUtil.getCorelationId(), CLASS_NAME, BFLLoggerComponent.DAO,
					EmandateServiceConstant.EMND_7102, exception);
			throw new BFLTechnicalException(EmandateServiceConstant.EMND_7102,
					env.getProperty(EmandateServiceConstant.EMND_7102));
		}
	}
	
	@SuppressWarnings("deprecation")
	@CrossOrigin
	public ResponseBean createInvoice(InvoiceRequestBean invoiceRequest, String cmptcorrid,String authtoken,String guardtoken) {
		validateInvoiceRequest(invoiceRequest);
		logger.setCorrelationID(cmptcorrid);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getInvoice started");
		try {
			InvoiceResponseBean invoiceRes = razorpayService.createInvoice(invoiceRequest,authtoken,guardtoken);
			return new ResponseBean(invoiceRes);
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			BFLLoggerUtil.error(RazorpayServiceUtil.getCorelationId(), CLASS_NAME, BFLLoggerComponent.DAO,
					EmandateServiceConstant.INVCE_0002, exception);
			throw new BFLTechnicalException(EmandateServiceConstant.INVCE_0002,
					env.getProperty(EmandateServiceConstant.INVCE_0002));
		}
	}

	private void validateInvoiceRequest(InvoiceRequestBean invoiceRequest) {
		if (null == invoiceRequest.getContact() || invoiceRequest.getContact().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Contact");
			throw new BFLBusinessException("EMND-7130", env.getProperty("EMND-7130"));
		}
		if (null == invoiceRequest.getCurrency() || invoiceRequest.getCurrency().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Currency");
			throw new BFLBusinessException("EMND-7133", env.getProperty("EMND-7133"));
		}

		if (null == invoiceRequest.getDescription() || invoiceRequest.getDescription().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Descrption");
			throw new BFLBusinessException("INVCE-0001", env.getProperty("INVCE-0001"));
		}

		/*if (null == invoiceRequest.getEmail() || invoiceRequest.getEmail().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Email");
			throw new BFLBusinessException("EMND-7129", env.getProperty("EMND-7129"));
		}*/
		if (null == invoiceRequest.getName() || invoiceRequest.getName().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Name");
			throw new BFLBusinessException("EMND-7131", env.getProperty("EMND-7131"));
		}
		if (null == invoiceRequest.getType() || invoiceRequest.getType().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Type");
			throw new BFLBusinessException("INVCE-0002", env.getProperty("INVCE-0002"));
		}
		
	}

	private void validateInput(MandateOrderIdAndCustomerIdRequest requestMetaData) {
		if (null == requestMetaData.getCurrency() || requestMetaData.getCurrency().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Currency");
			throw new BFLBusinessException("EMND-7133", env.getProperty("EMND-7133"));
		}
		if (null == requestMetaData.getMethod() || requestMetaData.getMethod().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Method");
			throw new BFLBusinessException("EMND-7134", env.getProperty("EMND-7134"));
		}

		if (null == requestMetaData.getName() || requestMetaData.getName().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Name");
			throw new BFLBusinessException("EMND-7131", env.getProperty("EMND-7131"));
		}

		if (null == requestMetaData.getEmail() || requestMetaData.getEmail().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Email");
			throw new BFLBusinessException("EMND-7129", env.getProperty("EMND-7129"));
		}
		if (null == requestMetaData.getContact() || requestMetaData.getContact().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Contact");
			throw new BFLBusinessException("EMND-7130", env.getProperty("EMND-7130"));
		}

	}

	private void validationfetchtoken(FetchTokenRequestBean fetchdata) {

		if (null == fetchdata.getPaymentId() || fetchdata.getPaymentId().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid PaymentId");
			throw new BFLBusinessException("EMND-7136", env.getProperty("EMND-7136"));
		}
		if (null == fetchdata.getCustomerId() || fetchdata.getCustomerId().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid CustomerId");
			throw new BFLBusinessException("EMND-7135", env.getProperty("EMND-7135"));
		}

	}

	public void validateRazorpayRequest(RazorPayOrderRequestBean razorPayOrderRequestBean) {

		if (0 == razorPayOrderRequestBean.getAmount()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Amount");
			throw new BFLBusinessException("EMND-7138", env.getProperty("EMND-7138"));
		}
		if (null == razorPayOrderRequestBean.getCurrency() || razorPayOrderRequestBean.getCurrency().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Currency");
			throw new BFLBusinessException("EMND-7133", env.getProperty("EMND-7133"));
		}
		if (1 != razorPayOrderRequestBean.getPayment_Capture()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid PaymentCapture");
			throw new BFLBusinessException("EMND-7140", env.getProperty("EMND-7140"));
		}
		if (null == razorPayOrderRequestBean.getProductCode() || razorPayOrderRequestBean.getProductCode().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid ProductCode");
			throw new BFLBusinessException("EMND-7132", env.getProperty("EMND-7132"));
		}
	}
	
	@SuppressWarnings("deprecation")
	@CrossOrigin
	public ResponseBean initiateRefundRzrpay( RefundRequestBean refundReqBean , String cmptcorrid) {
		logger.setCorrelationID(cmptcorrid);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "initiateRefund() Started");
		ResponseBean reponseBean;
		try {
			reponseBean = razorpayService.initiateRefundRzrpay(refundReqBean);
			return reponseBean;
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			BFLLoggerUtil.error(RazorpayServiceUtil.getCorelationId(), CLASS_NAME, BFLLoggerComponent.DAO,
					EmandateServiceConstant.RZPRI_1001, exception);
			throw new BFLTechnicalException(EmandateServiceConstant.RZPRI_1001,
					env.getProperty(EmandateServiceConstant.RZPRI_1001));
		}
	}
	
	/**
	 * Endpoint for transferring the Amount from Razor pay to multiple accounts(Safegold & Bajaj) for DigiGold.
	 * @param transferRequestBean
	 * @param cmptcorrid
	 * @return
	 */
	@SuppressWarnings("deprecation")
	@CrossOrigin
	public ResponseBean initiateMultipleTransferRzrpay( TransferRequestBean transferRequestBean , String cmptcorrid) {
		logger.setCorrelationID(cmptcorrid);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "initiateMultipleTransferRzrpay() Started");
		ResponseBean reponseBean;
		try {
			reponseBean = new ResponseBean(razorpayService.initiateRazorPayTransfer(transferRequestBean));
			
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			BFLLoggerUtil.error(RazorpayServiceUtil.getCorelationId(), CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					EmandateServiceConstant.DIGITALGOLD_10552, exception);
			throw new BFLTechnicalException(EmandateServiceConstant.DIGITALGOLD_10552,
					env.getProperty(EmandateServiceConstant.DIGITALGOLD_10552));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "initiateMultipleTransferRzrpay() End");
		return reponseBean;
	}
	@SuppressWarnings("deprecation")
	@CrossOrigin
	public ResponseBean getRazorPayPaymentStatus(RazorPayPaymentStatusRequestBean razorPayPaymentStatusRequestBean, String cmptcorrid) {
		validateRazorpayPaymentStatusRequest(razorPayPaymentStatusRequestBean);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getRazorPayPaymentStatus started");
		logger.setCorrelationID(cmptcorrid);
		ResponseBean reponseBean;
		RazorpayPaymentStatusResponse razorpayPaymentStatusByOrderResponse;
		try {
			razorpayPaymentStatusByOrderResponse = razorpayService.getRazorPayPaymentStatus(razorPayPaymentStatusRequestBean);
			return  new ResponseBean(razorpayPaymentStatusByOrderResponse); 
		} catch (BFLBusinessException | BFLTechnicalException exception) {
			throw exception;
		} catch (Exception exception) {
			BFLLoggerUtil.error(RazorpayServiceUtil.getCorelationId(), CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					RazorpayConstants.RZPRI_1006, exception);
			throw new BFLTechnicalException(RazorpayConstants.RZPRI_1006,
					env.getProperty(RazorpayConstants.RZPRI_1006));
		}
	}
	
	
	public void validateRazorpayPaymentStatusRequest(RazorPayPaymentStatusRequestBean razorPayPaymentStatusRequestBean) {

	    if ( (null == razorPayPaymentStatusRequestBean.getPayReferenaceNumber()) && (null == razorPayPaymentStatusRequestBean.getPayTransactionId())) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorpayConstants.RZPRI_1007);
			throw new BFLBusinessException(RazorpayConstants.RZPRI_1007, env.getProperty(RazorpayConstants.RZPRI_1007));
		}
		if (null == razorPayPaymentStatusRequestBean.getProductCode() || razorPayPaymentStatusRequestBean.getProductCode().isEmpty()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorpayConstants.RZPRI_1007);
			throw new BFLBusinessException(RazorpayConstants.RZPRI_1007, env.getProperty(RazorpayConstants.RZPRI_1007));
		}
	}
	
	/**
	 * Calling razorpay upi intent endpoint for UPI payment.
	 * @param upiIntentRequestBean
	 * @param cmptcorrid
	 * @return
	 */
	@CrossOrigin
	public ResponseBean initiateUpiPayment(UpiIntentRequestBean upiIntentRequestBean , String cmptcorrid) {
		logger.setCorrelationID(cmptcorrid);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "initiateUpiPayment() Started upiIntentRequestBean: " + upiIntentRequestBean);
		validateUpiIntentRequestBean(upiIntentRequestBean);
		ResponseBean reponseBean = new ResponseBean(razorpayService.initiateUpiPayment(upiIntentRequestBean));
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "initiateUpiPayment() End");
		return reponseBean;
	}
	
	public void validateUpiIntentRequestBean(UpiIntentRequestBean upiIntentRequestBean){
		if (null==upiIntentRequestBean.getProductCode() || upiIntentRequestBean.getProductCode().isEmpty()
				|| null==upiIntentRequestBean.getAmount() || null==upiIntentRequestBean.getOrderId()
				|| null==upiIntentRequestBean.getNotes() || null==upiIntentRequestBean.getContact()
				|| null==upiIntentRequestBean.getEmail() || null==upiIntentRequestBean.getIp()
				|| null==upiIntentRequestBean.getReferer() || null==upiIntentRequestBean.getUserAgent()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, RazorpayConstants.RZPRI_1011 + env.getProperty(RazorpayConstants.RZPRI_1011));
			throw new BFLBusinessException(RazorpayConstants.RZPRI_1011, env.getProperty(RazorpayConstants.RZPRI_1011));
		}
	}
	
}