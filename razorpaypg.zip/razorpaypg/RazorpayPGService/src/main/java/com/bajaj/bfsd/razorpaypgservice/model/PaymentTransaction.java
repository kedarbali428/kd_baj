package com.bajaj.bfsd.razorpaypgservice.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.sql.Timestamp;


/**
 * The persistent class for the PAYMENT_TRANSACTIONS database table.
 * 
 */
@Entity
@Table(name="PAYMENT_TRANSACTIONS")
@NamedQuery(name="PaymentTransaction.findAll", query="SELECT p FROM PaymentTransaction p")
@NamedQueries(value={
@NamedQuery(name="PaymentTransaction.findByTransrefnum",query="SELECT p FROM PaymentTransaction p where p.transresprefnum =:transrefnum")
})
public class PaymentTransaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long transactionkey;

	private BigDecimal amount;

	private String createby;

	private Timestamp createdt;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal payeventtype;

	@Temporal(TemporalType.DATE)
	private Date paymentdate;

	private String transrefnum;

	private String transrespcode;

	private String transresprefnum;

	private BigDecimal transstatus;
	
	private String transrespmsg;

	//bi-directional many-to-one association to PayGatewayPartner
	@ManyToOne(cascade = {CascadeType.ALL})
	@JoinColumn(name="PAYGATEWAYPARTNERKEY")
	private PayGatewayPartner payGatewayPartner;
	
	/*@OneToMany(mappedBy="paymentTransaction")
	private List<VasApplication> vasApplication;
*/
	public PaymentTransaction() {
	}

	public long getTransactionkey() {
		return this.transactionkey;
	}

	public void setTransactionkey(long transactionkey) {
		this.transactionkey = transactionkey;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCreateby() {
		return this.createby;
	}

	public void setCreateby(String createby) {
		this.createby = createby;
	}

	public Timestamp getCreatedt() {
		return this.createdt;
	}

	public void setCreatedt(Timestamp createdt) {
		this.createdt = createdt;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getPayeventtype() {
		return this.payeventtype;
	}

	public void setPayeventtype(BigDecimal payeventtype) {
		this.payeventtype = payeventtype;
	}

	public Date getPaymentdate() {
		return this.paymentdate;
	}

	public void setPaymentdate(Date paymentdate) {
		this.paymentdate = paymentdate;
	}

	public String getTransrefnum() {
		return this.transrefnum;
	}

	public void setTransrefnum(String transrefnum) {
		this.transrefnum = transrefnum;
	}

	public String getTransrespcode() {
		return this.transrespcode;
	}

	public void setTransrespcode(String transrespcode) {
		this.transrespcode = transrespcode;
	}

	public String getTransresprefnum() {
		return this.transresprefnum;
	}

	public void setTransresprefnum(String transresprefnum) {
		this.transresprefnum = transresprefnum;
	}

	public BigDecimal getTransstatus() {
		return this.transstatus;
	}

	public void setTransstatus(BigDecimal transstatus) {
		this.transstatus = transstatus;
	}

	public PayGatewayPartner getPayGatewayPartner() {
		return this.payGatewayPartner;
	}

	public void setPayGatewayPartner(PayGatewayPartner payGatewayPartner) {
		this.payGatewayPartner = payGatewayPartner;
	}

	public String getTransrespmsg() {
		return transrespmsg;
	}

/*	public List<VasApplication> getVasApplication() {
		return vasApplication;
	}

	public void setVasApplication(List<VasApplication> vasApplication) {
		this.vasApplication = vasApplication;
	}*/

	public void setTransrespmsg(String transrespmsg) {
		this.transrespmsg = transrespmsg;
	}
	
	/*public VasApplication addVasApplication(VasApplication vasApplication) {
		getVasApplication().add(vasApplication);
		vasApplication.setPaymentTransaction(this);

		return vasApplication;
	}

	public VasApplication removeVasApplication(VasApplication vasApplication) {
		getVasApplication().remove(vasApplication);
		vasApplication.setPaymentTransaction(null);

		return vasApplication;
	}*/
}