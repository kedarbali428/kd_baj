package com.bajaj.bfsd.razorpaypgservice.dao;

import java.sql.SQLException;

import com.bajaj.bfsd.razorpaypgservice.bean.FetchTokenRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.TokenResponseBean;
import com.bajaj.bfsd.razorpaypgservice.model.ApplicationApplicant;
import com.bajaj.bfsd.razorpaypgservice.model.EmandateRegistration;
import com.bajaj.bfsd.razorpaypgservice.model.PayGatewayPartner;

public interface Razorpaydao {

	public PayGatewayPartner getPaypartnerCredentials(String productcode) throws SQLException;

	public ApplicationApplicant getApplicationApplcant(long applicantkey, long applicationkey);

	public void saveCustomerRegistration(String orderid, String customerid, long applicantkey, long applicationkey,
			String productcode);

	public EmandateRegistration getEmandateReg(long appapltkey, String productCode);

	public void updateTokenInEmandateReg(FetchTokenRequestBean fetchTokenReq,TokenResponseBean tokenResponseBean);
}
