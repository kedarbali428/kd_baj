package com.bajaj.bfsd.razorpaypgservice.bean;

public class PaymentRequest {

	private  String partnername;
    private String txnNumber;
    private String responseStatus;
    private String inqueryType;
    private String paymentMode;
    private String txnMessage;

	public String getTxnMessage() {
		return txnMessage;
	}

	public void setTxnMessage(String txnMessage) {
		this.txnMessage = txnMessage;
	}

	public String getInqueryType() {
		return inqueryType;
	}

	public void setInqueryType(String inqueryType) {
		this.inqueryType = inqueryType;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getTxnNumber() {
		return txnNumber;
	}

	public void setTxnNumber(String txnNumber) {
		this.txnNumber = txnNumber;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getPartnername() {
		return partnername;
	}

	public void setPartnername(String partnername) {
		this.partnername = partnername;
	}
	
}
