package com.bajaj.bfsd.razorpaypgservice.model;

import java.util.Map;

public class TokenItemsBean {
	private String id;
	private String entity;
	private String token;
	private String bank;
	private String wallet;
	private String method;
	private String recurring;
	private Map<String, String> recurring_details;
     private int created_at;
     private int used_at;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getWallet() {
		return wallet;
	}
	public void setWallet(String wallet) {
		this.wallet = wallet;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getRecurring() {
		return recurring;
	}
	public void setRecurring(String recurring) {
		this.recurring = recurring;
	}
	public Map<String, String> getRecurring_details() {
		return recurring_details;
	}
	public void setRecurring_details(Map<String, String> recurring_details) {
		this.recurring_details = recurring_details;
	}
	public int getCreated_at() {
		return created_at;
	}
	public void setCreated_at(int created_at) {
		this.created_at = created_at;
	}
	public int getUsed_at() {
		return used_at;
	}
	public void setUsed_at(int used_at) {
		this.used_at = used_at;
	}

}
