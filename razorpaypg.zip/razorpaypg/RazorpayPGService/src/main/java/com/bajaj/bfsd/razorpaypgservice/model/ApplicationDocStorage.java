package com.bajaj.bfsd.razorpaypgservice.model;


import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the APPLICATION_DOC_STORAGE database table.
 * 
 */
@Entity
@Table(name="APPLICATION_DOC_STORAGE")
@NamedQuery(name="ApplicationDocStorage.findAll", query="SELECT ads FROM ApplicationDocStorage ads")
public class ApplicationDocStorage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false, precision=20)
	private long appdocstorekey;

	@Column(length=20)
	private String adscontenttype;

	@Column(precision=10)
	private BigDecimal adsdocsize;

	@Column(nullable=false, length=50)
	private String adsdocstorerefnum;

	@Column(nullable=false, precision=1)
	private BigDecimal adsesigneddocflg;

	@Column(precision=1)
	private BigDecimal adsisactive;

	@Column(length=20)
	private String adslstupdateby;
	
	@Column(length=100)
	private String adsdocfilename;

	private Timestamp adslstupdatedt;

	private Timestamp adsocrdate;

	@Column(nullable=false, precision=2)
	private BigDecimal adsocrstatus;

	@Column(nullable=false)
	private Timestamp adsstoredt;

	@Column(nullable=false, length=400)
	private String adsstorelink;

	//bi-directional many-to-one association to ApplicationDocument
	@ManyToOne
	@JoinColumn(name="APPDOCKEY", nullable=false)
	private ApplicationDocument applicationDocument;

	public ApplicationDocStorage() {
		//Needed by JPA
	}

	public long getAppdocstorekey() {
		return this.appdocstorekey;
	}

	public void setAppdocstorekey(long appdocstorekey) {
		this.appdocstorekey = appdocstorekey;
	}

	public String getAdscontenttype() {
		return this.adscontenttype;
	}

	public void setAdscontenttype(String adscontenttype) {
		this.adscontenttype = adscontenttype;
	}

	public BigDecimal getAdsdocsize() {
		return this.adsdocsize;
	}

	public void setAdsdocsize(BigDecimal adsdocsize) {
		this.adsdocsize = adsdocsize;
	}

	public String getAdsdocstorerefnum() {
		return this.adsdocstorerefnum;
	}

	public void setAdsdocstorerefnum(String adsdocstorerefnum) {
		this.adsdocstorerefnum = adsdocstorerefnum;
	}

	public BigDecimal getAdsesigneddocflg() {
		return this.adsesigneddocflg;
	}

	public void setAdsesigneddocflg(BigDecimal adsesigneddocflg) {
		this.adsesigneddocflg = adsesigneddocflg;
	}

	public BigDecimal getAdsisactive() {
		return this.adsisactive;
	}

	public void setAdsisactive(BigDecimal adsisactive) {
		this.adsisactive = adsisactive;
	}

	public String getAdslstupdateby() {
		return this.adslstupdateby;
	}

	public void setAdslstupdateby(String adslstupdateby) {
		this.adslstupdateby = adslstupdateby;
	}

	public Timestamp getAdslstupdatedt() {
		return this.adslstupdatedt;
	}

	public void setAdslstupdatedt(Timestamp adslstupdatedt) {
		this.adslstupdatedt = adslstupdatedt;
	}

	public Timestamp getAdsocrdate() {
		return this.adsocrdate;
	}

	public void setAdsocrdate(Timestamp adsocrdate) {
		this.adsocrdate = adsocrdate;
	}

	public BigDecimal getAdsocrstatus() {
		return this.adsocrstatus;
	}

	public void setAdsocrstatus(BigDecimal adsocrstatus) {
		this.adsocrstatus = adsocrstatus;
	}

	public Timestamp getAdsstoredt() {
		return this.adsstoredt;
	}

	public void setAdsstoredt(Timestamp adsstoredt) {
		this.adsstoredt = adsstoredt;
	}

	public String getAdsstorelink() {
		return this.adsstorelink;
	}

	public void setAdsstorelink(String adsstorelink) {
		this.adsstorelink = adsstorelink;
	}

	public ApplicationDocument getApplicationDocument() {
		return this.applicationDocument;
	}

	public void setApplicationDocument(ApplicationDocument applicationDocument) {
		this.applicationDocument = applicationDocument;
	}


	public String getAdsdocfilename() {
		return this.adsdocfilename;
	}

	public void setAdsdocfilename(String adsdocfilename) {
		this.adsdocfilename = adsdocfilename;
	}

	

}