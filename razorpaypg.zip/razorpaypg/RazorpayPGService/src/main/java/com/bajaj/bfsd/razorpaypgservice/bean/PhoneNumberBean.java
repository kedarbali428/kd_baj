package com.bajaj.bfsd.razorpaypgservice.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

public class PhoneNumberBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@NotNull(message = "applicantId can not be null")
	private Long applicantId;
	@NotNull(message = "phnnumber can not be null")
	private String phnnumber;
	public Long getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}
	public String getPhnnumber() {
		return phnnumber;
	}
	public void setPhnnumber(String phnnumber) {
		this.phnnumber = phnnumber;
	}
	
	

}
