package com.bajaj.bfsd.razorpaypgservice.model;


import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DOCUMENT_CATEGORIES database table.
 * 
 */
@Entity
@Table(name="DOCUMENT_CATEGORIES")
@NamedQuery(name="DocumentCategory.findAll", query="SELECT d FROM DocumentCategory d")
public class DocumentCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=10)
	private long doccatkey;

	@Column(nullable=false, length=10)
	private String doccatcode;

	@Column(nullable=false, length=50)
	private String doccatdesc;

	@Column(precision=1)
	private BigDecimal doccatisactive;

	@Column(length=20)
	private String doccatlstupdateby;

	private Timestamp doccatlstupdatedt;

	//bi-directional many-to-one association to ApplicationDocument
	@OneToMany(mappedBy="documentCategory")
	private List<ApplicationDocument> applicationDocuments;

	//bi-directional many-to-one association to DocumentTypeCategory
	@OneToMany(mappedBy="documentCategory")
	private List<DocumentTypeCategory> documentTypeCategories;

	public DocumentCategory() {
		//Needed by JPA
	}

	public long getDoccatkey() {
		return this.doccatkey;
	}

	public void setDoccatkey(long doccatkey) {
		this.doccatkey = doccatkey;
	}

	public String getDoccatcode() {
		return this.doccatcode;
	}

	public void setDoccatcode(String doccatcode) {
		this.doccatcode = doccatcode;
	}

	public String getDoccatdesc() {
		return this.doccatdesc;
	}

	public void setDoccatdesc(String doccatdesc) {
		this.doccatdesc = doccatdesc;
	}

	public BigDecimal getDoccatisactive() {
		return this.doccatisactive;
	}

	public void setDoccatisactive(BigDecimal doccatisactive) {
		this.doccatisactive = doccatisactive;
	}

	public String getDoccatlstupdateby() {
		return this.doccatlstupdateby;
	}

	public void setDoccatlstupdateby(String doccatlstupdateby) {
		this.doccatlstupdateby = doccatlstupdateby;
	}

	public Timestamp getDoccatlstupdatedt() {
		return this.doccatlstupdatedt;
	}

	public void setDoccatlstupdatedt(Timestamp doccatlstupdatedt) {
		this.doccatlstupdatedt = doccatlstupdatedt;
	}

	public List<ApplicationDocument> getApplicationDocuments() {
		return this.applicationDocuments;
	}

	public void setApplicationDocuments(List<ApplicationDocument> applicationDocuments) {
		this.applicationDocuments = applicationDocuments;
	}

	public ApplicationDocument addApplicationDocument(ApplicationDocument applicationDocument) {
		getApplicationDocuments().add(applicationDocument);
		applicationDocument.setDocumentCategory(this);

		return applicationDocument;
	}

	public ApplicationDocument removeApplicationDocument(ApplicationDocument applicationDocument) {
		getApplicationDocuments().remove(applicationDocument);
		applicationDocument.setDocumentCategory(null);

		return applicationDocument;
	}

	public List<DocumentTypeCategory> getDocumentTypeCategories() {
		return this.documentTypeCategories;
	}

	public void setDocumentTypeCategories(List<DocumentTypeCategory> documentTypeCategories) {
		this.documentTypeCategories = documentTypeCategories;
	}

	public DocumentTypeCategory addDocumentTypeCategory(DocumentTypeCategory documentTypeCategory) {
		getDocumentTypeCategories().add(documentTypeCategory);
		documentTypeCategory.setDocumentCategory(this);

		return documentTypeCategory;
	}

	public DocumentTypeCategory removeDocumentTypeCategory(DocumentTypeCategory documentTypeCategory) {
		getDocumentTypeCategories().remove(documentTypeCategory);
		documentTypeCategory.setDocumentCategory(null);

		return documentTypeCategory;
	}

}