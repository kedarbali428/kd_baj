package com.bajaj.bfsd.razorpaypgservice.util;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.DynamoDbBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class DynamoDBHelper {

	@Autowired
	BFLLoggerUtilExt logger;

	@Value("${api.nosql.audit.POST.url}")
	private String dynamoDBUrl;

	private static final String CLASS_NAME = DynamoDBHelper.class.getName();
	private Properties Proeprties = RazorpayUtility
			.readPropertyFile("application.properties");

	// @Async
	public void dynamoDb(DynamoDbBean dynamoDbBean, String authtoken, String guardtoken) {
		ObjectMapper mapper = new ObjectMapper();
		String reqJson;
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Enter Dynamodb for async");
			reqJson = mapper.writeValueAsString(dynamoDbBean);
			callingDynamoDB(reqJson, authtoken, guardtoken);
		} catch (JsonProcessingException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occured while converting json string :" + e);
		}

	}

	public void callingDynamoDB(String jsonReqString, String authtoken, String guardtoken) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Calling Dynamodb started");
		try {
			if (null != Proeprties) {
				HttpHeaders headers = new HttpHeaders();
				headers.add("authtoken", authtoken);
				headers.add("guardtoken", guardtoken);
				headers.add("Content-Type", "application/json");
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Calling Dynamodb request payload"+jsonReqString);
				ResponseEntity<ResponseBean> responseEntity = BFLCommonRestClient.create(dynamoDBUrl, jsonReqString,
						String.class, null, null, headers);
				ResponseBean responBean = responseEntity.getBody();
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Response of dynamodb" + responBean.toString());

			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
						"Exception in getting properties from property file");
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Exception in callingDynamoDB: " + e);
		}
	}

}
