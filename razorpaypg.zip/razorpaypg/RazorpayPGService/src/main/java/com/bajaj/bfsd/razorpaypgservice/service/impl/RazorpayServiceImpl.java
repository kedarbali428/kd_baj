package com.bajaj.bfsd.razorpaypgservice.service.impl;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.NoResultException;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.authentication.util.MapperFactory;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.razorpaypgservice.bean.DynamoDbBean;
import com.bajaj.bfsd.razorpaypgservice.bean.EmandateOrderResponse;
import com.bajaj.bfsd.razorpaypgservice.bean.EmandateRequestOrderBean;
import com.bajaj.bfsd.razorpaypgservice.bean.FetchTokenRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.InvoiceRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.InvoiceResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateCustomerRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateCustomerResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayOrderRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayOrderResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayPaymentStatusRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorpayPaymentStatusByPaymntIdResponse;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorpayPaymentStatusResponse;
import com.bajaj.bfsd.razorpaypgservice.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RefundResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.TokenResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.TransferRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.TransferResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.UpiIntentRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.UpiIntentResponseBean;
import com.bajaj.bfsd.razorpaypgservice.dao.Razorpaydao;
import com.bajaj.bfsd.razorpaypgservice.model.PayGatewayPartner;
import com.bajaj.bfsd.razorpaypgservice.service.RazorpayService;
import com.bajaj.bfsd.razorpaypgservice.util.DynamoDBHelper;
import com.bajaj.bfsd.razorpaypgservice.util.EmandateServiceConstant;
import com.bajaj.bfsd.razorpaypgservice.util.MapperForDynamoDB;
import com.bajaj.bfsd.razorpaypgservice.util.RazorpayConstants;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class RazorpayServiceImpl extends BFLComponent implements RazorpayService {

	private static final String CLASS_NAME = RazorpayServiceImpl.class.getName();

	@Autowired
	private Environment env;

	@Autowired
	private BFLLoggerUtilExt logger;

	@Value("${emandate.getmandatecustomer.url}")
	private String rzrPaycustomerUrl;
    
	@Value("${razorpay.getOrder.url}")
	private String rzrPayOrderUrl;

	@Value("${emandate.getmandatetoken.url}")
	private String rzrPayTokenUrl;

	@Value("${external.emicdatacapture.nsbfg.url}")
	private String nsbfgUrl;

	@Value("${external.emicdatacapture.nsbfg.auth.key}")
	private String nsbfgAuthKey;

	@Value("${external.emicdatacapture.nsbfg.auth.value}")
	private String nsbfgAuthValue;

	@Value("${proxy.url}")
	private String proxyurl;
	
	@Value("${proxy.port}")
	private int port;
	
	@Value("${api.razorpayinvoice}")
	private String razorpayinvoice;
	
	@Value("${razorpay.paymentid.refund.url}")
	private String refundUrl;
	
	@Value("${razorpay.paymentid.refund.suffix}")
	private String refundUrlSuffix;
	
	@Value("${razorpay.transfer.url}")
	private String rzrPayTransferUrl;
	
	@Autowired
	DynamoDBHelper dynamoDBHelper;

	@Autowired
	MapperForDynamoDB mapperForDynamoDB;
	
	@Value("${razorpay.paymentid.paymentstatus.url}")
	private String rzrPayPaymntStsByPaymntIdUrl;
	
	@Value("${razorpay.orderid.paymentstatus.url}")
	private String rzrPayPaymntStsByOrderIdUrl;
	
	@Value("${razorpay.upi.intent.url}")
	private String rzrPayUpiIntentUrl;
	
	@Autowired
	private Razorpaydao razorpaydao;

	@Autowired
	RestTemplate restTemplate;

	@SuppressWarnings("unchecked")
	@Override
	public EmandateOrderResponse createMandateOrder(EmandateRequestOrderBean mandateRequestOrderBean) {
		EmandateOrderResponse mandateOrderResponse = null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "createMandateOrder started");
		try {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("amount", mandateRequestOrderBean.getAmount());
			jsonObject.put("currency", mandateRequestOrderBean.getCurrency());
			jsonObject.put("receipt", mandateRequestOrderBean.getReceipt());
			jsonObject.put("method", mandateRequestOrderBean.getMethod());
			jsonObject.put("payment_capture", mandateRequestOrderBean.getPayment_Capture());
			SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyurl, port));
			requestFactory.setProxy(proxy);
			requestFactory.setConnectTimeout(15000);
			RestTemplate restTemplate = new RestTemplate(requestFactory);
			HttpEntity<String> httpEntity = getHttpEntity(jsonObject, mandateRequestOrderBean.getProductCode());
			ResponseEntity<EmandateOrderResponse> responseEntity = restTemplate.exchange(rzrPayOrderUrl,
					HttpMethod.POST, httpEntity, EmandateOrderResponse.class);
			if (responseEntity != null) {
				mandateOrderResponse = responseEntity.getBody();
				logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "createMandateOrder ended");
			} else {
				throw new BFLBusinessException(EmandateServiceConstant.EMND_7123,
						env.getProperty(EmandateServiceConstant.EMND_7123));
			}
		} catch (ResourceAccessException ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7123 + ex);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7124,
					env.getProperty(EmandateServiceConstant.EMND_7124));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7123 + e);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7123,
					env.getProperty(EmandateServiceConstant.EMND_7123));
		}
		return mandateOrderResponse;
	}

	public HttpEntity<String> getHttpEntity(JSONObject jsonObject, String productcode) throws SQLException {
		HttpHeaders headers = new HttpHeaders();
		if (productcode == null || productcode.isEmpty()) {
			ResponseBean responseBean = new ResponseBean();
			responseBean.setStatus(StatusCode.FAILURE);
			return new ResponseEntity<>("FAILURE", HttpStatus.BAD_REQUEST);

		}
		
		String rzrApiKey1 = null;
		String rzrApiSecret1 = null;
		PayGatewayPartner paypartner = razorpaydao.getPaypartnerCredentials(productcode);
		if (paypartner != null) {
			rzrApiKey1 = paypartner.getApikey();
			rzrApiSecret1 = paypartner.getApisecret();
		}
		
		String auth = rzrApiKey1 + ":" + rzrApiSecret1;
		byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
		String authHeader = "Basic " + new String(encodedAuth);
		headers.add("Authorization", authHeader);
		headers.add("Accept-Language", "application/json");
		headers.add("Content-Type", "application/json");
		if (jsonObject != null) {
			return new HttpEntity<>(jsonObject.toString(), headers);
		} else {
			return new HttpEntity<>(headers);
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public MandateCustomerResponseBean createMandateCustomer(MandateCustomerRequestBean mandateCustomerRequestBean) {
		MandateCustomerResponseBean mandateCustomerResponseBean = null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "createMandateCustomer started");
		try {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("name", mandateCustomerRequestBean.getName());
			jsonObject.put("email", mandateCustomerRequestBean.getEmail());
			jsonObject.put("contact", mandateCustomerRequestBean.getContact());
			jsonObject.put("fail_existing","0");
			SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyurl, port));
			requestFactory.setProxy(proxy);
			requestFactory.setConnectTimeout(15000);
			RestTemplate restTemplate = new RestTemplate(requestFactory);
			HttpEntity<String> httpEntity = getHttpEntity(jsonObject, mandateCustomerRequestBean.getProductCode());
			ResponseEntity<MandateCustomerResponseBean> responseEntity = restTemplate.exchange(rzrPaycustomerUrl,
					HttpMethod.POST, httpEntity, MandateCustomerResponseBean.class);

			if (responseEntity != null) {
				mandateCustomerResponseBean = responseEntity.getBody();
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "createMandateCustomer ended");
			} else {
				throw new BFLBusinessException(EmandateServiceConstant.EMND_7123,
						env.getProperty(EmandateServiceConstant.EMND_7123));
			}
		} catch (ResourceAccessException ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7123 + ex);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7124,
					env.getProperty(EmandateServiceConstant.EMND_7124));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7123 + e);

			throw new BFLBusinessException("EMND-7123", env.getProperty("EMND-7123"));
		}

		return mandateCustomerResponseBean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public TokenResponseBean getRazorPayToken(String paymentId, String productCode) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getRazorPayToken started");
		try {
			Map<String, String> params = new HashMap<>();
			params.put("paymentId", paymentId);
			SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyurl, port));
			requestFactory.setProxy(proxy);
			requestFactory.setConnectTimeout(15000);
			RestTemplate restTemplate = new RestTemplate(requestFactory);
			HttpEntity<String> httpEntity = getHttpEntity(null, productCode);
			ResponseEntity<TokenResponseBean> responseEntity = restTemplate.exchange(rzrPayTokenUrl, HttpMethod.GET,
					httpEntity, TokenResponseBean.class, params);
			if (responseEntity != null) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getRazorPayToken ended");
				return responseEntity.getBody();
			} else {
				throw new BFLBusinessException(EmandateServiceConstant.EMND_7123,
						env.getProperty(EmandateServiceConstant.EMND_7123));
			}
		} catch (ResourceAccessException ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7123 + ex);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7124,
					env.getProperty(EmandateServiceConstant.EMND_7124));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7123 + e);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7123,
					env.getProperty(EmandateServiceConstant.EMND_7123));
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public RazorPayOrderResponseBean createRazorPayOrder(RazorPayOrderRequestBean razorPayOrderRequestBean) {
		RazorPayOrderResponseBean razorPayOrderResponseBean = new RazorPayOrderResponseBean();
		try {

			JSONObject jsonObject = new JSONObject();
			jsonObject.put("amount", razorPayOrderRequestBean.getAmount());
			jsonObject.put("payment_capture", razorPayOrderRequestBean.getPayment_Capture());
			jsonObject.put("currency", razorPayOrderRequestBean.getCurrency());
			jsonObject.put("receipt", razorPayOrderRequestBean.getReceipt());

			ResponseEntity<RazorPayOrderResponseBean> responseEntity = (ResponseEntity<RazorPayOrderResponseBean>) callRazorPayService(
					jsonObject, rzrPayOrderUrl, razorPayOrderRequestBean.getProductCode());

			if (responseEntity != null) {
				razorPayOrderResponseBean = responseEntity.getBody();
			} else {
				throw new BFLBusinessException(EmandateServiceConstant.EMND_7123,
						env.getProperty(EmandateServiceConstant.EMND_7123));
			}

		} catch (ResourceAccessException ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7124 + ex);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7124,
					env.getProperty(EmandateServiceConstant.EMND_7124));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7123 + e);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7123,
					env.getProperty(EmandateServiceConstant.EMND_7123));
		}
		return razorPayOrderResponseBean;
	}

	private ResponseEntity<?> callRazorPayService(JSONObject jsonObject, String url, String productcode)
			throws SQLException {
		HttpHeaders headers = new HttpHeaders();
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();

		Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyurl, port));

		requestFactory.setProxy(proxy);
		requestFactory.setConnectTimeout(15000);
		RestTemplate restTemplate = new RestTemplate(requestFactory);

		if (productcode == null || productcode.isEmpty()) {
			ResponseBean responseBean = new ResponseBean();
			responseBean.setStatus(StatusCode.FAILURE);
			return new ResponseEntity<>(responseBean, HttpStatus.BAD_REQUEST);

		}
		String rzrApiKey = null;
		String rzrApiSecret = null;
		PayGatewayPartner paypartner = razorpaydao.getPaypartnerCredentials(productcode);
		if (paypartner != null) {
			rzrApiKey = paypartner.getApikey();
			rzrApiSecret = paypartner.getApisecret();
		}

		String auth = rzrApiKey + ":" + rzrApiSecret;
		byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
		String authHeader = "Basic " + new String(encodedAuth);
		headers.add("Authorization", authHeader);
		headers.add("Accept-Language", "application/json");
		headers.add("Content-Type", "application/json");

		HttpEntity<String> httpEntity = new HttpEntity<>(jsonObject.toString(), headers);

		return restTemplate.exchange(url, HttpMethod.POST, httpEntity, RazorPayOrderResponseBean.class);
	}

	@Override
	public void savecustomeridInRegistration(String orderid, String customerid, long applicantkey, long applicationkey,
			String productcode) {
		razorpaydao.saveCustomerRegistration(orderid, customerid, applicantkey, applicationkey, productcode);
	}

	@Override
	public void updateTokenInEmandateReg(FetchTokenRequestBean fetchTokenReq, TokenResponseBean tokenResponseBean) {
		razorpaydao.updateTokenInEmandateReg(fetchTokenReq, tokenResponseBean);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public InvoiceResponseBean createInvoice(InvoiceRequestBean invoiceRequest,String authtoken,String guardtoken) {
		
		InvoiceResponseBean invoiceRes = null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "createInvoice started");
		try {
			JSONObject jsonObject = new JSONObject();
			JSONObject jsonNotes = new JSONObject();
			jsonNotes.put("applicationKey", invoiceRequest.getApplicationId());
			jsonNotes.put("email", invoiceRequest.getEmpemail());
			jsonNotes.put("role", invoiceRequest.getRole());
			JSONObject jsonObjectcust = new JSONObject();
			jsonObjectcust.put("name", invoiceRequest.getName());
			jsonObjectcust.put("email", invoiceRequest.getEmail());
			jsonObjectcust.put("contact", invoiceRequest.getContact());
			jsonObject.put("customer", jsonObjectcust);
			jsonObject.put("type", invoiceRequest.getType());
			jsonObject.put("view_less", invoiceRequest.getViewless());
			jsonObject.put("amount", invoiceRequest.getAmount());
			jsonObject.put("currency", invoiceRequest.getCurrency());
			jsonObject.put("description", invoiceRequest.getDescription());
			jsonObject.put("expire_by", invoiceRequest.getExpireby());
			jsonObject.put("sms_notify", invoiceRequest.getSmsNotify());
			jsonObject.put("email_notify", invoiceRequest.getEmailNotify());
			jsonObject.put("notes", jsonNotes);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "createInvoice request payload::"+jsonObject);
			SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyurl, port));
			requestFactory.setProxy(proxy);
			requestFactory.setConnectTimeout(15000);
			RestTemplate restTemplate = new RestTemplate(requestFactory);
			HttpEntity<String> httpEntity = getHttpEntity(jsonObject, invoiceRequest.getProductcode());
			ResponseEntity<InvoiceResponseBean> responseEntity = restTemplate.exchange(razorpayinvoice,
					HttpMethod.POST, httpEntity, InvoiceResponseBean.class);

			if (responseEntity != null) {
				invoiceRes = responseEntity.getBody();
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "createInvoice ended");
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.INVCE_0002 + e);
			throw new BFLBusinessException("INVCE-0002", env.getProperty("INVCE-0002"));
		}

		DynamoDbBean dynamoDbBean = mapperForDynamoDB.mapperForInvoiceSelection(invoiceRequest,invoiceRes);
		dynamoDBHelper.dynamoDb(dynamoDbBean, authtoken, guardtoken);
		return invoiceRes;
		
		
	}
	
	@Override
	public ResponseBean initiateRefundRzrpay(RefundRequestBean refundReqBean) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "initiateRefundRzrpay started for payment Id ="
																			+refundReqBean.getPaymentId());
		ResponseBean respBean = new ResponseBean();
		try {
			Map<String, String> params = new HashMap<>();
			params.put("amount", null!=refundReqBean.getAmount()?refundReqBean.getAmount().toString():null);
			SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyurl, port));
			requestFactory.setProxy(proxy);
			requestFactory.setConnectTimeout(15000);
			RestTemplate restTemplate = new RestTemplate(requestFactory);
			HttpEntity<String> httpEntity = getHttpEntity(null, refundReqBean.getProductCode());
			String refundPaymentUrl =refundUrl+refundReqBean.getPaymentId()+refundUrlSuffix;
			ResponseEntity<RefundResponseBean> responseEntity = restTemplate.exchange(refundPaymentUrl, HttpMethod.POST,
					httpEntity, RefundResponseBean.class, params);
			org.springframework.http.HttpStatus httpstat =responseEntity.getStatusCode();
			int statusCode=httpstat.value();
			if(statusCode==200) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "initiateRefundRzrpay ended with success response");
				respBean.setPayload(responseEntity.getBody());
				respBean.setStatus(StatusCode.SUCCESS);
			}
		} catch (ResourceAccessException ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7124 + ex);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7124,
					env.getProperty(EmandateServiceConstant.EMND_7124));
		}catch (HttpClientErrorException e) {
			org.json.JSONObject jsonRes = new org.json.JSONObject(e.getResponseBodyAsString());
			org.json.JSONObject errorJson =(org.json.JSONObject)jsonRes.get("error");
			String errCode =errorJson.getString("code");
			String errorDesc = errorJson.getString("description");
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, errorDesc);
			ErrorBean err = new ErrorBean(errCode,errorDesc);
			List<ErrorBean> errList = new ArrayList<>();
			errList.add(err);
			respBean.setErrorBean(errList);
			respBean.setStatus(StatusCode.FAILURE);
		}catch (NoResultException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, EmandateServiceConstant.RZPRI_1003, e);
			ErrorBean err = new ErrorBean(EmandateServiceConstant.RZPRI_1003,env.getProperty(EmandateServiceConstant.RZPRI_1003));
			List<ErrorBean> errList = new ArrayList<>();
			errList.add(err);
			respBean.setErrorBean(errList);
			respBean.setStatus(StatusCode.FAILURE);
		}
		catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.RZPRI_1001 + e);
			throw new BFLBusinessException(EmandateServiceConstant.RZPRI_1001,
					env.getProperty(EmandateServiceConstant.RZPRI_1001));
		}
		return respBean;
	}

	/**
	 * Initiate transfer from razor pay to multiple accounts(Bajaj, SafeGold) for DigitalGold application.
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public TransferResponseBean initiateRazorPayTransfer(TransferRequestBean transferRequestBean) {
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "initiateRazorPayTransfer()-start transfer request object: "+transferRequestBean);
		TransferResponseBean transferResponseBean = null;
		try {
			JSONObject jsonFirstObject = new JSONObject();
			jsonFirstObject.put("account", transferRequestBean.getTransfers().get(0).getAccount());
			jsonFirstObject.put("amount", transferRequestBean.getTransfers().get(0).getAmount());
			jsonFirstObject.put("currency", transferRequestBean.getTransfers().get(0).getCurrency());
			jsonFirstObject.put("notes", transferRequestBean.getTransfers().get(0).getNotes());
			
			JSONObject jsonSecondObject = new JSONObject();
			jsonSecondObject.put("account", transferRequestBean.getTransfers().get(1).getAccount());
			jsonSecondObject.put("amount", transferRequestBean.getTransfers().get(1).getAmount());
			jsonSecondObject.put("currency", transferRequestBean.getTransfers().get(1).getCurrency());
			jsonSecondObject.put("notes", transferRequestBean.getTransfers().get(1).getNotes());

			JSONArray jsonArray = new JSONArray();
			jsonArray.add(jsonFirstObject);
			jsonArray.add(jsonSecondObject);
			
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("transfers", jsonArray);
			ResponseEntity<TransferResponseBean> responseEntity = (ResponseEntity<TransferResponseBean>) callRazorPayServiceForTransfer(
					jsonObject, rzrPayTransferUrl, transferRequestBean.getProductCode(),transferRequestBean.getPaymentId());

			if (responseEntity != null) {
				transferResponseBean = responseEntity.getBody();
			} else {
				throw new BFLBusinessException(EmandateServiceConstant.DIGITALGOLD_10550,
						env.getProperty(EmandateServiceConstant.DIGITALGOLD_10550));
			}

		} catch (ResourceAccessException ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.DIGITALGOLD_10551 + ex);
			throw new BFLBusinessException(EmandateServiceConstant.DIGITALGOLD_10551,
					env.getProperty(EmandateServiceConstant.DIGITALGOLD_10551));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.DIGITALGOLD_10550 + e);
			throw new BFLBusinessException(EmandateServiceConstant.DIGITALGOLD_10550,
					env.getProperty(EmandateServiceConstant.DIGITALGOLD_10550));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "initiateRazorPayTransfer()-end transfer response object: "+transferResponseBean);
		return transferResponseBean;
	}
	
	
	/**
	 * Calling razorpay transfer api for DigitalGold.
	 * @param jsonObject
	 * @param url
	 * @param productcode
	 * @param paymentId
	 * @return
	 * @throws SQLException
	 */
	private ResponseEntity<?> callRazorPayServiceForTransfer(JSONObject jsonObject, String url, String productcode,String paymentId)
			throws SQLException {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "callRazorPayServiceForTransfer()-start json object: "+jsonObject+", productcode:"+productcode+", paymentId:"+paymentId);
		HttpHeaders headers = new HttpHeaders();
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();

		Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyurl, port));

		requestFactory.setProxy(proxy);
		requestFactory.setConnectTimeout(15000);
		RestTemplate restTemplate = new RestTemplate(requestFactory);

		if (productcode == null || productcode.isEmpty()) {
			ResponseBean responseBean = new ResponseBean();
			responseBean.setStatus(StatusCode.FAILURE);
			return new ResponseEntity<>(responseBean, HttpStatus.BAD_REQUEST);

		}
		String rzrApiKey = null;
		String rzrApiSecret = null;
		PayGatewayPartner paypartner = razorpaydao.getPaypartnerCredentials(productcode);
		if (paypartner != null) {
			rzrApiKey = paypartner.getApikey();
			rzrApiSecret = paypartner.getApisecret();
		}

		String auth = rzrApiKey + ":" + rzrApiSecret;
		byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
		String authHeader = "Basic " + new String(encodedAuth);
		headers.add("Authorization", authHeader);
		headers.add("Accept-Language", "application/json");
		headers.add("Content-Type", "application/json");
		
		Map<String, String> params = new HashMap<>();
		params.put("paymentId", paymentId);
		
		HttpEntity<String> httpEntity = new HttpEntity<>(jsonObject.toString(), headers);

		return restTemplate.exchange(url, HttpMethod.POST, httpEntity, TransferResponseBean.class,params);
	}


	@SuppressWarnings("unchecked")
	@Override
	public RazorpayPaymentStatusResponse getRazorPayPaymentStatus(
			RazorPayPaymentStatusRequestBean razorPayPaymentStatusRequestBean) {
		

		RazorpayPaymentStatusByPaymntIdResponse razorpayPaymentStatusByPaymntIdResponse = new RazorpayPaymentStatusByPaymntIdResponse();
		RazorpayPaymentStatusResponse razorpayPaymentStatusResponse = new RazorpayPaymentStatusResponse();
		try {

			ResponseEntity<String> responseEntity = null;
			boolean isPayTransactionId = false;
			if(razorPayPaymentStatusRequestBean.getPayTransactionId() != null && !razorPayPaymentStatusRequestBean.getPayTransactionId().isEmpty()) {
				//Based on Payment Id
				isPayTransactionId = true;
				responseEntity  = (ResponseEntity<String>) callRazorPayServiceForPaymnetStatus(
						 rzrPayPaymntStsByPaymntIdUrl, razorPayPaymentStatusRequestBean, isPayTransactionId);
				 
			}else if(razorPayPaymentStatusRequestBean.getPayReferenaceNumber() != null && !razorPayPaymentStatusRequestBean.getPayReferenaceNumber().isEmpty()) {
				//Based on Order Id
				responseEntity = (ResponseEntity<String>) callRazorPayServiceForPaymnetStatus(
						rzrPayPaymntStsByOrderIdUrl, razorPayPaymentStatusRequestBean, isPayTransactionId);
			}
			if (null != responseEntity  && null != responseEntity.getBody() ) {
				
				if(isPayTransactionId) {
					razorpayPaymentStatusByPaymntIdResponse = (RazorpayPaymentStatusByPaymntIdResponse) getResponseObjectFromResponseJsonString(responseEntity.getBody(),
							 RazorpayPaymentStatusByPaymntIdResponse.class);
					List<RazorpayPaymentStatusByPaymntIdResponse> listRazorpayPaymentStatusResponse = new ArrayList<>();
					listRazorpayPaymentStatusResponse.add(razorpayPaymentStatusByPaymntIdResponse);
					razorpayPaymentStatusResponse.setItems(listRazorpayPaymentStatusResponse);
				}
				else {
					razorpayPaymentStatusResponse = (RazorpayPaymentStatusResponse) getResponseObjectFromResponseJsonString(responseEntity.getBody(),
							RazorpayPaymentStatusResponse.class);
				}
			} else {
				throw new BFLBusinessException(EmandateServiceConstant.EMND_7123,
						env.getProperty(EmandateServiceConstant.EMND_7123));
			}

		} catch (ResourceAccessException ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7124 + ex);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7124,
					env.getProperty(EmandateServiceConstant.EMND_7124));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, EmandateServiceConstant.EMND_7123 + e);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7123,
					env.getProperty(EmandateServiceConstant.EMND_7123));
		}
		return razorpayPaymentStatusResponse;
	}
	
	
	private ResponseEntity<?> callRazorPayServiceForPaymnetStatus( String url, RazorPayPaymentStatusRequestBean razorPayPaymentStatusRequestBean, boolean isPayTransactionId)
			throws SQLException {
		HttpHeaders headers = new HttpHeaders();
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();

		Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyurl, port));

		requestFactory.setProxy(proxy);
		requestFactory.setConnectTimeout(15000);
		restTemplate.setRequestFactory(requestFactory);

		if (razorPayPaymentStatusRequestBean.getProductCode() == null || razorPayPaymentStatusRequestBean.getProductCode().isEmpty()) {
			ResponseBean responseBean = new ResponseBean();
			responseBean.setStatus(StatusCode.FAILURE);
			return new ResponseEntity<>(responseBean, HttpStatus.BAD_REQUEST);

		}
		String rzrApiKey = null;
		String rzrApiSecret = null;
		PayGatewayPartner paypartner = razorpaydao.getPaypartnerCredentials(razorPayPaymentStatusRequestBean.getProductCode());
		if (paypartner != null) {
			rzrApiKey = paypartner.getApikey();
			rzrApiSecret = paypartner.getApisecret();
		}

		String auth = rzrApiKey + ":" + rzrApiSecret;
		byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
		String authHeader = "Basic " + new String(encodedAuth);
		headers.add("Authorization", authHeader);
		headers.add("Accept-Language", "application/json");
		headers.add("Content-Type", "application/json");
		
		Map<String, String> params = new HashMap<>();
		if(isPayTransactionId) {
			params.put("id", razorPayPaymentStatusRequestBean.getPayTransactionId());
		}
		else {
			params.put("id", razorPayPaymentStatusRequestBean.getPayReferenaceNumber());
		}
		
		HttpEntity<String> httpEntity = new HttpEntity<>(headers);
		return restTemplate.exchange(url, HttpMethod.GET, httpEntity, String.class, params);
	}
	
	
	/**
	 * @author 678676
	 * @param responseJson
	 * @param classType
	 * @return Object
	 */
	private Object getResponseObjectFromResponseJsonString(String responseJson,Class<?> classType)
	{
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Inside getResponseObjectFromResponseJsonString() in " + CLASS_NAME);
		Object responseObject = null;

		if (null != responseJson && !responseJson.isEmpty() && null != classType) {
			ObjectMapper mapper = MapperFactory.getInstance();
			try {
				responseObject = mapper.readValue(responseJson, classType);
			} catch (JsonParseException jpe) {
				logger.error(CLASS_NAME, BFLLoggerComponent.DAO,
						"JsonParseException occurred while parsing response json", jpe);
				throw new BFLTechnicalException(RazorpayConstants.RZPRI_1008,
						env.getProperty(RazorpayConstants.RZPRI_1008));
			} catch (JsonMappingException jme) {
				logger.error(CLASS_NAME, BFLLoggerComponent.DAO,
						"JsonMappingException occurred while parsing response json", jme);
				throw new BFLTechnicalException(RazorpayConstants.RZPRI_1004,
						env.getProperty(RazorpayConstants.RZPRI_1004));
			} catch (IOException ioe) {
				logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "IOException occurred while parsing response json",
						ioe);
				throw new BFLTechnicalException(RazorpayConstants.RZPRI_1005,
						env.getProperty(RazorpayConstants.RZPRI_1005));
			}
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Exit from getResponseObjectFromResponseJsonString() in " + CLASS_NAME);
		return responseObject;
	}
	
	@Override
	public UpiIntentResponseBean initiateUpiPayment(UpiIntentRequestBean upiIntentRequestBean) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "initiateUpiPayment started for order Id : "+ upiIntentRequestBean.getOrderId());
		UpiIntentResponseBean upiIntentResponseBean;
		try {
			
			JSONObject jsonObject = mapRequestForUpiIntent(upiIntentRequestBean);
			
			HttpHeaders headers = new HttpHeaders();
			SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyurl, port));
			requestFactory.setProxy(proxy);
			requestFactory.setConnectTimeout(15000);
			restTemplate.setRequestFactory(requestFactory);

			PayGatewayPartner paypartner;
			paypartner = razorpaydao.getPaypartnerCredentials(upiIntentRequestBean.getProductCode());

			String apiKey = null;
			String apiSecretKey = null;
			if (paypartner != null) {
				apiKey = paypartner.getApikey();
				apiSecretKey = paypartner.getApisecret();
			}

			String auth = apiKey + ":" + apiSecretKey;
			byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
			String authHeader = "Basic " + new String(encodedAuth);
			headers.add("Authorization", authHeader);
			headers.add("Accept-Language", "application/json");
			headers.add("Content-Type", "application/json");

			HttpEntity<String> httpEntity = new HttpEntity<>(jsonObject.toString(), headers);

			ResponseEntity<UpiIntentResponseBean> responseEntity = restTemplate.exchange(rzrPayUpiIntentUrl, HttpMethod.POST, httpEntity, UpiIntentResponseBean.class);
			
			if (null != responseEntity && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				upiIntentResponseBean = responseEntity.getBody();
			} else {
				throw new BFLBusinessException(RazorpayConstants.RZPRI_1010,env.getProperty(RazorpayConstants.RZPRI_1010));
			}
			
		}catch (ResourceAccessException resourceAccessException) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, RazorpayConstants.RZPRI_1009 + resourceAccessException);
			throw new BFLTechnicalException(RazorpayConstants.RZPRI_1009,env.getProperty(RazorpayConstants.RZPRI_1009));
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, RazorpayConstants.RZPRI_1009 + exception);
			throw new BFLTechnicalException(RazorpayConstants.RZPRI_1009,exception.getMessage());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "initiateUpiPayment()-end response object: "+upiIntentResponseBean);
		return upiIntentResponseBean;	
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject mapRequestForUpiIntent(UpiIntentRequestBean upiIntentRequestBean){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("amount", upiIntentRequestBean.getAmount());
		jsonObject.put("currency", "INR");
		jsonObject.put("order_id", upiIntentRequestBean.getOrderId());
		jsonObject.put("notes", upiIntentRequestBean.getNotes());
		jsonObject.put("method", "upi");
		jsonObject.put("description", upiIntentRequestBean.getDescription());
		jsonObject.put("contact", upiIntentRequestBean.getContact());
		jsonObject.put("email", upiIntentRequestBean.getEmail());
		jsonObject.put("flow", "intent");
		jsonObject.put("ip", upiIntentRequestBean.getIp());
		jsonObject.put("referer", upiIntentRequestBean.getReferer());
		jsonObject.put("user_agent", upiIntentRequestBean.getUserAgent());
		
		return jsonObject;
	}
	
}
