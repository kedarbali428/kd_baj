package com.bajaj.bfsd.razorpaypgservice.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.razorpaypgservice.bean.DynamoDbBean;
import com.bajaj.bfsd.razorpaypgservice.bean.InvoiceRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.InvoiceResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RefreshScope
@Component
public class MapperForDynamoDB {

	@Value("${api.razorpayinvoice}")
	private String razorpayinvoice;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	/**
	 * @Desc This method is used to get current Timestamp
	 * @return Date
	 */
	private Timestamp getCurrentDateTimeStamp() {
		Date date = Calendar.getInstance().getTime();
		return new Timestamp(date.getTime());
	}

	public DynamoDbBean mapperForInvoiceSelection(InvoiceRequestBean invoiceRequest, InvoiceResponseBean invoiceRes) {
		DynamoDbBean dynamoDbBean = new DynamoDbBean();
		dynamoDbBean.setApplicantId(invoiceRequest.getApplicantId());
		dynamoDbBean.setAppnId(invoiceRequest.getApplicationId());
		dynamoDbBean.setRawResUrl(razorpayinvoice);
		ObjectMapper objmap = new ObjectMapper();
		String reqPayload = null;
		try {
			reqPayload = objmap.writeValueAsString(invoiceRequest);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String resPayload = null;
		try {
			resPayload = objmap.writeValueAsString(invoiceRes);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dynamoDbBean.setReqPayload(reqPayload);
		dynamoDbBean.setReqTimeStamp(sdf.format(getCurrentDateTimeStamp()));
		dynamoDbBean.setResPayload(resPayload);
		dynamoDbBean.setResPayloadStr("");
		dynamoDbBean.setResTimeStamp(sdf.format(getCurrentDateTimeStamp()));
		dynamoDbBean.setSource(RazorpayConstants.RAZORPAY);
		dynamoDbBean.setSourcetype(RazorpayConstants.RPAY_PGLINK);
		return dynamoDbBean;
	}
	
	
	

}