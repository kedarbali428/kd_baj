package com.bajaj.bfsd.razorpaypgservice.bean;

import java.math.BigDecimal;

public class RefundRequestBean {


	private String paymentId;
	private String productCode;
	private BigDecimal amount;
	
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
	
	
	
	
}
