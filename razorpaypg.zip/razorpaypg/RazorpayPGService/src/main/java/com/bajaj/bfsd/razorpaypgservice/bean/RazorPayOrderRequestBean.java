package com.bajaj.bfsd.razorpaypgservice.bean;

import java.io.Serializable;
import java.util.Map;

public class RazorPayOrderRequestBean implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 8223701981019043893L;
	private String receipt;
	private int amount;
	private String currency;
	private int payment_Capture;
	private String productCode;
	private String partnername;
	private String applicationKey;
	private String productKey;
	private String customerId;
	private String eventType;
	
	public RazorPayOrderRequestBean() {
		super();
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public String getPartnername() {
		return partnername;
	}

	public void setPartnername(String partnername) {
		this.partnername = partnername;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	
	
	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getProductKey() {
		return productKey;
	}

	public void setProductKey(String productKey) {
		this.productKey = productKey;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public int getPayment_Capture() {
		return payment_Capture;
	}

	public void setPayment_Capture(int payment_Capture) {
		this.payment_Capture = payment_Capture;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	

	/*
	 * public Map<String, String> getNotes() { return notes; }
	 * 
	 * public void setNotes(Map<String, String> notes) { this.notes = notes; }
	 */
}
