package com.bajaj.bfsd.razorpaypgservice.model;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
/**
 * Description of the class
 * This class is the bean class for the employment details of applicant in Applicant Service
 *
 * @author Cognizant - Date - 16/11/2016
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                                       16/11/2016
 *
 */
public class ApplicantEmploymentDetailBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6692921046606659171L;
	private Long key;
	private BigDecimal currentExperience;
	private String employerName;
	private String designation;
	private Date endDate;
	private Date startDate;
	private BigDecimal totalExperience;

	private Long employerId;
	private String companyListedOrUnlisted;
	private String companyType;

	private Long designationId;
	
	private Long employmentStatusCode;
	
	private Long professionCode;
	private Long applicantKey;
	
	/**
	 * @return the key
	 */
	public Long getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(Long key) {
		this.key = key;
	}

	/**
	 * @return the currentExperience
	 */
	public BigDecimal getCurrentExperience() {
		return currentExperience;
	}

	/**
	 * @param currentExperience the currentExperience to set
	 */
	public void setCurrentExperience(BigDecimal currentExperience) {
		this.currentExperience = currentExperience;
	}

	/**
	 * @return the employerName
	 */
	public String getEmployerName() {
		return employerName;
	}

	/**
	 * @param employerName the employerName to set
	 */
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}

	/**
	 * @param designation the designation to set
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the totalExperience
	 */
	public BigDecimal getTotalExperience() {
		return totalExperience;
	}

	/**
	 * @param totalExperience the totalExperience to set
	 */
	public void setTotalExperience(BigDecimal totalExperience) {
		this.totalExperience = totalExperience;
	}

	/**
	 * @return the employerId
	 */
	public Long getEmployerId() {
		return employerId;
	}

	/**
	 * @param employerId the employerId to set
	 */
	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

	/**
	 * @return the companyListedOrUnlisted
	 */
	public String getCompanyListedOrUnlisted() {
		return companyListedOrUnlisted;
	}

	/**
	 * @param companyListedOrUnlisted the companyListedOrUnlisted to set
	 */
	public void setCompanyListedOrUnlisted(String companyListedOrUnlisted) {
		this.companyListedOrUnlisted = companyListedOrUnlisted;
	}

	/**
	 * @return the companyType
	 */
	public String getCompanyType() {
		return companyType;
	}

	/**
	 * @param companyType the companyType to set
	 */
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	/**
	 * @return the designationId
	 */
	public Long getDesignationId() {
		return designationId;
	}

	/**
	 * @param designationId the designationId to set
	 */
	public void setDesignationId(Long designationId) {
		this.designationId = designationId;
	}

	/**
	 * @return the employmentStatusCode
	 */
	public Long getEmploymentStatusCode() {
		return employmentStatusCode;
	}

	/**
	 * @param employmentStatusCode the employmentStatusCode to set
	 */
	public void setEmploymentStatusCode(Long employmentStatusCode) {
		this.employmentStatusCode = employmentStatusCode;
	}

	/**
	 * @return the professionCode
	 */
	public Long getProfessionCode() {
		return professionCode;
	}

	/**
	 * @param professionCode the professionCode to set
	 */
	public void setProfessionCode(Long professionCode) {
		this.professionCode = professionCode;
	}

	/**
	 * @return the applicantKey
	 */
	public Long getApplicantKey() {
		return applicantKey;
	}

	/**
	 * @param applicantKey the applicantKey to set
	 */
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	@Override
	public String toString() {
		return "ApplicantEmploymentDetailBean [key=" + key + ", currentExperience=" + currentExperience
				+ ", employerName=" + employerName + ", designation=" + designation + ", endDate=" + endDate
				+ ", startDate=" + startDate + ", totalExperience=" + totalExperience + ", employerId=" + employerId
				+ ", designationId=" + designationId + ", employmentStatusCode=" + employmentStatusCode
				+ ", professionCode=" + professionCode + ", applicantKey=" + applicantKey + "]";
	}
	
}