package com.bajaj.bfsd.razorpaypgservice.application;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.http.HttpStatus;

import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpaypgservice.util.RazorpayConstants;
import com.bajaj.bfsd.razorpaypgservice.util.RazorpayUtility;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.bfl.common.util.BFLExceptionUtil;

public class CamelExceptionHandler implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		Properties propObj = RazorpayUtility.readPropertyFile("error.properties");
		Exception ex = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);

		ResponseBean responseBean = BFLExceptionUtil.handle(ex, propObj);
		List<ErrorBean> errorBeanList = new ArrayList<>();
		if (ex instanceof BFLBusinessException) {// currently handles business
													// exception for Invalid
													// Input fields.
			exchange.getOut().setBody(responseBean);
			exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.BAD_REQUEST);
			exchange.getOut().setFault(true);
		} else if (ex instanceof BFLTechnicalException) {
			exchange.getOut().setBody(responseBean);
			exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.INTERNAL_SERVER_ERROR);
			exchange.getOut().setFault(true);
		} else {
			ex.printStackTrace();
			ErrorBean errBean = new ErrorBean("EMND-7123",propObj.getProperty("EMND-7123"));
			errorBeanList.add(errBean);
			responseBean = new ResponseBean(errorBeanList);
			exchange.getOut().setBody(responseBean);
			exchange.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, HttpStatus.INTERNAL_SERVER_ERROR);
			exchange.getOut().setFault(true);
		}
	}}
