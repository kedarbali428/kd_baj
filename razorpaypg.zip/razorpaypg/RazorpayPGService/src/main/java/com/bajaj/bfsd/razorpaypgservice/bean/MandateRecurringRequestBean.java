package com.bajaj.bfsd.razorpaypgservice.bean;

import java.util.Map;

public class MandateRecurringRequestBean {
	private String email;
	private String contact;
	private String currency;
	private int amount;
	private String order_id;
	private String recurring;
	private String customer_id;
	private String description;
	private String token;
	
	private String productCode;
	
	public String getToken() {
		return token;
	}
	
	
	
	
	public String getProductCode() {
		return productCode;
	}




	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}




	public void setToken(String token) {
		this.token = token;
	}
	private Map<String, String> notes;

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public String getRecurring() {
		return recurring;
	}
	public void setRecurring(String recurring) {
		this.recurring = recurring;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Map<String, String> getNotes() {
		return notes;
	}
	public void setNotes(Map<String, String> notes) {
		this.notes = notes;
	}
	
	
}
