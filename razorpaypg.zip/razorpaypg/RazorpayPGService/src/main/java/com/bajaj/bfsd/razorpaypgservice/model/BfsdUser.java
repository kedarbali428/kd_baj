package com.bajaj.bfsd.razorpaypgservice.model;


import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the BFSD_USERS database table.
 * 
 */
@Entity
@Table(name="BFSD_USERS")
@NamedQuery(name="BfsdUser.findAll", query="SELECT b FROM BfsdUser b")
public class BfsdUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long userkey;

	private BigDecimal failedlogincount;

	private BigDecimal isactive;

	private Timestamp lstfailedlogindt;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private Timestamp registrationdate;

	private BigDecimal userblockedflg;

	private BigDecimal usertype;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="PARENTUSERKEY")
	private BfsdUser bfsdUser;

	//bi-directional many-to-one association to BfsdUser
	@OneToMany(mappedBy="bfsdUser")
	private List<BfsdUser> bfsdUsers;

	public BfsdUser() {
	}

	public long getUserkey() {
		return this.userkey;
	}

	public void setUserkey(long userkey) {
		this.userkey = userkey;
	}

	public BigDecimal getFailedlogincount() {
		return this.failedlogincount;
	}

	public void setFailedlogincount(BigDecimal failedlogincount) {
		this.failedlogincount = failedlogincount;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public Timestamp getLstfailedlogindt() {
		return this.lstfailedlogindt;
	}

	public void setLstfailedlogindt(Timestamp lstfailedlogindt) {
		this.lstfailedlogindt = lstfailedlogindt;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Timestamp getRegistrationdate() {
		return this.registrationdate;
	}

	public void setRegistrationdate(Timestamp registrationdate) {
		this.registrationdate = registrationdate;
	}

	public BigDecimal getUserblockedflg() {
		return this.userblockedflg;
	}

	public void setUserblockedflg(BigDecimal userblockedflg) {
		this.userblockedflg = userblockedflg;
	}

	public BigDecimal getUsertype() {
		return this.usertype;
	}

	public void setUsertype(BigDecimal usertype) {
		this.usertype = usertype;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

	public List<BfsdUser> getBfsdUsers() {
		return this.bfsdUsers;
	}

	public void setBfsdUsers(List<BfsdUser> bfsdUsers) {
		this.bfsdUsers = bfsdUsers;
	}

	public BfsdUser addBfsdUser(BfsdUser bfsdUser) {
		getBfsdUsers().add(bfsdUser);
		bfsdUser.setBfsdUser(this);

		return bfsdUser;
	}

	public BfsdUser removeBfsdUser(BfsdUser bfsdUser) {
		getBfsdUsers().remove(bfsdUser);
		bfsdUser.setBfsdUser(null);

		return bfsdUser;
	}

}