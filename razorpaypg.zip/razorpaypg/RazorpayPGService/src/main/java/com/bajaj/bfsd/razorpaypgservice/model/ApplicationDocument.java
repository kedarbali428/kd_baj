package com.bajaj.bfsd.razorpaypgservice.model;


import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the APPLICATION_DOCUMENTS database table.
 * 
 */
@Entity
@Table(name="APPLICATION_DOCUMENTS")
@NamedQuery(name="ApplicationDocument.findAll", query="SELECT ad FROM ApplicationDocument ad")
public class ApplicationDocument implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false, precision=20)
	private long appdockey;

	private Timestamp adarchivedt;

	@Column(nullable=false, precision=1)
	private BigDecimal adarchiveflg;

	@Column(length=50)
	private String addocidentitynum;

	@Column(precision=2)
	private BigDecimal addocsubmitmode;

	private Timestamp adesigndt;

	@Column(nullable=false, precision=1)
	private BigDecimal adesignstatus;

	@Column(precision=1)
	private BigDecimal adisactive;
	
	@Column(precision=1)
	private BigDecimal aduploadflg;
	
	@Column(length=20)
	private String adlstupdateby;

	private Timestamp adlstupdatedt;

	private Timestamp adsubmitdt;

	@Column(nullable=false, precision=1)
	private BigDecimal adsubmitstatus;

	private Timestamp adverificationdt;

	@Column(length=10)
	private String adverificationmode;

	@Column(nullable=false, precision=2)
	private BigDecimal adverificationsts;

	//bi-directional many-to-one association to Application
	@ManyToOne
	@JoinColumn(name="APPLICATIONKEY", nullable=false)
	private Application application;

	//bi-directional many-to-one association to ApplicationApplicant
	@ManyToOne
	@JoinColumn(name="APPAPLTKEY")
	private ApplicationApplicant applicationApplicant;

	//bi-directional many-to-one association to DocumentCategory
	@ManyToOne
	@JoinColumn(name="DOCCATKEY", nullable=false)
	private DocumentCategory documentCategory;

	//bi-directional many-to-one association to DocumentType
	@ManyToOne
	@JoinColumn(name="DOCTYPEKEY", nullable=false)
	private DocumentType documentType;

	//bi-directional many-to-one association to ApplicationDocStorage
	@OneToMany(mappedBy="applicationDocument", cascade=CascadeType.ALL)
	private List<ApplicationDocStorage> applicationDocStorages;

	public ApplicationDocument() {
		//Needed by JPA
	}

	public long getAppdockey() {
		return this.appdockey;
	}

	public void setAppdockey(long appdockey) {
		this.appdockey = appdockey;
	}

	public Timestamp getAdarchivedt() {
		return this.adarchivedt;
	}

	public void setAdarchivedt(Timestamp adarchivedt) {
		this.adarchivedt = adarchivedt;
	}

	public BigDecimal getAdarchiveflg() {
		return this.adarchiveflg;
	}

	public void setAdarchiveflg(BigDecimal adarchiveflg) {
		this.adarchiveflg = adarchiveflg;
	}

	public String getAddocidentitynum() {
		return this.addocidentitynum;
	}

	public void setAddocidentitynum(String addocidentitynum) {
		this.addocidentitynum = addocidentitynum;
	}

	public BigDecimal getAddocsubmitmode() {
		return this.addocsubmitmode;
	}

	public void setAddocsubmitmode(BigDecimal addocsubmitmode) {
		this.addocsubmitmode = addocsubmitmode;
	}

	public Timestamp getAdesigndt() {
		return this.adesigndt;
	}

	public void setAdesigndt(Timestamp adesigndt) {
		this.adesigndt = adesigndt;
	}

	public BigDecimal getAdesignstatus() {
		return this.adesignstatus;
	}

	public void setAdesignstatus(BigDecimal adesignstatus) {
		this.adesignstatus = adesignstatus;
	}

	public BigDecimal getAdisactive() {
		return this.adisactive;
	}
	
	public BigDecimal getAduploadflg() {
		return aduploadflg;
	}

	public void setAduploadflg(BigDecimal aduploadflg) {
		this.aduploadflg = aduploadflg;
	}

	public void setAdisactive(BigDecimal adisactive) {
		this.adisactive = adisactive;
	}

	public String getAdlstupdateby() {
		return this.adlstupdateby;
	}

	public void setAdlstupdateby(String adlstupdateby) {
		this.adlstupdateby = adlstupdateby;
	}

	public Timestamp getAdlstupdatedt() {
		return this.adlstupdatedt;
	}

	public void setAdlstupdatedt(Timestamp adlstupdatedt) {
		this.adlstupdatedt = adlstupdatedt;
	}

	public Timestamp getAdsubmitdt() {
		return this.adsubmitdt;
	}

	public void setAdsubmitdt(Timestamp adsubmitdt) {
		this.adsubmitdt = adsubmitdt;
	}

	public BigDecimal getAdsubmitstatus() {
		return this.adsubmitstatus;
	}

	public void setAdsubmitstatus(BigDecimal adsubmitstatus) {
		this.adsubmitstatus = adsubmitstatus;
	}

	public Timestamp getAdverificationdt() {
		return this.adverificationdt;
	}

	public void setAdverificationdt(Timestamp adverificationdt) {
		this.adverificationdt = adverificationdt;
	}

	public String getAdverificationmode() {
		return this.adverificationmode;
	}

	public void setAdverificationmode(String adverificationmode) {
		this.adverificationmode = adverificationmode;
	}

	public BigDecimal getAdverificationsts() {
		return this.adverificationsts;
	}

	public void setAdverificationsts(BigDecimal adverificationsts) {
		this.adverificationsts = adverificationsts;
	}

	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public ApplicationApplicant getApplicationApplicant() {
		return this.applicationApplicant;
	}

	public void setApplicationApplicant(ApplicationApplicant applicationApplicant) {
		this.applicationApplicant = applicationApplicant;
	}

	public DocumentCategory getDocumentCategory() {
		return this.documentCategory;
	}

	public void setDocumentCategory(DocumentCategory documentCategory) {
		this.documentCategory = documentCategory;
	}

	public DocumentType getDocumentType() {
		return this.documentType;
	}

	public void setDocumentType(DocumentType documentType) {
		this.documentType = documentType;
	}

	public List<ApplicationDocStorage> getApplicationDocStorages() {
		return this.applicationDocStorages;
	}

	public void setApplicationDocStorages(List<ApplicationDocStorage> applicationDocStorages) {
		this.applicationDocStorages = applicationDocStorages;
	}

	public ApplicationDocStorage addApplicationDocStorage(ApplicationDocStorage applicationDocStorage) {
		getApplicationDocStorages().add(applicationDocStorage);
		applicationDocStorage.setApplicationDocument(this);

		return applicationDocStorage;
	}

	public ApplicationDocStorage removeApplicationDocStorage(ApplicationDocStorage applicationDocStorage) {
		getApplicationDocStorages().remove(applicationDocStorage);
		applicationDocStorage.setApplicationDocument(null);

		return applicationDocStorage;
	}

}