package com.bajaj.bfsd.razorpaypgservice.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.bajaj.bfsd.razorpaypgservice.bean.EmandateRequestOrderBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateCustomerRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateOrderIdAndCustomerIdRequest;
import com.bajaj.bfsd.razorpaypgservice.bean.PaymentRequest;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayOrderRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorpayTransaction;

public class RazorpayServiceUtil {
	
	/**
     * Variable to hold value for corelation id.
     */
    private static String corelationId;
    /**
     * Instantiates a new authentication service util.
     */
    private RazorpayServiceUtil(){
        
    } 

    /**
     * Getter method for corelation id.
     *
     * @return corelation id
     */
    public static String getCorelationId() {
        return corelationId;
    }

    /**
     * Sets the value of corelation id.
     *
     * @param corelationId the new corelation id
     */
    public static void setCorelationId(String corelationId) {
    	RazorpayServiceUtil.corelationId = corelationId;
    }
	
    public static String getStampDateWithInString(Date date){
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'00:00:00");
		return formatter.format(date);
	}
    
    public static String getformattedDate(Date date){
    	DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
		return formatter.format(date);
	}
    
    public static Date convertStringDatetoTimeStampDate(String date) throws ParseException{
  	    return new SimpleDateFormat("yyyy-MM-dd'T'00:00:00").parse(date);
  	    
  	}
    
    public static Date getDate() throws ParseException{
    	 String format = new SimpleDateFormat("yyyy-MM-dd 00:00:00").format(new Date());
    	return new SimpleDateFormat("yyyy-MM-dd 00:00:00").parse(format);
  
    }
 
public static EmandateRequestOrderBean  mandateOrderRequestBeanMapper(MandateOrderIdAndCustomerIdRequest mandateOrderIdAndCustomerIdRequest) {
	EmandateRequestOrderBean emandateRequestOrderBean = new EmandateRequestOrderBean();
	emandateRequestOrderBean.setAmount(mandateOrderIdAndCustomerIdRequest.getAmount());
	emandateRequestOrderBean.setCurrency(mandateOrderIdAndCustomerIdRequest.getCurrency());
	emandateRequestOrderBean.setReceipt(mandateOrderIdAndCustomerIdRequest.getReceipt());
	emandateRequestOrderBean.setMethod(mandateOrderIdAndCustomerIdRequest.getMethod());
	emandateRequestOrderBean.setPayment_Capture(mandateOrderIdAndCustomerIdRequest.getPayment_Capture());
	emandateRequestOrderBean.setProductCode(mandateOrderIdAndCustomerIdRequest.getProductNumber());
	return emandateRequestOrderBean;
}
public static MandateCustomerRequestBean  mandateCustomerRequestBeanMapper(MandateOrderIdAndCustomerIdRequest mandateOrderIdAndCustomerIdRequest) {
	MandateCustomerRequestBean mandateCustomerRequestBean = new MandateCustomerRequestBean();
	mandateCustomerRequestBean.setContact(mandateOrderIdAndCustomerIdRequest.getContact());
	mandateCustomerRequestBean.setEmail(mandateOrderIdAndCustomerIdRequest.getEmail());
	mandateCustomerRequestBean.setName(mandateOrderIdAndCustomerIdRequest.getName());
	mandateCustomerRequestBean.setProductCode(mandateOrderIdAndCustomerIdRequest.getProductNumber());
	return mandateCustomerRequestBean;
}

	public static PaymentRequest paymentRequestMapper(RazorpayTransaction razorpayTxn) {
	    PaymentRequest paymentRequest = new PaymentRequest();
	    paymentRequest.setTxnNumber(razorpayTxn.getRazorpay_payment_id());
	    paymentRequest.setPartnername(razorpayTxn.getPartnername());
	    paymentRequest.setResponseStatus("success");
	    paymentRequest.setInqueryType(razorpayTxn.getInqueryType());
	    paymentRequest.setPaymentMode(razorpayTxn.getPaymentMode());
	    paymentRequest.setTxnMessage(razorpayTxn.getTxnMessage());
	    return paymentRequest;
	}
}
