package com.bajaj.bfsd.razorpaypgservice.bean;

import java.io.Serializable;

public class RazorPayPaymentStatusRequestBean implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 2472827216725453663L;
	private String payTransactionId;
	private String payReferenaceNumber;
	private String productCode;
	
	public String getPayTransactionId() {
		return payTransactionId;
	}
	public void setPayTransactionId(String payTransactionId) {
		this.payTransactionId = payTransactionId;
	}
	public String getPayReferenaceNumber() {
		return payReferenaceNumber;
	}
	public void setPayReferenaceNumber(String payReferenaceNumber) {
		this.payReferenaceNumber = payReferenaceNumber;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	
	
}
