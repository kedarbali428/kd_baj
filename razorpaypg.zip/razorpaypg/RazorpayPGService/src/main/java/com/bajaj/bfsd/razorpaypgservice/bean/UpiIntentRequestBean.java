package com.bajaj.bfsd.razorpaypgservice.bean;

/**
 * notes & description are non mandatory rest of the fields are mandatory.
 * @author 738768
 *
 */
public class UpiIntentRequestBean {

	private String productCode;
	private Long amount;
	private String orderId;
	private Object notes; 
	private String description;
	private String contact;
	private String email;
	private String ip;
	private String referer;
	private String userAgent;
	
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public Object getNotes() {
		return notes;
	}
	public void setNotes(Object notes) {
		this.notes = notes;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getReferer() {
		return referer;
	}
	public void setReferer(String referer) {
		this.referer = referer;
	}
	public String getUserAgent() {
		return userAgent;
	}
	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}
	@Override
	public String toString() {
		return "UpiIntentRequestBean [productCode=" + productCode + ", amount=" + amount + ", orderId=" + orderId
				+ ", notes=" + notes + ", description=" + description + ", contact=" + contact + ", email=" + email
				+ ", ip=" + ip + ", referer=" + referer + ", userAgent=" + userAgent + "]";
	}
}
