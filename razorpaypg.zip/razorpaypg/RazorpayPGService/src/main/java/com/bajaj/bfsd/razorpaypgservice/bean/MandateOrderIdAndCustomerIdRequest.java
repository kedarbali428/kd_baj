package com.bajaj.bfsd.razorpaypgservice.bean;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Transient;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class MandateOrderIdAndCustomerIdRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	private String receipt;
	private int amount;
	@NotNull(message="EMND-7133")
	private String currency;
	@NotNull(message="EMND-7134")
	private String method;
	private String url;
	private int payment_Capture;
	@NotNull(message="EMND-7131")
	private String name;
	@NotNull(message="EMND-7129")
	private String email;
	@NotNull(message="EMND-7130")
	private String contact;
	@NotNull(message="EMND-7132")
	private String productNumber;// Loan Number
	//User Applicant
	@Min(value=1,message="EMND-7127")
	private long applicantKey;
	@Min(value=1,message="EMND-7128")
	private long applicationKey;
	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getProductNumber() {
		return productNumber;
	}

	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}

	
	public long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(long applicationkey) {
		this.applicationKey = applicationkey;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getPayment_Capture() {
		return payment_Capture;
	}

	public void setPayment_Capture(int payment_Capture) {
		this.payment_Capture = payment_Capture;
	}

}
