package com.bajaj.bfsd.razorpaypgservice.bean;

import java.io.Serializable;
import java.util.Map;

public class MandateCustomerResponseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6584173932362089244L;
	private String id;
	private String entity;
	private String name;
	private String email;
	private String contact;
	private float created_at;

	public float getCreated_at() {
		return created_at;
	}

	public void setCreated_at(float created_at) {
		this.created_at = created_at;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

}