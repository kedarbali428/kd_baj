package com.bajaj.bfsd.razorpaypgservice.bean;

public class InvoiceRequestBean {

	private String applicationId;
	private String applicantId;
	private String name;
	private String email;
	private String contact;
	private String type;
	private long viewless;
	private long amount;
	private String currency;
	private String description;
	private String expireby;
	private String productcode;
	private String empemail;
	private String role;
	private String smsNotify;
	private String emailNotify;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public long getViewless() {
		return viewless;
	}
	public void setViewless(long viewless) {
		this.viewless = viewless;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getExpireby() {
		return expireby;
	}
	public void setExpireby(String expireby) {
		this.expireby = expireby;
	}
	public String getProductcode() {
		return productcode;
	}
	public void setProductcode(String productcode) {
		this.productcode = productcode;
	}
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	public String getEmpemail() {
		return empemail;
	}
	public void setEmpemail(String empemail) {
		this.empemail = empemail;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getSmsNotify() {
		return smsNotify;
	}
	public void setSmsNotify(String smsNotify) {
		this.smsNotify = smsNotify;
	}
	public String getEmailNotify() {
		return emailNotify;
	}
	public void setEmailNotify(String emailNotify) {
		this.emailNotify = emailNotify;
	}
	
	
	
	
}
