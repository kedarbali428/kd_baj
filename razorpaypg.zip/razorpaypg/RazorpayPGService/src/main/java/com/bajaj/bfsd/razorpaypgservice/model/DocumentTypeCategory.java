package com.bajaj.bfsd.razorpaypgservice.model;


import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the DOCUMENT_TYPE_CATEGORIES database table.
 * 
 */
@Entity
@Table(name="DOCUMENT_TYPE_CATEGORIES")
@NamedQuery(name="DocumentTypeCategory.findAll", query="SELECT d FROM DocumentTypeCategory d")
public class DocumentTypeCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=10)
	private long doctypecatmapkey;

	//bi-directional many-to-one association to DocumentCategory
	@ManyToOne
	@JoinColumn(name="DOCCATKEY", nullable=false)
	private DocumentCategory documentCategory;

	//bi-directional many-to-one association to DocumentType
	@ManyToOne
	@JoinColumn(name="DOCTYPEKEY", nullable=false)
	private DocumentType documentType;

	public DocumentTypeCategory() {
		//Needed by JPA
	}

	public long getDoctypecatmapkey() {
		return this.doctypecatmapkey;
	}

	public void setDoctypecatmapkey(long doctypecatmapkey) {
		this.doctypecatmapkey = doctypecatmapkey;
	}

	public DocumentCategory getDocumentCategory() {
		return this.documentCategory;
	}

	public void setDocumentCategory(DocumentCategory documentCategory) {
		this.documentCategory = documentCategory;
	}

	public DocumentType getDocumentType() {
		return this.documentType;
	}

	public void setDocumentType(DocumentType documentType) {
		this.documentType = documentType;
	}

}