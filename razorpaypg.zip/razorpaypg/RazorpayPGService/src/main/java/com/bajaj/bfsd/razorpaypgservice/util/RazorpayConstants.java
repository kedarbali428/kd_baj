package com.bajaj.bfsd.razorpaypgservice.util;

public class RazorpayConstants {


	/**
	 * Constant for Camel URL mapping
	 */
	public static final String CAMEL_MAPPING = "/*";
	
	/**
	 * Constant for Camel Servlet component
	 */
	public static final String CAMEL_SERVLET_NAME = "CamelServlet";
	
	/**
	 * Constant for CORELATION_ID
	 */
	public static final String CORELATION_ID = "CORELATION_ID";
	public static final String RAZORPAY = "RAZORPAY";
	public static final String RPAY_PGLINK = "RPAY_PGLINK";
	
	public static final String RZPRI_1003 = "RZPRI-1003";
	public static final String RZPRI_1004 = "RZPRI-1004";
	public static final String RZPRI_1005 = "RZPRI-1005";
	public static final String RZPRI_1006 = "RZPRI-1006";
	public static final String RZPRI_1007 = "RZPRI-1007";
	public static final String RZPRI_1008 = "RZPRI-1008";
	public static final String RZPRI_1009="RZPRI-1009";
    public static final String RZPRI_1010="RZPRI-1010";
	public static final String RZPRI_1011 = "RZPRI-1011";
	
}
