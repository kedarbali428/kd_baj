package com.bajaj.bfsd.razorpaypgservice.model;


import java.util.Date;

public class SystemDateResponseBean {

	private Date appDate;
	private Date valueDate;
	private ReturnStatusBean returnstatus;
	
	public Date getAppDate() {
		return appDate;
	}
	public void setAppDate(Date appDate) {
		this.appDate = appDate;
	}
	public Date getValueDate() {
		return valueDate;
	}
	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}
	public ReturnStatusBean getReturnstatus() {
		return returnstatus;
	}
	public void setReturnstatus(ReturnStatusBean returnstatus) {
		this.returnstatus = returnstatus;
	}
}
