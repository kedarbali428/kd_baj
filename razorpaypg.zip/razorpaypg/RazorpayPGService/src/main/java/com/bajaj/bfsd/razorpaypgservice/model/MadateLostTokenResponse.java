package com.bajaj.bfsd.razorpaypgservice.model;


import java.io.Serializable;
import java.util.List;

public class MadateLostTokenResponse implements Serializable  {
/**
	 * 
	 */
private static final long serialVersionUID = 5088121976992709293L;
private String entity;
private String count;
private List<TokenItemsBean> items;

public String getEntity() {
	return entity;
}
public void setEntity(String entity) {
	this.entity = entity;
}
public String getCount() {
	return count;
}
public void setCount(String count) {
	this.count = count;
}
public List<TokenItemsBean> getItems() {
	return items;
}
public void setItems(List<TokenItemsBean> items) {
	this.items = items;
}
public static long getSerialversionuid() {
	return serialVersionUID;
}
	




	
}
