package com.bajaj.bfsd.razorpaypgservice.model;


import java.util.Map;

public class NotificationRequest {
	private Map<String, String> templateDataMap;
	private String notificationTypeCode;
	private String  templateCode;
	
	public Map<String, String> getTemplateDataMap() {
		return templateDataMap;
	}
	public void setTemplateDataMap(Map<String, String> templateDataMap) {
		this.templateDataMap = templateDataMap;
	}
	public String getNotificationTypeCode() {
		return notificationTypeCode;
	}
	public void setNotificationTypeCode(String notificationTypeCode) {
		this.notificationTypeCode = notificationTypeCode;
	}
	public String getTemplateCode() {
		return templateCode;
	}
	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}
    
	
    
    
	
	
    
	
}
