package com.bajaj.bfsd.razorpaypgservice.model;


import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;
/**
 * Description of the class
 * This class is the bean class for the phone number of applicant in Applicant Service
 *
 * @author Cognizant - Date - 16/11/2016
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                                       16/11/2016
 *
 */
public class ApplicantPhoneNumberBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long key;
	@NotNull(message="Area code can not be null")
	private String areaCode;
	@NotNull(message="Country Code can not be null")
	private String countryCode;
	private BigDecimal isDNDActive;
	private BigDecimal isPreferred;
	private BigDecimal isVerified;
	@NotNull(message="Phone Number can not be null")
	private String number;
	private Long applicantKey;
	@NotNull(message="Phone Type can not be null")
	private String type;

	
	/**
	 * @return the key
	 */
	public Long getKey() {
		return key;
	}


	/**
	 * @param key the key to set
	 */
	public void setKey(Long key) {
		this.key = key;
	}


	/**
	 * @return the areaCode
	 */
	public String getAreaCode() {
		return areaCode;
	}


	/**
	 * @param areaCode the areaCode to set
	 */
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}


	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}


	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}


	/**
	 * @return the isDNDActive
	 */
	public BigDecimal getIsDNDActive() {
		return isDNDActive;
	}


	/**
	 * @param isDNDActive the isDNDActive to set
	 */
	public void setIsDNDActive(BigDecimal isDNDActive) {
		this.isDNDActive = isDNDActive;
	}


	/**
	 * @return the isPreferred
	 */
	public BigDecimal getIsPreferred() {
		return isPreferred;
	}


	/**
	 * @param isPreferred the isPreferred to set
	 */
	public void setIsPreferred(BigDecimal isPreferred) {
		this.isPreferred = isPreferred;
	}


	/**
	 * @return the isVerified
	 */
	public BigDecimal getIsVerified() {
		return isVerified;
	}


	/**
	 * @param isVerified the isVerified to set
	 */
	public void setIsVerified(BigDecimal isVerified) {
		this.isVerified = isVerified;
	}


	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}


	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}


	/**
	 * @return the applicantKey
	 */
	public Long getApplicantKey() {
		return applicantKey;
	}


	/**
	 * @param applicantKey the applicantKey to set
	 */
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}


	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}


	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}


	@Override
	public String toString() {
		return "ApplicantPhoneNumberBean [key=" + key + ", areaCode=" + areaCode + ", countryCode=" + countryCode
				+ ", isDNDActive=" + isDNDActive + ", isPreferred=" + isPreferred + ", isVerified=" + isVerified
				+ ", number=" + number + ", applicantKey=" + applicantKey + ", type=" + type + "]";
	}
}