package com.bajaj.bfsd.razorpaypgservice.bean;

import java.util.List;

public class InvoiceResponseBean {

	private String id;
	private String entity;
	private String receipt;
	private String invoice_number;
	private String customer_id;
	CustomerDetailsBean customer_details;
	private String order_id;
	List line_items;
	private String payment_id;
	private String status;
	private long expire_by;
	private long issued_at;
	private String paid_at;
	private String cancelled_at;
	private String expired_at;
	private String sms_status;
	private String email_status;
	private long date;
	private String terms;
	private boolean partial_payment;
	private float gross_amount;
	private float tax_amount;
	private float taxable_amount;
	private float amount;
	private float amount_paid;
	private float amount_due;
	private String currency;
	private String description;
	private NotesBean notes;
	private String comment;
	private String short_url;
	private boolean view_less;
	private String billing_start;
	private String billing_end;
	private String type;
	private boolean group_taxes_discounts;
	private long created_at;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	public String getReceipt() {
		return receipt;
	}
	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}
	public String getInvoice_number() {
		return invoice_number;
	}
	public void setInvoice_number(String invoice_number) {
		this.invoice_number = invoice_number;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public CustomerDetailsBean getCustomer_details() {
		return customer_details;
	}
	public void setCustomer_details(CustomerDetailsBean customer_details) {
		this.customer_details = customer_details;
	}
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public List getLine_items() {
		return line_items;
	}
	public void setLine_items(List line_items) {
		this.line_items = line_items;
	}
	public String getPayment_id() {
		return payment_id;
	}
	public void setPayment_id(String payment_id) {
		this.payment_id = payment_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public long getExpire_by() {
		return expire_by;
	}
	public void setExpire_by(long expire_by) {
		this.expire_by = expire_by;
	}
	public long getIssued_at() {
		return issued_at;
	}
	public void setIssued_at(long issued_at) {
		this.issued_at = issued_at;
	}
	public String getPaid_at() {
		return paid_at;
	}
	public void setPaid_at(String paid_at) {
		this.paid_at = paid_at;
	}
	public String getCancelled_at() {
		return cancelled_at;
	}
	public void setCancelled_at(String cancelled_at) {
		this.cancelled_at = cancelled_at;
	}
	public String getExpired_at() {
		return expired_at;
	}
	public void setExpired_at(String expired_at) {
		this.expired_at = expired_at;
	}
	public String getSms_status() {
		return sms_status;
	}
	public void setSms_status(String sms_status) {
		this.sms_status = sms_status;
	}
	public String getEmail_status() {
		return email_status;
	}
	public void setEmail_status(String email_status) {
		this.email_status = email_status;
	}
	public long getDate() {
		return date;
	}
	public void setDate(long date) {
		this.date = date;
	}
	public String getTerms() {
		return terms;
	}
	public void setTerms(String terms) {
		this.terms = terms;
	}
	public boolean isPartial_payment() {
		return partial_payment;
	}
	public void setPartial_payment(boolean partial_payment) {
		this.partial_payment = partial_payment;
	}
	public float getGross_amount() {
		return gross_amount;
	}
	public void setGross_amount(float gross_amount) {
		this.gross_amount = gross_amount;
	}
	public float getTax_amount() {
		return tax_amount;
	}
	public void setTax_amount(float tax_amount) {
		this.tax_amount = tax_amount;
	}
	public float getTaxable_amount() {
		return taxable_amount;
	}
	public void setTaxable_amount(float taxable_amount) {
		this.taxable_amount = taxable_amount;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public float getAmount_paid() {
		return amount_paid;
	}
	public void setAmount_paid(float amount_paid) {
		this.amount_paid = amount_paid;
	}
	public float getAmount_due() {
		return amount_due;
	}
	public void setAmount_due(float amount_due) {
		this.amount_due = amount_due;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public NotesBean getNotes() {
		return notes;
	}
	public void setNotes(NotesBean notes) {
		this.notes = notes;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getShort_url() {
		return short_url;
	}
	public void setShort_url(String short_url) {
		this.short_url = short_url;
	}
	public boolean isView_less() {
		return view_less;
	}
	public void setView_less(boolean view_less) {
		this.view_less = view_less;
	}
	public String getBilling_start() {
		return billing_start;
	}
	public void setBilling_start(String billing_start) {
		this.billing_start = billing_start;
	}
	public String getBilling_end() {
		return billing_end;
	}
	public void setBilling_end(String billing_end) {
		this.billing_end = billing_end;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean isGroup_taxes_discounts() {
		return group_taxes_discounts;
	}
	public void setGroup_taxes_discounts(boolean group_taxes_discounts) {
		this.group_taxes_discounts = group_taxes_discounts;
	}
	public long getCreated_at() {
		return created_at;
	}
	public void setCreated_at(long created_at) {
		this.created_at = created_at;
	}

	
	@Override
	public String toString() {
		return "{" + "\\\"id\\\"" + ":" + "\\\"" + id + "\\\"" + ", \\\"entity\\\"" + ":" + "\\\""
				+ entity + "\\\"" + ", \\\"receipt\\\"" + ":" + "\\\"" + receipt + "\\\"" + ", \\\"invoice_number\\\""
				+ ":" + "\\\"" + invoice_number + "\\\"" + ", \\\"customer_id\\\"" + ":" + "\\\"" + customer_id + "\\\""+ ", \\\"customer_details\\\"" + ":" + "\\\"" + customer_details + "\\\"" 
				+ ", \\\"order_id\\\"" + ":" + "\\\"" + order_id + "\\\"" + ", \\\"line_items\\\"" + ":" + "\\\"" + line_items + "\\\"" + ", \\\"payment_id\\\"" + ":" + "\\\"" + payment_id + "\\\"" +
				 ", \\\"status\\\"" + ":" + "\\\"" + status + "\\\"" +", \\\"expire_by\\\"" + ":" + "\\\"" + expire_by + "\\\"" +", \\\"issued_at\\\"" + ":" + "\\\"" + issued_at + "\\\"" +", \\\"paid_at\\\"" + ":" + "\\\"" + paid_at + "\\\"" + 
				 ", \\\"cancelled_at\\\"" + ":" + "\\\"" + cancelled_at + "\\\"" +", \\\"expired_at\\\"" + ":" + "\\\"" + expired_at + "\\\"" +", \\\"sms_status\\\"" + ":" + "\\\"" + sms_status + "\\\"" +
				 ", \\\"email_status\\\"" + ":" + "\\\"" + email_status + "\\\"" +", \\\"date\\\"" + ":" + "\\\"" + date + "\\\"" +", \\\"terms\\\"" + ":" + "\\\"" + terms + "\\\"" +
				 ", \\\"partial_payment\\\"" + ":" + "\\\"" + partial_payment + "\\\"" +", \\\"gross_amount\\\"" + ":" + "\\\"" + gross_amount + "\\\"" +", \\\"tax_amount\\\"" + ":" + "\\\"" + tax_amount + "\\\"" +
				 ", \\\"taxable_amount\\\"" + ":" + "\\\"" + taxable_amount + "\\\"" +", \\\"amount\\\"" + ":" + "\\\"" + amount + "\\\"" +", \\\"amount_paid\\\"" + ":" + "\\\"" + amount_paid + "\\\"" +
				 ", \\\"currency\\\"" + ":" + "\\\"" + currency + "\\\"" +", \\\"short_url\\\"" + ":" + "\\\"" + short_url + "\\\"" +", \\\"created_at\\\"" + ":" + "\\\"" + created_at + "\\\"" +"}";
	}
	
	
	
	
	
}
