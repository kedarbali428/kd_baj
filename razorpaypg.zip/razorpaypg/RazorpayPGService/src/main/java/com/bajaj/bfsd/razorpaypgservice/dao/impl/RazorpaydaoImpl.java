package com.bajaj.bfsd.razorpaypgservice.dao.impl;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.razorpaypgservice.bean.FetchTokenRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.PaymentRequest;
import com.bajaj.bfsd.razorpaypgservice.bean.TokenResponseBean;
import com.bajaj.bfsd.razorpaypgservice.dao.Razorpaydao;
import com.bajaj.bfsd.razorpaypgservice.model.ApplicationApplicant;
import com.bajaj.bfsd.razorpaypgservice.model.EmandateRegistration;
import com.bajaj.bfsd.razorpaypgservice.model.PGMerchantProductsMapping;
import com.bajaj.bfsd.razorpaypgservice.model.PayGatewayPartner;
import com.bajaj.bfsd.razorpaypgservice.util.EmandateServiceConstant;
import com.bajaj.bfsd.razorpaypgservice.util.RazorpayServiceUtil;
import com.bfl.common.exceptions.BFLBusinessException;

@RefreshScope
@Component
public class RazorpaydaoImpl extends BFLComponent implements Razorpaydao {

	@Autowired
	EntityManager entityManager;

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private Environment env;

	/**
	 * Constant for THIS_CLASS.
	 */
	private static final String THIS_CLASS = RazorpaydaoImpl.class.getName();

	@SuppressWarnings("unused")
	private static final String EMND_7104 = "EMND-7104";
	private static final String EMND_7125 = "EMND-7125";

	@SuppressWarnings("unchecked")
	public PayGatewayPartner getPaypartnerCredentials(String productcode) throws SQLException {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getPaypartnerCredentials - started");
		PGMerchantProductsMapping merchantProducts = null;
		PayGatewayPartner payPartner = null;
		try {
			Query query = entityManager
					.createQuery("from PGMerchantProductsMapping m where m.productCodeL3 =:productcode");
			query.setParameter("productcode", productcode);
			merchantProducts = (PGMerchantProductsMapping) query.getSingleResult();
			if (merchantProducts != null) {
				payPartner = merchantProducts.getPayGatewayPartner();
			}
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "EMND_7125", e);
			throw new BFLBusinessException("EMND_7125", env.getProperty("EMND_7125"));
		}
		return payPartner;
	}

	@SuppressWarnings("unchecked")
	private PayGatewayPartner getPaymentcode(PaymentRequest paymentRequest) {
		List<PayGatewayPartner> paymentTransactionList = new ArrayList<>();
		PayGatewayPartner payGatewayPartner = new PayGatewayPartner();
		try {
			paymentTransactionList = (List<PayGatewayPartner>) entityManager
					.createQuery(
							"select pg from PayGatewayPartner pg " + "where pg.partnername = ?1 and pg.isactive =1")
					.setParameter(1, paymentRequest.getPartnername()).getResultList();
			if (!paymentTransactionList.isEmpty()) {
				payGatewayPartner = paymentTransactionList.get(0);
			} else {
				logger.error(THIS_CLASS, BFLLoggerComponent.DAO, EmandateServiceConstant.EMND_7109);
			}
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.DAO, EmandateServiceConstant.EMND_7109, e);
			throw new BFLBusinessException(EmandateServiceConstant.EMND_7109,
					env.getProperty(EmandateServiceConstant.EMND_7109));
		}

		return payGatewayPartner;
	}

	@Override
	public ApplicationApplicant getApplicationApplcant(long applicantkey, long applicationkey) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getEmandateApplicationApplicant started");
		Query query = entityManager.createQuery(
				"from  ApplicationApplicant app where app.applicant.applicantkey =:applicantid and app.application.applicationkey=:applicationkey");
		query.setParameter("applicantid", applicantkey);
		query.setParameter("applicationkey", applicationkey);
		List<ApplicationApplicant> app = query.getResultList();
		ApplicationApplicant applicationApplicant = null;
		if (app.size() != 0) {
			applicationApplicant = app.get(0);
		}
		return applicationApplicant;
	}

	@Transactional
	@Override
	public void saveCustomerRegistration(String orderid, String customerid, long applicantkey, long applicationkey,
			String productcode) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "EmandateDaoImpl started");
		EmandateRegistration emandateReg = new EmandateRegistration();
		ApplicationApplicant applicationApplcant = getApplicationApplcant(applicantkey, applicationkey);

		//We have set the flags for testing purpose, and shall be removed soon.
		if (applicationApplcant != null) {
			emandateReg.setAppapltkey(applicationApplcant.getAppapltkey());
		}
		Date date = null;
		try {
			date = RazorpayServiceUtil.getDate();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		emandateReg.setPresentment_date(date);
		emandateReg.setLast_successful_payment_date(date);
		emandateReg.setProductCode(productcode);
		emandateReg.setRp_customer_id(customerid);
		emandateReg.setIsactive(1);
		emandateReg.setLstupdateby("System");
		emandateReg.setLstupdatedt(new Timestamp(new Date().getTime()));
		entityManager.persist(emandateReg);
	}

	@SuppressWarnings("unchecked")
	@Override
	public EmandateRegistration getEmandateReg(long appapltkey, String productCode) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getEmandateReg started");
		List<EmandateRegistration> emd = entityManager.createQuery(
				"from  EmandateRegistration app where app.appapltkey =:appapltkey and app.productCode =:productCode")
				.setParameter("appapltkey", appapltkey).setParameter("productCode", productCode).getResultList();
		if (emd.size() != 0) {
			return emd.get(0);
		}
		return null;
	}

	@Transactional
	@Override
	public void updateTokenInEmandateReg(FetchTokenRequestBean fetchTokenReq,TokenResponseBean tokenResponseBean) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "UpdateTOkenINEmandateRegistration");
		Query query = entityManager.createQuery(
				"from  ApplicationApplicant app where app.applicant.applicantkey =:applicantid and app.application.applicationkey=:applicationkey");
		query.setParameter("applicantid", fetchTokenReq.getApplicantKey());
		query.setParameter("applicationkey", fetchTokenReq.getApplicationKey());
		List<ApplicationApplicant> app = query.getResultList();
		ApplicationApplicant applicationApplicant = null;
		if (app.size() != 0) {
			applicationApplicant = app.get(0);

			Query emreg = entityManager.createQuery(
					"from  EmandateRegistration app where app.appapltkey =:appapltkey and app.rp_customer_id=:vendor_customerid");
			emreg.setParameter("appapltkey", applicationApplicant.getAppapltkey());
			emreg.setParameter("vendor_customerid", fetchTokenReq.getCustomerId());
			List<EmandateRegistration> app1 = emreg.getResultList();
			EmandateRegistration emr = null;
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "emandate reg details="+fetchTokenReq.getCustomerId()+":appapltkey="+applicationApplicant.getAppapltkey()+"orderid="+tokenResponseBean.getOrder_id());
			if (app1.size() != 0) {
				emr = app1.get(0);
				emr.setToken_id(tokenResponseBean.getToken_id());
				emr.setOrderid(tokenResponseBean.getOrder_id());
				emr.setPaymentid(fetchTokenReq.getPaymentId());
				emr.setToken_status(tokenResponseBean.getStatus());
				emr.setTxn_date_time(new Date());
				entityManager.merge(emr);
			}
		}
	}

}
