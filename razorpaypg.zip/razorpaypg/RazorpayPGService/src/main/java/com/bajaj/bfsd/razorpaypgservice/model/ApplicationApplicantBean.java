package com.bajaj.bfsd.razorpaypgservice.model;


import java.io.Serializable;

public class ApplicationApplicantBean implements Serializable{
  
	/**
	 * 
	 */
	private static final long serialVersionUID = 6934025080813497752L;

	private Long applicationId;
	private Long applicationApplicantId;
	
	private String residentialTypeCode;
	
	private String residentialTypeDesc;

	public Long getApplicationId() {
		return applicationId;
	}

	
	/**
	 * @return the applicationApplicantId
	 */
	public Long getApplicationApplicantId() {
		return applicationApplicantId;
	}


	/**
	 * @param applicationApplicantId the applicationApplicantId to set
	 */
	public void setApplicationApplicantId(Long applicationApplicantId) {
		this.applicationApplicantId = applicationApplicantId;
	}


	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public String getResidentialTypeCode() {
		return residentialTypeCode;
	}

	public void setResidentialTypeCode(String residentialTypeCode) {
		this.residentialTypeCode = residentialTypeCode;
	}

	public String getResidentialTypeDesc() {
		return residentialTypeDesc;
	}

	public void setResidentialTypeDesc(String residentialTypeDesc) {
		this.residentialTypeDesc = residentialTypeDesc;
	}
	
	
}
