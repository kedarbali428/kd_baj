package com.bajaj.bfsd.razorpaypgservice.bean;

public class MandateOrderIdAndCustomerIdResponse {

	
	private String orderId;
	private String customerId;

	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
}
