package com.bajaj.bfsd.razorpaypgservice.model;


import java.io.Serializable;
import java.util.List;

public class OrderIdRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    //for order id
	private String receipt;
	private int amount;
	private String currency;
	private int paymentCapture;
	private String url;
	
	public String getReceipt() {
		return receipt;
	}
	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getPaymentCapture() {
		return paymentCapture;
	}
	public void setPaymentCapture(int paymentCapture) {
		this.paymentCapture = paymentCapture;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
}
