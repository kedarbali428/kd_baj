package com.bajaj.bfsd.razorpaypgservice.service;

import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.EmandateOrderResponse;
import com.bajaj.bfsd.razorpaypgservice.bean.EmandateRequestOrderBean;
import com.bajaj.bfsd.razorpaypgservice.bean.FetchTokenRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.InvoiceRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.InvoiceResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateCustomerRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateCustomerResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayOrderRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayOrderResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayPaymentStatusRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorpayPaymentStatusResponse;
import com.bajaj.bfsd.razorpaypgservice.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.TokenResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.TransferRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.TransferResponseBean;
import com.bajaj.bfsd.razorpaypgservice.bean.UpiIntentRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.UpiIntentResponseBean;

public interface RazorpayService {

	public EmandateOrderResponse createMandateOrder(EmandateRequestOrderBean mandateRequestOrderBean);

	public MandateCustomerResponseBean createMandateCustomer(MandateCustomerRequestBean mandateCustomerRequestBean);

	public TokenResponseBean getRazorPayToken(String paymentId, String productCode);

	public RazorPayOrderResponseBean createRazorPayOrder(RazorPayOrderRequestBean orderRequest);

	public void savecustomeridInRegistration(String orderid, String customerid, long applicantkey, long applicationkey,
			String productcode);

	public void updateTokenInEmandateReg(FetchTokenRequestBean fetchTokenReq, TokenResponseBean tokenResponseBean);
	
	public InvoiceResponseBean createInvoice(InvoiceRequestBean invoiceRequest,String authtoken,String guardtoken);
	
	public ResponseBean initiateRefundRzrpay(RefundRequestBean refundReqBean);
	
	public TransferResponseBean initiateRazorPayTransfer(TransferRequestBean transferRequestBean);

	public RazorpayPaymentStatusResponse getRazorPayPaymentStatus(RazorPayPaymentStatusRequestBean razorPayPaymentStatusRequestBean);
	
	public UpiIntentResponseBean initiateUpiPayment(UpiIntentRequestBean upiIntentRequestBean);
}
