package com.bajaj.bfsd.razorpaypgservice.application;

import java.util.EnumSet;

import javax.servlet.DispatcherType;
import javax.ws.rs.core.MediaType;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.swagger.servletlistener.ServletListenerRestSwaggerApiDeclarationServlet;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.swagger.servlet.RestSwaggerCorsFilter;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.FilterHolder;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.razorpaypgservice.bean.EmandateRequestOrderBean;
import com.bajaj.bfsd.razorpaypgservice.bean.FetchTokenRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.InvoiceRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateCustomerRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.MandateOrderIdAndCustomerIdRequest;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayOrderRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RazorPayPaymentStatusRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.RefundRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.TransferRequestBean;
import com.bajaj.bfsd.razorpaypgservice.bean.UpiIntentRequestBean;

@Component
public class RazorpayServiceRouter extends RouteBuilder {

	@Autowired
	CamelContext camelContext;

	@Autowired
	Environment env;

	@Override
	public void configure() throws Exception {
		onException(Exception.class).process(new CamelExceptionHandler()).handled(true).end();
		restConfiguration().component("servlet").enableCORS(true).bindingMode(RestBindingMode.json)
				.dataFormatProperty("prettyPrint", "true")
				.dataFormatProperty("json.in.disableFeatures", "FAIL_ON_UNKNOWN_PROPERTIES");

		rest("/").description("This service createorderid for emandate").consumes(MediaType.APPLICATION_JSON)
				.produces(MediaType.APPLICATION_JSON)
				.post(env.getProperty("api.razorpay.emandate.createorderid.POST.route"))
				.type(EmandateRequestOrderBean.class)
				.to("bean:razorpayServiceController?method=getEmandateOrderId(${body},${header.cmptcorrid})")
				.produces("application/json");

		rest("/").description("This service intiateEmandate for create orderid and customerid")
				.consumes(MediaType.APPLICATION_JSON).produces(MediaType.APPLICATION_JSON)
				.post(env.getProperty("api.razorpay.emandate.intiatemandate.POST.route"))
				.type(MandateOrderIdAndCustomerIdRequest.class)
				.to("bean:razorpayServiceController?method=getMandateOrderIdAndCutomerId(${body},${header.cmptcorrid})")
				.produces("application/json");
		rest("/").description("This service fetch token").consumes(MediaType.APPLICATION_JSON)
				.produces(MediaType.APPLICATION_JSON)
				.put(env.getProperty("api.razorpay.emandate.fetchtoken.POST.route")).type(FetchTokenRequestBean.class)
				.to("bean:razorpayServiceController?method=getMandateToken(${body},${header.cmptcorrid})")
				.produces("application/json");

		rest("/").description("This service createCustomer for emandate").consumes(MediaType.APPLICATION_JSON)
				.produces(MediaType.APPLICATION_JSON)
				.post(env.getProperty("api.razorpay.emandate.createcustomer.POST.route"))
				.type(MandateCustomerRequestBean.class)
				.to("bean:razorpayServiceController?method=getEmandateCustomer(${body},${header.cmptcorrid})")
				.produces("application/json");

		rest("/").description("This service for PG orderid").consumes(MediaType.APPLICATION_JSON)
				.produces(MediaType.APPLICATION_JSON).post(env.getProperty("api.razorpay.pg.getorderid.POST.route"))
				.type(RazorPayOrderRequestBean.class)
				.to("bean:razorpayServiceController?method=getRazorPayOrderId(${body},${header.cmptcorrid})")
				.produces("application/json");
		
		rest("/").description("This service for payment status").consumes(MediaType.APPLICATION_JSON)
				.produces(MediaType.APPLICATION_JSON).post(env.getProperty("api.razorpay.getpaymentstatus.POST.route"))
				.type(RazorPayPaymentStatusRequestBean.class)
				.to("bean:razorpayServiceController?method=getRazorPayPaymentStatus(${body},${header.cmptcorrid})")
				.produces("application/json");
		rest("/").description("This service for invoice").consumes(MediaType.APPLICATION_JSON)
		.produces(MediaType.APPLICATION_JSON).post(env.getProperty("api.razorpay.create.invoice.POST.route"))
		.type(InvoiceRequestBean.class)
		.to("bean:razorpayServiceController?method=createInvoice(${body},${header.cmptcorrid},${header.authtoken},${header.guardtoken})")
		.produces("application/json");
		
		rest("/").description("This service is to call refund API of Razorpay")
		.consumes(MediaType.APPLICATION_JSON).produces(MediaType.APPLICATION_JSON)
		.post(env.getProperty("api.razorpay.initiaterefund.POST.route"))
		.type(RefundRequestBean.class)
		.to("bean:razorpayServiceController?method=initiateRefundRzrpay(${body},${header.cmptcorrid})")
		.produces(MediaType.APPLICATION_JSON);

		rest("/").description("This service is to call transfer API of Razorpay")
		.consumes(MediaType.APPLICATION_JSON).produces(MediaType.APPLICATION_JSON)
		.post(env.getProperty("api.razorpay.transfer.POST.route"))
		.type(TransferRequestBean.class)
		.to("bean:razorpayServiceController?method=initiateMultipleTransferRzrpay(${body},${header.cmptcorrid})")
		.produces(MediaType.APPLICATION_JSON);
		
		rest("/").description("This service is to call upi intent API of Razorpay")
		.consumes(MediaType.APPLICATION_JSON).produces(MediaType.APPLICATION_JSON)
		.post(env.getProperty("api.razorpay.upi.intent.POST.route"))
		.type(UpiIntentRequestBean.class)
		.to("bean:razorpayServiceController?method=initiateUpiPayment(${body},${header.cmptcorrid})")
		.produces(MediaType.APPLICATION_JSON);

		startSwaggerServer(camelContext, env);
	}

	private static Server startSwaggerServer(CamelContext camelContext, Environment env) throws Exception {
		Server server = new Server(9090);
		ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);

		context.setContextPath("/");
		context.setAttribute("CamelContext", camelContext);

		server.setHandler(context);

		ServletHolder swaggerServlet = new ServletHolder(new ServletListenerRestSwaggerApiDeclarationServlet());

		swaggerServlet.setInitParameter("base.path", env.getProperty("base.path"));
		swaggerServlet.setInitParameter("api.path", env.getProperty("api.path"));
		swaggerServlet.setInitParameter("api.version", env.getProperty("api.version"));
		swaggerServlet.setInitParameter("api.title", env.getProperty("api.title"));

		context.addServlet(swaggerServlet, "/api-docs/*");
		context.addFilter(new FilterHolder(new RestSwaggerCorsFilter()), "/api-docs/*",
				EnumSet.of(DispatcherType.REQUEST));

		server.start();
		return server;
	}

}
