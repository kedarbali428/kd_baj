/*
 * 
 */
package com.bajaj.bfsd.razorpaypgservice.util;

import java.math.BigDecimal;

/**
 * The Class EmandateServiceConstans.
 */
public class EmandateServiceConstant {
	
	
    /** The Constant APPACCT_Flag. */
    public static final String APPACCT_FLAG = "1";// (1-account , 2- application)
    
    /** The Constant CHANNEL_TYPE. */
    public static final String CHANNEL_TYPE = "Customer Portal";//channelType
    
    public static final BigDecimal STATUS_IN_PROGRESS = new BigDecimal(1) ;
    public static final BigDecimal STATUS_CLOSE = new BigDecimal(3) ;
    public static final BigDecimal STATUS_OPEN = new BigDecimal(0) ;
    
    public static final BigDecimal TXN_SUCCESS_STATUS = new BigDecimal(1) ;//PAYMENT SUCCESS
    public static final BigDecimal TXN_FAILURE_STATUS = new BigDecimal(2) ;//PAYMENT FAILURE
    public static final BigDecimal PENN_SUCCESS_STATUS = new BigDecimal(1) ;//PENNANT SUCCESS
    
    /** The Constant PENN_FAILURE_STATUS. */
    public static final BigDecimal PENN_FAILURE_STATUS = new BigDecimal(2) ;//PENNANT FAILURE
    
    public static final String PART_PAYMENT = "PP";
    public static final String INT_SERVICE = "DI";
    public static final String FORC_CLOSURE = "FC";
    public static final String MISSED_EMI = "ME";
    public static final String PENNANT_SUCCESS =  "Success";
    public static final String PENNANT_PARTIAL =  "Partial";
    public static final String PAYMENT_FAILURE =  "Failure";
    public static final String CREATED_BY =  "SYSTEM";
    public static final String EVENT_TYPE_FC =  "FC";
    public static final String EVENT_TYPE_PP =  "PP";
    public static final String EVENT_TYPE_ME =  "ME";
    
    /** The Constant for errors */
    public static final String EMND_7111="EMND-7111";
    public static final String EMND_7104="EMND-7104";
    public static final String EMND_7106="EMND-7106";
    public static final String EMND_7109="EMND-7109";
    public static final String EMND_7108="EMND-7108";
    public static final String EMND_7107="EMND-7107";
    public static final String EMND_7114="EMND-7114";
    public static final String EMND_7113="EMND-7113";
    public static final String EMND_7105="EMND-7105";
    public static final String EMND_7101="EMND-7101";
    public static final String EMND_7102="EMND-7102";
    public static final String EMND_7103="EMND-7103";
    public static final String EMND_7115="EMND-7115";
    public static final String EMND_7116="EMND-7116";
    public static final String EMND_7117="EMND-7117";
    public static final String EMND_7118="EMND-7118";
    public static final String EMND_7119="EMND-7119";
    public static final String EMND_7120="EMND-7120";
    public static final String EMND_7121="EMND-7121";
    public static final String EMND_7123="EMND-7123";
    public static final String EMND_7124="EMND-7124";
    public static final String INVCE_0002="INVCE-0002";
    
    
    /** The Constant for CREATING SERVICE REQUEST */
    public static final String STP_REQ_TYPE="stpReqType";
    public static final String STP_FLAG="stpFlag";
    public static final String REQ_AMOUNT="reqAmount";
    public static final String TOTAL_FEES="totalFees";
    public static final String NET_AMOUNT="netAmount";
    public static final String REQ_ATTRIBUTES="reqAttributes";
    public static final String WITHDRAWAMOUNT="withdrawAmount";
    public static final String PRODCODE="productCode";
    public static final String SUBPRODCODE="subProductCode";
    public static final String APPLICANT="applicantId";
    public static final String QUERYTYPE="queryType";
    public static final String QUERYSUBTYPE="querySubType";
    public static final String SERVICESTATUS="serReqCurStatus";
    
    
    //Notification Templetes
    public static final String PARTPAYMENTSUCCESS="partPaymentSuccess";
    public static final String PARTPAYMENTFAILURE="partPaymentFail";

    public static final String INSSUCCESS="InsSuccess";
    public static final String INSFAILURE="InsFail";
    
    
    public static final String MISSEDEMISUCCESS="MissedEmiSuccess";
    public static final String MISSEDEMIFAILURE="MissedEmiFail";
    
    public static final String FORECLOSUREEMISUCCESS="ForeclosureSuccess";
    public static final String FORECLOSURESMSFAILURE="ForeclosureFail";
   
    
    public static final String WITHDRAWALSUCCESS="WithdrawalSuccess";
    public static final String WITHDRAWALFAILURE="WithdrawalFail";
    
    public static final String PARTTYPECODE="PREPAD";
    public static final String PARTFAILTYPECODE="PREPADFAIL";
    public static final String INSCODE="INS";
    public static final String INSCODEFAIL="INSFAIL";
    public static final String MISSEDEMI="EMIDUE";
    public static final String MISSEDEMIFAIL="EMIDUEFAIL";
    public static final String FORECLOSURE="FORCD";
    public static final String FORECLOSUREFAIL="FORCDFAIL";
    public static final String WITHDRAWAL="WITHDRAWAL";
    public static final String WITHDRAWALFAIL="WITHDRAWALFAIL";
    public static final String FALSE="false";
    public static final String TRUE="true";
    public static final String PRODUCTCODE = "1" ;
    public static final String CARDPRODUCTCODE = "28" ;

  //QueryType and Subtype
    public static final String PPQUERYTYPE="PART_PRE-PAYMENT";
    public static final String PPQUERYSUBTYPE="PART_PREPAYMENT_TRANSACTION_FAILED";
    public static final String ISQUERYTYPE="INTEREST_SERVICING_DEPOSIT";
    public static final String ISQUERYSUBTYPE="INTEREST_SERVICING_DEPOSIT_TRANSACTION_FAILED";
    public static final String MEQUERYTYPE="MISSED_EMI";
    public static final String MEQUERYSUBTYPE="MISSED_EMI_TRANSACTION_FAILED";
    public static final String FCQUERYTYPE="FORECLOSURE";
    public static final String FCQUERYSUBTYPE="FORECLOSURE_TRANSACTION_FAILED";
    public static final String PPINQQUERYSUBTYPE="PART_PRE-PAYMENT_INQUIRY";
    public static final String DIINQQUERYSUBTYPE="INTEREST_SERVICING_DEPOSIT_INQUIRY";
    public static final String MEINQQUERYSUBTYPE="MISSED_EMI_INQUIRY";
    public static final String FCINQQUERYSUBTYPE="FC_ENQUIRY";
    public static final String PPPAYMENTSUBTYPE="PART_PRE-PAYMENT_GATEWAY_FAILURE";
    public static final String DIPAYMENTSUBTYPE="INTEREST_SERVICING_DEPOSIT_PAYMENT_GATEWAY_FAILURE";
    public static final String MEPAYMENTSUBTYPE="MISSED_EMI_INQUIRY_PAYMENT_GATEWAY_FAILURE";
    public static final String FCPAYMENTSUBTYPE="PAYMENT_GATEWAY_FAILED";
    //Pennant success query subtypes
    public static final String PPPENNANTSUCCESS="PART_PRE-PAYMENT";
    public static final String FCPENNANTSUCCESS="FORECLOSURE";
    public static final String DIPENNANTSUCCESS="INTEREST_SERVICING_DEPOSIT";
    public static final String MEPENNANTSUCCESS="MISSED_EMI_PAYMENT";
    public static final String CURRENCY = "INR";
    public static final BigDecimal ACTIVEFLAG = new BigDecimal(1) ;
    
    public static final String DIGITALGOLD_10550="DIGITALGOLD_10550";
    public static final String DIGITALGOLD_10551="DIGITALGOLD_10551";
    public static final String DIGITALGOLD_10552="DIGITALGOLD_10552";
    
    public static final String RZPRI_1001="RZPRI-1001";
    public static final String RZPRI_1002="RZPRI-1002";
    public static final String RZPRI_1003="RZPRI-1003";
    
    private EmandateServiceConstant()
    {
    	//private constructor
    }
    
    
}
