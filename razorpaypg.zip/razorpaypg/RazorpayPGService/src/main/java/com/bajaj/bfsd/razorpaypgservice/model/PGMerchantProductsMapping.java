package com.bajaj.bfsd.razorpaypgservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the PGMERCHANT_PRODUCTS_MAPPING database table.
 * 
 */
@Entity
@Table(name="PGMERCHANT_PRODUCTS_MAPPING")
@NamedQuery(name="PGMerchantProductsMapping.findAll", query="SELECT m FROM PGMerchantProductsMapping m")
public class PGMerchantProductsMapping implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3759390573005374545L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String merchantproductkey;
	
	@Column(name="PRODUCT_CODE_L3")
	private String productCodeL3;
	
	private String merchantid;
	
	@ManyToOne
	@JoinColumn(name="merchantid",referencedColumnName="merchantid", insertable=false, updatable=false)
	private PayGatewayPartner payGatewayPartner;

	public String getMerchantproductkey() {
		return merchantproductkey;
	}

	public PayGatewayPartner getPayGatewayPartner() {
		return payGatewayPartner;
	}

	public void setPayGatewayPartner(PayGatewayPartner payGatewayPartner) {
		this.payGatewayPartner = payGatewayPartner;
	}

	public PGMerchantProductsMapping() {
	}

	public void setMerchantproductkey(String merchantproductkey) {
		this.merchantproductkey = merchantproductkey;
	}

	

	public String getMerchantid() {
		return merchantid;
	}

	public void setMerchantid(String merchantid) {
		this.merchantid = merchantid;
	}

	public String getProductCodeL3() {
		return productCodeL3;
	}

	public void setProductCodeL3(String productCodeL3) {
		this.productCodeL3 = productCodeL3;
	}

}
