package com.bajaj.bfsd.razorpaypgservice.bean;

public class UpiIntentResponseBean {

	private String razorpay_payment_id;
	private String link;
	
	public String getRazorpay_payment_id() {
		return razorpay_payment_id;
	}
	public void setRazorpay_payment_id(String razorpay_payment_id) {
		this.razorpay_payment_id = razorpay_payment_id;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	@Override
	public String toString() {
		return "UpiIntentResponseBean [razorpay_payment_id=" + razorpay_payment_id + ", link=" + link + "]";
	}
}
