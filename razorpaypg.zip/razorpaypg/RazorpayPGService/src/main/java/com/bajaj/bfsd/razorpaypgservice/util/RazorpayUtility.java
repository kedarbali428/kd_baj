package com.bajaj.bfsd.razorpaypgservice.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;

public class RazorpayUtility {	
	
	private static final String CLASS_NAME = RazorpayUtility.class.getCanonicalName();
	/**
	 * This method will get the exception trace as string 
	 * @param ex
	 * @return String 
	 */
	public static String getExceptionTrace(Exception ex) {
		try {
			StringWriter strbufLog = new StringWriter();
			ex.printStackTrace(new PrintWriter(strbufLog));
			return strbufLog.toString();
		} catch (Exception e) {
			BFLLoggerUtil.error(RazorpayConstants.CORELATION_ID, CLASS_NAME, BFLLoggerComponent.CONTROLLER,"Error in creating Exception Trace" + e.getMessage());
			BFLLoggerUtil.info(RazorpayConstants.CORELATION_ID, CLASS_NAME, BFLLoggerComponent.CONTROLLER,RazorpayUtility.getExceptionTrace(e));
		}
		return "";
	}
	
	/**
	 * This method will load the properties file
	 * @param propertyFileName
	 * @return Properties
	 */
	public static Properties readPropertyFile(String propertyFileName) {
		Properties prop = new Properties();
		InputStream input = null;

		try {
			input = RazorpayUtility.class.getClassLoader().getResourceAsStream(propertyFileName);
			if (input == null) {
				BFLLoggerUtil.debug(RazorpayConstants.CORELATION_ID, CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Sorry, unable to find " + propertyFileName);
			} else {
				prop.load(input);
			}

		} catch (IOException ex) {
			BFLLoggerUtil.error(RazorpayConstants.CORELATION_ID, CLASS_NAME, BFLLoggerComponent.CONTROLLER,"Unable to read config file. " + ex.getMessage());
			BFLLoggerUtil.info(RazorpayConstants.CORELATION_ID, CLASS_NAME, BFLLoggerComponent.CONTROLLER,RazorpayUtility.getExceptionTrace(ex));
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					BFLLoggerUtil.error(RazorpayConstants.CORELATION_ID, CLASS_NAME, BFLLoggerComponent.CONTROLLER,"Exception in closing stream " + e.getMessage());
					BFLLoggerUtil.info(RazorpayConstants.CORELATION_ID, CLASS_NAME, BFLLoggerComponent.CONTROLLER,RazorpayUtility.getExceptionTrace(e));
				}
			}
		}
		return prop;
	}
	
	/**
	 * @Desc This method is used to get current date
	 * @return Date
	 */
	public static Timestamp getCurrentDate() {
		Date date=Calendar.getInstance().getTime();
		return new Timestamp(date.getTime());
	}
}
