package com.bajaj.bfsd.razorpaypgservice.bean;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DynamoDbBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String appnId; // Application Key

	private String applicantId;

	// @NotNull(message = "Source must not be null")
	private String source;

	@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
	private transient Object resPayload;

	private String resPayloadStr;

	// DynamoDB do not support Timestamp data type
	private String reqTimeStamp;

	private String resTimeStamp;

	private String rawResUrl;

	private String sourcetype;

	@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
	private transient Object reqPayload;

	public String getAppnId() {
		return appnId;
	}

	public void setAppnId(String appnId) {
		this.appnId = appnId;
	}

	public String getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Object getResPayload() {
		return resPayload;
	}

	public void setResPayload(Object resPayload) {
		this.resPayload = resPayload;
	}

	public String getReqTimeStamp() {
		return reqTimeStamp;
	}

	public void setReqTimeStamp(String reqTimeStamp) {
		this.reqTimeStamp = reqTimeStamp;
	}

	public String getResTimeStamp() {
		return resTimeStamp;
	}

	public void setResTimeStamp(String resTimeStamp) {
		this.resTimeStamp = resTimeStamp;
	}

	public String getRawResUrl() {
		return rawResUrl;
	}

	public void setRawResUrl(String rawResUrl) {
		this.rawResUrl = rawResUrl;
	}

	public String getResPayloadStr() {
		return resPayloadStr;
	}

	public void setResPayloadStr(String resPayloadStr) {
		this.resPayloadStr = resPayloadStr;
	}

	public String getSourcetype() {
		return sourcetype;
	}

	public void setSourcetype(String sourcetype) {
		this.sourcetype = sourcetype;
	}

	public Object getReqPayload() {
		return reqPayload;
	}

	public void setReqPayload(Object reqPayload) {
		this.reqPayload = reqPayload;
	}

}
