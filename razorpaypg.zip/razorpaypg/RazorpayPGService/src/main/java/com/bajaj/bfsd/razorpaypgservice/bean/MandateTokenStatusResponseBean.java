package com.bajaj.bfsd.razorpaypgservice.bean;

import java.util.List;
import java.util.Map;

public class MandateTokenStatusResponseBean {

	private String id;
	private String entity;
	private String method;
	private String bank;
	private String wallet;
	private String recurring;
	private Map<String,String> recurring_details;
	private String created_at;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getWallet() {
		return wallet;
	}

	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	public String getRecurring() {
		return recurring;
	}

	public void setRecurring(String recurring) {
		this.recurring = recurring;
	}

	/*public List<String> getRecurring_details() {
		return recurring_details;
	}

	public void setRecurring_details(List<String> recurring_details) {
		this.recurring_details = recurring_details;
	}*/

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public Map<String,String> getRecurring_details() {
		return recurring_details;
	}

	public void setRecurring_details(Map<String,String> recurring_details) {
		this.recurring_details = recurring_details;
	}

}