package com.bajaj.bfsd.razorpaypgservice.application;
 
import static com.bajaj.bfsd.razorpaypgservice.util.RazorpayConstants.CAMEL_SERVLET_NAME;
import static com.bajaj.bfsd.razorpaypgservice.util.RazorpayConstants.CAMEL_MAPPING;

import org.apache.camel.component.servlet.CamelHttpTransportServlet;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.cloud.config.server.EnableConfigServer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;

import com.bajaj.bfsd.common.business.baseclasses.BFLBusinessApplication;

@EnableConfigServer
@PropertySource("classpath:error.properties")
@EntityScan("com")
public class RazorpayBootApplication extends BFLBusinessApplication{

	/**
	 * This is the main class for the spring boot application start
	 * 
	 * @param args 
	 */
	@Value("${api.razorpay.base.context}")
	private String camelUrlMapping;
	
	public static void main(String[] args) {
        SpringApplication.run(RazorpayBootApplication.class, args);
        }
	
		
	 /**
		 * Method for Servlet Resgistration.
		 * @return ServletRegistrationBean
		 */
		@Bean
		public ServletRegistrationBean servletRegistrationBean() {
			ServletRegistrationBean registration = new ServletRegistrationBean(new CamelHttpTransportServlet(),camelUrlMapping+CAMEL_MAPPING);
			registration.setName(CAMEL_SERVLET_NAME);
			return registration;
		}
}
