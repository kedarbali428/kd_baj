package com.bajaj.bfsd.razorpaypgservice.bean;

import java.io.Serializable;
import java.util.List;

public class RazorpayPaymentStatusResponse implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2724484570939391606L;
	
	private String entity;
	private int count;
	private List<RazorpayPaymentStatusByPaymntIdResponse> items;
	
	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public List<RazorpayPaymentStatusByPaymntIdResponse> getItems() {
		return items;
	}
	public void setItems(List<RazorpayPaymentStatusByPaymntIdResponse> items) {
		this.items = items;
	}
	
	
}
