package com.bajaj.bfsd.razorpaypgservice.model;


public class ReturnStatusBean {
private String returnCode;
	
	private String returnText;

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnText() {
		return returnText;
	}

	public void setReturnText(String returnText) {
		this.returnText = returnText;
	}
}
