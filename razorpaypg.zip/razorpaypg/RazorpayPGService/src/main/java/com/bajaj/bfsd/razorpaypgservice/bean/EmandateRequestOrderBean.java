package com.bajaj.bfsd.razorpaypgservice.bean;

import java.io.Serializable;

public class EmandateRequestOrderBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2614182125945989449L;
	private String receipt;
	private int amount;
	private String currency;
	private String method;
	private String productCode;
	private int payment_Capture;
	private boolean registration;

	public int getPayment_Capture() {
		return payment_Capture;
	}

	public void setPayment_Capture(int payment_Capture) {
		this.payment_Capture = payment_Capture;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public boolean isRegistration() {
		return registration;
	}

	public void setRegistration(boolean registration) {
		this.registration = registration;
	}

}