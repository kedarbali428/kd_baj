package com.bajaj.bfsd.common.domain;

import java.io.Serializable;
import java.util.List;
import java.util.concurrent.Future;

/**
 * Standard Response Bean 
 * @author 595327
 *
 */
public class ResponseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private transient Object payload;
	private StatusCode status;
	private List<ErrorBean> errorBean;
	
	public ResponseBean() {
		//Empty constructor
	}

	public ResponseBean(Object payload) {
		super();
		this.status = StatusCode.SUCCESS;
		this.payload = payload;
	}

	public ResponseBean(List<ErrorBean> errorBean) {
		super();
		this.status = StatusCode.FAILURE;
		this.errorBean = errorBean;
	}
	
	public ResponseBean(Object payload, List<ErrorBean> errorBean) {
		super();
		this.status = StatusCode.PARTIAL_SUCCESS;
		this.payload = payload;
		this.errorBean = errorBean;
	}

	public List<ErrorBean> getErrorBean() {
		return errorBean;
	}

	public void setErrorBean(List<ErrorBean> errorBean) {
		this.errorBean = errorBean;
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}

	public StatusCode getStatus() {
		return status;
	}

	public void setStatus(StatusCode status) {
		this.status = status;
	}
	
	@Override
	public String toString(){
		return "status : "+status+", payload: "+payload +" error:" + errorBean +" ";
	}
}
