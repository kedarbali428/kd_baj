package com.bajaj.bfsd.common.domain;

/**
 * Status code for business scnearios
 * @author 595327
 *
 */
public enum StatusCode {

	SUCCESS, FAILURE, PARTIAL_SUCCESS
	
}
