package com.bajaj.bfsd.common.domain;

import java.io.Serializable;

/**
 * Bean for handling error scenarios
 * @author 595327
 *
 */
public class ErrorBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private String errorCode;
	private String errorMessage;
	
	public ErrorBean(){
		//Empty constructor
	}
	
	public ErrorBean(String errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	@Override
	public String toString(){
		return "errorCode : "+errorCode+", errorMessage: "+errorMessage;
	}
}
