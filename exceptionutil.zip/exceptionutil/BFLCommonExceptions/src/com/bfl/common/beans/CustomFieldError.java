package com.bfl.common.beans;

public class CustomFieldError {
	private String fieldName;
	private String errorMessage;
	private String objectName;
	
	public CustomFieldError(String objectName, String fieldName, String errorMessage) {
		this.errorMessage = errorMessage;
		this.objectName = objectName;
		this.fieldName = fieldName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public String getObjectName() {
		return objectName;
	}	
}
