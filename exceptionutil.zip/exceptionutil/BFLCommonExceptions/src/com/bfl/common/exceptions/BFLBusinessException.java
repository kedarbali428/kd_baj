package com.bfl.common.exceptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.core.env.Environment;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bfl.common.beans.CustomFieldError;

public class BFLBusinessException extends BFLException
{
	private static final long serialVersionUID = -4229087891456998375L;

	private final transient Errors errors;
	private final List<FieldError> fieldErrors;
	private final transient List<CustomFieldError> customFieldError;
	private final String isCamelValidationError;
	
	private static final String FIELD_NAME = "Field name : ";
	private static final String MESSAGE = ", Message : ";
	private static final String STR_FALSE = "false";
	private static final String STR_TRUE = "true";
	
	public BFLBusinessException(String code, Throwable cause, Map<String, String> params) {
		super(code, cause, params);
		this.isCamelValidationError = STR_FALSE;
		this.customFieldError = null;
		this.errors = null;
		this.fieldErrors=null;
	}

	public BFLBusinessException(String code, String message, Map<String, String> params) {
		super(code, message,params);
		this.isCamelValidationError = STR_FALSE;
		this.customFieldError = null;
		this.errors = null;
		this.fieldErrors=null;
	}
	
	public BFLBusinessException(List<FieldError> fieldErrors) {
		super();
		this.fieldErrors=fieldErrors;
		this.isCamelValidationError = STR_FALSE;
		this.customFieldError = null;
		this.errors = null;
	}
	
	public BFLBusinessException(boolean isCamelValidationError, List<CustomFieldError> customFieldError) {
		super();
		this.customFieldError=customFieldError;
		this.isCamelValidationError = String.valueOf(isCamelValidationError);
		this.errors = null;
		this.fieldErrors=null;
	}

	public BFLBusinessException(String code, String message) {
		super(code, message);
		this.isCamelValidationError = STR_FALSE;
		this.customFieldError = null;
		this.errors = null;
		this.fieldErrors=null;
	}
	
	public BFLBusinessException() {
		super();
		this.isCamelValidationError = STR_FALSE;
		this.customFieldError = null;
		this.errors = null;
		this.fieldErrors=null;
	}

	public Errors getErrors() {
		return errors;
	}

	public List<FieldError> getFieldErrors() {
		return fieldErrors;
	}

	public List<CustomFieldError> getCustomFieldError() {
		return customFieldError;
	}

	public String getIsCamelValidationError() {
		return isCamelValidationError;
	}

	@Override
	public ResponseBean handleException(Environment env) {
		
		List<ErrorBean> errorBeans = new ArrayList<>();
		if(null != this.getFieldErrors() && !this.getFieldErrors().isEmpty()){
			List<FieldError> errorsList = this.getFieldErrors();
			for (FieldError fieldError : errorsList) {
				ErrorBean errorBean = new ErrorBean(fieldError.getDefaultMessage(),
						FIELD_NAME+fieldError.getField()+MESSAGE+env.getProperty(fieldError.getDefaultMessage()));
				errorBeans.add(errorBean);
			}
		}else if(null != this.getIsCamelValidationError() && STR_TRUE.equals(this.getIsCamelValidationError())){
			List<CustomFieldError> customErrorsList = this.getCustomFieldError();
			for (CustomFieldError fieldError : customErrorsList) {
				ErrorBean errorBean = new ErrorBean(fieldError.getErrorMessage(),
						FIELD_NAME+fieldError.getFieldName()+MESSAGE+env.getProperty(fieldError.getErrorMessage()));
				errorBeans.add(errorBean);
			}
		}else {
			ErrorBean errorBean = new ErrorBean(this.getCode(), customMessage(env));
			errorBeans.add(errorBean);
		}
		return new ResponseBean(errorBeans);
	
	}
	
	//overloaded option for camel services 
		public ResponseBean handleException(Properties prop) {
			List<ErrorBean> errorBeans = new ArrayList<>();
			if(null != this.getFieldErrors() && !this.getFieldErrors().isEmpty()){
				List<FieldError> errorsList = this.getFieldErrors();
				for (FieldError fieldError : errorsList) {
					ErrorBean errorBean = new ErrorBean(fieldError.getDefaultMessage(),
							FIELD_NAME+fieldError.getField()+MESSAGE+prop.getProperty(fieldError.getDefaultMessage()));
					errorBeans.add(errorBean);
				}
			}else if(null != this.getIsCamelValidationError() && STR_TRUE.equals(this.getIsCamelValidationError())){
				List<CustomFieldError> customErrorsList = this.getCustomFieldError();
				for (CustomFieldError fieldError : customErrorsList) {
					ErrorBean errorBean = new ErrorBean(fieldError.getErrorMessage(),
							FIELD_NAME+fieldError.getFieldName()+MESSAGE+prop.getProperty(fieldError.getErrorMessage()));
					errorBeans.add(errorBean);
				}
			}else {
				ErrorBean errorBean = new ErrorBean(this.getCode(), customMessage(prop));
				errorBeans.add(errorBean);
			}
			return new ResponseBean(errorBeans);
		}
}
