package com.bfl.common.exceptions;

import java.util.Map;
import java.util.Properties;

import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.domain.ResponseBean;

public abstract class BFLException extends RuntimeException {

	private static final long serialVersionUID = 5876110090863964597L;
	protected final String code;
	protected Map<String,String> params;
	
	public BFLException() {
		super();
		code=null;
		params=null;
	}
	
	public BFLException(String code, String message) {
		super(message);
		this.code = code;
	}
	
	public BFLException(String code, Throwable cause) {
		super(code, cause);
		this.code = code;
	}
	
	public BFLException(String code, String message, Map<String,String> params) {
		super(message);
		this.code = code;
		this.params = params;
	}
	
	public BFLException(String code, Throwable cause,Map<String,String> params) {
		super(code, cause);
		this.code = code;
		this.params = params;
	}

	public String getCode() {
		return code;
	}
	
	public Map<String, String> getParams() {
		return params;
	}
	
	protected String customMessage(Properties prop) {
		String message = prop.getProperty(this.getCode());
		if (this.getParams() != null && this.getParams().size() > 0) {
			for (String key : this.getParams().keySet()) {
				message = message.replaceAll("{"+key+"}", this.getParams().get(key));
			}
			return message;
		} else {
			return message;
		}
	}
	
	protected String customMessage(Environment env) {
		String message = env.getProperty(this.getCode()) != null ? env.getProperty(this.getCode()) : "";
		if (this.getParams() != null && this.getParams().size() > 0) {
			for (String key : this.getParams().keySet()) {
				message = message.replaceAll("\\{" + key + "\\}", this.getParams().get(key));
			}
			return message;
		} else {
			return message;
		}
	}

	public abstract ResponseBean handleException(Environment env);
}
