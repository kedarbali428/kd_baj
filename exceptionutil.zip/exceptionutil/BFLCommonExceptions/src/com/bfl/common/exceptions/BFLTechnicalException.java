package com.bfl.common.exceptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;

public class BFLTechnicalException extends BFLException {

	private static final long serialVersionUID = -5081197387222403104L;

	public BFLTechnicalException() {
		super();
	}

	public BFLTechnicalException(String code, Throwable cause) {
		super(code, cause);
	}

	public BFLTechnicalException(String code, String message) {
		super(code, message);
	}

	public BFLTechnicalException(String code, Throwable cause, Map<String, String> params) {
		super(code, cause, params);
	}

	public BFLTechnicalException(String code, String message, Map<String, String> params) {
		super(code, message, params);
	}

	@Override
	public ResponseBean handleException(Environment env) {
		List<ErrorBean> errorBeans = new ArrayList<>();
		if (null != this.getCause()) {
			//ErrorBean errorBean = new ErrorBean(this.getCode(), env.getProperty(this.getCode()));
			ErrorBean errorBean = new ErrorBean(this.getCode(), customMessage(env));
			errorBeans.add(errorBean);
		} else {
			//ErrorBean errorBean = new ErrorBean(this.getCode(), env.getProperty(this.getCode()));
			ErrorBean errorBean = new ErrorBean(this.getCode(), customMessage(env));
			errorBeans.add(errorBean);
		}
		return new ResponseBean(errorBeans);

	}

	// overloaded option for camel services
	public ResponseBean handleException(Properties prop) {
		List<ErrorBean> errorBeans = new ArrayList<>();
		if (null != this.getCause()) {
			//ErrorBean errorBean = new ErrorBean(this.getCode(), prop.getProperty(this.getCode()));
			ErrorBean errorBean = new ErrorBean(this.getCode(), customMessage(prop));
			errorBeans.add(errorBean);
		} else {
			//ErrorBean errorBean = new ErrorBean(this.getCode(), prop.getProperty(this.getCode()));
			ErrorBean errorBean = new ErrorBean(this.getCode(), customMessage(prop));
			errorBeans.add(errorBean);
		}
		return new ResponseBean(errorBeans);
	}

	
}
