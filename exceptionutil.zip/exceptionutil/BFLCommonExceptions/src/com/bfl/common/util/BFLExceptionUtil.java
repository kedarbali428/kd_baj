/**
 * 
 */
package com.bfl.common.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;

/**
 * @author 595327
 *
 */
public class BFLExceptionUtil  {
	private static final String BFSD_500 = "BFSD_500";
	private BFLExceptionUtil(){
	}
	
	public static ResponseBean handle(Exception ex, Environment env) {
		List<ErrorBean> errorBeans = new ArrayList<>();
		ResponseBean responseBean;
		if(ex instanceof BFLHttpException){
			responseBean = ((BFLHttpException) ex).handleException(env);
		}else if(ex instanceof BFLBusinessException) {
			responseBean = ((BFLBusinessException) ex).handleException(env);
		}else if (ex instanceof BFLTechnicalException) {
			responseBean = ((BFLTechnicalException) ex).handleException(env);
		} else {
			ErrorBean errorBean = new ErrorBean(BFSD_500, env.getProperty(BFSD_500));
			errorBeans.add(errorBean);	
			responseBean = new ResponseBean(errorBeans);
		}
		return responseBean;
	}
	
		//overloaded option for camel services
	public static ResponseBean handle(Exception ex, Properties prop) {
		List<ErrorBean> errorBeans = new ArrayList<>();
		ResponseBean responseBean;
		if(ex instanceof BFLHttpException){
			responseBean = ((BFLHttpException) ex).handleException(prop);
		}else if(ex instanceof BFLBusinessException) {
			responseBean = ((BFLBusinessException) ex).handleException(prop);
		}else if (ex instanceof BFLTechnicalException) {
			responseBean = ((BFLTechnicalException) ex).handleException(prop);
		} else {
			ErrorBean errorBean = new ErrorBean(BFSD_500, prop.getProperty(BFSD_500));
			errorBeans.add(errorBean);	
			responseBean = new ResponseBean(errorBeans);
		}
		return responseBean;
	}
	
}