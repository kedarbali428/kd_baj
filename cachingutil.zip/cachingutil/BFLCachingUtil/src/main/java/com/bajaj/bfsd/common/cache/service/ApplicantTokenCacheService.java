package com.bajaj.bfsd.common.cache.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.cache.service.entity.ApplicantToken;

@Component
public class ApplicantTokenCacheService {

	SingleObjectCacheRepositoryImpl<String,ApplicantToken> cacheRepository;
	
	@Autowired
	protected Environment env;
	
	@Autowired
	protected RedisConfig redisConfig;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASSNAME = ApplicantTokenCacheService.class.getName();
	
	public ApplicantToken get(String token) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE,"token : "+token);
		return getCacheRepository().find(token);
	}
	
	public void save(String token,ApplicantToken applicantToken) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE,"in save token key : "+token+" and value applicantkey : "+applicantToken.getApplicantId()+"token : "+applicantToken.getToken());
		 getCacheRepository().save(token, applicantToken);
	}
	
	public void update(String token,ApplicantToken applicantToken) {
		getCacheRepository().update(token, applicantToken);
	}
	
	public void delete(String token) {
		getCacheRepository().delete(token);
	}	
	
	private SingleObjectCacheRepositoryImpl<String, ApplicantToken> getCacheRepository()
	{
		if(null == this.cacheRepository){
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(ApplicantToken.class, env, redisConfig);			
		}	
		return cacheRepository;
	}	
}
