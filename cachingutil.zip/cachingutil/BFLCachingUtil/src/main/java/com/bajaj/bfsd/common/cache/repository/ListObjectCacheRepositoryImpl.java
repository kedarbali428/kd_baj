package com.bajaj.bfsd.common.cache.repository;

public class ListObjectCacheRepositoryImpl {
	
	@Override
	public String toString() {
		return super.toString();
	}

}
