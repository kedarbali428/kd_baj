package com.bajaj.bfsd.common.cache.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.cache.service.entity.SessionBean;

@Component
public class AuthenticationSessionCacheService {

	SingleObjectCacheRepositoryImpl<String, SessionBean> cacheRepository;

	@Autowired
	protected Environment env;

	@Autowired
	protected RedisConfig redisConfig;

	public SessionBean get(String sessionId, long ttl) {
		return getCacheRepository().find(sessionId, ttl);
	}

	public void save(String sessionId, SessionBean additionalInfo, long ttl) {
		getCacheRepository().save(sessionId, additionalInfo, ttl);
	}

	public SessionBean get(String sessionId) {
		return getCacheRepository().find(sessionId);
	}
	
	public void update(String sessionId, SessionBean additionalInfo, long ttl) {
		getCacheRepository().update(sessionId, additionalInfo, ttl);
	}

	public void delete(String sessionId) {
		getCacheRepository().delete(sessionId);
	}
	
	private SingleObjectCacheRepositoryImpl<String, SessionBean> getCacheRepository() {
		if (null == this.cacheRepository) {
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(SessionBean.class, env, redisConfig);
		}
		return cacheRepository;
	}
}
