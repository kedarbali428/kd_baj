package com.bajaj.bfsd.common.cache.service.entity;

import java.io.Serializable;

public class InsuranceFieldSetDataEntity implements Serializable{

	private static final long serialVersionUID = -468333335320200073L;
	private long inFieldSetKey;
	private long inFieldSetCode;
	private String inFieldSetName;
	private long inTabKey;
	private long inProdMastKey;
	private long inSubProdKey;
	private long inFilterFlag;
	/**
	 * @return the inFieldSetKey
	 */
	public long getInFieldSetKey() {
		return inFieldSetKey;
	}
	/**
	 * @param inFieldSetKey the inFieldSetKey to set
	 */
	public void setInFieldSetKey(long inFieldSetKey) {
		this.inFieldSetKey = inFieldSetKey;
	}
	
	/**
	 * @return the inFieldSetCode
	 */
	public long getInFieldSetCode() {
		return inFieldSetCode;
	}
	/**
	 * @param inFieldSetCode the inFieldSetCode to set
	 */
	public void setInFieldSetCode(long inFieldSetCode) {
		this.inFieldSetCode = inFieldSetCode;
	}
	/**
	 * @return the inFieldSetName
	 */
	public String getInFieldSetName() {
		return inFieldSetName;
	}
	/**
	 * @param inFieldSetName the inFieldSetName to set
	 */
	public void setInFieldSetName(String inFieldSetName) {
		this.inFieldSetName = inFieldSetName;
	}
	/**
	 * @return the inTabKey
	 */
	public long getInTabKey() {
		return inTabKey;
	}
	/**
	 * @param inTabKey the inTabKey to set
	 */
	public void setInTabKey(long inTabKey) {
		this.inTabKey = inTabKey;
	}
	/**
	 * @return the inProdMastKey
	 */
	public long getInProdMastKey() {
		return inProdMastKey;
	}
	/**
	 * @param inProdMastKey the inProdMastKey to set
	 */
	public void setInProdMastKey(long inProdMastKey) {
		this.inProdMastKey = inProdMastKey;
	}
	/**
	 * @return the inSubProdKey
	 */
	public long getInSubProdKey() {
		return inSubProdKey;
	}
	/**
	 * @param inSubProdKey the inSubProdKey to set
	 */
	public void setInSubProdKey(long inSubProdKey) {
		this.inSubProdKey = inSubProdKey;
	}
	
	/**
	 * @return the inFilterFlag
	 */
	public long getInFilterFlag() {
		return inFilterFlag;
	}
	/**
	 * @param inFilterFlag the inFilterFlag to set
	 */
	public void setInFilterFlag(long inFilterFlag) {
		this.inFilterFlag = inFilterFlag;
	}
}