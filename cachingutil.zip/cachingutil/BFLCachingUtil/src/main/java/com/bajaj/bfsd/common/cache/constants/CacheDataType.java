package com.bajaj.bfsd.common.cache.constants;

public enum CacheDataType {
	PLAINOBJECT,HASHOBJECT, LISTOBJECT,SETOBJECT	
}