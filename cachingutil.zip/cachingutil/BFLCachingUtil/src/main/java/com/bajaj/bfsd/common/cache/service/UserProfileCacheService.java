package com.bajaj.bfsd.common.cache.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.cache.service.entity.UserProfileEntity;

@Component
public class UserProfileCacheService {

	SingleObjectCacheRepositoryImpl<String, UserProfileEntity> cacheRepository;

	@Autowired
	protected Environment env;

	@Autowired
	protected RedisConfig redisConfig;

	private static final String USER_PROFILE_PREFIX ="PROFILE-";
	
	public UserProfileEntity get(long userId){
		return getCacheRepository().find(USER_PROFILE_PREFIX+userId);
	}
	
	public void save(long userId, UserProfileEntity entity) {
		getCacheRepository().save(USER_PROFILE_PREFIX+userId, entity);
	}

	public void update(long userId, UserProfileEntity entity) {
		getCacheRepository().update(USER_PROFILE_PREFIX+userId, entity);
	}

	public void delete(long userId) {
		getCacheRepository().delete(USER_PROFILE_PREFIX+userId);
	}

	private SingleObjectCacheRepositoryImpl<String, UserProfileEntity> getCacheRepository()
	{
		if(null == this.cacheRepository){
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(UserProfileEntity.class, env, redisConfig);			
		}
		
		return cacheRepository;
	}
}