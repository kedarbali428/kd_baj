package com.bajaj.bfsd.common.cache.service.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class ShoppingCartEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6703749007382482448L;

	private String applicantId;
	private Set<ShoppingCartProduct> productList;
	
	
	public ShoppingCartEntity(String applicantId) {
		super();
		this.applicantId = applicantId;
		this.productList = new HashSet<>();
	}
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	public Set<ShoppingCartProduct> getProductList() {
		return productList;
	}
	public void setProductList(Set<ShoppingCartProduct> productList) {
		this.productList = productList;
	}
	
	@Override
	public String toString() {
		return "ShoppingCartEntity [applicantId=" + applicantId + ", productList=" + productList + "]";
	}
	
	
}
