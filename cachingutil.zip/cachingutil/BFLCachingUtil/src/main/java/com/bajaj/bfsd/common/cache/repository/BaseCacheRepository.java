package com.bajaj.bfsd.common.cache.repository;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.constants.CacheDataType;
import com.bajaj.bfsd.common.cache.util.BFLCommonCacheUtility;

public abstract class BaseCacheRepository {
	protected String cacheKey;
	protected CacheDataType dataType = CacheDataType.PLAINOBJECT;
	protected Long ttl = 0L;

	protected Environment env;
	
	protected RedisConfig redisConfig;
	
	private Properties props;
	
	public BaseCacheRepository(Environment env, RedisConfig redisConfig){
		this.env = env;
		this.redisConfig = redisConfig;
		this.props = BFLCommonCacheUtility.getProperties("cachingutil.properties");
	}
	protected Long getTTL(String cacheKey){
		this.ttl = null; //15 mins
		if(null != cacheKey){
		String propTTL = (null != props.get(cacheKey)) ? ((String) props.get(cacheKey)) : null; 
		
		if(null != propTTL){
			this.ttl = Long.parseLong(propTTL);
		}
		}
		return ttl;
	}
	
	protected void setTTL(){
		//redisConfig.getRedisTemplate().opsForValue().
		if(null != redisConfig){
			RedisTemplate<String,Object> template = redisConfig.getRedisTemplate();
			if(null != template && null != cacheKey &&  null != getTTL(cacheKey)){
				template.expire(cacheKey, getTTL(cacheKey), TimeUnit.MINUTES);	
			}
		}
	}

	protected Long getOtpTTL(String cacheKey) {
		this.ttl = null; // 15 mins
		if (null != cacheKey) {
			String propTTL = (null != props.get(cacheKey)) ? ((String) props.get(cacheKey)) : null;
			if (null != propTTL) {
				this.ttl = Long.parseLong(propTTL);
			}
		}
		return ttl;
	}

	protected void setOtpTTL() {
		if (null != redisConfig) {
			RedisTemplate<String, Object> template = redisConfig.getRedisTemplate();
			if (null != template && null != cacheKey && null != getOtpTTL(cacheKey)) {
				template.expire(cacheKey, getOtpTTL(cacheKey), TimeUnit.MINUTES);
			}
		}
	}

	protected String getCacheKey() {
		return cacheKey;
	}

	protected abstract void setCacheKey();
}
