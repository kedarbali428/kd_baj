package com.bajaj.bfsd.common.cache.service.entity;

import java.io.Serializable;

public class LoanFieldSetDataEntity implements Serializable{

	private static final long serialVersionUID = -468333335320200073L;
	private long lnFieldSetKey;
	private long lnFieldSetCode;
	private String lnFieldSetName;
	private long lnTabKey;
	private long lnProdMastKey;
	private long lnSubProdKey;
	private long lnFilterFlag;
	/**
	 * @return the lnFieldSetKey
	 */
	public long getLnFieldSetKey() {
		return lnFieldSetKey;
	}
	/**
	 * @param lnFieldSetKey the lnFieldSetKey to set
	 */
	public void setLnFieldSetKey(long lnFieldSetKey) {
		this.lnFieldSetKey = lnFieldSetKey;
	}
	/**
	 * @return the lnFieldSetCode
	 */
	public long getLnFieldSetCode() {
		return lnFieldSetCode;
	}
	/**
	 * @param lnFieldSetCode the lnFieldSetCode to set
	 */
	public void setLnFieldSetCode(long lnFieldSetCode) {
		this.lnFieldSetCode = lnFieldSetCode;
	}
	/**
	 * @return the lnFieldSetName
	 */
	public String getLnFieldSetName() {
		return lnFieldSetName;
	}
	/**
	 * @param lnFieldSetName the lnFieldSetName to set
	 */
	public void setLnFieldSetName(String lnFieldSetName) {
		this.lnFieldSetName = lnFieldSetName;
	}
	/**
	 * @return the lnTabKey
	 */
	public long getLnTabKey() {
		return lnTabKey;
	}
	/**
	 * @param lnTabKey the lnTabKey to set
	 */
	public void setLnTabKey(long lnTabKey) {
		this.lnTabKey = lnTabKey;
	}
	/**
	 * @return the lnProdMastKey
	 */
	public long getLnProdMastKey() {
		return lnProdMastKey;
	}
	/**
	 * @param lnProdMastKey the lnProdMastKey to set
	 */
	public void setLnProdMastKey(long lnProdMastKey) {
		this.lnProdMastKey = lnProdMastKey;
	}
	/**
	 * @return the lnSubProdKey
	 */
	public long getLnSubProdKey() {
		return lnSubProdKey;
	}
	/**
	 * @param lnSubProdKey the lnSubProdKey to set
	 */
	public void setLnSubProdKey(long lnSubProdKey) {
		this.lnSubProdKey = lnSubProdKey;
	}
	/**
	 * @return the lnFilterFlag
	 */
	public long getLnFilterFlag() {
		return lnFilterFlag;
	}
	/**
	 * @param lnFilterFlag the lnFilterFlag to set
	 */
	public void setLnFilterFlag(long lnFilterFlag) {
		this.lnFilterFlag = lnFilterFlag;
	}
	
}
