package com.bajaj.bfsd.common.cache.service.entity;

import java.io.Serializable;

public class ApplicantToken implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2193496574514079311L;
	
	private String applicantId;
	private String token;
	
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	

	
	
}
