package com.bajaj.bfsd.common.cache.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

@Configuration
@ComponentScan("com.*")
public class RedisConfig {

	RedisTemplate<String, Object> redisTemplate;
	static HashOperations<String, Object, Object> hashOperations;
	static ValueOperations<String, Object> valueOperations;

	@Autowired
	RedisConfigPropertiesConfigurer redisConfigPropertiesConfigurer;

	@RefreshScope
	@Bean
	JedisConnectionFactory jedisConnectionFactory() {

		JedisConnectionFactory jedisConFactory;
		if (redisConfigPropertiesConfigurer.getIsClusterSetup()) {
			RedisClusterConfiguration redisClusterConfiguration = new RedisClusterConfiguration();
			redisClusterConfiguration.clusterNode(redisConfigPropertiesConfigurer.getCacheHost(),
					redisConfigPropertiesConfigurer.getCachePort());
			jedisConFactory = new JedisConnectionFactory(redisClusterConfiguration);
		} else {
			jedisConFactory = new JedisConnectionFactory();
		}
		
		jedisConFactory.setHostName(redisConfigPropertiesConfigurer.getCacheHost());
		jedisConFactory.setPort(redisConfigPropertiesConfigurer.getCachePort());
		jedisConFactory.setTimeout(redisConfigPropertiesConfigurer.getCacheTimeout());
		jedisConFactory.setUsePool(true);
				
		return jedisConFactory;
	}

	@RefreshScope
	@Bean
	public RedisTemplate<String, Object> redisTemplate() {
		final RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
		template.setConnectionFactory(jedisConnectionFactory());
		// template.setValueSerializer(new
		// GenericToStringSerializer<Object>(Object.class));
		setRedisTemplate(template);
		return template;
	}

	@RefreshScope
	@Bean
	@DependsOn("redisTemplate")
	public HashOperations<String, Object, Object> hashOperations() {
		HashOperations<String, Object, Object> hashOperations = getRedisTemplate().opsForHash();
		RedisConfig.setHashOperations(hashOperations);
		return hashOperations;

	}

	@RefreshScope
	@Bean
	@DependsOn("redisTemplate")
	public ValueOperations<String, Object> valueOpertions() {
		ValueOperations<String, Object> valueOperations = getRedisTemplate().opsForValue();
		RedisConfig.setValueOperations(valueOperations);
		return valueOperations;
	}

	private static void setValueOperations(ValueOperations<String, Object> valueOperations2) {
		valueOperations = valueOperations2;
	}

	public static ValueOperations<String, Object> getValueOperations() {
		return valueOperations;
	}

	public RedisTemplate<String, Object> getRedisTemplate() {
		return redisTemplate;
	}

	public void setRedisTemplate(RedisTemplate<String, Object> redisTemplate) {
		this.redisTemplate = redisTemplate;
	}

	private static void setHashOperations(HashOperations<String, Object, Object> hashOperation) {
		hashOperations = hashOperation;
	}

	public static HashOperations<String, Object, Object> getHashOperations() {
		return hashOperations;
	}
}