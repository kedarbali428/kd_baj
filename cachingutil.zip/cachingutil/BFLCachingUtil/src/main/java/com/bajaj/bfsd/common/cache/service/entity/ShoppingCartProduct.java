package com.bajaj.bfsd.common.cache.service.entity;

import java.io.Serializable;

public class ShoppingCartProduct implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String productId;
	private String productDesc;
	private int quantity = 1;
	private Double makingCharges;
	private Double weight;
	

	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Double getMakingCharges() {
		return makingCharges;
	}
	public void setMakingCharges(Double makingCharges) {
		this.makingCharges = makingCharges;
	}
	public Double getWeight() {
		return weight;
	}
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((productId == null) ? 0 : productId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ShoppingCartProduct other = (ShoppingCartProduct) obj;
		if (productId == null) {
			if (other.productId != null)
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ShoppingCartProduct [productId=" + productId + ", productDesc=" + productDesc + ", quantity=" + quantity
				+ ", makingCharges=" + makingCharges + ", weight=" + weight + "]";
	}
	
	
	
}
