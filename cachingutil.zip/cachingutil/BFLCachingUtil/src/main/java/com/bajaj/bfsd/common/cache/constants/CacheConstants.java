package com.bajaj.bfsd.common.cache.constants;

public class CacheConstants {
	
	public static final String CACHE_REGION_PREFIX_LIST = "collection_";
	public static final String CACHE_REGION_PREFIX_HASH_MAP = "hash_";
	public static final String CACHE_REGION_PREFIX_SET = "set_";
	public static final String CACHE_REGION_PREFIX_PLAIN_OBJ = "";
	public static final String CACHE_REGION_PREFIX_DEFAULT = "default";
	
	private CacheConstants(){
		//empty constructor
	}
}
