package com.bajaj.bfsd.common.cache.service.entity;

import java.io.Serializable;

public class LoanProviderEntity implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 6495892102018724225L;
	/**
	 * Loan Provider name ie. PLF, HFC
	 */
	private String lnProviderName;

	/**
	 * @return the lnProviderName
	 */
	public String getLnProviderName() {
		return lnProviderName;
	}

	/**
	 * @param lnProviderName the lnProviderName to set
	 */
	public void setLnProviderName(String lnProviderName) {
		this.lnProviderName = lnProviderName;
	}
	
}
