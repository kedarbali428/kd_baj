package com.bajaj.bfsd.common.cache.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLTechnicalException;

public class BFLCommonCacheUtility {
	
	private BFLCommonCacheUtility() {

	}
	
	private static final String className = BFLCommonCacheUtility.class.getName();

	/**
	 * Method to return properties file
	 * @param propertyFileName
	 * @return
	 */
	public static Properties getProperties(String propertyFileName) {
		Properties propObj = new Properties();
		InputStream input = null;

		try {
			input = BFLCommonCacheUtility.class.getClassLoader().getResourceAsStream(propertyFileName);
			if (input != null) {
				propObj.load(input);
			}
		} catch (IOException ex) {
			BFLLoggerUtil.error(null, className, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonCacheUtility : Unable to read config file. " + ex.getMessage());
			throw new BFLTechnicalException("CORE-005", ex);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					BFLLoggerUtil.error(null, className, BFLLoggerComponent.UTILITY,
							"BFLCommonClient BFLCommonCacheUtility : Exception in closing stream " ,e);
				}
			}
		}
		return propObj;
	}
}