package com.bajaj.bfsd.common.cache.repository;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.ValueOperations;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.constants.CacheConstants;
import com.bajaj.bfsd.common.cache.constants.CacheDataType;

/**
 * This class is responsible for doing cache operations. Currently it support Redis. There are multiple ways this class should be able to used
 * 1. For plain object - In this scenario though object is part of a logical group but they are independent and have their own life cycle (TTL) - Example Tokens, Users
 * 2. Collection object - In this scenario whole collection will be put in cache and all the object within the collection are related. Collection has TTL not the individual objects with collection - Example Reference data, master data   
 * Cache Key is string though this class will accept all the primitive types but internally will convert to string. Same approach can support user defined type but currently not developing that in mind and not testing the same
 * TTL has to be configured in configuration file and key would be based on the type which is being stored in the cache, this will be determined at runtime
 *  
 * @author 228670
 *
 * @param <K> - Key type 
 * @param <V> - Value Type
 */
@PropertySource("classpath:cachingutil.properties")
public class SingleObjectCacheRepositoryImpl<K,V> extends BaseCacheRepository implements CacheRepository<K,V> {

	
	private Class<V> type;
		
	public SingleObjectCacheRepositoryImpl(Class<V> valueType, Environment env, RedisConfig redisConfig) {
		super(env, redisConfig);
		this.type = valueType;
		setCacheKey();
		setTTL();
	}

	public SingleObjectCacheRepositoryImpl(Class baseType, CacheDataType dataType, Environment env, RedisConfig redisConfig) {
		super(env, redisConfig);
		this.type = baseType;
		this.dataType = dataType;
		setCacheKey();
		setTTL();
	}	

	private ValueOperations<String, Object> getValueOperations(){
		return RedisConfig.getValueOperations();
	}
	
	@Override
	protected void setCacheKey() {
		if (null != type){
			this.cacheKey = type.getSimpleName();
			this.cacheKey = cacheKey == null? "":cacheKey.toLowerCase();
		}
		
		this.cacheKey = CacheConstants.CACHE_REGION_PREFIX_PLAIN_OBJ + cacheKey;
	}

	@Override
	public void save(K key, V value) {
		if(null != getTTL(cacheKey)){
			getValueOperations().set(getValueKey(key), value, getTTL(cacheKey), TimeUnit.MINUTES);	
		}else{
			getValueOperations().set(getValueKey(key), value);
		}
		
	}
	
	
	@Override
	public V find(K key) {		
		Object obj = getValueOperations().get(getValueKey(key));
		if (null != obj) {
			V cacheObj = (V) obj;
			if(null != getTTL(cacheKey)){
				getValueOperations().getOperations().expire(getValueKey(key), getTTL(cacheKey), TimeUnit.MINUTES);	
			}
			return cacheObj;
		}
		return null;
	}	
	
	
	@Override
	public void update(K key, V value) {
		if(null != getTTL(cacheKey)){
			getValueOperations().set(getValueKey(key), value, getTTL(cacheKey), TimeUnit.MINUTES);
		}else{
			getValueOperations().set(getValueKey(key), value);
		}
	}	

	@Override
	public Map<K, V> findAll() {
		// For single object there is no "all"
		return null;
	}

	@Override
	public void delete(K key) {
		redisConfig.getRedisTemplate().delete(getValueKey(key));
	}
		
	protected String getValueKey(K key){
		if(null != key)
			return getCacheKey() + "_" + key.toString();
		return getCacheKey()+ "_" + "null";
	}
	
	@Override
	public void save(K key, V value, Long ttl) {
		getValueOperations().set(getValueKey(key), value, ttl, TimeUnit.MINUTES);
	}

	@Override
	public void update(K key, V value, Long ttl) {
		getValueOperations().set(getValueKey(key), value, ttl, TimeUnit.MINUTES);
	}

	@Override
	public V find(K key, Long ttl) {
		Object obj = getValueOperations().get(getValueKey(key));
		if (null != obj) {
			V cacheObj = (V) obj;
			getValueOperations().getOperations().expire(getValueKey(key), ttl, TimeUnit.MINUTES);	
			return cacheObj;
		}
		return null;
	}	
}