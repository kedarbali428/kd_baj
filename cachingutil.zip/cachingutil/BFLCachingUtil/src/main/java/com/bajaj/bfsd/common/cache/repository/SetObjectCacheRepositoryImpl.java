package com.bajaj.bfsd.common.cache.repository;

public class SetObjectCacheRepositoryImpl {

	@Override
	public String toString() {
		return super.toString();
	}
}
