package com.bajaj.bfsd.common.cache.service.entity;

import java.io.Serializable;

public class CardsFieldSetDataEntity implements Serializable{

	private static final long serialVersionUID = -468333335320200073L;
	private long cardsFieldSetKey;
	private long cardsSubProdKey;
	/**
	 * @return the cardsFieldSetKey
	 */
	public long getCardsFieldSetKey() {
		return cardsFieldSetKey;
	}
	/**
	 * @param cardsFieldSetKey the cardsFieldSetKey to set
	 */
	public void setCardsFieldSetKey(long cardsFieldSetKey) {
		this.cardsFieldSetKey = cardsFieldSetKey;
	}
	
	/**
	 * @return the cardsSubProdKey
	 */
	public long getCardsSubProdKey() {
		return cardsSubProdKey;
	}
	/**
	 * @param cardsSubProdKey the cardsSubProdKey to set
	 */
	public void setCardsSubProdKey(long cardsSubProdKey) {
		this.cardsSubProdKey = cardsSubProdKey;
	}
	
}