package com.bajaj.bfsd.common.cache.repository;

import java.util.Map;

public interface CacheRepository<K, V> {

    void save(final K key, V value);

    void update(final K key, V value);

    V find(final K key);

    Map<K, V> findAll();

    void delete(final K key);

	void save(final K key, V value, Long ttl);
	
	void update(final K key, V value, Long ttl);
	
	V find(final K key, Long ttl);
}