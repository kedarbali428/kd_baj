package com.bajaj.bfsd.common.cache.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.cache.service.entity.LoanProviderEntity;

@Component
public class LoanProviderSetCacheService {

	SingleObjectCacheRepositoryImpl<String, LoanProviderEntity> cacheRepository;

	@Autowired
	protected Environment env;

	@Autowired
	protected RedisConfig redisConfig;

	public LoanProviderEntity get(String product) {
		return getCacheRepository().find(product);
	}

	public void save(String product, LoanProviderEntity entity) {
		getCacheRepository().save(product, entity);
	}

	public void delete(String product) {
		getCacheRepository().delete(product);
	}

	private SingleObjectCacheRepositoryImpl<String, LoanProviderEntity> getCacheRepository() {
		if (null == this.cacheRepository) {
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(LoanProviderEntity.class, env, redisConfig);
		}

		return cacheRepository;
	}
}
