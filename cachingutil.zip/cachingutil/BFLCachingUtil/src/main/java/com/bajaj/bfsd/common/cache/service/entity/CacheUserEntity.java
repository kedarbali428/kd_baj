package com.bajaj.bfsd.common.cache.service.entity;

import java.io.Serializable;

public class CacheUserEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -468333335320200073L;
	private long userKey;
	private long userRoleKey;
	private String userCurrentRoleName;
	private long roleKey;
	
	public long getUserKey() {
		return userKey;
	}
	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}
	public long getUserRoleKey() {
		return userRoleKey;
	}
	public void setUserRoleKey(long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}
	public String getUserCurrentRoleName() {
		return userCurrentRoleName;
	}
	public void setUserCurrentRoleName(String userCurrentRoleName) {
		this.userCurrentRoleName = userCurrentRoleName;
	}
	public long getRoleKey() {
		return roleKey;
	}
	public void setRoleKey(long roleKey) {
		this.roleKey = roleKey;
	}
	
}
