package com.bajaj.bfsd.common.cache.repository;

import java.util.Map;

import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.HashOperations;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.constants.CacheConstants;
import com.bajaj.bfsd.common.cache.constants.CacheDataType;

public class HashMapObjectCacheRepositoryImpl<K,V> extends BaseCacheRepository implements CacheRepository<K,V> {


	private Class<V> type;

	public HashMapObjectCacheRepositoryImpl(Class<V> valueType, Environment env, RedisConfig redisConfig) {
		super(env, redisConfig);
		this.type = valueType;
		setCacheKey();
		setTTL();
	}

	public HashMapObjectCacheRepositoryImpl(Class baseType, CacheDataType dataType, Environment env, RedisConfig redisConfig) {
		super(env, redisConfig);
		this.type = baseType;
		this.dataType = dataType;
		setCacheKey();
		setTTL();
	}

	private HashOperations<String, Object,Object> getHashOperations() {
		return RedisConfig.getHashOperations();
	}	
	
	@Override
	protected void setCacheKey() {
		if (null != type){
			this.cacheKey = type.getSimpleName();
			this.cacheKey = cacheKey == null? "":cacheKey.toLowerCase();
		}
		
		this.cacheKey = CacheConstants.CACHE_REGION_PREFIX_HASH_MAP + cacheKey;
	}

	@Override
	public void save(K key, V value) {
		getHashOperations().put(getCacheKey(), key, value);
	}

	@Override
	public void update(K key, V value) {
		getHashOperations().put(getCacheKey(), key, value);
	}

	@Override
	public V find(K key) {
		Object obj = getHashOperations().get(getCacheKey(), key);
		if (null != obj) {
			return (V) obj;
		}
		return null;
	}	

	@Override
	public Map<K, V> findAll() {
		Object cacheObj = getHashOperations().entries(getCacheKey());
		if (null != cacheObj) {
			return (Map<K, V>) cacheObj;
		}
		return null;
	}

	@Override
	public void delete(K key) {
		getHashOperations().delete(getCacheKey(), key);
	}
	
	public void save(K key, V value, Long ttl) {
		//Hash Ops is not having ttl set functionality with its current version hence putting this method empty
	}

	@Override
	public void update(K key, V value, Long ttl) {
		//Hash Ops is not having ttl set functionality with its current version hence putting this method empty
	}

	@Override
	public V find(K key, Long ttl) {
		//Hash Ops is not having ttl set functionality with its current version hence putting this method empty
		return null;
	}
}