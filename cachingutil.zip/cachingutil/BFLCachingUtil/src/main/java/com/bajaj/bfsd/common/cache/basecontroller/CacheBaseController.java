package com.bajaj.bfsd.common.cache.basecontroller;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.cache.service.UserCacheService;
import com.bajaj.bfsd.common.cache.service.entity.CacheUserEntity;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;

/**
 * Description of the class This class is the controller class for the View
 * Management Service
 *
 * @author Cognizant - Date - 27/02/2017
 * 
 *         Version BugId UsrId Date Description 1.0 27/02/2017
 *
 */
@RefreshScope
@RestController
public class CacheBaseController {

	@Autowired
	protected CustomDefaultHeaders customdefaultheaders;

	@Autowired
	private UserCacheService cacheService;

	@Inject
	protected BFLLoggerUtilExt logger; // NOSONAR

	private static final String CLASS_NAME = CacheBaseController.class.getCanonicalName();

	public long getUserRoleKey() {
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "GetUserRoleKey - finding current user's userRoleKey");
		Long userrolekey = -1L;
		CacheUserEntity currentUser = cacheService.get(customdefaultheaders.getUserKey());
		if (null != currentUser) {
			userrolekey = currentUser.getUserRoleKey();
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "GetUserRoleKey -" + userrolekey);
		} else {
			// return -1 in this case, we might need to throw an exception
			return userrolekey;
		}
		return userrolekey;
	}

	public long getActiveRoleKey() {
		logger.info(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"getActiveRoleKey - finding current user's active role key");
		Long rolekey = -1L;
		CacheUserEntity currentUser = cacheService.get(customdefaultheaders.getUserKey());
		if (null != currentUser) {
			rolekey = currentUser.getRoleKey();
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getActiveRoleKey -" + rolekey);
		} else {
			// return -1 in this case, we might need to throw an exception
			return rolekey;
		}
		return rolekey;
	}

}