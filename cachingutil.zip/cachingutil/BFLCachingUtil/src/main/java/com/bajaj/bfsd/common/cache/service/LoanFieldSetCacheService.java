package com.bajaj.bfsd.common.cache.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.cache.service.entity.LoanFieldSetDataEntity;

@Component
public class LoanFieldSetCacheService {

	SingleObjectCacheRepositoryImpl<String, LoanFieldSetDataEntity> cacheRepository;

	@Autowired
	protected Environment env;

	@Autowired
	protected RedisConfig redisConfig;

	public LoanFieldSetDataEntity get(Long subProdKey) {
		return getCacheRepository().find(subProdKey.toString());
	}

	public void save(Long subProdKey, LoanFieldSetDataEntity entity) {
		getCacheRepository().save(subProdKey.toString(), entity);
	}

	public void delete(Long subProdKey) {
		getCacheRepository().delete(subProdKey.toString());
	}

	private SingleObjectCacheRepositoryImpl<String, LoanFieldSetDataEntity> getCacheRepository() {
		if (null == this.cacheRepository) {
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(LoanFieldSetDataEntity.class, env, redisConfig);
		}

		return cacheRepository;
	}
}
