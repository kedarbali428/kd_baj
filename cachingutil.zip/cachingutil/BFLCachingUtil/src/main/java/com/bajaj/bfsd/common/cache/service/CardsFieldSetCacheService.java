package com.bajaj.bfsd.common.cache.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.cache.service.entity.CardsFieldSetDataEntity;

@Component
public class CardsFieldSetCacheService {

	SingleObjectCacheRepositoryImpl<String, CardsFieldSetDataEntity> cacheRepository;

	@Autowired
	protected Environment env;

	@Autowired
	protected RedisConfig redisConfig;

	public CardsFieldSetDataEntity get(Long subProdKey) {
		return getCacheRepository().find(subProdKey.toString());
	}

	public void save(Long subProdKey, CardsFieldSetDataEntity entity) {
		getCacheRepository().save(subProdKey.toString(), entity);
	}

	public void delete(Long subProdKey) {
		getCacheRepository().delete(subProdKey.toString());
	}

	private SingleObjectCacheRepositoryImpl<String, CardsFieldSetDataEntity> getCacheRepository() {
		if (null == this.cacheRepository) {
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(CardsFieldSetDataEntity.class, env, redisConfig);
		}

		return cacheRepository;
	}
}
