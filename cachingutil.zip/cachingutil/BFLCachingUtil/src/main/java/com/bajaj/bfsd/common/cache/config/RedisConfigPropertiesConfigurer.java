package com.bajaj.bfsd.common.cache.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@RefreshScope
@Component
public class RedisConfigPropertiesConfigurer {

	@Value("${bfl.cache.host}")
	private String cacheHost;
	
	@Value("${bfl.cache.port}")
	private int cachePort;
	
	@Value("${bfl.cache.timeout}")
	private int cacheTimeout;
	
	
	@Value("${bfl.cache.isclustersetup}")
	private boolean isClusterSetup;

	public String getCacheHost() {
		return cacheHost;
	}

	public void setCacheHost(String cacheHost) {
		this.cacheHost = cacheHost;
	}

	public int getCachePort() {
		return cachePort;
	}

	public void setCachePort(int cachePort) {
		this.cachePort = cachePort;
	}

	public int getCacheTimeout() {
		return cacheTimeout;
	}

	public void setCacheTimeout(int cacheTimeout) {
		this.cacheTimeout = cacheTimeout;
	}

	public boolean getIsClusterSetup() {
		return isClusterSetup;
	}

	public void setIsClusterSetup(boolean isClusterSetup) {
		this.isClusterSetup = isClusterSetup;
	}	
	
}