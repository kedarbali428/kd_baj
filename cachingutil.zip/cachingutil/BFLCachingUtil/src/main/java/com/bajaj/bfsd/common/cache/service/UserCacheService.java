package com.bajaj.bfsd.common.cache.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.cache.service.entity.CacheUserEntity;

@Component
public class UserCacheService {

	SingleObjectCacheRepositoryImpl<String, CacheUserEntity> cacheRepository;
	
	@Autowired
	protected Environment env;
		
	@Autowired
	protected RedisConfig redisConfig;
	
	public CacheUserEntity get(Long userId){
		return getCacheRepository().find(userId.toString());
	}
	
	public void save(Long userId, CacheUserEntity entity){
		getCacheRepository().save(userId.toString(), entity);
	}
	
	public void delete(Long userId){
		getCacheRepository().delete(userId.toString());
	}
	
	private SingleObjectCacheRepositoryImpl<String, CacheUserEntity> getCacheRepository()
	{
		if(null == this.cacheRepository){
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(CacheUserEntity.class, env, redisConfig);			
		}
		
		return cacheRepository;
	}
}
