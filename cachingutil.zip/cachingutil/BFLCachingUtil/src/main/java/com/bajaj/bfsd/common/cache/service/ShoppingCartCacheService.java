package com.bajaj.bfsd.common.cache.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.common.cache.service.entity.ShoppingCartEntity;



@Component
public class ShoppingCartCacheService {

	private SingleObjectCacheRepositoryImpl<String, ShoppingCartEntity> cacheRepository;

	@Autowired
	protected Environment env;

	@Autowired
	protected RedisConfig redisConfig;

	private static final String SHOPPING_CART_PREFIX ="SHOPPING_CART-";
	
	public ShoppingCartEntity get(String key){
		return getCacheRepository().find(SHOPPING_CART_PREFIX+key);
	}
	
	public void save(String key, ShoppingCartEntity entity) {
		getCacheRepository().save(SHOPPING_CART_PREFIX+key, entity);
	}

	public void update(String key, ShoppingCartEntity entity) {
		getCacheRepository().update(SHOPPING_CART_PREFIX+key, entity);
	}

	public void delete(String key) {
		getCacheRepository().delete(SHOPPING_CART_PREFIX+key);
	}

	private SingleObjectCacheRepositoryImpl<String, ShoppingCartEntity> getCacheRepository()
	{
		if(null == this.cacheRepository){
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(ShoppingCartEntity.class, env, redisConfig);			
		}
		
		return cacheRepository;
	}
}
