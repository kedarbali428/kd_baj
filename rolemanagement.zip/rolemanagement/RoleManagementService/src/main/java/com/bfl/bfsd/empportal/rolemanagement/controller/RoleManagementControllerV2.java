package com.bfl.bfsd.empportal.rolemanagement.controller;


import static com.bajaj.bfsd.common.BFLLoggerComponent.CONTROLLER;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.CNTR_MSG1;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.CNTR_MSG2;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.CNTR_MSG3;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.CNTR_MSG4;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.CNTR_MSG5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerHeader;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.cache.basecontroller.CacheBaseController;
import com.bajaj.bfsd.common.cache.service.UserCacheService;
import com.bajaj.bfsd.common.cache.service.entity.CacheUserEntity;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.FieldSetGroupBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationResponseBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleTabKeyAndNameResponse;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabResponse;
import com.bfl.bfsd.empportal.rolemanagement.bean.UserRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.beanmapper.BeanMapperV2;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetRolesL3DTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetSubSectionRolesL3DTO;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetGroupL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetMasterL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.plugin.OMRoleManagementDataPluginMapper;
import com.bfl.bfsd.empportal.rolemanagement.service.RoleManagementService;
import com.bfl.bfsd.empportal.rolemanagement.util.RoleManagementUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * Description of the class
 * This class is the controller class for the Role Management Service
 *
 * @author Cognizant - Date - 27/02/2017
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                                       27/02/2017
 *
 */
@RestController
@ComponentScans(value = {@ComponentScan("com.bfl.bfsd.empportal.rolemanagement"),@ComponentScan("com.bajaj.bfsd.common")})
//@RequestMapping("${rolemanagement.base.url}")
public class RoleManagementControllerV2 extends CacheBaseController
{
	
	@Autowired
	RoleManagementService roleManagementService;
	
	/**@Inject
    @RequestScoped*/
    @Autowired
    BFLLoggerUtil logger1;
	@Autowired
	Environment env1;
	@Autowired
	BeanMapperV2 beanMapper1;
	@Autowired
	private UserCacheService cacheService1;
	@Autowired
	private CustomDefaultHeaders customHeader1;
	@Autowired
	OMRoleManagementDataPluginMapper dataPluginMapper;
	
	private static final String CLASS_NAME = RoleManagementControllerV2.class.getCanonicalName();

	/**
	 * @Desc This is Controller method for creating the view
	 * @param bean
	 * @param headers 
	 * @return ResponseEntity
	 * @throws BFLTechnicalException 
	 */
	@ApiOperation(value = "Get The Master Tab details ", notes = "Get The Master Tab details", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.tab.POST.V2.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getTabDetailsBasedonL3(@RequestBody RoleAccessConfigurationBean roleAccessConfigBean,@RequestHeader HttpHeaders headers)  {
	
		
		logger1.setCorrelationID(customHeader1.getCmptcorrid());
		logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleManagementControllerV2 : Fetch Master tab role mgmnt Service execution invoked");
		RoleAccessConfigurationBean roleAccConfig= new RoleAccessConfigurationBean();
		try {
			
			logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG4 +customHeader1.getUserKey());
			roleAccConfig= roleManagementService.getTabDetailsBasedonL3(roleAccessConfigBean);
			String prodMastCode = roleManagementService.getProdMastCode(roleAccessConfigBean.getProductTypeKey());
			switch(prodMastCode) {
			case "OMCREDIT":
				roleAccConfig = roleManagementService.fetchCommonTabsMappedForOm(roleAccConfig, roleAccessConfigBean);
				List<TabBean> omTabBeanList = dataPluginMapper.getTabBeanList(roleAccessConfigBean.getProductTypeKey(), roleAccessConfigBean.getSubprodkey().get(0),roleAccessConfigBean.getRoleKeys(), headers);
				roleAccConfig.getTabBeanList().addAll(omTabBeanList);
				break;
				
			case "OMINS":
				roleAccConfig = roleManagementService.fetchCommonTabsMappedForOm(roleAccConfig, roleAccessConfigBean);
				List<TabBean> omInsurnaceTabBeanList = dataPluginMapper.getTabBeanListOmIns(roleAccessConfigBean.getProductTypeKey(), roleAccessConfigBean.getSubprodkey().get(0),roleAccessConfigBean.getRoleKeys(), headers);
				roleAccConfig.getTabBeanList().addAll(omInsurnaceTabBeanList);
				break;
			}
			//roleAccConfig = roleManagementService.fetchCommonTabsMappedForOm(roleAccConfig, roleAccessConfigBean);
			List<TabBean> omOfferTabBeanList = dataPluginMapper.getTabBeanListOmOffer(roleAccessConfigBean.getRoleKeys(), headers);
			roleAccConfig.getTabBeanList().addAll(omOfferTabBeanList);
			
			logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG5);
		
		} 
		catch (BFLBusinessException exception) {
			logger1.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exception occured while config role(TABDETAILS) : "+RoleManagementUtil.getExceptionTrace(exception, logger1.getCorrelationID()));
			throw new BFLBusinessException("ROLEMGT_7003",env1.getProperty("ROLEMGT_7003"));			
		} 
		

		logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleManagementController : TAB configuration Service execution completed");
		return new ResponseEntity<>(new ResponseBean(roleAccConfig), HttpStatus.OK);
	}

	private UserRoleBean setCacheUserRole(UserRoleBean userRoleBean){
			
			UserRoleBean dbUserRole = roleManagementService.getUserRole(userRoleBean.getUserKey(), userRoleBean.getUserRoleKey());
			
			CacheUserEntity cacheUser = new CacheUserEntity();
			
			cacheUser.setUserKey(dbUserRole.getUserKey());
			cacheUser.setUserCurrentRoleName(dbUserRole.getRoleName());
			cacheUser.setUserRoleKey(dbUserRole.getUserRoleKey());
			cacheUser.setRoleKey(dbUserRole.getRoleKey());
			
			cacheService1.save(cacheUser.getUserKey(), cacheUser);
			
			return dbUserRole;
		}
	
	@ApiOperation(value = "Get The Group, Section and sub Section details.", notes = "Get The Group, Section and sub Section details.", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.group.section.subsection.details.POST.V2.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> fetchAllGroupSectionAndSubSectionDetailsBasedonL3(@RequestBody RoleAccessConfigurationBean roleAccessBean,@RequestHeader HttpHeaders headers)  {
		logger1.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		try {
			logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start fetching groups, section and sub section details for input :"+roleAccessBean);
			List<FieldSetGroupL3> list = roleManagementService.fetchGroupsSectinoAndsubSectionforUserBasedonL3(roleAccessBean);
			beanMapper1.prepareResponseForGroupsAndSectionL3(roleAccessBean, list);
			logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching groups details.");
			if(CollectionUtils.isEmpty(roleAccessBean.getFieldSetGroups())) {
				String prodMastCode = roleManagementService.getProdMastCode(roleAccessBean.getProductTypeKey());
				
				if(roleAccessBean.getTabName().contains("OM-Product Offering")) {
					List<FieldSetGroupBean> omOffereGroupBeanList = dataPluginMapper.getGroupsDataListOmOffer(roleAccessBean.getProductTypeKey(), roleAccessBean.getSubprodkey().get(0),roleAccessBean.getTabKeys(),roleAccessBean.getRoleKeys(), headers, roleAccessBean.getProdCatCode(),"0");
					roleAccessBean.getFieldSetGroups().addAll(omOffereGroupBeanList);
				}else {
					switch(prodMastCode) {
					case "OMCREDIT":
						List<FieldSetGroupBean> omGroupBeanList = dataPluginMapper.getGroupsDataList(roleAccessBean.getProductTypeKey(), roleAccessBean.getSubprodkey().get(0),roleAccessBean.getTabKeys(),roleAccessBean.getRoleKeys(), headers);
						roleAccessBean.getFieldSetGroups().addAll(omGroupBeanList);
						break;
					
					case "OMINS":
						List<FieldSetGroupBean> omInsuranceGroupBeanList = dataPluginMapper.getGroupsDataListOmIns(roleAccessBean.getProductTypeKey(), roleAccessBean.getSubprodkey().get(0),roleAccessBean.getTabKeys(),roleAccessBean.getRoleKeys(), headers);
						roleAccessBean.getFieldSetGroups().addAll(omInsuranceGroupBeanList);
						break;
					}	
				}
				
			}
			
		} catch (BFLBusinessException eexception) {
			logger1.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Hibernate Exception occured while fetching groups details: "+RoleManagementUtil.getExceptionTrace(eexception, logger1.getCorrelationID()));
			throw new BFLBusinessException("ROLEMGT_7007", env1.getProperty("ROLEMGT_7007"));
		} 
		logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching groups, section and sub section details for input");
		return new ResponseEntity<>(new ResponseBean(roleAccessBean), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.POST, value ="${api.rolemanagement.edit.roleaccessconfig.POST.V2.uri}")
	@ApiOperation(value = "Get The Group, Section and sub Section details for edit case.", notes = "Get The Group, Section and sub Section details for edit case.", httpMethod = "POST")
	@CrossOrigin
	public ResponseEntity<ResponseBean> fetchAllGroupSectionAndSubSectionDetailsForEditBasedonL3(@PathVariable(name= "roleKey") long roleKey,
			@RequestBody RoleAccessConfigurationBean roleAccessConfigBean,
			@RequestHeader HttpHeaders headers)  {
		
		logger1.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		List<FieldSetGroupBean> fieldSetGroupBeans = null;
		try {
			logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start fetching groups, section and sub section details for input role for edit :" +roleKey + " And tab keys :"+roleAccessConfigBean.getTabKeys());
			List<Long> tabKeysList = roleAccessConfigBean.getTabKeys();
			List<Long> subprodkey = roleAccessConfigBean.getSubprodkey();			
			FieldSetGroupAndFieldSetSubSectionRolesL3DTO dto = roleManagementService.fetchGroupsSectinoAndsubSectionforUserInEditViewBasedonL3(Arrays.asList(roleKey),tabKeysList,roleAccessConfigBean.getProductTypeKey(),subprodkey);
			FieldSetRoleL3 fieldsetrole  =dto.getFieldSetRoles().get(0);
			long rolekey=fieldsetrole.getRoleProductMapping().getRoleprodkey();
			fieldSetGroupBeans = beanMapper1.prepareResponseForGroupsAndSectionForEditCase(dto,rolekey);
			
			String prodMastCode = roleManagementService.getProdMastCode(roleAccessConfigBean.getProductTypeKey());
			switch(prodMastCode) {
			case "OMCREDIT":
				if(CollectionUtils.isEmpty(fieldSetGroupBeans)) {
					fieldSetGroupBeans.addAll(new ArrayList<FieldSetGroupBean>());
				}
				List<FieldSetGroupBean> omGroupBeanList = dataPluginMapper.getGroupDataEditList(roleAccessConfigBean.getProductTypeKey(), roleAccessConfigBean.getSubprodkey().get(0), roleAccessConfigBean.getTabKeys(), Arrays.asList(roleKey), headers);
				fieldSetGroupBeans.addAll(omGroupBeanList);
				break;
			
			
			case "OMINS":
				if (CollectionUtils.isEmpty(fieldSetGroupBeans)) {
					fieldSetGroupBeans.addAll(new ArrayList<FieldSetGroupBean>());
				}
				List<FieldSetGroupBean> omInsGroupBeanList = dataPluginMapper.getGroupDataEditListOmIns(roleAccessConfigBean.getProductTypeKey(), roleAccessConfigBean.getSubprodkey().get(0),roleAccessConfigBean.getTabKeys(), Arrays.asList(roleKey), headers);
				fieldSetGroupBeans.addAll(omInsGroupBeanList);
				break;
			}
			
				List<FieldSetGroupBean> omOffereGroupBeanList = dataPluginMapper.getGroupsDataListOmOffer(roleAccessConfigBean.getProductTypeKey(), roleAccessConfigBean.getSubprodkey().get(0),roleAccessConfigBean.getTabKeys(),Arrays.asList(roleKey), headers, roleAccessConfigBean.getProdCatCode(),"1");
				fieldSetGroupBeans.addAll(omOffereGroupBeanList);
			logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching groups details for edit.");
		}
		catch (BFLBusinessException except) {
			logger1.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, " Exception occured while fetching group n subsection : "+RoleManagementUtil.getExceptionTrace(except, logger1.getCorrelationID()));
			throw new BFLBusinessException("ROLEMGT_7021",  env1.getProperty("ROLEMGT_7021"));
		}  
		logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching groups, section and sub section details for input role for edit.");
		return new ResponseEntity<>(new ResponseBean(fieldSetGroupBeans), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get The UIFields details for selected Group, Section and SubSections.", notes = "Get The UIFields details for selected Group, Section and SubSections.", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.uifields.POST.V2.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUIFieldsForSelectedSectionAndSubSectionsBasedonL3(@RequestBody RoleAccessConfigurationBean roleAccessConBean,@RequestHeader HttpHeaders headers)  {
	
		
		logger1.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Request came for fetching All Fields details for selected group, section and subsection : "+roleAccessConBean);
		try {
			FieldSetGroupAndFieldSetRolesL3DTO dto = roleManagementService.fetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3(roleAccessConBean);
			List <FieldSetMasterL3> fieldsetmaster = roleManagementService.fetchFieldSetMaster(roleAccessConBean);

			List<FieldSetGroupBean> fieldSetGroupBeans = beanMapper1.prepareGroupsWithSubSectionsL3(dto, roleAccessConBean,fieldsetmaster );
			roleAccessConBean.setFieldSetGroups(fieldSetGroupBeans);
			
			String prodMastCode = roleManagementService.getProdMastCode(roleAccessConBean.getProductTypeKey());
			switch(prodMastCode) {
			case "OMCREDIT":
				if(CollectionUtils.isEmpty(roleAccessConBean.getFieldSetGroups())) {
					roleAccessConBean.setFieldSetGroups(new ArrayList<FieldSetGroupBean>());
				}
				List<FieldSetGroupBean> omGroupBeanList = dataPluginMapper.getFieldsDataList(roleAccessConBean.getProductTypeKey(), roleAccessConBean.getSubprodkey().get(0), roleAccessConBean.getTabKeys(), roleAccessConBean.getRoleKeys(),roleAccessConBean.getGroupKeys(),roleAccessConBean.getSectionKeys(),roleAccessConBean.getSubSectionKeys(), headers);
				roleAccessConBean.getFieldSetGroups().addAll(omGroupBeanList);
				break;
				
			case "OMINS":
				if(CollectionUtils.isEmpty(roleAccessConBean.getFieldSetGroups())) {
					roleAccessConBean.setFieldSetGroups(new ArrayList<FieldSetGroupBean>());
				}
				List<FieldSetGroupBean> omInsGroupBeanList = dataPluginMapper.getFieldsDataListOmIns(roleAccessConBean.getProductTypeKey(), roleAccessConBean.getSubprodkey().get(0), roleAccessConBean.getTabKeys(), roleAccessConBean.getRoleKeys(),roleAccessConBean.getGroupKeys(),roleAccessConBean.getSectionKeys(),roleAccessConBean.getSubSectionKeys(), headers);
				roleAccessConBean.getFieldSetGroups().addAll(omInsGroupBeanList);
				break;
			}
			
			if (roleAccessConBean.getTabName().contains("OM-Product Offering")) {
				if(CollectionUtils.isEmpty(roleAccessConBean.getFieldSetGroups())) {
					roleAccessConBean.setFieldSetGroups(new ArrayList<FieldSetGroupBean>());
				}
				List<Long> productOfferTabs = new ArrayList<>();
				productOfferTabs.add(1236L);
				List<FieldSetGroupBean> omGroupBeanList = dataPluginMapper.getFieldsDataListForOmOffer(roleAccessConBean.getProductTypeKey(), roleAccessConBean.getSubprodkey().get(0), productOfferTabs, roleAccessConBean.getRoleKeys(),roleAccessConBean.getGroupKeys(),roleAccessConBean.getSectionKeys(),roleAccessConBean.getSubSectionKeys(),roleAccessConBean.getProdCatCode(),headers);
				roleAccessConBean.getFieldSetGroups().addAll(omGroupBeanList);
				
			}
			logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching ui fields for selected group, section and subsection : "+roleAccessConBean);
		
		} catch (BFLBusinessException hiexception) {
			logger1.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exception occured while fetching ui fields : "+RoleManagementUtil.getExceptionTrace(hiexception, logger1.getCorrelationID()));
			throw new BFLBusinessException("ROLEMGT_7009", env1.getProperty("ROLEMGT_7009"));
		}  
		logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching ui fields.");
		return new ResponseEntity<>(new ResponseBean(roleAccessConBean), HttpStatus.OK);
	}
	
	@CrossOrigin
	@ApiOperation(value = "Save details for selected product,role,tabs,ctas and fields access details.", notes = "Save details for selected product,role,tabs,ctas and fields access details.")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.role.access.configuration.POST.V2.uri}")
	public ResponseEntity<ResponseBean> saveTabCtaConfiguration(
			@Valid @RequestBody RoleAccessConfigurationInputBean inputBean, 
			BindingResult bindingResult,
			@RequestHeader HttpHeaders headers)  {
		logger1.debug(CLASS_NAME, CONTROLLER, "Controller invoked!!");
		validateRequest(bindingResult);
		logger1.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger1.debug(CLASS_NAME, CONTROLLER, CNTR_MSG1);
		boolean successFlag = false;
		
		String prodMastCode = roleManagementService.getProdMastCode(inputBean.getProductkey());
		//OM Call
		if (prodMastCode.equalsIgnoreCase("OMCREDIT")) {
			roleManagementService.updateBauDependantAccessForOm(inputBean);
			successFlag = dataPluginMapper.updatedRoleAccessDetails(inputBean, headers);
		} else if (prodMastCode.equalsIgnoreCase("OMINS")) {
			roleManagementService.updateBauDependantAccessForOm(inputBean);
			successFlag = dataPluginMapper.updatedRoleAccessDetailsOmIns(inputBean, headers);
		} else {
			successFlag = roleManagementService.saveRoleAccessconfigurationsBasedonL3(inputBean);
		}
		RoleAccessConfigurationResponseBean result = prepareRespponse(successFlag);
		logger1.debug(CLASS_NAME, CONTROLLER, CNTR_MSG2+result);
		return new ResponseEntity<>(new ResponseBean(result), HttpStatus.OK);
	}
	
	private void validateRequest(BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			logger1.error(CLASS_NAME, CONTROLLER, CNTR_MSG3);
			throw new BFLBusinessException(bindingResult.getFieldErrors());
		}
	}
	
	private RoleAccessConfigurationResponseBean prepareRespponse(boolean successFlag) {
		RoleAccessConfigurationResponseBean bean = new RoleAccessConfigurationResponseBean();
		bean.setIsRoleAccessConfigurationSuccessful(successFlag);
		return bean;
		
	}
	
	@ApiOperation(value = "Clone the role aceces from one role to another.", notes = "Clone the role aceces from one role to another.", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.clone.POST.V2.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> cloneRoleAccessConfiguration(@RequestBody CloneRoleAccessConfigureBean cloneRoleAccessConfigBean,@RequestHeader HttpHeaders headers)  {
	
		
		logger1.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleManagementController : clone service role mgmnt Service execution invoked");
		
		try {
			
			logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG4);
			
			roleManagementService.cloneRoleAccessConfigurationBasedonL3(cloneRoleAccessConfigBean);
			
			logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG5);
		
		} catch (BFLBusinessException hiberexception) {
			logger1.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, " Exception occured while cloning role : "+RoleManagementUtil.getExceptionTrace(hiberexception, logger1.getCorrelationID()));
			throw new BFLBusinessException("ROLEMGT_7020", env1.getProperty("ROLEMGT_7020"));
		}
		
		
		logger1.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleManagementController : role mgmt Service execution completed");
		return new ResponseEntity<>(new ResponseBean("SUCCESS"), HttpStatus.OK);
	}
	
	@CrossOrigin
	@ApiOperation(value = "Fetching tabkey and L3 products after logging", notes = "Fetching tabkey and L3 products after logging")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.GET, value = "${api.rolemanagement.tabs.L3products.GET.V2.uri}")
	public ResponseEntity<ResponseBean> getTabKeyAndProductsBasedonL3(@RequestParam ("userRoleKey") long userRoleKey ,@RequestHeader HttpHeaders headers){
		logger1.debug(CLASS_NAME, CONTROLLER, "Controller invoked");
		UserRoleBean roleBean = new UserRoleBean();
		roleBean.setUserRoleKey(userRoleKey);
		roleBean.setUserKey(customHeader1.getUserKey());
		roleBean = setCacheUserRole(roleBean);
		
		TabResponse response = new TabResponse();
		try{
		 response = roleManagementService.fetchTabKeyAndProducts(roleBean);
		 if(null != cacheService1.get(customHeader1.getUserKey())) {
			 String roleKey = String.valueOf(cacheService1.get(customHeader1.getUserKey()).getRoleKey());
			 List<RoleTabKeyAndNameResponse> omRoleTabResponseList = dataPluginMapper.getTabsBasedOnRole(roleKey, headers);
		     List<RoleTabKeyAndNameResponse> omInsRoleTabResponseList = dataPluginMapper.getTabsBasedOnRoleOmIns(roleKey, headers);
			 //List<RoleTabKeyAndNameResponse> omPocRoleTabResponseList = dataPluginMapper.getTabsBasedOnRolePoc(roleKey, headers);
			 List<RoleTabKeyAndNameResponse> omOfferRoleTabResponseList = dataPluginMapper.getTabsBasedOnRoleOffer(roleKey, headers);
			 response.getRoleTabKeyAndNameResponse().addAll(omRoleTabResponseList);
			 response.getRoleTabKeyAndNameResponse().addAll(omInsRoleTabResponseList);
			 //response.getRoleTabKeyAndNameResponse().addAll(omPocRoleTabResponseList);
			 response.getRoleTabKeyAndNameResponse().addAll(omOfferRoleTabResponseList);
			 Collections.sort(response.getRoleTabKeyAndNameResponse());
		 }
		
	
		} catch (Exception exception) {
			logger1.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,exception.getMessage());
			logger1.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Hibernate Exception occured while fetching tabs : "+RoleManagementUtil.getExceptionTrace(exception, logger1.getCorrelationID()));
			throw new BFLBusinessException("ROLEMGT_7019", env1.getProperty("ROLEMGT_7019"));
		}
			logger1.debug(CLASS_NAME, CONTROLLER, "successfully fetched tabs");
			return new ResponseEntity<>(new ResponseBean(response), HttpStatus.OK);
		}
	
}
