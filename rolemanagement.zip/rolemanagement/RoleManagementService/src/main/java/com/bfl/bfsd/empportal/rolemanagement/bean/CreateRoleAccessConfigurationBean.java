package com.bfl.bfsd.empportal.rolemanagement.bean;

import java.util.List;

public class CreateRoleAccessConfigurationBean {
	
/**	first page
 * 	private Long productType;
 *	private Long functionType;
 *	 private List<Long> userRole;
 *	 
 *	select tab page
 *	 private List<Long> tabs;
 *	 
 *	 Select CTA page --> Map it gainst Role or TAB??
 *	 
 *	 List<Long> selectedCTAKeys;
 *	 
 *	 Select UI field Configuration
 *	 List<UIFieldsSection> uiFieldSelection;
 *	 private List<CTAMappingBean> bean;
 */
		}

class UIFieldsSection{
	Long uiFieldKey;
	boolean readOnly;
	boolean editFlag;
}


class CTAMappingBean{
	String logicalSectionName;
	String logicalName;
	List<TopCTABean> topCTAs; 
	List<SubsectionBean> subsectionbean;
}
/**
*class TopCTABean{
*	String logicalSectionName;
*	Long sebsectionCTAKey;
}*/

class SubsectionBean{
	String logicalSectionName;
	Long sebsectionCTAKey;
}
