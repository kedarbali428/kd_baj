package com.bfl.bfsd.empportal.rolemanagement.constants;

public class RoleManagementMessageConstants {
	

	
	public static final String CNTR_MSG1 = "Started saving role access configurations for";
	public static final String CNTR_MSG2 = "Done with saving role access configuration with response :";
	public static final String CNTR_MSG3 = "Not Valid request for Role access Configuration.";
	public static final String CNTR_MSG4 = "RoleManagementController : Role Mgmt Service class completed";
	public static final String CNTR_MSG5 = "RoleManagementController : Role Mgmt Service class invoked";

	
	
	public static final String DAO_MSG1 = "Started saving role access configurations for input :";
	public static final String DAO_ERR_MSG1 = "Error occured while saving role access configurations. Rooling back all changes.";
	public static final String DAO_MSG2 = "Successfully saved role access configurations.";
	public static final String DAO_MSG3 = "Started saving HeaderTabRole for selected Tabs:";
	public static final String DAO_MSG4 = "Done with saving HeaderTabRole.";
	public static final String DAO_MSG5 = "Started saving FieldSetRoles for fieldAccessBeans:";
	public static final String DAO_MSG6 = "Done with saving FieldSetRoles.";
	public static final String DAO_MSG7 = "Started saving CtaRoles for CTA ID :";
	public static final String DAO_MSG8 = "Done with saving CtaRoles.";
	
	public static final String DAO_MSG9 = "Soft Deleted :";
	public static final String DAO_MSG10 = "Role Access configuration will be updated for :";
	public static final String DAO_MSG11 = "Creating CTA Product Keys list.";
	public static final String DAO_MSG12 = "CTA Product Keys list created :";
	public static final String DAO_MSG13 = "Started saving FieldSetSubsectionRoles :";
	public static final String DAO_MSG14 = "Done with saving FieldSetSubsectionRoles.";
	
	private RoleManagementMessageConstants() {
		
	};
}
