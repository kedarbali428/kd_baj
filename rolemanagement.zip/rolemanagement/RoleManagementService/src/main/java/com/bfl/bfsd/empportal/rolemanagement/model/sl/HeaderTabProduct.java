package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the HEADER_TAB_PRODUCTS database table.
 * 
 */
@Entity
@Table(name="HEADER_TAB_PRODUCTS")
@NamedQueries({
	//@NamedQuery(name="HeaderTabProduct.findAllL3", query="SELECT h FROM HeaderTabProduct h"),
@NamedQuery(name="HeaderTabProduct.findAllBySubprodkey", query="SELECT h FROM HeaderTabMasterL3 h "
		+ ",HeaderTabProduct hp "
		+ "where hp.isactive=1 and "
		+ "h.tabkey =hp.headerTabMaster.tabkey and "
		+ "h.isactive=1 AND (hp.prodmastkey = :prodkey or hp.prodmastkey is null)"
		+ " and (hp.subprodkey = :subprodkey or hp.subprodkey is null)")
})
public class HeaderTabProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long tabprodkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodmastkey;

	private BigDecimal subprodkey;

	//bi-directional many-to-one association to HeaderTabMaster
	@ManyToOne
	@JoinColumn(name="TABKEY")
	private HeaderTabMasterL3 headerTabMaster;

	public HeaderTabProduct() {
	}

	public long getTabprodkey() {
		return this.tabprodkey;
	}

	public void setTabprodkey(long tabprodkey) {
		this.tabprodkey = tabprodkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(BigDecimal prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public BigDecimal getSubprodkey() {
		return this.subprodkey;
	}

	public void setSubprodkey(BigDecimal subprodkey) {
		this.subprodkey = subprodkey;
	}

	public HeaderTabMasterL3 getHeaderTabMaster() {
		return this.headerTabMaster;
	}

	public void setHeaderTabMaster(HeaderTabMasterL3 headerTabMaster) {
		this.headerTabMaster = headerTabMaster;
	}

}