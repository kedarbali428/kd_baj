package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the APP_VIEW_SUMMARY_FIELDS database table.
 * 
 */
@Entity
@Table(name="APP_VIEW_SUMMARY_FIELDS")
//@NamedQuery(name="AppViewSummaryField.findAll", query="SELECT a FROM AppViewSummaryField a")
public class AppViewSummaryField implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long viewfieldkey;

	private BigDecimal displayorder;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to AppViewDefinition
	@ManyToOne
	@JoinColumn(name="VIEWKEY")
	private AppViewDefinition appViewDefinition;

	//bi-directional many-to-one association to FieldSetAttribute
	@ManyToOne
	@JoinColumn(name="FIELDKEY")
	private FieldSetAttribute fieldSetAttribute;

	public AppViewSummaryField() {
	}

	public long getViewfieldkey() {
		return this.viewfieldkey;
	}

	public void setViewfieldkey(long viewfieldkey) {
		this.viewfieldkey = viewfieldkey;
	}

	public BigDecimal getDisplayorder() {
		return this.displayorder;
	}

	public void setDisplayorder(BigDecimal displayorder) {
		this.displayorder = displayorder;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public AppViewDefinition getAppViewDefinition() {
		return this.appViewDefinition;
	}

	public void setAppViewDefinition(AppViewDefinition appViewDefinition) {
		this.appViewDefinition = appViewDefinition;
	}

	public FieldSetAttribute getFieldSetAttribute() {
		return this.fieldSetAttribute;
	}

	public void setFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		this.fieldSetAttribute = fieldSetAttribute;
	}

}