package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the USER_ROLE_PRODUCT database table.
 * 
 */
@Entity
@Table(name="USER_ROLE_PRODUCT")
//@NamedQuery(name="UserRoleProduct.findAll", query="SELECT u FROM UserRoleProduct u")
public class UserRoleProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long userprodkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodmastkey;

	private BigDecimal subprodtypekey;

	//bi-directional many-to-one association to UserRole
	@ManyToOne
	@JoinColumn(name="USERROLEKEY")
	private UserRole userRole;

	public UserRoleProduct() {
	}

	public long getUserprodkey() {
		return this.userprodkey;
	}

	public void setUserprodkey(long userprodkey) {
		this.userprodkey = userprodkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(BigDecimal prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public BigDecimal getSubprodtypekey() {
		return this.subprodtypekey;
	}

	public void setSubprodtypekey(BigDecimal subprodtypekey) {
		this.subprodtypekey = subprodtypekey;
	}

	public UserRole getUserRole() {
		return this.userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

}