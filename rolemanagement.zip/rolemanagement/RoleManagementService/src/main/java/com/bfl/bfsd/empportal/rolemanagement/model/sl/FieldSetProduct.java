package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the FIELD_SET_PRODUCT database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_PRODUCT")
//@NamedQuery(name="FieldSetProduct.findAll", query="SELECT f FROM FieldSetProduct f")
public class FieldSetProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long fieldprodkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodmastkey;

	private BigDecimal subprodtypekey;

	//bi-directional many-to-one association to FieldSetAttribute
	@ManyToOne
	@JoinColumn(name="FIELDKEY")
	private FieldSetAttributeL3 fieldSetAttribute;

	public FieldSetProduct() {
	}

	public long getFieldprodkey() {
		return this.fieldprodkey;
	}

	public void setFieldprodkey(long fieldprodkey) {
		this.fieldprodkey = fieldprodkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(BigDecimal prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public BigDecimal getSubprodtypekey() {
		return this.subprodtypekey;
	}

	public void setSubprodtypekey(BigDecimal subprodtypekey) {
		this.subprodtypekey = subprodtypekey;
	}

	public FieldSetAttributeL3 getFieldSetAttribute() {
		return this.fieldSetAttribute;
	}

	public void setFieldSetAttribute(FieldSetAttributeL3 fieldSetAttribute) {
		this.fieldSetAttribute = fieldSetAttribute;
	}

}