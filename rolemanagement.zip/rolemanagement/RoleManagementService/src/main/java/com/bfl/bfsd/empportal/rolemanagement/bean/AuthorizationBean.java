package com.bfl.bfsd.empportal.rolemanagement.bean;

public class AuthorizationBean {
	
	private Long userId;
	private String endPoint;
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getEndPoint() {
		return endPoint;
	}
	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}

	 
}
