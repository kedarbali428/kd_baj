package com.bfl.bfsd.empportal.rolemanagement.service;

import java.util.List;

import com.bfl.bfsd.empportal.rolemanagement.bean.AssignedRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleBasedUsersListResponceBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabResponse;
import com.bfl.bfsd.empportal.rolemanagement.bean.UserRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetRolesDTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetRolesL3DTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetSubSectionRolesDTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetSubSectionRolesL3DTO;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetGroup;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsection;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetGroupL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetMasterL3;

/**
 * Description of the interface This interface is for the Role Management
 * Service
 *
 * @author Cognizant - Date - 27/02/2017
 * 
 *         Version BugId UsrId Date Description 1.0 27/02/2017
 *
 */
public interface RoleManagementService  {

	RoleAccessConfigurationBean getTabDetails( RoleAccessConfigurationBean roleAccessConfigBean);

	RoleAccessConfigurationBean getCTADetails(RoleAccessConfigurationBean roleAccessConfigBean);

/**	RoleAccessConfigurationBean getUIFields(RoleAccessConfigurationBean roleAccessConfigBean);*/
		
	boolean saveRoleAccessconfigurations(RoleAccessConfigurationInputBean inputBean);

	RoleBasedUsersListResponceBean getUsersListOnRoleBased(Long roleKey, Long applicationkey);

	void cloneRoleAccessConfiguration(CloneRoleAccessConfigureBean cloneRoleAccessConfigBean);
	
	List<FieldSetGroup> fetchGroupsSectinoAndsubSectionforUser(RoleAccessConfigurationBean inputBean);
	
	FieldSetGroupAndFieldSetSubSectionRolesDTO fetchGroupsSectinoAndsubSectionforUserInEditView(List<Long> roleKeya,List<Long> tabkeys);

	List<FieldSetSubsection> fetchFieldsforGroupsSectinoAndsubSection(RoleAccessConfigurationBean roleAccessConfigBean);

	FieldSetGroupAndFieldSetRolesDTO fetchFieldsDetailsforGroupsSectinoAndsubSection(
			RoleAccessConfigurationBean roleAccessConfigBean);
	
	public Boolean checkRoleInUsersAssignedRolesHierarchy(AssignedRoleBean assignedRoleBean);
	
	public UserRoleBean getUserRole(long userKey, long userRoleKey);
	public boolean checkEmailCTAAccess(long applicationKey);

	/** HL End-points*/

	RoleAccessConfigurationBean getTabDetailsBasedonL3(RoleAccessConfigurationBean roleAccessConfigBean);

	FieldSetGroupAndFieldSetSubSectionRolesL3DTO fetchGroupsSectinoAndsubSectionforUserInEditViewBasedonL3(
			List<Long> roleKeys, List<Long> tabKeys, long prodkey, List <Long> subprodkey);

	List<FieldSetGroupL3> fetchGroupsSectinoAndsubSectionforUserBasedonL3(RoleAccessConfigurationBean roleAccessBean);

	FieldSetGroupAndFieldSetRolesL3DTO fetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3(
			RoleAccessConfigurationBean roleAccessConBean);

	boolean saveRoleAccessconfigurationsBasedonL3(RoleAccessConfigurationInputBean inputBean);

	void cloneRoleAccessConfigurationBasedonL3(CloneRoleAccessConfigureBean cloneRoleAccessConfigBean);

	TabResponse fetchTabKeyAndProducts(UserRoleBean roleBean);

	List<FieldSetMasterL3> fetchFieldSetMaster(RoleAccessConfigurationBean roleAccessBean);

	RoleAccessConfigurationBean getLinkAcess(RoleAccessConfigurationBean roleAccConfigBean);

	RoleAccessConfigurationBean getLinksAcess(long roleKey, long tabKey);

	String getProdMastCode(Long prodMastKey);

	boolean updateBauDependantAccessForOm(RoleAccessConfigurationInputBean roleAccessConfigurationInputBean);

	RoleAccessConfigurationBean fetchCommonTabsMappedForOm(RoleAccessConfigurationBean roleAccConfig,
			RoleAccessConfigurationBean roleAccessConfigBean);

}
