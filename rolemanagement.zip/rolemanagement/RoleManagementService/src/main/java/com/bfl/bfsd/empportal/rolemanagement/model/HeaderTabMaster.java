package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the HEADER_TAB_MASTER database table.
 * 
 */
@Entity
@Table(name="HEADER_TAB_MASTER")
@NamedQueries({
//@NamedQuery(name="HeaderTabMaster.findAll", query="SELECT h FROM HeaderTabMaster h"),
@NamedQuery(name="HeaderTabMaster.findAlltabkey", query="SELECT h FROM HeaderTabMaster h where tabkey in :tabkey")
//@NamedQuery(name="HeaderTabMaster.findAllBySubprodkey", query="SELECT h FROM HeaderTabMaster h "
//		+ ",HeaderTabProduct hp "
//		+ "where hp.isactive=1 and "
//		+ "h.tabkey =hp.headerTabMaster.tabkey and "
//		+ "h.isactive=1 AND hp.subprodkey IN :subprodkey")
})
public class HeaderTabMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long tabkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal tabcd;

	private String tabname;

	private BigDecimal vieworder;

	//bi-directional many-to-one association to HeaderTabRole
	@OneToMany(mappedBy="headerTabMaster")
	private List<HeaderTabRole> headerTabRoles;

	//bi-directional many-to-one association to HeaderTabCta
	@OneToMany(mappedBy="headerTabMaster")
	private List<HeaderTabCta> headerTabCtas;
	
	
	//bi-directional many-to-one association to HeaderTabLink
	@OneToMany(mappedBy="headerTabMaster")
	private List<HeaderTabLinks> headerTabLinks;

	//bi-directional many-to-one association to HeaderTabSection
	@OneToMany(mappedBy="headerTabMaster")
	private List<HeaderTabSection> headerTabSections;

	public HeaderTabMaster() {
	}

	public long getTabkey() {
		return this.tabkey;
	}

	public void setTabkey(long tabkey) {
		this.tabkey = tabkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getTabcd() {
		return this.tabcd;
	}

	public void setTabcd(BigDecimal tabcd) {
		this.tabcd = tabcd;
	}

	public String getTabname() {
		return this.tabname;
	}

	public void setTabname(String tabname) {
		this.tabname = tabname;
	}

	public BigDecimal getVieworder() {
		return this.vieworder;
	}

	public void setVieworder(BigDecimal vieworder) {
		this.vieworder = vieworder;
	}

	public List<HeaderTabRole> getHeaderTabRoles() {
		return this.headerTabRoles;
	}

	public void setHeaderTabRoles(List<HeaderTabRole> headerTabRoles) {
		this.headerTabRoles = headerTabRoles;
	}

	public HeaderTabRole addHeaderTabRole(HeaderTabRole headerTabRole) {
		getHeaderTabRoles().add(headerTabRole);
		headerTabRole.setHeaderTabMaster(this);

		return headerTabRole;
	}

	public HeaderTabRole removeHeaderTabRole(HeaderTabRole headerTabRole) {
		getHeaderTabRoles().remove(headerTabRole);
		headerTabRole.setHeaderTabMaster(null);

		return headerTabRole;
	}

	public List<HeaderTabCta> getHeaderTabCtas() {
		return this.headerTabCtas;
	}

	public void setHeaderTabCtas(List<HeaderTabCta> headerTabCtas) {
		this.headerTabCtas = headerTabCtas;
	}

	public HeaderTabCta addHeaderTabCta(HeaderTabCta headerTabCta) {
		getHeaderTabCtas().add(headerTabCta);
		headerTabCta.setHeaderTabMaster(this);

		return headerTabCta;
	}

	public HeaderTabCta removeHeaderTabCta(HeaderTabCta headerTabCta) {
		getHeaderTabCtas().remove(headerTabCta);
		headerTabCta.setHeaderTabMaster(null);

		return headerTabCta;
	}

	


	public List<HeaderTabSection> getHeaderTabSections() {
		return this.headerTabSections;
	}

	public void setHeaderTabSections(List<HeaderTabSection> headerTabSections) {
		this.headerTabSections = headerTabSections;
	}

	public HeaderTabSection addHeaderTabSection(HeaderTabSection headerTabSection) {
		getHeaderTabSections().add(headerTabSection);
		headerTabSection.setHeaderTabMaster(this);

		return headerTabSection;
	}

	public HeaderTabSection removeHeaderTabSection(HeaderTabSection headerTabSection) {
		getHeaderTabSections().remove(headerTabSection);
		headerTabSection.setHeaderTabMaster(null);

		return headerTabSection;
	}

	public List<HeaderTabLinks> getHeaderTabLinks() {
		return this.headerTabLinks;
	}

	public void setHeaderTabLinks(List<HeaderTabLinks> headerTabLinks) {
		this.headerTabLinks = headerTabLinks;
	}

	public HeaderTabLinks addHeaderTabLink(HeaderTabLinks headerTabLink) {
		getHeaderTabLinks().add(headerTabLink);
		headerTabLink.setHeaderTabMaster(this);

		return headerTabLink;
	}

	public HeaderTabLinks removeHeaderTabLink(HeaderTabLinks headerTabLink) {
		getHeaderTabLinks().remove(headerTabLink);
		headerTabLink.setHeaderTabMaster(null);

		return headerTabLink;
	}
}