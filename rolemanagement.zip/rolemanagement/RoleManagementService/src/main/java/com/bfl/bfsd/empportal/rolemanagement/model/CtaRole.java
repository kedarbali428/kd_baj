package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the CTA_ROLES database table.
 * 
 */
@Entity
@Table(name="CTA_ROLES")
@NamedQueries({
//@NamedQuery(name="CtaRole.findAll", query="SELECT c FROM CtaRole c"),
@NamedQuery(name="CtaRole.findAllActiveForProductAndRole", query="SELECT c FROM CtaRole c WHERE c.isactive = 1 "
			+ " AND c.ctaProduct.ctaprodkey IN :ctaprodkeys AND c.bfsdRoleMaster.rolekey =:rolekey"),
@NamedQuery(name="CtaRole.DeactivateCtaRoles",query="UPDATE CtaRole c set c.isactive = 0 WHERE c.isactive = 1 "
		//+ " AND c.ctaProduct.ctaprodkey IN :ctaprodkeys"
		+ " AND c.bfsdRoleMaster.rolekey =:rolekey")
})
public class CtaRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long ctarolekey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to BfsdRoleMaster
	@ManyToOne
	@JoinColumn(name="ROLEKEY")
	private BfsdRoleMaster bfsdRoleMaster;

	//bi-directional many-to-one association to CtaProduct
	@ManyToOne
	@JoinColumn(name="CTAPRODKEY")
	private CtaProduct ctaProduct;

	public CtaRole() {
	}

	public long getCtarolekey() {
		return this.ctarolekey;
	}

	public void setCtarolekey(long ctarolekey) {
		this.ctarolekey = ctarolekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return this.bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

	public CtaProduct getCtaProduct() {
		return this.ctaProduct;
	}

	public void setCtaProduct(CtaProduct ctaProduct) {
		this.ctaProduct = ctaProduct;
	}

}