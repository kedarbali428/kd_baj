package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the FIELD_SET_ATTRIBUTES database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_ATTRIBUTES")
//@NamedQuery(name="FieldSetAttributeL3.findAll", query="SELECT f FROM FieldSetAttribute f")
public class FieldSetAttributeL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long fieldkey;

	private BigDecimal dfltvwsummaryorder;

	private BigDecimal displayorder;

	private String dmlcolumn;

	private String dmlkey;

	private String dmltable;

	private BigDecimal editablebystage;

	private BigDecimal fieldcd;

	private BigDecimal fielddatatype;

	private String fieldlength;

	private String fieldname;

	private long fieldsetkey;

	private BigDecimal fieldtype;

	private String fieldurl;

	private String getquery;

	private String insertquery;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String physicalcolumn;

	private String physicaltable;

	private BigDecimal requiredflg;

	private BigDecimal setfilterflg;

	private BigDecimal sourcecd;

	private String updatequery;

	private String viewcolumn;

	private String viewtable;

	private BigDecimal vwdispalyfilterflg;

	//bi-directional many-to-one association to FieldSetAttribute
	@ManyToOne
	@JoinColumn(name="PARENTFIELDKEY")
	private FieldSetAttributeL3 fieldSetAttribute;

	//bi-directional many-to-one association to FieldSetAttribute
	@OneToMany(mappedBy="fieldSetAttribute")
	private List<FieldSetAttributeL3> fieldSetAttributes;

	//bi-directional many-to-one association to FieldSetSubsection
	@ManyToOne
	@JoinColumn(name="SUBSECTIONKEY")
	private FieldSetSubsectionL3 fieldSetSubsection;

	//bi-directional many-to-one association to FieldSetProduct
	@OneToMany(mappedBy="fieldSetAttribute")
	private List<FieldSetProduct> fieldSetProducts;

	//bi-directional many-to-one association to FieldSetRole
	@OneToMany(mappedBy="fieldSetAttribute")
	private List<FieldSetRoleL3> fieldSetRoles;

	public FieldSetAttributeL3() {
	}

	public long getFieldkey() {
		return this.fieldkey;
	}

	public void setFieldkey(long fieldkey) {
		this.fieldkey = fieldkey;
	}

	public BigDecimal getDfltvwsummaryorder() {
		return this.dfltvwsummaryorder;
	}

	public void setDfltvwsummaryorder(BigDecimal dfltvwsummaryorder) {
		this.dfltvwsummaryorder = dfltvwsummaryorder;
	}

	public BigDecimal getDisplayorder() {
		return this.displayorder;
	}

	public void setDisplayorder(BigDecimal displayorder) {
		this.displayorder = displayorder;
	}

	public String getDmlcolumn() {
		return this.dmlcolumn;
	}

	public void setDmlcolumn(String dmlcolumn) {
		this.dmlcolumn = dmlcolumn;
	}

	public String getDmlkey() {
		return this.dmlkey;
	}

	public void setDmlkey(String dmlkey) {
		this.dmlkey = dmlkey;
	}

	public String getDmltable() {
		return this.dmltable;
	}

	public void setDmltable(String dmltable) {
		this.dmltable = dmltable;
	}

	public BigDecimal getEditablebystage() {
		return this.editablebystage;
	}

	public void setEditablebystage(BigDecimal editablebystage) {
		this.editablebystage = editablebystage;
	}

	public BigDecimal getFieldcd() {
		return this.fieldcd;
	}

	public void setFieldcd(BigDecimal fieldcd) {
		this.fieldcd = fieldcd;
	}

	public BigDecimal getFielddatatype() {
		return this.fielddatatype;
	}

	public void setFielddatatype(BigDecimal fielddatatype) {
		this.fielddatatype = fielddatatype;
	}

	public String getFieldlength() {
		return this.fieldlength;
	}

	public void setFieldlength(String fieldlength) {
		this.fieldlength = fieldlength;
	}

	public String getFieldname() {
		return this.fieldname;
	}

	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}

	public long getFieldsetkey() {
		return this.fieldsetkey;
	}

	public void setFieldsetkey(long fieldsetkey) {
		this.fieldsetkey = fieldsetkey;
	}

	public BigDecimal getFieldtype() {
		return this.fieldtype;
	}

	public void setFieldtype(BigDecimal fieldtype) {
		this.fieldtype = fieldtype;
	}

	public String getFieldurl() {
		return this.fieldurl;
	}

	public void setFieldurl(String fieldurl) {
		this.fieldurl = fieldurl;
	}

	public String getGetquery() {
		return this.getquery;
	}

	public void setGetquery(String getquery) {
		this.getquery = getquery;
	}

	public String getInsertquery() {
		return this.insertquery;
	}

	public void setInsertquery(String insertquery) {
		this.insertquery = insertquery;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getPhysicalcolumn() {
		return this.physicalcolumn;
	}

	public void setPhysicalcolumn(String physicalcolumn) {
		this.physicalcolumn = physicalcolumn;
	}

	public String getPhysicaltable() {
		return this.physicaltable;
	}

	public void setPhysicaltable(String physicaltable) {
		this.physicaltable = physicaltable;
	}

	public BigDecimal getRequiredflg() {
		return this.requiredflg;
	}

	public void setRequiredflg(BigDecimal requiredflg) {
		this.requiredflg = requiredflg;
	}

	public BigDecimal getSetfilterflg() {
		return this.setfilterflg;
	}

	public void setSetfilterflg(BigDecimal setfilterflg) {
		this.setfilterflg = setfilterflg;
	}

	public BigDecimal getSourcecd() {
		return this.sourcecd;
	}

	public void setSourcecd(BigDecimal sourcecd) {
		this.sourcecd = sourcecd;
	}

	public String getUpdatequery() {
		return this.updatequery;
	}

	public void setUpdatequery(String updatequery) {
		this.updatequery = updatequery;
	}

	public String getViewcolumn() {
		return this.viewcolumn;
	}

	public void setViewcolumn(String viewcolumn) {
		this.viewcolumn = viewcolumn;
	}

	public String getViewtable() {
		return this.viewtable;
	}

	public void setViewtable(String viewtable) {
		this.viewtable = viewtable;
	}

	public BigDecimal getVwdispalyfilterflg() {
		return this.vwdispalyfilterflg;
	}

	public void setVwdispalyfilterflg(BigDecimal vwdispalyfilterflg) {
		this.vwdispalyfilterflg = vwdispalyfilterflg;
	}

	public FieldSetAttributeL3 getFieldSetAttribute() {
		return this.fieldSetAttribute;
	}

	public void setFieldSetAttribute(FieldSetAttributeL3 fieldSetAttribute) {
		this.fieldSetAttribute = fieldSetAttribute;
	}

	public List<FieldSetAttributeL3> getFieldSetAttributes() {
		return this.fieldSetAttributes;
	}

	public void setFieldSetAttributes(List<FieldSetAttributeL3> fieldSetAttributes) {
		this.fieldSetAttributes = fieldSetAttributes;
	}

	public FieldSetAttributeL3 addFieldSetAttribute(FieldSetAttributeL3 fieldSetAttribute) {
		getFieldSetAttributes().add(fieldSetAttribute);
		fieldSetAttribute.setFieldSetAttribute(this);

		return fieldSetAttribute;
	}

	public FieldSetAttributeL3 removeFieldSetAttribute(FieldSetAttributeL3 fieldSetAttribute) {
		getFieldSetAttributes().remove(fieldSetAttribute);
		fieldSetAttribute.setFieldSetAttribute(null);

		return fieldSetAttribute;
	}

	public FieldSetSubsectionL3 getFieldSetSubsection() {
		return this.fieldSetSubsection;
	}

	public void setFieldSetSubsection(FieldSetSubsectionL3 fieldSetSubsection) {
		this.fieldSetSubsection = fieldSetSubsection;
	}

	public List<FieldSetProduct> getFieldSetProducts() {
		return this.fieldSetProducts;
	}

	public void setFieldSetProducts(List<FieldSetProduct> fieldSetProducts) {
		this.fieldSetProducts = fieldSetProducts;
	}

	public FieldSetProduct addFieldSetProduct(FieldSetProduct fieldSetProduct) {
		getFieldSetProducts().add(fieldSetProduct);
		fieldSetProduct.setFieldSetAttribute(this);

		return fieldSetProduct;
	}

	public FieldSetProduct removeFieldSetProduct(FieldSetProduct fieldSetProduct) {
		getFieldSetProducts().remove(fieldSetProduct);
		fieldSetProduct.setFieldSetAttribute(null);

		return fieldSetProduct;
	}

	public List<FieldSetRoleL3> getFieldSetRoles() {
		return this.fieldSetRoles;
	}

	public void setFieldSetRoles(List<FieldSetRoleL3> fieldSetRoles) {
		this.fieldSetRoles = fieldSetRoles;
	}

	public FieldSetRoleL3 addFieldSetRole(FieldSetRoleL3 fieldSetRole) {
		getFieldSetRoles().add(fieldSetRole);
		fieldSetRole.setFieldSetAttribute(this);

		return fieldSetRole;
	}

	public FieldSetRoleL3 removeFieldSetRole(FieldSetRoleL3 fieldSetRole) {
		getFieldSetRoles().remove(fieldSetRole);
		fieldSetRole.setFieldSetAttribute(null);

		return fieldSetRole;
	}


}