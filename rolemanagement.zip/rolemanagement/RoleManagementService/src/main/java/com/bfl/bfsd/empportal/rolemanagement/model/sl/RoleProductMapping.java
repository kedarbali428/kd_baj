package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ROLE_PRODUCT_MAPPING database table.
 * 
 */
@Entity
@Table(name="ROLE_PRODUCT_MAPPING")
@NamedQueries({
@NamedQuery(name="RoleProductMapping.findAll", query="SELECT r FROM RoleProductMapping r where r.rolekey=:rolekey and r.isactive=1"),
@NamedQuery(name="RoleProductMapping.findAllRoleKey", query="SELECT r.roleprodkey FROM RoleProductMapping r where r.rolekey in :rolekey"
			+ " and r.prodmastkey=:prodkey and r.subprodmastkey=:subprodkey"),
@NamedQuery(name="RoleProductMapping.findAllRoleKeyProdkey", query="SELECT r.roleprodkey FROM RoleProductMapping r where r.rolekey = :rolekey"
		),
@NamedQuery(name="RoleProductMapping.findAllRoleMapping", query="SELECT r FROM RoleProductMapping r where r.rolekey in :rolekey"
		+ " and r.prodmastkey=:prodkey and r.subprodmastkey=:subprodkey"),
@NamedQuery(name="RoleProductMapping.activeroleprodmap", query="update RoleProductMapping set isactive=1 where roleprodkey =:roleprodkey"),
@NamedQuery(name="RoleProductMapping.FindAllRoleProdKeysForRolekeys", query="SELECT r.roleprodkey FROM RoleProductMapping r where r.rolekey in :rolekeys")
})
public class RoleProductMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long roleprodkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodmastkey;

	private BigDecimal rolekey;

	private BigDecimal subprodmastkey;

	//bi-directional many-to-one association to HeaderTabRole
	@OneToMany(mappedBy="roleProductMapping", cascade = CascadeType.ALL)
	private List<HeaderTabRoleL3> headerTabRoles;
	
	@OneToMany(mappedBy="roleProductMapping")
	private List<CtaRoleL3> ctaRoles;
	
	@OneToMany(mappedBy="roleProductMapping")
	private List<FieldSetRoleL3> fieldSetRoles;
	
	@OneToMany(mappedBy="roleProductMapping")
	private List<FieldSetSubsectionRoleL3> fieldSetSubsectionRoles;


	public RoleProductMapping() {
	}

	public long getRoleprodkey() {
		return this.roleprodkey;
	}

	public void setRoleprodkey(long roleprodkey) {
		this.roleprodkey = roleprodkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(BigDecimal prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public BigDecimal getRolekey() {
		return this.rolekey;
	}

	public void setRolekey(BigDecimal rolekey) {
		this.rolekey = rolekey;
	}

	public BigDecimal getSubprodmastkey() {
		return this.subprodmastkey;
	}

	public void setSubprodmastkey(BigDecimal subprodmastkey) {
		this.subprodmastkey = subprodmastkey;
	}

	public List<FieldSetRoleL3> getFieldSetRoles() {
		return this.fieldSetRoles;
	}

	public void setFieldSetRoles(List<FieldSetRoleL3> fieldSetRoles) {
		this.fieldSetRoles = fieldSetRoles;
	}

	public FieldSetRoleL3 addFieldSetRole(FieldSetRoleL3 fieldSetRole) {
		getFieldSetRoles().add(fieldSetRole);
		fieldSetRole.setRoleProductMapping(this);

		return fieldSetRole;
	}

	public FieldSetRoleL3 removeFieldSetRole(FieldSetRoleL3 fieldSetRole) {
		getFieldSetRoles().remove(fieldSetRole);
		fieldSetRole.setRoleProductMapping(null);

		return fieldSetRole;
	}
	
public List<HeaderTabRoleL3> getHeaderTabRoles() {
	return this.headerTabRoles;
}

public void setHeaderTabRoles(List<HeaderTabRoleL3> headerTabRoles) {
	this.headerTabRoles = headerTabRoles;
}

public HeaderTabRoleL3 addHeaderTabRole(HeaderTabRoleL3 headerTabRole) {
	getHeaderTabRoles().add(headerTabRole);
	headerTabRole.setRoleProductMapping(this);

	return headerTabRole;
}

public HeaderTabRoleL3 removeHeaderTabRole(HeaderTabRoleL3 headerTabRole) {
	getHeaderTabRoles().remove(headerTabRole);
	headerTabRole.setRoleProductMapping(null);

	return headerTabRole;
}

public List<FieldSetSubsectionRoleL3> getFieldSetSubectionRoles() {
	return this.fieldSetSubsectionRoles;
}

public void setFieldSetSubectionRoles(List<FieldSetSubsectionRoleL3> fieldSetSubsectionRoles) {
	this.fieldSetSubsectionRoles = fieldSetSubsectionRoles;
}

public FieldSetSubsectionRoleL3 addFieldSetSubectionRole(FieldSetSubsectionRoleL3 fieldSetSubsectionRole) {
	getFieldSetSubectionRoles().add(fieldSetSubsectionRole);
	fieldSetSubsectionRole.setRoleProductMapping(this);

	return fieldSetSubsectionRole;
}

public FieldSetSubsectionRoleL3 removeFieldSetSubectionRole(FieldSetSubsectionRoleL3 fieldSetSubsectionRole) {
	getFieldSetSubectionRoles().remove(fieldSetSubsectionRole);
	fieldSetSubsectionRole.setRoleProductMapping(null);

	return fieldSetSubsectionRole;
}

public List<CtaRoleL3> getCtaRoles() {
	return this.ctaRoles;
}

public void setCtaRoles(List<CtaRoleL3> ctaRoles) {
	this.ctaRoles = ctaRoles;
}

public CtaRoleL3 addctaRole(CtaRoleL3 ctaRole) {
	getCtaRoles().add(ctaRole);
	ctaRole.setRoleProductMapping(this);

	return ctaRole;
}

public CtaRoleL3 removeCtaRole(CtaRoleL3 ctaRole) {
	getCtaRoles().remove(ctaRole);
	ctaRole.setRoleProductMapping(null);

	return ctaRole;
}
}