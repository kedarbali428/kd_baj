package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import com.bfl.bfsd.empportal.rolemanagement.bean.LinkBean;


/**
 * The persistent class for the HEADER_TAB_LINK_ROLE_MAP database table.
 * 
 */
@Entity
@Table(name="HEADER_TAB_LINK_ROLE_MAP")
@NamedNativeQueries({
@NamedNativeQuery(name="findLinksByTabKeyAndRoleKey",query="SELECT lm.LINKKEY linkkey, lm.LINKCODE linkcode,lm.LINKDESC linkname,nvl(htlrm.ISACTIVE,0) selected ,htl.TABKEY tabkey,htm.TABNAME tabname FROM HEADER_TAB_LINK_ROLE_MAP htlrm ,HEADER_TAB_LINKS htl , LINK_MASTER lm, HEADER_TAB_MASTER htm WHERE htl.LINKKEY = lm.LINKKEY AND lm.ISACTIVE = 1 AND htl.ISACTIVE = 1 AND htl.TABKEY in (:tabKeys) AND htlrm.ROLEKEY(+) in (:roleKeys) and htlrm.TABLINKKEY(+) = htl.TABLINKKEY AND htl.TABKEY = htm.TABKEY"),
@NamedNativeQuery(name="deleteLinksByTabKeyAndRoleKey",query="Delete from HEADER_TAB_LINK_ROLE_MAP htlrm  WHERE htlrm.TABLINKKEY in (select TABLINKKEY from HEADER_TAB_LINKS where TABKEY in (:tabkeys)) and htlrm.ROLEKEY = :rolekey")
})
public class HeaderTabLinkRoleMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long linkrolekey;

	private BigDecimal isactive;

	private String lstupdatedby;

	private Timestamp lstupdtaeddt;

	private BigDecimal rolekey;

	//bi-directional many-to-one association to HeaderTabLink
	@ManyToOne
	@JoinColumn(name="TABLINKKEY")
	private HeaderTabLinks headerTabLink;

	public HeaderTabLinkRoleMap() {
	}

	public long getLinkrolekey() {
		return this.linkrolekey;
	}

	public void setLinkrolekey(long linkrolekey) {
		this.linkrolekey = linkrolekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdatedby() {
		return this.lstupdatedby;
	}

	public void setLstupdatedby(String lstupdatedby) {
		this.lstupdatedby = lstupdatedby;
	}

	public Timestamp getLstupdtaeddt() {
		return this.lstupdtaeddt;
	}

	public void setLstupdtaeddt(Timestamp lstupdtaeddt) {
		this.lstupdtaeddt = lstupdtaeddt;
	}

	public BigDecimal getRolekey() {
		return this.rolekey;
	}

	public void setRolekey(BigDecimal rolekey) {
		this.rolekey = rolekey;
	}

	public HeaderTabLinks getHeaderTabLink() {
		return this.headerTabLink;
	}

	public void setHeaderTabLink(HeaderTabLinks headerTabLink) {
		this.headerTabLink = headerTabLink;
	}

}