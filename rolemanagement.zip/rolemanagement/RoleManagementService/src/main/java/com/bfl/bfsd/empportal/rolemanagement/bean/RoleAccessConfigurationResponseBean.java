package com.bfl.bfsd.empportal.rolemanagement.bean;

public class RoleAccessConfigurationResponseBean {
	
	private Boolean isRoleAccessConfigurationSuccessful;

	public Boolean getIsRoleAccessConfigurationSuccessful() {
		return isRoleAccessConfigurationSuccessful;
	}

	public void setIsRoleAccessConfigurationSuccessful(Boolean isRoleAccessConfigurationSuccessful) {
		this.isRoleAccessConfigurationSuccessful = isRoleAccessConfigurationSuccessful;
	}

	@Override
	public String toString() {
		return "RoleAccessConfigurationResponseBean [isRoleAccessConfigurationSuccessful="
				+ isRoleAccessConfigurationSuccessful + "]";
	}
	
	
}
