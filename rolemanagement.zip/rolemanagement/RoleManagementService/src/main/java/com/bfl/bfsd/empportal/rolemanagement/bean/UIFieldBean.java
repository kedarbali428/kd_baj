package com.bfl.bfsd.empportal.rolemanagement.bean;

import java.math.BigDecimal;

public class UIFieldBean {

	private long fieldkey;
	private String fieldName;
	private String sectionName;
	private BigDecimal accessLevel;
	private boolean selected;
	private int sectionId ;
	private long subSectionId ;
	private long displayOrder ;
	private BigDecimal fieldcd;
	
	public long getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(long displayOrder) {
		this.displayOrder = displayOrder;
	}

/**	public int getSectionId() {
 *		return sectionId;
 *	}
 */
	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}

	public long getSubSectionId() {
		return subSectionId;
	}

	public void setSubSectionId(long subSectionId) {
		this.subSectionId = subSectionId;
	}

/**	public String getSectionName() {
 *		return sectionName;
 *	}
 */
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public BigDecimal getAccessLevel() {
		return accessLevel;
	}

	public void setAccessLevel(BigDecimal accessLevel) {
		this.accessLevel = accessLevel;
	}

/**(	public boolean isSelected() {
 *		return selected;
 *	}
 */
	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public long getFieldkey() {
		return fieldkey;
	}

	public void setFieldkey(long fieldkey) {
		this.fieldkey = fieldkey;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the fieldcd
	 */
	public BigDecimal getFieldcd() {
		return fieldcd;
	}

	/**
	 * @param fieldcd the fieldcd to set
	 */
	public void setFieldcd(BigDecimal fieldcd) {
		this.fieldcd = fieldcd;
	}

}
