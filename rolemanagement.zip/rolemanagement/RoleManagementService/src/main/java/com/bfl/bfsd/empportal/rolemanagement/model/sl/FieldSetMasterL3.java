package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the FIELD_SET_MASTER database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_MASTER")
@NamedQueries({
//@NamedQuery(name="FieldSetMasterL3.findAll", query="SELECT f FROM FieldSetMasterL3 f"),
@NamedQuery(name="FieldSetMasterL3.findAllBasedonSubprodkey", query="SELECT f FROM FieldSetMasterL3 f where "
		+ "prodmastkey=:prodkey and subprodkey=:subprodkey and tabkey in :tabkeys and f.isactive=1"),
@NamedQuery(name="FieldSetMasterL3.findAllBasedonTabkey", query="SELECT f FROM FieldSetMasterL3 f where "
		+ "f.isactive=1 and tabkey in :tabkeys"),
@NamedQuery(name="FieldSetMasterL3.findAllBasedonTabandProductkey", query="SELECT f FROM FieldSetMasterL3 f where "
		+ "f.isactive=1 and tabkey in :tabkeys and (prodmastkey=:prodkey or prodmastkey =null) and (subprodkey = :subprodkey or subprodkey=null) and filterflg=0")

})
public class FieldSetMasterL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long fieldsetkey;

	private BigDecimal fieldsetcd;

	private String fieldsetname;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodmastkey;

	private BigDecimal subprodkey;

	private BigDecimal tabkey;

	//bi-directional many-to-one association to FieldSetGroup
	@OneToMany(mappedBy="fieldSetMaster")
	private List<FieldSetGroupL3> fieldSetGroups;

	public FieldSetMasterL3() {
	}

	public long getFieldsetkey() {
		return this.fieldsetkey;
	}

	public void setFieldsetkey(long fieldsetkey) {
		this.fieldsetkey = fieldsetkey;
	}

	public BigDecimal getFieldsetcd() {
		return this.fieldsetcd;
	}

	public void setFieldsetcd(BigDecimal fieldsetcd) {
		this.fieldsetcd = fieldsetcd;
	}

	public String getFieldsetname() {
		return this.fieldsetname;
	}

	public void setFieldsetname(String fieldsetname) {
		this.fieldsetname = fieldsetname;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(BigDecimal prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public BigDecimal getSubprodkey() {
		return this.subprodkey;
	}

	public void setSubprodkey(BigDecimal subprodkey) {
		this.subprodkey = subprodkey;
	}

	public BigDecimal getTabkey() {
		return this.tabkey;
	}

	public void setTabkey(BigDecimal tabkey) {
		this.tabkey = tabkey;
	}

	public List<FieldSetGroupL3> getFieldSetGroups() {
		return this.fieldSetGroups;
	}

	public void setFieldSetGroups(List<FieldSetGroupL3> fieldSetGroups) {
		this.fieldSetGroups = fieldSetGroups;
	}

	public FieldSetGroupL3 addFieldSetGroup(FieldSetGroupL3 fieldSetGroup) {
		getFieldSetGroups().add(fieldSetGroup);
		fieldSetGroup.setFieldSetMaster(this);

		return fieldSetGroup;
	}

	public FieldSetGroupL3 removeFieldSetGroup(FieldSetGroupL3 fieldSetGroup) {
		getFieldSetGroups().remove(fieldSetGroup);
		fieldSetGroup.setFieldSetMaster(null);

		return fieldSetGroup;
	}

}