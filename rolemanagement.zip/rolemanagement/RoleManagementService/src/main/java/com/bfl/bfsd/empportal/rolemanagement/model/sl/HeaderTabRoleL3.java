package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the HEADER_TAB_ROLE database table.
 * 
 */
@Entity
@Table(name="HEADER_TAB_ROLE")
@NamedQueries({ 
	//@NamedQuery(name = "HeaderTabRoleL3.findAllL3", query = "SELECT ht FROM HeaderTabRole ht"),
	@NamedQuery(name = "HeaderTabRoleL3.DeactivateHeaderTabRolesBasedonL3", query = "UPDATE HeaderTabRoleL3 ht set ht.isactive = 0 "
			+ "WHERE ht.isactive = 1 AND ht.roleProductMapping.roleprodkey in :rolekey"),
	@NamedQuery(name = "HeaderTabRoleL3.DeleteHeaderTabRolesBasedonL3", query = "Delete from HeaderTabRoleL3 ht where  ht.roleProductMapping.roleprodkey in"
			+ " (select r.roleprodkey from RoleProductMapping r ,HeaderTabRoleL3 ht  WHERE ht.isactive = 1 AND"
			+ " ht.roleProductMapping.roleprodkey=r.roleprodkey"
			+ " and ht.roleProductMapping.roleprodkey = :rolekey) and ht.headerTabMaster.tabkey in (select h.tabkey from HeaderTabMasterL3 h where h.tabcd in (1,6,8,14,15,16,17,18,2,19,20))"),
	@NamedQuery(name = "HeaderTabRoleL3.findAllActiveWithUserAndRoleBasedonL3", query = "SELECT ht FROM HeaderTabRoleL3 ht"
			+ " WHERE ht.isactive = 1 AND ht.roleProductMapping.roleprodkey in :rolekey"),
	@NamedQuery(name = "HeaderTabRoleL3.findTabDetailsForRole", query ="Select distinct h from HeaderTabMasterL3 h ,HeaderTabRoleL3 hr ,RoleProductMapping rp "
			+ " where hr.roleProductMapping.roleprodkey =rp.roleprodkey and h.tabkey=hr.headerTabMaster.tabkey and rp.roleprodkey in :rolekey "
			+ " and h.isactive=1 and hr.isactive=1 order by h.vieworder"),
	@NamedQuery(name = "HeaderTabRoleL3.findAllTabDetails", query ="Select distinct h from HeaderTabMasterL3 h ,HeaderTabRoleL3 hr ,RoleProductMapping rp "
			+ " where hr.roleProductMapping.roleprodkey =rp.roleprodkey and h.tabkey=hr.headerTabMaster.tabkey and rp.rolekey in :rolekey "
			+ " and h.isactive=1 and hr.isactive=1 order by h.vieworder"),
	
	@NamedQuery(name = "HeaderTabRoleL3.DeactivateHeaderTabRolesBasedonTabkeysAndRolekeys", query = "UPDATE HeaderTabRoleL3 htr set htr.isactive = 0 "
			+ "WHERE htr.isactive = 1 AND htr.headerTabMaster.tabkey in :tabkeys AND htr.roleProductMapping.roleprodkey in :roleprodkeys")
			
})

public class HeaderTabRoleL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long roletabkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to HeaderTabMaster
	@ManyToOne
	@JoinColumn(name="TABKEY")
	private HeaderTabMasterL3 headerTabMaster;

	//bi-directional many-to-one association to RoleProductMapping
	@ManyToOne
	@JoinColumn(name="ROLEKEY")
	private RoleProductMapping roleProductMapping;

	public HeaderTabRoleL3() {
	}

	public long getRoletabkey() {
		return this.roletabkey;
	}

	public void setRoletabkey(long roletabkey) {
		this.roletabkey = roletabkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public HeaderTabMasterL3 getHeaderTabMaster() {
		return this.headerTabMaster;
	}

	public void setHeaderTabMaster(HeaderTabMasterL3 headerTabMaster) {
		this.headerTabMaster = headerTabMaster;
	}

	public RoleProductMapping getRoleProductMapping() {
		return this.roleProductMapping;
	}

	public void setRoleProductMapping(RoleProductMapping roleProductMapping) {
		this.roleProductMapping = roleProductMapping;
	}

}