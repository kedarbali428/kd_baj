package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the APP_QUEUE_PARAM_STAGE database table.
 * 
 */
@Entity
@Table(name="APP_QUEUE_PARAM_STAGE")
//@NamedQuery(name="AppQueueParamStage.findAll", query="SELECT a FROM AppQueueParamStage a")
public class AppQueueParamStage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long stageperckey;

	private BigDecimal isactive;

	private String logicaloperator;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String paramvalue;

	private String relationaloperator;

	//bi-directional many-to-one association to AppQueueDefinition
	@ManyToOne
	@JoinColumn(name="QUEUEKEY")
	private AppQueueDefinition appQueueDefinition;

	public AppQueueParamStage() {
	}

	public long getStageperckey() {
		return this.stageperckey;
	}

	public void setStageperckey(long stageperckey) {
		this.stageperckey = stageperckey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLogicaloperator() {
		return this.logicaloperator;
	}

	public void setLogicaloperator(String logicaloperator) {
		this.logicaloperator = logicaloperator;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getParamvalue() {
		return this.paramvalue;
	}

	public void setParamvalue(String paramvalue) {
		this.paramvalue = paramvalue;
	}

	public String getRelationaloperator() {
		return this.relationaloperator;
	}

	public void setRelationaloperator(String relationaloperator) {
		this.relationaloperator = relationaloperator;
	}

	public AppQueueDefinition getAppQueueDefinition() {
		return this.appQueueDefinition;
	}

	public void setAppQueueDefinition(AppQueueDefinition appQueueDefinition) {
		this.appQueueDefinition = appQueueDefinition;
	}

}