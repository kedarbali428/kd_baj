package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the FIELD_SET_GROUP_SECTIONS database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_GROUP_SECTIONS")
//@NamedQuery(name="FieldSetGroupSection.findAll", query="SELECT f FROM FieldSetGroupSection f")
public class FieldSetGroupSection implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long grpsectionkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to FieldSetGroup
	@ManyToOne
	@JoinColumn(name="GROUPKEY")
	private FieldSetGroup fieldSetGroup;

	//bi-directional many-to-one association to FieldSetSection
	@ManyToOne
	@JoinColumn(name="SECTIONKEY")
	private FieldSetSection fieldSetSection;

	public FieldSetGroupSection() {
	}

	public long getGrpsectionkey() {
		return this.grpsectionkey;
	}

	public void setGrpsectionkey(long grpsectionkey) {
		this.grpsectionkey = grpsectionkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public FieldSetGroup getFieldSetGroup() {
		return this.fieldSetGroup;
	}

	public void setFieldSetGroup(FieldSetGroup fieldSetGroup) {
		this.fieldSetGroup = fieldSetGroup;
	}

	public FieldSetSection getFieldSetSection() {
		return this.fieldSetSection;
	}

	public void setFieldSetSection(FieldSetSection fieldSetSection) {
		this.fieldSetSection = fieldSetSection;
	}

}