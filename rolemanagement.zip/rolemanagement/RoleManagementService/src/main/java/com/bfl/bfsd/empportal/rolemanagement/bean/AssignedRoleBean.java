package com.bfl.bfsd.empportal.rolemanagement.bean;

public class AssignedRoleBean {
	
	private Long userId;
	private String commaSeparatedRolesToVerify;
	private String defaultRoleName;
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}	
	
	public String getDefaultRoleName() {
		return defaultRoleName;
	}
	public void setDefaultRoleName(String defaultRoleName) {
		this.defaultRoleName = defaultRoleName;
	}
	public String getCommaSeparatedRolesToVerify() {
		return commaSeparatedRolesToVerify;
	}
	public void setCommaSeparatedRolesToVerify(String commaSeparatedRolesToVerify) {
		this.commaSeparatedRolesToVerify = commaSeparatedRolesToVerify == null? "":commaSeparatedRolesToVerify;
	}	 
}
