package com.bfl.bfsd.empportal.rolemanagement.dao;

import java.math.BigDecimal;
import java.util.List;

import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabResponse;
import com.bfl.bfsd.empportal.rolemanagement.bean.UserRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetGroupL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetMasterL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetSubsectionRoleL3;

public interface RoleManagementDaoV2 {

	
	RoleAccessConfigurationBean getTabDetailsBasedonL3(List<Long> roleKey, long subprodkey, long prodkey);

	List<FieldSetSubsectionRoleL3> fetchSubSectionRoleByRoleBasedonL3(List<Long> roles, long prodkey, long subprodkey);

	List<FieldSetRoleL3> fetchFieldsSetRolesByRoleKeysBasedonL3(List<Long> roleKeys, long prodkey, long subprodkey);

	List<FieldSetGroupL3> fetchGroupsSectionAndSubSectionsBasedonL3(RoleAccessConfigurationBean inputBean);

	List<FieldSetGroupL3> fetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3(RoleAccessConfigurationBean inputBean);

	boolean saveConfigurationsBasedonL3(RoleAccessConfigurationInputBean inputBean);

	void cloneRoleAccessConfigurationBasedonL3(CloneRoleAccessConfigureBean cloneRoleAccessConfigBean);

	TabResponse saveTabKeyAndProducts(UserRoleBean rolebean);

	List<Long> getroleprodkey(List<BigDecimal> roleKeys, long prodkey, long subprodkey);

	List<FieldSetMasterL3> getfieldsetmaster(RoleAccessConfigurationBean inputBean);

	boolean updateHomeAndGlobalSearchAccessForOmInBau(RoleAccessConfigurationInputBean roleAccessConfigurationInputBean);

	RoleAccessConfigurationBean fetchCommonTabsMappedForRole(RoleAccessConfigurationBean roleAccConfig,
			List<Long> roleKeys);

	Boolean updateHeaderTabLinkAccess(RoleAccessConfigurationInputBean roleAccessConfigurationInputBean);

}
