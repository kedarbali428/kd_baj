package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the HEADER_TAB_LINKS database table.
 * 
 */
@Entity
@Table(name="HEADER_TAB_LINKS")
@NamedQuery (name="HeaderTabLinks.findAllByTabkeyAndLinkkey", query = "SELECT h from HeaderTabLinks h where h.headerTabMaster.tabkey in (:tabkeys) AND  h.linkMaster.linkkey in (:Linkkeys)")
public class HeaderTabLinks implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long tablinkkey;

	private BigDecimal isactive;

	private String lstupdatedby;

	private Timestamp lstupdtaeddt;

	//bi-directional many-to-one association to HeaderTabMaster
	@ManyToOne
	@JoinColumn(name="TABKEY")
	private HeaderTabMaster headerTabMaster;

	//bi-directional many-to-one association to LinkMaster
	@ManyToOne
	@JoinColumn(name="LINKKEY")
	private LinkMaster linkMaster;

	//bi-directional many-to-one association to HeaderTabLinkRoleMap
	@OneToMany(mappedBy="headerTabLink")
	private List<HeaderTabLinkRoleMap> headerTabLinkRoleMaps;

	public HeaderTabLinks() {
	}

	public long getTablinkkey() {
		return this.tablinkkey;
	}

	public void setTablinkkey(long tablinkkey) {
		this.tablinkkey = tablinkkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdatedby() {
		return this.lstupdatedby;
	}

	public void setLstupdatedby(String lstupdatedby) {
		this.lstupdatedby = lstupdatedby;
	}

	public Timestamp getLstupdtaeddt() {
		return this.lstupdtaeddt;
	}

	public void setLstupdtaeddt(Timestamp lstupdtaeddt) {
		this.lstupdtaeddt = lstupdtaeddt;
	}

	public HeaderTabMaster getHeaderTabMaster() {
		return this.headerTabMaster;
	}

	public void setHeaderTabMaster(HeaderTabMaster headerTabMaster) {
		this.headerTabMaster = headerTabMaster;
	}

	public LinkMaster getLinkMaster() {
		return this.linkMaster;
	}

	public void setLinkMaster(LinkMaster linkMaster) {
		this.linkMaster = linkMaster;
	}

	public List<HeaderTabLinkRoleMap> getHeaderTabLinkRoleMaps() {
		return this.headerTabLinkRoleMaps;
	}

	public void setHeaderTabLinkRoleMaps(List<HeaderTabLinkRoleMap> headerTabLinkRoleMaps) {
		this.headerTabLinkRoleMaps = headerTabLinkRoleMaps;
	}

	public HeaderTabLinkRoleMap addHeaderTabLinkRoleMap(HeaderTabLinkRoleMap headerTabLinkRoleMap) {
		getHeaderTabLinkRoleMaps().add(headerTabLinkRoleMap);
		headerTabLinkRoleMap.setHeaderTabLink(this);

		return headerTabLinkRoleMap;
	}

	public HeaderTabLinkRoleMap removeHeaderTabLinkRoleMap(HeaderTabLinkRoleMap headerTabLinkRoleMap) {
		getHeaderTabLinkRoleMaps().remove(headerTabLinkRoleMap);
		headerTabLinkRoleMap.setHeaderTabLink(null);

		return headerTabLinkRoleMap;
	}

}