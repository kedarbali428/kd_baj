package com.bfl.bfsd.empportal.rolemanagement.bean;

public class CTASectionBean {
	
	private int location;
	private Long tabKey;
	private String sectionName;
    private boolean selected;
    
	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	private Long ctaKey;
	private String ctaDesc;
	

	/**private List<SubSectionBean> subSectionBean;*/

	
	public String getSectionName() {
		return sectionName;
	}

	public Long getCtaKey() {
		return ctaKey;
	}

	public void setCtaKey(Long ctaKey) {
		this.ctaKey = ctaKey;
	}

	public String getCtaDesc() {
		return ctaDesc;
	}

	public void setCtaDesc(String ctaDesc) {
		this.ctaDesc = ctaDesc;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public Long getTabKey() {
		return tabKey;
	}

	public void setTabKey(Long tabKey) {
		this.tabKey = tabKey;
	}

	/**public List<SubSectionBean> getSubSectionBean() {
	*	return subSectionBean;
	*}
	*
	*public void setSubSectionBean(List<SubSectionBean> subSectionBean) {
	*	this.subSectionBean = subSectionBean;
	*}
	*/

	public int getLocation() {
		return location;
	}

	public void setLocation(int location) {
		this.location = location;
	}

}
