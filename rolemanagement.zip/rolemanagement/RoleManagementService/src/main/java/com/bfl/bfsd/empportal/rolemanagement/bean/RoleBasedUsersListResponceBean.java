package com.bfl.bfsd.empportal.rolemanagement.bean;

import java.util.List;

public class RoleBasedUsersListResponceBean {
	
	List<RoleBasedUsersResponseBean> rolebasedUserList;
	

	public List<RoleBasedUsersResponseBean> getRolebasedUserList() {
		return rolebasedUserList;
	}

	public void setRolebasedUserList(List<RoleBasedUsersResponseBean> rolebasedUserList) {
		this.rolebasedUserList = rolebasedUserList;
	}
	
	

	@Override
	public String toString() {
		return "RoleBasedUsersListResponceBean [rolebasedUserList=" + rolebasedUserList + "]";
	}
	
	

}
