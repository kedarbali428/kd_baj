package com.bfl.bfsd.empportal.rolemanagement.service.impl;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bfl.bfsd.empportal.rolemanagement.bean.AssignedRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleBasedUsersListResponceBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabResponse;
import com.bfl.bfsd.empportal.rolemanagement.bean.UserRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.dao.RoleManagementDao;
import com.bfl.bfsd.empportal.rolemanagement.dao.RoleManagementDaoV2;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetRolesDTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetRolesL3DTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetSubSectionRolesDTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetSubSectionRolesL3DTO;
import com.bfl.bfsd.empportal.rolemanagement.model.BfsdRoleMaster;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetGroup;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetRole;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsection;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsectionRole;
import com.bfl.bfsd.empportal.rolemanagement.model.UserRole;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetGroupL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetMasterL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetSubsectionRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.RoleProductMapping;
import com.bfl.bfsd.empportal.rolemanagement.service.RoleManagementService;

/**
 * Description of the class
 * This class is the service implementation class for the View Management Service
 *
 * @author Cognizant - Date - 27/02/2017
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0              27/02/2017
 *
 */

@Component
public class RoleManagementServiceImpl extends BFLComponent implements RoleManagementService{
 
	@Autowired
	RoleManagementDao roleManagementDao;
	
	@Autowired
	RoleManagementDaoV2 roleManagementDaoV2;
	
	@Override
	public RoleAccessConfigurationBean getTabDetails( RoleAccessConfigurationBean roleAccessConfigBean) {
		List<Long> roleKey = roleAccessConfigBean.getRoleKeys();
		return roleManagementDao.getTabDetails(roleKey);
	}

	@Override
	public RoleAccessConfigurationBean getCTADetails(RoleAccessConfigurationBean roleAccessConfigBean) {
		return roleManagementDao.getCTADetails(roleAccessConfigBean);
	}

/**	@Override
//	public RoleAccessConfigurationBean getUIFields(RoleAccessConfigurationBean roleAccessConfigBean) {
//		
//		List<Long> roleKeyList = roleAccessConfigBean.getRoleKeys();
//		List<Long>listOfTabKeys = roleAccessConfigBean.getTabKeys();
//		return roleManagementDao.getUIFields(roleKeyList,listOfTabKeys);
//	}
*/
	@Override
	public boolean saveRoleAccessconfigurations(RoleAccessConfigurationInputBean inputBean) {
		return roleManagementDao.saveConfigurations(inputBean);
	}
	
	@Override
	public RoleBasedUsersListResponceBean getUsersListOnRoleBased(Long roleKey,Long applicationkey) {
		return roleManagementDao.usersListOnRoleBased(roleKey,applicationkey);
	}

	@Override
	public void cloneRoleAccessConfiguration(CloneRoleAccessConfigureBean cloneRoleAccessConfigBean) {
		roleManagementDao.cloneRoleAccessConfiguration(cloneRoleAccessConfigBean);
		
	}

	@Override
	public List<FieldSetGroup> fetchGroupsSectinoAndsubSectionforUser(RoleAccessConfigurationBean inputBean) {
		return roleManagementDao.fetchGroupsSectionAndSubSections(inputBean);
	}

	@Override
	public List<FieldSetSubsection> fetchFieldsforGroupsSectinoAndsubSection(RoleAccessConfigurationBean roleAccessConfigBean) {
		return roleManagementDao.fetchFieldsforGroupsSectinoAndsubSection(roleAccessConfigBean);
	}

	@Override
	public FieldSetGroupAndFieldSetRolesDTO fetchFieldsDetailsforGroupsSectinoAndsubSection(RoleAccessConfigurationBean roleAccessConfigBean) {
		
		List<FieldSetRole> fieldSetRoles = roleManagementDao.fetchFieldsSetRolesByRoleKeys(roleAccessConfigBean.getRoleKeys());
		List<FieldSetGroup> fieldSetGroups = roleManagementDao.fetchFieldsDetailsforGroupsSectinoAndsubSection(roleAccessConfigBean);
		
		return new FieldSetGroupAndFieldSetRolesDTO(fieldSetGroups,fieldSetRoles);
	}

	@Override
	public FieldSetGroupAndFieldSetSubSectionRolesDTO fetchGroupsSectinoAndsubSectionforUserInEditView(List<Long> roleKeys, List<Long> tabKeys) {
		
		List<FieldSetRole> fieldSetRoles = roleManagementDao.fetchFieldsSetRolesByRoleKeys(roleKeys);
		List<FieldSetSubsectionRole> fieldSetSubsectionRoles = roleManagementDao.fetchSubSectionRoleByRole(roleKeys);
		
		RoleAccessConfigurationBean bean = new RoleAccessConfigurationBean();
		bean.setRoleKeys(roleKeys);
		bean.setTabKeys(tabKeys);
		List<FieldSetGroup> fieldSetGroups = roleManagementDao.fetchGroupsSectionAndSubSections(bean);
		
		return new FieldSetGroupAndFieldSetSubSectionRolesDTO(fieldSetGroups,fieldSetRoles, fieldSetSubsectionRoles); 
	}
	
	@Override
	public Boolean checkRoleInUsersAssignedRolesHierarchy(AssignedRoleBean assignedRoleBean){
		return roleManagementDao.checkRoleInUsersAssignedRolesHierarchy(assignedRoleBean);
	}

	@Override
	public UserRoleBean getUserRole(long userKey, long userRoleKey) {
		
		UserRole userRole = roleManagementDao.getUserRole(userKey, userRoleKey);
		
		BfsdRoleMaster role = userRole.getBfsdRoleMaster();
		UserRoleBean roleBean =  new UserRoleBean();
		
		roleBean.setRoleKey(role.getRolekey());
		roleBean.setRoleName(role.getRolename());
		roleBean.setUserKey(userKey);
		roleBean.setUserRoleKey(userRoleKey);
		return roleBean;
	}
	
	@Override
	public boolean checkEmailCTAAccess(long applicationKey){
		
		return roleManagementDao.checkEmailCTAAccess(applicationKey);
	}
	@Override
	public RoleAccessConfigurationBean getTabDetailsBasedonL3( RoleAccessConfigurationBean roleAccessConfigBean) {
		List<Long> roleKey = roleAccessConfigBean.getRoleKeys();
		long subprodkey =roleAccessConfigBean.getSubprodkey().get(0);
		
		return roleManagementDaoV2.getTabDetailsBasedonL3(roleKey,subprodkey,roleAccessConfigBean.getProductTypeKey());
	}
	

	@Override
	public FieldSetGroupAndFieldSetSubSectionRolesL3DTO fetchGroupsSectinoAndsubSectionforUserInEditViewBasedonL3(List<Long> roleKeys, List<Long> tabKeys,  long prodkey, List <Long> subprodkey) {
		
		long subpkey =subprodkey.get(0);
		List<BigDecimal> rolekeys = roleKeys.stream().map(BigDecimal::new).collect(Collectors.toList());
		
		List <Long> roleProdKeys = roleManagementDaoV2.getroleprodkey(rolekeys, prodkey , subprodkey.get(0));
		
		RoleAccessConfigurationBean bean = new RoleAccessConfigurationBean();
		bean.setRoleKeys(roleKeys);
		bean.setTabKeys(tabKeys);
		bean.setSubprodkey(subprodkey);
		bean.setProductTypeKey(prodkey);
		bean.setRoleProdKeys(roleProdKeys);
		
		List<FieldSetRoleL3> fieldSetRoles = roleManagementDaoV2.fetchFieldsSetRolesByRoleKeysBasedonL3(roleProdKeys,prodkey,subpkey);
		if(fieldSetRoles.isEmpty()){
			RoleProductMapping roleProductMapping = new RoleProductMapping();
			roleProductMapping.setRoleprodkey(roleProdKeys.get(0));
			FieldSetRoleL3 fieldsetrole = new FieldSetRoleL3();
			fieldsetrole.setRoleProductMapping(roleProductMapping);
			fieldSetRoles.add(fieldsetrole);
		}
		List<FieldSetSubsectionRoleL3> fieldSetSubsectionRoles = roleManagementDaoV2.fetchSubSectionRoleByRoleBasedonL3(roleProdKeys,prodkey,subpkey);
		List<FieldSetGroupL3> fieldSetGroups = roleManagementDaoV2.fetchGroupsSectionAndSubSectionsBasedonL3(bean);
		
		return new FieldSetGroupAndFieldSetSubSectionRolesL3DTO(fieldSetGroups,fieldSetRoles, fieldSetSubsectionRoles); 
	}
	
	@Override
	public List<FieldSetGroupL3> fetchGroupsSectinoAndsubSectionforUserBasedonL3(RoleAccessConfigurationBean inputBean) {
	
		List<BigDecimal> rolekeys = inputBean.getRoleKeys().stream().map(BigDecimal::new).collect(Collectors.toList());
		
		List <Long> roleProdKeys = roleManagementDaoV2.getroleprodkey(rolekeys, inputBean.getProductTypeKey() , inputBean.getSubprodkey().get(0));
		inputBean.setRoleProdKeys(roleProdKeys);
		return roleManagementDaoV2.fetchGroupsSectionAndSubSectionsBasedonL3(inputBean);
	}
	
	@Override
	public FieldSetGroupAndFieldSetRolesL3DTO fetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3(
			RoleAccessConfigurationBean roleAccessConfigBean) {
		List<BigDecimal> rolekeys = roleAccessConfigBean.getRoleKeys().stream().map(BigDecimal::new).collect(Collectors.toList());
		
		List <Long> roleProdKeys = roleManagementDaoV2.getroleprodkey(rolekeys, roleAccessConfigBean.getProductTypeKey() , roleAccessConfigBean.getSubprodkey().get(0));
		roleAccessConfigBean.setRoleProdKeys(roleProdKeys);
		List<FieldSetRoleL3> fieldSetRoles = roleManagementDaoV2.fetchFieldsSetRolesByRoleKeysBasedonL3(roleProdKeys,roleAccessConfigBean.getProductTypeKey(),roleAccessConfigBean.getSubprodkey().get(0));
		List<FieldSetGroupL3> fieldSetGroups = roleManagementDaoV2.fetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3(roleAccessConfigBean);
		
		return new FieldSetGroupAndFieldSetRolesL3DTO(fieldSetGroups,fieldSetRoles);
		
	}
	
	@Override
	public boolean saveRoleAccessconfigurationsBasedonL3(RoleAccessConfigurationInputBean inputBean) {
		return roleManagementDaoV2.saveConfigurationsBasedonL3(inputBean);
	}
	
	@Override
	public void cloneRoleAccessConfigurationBasedonL3(CloneRoleAccessConfigureBean cloneRoleAccessConfigBean) {
		roleManagementDaoV2.cloneRoleAccessConfigurationBasedonL3(cloneRoleAccessConfigBean);
	}
	
	@Override
	public TabResponse fetchTabKeyAndProducts(UserRoleBean rolebean){
		return roleManagementDaoV2.saveTabKeyAndProducts(rolebean);
	}
	@Override
	public List<FieldSetMasterL3> fetchFieldSetMaster(RoleAccessConfigurationBean inputBean){
		return roleManagementDaoV2.getfieldsetmaster(inputBean);
	}

	@Override
	public RoleAccessConfigurationBean getLinkAcess(RoleAccessConfigurationBean roleAccConfigBean) {
		
		return roleManagementDao.getLinkAcess(roleAccConfigBean);
	}

	@Override
	public RoleAccessConfigurationBean getLinksAcess(long roleKey, long tabKey) {
		RoleAccessConfigurationBean roleAccConfigBean = new RoleAccessConfigurationBean();
		roleAccConfigBean.setRoleKeys(Arrays.asList(roleKey));
		roleAccConfigBean.setTabKeys(Arrays.asList(tabKey));
		return roleManagementDao.getLinkAcess(roleAccConfigBean);
	}
	
	@Override
	public String getProdMastCode(Long prodMastKey) {
		return roleManagementDao.getProdMastCode(prodMastKey);
	}

	@Override
	public boolean updateBauDependantAccessForOm(RoleAccessConfigurationInputBean roleAccessConfigurationInputBean) {
		roleManagementDaoV2.updateHeaderTabLinkAccess(roleAccessConfigurationInputBean);
		return roleManagementDaoV2.updateHomeAndGlobalSearchAccessForOmInBau(roleAccessConfigurationInputBean);
	}

	@Override
	public RoleAccessConfigurationBean fetchCommonTabsMappedForOm(RoleAccessConfigurationBean roleAccConfig,
			RoleAccessConfigurationBean roleAccessConfigBean) {
		return roleManagementDaoV2.fetchCommonTabsMappedForRole(roleAccConfig,roleAccessConfigBean.getRoleKeys());
	}

}


