package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the APP_VIEW_PARAM_LOAN database table.
 * 
 */
@Entity
@Table(name="APP_VIEW_PARAM_LOAN")
//@NamedQuery(name="AppViewParamLoan.findAll", query="SELECT a FROM AppViewParamLoan a")
public class AppViewParamLoan implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long viewloankey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal orderno;

	private String paramvalue;

	private String relationaloperator;

	//bi-directional many-to-one association to AppViewDefinition
	@ManyToOne
	@JoinColumn(name="VIEWKEY")
	private AppViewDefinition appViewDefinition;

	//bi-directional many-to-one association to FieldSetAttribute
	@ManyToOne
	@JoinColumn(name="FIELDKEY")
	private FieldSetAttribute fieldSetAttribute;

	public AppViewParamLoan() {
	}

	public long getViewloankey() {
		return this.viewloankey;
	}

	public void setViewloankey(long viewloankey) {
		this.viewloankey = viewloankey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getOrderno() {
		return this.orderno;
	}

	public void setOrderno(BigDecimal orderno) {
		this.orderno = orderno;
	}

	public String getParamvalue() {
		return this.paramvalue;
	}

	public void setParamvalue(String paramvalue) {
		this.paramvalue = paramvalue;
	}

	public String getRelationaloperator() {
		return this.relationaloperator;
	}

	public void setRelationaloperator(String relationaloperator) {
		this.relationaloperator = relationaloperator;
	}

	public AppViewDefinition getAppViewDefinition() {
		return this.appViewDefinition;
	}

	public void setAppViewDefinition(AppViewDefinition appViewDefinition) {
		this.appViewDefinition = appViewDefinition;
	}

	public FieldSetAttribute getFieldSetAttribute() {
		return this.fieldSetAttribute;
	}

	public void setFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		this.fieldSetAttribute = fieldSetAttribute;
	}

}