package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the FIELD_SET_SUBSECTIONS database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_SUBSECTIONS")
@NamedQuery(name="FieldSetSubsectionL3.findAllBasedonProdAndSubProdkey", query="SELECT f FROM FieldSetSubsectionL3 f,"
		+ " FieldSetSubsectionProduct fsp where f.subsectionkey=fsp.fieldSetSubsection.subsectionkey and "
		+ "fsp.prodmastkey=:prodkey and fsp.subprodkey=:subprodkey")
public class FieldSetSubsectionL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long subsectionkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal orderno;

	private BigDecimal subsectioncd;

	private String subsectionname;

	//bi-directional many-to-one association to FieldSetAttribute
	@OneToMany(mappedBy="fieldSetSubsection")
	private List<FieldSetAttributeL3> fieldSetAttributes;

	//bi-directional many-to-one association to FieldSetSection
	@ManyToOne
	@JoinColumn(name="SECTIONKEY")
	private FieldSetSectionL3 fieldSetSection;

	//bi-directional many-to-one association to FieldSetSubsectionProduct
	@OneToMany(mappedBy="fieldSetSubsection")
	private List<FieldSetSubsectionProduct> fieldSetSubsectionProducts;

	//bi-directional many-to-one association to FieldSetSubsectionRole
	@OneToMany(mappedBy="fieldSetSubsection")
	private List<FieldSetSubsectionRoleL3> fieldSetSubsectionRoles;

	public FieldSetSubsectionL3() {
	}

	public long getSubsectionkey() {
		return this.subsectionkey;
	}

	public void setSubsectionkey(long subsectionkey) {
		this.subsectionkey = subsectionkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getOrderno() {
		return this.orderno;
	}

	public void setOrderno(BigDecimal orderno) {
		this.orderno = orderno;
	}

	public BigDecimal getSubsectioncd() {
		return this.subsectioncd;
	}

	public void setSubsectioncd(BigDecimal subsectioncd) {
		this.subsectioncd = subsectioncd;
	}

	public String getSubsectionname() {
		return this.subsectionname;
	}

	public void setSubsectionname(String subsectionname) {
		this.subsectionname = subsectionname;
	}

	public List<FieldSetAttributeL3> getFieldSetAttributes() {
		return this.fieldSetAttributes;
	}

	public void setFieldSetAttributes(List<FieldSetAttributeL3> fieldSetAttributes) {
		this.fieldSetAttributes = fieldSetAttributes;
	}

	public FieldSetAttributeL3 addFieldSetAttribute(FieldSetAttributeL3 fieldSetAttribute) {
		getFieldSetAttributes().add(fieldSetAttribute);
		fieldSetAttribute.setFieldSetSubsection(this);

		return fieldSetAttribute;
	}

	public FieldSetAttributeL3 removeFieldSetAttribute(FieldSetAttributeL3 fieldSetAttribute) {
		getFieldSetAttributes().remove(fieldSetAttribute);
		fieldSetAttribute.setFieldSetSubsection(null);

		return fieldSetAttribute;
	}

	public FieldSetSectionL3 getFieldSetSection() {
		return this.fieldSetSection;
	}

	public void setFieldSetSection(FieldSetSectionL3 fieldSetSection) {
		this.fieldSetSection = fieldSetSection;
	}

	public List<FieldSetSubsectionProduct> getFieldSetSubsectionProducts() {
		return this.fieldSetSubsectionProducts;
	}

	public void setFieldSetSubsectionProducts(List<FieldSetSubsectionProduct> fieldSetSubsectionProducts) {
		this.fieldSetSubsectionProducts = fieldSetSubsectionProducts;
	}

	public FieldSetSubsectionProduct addFieldSetSubsectionProduct(FieldSetSubsectionProduct fieldSetSubsectionProduct) {
		getFieldSetSubsectionProducts().add(fieldSetSubsectionProduct);
		fieldSetSubsectionProduct.setFieldSetSubsection(this);

		return fieldSetSubsectionProduct;
	}

	public FieldSetSubsectionProduct removeFieldSetSubsectionProduct(FieldSetSubsectionProduct fieldSetSubsectionProduct) {
		getFieldSetSubsectionProducts().remove(fieldSetSubsectionProduct);
		fieldSetSubsectionProduct.setFieldSetSubsection(null);

		return fieldSetSubsectionProduct;
	}

	public List<FieldSetSubsectionRoleL3> getFieldSetSubsectionRoles() {
		return this.fieldSetSubsectionRoles;
	}

	public void setFieldSetSubsectionRoles(List<FieldSetSubsectionRoleL3> fieldSetSubsectionRoles) {
		this.fieldSetSubsectionRoles = fieldSetSubsectionRoles;
	}

	public FieldSetSubsectionRoleL3 addFieldSetSubsectionRole(FieldSetSubsectionRoleL3 fieldSetSubsectionRole) {
		getFieldSetSubsectionRoles().add(fieldSetSubsectionRole);
		fieldSetSubsectionRole.setFieldSetSubsection(this);

		return fieldSetSubsectionRole;
	}

	public FieldSetSubsectionRoleL3 removeFieldSetSubsectionRole(FieldSetSubsectionRoleL3 fieldSetSubsectionRole) {
		getFieldSetSubsectionRoles().remove(fieldSetSubsectionRole);
		fieldSetSubsectionRole.setFieldSetSubsection(null);

		return fieldSetSubsectionRole;
	}

}