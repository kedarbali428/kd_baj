package com.bfl.bfsd.empportal.rolemanagement.bean;

public class UserRoleBean {
	private long userRoleKey;
	private long roleKey;
	private String roleName;
	private long userKey;

	public Long getUserRoleKey() {
		return userRoleKey;
	}

	public void setUserRoleKey(long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}

	public long getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(long roleKey) {
		this.roleKey = roleKey;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}
}