package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the CTA_SECTION database table.
 * 
 */
@Entity
@Table(name="CTA_SECTION")
//@NamedQuery(name="CtaSection.findAll", query="SELECT c FROM CtaSection c")
public class CtaSection implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long ctasectionkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to CtaType
	@ManyToOne
	@JoinColumn(name="CTAKEY")
	private CtaType ctaType;

	//bi-directional many-to-one association to FieldSetSection
	@ManyToOne
	@JoinColumn(name="SECTIONKEY")
	private FieldSetSection fieldSetSection;

	public CtaSection() {
	}

	public long getCtasectionkey() {
		return this.ctasectionkey;
	}

	public void setCtasectionkey(long ctasectionkey) {
		this.ctasectionkey = ctasectionkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public CtaType getCtaType() {
		return this.ctaType;
	}

	public void setCtaType(CtaType ctaType) {
		this.ctaType = ctaType;
	}

	public FieldSetSection getFieldSetSection() {
		return this.fieldSetSection;
	}

	public void setFieldSetSection(FieldSetSection fieldSetSection) {
		this.fieldSetSection = fieldSetSection;
	}

}