package com.bfl.bfsd.empportal.rolemanagement.bean;

public class BottomUIFieldBean {
	private long fieldkey;
	private String fieldName;

	public long getFieldkey() {
		return fieldkey;
	}

	public void setFieldkey(long fieldkey) {
		this.fieldkey = fieldkey;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
}
