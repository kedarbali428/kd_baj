package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the BFSD_FUNCTIONS database table.
 * 
 */
@Entity
@Table(name="BFSD_FUNCTIONS")
//@NamedQuery(name="BfsdFunction.findAll", query="SELECT b FROM BfsdFunction b")
public class BfsdFunction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long functionkey;

	private BigDecimal functioncd;

	private String functiondesc;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to BfsdFunctionProduct
	@OneToMany(mappedBy="bfsdFunction")
	private List<BfsdFunctionProduct> bfsdFunctionProducts;

	//bi-directional many-to-one association to BfsdFunctionRole
	@OneToMany(mappedBy="bfsdFunction")
	private List<BfsdFunctionRole> bfsdFunctionRoles;

	public BfsdFunction() {
	}

	public long getFunctionkey() {
		return this.functionkey;
	}

	public void setFunctionkey(long functionkey) {
		this.functionkey = functionkey;
	}

	public BigDecimal getFunctioncd() {
		return this.functioncd;
	}

	public void setFunctioncd(BigDecimal functioncd) {
		this.functioncd = functioncd;
	}

	public String getFunctiondesc() {
		return this.functiondesc;
	}

	public void setFunctiondesc(String functiondesc) {
		this.functiondesc = functiondesc;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public List<BfsdFunctionProduct> getBfsdFunctionProducts() {
		return this.bfsdFunctionProducts;
	}

	public void setBfsdFunctionProducts(List<BfsdFunctionProduct> bfsdFunctionProducts) {
		this.bfsdFunctionProducts = bfsdFunctionProducts;
	}

	public BfsdFunctionProduct addBfsdFunctionProduct(BfsdFunctionProduct bfsdFunctionProduct) {
		getBfsdFunctionProducts().add(bfsdFunctionProduct);
		bfsdFunctionProduct.setBfsdFunction(this);

		return bfsdFunctionProduct;
	}

	public BfsdFunctionProduct removeBfsdFunctionProduct(BfsdFunctionProduct bfsdFunctionProduct) {
		getBfsdFunctionProducts().remove(bfsdFunctionProduct);
		bfsdFunctionProduct.setBfsdFunction(null);

		return bfsdFunctionProduct;
	}

	public List<BfsdFunctionRole> getBfsdFunctionRoles() {
		return this.bfsdFunctionRoles;
	}

	public void setBfsdFunctionRoles(List<BfsdFunctionRole> bfsdFunctionRoles) {
		this.bfsdFunctionRoles = bfsdFunctionRoles;
	}

	public BfsdFunctionRole addBfsdFunctionRole(BfsdFunctionRole bfsdFunctionRole) {
		getBfsdFunctionRoles().add(bfsdFunctionRole);
		bfsdFunctionRole.setBfsdFunction(this);

		return bfsdFunctionRole;
	}

	public BfsdFunctionRole removeBfsdFunctionRole(BfsdFunctionRole bfsdFunctionRole) {
		getBfsdFunctionRoles().remove(bfsdFunctionRole);
		bfsdFunctionRole.setBfsdFunction(null);

		return bfsdFunctionRole;
	}

}