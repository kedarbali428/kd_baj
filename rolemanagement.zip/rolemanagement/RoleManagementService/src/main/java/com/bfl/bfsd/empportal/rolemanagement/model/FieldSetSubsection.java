package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the FIELD_SET_SUBSECTIONS database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_SUBSECTIONS")
@NamedQueries({
	@NamedQuery(name="FieldSetSubsection.findAll", query="SELECT f FROM FieldSetSubsection f"),
	@NamedQuery(name="FieldSetSubsection.findAllById", 
		query="SELECT fsf FROM FieldSetSubsection fsf where fsf.subsectionkey IN :subSectionKeys and"
				+ " fsf.isactive =1")
})

public class FieldSetSubsection implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long subsectionkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal orderno;

	private BigDecimal subsectioncd;

	private String subsectionname;

	//bi-directional many-to-one association to FieldSetAttribute
	@OneToMany(mappedBy="fieldSetSubsection")
	private List<FieldSetAttribute> fieldSetAttributes;

	//bi-directional many-to-one association to FieldSetSection
	@ManyToOne
	@JoinColumn(name="SECTIONKEY")
	private FieldSetSection fieldSetSection;

	//bi-directional many-to-one association to FieldSetSubsectionRole
	@OneToMany(mappedBy="fieldSetSubsection")
	private List<FieldSetSubsectionRole> fieldSetSubsectionRoles;

	public FieldSetSubsection() {
	}

	public long getSubsectionkey() {
		return this.subsectionkey;
	}

	public void setSubsectionkey(long subsectionkey) {
		this.subsectionkey = subsectionkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getOrderno() {
		return this.orderno;
	}

	public void setOrderno(BigDecimal orderno) {
		this.orderno = orderno;
	}

	public BigDecimal getSubsectioncd() {
		return this.subsectioncd;
	}

	public void setSubsectioncd(BigDecimal subsectioncd) {
		this.subsectioncd = subsectioncd;
	}

	public String getSubsectionname() {
		return this.subsectionname;
	}

	public void setSubsectionname(String subsectionname) {
		this.subsectionname = subsectionname;
	}

	public List<FieldSetAttribute> getFieldSetAttributes() {
		return this.fieldSetAttributes;
	}

	public void setFieldSetAttributes(List<FieldSetAttribute> fieldSetAttributes) {
		this.fieldSetAttributes = fieldSetAttributes;
	}

	public FieldSetAttribute addFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		getFieldSetAttributes().add(fieldSetAttribute);
		fieldSetAttribute.setFieldSetSubsection(this);

		return fieldSetAttribute;
	}

	public FieldSetAttribute removeFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		getFieldSetAttributes().remove(fieldSetAttribute);
		fieldSetAttribute.setFieldSetSubsection(null);

		return fieldSetAttribute;
	}

	public FieldSetSection getFieldSetSection() {
		return this.fieldSetSection;
	}

	public void setFieldSetSection(FieldSetSection fieldSetSection) {
		this.fieldSetSection = fieldSetSection;
	}

	public List<FieldSetSubsectionRole> getFieldSetSubsectionRoles() {
		return this.fieldSetSubsectionRoles;
	}

	public void setFieldSetSubsectionRoles(List<FieldSetSubsectionRole> fieldSetSubsectionRoles) {
		this.fieldSetSubsectionRoles = fieldSetSubsectionRoles;
	}

	public FieldSetSubsectionRole addFieldSetSubsectionRole(FieldSetSubsectionRole fieldSetSubsectionRole) {
		getFieldSetSubsectionRoles().add(fieldSetSubsectionRole);
		fieldSetSubsectionRole.setFieldSetSubsection(this);

		return fieldSetSubsectionRole;
	}

	public FieldSetSubsectionRole removeFieldSetSubsectionRole(FieldSetSubsectionRole fieldSetSubsectionRole) {
		getFieldSetSubsectionRoles().remove(fieldSetSubsectionRole);
		fieldSetSubsectionRole.setFieldSetSubsection(null);

		return fieldSetSubsectionRole;
	}

}