package com.bfl.bfsd.empportal.rolemanagement.bean;

import java.util.List;

public class RoleAccessConfig {
	
	private Long productTypeKey;
	private Long functionKey;
	private List<Long> roleKeys;
	private List<Long> tabKeys;
	
	/**private List<TabBean> masterTabBean;
	 *private List<TabBean> assignedTabBean;
	 */
	
	List<CTASectionBean> ctaSectionbeanList;
	List<CTASectionBean> subSectionList;

	public Long getProductTypeKey() {
		return productTypeKey;
	}

	public void setProductTypeKey(Long productTypeKey) {
		this.productTypeKey = productTypeKey;
	}

	public Long getFunctionKey() {
		return functionKey;
	}

	public void setFunctionKey(Long functionKey) {
		this.functionKey = functionKey;
	}

	public List<Long> getRoleKeys() {
		return roleKeys;
	}

	public void setRoleKeys(List<Long> roleKeys) {
		this.roleKeys = roleKeys;
	}

	public List<Long> getTabKeys() {
		return tabKeys;
	}

	public void setTabKeys(List<Long> tabKeys) {
		this.tabKeys = tabKeys;
	}

	/**public List<TabBean> getMasterTabBean() {
	 *	return masterTabBean;
	 *}
	 *
	 *public void setMasterTabBean(List<TabBean> masterTabBean) {
	 *	this.masterTabBean = masterTabBean;
	 *}
	 *
	 *public List<TabBean> getAssignedTabBean() {
	 *	return assignedTabBean;
	 *}
	 *
	 *public void setAssignedTabBean(List<TabBean> assignedTabBean) {
	 *	this.assignedTabBean = assignedTabBean;
	 *}
	 *
	 *public List<List<CTASection>> getCtaSectionbeanList() {
	 *	return ctaSectionbeanList;
	 *}
	 *
	 *public void setCtaSectionbeanList(List<List<CTASection>> ctaSectionbeanList) {
	 *	this.ctaSectionbeanList = ctaSectionbeanList;
	 *}
	 */
	 
}
