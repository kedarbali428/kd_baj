package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the APP_QUEUE_DEFINITION database table.
 * 
 */
@Entity
@Table(name="APP_QUEUE_DEFINITION")
//@NamedQuery(name="AppQueueDefinition.findAll", query="SELECT a FROM AppQueueDefinition a")
public class AppQueueDefinition implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long queuekey;

	private String createdby;

	private Timestamp createddt;

	@Lob
	private String filtercondtionjason;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodmastkey;

	private String queuename;

	private BigDecimal queuestatus;

	private String whereclause;

	//bi-directional many-to-one association to AppQueueParamLocation
	@OneToMany(mappedBy="appQueueDefinition")
	private List<AppQueueParamLocation> appQueueParamLocations;

	//bi-directional many-to-one association to AppQueueParamProduct
	@OneToMany(mappedBy="appQueueDefinition")
	private List<AppQueueParamProduct> appQueueParamProducts;

	//bi-directional many-to-one association to AppRoleQueue
	@OneToMany(mappedBy="appQueueDefinition")
	private List<AppRoleQueue> appRoleQueues;

	public AppQueueDefinition() {
	}

	public long getQueuekey() {
		return this.queuekey;
	}

	public void setQueuekey(long queuekey) {
		this.queuekey = queuekey;
	}

	public String getCreatedby() {
		return this.createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public Timestamp getCreateddt() {
		return this.createddt;
	}

	public void setCreateddt(Timestamp createddt) {
		this.createddt = createddt;
	}

	public String getFiltercondtionjason() {
		return this.filtercondtionjason;
	}

	public void setFiltercondtionjason(String filtercondtionjason) {
		this.filtercondtionjason = filtercondtionjason;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(BigDecimal prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public String getQueuename() {
		return this.queuename;
	}

	public void setQueuename(String queuename) {
		this.queuename = queuename;
	}

	public BigDecimal getQueuestatus() {
		return this.queuestatus;
	}

	public void setQueuestatus(BigDecimal queuestatus) {
		this.queuestatus = queuestatus;
	}

	public String getWhereclause() {
		return this.whereclause;
	}

	public void setWhereclause(String whereclause) {
		this.whereclause = whereclause;
	}

	public List<AppQueueParamLocation> getAppQueueParamLocations() {
		return this.appQueueParamLocations;
	}

	public void setAppQueueParamLocations(List<AppQueueParamLocation> appQueueParamLocations) {
		this.appQueueParamLocations = appQueueParamLocations;
	}

	public AppQueueParamLocation addAppQueueParamLocation(AppQueueParamLocation appQueueParamLocation) {
		getAppQueueParamLocations().add(appQueueParamLocation);
		appQueueParamLocation.setAppQueueDefinition(this);

		return appQueueParamLocation;
	}

	public AppQueueParamLocation removeAppQueueParamLocation(AppQueueParamLocation appQueueParamLocation) {
		getAppQueueParamLocations().remove(appQueueParamLocation);
		appQueueParamLocation.setAppQueueDefinition(null);

		return appQueueParamLocation;
	}

	public List<AppQueueParamProduct> getAppQueueParamProducts() {
		return this.appQueueParamProducts;
	}

	public void setAppQueueParamProducts(List<AppQueueParamProduct> appQueueParamProducts) {
		this.appQueueParamProducts = appQueueParamProducts;
	}

	public AppQueueParamProduct addAppQueueParamProduct(AppQueueParamProduct appQueueParamProduct) {
		getAppQueueParamProducts().add(appQueueParamProduct);
		appQueueParamProduct.setAppQueueDefinition(this);

		return appQueueParamProduct;
	}

	public AppQueueParamProduct removeAppQueueParamProduct(AppQueueParamProduct appQueueParamProduct) {
		getAppQueueParamProducts().remove(appQueueParamProduct);
		appQueueParamProduct.setAppQueueDefinition(null);

		return appQueueParamProduct;
	}

	public List<AppRoleQueue> getAppRoleQueues() {
		return this.appRoleQueues;
	}

	public void setAppRoleQueues(List<AppRoleQueue> appRoleQueues) {
		this.appRoleQueues = appRoleQueues;
	}

	public AppRoleQueue addAppRoleQueue(AppRoleQueue appRoleQueue) {
		getAppRoleQueues().add(appRoleQueue);
		appRoleQueue.setAppQueueDefinition(this);

		return appRoleQueue;
	}

	public AppRoleQueue removeAppRoleQueue(AppRoleQueue appRoleQueue) {
		getAppRoleQueues().remove(appRoleQueue);
		appRoleQueue.setAppQueueDefinition(null);

		return appRoleQueue;
	}

}