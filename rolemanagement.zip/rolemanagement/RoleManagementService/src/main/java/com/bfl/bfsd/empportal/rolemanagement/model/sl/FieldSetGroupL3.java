package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import javax.persistence.*;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the FIELD_SET_GROUPS database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_GROUPS")
@NamedQueries({
//@NamedQuery(name="FieldSetGroupL3.findAll", query="SELECT f FROM FieldSetGroupL3 f"),
//@NamedQuery(name="FieldSetGroupL3.findAllGroupsSectionsAndSubSectionBasedOnRoleKeyAndFieldsetKey", 
//query="SELECT distinct fsg FROM FieldSetGroupL3 fsg, FieldSetSectionL3 fss,"
//		+ " FieldSetSubsectionL3 fssb, FieldSetSubsectionRoleL3 fssr,"
//		+ " HeaderTabGroup ht"
////		+ " UserRole ur,"
//		+ " ,FieldSetAttributeL3 fsa"
//		+ " where fsg.groupkey = fss.fieldSetGroup.groupkey"
//		//+ " and fsg.headerTabGroups.tabkey = ht.tabkey"
//		+ " and ht.tabkey IN :tabkeys"
//		+ " and fss.sectionkey = fssb.fieldSetSection.sectionkey"
//		+ " and fsa.fieldSetSubsection.subsectionkey=fssb.subsectionkey"
//		+ " and fss.sectionkey = fssb.fieldSetSection.sectionkey"
//		+ " and fssr.roleProductMapping.roleprodkey IN :roleKeys "
//		+ " and fssb.subsectionkey = fssr.fieldSetSubsection.subsectionkey"
////		+ " and ur.userrolekey IN :roleKeys"
//		+ " and fsg.isactive = 1"
//		+ " and fss.isactive = 1"
//		+ " and fssb.isactive = 1"
////		+ " and ur.isactive = 1"
//		+ " and fssr.isactive = 1"
//		+ " and fsa.isactive=1 "
//		),

@NamedQuery(name="FieldSetGroupL3.findAllGroupsSectionsAndSubSectionBasedOnRoleKeyAndTabKey", 
		query="SELECT Distinct fsg FROM FieldSetGroupL3 fsg"
		+ " left outer Join fsg.fieldSetGroupProducts fsgp"
		+ " inner join fsg.fieldSetSections fss"
		+ " left outer join fss.fieldSetSectionProducts fssp"
		+ " inner join fss.fieldSetSubsections fssb"
		//+ " inner join fsg.fieldSetMaster fsm "
		+ " inner join fsg.headerTabGroups ht "
		+ " left outer Join fssb.fieldSetSubsectionProducts fssbp"
		+ " inner join fssb.fieldSetSubsectionRoles fssr"
		+ " where ht.headerTabMaster.tabkey IN :tabkeys"
		+ " and (fsgp.prodmastkey = :prodkey or fsgp.prodmastkey is null)"
		+ " and (fsgp.subprodkey = :subprodkey or fsgp.subprodkey is null)"
		+ " and (fssbp.prodmastkey = :prodkey or fssbp.prodmastkey is null)"
		+ " and (fssbp.subprodkey = :subprodkey or fssbp.subprodkey is null)"
		+ " and (fssp.prodmastkey = :prodkey or fssp.prodmastkey  is null)"
		+ " and (fssp.subprodkey = :subprodkey or fssp.subprodkey is null)"
		+ " and fssr.roleProductMapping.roleprodkey IN :rolekeys"
		+ " and fsg.isactive = 1"
		+ " and fss.isactive = 1"
		+ " and fssb.isactive = 1"
		+ " and fssr.isactive = 1"
		),

@NamedQuery(name="FieldSetGroupL3.findAllSubSectionBasedOnSubSectionKeys", 
query="SELECT distinct fsg FROM FieldSetGroupL3 fsg"
		+ " left outer Join fsg.fieldSetGroupProducts fsgp"
		+ " inner join fsg.fieldSetSections fss"
		+ " left outer join fss.fieldSetSectionProducts fssp"
		+ " inner join fss.fieldSetSubsections fssb"
	//	+ " inner join fsg.fieldSetMaster fsm "
		+ " inner join fsg.headerTabGroups ht "
		+ " left outer Join fssb.fieldSetSubsectionProducts fssbp"
		+ " inner join fssb.fieldSetSubsectionRoles fssr"
		+ " where ht.headerTabMaster.tabkey IN :tabkeys"
		+ " and (fsgp.prodmastkey = :prodkey or fsgp.prodmastkey is null)"
		+ " and (fsgp.subprodkey = :subprodkey or fsgp.subprodkey is null)"
		+ " and (fssp.prodmastkey = :prodkey or fssp.prodmastkey is null)"
		+ " and (fssp.subprodkey = :subprodkey or fssp.subprodkey is null)"
		+ " and (fssbp.prodmastkey = :prodkey or fssbp.prodmastkey is null)"
		+ " and (fssbp.subprodkey = :subprodkey or fssbp.subprodkey is null) "
		+ " and (fssp.prodmastkey = :prodkey or fssp.prodmastkey is null)"
		+ " and (fssp.subprodkey = :subprodkey or fssp.subprodkey is null)"
		+ " and fssr.roleProductMapping.roleprodkey IN :rolekeys "
		+ " and fssb.subsectionkey IN :subsectionkeys"
		+ " and fss.sectionkey IN :sectionkeys"
		+ " and fsg.groupkey IN :groupkeys"
		+ " and fsg.isactive = 1"
		+ " and fss.isactive = 1"
		+ " and fssb.isactive = 1"
		+ " and fssr.isactive = 1"

),
@NamedQuery(name="FieldSetGroupL3.findAllSubSectionBasedOnSubSectionKeysFieldsetkeys", 
query="SELECT distinct fsg FROM FieldSetGroupL3 fsg"
		+ " left outer Join fsg.fieldSetGroupProducts fsgp"
		+ " inner join fsg.fieldSetSections fss"
		+ " inner join fss.fieldSetSubsections fssb"
//		+ " inner join fsg.fieldSetMaster fsm "
		+ " inner join fsg.headerTabGroups ht "		
		+ " left outer Join fssb.fieldSetSubsectionProducts fssbp"
		+ " left outer join fss.fieldSetSectionProducts as fssp"
		+ " inner join fssb.fieldSetSubsectionRoles fssr"
		+ " where ht.headerTabMaster.tabkey in :tabkeys"
		+ " and fssr.roleProductMapping.roleprodkey IN :rolekeys "	
		+ " and fssb.subsectionkey IN :subsectionkeys"
		+ " and fss.sectionkey IN :sectionkeys"
		+ " and fsg.groupkey IN :groupkeys"
		+ " and fsg.isactive = 1"
		+ " and fss.isactive = 1"
		+ " and fssb.isactive = 1")
})
public class FieldSetGroupL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long groupkey;

	private BigDecimal groupcd;

	private String groupname;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal orderno;

	//bi-directional many-to-one association to FieldSetMaster
	@ManyToOne
	@JoinColumn(name="FIELDSETKEY")
	private FieldSetMasterL3 fieldSetMaster;
	
	@OneToMany(mappedBy="fieldSetGroup")
	private List<HeaderTabGroup> headerTabGroups;

	//bi-directional many-to-one association to FieldSetGroupProduct
	@OneToMany(mappedBy="fieldSetGroup")
	private List<FieldSetGroupProduct> fieldSetGroupProducts;

	//bi-directional many-to-one association to FieldSetSection
	@OneToMany(mappedBy="fieldSetGroup")
	private List<FieldSetSectionL3> fieldSetSections;

	public FieldSetGroupL3() {
	}

	public long getGroupkey() {
		return this.groupkey;
	}

	public void setGroupkey(long groupkey) {
		this.groupkey = groupkey;
	}

	public BigDecimal getGroupcd() {
		return this.groupcd;
	}

	public void setGroupcd(BigDecimal groupcd) {
		this.groupcd = groupcd;
	}

	public String getGroupname() {
		return this.groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getOrderno() {
		return this.orderno;
	}

	public void setOrderno(BigDecimal orderno) {
		this.orderno = orderno;
	}

	public FieldSetMasterL3 getFieldSetMaster() {
		return this.fieldSetMaster;
	}

	public void setFieldSetMaster(FieldSetMasterL3 fieldSetMaster) {
		this.fieldSetMaster = fieldSetMaster;
	}

	public List<FieldSetGroupProduct> getFieldSetGroupProducts() {
		return this.fieldSetGroupProducts;
	}

	public void setFieldSetGroupProducts(List<FieldSetGroupProduct> fieldSetGroupProducts) {
		this.fieldSetGroupProducts = fieldSetGroupProducts;
	}

	public FieldSetGroupProduct addFieldSetGroupProduct(FieldSetGroupProduct fieldSetGroupProduct) {
		getFieldSetGroupProducts().add(fieldSetGroupProduct);
		fieldSetGroupProduct.setFieldSetGroup(this);

		return fieldSetGroupProduct;
	}

	public FieldSetGroupProduct removeFieldSetGroupProduct(FieldSetGroupProduct fieldSetGroupProduct) {
		getFieldSetGroupProducts().remove(fieldSetGroupProduct);
		fieldSetGroupProduct.setFieldSetGroup(null);

		return fieldSetGroupProduct;
	}

	public List<FieldSetSectionL3> getFieldSetSections() {
		return this.fieldSetSections;
	}

	public void setFieldSetSections(List<FieldSetSectionL3> fieldSetSections) {
		this.fieldSetSections = fieldSetSections;
	}

	public FieldSetSectionL3 addFieldSetSection(FieldSetSectionL3 fieldSetSection) {
		getFieldSetSections().add(fieldSetSection);
		fieldSetSection.setFieldSetGroup(this);

		return fieldSetSection;
	}

	public FieldSetSectionL3 removeFieldSetSection(FieldSetSectionL3 fieldSetSection) {
		getFieldSetSections().remove(fieldSetSection);
		fieldSetSection.setFieldSetGroup(null);

		return fieldSetSection;
	}
	
	public List<HeaderTabGroup> getHeaderTabGroups() {
		return this.headerTabGroups;
	}

	public void setHeaderTabGroups(List<HeaderTabGroup> headerTabGroups) {
		this.headerTabGroups = headerTabGroups;
	}

	public HeaderTabGroup addHeaderTabGroups(HeaderTabGroup headerTabGroup) {
		getHeaderTabGroups().add(headerTabGroup);
		headerTabGroup.setFieldSetGroup(this);

		return headerTabGroup;
	}

	public HeaderTabGroup removeHeaderTabGroups(HeaderTabGroup headerTabGroup) {
		getHeaderTabGroups().remove(headerTabGroup);
		headerTabGroup.setFieldSetGroup(null);

		return headerTabGroup;
	}

}