package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the FIELD_SET_SUBSECTION_PRODUCTS database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_SUBSECTION_PRODUCTS")
//@NamedQuery(name="FieldSetSubsectionProduct.findAll", query="SELECT f FROM FieldSetSubsectionProduct f")
public class FieldSetSubsectionProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long tabprodkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodmastkey;

	private BigDecimal subprodkey;

	//bi-directional many-to-one association to FieldSetSubsection
	@ManyToOne
	@JoinColumn(name="SUBSECTIONKEY")
	private FieldSetSubsectionL3 fieldSetSubsection;

	public FieldSetSubsectionProduct() {
	}

	public long getTabprodkey() {
		return this.tabprodkey;
	}

	public void setTabprodkey(long tabprodkey) {
		this.tabprodkey = tabprodkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(BigDecimal prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public BigDecimal getSubprodkey() {
		return this.subprodkey;
	}

	public void setSubprodkey(BigDecimal subprodkey) {
		this.subprodkey = subprodkey;
	}

	public FieldSetSubsectionL3 getFieldSetSubsection() {
		return this.fieldSetSubsection;
	}

	public void setFieldSetSubsection(FieldSetSubsectionL3 fieldSetSubsection) {
		this.fieldSetSubsection = fieldSetSubsection;
	}

}