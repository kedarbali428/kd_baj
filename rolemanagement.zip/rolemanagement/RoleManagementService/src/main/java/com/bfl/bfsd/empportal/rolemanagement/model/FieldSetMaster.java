package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the FIELD_SET_MASTER database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_MASTER")
//@NamedQuery(name="FieldSetMaster.findAll", query="SELECT f FROM FieldSetMaster f")
public class FieldSetMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long fieldsetkey;

	private BigDecimal fieldsetcd;

	private String fieldsetname;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to FieldSetGroup
	@OneToMany(mappedBy="fieldSetMaster")
	private List<FieldSetGroup> fieldSetGroups;

	public FieldSetMaster() {
	}

	public long getFieldsetkey() {
		return this.fieldsetkey;
	}

	public void setFieldsetkey(long fieldsetkey) {
		this.fieldsetkey = fieldsetkey;
	}

	public BigDecimal getFieldsetcd() {
		return this.fieldsetcd;
	}

	public void setFieldsetcd(BigDecimal fieldsetcd) {
		this.fieldsetcd = fieldsetcd;
	}

	public String getFieldsetname() {
		return this.fieldsetname;
	}

	public void setFieldsetname(String fieldsetname) {
		this.fieldsetname = fieldsetname;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public List<FieldSetGroup> getFieldSetGroups() {
		return this.fieldSetGroups;
	}

	public void setFieldSetGroups(List<FieldSetGroup> fieldSetGroups) {
		this.fieldSetGroups = fieldSetGroups;
	}

	public FieldSetGroup addFieldSetGroup(FieldSetGroup fieldSetGroup) {
		getFieldSetGroups().add(fieldSetGroup);
		fieldSetGroup.setFieldSetMaster(this);

		return fieldSetGroup;
	}

	public FieldSetGroup removeFieldSetGroup(FieldSetGroup fieldSetGroup) {
		getFieldSetGroups().remove(fieldSetGroup);
		fieldSetGroup.setFieldSetMaster(null);

		return fieldSetGroup;
	}

}