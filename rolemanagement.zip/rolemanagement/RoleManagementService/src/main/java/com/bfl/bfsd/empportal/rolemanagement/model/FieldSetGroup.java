package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the FIELD_SET_GROUPS database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_GROUPS")
@NamedQueries({
//@NamedQuery(name="FieldSetGroup.findAll", query="SELECT f FROM FieldSetGroup f"),
@NamedQuery(name="FieldSetGroup.findAllGroupsAndSections", 
query="SELECT distinct fsg FROM FieldSetGroup fsg, FieldSetSection fss, "
		+ " FieldSetSubsection fssb, FieldSetMaster fsm, UserRole ur, FieldSetSubsectionRole fssr"
		+ " where fsg.groupkey = fss.fieldSetGroup.groupkey"
		+ " and fsg.fieldSetMaster.fieldsetkey = fsm.fieldsetkey"
		+ " and fsm.fieldsetcd IN :fieldsetcds"
		+ " and fss.sectionkey = fssb.fieldSetSection.sectionkey"
		+ " and fssr.rolekey = ur.bfsdRoleMaster.rolekey "
		+ " and fssb.subsectionkey = fssr.fieldSetSubsection.subsectionkey"
		+ " and ur.userrolekey IN :roleKeys"
		+ " and fsg.isactive = 1"
		+ " and fss.isactive = 1"
		+ " and fssb.isactive = 1"
		+ " and fsm.isactive = 1"
		+ " and ur.isactive = 1"
		+ " and fssr.isactive = 1"),

@NamedQuery(name="FieldSetGroup.findAllGroupsSectionsAndSubSectionBasedOnRoleKeyAndTabKey", 
query="SELECT distinct fsg FROM FieldSetGroup fsg, FieldSetSection fss, "
		+ " FieldSetSubsection fssb, FieldSetMaster fsm, FieldSetSubsectionRole fssr"
//		+ " UserRole ur,"
		+ " where fsg.groupkey = fss.fieldSetGroup.groupkey"
		+ " and fsg.fieldSetMaster.fieldsetkey = fsm.fieldsetkey"
		+ " and fsm.fieldsetcd IN :fieldsetcds"
		+ " and fss.sectionkey = fssb.fieldSetSection.sectionkey"
		+ " and fssr.rolekey IN :roleKeys "
		+ " and fssb.subsectionkey = fssr.fieldSetSubsection.subsectionkey"
//		+ " and ur.userrolekey IN :roleKeys"
		+ " and fsg.isactive = 1"
		+ " and fss.isactive = 1"
		+ " and fssb.isactive = 1"
		+ " and fsm.isactive = 1"
//		+ " and ur.isactive = 1"
		+ " and fssr.isactive = 1"),

@NamedQuery(name="FieldSetGroup.findAllSubSectionBasedOnSubSectionKeys", 
query="SELECT distinct fsg FROM FieldSetGroup fsg, FieldSetSection fss, "
		+ " FieldSetSubsection fssb, FieldSetMaster fsm, FieldSetSubsectionRole fssr"
		+ " where fsg.groupkey = fss.fieldSetGroup.groupkey"
		+ " and fsg.fieldSetMaster.fieldsetkey = fsm.fieldsetkey"
		+ " and fsm.fieldsetcd IN :fieldsetcds"
//		+ " and fss.sectionkey = fssb.fieldSetSection.sectionkey"
		+ " and fssr.rolekey IN :roleKeys "
		+ " and fssb.subsectionkey = fssr.fieldSetSubsection.subsectionkey"
		+ " and fssb.subsectionkey IN :subsectionkeys"
		+ " and fss.sectionkey IN :sectionkeys"
		+ " and fsg.groupkey IN :groupkeys"
		+ " and fsg.isactive = 1"
		+ " and fss.isactive = 1"
		+ " and fssb.isactive = 1"
		+ " and fsm.isactive = 1"
//		+ " and ur.isactive = 1"
	//	+ " and fssr.isactive = 1"
)
})

public class FieldSetGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long groupkey;

	private BigDecimal groupcd;

	private String groupname;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal orderno;

	//bi-directional many-to-one association to FieldSetMaster
	@ManyToOne
	@JoinColumn(name="FIELDSETKEY")
	private FieldSetMaster fieldSetMaster;

	//bi-directional many-to-one association to FieldSetSection
	@OneToMany(mappedBy="fieldSetGroup")
	private List<FieldSetSection> fieldSetSections;

	public FieldSetGroup() {
	}

	public long getGroupkey() {
		return this.groupkey;
	}

	public void setGroupkey(long groupkey) {
		this.groupkey = groupkey;
	}

	public BigDecimal getGroupcd() {
		return this.groupcd;
	}

	public void setGroupcd(BigDecimal groupcd) {
		this.groupcd = groupcd;
	}

	public String getGroupname() {
		return this.groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getOrderno() {
		return this.orderno;
	}

	public void setOrderno(BigDecimal orderno) {
		this.orderno = orderno;
	}

	public FieldSetMaster getFieldSetMaster() {
		return this.fieldSetMaster;
	}

	public void setFieldSetMaster(FieldSetMaster fieldSetMaster) {
		this.fieldSetMaster = fieldSetMaster;
	}

	public List<FieldSetSection> getFieldSetSections() {
		return this.fieldSetSections;
	}

	public void setFieldSetSections(List<FieldSetSection> fieldSetSections) {
		this.fieldSetSections = fieldSetSections;
	}

	public FieldSetSection addFieldSetSection(FieldSetSection fieldSetSection) {
		getFieldSetSections().add(fieldSetSection);
		fieldSetSection.setFieldSetGroup(this);

		return fieldSetSection;
	}

	public FieldSetSection removeFieldSetSection(FieldSetSection fieldSetSection) {
		getFieldSetSections().remove(fieldSetSection);
		fieldSetSection.setFieldSetGroup(null);

		return fieldSetSection;
	}

}