package com.bfl.bfsd.empportal.rolemanagement.bean;

import java.math.BigDecimal;
import java.util.List;

public class RoleTabKeyAndNameResponse implements Comparable<RoleTabKeyAndNameResponse>{

	private BigDecimal tabKey;
	private String tabName;
	private BigDecimal tabCode;
	private BigDecimal viewOrder;
	private List<SubProductBean> subProductBean;

	

	public BigDecimal getTabKey() {
		return tabKey;
	}

	public void setTabKey(BigDecimal tabKey) {
		this.tabKey = tabKey;
	}

	public String getTabName() {
		return tabName;
	}

	public void setTabName(String tabName) {
		this.tabName = tabName;
	}

	

	public List<SubProductBean> getSubProductBean() {
		return subProductBean;
	}

	public void setSubProductBean(List<SubProductBean> subProductBean) {
		this.subProductBean = subProductBean;
	}

	/**
	 * @return the tabCode
	 */
	public BigDecimal getTabCode() {
		return tabCode;
	}

	/**
	 * @param tabCode the tabCode to set
	 */
	public void setTabCode(BigDecimal tabCode) {
		this.tabCode = tabCode;
	}

	public BigDecimal getViewOrder() {
		return viewOrder;
	}

	public void setViewOrder(BigDecimal viewOrder) {
		this.viewOrder = viewOrder;
	}
	
	@Override public int compareTo(RoleTabKeyAndNameResponse u) { 
	    if (getViewOrder() == null || u.getViewOrder() == null) { 
	      return 0; 
	    } 
	    return getViewOrder().compareTo(u.getViewOrder());
	  } 
	
	
}
