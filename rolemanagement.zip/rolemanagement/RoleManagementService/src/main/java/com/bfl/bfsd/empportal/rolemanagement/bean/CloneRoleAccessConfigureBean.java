package com.bfl.bfsd.empportal.rolemanagement.bean;

import java.util.List;

public class CloneRoleAccessConfigureBean {

	private List<Long> roleKeyFrom;
	private long productkeyFrom;
	private long subprodkeyFrom;
	private List<Long> roleKeysTo;
	private long productkeyTo;
	private long subprodkeyTo;

	public List<Long> getRoleKeyFrom() {
		return roleKeyFrom;
	}

	/**
	 * @return the productkeyFrom
	 */
	public long getProductkeyFrom() {
		return productkeyFrom;
	}

	/**
	 * @param productkeyFrom the productkeyFrom to set
	 */
	public void setProductkeyFrom(long productkeyFrom) {
		this.productkeyFrom = productkeyFrom;
	}

	/**
	 * @return the subprodkeyFrom
	 */
	public long getSubprodkeyFrom() {
		return subprodkeyFrom;
	}

	/**
	 * @param subprodkeyFrom the subprodkeyFrom to set
	 */
	public void setSubprodkeyFrom(long subprodkeyFrom) {
		this.subprodkeyFrom = subprodkeyFrom;
	}

	/**
	 * @return the productkeyTo
	 */
	public long getProductkeyTo() {
		return productkeyTo;
	}

	/**
	 * @param productkeyTo the productkeyTo to set
	 */
	public void setProductkeyTo(long productkeyTo) {
		this.productkeyTo = productkeyTo;
	}

	/**
	 * @return the subprodkeyTo
	 */
	public long getSubprodkeyTo() {
		return subprodkeyTo;
	}

	/**
	 * @param subprodkeyTo the subprodkeyTo to set
	 */
	public void setSubprodkeyTo(long subprodkeyTo) {
		this.subprodkeyTo = subprodkeyTo;
	}

	public void setRoleKeyFrom(List<Long> roleKeyFrom) {
		this.roleKeyFrom = roleKeyFrom;
	}

	public List<Long> getRoleKeysTo() {
		return roleKeysTo;
	}

	public void setRoleKeysTo(List<Long> roleKeysTo) {
		this.roleKeysTo = roleKeysTo;
	}

}
