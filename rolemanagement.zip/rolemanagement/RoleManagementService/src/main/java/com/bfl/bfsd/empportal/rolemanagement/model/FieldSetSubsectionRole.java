package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the FIELD_SET_SUBSECTION_ROLE database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_SUBSECTION_ROLE")
@NamedQueries({
	//@NamedQuery(name="FieldSetSubsectionRole.findAll", query="SELECT f FROM FieldSetSubsectionRole f"),
	@NamedQuery(name="FieldSetSubsectionRole.DeactivateFieldSetRoles",query="UPDATE FieldSetSubsectionRole f set f.isactive = 0 "
		+ " WHERE f.isactive = 1 AND f.fieldSetSubsection.subsectionkey IN :subsectionkeys and f.rolekey IN :rolekeys"),
	@NamedQuery(name="FieldSetSubsectionRole.DeactivateAllSubSectionRoles",query="UPDATE FieldSetSubsectionRole f set f.isactive = 0 "
			+ " WHERE f.isactive = 1 AND f.rolekey IN :rolekeys"),
	@NamedQuery(name="FieldSetSubsectionRole.FetchAllByRole",query="SELECT f FROM FieldSetSubsectionRole f"
			+ " WHERE f.isactive = 1 AND f.rolekey IN :rolekeys")
})

public class FieldSetSubsectionRole implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long sectionrolekey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal rolekey;

	private String selectclause;

	//bi-directional many-to-one association to FieldSetSubsection
	@ManyToOne
	@JoinColumn(name="SUBSECTIONKEY")
	private FieldSetSubsection fieldSetSubsection;

	public FieldSetSubsectionRole() {
	}

	public long getSectionrolekey() {
		return this.sectionrolekey;
	}

	public void setSectionrolekey(long sectionrolekey) {
		this.sectionrolekey = sectionrolekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getRolekey() {
		return this.rolekey;
	}

	public void setRolekey(BigDecimal rolekey) {
		this.rolekey = rolekey;
	}

	public String getSelectclause() {
		return this.selectclause;
	}

	public void setSelectclause(String selectclause) {
		this.selectclause = selectclause;
	}

	public FieldSetSubsection getFieldSetSubsection() {
		return this.fieldSetSubsection;
	}

	public void setFieldSetSubsection(FieldSetSubsection fieldSetSubsection) {
		this.fieldSetSubsection = fieldSetSubsection;
	}
	
	@Override
	public Object clone()throws CloneNotSupportedException{  
		return super.clone();  
		}  

}