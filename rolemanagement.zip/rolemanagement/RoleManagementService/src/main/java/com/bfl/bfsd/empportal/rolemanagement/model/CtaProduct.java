package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;

import com.bfl.bfsd.empportal.rolemanagement.model.sl.CtaRoleL3;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the CTA_PRODUCT database table.
 * 
 */
@Entity
@Table(name="CTA_PRODUCT")
@NamedQueries({
//@NamedQuery(name="CtaProduct.findAll", query="SELECT c FROM CtaProduct c"),
@NamedQuery(name="CtaProduct.findByCtaIdAndProductMasterKey", query="SELECT c FROM CtaProduct c where c.isactive =1 "
		+ "AND c.prodmastkey =:productMasterKey AND c.ctaType.ctakey =:ctaKey"),
@NamedQuery(name="CtaProduct.findAlldByCtaIdAndProductMasterKey", 
query="SELECT c FROM CtaProduct c WHERE c.isactive =1 AND c.prodmastkey =:productMasterKey AND c.ctaType.ctakey IN :ctaKeys"),	
@NamedQuery(name="CtaProduct.findAlldByCtaIdAndProductMasterKeyandSubprodkey", 
query="SELECT c FROM CtaProduct c WHERE c.isactive =1 AND"
		+ " c.prodmastkey =:productMasterKey and c.subprodtypekey= :subprodkey AND c.ctaType.ctakey IN :ctaKeys")
})
public class CtaProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long ctaprodkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal prodmastkey;

	private BigDecimal subprodtypekey;

	//bi-directional many-to-one association to CtaType
	@ManyToOne
	@JoinColumn(name="CTAKEY")
	private CtaType ctaType;

	//bi-directional many-to-one association to CtaRole
	@OneToMany(mappedBy="ctaProduct")
	private List<CtaRole> ctaRoles;
	
	@OneToMany(mappedBy="ctaProduct")
	private List<CtaRoleL3> ctaroles;

	public CtaProduct() {
	}

	public long getCtaprodkey() {
		return this.ctaprodkey;
	}

	public void setCtaprodkey(long ctaprodkey) {
		this.ctaprodkey = ctaprodkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(BigDecimal prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public BigDecimal getSubprodtypekey() {
		return this.subprodtypekey;
	}

	public void setSubprodtypekey(BigDecimal subprodtypekey) {
		this.subprodtypekey = subprodtypekey;
	}

	public CtaType getCtaType() {
		return this.ctaType;
	}

	public void setCtaType(CtaType ctaType) {
		this.ctaType = ctaType;
	}

	public List<CtaRole> getCtaRoles() {
		return this.ctaRoles;
	}

	public void setCtaRoles(List<CtaRole> ctaRoles) {
		this.ctaRoles = ctaRoles;
	}

	public CtaRole addCtaRole(CtaRole ctaRole) {
		getCtaRoles().add(ctaRole);
		ctaRole.setCtaProduct(this);

		return ctaRole;
	}

	public CtaRole removeCtaRole(CtaRole ctaRole) {
		getCtaRoles().remove(ctaRole);
		ctaRole.setCtaProduct(null);

		return ctaRole;
	}
	public List<CtaRoleL3> getCtaroles() {
		return this.ctaroles;
	}

	public void setCtaroles(List<CtaRoleL3> ctaroles) {
		this.ctaroles = ctaroles;
	}

	public CtaRoleL3 addCtarole(CtaRoleL3 ctarole) {
		getCtaroles().add(ctarole);
		ctarole.setCtaProduct(this);

		return ctarole;
	}

	public CtaRoleL3 removeCtarole(CtaRoleL3 ctarole) {
		getCtaroles().remove(ctarole);
		ctarole.setCtaProduct(null);

		return ctarole;
	}

}