package com.bfl.bfsd.empportal.rolemanagement.enums;

import java.util.ArrayList;
import java.util.List;

public enum HeaderTabKeyNFieldSetMasterMappingEnum {

	LOAN(1,1),
	INSURANCE(2,2),
	SERVICE_REQUEST(6,3),
	GLOBAL_SEARCH(16,16);
	
	private long headerTabCd;
	private long fieldSetMasterCode;
	
	HeaderTabKeyNFieldSetMasterMappingEnum(long tabCd, long fieldSetCode){
		this.headerTabCd = tabCd;
		this.fieldSetMasterCode = fieldSetCode;
	}
	
	public static long getFieldSetCodeForHeaderTabKey(long headerTabCd){
		
		for (HeaderTabKeyNFieldSetMasterMappingEnum map : HeaderTabKeyNFieldSetMasterMappingEnum.values()) {
			if(map.headerTabCd == headerTabCd){
				return map.fieldSetMasterCode;
			}
		}
		return 1;
	}
	
	public static List<Long> getFieldSetCodesForHeaderTabKeys(List<Long> tabcds) {

		List<Long> fieldSetCodes = new ArrayList<>();
		for (HeaderTabKeyNFieldSetMasterMappingEnum map : HeaderTabKeyNFieldSetMasterMappingEnum.values()) {
			for(Long headerTabCd : tabcds){
				if (map.headerTabCd == headerTabCd) {
					fieldSetCodes.add(map.fieldSetMasterCode);
				}
			}
		}
		return fieldSetCodes;
	}
}
