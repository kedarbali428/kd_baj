package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the CASE_ASSIGNMENT database table.
 * 
 */
@Entity
@Table(name="CASE_ASSIGNMENT")
//@NamedQuery(name="CaseAssignment.findAll", query="SELECT c FROM CaseAssignment c")
public class CaseAssignment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long assignmentkey;

	private Timestamp assignenddt;

	private Timestamp assignstrtdt;

	private BigDecimal consentflg;

	private BigDecimal dockitstatus;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal paymentflg;

	private BigDecimal rschdoutoflimit;

	//bi-directional many-to-one association to CaseApplication
	@ManyToOne
	@JoinColumn(name="APPCASEKEY")
	private CaseApplication caseApplication;

	//bi-directional many-to-one association to UserRole
	@ManyToOne
	@JoinColumn(name="USERROLEKEY")
	private UserRole userRole;

	public CaseAssignment() {
	}

	public long getAssignmentkey() {
		return this.assignmentkey;
	}

	public void setAssignmentkey(long assignmentkey) {
		this.assignmentkey = assignmentkey;
	}

	public Timestamp getAssignenddt() {
		return this.assignenddt;
	}

	public void setAssignenddt(Timestamp assignenddt) {
		this.assignenddt = assignenddt;
	}

	public Timestamp getAssignstrtdt() {
		return this.assignstrtdt;
	}

	public void setAssignstrtdt(Timestamp assignstrtdt) {
		this.assignstrtdt = assignstrtdt;
	}

	public BigDecimal getConsentflg() {
		return this.consentflg;
	}

	public void setConsentflg(BigDecimal consentflg) {
		this.consentflg = consentflg;
	}

	public BigDecimal getDockitstatus() {
		return this.dockitstatus;
	}

	public void setDockitstatus(BigDecimal dockitstatus) {
		this.dockitstatus = dockitstatus;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getPaymentflg() {
		return this.paymentflg;
	}

	public void setPaymentflg(BigDecimal paymentflg) {
		this.paymentflg = paymentflg;
	}

	public BigDecimal getRschdoutoflimit() {
		return this.rschdoutoflimit;
	}

	public void setRschdoutoflimit(BigDecimal rschdoutoflimit) {
		this.rschdoutoflimit = rschdoutoflimit;
	}

	public CaseApplication getCaseApplication() {
		return this.caseApplication;
	}

	public void setCaseApplication(CaseApplication caseApplication) {
		this.caseApplication = caseApplication;
	}

	public UserRole getUserRole() {
		return this.userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

}