package com.bfl.bfsd.empportal.rolemanagement.bean;


import java.util.List;

public class Section {
	
	private String sectionName;
	private Long tabKey;
    private int sectionId;
	public int getSectionId() {
		return sectionId;
	}

	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}

	private List<CTABean> ctaBeanList;
	private List<Section> subSectionList;
	
	public Long getTabKey() {
		return tabKey;
	}

	public void setTabKey(Long tabKey) {
		this.tabKey = tabKey;
	}

	public List<Section> getSubSectionList() {
		return subSectionList;
	}

	public void setSubSectionList(List<Section> subSectionList) {
		this.subSectionList = subSectionList;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public List<CTABean> getCtaBeanList() {
		return ctaBeanList;
	}

	public void setCtaBeanList(List<CTABean> ctaBeanList) {
		this.ctaBeanList = ctaBeanList;
	}
}
