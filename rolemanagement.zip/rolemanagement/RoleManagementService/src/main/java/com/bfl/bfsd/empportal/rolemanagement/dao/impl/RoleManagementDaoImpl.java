package com.bfl.bfsd.empportal.rolemanagement.dao.impl;

import static com.bajaj.bfsd.common.BFLLoggerComponent.DAO;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_ERR_MSG1;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG1;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG10;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG2;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG3;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG4;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG5;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG6;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG7;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG8;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG9;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.cache.service.UserCacheService;
import com.bajaj.bfsd.common.cache.service.entity.CacheUserEntity;
import com.bfl.bfsd.empportal.rolemanagement.bean.AssignedRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.CTABean;
import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.FieldAccessBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.LinkBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleBasedUsersListResponceBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleBasedUsersResponseBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.Section;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabBean;
import com.bfl.bfsd.empportal.rolemanagement.dao.RoleManagementDao;
import com.bfl.bfsd.empportal.rolemanagement.enums.HeaderTabKeyNFieldSetMasterMappingEnum;
import com.bfl.bfsd.empportal.rolemanagement.model.BfsdRoleMaster;
import com.bfl.bfsd.empportal.rolemanagement.model.CtaProduct;
import com.bfl.bfsd.empportal.rolemanagement.model.CtaRole;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetAttribute;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetGroup;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetRole;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsection;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsectionRole;
import com.bfl.bfsd.empportal.rolemanagement.model.HeaderTabMaster;
import com.bfl.bfsd.empportal.rolemanagement.model.HeaderTabRole;
import com.bfl.bfsd.empportal.rolemanagement.model.LinkSectionBean;
import com.bfl.bfsd.empportal.rolemanagement.model.ProductMaster;
import com.bfl.bfsd.empportal.rolemanagement.model.UserRole;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

/**
 * Description of the class This class is the dao implementation class for the
 * Role Management Dao
 *
 * @author Cognizant - Date - 27/02/2017
 * 
 *         Version BugId UsrId Date Description 1.0 27/02/2017
 *
 */
@SuppressWarnings("unchecked")
@PropertySource("classpath:application.properties")
@Component
public class RoleManagementDaoImpl extends BFLComponent implements RoleManagementDao {

	@Autowired
	EntityManager entityManager;

	@Autowired
	Environment env;

	@Autowired
	EntityManagerFactory entityManagerFactory;

	/**
	 * @Inject
	 * @RequestScoped
	 */
	@Autowired
	BFLLoggerUtil logger;

	private static final String CLASS_NAME = RoleManagementDaoImpl.class.getCanonicalName();

	private static final String ISACTIVE = "isactive";
	private static final String ROLEKEY = "rolekey";
	private static final String BFSDROLEMASTER = "bfsdRoleMaster";
	private static final String ROLEKEYS = "rolekeys";
	private static final String RKEY = "roleKeys";
	private static final String PRODKEY = "prodkey";
	private static final String SUBPRODKEY = "subprodkey";
	private static final String TABKEY = "tabKeys";
	private static final String LINKKEY = "linkKeys";
	@Autowired
	UserCacheService userCacheService;

	@Override
	public RoleAccessConfigurationBean getTabDetails(List<Long> roleKey) {

		RoleAccessConfigurationBean roleAccessConfigBean = new RoleAccessConfigurationBean();
		CriteriaBuilder criteriaBlde = entityManager.getCriteriaBuilder();
		CriteriaQuery<HeaderTabMaster> criteriaQry = criteriaBlde.createQuery(HeaderTabMaster.class);
		Root<HeaderTabMaster> rootHeaderTabMaster = criteriaQry.from(HeaderTabMaster.class);
		criteriaQry.select(rootHeaderTabMaster);
		criteriaQry.orderBy(criteriaBlde.asc(rootHeaderTabMaster.get("vieworder")));
		CriteriaQuery<HeaderTabRole> criteriaQry2 = criteriaBlde.createQuery(HeaderTabRole.class);
		Root<HeaderTabRole> rootHeaderTabRole = criteriaQry2.from(HeaderTabRole.class);

		List<Long> assignedTabBeanList = getAssignedTab(criteriaBlde, criteriaQry2, rootHeaderTabRole, roleKey);

		criteriaQry.where(criteriaBlde.equal(rootHeaderTabMaster.get(ISACTIVE), new BigDecimal(1)));
		List<HeaderTabMaster> masterTabBeanList = entityManager.createQuery(criteriaQry).getResultList();
		List<TabBean> tabBeanList = new ArrayList<>();
		for (HeaderTabMaster headTadMaster : masterTabBeanList) {
			TabBean tab = new TabBean();
			tab.setTabKey(headTadMaster.getTabkey());
			tab.setTabName(headTadMaster.getTabname());
			tab.setTabCode(headTadMaster.getTabcd().longValue());
			if (assignedTabBeanList.contains(headTadMaster.getTabkey()))
				tab.setSelected(true);
			tabBeanList.add(tab);
		}
		roleAccessConfigBean.setTabBeanList(tabBeanList);
		return roleAccessConfigBean;
	}

	private List<Long> getAssignedTab(CriteriaBuilder criteriaBlde, CriteriaQuery<HeaderTabRole> criteriaQry2,
			Root<HeaderTabRole> rootHeaderTabRole, List<Long> roleKey) {

		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlde.equal(rootHeaderTabRole.get(ISACTIVE), new BigDecimal(1)));
		predicates.add(rootHeaderTabRole.get(BFSDROLEMASTER).get(ROLEKEY).in(roleKey));

		criteriaQry2.select(rootHeaderTabRole).where(predicates.toArray(new Predicate[] {}));
		List<HeaderTabRole> results = entityManager.createQuery(criteriaQry2).getResultList();
		List<Long> tabBeanKeyList = new ArrayList<>();
		for (HeaderTabRole headTadRole : results) {

			tabBeanKeyList.add(headTadRole.getHeaderTabMaster().getTabkey());
		}
		return tabBeanKeyList;
	}

	@Override
	public RoleAccessConfigurationBean getCTADetails(RoleAccessConfigurationBean inputbean) {
		RoleAccessConfigurationBean roleAccessConfigBean = new RoleAccessConfigurationBean();
		List<Long> assignedCTAKeyList;
		String nativeQueryStr;

		if (inputbean.getSubprodkey() == null) {

			assignedCTAKeyList = getAssignedCTAKeyList(inputbean.getRoleKeys());
			nativeQueryStr =

					"select h.tabkey, m.tabname ||' CTAs' tabname,c.ctakey,c.ctaname,s.sectionkey,"
							+ "(select f.sectionname from field_set_sections f where f.sectionkey = s.sectionkey) sectionname "
							+ " from header_tab_master m,header_tab_cta h,cta_types c,cta_section s where h.tabkey = ?tabKey "
							+ " and h.tabkey = m.tabkey and h.ctakey = c.ctakey and c.isactive=1 and c.ctakey = s.ctakey(+) order by c.ctaname ";
		}

		else {
			assignedCTAKeyList = getAssignedCTAKeyListBasedonL3(inputbean.getRoleKeys(), inputbean.getProductTypeKey(),
					inputbean.getSubprodkey().get(0));
			nativeQueryStr = "SELECT h.tabkey,m.tabname||' CTAs' tabname,c.ctakey,c.ctaname,s.sectionkey,s.sectionname"
					+ " from header_tab_master m, header_tab_cta h, cta_types c,"
					+ " (select s.ctakey,s.sectionkey,f.sectionname from  cta_section s,field_set_sections f where s.sectionkey = f.sectionkey and s.isactive = 1 ) s,"
					+ " cta_product cp WHERE m.tabkey = h.tabkey AND h.ctakey = c.ctakey AND c.ctakey = s.ctakey(+)"
					+ " AND c.ctakey= cp.ctakey AND h.isactive = 1 AND cp.isactive = 1 and c.isactive=1"
					+ " AND m.tabkey = ?tabKey AND cp.prodmastkey =:prodkey AND cp.subprodtypekey = :subprodkey";
		}

		List<Section> sectionBeanList = new ArrayList<>();
		for (Long tabKey : inputbean.getTabKeys()) {
			List<Object[]> ctaKeyList;
			if (inputbean.getSubprodkey() == null) {

				ctaKeyList = entityManager.createNativeQuery(nativeQueryStr.replace("?tabKey", tabKey.toString()))
						.getResultList();
			} else {
				ctaKeyList = entityManager.createNativeQuery(nativeQueryStr.replace("?tabKey", tabKey.toString()))
						.setParameter(PRODKEY, inputbean.getProductTypeKey())
						.setParameter(SUBPRODKEY, inputbean.getSubprodkey().get(0)).getResultList();

			}
			List<CTABean> topCtaBeanList = new ArrayList<>();
			Map<String, List<CTABean>> subSectionMap = new HashMap<>();
			if (ctaKeyList != null && !ctaKeyList.isEmpty()) {
				Section section = new Section();
				for (Object[] a : ctaKeyList) {
					sectioncheck(section, a);
					setbean(assignedCTAKeyList, a, topCtaBeanList, subSectionMap);

				}

				section.setCtaBeanList(topCtaBeanList);
				Iterator<String> keyIterator = subSectionMap.keySet().iterator();
				List<Section> subSectionList = new ArrayList<>();
				int sectionID = 1;
				while (keyIterator.hasNext()) {
					String keyName = keyIterator.next();
					Section secn = new Section();
					List<CTABean> listBean = subSectionMap.get(keyName);
					secn.setSectionName(keyName);
					secn.setSectionId(sectionID++);
					secn.setCtaBeanList(listBean);
					subSectionList.add(secn);
				}
				section.setSubSectionList(subSectionList);
				sectionBeanList.add(section);
			}
		}
		roleAccessConfigBean.setCtaSectionList(sectionBeanList);
		return roleAccessConfigBean;
	}

	private List<Long> getAssignedCTAKeyList(List<Long> roleKeys) {

		StringBuilder roleKeyID = new StringBuilder();
		for (Long roleKey : roleKeys) {
			roleKeyID.append(roleKey).append(",");
		}

		String nativeQueryStr = "SELECT CTAKEY   from CTA_PRODUCT  WHERE isactive =1 and CTAPRODKEY IN (SELECT CTAPRODKEY FROM CTA_ROLES WHERE isactive=1 and ROLEKEY in("
				+ roleKeyID.replace(roleKeyID.length() - 1, roleKeyID.length(), "") + "))";
		List<Object[]> ctaKeyList = entityManager.createNativeQuery(nativeQueryStr).getResultList();
		List<Long> ctaKeys = new ArrayList<>();
		if (ctaKeyList != null && !ctaKeyList.isEmpty()) {

			for (Object a : ctaKeyList) {
				ctaKeys.add(((BigDecimal) a).longValue());
			}
		}
		return ctaKeys;
	}

	public void sectioncheck(Section section, Object[] a) {
		if (section.getSectionName() == null) {
			section.setSectionName((String) a[1]);
			section.setTabKey(((BigDecimal) a[0]).longValue());
		}
	}

	public void setbean(List<Long> assignedCTAKeyList, Object[] a, List<CTABean> topCtaBeanList,
			Map<String, List<CTABean>> subSectionMap) {
		if (a[5] == null) {
			CTABean ctaBean = new CTABean();
			ctaBean.setFieldkey(((BigDecimal) a[2]).longValue());
			ctaBean.setFieldName((String) a[3]);
			if (assignedCTAKeyList.contains(ctaBean.getFieldkey()))
				ctaBean.setSelected(true);

			topCtaBeanList.add(ctaBean);
		}

		else {
			CTABean ctaBean = new CTABean();
			ctaBean.setFieldkey(((BigDecimal) a[2]).longValue());
			ctaBean.setFieldName((String) a[3]);
			if (assignedCTAKeyList.contains(ctaBean.getFieldkey()))
				ctaBean.setSelected(true);
			List<CTABean> subSecList = subSectionMap.get((String) a[5]);
			if (subSecList == null) {
				subSecList = new ArrayList<>();
				subSecList.add(ctaBean);
				subSectionMap.put((String) a[5], subSecList);
			} else {
				subSecList.add(ctaBean);
				subSectionMap.put((String) a[5], subSecList);
			}

		}

	}

	/**
	 * @Override // public RoleAccessConfigurationBean getUIFields(List
	 *           <Long> roleKeyList, List<Long> listOfTabKeys) { //
	 *           RoleAccessConfigurationBean roleAccessConfigBean = new
	 *           RoleAccessConfigurationBean(); // CriteriaBuilder criteriaBlde
	 *           = entityManager.getCriteriaBuilder(); // // CriteriaQuery
	 *           <FieldSetRole> criteriaQry2 =
	 *           criteriaBlde.createQuery(FieldSetRole.class); // // Root
	 *           <FieldSetRole> rootFieldSetRole =
	 *           criteriaQry2.from(FieldSetRole.class); // //
	 *           criteriaQry2.select(rootFieldSetRole); //
	 *           criteriaQry2.where(criteriaBlde.in(rootFieldSetRole.get(
	 *           "bfsdRoleMaster").get("rolekey")).value(roleKeyList)); // List
	 *           <FieldSetRole> results1 =
	 *           entityManager.createQuery(criteriaQry2).getResultList(); //
	 *           List<Long> assignedFieldKeyList = new ArrayList<>(); // List
	 *           <Long> fieldAccessLevelList = new ArrayList<>(); // for
	 *           (FieldSetRole fieldSetRole : results1) { //
	 *           assignedFieldKeyList.add(fieldSetRole.getFieldSetAttribute().
	 *           getFieldkey()); //
	 *           fieldAccessLevelList.add(fieldSetRole.getFieldaccess().
	 *           longValue()); // } // // String nativeQueryStr = "select
	 *           fa.fieldkey, f.sectionname,fa.fieldname ,f.sectionkey from
	 *           field_set_sections f join header_tab_section h on
	 *           f.sectionkey=h.sectionkey " // + "join FIELD_SET_ATTRIBUTES fa
	 *           on fa.sectionkey = f.sectionkey where h.TABKEY = ?tabKey order
	 *           by f.sectionkey asc "; // // List
	 *           <UIFieldSection> uiFieldSectionList = new ArrayList<>(); // //
	 *           for (Long tabKey : listOfTabKeys) { // List
	 *           <Object[]> uiFieldKeyList = entityManager //
	 *           .createNativeQuery(nativeQueryStr.replace("?tabKey",
	 *           tabKey.toString())).getResultList(); // UIFieldSection uiFldSec
	 *           = new UIFieldSection(); // uiFldSec.setSectionName("Loan CTA");
	 *           // uiFldSec.setTabKey(tabKey); // List<List<UIFieldBean>>
	 *           uiFieldSectnList = new ArrayList<>(); // Map<String, List
	 *           <UIFieldBean>> subSectionMap = new HashMap<>(); // if
	 *           (uiFieldKeyList != null && !uiFieldKeyList.isEmpty()) { // //
	 *           for (Object[] a : uiFieldKeyList) { // // UIFieldBean uiFldBean
	 *           = new UIFieldBean(); // uiFldBean.setSectionName((String)
	 *           a[1]); // uiFldBean.setFieldkey(((BigDecimal)
	 *           a[0]).longValue()); // uiFldBean.setFieldName((String) a[2]);
	 *           // if (assignedFieldKeyList.contains(uiFldBean.getFieldkey()))
	 *           { // uiFldBean.setSelected(true); // int index =
	 *           assignedFieldKeyList.indexOf(uiFldBean.getFieldkey()); //
	 *           uiFldBean.setAccessLevel(fieldAccessLevelList.get(index).
	 *           longValue()); // } // List<UIFieldBean> subSecList =
	 *           subSectionMap.get(uiFldBean.getSectionName()); // if
	 *           (subSecList == null) { // subSecList = new ArrayList<>(); //
	 *           subSecList.add(uiFldBean); //
	 *           subSectionMap.put(uiFldBean.getSectionName(), subSecList); // }
	 *           else { // subSecList.add(uiFldBean); //
	 *           subSectionMap.put(uiFldBean.getSectionName(), subSecList); // }
	 *           // } // } // // int sectionId = 1; // Iterator
	 *           <String> keyIterator = subSectionMap.keySet().iterator(); //
	 *           while (keyIterator.hasNext()) { // String keyName =
	 *           keyIterator.next(); // List<UIFieldBean> listBean =
	 *           subSectionMap.get(keyName); //
	 *           listBean.get(0).setSectionId(sectionId++); //
	 *           uiFieldSectnList.add(listBean); // } // //
	 *           uiFldSec.setUiFieldSectionList(uiFieldSectnList); //
	 *           uiFieldSectionList.add(uiFldSec); // } // //
	 *           roleAccessConfigBean.setUiFieldSectionList(uiFieldSectionList);
	 *           // return roleAccessConfigBean; // }
	 */

	@Override
	@Transactional
	public boolean saveConfigurations(RoleAccessConfigurationInputBean inputBean) {

		logger.debug(CLASS_NAME, DAO, DAO_MSG1 + inputBean);
		boolean successFlag = false;
		EntityManager em = entityManagerFactory.createEntityManager();
		try {

			em.getTransaction().begin();
			for (int i = 0; i < inputBean.getRolekeys().length; i++) {

				long roleKey = inputBean.getRolekeys()[i];
				logger.debug(CLASS_NAME, DAO, "Start saving role access configuration for Role Key :" + roleKey);
				softDeleteRoleAccessConfigurationsIfAny(inputBean, em, roleKey);
				saveAllSubsectionFields(em, roleKey);
				saveCtaRoles(inputBean, em, roleKey);
				saveFieldSetRoles(inputBean, em, roleKey);
				saveFieldSetSubSectionRoles(inputBean, em, roleKey);
				saveHeaderTabRoles(inputBean, em, roleKey);
			}

			em.getTransaction().commit();
			successFlag = true;

		} catch (Exception e) {
			/** successFlag = false; */
			em.getTransaction().rollback();
			logger.error(CLASS_NAME, DAO, DAO_ERR_MSG1);
			throw new BFLTechnicalException("ROLEMGT_7016", e);
		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG2);
		return successFlag;
	}

	private void saveFieldSetSubSectionRoles(RoleAccessConfigurationInputBean inputBean, EntityManager em,
			Long roleKey) {

		logger.debug(CLASS_NAME, DAO, "");

		BfsdRoleMaster bfsdRoleMaster2 = new BfsdRoleMaster();
		bfsdRoleMaster2.setRolekey(roleKey);

		for (Long subSectionKey : inputBean.getSubSectionKeys()) {

			FieldSetSubsectionRole fieldSetSubsectionRole = new FieldSetSubsectionRole();

			FieldSetSubsection fieldSetSubsection = new FieldSetSubsection();
			fieldSetSubsection.setSubsectionkey(subSectionKey);

			fieldSetSubsectionRole.setFieldSetSubsection(fieldSetSubsection);
			fieldSetSubsectionRole.setRolekey(new BigDecimal(roleKey));
			fieldSetSubsectionRole.setIsactive(new BigDecimal(1));
			fieldSetSubsectionRole.setLstupdatedt(Timestamp.from(Instant.now()));
			fieldSetSubsectionRole.setSelectclause("What to store??");
			em.merge(fieldSetSubsectionRole);
		}
		logger.debug(CLASS_NAME, DAO, "");
	}

	private void saveHeaderTabRoles(RoleAccessConfigurationInputBean inputBean, EntityManager em, Long roleKey) {

		logger.debug(CLASS_NAME, DAO, DAO_MSG3 + inputBean.getTabIds());
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(roleKey);

		for (long tabId : inputBean.getTabIds()) {
			HeaderTabMaster headerTabMaster = new HeaderTabMaster();
			headerTabMaster.setTabkey(tabId); // header tab master key

			HeaderTabRole headerTabRole = new HeaderTabRole();
			headerTabRole.setHeaderTabMaster(headerTabMaster);
			headerTabRole.setBfsdRoleMaster(bfsdRoleMaster);
			headerTabRole.setIsactive(new BigDecimal(1));
			headerTabRole.setLstupdatedt(Timestamp.from(Instant.now()));
			/** HeaderTabRole headerTabRole2 = em.merge(headerTabRole); */
			em.persist(headerTabRole);

		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG4);
	}

	private void saveFieldSetRoles(RoleAccessConfigurationInputBean inputBean, EntityManager em, Long roleKey) {

		logger.debug(CLASS_NAME, DAO, DAO_MSG5 + inputBean.getFieldAccessBeans());

		BfsdRoleMaster bfsdRoleMaster2 = new BfsdRoleMaster();
		bfsdRoleMaster2.setRolekey(roleKey);

		for (FieldAccessBean fieldAccessBean : inputBean.getFieldAccessBeans()) {

			FieldSetRole fieldSetRole = new FieldSetRole();
			fieldSetRole.setFieldaccess(new BigDecimal(fieldAccessBean.getFieldAccesskey()));
			fieldSetRole.setBfsdRoleMaster(bfsdRoleMaster2);
			fieldSetRole.setIsactive(new BigDecimal(1));
			FieldSetAttribute fieldSetAttribute = new FieldSetAttribute();
			fieldSetAttribute.setFieldkey(fieldAccessBean.getFieldkey());
			fieldSetRole.setFieldSetAttribute(fieldSetAttribute);
			fieldSetRole.setLstupdatedt(Timestamp.from(Instant.now()));
			/** FieldSetRole fieldSetRole2 = em.merge(fieldSetRole); */
			em.persist(fieldSetRole);
		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG6);
	}

	private void saveCtaRoles(RoleAccessConfigurationInputBean inputBean, EntityManager em, Long roleKey) {

		BfsdRoleMaster bfsdRoleMaster1 = new BfsdRoleMaster();
		bfsdRoleMaster1.setRolekey(roleKey);
		long productMasterKey = inputBean.getProductkey();

		logger.debug(CLASS_NAME, DAO, DAO_MSG7 + inputBean.getCtaIds());
		for (long ctaId : inputBean.getCtaIds()) {

			CtaRole ctaRole = new CtaRole();
			ctaRole.setCtaProduct(getCtaProductfor(ctaId, productMasterKey));
			ctaRole.setBfsdRoleMaster(bfsdRoleMaster1);
			ctaRole.setIsactive(new BigDecimal(1));
			ctaRole.setLstupdatedt(Timestamp.from(Instant.now()));
			ctaRole.setLstupdateby("Check What to Pass");
			/** CtaRole ctaRole2 = em.merge(ctaRole); */
			em.persist(ctaRole);
		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG8);
	}

	private CtaProduct getCtaProductfor(long ctaId, long productMasterKey) {

		logger.debug(CLASS_NAME, DAO,
				"Fetch CTA Product for CTA ID :" + ctaId + " and Product Master Key :" + productMasterKey);
		CtaProduct ctaProduct = null;
		List<CtaProduct> ctaProducts = null;
		try {
			ctaProducts = (List<CtaProduct>) entityManager.createNamedQuery("CtaProduct.findByCtaIdAndProductMasterKey")
					.setParameter("productMasterKey", new BigDecimal(productMasterKey)).setParameter("ctaKey", ctaId)
					.getResultList();
			/**
			 * .getSingleResult(); todo: CTA product key should be fetched
			 * aginst subproduct, but since UI is designed witout subproduct
			 * dropdown, //we are getting first entry from the list
			 */
			if (null != ctaProducts && !ctaProducts.isEmpty()) {
				ctaProduct = ctaProducts.get(0);
			}
		} catch (PersistenceException e) {
			logger.error(CLASS_NAME, DAO, "Error occured while fetching CTA Product for CTA ID :" + ctaId
					+ " and Product Master Key :" + productMasterKey);
			throw new BFLTechnicalException("ROLEMGT_7017", e);
		}
		logger.debug(CLASS_NAME, DAO, "Fetch CTA Product :" + ctaProduct);
		return ctaProduct;
	}

	private void softDeleteRoleAccessConfigurationsIfAny(RoleAccessConfigurationInputBean inputBean,
			EntityManager manager, Long roleKey) {

		logger.debug(CLASS_NAME, DAO, DAO_MSG10 + inputBean);
		List<Long> ctaIds = new ArrayList<>();
		for (Long ctaId : inputBean.getCtaIds()) {
			ctaIds.add(ctaId);
		}
		logger.debug(CLASS_NAME, DAO, "CTA Ids :" + ctaIds);
		List<CtaProduct> ctaProducts = manager.createNamedQuery("CtaProduct.findAlldByCtaIdAndProductMasterKey")
				.setParameter("productMasterKey", new BigDecimal(inputBean.getProductkey()))
				.setParameter("ctaKeys", ctaIds) // inputBean.getCtaIds()
				.getResultList();

		List<Long> ctaProductKeys = ctaProducts.stream().map(CtaProduct::getCtaprodkey).collect(Collectors.toList());
		if (!ctaProductKeys.isEmpty()) {
			int ctaRoles = manager.createNamedQuery("CtaRole.DeactivateCtaRoles")
					/** .setParameter("ctaprodkeys", ctaProductKeys) */
					.setParameter(ROLEKEY, roleKey) // inputBean.getRolekey()
					.executeUpdate();
			logger.debug(CLASS_NAME, DAO, DAO_MSG9 + ctaRoles + " CtaRole Records for Product Key :" + ctaProductKeys
					+ " for Role Key :" + roleKey);
		} else {
			logger.debug(CLASS_NAME, DAO, "No CtaRole Records for found for soft delete with Product Key :"
					+ ctaProductKeys + " for Role Key :" + roleKey);
		}

		int headerTabRoles = manager.createNamedQuery("HeaderTabRole.DeactivateHeaderTabRoles")
				.setParameter(ROLEKEY, roleKey) // inputBean.getRolekey()
				.executeUpdate();

		logger.debug(CLASS_NAME, DAO, DAO_MSG9 + headerTabRoles + " HeaderTabRole Records for Role Key :" + roleKey);

		int fieldSetRoles = manager.createNamedQuery("FieldSetRole.DeactivateFieldSetRoles")
				.setParameter("roleKey", roleKey) // inputBean.getRolekey()
				.executeUpdate();
		logger.debug(CLASS_NAME, DAO, DAO_MSG9 + fieldSetRoles + " FieldSetRole Records for Role Key :" + roleKey);

		int fieldSetSubsectionRoles = manager.createNamedQuery("FieldSetSubsectionRole.DeactivateAllSubSectionRoles")
				// .setParameter("subsectionkeys",inputBean.getSubSectionKeys())
				.setParameter(ROLEKEYS, new BigDecimal(roleKey)) // inputBean.getRoleKeys()
				.executeUpdate();
		logger.debug(CLASS_NAME, DAO,
				DAO_MSG9 + fieldSetSubsectionRoles + " FieldSetSubsectionRole Records with Role Key :" + roleKey);

	}

	@Override
	public RoleBasedUsersListResponceBean usersListOnRoleBased(Long roleKey, Long applicationkey) {

		logger.debug(CLASS_NAME, DAO, "get user role key :" + roleKey);

		/**
		 * CriteriaBuilder criteriaBlde = entityManager.getCriteriaBuilder();
		 * criteriaBlde.createQuery(UserRole.class); Root
		 * <UserRole> root_BfsdRoleMaster = criteriaQry.from(UserRole.class);
		 * criteriaQry.select(root_BfsdRoleMaster);
		 * criteriaQry.where(criteriaBlde.equal(root_BfsdRoleMaster.get(
		 * "bfsdRoleMaster").get("rolekey"), roleKey)); List
		 * <UserRole> bfsdRoleMaster =
		 * entityManager.createQuery(criteriaQry).getResultList();
		 */

		String nativeQuery;
		Query query;
		if (applicationkey == null) {
			nativeQuery = " SELECT USERKEY, FIRSTNAME || ' ' || LASTNAME, FIRSTNAME, LASTNAME FROM USER_PROFILES WHERE"
					+ " USERKEY IN (SELECT BFSD_USERS.USERKEY FROM USER_ROLES,BFSD_USERS"
					+ " WHERE BFSD_USERS.USERKEY=USER_ROLES.USERKEY AND USER_ROLES.ROLEKEY =:roleKey"
					+ " AND BFSD_USERS.ISACTIVE =1 and USER_ROLES.ISACTIVE=1)";
			query = entityManager.createNativeQuery(nativeQuery).setParameter("roleKey", roleKey);
		} else {
			nativeQuery = "SELECT USERKEY, FIRSTNAME || ' ' || LASTNAME, FIRSTNAME, LASTNAME FROM USER_PROFILES WHERE"
					+ " USERKEY IN (SELECT BFSD_USERS.USERKEY FROM USER_ROLES,BFSD_USERS,APPLICATIONS,USER_ROLE_LOCATIONS "
					+ " WHERE BFSD_USERS.USERKEY=USER_ROLES.USERKEY AND USER_ROLES.ROLEKEY =:roleKey"
					+ " AND BFSD_USERS.ISACTIVE =1 and USER_ROLES.ISACTIVE=1 and APPLICATIONS.BFLBRANCHKEY=USER_ROLE_LOCATIONS.BFLBRANCHKEY"
					+ " and USER_ROLE_LOCATIONS.userrolekey=USER_ROLES.userrolekey and APPLICATIONS.applicationkey=:appkey)";
			query = entityManager.createNativeQuery(nativeQuery).setParameter("roleKey", roleKey).setParameter("appkey",
					applicationkey);

		}
		logger.debug(CLASS_NAME, DAO, "nativeQuery------ :" + nativeQuery);
		logger.debug(CLASS_NAME, DAO, "query-------- :" + query);
		List<Object[]> userList = query.getResultList();

		RoleBasedUsersListResponceBean roleBasedUsersListResponceBean = new RoleBasedUsersListResponceBean();
		List<RoleBasedUsersResponseBean> roleBasedUserList = new ArrayList<>();
		logger.debug(CLASS_NAME, DAO, "Test Data-------- :" + userList);
		if (!userList.isEmpty()) {
			logger.debug(CLASS_NAME, DAO, "Inside if dao :" + roleKey);

			for (Object[] a : userList) {

				logger.debug(CLASS_NAME, DAO, "For loop dao Object[] a :" + roleKey);

				RoleBasedUsersResponseBean roleBasedUsersResponceBean = new RoleBasedUsersResponseBean();
				if (null != a[1] && null != a[2] && null != a[3]) {
					roleBasedUsersResponceBean.setUserKey((BigDecimal) a[0]);
					roleBasedUsersResponceBean.setUserFullName((String) a[1]);
					roleBasedUsersResponceBean.setFirstName((String) a[2]);
					roleBasedUsersResponceBean.setLastName((String) a[3]);

					roleBasedUserList.add(roleBasedUsersResponceBean);
				}
			}
			roleBasedUsersListResponceBean.setRolebasedUserList(roleBasedUserList);
			logger.debug(CLASS_NAME, DAO, "Done with fetching users based on role--" + roleBasedUsersListResponceBean);

		} else {

			logger.debug(CLASS_NAME, DAO, "Object is null");
		}

		return roleBasedUsersListResponceBean;
	}

	@Transactional
	@Override
	public void cloneRoleAccessConfiguration(CloneRoleAccessConfigureBean cloneRoleAccessConfigBean) {

		logger.debug(CLASS_NAME, DAO, "Cloning begins for the role");
		/** boolean successFlag = false; */
		EntityManager em = entityManagerFactory.createEntityManager();
		try {

			em.getTransaction().begin();
			List<Long> roleKeysFrom = cloneRoleAccessConfigBean.getRoleKeyFrom();
			List<Long> roleKeysTo = cloneRoleAccessConfigBean.getRoleKeysTo();
			softDeleteRoleAccessConfig(roleKeysTo, em);
			cloneCtaRoles(roleKeysFrom, roleKeysTo, em);
			cloneFieldSetRoles(roleKeysFrom, roleKeysTo, em);
			cloneHeaderTabRoles(roleKeysFrom, roleKeysTo, em);
			cloneFieldSetSubSectionRoles(roleKeysFrom, roleKeysTo, em);

			em.getTransaction().commit();
			/** successFlag = true; */

		} catch (Exception e) {
			/** successFlag = false; */
			em.getTransaction().rollback();
			logger.error(CLASS_NAME, DAO, DAO_ERR_MSG1);
			throw new BFLTechnicalException("ROLEMGT_7016", e);
		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG2);

	}

	private void cloneFieldSetSubSectionRoles(List<Long> roleKeysFrom, List<Long> roleKeysTo, EntityManager em) {

		List<BigDecimal> roles = roleKeysFrom.stream().map(BigDecimal::new).collect(Collectors.toList());
		List<FieldSetSubsectionRole> fieldSetSubsectionRoles = em
				.createNamedQuery("FieldSetSubsectionRole.FetchAllByRole").setParameter(ROLEKEYS, roles)
				.getResultList();

		for (Long role : roleKeysTo) {
			for (FieldSetSubsectionRole oldSubsectionRole : fieldSetSubsectionRoles) {
				/**
				 * try { // FieldSetSubsectionRole fieldSetSubsectionRole2 =
				 * (FieldSetSubsectionRole) fieldSetSubsectionRole.clone();
				 */
				FieldSetSubsectionRole newSubsectionRole = new FieldSetSubsectionRole();
				newSubsectionRole.setSelectclause(oldSubsectionRole.getSelectclause());
				newSubsectionRole.setFieldSetSubsection(oldSubsectionRole.getFieldSetSubsection());
				newSubsectionRole.setIsactive(new BigDecimal(1));
				newSubsectionRole.setRolekey(new BigDecimal(role));
				newSubsectionRole.setLstupdatedt(Timestamp.from(Instant.now()));
				/** newSubsectionRole = em.merge(newSubsectionRole); */
				em.persist(newSubsectionRole);
				/**
				 * } catch (CloneNotSupportedException e) { //
				 * e.printStackTrace(); // }
				 */
			}
		}
	}

	private void cloneHeaderTabRoles(List<Long> roleKeysFrom, List<Long> roleKeysTo, EntityManager em) {

		CriteriaBuilder criteriaBlde = em.getCriteriaBuilder();
		CriteriaQuery<HeaderTabRole> criteriaQry = criteriaBlde.createQuery(HeaderTabRole.class);
		Root<HeaderTabRole> rootHeaderTabRole = criteriaQry.from(HeaderTabRole.class);
		criteriaQry.select(rootHeaderTabRole);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlde.equal(rootHeaderTabRole.get(ISACTIVE), new BigDecimal(1)));
		predicates.add(rootHeaderTabRole.get(BFSDROLEMASTER).get(ROLEKEY).in(roleKeysFrom));
		criteriaQry.where(predicates.toArray(new Predicate[] {}));

		List<HeaderTabRole> results = em.createQuery(criteriaQry).getResultList();

		for (Long roleKey : roleKeysTo) {
			BfsdRoleMaster bfsdRoleMaster1 = new BfsdRoleMaster();
			bfsdRoleMaster1.setRolekey(roleKey);
			for (HeaderTabRole resultHeaderTabRole : results) {
				HeaderTabMaster headerTabMaster = new HeaderTabMaster();
				headerTabMaster.setTabkey(resultHeaderTabRole.getHeaderTabMaster().getTabkey()); // header
																									// tab
																									// master
																									// key

				HeaderTabRole headerTabRole = new HeaderTabRole();
				headerTabRole.setHeaderTabMaster(headerTabMaster);
				headerTabRole.setBfsdRoleMaster(bfsdRoleMaster1);
				headerTabRole.setIsactive(new BigDecimal(1));
				headerTabRole.setLstupdatedt(Timestamp.from(Instant.now()));
				/** HeaderTabRole headerTabRole2 = em.merge(headerTabRole); */
				em.persist(headerTabRole);

			}
		}

	}

	private void cloneFieldSetRoles(List<Long> roleKeysFrom, List<Long> roleKeysTo, EntityManager em) {

		CriteriaBuilder criteriaBlde = em.getCriteriaBuilder();
		CriteriaQuery<FieldSetRole> criteriaQry = criteriaBlde.createQuery(FieldSetRole.class);
		Root<FieldSetRole> rootFieldSetRole = criteriaQry.from(FieldSetRole.class);
		criteriaQry.select(rootFieldSetRole);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlde.equal(rootFieldSetRole.get(ISACTIVE), new BigDecimal(1)));
		predicates.add(rootFieldSetRole.get(BFSDROLEMASTER).get(ROLEKEY).in(roleKeysFrom));
		criteriaQry.where(predicates.toArray(new Predicate[] {}));

		List<FieldSetRole> results = em.createQuery(criteriaQry).getResultList();

		for (Long roleKey : roleKeysTo) {
			BfsdRoleMaster bfsdRoleMaster1 = new BfsdRoleMaster();
			bfsdRoleMaster1.setRolekey(roleKey);
			for (FieldSetRole resultFieldRole : results) {
				FieldSetRole fieldSetRole = new FieldSetRole();
				fieldSetRole.setFieldaccess(resultFieldRole.getFieldaccess());
				fieldSetRole.setBfsdRoleMaster(bfsdRoleMaster1);
				fieldSetRole.setIsactive(new BigDecimal(1));
				FieldSetAttribute fieldSetAttribute = new FieldSetAttribute();
				fieldSetAttribute.setFieldkey(resultFieldRole.getFieldSetAttribute().getFieldkey());
				fieldSetRole.setFieldSetAttribute(fieldSetAttribute);
				fieldSetRole.setLstupdatedt(Timestamp.from(Instant.now()));
				/** FieldSetRole fieldSetRole2 = em.merge(fieldSetRole); */
				em.persist(fieldSetRole);

			}
		}

	}

	private void cloneCtaRoles(List<Long> roleKeysFrom, List<Long> roleKeysTo, EntityManager em) {

		CriteriaBuilder criteriaBlde = em.getCriteriaBuilder();
		CriteriaQuery<CtaRole> criteriaQry = criteriaBlde.createQuery(CtaRole.class);
		Root<CtaRole> rootCtaRole = criteriaQry.from(CtaRole.class);
		criteriaQry.select(rootCtaRole);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlde.equal(rootCtaRole.get(ISACTIVE), new BigDecimal(1)));
		predicates.add(rootCtaRole.get(BFSDROLEMASTER).get(ROLEKEY).in(roleKeysFrom));
		criteriaQry.where(predicates.toArray(new Predicate[] {}));

		List<CtaRole> results = em.createQuery(criteriaQry).getResultList();

		for (Long roleKey : roleKeysTo) {
			BfsdRoleMaster bfsdRoleMaster1 = new BfsdRoleMaster();
			bfsdRoleMaster1.setRolekey(roleKey);
			for (CtaRole resultCtaRole : results) {
				CtaRole ctaRole = new CtaRole();
				ctaRole.setCtaProduct(resultCtaRole.getCtaProduct());
				ctaRole.setBfsdRoleMaster(bfsdRoleMaster1);
				ctaRole.setIsactive(new BigDecimal(1));
				ctaRole.setLstupdatedt(Timestamp.from(Instant.now()));
				ctaRole.setLstupdateby("Check What to Pass");
				em.persist(ctaRole);

			}
		}

	}

	private void softDeleteRoleAccessConfig(List<Long> roleKeys, EntityManager em) {

		CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();

		CriteriaUpdate<CtaRole> criteriaUpdCtaRole = criteriaBuilder.createCriteriaUpdate(CtaRole.class);
		Root<CtaRole> rootCtaRole = criteriaUpdCtaRole.from(CtaRole.class);
		criteriaUpdCtaRole.set(rootCtaRole.get(ISACTIVE), new BigDecimal(0));
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBuilder.equal(rootCtaRole.get(ISACTIVE), new BigDecimal(1)));
		predicates.add(rootCtaRole.get(BFSDROLEMASTER).get(ROLEKEY).in(roleKeys));
		criteriaUpdCtaRole.where(predicates.toArray(new Predicate[] {}));
		em.createQuery(criteriaUpdCtaRole).executeUpdate();

		CriteriaUpdate<HeaderTabRole> criteriaUpdHeadrTabRole = criteriaBuilder
				.createCriteriaUpdate(HeaderTabRole.class);
		Root<HeaderTabRole> rootHeaderTabRole = criteriaUpdHeadrTabRole.from(HeaderTabRole.class);
		criteriaUpdHeadrTabRole.set(rootCtaRole.get(ISACTIVE), new BigDecimal(0));
		predicates.clear();
		predicates.add(criteriaBuilder.equal(rootHeaderTabRole.get(ISACTIVE), new BigDecimal(1)));
		predicates.add(rootHeaderTabRole.get(BFSDROLEMASTER).get(ROLEKEY).in(roleKeys));
		criteriaUpdHeadrTabRole.where(predicates.toArray(new Predicate[] {}));
		em.createQuery(criteriaUpdHeadrTabRole).executeUpdate();

		CriteriaUpdate<FieldSetRole> criteriaUpdFieldSetRole = criteriaBuilder.createCriteriaUpdate(FieldSetRole.class);
		Root<FieldSetRole> rootFieldSetRole = criteriaUpdFieldSetRole.from(FieldSetRole.class);
		criteriaUpdFieldSetRole.set(rootFieldSetRole.get(ISACTIVE), new BigDecimal(0));
		predicates.clear();
		predicates.add(criteriaBuilder.equal(rootFieldSetRole.get(ISACTIVE), new BigDecimal(1)));

		predicates.add(rootFieldSetRole.get(BFSDROLEMASTER).get(ROLEKEY).in(roleKeys));
		criteriaUpdFieldSetRole.where(predicates.toArray(new Predicate[] {}));
		em.createQuery(criteriaUpdFieldSetRole).executeUpdate();

		List<BigDecimal> roles = roleKeys.stream().map(BigDecimal::new).collect(Collectors.toList());
		int fieldSetSubsectionRoles = em.createNamedQuery("FieldSetSubsectionRole.DeactivateAllSubSectionRoles")
				.setParameter(ROLEKEYS, roles) // inputBean.getRoleKeys()
				.executeUpdate();
		logger.debug(CLASS_NAME, DAO,
				DAO_MSG9 + fieldSetSubsectionRoles + " FieldSetSubsectionRole Records with Role Key :" + roleKeys);

	}

	@Override
	public List<FieldSetGroup> fetchGroupsSectionAndSubSections(RoleAccessConfigurationBean inputBean) {
		List<Long> tabcds = new ArrayList<>();
		List<HeaderTabMaster> headertab = entityManager.createNamedQuery("HeaderTabMaster.findAlltabkey")
				.setParameter("tabkey", inputBean.getTabKeys()).getResultList();
		for (HeaderTabMaster header : headertab) {
			tabcds.add(header.getTabcd().longValue());
		}

		/**
		 * List<long[]> roleKeys = Arrays.asList(inputBean.getRoleKeys()); //
		 * List<Long> tabKeys = //
		 * Arrays.stream(inputBean.getTabIds()).boxed().collect(Collectors.
		 * toList());
		 */
		List<Long> fieldcodes = HeaderTabKeyNFieldSetMasterMappingEnum.getFieldSetCodesForHeaderTabKeys(tabcds);
		List<BigDecimal> rolesKeys = inputBean.getRoleKeys().stream().map(BigDecimal::new).collect(Collectors.toList());
		List<BigDecimal> fieldsetCodes = fieldcodes.stream().map(BigDecimal::new).collect(Collectors.toList());

		return entityManager.createNamedQuery("FieldSetGroup.findAllGroupsSectionsAndSubSectionBasedOnRoleKeyAndTabKey")
				.setParameter(RKEY, rolesKeys).setParameter("fieldsetcds", fieldsetCodes).getResultList();
		/** return fieldSetGroups; */
	}

	@Override
	public List<FieldSetSubsection> fetchFieldsforGroupsSectinoAndsubSection(RoleAccessConfigurationBean inputBean) {

		return entityManager.createNamedQuery("FieldSetSubsection.findAllById")
				.setParameter("subSectionKeys", inputBean.getSubSectionKeys()).getResultList();

	}

	@Override
	public List<FieldSetGroup> fetchFieldsDetailsforGroupsSectinoAndsubSection(RoleAccessConfigurationBean inputBean) {
		List<Long> tabcds = new ArrayList<>();
		List<HeaderTabMaster> headertab = entityManager.createNamedQuery("HeaderTabMaster.findAlltabkey")
				.setParameter("tabkey", inputBean.getTabKeys()).getResultList();
		for (HeaderTabMaster header : headertab) {
			tabcds.add(header.getTabcd().longValue());
		}

		List<Long> fieldcodes = HeaderTabKeyNFieldSetMasterMappingEnum.getFieldSetCodesForHeaderTabKeys(tabcds);
		List<BigDecimal> rolesKeys = inputBean.getRoleKeys().stream().map(BigDecimal::new).collect(Collectors.toList());
		List<BigDecimal> fieldsetCodes = fieldcodes.stream().map(BigDecimal::new).collect(Collectors.toList());

		return entityManager.createNamedQuery("FieldSetGroup.findAllSubSectionBasedOnSubSectionKeys")
				.setParameter(RKEY, rolesKeys).setParameter("fieldsetcds", fieldsetCodes)
				.setParameter("sectionkeys", inputBean.getSectionKeys())
				.setParameter("groupkeys", inputBean.getGroupKeys())
				.setParameter("subsectionkeys", inputBean.getSubSectionKeys()).getResultList();

		/** return fieldSetGroups; */

	}

	@Override
	public List<FieldSetRole> fetchFieldsSetRolesByRoleKeys(List<Long> roleKeys) {
		return entityManager.createNamedQuery("FieldSetRole.findAllActiveForRoleKeys").setParameter(RKEY, roleKeys)
				.getResultList();

	}

	@Override
	public List<FieldSetSubsectionRole> fetchSubSectionRoleByRole(List<Long> roles) {

		List<BigDecimal> roleKeys = roles.stream().map(BigDecimal::new).collect(Collectors.toList());
		return entityManager.createNamedQuery("FieldSetSubsectionRole.FetchAllByRole").setParameter(ROLEKEYS, roleKeys)
				.getResultList();

		/** return fieldSetSubsectionRoles; */
	}

	@Override
	public Boolean checkRoleInUsersAssignedRolesHierarchy(AssignedRoleBean assignedRoleBean) {

		logger.debug(CLASS_NAME, DAO, "get assigned role for user id :" + assignedRoleBean.getUserId());
		boolean retVal = false;
		String roleNamesPolicyStore = assignedRoleBean.getCommaSeparatedRolesToVerify();

		String currentUserRoleName = "";
		CacheUserEntity userEntity = userCacheService.get(assignedRoleBean.getUserId());
		if (null != userEntity) {
			currentUserRoleName = userEntity.getUserCurrentRoleName();
		} else {
			// TODO - Get the user's current role name from database
		}

		String[] splitRoles = roleNamesPolicyStore.split(",");
		if (Arrays.asList(splitRoles).contains(currentUserRoleName)) {
			retVal = true;

		} else {
			String nativeQuery = "SELECT rm.rolename" + " FROM bfsd_role_master rm" + "	WHERE rm.systemroleflg = 0 AND"
					+ "	 LEVEL > 1" + "	 START WITH rm.rolename = :currentRole"
					+ "	CONNECT BY nocycle PRIOR  rm.rolekey  = rm.parentrole ";

			Query query = entityManager.createNativeQuery(nativeQuery);
			query.setParameter("currentRole", currentUserRoleName);
			logger.debug(CLASS_NAME, DAO, "nativeQuery------ :" + nativeQuery);
			logger.debug(CLASS_NAME, DAO, "query-------- :" + query);
			List<String> result = query.getResultList();

			if (!result.isEmpty()) {
				for (int i = 0; i < result.size(); i++) {
					if (Arrays.asList(splitRoles).contains(result.get(i))) {
						retVal = true;
						break;
					}
				}

			}
		}

		return retVal;
	}

	@Override
	public UserRole getUserRole(long userKey, long userRoleKey) {

		Query query = entityManager
				.createQuery("from UserRole where userrolekey=:userRoleKey and userkey=:userKey and isactive=1 ");

		query.setParameter("userRoleKey", userRoleKey);
		query.setParameter("userKey", BigDecimal.valueOf(userKey));

		try {

			return (UserRole) query.getSingleResult();
		} catch (NoResultException e) {
			logger.error(CLASS_NAME, DAO, "getUserRole - no user found for given userKey and userRoleKey" + e);
			throw new BFLBusinessException("ROLEMGT_7012", env.getProperty("ROLEMGT_7012"));
		}
	}

	private void saveAllSubsectionFields(EntityManager em, Long roleKey) {
		logger.debug(CLASS_NAME, DAO, "");
		List<FieldSetSubsection> fieldsubsection = (List<FieldSetSubsection>) entityManager
				.createNamedQuery("FieldSetSubsection.findAll").getResultList();

		BfsdRoleMaster bfsdRoleMaster2 = new BfsdRoleMaster();
		bfsdRoleMaster2.setRolekey(roleKey);

		/** List <FieldSetSubsection> fieldsub = new ArrayList<>(); */

		for (FieldSetSubsection field : fieldsubsection) {
			FieldSetSubsectionRole fieldsubsect = new FieldSetSubsectionRole();
			fieldsubsect.setFieldSetSubsection(field);
			fieldsubsect.setRolekey(BigDecimal.valueOf(roleKey));
			fieldsubsect.setIsactive(BigDecimal.ZERO);
			fieldsubsect.setLstupdatedt(Timestamp.from(Instant.now()));
			fieldsubsect.setSelectclause("What to store??");
			fieldsubsect.setLstupdateby("System");
			FieldSetSubsectionRole fieldsubsect2 = em.merge(fieldsubsect);
			em.persist(fieldsubsect2);
		}

		/**
		 * Query query= entityManager.createNativeQuery(
		 * "update FIELD_SET_SUBSECTION_ROLE set ROLEKEY=:rolekey ,SUBSECTIONKEY=:subsectionkey"
		 * + ", ISACTIVE=:isactive, SELECTCLAUSE=:select ,LSTUPDATEDT=:lstdt")
		 * .setParameter("rolekey", roleKey)
		 * .setParameter("subsectionkey",field.getSubsectionkey())
		 * .setParameter("isactive", BigDecimal.ZERO) .setParameter("select",
		 * "What to store??") .setParameter("lstdt",
		 * Timestamp.from(Instant.now())); query.executeUpdate();
		 * 
		 * }
		 */

	}

	@Override
	public boolean checkEmailCTAAccess(long applicationKey) {

		int matchPercent;
		int currentPercent;
		Query query = entityManager.createNativeQuery(
				"select APPLSUBSTAGECOMPLETIONPER from APPLICATION_SUBSTAGE_MASTER where APPLSUBSTAGECODE='ULSSG_AIP' "
						+ "and APPLSUBSTAGEISACTIVE=1 ");
		List<BigDecimal> basePercentage = query.getResultList();

		if (basePercentage != null && !basePercentage.isEmpty()) {
			matchPercent = basePercentage.get(0).intValue();
		} else
			return false;

		query = entityManager.createNativeQuery(
				"select asm.APPLSUBSTAGECOMPLETIONPER from APPLICATION_STAGES ast, APPLICATION_SUBSTAGE_MASTER asm, applications ap "
						+ "where ap.APPLICATIONKEY=ast.APPLICATIONKEY and ap.APPISACTIVE=1 and ast.APPLSUBSTAGEKEY=asm.APPLSUBSTAGEKEY "
						+ "and ast.APPSUBSTAGEOUTDT is null and ap.applicationkey=:applicationKey ");
		query.setParameter("applicationKey", applicationKey);

		List<BigDecimal> applications = query.getResultList();

		if (applications != null && !applications.isEmpty()) {
			currentPercent = applications.get(0).intValue();
		} else
			return false;
		return currentPercent >= matchPercent;
	}

	private List<Long> getAssignedCTAKeyListBasedonL3(List<Long> roleKeys, long prodkey, long subprodkey) {

		List<BigDecimal> role = roleKeys.stream().map(BigDecimal::new).collect(Collectors.toList());
		List<Long> roleProdKeys = entityManager.createNamedQuery("RoleProductMapping.findAllRoleKey")
				.setParameter(ROLEKEY, role).setParameter(PRODKEY, BigDecimal.valueOf(prodkey))
				.setParameter(SUBPRODKEY, BigDecimal.valueOf(subprodkey)).getResultList();

		if (roleProdKeys.isEmpty()) {
			logger.info(CLASS_NAME, BFLLoggerComponent.DAO, "  No Role_Product found in DB");
			throw new HibernateException(env.getProperty("ROLEMGT_7014"));
		}

		List<BigDecimal> rolepkey = roleProdKeys.stream().map(BigDecimal::new).collect(Collectors.toList());
		String nativeQueryStr = "SELECT CTAKEY from CTA_PRODUCT  WHERE isactive =1 and prodmastkey = :prodkey and subprodtypekey in :subprodkey and CTAPRODKEY IN "
				+ "(SELECT CTAPRODKEY FROM CTA_ROLES WHERE isactive=1 and ROLEKEY in :roleKeys)";

		List<Object[]> ctaKeyList = entityManager.createNativeQuery(nativeQueryStr).setParameter(RKEY, rolepkey)
				.setParameter(PRODKEY, prodkey).setParameter(SUBPRODKEY, subprodkey).getResultList();
		List<Long> ctaKeys = new ArrayList<>();
		if (ctaKeyList != null && !ctaKeyList.isEmpty()) {

			for (Object a : ctaKeyList) {
				ctaKeys.add(((BigDecimal) a).longValue());
			}
		}

		return ctaKeys;
	}

	@Override
	public RoleAccessConfigurationBean getLinkAcess(RoleAccessConfigurationBean inputbean) {

		RoleAccessConfigurationBean accessConfigurationBean = new RoleAccessConfigurationBean();
		List<LinkSectionBean> linkSectionBeans = new ArrayList<>();
		Map<Long, LinkSectionBean> linkSectionBeanMap = new HashMap<>();
		List<Object[]> objectList = entityManager.createNamedQuery("findLinksByTabKeyAndRoleKey")
				.setParameter(TABKEY, inputbean.getTabKeys()).setParameter(RKEY, inputbean.getRoleKeys())
				.getResultList();
		for (Object[] links : objectList) {
			LinkBean linkBean = new LinkBean();
			linkBean.setLinkkey(Long.parseLong(links[0].toString()));
			linkBean.setLinkcode(new BigDecimal(links[1].toString()));
			linkBean.setLinkname(links[2].toString());
			if (BigDecimal.ONE.equals(new BigDecimal(links[3].toString()))) {
				linkBean.setSelected(true);
			}

			if (linkSectionBeanMap.get(Long.parseLong(links[4].toString())) != null) {
				List<LinkBean> linkBeanList = linkSectionBeanMap.get(Long.parseLong(links[4].toString())).getLinks();
				linkBeanList.add(linkBean);
			} else {
				List<LinkBean> linkBeanList = new ArrayList<>();
				linkBeanList.add(linkBean);
				LinkSectionBean linkSectionBean = new LinkSectionBean();

				linkSectionBean.setTabkey(Long.parseLong(links[4].toString()));
				linkSectionBean.setTabname(links[5].toString());
				linkSectionBean.setLinks(linkBeanList);
				linkSectionBeans.add(linkSectionBean);
				linkSectionBeanMap.put(Long.parseLong(links[4].toString()), linkSectionBean);
			}

		}

		if (!linkSectionBeans.isEmpty()) {

			accessConfigurationBean.setLinkBeanList(linkSectionBeans);
		}
		return accessConfigurationBean;
	}
	
	@Override
	public String getProdMastCode(Long prodMastKey) {
		try {
			ProductMaster productMaster = (ProductMaster) entityManager
					.createNamedQuery("ProductMaster.findAllByProdMastKey").setParameter("prodmastkey", prodMastKey)
					.setParameter("prodmastisactive", BigDecimal.ONE).getSingleResult();
			return productMaster.getProdmastcode();
		}catch (NoResultException noResult) {
			return null;
		} catch (Exception e) {
			logger.error(CLASS_NAME, DAO, DAO_ERR_MSG1);
			throw new BFLTechnicalException("ROLEMGT_7016", e);
		}
	}

}
