package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the FIELD_SET_ROLES database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_ROLES")
@NamedQueries({
//@NamedQuery(name="FieldSetRoleL3.findAll", query="SELECT f FROM FieldSetRoleL3 f"),
@NamedQuery(name="FieldSetRoleL3.findActiveForRole", 
	query="SELECT f FROM FieldSetRoleL3 f WHERE f.isactive =1 AND f.roleProductMapping.roleprodkey =:roleKey"),
@NamedQuery(name="FieldSetRoleL3.findAllActiveForRoleKeys", 
	query="SELECT f FROM FieldSetRoleL3 f"
			+ " ,FieldSetAttributeL3 fsa"
			+ " WHERE f.isactive =1"
			+ " and f.fieldSetAttribute.fieldkey= fsa.fieldkey and"
			+ " f.roleProductMapping.roleprodkey IN :rolekeys"
			//+ " and fp.prodmastkey=:prodkey and fp.subprodtypekey=:subprodkey"
			),
@NamedQuery(name="FieldSetRoleL3.DeleteFieldSetRoles",query="Delete from FieldSetRoleL3 f where f.roleProductMapping.roleprodkey in ("
		+ " select rp.roleprodkey from RoleProductMapping rp ,FieldSetRoleL3 f WHERE f.isactive = 1 and"
		+ " f.roleProductMapping.roleprodkey = rp.roleprodkey"
		+ " AND f.roleProductMapping.roleprodkey = :rolekey)")
})
public class FieldSetRoleL3 implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long fieldrolekey;

	private BigDecimal fieldaccess;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//private BigDecimal rolekey;

	//bi-directional many-to-one association to FieldSetAttribute
	@ManyToOne
	@JoinColumn(name="FIELDKEY")
	private FieldSetAttributeL3 fieldSetAttribute;
	
	@ManyToOne
	@JoinColumn(name="ROLEKEY",referencedColumnName="ROLEPRODKEY")
	private RoleProductMapping roleProductMapping;

	public FieldSetRoleL3() {
	}

	public long getFieldrolekey() {
		return this.fieldrolekey;
	}

	public void setFieldrolekey(long fieldrolekey) {
		this.fieldrolekey = fieldrolekey;
	}

	public BigDecimal getFieldaccess() {
		return this.fieldaccess;
	}

	public void setFieldaccess(BigDecimal fieldaccess) {
		this.fieldaccess = fieldaccess;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

//	public BigDecimal getRolekey() {
//		return this.rolekey;
//	}
//
//	public void setRolekey(BigDecimal rolekey) {
//		this.rolekey = rolekey;
//	}

	public FieldSetAttributeL3 getFieldSetAttribute() {
		return this.fieldSetAttribute;
	}

	public void setFieldSetAttribute(FieldSetAttributeL3 fieldSetAttribute) {
		this.fieldSetAttribute = fieldSetAttribute;
	}
	public RoleProductMapping getRoleProductMapping() {
		return this.roleProductMapping;
	}

	public void setRoleProductMapping(RoleProductMapping roleProductMapping) {
		this.roleProductMapping = roleProductMapping;
	}

}