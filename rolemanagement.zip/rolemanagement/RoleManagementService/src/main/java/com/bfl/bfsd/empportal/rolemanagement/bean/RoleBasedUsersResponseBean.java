package com.bfl.bfsd.empportal.rolemanagement.bean;

import java.math.BigDecimal;

public class RoleBasedUsersResponseBean {
	
	
	private BigDecimal userKey;
	private String userFullName;
	private String firstName;
	private String lastName;
	
	
	public BigDecimal getUserKey() {
		return userKey;
	}
	public void setUserKey(BigDecimal userKey) {
		this.userKey = userKey;
	}
	public String getUserFullName() {
		return userFullName;
	}
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	@Override
	public String toString() {
		return "RoleBasedUsersResponseBean [userKey=" + userKey + ", userFullName=" + userFullName + ", firstName="
				+ firstName + ", lastName=" + lastName + "]";
	}
	
	


}
	