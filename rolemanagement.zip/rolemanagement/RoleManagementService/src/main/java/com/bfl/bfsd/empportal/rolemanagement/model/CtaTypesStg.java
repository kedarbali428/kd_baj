package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the CTA_TYPES_STG database table.
 * 
 */
@Entity
@Table(name="CTA_TYPES_STG")
//@NamedQuery(name="CtaTypesStg.findAll", query="SELECT c FROM CtaTypesStg c")
public class CtaTypesStg implements Serializable {
	private static final long serialVersionUID = 1L;

	private String activity;

	@Column(name="CTA_NAME")
	private String ctaName;
	@Id
	private BigDecimal ctacode;

	private String description;

	private String location;

	public CtaTypesStg() {
	}

	public String getActivity() {
		return this.activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public String getCtaName() {
		return this.ctaName;
	}

	public void setCtaName(String ctaName) {
		this.ctaName = ctaName;
	}

	public BigDecimal getCtacode() {
		return this.ctacode;
	}

	public void setCtacode(BigDecimal ctacode) {
		this.ctacode = ctacode;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

}