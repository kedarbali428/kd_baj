package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the APP_ROLE_VIEW database table.
 * 
 */
@Entity
@Table(name="APP_ROLE_VIEW")
//o@NamedQuery(name="AppRoleView.findAll", query="SELECT a FROM AppRoleView a")
public class AppRoleView implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long viewrolekey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to AppViewDefinition
	@ManyToOne
	@JoinColumn(name="VIEWKEY")
	private AppViewDefinition appViewDefinition;

	//bi-directional many-to-one association to BfsdRoleMaster
	@ManyToOne
	@JoinColumn(name="ROLEKEY")
	private BfsdRoleMaster bfsdRoleMaster;

	//bi-directional many-to-one association to AppUserView
	@OneToMany(mappedBy="appRoleView")
	private List<AppUserView> appUserViews;

	public AppRoleView() {
	}

	public long getViewrolekey() {
		return this.viewrolekey;
	}

	public void setViewrolekey(long viewrolekey) {
		this.viewrolekey = viewrolekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public AppViewDefinition getAppViewDefinition() {
		return this.appViewDefinition;
	}

	public void setAppViewDefinition(AppViewDefinition appViewDefinition) {
		this.appViewDefinition = appViewDefinition;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return this.bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

	public List<AppUserView> getAppUserViews() {
		return this.appUserViews;
	}

	public void setAppUserViews(List<AppUserView> appUserViews) {
		this.appUserViews = appUserViews;
	}

	public AppUserView addAppUserView(AppUserView appUserView) {
		getAppUserViews().add(appUserView);
		appUserView.setAppRoleView(this);

		return appUserView;
	}

	public AppUserView removeAppUserView(AppUserView appUserView) {
		getAppUserViews().remove(appUserView);
		appUserView.setAppRoleView(null);

		return appUserView;
	}

}