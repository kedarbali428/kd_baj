package com.bfl.bfsd.empportal.rolemanagement.constants;

import java.math.BigDecimal;

public class RoleManagementConstants {
	

	public static final String ISACTIVE = "isactive";
	public static final String ROLEPRODUCTMAPPING = "roleProductMapping";
	public static final String ROLEKEY = "rolekey";
	public static final String ROLEKEYS = "rolekeys";
	public static final String SUBPRODKEY = "subprodkey";
	public static final String PRODKEY = "prodkey";
	public static final String ROLEPRODKEY = "roleprodkey";
	public static final String ROLEPRODKEYS = "roleprodkeys";
	public static final String TABKEYS = "tabkeys";
	public static final String LINKKEYS = "Linkkeys";
	public static final String COMMON_TABCD_LIST = "commonTabcdList";
	
	
	public static final BigDecimal TAB_CODE_UNSECURED=BigDecimal.ONE;
	public static final BigDecimal TAB_CODE_SECURED=BigDecimal.valueOf(17);
	public static final BigDecimal TAB_CODE_GENERAL_INS=BigDecimal.valueOf(2);
	public static final BigDecimal TAB_CODE_LIFE_INS=BigDecimal.valueOf(19);
	public static final String ADMIN_CODE = "44";
	
	public static final String ROLEPRODNAMEDQUERY="RoleProductMapping.findAllRoleKey";
	public static final String ROLEPRODUCTNAMEDQUERY="RoleProductMapping.findAllRoleKeyProdkey";
	
	
	public static final String ERROR_7018 = "ROLEMGT_7018";
	public static final BigDecimal TAB_CODE_CARDS=BigDecimal.valueOf(20);
	
	private RoleManagementConstants(){
		
	}
}
