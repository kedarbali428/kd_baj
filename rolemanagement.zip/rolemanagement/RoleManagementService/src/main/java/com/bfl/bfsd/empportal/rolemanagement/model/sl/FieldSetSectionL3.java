package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the FIELD_SET_SECTIONS database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_SECTIONS")
//@NamedQuery(name="FieldSetSectionL3.findAll", query="SELECT f FROM FieldSetSection f")
public class FieldSetSectionL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long sectionkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal orderno;

	private BigDecimal sectioncd;

	private String sectionname;

	//bi-directional many-to-one association to FieldSetGroup
	@ManyToOne
	@JoinColumn(name="GROUPKEY")
	private FieldSetGroupL3 fieldSetGroup;

	//bi-directional many-to-one association to FieldSetSectionProduct
	@OneToMany(mappedBy="fieldSetSection")
	private List<FieldSetSectionProduct> fieldSetSectionProducts;

	//bi-directional many-to-one association to FieldSetSubsection
	@OneToMany(mappedBy="fieldSetSection")

	private List<FieldSetSubsectionL3> fieldSetSubsections;
	public FieldSetSectionL3() {
	}

	public long getSectionkey() {
		return this.sectionkey;
	}

	public void setSectionkey(long sectionkey) {
		this.sectionkey = sectionkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getOrderno() {
		return this.orderno;
	}

	public void setOrderno(BigDecimal orderno) {
		this.orderno = orderno;
	}

	public BigDecimal getSectioncd() {
		return this.sectioncd;
	}

	public void setSectioncd(BigDecimal sectioncd) {
		this.sectioncd = sectioncd;
	}

	public String getSectionname() {
		return this.sectionname;
	}

	public void setSectionname(String sectionname) {
		this.sectionname = sectionname;
	}

	public FieldSetGroupL3 getFieldSetGroup() {
		return this.fieldSetGroup;
	}

	public void setFieldSetGroup(FieldSetGroupL3 fieldSetGroup) {
		this.fieldSetGroup = fieldSetGroup;
	}

	public List<FieldSetSectionProduct> getFieldSetSectionProducts() {
		return this.fieldSetSectionProducts;
	}

	public void setFieldSetSectionProducts(List<FieldSetSectionProduct> fieldSetSectionProducts) {
		this.fieldSetSectionProducts = fieldSetSectionProducts;
	}

	public FieldSetSectionProduct addFieldSetSectionProduct(FieldSetSectionProduct fieldSetSectionProduct) {
		getFieldSetSectionProducts().add(fieldSetSectionProduct);
		fieldSetSectionProduct.setFieldSetSection(this);

		return fieldSetSectionProduct;
	}

	public FieldSetSectionProduct removeFieldSetSectionProduct(FieldSetSectionProduct fieldSetSectionProduct) {
		getFieldSetSectionProducts().remove(fieldSetSectionProduct);
		fieldSetSectionProduct.setFieldSetSection(null);

		return fieldSetSectionProduct;
	}

	public List<FieldSetSubsectionL3> getFieldSetSubsections() {
		return this.fieldSetSubsections;
	}

	public void setFieldSetSubsections(List<FieldSetSubsectionL3> fieldSetSubsections) {
		this.fieldSetSubsections = fieldSetSubsections;
	}

	public FieldSetSubsectionL3 addFieldSetSubsection(FieldSetSubsectionL3 fieldSetSubsection) {
		getFieldSetSubsections().add(fieldSetSubsection);
		fieldSetSubsection.setFieldSetSection(this);

		return fieldSetSubsection;
	}

	public FieldSetSubsectionL3 removeFieldSetSubsection(FieldSetSubsectionL3 fieldSetSubsection) {
		getFieldSetSubsections().remove(fieldSetSubsection);
		fieldSetSubsection.setFieldSetSection(null);

		return fieldSetSubsection;
	}

}