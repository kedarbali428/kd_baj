package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the BFSD_FUNCTION_ROLES database table.
 * 
 */
@Entity
@Table(name="BFSD_FUNCTION_ROLES")
//@NamedQuery(name="BfsdFunctionRole.findAll", query="SELECT b FROM BfsdFunctionRole b")
public class BfsdFunctionRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long functionrolekey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to BfsdFunction
	@ManyToOne
	@JoinColumn(name="FUNCTIONKEY")
	private BfsdFunction bfsdFunction;

	//bi-directional many-to-one association to BfsdRoleMaster
	@ManyToOne
	@JoinColumn(name="ROLEKEY")
	private BfsdRoleMaster bfsdRoleMaster;

	public BfsdFunctionRole() {
	}

	public long getFunctionrolekey() {
		return this.functionrolekey;
	}

	public void setFunctionrolekey(long functionrolekey) {
		this.functionrolekey = functionrolekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BfsdFunction getBfsdFunction() {
		return this.bfsdFunction;
	}

	public void setBfsdFunction(BfsdFunction bfsdFunction) {
		this.bfsdFunction = bfsdFunction;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return this.bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

}