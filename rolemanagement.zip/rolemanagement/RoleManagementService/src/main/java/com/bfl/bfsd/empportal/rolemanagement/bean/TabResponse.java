package com.bfl.bfsd.empportal.rolemanagement.bean;

import java.util.List;

public class TabResponse {

	private List<RoleTabKeyAndNameResponse> roleTabKeyAndNameResponse;

	public List<RoleTabKeyAndNameResponse> getRoleTabKeyAndNameResponse() {
		return roleTabKeyAndNameResponse;
	}

	public void setRoleTabKeyAndNameResponse(List<RoleTabKeyAndNameResponse> roleTabKeyAndNameResponse) {
		this.roleTabKeyAndNameResponse = roleTabKeyAndNameResponse;
	}

	
	
	
	
}
