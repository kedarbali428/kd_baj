package com.bfl.bfsd.empportal.rolemanagement.controller;




import static com.bajaj.bfsd.common.BFLLoggerComponent.CONTROLLER;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.CNTR_MSG1;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.CNTR_MSG2;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.CNTR_MSG3;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.CNTR_MSG4;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.CNTR_MSG5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.persistence.PersistenceException;
import javax.validation.Valid;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerHeader;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.cache.service.UserCacheService;
import com.bajaj.bfsd.common.cache.service.entity.CacheUserEntity;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.bfsd.empportal.rolemanagement.bean.AssignedRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.FieldSetGroupBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationResponseBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleBasedUsersListResponceBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.Section;
import com.bfl.bfsd.empportal.rolemanagement.bean.UserRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.beanmapper.BeanMapper;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetRolesDTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetSubSectionRolesDTO;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetGroup;
import com.bfl.bfsd.empportal.rolemanagement.model.LinkSectionBean;
import com.bfl.bfsd.empportal.rolemanagement.plugin.OMRoleManagementDataPluginMapper;
import com.bfl.bfsd.empportal.rolemanagement.service.RoleManagementService;
import com.bfl.bfsd.empportal.rolemanagement.util.RoleManagementUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * Description of the class
 * This class is the controller class for the Role Management Service
 *
 * @author Cognizant - Date - 27/02/2017
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                                       27/02/2017
 *
 */
@RestController
@ComponentScans(value = {@ComponentScan("com.bfl.bfsd.empportal.rolemanagement"),@ComponentScan("com.bajaj.bfsd.common")})
//@RequestMapping("${rolemanagement.base.url}")
public class RoleManagementController extends BFLController{
	
	@Autowired
	RoleManagementService roleManagementService;
	
	/**@Inject
    @RequestScoped*/
    @Autowired
    BFLLoggerUtil logger;
	@Autowired
	Environment env;
	@Autowired
	BeanMapper beanMapper;
	@Autowired
	private UserCacheService cacheService;
	@Autowired
	private CustomDefaultHeaders customHeader;
	@Autowired
	OMRoleManagementDataPluginMapper dataPluginMapper;
	
	private static final String CLASS_NAME = RoleManagementController.class.getCanonicalName();

	/**
	 * @Desc This is Controller method for creating the view
	 * @param bean
	 * @param headers 
	 * @return ResponseEntity
	 * @throws BFLTechnicalException 
	 */
	@ApiOperation(value = "Get The Master Tab details ", notes = "Get The Master Tab details", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.tab.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getTabDetails(@RequestBody RoleAccessConfigurationBean roleAccessConfigBean,@RequestHeader HttpHeaders headers)  {
	
		
		logger.setCorrelationID(customHeader.getCmptcorrid());
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleManagementController : Fetch Master tab role mgmnt Service execution invoked");
		RoleAccessConfigurationBean roleAccConfig= new RoleAccessConfigurationBean();
		try {
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG4 +customHeader.getUserKey());
			
			//Set userrole in cache
			UserRoleBean roleBean = roleAccessConfigBean.getUserRole();
			if(null != roleBean){
				roleBean.setUserKey(customHeader.getUserKey());
				roleBean = setCacheUserRole(roleBean);
				 //Set DB Role is exisiting payload
				roleAccessConfigBean.setUserRole(roleBean);
			}
			
			roleAccConfig= roleManagementService.getTabDetails(roleAccessConfigBean);
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG5);
		
		} catch (HibernateException hexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Hibernate Exception occured while fetching tab details : "+RoleManagementUtil.getExceptionTrace(hexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("ROLEMGT_7003", hexception);
		} catch (PersistenceException pexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Persistence Exception occured while fetching tab details : "+RoleManagementUtil.getExceptionTrace(pexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("ROLEMGT_7004", pexception);
		} 
		
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleManagementController : Tab configuration Service execution completed");
		return new ResponseEntity<>(new ResponseBean(roleAccConfig), HttpStatus.OK);
	}
	/**
	 * @Desc This is Controller method for creating the view
	 * @param bean
	 * @param headers 
	 * @return ResponseEntity
	 * @throws BFLTechnicalException 
	 */
	@ApiOperation(value = "Get The Master Tab details ", notes = "Get The Master Tab details", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.cta.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getCTADetails(@RequestBody RoleAccessConfigurationBean roleAccConfigBean,@RequestHeader HttpHeaders headers)  {
	
		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleManagementController : Fetch  ctadetails role mgmnt Service execution invoked");
		RoleAccessConfigurationBean roleAccConfig= new RoleAccessConfigurationBean();
		try {
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG4);
			 String prodMastCode = roleManagementService.getProdMastCode(roleAccConfigBean.getProductTypeKey());
			 roleAccConfig= roleManagementService.getCTADetails(roleAccConfigBean);
				switch(prodMastCode) {
				case "OMCREDIT":
					List<Section> omGroupBeanList = dataPluginMapper.getCTADataList(roleAccConfigBean.getProductTypeKey(), roleAccConfigBean.getSubprodkey().get(0), roleAccConfigBean.getTabKeys(), roleAccConfigBean.getRoleKeys(), headers);
					if(CollectionUtils.isEmpty(roleAccConfig.getCtaSectionList())) {
						roleAccConfig.setCtaSectionList(new ArrayList<Section>());
					}
					roleAccConfig.getCtaSectionList().addAll(omGroupBeanList);
					break;
				
				case "OMINS":
					List<Section> omInsGroupBeanList = dataPluginMapper.getCTADataListOmIns(roleAccConfigBean.getProductTypeKey(), roleAccConfigBean.getSubprodkey().get(0), roleAccConfigBean.getTabKeys(), roleAccConfigBean.getRoleKeys(), headers);
					if(CollectionUtils.isEmpty(roleAccConfig.getCtaSectionList())) {
						roleAccConfig.setCtaSectionList(new ArrayList<Section>());
					}
					roleAccConfig.getCtaSectionList().addAll(omInsGroupBeanList);
					break;
				}
				if(roleAccConfigBean.getTabName().contains("OM-Product Offering")) {
					List<Long> productOfferTabs = new ArrayList<>();
					productOfferTabs.add(1236L);
					 List<Section> omOfferGroupBeanList = dataPluginMapper.getOfferCTADataList(roleAccConfigBean.getProductTypeKey(), roleAccConfigBean.getSubprodkey().get(0), roleAccConfigBean.getTabKeys(),roleAccConfigBean.getRoleKeys(), headers,roleAccConfigBean.getProdCatCode(),"0");
					 roleAccConfig.getCtaSectionList().addAll(omOfferGroupBeanList);
					}
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,CNTR_MSG5);
		
		} catch (HibernateException hibexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Hibernate Exception occured while config role(CTADETAILS) : "+RoleManagementUtil.getExceptionTrace(hibexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("ROLEMGT_7005",env.getProperty("ROLEMGT_7005"));
			
		} catch (PersistenceException perexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Persistence Exception occured while config role(CTADETAILS) : "+RoleManagementUtil.getExceptionTrace(perexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("ROLEMGT_7006",env.getProperty("ROLEMGT_7006"));
			
		} 
		
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleManagementController : CTA configuration Service execution completed(CTADETAILS)");
		return new ResponseEntity<>(new ResponseBean(roleAccConfig), HttpStatus.OK);
	}
	
	
	/**
	 * @Desc This is Controller method for creating the Role access configurations.
	 * @param bean RoleAccessConfigurationInputBean
	 * @param headers 
	 * @return ResponseEntity
	 * @throws BFLTechnicalException 
	 */
	@CrossOrigin
	@ApiOperation(value = "Save details for selected product,role,tabs,ctas and fields access details.", notes = "Save details for selected product,role,tabs,ctas and fields access details.")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.role.access.configuration.POST.uri}")
	public ResponseEntity<ResponseBean> saveTabCtaConfiguration(
			@Valid @RequestBody RoleAccessConfigurationInputBean inputBean, 
			BindingResult bindingResult,
			@RequestHeader HttpHeaders headers)  {
		logger.debug(CLASS_NAME, CONTROLLER, "Controller invoked!!");
		validateRequest(bindingResult);
		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.debug(CLASS_NAME, CONTROLLER, CNTR_MSG1);
		
		boolean successFlag = roleManagementService.saveRoleAccessconfigurations(inputBean);
		RoleAccessConfigurationResponseBean result = prepareRespponse(successFlag);
		logger.debug(CLASS_NAME, CONTROLLER, CNTR_MSG2+result);
		return new ResponseEntity<>(new ResponseBean(result), HttpStatus.OK);
	}
	
	private void validateRequest(BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			logger.error(CLASS_NAME, CONTROLLER, CNTR_MSG3);
			throw new BFLBusinessException(bindingResult.getFieldErrors());
		}
	}
	
	private RoleAccessConfigurationResponseBean prepareRespponse(boolean successFlag) {
		RoleAccessConfigurationResponseBean bean = new RoleAccessConfigurationResponseBean();
		bean.setIsRoleAccessConfigurationSuccessful(successFlag);
		return bean;
		
	}
	
	
	/**
	 * @Desc This is Controller method for creating the view
	 * @param bean
	 * @param headers 
	 * @return ResponseEntity
	 * @throws BFLTechnicalException 
	 */
	@ApiOperation(value = "get user list based on user role  ", notes = "Based on role key need to access all user", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.GET, value = "${api.rolemanagement.role.list.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUserRoles(@RequestParam Long roleKey ,@RequestParam(required=false) Long applicationkey , @RequestHeader HttpHeaders headers)  {
	
		RoleBasedUsersListResponceBean userRoleList = roleManagementService.getUsersListOnRoleBased(roleKey,applicationkey);
		
		if(userRoleList != null)
		{
			logger.debug(CLASS_NAME, CONTROLLER, "users list based on user role displayed"+ userRoleList);
		}
		else
		{
			logger.debug(CLASS_NAME, CONTROLLER, "userRoleList is null "+ userRoleList);
		}
		
		
	
		return new ResponseEntity<>(new ResponseBean(userRoleList), HttpStatus.OK);
	}

	
	/**
	 * @Desc This is Controller method for creating the view
	 * @param bean
	 * @param headers 
	 * @return ResponseEntity
	 * @throws BFLTechnicalException 
	 */
	@ApiOperation(value = "Get The Group, Section and sub Section details.", notes = "Get The Group, Section and sub Section details.", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.group.section.subsection.details.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> fetchAllGroupSectionAndSubSectionDetails(@RequestBody RoleAccessConfigurationBean roleAccessBean,@RequestHeader HttpHeaders headers)  {
	
		
		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start fetching groups, section and sub section details for input :"+roleAccessBean);
/**			roleAccessConfigBean= roleManagementService.getUIFields(roleAccessConfigBean);
			//Fetch  Groups, Section and SubSection
	*/		List<FieldSetGroup> list = roleManagementService.fetchGroupsSectinoAndsubSectionforUser(roleAccessBean);
			beanMapper.prepareResponseForGroupsAndSection(roleAccessBean, list);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching groups details.");
		} catch (HibernateException hibernateexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Hibernate Exception occured while fetching groups details: "+RoleManagementUtil.getExceptionTrace(hibernateexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("ROLEMGT_7007", env.getProperty("ROLEMGT_7007"));
		} catch (PersistenceException persistexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Persistence Exception occured while fetching groups details : "+RoleManagementUtil.getExceptionTrace(persistexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("ROLEMGT_7008", env.getProperty("ROLEMGT_7008"));
		} 
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching groups, section and sub section details for input");
		return new ResponseEntity<>(new ResponseBean(roleAccessBean), HttpStatus.OK);
	}
	
	/**
	 * @Desc This is Controller method for creating the view
	 * @param bean
	 * @param headers 
	 * @return ResponseEntity
	 * @throws BFLTechnicalException 
	 */
	@ApiOperation(value = "Get The UIFields details for selected Group, Section and SubSections.", notes = "Get The UIFields details for selected Group, Section and SubSections.", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.uifields.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getUIFieldsForSelectedSectionAndSubSections(@RequestBody RoleAccessConfigurationBean roleAccessConBean,@RequestHeader HttpHeaders headers)  {
	
		
		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Request came for fetching All Fields details for selected group, section and subsection : "+roleAccessConBean);
		try {
			/**Fetch UI fields for Group/Section and SuvSection
//			List<FieldSetSubsection> list2 = roleManagementService.fetchFieldsforGroupsSectinoAndsubSection(roleAccessConBean);
//			beanMapper.mapFields(roleAccessConBean, list2);;
//			List<FieldSetGroup> list3 = roleManagementService.fetchFieldsDetailsforGroupsSectinoAndsubSection(roleAccessConBean);
		*/	FieldSetGroupAndFieldSetRolesDTO dto = roleManagementService.fetchFieldsDetailsforGroupsSectinoAndsubSection(roleAccessConBean);
			List<FieldSetGroupBean> fieldSetGroupBeans = beanMapper.prepareGroupsWithSubSections(dto, roleAccessConBean );
			roleAccessConBean.setFieldSetGroups(fieldSetGroupBeans);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching ui fields for selected group, section and subsection : "+roleAccessConBean);
		
		} catch (HibernateException hiexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Hibernate Exception occured while fetching ui fields : "+RoleManagementUtil.getExceptionTrace(hiexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("ROLEMGT_7009", env.getProperty("ROLEMGT_7009"));
		} catch (PersistenceException persexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Persistence Exception occured while fetching ui fields : "+RoleManagementUtil.getExceptionTrace(persexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("ROLEMGT_7010", env.getProperty("ROLEMGT_7010"));
		} 
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching ui fields.");
		return new ResponseEntity<>(new ResponseBean(roleAccessConBean), HttpStatus.OK);
	}
	
	/**
	 * @Desc This is Controller method for creating the view
	 * @param bean
	 * @param headers 
	 * @return ResponseEntity
	 * @throws BFLTechnicalException 
	 */
	@ApiOperation(value = "Get The Group, Section and sub Section details for edit case.", notes = "Get The Group, Section and sub Section details for edit case.", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.GET, value = "${api.rolemanagement.edit.roleaccessconfig.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> fetchAllGroupSectionAndSubSectionDetailsForEdit(
			@PathVariable(name="roleKey")long roleKey,
			@RequestParam(name="tabKeys")String tabKeys,
			@RequestHeader HttpHeaders headers)  {
		
		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		List<FieldSetGroupBean> fieldSetGroupBeans = null;
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start fetching groups, section and sub section details for input role for edit :" +roleKey + " And tab keys :"+tabKeys);
			List<Long> tabKeysList = Arrays.asList(tabKeys.split(",")).stream().map(Long::parseLong).collect(Collectors.toList());
			FieldSetGroupAndFieldSetSubSectionRolesDTO dto = roleManagementService.fetchGroupsSectinoAndsubSectionforUserInEditView(Arrays.asList(roleKey),tabKeysList);
			fieldSetGroupBeans = beanMapper.prepareResponseForGroupsAndSectionForEditCase(dto,roleKey);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching groups details for edit.");
		} catch (HibernateException hibernexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Hibernate Exception occured while fetching group n subsection : "+RoleManagementUtil.getExceptionTrace(hibernexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("VWMT_7011", hibernexception);
		} catch (PersistenceException persistentexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Persistence Exception occured while fetching group n subsection : "+RoleManagementUtil.getExceptionTrace(persistentexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("VWMT_7012", persistentexception);
		} 
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Done with fetching groups, section and sub section details for input role for edit.");
		return new ResponseEntity<>(new ResponseBean(fieldSetGroupBeans), HttpStatus.OK);
	}
	
	
	/**
	 * @Desc This is Controller method for creating the view
	 * @param bean
	 * @param headers 
	 * @return ResponseEntity
	 * @throws BFLTechnicalException 
	 */
	@ApiOperation(value = "Clone the role aceces from one role to another.", notes = "Clone the role aceces from one role to another.", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.clone.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> cloneRoleAccessConfiguration(@RequestBody CloneRoleAccessConfigureBean cloneRoleAccessConfigBean,@RequestHeader HttpHeaders headers)  {
	
		
		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleManagementController : clone service role mgmnt Service execution invoked");
		
		try {
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG4);
			
			roleManagementService.cloneRoleAccessConfiguration(cloneRoleAccessConfigBean);
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG5);
		
		} catch (HibernateException hiberexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Hibernate Exception occured while cloning role : "+RoleManagementUtil.getExceptionTrace(hiberexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("VWMT_7013", hiberexception);
		} catch (PersistenceException persisexception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Persistence Exception occured while cloning role : "+RoleManagementUtil.getExceptionTrace(persisexception, logger.getCorrelationID()));
			throw new BFLTechnicalException("VWMT_7014", persisexception);
		} 
		
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleManagementController : role mgmt Service execution completed");
		return new ResponseEntity<>(new ResponseBean("SUCCESS"), HttpStatus.OK);
	}


	@ApiOperation(value = "get assigned user role  ", notes = "Based on role key need to access all user", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid",required = true,dataType = "string",paramType = "header") 
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.checkRoleInUsersAssignedRolesHierarchy.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> checkRoleInUsersAssignedRolesHierarchy(@RequestBody AssignedRoleBean roleConfig  , @RequestHeader HttpHeaders headers)  {
		
		
		Boolean isRoleAssigned = roleManagementService.checkRoleInUsersAssignedRolesHierarchy(roleConfig);
		logger.debug(CLASS_NAME, CONTROLLER, "users has role in his hierarchy - "+ isRoleAssigned);
		return new ResponseEntity<>(new ResponseBean(isRoleAssigned), HttpStatus.OK);
	}

	
	private UserRoleBean setCacheUserRole(UserRoleBean userRoleBean){
			
		UserRoleBean dbUserRole = roleManagementService.getUserRole(userRoleBean.getUserKey(), userRoleBean.getUserRoleKey());
		
		CacheUserEntity cacheUser = new CacheUserEntity();
		
		cacheUser.setUserKey(dbUserRole.getUserKey());
		cacheUser.setUserCurrentRoleName(dbUserRole.getRoleName());
		cacheUser.setUserRoleKey(dbUserRole.getUserRoleKey());
		cacheUser.setRoleKey(dbUserRole.getRoleKey());
		
		cacheService.save(cacheUser.getUserKey(), cacheUser);
		
		return dbUserRole;
	}
	
	@CrossOrigin
	@ApiOperation(value = "Check if email update is allowed", notes = "If sub stage AIP eligibility is completed, email update is allowed", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header") })
	@RequestMapping(value = "${api.rolemanagement.checkCTAAccess.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> checkCTAAccess(@PathVariable long applicationKey,
			@RequestHeader HttpHeaders headers) {
		logger.setCorrelationID(customHeader.getCmptcorrid());
		boolean isAllowed = roleManagementService.checkEmailCTAAccess(applicationKey);
		if (!isAllowed) {
			logger.error(CLASS_NAME, CONTROLLER, "checkCTAAccess - Update email not allowed for - " + applicationKey);
			throw new BFLBusinessException("ROLEMGT_7013", env.getProperty("ROLEMGT_7013"));
		}
		return new ResponseEntity<>(new ResponseBean(StatusCode.SUCCESS),HttpStatus.OK);

	}
	
	/**
	 * @Desc This is Controller method for creating the Role access configurations
	 *       for links
	 * @param bean
	 * @param headers
	 * @return ResponseEntity
	 * @throws BFLTechnicalException
	 */
	@ApiOperation(value = "Get The LinkAcess details ", notes = "Get The LinkAcess details", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.POST, value = "${api.rolemanagement.link.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getLinkAcess(@RequestBody RoleAccessConfigurationBean roleAccConfigBean,
			@RequestHeader HttpHeaders headers) {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleManagementController : Fetch  LinkAcess role mgmnt Service execution invoked");
		RoleAccessConfigurationBean roleAccConfig = new RoleAccessConfigurationBean();
		try {

			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG4);

			roleAccConfig = roleManagementService.getLinkAcess(roleAccConfigBean);
			
			 String prodMastCode = roleManagementService.getProdMastCode(roleAccConfigBean.getProductTypeKey());
			 if(null!=prodMastCode) {
				switch(prodMastCode) {
				case "OMCREDIT":
					List<LinkSectionBean> omLinkBeanList = dataPluginMapper.getLinksDataList(roleAccConfigBean.getTabKeys(), roleAccConfigBean.getRoleKeys(), headers);
					if(CollectionUtils.isEmpty(roleAccConfig.getLinkBeanList())) {
						roleAccConfig.setLinkBeanList(new ArrayList<LinkSectionBean>());
					}
					roleAccConfig.getLinkBeanList().addAll(omLinkBeanList);
					break;
					
				case "OMINS":
					List<LinkSectionBean> omInsLinkBeanList = dataPluginMapper.getLinksDataListOmIns(roleAccConfigBean.getTabKeys(), roleAccConfigBean.getRoleKeys(), headers);
					if(CollectionUtils.isEmpty(roleAccConfig.getLinkBeanList())) {
						roleAccConfig.setLinkBeanList(new ArrayList<LinkSectionBean>());
					}
					roleAccConfig.getLinkBeanList().addAll(omInsLinkBeanList);
					break;
				}
				
				if(roleAccConfigBean.getTabKeys().contains(1236L)) {
					List<Long> productOfferTabs = new ArrayList<>();
					productOfferTabs.add(1236L);
					 List<LinkSectionBean> omLinkBeanList = dataPluginMapper.getOfferLinksDataList(roleAccConfigBean.getTabKeys(), roleAccConfigBean.getRoleKeys(), headers,"0");
					 roleAccConfig.getLinkBeanList().addAll(omLinkBeanList);
					}
			 }

			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG5);

		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exception occured while config role(LinkAcess) : "
					+ RoleManagementUtil.getExceptionTrace(exception, logger.getCorrelationID()));
			throw new BFLTechnicalException("ROLEMGT_7023", env.getProperty("ROLEMGT_7023"));

		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleManagementController : LinkAcess configuration Service execution completed(LinkAcess)");
		return new ResponseEntity<>(new ResponseBean(roleAccConfig), HttpStatus.OK);
	}
	
	
	/**
	 * @Desc This is Controller method for creating the Role access configurations
	 *       for Links
	 * @param bean
	 * @param headers
	 * @return ResponseEntity
	 * @throws BFLTechnicalException
	 */
	@ApiOperation(value = "Get Selected links", notes = "GetSelected links", httpMethod = "GET")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.GET, value = "${api.rolemanagement.link.GET.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getLinksAcess(@RequestParam(required = false) Long roleKey, @RequestParam Long tabKey,
			@RequestHeader HttpHeaders headers) {

		logger.setCorrelationID(headers.getFirst(BFLLoggerHeader.ID.getValue()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleManagementController : Fetch  LinkAcess role mgmnt Service execution invoked");

		RoleAccessConfigurationBean roleAccConfig = new RoleAccessConfigurationBean();
		try {

			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG4);
			
			Long userKeyFromHeader = customHeader.getUserKey();
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Obtained userkey from header = "+userKeyFromHeader);
			CacheUserEntity userEntity = cacheService.get(userKeyFromHeader);
			Long roleKeyFromEntity = userEntity.getRoleKey();
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "RoleKey from Cache User Entity = "+roleKeyFromEntity);
			
			roleAccConfig = roleManagementService.getLinksAcess(roleKeyFromEntity, tabKey);

			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, CNTR_MSG5);

		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Exception occured while config role(LinkAcess) : "
					+ RoleManagementUtil.getExceptionTrace(exception, logger.getCorrelationID()));
			throw new BFLTechnicalException("ROLEMGT_7024", env.getProperty("ROLEMGT_7024"));

		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"RoleManagementController : LinkAcess configuration Service execution completed(LinkAcess)");
		return new ResponseEntity<>(new ResponseBean(roleAccConfig), HttpStatus.OK);
	}
	
	
}
