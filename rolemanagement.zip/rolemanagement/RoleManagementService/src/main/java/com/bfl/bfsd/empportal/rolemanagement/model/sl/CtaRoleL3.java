package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import javax.persistence.*;

import com.bfl.bfsd.empportal.rolemanagement.model.CtaProduct;

import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the CTA_ROLES database table.
 * 
 */
@Entity
@Table(name="CTA_ROLES")
@NamedQueries({
//@NamedQuery(name="CtaRoleL3.findAll", query="SELECT c FROM CtaRoleL3 c"),
@NamedQuery(name="CtaRoleL3.findAllActiveForProductAndRole", query="SELECT c FROM CtaRoleL3 c WHERE c.isactive = 1 "
			+ " AND c.ctaProduct.ctaprodkey IN :ctaprodkeys AND c.roleProductMapping.roleprodkey =:rolekey"),
@NamedQuery(name="CtaRoleL3.DeleteCtaRoles",query="DELETE FROM CtaRoleL3 c WHERE c.roleProductMapping.roleprodkey in"
		+ " (select r.roleprodkey from RoleProductMapping r ,CtaProduct cp ,CtaRoleL3 c"
		+ " where cp.ctaprodkey=c.ctaProduct.ctaprodkey and c.roleProductMapping.roleprodkey=r.roleprodkey"
		+ " and cp.prodmastkey = :productmasterkey AND"
		+ " cp.subprodtypekey= :subprodkey AND c.roleProductMapping.roleprodkey= :rolekey)")
})
public class CtaRoleL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long ctarolekey;                           

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to RoleProductMapping
	@ManyToOne
	@JoinColumn(name="ROLEKEY",referencedColumnName="ROLEPRODKEY")
	private RoleProductMapping roleProductMapping;

	//bi-directional many-to-one association to CtaProduct
	@ManyToOne
	@JoinColumn(name="CTAPRODKEY")
	private CtaProduct ctaProduct;

	public CtaRoleL3() {
	}

	public long getCtarolekey() {
		return this.ctarolekey;
	}

	public void setCtarolekey(long ctarolekey) {
		this.ctarolekey = ctarolekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}


	public RoleProductMapping getRoleProductMapping() {
		return roleProductMapping;
	}

	public void setRoleProductMapping(RoleProductMapping roleProductMapping) {
		this.roleProductMapping = roleProductMapping;
	}


	public CtaProduct getCtaProduct() {
		return this.ctaProduct;
	}

	public void setCtaProduct(CtaProduct ctaProduct) {
		this.ctaProduct = ctaProduct;
	}

}