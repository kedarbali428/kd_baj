package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the USER_ROLES database table.
 * 
 */
@Entity
@Table(name="USER_ROLES")
//@NamedQuery(name="UserRole.findAll", query="SELECT u FROM UserRole u")
public class UserRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long userrolekey;

	private BigDecimal creditlimit;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal parentuser;

	private BigDecimal userkey;

	//bi-directional many-to-one association to AppUserView
	@OneToMany(mappedBy="userRole")
	private List<AppUserView> appUserViews;

	//bi-directional many-to-one association to UserNotification
	@OneToMany(mappedBy="userRole")
	private List<UserNotification> userNotifications;

	//bi-directional many-to-one association to BfsdRoleMaster
	@ManyToOne
	@JoinColumn(name="ROLEKEY")
	private BfsdRoleMaster bfsdRoleMaster;

	//bi-directional many-to-one association to UserRoleChannel
	@OneToMany(mappedBy="userRole")
	private List<UserRoleChannel> userRoleChannels;

	//bi-directional many-to-one association to UserRoleLocation
	@OneToMany(mappedBy="userRole")
	private List<UserRoleLocation> userRoleLocations;

	//bi-directional many-to-one association to UserRolePinCode
	@OneToMany(mappedBy="userRole")
	private List<UserRolePinCode> userRolePinCodes;

	//bi-directional many-to-one association to UserRoleProduct
	@OneToMany(mappedBy="userRole")
	private List<UserRoleProduct> userRoleProducts;

	//bi-directional many-to-one association to CaseAssignment
	@OneToMany(mappedBy="userRole")
	private List<CaseAssignment> caseAssignments;

	public UserRole() {
	}

	public long getUserrolekey() {
		return this.userrolekey;
	}

	public void setUserrolekey(long userrolekey) {
		this.userrolekey = userrolekey;
	}

	public BigDecimal getCreditlimit() {
		return this.creditlimit;
	}

	public void setCreditlimit(BigDecimal creditlimit) {
		this.creditlimit = creditlimit;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getParentuser() {
		return this.parentuser;
	}

	public void setParentuser(BigDecimal parentuser) {
		this.parentuser = parentuser;
	}

	public BigDecimal getUserkey() {
		return this.userkey;
	}

	public void setUserkey(BigDecimal userkey) {
		this.userkey = userkey;
	}

	public List<AppUserView> getAppUserViews() {
		return this.appUserViews;
	}

	public void setAppUserViews(List<AppUserView> appUserViews) {
		this.appUserViews = appUserViews;
	}

	public AppUserView addAppUserView(AppUserView appUserView) {
		getAppUserViews().add(appUserView);
		appUserView.setUserRole(this);

		return appUserView;
	}

	public AppUserView removeAppUserView(AppUserView appUserView) {
		getAppUserViews().remove(appUserView);
		appUserView.setUserRole(null);

		return appUserView;
	}

	public List<UserNotification> getUserNotifications() {
		return this.userNotifications;
	}

	public void setUserNotifications(List<UserNotification> userNotifications) {
		this.userNotifications = userNotifications;
	}

	public UserNotification addUserNotification(UserNotification userNotification) {
		getUserNotifications().add(userNotification);
		userNotification.setUserRole(this);

		return userNotification;
	}

	public UserNotification removeUserNotification(UserNotification userNotification) {
		getUserNotifications().remove(userNotification);
		userNotification.setUserRole(null);

		return userNotification;
	}

	public BfsdRoleMaster getBfsdRoleMaster() {
		return this.bfsdRoleMaster;
	}

	public void setBfsdRoleMaster(BfsdRoleMaster bfsdRoleMaster) {
		this.bfsdRoleMaster = bfsdRoleMaster;
	}

	public List<UserRoleChannel> getUserRoleChannels() {
		return this.userRoleChannels;
	}

	public void setUserRoleChannels(List<UserRoleChannel> userRoleChannels) {
		this.userRoleChannels = userRoleChannels;
	}

	public UserRoleChannel addUserRoleChannel(UserRoleChannel userRoleChannel) {
		getUserRoleChannels().add(userRoleChannel);
		userRoleChannel.setUserRole(this);

		return userRoleChannel;
	}

	public UserRoleChannel removeUserRoleChannel(UserRoleChannel userRoleChannel) {
		getUserRoleChannels().remove(userRoleChannel);
		userRoleChannel.setUserRole(null);

		return userRoleChannel;
	}

	public List<UserRoleLocation> getUserRoleLocations() {
		return this.userRoleLocations;
	}

	public void setUserRoleLocations(List<UserRoleLocation> userRoleLocations) {
		this.userRoleLocations = userRoleLocations;
	}

	public UserRoleLocation addUserRoleLocation(UserRoleLocation userRoleLocation) {
		getUserRoleLocations().add(userRoleLocation);
		userRoleLocation.setUserRole(this);

		return userRoleLocation;
	}

	public UserRoleLocation removeUserRoleLocation(UserRoleLocation userRoleLocation) {
		getUserRoleLocations().remove(userRoleLocation);
		userRoleLocation.setUserRole(null);

		return userRoleLocation;
	}

	public List<UserRolePinCode> getUserRolePinCodes() {
		return this.userRolePinCodes;
	}

	public void setUserRolePinCodes(List<UserRolePinCode> userRolePinCodes) {
		this.userRolePinCodes = userRolePinCodes;
	}

	public UserRolePinCode addUserRolePinCode(UserRolePinCode userRolePinCode) {
		getUserRolePinCodes().add(userRolePinCode);
		userRolePinCode.setUserRole(this);

		return userRolePinCode;
	}

	public UserRolePinCode removeUserRolePinCode(UserRolePinCode userRolePinCode) {
		getUserRolePinCodes().remove(userRolePinCode);
		userRolePinCode.setUserRole(null);

		return userRolePinCode;
	}

	public List<UserRoleProduct> getUserRoleProducts() {
		return this.userRoleProducts;
	}

	public void setUserRoleProducts(List<UserRoleProduct> userRoleProducts) {
		this.userRoleProducts = userRoleProducts;
	}

	public UserRoleProduct addUserRoleProduct(UserRoleProduct userRoleProduct) {
		getUserRoleProducts().add(userRoleProduct);
		userRoleProduct.setUserRole(this);

		return userRoleProduct;
	}

	public UserRoleProduct removeUserRoleProduct(UserRoleProduct userRoleProduct) {
		getUserRoleProducts().remove(userRoleProduct);
		userRoleProduct.setUserRole(null);

		return userRoleProduct;
	}

	public List<CaseAssignment> getCaseAssignments() {
		return this.caseAssignments;
	}

	public void setCaseAssignments(List<CaseAssignment> caseAssignments) {
		this.caseAssignments = caseAssignments;
	}

	public CaseAssignment addCaseAssignment(CaseAssignment caseAssignment) {
		getCaseAssignments().add(caseAssignment);
		caseAssignment.setUserRole(this);

		return caseAssignment;
	}

	public CaseAssignment removeCaseAssignment(CaseAssignment caseAssignment) {
		getCaseAssignments().remove(caseAssignment);
		caseAssignment.setUserRole(null);

		return caseAssignment;
	}

}