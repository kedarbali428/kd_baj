package com.bfl.bfsd.empportal.rolemanagement;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.bfl.common.util.BFLExceptionUtil;

/**
 * Description of the class
 * This class is the exception handler class for the Applicant Service
 *
 * @author Cognizant - Date - 16/11/2016
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                                       16/11/2016
 *
 */

@Configuration
@ControllerAdvice
@PropertySource("classpath:error.properties")
public class ControllerExceptionHandler extends ResponseEntityExceptionHandler {

	private static final String CLASS_NAME = ControllerExceptionHandler.class.getName();
	
    @Autowired
    Environment env;

    /**
     * @param exception
     * @param request
     * @return ResponseEntity<ResponseBean>
     */
    @ExceptionHandler(value = { BFLTechnicalException.class, BFLBusinessException.class, RuntimeException.class,Exception.class})
	protected ResponseEntity<ResponseBean> handleConflict(Exception ex, WebRequest request) {
		ResponseBean responseBean = BFLExceptionUtil.handle(ex, env);
		if (ex instanceof BFLBusinessException) {

			return new ResponseEntity<>(responseBean, HttpStatus.OK);
		} else if (ex instanceof BFLTechnicalException) {

			return new ResponseEntity<>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			BFLLoggerUtil.error("", CLASS_NAME, BFLLoggerComponent.CONTROLLER,"handleConflict - " + env.getProperty("VWMT_7001"), ex);

			return new ResponseEntity<>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

}