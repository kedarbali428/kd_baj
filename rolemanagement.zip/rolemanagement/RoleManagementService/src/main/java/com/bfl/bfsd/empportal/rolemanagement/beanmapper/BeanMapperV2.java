package com.bfl.bfsd.empportal.rolemanagement.beanmapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bfl.bfsd.empportal.rolemanagement.bean.FieldSetGroupBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.SectionBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.SubSectionalBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.UIFieldBean;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetRolesL3DTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetSubSectionRolesL3DTO;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetAttributeL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetGroupL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetGroupProduct;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetMasterL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetSectionL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetSectionProduct;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetSubsectionL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetSubsectionProduct;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetSubsectionRoleL3;


@Component
public class BeanMapperV2 extends BFLComponent{

	public void prepareResponseForGroupsAndSectionL3(RoleAccessConfigurationBean roleAccessConfigBean,
			List<FieldSetGroupL3> groups) {

		roleAccessConfigBean.setFieldSetGroups(prepareL3Sections2(groups, false,roleAccessConfigBean));
	}

	private List<FieldSetGroupBean> prepareL3Sections2(List<FieldSetGroupL3> groups, boolean shouldAddFieldsSetAttributes,RoleAccessConfigurationBean roleAccessConfigBean) {

		List<FieldSetGroupBean> fieldSetGroups = new ArrayList<>();

		for (FieldSetGroupL3 fieldSetGroup : groups) {
			
			if(fieldSetGroup.getFieldSetGroupProducts().isEmpty()){
			
				setCommon(fieldSetGroup,shouldAddFieldsSetAttributes,fieldSetGroups);
			}
			else if (!fieldSetGroup.getFieldSetGroupProducts().isEmpty()){
			for(FieldSetGroupProduct groupproduct :fieldSetGroup.getFieldSetGroupProducts()){
				boolean goupSubproduct = mapGroupSubproduct( groupproduct,  roleAccessConfigBean);
				if(goupSubproduct){
			List<SectionBean> parentSectionList = new ArrayList<>();

			FieldSetGroupBean fieldSetGroupBean = new FieldSetGroupBean();
			fieldSetGroupBean.setActive(fieldSetGroup.getIsactive().longValue() == 1 ? true : false);
			fieldSetGroupBean.setFieldsetKey(fieldSetGroup.getGroupkey());
			fieldSetGroupBean.setGroupCode(fieldSetGroup.getGroupcd().longValue());
			fieldSetGroupBean.setFieldsetKey(fieldSetGroup.getFieldSetMaster().getFieldsetkey());
			fieldSetGroupBean.setOrderNo(fieldSetGroup.getOrderno().longValue());
			fieldSetGroupBean.setGroupName(fieldSetGroup.getGroupname());
			fieldSetGroupBean.setGroupKey(fieldSetGroup.getGroupkey());

			for (FieldSetSectionL3 fieldSetSection : fieldSetGroup.getFieldSetSections()) {
				if(!fieldSetSection.getFieldSetSectionProducts().isEmpty()){
				for(FieldSetSectionProduct sectionProduct : fieldSetSection.getFieldSetSectionProducts()){
					boolean sectionSubproduct = mapSectionSubproduct( sectionProduct,  roleAccessConfigBean);
					if(sectionSubproduct){
					SectionBean parentSection = new SectionBean();
				parentSection.setSectionId(fieldSetSection.getSectionkey());
				parentSection.setSectionCode(fieldSetSection.getSectioncd().longValue());
				parentSection.setSectionName(fieldSetSection.getSectionname());
				parentSection.setSectionOrder(setSectionOrderNo(fieldSetSection));
					/**	null != fieldSetSection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);*/
				fieldSetGroupBean.getSections().add(parentSection);

				for (FieldSetSubsectionL3 subsection : fieldSetSection.getFieldSetSubsections()) {
					if(!subsection.getFieldSetSubsectionProducts().isEmpty()){
					for(FieldSetSubsectionProduct subsectionProduct : subsection.getFieldSetSubsectionProducts()){
						boolean subsectionSubproduct = mapSubsectionSubproduct( subsectionProduct,  roleAccessConfigBean);
						if(subsectionSubproduct){
						
					SubSectionalBean subSectionBean = new SubSectionalBean();
					subSectionBean.setParentSectionId(fieldSetSection.getSectionkey());
					subSectionBean.setSectionId(subsection.getSubsectionkey());
					subSectionBean.setSectionCode(subsection.getSubsectioncd().longValue());
					subSectionBean.setSectionName(subsection.getSubsectionname());
					subSectionBean.setSectionOrder(setSubsectionOrderNo(subsection,fieldSetSection));
							/**null != subsection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);*/

					addfieldsetL3( shouldAddFieldsSetAttributes, subsection, subSectionBean);
					parentSection.getChildSections().add(subSectionBean);
				}
					}
				}
				}
				Collections.sort(parentSection.getChildSections(),
						(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
				parentSectionList.add(parentSection);
			}
				}
			}
			}
			Collections.sort(fieldSetGroupBean.getSections(),
					(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
			fieldSetGroups.add(fieldSetGroupBean);
		}
			}
		}
		}
		
			Collections.sort(fieldSetGroups, (s1, s2) -> (int) (s1.getOrderNo() - s2.getOrderNo()));
		return fieldSetGroups;
	}
		
	public void addfieldsetL3 (boolean shouldAddFieldsSetAttributes,FieldSetSubsectionL3 subsection,SubSectionalBean subSectionBean){
		if (shouldAddFieldsSetAttributes) {
			for (FieldSetAttributeL3 fieldSetAttribute : subsection.getFieldSetAttributes()) {
				UIFieldBean fieldBean = new UIFieldBean();
				fieldBean.setFieldkey(fieldSetAttribute.getFieldkey());
				fieldBean.setFieldName(fieldSetAttribute.getFieldname());
				/** fieldBean.setSectionId(fieldSetSection.getSectionkey());*/
				fieldBean.setSubSectionId(subsection.getSubsectionkey());
				subSectionBean.getFields().add(fieldBean);
				}
			}
		}
			

	public List<FieldSetGroupBean> prepareGroupsWithSubSectionsL3(FieldSetGroupAndFieldSetRolesL3DTO dto,
			RoleAccessConfigurationBean roleAccessConfigBean,List <FieldSetMasterL3> fieldsetmaster) {
		List <Long> fieldsetkey = new ArrayList<>();
		for(FieldSetMasterL3 setmaster : fieldsetmaster){
			fieldsetkey.add(setmaster.getFieldsetkey());
		}
		
		
		List<FieldSetGroupBean> fieldSetGroups = new ArrayList<>();
		
		for (FieldSetGroupL3 fieldSetGroup : dto.getFieldSetGroups()) {
	
			if (!roleAccessConfigBean.getGroupKeys().contains(fieldSetGroup.getGroupkey()))
				continue;

			List<SectionBean> parentSectionList = new ArrayList<>();

			FieldSetGroupBean fieldSetGroupBeanL3 = new FieldSetGroupBean();
			fieldSetGroupBeanL3.setActive(fieldSetGroup.getIsactive().longValue() == 1 ? true : false);
			fieldSetGroupBeanL3.setGroupCode(fieldSetGroup.getGroupcd().longValue());
			fieldSetGroupBeanL3.setFieldsetKey(fieldSetGroup.getFieldSetMaster().getFieldsetkey());
			fieldSetGroupBeanL3.setOrderNo(fieldSetGroup.getOrderno().longValue());
			fieldSetGroupBeanL3.setGroupName(fieldSetGroup.getGroupname());
			fieldSetGroupBeanL3.setGroupKey(fieldSetGroup.getGroupkey());

			for (FieldSetSectionL3 fieldSetSection : fieldSetGroup.getFieldSetSections()) {

				if (!roleAccessConfigBean.getSectionKeys().contains(fieldSetSection.getSectionkey()))
					continue;

				SectionBean parentSection = new SectionBean();
				parentSection.setSectionId(fieldSetSection.getSectionkey());
				parentSection.setSectionCode(fieldSetSection.getSectioncd().longValue());
				parentSection.setSectionName(fieldSetSection.getSectionname());
				parentSection.setSectionOrder(
						null != fieldSetSection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);
				fieldSetGroupBeanL3.getSections().add(parentSection);
				
				subsectionL3 (dto,roleAccessConfigBean,parentSection,fieldSetSection,fieldsetkey);
				
				Collections.sort(parentSection.getChildSections(),
						(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
				parentSectionList.add(parentSection);
			}
			Collections.sort(fieldSetGroupBeanL3.getSections(),
					(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
			fieldSetGroups.add(fieldSetGroupBeanL3);
		}
		Collections.sort(fieldSetGroups, (s1, s2) -> (int) (s1.getOrderNo() - s2.getOrderNo()));
		return fieldSetGroups;
		/** roleAccessConfigBean.setFieldSetGroups(fieldSetGroups);*/
	}
	public void subsectionL3 (FieldSetGroupAndFieldSetRolesL3DTO dto,RoleAccessConfigurationBean roleAccessConfigBean,
			SectionBean parentSection,FieldSetSectionL3 fieldSetSection, List <Long> fieldsetkey){
		for (FieldSetSubsectionL3 subsection : fieldSetSection.getFieldSetSubsections()) {

			if (!roleAccessConfigBean.getSubSectionKeys().contains(subsection.getSubsectionkey()))
				continue;

			SubSectionalBean subSectionBeanL3 = new SubSectionalBean();
			subSectionBeanL3.setParentSectionId(fieldSetSection.getSectionkey());
			subSectionBeanL3.setSectionId(subsection.getSubsectionkey());
			subSectionBeanL3.setSectionCode(subsection.getSubsectioncd().longValue());
			subSectionBeanL3.setSectionName(subsection.getSubsectionname());
			subSectionBeanL3.setSectionOrder(
					null != subsection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);
		
			for (FieldSetAttributeL3 fieldSetAttribute : subsection.getFieldSetAttributes()) {
			if(fieldsetkey.contains(fieldSetAttribute.getFieldsetkey()) && fieldSetAttribute.getIsactive().equals(BigDecimal.ONE)) {

				UIFieldBean fieldBeanL3 = new UIFieldBean();
				fieldBeanL3.setFieldkey(fieldSetAttribute.getFieldkey());
				fieldBeanL3.setFieldName(fieldSetAttribute.getFieldname());
				/** fieldBean.setSectionId(fieldSetSection.getSectionkey());*/
				fieldBeanL3.setSubSectionId(subsection.getSubsectionkey());
				fieldBeanL3.setDisplayOrder(fieldSetAttribute.getDisplayorder().longValue());
				long inputRoleKey = roleAccessConfigBean.getRoleProdKeys().get(0);
				fieldBeanL3.setAccessLevel(getFieldAccess(dto, fieldSetAttribute, inputRoleKey));

				subSectionBeanL3.getFields().add(fieldBeanL3);
			}
			}
			Collections.sort(subSectionBeanL3.getFields(),
					(f1, f2) -> (int) (f1.getDisplayOrder() - f2.getDisplayOrder()));

			parentSection.getChildSections().add(subSectionBeanL3);
				
	}
	}
	private BigDecimal getFieldAccess(FieldSetGroupAndFieldSetRolesL3DTO dto, FieldSetAttributeL3 fieldSetAttribute,
			long inputRoleKey) {
		for (FieldSetRoleL3 fieldSetRole : dto.getFieldSetRoles()) {
			if(isrolefiledsetL3(fieldSetRole) && isfieldL3(fieldSetRole,fieldSetAttribute,inputRoleKey)){
				
				return fieldSetRole.getFieldaccess();
			}
			
		}
		return null;
	}
	public boolean isrolefiledsetL3(FieldSetRoleL3 fieldSetRole){
		return null != fieldSetRole && null != fieldSetRole.getRoleProductMapping()
				&& null != fieldSetRole.getFieldSetAttribute() && null != fieldSetRole.getFieldSetAttribute().getFieldcd();
	}
	
	public boolean isfieldL3(FieldSetRoleL3 fieldSetRole, FieldSetAttributeL3 fieldSetAttribute,
			long inputRoleKey){
		return fieldSetRole.getRoleProductMapping().getRoleprodkey() == inputRoleKey && fieldSetRole.getFieldSetAttribute()
				.getFieldcd().longValue() == fieldSetAttribute.getFieldcd().longValue();
	}

	public List<FieldSetGroupBean> prepareResponseForGroupsAndSectionForEditCase(
			FieldSetGroupAndFieldSetSubSectionRolesL3DTO dto, long inputRoleKey) {

		return prepareResponseForEditCaseL3(dto, inputRoleKey, true);

	}

	private List<FieldSetGroupBean> prepareResponseForEditCaseL3(FieldSetGroupAndFieldSetSubSectionRolesL3DTO dto,
			long inputRoleKey, boolean shouldAddFieldsSetAttributes) {

		List<FieldSetGroupBean> fieldSetGroups = new ArrayList<>();

		for (FieldSetGroupL3 fieldSetGroup : dto.getFieldSetGroups()) {

			/** List<SectionBean> parentSectionList = new ArrayList<>();*/
			boolean isParentSectionAdded = false;

			FieldSetGroupBean fieldSetGroupBean = new FieldSetGroupBean();
			fieldSetGroupBean.setActive(fieldSetGroup.getIsactive().longValue() == 1 ? true : false);
			fieldSetGroupBean.setFieldsetKey(fieldSetGroup.getGroupkey());
			fieldSetGroupBean.setGroupCode(fieldSetGroup.getGroupcd().longValue());
			fieldSetGroupBean.setFieldsetKey(fieldSetGroup.getFieldSetMaster().getFieldsetkey());
			fieldSetGroupBean.setOrderNo(fieldSetGroup.getOrderno().longValue());
			fieldSetGroupBean.setGroupName(fieldSetGroup.getGroupname());
			fieldSetGroupBean.setGroupKey(fieldSetGroup.getGroupkey());

			for (FieldSetSectionL3 fieldSetSection : fieldSetGroup.getFieldSetSections()) {

				boolean isSubSectionAdded = false;

				SectionBean parentSection = new SectionBean();
				parentSection.setSectionId(fieldSetSection.getSectionkey());
				parentSection.setSectionCode(fieldSetSection.getSectioncd().longValue());
				parentSection.setSectionName(fieldSetSection.getSectionname());
				parentSection.setSectionOrder(setSectionOrderNo(fieldSetSection));
						

				/** fieldSetGroupBean.getSections().add(parentSection);*/

				for (FieldSetSubsectionL3 subsection : fieldSetSection.getFieldSetSubsections()) {

					SubSectionalBean subSectionBean = new SubSectionalBean();
					subSectionBean.setParentSectionId(fieldSetSection.getSectionkey());
					subSectionBean.setSectionId(subsection.getSubsectionkey());
					subSectionBean.setSectionCode(subsection.getSubsectioncd().longValue());
					subSectionBean.setSectionName(subsection.getSubsectionname());
					subSectionBean.setSectionOrder(setSubsectionOrderNo(subsection,fieldSetSection));
							
					if (isRolesHaveAccessforSubSectionL3(inputRoleKey, subsection.getSubsectionkey(),
							dto.getFieldSetSubsectionRoles()) ) {

						parentSection.getChildSections().add(subSectionBean);
						isSubSectionAdded = true;
						addfieldL3 ( shouldAddFieldsSetAttributes, dto, subsection, subSectionBean, inputRoleKey);
			
					}
				}
				isParentSectionAdded = setparentsection(isSubSectionAdded, fieldSetGroupBean, parentSection, isParentSectionAdded);

			

				Collections.sort(parentSection.getChildSections(),
						(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
			}

			if (isParentSectionAdded) {
				fieldSetGroups.add(fieldSetGroupBean);
			}

			Collections.sort(fieldSetGroupBean.getSections(),
					(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
			/** fieldSetGroups.add(fieldSetGroupBean);*/
		}
		Collections.sort(fieldSetGroups, (s1, s2) -> (int) (s1.getOrderNo() - s2.getOrderNo()));
		return fieldSetGroups;
	}
	public void addfieldL3 (boolean shouldAddFieldsSetAttributes,FieldSetGroupAndFieldSetSubSectionRolesL3DTO dto,FieldSetSubsectionL3 subsection,SubSectionalBean subSectionBean,long inputRoleKey){
		if (shouldAddFieldsSetAttributes) {
		for (FieldSetAttributeL3 fieldSetAttribute : subsection.getFieldSetAttributes()) {
			UIFieldBean fieldBean = new UIFieldBean();
			fieldBean.setFieldkey(fieldSetAttribute.getFieldkey());
			fieldBean.setFieldName(fieldSetAttribute.getFieldname());
			/** fieldBean.setSectionId(fieldSetSection.getSectionkey());*/
			fieldBean.setSubSectionId(subsection.getSubsectionkey());
			subSectionBean.getFields().add(fieldBean);
			
			fieldBean.setAccessLevel(getFieldAccessL3(dto.getFieldSetRoles(), fieldSetAttribute, inputRoleKey));
		}
		}}

	private boolean isRolesHaveAccessforSubSectionL3(long roleKey, long subSectionKey,
			List<FieldSetSubsectionRoleL3> fieldSetSubsectionRoles) {

		boolean hasAccess = false;
		for (FieldSetSubsectionRoleL3 subsectionRole : fieldSetSubsectionRoles) {
			if (subSectionKey == subsectionRole.getFieldSetSubsection().getSubsectionkey()
					&& subsectionRole.getRoleProductMapping().getRoleprodkey()== roleKey) {
				hasAccess = true;
				break;
			}
		}
		return hasAccess;
	}
	
	private BigDecimal getFieldAccessL3(List<FieldSetRoleL3> fieldSetRoles, FieldSetAttributeL3 fieldSetAttribute,
			long inputRoleKey) {

		for (FieldSetRoleL3 fieldSetRole : fieldSetRoles) {
			if (isroleandattributeL3(fieldSetRole)

					&& isfieldsetL3(fieldSetRole,inputRoleKey,fieldSetAttribute)) {
				return fieldSetRole.getFieldaccess();}
		}
		return null;
	}
public boolean isfieldsetL3(FieldSetRoleL3 fieldSetRole ,long inputRoleKey,FieldSetAttributeL3 fieldSetAttribute){
	return fieldSetRole.getRoleProductMapping().getRoleprodkey() == inputRoleKey && fieldSetRole.getFieldSetAttribute()
			.getFieldcd().longValue() == fieldSetAttribute.getFieldcd().longValue() ;
	}
public boolean isroleandattributeL3(FieldSetRoleL3 fieldSetRole){
	return null != fieldSetRole && null != fieldSetRole.getRoleProductMapping()
			&& null != fieldSetRole.getFieldSetAttribute()
			&& null != fieldSetRole.getFieldSetAttribute().getFieldcd();

}
private boolean setparentsection(boolean isSubSectionAdded,FieldSetGroupBean fieldSetGroupBean,SectionBean parentSection,boolean isParentSectionAdd){
	if (isSubSectionAdded) {
		fieldSetGroupBean.getSections().add(parentSection);
		/** isSubSectionAdded = false;*/
		isParentSectionAdd = true;
	}
 return isParentSectionAdd;
}
private long setSubsectionOrderNo(FieldSetSubsectionL3 subsection ,FieldSetSectionL3 fieldSetSection){
	if(null != subsection.getOrderno()){
		return fieldSetSection.getOrderno().longValue();
	}
	else {
		return 0;
	}
	/**null != subsection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);
	*/
}
private long setSectionOrderNo(FieldSetSectionL3 fieldSetSection){
	if(null != fieldSetSection.getOrderno()){
		/** null != fieldSetSection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);*/
		return fieldSetSection.getOrderno().longValue();
	}
	else {
		return 0;
	}
}
public boolean mapGroupSubproduct(FieldSetGroupProduct groupproduct, RoleAccessConfigurationBean roleAccessConfigBean){
	boolean setproduct=false;
	if((groupproduct.getProdmastkey().equals(BigDecimal.valueOf(roleAccessConfigBean.getProductTypeKey())))&& 
		 (groupproduct.getSubprodkey().equals(BigDecimal.valueOf(roleAccessConfigBean.getSubprodkey().get(0))))){
		setproduct =true;
	}
	return setproduct;
}

public boolean mapSectionSubproduct(FieldSetSectionProduct sectionProduct, RoleAccessConfigurationBean roleAccessConfigBean){
	boolean setproduct=false;
	if((sectionProduct.getProdmastkey().equals(BigDecimal.valueOf(roleAccessConfigBean.getProductTypeKey())))&& 
			 (sectionProduct.getSubprodkey().equals(BigDecimal.valueOf(roleAccessConfigBean.getSubprodkey().get(0))))){
		setproduct =true;
	}
	return setproduct;
}

public boolean mapSubsectionSubproduct(FieldSetSubsectionProduct subsectionProduct, RoleAccessConfigurationBean roleAccessConfigBean){
	boolean setproduct=false;
	if((subsectionProduct.getProdmastkey().equals(BigDecimal.valueOf(roleAccessConfigBean.getProductTypeKey()))) && 
			 (subsectionProduct.getSubprodkey().equals(BigDecimal.valueOf(roleAccessConfigBean.getSubprodkey().get(0))))){
		setproduct =true;
	}
	return setproduct;
}


public void setCommon(FieldSetGroupL3 fieldSetGroup, boolean shouldAddFieldsSetAttributes,List<FieldSetGroupBean> fieldSetGroups){
	
			List<SectionBean> parentSectionList1 = new ArrayList<>();

		FieldSetGroupBean fieldSetGroupBean1 = new FieldSetGroupBean();
		fieldSetGroupBean1.setActive(fieldSetGroup.getIsactive().longValue() == 1 ? true : false);
		fieldSetGroupBean1.setFieldsetKey(fieldSetGroup.getGroupkey());
		fieldSetGroupBean1.setGroupCode(fieldSetGroup.getGroupcd().longValue());
		fieldSetGroupBean1.setFieldsetKey(fieldSetGroup.getFieldSetMaster().getFieldsetkey());
		fieldSetGroupBean1.setOrderNo(fieldSetGroup.getOrderno().longValue());
		fieldSetGroupBean1.setGroupName(fieldSetGroup.getGroupname());
		fieldSetGroupBean1.setGroupKey(fieldSetGroup.getGroupkey());

		for (FieldSetSectionL3 fieldSetSection1 : fieldSetGroup.getFieldSetSections()) {
				SectionBean parentSection1 = new SectionBean();
			parentSection1.setSectionId(fieldSetSection1.getSectionkey());
			parentSection1.setSectionCode(fieldSetSection1.getSectioncd().longValue());
			parentSection1.setSectionName(fieldSetSection1.getSectionname());
			parentSection1.setSectionOrder(
					null != fieldSetSection1.getOrderno() ? fieldSetSection1.getOrderno().longValue() : 0);
			fieldSetGroupBean1.getSections().add(parentSection1);

			for (FieldSetSubsectionL3 subsection : fieldSetSection1.getFieldSetSubsections()) {
				SubSectionalBean subSectionBean1 = new SubSectionalBean();
				subSectionBean1.setParentSectionId(fieldSetSection1.getSectionkey());
				subSectionBean1.setSectionId(subsection.getSubsectionkey());
				subSectionBean1.setSectionCode(subsection.getSubsectioncd().longValue());
				subSectionBean1.setSectionName(subsection.getSubsectionname());
				subSectionBean1.setSectionOrder(
						null != subsection.getOrderno() ? fieldSetSection1.getOrderno().longValue() : 0);

				addfieldsetL3( shouldAddFieldsSetAttributes, subsection, subSectionBean1);
				parentSection1.getChildSections().add(subSectionBean1);
			}

			Collections.sort(parentSection1.getChildSections(),
					(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
			parentSectionList1.add(parentSection1);
		}
		Collections.sort(fieldSetGroupBean1.getSections(),
				(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
		fieldSetGroups.add(fieldSetGroupBean1);
	
}
}