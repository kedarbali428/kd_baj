package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the FIELD_SET_SUBSECTION_ROLE database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_SUBSECTION_ROLE")
@NamedQueries({
	//@NamedQuery(name="FieldSetSubsectionRoleL3.findAll", query="SELECT f FROM FieldSetSubsectionRoleL3 f"),
	@NamedQuery(name="FieldSetSubsectionRoleL3.DeactivateFieldSetRoles",query="UPDATE FieldSetSubsectionRoleL3 f set f.isactive = 0 "
		+ " WHERE f.isactive = 1 AND f.fieldSetSubsection.subsectionkey IN :subsectionkeys and f.roleProductMapping.roleprodkey IN :rolekeys"),
	@NamedQuery(name="FieldSetSubsectionRoleL3.DeactivateAllSubSectionRoles",query="UPDATE FieldSetSubsectionRoleL3 f set f.isactive = 0 "
			+ " WHERE f.isactive = 1 AND f.roleProductMapping.roleprodkey IN :rolekeys"),
	@NamedQuery(name="FieldSetSubsectionRoleL3.DeleteAllSubSectionRoles",query="Delete from FieldSetSubsectionRoleL3 f where f.roleProductMapping.roleprodkey in"
			+ " (select r.roleprodkey from RoleProductMapping r,FieldSetSubsectionRoleL3 f where r.roleprodkey=f.roleProductMapping.roleprodkey"
			+ " and f.isactive=1 and f.roleProductMapping.roleprodkey = :rolekeys)"),
	@NamedQuery(name="FieldSetSubsectionRoleL3.FetchAllByRole",query="SELECT f FROM FieldSetSubsectionRoleL3 f inner join f.fieldSetSubsection as fssb left outer join"
			+ " fssb.fieldSetSubsectionProducts "
			+ " WHERE f.isactive = 1 and f.roleProductMapping.roleprodkey IN :rolekeys")
	
	
})public class FieldSetSubsectionRoleL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long sectionrolekey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

//	private BigDecimal rolekey;

	private String selectclause;

	//bi-directional many-to-one association to FieldSetSubsection
	@ManyToOne
	@JoinColumn(name="SUBSECTIONKEY")
	private FieldSetSubsectionL3 fieldSetSubsection;
	
	//bi-directional many-to-one association to FieldSetSubsection
	@ManyToOne
	@JoinColumn(name="ROLEKEY",referencedColumnName="ROLEPRODKEY")
	private RoleProductMapping roleProductMapping;

	public FieldSetSubsectionRoleL3() {
	}

	public long getSectionrolekey() {
		return this.sectionrolekey;
	}

	public void setSectionrolekey(long sectionrolekey) {
		this.sectionrolekey = sectionrolekey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

//	public BigDecimal getRolekey() {
//		return this.rolekey;
//	}
//
//	public void setRolekey(BigDecimal rolekey) {
//		this.rolekey = rolekey;
//	}

	public String getSelectclause() {
		return this.selectclause;
	}

	public void setSelectclause(String selectclause) {
		this.selectclause = selectclause;
	}

	public FieldSetSubsectionL3 getFieldSetSubsection() {
		return this.fieldSetSubsection;
	}

	public void setFieldSetSubsection(FieldSetSubsectionL3 fieldSetSubsection) {
		this.fieldSetSubsection = fieldSetSubsection;
	}
	public RoleProductMapping getRoleProductMapping() {
		return this.roleProductMapping;
	}

	public void setRoleProductMapping(RoleProductMapping roleProductMapping) {
		this.roleProductMapping = roleProductMapping;
	}

}