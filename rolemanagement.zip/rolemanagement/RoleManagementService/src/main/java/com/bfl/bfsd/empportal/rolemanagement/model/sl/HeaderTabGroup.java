package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the HEADER_TAB_GROUPS database table.
 * 
 */
@Entity
@Table(name="HEADER_TAB_GROUPS")
//@NamedQuery(name="HeaderTabGroup.findAll", query="SELECT h FROM HeaderTabGroup h")
public class HeaderTabGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long tabgroupkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to FieldSetGroup
	@ManyToOne
	@JoinColumn(name="GROUPKEY")
	private FieldSetGroupL3 fieldSetGroup;

	//bi-directional many-to-one association to HeaderTabMaster
	@ManyToOne
	@JoinColumn(name="TABKEY")
	private HeaderTabMasterL3 headerTabMaster;

	public HeaderTabGroup() {
	}

	public long getTabgroupkey() {
		return this.tabgroupkey;
	}

	public void setTabgroupkey(long tabgroupkey) {
		this.tabgroupkey = tabgroupkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public FieldSetGroupL3 getFieldSetGroup() {
		return this.fieldSetGroup;
	}

	public void setFieldSetGroup(FieldSetGroupL3 fieldSetGroup) {
		this.fieldSetGroup = fieldSetGroup;
	}

	public HeaderTabMasterL3 getHeaderTabMaster() {
		return this.headerTabMaster;
	}

	public void setHeaderTabMaster(HeaderTabMasterL3 headerTabMaster) {
		this.headerTabMaster = headerTabMaster;
	}

}