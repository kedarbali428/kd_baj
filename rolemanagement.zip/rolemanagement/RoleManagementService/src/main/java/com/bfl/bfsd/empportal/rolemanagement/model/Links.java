package com.bfl.bfsd.empportal.rolemanagement.model;

public class Links {

	private Long tabKey;
	private long[] linkIds;

	public Long getTabKey() {
		return tabKey;
	}

	public void setTabKey(Long tabKey) {
		this.tabKey = tabKey;
	}

	public long[] getLinkIds() {
		return linkIds;
	}

	public void setLinkIds(long[] linkIds) {
		this.linkIds = linkIds;
	}

}
