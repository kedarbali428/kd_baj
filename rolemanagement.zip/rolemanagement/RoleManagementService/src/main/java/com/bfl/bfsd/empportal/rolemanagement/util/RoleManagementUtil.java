package com.bfl.bfsd.empportal.rolemanagement.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;

/**
 * @Description This class contains utility methods 
 * 
 */
public class RoleManagementUtil {
	

	private static final String CLASS_NAME = RoleManagementUtil.class.getCanonicalName();
			
	/**
	 * @Desc This method is used to get current Timestamp
	 * @return Date
	 */
	public static Timestamp getCurrentDateTimeStamp() {
		Date date=Calendar.getInstance().getTime();
		return new Timestamp(date.getTime());
	}
	
	/**
	 * @Desc This method is used to get exception trace
	 * @return string
	 */
	public static String getExceptionTrace(Exception ex, String correlationId) {
		try {
			StringWriter strbufLog = new StringWriter();
			ex.printStackTrace(new PrintWriter(strbufLog));
			return  strbufLog.toString();
		} catch(Exception e) {
			BFLLoggerUtil.error(correlationId, CLASS_NAME, BFLLoggerComponent.SERVICE,"Error in creating Exception Trace"+getExceptionTrace(e, null));
		}
		return "";
	}
private RoleManagementUtil() {
		
	};
}
