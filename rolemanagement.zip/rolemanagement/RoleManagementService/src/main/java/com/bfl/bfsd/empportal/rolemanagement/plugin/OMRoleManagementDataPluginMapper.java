package com.bfl.bfsd.empportal.rolemanagement.plugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.bajaj.bfdl.om.impl.EpBauClientImpl;
import com.bajaj.bfdl.om.insurance.impl.EpBauInsuranceClientImpl;
import com.bajaj.bfdl.om.offer.impl.EpOfferDomainClientImpl;
import com.bfl.bfsd.empportal.rolemanagement.bean.FieldSetGroupBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleTabKeyAndNameResponse;
import com.bfl.bfsd.empportal.rolemanagement.bean.Section;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabBean;
import com.bfl.bfsd.empportal.rolemanagement.model.LinkSectionBean;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfsd.om.bean.UserMgmtTabBean;
import com.google.gson.Gson;

@Component
public class OMRoleManagementDataPluginMapper {

	@Autowired
	private EpBauClientImpl bauClientImpl;
	
	@Autowired
	private EpBauInsuranceClientImpl bauInsClientImpl;
	
	@Autowired
	private EpOfferDomainClientImpl offerClientImpl;

	public List<TabBean> getTabBeanList(Long prodMastKey, Long productKey,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<UserMgmtTabBean> beanList= bauClientImpl.getUserMgmtTabs(String.valueOf(prodMastKey), String.valueOf(productKey),roleKeyListStr, headers);
		List<TabBean> tabBeanList = new ArrayList<TabBean>();
		beanList.forEach(bean ->{
			TabBean tabBean= new TabBean();
			tabBean.setTabCode(bean.getTabCode());
			tabBean.setTabKey(bean.getTabKey());
			tabBean.setTabName(bean.getTabName());
			tabBean.setSelected(bean.isSelected());
			tabBeanList.add(tabBean);
		});
		return tabBeanList;
	}

	public List<FieldSetGroupBean> getGroupsDataList(Long prodMastKey, Long productKey, List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException {
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<Object> objectList= bauClientImpl.getUserMgmtTabGroups(String.valueOf(prodMastKey), String.valueOf(productKey), String.valueOf(tabKeys.get(0)),roleKeyListStr, headers);
		List<FieldSetGroupBean> beanList = (List<FieldSetGroupBean>)(List<?>) objectList;
		return beanList;
	}

	public List<Section> getCTADataList(Long prodMastKey, Long productKey, List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
		List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String tabKeyListStr = String.join(",", tabKeyList);
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<Object> objectList= bauClientImpl.getUserMgmtGroupsCTA(String.valueOf(prodMastKey), String.valueOf(productKey), tabKeyListStr, roleKeyListStr, headers);
		List<Section> beanList = (List<Section>)(List<?>) objectList;
		return beanList;
	}
	
public List<FieldSetGroupBean> getFieldsDataList(Long prodMastKey, Long productKey, List<Long> tabKeys,List<Long> roleKeys, List<Long> groupKeys, List<Long> sectionKeys, List<Long> subSectionKeys, HttpHeaders headers) throws BFLBusinessException{
		List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String tabKeyListStr = String.join(",", tabKeyList);
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<String> groupKeyList = groupKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String groupKeyListStr = String.join(",", groupKeyList);
		List<String> sectionKeyList = sectionKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String sectionKeyListStr = String.join(",", sectionKeyList);
		List<String> subSectionKeyList = subSectionKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String subSectionKeyListStr = String.join(",", subSectionKeyList);
		List<Object> objectList= bauClientImpl.getUserMgmtGroupsFields(String.valueOf(prodMastKey), String.valueOf(productKey), tabKeyListStr, roleKeyListStr, groupKeyListStr, sectionKeyListStr, subSectionKeyListStr, headers, null);
		List<FieldSetGroupBean> beanList = (List<FieldSetGroupBean>)(List<?>) objectList;
		return beanList;
	}

public List<LinkSectionBean> getLinksDataList(List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
	List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String tabKeyListStr = String.join(",", tabKeyList);
	List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String roleKeyListStr = String.join(",", roleKeyList);
	List<Object> objectList= bauClientImpl.getUserMgmtTabLinks(tabKeyListStr, roleKeyListStr, headers);
	List<LinkSectionBean> beanList = (List<LinkSectionBean>)(List<?>) objectList;
	return beanList;
}


	public boolean updatedRoleAccessDetails(RoleAccessConfigurationInputBean roleAccessBean, HttpHeaders headers) throws BFLBusinessException {
		Gson gson = new Gson();
		String roleaccessBeanString = gson.toJson(roleAccessBean);
		boolean successFlag = bauClientImpl.updateRoleAccess(roleaccessBeanString, headers);
		return successFlag;
	}
	
	
	public List<RoleTabKeyAndNameResponse> getTabsBasedOnRole(String roleKey,  HttpHeaders headers) throws BFLBusinessException{
		
		List<Object> objectList= bauClientImpl.fetchTabsBasedOnRole(roleKey, headers);
		Gson gson = new Gson();
		String arrayToJson = gson.toJson(objectList);
		RoleTabKeyAndNameResponse[] beanList = gson.fromJson(arrayToJson,RoleTabKeyAndNameResponse[].class);
		return Arrays.asList(beanList);
	}
	
	public List<FieldSetGroupBean> getGroupDataEditList(Long prodMastKey, Long productKey, List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
		List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String tabKeyListStr = String.join(",", tabKeyList);
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<Object> objectList= bauClientImpl.getUserMgmtGroupsFields(String.valueOf(prodMastKey), String.valueOf(productKey), tabKeyListStr, roleKeyListStr, null, null, null, headers, "1");
		List<FieldSetGroupBean> beanList = (List<FieldSetGroupBean>)(List<?>) objectList;
		return beanList;
	}
	
	public List<TabBean> getOmInsuranceTabBeanList(Long prodMastKey, Long productKey,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<UserMgmtTabBean> beanList= bauClientImpl.getUserMgmtTabs(String.valueOf(prodMastKey), String.valueOf(productKey),roleKeyListStr, headers);
		List<TabBean> tabBeanList = new ArrayList<TabBean>();
		beanList.forEach(bean ->{
			TabBean tabBean= new TabBean();
			tabBean.setTabCode(bean.getTabCode());
			tabBean.setTabKey(bean.getTabKey());
			tabBean.setTabName(bean.getTabName());
			tabBean.setSelected(bean.isSelected());
			tabBeanList.add(tabBean);
		});
		return tabBeanList;
	}
	
	public List<TabBean> getTabBeanListOmIns(Long prodMastKey, Long productKey,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<UserMgmtTabBean> beanList= bauInsClientImpl.getUserMgmtTabsOmIns(String.valueOf(prodMastKey), String.valueOf(productKey),roleKeyListStr, headers);
		List<TabBean> tabBeanList = new ArrayList<TabBean>();
		beanList.forEach(bean ->{
			TabBean tabBean= new TabBean();
			tabBean.setTabCode(bean.getTabCode());
			tabBean.setTabKey(bean.getTabKey());
			tabBean.setTabName(bean.getTabName());
			tabBean.setSelected(bean.isSelected());
			tabBeanList.add(tabBean);
		});
		return tabBeanList;
	}

	public List<FieldSetGroupBean> getGroupsDataListOmIns(Long prodMastKey, Long productKey, List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException {
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<Object> objectList= bauInsClientImpl.getUserMgmtTabGroupsOmIns(String.valueOf(prodMastKey), String.valueOf(productKey), String.valueOf(tabKeys.get(0)),roleKeyListStr, headers);
		List<FieldSetGroupBean> beanList = (List<FieldSetGroupBean>)(List<?>) objectList;
		return beanList;
	}

	public List<Section> getCTADataListOmIns(Long prodMastKey, Long productKey, List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
		List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String tabKeyListStr = String.join(",", tabKeyList);
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<Object> objectList= bauInsClientImpl.getUserMgmtGroupsCTAOmIns(String.valueOf(prodMastKey), String.valueOf(productKey), tabKeyListStr, roleKeyListStr, headers);
		List<Section> beanList = (List<Section>)(List<?>) objectList;
		return beanList;
	}
	
public List<FieldSetGroupBean> getFieldsDataListOmIns(Long prodMastKey, Long productKey, List<Long> tabKeys,List<Long> roleKeys, List<Long> groupKeys, List<Long> sectionKeys, List<Long> subSectionKeys, HttpHeaders headers) throws BFLBusinessException{
		List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String tabKeyListStr = String.join(",", tabKeyList);
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<String> groupKeyList = groupKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String groupKeyListStr = String.join(",", groupKeyList);
		List<String> sectionKeyList = sectionKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String sectionKeyListStr = String.join(",", sectionKeyList);
		List<String> subSectionKeyList = subSectionKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String subSectionKeyListStr = String.join(",", subSectionKeyList);
		List<Object> objectList= bauInsClientImpl.getUserMgmtGroupsFieldsOmIns(String.valueOf(prodMastKey), String.valueOf(productKey), tabKeyListStr, roleKeyListStr, groupKeyListStr, sectionKeyListStr, subSectionKeyListStr, headers, null);
		List<FieldSetGroupBean> beanList = (List<FieldSetGroupBean>)(List<?>) objectList;
		return beanList;
	}

public List<LinkSectionBean> getLinksDataListOmIns(List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
	List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String tabKeyListStr = String.join(",", tabKeyList);
	List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String roleKeyListStr = String.join(",", roleKeyList);
	List<Object> objectList= bauInsClientImpl.getUserMgmtTabLinksOmIns(tabKeyListStr, roleKeyListStr, headers);
	List<LinkSectionBean> beanList = (List<LinkSectionBean>)(List<?>) objectList;
	return beanList;
}


	public boolean updatedRoleAccessDetailsOmIns(RoleAccessConfigurationInputBean roleAccessBean, HttpHeaders headers) throws BFLBusinessException {
		Gson gson = new Gson();
		String roleaccessBeanString = gson.toJson(roleAccessBean);
		boolean successFlag = bauInsClientImpl.updateRoleAccessOmIns(roleaccessBeanString, headers);
		return successFlag;
	}
	
	
	public List<RoleTabKeyAndNameResponse> getTabsBasedOnRoleOmIns(String roleKey,  HttpHeaders headers) throws BFLBusinessException{		
		List<Object> objectList= bauInsClientImpl.fetchTabsBasedOnRoleOmIns(roleKey, headers);
		Gson gson = new Gson();
		String arrayToJson = gson.toJson(objectList);
		RoleTabKeyAndNameResponse[] beanList = gson.fromJson(arrayToJson,RoleTabKeyAndNameResponse[].class);
		return Arrays.asList(beanList);
	}
	
	public List<FieldSetGroupBean> getGroupDataEditListOmIns(Long prodMastKey, Long productKey, List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
		List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String tabKeyListStr = String.join(",", tabKeyList);
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<Object> objectList= bauInsClientImpl.getUserMgmtGroupsFieldsOmIns(String.valueOf(prodMastKey), String.valueOf(productKey), tabKeyListStr, roleKeyListStr, null, null, null, headers, "1");
		List<FieldSetGroupBean> beanList = (List<FieldSetGroupBean>)(List<?>) objectList;
		return beanList;
	}
	
	public List<TabBean> getOmInsuranceTabBeanListOmIns(Long prodMastKey, Long productKey,List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
		String roleKeyListStr = String.join(",", roleKeyList);
		List<UserMgmtTabBean> beanList= bauInsClientImpl.getUserMgmtTabsOmIns(String.valueOf(prodMastKey), String.valueOf(productKey),roleKeyListStr, headers);
		List<TabBean> tabBeanList = new ArrayList<TabBean>();
		beanList.forEach(bean ->{
			TabBean tabBean= new TabBean();
			tabBean.setTabCode(bean.getTabCode());
			tabBean.setTabKey(bean.getTabKey());
			tabBean.setTabName(bean.getTabName());
			tabBean.setSelected(bean.isSelected());
			tabBeanList.add(tabBean);
		});
		return tabBeanList;
	}
	
public List<RoleTabKeyAndNameResponse> getTabsBasedOnRolePoc(String roleKey,  HttpHeaders headers) throws BFLBusinessException{
		
		List<Object> objectList= bauInsClientImpl.fetchTabsBasedOnRoleOmPoc(roleKey, headers);
		Gson gson = new Gson();
		String arrayToJson = gson.toJson(objectList);
		RoleTabKeyAndNameResponse[] beanList = gson.fromJson(arrayToJson,RoleTabKeyAndNameResponse[].class);
		return Arrays.asList(beanList);
	}
     
//	public List<TabBean> getTabBeanListOmOffer(List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException {
//		List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
//		String roleKeyListStr = String.join(",", roleKeyList);
//		List<UserMgmtTabBean> beanList = bauInsClientImpl.getUserMgmtTabsOmOffer(roleKeyListStr, headers);
//		List<TabBean> tabBeanList = new ArrayList<TabBean>();
//		beanList.forEach(bean -> {
//			TabBean tabBean = new TabBean();
//			tabBean.setTabCode(bean.getTabCode());
//			tabBean.setTabKey(bean.getTabKey());
//			tabBean.setTabName(bean.getTabName());
//			tabBean.setSelected(bean.isSelected());
//			tabBeanList.add(tabBean);
//		});
//		return tabBeanList;
//	}

public List<FieldSetGroupBean> getGroupsDataListOmOffer(Long prodMastKey, Long productKey, List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers, String prodCatCode, String editFlag) throws BFLBusinessException {
	List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String roleKeyListStr = String.join(",", roleKeyList);
	List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String tabKeyListStr = String.join(",", tabKeyList);
	List<Object> objectList= offerClientImpl.getUserMgmtTabGroups(String.valueOf(prodMastKey), String.valueOf(productKey), tabKeyListStr,roleKeyListStr, headers, prodCatCode,editFlag);
	List<FieldSetGroupBean> beanList = (List<FieldSetGroupBean>)(List<?>) objectList;
	return beanList;
}

public List<Section> getOfferCTADataList(Long prodMastKey, Long productKey, List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers, String prodCatCode, String editFlag) throws BFLBusinessException{
	List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String tabKeyListStr = String.join(",", tabKeyList);
	List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String roleKeyListStr = String.join(",", roleKeyList);
	List<Object> objectList= offerClientImpl.getUserMgmtGroupsCTA(String.valueOf(prodMastKey), String.valueOf(productKey), tabKeyListStr, roleKeyListStr, headers,prodCatCode,editFlag);
	List<Section> beanList = (List<Section>)(List<?>) objectList;
	return beanList;
}

public List<LinkSectionBean> getOfferLinksDataList(List<Long> tabKeys,List<Long> roleKeys, HttpHeaders headers, String editFlag) throws BFLBusinessException{
	List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String tabKeyListStr = String.join(",", tabKeyList);
	List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String roleKeyListStr = String.join(",", roleKeyList);
	List<Object> objectList= offerClientImpl.getUserMgmtTabLinks(tabKeyListStr, roleKeyListStr, headers,editFlag);
	List<LinkSectionBean> beanList = (List<LinkSectionBean>)(List<?>) objectList;
	return beanList;
}

public List<TabBean> getTabBeanListOmOffer(List<Long> roleKeys, HttpHeaders headers) throws BFLBusinessException{
	List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String roleKeyListStr = String.join(",", roleKeyList);
	List<UserMgmtTabBean> beanList= offerClientImpl.getUserMgmtTabs(roleKeyListStr, headers);
	List<TabBean> tabBeanList = new ArrayList<TabBean>();
	beanList.forEach(bean ->{
		TabBean tabBean= new TabBean();
		tabBean.setTabCode(bean.getTabCode());
		tabBean.setTabKey(bean.getTabKey());
		tabBean.setTabName(bean.getTabName());
		tabBean.setSelected(bean.isSelected());
		tabBeanList.add(tabBean);
	});
	return tabBeanList;
}

public List<FieldSetGroupBean> getFieldsDataListForOmOffer(Long prodMastKey, Long productKey, List<Long> tabKeys,
		List<Long> roleKeys, List<Long> groupKeys, List<Long> sectionKeys, List<Long> subSectionKeys,
		String prodCatCode, HttpHeaders headers) {
	List<String> tabKeyList = tabKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String tabKeyListStr = String.join(",", tabKeyList);
	List<String> roleKeyList = roleKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String roleKeyListStr = String.join(",", roleKeyList);
	List<String> groupKeyList = groupKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String groupKeyListStr = String.join(",", groupKeyList);
	List<String> sectionKeyList = sectionKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String sectionKeyListStr = String.join(",", sectionKeyList);
	List<String> subSectionKeyList = subSectionKeys.stream().map(String::valueOf).collect(Collectors.toList());
	String subSectionKeyListStr = String.join(",", subSectionKeyList);
	List<Object> objectList= offerClientImpl.getUserMgmtGroupsFieldsForOmOffer(String.valueOf(prodMastKey), String.valueOf(productKey), tabKeyListStr, roleKeyListStr, groupKeyListStr, sectionKeyListStr, subSectionKeyListStr,prodCatCode, headers, null);
	List<FieldSetGroupBean> beanList = (List<FieldSetGroupBean>)(List<?>) objectList;
	return beanList;
}

public List<RoleTabKeyAndNameResponse> getTabsBasedOnRoleOffer(String roleKey,  HttpHeaders headers) throws Exception{
	
	List<Object> objectList= offerClientImpl.fetchTabsBasedOnRoleOmOffer(roleKey, headers);
	Gson gson = new Gson();
	String arrayToJson = gson.toJson(objectList);
	RoleTabKeyAndNameResponse[] beanList = gson.fromJson(arrayToJson,RoleTabKeyAndNameResponse[].class);
	return Arrays.asList(beanList);
}


}
