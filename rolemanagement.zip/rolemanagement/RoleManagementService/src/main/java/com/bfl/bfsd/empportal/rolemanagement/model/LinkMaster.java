package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the LINK_MASTER database table.
 * 
 */
@Entity
@Table(name="LINK_MASTER")
public class LinkMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long linkkey;

	private BigDecimal isactive;

	private BigDecimal linkcode;

	private String linkdesc;

	private String lstupdatedby;

	private Timestamp lstupdtaeddt;

	//bi-directional many-to-one association to HeaderTabLink
	@OneToMany(mappedBy="linkMaster")
	private List<HeaderTabLinks> headerTabLinks;

	public LinkMaster() {
	}

	public long getLinkkey() {
		return this.linkkey;
	}

	public void setLinkkey(long linkkey) {
		this.linkkey = linkkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public BigDecimal getLinkcode() {
		return this.linkcode;
	}

	public void setLinkcode(BigDecimal linkcode) {
		this.linkcode = linkcode;
	}

	public String getLinkdesc() {
		return this.linkdesc;
	}

	public void setLinkdesc(String linkdesc) {
		this.linkdesc = linkdesc;
	}

	public String getLstupdatedby() {
		return this.lstupdatedby;
	}

	public void setLstupdatedby(String lstupdatedby) {
		this.lstupdatedby = lstupdatedby;
	}

	public Timestamp getLstupdtaeddt() {
		return this.lstupdtaeddt;
	}

	public void setLstupdtaeddt(Timestamp lstupdtaeddt) {
		this.lstupdtaeddt = lstupdtaeddt;
	}

	public List<HeaderTabLinks> getHeaderTabLinks() {
		return this.headerTabLinks;
	}

	public void setHeaderTabLinks(List<HeaderTabLinks> headerTabLinks) {
		this.headerTabLinks = headerTabLinks;
	}

	public HeaderTabLinks addHeaderTabLink(HeaderTabLinks headerTabLink) {
		getHeaderTabLinks().add(headerTabLink);
		headerTabLink.setLinkMaster(this);

		return headerTabLink;
	}

	public HeaderTabLinks removeHeaderTabLink(HeaderTabLinks headerTabLink) {
		getHeaderTabLinks().remove(headerTabLink);
		headerTabLink.setLinkMaster(null);

		return headerTabLink;
	}

}