package com.bfl.bfsd.empportal.rolemanagement.bean;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Min;

import com.bfl.bfsd.empportal.rolemanagement.model.Links;

public class RoleAccessConfigurationInputBean {
	
	@Min(value=1,message="Please provide valid productkey.")
	private long productkey;
	private long subprodkey;
	private long[] rolekeys;
	@Min(value=1,message="Please provide valid function key.")
	private long functionkey;
	
	private long[] tabIds;
	private long[] ctaIds;

	private List<Links> linkBeanList;

	@Valid
	private java.util.List<FieldAccessBean> fieldAccessBeans;
	
	private List<Long> subSectionKeys;
	private List<Long> roleKeys;

	
	public List<Long> getSubSectionKeys() {
		return subSectionKeys;
	}

	public void setSubSectionKeys(List<Long> subSectionKeys) {
		this.subSectionKeys = subSectionKeys;
	}

	public List<Long> getRoleKeys() {
		return roleKeys;
	}

	public void setRoleKeys(List<Long> roleKeys) {
		this.roleKeys = roleKeys;
	}

	public long getProductkey() {
		return productkey;
	}

	public void setProductkey(long productkey) {
		this.productkey = productkey;
	}
	
	public long[] getRolekeys() {
		return rolekeys;
	}

	public void setRolekeys(long[] rolekeys) {
		this.rolekeys = rolekeys;
	}

	public long getFunctionkey() {
		return functionkey;
	}

	public void setFunctionkey(long functionkey) {
		this.functionkey = functionkey;
	}

	public long[] getTabIds() {
		return tabIds;
	}

	public void setTabIds(long[] tabIds) {
		this.tabIds = tabIds;
	}

	public long[] getCtaIds() {
		return ctaIds;
	}

	public void setCtaIds(long[] ctaIds) {
		this.ctaIds = ctaIds;
	}

	public java.util.List<FieldAccessBean> getFieldAccessBeans() {
		return fieldAccessBeans;
	}

	public void setFieldAccessBeans(java.util.List<FieldAccessBean> fieldAccessBeans) {
		this.fieldAccessBeans = fieldAccessBeans;
	}

	@Override
	public String toString() {
		return "RoleAccessConfigurationInputBean [productkey=" + productkey + ", subprodkey=" + subprodkey
				+ ", rolekeys=" + Arrays.toString(rolekeys) + ", functionkey=" + functionkey + ", tabIds="
				+ Arrays.toString(tabIds) + ", ctaIds=" + Arrays.toString(ctaIds) + ", linkIds=" + linkBeanList
				+ ", fieldAccessBeans=" + fieldAccessBeans + ", subSectionKeys=" + subSectionKeys + ", roleKeys="
				+ roleKeys + "]";
	}

	/**
	 * @return the subprodkey
	 */
	public long getSubprodkey() {
		return subprodkey;
	}

	/**
	 * @param subprodkey the subprodkey to set
	 */
	public void setSubprodkey(long subprodkey) {
		this.subprodkey = subprodkey;
	}

	/**
	 * @return the linkBeanList
	 */
	public List<Links> getLinkBeanList() {
		return linkBeanList;
	}

	/**
	 * @param linkBeanList the linkBeanList to set
	 */
	public void setLinkBeanList(List<Links> linkBeanList) {
		this.linkBeanList = linkBeanList;
	}

	

}
