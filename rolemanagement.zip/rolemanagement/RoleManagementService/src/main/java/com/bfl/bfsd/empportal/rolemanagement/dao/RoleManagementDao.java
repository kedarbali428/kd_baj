package com.bfl.bfsd.empportal.rolemanagement.dao;

import java.util.List;

import com.bfl.bfsd.empportal.rolemanagement.bean.AssignedRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleBasedUsersListResponceBean;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetGroup;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetRole;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsection;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsectionRole;
import com.bfl.bfsd.empportal.rolemanagement.model.UserRole;

/**
 * Description of the class This class is the dao implementation class for the
 * Role Management DAO
 *
 * @author Cognizant - Date - 27/02/2017
 * 
 *         Version BugId UsrId Date Description 1.0 27/02/2017
 *
 */
public interface RoleManagementDao {

	RoleAccessConfigurationBean getTabDetails( List<Long> roleKey);

/**	RoleAccessConfigurationBean getCTADetails(List<Long> roleKey, List<Long> listOfTabKeys);*/

	public boolean saveConfigurations(RoleAccessConfigurationInputBean inputBean);

	RoleBasedUsersListResponceBean usersListOnRoleBased(Long roleKey, Long applicationkey);

/**	RoleAccessConfigurationBean getUIFields(List<Long> roleKeyList, List<Long> listOfTabKeys);*/

	void cloneRoleAccessConfiguration(CloneRoleAccessConfigureBean cloneRoleAccessConfigBean);

	List<FieldSetGroup> fetchGroupsSectionAndSubSections(RoleAccessConfigurationBean inputBean);

	List<FieldSetSubsection> fetchFieldsforGroupsSectinoAndsubSection(RoleAccessConfigurationBean roleAccessConfigBean);
	
	List<FieldSetSubsectionRole> fetchSubSectionRoleByRole(List<Long> roels);

	List<FieldSetGroup> fetchFieldsDetailsforGroupsSectinoAndsubSection(
			RoleAccessConfigurationBean roleAccessConfigBean);

	List<FieldSetRole> fetchFieldsSetRolesByRoleKeys(List<Long> roleKeys);
	
	public Boolean checkRoleInUsersAssignedRolesHierarchy(AssignedRoleBean assignedRoleBean);
	
	public UserRole getUserRole(long userKey, long userRoleKey);

	public boolean checkEmailCTAAccess(long applicationKey);

	RoleAccessConfigurationBean getCTADetails(RoleAccessConfigurationBean inputbean);

	RoleAccessConfigurationBean getLinkAcess(RoleAccessConfigurationBean roleAccConfigBean);

	public String getProdMastCode(Long prodMastKey);

	

}