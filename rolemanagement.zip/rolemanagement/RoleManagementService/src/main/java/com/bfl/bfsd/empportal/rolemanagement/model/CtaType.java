package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the CTA_TYPES database table.
 * 
 */
@Entity
@Table(name="CTA_TYPES")
//@NamedQuery(name="CtaType.findAll", query="SELECT c FROM CtaType c")
public class CtaType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long ctakey;

	private String ctaactivity;

	private BigDecimal ctacode;

	private String ctadescription;

	private BigDecimal ctalocation;

	private String ctaname;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to CtaProduct
	@OneToMany(mappedBy="ctaType")
	private List<CtaProduct> ctaProducts;

	//bi-directional many-to-one association to CtaSection
	@OneToMany(mappedBy="ctaType")
	private List<CtaSection> ctaSections;

	//bi-directional many-to-one association to CtaSetMaster
	@ManyToOne
	@JoinColumn(name="CTASETKEY")
	private CtaSetMaster ctaSetMaster;

	//bi-directional many-to-one association to HeaderTabCta
	@OneToMany(mappedBy="ctaType")
	private List<HeaderTabCta> headerTabCtas;

	public CtaType() {
	}

	public long getCtakey() {
		return this.ctakey;
	}

	public void setCtakey(long ctakey) {
		this.ctakey = ctakey;
	}

	public String getCtaactivity() {
		return this.ctaactivity;
	}

	public void setCtaactivity(String ctaactivity) {
		this.ctaactivity = ctaactivity;
	}

	public BigDecimal getCtacode() {
		return this.ctacode;
	}

	public void setCtacode(BigDecimal ctacode) {
		this.ctacode = ctacode;
	}

	public String getCtadescription() {
		return this.ctadescription;
	}

	public void setCtadescription(String ctadescription) {
		this.ctadescription = ctadescription;
	}

	public BigDecimal getCtalocation() {
		return this.ctalocation;
	}

	public void setCtalocation(BigDecimal ctalocation) {
		this.ctalocation = ctalocation;
	}

	public String getCtaname() {
		return this.ctaname;
	}

	public void setCtaname(String ctaname) {
		this.ctaname = ctaname;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public List<CtaProduct> getCtaProducts() {
		return this.ctaProducts;
	}

	public void setCtaProducts(List<CtaProduct> ctaProducts) {
		this.ctaProducts = ctaProducts;
	}

	public CtaProduct addCtaProduct(CtaProduct ctaProduct) {
		getCtaProducts().add(ctaProduct);
		ctaProduct.setCtaType(this);

		return ctaProduct;
	}

	public CtaProduct removeCtaProduct(CtaProduct ctaProduct) {
		getCtaProducts().remove(ctaProduct);
		ctaProduct.setCtaType(null);

		return ctaProduct;
	}

	public List<CtaSection> getCtaSections() {
		return this.ctaSections;
	}

	public void setCtaSections(List<CtaSection> ctaSections) {
		this.ctaSections = ctaSections;
	}

	public CtaSection addCtaSection(CtaSection ctaSection) {
		getCtaSections().add(ctaSection);
		ctaSection.setCtaType(this);

		return ctaSection;
	}

	public CtaSection removeCtaSection(CtaSection ctaSection) {
		getCtaSections().remove(ctaSection);
		ctaSection.setCtaType(null);

		return ctaSection;
	}

	public CtaSetMaster getCtaSetMaster() {
		return this.ctaSetMaster;
	}

	public void setCtaSetMaster(CtaSetMaster ctaSetMaster) {
		this.ctaSetMaster = ctaSetMaster;
	}

	public List<HeaderTabCta> getHeaderTabCtas() {
		return this.headerTabCtas;
	}

	public void setHeaderTabCtas(List<HeaderTabCta> headerTabCtas) {
		this.headerTabCtas = headerTabCtas;
	}

	public HeaderTabCta addHeaderTabCta(HeaderTabCta headerTabCta) {
		getHeaderTabCtas().add(headerTabCta);
		headerTabCta.setCtaType(this);

		return headerTabCta;
	}

	public HeaderTabCta removeHeaderTabCta(HeaderTabCta headerTabCta) {
		getHeaderTabCtas().remove(headerTabCta);
		headerTabCta.setCtaType(null);

		return headerTabCta;
	}

}