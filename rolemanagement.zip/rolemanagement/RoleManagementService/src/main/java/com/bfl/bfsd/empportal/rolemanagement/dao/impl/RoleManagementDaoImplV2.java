package com.bfl.bfsd.empportal.rolemanagement.dao.impl;

import static com.bajaj.bfsd.common.BFLLoggerComponent.DAO;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_ERR_MSG1;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG1;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG10;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG13;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG14;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG2;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG3;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG4;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG5;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG6;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG7;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG8;
import static com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementMessageConstants.DAO_MSG9;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.cache.service.UserCacheService;
import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.FieldAccessBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleTabKeyAndNameResponse;
import com.bfl.bfsd.empportal.rolemanagement.bean.SubProductBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabResponse;
import com.bfl.bfsd.empportal.rolemanagement.bean.UserRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementConstants;
import com.bfl.bfsd.empportal.rolemanagement.dao.RoleManagementDaoV2;
import com.bfl.bfsd.empportal.rolemanagement.model.BfsdRoleMaster;
import com.bfl.bfsd.empportal.rolemanagement.model.CtaProduct;
import com.bfl.bfsd.empportal.rolemanagement.model.HeaderTabLinkRoleMap;
import com.bfl.bfsd.empportal.rolemanagement.model.HeaderTabLinks;
import com.bfl.bfsd.empportal.rolemanagement.model.Links;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.CtaRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetAttributeL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetGroupL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetMasterL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetSubsectionL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetSubsectionRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.HeaderTabMasterL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.HeaderTabRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.RoleProductMapping;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@SuppressWarnings("unchecked")
@PropertySource("classpath:application.properties")
@Component
public class RoleManagementDaoImplV2 extends BFLComponent implements RoleManagementDaoV2 {

	@Autowired
	EntityManager entityManager;

	@Autowired
	Environment env;

	@Autowired
	EntityManagerFactory entityManagerFactory;

	/**
	 * @Inject
	 * @RequestScoped
	 */
	@Autowired
	BFLLoggerUtil logger;

	private static final String CLASS_NAME = RoleManagementDaoImplV2.class.getCanonicalName();
	
	
	@Autowired
	UserCacheService userCacheService;

	@Override
	@Transactional
	public RoleAccessConfigurationBean getTabDetailsBasedonL3(List<Long> roleKey, long subprodkey, long prodkey) {
		BigDecimal pkey = BigDecimal.valueOf(prodkey);
		List<BigDecimal> rolek = new ArrayList<>();
		for (long key : roleKey) {
			rolek.add(BigDecimal.valueOf(key));
		}
		List<Long> roleprodkey = entityManager
				.createQuery(
						"Select roleprodkey from RoleProductMapping where rolekey in :rolekey and prodmastkey=:prodkey and subprodmastkey in :subprodkey")
				.setParameter(RoleManagementConstants.ROLEKEY, rolek)
				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(subprodkey))
				.setParameter(RoleManagementConstants.PRODKEY, pkey).getResultList();

		if (roleprodkey.isEmpty()) {
			for (BigDecimal rolekey : rolek) {
				try {

					RoleProductMapping role = new RoleProductMapping();
					role.setIsactive(BigDecimal.ZERO);
					role.setRolekey(rolekey);
					role.setProdmastkey(pkey);
					role.setLstupdateby("1");
					role.setSubprodmastkey(BigDecimal.valueOf(subprodkey));
					role.setLstupdatedt(Timestamp.from(Instant.now()));
					entityManager.persist(role);
					logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Done with saving Roleproductmapping.");
				} catch (Exception exception) {
					logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Error in saving Roleproductmapping into database",
							exception);
					throw new BFLBusinessException(RoleManagementConstants.ERROR_7018, env.getProperty(RoleManagementConstants.ERROR_7018));
				}
			}
		}
	
		RoleAccessConfigurationBean roleAccessConfigBean = new RoleAccessConfigurationBean();

		List<HeaderTabMasterL3> headertab = entityManager.createNamedQuery("HeaderTabProduct.findAllBySubprodkey")
				.setParameter(RoleManagementConstants.PRODKEY, pkey)
				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(subprodkey))
				.getResultList();

		List<Long> assignedTabBeanList = getAssignedTabBasedonL3(roleprodkey);

		List<TabBean> tabBeanList = new ArrayList<>();
		for (HeaderTabMasterL3 headTadMaster : headertab) {
			TabBean tab = new TabBean();
			tab.setTabKey(headTadMaster.getTabkey());

			tab.setTabName(headTadMaster.getTabname());
			tab.setTabCode(headTadMaster.getTabcd().longValue());
			if (assignedTabBeanList.contains(headTadMaster.getTabkey()))
				tab.setSelected(true);
			tabBeanList.add(tab);
		}
		roleAccessConfigBean.setTabBeanList(tabBeanList);
		return roleAccessConfigBean;
	}

	private List<Long> getAssignedTabBasedonL3(List<Long> roleprod) {

		if (roleprod.isEmpty()) {
			roleprod.add((long) 0);
		}

		List<HeaderTabRoleL3> headertabrole = entityManager
				.createNamedQuery("HeaderTabRoleL3.findAllActiveWithUserAndRoleBasedonL3")
				.setParameter(RoleManagementConstants.ROLEKEY, roleprod).getResultList();

		List<Long> tabBeanKeyList = new ArrayList<>();
		for (HeaderTabRoleL3 headTadRole : headertabrole) {

			tabBeanKeyList.add(headTadRole.getHeaderTabMaster().getTabkey());
		}
		return tabBeanKeyList;
	}

	@Override
	public List<FieldSetRoleL3> fetchFieldsSetRolesByRoleKeysBasedonL3(List<Long> roleKeys, long prodkey,
			long subprodkey) {
		return entityManager.createNamedQuery("FieldSetRoleL3.findAllActiveForRoleKeys")
				.setParameter(RoleManagementConstants.ROLEKEYS, roleKeys)
				.getResultList();

	}

	@Override
	public List<FieldSetSubsectionRoleL3> fetchSubSectionRoleByRoleBasedonL3(List<Long> roleKeys, long prodkey,
			long subprodkey) {		
		return entityManager.createNamedQuery("FieldSetSubsectionRoleL3.FetchAllByRole")
				.setParameter(RoleManagementConstants.ROLEKEYS, roleKeys).getResultList();
	}

	@Override
	public List<FieldSetGroupL3> fetchGroupsSectionAndSubSectionsBasedonL3(RoleAccessConfigurationBean inputBean) {
		List<FieldSetGroupL3> fieldsetgroup ;
		
		 BigDecimal productkey = BigDecimal.valueOf(inputBean.getProductTypeKey());
		 BigDecimal subprodkey = BigDecimal.valueOf(inputBean.getSubprodkey().get(0));

			fieldsetgroup = entityManager
						.createNamedQuery("FieldSetGroupL3.findAllGroupsSectionsAndSubSectionBasedOnRoleKeyAndTabKey")
						.setParameter(RoleManagementConstants.ROLEKEYS, inputBean.getRoleProdKeys())
						.setParameter(RoleManagementConstants.PRODKEY, productkey)
						.setParameter(RoleManagementConstants.SUBPRODKEY, subprodkey)
						.setParameter(RoleManagementConstants.TABKEYS, inputBean.getTabKeys()).getResultList();
			return fieldsetgroup;
		}
		
	@Override
	public List<FieldSetGroupL3> fetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3(
			RoleAccessConfigurationBean inputBean) {
		
		List<FieldSetGroupL3> fieldsetgroups;
				
		fieldsetgroups = entityManager.createNamedQuery("FieldSetGroupL3.findAllSubSectionBasedOnSubSectionKeys")
				.setParameter(RoleManagementConstants.ROLEKEYS, inputBean.getRoleProdKeys())
				.setParameter(RoleManagementConstants.TABKEYS, inputBean.getTabKeys())
				.setParameter(RoleManagementConstants.PRODKEY, BigDecimal.valueOf(inputBean.getProductTypeKey()))
				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(inputBean.getSubprodkey().get(0)))
				.setParameter("sectionkeys", inputBean.getSectionKeys())
				.setParameter("groupkeys", inputBean.getGroupKeys())
				.setParameter("subsectionkeys", inputBean.getSubSectionKeys()).getResultList();
			
			return fieldsetgroups;
		}

	@Override
	@Transactional
	public boolean saveConfigurationsBasedonL3(RoleAccessConfigurationInputBean inputBean) {

		logger.debug(CLASS_NAME, DAO, DAO_MSG1 + inputBean);
		boolean successFlag = false;
		EntityManager em = entityManagerFactory.createEntityManager();

		try {

			em.getTransaction().begin();
			for (int i = 0; i < inputBean.getRolekeys().length; i++) {
				long roleKey = inputBean.getRolekeys()[i];
				List<RoleProductMapping> roleProductMap = entityManager
						.createNamedQuery("RoleProductMapping.findAllRoleMapping")
						.setParameter(RoleManagementConstants.ROLEKEY, BigDecimal.valueOf(roleKey))
						.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(inputBean.getSubprodkey()))
						.setParameter(RoleManagementConstants.PRODKEY, BigDecimal.valueOf(inputBean.getProductkey()))
						.getResultList();

				RoleProductMapping roleProductMapping = roleProductMap.get(0);

				logger.debug(CLASS_NAME, DAO, "Start saving role access configuration for Role Key :" + roleKey);
				hardDeleteRoleAccessConfigurationsIfAnyBasedonL3(inputBean, em, roleProductMapping.getRoleprodkey());
				saveAllSubsectionFieldsBasedonL3(em, inputBean, roleProductMapping);
				saveCtaRolesBasedonL3(inputBean, em, roleProductMapping);
				saveFieldSetRolesBasedonL3(inputBean, em, roleProductMapping);
				saveFieldSetSubSectionRolesBasedomL3(inputBean, em, roleProductMapping);
				saveHeaderTabRolesBasedonL3(inputBean, em, roleProductMapping);
				activeRoleProductMap(roleProductMapping,em);
				saveLinkRoles(inputBean, em,roleKey);
			}

			em.getTransaction().commit();
			successFlag = true;

		} catch (Exception e) {
			/** successFlag = false; */
			logger.error(CLASS_NAME, DAO, DAO_ERR_MSG1,e);
			em.getTransaction().rollback();
			throw new BFLTechnicalException("ROLEMGT_7016", e);
		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG2);
		return successFlag;
	}


	@Transactional
	private void saveLinkRoles(RoleAccessConfigurationInputBean inputBean, EntityManager em, long roleKey) {
		List<Long> tabKeys = Arrays.stream(inputBean.getTabIds()).boxed().collect(Collectors.toList());
		int count = entityManager.createNamedQuery("deleteLinksByTabKeyAndRoleKey").setParameter(RoleManagementConstants.TABKEYS, tabKeys)
				.setParameter(RoleManagementConstants.ROLEKEY, new BigDecimal(roleKey)).executeUpdate();
		logger.debug(CLASS_NAME, DAO, "delete count:" + count);

		if (null != inputBean.getLinkBeanList() && !inputBean.getLinkBeanList().isEmpty()) {

			for (Links link : inputBean.getLinkBeanList()) {
				
				List<Long> linksValues =  Arrays.stream(link.getLinkIds()).boxed().collect(Collectors.toList());

				List<HeaderTabLinks> headerTabLinksList = entityManager
						.createNamedQuery("HeaderTabLinks.findAllByTabkeyAndLinkkey")
						.setParameter(RoleManagementConstants.TABKEYS, link.getTabKey())
						.setParameter(RoleManagementConstants.LINKKEYS, linksValues)
						.getResultList();

				if (headerTabLinksList != null && !headerTabLinksList.isEmpty()) {
					for (HeaderTabLinks headerTabLinks : headerTabLinksList) {
						HeaderTabLinkRoleMap headerTabLinkRoleMap = new HeaderTabLinkRoleMap();
						headerTabLinkRoleMap.setHeaderTabLink(headerTabLinks);
						headerTabLinkRoleMap.setRolekey(new BigDecimal(roleKey));
						headerTabLinkRoleMap.setIsactive(new BigDecimal(1));
						headerTabLinkRoleMap.setLstupdtaeddt(Timestamp.from(Instant.now()));
						entityManager.persist(headerTabLinkRoleMap);
					}
				}

			}

		}
	}
	private void hardDeleteRoleAccessConfigurationsIfAnyBasedonL3(RoleAccessConfigurationInputBean inputBean,
			EntityManager manager, Long roleKey) {

		logger.debug(CLASS_NAME, DAO, DAO_MSG10 + inputBean);
		List<Long> ctaIds = new ArrayList<>();
		for (Long ctaId : inputBean.getCtaIds()) {
			ctaIds.add(ctaId);
		}
		logger.debug(CLASS_NAME, DAO, "CTA Ids :" + ctaIds);
		List<CtaProduct> ctaProducts = manager
				.createNamedQuery("CtaProduct.findAlldByCtaIdAndProductMasterKeyandSubprodkey")
				.setParameter("productMasterKey", new BigDecimal(inputBean.getProductkey()))
				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(inputBean.getSubprodkey())).setParameter("ctaKeys", ctaIds) // inputBean.getCtaIds()
				.getResultList();

		List<Long> ctaProductKeys = ctaProducts.stream().map(CtaProduct::getCtaprodkey).collect(Collectors.toList());
		if (!ctaProductKeys.isEmpty()) {
			int ctaRoles = manager.createNamedQuery("CtaRoleL3.DeleteCtaRoles")
					/** .setParameter("ctaprodkeys", ctaProductKeys) */
					.setParameter(RoleManagementConstants.ROLEKEY, roleKey) // inputBean.getRolekey()
					.setParameter("productmasterkey", BigDecimal.valueOf(inputBean.getProductkey()))
					.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(inputBean.getSubprodkey())).executeUpdate();
			logger.debug(CLASS_NAME, DAO, DAO_MSG9 + ctaRoles + "Deleted CtaRole Records for Product Key :"
					+ ctaProductKeys + " for ROLEKEY :" + roleKey);
		} else {
			logger.debug(CLASS_NAME, DAO, "No CtaRole Records for found for soft delete with Product Key , no ctaProduct mapping found :"
					+ ctaProductKeys + " for Role Key :" + roleKey);
		}

		int headerTabRoles = manager.createNamedQuery("HeaderTabRoleL3.DeleteHeaderTabRolesBasedonL3")
				.setParameter(RoleManagementConstants.ROLEKEY, roleKey) // inputBean.getRolekey()
				.executeUpdate();

		logger.debug(CLASS_NAME, DAO,
				DAO_MSG9 + headerTabRoles + "Deleted HeaderTabRole Records for Role Key :" + roleKey);

		int fieldSetRoles = manager.createNamedQuery("FieldSetRoleL3.DeleteFieldSetRoles")
				.setParameter(RoleManagementConstants.ROLEKEY, roleKey) // inputBean.getRolekey()
				.executeUpdate();
		logger.debug(CLASS_NAME, DAO,
				DAO_MSG9 + fieldSetRoles + " Deleted FieldSetRole Records for Role Key :" + roleKey);

		int fieldSetSubsectionRoles = manager.createNamedQuery("FieldSetSubsectionRoleL3.DeleteAllSubSectionRoles")
				.setParameter(RoleManagementConstants.ROLEKEYS, roleKey) // inputBean.getRoleKeys()
				.executeUpdate();
		logger.debug(CLASS_NAME, DAO, DAO_MSG9 + fieldSetSubsectionRoles
				+ " Deleted FieldSetSubsectionRole Records with Role Key :" + roleKey);

	}

	private void saveAllSubsectionFieldsBasedonL3(EntityManager em, RoleAccessConfigurationInputBean inputBean,
			RoleProductMapping roleProductMapping) {
		logger.debug(CLASS_NAME, DAO, "");

		List<FieldSetSubsectionL3> fieldsubsection = (List<FieldSetSubsectionL3>) entityManager
				.createNamedQuery("FieldSetSubsectionL3.findAllBasedonProdAndSubProdkey")
				.setParameter(RoleManagementConstants.PRODKEY, BigDecimal.valueOf(inputBean.getProductkey()))
				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(inputBean.getSubprodkey())).getResultList();
		/** List <FieldSetSubsection> fieldsub = new ArrayList<>(); */

		for (FieldSetSubsectionL3 field : fieldsubsection) {
			FieldSetSubsectionRoleL3 fieldsubsect = new FieldSetSubsectionRoleL3();
			fieldsubsect.setFieldSetSubsection(field);
			fieldsubsect.setRoleProductMapping(roleProductMapping);
			fieldsubsect.setIsactive(BigDecimal.ZERO);
			fieldsubsect.setLstupdatedt(Timestamp.from(Instant.now()));
			fieldsubsect.setSelectclause("What to store??");
			fieldsubsect.setLstupdateby("1");
			FieldSetSubsectionRoleL3 fieldsubsect2 = em.merge(fieldsubsect);
			em.persist(fieldsubsect2);
		}
	}

	private void saveCtaRolesBasedonL3(RoleAccessConfigurationInputBean inputBean, EntityManager em,
			RoleProductMapping roleProductMapping) {

		long productMasterKey = inputBean.getProductkey();
		long subprodkey = inputBean.getSubprodkey();

		logger.debug(CLASS_NAME, DAO, DAO_MSG7 + inputBean.getCtaIds());
		for (long ctaId : inputBean.getCtaIds()) {

			CtaRoleL3 ctaRole = new CtaRoleL3();
			ctaRole.setCtaProduct(getCtaProductfor(ctaId, productMasterKey, subprodkey));
			ctaRole.setRoleProductMapping(roleProductMapping);
			ctaRole.setIsactive(new BigDecimal(1));
			ctaRole.setLstupdatedt(Timestamp.from(Instant.now()));
			ctaRole.setLstupdateby("Check What to Pass");
			CtaRoleL3 ctaRole2 = em.merge(ctaRole);
			em.persist(ctaRole2);
		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG8);
	}

	private CtaProduct getCtaProductfor(long ctaId, long productMasterKey, long subprodkey) {

		logger.debug(CLASS_NAME, DAO,
				"Fetch CTA Product for CTA ID :" + ctaId + " and Product Master Key :" + productMasterKey);
		CtaProduct ctaProduct = null;
		List<CtaProduct> ctaProducts = null;
		try {
			ctaProducts = (List<CtaProduct>) entityManager
					.createNamedQuery("CtaProduct.findAlldByCtaIdAndProductMasterKeyandSubprodkey")
					.setParameter("productMasterKey", new BigDecimal(productMasterKey)).setParameter("ctaKeys", ctaId)
					.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(subprodkey)).getResultList();
			if (null != ctaProducts && !ctaProducts.isEmpty()) {
				ctaProduct = ctaProducts.get(0);
			}
		} catch (BFLTechnicalException e) {
			logger.error(CLASS_NAME, DAO, "Error occured while fetching CTA Product for CTA ID :" + ctaId
					+ " and Product Master Key :" + productMasterKey);
			throw new BFLTechnicalException("ROLEMGT_7017", e);
		}
		logger.debug(CLASS_NAME, DAO, "Fetch CTA Product :" + ctaProduct);
		return ctaProduct;
	}

	private void saveFieldSetRolesBasedonL3(RoleAccessConfigurationInputBean inputBean, EntityManager em,
			RoleProductMapping roleProductMapping) {

		logger.debug(CLASS_NAME, DAO, DAO_MSG5 + inputBean.getFieldAccessBeans());

		for (FieldAccessBean fieldAccessBean : inputBean.getFieldAccessBeans()) {

			FieldSetRoleL3 fieldSetRole = new FieldSetRoleL3();
			fieldSetRole.setFieldaccess(new BigDecimal(fieldAccessBean.getFieldAccesskey()));
			fieldSetRole.setRoleProductMapping(roleProductMapping);
			fieldSetRole.setIsactive(new BigDecimal(1));
			FieldSetAttributeL3 fieldSetAttribute = new FieldSetAttributeL3();
			fieldSetAttribute.setFieldkey(fieldAccessBean.getFieldkey());
			fieldSetRole.setFieldSetAttribute(fieldSetAttribute);
			fieldSetRole.setLstupdatedt(Timestamp.from(Instant.now()));
			FieldSetRoleL3 fieldSetRole2 = em.merge(fieldSetRole);
			em.persist(fieldSetRole2);
		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG6);
	}

	private void saveFieldSetSubSectionRolesBasedomL3(RoleAccessConfigurationInputBean inputBean, EntityManager em,
			RoleProductMapping roleProductMapping) {

		logger.debug(CLASS_NAME, DAO, DAO_MSG13);

		for (Long subSectionKey : inputBean.getSubSectionKeys()) {

			FieldSetSubsectionRoleL3 fieldSetSubsectionRole = new FieldSetSubsectionRoleL3();

			FieldSetSubsectionL3 fieldSetSubsection = new FieldSetSubsectionL3();
			fieldSetSubsection.setSubsectionkey(subSectionKey);

			fieldSetSubsectionRole.setFieldSetSubsection(fieldSetSubsection);
			fieldSetSubsectionRole.setRoleProductMapping(roleProductMapping);
			fieldSetSubsectionRole.setIsactive(new BigDecimal(1));
			fieldSetSubsectionRole.setLstupdatedt(Timestamp.from(Instant.now()));
			fieldSetSubsectionRole.setSelectclause("What to store??");
			em.merge(fieldSetSubsectionRole);
		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG14);
	}

	private void saveHeaderTabRolesBasedonL3(RoleAccessConfigurationInputBean inputBean, EntityManager em,
			RoleProductMapping roleProductMapping) {

		logger.debug(CLASS_NAME, DAO, DAO_MSG3 + inputBean.getTabIds());

		for (long tabId : inputBean.getTabIds()) {
			HeaderTabMasterL3 headerTabMaster = new HeaderTabMasterL3();
			headerTabMaster.setTabkey(tabId); // header tab master key

			HeaderTabRoleL3 headerTabRole = new HeaderTabRoleL3();
			headerTabRole.setHeaderTabMaster(headerTabMaster);
			headerTabRole.setRoleProductMapping(roleProductMapping);
			headerTabRole.setIsactive(new BigDecimal(1));
			headerTabRole.setLstupdatedt(Timestamp.from(Instant.now()));
			HeaderTabRoleL3 headerTabRole2 = em.merge(headerTabRole);
			em.persist(headerTabRole2);

		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG4);
	}

	/** <---------------------------clone-------------------------------------------> */
	@Transactional
	@Override
	public void cloneRoleAccessConfigurationBasedonL3(CloneRoleAccessConfigureBean cloneRoleAccessConfigBean) {

		logger.debug(CLASS_NAME, DAO, "Cloning begins for the role");
		/** boolean successFlag = false; */
		EntityManager em = entityManagerFactory.createEntityManager();

		List<Long> roleTo = cloneRoleAccessConfigBean.getRoleKeysTo();
		List<Long> roleFrom = cloneRoleAccessConfigBean.getRoleKeyFrom();
		List<BigDecimal> roleKeysTo = roleTo.stream().map(BigDecimal::new).collect(Collectors.toList());
		List<BigDecimal> roleKeysFrom = roleFrom.stream().map(BigDecimal::new).collect(Collectors.toList());

		List<BigDecimal> roleprodTo = entityManager
				.createNativeQuery("Select roleprodkey from Role_product_Mapping where rolekey in :rolekey"
						+ " and prodmastkey=:prodkey and subprodmastkey= :subprodkey and isactive=1")
				.setParameter(RoleManagementConstants.ROLEKEY, roleKeysTo)
				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(cloneRoleAccessConfigBean.getSubprodkeyTo()))
				.setParameter(RoleManagementConstants.PRODKEY, new BigDecimal(cloneRoleAccessConfigBean.getProductkeyTo())).getResultList();
		
		if (roleprodTo.isEmpty()) {
			for (BigDecimal rolekey : roleKeysTo) {
				try {
					RoleProductMapping rolemap = new RoleProductMapping(); 
					rolemap.setIsactive(BigDecimal.ONE);
					rolemap.setRolekey(rolekey);
					rolemap.setProdmastkey(BigDecimal.valueOf(cloneRoleAccessConfigBean.getProductkeyTo()));
					rolemap.setLstupdateby("1");
					rolemap.setSubprodmastkey(BigDecimal.valueOf(cloneRoleAccessConfigBean.getSubprodkeyTo()));
					rolemap.setLstupdatedt(Timestamp.from(Instant.now()));
					entityManager.persist(rolemap);
					logger.debug(CLASS_NAME, BFLLoggerComponent.DAO, "Done with saving Roleproductmapping.");
				} catch (Exception exception) {
					logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Error in saving Roleproductmapping into database",
							exception);
					throw new BFLBusinessException(RoleManagementConstants.ERROR_7018, env.getProperty(RoleManagementConstants.ERROR_7018));
				}
			}
		}
		List<BigDecimal> roleprodFrom = new ArrayList<>();
		
		try{
			roleprodFrom = entityManager.createNativeQuery("Select roleprodkey from Role_product_Mapping where rolekey in :rolekey"
						+ " and prodmastkey=:prodkey and subprodmastkey= :subprodkey and isactive=1")
				.setParameter(RoleManagementConstants.ROLEKEY, roleKeysFrom)
				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(cloneRoleAccessConfigBean.getSubprodkeyTo()))
				.setParameter(RoleManagementConstants.PRODKEY, new BigDecimal(cloneRoleAccessConfigBean.getProductkeyTo())).getResultList();
		}
		catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "NO role access configured for"+roleKeysFrom ,
					exception);
			throw exception;}
		List <Long> roleCloneFrom = new ArrayList<>();
		List <Long> roleCloneTo = new ArrayList<>();
		for(BigDecimal role : roleprodTo){
			roleCloneTo.add(role.longValue());
		}
		for(BigDecimal role : roleprodFrom){
			roleCloneFrom.add(role.longValue());
		}
		try {

			em.getTransaction().begin();

			deleteRoleAccessConfigurationsinClone(roleCloneTo, em, cloneRoleAccessConfigBean);
			cloneCtaRoles(roleCloneFrom, roleCloneTo, em);
			cloneFieldSetRoles(roleCloneFrom, roleCloneTo, em);
			cloneHeaderTabRoles(roleCloneFrom, roleCloneTo, em);
			cloneFieldSetSubSectionRoles(roleCloneFrom, roleCloneTo, em);
			/**activeRoleProductMap(rolemap,em);*/

			em.getTransaction().commit();
			/** successFlag = true; */

		} catch (Exception e) {
			/** successFlag = false; */
			em.getTransaction().rollback();
			logger.error(CLASS_NAME, DAO, DAO_ERR_MSG1);
			throw new BFLTechnicalException("ROLEMGT_7016", e);
		}
		logger.debug(CLASS_NAME, DAO, DAO_MSG2);

	}

	private void cloneFieldSetSubSectionRoles(List<Long> roleKeysFrom, List<Long> roleKeysTo, EntityManager em) {

		List<FieldSetSubsectionRoleL3> fieldSetSubsectionRoles = em
				.createNamedQuery("FieldSetSubsectionRoleL3.FetchAllByRole")
				.setParameter(RoleManagementConstants.ROLEKEYS, roleKeysFrom)
				.getResultList();

		for (Long role : roleKeysTo) {
			for (FieldSetSubsectionRoleL3 oldSubsectionRole : fieldSetSubsectionRoles) {
				RoleProductMapping roleproductmapping = new RoleProductMapping();
				roleproductmapping.setRoleprodkey(role);
				FieldSetSubsectionRoleL3 newSubsectionRole = new FieldSetSubsectionRoleL3();
				newSubsectionRole.setSelectclause(oldSubsectionRole.getSelectclause());
				newSubsectionRole.setFieldSetSubsection(oldSubsectionRole.getFieldSetSubsection());
				newSubsectionRole.setIsactive(new BigDecimal(1));
				newSubsectionRole.setRoleProductMapping(roleproductmapping);
				newSubsectionRole.setLstupdatedt(Timestamp.from(Instant.now()));
				FieldSetSubsectionRoleL3 newSubsectionRole2 = em.merge(newSubsectionRole);
				em.persist(newSubsectionRole2);
				
			}
		}
	}

	private void cloneHeaderTabRoles(List<Long> roleKeysFrom, List<Long> roleKeysTo, EntityManager em) {

		CriteriaBuilder criteriaBlde = em.getCriteriaBuilder();
		CriteriaQuery<HeaderTabRoleL3> criteriaQry = criteriaBlde.createQuery(HeaderTabRoleL3.class);
		Root<HeaderTabRoleL3> rootHeaderTabRole = criteriaQry.from(HeaderTabRoleL3.class);
		criteriaQry.select(rootHeaderTabRole);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlde.equal(rootHeaderTabRole.get(RoleManagementConstants.ISACTIVE), new BigDecimal(1)));
		predicates.add(rootHeaderTabRole.get(RoleManagementConstants.ROLEPRODUCTMAPPING)
				.get(RoleManagementConstants.ROLEPRODKEY).in(roleKeysFrom));
		criteriaQry.where(predicates.toArray(new Predicate[] {}));

		List<HeaderTabRoleL3> results = em.createQuery(criteriaQry).getResultList();

		for (Long roleKey : roleKeysTo) {
			RoleProductMapping roleproductmapping = new RoleProductMapping();
			roleproductmapping.setRoleprodkey(roleKey);
			for (HeaderTabRoleL3 resultHeaderTabRole : results) {
				HeaderTabMasterL3 headerTabMaster = new HeaderTabMasterL3();
				headerTabMaster.setTabkey(resultHeaderTabRole.getHeaderTabMaster().getTabkey()); // header tab master key
				HeaderTabRoleL3 headerTabRole = new HeaderTabRoleL3();
				headerTabRole.setHeaderTabMaster(headerTabMaster);
				headerTabRole.setRoleProductMapping(roleproductmapping);
				headerTabRole.setIsactive(new BigDecimal(1));
				headerTabRole.setLstupdatedt(Timestamp.from(Instant.now()));
				HeaderTabRoleL3 headerTabRole2 = em.merge(headerTabRole);
				em.persist(headerTabRole2);

			}
		}
	}

	private void cloneFieldSetRoles(List<Long> roleKeysFrom, List<Long> roleKeysTo, EntityManager em) {

		CriteriaBuilder criteriaBlde = em.getCriteriaBuilder();
		CriteriaQuery<FieldSetRoleL3> criteriaQry = criteriaBlde.createQuery(FieldSetRoleL3.class);
		Root<FieldSetRoleL3> rootFieldSetRole = criteriaQry.from(FieldSetRoleL3.class);
		criteriaQry.select(rootFieldSetRole);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlde.equal(rootFieldSetRole.get(RoleManagementConstants.ISACTIVE), new BigDecimal(1)));
		predicates.add(rootFieldSetRole.get(RoleManagementConstants.ROLEPRODUCTMAPPING)
				.get(RoleManagementConstants.ROLEPRODKEY).in(roleKeysFrom));
		criteriaQry.where(predicates.toArray(new Predicate[] {}));

		List<FieldSetRoleL3> results = em.createQuery(criteriaQry).getResultList();

		for (Long roleKey : roleKeysTo) {
			RoleProductMapping roleproductmapping = new RoleProductMapping();
			roleproductmapping.setRoleprodkey(roleKey);
			for (FieldSetRoleL3 resultFieldRole : results) {
				FieldSetRoleL3 fieldSetRole = new FieldSetRoleL3();
				fieldSetRole.setFieldaccess(resultFieldRole.getFieldaccess());
				fieldSetRole.setRoleProductMapping(roleproductmapping);
				fieldSetRole.setIsactive(new BigDecimal(1));
				FieldSetAttributeL3 fieldSetAttribute = new FieldSetAttributeL3();
				fieldSetAttribute.setFieldkey(resultFieldRole.getFieldSetAttribute().getFieldkey());
				fieldSetRole.setFieldSetAttribute(fieldSetAttribute);
				fieldSetRole.setLstupdatedt(Timestamp.from(Instant.now()));
				FieldSetRoleL3 fieldSetRole2 = em.merge(fieldSetRole);
				em.persist(fieldSetRole2);

			}
		}
	}

	private void cloneCtaRoles(List<Long> roleKeysFrom, List<Long> roleKeysTo, EntityManager em) {

		CriteriaBuilder criteriaBlde = em.getCriteriaBuilder();
		CriteriaQuery<CtaRoleL3> criteriaQry = criteriaBlde.createQuery(CtaRoleL3.class);
		Root<CtaRoleL3> rootCtaRole = criteriaQry.from(CtaRoleL3.class);
		criteriaQry.select(rootCtaRole);
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBlde.equal(rootCtaRole.get(RoleManagementConstants.ISACTIVE), new BigDecimal(1)));
		predicates.add(rootCtaRole.get(RoleManagementConstants.ROLEPRODUCTMAPPING)
				.get(RoleManagementConstants.ROLEPRODKEY).in(roleKeysFrom));
		criteriaQry.where(predicates.toArray(new Predicate[] {}));

		List<CtaRoleL3> results = em.createQuery(criteriaQry).getResultList();

		for (Long roleKey : roleKeysTo) {
			RoleProductMapping roleproductmapping = new RoleProductMapping();
			roleproductmapping.setRoleprodkey(roleKey);
			for (CtaRoleL3 resultCtaRole : results) {
				CtaRoleL3 ctaRole = new CtaRoleL3();
				ctaRole.setCtaProduct(resultCtaRole.getCtaProduct());
				ctaRole.setRoleProductMapping(roleproductmapping);
				ctaRole.setIsactive(new BigDecimal(1));
				ctaRole.setLstupdatedt(Timestamp.from(Instant.now()));
				ctaRole.setLstupdateby("Check What to Pass");
				em.persist(ctaRole);

			}
		}
	}

	private void deleteRoleAccessConfigurationsinClone(List<Long> roleprodTo, EntityManager manager,
			CloneRoleAccessConfigureBean inputBean) {

		logger.debug(CLASS_NAME, DAO, DAO_MSG10 + roleprodTo);
		for (long roleto : roleprodTo) {
			
			int ctaRoles = manager.createNamedQuery("CtaRoleL3.DeleteCtaRoles")
					/** .setParameter("ctaprodkeys", ctaProductKeys) */
					.setParameter(RoleManagementConstants.ROLEKEY, roleto) // inputBean.getRolekey()
					.setParameter("productmasterkey", BigDecimal.valueOf(inputBean.getProductkeyTo()))
					.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(inputBean.getSubprodkeyTo())).executeUpdate();
			logger.debug(CLASS_NAME, DAO,
					DAO_MSG9 + ctaRoles + " Deleted CtaRole Records for Product Key :" + " for Role Key :" + roleto);

			int headerTabRoles = manager.createNamedQuery("HeaderTabRoleL3.DeleteHeaderTabRolesBasedonL3")
					.setParameter(RoleManagementConstants.ROLEKEY, roleto) // inputBean.getRolekey()
					.executeUpdate();

			logger.debug(CLASS_NAME, DAO,
					DAO_MSG9 + headerTabRoles + " Deleted HeaderTabRole Records for Role Key :" + roleto);

			int fieldSetRoles = manager.createNamedQuery("FieldSetRoleL3.DeleteFieldSetRoles")
					.setParameter(RoleManagementConstants.ROLEKEY, roleto) // inputBean.getRolekey()
					.executeUpdate();
			logger.debug(CLASS_NAME, DAO,
					DAO_MSG9 + fieldSetRoles + " Deleted FieldSetRole Records for Role Key :" + roleto);

			int fieldSetSubsectionRoles = manager.createNamedQuery("FieldSetSubsectionRoleL3.DeleteAllSubSectionRoles")
					.setParameter(RoleManagementConstants.ROLEKEYS, roleto) // inputBean.getRoleKeys()
					.executeUpdate();
			logger.debug(CLASS_NAME, DAO, DAO_MSG9 + fieldSetSubsectionRoles
					+ " Deleted FieldSetSubsectionRole Records with Role Key :" + roleto);
		}
	}

	@Override
	public TabResponse saveTabKeyAndProducts(UserRoleBean rolebean) {
		logger.debug(CLASS_NAME, DAO, "Dao invoked");
		TabResponse tabResponsesList = new TabResponse();
		try{
		BigDecimal rolekey = (BigDecimal) entityManager.createNativeQuery("Select rolekey from USER_ROLES where userrolekey = :userrolekey and userkey = :userkey")
				.setParameter("userrolekey", rolebean.getUserRoleKey())
				.setParameter("userkey", rolebean.getUserKey())
				.getSingleResult();
		
		
		List <RoleProductMapping> roleprodkey = entityManager
				.createNamedQuery("RoleProductMapping.findAll")
				.setParameter(RoleManagementConstants.ROLEKEY, rolekey).getResultList();
		
		List <Long>  role = new ArrayList<>();
		for(RoleProductMapping roleprod : roleprodkey){
			long rolek = roleprod.getRoleprodkey();
			role.add(rolek);
		}
		List<BigDecimal> roleskeys = role.stream().map(BigDecimal::new).collect(Collectors.toList());
		
		List<RoleTabKeyAndNameResponse> roleList = new ArrayList<>();

		/*
		List<HeaderTabMasterL3> tabresponse =  entityManager.createNamedQuery ("HeaderTabRoleL3.findAllTabDetails")
				.setParameter(RoleManagementConstants.ROLEKEY, role).getResultList(); */
		
		List<HeaderTabMasterL3> tabresponse =  entityManager.createNamedQuery ("HeaderTabRoleL3.findTabDetailsForRole")
				.setParameter(RoleManagementConstants.ROLEKEY, role).getResultList();
 
		for (HeaderTabMasterL3 keyResponse : tabresponse) {
			 List<SubProductBean> subProductlist = new ArrayList<>();
			 RoleTabKeyAndNameResponse response = new RoleTabKeyAndNameResponse();
			 response.setTabKey(BigDecimal.valueOf(keyResponse.getTabkey()));
			 response.setTabName(keyResponse.getTabname());
			 response.setTabCode(keyResponse.getTabcd());
			 response.setViewOrder(keyResponse.getVieworder());
			 
			 setSubProductbean(keyResponse,subProductlist,roleskeys);
		
			 response.setSubProductBean(subProductlist);
			 roleList.add(response);
		}
		 tabResponsesList.setRoleTabKeyAndNameResponse(roleList);
		} 
		catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Error in getting tabdetails",
					exception);
			throw new BFLTechnicalException("ROLEMGT_7019", exception);
		}
		return tabResponsesList;
	}
	private void setSubProductbean(HeaderTabMasterL3 keyResponse, List<SubProductBean> subProductlist,List<BigDecimal> roleskeys){
				
		 if (keyResponse.getTabcd().equals(RoleManagementConstants.TAB_CODE_SECURED) || keyResponse.getTabcd().equals(RoleManagementConstants.TAB_CODE_UNSECURED)) {
			List <Object[]> subproduct = entityManager
					.createNativeQuery("select l.LNPRODKEY, l.LNPRODDESC, l.LNPRODCODE"
							+ " from LOAN_PRODUCTS l,header_tab_products htp where htp.tabkey=:tabkeys and"
							+ " htp.subprodkey=l.lnprodkey and l.LNPRODKEY in"
							+ " (select m.SUBPRODMASTKEY from ROLE_PRODUCT_MAPPING m where m.ROLEPRODKEY in :rolekey and m.isactive=1)")
					.setParameter(RoleManagementConstants.ROLEKEY, roleskeys)
					.setParameter(RoleManagementConstants.TABKEYS, keyResponse.getTabkey())
					.getResultList();
			for (Object[] object : subproduct) {
				SubProductBean subProductBean = new SubProductBean();
				subProductBean.setLoanProdDesc(object[1].toString());
				subProductBean.setLoanProdKey((BigDecimal) object[0]);
				subProductBean.setLoanProdCode(object[2].toString());
				subProductlist.add(subProductBean);
			}

		} 
		else if(keyResponse.getTabcd().equals(RoleManagementConstants.TAB_CODE_GENERAL_INS) || keyResponse.getTabcd().equals(RoleManagementConstants.TAB_CODE_LIFE_INS)){
			List <Object[]> subproduct = entityManager
					.createNativeQuery("select inp.INSPRODTYPEKEY, inp.INSPRODTYPEDESC, inp.INSPRODTYPECODE "
							+ " from INS_PRODUCT_TYPES inp,header_tab_products htp where htp.tabkey=:tabkeys and"
							+ " htp.subprodkey=inp.INSPRODTYPEKEY and inp.INSPRODTYPEKEY in"
							+ " (select m.SUBPRODMASTKEY from ROLE_PRODUCT_MAPPING m where m.ROLEPRODKEY in :rolekey and m.isactive=1)")
					.setParameter(RoleManagementConstants.ROLEKEY, roleskeys)
					.setParameter(RoleManagementConstants.TABKEYS, keyResponse.getTabkey())
					.getResultList();
			for (Object[] object : subproduct) {
				SubProductBean subProductBean = new SubProductBean();
				subProductBean.setLoanProdDesc(object[1].toString());
				subProductBean.setLoanProdKey((BigDecimal) object[0]);
				subProductBean.setLoanProdCode(object[2].toString());
				subProductlist.add(subProductBean);
			}

		}
		else if(keyResponse.getTabcd().equals(RoleManagementConstants.TAB_CODE_CARDS)){
			List <Object[]> subproduct = entityManager
					.createNativeQuery("SELECT vas.VASPRODTYPEKEY, vas.VPTPRODTYPEDESC, vas.VPTPRODTYPECODE FROM VAS_PRODUCT_TYPES vas, header_tab_products htp "
							+ " WHERE htp.tabkey =:tabkeys AND htp.subprodkey = vas.VASPRODTYPEKEY AND vas.VASPRODTYPEKEY IN "
							+ " (SELECT m.SUBPRODMASTKEY FROM ROLE_PRODUCT_MAPPING m WHERE m.ROLEPRODKEY IN :rolekey AND m.isactive = 1 )")
					.setParameter(RoleManagementConstants.ROLEKEY, roleskeys)
					.setParameter(RoleManagementConstants.TABKEYS, keyResponse.getTabkey())
					.getResultList();
			for (Object[] object : subproduct) {
				SubProductBean subProductBean = new SubProductBean();
				subProductBean.setLoanProdDesc(object[1].toString());
				subProductBean.setLoanProdKey((BigDecimal) object[0]);
				subProductBean.setLoanProdCode(object[2].toString());
				subProductlist.add(subProductBean);
			}

		}
		else {
			subProductlist.add(null);
			}
	}
	@Override
	public List <Long> getroleprodkey(List <BigDecimal> roleKeys,long prodkey ,long subprodkey){
		
		List<Long> roleProdKeys = new ArrayList<>();
		List <Long> longRolekeys = new ArrayList<>();
		for(BigDecimal r : roleKeys){
			longRolekeys.add(r.longValue());
		}
		List <BfsdRoleMaster> rolemaster = entityManager.createNamedQuery("BfsdRoleMaster.findAllByRolekey")
										.setParameter(RoleManagementConstants.ROLEKEYS, longRolekeys)
										.getResultList();
		
		for(BfsdRoleMaster role :rolemaster){
			if(RoleManagementConstants.ADMIN_CODE.equals(role.getRolecd())){
				roleProdKeys= entityManager.createNamedQuery(RoleManagementConstants.ROLEPRODUCTNAMEDQUERY)
						.setParameter(RoleManagementConstants.ROLEKEY, roleKeys)
						.getResultList();
			}
			else{
				roleProdKeys = entityManager.createNamedQuery(RoleManagementConstants.ROLEPRODNAMEDQUERY)
				.setParameter(RoleManagementConstants.ROLEKEY, roleKeys)
				.setParameter(RoleManagementConstants.PRODKEY, BigDecimal.valueOf(prodkey))
				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(subprodkey))
				.getResultList();
			}
		}
		return roleProdKeys;
	}
	@Override
	public List <FieldSetMasterL3> getfieldsetmaster(RoleAccessConfigurationBean inputbean){
		List<BigDecimal> tabkeys = inputbean.getTabKeys().stream().map(BigDecimal::new).collect(Collectors.toList());
		return entityManager.createNamedQuery("FieldSetMasterL3.findAllBasedonTabandProductkey")
				.setParameter(RoleManagementConstants.TABKEYS,tabkeys)
				.setParameter(RoleManagementConstants.PRODKEY, BigDecimal.valueOf(inputbean.getProductTypeKey()))
				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(inputbean.getSubprodkey().get(0)))
				.getResultList();
	}
	public void activeRoleProductMap(RoleProductMapping roleProductMapping, EntityManager em){
		roleProductMapping.setIsactive(BigDecimal.ONE);
		roleProductMapping.setLstupdatedt(Timestamp.from(Instant.now()));
		em.merge(roleProductMapping);
		}

	@Override
	@Transactional
	public boolean updateHomeAndGlobalSearchAccessForOmInBau(RoleAccessConfigurationInputBean roleAccessConfigurationInputBean) {
		try {
			List<Long> tabKeys = Arrays.stream(roleAccessConfigurationInputBean.getTabIds()).boxed()
					.collect(Collectors.toList());
			List<Long> rolekeys = Arrays.stream(roleAccessConfigurationInputBean.getRolekeys()).boxed()
					.collect(Collectors.toList());
			List<BigDecimal> commonTabcdList = new ArrayList<>();
			commonTabcdList.add(new BigDecimal(15));// home tabcd
			commonTabcdList.add(new BigDecimal(16));// Global search tabcd
			
			List<Long> commonTabKeys = entityManager
					.createNamedQuery("HeaderTabMasterL3.findSelectedCommonTabkeys")
					.setParameter(RoleManagementConstants.COMMON_TABCD_LIST, commonTabcdList)
					.setParameter(RoleManagementConstants.TABKEYS, tabKeys).getResultList();
			
			deactivateExistingAccessToCommonTabs(commonTabcdList, rolekeys);
			saveHeaderTabRoleForCommonTabs(commonTabKeys, rolekeys, roleAccessConfigurationInputBean.getProductkey());

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Error in saving updating access to common tabs into database", e);
			throw new BFLBusinessException(RoleManagementConstants.ERROR_7018,
					env.getProperty(RoleManagementConstants.ERROR_7018));
		}
		return true;
	}

	public void saveHeaderTabRoleForCommonTabs(List<Long> commonTabKeys, List<Long> rolekeys, Long prodMastKey) {
		try {
			HeaderTabMasterL3 headerTabMaster = null;
			RoleProductMapping roleProductMapping = null;
			HeaderTabRoleL3 headerTabRole = null;
			for (Long rolekey : rolekeys) {
				List <RoleProductMapping> roleProductMappingList = entityManager
						.createNamedQuery("RoleProductMapping.findAll")
						.setParameter(RoleManagementConstants.ROLEKEY, BigDecimal.valueOf(rolekey)).getResultList();
				
				if (!CollectionUtils.isEmpty(roleProductMappingList)) {
					roleProductMapping = roleProductMappingList.get(0);
					for (Long tabkey : commonTabKeys) {

						headerTabMaster = new HeaderTabMasterL3();
						headerTabMaster.setTabkey(tabkey);

						headerTabRole = new HeaderTabRoleL3();
						headerTabRole.setRoleProductMapping(roleProductMapping);
						headerTabRole.setHeaderTabMaster(headerTabMaster);
						headerTabRole.setIsactive(new BigDecimal(1));
						headerTabRole.setLstupdatedt(Timestamp.from(Instant.now()));
						entityManager.persist(headerTabRole);
					}
				} else {
					roleProductMapping = new RoleProductMapping();
					roleProductMapping.setRolekey(BigDecimal.valueOf(rolekey));
					roleProductMapping.setProdmastkey(BigDecimal.valueOf(prodMastKey));
					roleProductMapping.setSubprodmastkey(new BigDecimal(-1));
					roleProductMapping.setIsactive(BigDecimal.ONE);
					roleProductMapping.setLstupdateby("");
					roleProductMapping.setLstupdatedt(Timestamp.from(Instant.now()));
					
					List<HeaderTabRoleL3> headerTabRoles = new ArrayList<>();

					for (Long tabkey : commonTabKeys) {

						headerTabMaster = new HeaderTabMasterL3();
						headerTabMaster.setTabkey(tabkey);

						headerTabRole = new HeaderTabRoleL3();
						headerTabRole.setHeaderTabMaster(headerTabMaster);
						headerTabRole.setIsactive(new BigDecimal(1));
						headerTabRole.setLstupdatedt(Timestamp.from(Instant.now()));
						headerTabRole.setRoleProductMapping(roleProductMapping);
						headerTabRoles.add(headerTabRole);
					}
					roleProductMapping.setHeaderTabRoles(headerTabRoles);
					entityManager.persist(roleProductMapping);
				}
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Error in saving Roleproductmapping into database", e);
			throw new BFLBusinessException(RoleManagementConstants.ERROR_7018,
					env.getProperty(RoleManagementConstants.ERROR_7018));
		}
	}

	public void deactivateExistingAccessToCommonTabs(List<BigDecimal> commonTabcdList, List<Long> rolekeys) {
		try {
			logger.debug(CLASS_NAME, DAO, "deactivating access to Home and Global search:" + "for roles " + rolekeys);
			
			List<BigDecimal> roleKeysBigDecimal = new ArrayList<>();
			for (Long rolekey : rolekeys) {
				roleKeysBigDecimal.add(BigDecimal.valueOf(rolekey));
			}
			
			List<Long> commonTabKeys = entityManager
					.createNamedQuery("HeaderTabMasterL3.findHomeAndGlobalSearchTabkeys")
					.setParameter(RoleManagementConstants.COMMON_TABCD_LIST, commonTabcdList).getResultList();
			
			List<Long> roleProdKeys = entityManager
					.createNamedQuery("RoleProductMapping.FindAllRoleProdKeysForRolekeys")
					.setParameter(RoleManagementConstants.ROLEKEYS, roleKeysBigDecimal)
					.getResultList();
			if (!CollectionUtils.isEmpty(roleProdKeys)) {
				int headerTabRoles = entityManager
						.createNamedQuery("HeaderTabRoleL3.DeactivateHeaderTabRolesBasedonTabkeysAndRolekeys")
						.setParameter(RoleManagementConstants.TABKEYS, commonTabKeys)
						.setParameter(RoleManagementConstants.ROLEPRODKEYS, roleProdKeys).executeUpdate();
				logger.debug(CLASS_NAME, DAO,
						DAO_MSG9 + headerTabRoles + "Deactivated HeaderTabRole Records for Role Key :" + rolekeys);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Error in saving Roleproductmapping into database", e);
			throw new BFLBusinessException(RoleManagementConstants.ERROR_7018,
					env.getProperty(RoleManagementConstants.ERROR_7018));
		}
	}

	@Override
	@Transactional
	public RoleAccessConfigurationBean fetchCommonTabsMappedForRole(RoleAccessConfigurationBean roleAccConfig,
			List<Long> rolekeys) {
		
		List<BigDecimal> roleKeysBigDecimal = new ArrayList<>();
		for (Long rolekey : rolekeys) {
			roleKeysBigDecimal.add(BigDecimal.valueOf(rolekey));
		}
		
		List<Long> roleProdKeys = entityManager
				.createNamedQuery("RoleProductMapping.FindAllRoleProdKeysForRolekeys")
				.setParameter(RoleManagementConstants.ROLEKEYS, roleKeysBigDecimal)
				.getResultList();
		
		List<BigDecimal> commonTabcdList = new ArrayList<>();
		commonTabcdList.add(new BigDecimal(15));// home tabcd
		commonTabcdList.add(new BigDecimal(16));// Global search tabcd
		
		List<Long> commonTabkeysConfigured = entityManager
				.createNamedQuery("HeaderTabMasterL3.FindCommonTabkeysConfiguredForRoles")
				.setParameter(RoleManagementConstants.ROLEPRODKEYS, roleProdKeys)
				.setParameter(RoleManagementConstants.COMMON_TABCD_LIST, commonTabcdList).getResultList();
		
		for (TabBean tabBean : roleAccConfig.getTabBeanList()) {
			if(commonTabkeysConfigured.contains(tabBean.getTabKey())){
				tabBean.setSelected(true);
			}
		}
		
		return roleAccConfig;
	}

	@Override
	@Transactional
	public Boolean updateHeaderTabLinkAccess(RoleAccessConfigurationInputBean roleAccessConfigurationInputBean) {
		Boolean success = false;
		EntityManager em = entityManagerFactory.createEntityManager();
		try {
			for (Long roleKey : roleAccessConfigurationInputBean.getRolekeys()) {
				saveLinkRoles(roleAccessConfigurationInputBean, em, roleKey);	
			}
			
		}catch (Exception e){
			logger.error(CLASS_NAME, BFLLoggerComponent.DAO, "Error in saving Roleproductmapping into database", e);
			throw new BFLBusinessException(RoleManagementConstants.ERROR_7018,
					env.getProperty(RoleManagementConstants.ERROR_7018));
		}
		return success;
	}

}