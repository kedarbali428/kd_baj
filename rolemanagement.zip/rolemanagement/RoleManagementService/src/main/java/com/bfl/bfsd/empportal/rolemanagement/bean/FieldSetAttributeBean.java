package com.bfl.bfsd.empportal.rolemanagement.bean;

public class FieldSetAttributeBean {
	
	private long fieldkey;
	private String fieldName;
	
	private String groupName;
	private long groupId ;
	
	private String sectionName;
	private long sectionId ;
	
	private long subSectionId ;
	private String subSectionName;
	public long getFieldkey() {
		return fieldkey;
	}
	public void setFieldkey(long fieldkey) {
		this.fieldkey = fieldkey;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public long getGroupId() {
		return groupId;
	}
	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	public long getSectionId() {
		return sectionId;
	}
	public void setSectionId(long sectionId) {
		this.sectionId = sectionId;
	}
	public long getSubSectionId() {
		return subSectionId;
	}
	public void setSubSectionId(long subSectionId) {
		this.subSectionId = subSectionId;
	}
	public String getSubSectionName() {
		return subSectionName;
	}
	public void setSubSectionName(String subSectionName) {
		this.subSectionName = subSectionName;
	}

	
	
}
