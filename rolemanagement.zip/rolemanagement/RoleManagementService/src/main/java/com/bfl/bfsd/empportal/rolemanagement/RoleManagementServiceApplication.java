package com.bfl.bfsd.empportal.rolemanagement;



import static com.bajaj.bfsd.common.BFLLoggerComponent.CONTROLLER;

import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.PropertySource;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLBusinessApplication;


@PropertySource({"classpath:application.properties", "classpath:error.properties"})
public class RoleManagementServiceApplication extends BFLBusinessApplication {

	private static final String CLASS_NAME = RoleManagementServiceApplication.class.getName();
	
    public static void main(String[] args) {
    	BFLLoggerUtil.info("PASS_CORELATION_ID", CLASS_NAME, CONTROLLER, "Role Management Service Initialization Started");
    	SpringApplication.run(RoleManagementServiceApplication.class, args);
    	BFLLoggerUtil.info("PASS_CORELATION_ID", CLASS_NAME, CONTROLLER, "Role Management Service Initialization Completed");
     }
}
