package com.bfl.bfsd.empportal.rolemanagement.bean;

import java.util.ArrayList;
import java.util.List;

public class FieldSetGroupBean {

	private long groupKey;
	private long groupCode;
	private String groupName;
	private long orderNo;
	private long fieldsetKey;
	private boolean isActive;
	
	List<SectionBean> sections = new ArrayList<>();

	public long getGroupKey() {
		return groupKey;
	}

	public void setGroupKey(long groupKey) {
		this.groupKey = groupKey;
	}

	public long getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(long groupCode) {
		this.groupCode = groupCode;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public long getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(long orderNo) {
		this.orderNo = orderNo;
	}

	public long getFieldsetKey() {
		return fieldsetKey;
	}

	public void setFieldsetKey(long fieldsetKey) {
		this.fieldsetKey = fieldsetKey;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public List<SectionBean> getSections() {
		return sections;
	}

	public void setSections(List<SectionBean> sections) {
		this.sections = sections;
	}
}
