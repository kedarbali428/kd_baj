package com.bfl.bfsd.empportal.rolemanagement.dto;

import java.util.List;

import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetGroupL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetRoleL3;

public class FieldSetGroupAndFieldSetRolesL3DTO {
	
	private List<FieldSetGroupL3> fieldSetGroups;
	private List<FieldSetRoleL3> fieldSetRoles;
	
	public List<FieldSetGroupL3> getFieldSetGroups() {
		return fieldSetGroups;
	}
	public List<FieldSetRoleL3> getFieldSetRoles() {
		return fieldSetRoles;
	}
	public FieldSetGroupAndFieldSetRolesL3DTO(List<FieldSetGroupL3> fieldSetGroups, List<FieldSetRoleL3> fieldSetRoles) {
		super();
		this.fieldSetGroups = fieldSetGroups;
		this.fieldSetRoles = fieldSetRoles;
	}
	
}
