package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;


/**
 * The persistent class for the FIELD_SET_SECTIONS database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_SECTIONS")

@NamedQueries({
//@NamedQuery(name="FieldSetSection.findAll", query="SELECT f FROM FieldSetSection f"),
@NamedQuery(name="FieldSetSection.findAllSection", 
	query="SELECT fss FROM FieldSetSection fss,HeaderTabSection hts, HeaderTabRole htr "
			+ " where fss.sectionkey = hts.fieldSetSection.sectionkey"
			+ " and htr.headerTabMaster.tabkey = hts.headerTabMaster.tabkey"
			+ " and htr.bfsdRoleMaster.rolekey =:roleKey"
			+ " and htr.isactive = 1"
			+ " and hts.isactive = 1"
			+ " and fss.isactive = 1"),

@NamedQuery(name="FieldSetSection.findAllSectionAndSubSections", 
query="SELECT fss FROM FieldSetSection fss, "
		+ " FieldSetGroup fsg, FieldSetSubsection fssb, FieldSetMaster fsm, UserRole ur, FieldSetSubsectionRole fssr"
		+ " where fss.fieldSetGroup.groupkey = fsg.groupkey"
		+ " and fsg.fieldSetMaster.fieldsetkey = fsm.fieldsetkey"
		+ " and fsm.fieldsetcd = :fieldsetcd"
		+ " and fss.sectionkey = fssb.fieldSetSection.sectionkey"
		+ " and fssr.rolekey = ur.bfsdRoleMaster.rolekey "
		+ " and fssb.subsectionkey = fssr.fieldSetSubsection.subsectionkey"
		+ " and ur.userrolekey = :roleKey"
		+ " and fss.isactive = 1"
		+ " and fsg.isactive = 1"
		+ " and fsm.isactive = 1"
		+ " and ur.isactive = 1"
		+ " and fssr.isactive = 1"),
})



public class FieldSetSection implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long sectionkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal orderno;

	private BigDecimal sectioncd;

	private String sectionname;

/**	//bi-directional many-to-one association to CtaSection
//	@OneToMany(mappedBy="fieldSetSection")
//	private List<CtaSection> ctaSections;
//
//	//bi-directional many-to-one association to FieldSetAttribute
//	@OneToMany(mappedBy="fieldSetSection")
//	private List<FieldSetAttribute> fieldSetAttributes;
//
//	//bi-directional many-to-one association to HeaderTabSection
//	@OneToMany(mappedBy="fieldSetSection")
//	private List<HeaderTabSection> headerTabSections;
	
	*/
	//bi-directional many-to-one association to HeaderTabSection
	@OneToMany(mappedBy="fieldSetSection")
	private List<HeaderTabSection> headerTabSections;

	//bi-directional many-to-one association to FieldSetGroup
	@ManyToOne
	@JoinColumn(name="GROUPKEY")
	private FieldSetGroup fieldSetGroup;

	//bi-directional many-to-one association to FieldSetSubsection
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(mappedBy="fieldSetSection",fetch=FetchType.EAGER)
	private List<FieldSetSubsection> fieldSetSubsections;
	

	public FieldSetSection() {
	}
	
	public List<HeaderTabSection> getHeaderTabSections() {
		return this.headerTabSections;
	}

	public void setHeaderTabSections(List<HeaderTabSection> headerTabSections) {
		this.headerTabSections = headerTabSections;
	}

	public FieldSetGroup getFieldSetGroup() {
		return this.fieldSetGroup;
	}

	public void setFieldSetGroup(FieldSetGroup fieldSetGroup) {
		this.fieldSetGroup = fieldSetGroup;
	}

	public List<FieldSetSubsection> getFieldSetSubsections() {
		return this.fieldSetSubsections;
	}

	public void setFieldSetSubsections(List<FieldSetSubsection> fieldSetSubsections) {
		this.fieldSetSubsections = fieldSetSubsections;
	}

	public long getSectionkey() {
		return this.sectionkey;
	}

	public void setSectionkey(long sectionkey) {
		this.sectionkey = sectionkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getOrderno() {
		return this.orderno;
	}

	public void setOrderno(BigDecimal orderno) {
		this.orderno = orderno;
	}

	public BigDecimal getSectioncd() {
		return this.sectioncd;
	}

	public void setSectioncd(BigDecimal sectioncd) {
		this.sectioncd = sectioncd;
	}

	public String getSectionname() {
		return this.sectionname;
	}

	public void setSectionname(String sectionname) {
		this.sectionname = sectionname;
	}

/**	public List<CtaSection> getCtaSections() {
//		return this.ctaSections;
//	}
//
//	public void setCtaSections(List<CtaSection> ctaSections) {
//		this.ctaSections = ctaSections;
//	}
//
//	public CtaSection addCtaSection(CtaSection ctaSection) {
//		getCtaSections().add(ctaSection);
//		ctaSection.setFieldSetSection(this);
//
//		return ctaSection;
//	}
//
//	public CtaSection removeCtaSection(CtaSection ctaSection) {
//		getCtaSections().remove(ctaSection);
//		ctaSection.setFieldSetSection(null);
//
//		return ctaSection;
//	}
//
//	public List<FieldSetAttribute> getFieldSetAttributes() {
//		return this.fieldSetAttributes;
//	}
//
//	public void setFieldSetAttributes(List<FieldSetAttribute> fieldSetAttributes) {
//		this.fieldSetAttributes = fieldSetAttributes;
//	}
//
//	public FieldSetAttribute addFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
//		getFieldSetAttributes().add(fieldSetAttribute);
//		fieldSetAttribute.setFieldSetSection(this);
//
//		return fieldSetAttribute;
//	}
//
//	public FieldSetAttribute removeFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
//		getFieldSetAttributes().remove(fieldSetAttribute);
//		fieldSetAttribute.setFieldSetSection(null);
//
//		return fieldSetAttribute;
//	}
//
//	public List<HeaderTabSection> getHeaderTabSections() {
//		return this.headerTabSections;
//	}
//
//	public void setHeaderTabSections(List<HeaderTabSection> headerTabSections) {
//		this.headerTabSections = headerTabSections;
//	}
//
//	public HeaderTabSection addHeaderTabSection(HeaderTabSection headerTabSection) {
//		getHeaderTabSections().add(headerTabSection);
//		headerTabSection.setFieldSetSection(this);
//
//		return headerTabSection;
//	}
//
//	public HeaderTabSection removeHeaderTabSection(HeaderTabSection headerTabSection) {
//		getHeaderTabSections().remove(headerTabSection);
//		headerTabSection.setFieldSetSection(null);
//
//		return headerTabSection;
//	}*/

}