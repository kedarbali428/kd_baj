package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the CASE_APPLICATION database table.
 * 
 */
@Entity
@Table(name="CASE_APPLICATION")
//@NamedQuery(name="CaseApplication.findAll", query="SELECT c FROM CaseApplication c")
public class CaseApplication implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long appcasekey;

	private BigDecimal appcasepriority;

	private BigDecimal appcasestatus;

	private Timestamp appcasestatustm;

	private BigDecimal applicationkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to CaseAssignment
	@OneToMany(mappedBy="caseApplication")
	private List<CaseAssignment> caseAssignments;

	public CaseApplication() {
	}

	public long getAppcasekey() {
		return this.appcasekey;
	}

	public void setAppcasekey(long appcasekey) {
		this.appcasekey = appcasekey;
	}

	public BigDecimal getAppcasepriority() {
		return this.appcasepriority;
	}

	public void setAppcasepriority(BigDecimal appcasepriority) {
		this.appcasepriority = appcasepriority;
	}

	public BigDecimal getAppcasestatus() {
		return this.appcasestatus;
	}

	public void setAppcasestatus(BigDecimal appcasestatus) {
		this.appcasestatus = appcasestatus;
	}

	public Timestamp getAppcasestatustm() {
		return this.appcasestatustm;
	}

	public void setAppcasestatustm(Timestamp appcasestatustm) {
		this.appcasestatustm = appcasestatustm;
	}

	public BigDecimal getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(BigDecimal applicationkey) {
		this.applicationkey = applicationkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public List<CaseAssignment> getCaseAssignments() {
		return this.caseAssignments;
	}

	public void setCaseAssignments(List<CaseAssignment> caseAssignments) {
		this.caseAssignments = caseAssignments;
	}

	public CaseAssignment addCaseAssignment(CaseAssignment caseAssignment) {
		getCaseAssignments().add(caseAssignment);
		caseAssignment.setCaseApplication(this);

		return caseAssignment;
	}

	public CaseAssignment removeCaseAssignment(CaseAssignment caseAssignment) {
		getCaseAssignments().remove(caseAssignment);
		caseAssignment.setCaseApplication(null);

		return caseAssignment;
	}

}