package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the ROLE_MASTER_STG database table.
 * 
 */
@Entity
@Table(name="ROLE_MASTER_STG")
//@NamedQuery(name="RoleMasterStg.findAll", query="SELECT r FROM RoleMasterStg r")
public class RoleMasterStg implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	private String rolecd;

	private String rolename;

	@Column(name="SR_NAME")
	private String srName;

	public RoleMasterStg() {
	}

	public String getRolecd() {
		return this.rolecd;
	}

	public void setRolecd(String rolecd) {
		this.rolecd = rolecd;
	}

	public String getRolename() {
		return this.rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	public String getSrName() {
		return this.srName;
	}

	public void setSrName(String srName) {
		this.srName = srName;
	}

}