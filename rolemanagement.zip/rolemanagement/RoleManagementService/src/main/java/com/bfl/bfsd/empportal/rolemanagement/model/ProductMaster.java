package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "PRODUCT_MASTER")
@NamedQueries({
		@NamedQuery(name = "ProductMaster.findAllByProdMastKey", query = "select pm from ProductMaster pm where pm.prodmastkey=:prodmastkey AND prodmastisactive=:prodmastisactive") })

public class ProductMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long prodmastkey;

	private String prodmastassestlibilityflag;

	private String prodmastcode;

	private String prodmastdesc;

	private BigDecimal prodmastisactive;

	private String prodmastlstupdateby;

	private Timestamp prodmastlstupdatedt;

	public ProductMaster() {
	}

	public long getProdmastkey() {
		return this.prodmastkey;
	}

	public void setProdmastkey(long prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public String getProdmastassestlibilityflag() {
		return this.prodmastassestlibilityflag;
	}

	public void setProdmastassestlibilityflag(String prodmastassestlibilityflag) {
		this.prodmastassestlibilityflag = prodmastassestlibilityflag;
	}

	public String getProdmastcode() {
		return this.prodmastcode;
	}

	public void setProdmastcode(String prodmastcode) {
		this.prodmastcode = prodmastcode;
	}

	public String getProdmastdesc() {
		return this.prodmastdesc;
	}

	public void setProdmastdesc(String prodmastdesc) {
		this.prodmastdesc = prodmastdesc;
	}

	public BigDecimal getProdmastisactive() {
		return this.prodmastisactive;
	}

	public void setProdmastisactive(BigDecimal prodmastisactive) {
		this.prodmastisactive = prodmastisactive;
	}

	public String getProdmastlstupdateby() {
		return this.prodmastlstupdateby;
	}

	public void setProdmastlstupdateby(String prodmastlstupdateby) {
		this.prodmastlstupdateby = prodmastlstupdateby;
	}

	public Timestamp getProdmastlstupdatedt() {
		return this.prodmastlstupdatedt;
	}

	public void setProdmastlstupdatedt(Timestamp prodmastlstupdatedt) {
		this.prodmastlstupdatedt = prodmastlstupdatedt;
	}

}
