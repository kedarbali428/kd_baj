package com.bfl.bfsd.empportal.rolemanagement.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the FIELD_SET_ATTRIBUTES database table.
 * 
 */
@Entity
@Table(name="FIELD_SET_ATTRIBUTES")
//@NamedQuery(name="FieldSetAttribute.findAll", query="SELECT f FROM FieldSetAttribute f")
public class FieldSetAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long fieldkey;

	private BigDecimal dfltvwsummaryorder;

	private BigDecimal displayorder;

	private BigDecimal editablebystage;

	private BigDecimal fieldcd;

	private BigDecimal fielddatatype;

	private String fieldname;

	private BigDecimal fieldsetkey;

	private BigDecimal fieldtype;

	private String fieldurl;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String physicalcolumn;

	private String physicaltable;

	private BigDecimal requiredflg;

	private BigDecimal setfilterflg;

	private BigDecimal sourcecd;

	private BigDecimal vwdispalyfilterflg;

	//bi-directional many-to-one association to AppViewParamLoan
/**	@OneToMany(mappedBy="fieldSetAttribute")
//	private List<AppViewParamLoan> appViewParamLoans;
//
//	//bi-directional many-to-one association to AppViewSummaryField
//	@OneToMany(mappedBy="fieldSetAttribute")
//	private List<AppViewSummaryField> appViewSummaryFields;*/

	//bi-directional many-to-one association to FieldSetAttribute
	@ManyToOne
	@JoinColumn(name="PARENTFIELDKEY")
	private FieldSetAttribute fieldSetAttribute;

	//bi-directional many-to-one association to FieldSetAttribute
	@OneToMany(mappedBy="fieldSetAttribute")
	private List<FieldSetAttribute> fieldSetAttributes;

	//bi-directional many-to-one association to FieldSetRole
	@OneToMany(mappedBy="fieldSetAttribute")
	private List<FieldSetRole> fieldSetRoles;

	//bi-directional many-to-one association to FieldSetSubsection
	@ManyToOne
	@JoinColumn(name="SUBSECTIONKEY")
	private FieldSetSubsection fieldSetSubsection;

	public FieldSetAttribute() {
	}

	public long getFieldkey() {
		return this.fieldkey;
	}

	public void setFieldkey(long fieldkey) {
		this.fieldkey = fieldkey;
	}

	public BigDecimal getDfltvwsummaryorder() {
		return this.dfltvwsummaryorder;
	}

	public void setDfltvwsummaryorder(BigDecimal dfltvwsummaryorder) {
		this.dfltvwsummaryorder = dfltvwsummaryorder;
	}

	public BigDecimal getDisplayorder() {
		return this.displayorder;
	}

	public void setDisplayorder(BigDecimal displayorder) {
		this.displayorder = displayorder;
	}

	public BigDecimal getEditablebystage() {
		return this.editablebystage;
	}

	public void setEditablebystage(BigDecimal editablebystage) {
		this.editablebystage = editablebystage;
	}

	public BigDecimal getFieldcd() {
		return this.fieldcd;
	}

	public void setFieldcd(BigDecimal fieldcd) {
		this.fieldcd = fieldcd;
	}

	public BigDecimal getFielddatatype() {
		return this.fielddatatype;
	}

	public void setFielddatatype(BigDecimal fielddatatype) {
		this.fielddatatype = fielddatatype;
	}

	public String getFieldname() {
		return this.fieldname;
	}

	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}

	public BigDecimal getFieldsetkey() {
		return this.fieldsetkey;
	}

	public void setFieldsetkey(BigDecimal fieldsetkey) {
		this.fieldsetkey = fieldsetkey;
	}

	public BigDecimal getFieldtype() {
		return this.fieldtype;
	}

	public void setFieldtype(BigDecimal fieldtype) {
		this.fieldtype = fieldtype;
	}

	public String getFieldurl() {
		return this.fieldurl;
	}

	public void setFieldurl(String fieldurl) {
		this.fieldurl = fieldurl;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getPhysicalcolumn() {
		return this.physicalcolumn;
	}

	public void setPhysicalcolumn(String physicalcolumn) {
		this.physicalcolumn = physicalcolumn;
	}

	public String getPhysicaltable() {
		return this.physicaltable;
	}

	public void setPhysicaltable(String physicaltable) {
		this.physicaltable = physicaltable;
	}

	public BigDecimal getRequiredflg() {
		return this.requiredflg;
	}

	public void setRequiredflg(BigDecimal requiredflg) {
		this.requiredflg = requiredflg;
	}

	public BigDecimal getSetfilterflg() {
		return this.setfilterflg;
	}

	public void setSetfilterflg(BigDecimal setfilterflg) {
		this.setfilterflg = setfilterflg;
	}

	public BigDecimal getSourcecd() {
		return this.sourcecd;
	}

	public void setSourcecd(BigDecimal sourcecd) {
		this.sourcecd = sourcecd;
	}

	public BigDecimal getVwdispalyfilterflg() {
		return this.vwdispalyfilterflg;
	}

	public void setVwdispalyfilterflg(BigDecimal vwdispalyfilterflg) {
		this.vwdispalyfilterflg = vwdispalyfilterflg;
	}

/**	public List<AppViewParamLoan> getAppViewParamLoans() {
//		return this.appViewParamLoans;
//	}
//
//	public void setAppViewParamLoans(List<AppViewParamLoan> appViewParamLoans) {
//		this.appViewParamLoans = appViewParamLoans;
//	}
//
//	public AppViewParamLoan addAppViewParamLoan(AppViewParamLoan appViewParamLoan) {
//		getAppViewParamLoans().add(appViewParamLoan);
//		appViewParamLoan.setFieldSetAttribute(this);
//
//		return appViewParamLoan;
//	}
//
//	public AppViewParamLoan removeAppViewParamLoan(AppViewParamLoan appViewParamLoan) {
//		getAppViewParamLoans().remove(appViewParamLoan);
//		appViewParamLoan.setFieldSetAttribute(null);
//
//		return appViewParamLoan;
//	}
//
//	public List<AppViewSummaryField> getAppViewSummaryFields() {
//		return this.appViewSummaryFields;
//	}
//
//	public void setAppViewSummaryFields(List<AppViewSummaryField> appViewSummaryFields) {
//		this.appViewSummaryFields = appViewSummaryFields;
//	}
//
//	public AppViewSummaryField addAppViewSummaryField(AppViewSummaryField appViewSummaryField) {
//		getAppViewSummaryFields().add(appViewSummaryField);
//		appViewSummaryField.setFieldSetAttribute(this);
//
//		return appViewSummaryField;
//	}
//
//	public AppViewSummaryField removeAppViewSummaryField(AppViewSummaryField appViewSummaryField) {
//		getAppViewSummaryFields().remove(appViewSummaryField);
//		appViewSummaryField.setFieldSetAttribute(null);
//
//		return appViewSummaryField;
//	}*/

	public FieldSetAttribute getFieldSetAttribute() {
		return this.fieldSetAttribute;
	}

	public void setFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		this.fieldSetAttribute = fieldSetAttribute;
	}

	public List<FieldSetAttribute> getFieldSetAttributes() {
		return this.fieldSetAttributes;
	}

	public void setFieldSetAttributes(List<FieldSetAttribute> fieldSetAttributes) {
		this.fieldSetAttributes = fieldSetAttributes;
	}

	public FieldSetAttribute addFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		getFieldSetAttributes().add(fieldSetAttribute);
		fieldSetAttribute.setFieldSetAttribute(this);

		return fieldSetAttribute;
	}

	public FieldSetAttribute removeFieldSetAttribute(FieldSetAttribute fieldSetAttribute) {
		getFieldSetAttributes().remove(fieldSetAttribute);
		fieldSetAttribute.setFieldSetAttribute(null);

		return fieldSetAttribute;
	}

	public List<FieldSetRole> getFieldSetRoles() {
		return this.fieldSetRoles;
	}

	public void setFieldSetRoles(List<FieldSetRole> fieldSetRoles) {
		this.fieldSetRoles = fieldSetRoles;
	}

	public FieldSetRole addFieldSetRole(FieldSetRole fieldSetRole) {
		getFieldSetRoles().add(fieldSetRole);
		fieldSetRole.setFieldSetAttribute(this);

		return fieldSetRole;
	}

	public FieldSetRole removeFieldSetRole(FieldSetRole fieldSetRole) {
		getFieldSetRoles().remove(fieldSetRole);
		fieldSetRole.setFieldSetAttribute(null);

		return fieldSetRole;
	}

	public FieldSetSubsection getFieldSetSubsection() {
		return this.fieldSetSubsection;
	}

	public void setFieldSetSubsection(FieldSetSubsection fieldSetSubsection) {
		this.fieldSetSubsection = fieldSetSubsection;
	}

}