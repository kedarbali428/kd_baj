package com.bfl.bfsd.empportal.rolemanagement.dto;

import java.util.List;

import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetGroup;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetRole;

public class FieldSetGroupAndFieldSetRolesDTO {
	
	private List<FieldSetGroup> fieldSetGroups;
	private List<FieldSetRole> fieldSetRoles;
	
	public List<FieldSetGroup> getFieldSetGroups() {
		return fieldSetGroups;
	}
	public List<FieldSetRole> getFieldSetRoles() {
		return fieldSetRoles;
	}
	public FieldSetGroupAndFieldSetRolesDTO(List<FieldSetGroup> fieldSetGroups, List<FieldSetRole> fieldSetRoles) {
		super();
		this.fieldSetGroups = fieldSetGroups;
		this.fieldSetRoles = fieldSetRoles;
	}
	
	

}
