package com.bfl.bfsd.empportal.rolemanagement.model.sl;

import java.io.Serializable;
import javax.persistence.*;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the HEADER_TAB_MASTER database table.
 * 
 */
@Entity
@Table(name="HEADER_TAB_MASTER")
@NamedQueries({
//@NamedQuery(name="HeaderTabMasterL3.findAll", query="SELECT h FROM HeaderTabMasterL3 h"),
@NamedQuery(name="HeaderTabMasterL3.findAlltabkey", query="SELECT h FROM HeaderTabMasterL3 h where tabkey in :tabkeys"),
@NamedQuery(name="HeaderTabMasterL3.findAllBySubprodkey", query="SELECT h FROM HeaderTabMasterL3 h "
		+ ",HeaderTabProduct hp "
		+ "where hp.isactive=1 and "
		+ "h.tabkey =hp.headerTabMaster.tabkey and "
		+ "h.isactive=1 AND hp.subprodkey = :subprodkey"),
@NamedQuery(name="HeaderTabMasterL3.findSelectedCommonTabkeys", query = "select htm.tabkey From HeaderTabMasterL3 htm "
		+"where htm.isactive=1 and htm.tabcd in:commonTabcdList and htm.tabkey in:tabkeys"),
@NamedQuery(name="HeaderTabMasterL3.findHomeAndGlobalSearchTabkeys", query = "select htm.tabkey From HeaderTabMasterL3 htm "
		+"where htm.isactive=1 and htm.tabcd in:commonTabcdList"),
@NamedQuery(name = "HeaderTabMasterL3.FindCommonTabkeysConfiguredForRoles", 
	query = "SELECT distinct htm.tabkey FROM HeaderTabMasterL3 htm "
		+ "where htm.tabcd in :commonTabcdList AND htm.isactive=1 AND htm.tabkey in "
		+ "(SELECT distinct htr.headerTabMaster.tabkey FROM HeaderTabRoleL3 htr, RoleProductMapping rpm WHERE "
		+ "htr.roleProductMapping.roleprodkey = rpm.roleprodkey AND rpm.roleprodkey in :roleprodkeys "
		+ "AND htr.isactive=1 AND rpm.isactive=1)")
})

public class HeaderTabMasterL3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long tabkey;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal tabcd;

	private String tabname;

	private BigDecimal vieworder;

	//bi-directional many-to-one association to HeaderTabProduct
	@OneToMany(mappedBy="headerTabMaster")
	private List<HeaderTabProduct> headerTabProducts;

	//bi-directional many-to-one association to HeaderTabRole
	@OneToMany(mappedBy="headerTabMaster")
	private List<HeaderTabRoleL3> headerTabRoles;
	
	@OneToMany(mappedBy="headerTabMaster")
	private List<HeaderTabGroup> headerTabGroups;

	public HeaderTabMasterL3() {
	}

	public long getTabkey() {
		return this.tabkey;
	}

	public void setTabkey(long tabkey) {
		this.tabkey = tabkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getTabcd() {
		return this.tabcd;
	}

	public void setTabcd(BigDecimal tabcd) {
		this.tabcd = tabcd;
	}

	public String getTabname() {
		return this.tabname;
	}

	public void setTabname(String tabname) {
		this.tabname = tabname;
	}

	public BigDecimal getVieworder() {
		return this.vieworder;
	}

	public void setVieworder(BigDecimal vieworder) {
		this.vieworder = vieworder;
	}

	public List<HeaderTabProduct> getHeaderTabProducts() {
		return this.headerTabProducts;
	}

	public void setHeaderTabProducts(List<HeaderTabProduct> headerTabProducts) {
		this.headerTabProducts = headerTabProducts;
	}

	public HeaderTabProduct addHeaderTabProduct(HeaderTabProduct headerTabProduct) {
		getHeaderTabProducts().add(headerTabProduct);
		headerTabProduct.setHeaderTabMaster(this);

		return headerTabProduct;
	}

	public HeaderTabProduct removeHeaderTabProduct(HeaderTabProduct headerTabProduct) {
		getHeaderTabProducts().remove(headerTabProduct);
		headerTabProduct.setHeaderTabMaster(null);

		return headerTabProduct;
	}

	public List<HeaderTabRoleL3> getHeaderTabRoles() {
		return this.headerTabRoles;
	}

	public void setHeaderTabRoles(List<HeaderTabRoleL3> headerTabRoles) {
		this.headerTabRoles = headerTabRoles;
	}

	public HeaderTabRoleL3 addHeaderTabRole(HeaderTabRoleL3 headerTabRole) {
		getHeaderTabRoles().add(headerTabRole);
		headerTabRole.setHeaderTabMaster(this);

		return headerTabRole;
	}

	public HeaderTabRoleL3 removeHeaderTabRole(HeaderTabRoleL3 headerTabRole) {
		getHeaderTabRoles().remove(headerTabRole);
		headerTabRole.setHeaderTabMaster(null);

		return headerTabRole;
	}
	public List<HeaderTabGroup> getHeaderTabGroups() {
		return this.headerTabGroups;
	}

	public void setHeaderTabGroups(List<HeaderTabGroup> headerTabGroups) {
		this.headerTabGroups = headerTabGroups;
	}

	public HeaderTabGroup addHeaderTabGroup(HeaderTabGroup headerTabGroup) {
		getHeaderTabGroups().add(headerTabGroup);
		headerTabGroup.setHeaderTabMaster(this);

		return headerTabGroup;
	}

	public HeaderTabGroup removeHeaderTabGroup(HeaderTabGroup headerTabGroup) {
		getHeaderTabGroups().remove(headerTabGroup);
		headerTabGroup.setHeaderTabMaster(null);

		return headerTabGroup;
	}

}