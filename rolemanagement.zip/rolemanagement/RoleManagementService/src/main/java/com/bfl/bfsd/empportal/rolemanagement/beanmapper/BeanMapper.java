package com.bfl.bfsd.empportal.rolemanagement.beanmapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bfl.bfsd.empportal.rolemanagement.bean.FieldSetGroupBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.SectionBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.SubSectionalBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.UIFieldBean;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetRolesDTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetSubSectionRolesDTO;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetAttribute;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetGroup;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetRole;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSection;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsection;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsectionRole;

@Component
public class BeanMapper extends BFLComponent{

	public void prepareResponseForGroupsAndSection(RoleAccessConfigurationBean roleAccessConfigBean,
			List<FieldSetGroup> groups) {

		roleAccessConfigBean.setFieldSetGroups(prepareSections2(groups, false));
	}

	private List<FieldSetGroupBean> prepareSections2(List<FieldSetGroup> groups, boolean shouldAddFieldsSetAttributes) {

		List<FieldSetGroupBean> fieldSetGroups = new ArrayList<>();

		for (FieldSetGroup fieldSetGroup : groups) {

			List<SectionBean> parentSectionList = new ArrayList<>();

			FieldSetGroupBean fieldSetGroupBean = new FieldSetGroupBean();
			fieldSetGroupBean.setActive(fieldSetGroup.getIsactive().longValue() == 1 ? true : false);
			fieldSetGroupBean.setFieldsetKey(fieldSetGroup.getGroupkey());
			fieldSetGroupBean.setGroupCode(fieldSetGroup.getGroupcd().longValue());
			fieldSetGroupBean.setFieldsetKey(fieldSetGroup.getFieldSetMaster().getFieldsetkey());
			fieldSetGroupBean.setOrderNo(fieldSetGroup.getOrderno().longValue());
			fieldSetGroupBean.setGroupName(fieldSetGroup.getGroupname());
			fieldSetGroupBean.setGroupKey(fieldSetGroup.getGroupkey());

			for (FieldSetSection fieldSetSection : fieldSetGroup.getFieldSetSections()) {

				SectionBean parentSection = new SectionBean();
				parentSection.setSectionId(fieldSetSection.getSectionkey());
				parentSection.setSectionCode(fieldSetSection.getSectioncd().longValue());
				parentSection.setSectionName(fieldSetSection.getSectionname());
				parentSection.setSectionOrder(
						null != fieldSetSection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);
				fieldSetGroupBean.getSections().add(parentSection);

				for (FieldSetSubsection subsection : fieldSetSection.getFieldSetSubsections()) {

					SubSectionalBean subSectionBean = new SubSectionalBean();
					subSectionBean.setParentSectionId(fieldSetSection.getSectionkey());
					subSectionBean.setSectionId(subsection.getSubsectionkey());
					subSectionBean.setSectionCode(subsection.getSubsectioncd().longValue());
					subSectionBean.setSectionName(subsection.getSubsectionname());
					subSectionBean.setSectionOrder(
							null != subsection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);

					addfieldset( shouldAddFieldsSetAttributes, subsection, subSectionBean);
					
					/**	if (shouldAddFieldsSetAttributes) {
						for (FieldSetAttribute fieldSetAttribute : subsection.getFieldSetAttributes()) {
							UIFieldBean fieldBean = new UIFieldBean();
							fieldBean.setFieldkey(fieldSetAttribute.getFieldkey());
							fieldBean.setFieldName(fieldSetAttribute.getFieldname());
							/** fieldBean.setSectionId(fieldSetSection.getSectionkey());
							fieldBean.setSubSectionId(subsection.getSubsectionkey());
							subSectionBean.getFields().add(fieldBean);
						}
					}*/

					parentSection.getChildSections().add(subSectionBean);
				}
				Collections.sort(parentSection.getChildSections(),
						(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
				parentSectionList.add(parentSection);
			}
			Collections.sort(fieldSetGroupBean.getSections(),
					(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
			fieldSetGroups.add(fieldSetGroupBean);
		}
		Collections.sort(fieldSetGroups, (s1, s2) -> (int) (s1.getOrderNo() - s2.getOrderNo()));
		return fieldSetGroups;
	}
	public void addfieldset (boolean shouldAddFieldsSetAttributes,FieldSetSubsection subsection,SubSectionalBean subSectionBean){
		if (shouldAddFieldsSetAttributes) {
			for (FieldSetAttribute fieldSetAttribute : subsection.getFieldSetAttributes()) {
				UIFieldBean fieldBean = new UIFieldBean();
				fieldBean.setFieldkey(fieldSetAttribute.getFieldkey());
				fieldBean.setFieldName(fieldSetAttribute.getFieldname());
				/** fieldBean.setSectionId(fieldSetSection.getSectionkey());*/
				fieldBean.setSubSectionId(subsection.getSubsectionkey());
				subSectionBean.getFields().add(fieldBean);
				}
			}
		}
			
	/**public void mapFields(RoleAccessConfigurationBean roleAccessConfigBean,
			List<FieldSetSubsection> fieldSetSubsections) {

		for (FieldSetSubsection fieldSetSubsection : fieldSetSubsections) {

			for (FieldSetAttribute fieldSetAttribute : fieldSetSubsection.getFieldSetAttributes()) {
				FieldSetAttributeBean bean = new FieldSetAttributeBean();
				bean.setFieldkey(fieldSetAttribute.getFieldkey());
				bean.setFieldName(fieldSetAttribute.getFieldname());

				bean.setGroupId(fieldSetSubsection.getFieldSetSection().getFieldSetGroup().getGroupkey());
				bean.setGroupName(fieldSetSubsection.getFieldSetSection().getFieldSetGroup().getGroupname());

				bean.setSectionId(fieldSetSubsection.getFieldSetSection().getSectionkey());
				bean.setSectionName(fieldSetSubsection.getFieldSetSection().getSectionname());

				bean.setSubSectionId(fieldSetSubsection.getSubsectionkey());
				bean.setSubSectionName(fieldSetSubsection.getSubsectionname());

			}
		}

		/** roleAccessConfigBean.setFieldSetGroups(prepareSections2(fieldSetGroups,
		// true));

	}*/

	public List<FieldSetGroupBean> prepareGroupsWithSubSections(FieldSetGroupAndFieldSetRolesDTO dto,
			RoleAccessConfigurationBean roleAccessConfigBean) {

		List<FieldSetGroupBean> fieldSetGroups = new ArrayList<>();

		for (FieldSetGroup fieldSetGroup : dto.getFieldSetGroups()) {

			if (!roleAccessConfigBean.getGroupKeys().contains(fieldSetGroup.getGroupkey()))
				continue;

			List<SectionBean> parentSectionList = new ArrayList<>();

			FieldSetGroupBean fieldSetGroupBean = new FieldSetGroupBean();
			fieldSetGroupBean.setActive(fieldSetGroup.getIsactive().longValue() == 1 ? true : false);
			fieldSetGroupBean.setGroupCode(fieldSetGroup.getGroupcd().longValue());
			fieldSetGroupBean.setFieldsetKey(fieldSetGroup.getFieldSetMaster().getFieldsetkey());
			fieldSetGroupBean.setOrderNo(fieldSetGroup.getOrderno().longValue());
			fieldSetGroupBean.setGroupName(fieldSetGroup.getGroupname());
			fieldSetGroupBean.setGroupKey(fieldSetGroup.getGroupkey());

			for (FieldSetSection fieldSetSection : fieldSetGroup.getFieldSetSections()) {

				if (!roleAccessConfigBean.getSectionKeys().contains(fieldSetSection.getSectionkey()))
					continue;

				SectionBean parentSection = new SectionBean();
				parentSection.setSectionId(fieldSetSection.getSectionkey());
				parentSection.setSectionCode(fieldSetSection.getSectioncd().longValue());
				parentSection.setSectionName(fieldSetSection.getSectionname());
				parentSection.setSectionOrder(
						null != fieldSetSection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);
				fieldSetGroupBean.getSections().add(parentSection);
				
				subsection (dto,roleAccessConfigBean,parentSection,fieldSetSection);

		/**		for (FieldSetSubsection subsection : fieldSetSection.getFieldSetSubsections()) {

					if (!roleAccessConfigBean.getSubSectionKeys().contains(subsection.getSubsectionkey()))
						continue;

					SubSectionalBean subSectionBean = new SubSectionalBean();
					subSectionBean.setParentSectionId(fieldSetSection.getSectionkey());
					subSectionBean.setSectionId(subsection.getSubsectionkey());
					subSectionBean.setSectionCode(subsection.getSubsectioncd().longValue());
					subSectionBean.setSectionName(subsection.getSubsectionname());
					subSectionBean.setSectionOrder(
							null != subsection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);

					for (FieldSetAttribute fieldSetAttribute : subsection.getFieldSetAttributes()) {
						UIFieldBean fieldBean = new UIFieldBean();
						fieldBean.setFieldkey(fieldSetAttribute.getFieldkey());
						fieldBean.setFieldName(fieldSetAttribute.getFieldname());
						// fieldBean.setSectionId(fieldSetSection.getSectionkey());
						fieldBean.setSubSectionId(subsection.getSubsectionkey());
						fieldBean.setDisplayOrder(fieldSetAttribute.getDisplayorder().longValue());
						long inputRoleKey = roleAccessConfigBean.getRoleKeys().get(0);
						fieldBean.setAccessLevel(getFieldAccess(dto, fieldSetAttribute, inputRoleKey));

						subSectionBean.getFields().add(fieldBean);
					}
					Collections.sort(subSectionBean.getFields(),
							(f1, f2) -> (int) (f1.getDisplayOrder() - f2.getDisplayOrder()));

					parentSection.getChildSections().add(subSectionBean);
				}*/
				Collections.sort(parentSection.getChildSections(),
						(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
				parentSectionList.add(parentSection);
			}
			Collections.sort(fieldSetGroupBean.getSections(),
					(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
			fieldSetGroups.add(fieldSetGroupBean);
		}
		Collections.sort(fieldSetGroups, (s1, s2) -> (int) (s1.getOrderNo() - s2.getOrderNo()));
		return fieldSetGroups;
		/** roleAccessConfigBean.setFieldSetGroups(fieldSetGroups);*/
	}
	public void subsection (FieldSetGroupAndFieldSetRolesDTO dto,RoleAccessConfigurationBean roleAccessConfigBean,SectionBean parentSection,FieldSetSection fieldSetSection){
		for (FieldSetSubsection subsection : fieldSetSection.getFieldSetSubsections()) {

			if (!roleAccessConfigBean.getSubSectionKeys().contains(subsection.getSubsectionkey()))
				continue;

			SubSectionalBean subSectionBean = new SubSectionalBean();
			subSectionBean.setParentSectionId(fieldSetSection.getSectionkey());
			subSectionBean.setSectionId(subsection.getSubsectionkey());
			subSectionBean.setSectionCode(subsection.getSubsectioncd().longValue());
			subSectionBean.setSectionName(subsection.getSubsectionname());
			subSectionBean.setSectionOrder(
					null != subsection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);

			for (FieldSetAttribute fieldSetAttribute : subsection.getFieldSetAttributes()) {
				UIFieldBean fieldBean = new UIFieldBean();
				fieldBean.setFieldkey(fieldSetAttribute.getFieldkey());
				fieldBean.setFieldName(fieldSetAttribute.getFieldname());
				/** fieldBean.setSectionId(fieldSetSection.getSectionkey());*/
				fieldBean.setSubSectionId(subsection.getSubsectionkey());
				fieldBean.setDisplayOrder(fieldSetAttribute.getDisplayorder().longValue());
				long inputRoleKey = roleAccessConfigBean.getRoleKeys().get(0);
				fieldBean.setAccessLevel(getFieldAccess(dto, fieldSetAttribute, inputRoleKey));

				subSectionBean.getFields().add(fieldBean);
			}
			Collections.sort(subSectionBean.getFields(),
					(f1, f2) -> (int) (f1.getDisplayOrder() - f2.getDisplayOrder()));

			parentSection.getChildSections().add(subSectionBean);
				
	}
	}
	private BigDecimal getFieldAccess(FieldSetGroupAndFieldSetRolesDTO dto, FieldSetAttribute fieldSetAttribute,
			long inputRoleKey) {
		for (FieldSetRole fieldSetRole : dto.getFieldSetRoles()) {
			if(isrolefiledset(fieldSetRole)
					/**null != fieldSetRole && null != fieldSetRole.getBfsdRoleMaster() 
					&& null != fieldSetRole.getFieldSetAttribute() && null != fieldSetRole.getFieldSetAttribute().getFieldcd()
					*/&& isfield(fieldSetRole,fieldSetAttribute,inputRoleKey)){
				
				/**if (fieldSetRole.getBfsdRoleMaster().getRolekey() == inputRoleKey && fieldSetRole.getFieldSetAttribute()
						.getFieldcd().longValue() == fieldSetAttribute.getFieldcd().longValue()) {
					return fieldSetRole.getFieldaccess();
				}*/
				return fieldSetRole.getFieldaccess();
			}
			
		}
		return null;
	}
	public boolean isrolefiledset(FieldSetRole fieldSetRole){
		return null != fieldSetRole && null != fieldSetRole.getBfsdRoleMaster() 
				&& null != fieldSetRole.getFieldSetAttribute() && null != fieldSetRole.getFieldSetAttribute().getFieldcd();
	}
	
	public boolean isfield(FieldSetRole fieldSetRole, FieldSetAttribute fieldSetAttribute,
			long inputRoleKey){
		return fieldSetRole.getBfsdRoleMaster().getRolekey() == inputRoleKey && fieldSetRole.getFieldSetAttribute()
				.getFieldcd().longValue() == fieldSetAttribute.getFieldcd().longValue();
	}

	public List<FieldSetGroupBean> prepareResponseForGroupsAndSectionForEditCase(
			FieldSetGroupAndFieldSetSubSectionRolesDTO dto, long inputRoleKey) {

		return prepareResponseForEditCase(dto, inputRoleKey, true);

	}

	private List<FieldSetGroupBean> prepareResponseForEditCase(FieldSetGroupAndFieldSetSubSectionRolesDTO dto,
			long inputRoleKey, boolean shouldAddFieldsSetAttributes) {

		List<FieldSetGroupBean> fieldSetGroups = new ArrayList<>();

		for (FieldSetGroup fieldSetGroup : dto.getFieldSetGroups()) {

			/** List<SectionBean> parentSectionList = new ArrayList<>();*/
			boolean isParentSectionAdded = false;

			FieldSetGroupBean fieldSetGroupBean = new FieldSetGroupBean();
			fieldSetGroupBean.setActive(fieldSetGroup.getIsactive().longValue() == 1 ? true : false);
			fieldSetGroupBean.setFieldsetKey(fieldSetGroup.getGroupkey());
			fieldSetGroupBean.setGroupCode(fieldSetGroup.getGroupcd().longValue());
			fieldSetGroupBean.setFieldsetKey(fieldSetGroup.getFieldSetMaster().getFieldsetkey());
			fieldSetGroupBean.setOrderNo(fieldSetGroup.getOrderno().longValue());
			fieldSetGroupBean.setGroupName(fieldSetGroup.getGroupname());
			fieldSetGroupBean.setGroupKey(fieldSetGroup.getGroupkey());

			for (FieldSetSection fieldSetSection : fieldSetGroup.getFieldSetSections()) {

				boolean isSubSectionAdded = false;

				SectionBean parentSection = new SectionBean();
				parentSection.setSectionId(fieldSetSection.getSectionkey());
				parentSection.setSectionCode(fieldSetSection.getSectioncd().longValue());
				parentSection.setSectionName(fieldSetSection.getSectionname());
				parentSection.setSectionOrder(setSectionOrderNo(fieldSetSection));
						

				/** fieldSetGroupBean.getSections().add(parentSection);*/

				for (FieldSetSubsection subsection : fieldSetSection.getFieldSetSubsections()) {

					SubSectionalBean subSectionBean = new SubSectionalBean();
					subSectionBean.setParentSectionId(fieldSetSection.getSectionkey());
					subSectionBean.setSectionId(subsection.getSubsectionkey());
					subSectionBean.setSectionCode(subsection.getSubsectioncd().longValue());
					subSectionBean.setSectionName(subsection.getSubsectionname());
					subSectionBean.setSectionOrder(setSubsectionOrderNo(subsection,fieldSetSection));
					if (isRolesHaveAccessforSubSection(inputRoleKey, subsection.getSubsectionkey(),
							dto.getFieldSetSubsectionRoles()) ) {

						parentSection.getChildSections().add(subSectionBean);
						isSubSectionAdded = true;
						addfield ( shouldAddFieldsSetAttributes, dto, subsection, subSectionBean, inputRoleKey);
				/**		if (shouldAddFieldsSetAttributes) {
							for (FieldSetAttribute fieldSetAttribute : subsection.getFieldSetAttributes()) {
								UIFieldBean fieldBean = new UIFieldBean();
								fieldBean.setFieldkey(fieldSetAttribute.getFieldkey());
								fieldBean.setFieldName(fieldSetAttribute.getFieldname());
								/** fieldBean.setSectionId(fieldSetSection.getSectionkey());
								fieldBean.setSubSectionId(subsection.getSubsectionkey());
								subSectionBean.getFields().add(fieldBean);
								
								fieldBean.setAccessLevel(getFieldAccess(dto.getFieldSetRoles(), fieldSetAttribute, inputRoleKey));
							}
					
					}*/
					}
				}

				isParentSectionAdded = setparentsection(isSubSectionAdded, fieldSetGroupBean, parentSection, isParentSectionAdded);

				Collections.sort(parentSection.getChildSections(),
						(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
			}

			if (isParentSectionAdded) {
				fieldSetGroups.add(fieldSetGroupBean);
			}

			Collections.sort(fieldSetGroupBean.getSections(),
					(s1, s2) -> (int) (s1.getSectionOrder() - s2.getSectionOrder()));
			/** fieldSetGroups.add(fieldSetGroupBean);*/
		}
		Collections.sort(fieldSetGroups, (s1, s2) -> (int) (s1.getOrderNo() - s2.getOrderNo()));
		return fieldSetGroups;
	}
public void addfield (boolean shouldAddFieldsSetAttributes,FieldSetGroupAndFieldSetSubSectionRolesDTO dto,FieldSetSubsection subsection,SubSectionalBean subSectionBean,long inputRoleKey){
	if (shouldAddFieldsSetAttributes) {
		for (FieldSetAttribute fieldSetAttribute : subsection.getFieldSetAttributes()) {
			UIFieldBean fieldBean = new UIFieldBean();
			fieldBean.setFieldkey(fieldSetAttribute.getFieldkey());
			fieldBean.setFieldName(fieldSetAttribute.getFieldname());
			/** fieldBean.setSectionId(fieldSetSection.getSectionkey());*/
			fieldBean.setSubSectionId(subsection.getSubsectionkey());
			subSectionBean.getFields().add(fieldBean);
			
			fieldBean.setAccessLevel(getFieldAccess(dto.getFieldSetRoles(), fieldSetAttribute, inputRoleKey));
		}
}}

	private boolean isRolesHaveAccessforSubSection(long roleKey, long subSectionKey,
			List<FieldSetSubsectionRole> fieldSetSubsectionRoles) {

		boolean hasAccess = false;
		for (FieldSetSubsectionRole subsectionRole : fieldSetSubsectionRoles) {
			if (subSectionKey == subsectionRole.getFieldSetSubsection().getSubsectionkey()
					&& subsectionRole.getRolekey().longValue() == roleKey) {
				hasAccess = true;
				break;
			}
		}
		return hasAccess;
	}
	
	private BigDecimal getFieldAccess(List<FieldSetRole> fieldSetRoles, FieldSetAttribute fieldSetAttribute,
			long inputRoleKey) {

		for (FieldSetRole fieldSetRole : fieldSetRoles) {
			if (isroleandattribute(fieldSetRole)
					/**null != fieldSetRole && null != fieldSetRole.getBfsdRoleMaster()
					//&& null != fieldSetRole.getFieldSetAttribute()
					//&& null != fieldSetRole.getFieldSetAttribute().getFieldcd() */
					&& isfieldset(fieldSetRole,inputRoleKey,fieldSetAttribute)) {

		/**		if (fieldSetRole.getBfsdRoleMaster().getRolekey() == inputRoleKey && fieldSetRole.getFieldSetAttribute()
						.getFieldcd().longValue() == fieldSetAttribute.getFieldcd().longValue()) {
					return fieldSetRole.getFieldaccess();
				}
			*/
				return fieldSetRole.getFieldaccess();}
		}
		return null;
	}
public boolean isfieldset(FieldSetRole fieldSetRole ,long inputRoleKey,FieldSetAttribute fieldSetAttribute){
	return fieldSetRole.getBfsdRoleMaster().getRolekey() == inputRoleKey && fieldSetRole.getFieldSetAttribute()
			.getFieldcd().longValue() == fieldSetAttribute.getFieldcd().longValue() ;
	}
public boolean isroleandattribute(FieldSetRole fieldSetRole){
	return null != fieldSetRole && null != fieldSetRole.getBfsdRoleMaster()
			&& null != fieldSetRole.getFieldSetAttribute()
			&& null != fieldSetRole.getFieldSetAttribute().getFieldcd();
	
}

private boolean setparentsection(boolean isSubSectionAdded,FieldSetGroupBean fieldSetGroupBean,SectionBean parentSection,boolean isParentSectionAdded){
	if (isSubSectionAdded) {
		fieldSetGroupBean.getSections().add(parentSection);
		/** isSubSectionAdded = false;*/
		isParentSectionAdded = true;
	}
 return isParentSectionAdded;
}
private long setSubsectionOrderNo(FieldSetSubsection subsection ,FieldSetSection fieldSetSection){
	if(null != subsection.getOrderno()){
		return fieldSetSection.getOrderno().longValue();
	}
	else {
		return 0;
	}
	/**null != subsection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);
	*/
}
private long setSectionOrderNo(FieldSetSection fieldSetSection){
	if(null != fieldSetSection.getOrderno()){
		/** null != fieldSetSection.getOrderno() ? fieldSetSection.getOrderno().longValue() : 0);*/
		return fieldSetSection.getOrderno().longValue();
	}
	else {
		return 0;
	}
}
}
