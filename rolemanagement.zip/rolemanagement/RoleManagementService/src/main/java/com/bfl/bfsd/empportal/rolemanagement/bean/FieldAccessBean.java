package com.bfl.bfsd.empportal.rolemanagement.bean;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

public class FieldAccessBean {

	@Min(value=1,message="Please provide valid fieldkey.")
	private long fieldkey;
	
	@Min(value=0,message="Please provide valid fieldAccesskey.")
	@Max(value=2,message="Please provide valid fieldAccesskey.")
	private long fieldAccesskey;
	
	public long getFieldkey() {
		return fieldkey;
	}
	public void setFieldkey(long fieldkey) {
		this.fieldkey = fieldkey;
	}
	public long getFieldAccesskey() {
		return fieldAccesskey;
	}
	public void setFieldAccesskey(long fieldAccesskey) {
		this.fieldAccesskey = fieldAccesskey;
	}
	@Override
	public String toString() {
		return "FieldAccessBean [fieldkey=" + fieldkey + ", fieldAccesskey=" + fieldAccesskey + "]";
	}
	
	
}
