package com.bfl.bfsd.empportal.rolemanagement.serviceTest;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;

import com.bfl.bfsd.empportal.rolemanagement.bean.AssignedRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleBasedUsersListResponceBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabResponse;
import com.bfl.bfsd.empportal.rolemanagement.bean.UserRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.dao.RoleManagementDao;
import com.bfl.bfsd.empportal.rolemanagement.dao.RoleManagementDaoV2;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetSubSectionRolesDTO;
import com.bfl.bfsd.empportal.rolemanagement.model.BfsdRoleMaster;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetGroup;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetRole;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsection;
import com.bfl.bfsd.empportal.rolemanagement.model.FieldSetSubsectionRole;
import com.bfl.bfsd.empportal.rolemanagement.model.UserRole;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetGroupL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetMasterL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.service.impl.RoleManagementServiceImpl;

@SpringBootTest
@SpringBootConfiguration
public class RoleManagementServiceImplTest {
	@InjectMocks
	RoleManagementServiceImpl roleManagementServiceImpl;
	
	@Mock
	HttpHeaders headers;
	
	@Mock
	RoleManagementDao roleManagementDao;
	
	@Mock
	RoleManagementDaoV2 roleManagementDaoV2;
	
	RoleAccessConfigurationBean roleAccessConfigBean = new RoleAccessConfigurationBean();
	RoleAccessConfigurationInputBean inputBean = new RoleAccessConfigurationInputBean();
	CloneRoleAccessConfigureBean cloneRoleAccessConfigBean = new CloneRoleAccessConfigureBean();
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetTabDetails() {
		List<Long> keys = new ArrayList<Long>();
		keys.add(1L);
		roleAccessConfigBean.setRoleKeys(keys);
		when(roleManagementDao.getTabDetails(keys)).thenReturn(new RoleAccessConfigurationBean());
		assertNotNull(roleManagementServiceImpl.getTabDetails(roleAccessConfigBean));
	}	
	@Test
	public void testGetCTADetails() {
		when(roleManagementDao.getCTADetails(roleAccessConfigBean)).thenReturn(new RoleAccessConfigurationBean());
		assertNotNull(roleManagementServiceImpl.getCTADetails(roleAccessConfigBean));
	}
	@Test
	public void testSaveRoleAccessconfigurations() {
		when(roleManagementDao.saveConfigurations(inputBean)).thenReturn(true);
		assertNotNull(roleManagementServiceImpl.saveRoleAccessconfigurations(inputBean));
	}
	@Test
	public void testGetUsersListOnRoleBased() {
		when(roleManagementDao.usersListOnRoleBased(1L,2L)).thenReturn(new RoleBasedUsersListResponceBean());
		assertNotNull(roleManagementServiceImpl.getUsersListOnRoleBased(1L,2L));
	}
	@Test
	public void testCloneRoleAccessConfiguration() {
		roleManagementServiceImpl.cloneRoleAccessConfiguration(cloneRoleAccessConfigBean);
	}
	@Test
	public void testFetchGroupsSectinoAndsubSectionforUser() {
		List<FieldSetGroup> fieldSetGroups = new ArrayList<FieldSetGroup>();
		when(roleManagementDao.fetchGroupsSectionAndSubSections(roleAccessConfigBean)).thenReturn(fieldSetGroups);
		assertNotNull(roleManagementServiceImpl.fetchGroupsSectinoAndsubSectionforUser(roleAccessConfigBean));
	}
	@Test
	public void testFetchFieldsforGroupsSectinoAndsubSection() {
		List<FieldSetSubsection> fieldSetSubsection = new ArrayList<FieldSetSubsection>();
		when(roleManagementDao.fetchFieldsforGroupsSectinoAndsubSection(roleAccessConfigBean)).thenReturn(fieldSetSubsection);
		assertNotNull(roleManagementServiceImpl.fetchFieldsforGroupsSectinoAndsubSection(roleAccessConfigBean));
	}
	@Test
	public void testFetchFieldsDetailsforGroupsSectinoAndsubSection() {
		List<FieldSetRole> fieldSetRoles = new ArrayList<FieldSetRole>();
		List<FieldSetGroup> fieldSetGroups = new ArrayList<FieldSetGroup>();
		List<Long> keys = new ArrayList<Long>();
		keys.add(1L);
		roleAccessConfigBean.setRoleKeys(keys);
		when(roleManagementDao.fetchFieldsSetRolesByRoleKeys(roleAccessConfigBean.getRoleKeys())).thenReturn(fieldSetRoles);
		when(roleManagementDao.fetchFieldsDetailsforGroupsSectinoAndsubSection(roleAccessConfigBean)).thenReturn(fieldSetGroups);
		assertNotNull(roleManagementServiceImpl.fetchFieldsDetailsforGroupsSectinoAndsubSection(roleAccessConfigBean));
	}
	@Test
	public void testFetchGroupsSectinoAndsubSectionforUserInEditView() {
		List<FieldSetRole> fieldSetRoles = new ArrayList<FieldSetRole>();
		List<FieldSetSubsectionRole> fieldSetSubsectionRoles = new ArrayList<FieldSetSubsectionRole>();
		List<Long> roleKeys = new ArrayList<Long>();
		roleKeys.add(1L);
		List<Long> tabKeys = new ArrayList<Long>();
		tabKeys.add(2L);
		roleAccessConfigBean.setRoleKeys(tabKeys);
		when(roleManagementDao.fetchFieldsSetRolesByRoleKeys(roleKeys)).thenReturn(fieldSetRoles);
		when(roleManagementDao.fetchSubSectionRoleByRole(roleKeys)).thenReturn(fieldSetSubsectionRoles);
		RoleAccessConfigurationBean bean = new RoleAccessConfigurationBean();
		bean.setRoleKeys(roleKeys);
		bean.setTabKeys(tabKeys);
		List<FieldSetGroup> fieldSetGroups = new ArrayList<FieldSetGroup>();
		when(roleManagementDao.fetchGroupsSectionAndSubSections(bean)).thenReturn(fieldSetGroups);	
		assertNotNull(roleManagementServiceImpl.fetchGroupsSectinoAndsubSectionforUserInEditView(roleKeys, tabKeys));
	}
	@Test
	public void testCheckRoleInUsersAssignedRolesHierarchy() {
		AssignedRoleBean assignedRoleBean = new AssignedRoleBean();
		when(roleManagementDao.checkRoleInUsersAssignedRolesHierarchy(assignedRoleBean)).thenReturn(true);	
		assertNotNull(roleManagementServiceImpl.checkRoleInUsersAssignedRolesHierarchy(assignedRoleBean));
	}
	@Test
	public void testGetUserRole() {
		UserRole userRole = new UserRole();
		BfsdRoleMaster bfsdRoleMaster = new BfsdRoleMaster();
		bfsdRoleMaster.setRolekey(123L);
		bfsdRoleMaster.setRolename("ABC");
		userRole.setBfsdRoleMaster(bfsdRoleMaster);
		when(roleManagementDao.getUserRole(1L, 2L)).thenReturn(userRole);
		assertNotNull(roleManagementServiceImpl.getUserRole(1L, 2L));
	}
	@Test
	public void testCheckEmailCTAAccess() {
		when(roleManagementDao.checkEmailCTAAccess(123L)).thenReturn(true);	
		assertNotNull(roleManagementServiceImpl.checkEmailCTAAccess(123L));
	}
	@Test
	public void testGetTabDetailsBasedonL3() {
		List<Long> roleKeys = new ArrayList<Long>();
		roleKeys.add(1L);
		List<Long> subProdKeys = new ArrayList<Long>();
		subProdKeys.add(2L);
		roleAccessConfigBean.setRoleKeys(roleKeys);
		roleAccessConfigBean.setSubprodkey(subProdKeys);
		roleAccessConfigBean.setProductTypeKey(3L);
		when(roleManagementDaoV2.getTabDetailsBasedonL3(roleKeys,2L,3L)).thenReturn(new RoleAccessConfigurationBean());
		assertNotNull(roleManagementServiceImpl.getTabDetailsBasedonL3(roleAccessConfigBean));
	}
	@Test
	public void testFetchGroupsSectinoAndsubSectionforUserInEditViewBasedonL3() {
		List<BigDecimal> roleKeys = new ArrayList<>();
		roleKeys.add(new BigDecimal(1));
		List<Long> tabKeys = new ArrayList<>();
		tabKeys.add(2L);
		long prodKey = 3L;
		List<Long> subprodkey = new ArrayList<>();
		subprodkey.add(4L);
		List <Long> roleProdKeys = new ArrayList<>();
		roleProdKeys.add(5L);
		when(roleManagementDaoV2.getroleprodkey(roleKeys, prodKey , subprodkey.get(0))).thenReturn(roleProdKeys);
		List<FieldSetRoleL3> fieldSetRoles = new ArrayList<FieldSetRoleL3>();
		when(roleManagementDaoV2.fetchFieldsSetRolesByRoleKeysBasedonL3(roleProdKeys,prodKey,subprodkey.get(0))).thenReturn(fieldSetRoles);
		List<Long> rolekeys = new ArrayList<>();
		rolekeys.add(1L);
		assertNotNull(roleManagementServiceImpl.fetchGroupsSectinoAndsubSectionforUserInEditViewBasedonL3(rolekeys, tabKeys, prodKey, subprodkey));
	}
	@Test
	public void testFetchGroupsSectinoAndsubSectionforUserBasedonL3() {
		List<Long> rolekeys = new ArrayList<>();
		rolekeys.add(1L);
		roleAccessConfigBean.setRoleKeys(rolekeys);
		List<Long> subprodkey = new ArrayList<>();
		subprodkey.add(4L);
		roleAccessConfigBean.setSubprodkey(subprodkey);
		roleAccessConfigBean.setProductTypeKey(4L);
		List <Long> roleProdKeys = new ArrayList<Long>();
		List<BigDecimal> roleKeys = new ArrayList<>();
		roleKeys.add(new BigDecimal(1));
		when(roleManagementDaoV2.getroleprodkey(roleKeys, roleAccessConfigBean.getProductTypeKey() , roleAccessConfigBean.getSubprodkey().get(0))).thenReturn(roleProdKeys);
		List<FieldSetGroupL3> fieldSetGroupL3s = new ArrayList<FieldSetGroupL3>();
		when(roleManagementDaoV2.fetchGroupsSectionAndSubSectionsBasedonL3(roleAccessConfigBean)).thenReturn(fieldSetGroupL3s);
		assertNotNull(roleManagementServiceImpl.fetchGroupsSectinoAndsubSectionforUserBasedonL3(roleAccessConfigBean));
	}
	@Test
	public void testFetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3() {
		List<Long> rolekeys = new ArrayList<>();
		rolekeys.add(1L);
		roleAccessConfigBean.setRoleKeys(rolekeys);
		List<BigDecimal> roleKeys = new ArrayList<>();
		roleKeys.add(new BigDecimal(1));
		List <Long> roleProdKeys = new ArrayList<Long>();
		List<Long> subprodkey = new ArrayList<>();
		subprodkey.add(4L);
		roleAccessConfigBean.setSubprodkey(subprodkey);
		roleAccessConfigBean.setProductTypeKey(4L);
		when(roleManagementDaoV2.getroleprodkey(roleKeys, roleAccessConfigBean.getProductTypeKey() , roleAccessConfigBean.getSubprodkey().get(0))).thenReturn(roleProdKeys);	
		List<FieldSetRoleL3> fieldSetRoles = new ArrayList<FieldSetRoleL3>();		
		when(roleManagementDaoV2.fetchFieldsSetRolesByRoleKeysBasedonL3(roleProdKeys,roleAccessConfigBean.getProductTypeKey(),roleAccessConfigBean.getSubprodkey().get(0))).thenReturn(fieldSetRoles);
		List<FieldSetGroupL3> fieldSetGroupL3s = new ArrayList<FieldSetGroupL3>();
		when(roleManagementDaoV2.fetchGroupsSectionAndSubSectionsBasedonL3(roleAccessConfigBean)).thenReturn(fieldSetGroupL3s);
		assertNotNull(roleManagementServiceImpl.fetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3(roleAccessConfigBean));
	}
	@Test
	public void testSaveRoleAccessconfigurationsBasedonL3() {
		when(roleManagementDaoV2.saveConfigurationsBasedonL3(inputBean)).thenReturn(true);	
		assertNotNull(roleManagementServiceImpl.saveRoleAccessconfigurationsBasedonL3(new RoleAccessConfigurationInputBean()));
	}
	@Test
	public void testCloneRoleAccessConfigurationBasedonL3() {
		roleManagementDaoV2.cloneRoleAccessConfigurationBasedonL3(cloneRoleAccessConfigBean);	
		roleManagementServiceImpl.cloneRoleAccessConfigurationBasedonL3(new CloneRoleAccessConfigureBean());
	}
	@Test
	public void testFetchTabKeyAndProducts() {
		TabResponse tabResponse = new TabResponse();
		UserRoleBean rolebean = new UserRoleBean();
		when(roleManagementDaoV2.saveTabKeyAndProducts(rolebean)).thenReturn(tabResponse);	
		assertNotNull(roleManagementServiceImpl.fetchTabKeyAndProducts(rolebean));
	}
	@Test
	public void testFetchFieldSetMaster() {
		List<FieldSetMasterL3> fieldSetMasterL3s = new ArrayList<FieldSetMasterL3>();
		when(roleManagementDaoV2.getfieldsetmaster(roleAccessConfigBean)).thenReturn(fieldSetMasterL3s);	
		assertNotNull(roleManagementServiceImpl.fetchFieldSetMaster(new RoleAccessConfigurationBean()));
	}
	@Test
	public void testGetLinkAcess() {
		when(roleManagementDao.getLinkAcess(roleAccessConfigBean)).thenReturn(roleAccessConfigBean);	
		assertNotNull(roleManagementServiceImpl.getLinkAcess(roleAccessConfigBean));
	}
	@Test
	public void testGetLinksAcess() {
		long roleKey = 123L;
		long tabKey = 456L;
		roleAccessConfigBean.setRoleKeys(Arrays.asList(roleKey));
		roleAccessConfigBean.setTabKeys(Arrays.asList(tabKey));
		when(roleManagementDao.getLinkAcess(roleAccessConfigBean)).thenReturn(roleAccessConfigBean);	
		roleManagementServiceImpl.getLinksAcess(roleKey, tabKey);
	}
	@Test
	public void testGetProdMastCode() {
		when(roleManagementDao.getProdMastCode(123L)).thenReturn("INS");	
		assertNotNull(roleManagementServiceImpl.getProdMastCode(123L));
	}
	@Test
	public void testUpdateBauDependantAccessForOm() {
		when(roleManagementDaoV2.updateHomeAndGlobalSearchAccessForOmInBau(inputBean)).thenReturn(true);	
		assertNotNull(roleManagementServiceImpl.updateBauDependantAccessForOm(new RoleAccessConfigurationInputBean()));
	}
	@Test
	public void testFetchCommonTabsMappedForOm() {
		List<Long> rolekeys = new ArrayList<>();
		rolekeys.add(1L);
		roleAccessConfigBean.setRoleKeys(rolekeys);
		when(roleManagementDaoV2.fetchCommonTabsMappedForRole(roleAccessConfigBean, rolekeys)).thenReturn(roleAccessConfigBean);	
		assertNotNull(roleManagementServiceImpl.fetchCommonTabsMappedForOm(roleAccessConfigBean, roleAccessConfigBean));
	}
}
