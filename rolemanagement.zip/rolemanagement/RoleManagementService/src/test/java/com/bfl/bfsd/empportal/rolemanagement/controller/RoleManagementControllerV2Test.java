package com.bfl.bfsd.empportal.rolemanagement.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.validation.BindingResult;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.cache.service.UserCacheService;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.FieldSetGroupBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.TabResponse;
import com.bfl.bfsd.empportal.rolemanagement.bean.UserRoleBean;
import com.bfl.bfsd.empportal.rolemanagement.beanmapper.BeanMapperV2;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetRolesL3DTO;
import com.bfl.bfsd.empportal.rolemanagement.dto.FieldSetGroupAndFieldSetSubSectionRolesL3DTO;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetGroupL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetMasterL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.FieldSetSubsectionRoleL3;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.RoleProductMapping;
import com.bfl.bfsd.empportal.rolemanagement.plugin.OMRoleManagementDataPluginMapper;
import com.bfl.bfsd.empportal.rolemanagement.service.RoleManagementService;
import com.bfl.bfsd.empportal.rolemanagement.service.impl.RoleManagementServiceImpl;
import com.bfl.common.exceptions.BFLBusinessException;

@SpringBootTest
@SpringBootConfiguration
public class RoleManagementControllerV2Test {

	@InjectMocks
	RoleManagementControllerV2 roleManagementControllerV2;
	
	@Mock
	RoleManagementService roleManagementService;
	@Mock
	RoleManagementServiceImpl roleManagementServiceImpl;
	/**@Inject
    @RequestScoped*/
	@Mock
    BFLLoggerUtil logger1;
	@Mock
	Environment env1;
	@Mock
	BeanMapperV2 beanMapper1;
	@Mock
	private UserCacheService cacheService1;
	@Mock
	private CustomDefaultHeaders customHeader1;
	@Mock
	OMRoleManagementDataPluginMapper dataPluginMapper;
	@Mock
	HttpHeaders headers;
	@Mock
	FieldSetGroupAndFieldSetSubSectionRolesL3DTO dto;
	@Mock
	BindingResult bindingResult;
	
	RoleAccessConfigurationBean roleAccessConfigBean = new RoleAccessConfigurationBean();
	long roleKey = 1L;
	List<Long> tabKeys = new ArrayList<>();
	List<FieldSetGroupL3> fieldSetGroups = new ArrayList<>();
	List<FieldSetRoleL3> fieldSetRoles = new ArrayList<>();
	RoleProductMapping roleProductMapping = new RoleProductMapping(); 
	List<FieldSetSubsectionRoleL3> fieldSetSubsectionRoles = new ArrayList<>();
	FieldSetRoleL3 fieldSetRoleL3 = new FieldSetRoleL3();
	FieldSetGroupL3 fieldSetGroupL3 = new FieldSetGroupL3();
	FieldSetSubsectionRoleL3 fieldSetSubsectionRoleL3 = new FieldSetSubsectionRoleL3();
	FieldSetMasterL3 fieldSetMasterL3 = new FieldSetMasterL3();
	List<FieldSetMasterL3> fieldSetMasterL3List = new ArrayList<>();
	RoleAccessConfigurationInputBean roleAccessConfigurationInputBean = new RoleAccessConfigurationInputBean();
	CloneRoleAccessConfigureBean cloneRoleAccessConfigureBean = new CloneRoleAccessConfigureBean();
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		List<Long> subprodkeyList = new ArrayList<>();
		subprodkeyList.add(1L);
		roleAccessConfigBean.setSubprodkey(subprodkeyList);
		roleAccessConfigBean.setProductTypeKey(69L);
		fieldSetMasterL3List.add(fieldSetMasterL3);
	}
	
	@Test
	public void getTabDetailsBasedonL3_Test() {
		
		RoleAccessConfigurationBean roleAccConfig= new RoleAccessConfigurationBean();
		List<TabBean> omTabBeanList = new ArrayList<>();
		TabBean tabBean = new TabBean();
		omTabBeanList.add(tabBean);
		roleAccConfig.setTabBeanList(omTabBeanList);
		
		when(roleManagementService.getTabDetailsBasedonL3(any())).thenReturn(roleAccConfig);
		when(roleManagementService.fetchCommonTabsMappedForOm(any(), any())).thenReturn(roleAccConfig);
		when(dataPluginMapper.getTabBeanList(any(), any(),any(), any())).thenReturn(omTabBeanList);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMINS");
		assertNotNull(roleManagementControllerV2.getTabDetailsBasedonL3(roleAccessConfigBean, headers));
	}
	
	@Test
	public void getTabDetailsBasedonL3_Test2() {
		
		RoleAccessConfigurationBean roleAccConfig= new RoleAccessConfigurationBean();
		List<TabBean> omTabBeanList = new ArrayList<>();
		TabBean tabBean = new TabBean();
		omTabBeanList.add(tabBean);
		roleAccConfig.setTabBeanList(omTabBeanList);
		
		when(roleManagementService.getTabDetailsBasedonL3(any())).thenReturn(roleAccConfig);
		when(roleManagementService.fetchCommonTabsMappedForOm(any(), any())).thenReturn(roleAccConfig);
		when(dataPluginMapper.getTabBeanList(any(), any(),any(), any())).thenReturn(omTabBeanList);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMCREDIT");
		assertNotNull(roleManagementControllerV2.getTabDetailsBasedonL3(roleAccessConfigBean, headers));
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = BFLBusinessException.class)
	public void getTabDetailsBasedonL3_TestException(){
		when(roleManagementService.getTabDetailsBasedonL3(any())).thenThrow(BFLBusinessException.class);
		assertNotNull(roleManagementControllerV2.getTabDetailsBasedonL3(roleAccessConfigBean, headers));
	}
	
	@Test
	public void fetchAllGroupSectionAndSubSectionDetailsBasedonL3_Test() {
		List<FieldSetGroupL3> listFieldSetGroupL3s = new ArrayList<>();
		FieldSetGroupL3 fieldSetGroupL3 = new FieldSetGroupL3();
		listFieldSetGroupL3s.add(fieldSetGroupL3);
		List<FieldSetGroupBean> fieldSetGroupBeanList = new ArrayList<>();
		roleAccessConfigBean.setFieldSetGroups(fieldSetGroupBeanList);
		roleAccessConfigBean.setTabName(new ArrayList<>());
		when(roleManagementService.fetchGroupsSectinoAndsubSectionforUserBasedonL3(any())).thenReturn(listFieldSetGroupL3s);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMINS");
		assertNotNull(roleManagementControllerV2.fetchAllGroupSectionAndSubSectionDetailsBasedonL3(roleAccessConfigBean, headers));
	}
	
	@Test
	public void fetchAllGroupSectionAndSubSectionDetailsBasedonL3_Test2() {
		List<FieldSetGroupL3> listFieldSetGroupL3s = new ArrayList<>();
		FieldSetGroupL3 fieldSetGroupL3 = new FieldSetGroupL3();
		listFieldSetGroupL3s.add(fieldSetGroupL3);
		List<FieldSetGroupBean> fieldSetGroupBeanList = new ArrayList<>();
		roleAccessConfigBean.setFieldSetGroups(fieldSetGroupBeanList);
		roleAccessConfigBean.setTabName(new ArrayList<>());
		when(roleManagementService.fetchGroupsSectinoAndsubSectionforUserBasedonL3(any())).thenReturn(listFieldSetGroupL3s);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMCREDIT");
		assertNotNull(roleManagementControllerV2.fetchAllGroupSectionAndSubSectionDetailsBasedonL3(roleAccessConfigBean, headers));
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = BFLBusinessException.class)
	public void fetchAllGroupSectionAndSubSectionDetailsBasedonL3_TestException(){
		when(roleManagementService.fetchGroupsSectinoAndsubSectionforUserBasedonL3(any())).thenThrow(BFLBusinessException.class);
		assertNotNull(roleManagementControllerV2.fetchAllGroupSectionAndSubSectionDetailsBasedonL3(roleAccessConfigBean, headers));
	}
	
	@Test
	public void fetchAllGroupSectionAndSubSectionDetailsForEditBasedonL3_Test() {
		long prodkey = 69L;
		tabKeys.add(1L);
		roleAccessConfigBean.setTabKeys(tabKeys);
		fieldSetRoleL3.setFieldrolekey(1L);
		fieldSetRoles.add(fieldSetRoleL3);
		fieldSetRoleL3.setRoleProductMapping(roleProductMapping);
		fieldSetGroups.add(fieldSetGroupL3);
		fieldSetSubsectionRoles.add(fieldSetSubsectionRoleL3);
		List<Long> roleKeys = new ArrayList<>();
		roleKeys.add(1L);
		FieldSetGroupBean fieldSetGroupBean = new FieldSetGroupBean();
		List<FieldSetGroupBean> fieldSetGroupBeanList = new ArrayList<>();
		fieldSetGroupBeanList.add(fieldSetGroupBean);
		FieldSetGroupAndFieldSetSubSectionRolesL3DTO dto = new  FieldSetGroupAndFieldSetSubSectionRolesL3DTO(fieldSetGroups, fieldSetRoles, fieldSetSubsectionRoles);
		when(roleManagementService.fetchGroupsSectinoAndsubSectionforUserInEditViewBasedonL3(roleKeys, roleKeys, prodkey, roleKeys)).thenReturn(dto);
		when(beanMapper1.prepareResponseForGroupsAndSectionForEditCase(dto, 0)).thenReturn(fieldSetGroupBeanList);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMCREDIT");
		assertNotNull(roleManagementControllerV2.fetchAllGroupSectionAndSubSectionDetailsForEditBasedonL3(roleKey, roleAccessConfigBean, headers));
	}
	
	@Test
	public void fetchAllGroupSectionAndSubSectionDetailsForEditBasedonL3_Test2() {
		long prodkey = 69L;
		tabKeys.add(1L);
		roleAccessConfigBean.setTabKeys(tabKeys);
		fieldSetRoleL3.setFieldrolekey(1L);
		fieldSetRoles.add(fieldSetRoleL3);
		fieldSetRoleL3.setRoleProductMapping(roleProductMapping);
		fieldSetGroups.add(fieldSetGroupL3);
		fieldSetSubsectionRoles.add(fieldSetSubsectionRoleL3);
		List<Long> roleKeys = new ArrayList<>();
		roleKeys.add(1L);
		FieldSetGroupBean fieldSetGroupBean = new FieldSetGroupBean();
		List<FieldSetGroupBean> fieldSetGroupBeanList = new ArrayList<>();
		fieldSetGroupBeanList.add(fieldSetGroupBean);
		FieldSetGroupAndFieldSetSubSectionRolesL3DTO dto = new  FieldSetGroupAndFieldSetSubSectionRolesL3DTO(fieldSetGroups, fieldSetRoles, fieldSetSubsectionRoles);
		when(roleManagementService.fetchGroupsSectinoAndsubSectionforUserInEditViewBasedonL3(roleKeys, roleKeys, prodkey, roleKeys)).thenReturn(dto);
		when(beanMapper1.prepareResponseForGroupsAndSectionForEditCase(dto, 0)).thenReturn(fieldSetGroupBeanList);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMINS");
		assertNotNull(roleManagementControllerV2.fetchAllGroupSectionAndSubSectionDetailsForEditBasedonL3(roleKey, roleAccessConfigBean, headers));
	}
	
//	@Test
//	public void getUIFieldsForSelectedSectionAndSubSectionsBasedonL3_Test(){
//		
//		FieldSetGroupAndFieldSetRolesL3DTO dto = new FieldSetGroupAndFieldSetRolesL3DTO(fieldSetGroups, fieldSetRoles);
//		when(roleManagementService.fetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3(roleAccessConfigBean)).thenReturn(dto);
//		when(roleManagementService.fetchFieldSetMaster(roleAccessConfigBean)).thenReturn(fieldSetMasterL3List);
//		when(roleManagementService.getProdMastCode(any())).thenReturn("OMCREDIT");
//		assertNotNull(roleManagementControllerV2.getUIFieldsForSelectedSectionAndSubSectionsBasedonL3(roleAccessConfigBean, headers));
//	}
	
//	@Test
//	public void getUIFieldsForSelectedSectionAndSubSectionsBasedonL3_Test2(){
//		
//		FieldSetGroupAndFieldSetRolesL3DTO dto = new FieldSetGroupAndFieldSetRolesL3DTO(fieldSetGroups, fieldSetRoles);
//		when(roleManagementService.fetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3(roleAccessConfigBean)).thenReturn(dto);
//		when(roleManagementService.fetchFieldSetMaster(roleAccessConfigBean)).thenReturn(fieldSetMasterL3List);
//		when(roleManagementService.getProdMastCode(any())).thenReturn("OMINS");
//		assertNotNull(roleManagementControllerV2.getUIFieldsForSelectedSectionAndSubSectionsBasedonL3(roleAccessConfigBean, headers));
//	}
//	
	@SuppressWarnings("unchecked")
	@Test(expected = BFLBusinessException.class)
	public void getUIFieldsForSelectedSectionAndSubSectionsBasedonL3_TestException(){
		FieldSetGroupAndFieldSetRolesL3DTO dto = new FieldSetGroupAndFieldSetRolesL3DTO(fieldSetGroups, fieldSetRoles);
		when(roleManagementService.fetchFieldsDetailsforGroupsSectinoAndsubSectionBasedonL3(roleAccessConfigBean)).thenReturn(dto);
		when(roleManagementService.fetchFieldSetMaster(roleAccessConfigBean)).thenReturn(fieldSetMasterL3List);
		when(dataPluginMapper.getFieldsDataList(any(), any(), any(), any(), any(), any(), any(), any())).thenThrow(BFLBusinessException.class);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMCREDIT");
		assertNotNull(roleManagementControllerV2.getUIFieldsForSelectedSectionAndSubSectionsBasedonL3(roleAccessConfigBean, headers));
	}
	
	@Test
	public void saveTabCtaConfiguration_Test(){
		roleAccessConfigurationInputBean.setProductkey(69L);
		when(dataPluginMapper.updatedRoleAccessDetails(any(), any())).thenReturn(true);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMCREDIT");
		assertNotNull(roleManagementControllerV2.saveTabCtaConfiguration(roleAccessConfigurationInputBean, bindingResult, headers));
	}
	
	@Test
	public void saveTabCtaConfiguration_Test3(){
		roleAccessConfigurationInputBean.setProductkey(69L);
		when(dataPluginMapper.updatedRoleAccessDetails(any(), any())).thenReturn(true);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMINS");
		assertNotNull(roleManagementControllerV2.saveTabCtaConfiguration(roleAccessConfigurationInputBean, bindingResult, headers));
	}
	
	@Test
	public void saveTabCtaConfiguration_Test4(){
		roleAccessConfigurationInputBean.setProductkey(69L);
		when(dataPluginMapper.updatedRoleAccessDetails(any(), any())).thenReturn(true);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMCIT");
		assertNotNull(roleManagementControllerV2.saveTabCtaConfiguration(roleAccessConfigurationInputBean, bindingResult, headers));
	}
	
	@Test
	public void saveTabCtaConfiguration_Test2(){
		roleAccessConfigurationInputBean.setProductkey(9L);
		when(roleManagementService.saveRoleAccessconfigurationsBasedonL3(any())).thenReturn(true);
		when(roleManagementService.getProdMastCode(any())).thenReturn("OMCREDIT");
		assertNotNull(roleManagementControllerV2.saveTabCtaConfiguration(roleAccessConfigurationInputBean, bindingResult, headers));
	}
	
	@Test
	public void cloneRoleAccessConfiguration_Test(){
		assertNotNull(roleManagementControllerV2.cloneRoleAccessConfiguration(cloneRoleAccessConfigureBean, headers));
	}
	
	@Test
	public void getTabKeyAndProductsBasedonL3_Test(){
		UserRoleBean userRoleBean = new UserRoleBean();
		TabResponse response = new TabResponse();
		when(roleManagementService.fetchTabKeyAndProducts(any())).thenReturn(response);
		when(roleManagementService.getUserRole(0, 1)).thenReturn(userRoleBean);
		assertNotNull(roleManagementControllerV2.getTabKeyAndProductsBasedonL3(roleKey, headers));
	}
}
