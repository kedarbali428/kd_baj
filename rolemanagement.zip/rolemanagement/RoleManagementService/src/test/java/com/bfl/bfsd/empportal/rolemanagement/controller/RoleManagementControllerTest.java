//package com.bfl.bfsd.empportal.rolemanagement;
//
//
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.persistence.EntityManager;
//import javax.persistence.EntityManagerFactory;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.env.Environment;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.MediaType;
//import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.TestPropertySource;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.transaction.TransactionConfiguration;
//import org.springframework.test.util.ReflectionTestUtils;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.setup.MockMvcBuilders;
//import org.springframework.transaction.annotation.Transactional;
//import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
//
//import com.bajaj.bfsd.common.BFLLoggerHeader;
//import com.bajaj.bfsd.common.BFLLoggerUtil;
//import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
//import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationBean;
//import com.bfl.bfsd.empportal.rolemanagement.controller.RoleManagementController;
//import com.bfl.bfsd.empportal.rolemanagement.dao.RoleManagementDao;
//import com.bfl.bfsd.empportal.rolemanagement.dao.impl.RoleManagementDaoImpl;
//import com.bfl.bfsd.empportal.rolemanagement.service.RoleManagementService;
//import com.bfl.bfsd.empportal.rolemanagement.service.impl.RoleManagementServiceImpl;
//import com.bfl.bfsd.empportal.rolemanagement.util.RoleManagementUtil;
//
//
//@TestPropertySource(value = { "classpath:application.properties" })
//@ContextConfiguration(classes =  com.bfl.bfsd.empportal.rolemanagement.DatabaseConfig.class)
//@Transactional
//@TransactionConfiguration(defaultRollback = true)
//@RunWith(SpringJUnit4ClassRunner.class)
//public class RoleManagementControllerTest {
//
//
//	private RoleManagementController roleMgmntController;
//	private RoleManagementService roleMgmntService;
//	private RoleManagementDao roleMgmntDao;
//	private RoleManagementUtil roleMgmntServiceUtil;
//	private  BFLLoggerUtil logger;
//	EntityManager em;
//	EntityManagerFactory entityManagerFactory;
//
//	private MockMvc mockMvc;
//
//	@Autowired
//	Environment env;
//
//	@Autowired
//	DatabaseConfig dbConfig;
//
//	@Before
//	public void setUp() {
//		roleMgmntController = new RoleManagementController();
//		roleMgmntService = new RoleManagementServiceImpl();
//		roleMgmntDao = new RoleManagementDaoImpl();
//		roleMgmntServiceUtil = new RoleManagementUtil();
//		logger = new BFLLoggerUtil();
//
//		LocalContainerEntityManagerFactoryBean localContainerEm = dbConfig.entityManagerFactory();
//		EntityManagerFactory entityManagerFact = localContainerEm.getNativeEntityManagerFactory();
//		em = entityManagerFact.createEntityManager();
//		
//		ReflectionTestUtils.setField(roleMgmntController, "roleManagementService", roleMgmntService);
//		ReflectionTestUtils.setField(roleMgmntController, "logger", logger);
//		ReflectionTestUtils.setField(roleMgmntService, "roleManagementDao", roleMgmntDao);
//		ReflectionTestUtils.setField(roleMgmntDao, "entityManager", em);
//		ReflectionTestUtils.setField(roleMgmntDao, "entityManagerFactory", entityManagerFact);
//		ReflectionTestUtils.setField(roleMgmntDao, "logger", logger);
//		this.mockMvc = MockMvcBuilders.standaloneSetup(roleMgmntController)
//				.setHandlerExceptionResolvers(createExceptionResolver())
//				.addPlaceholderValue("rolemanagement.base.url", env.getProperty("rolemanagement.base.url"))
//				.addPlaceholderValue("roleManagement.role.get.list.url",env.getProperty("roleManagement.role.get.list.url")+"?roleKey=1002")
//				.addPlaceholderValue("rolemanagement.clone.url", env.getProperty("rolemanagement.clone.url"))
//				.addPlaceholderValue("rolemanagement.tab.get.url", env.getProperty("rolemanagement.tab.get.url"))
//				.addPlaceholderValue("rolemanagement.cta.get.url", env.getProperty("rolemanagement.cta.get.url"))
//				.addPlaceholderValue("rolemanagement.uifields.get.url", env.getProperty("rolemanagement.uifields.get.url"))
//				.addPlaceholderValue("rolemanagement.role.access.configuration.url", env.getProperty("rolemanagement.role.access.configuration.url"))
//				.build();
//
//	}
//
//	
//			
//		
//	@Test
//	public void testgetTabDetails() throws Exception {
//
//
//		HttpHeaders headers = new HttpHeaders();
//		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
//		headers.add(BFLLoggerHeader.ID.getValue(), "5678");
//		try{
//			RoleAccessConfigurationBean roleAccessConfigurationBean= new RoleAccessConfigurationBean();
//			List<Long> roleKeys = new ArrayList<>();
//			roleKeys.add(81L);
//			roleAccessConfigurationBean.setRoleKeys(roleKeys);
//			roleMgmntController.getTabDetails(roleAccessConfigurationBean, headers);
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//
//	}
//
//	@Test
//	public void testgetCTADetails() throws Exception {
//
//		HttpHeaders headers = new HttpHeaders();
//		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
//		headers.add(BFLLoggerHeader.ID.getValue(), "5678");
//		try{
//			RoleAccessConfigurationBean roleAccessConfigurationBean= new RoleAccessConfigurationBean();
//			List<Long> roleKeys = new ArrayList<>();
//			roleKeys.add(81L);
//			List<Long> tabKeys = new ArrayList<>();
//			tabKeys.add(2l);
//			tabKeys.add(3L);
//			roleAccessConfigurationBean.setRoleKeys(roleKeys);
//			roleAccessConfigurationBean.setTabKeys(tabKeys);
//			roleMgmntController.getCTADetails(roleAccessConfigurationBean, headers);
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//
//	}
//
//	@Test
//	public void testgetuiFieldDetails() throws Exception {
//
//
//		HttpHeaders headers = new HttpHeaders();
//		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
//		headers.add(BFLLoggerHeader.ID.getValue(), "5678");
//		try{
//			RoleAccessConfigurationBean roleAccessConfigurationBean= new RoleAccessConfigurationBean();
//			List<Long> roleKeys = new ArrayList<>();
//			roleKeys.add(81L);
//			List<Long> tabKeys = new ArrayList<>();
//			tabKeys.add(2l);
//			tabKeys.add(3L);
//			roleAccessConfigurationBean.setRoleKeys(roleKeys);
//			roleAccessConfigurationBean.setTabKeys(tabKeys);
//			roleMgmntController.getUIFields(roleAccessConfigurationBean, headers);
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//
//	}
//	
//	@Test
//	public void testCloneRoleAccessConfig() throws Exception {
//
//
//		HttpHeaders headers = new HttpHeaders();
//		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
//		headers.add(BFLLoggerHeader.ID.getValue(), "5678");
//		try{
//			CloneRoleAccessConfigureBean cloneAccessConfigurationBean= new CloneRoleAccessConfigureBean();
//			List<Long> roleKeysFrom = new ArrayList<>();
//			List<Long> roleKeysTo = new ArrayList<>();
//			roleKeysFrom.add(81L);
//			roleKeysFrom.add(80L);
//			cloneAccessConfigurationBean.setRoleKeyFrom(roleKeysFrom);
//			cloneAccessConfigurationBean.setRoleKeysTo(roleKeysTo);
//			
//			roleMgmntController.cloneRoleAccessConfiguration(cloneAccessConfigurationBean, headers);
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//
//	}
//	@Test
//	public void testSaveRoleConfiguration() throws Exception {
//
//
//		HttpHeaders headers = new HttpHeaders();
//		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
//		headers.add(BFLLoggerHeader.ID.getValue(), "5678");
//		try{
//			
//			//roleMgmntController.saveTabCtaConfiguration(inputBean, bindingResult, headers);
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//
//	}
//	@Test
//	public void testGetUserRoles() throws Exception {
//
//
//		HttpHeaders headers = new HttpHeaders();
//		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
//		headers.add(BFLLoggerHeader.ID.getValue(), "5678");
//		try{
//			roleMgmntController.getUserRoles(81L, headers);
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//
//	}
//
//	private ExceptionHandlerExceptionResolver createExceptionResolver() {
//		return null;
//	}
//
//}
