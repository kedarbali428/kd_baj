package com.bfl.bfsd.empportal.rolemanagement.helper;

import org.junit.Test;

import com.openpojo.validation.Validator;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.rule.impl.GetterMustExistRule;
import com.openpojo.validation.rule.impl.SetterMustExistRule;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;

public class PojoTest {
	
	private String modelPackageName = "com.bfl.bfsd.empportal.rolemanagement.model";

	  @Test
	  public void validateModel() {
	    Validator validator = ValidatorBuilder.create()
	                            .with(new SetterMustExistRule(),
	                                  new GetterMustExistRule())
	                            .with(new SetterTester(),
	                                  new GetterTester())
	                            .build();
	    validator.validate(modelPackageName);
	  }

	  
	  private String beanPackageName = "com.bfl.bfsd.empportal.rolemanagement.bean";
	  @Test
	  public void validateBean() {
	    Validator validator = ValidatorBuilder.create()
	                            .with(new SetterTester(),
	                                  new GetterTester())
	                            .build();
	    validator.validate(beanPackageName);
	  }
	 
	  private String errorBeanPackageName = "com.bfl.bfsd.empportal.rolemanagement.helper";
	  @Test
	  public void validateErrorBean() {
	    Validator validator = ValidatorBuilder.create()
	                            .with(new SetterTester(),
	                                  new GetterTester())
	                            .build();
	    validator.validate(errorBeanPackageName);
	  }
	  
	  private String modelSlPackageName = "com.bfl.bfsd.empportal.rolemanagement.model.sl";
	  @Test
	  public void validateModelSl() {
	    Validator validator = ValidatorBuilder.create()
	                            .with(new SetterTester(),
	                                  new GetterTester())
	                            .build();
	    validator.validate(modelSlPackageName);
	  }
}


