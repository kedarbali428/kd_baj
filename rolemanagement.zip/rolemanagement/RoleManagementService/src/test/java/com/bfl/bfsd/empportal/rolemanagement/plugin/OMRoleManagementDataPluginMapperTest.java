package com.bfl.bfsd.empportal.rolemanagement.plugin;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;

import com.bajaj.bfdl.om.impl.EpBauClientImpl;
import com.bajaj.bfdl.om.insurance.impl.EpBauInsuranceClientImpl;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfsd.om.bean.UserMgmtTabBean;

@SpringBootTest
@SpringBootConfiguration
public class OMRoleManagementDataPluginMapperTest {

	@InjectMocks
	OMRoleManagementDataPluginMapper plugIn;
	@Mock
	private EpBauClientImpl bauClientImpl; 
	@Mock
	HttpHeaders headers;
	@Mock
	private EpBauInsuranceClientImpl bauInsClientImpl;
	Long prodMastKey = 1L;
	Long productKey = 69L;
	UserMgmtTabBean userMgmtTabBean = new UserMgmtTabBean();
	List<UserMgmtTabBean> userMgmtTabBeanList = new ArrayList<>();
	List<Long> tabKeys = new ArrayList<>();
	List<Object> objectList = new ArrayList<>();
	List<Long> roleKeys = new ArrayList<>();
	RoleAccessConfigurationInputBean roleAccessConfigurationInputBean = new RoleAccessConfigurationInputBean();
	List<Long> groupKeys = new ArrayList<>();
	List<Long> sectionKeys = new ArrayList<>();
	List<Long> subSectionKeys = new ArrayList<>();
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		tabKeys.add(1L);
		roleKeys.add(1L);
		groupKeys.add(1L);
		sectionKeys.add(1L);
		subSectionKeys.add(1L);
		
		userMgmtTabBeanList.add(userMgmtTabBean);
	}
	
	@Test
	public void getTabBeanList_Test() {
		when(bauClientImpl.getUserMgmtTabs(any(), any(),any(), any())).thenReturn(userMgmtTabBeanList);
		assertNotNull(plugIn.getTabBeanList(prodMastKey, productKey, roleKeys, headers));
	}
	
	@Test
	public void getGroupsDataList_Test() {
		when(bauClientImpl.getUserMgmtTabGroups(any(), any(), any(),any(), any())).thenReturn(objectList);
		assertNotNull(plugIn.getGroupsDataList(prodMastKey, productKey, tabKeys,roleKeys, headers));
	}
	
	@Test
	public void getCTADataList_Test() {
		when(bauClientImpl.getUserMgmtTabGroups(any(), any(), any(),any(), any())).thenReturn(objectList);
		assertNotNull(plugIn.getCTADataList(prodMastKey, productKey, tabKeys, roleKeys, headers));
	}
	
	@Test
	public void getFieldsDataList_Test() {
		when(bauClientImpl.getUserMgmtTabGroups(any(), any(), any(),any(), any())).thenReturn(objectList);
		assertNotNull(plugIn.getFieldsDataList(prodMastKey, productKey, tabKeys, roleKeys, groupKeys, sectionKeys, subSectionKeys, headers));
	}
	
	@Test
	public void getLinksDataList_Test() {
		when(bauClientImpl.getUserMgmtTabGroups(any(), any(), any(),any(), any())).thenReturn(objectList);
		assertNotNull(plugIn.getLinksDataList(tabKeys, roleKeys, headers));
	}
	
	@Test
	public void updatedRoleAccessDetails_Test() {
		when(bauClientImpl.getUserMgmtTabGroups(any(), any(), any(),any(), any())).thenReturn(objectList);
		assertNotNull(plugIn.updatedRoleAccessDetails(roleAccessConfigurationInputBean, headers));
	}
	
//	@Test
//	public void getTabBeanListOffer_Test() {
//		when(bauInsClientImpl.getUserMgmtTabsOmOffer(any(),any())).thenReturn(userMgmtTabBeanList);
//		assertNotNull(plugIn.getTabBeanListOmOffer(roleKeys, headers));
//	}
}
