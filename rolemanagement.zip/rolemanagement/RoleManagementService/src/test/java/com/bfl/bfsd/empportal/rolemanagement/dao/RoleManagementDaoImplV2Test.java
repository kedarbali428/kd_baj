package com.bfl.bfsd.empportal.rolemanagement.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.bfsd.empportal.rolemanagement.bean.CloneRoleAccessConfigureBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.FieldAccessBean;
import com.bfl.bfsd.empportal.rolemanagement.bean.RoleAccessConfigurationInputBean;
import com.bfl.bfsd.empportal.rolemanagement.constants.RoleManagementConstants;
import com.bfl.bfsd.empportal.rolemanagement.dao.impl.RoleManagementDaoImplV2;
import com.bfl.bfsd.empportal.rolemanagement.model.Links;
import com.bfl.bfsd.empportal.rolemanagement.model.sl.RoleProductMapping;

@RunWith(MockitoJUnitRunner.class)
public class RoleManagementDaoImplV2Test {

	@InjectMocks
	RoleManagementDaoImplV2 daoImpl;
	@Mock
	EntityManager entityManager;
	@Mock
	Environment env;
	@Mock
	EntityManagerFactory entityManagerFactory;
	@Mock
	BFLLoggerUtil logger;
	@Mock
	Query query;
	@Mock
	EntityTransaction entityTransaction;
	@Mock
	RoleManagementConstants constants;
	
	RoleAccessConfigurationInputBean roleAccessBean;
	List<Long> roleKeyList;
	FieldAccessBean fieldAccessBean;
	List<FieldAccessBean> fieldAccessBeans = new ArrayList<>();
	List<Long> subSectionKeys;
	List<Links> linkBeanList;
	
	CloneRoleAccessConfigureBean cloneRoleAccessConfigureBean;
	
	
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		
		cloneRoleAccessConfigureBean = new CloneRoleAccessConfigureBean();
		List<Long> roleKeyFrom = new ArrayList<>();
		List<Long> roleKeysTo = new ArrayList<>();
		roleKeyFrom.add(1L);
		roleKeysTo.add(2L);
		cloneRoleAccessConfigureBean.setRoleKeyFrom(roleKeyFrom);
		cloneRoleAccessConfigureBean.setRoleKeysTo(roleKeysTo);
		cloneRoleAccessConfigureBean.setProductkeyFrom(1L);
		cloneRoleAccessConfigureBean.setSubprodkeyFrom(1L);
		cloneRoleAccessConfigureBean.setProductkeyTo(2L);
		cloneRoleAccessConfigureBean.setSubprodkeyTo(2L);
		
		
		roleAccessBean = new RoleAccessConfigurationInputBean();
		roleAccessBean.setProductkey(69L);
		roleAccessBean.setSubprodkey(11L);
		
		roleKeyList = new ArrayList<>();
		roleKeyList.add(88L);
		roleAccessBean.setRoleKeys(roleKeyList);
		
		long rolekeys[]=new long[] {88};
		roleAccessBean.setRolekeys(rolekeys);
		
		roleAccessBean.setFunctionkey(10L);
		
		long tabIds[]=new long[] {1193};
		roleAccessBean.setTabIds(tabIds);
		
		long ctaIds[]=new long[] {147,148,149,150,62};
		roleAccessBean.setCtaIds(ctaIds);
		
		fieldAccessBean = new FieldAccessBean();
		fieldAccessBean.setFieldAccesskey(577L);
		fieldAccessBean.setFieldkey(2L);
		fieldAccessBeans.add(fieldAccessBean);
		roleAccessBean.setFieldAccessBeans(fieldAccessBeans);
		
		subSectionKeys = new ArrayList<>();
		subSectionKeys.add(67L);
		roleAccessBean.setSubSectionKeys(subSectionKeys);
		linkBeanList = new ArrayList<>();
		Links links = new Links();
		links.setTabKey(1193L);
		long linkIds [] = new long[] {1,2};
		links.setLinkIds(linkIds);
		linkBeanList.add(links);
		roleAccessBean.setLinkBeanList(linkBeanList);
	}
//	.setParameter("rolekey", BigDecimal.valueOf(10)).setParameter("subprodkey", BigDecimal.valueOf(10))
//	.setParameter("prodkey", BigDecimal.valueOf(10))
//	
//	@SuppressWarnings("unchecked")
//	@Test
	public void saveConfigurationsBasedonL3_Test() {
		RoleProductMapping roleProductMapping = new RoleProductMapping();
		List<RoleProductMapping> roleProductMappingList = new ArrayList<>();
		roleProductMappingList.add(roleProductMapping);
		
		Mockito.when(entityManager.createNamedQuery("RoleProductMapping.findAllRoleMapping")).thenReturn(query);
//		Mockito.when(entityManager.createNamedQuery("RoleProductMapping.findAllRoleMapping").setParameter(RoleManagementConstants.ROLEKEY, BigDecimal.valueOf(10L))).thenReturn(query);
//		Mockito.when(entityManager.createNamedQuery("RoleProductMapping.findAllRoleMapping").setParameter(RoleManagementConstants.ROLEKEY, BigDecimal.valueOf(10L))
//				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(11L))).thenReturn(query);
//		Mockito.when(entityManager.createNamedQuery("RoleProductMapping.findAllRoleMapping").setParameter(RoleManagementConstants.ROLEKEY, BigDecimal.valueOf(10L))
//				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(11L)).setParameter(RoleManagementConstants.PRODKEY, BigDecimal.valueOf(69L))).thenReturn(query);
//		Mockito.when(entityManager.createNamedQuery("RoleProductMapping.findAllRoleMapping").setParameter(RoleManagementConstants.ROLEKEY, BigDecimal.valueOf(10L))
//				.setParameter(RoleManagementConstants.SUBPRODKEY, BigDecimal.valueOf(11L)).setParameter(RoleManagementConstants.PRODKEY, BigDecimal.valueOf(69L))
//				.getResultList()).thenReturn(roleProductMappingList);
		Mockito.when(entityManagerFactory.createEntityManager()).thenReturn(entityManager);
		Mockito.when(entityManager.getTransaction()).thenReturn(entityTransaction);
		assertNotNull(daoImpl.saveConfigurationsBasedonL3(roleAccessBean));
	}
	
	
	@Test
	public void cloneRoleAccessConfigurationBasedonL3_Test() {
		
		assertTrue(true);
	}
}
