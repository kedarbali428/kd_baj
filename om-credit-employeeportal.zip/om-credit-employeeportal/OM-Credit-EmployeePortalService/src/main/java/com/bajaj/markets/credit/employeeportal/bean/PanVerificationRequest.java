package com.bajaj.markets.credit.employeeportal.bean;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class PanVerificationRequest {
	@NotBlank(message = "Pan Number cannot be null or empty")
	@Pattern(regexp = "[A-Za-z]{5}[0-9]{4}[A-z]{1}$")
	private String panNumber;

	private boolean forcedVerification;

	@NotBlank(message = "Application Key cannot be null or empty")
	@Pattern(regexp = "^(0|[1-9][0-9]*)$")
	private String applicationKey;

	@NotBlank(message = "Applicant Key cannot be null or empty")
	private String applicantKey;

	@NotBlank(message = "l2ProductCode can not be null")
	private String l2ProductCode;

	@NotNull
	private Long l2ProductKey;

	@NotBlank(message = "Full Name cannot be null or empty")
	private String fullName;

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public boolean isForcedVerification() {
		return forcedVerification;
	}

	public void setForcedVerification(boolean forcedVerification) {
		this.forcedVerification = forcedVerification;
	}

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getL2ProductCode() {
		return l2ProductCode;
	}

	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Long getL2ProductKey() {
		return l2ProductKey;
	}

	public void setL2ProductKey(Long l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}

	@Override
	public String toString() {
		return "PanVerificationRequest [panNumber=" + panNumber + ", forcedVerification=" + forcedVerification
				+ ", applicationKey=" + applicationKey + ", applicantKey=" + applicantKey + ", l2ProductCode="
				+ l2ProductCode + ", l2ProductKey=" + l2ProductKey + ", fullName=" + fullName + "]";
	}

}
