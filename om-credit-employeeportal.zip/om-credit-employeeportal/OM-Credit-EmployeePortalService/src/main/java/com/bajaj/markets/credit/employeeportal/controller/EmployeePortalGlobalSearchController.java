package com.bajaj.markets.credit.employeeportal.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalGlobalSearchServiceImpl;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import net.bytebuddy.build.Plugin.Engine.Summary;

@RestController
public class EmployeePortalGlobalSearchController {
	private static final String CLASSNAME = EmployeePortalGlobalSearchController.class.getName();
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	EmployeePortalGlobalSearchServiceImpl globalSearchService;
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch application summary", notes = "Fetch application summary on the basis of search criteria", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	  
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application summary found", response = Summary.class),
			@ApiResponse(code = 404, message = "application summary",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeePortal/products/CC/params/{paramname}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getCreditAppliactionSummary(@PathVariable("paramname") String paramName,final HttpServletRequest request,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getCreditAppliactionSummary method controller - parameter: "+ paramName);
		String criteria = request.getParameter("criteria");
		String value = request.getParameter("value");
		return new ResponseEntity<>(globalSearchService.fetchCreditApplicationSummary(paramName, criteria, value ,headers), HttpStatus.OK);
	}
	
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch application summary", notes = "Fetch application summary on the basis of search criteria", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	  
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application summary found", response = Summary.class),
			@ApiResponse(code = 404, message = "application summary",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeePortal/products/OMPL/params/{paramname}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getLoanAppliactionSummary(@PathVariable("paramname") String paramName,final HttpServletRequest request,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getLoanAppliactionSummary method controller - parameter: "+ paramName);
		String criteria = request.getParameter("criteria");
		String value = request.getParameter("value");
		return new ResponseEntity<>(globalSearchService.fetchCreditApplicationSummary(paramName, criteria, value,headers ), HttpStatus.OK);
	}
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch search by entities for global search", notes = "Fetch search by entities based on lookup code", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	  
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Search by entities found", response = Summary.class),
			@ApiResponse(code = 404, message = "search by entities not found",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeeportal/credit/searchbyentities", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getGlobalSearchByEntities(final HttpServletRequest request,@RequestHeader HttpHeaders headers){
		String lookupCode = request.getParameter("lookupcode");
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getGlobalSearchByEntities method controller - parameter: "+ lookupCode);
		return new ResponseEntity<>(globalSearchService.fetchGlobalSearchByEntities(lookupCode), HttpStatus.OK);
	}
	
}
