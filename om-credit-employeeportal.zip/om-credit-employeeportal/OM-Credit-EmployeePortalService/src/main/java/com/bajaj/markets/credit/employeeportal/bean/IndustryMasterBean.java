package com.bajaj.markets.credit.employeeportal.bean;

public class IndustryMasterBean {

	private Long indMastKey;
	
	private String indMastCode;
	
	private String indMastSubSectorCode;
	
	private String indMastDesc;

	/**
	 * @return the indMastKey
	 */
	public Long getIndMastKey() {
		return indMastKey;
	}

	/**
	 * @param indMastKey the indMastKey to set
	 */
	public void setIndMastKey(Long indMastKey) {
		this.indMastKey = indMastKey;
	}

	/**
	 * @return the indMastCode
	 */
	public String getIndMastCode() {
		return indMastCode;
	}

	/**
	 * @param indMastCode the indMastCode to set
	 */
	public void setIndMastCode(String indMastCode) {
		this.indMastCode = indMastCode;
	}

	/**
	 * @return the indMastSubSectorCode
	 */
	public String getIndMastSubSectorCode() {
		return indMastSubSectorCode;
	}

	/**
	 * @param indMastSubSectorCode the indMastSubSectorCode to set
	 */
	public void setIndMastSubSectorCode(String indMastSubSectorCode) {
		this.indMastSubSectorCode = indMastSubSectorCode;
	}

	/**
	 * @return the indMastDesc
	 */
	public String getIndMastDesc() {
		return indMastDesc;
	}

	/**
	 * @param indMastDesc the indMastDesc to set
	 */
	public void setIndMastDesc(String indMastDesc) {
		this.indMastDesc = indMastDesc;
	}
	
}
