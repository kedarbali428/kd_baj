package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "BFSD_USERS",schema="dmmaster")
public class BFSDUsers implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userkey;

	private BigDecimal failedlogincount;

	private BigDecimal isactive;

	private Timestamp lstfailedlogindt;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private Timestamp registrationdate;

	private BigDecimal userblockedflg;

	private BigDecimal usertype;
	
	private BigDecimal statuschngreason;
	
	@OneToMany(mappedBy="bfsdUser")
	private List<UserRoles> userRoles;

	public long getUserkey() {
		return userkey;
	}

	public void setUserkey(long userkey) {
		this.userkey = userkey;
	}

	public BigDecimal getFailedlogincount() {
		return failedlogincount;
	}

	public void setFailedlogincount(BigDecimal failedlogincount) {
		this.failedlogincount = failedlogincount;
	}

	public BigDecimal getIsactive() {
		return isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public Timestamp getLstfailedlogindt() {
		return lstfailedlogindt;
	}

	public void setLstfailedlogindt(Timestamp lstfailedlogindt) {
		this.lstfailedlogindt = lstfailedlogindt;
	}

	public String getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Timestamp getRegistrationdate() {
		return registrationdate;
	}

	public void setRegistrationdate(Timestamp registrationdate) {
		this.registrationdate = registrationdate;
	}

	public BigDecimal getUserblockedflg() {
		return userblockedflg;
	}

	public void setUserblockedflg(BigDecimal userblockedflg) {
		this.userblockedflg = userblockedflg;
	}

	public BigDecimal getUsertype() {
		return usertype;
	}

	public void setUsertype(BigDecimal usertype) {
		this.usertype = usertype;
	}

	public BigDecimal getStatuschngreason() {
		return statuschngreason;
	}

	public void setStatuschngreason(BigDecimal statuschngreason) {
		this.statuschngreason = statuschngreason;
	}

	public List<UserRoles> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(List<UserRoles> userRoles) {
		this.userRoles = userRoles;
	}
}
