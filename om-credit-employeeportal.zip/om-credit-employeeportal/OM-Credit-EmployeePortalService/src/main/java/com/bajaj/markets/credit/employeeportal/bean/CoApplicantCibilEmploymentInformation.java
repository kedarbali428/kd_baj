package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CoApplicantCibilEmploymentInformation implements Serializable {

	private static final long serialVersionUID = 1L;

	private String coapplicantName;
	private String coapplicantPan;
	private String coapplicantOccupationType;
	private String coapplicantIncome;
	private String coapplicantNetIncomeIndicator;
	private String coapplicantMonthlyAnnualIncomeIndicator;

	public String getCoapplicantName() {
		return coapplicantName;
	}

	public void setCoapplicantName(String coapplicantName) {
		this.coapplicantName = coapplicantName;
	}

	public String getCoapplicantPan() {
		return coapplicantPan;
	}

	public void setCoapplicantPan(String coapplicantPan) {
		this.coapplicantPan = coapplicantPan;
	}

	public String getCoapplicantOccupationType() {
		return coapplicantOccupationType;
	}

	public void setCoapplicantOccupationType(String coapplicantOccupationType) {
		this.coapplicantOccupationType = coapplicantOccupationType;
	}

	public String getCoapplicantIncome() {
		return coapplicantIncome;
	}

	public void setCoapplicantIncome(String coapplicantIncome) {
		this.coapplicantIncome = coapplicantIncome;
	}

	public String getCoapplicantNetIncomeIndicator() {
		return coapplicantNetIncomeIndicator;
	}

	public void setCoapplicantNetIncomeIndicator(String coapplicantNetIncomeIndicator) {
		this.coapplicantNetIncomeIndicator = coapplicantNetIncomeIndicator;
	}

	public String getCoapplicantMonthlyAnnualIncomeIndicator() {
		return coapplicantMonthlyAnnualIncomeIndicator;
	}

	public void setCoapplicantMonthlyAnnualIncomeIndicator(String coapplicantMonthlyAnnualIncomeIndicator) {
		this.coapplicantMonthlyAnnualIncomeIndicator = coapplicantMonthlyAnnualIncomeIndicator;
	}

}