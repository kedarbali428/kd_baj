package com.bajaj.markets.credit.employeeportal.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CommentDetails implements Comparable<CommentDetails>
{
	private String applicationKey;
	private String comments;
	private String userRoleKey;
	private String addedByUser;
	private String commentDate;
	/**
	 * @return the applicationKey
	 */
	public String getApplicationKey() {
		return applicationKey;
	}
	/**
	 * @param applicationKey the applicationKey to set
	 */
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return the userRoleKey
	 */
	public String getUserRoleKey() {
		return userRoleKey;
	}
	/**
	 * @param userRoleKey the userRoleKey to set
	 */
	public void setUserRoleKey(String userRoleKey) {
		this.userRoleKey = userRoleKey;
	}
	public String getAddedByUser() {
		return addedByUser;
	}
	public void setAddedByUser(String addedByUser) {
		this.addedByUser = addedByUser;
	}
	public String getCommentDate() {
		return commentDate;
	}
	public void setCommentDate(String commentDate) {
		this.commentDate = commentDate;
	}
	
	@Override
	public int compareTo(CommentDetails o) {

		try {
			Date d = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(o.getCommentDate());
			if (d.before(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(getCommentDate())))
				return -1;

			if (d.after(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(getCommentDate())))
				return 1;
			if (d.equals(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(getCommentDate())))
				return 0;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
		
}
