package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CoApplicantDedupeDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String coapplicantName;
	private String coapplicantPan;
	private String coApplicantPrincipalName;
	private String coApplicantDedupeSource;
	private String coApplicantDedupeCustType;
	private String coApplicantDedupeCustSegment;
	private String coApplicantExistingCustomerID;
	
	public String getCoapplicantName() {
		return coapplicantName;
	}
	public void setCoapplicantName(String coapplicantName) {
		this.coapplicantName = coapplicantName;
	}
	public String getCoapplicantPan() {
		return coapplicantPan;
	}
	public void setCoapplicantPan(String coapplicantPan) {
		this.coapplicantPan = coapplicantPan;
	}
	public String getCoApplicantPrincipalName() {
		return coApplicantPrincipalName;
	}
	public void setCoApplicantPrincipalName(String coApplicantPrincipalName) {
		this.coApplicantPrincipalName = coApplicantPrincipalName;
	}
	public String getCoApplicantDedupeSource() {
		return coApplicantDedupeSource;
	}
	public void setCoApplicantDedupeSource(String coApplicantDedupeSource) {
		this.coApplicantDedupeSource = coApplicantDedupeSource;
	}
	public String getCoApplicantDedupeCustType() {
		return coApplicantDedupeCustType;
	}
	public void setCoApplicantDedupeCustType(String coApplicantDedupeCustType) {
		this.coApplicantDedupeCustType = coApplicantDedupeCustType;
	}
	public String getCoApplicantDedupeCustSegment() {
		return coApplicantDedupeCustSegment;
	}
	public void setCoApplicantDedupeCustSegment(String coApplicantDedupeCustSegment) {
		this.coApplicantDedupeCustSegment = coApplicantDedupeCustSegment;
	}
	public String getCoApplicantExistingCustomerID() {
		return coApplicantExistingCustomerID;
	}
	public void setCoApplicantExistingCustomerID(String coApplicantExistingCustomerID) {
		this.coApplicantExistingCustomerID = coApplicantExistingCustomerID;
	}
	
}