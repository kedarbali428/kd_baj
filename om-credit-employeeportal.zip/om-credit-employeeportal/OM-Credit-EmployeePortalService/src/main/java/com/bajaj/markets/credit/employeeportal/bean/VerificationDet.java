package com.bajaj.markets.credit.employeeportal.bean;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class VerificationDet {

	private boolean isVerified;
	private String verifiedBy;
	private String verifiedFor;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date verificationDate;
	
	public boolean isVerified() {
		return isVerified;
	}
	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}
	public String getVerifiedBy() {
		return verifiedBy;
	}
	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}
	public String getVerifiedFor() {
		return verifiedFor;
	}
	public void setVerifiedFor(String verifiedFor) {
		this.verifiedFor = verifiedFor;
	}
	public Date getVerificationDate() {
		return verificationDate;
	}
	public void setVerificationDate(Date verificationDate) {
		this.verificationDate = verificationDate;
	}
	
	
}
