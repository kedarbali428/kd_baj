package com.bajaj.markets.credit.employeeportal.bean;

public enum Status {
	INITIAITED, COMPLETED, NOT_INITIAITED, SUSPENDED,DEFAULT

}
