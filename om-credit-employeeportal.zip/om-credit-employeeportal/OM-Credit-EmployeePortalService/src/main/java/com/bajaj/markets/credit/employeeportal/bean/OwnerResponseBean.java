package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class OwnerResponseBean implements Serializable{

	private static final long serialVersionUID = 1L;
	private String userName;
	private long userrolekey;
	private long rolekey;
	private long userkey;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public long getUserrolekey() {
		return userrolekey;
	}
	public void setUserrolekey(long userrolekey) {
		this.userrolekey = userrolekey;
	}
	public long getRolekey() {
		return rolekey;
	}
	public void setRolekey(long rolekey) {
		this.rolekey = rolekey;
	}
	public long getUserkey() {
		return userkey;
	}
	public void setUserkey(long userkey) {
		this.userkey = userkey;
	}
}
