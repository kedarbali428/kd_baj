package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_nominee", schema = "dmvas")
public class AppNominee implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_nominee_nomineekey_generator", sequenceName = "dmvas.seq_pk_app_nominee", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_nominee_nomineekey_generator")
	private Integer nomineekey;
	private String name;
	private Date dateofbirth;
	private Long applicationkey;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private Integer relationcodemastkey;

	public Integer getNomineekey() {
		return nomineekey;
	}

	public void setNomineekey(Integer nomineekey) {
		this.nomineekey = nomineekey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Integer getRelationcodemastkey() {
		return relationcodemastkey;
	}

	public void setRelationcodemastkey(Integer relationcodemastkey) {
		this.relationcodemastkey = relationcodemastkey;
	}

}
