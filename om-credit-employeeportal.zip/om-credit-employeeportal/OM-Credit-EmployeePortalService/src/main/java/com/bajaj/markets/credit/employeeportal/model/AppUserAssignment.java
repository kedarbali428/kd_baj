package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the APP_USER_ASSIGNMENT database table.
 * 
 */
@Entity
@Table(name="app_user_assignment", schema = "dmcredit")
public class AppUserAssignment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long assignmentkey;

	private BigDecimal appstatus;

	private Timestamp appstatustm;

	private String assigncomments;

	private BigDecimal assignedby;

	private Timestamp assignenddt;

	private Timestamp assignstrtdt;

	private BigDecimal assigntoflg;

	private BigDecimal isactive;

	private Integer lstupdateby;

	private Timestamp lstupdatedt;

	private Long rolekey;

	private Long userrolekey;
	
	private Long applsubstagekey;

	@ManyToOne
	@JoinColumn(name="applicationkey", nullable=false) 
	private Application  application;
	
	public long getAssignmentkey() {
		return this.assignmentkey;
	}

	public void setAssignmentkey(long assignmentkey) {
		this.assignmentkey = assignmentkey;
	}


	public BigDecimal getAppstatus() {
		return this.appstatus;
	}

	public void setAppstatus(BigDecimal appstatus) {
		this.appstatus = appstatus;
	}

	public Timestamp getAppstatustm() {
		return this.appstatustm;
	}

	public void setAppstatustm(Timestamp appstatustm) {
		this.appstatustm = appstatustm;
	}

	public String getAssigncomments() {
		return this.assigncomments;
	}

	public void setAssigncomments(String assigncomments) {
		this.assigncomments = assigncomments;
	}

	public BigDecimal getAssignedby() {
		return this.assignedby;
	}

	public void setAssignedby(BigDecimal assignedby) {
		this.assignedby = assignedby;
	}

	public Timestamp getAssignenddt() {
		return this.assignenddt;
	}

	public void setAssignenddt(Timestamp assignenddt) {
		this.assignenddt = assignenddt;
	}

	public Timestamp getAssignstrtdt() {
		return this.assignstrtdt;
	}

	public void setAssignstrtdt(Timestamp assignstrtdt) {
		this.assignstrtdt = assignstrtdt;
	}

	public BigDecimal getAssigntoflg() {
		return this.assigntoflg;
	}

	public void setAssigntoflg(BigDecimal assigntoflg) {
		this.assigntoflg = assigntoflg;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public Integer getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Integer lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getRolekey() {
		return this.rolekey;
	}

	public void setRolekey(Long rolekey) {
		this.rolekey = rolekey;
	}

	public Long getUserrolekey() {
		return this.userrolekey;
	}

	public void setUserrolekey(Long userrolekey) {
		this.userrolekey = userrolekey;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Long getApplsubstagekey() {
		return applsubstagekey;
	}

	public void setApplsubstagekey(Long applsubstagekey) {
		this.applsubstagekey = applsubstagekey;
	}

	
	/*public List<AppAppointment> getAppAppointments() {
		return this.appAppointments;
	}

	public void setAppAppointments(List<AppAppointment> appAppointments) {
		this.appAppointments = appAppointments;
	}

	public AppAppointment addAppAppointment(AppAppointment appAppointment) {
		getAppAppointments().add(appAppointment);
		appAppointment.setAppUserAssignment(this);

		return appAppointment;
	}

	public AppAppointment removeAppAppointment(AppAppointment appAppointment) {
		getAppAppointments().remove(appAppointment);
		appAppointment.setAppUserAssignment(null);

		return appAppointment;
	}*/

	
}