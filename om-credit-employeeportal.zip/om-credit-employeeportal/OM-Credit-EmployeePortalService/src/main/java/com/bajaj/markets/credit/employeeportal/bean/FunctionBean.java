package com.bajaj.markets.credit.employeeportal.bean;

public class FunctionBean {
	private Integer functionkey;
	private Integer functioncd;
	private String functiondesc;
	public Integer getFunctionkey() {
		return functionkey;
	}
	public void setFunctionkey(Integer functionkey) {
		this.functionkey = functionkey;
	}
	public Integer getFunctioncd() {
		return functioncd;
	}
	public void setFunctioncd(Integer functioncd) {
		this.functioncd = functioncd;
	}
	public String getFunctiondesc() {
		return functiondesc;
	}
	public void setFunctiondesc(String functiondesc) {
		this.functiondesc = functiondesc;
	}

}
