package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import javax.validation.constraints.NotNull;

/**
 * 
 * 
 *
 */
public class Group{

	@NotNull(message = "sectionId can not be null")
	private Integer groupId;
	
	//TODO - change group name to string
	@NotNull(message = "groupName can not be null")
	private String groupName;
	
	private String source;
	
	private List<Section> sectionList;
	
	


	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * @return the sectionList
	 */
	public List<Section> getSectionList() {
		return sectionList;
	}

	/**
	 * @param sectionList the sectionList to set
	 */
	public void setSectionList(List<Section> sectionList) {
		this.sectionList = sectionList;
	}

	/**
	 * @return the groupId
	 */
	public Integer getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}


	
}
