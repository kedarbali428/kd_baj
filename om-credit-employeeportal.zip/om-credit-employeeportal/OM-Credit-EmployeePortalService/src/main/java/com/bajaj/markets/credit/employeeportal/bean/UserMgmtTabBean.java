package com.bajaj.markets.credit.employeeportal.bean;

public class UserMgmtTabBean {
	private String name;
	private String tabKey;
	private String prodMastKey;
	private String tabCd;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the tabKey
	 */
	public String getTabKey() {
		return tabKey;
	}
	/**
	 * @param tabKey the tabKey to set
	 */
	public void setTabKey(String tabKey) {
		this.tabKey = tabKey;
	}
	/**
	 * @return the prodMastKey
	 */
	public String getProdMastKey() {
		return prodMastKey;
	}
	/**
	 * @param prodMastKey the prodMastKey to set
	 */
	public void setProdMastKey(String prodMastKey) {
		this.prodMastKey = prodMastKey;
	}
	/**
	 * @return the tabCd
	 */
	public String getTabCd() {
		return tabCd;
	}
	/**
	 * @param tabCd the tabCd to set
	 */
	public void setTabCd(String tabCd) {
		this.tabCd = tabCd;
	}
	
	
}
