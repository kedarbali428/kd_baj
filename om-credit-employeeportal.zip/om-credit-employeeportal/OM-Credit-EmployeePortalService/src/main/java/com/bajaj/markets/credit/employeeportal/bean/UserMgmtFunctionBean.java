package com.bajaj.markets.credit.employeeportal.bean;

public class UserMgmtFunctionBean {
	private String name;
	private String key;
	private String code;
	private String description;
	private String productRef;
	private String productMasterRef;
	private String productCategoryRef;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}
	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the productRef
	 */
	public String getProductRef() {
		return productRef;
	}
	/**
	 * @param productRef the productRef to set
	 */
	public void setProductRef(String productRef) {
		this.productRef = productRef;
	}
	/**
	 * @return the productMasterRef
	 */
	public String getProductMasterRef() {
		return productMasterRef;
	}
	/**
	 * @param productMasterRef the productMasterRef to set
	 */
	public void setProductMasterRef(String productMasterRef) {
		this.productMasterRef = productMasterRef;
	}
	/**
	 * @return the productCategoryRef
	 */
	public String getProductCategoryRef() {
		return productCategoryRef;
	}
	/**
	 * @param productCategoryRef the productCategoryRef to set
	 */
	public void setProductCategoryRef(String productCategoryRef) {
		this.productCategoryRef = productCategoryRef;
	}
	

}
