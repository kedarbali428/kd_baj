package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

public class UIFieldBean {

	private Long fieldkey;
	private String fieldName;
	private String sectionName;
	private BigDecimal accessLevel;
	private boolean selected;
	private Integer sectionId ;
	private Long subSectionId ;
	private Long displayOrder ;
	private BigDecimal fieldcd;
	/**
	 * @return the fieldkey
	 */
	public Long getFieldkey() {
		return fieldkey;
	}
	/**
	 * @param fieldkey the fieldkey to set
	 */
	public void setFieldkey(Long fieldkey) {
		this.fieldkey = fieldkey;
	}
	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}
	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	/**
	 * @return the sectionName
	 */
	public String getSectionName() {
		return sectionName;
	}
	/**
	 * @param sectionName the sectionName to set
	 */
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	/**
	 * @return the accessLevel
	 */
	public BigDecimal getAccessLevel() {
		return accessLevel;
	}
	/**
	 * @param accessLevel the accessLevel to set
	 */
	public void setAccessLevel(BigDecimal accessLevel) {
		this.accessLevel = accessLevel;
	}
	/**
	 * @return the selected
	 */
	public boolean isSelected() {
		return selected;
	}
	/**
	 * @param selected the selected to set
	 */
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	/**
	 * @return the sectionId
	 */
	public Integer getSectionId() {
		return sectionId;
	}
	/**
	 * @param sectionId the sectionId to set
	 */
	public void setSectionId(Integer sectionId) {
		this.sectionId = sectionId;
	}
	/**
	 * @return the subSectionId
	 */
	public Long getSubSectionId() {
		return subSectionId;
	}
	/**
	 * @param subSectionId the subSectionId to set
	 */
	public void setSubSectionId(Long subSectionId) {
		this.subSectionId = subSectionId;
	}
	/**
	 * @return the displayOrder
	 */
	public Long getDisplayOrder() {
		return displayOrder;
	}
	/**
	 * @param displayOrder the displayOrder to set
	 */
	public void setDisplayOrder(Long displayOrder) {
		this.displayOrder = displayOrder;
	}
	/**
	 * @return the fieldcd
	 */
	public BigDecimal getFieldcd() {
		return fieldcd;
	}
	/**
	 * @param fieldcd the fieldcd to set
	 */
	public void setFieldcd(BigDecimal fieldcd) {
		this.fieldcd = fieldcd;
	}
	

}
