package com.bajaj.markets.credit.employeeportal.bean;

public class KycResponse {

	
	private Payload  payload;
	
	private String status;
	
	private String errorBean;

	public Payload getPayload() {
		return payload;
	}

	public void setPayload(Payload payload) {
		this.payload = payload;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorBean() {
		return errorBean;
	}

	public void setErrorBean(String errorBean) {
		this.errorBean = errorBean;
	}

	@Override
	public String toString() {
		return "KycResponse [payload=" + payload + ", status=" + status + ", errorBean=" + errorBean + "]";
	}
	
	
	


}
