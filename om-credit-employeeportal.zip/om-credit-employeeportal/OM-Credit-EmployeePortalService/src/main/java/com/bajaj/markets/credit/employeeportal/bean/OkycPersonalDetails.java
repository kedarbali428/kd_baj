package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.util.Date;

public class OkycPersonalDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	private String customerFirstName;
	private String customerLastName;
	private Long mobile;
	private String emailAddress;
	private Date dateOfBirth;
	private String gender;
	private String permAddressLineOne;
	private String permAddressLineTwo;
	private String city;
	private Integer pincodeKey;
	private String stateName;

	public String getCustomerFirstName() {
		return customerFirstName;
	}

	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public String getCustomerLastName() {
		return customerLastName;
	}

	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPermAddressLineOne() {
		return permAddressLineOne;
	}

	public void setPermAddressLineOne(String permAddressLineOne) {
		this.permAddressLineOne = permAddressLineOne;
	}

	public String getPermAddressLineTwo() {
		return permAddressLineTwo;
	}

	public void setPermAddressLineTwo(String permAddressLineTwo) {
		this.permAddressLineTwo = permAddressLineTwo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(Integer pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

}
