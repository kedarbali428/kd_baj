package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class DeviationCodeBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer devaitionCodeKey;
	
	private String deviationCode;

	private String deviationDesc;

	public Integer getDevaitionCodeKey() {
		return devaitionCodeKey;
	}

	public void setDevaitionCodeKey(Integer devaitionCodeKey) {
		this.devaitionCodeKey = devaitionCodeKey;
	}

	public String getDeviationCode() {
		return deviationCode;
	}

	public void setDeviationCode(String deviationCode) {
		this.deviationCode = deviationCode;
	}

	public String getDeviationDesc() {
		return deviationDesc;
	}

	public void setDeviationDesc(String deviationDesc) {
		this.deviationDesc = deviationDesc;
	}
	
	@Override
	public String toString() {
		return "DeviationCodeBean [devaitionCodeKey=" + devaitionCodeKey + ", deviationCode=" + deviationCode
				+ ", deviationDesc=" + deviationDesc + "]";
	}
	
}
