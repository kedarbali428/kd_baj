package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the app_occupation_detail database table.
 * 
 */
@Entity
@Table(name = "app_occupation_detail", schema = "dmcredit")
public class AppSalariedDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_occupation_detail_appoccupationkey_generator", sequenceName = "dmcredit.seq_pk_app_occupation_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_occupation_detail_appoccupationkey_generator")
	private Long appoccupationkey;

	private Long appattrbkey;

	private Integer declaredexperience;

	private Long declaredincome;

	private Long emplrdesigkey;

	private Long emprmastid;

	private Integer finalexperience;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long netmonthlysalary;

	private Long occupationtype;

	private Long perfiosincome;

	private Long smsincome;

	private String empnameforoth;

	private String designforoth;

	private String industryother;

	private Long emplrtype;

	private Integer currentexperience;

	/*
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "occupationtype") private OccupationMaster
	 * occupationMaster;
	 */
	public Long getAppoccupationkey() {
		return appoccupationkey;
	}

	public void setAppoccupationkey(Long appoccupationkey) {
		this.appoccupationkey = appoccupationkey;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Integer getDeclaredexperience() {
		return declaredexperience;
	}

	public void setDeclaredexperience(Integer declaredexperience) {
		this.declaredexperience = declaredexperience;
	}

	public Long getDeclaredincome() {
		return declaredincome;
	}

	public void setDeclaredincome(Long declaredincome) {
		this.declaredincome = declaredincome;
	}

	public Long getEmplrdesigkey() {
		return emplrdesigkey;
	}

	public void setEmplrdesigkey(Long emplrdesigkey) {
		this.emplrdesigkey = emplrdesigkey;
	}

	public Long getEmprmastid() {
		return emprmastid;
	}

	public void setEmprmastid(Long emprmastid) {
		this.emprmastid = emprmastid;
	}

	public Integer getFinalexperience() {
		return finalexperience;
	}

	public void setFinalexperience(Integer finalexperience) {
		this.finalexperience = finalexperience;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getNetmonthlysalary() {
		return netmonthlysalary;
	}

	public void setNetmonthlysalary(Long netmonthlysalary) {
		this.netmonthlysalary = netmonthlysalary;
	}

//	public Long getOccupationtype() {
//		return occupationtype;
//	}
//
//	public void setOccupationtype(Long occupationtype) {
//		this.occupationtype = occupationtype;
//	}

	public Long getPerfiosincome() {
		return perfiosincome;
	}

	public void setPerfiosincome(Long perfiosincome) {
		this.perfiosincome = perfiosincome;
	}

	public Long getSmsincome() {
		return smsincome;
	}

	public void setSmsincome(Long smsincome) {
		this.smsincome = smsincome;
	}

	public String getEmpnameforoth() {
		return empnameforoth;
	}

	public void setEmpnameforoth(String empnameforoth) {
		this.empnameforoth = empnameforoth;
	}

	public String getDesignforoth() {
		return designforoth;
	}

	public void setDesignforoth(String designforoth) {
		this.designforoth = designforoth;
	}

	public String getIndustryother() {
		return industryother;
	}

	public void setIndustryother(String industryother) {
		this.industryother = industryother;
	}

	public Long getOccupationtype() {
		return occupationtype;
	}

	public void setOccupationtype(Long occupationtype) {
		this.occupationtype = occupationtype;
	}

	/**
	 * @return the emplrtype
	 */
	public Long getEmplrtype() {
		return emplrtype;
	}

	/**
	 * @param emplrtype the emplrtype to set
	 */
	public void setEmplrtype(Long emplrtype) {
		this.emplrtype = emplrtype;
	}

	public Integer getCurrentexperience() {
		return currentexperience;
	}

	public void setCurrentexperience(Integer currentexperience) {
		this.currentexperience = currentexperience;
	}

}