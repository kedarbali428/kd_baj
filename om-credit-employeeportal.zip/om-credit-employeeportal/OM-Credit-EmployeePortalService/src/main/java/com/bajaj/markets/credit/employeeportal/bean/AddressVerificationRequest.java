package com.bajaj.markets.credit.employeeportal.bean;

public class AddressVerificationRequest {

	private Integer permentAddressRequired;
	private Integer officeAddressRequired;
	private Integer docuemntPickatResidence;
	private Integer documentPickatOffice;
	private Integer qualifiedforstp;
	private Integer videoPdRequiredFlag;
	
	public Integer getVideoPdRequiredFlag() {
		return videoPdRequiredFlag;
	}
	public void setVideoPdRequiredFlag(Integer videoPdRequiredFlag) {
		this.videoPdRequiredFlag = videoPdRequiredFlag;
	}
	public Integer getPermentAddressRequired() {
		return permentAddressRequired;
	}
	public void setPermentAddressRequired(Integer permentAddressRequired) {
		this.permentAddressRequired = permentAddressRequired;
	}
	public Integer getOfficeAddressRequired() {
		return officeAddressRequired;
	}
	public void setOfficeAddressRequired(Integer officeAddressRequired) {
		this.officeAddressRequired = officeAddressRequired;
	}
	public Integer getDocuemntPickatResidence() {
		return docuemntPickatResidence;
	}
	public void setDocuemntPickatResidence(Integer docuemntPickatResidence) {
		this.docuemntPickatResidence = docuemntPickatResidence;
	}
	public Integer getDocumentPickatOffice() {
		return documentPickatOffice;
	}
	public void setDocumentPickatOffice(Integer documentPickatOffice) {
		this.documentPickatOffice = documentPickatOffice;
	}
	public Integer getQualifiedforstp() {
		return qualifiedforstp;
	}
	public void setQualifiedforstp(Integer qualifiedforstp) {
		this.qualifiedforstp = qualifiedforstp;
	}
	
}
