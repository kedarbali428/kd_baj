package com.bajaj.markets.credit.employeeportal.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Persistence class for application_address table
 * 
 * @author bflrdpuser1
 *
 */
@Entity
@Table(name = "application_address", schema = "dmcredit")
public class ApplicationAddress {

	@Id
	@SequenceGenerator(name = "application_address_addrkey_generator", sequenceName = "dmcredit.seq_pk_application_address", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_address_addrkey_generator")
	private Long addrkey;

	private Long addrtypkey;

	private Long statekey;

	private Long citykey;

	private Long pincodekey;

	private Long countryKey;

	private Timestamp effstartdt;

	private Timestamp effenddt;

	private String addrsrc;

	private String street;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long appattrbkey;

	private String addressline1;

	private String addressline2;

	private Long localitykey;

	// private String addressline3;

	private Integer prefferedflg;
	
	private Long ovddockey;
	
	private String ovddocvalue;
	
	public Long getAddrkey() {
		return addrkey;
	}

	public void setAddrkey(Long addrkey) {
		this.addrkey = addrkey;
	}

	public Long getAddrtypkey() {
		return addrtypkey;
	}

	public void setAddrtypkey(Long addrtypkey) {
		this.addrtypkey = addrtypkey;
	}

	public Long getStatekey() {
		return statekey;
	}

	public void setStatekey(Long statekey) {
		this.statekey = statekey;
	}

	public Long getCitykey() {
		return citykey;
	}

	public void setCitykey(Long citykey) {
		this.citykey = citykey;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}

	public Timestamp getEffstartdt() {
		return effstartdt;
	}

	public void setEffstartdt(Timestamp effstartdt) {
		this.effstartdt = effstartdt;
	}

	public Timestamp getEffenddt() {
		return effenddt;
	}

	public void setEffenddt(Timestamp effenddt) {
		this.effenddt = effenddt;
	}

	public String getAddrsrc() {
		return addrsrc;
	}

	public void setAddrsrc(String addrsrc) {
		this.addrsrc = addrsrc;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Long getCountryKey() {
		return countryKey;
	}

	public void setCountryKey(Long countryKey) {
		this.countryKey = countryKey;
	}

	public String getAddressline1() {
		return addressline1;
	}

	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	public String getAddressline2() {
		return addressline2;
	}

	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}

	public Long getLocalitykey() {
		return localitykey;
	}

	public void setLocalitykey(Long localitykey) {
		this.localitykey = localitykey;
	}

	/**
	 * @return the street
	 */
	public String getStreet() {
		return street;
	}

	/**
	 * @param street the street to set
	 */
	public void setStreet(String street) {
		this.street = street;
	}

	public Integer getPrefferedflg() {
		return prefferedflg;
	}

	public void setPrefferedflg(Integer prefferedflg) {
		this.prefferedflg = prefferedflg;
	}

	public Long getOvddockey() {
		return ovddockey;
	}

	public void setOvddockey(Long ovddockey) {
		this.ovddockey = ovddockey;
	}

	public String getOvddocvalue() {
		return ovddocvalue;
	}

	public void setOvddocvalue(String ovddocvalue) {
		this.ovddocvalue = ovddocvalue;
	}

//	/**
//	 * @return the addressline3
//	 */
//	public String getAddressline3() {
//		return addressline3;
//	}
//
//	/**
//	 * @param addressline3 the addressline3 to set
//	 */
//	public void setAddressline3(String addressline3) {
//		this.addressline3 = addressline3;
//	}
	
}
