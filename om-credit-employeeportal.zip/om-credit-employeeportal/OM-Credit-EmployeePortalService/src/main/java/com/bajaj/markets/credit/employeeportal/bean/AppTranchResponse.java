package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.util.List;


public class AppTranchResponse implements Serializable{

	
	private static final long serialVersionUID = 1L;

	private Integer loanAmount;
	
	private Integer netDisburseAmount;
	
	private Integer amountDisbursedTillNow;
	
	private String loanAccountNumber;
	
	private long applicationId;
	
	private List<TranchBean> applicationTranches;
	
	private boolean zeroAmtDisbursement;

	public Integer getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(Integer loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Integer getNetDisburseAmount() {
		return netDisburseAmount;
	}

	public void setNetDisburseAmount(Integer netDisburseAmount) {
		this.netDisburseAmount = netDisburseAmount;
	}

	public Integer getAmountDisbursedTillNow() {
		return amountDisbursedTillNow;
	}

	public void setAmountDisbursedTillNow(Integer amountDisbursedTillNow) {
		this.amountDisbursedTillNow = amountDisbursedTillNow;
	}

	public String getLoanAccountNumber() {
		return loanAccountNumber;
	}

	public void setLoanAccountNumber(String loanAccountNumber) {
		this.loanAccountNumber = loanAccountNumber;
	}

	public long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public List<TranchBean> getApplicationTranches() {
		return applicationTranches;
	}

	public void setApplicationTranches(List<TranchBean> applicationTranches) {
		this.applicationTranches = applicationTranches;
	}

	public boolean isZeroAmtDisbursement() {
		return zeroAmtDisbursement;
	}

	public void setZeroAmtDisbursement(boolean zeroAmtDisbursement) {
		this.zeroAmtDisbursement = zeroAmtDisbursement;
	}
	
	
	
	
}
