package com.bajaj.markets.credit.employeeportal.bean;

import java.sql.Timestamp;

public class DeviationDetails {
	private String appdeviationcd;
	private String appdeviationdscr;
	private String deviationauthority;
	private Timestamp createdtm;
	private String deviationProduct;
	private String deviationAddedBy;
	private String prodkey;
	private String applicationid;
	private String deviationcd;
	
	public String getAppdeviationcd() {
		return appdeviationcd;
	}
	public void setAppdeviationcd(String appdeviationcd) {
		this.appdeviationcd = appdeviationcd;
	}
	public String getAppdeviationdscr() {
		return appdeviationdscr;
	}
	public void setAppdeviationdscr(String appdeviationdscr) {
		this.appdeviationdscr = appdeviationdscr;
	}
	public String getDeviationauthority() {
		return deviationauthority;
	}
	public void setDeviationauthority(String deviationauthority) {
		this.deviationauthority = deviationauthority;
	}
	public Timestamp getCreatedtm() {
		return createdtm;
	}
	public void setCreatedtm(Timestamp createdtm) {
		this.createdtm = createdtm;
	}
	public String getDeviationProduct() {
		return deviationProduct;
	}
	public void setDeviationProduct(String deviationProduct) {
		this.deviationProduct = deviationProduct;
	}
	public String getDeviationAddedBy() {
		return deviationAddedBy;
	}
	public void setDeviationAddedBy(String deviationAddedBy) {
		this.deviationAddedBy = deviationAddedBy;
	}
	public String getProdkey() {
		return prodkey;
	}
	public void setProdkey(String prodkey) {
		this.prodkey = prodkey;
	}
	public String getApplicationid() {
		return applicationid;
	}
	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}
	public String getDeviationcd() {
		return deviationcd;
	}
	public void setDeviationcd(String deviationcd) {
		this.deviationcd = deviationcd;
	}
	
}
