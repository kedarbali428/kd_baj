package com.bajaj.markets.credit.employeeportal.bean;


import java.math.BigDecimal;

public class IntervalFeeBean {
	
	private String feeCode;
	private BigDecimal feeAmount;
	private BigDecimal waiverAmount;
	private BigDecimal paidAmount;
	private boolean active;
	
	public String getFeeCode() {
		return feeCode;
	}
	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}
	public BigDecimal getFeeAmount() {
		return feeAmount;
	}
	public void setFeeAmount(BigDecimal feeAmount) {
		this.feeAmount = feeAmount;
	}
	public BigDecimal getWaiverAmount() {
		return waiverAmount;
	}
	public void setWaiverAmount(BigDecimal waiverAmount) {
		this.waiverAmount = waiverAmount;
	}
	public BigDecimal getPaidAmount() {
		return paidAmount;
	}
	public void setPaidAmount(BigDecimal paidAmount) {
		this.paidAmount = paidAmount;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	
	

}
