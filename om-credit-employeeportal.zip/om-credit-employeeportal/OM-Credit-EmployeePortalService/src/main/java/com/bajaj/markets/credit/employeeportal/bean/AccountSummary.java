package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountSummary {
	private List<String> bankNames;
	private String numOfBanks;
	private String numOfAccount;
	private SalaryAccountDet salaryAccountDet;

	public List<String> getBankNames() {
		return bankNames;
	}

	public void setBankNames(List<String> bankNames) {
		this.bankNames = bankNames;
	}

	public String getNumOfBanks() {
		return numOfBanks;
	}

	public void setNumOfBanks(String numOfBanks) {
		this.numOfBanks = numOfBanks;
	}

	public String getNumOfAccount() {
		return numOfAccount;
	}

	public void setNumOfAccount(String numOfAccount) {
		this.numOfAccount = numOfAccount;
	}

	public SalaryAccountDet getSalaryAccountDet() {
		return salaryAccountDet;
	}

	public void setSalaryAccountDet(SalaryAccountDet salaryAccountDet) {
		this.salaryAccountDet = salaryAccountDet;
	}
}
