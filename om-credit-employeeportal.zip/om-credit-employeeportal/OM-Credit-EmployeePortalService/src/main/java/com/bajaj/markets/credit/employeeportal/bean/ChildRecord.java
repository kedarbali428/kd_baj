package com.bajaj.markets.credit.employeeportal.bean;

public class ChildRecord 
{
	private Long childApplicationId;
	private String l3product;
	private String appsubstage;
	private String appstagestatus;
	private Integer appstagecompletionper;
	private String prodCode;
	private Boolean inProgress;
	private Long productKey;
	
	
	public Long getChildApplicationId() {
		return childApplicationId;
	}

	public void setChildApplicationId(Long childApplicationId) {
		this.childApplicationId = childApplicationId;
	}

	public String getL3product() {
		return l3product;
	}

	public void setL3product(String l3product) {
		this.l3product = l3product;
	}


	public String getAppsubstage() {
		return appsubstage;
	}

	public void setAppsubstage(String appsubstage) {
		this.appsubstage = appsubstage;
	}

	public String getAppstagestatus() {
		return appstagestatus;
	}

	public void setAppstagestatus(String appstagestatus) {
		this.appstagestatus = appstagestatus;
	}

	public Integer getAppstagecompletionper() {
		return appstagecompletionper;
	}

	public void setAppstagecompletionper(Integer appstagecompletionper) {
		this.appstagecompletionper = appstagecompletionper;
	}
	

	public String getProdCode() {
		return prodCode;
	}

	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}

	/**
	 * @return the inProgress
	 */
	public Boolean getInProgress() {
		return inProgress;
	}

	/**
	 * @param inProgress the inProgress to set
	 */
	public void setInProgress(Boolean inProgress) {
		this.inProgress = inProgress;
	}

	/**
	 * @return the productKey
	 */
	public Long getProductKey() {
		return productKey;
	}

	/**
	 * @param productKey the productKey to set
	 */
	public void setProductKey(Long productKey) {
		this.productKey = productKey;
	}
}
