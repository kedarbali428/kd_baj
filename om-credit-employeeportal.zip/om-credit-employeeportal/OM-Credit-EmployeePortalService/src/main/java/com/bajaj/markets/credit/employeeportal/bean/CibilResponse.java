package com.bajaj.markets.credit.employeeportal.bean;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value = Include.NON_NULL)
public class CibilResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long cibilReferenceNumber;
	private String provider;
	private Long applicantKey;
	private Long applicationKey;
	private boolean authenticationRequired;
	private String state;
	private String cibilReport;

	public long getCibilReferenceNumber() {
		return cibilReferenceNumber;
	}

	public void setCibilReferenceNumber(long cibilReferenceNumber) {
		this.cibilReferenceNumber = cibilReferenceNumber;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public boolean isAuthenticationRequired() {
		return authenticationRequired;
	}

	public void setAuthenticationRequired(boolean authenticationRequired) {
		this.authenticationRequired = authenticationRequired;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCibilReport() {
		return cibilReport;
	}

	public void setCibilReport(String cibilReport) {
		this.cibilReport = cibilReport;
	}

	@Override
	public String toString() {
		return "CibilReference [cibilReferenceNumber=" + cibilReferenceNumber + ", provider=" + provider
				+ ", applicantKey=" + applicantKey + ", applicationKey=" + applicationKey + ", authenticationRequired="
				+ authenticationRequired + ", state=" + state + ", cibilReport=" + cibilReport + "]";
	}

}
