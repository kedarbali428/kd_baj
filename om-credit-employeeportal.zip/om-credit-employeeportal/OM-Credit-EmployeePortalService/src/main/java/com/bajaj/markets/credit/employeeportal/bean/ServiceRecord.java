package com.bajaj.markets.credit.employeeportal.bean;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceRecord {
	@Id
	private Object id;
	@Indexed
	private String applicationKey;
	private Long applicantKey;
	private String cif;
	private String beneficiaryID;
	private String collateralRef; 
	private String businessPan;
	private String _class;	
	private String customerLoanId;
	public Object getId() {
		return id;
	}

	public void setId(Object id) {
		this.id = id;
	}
	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public String getBeneficiaryID() {
		return beneficiaryID;
	}
	public void setBeneficiaryID(String beneficiaryID) {
		this.beneficiaryID = beneficiaryID;
	}
	public String getCollateralRef() {
		return collateralRef;
	}
	public void setCollateralRef(String collateralRef) {
		this.collateralRef = collateralRef;
	}
	public String getBusinessPan() {
		return businessPan;
	}
	public void setBusinessPan(String businessPan) {
		this.businessPan = businessPan;
	}
	public String get_class() {
		return _class;
	}
	public void set_class(String _class) {
		this._class = _class;
	}

	public String getCustomerLoanId() {
		return customerLoanId;
	}

	public void setCustomerLoanId(String customerLoanId) {
		this.customerLoanId = customerLoanId;
	}
}