package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_audit_detail", schema = "dmcredit")
public class AppAuditDetail implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@SequenceGenerator(name = "app_audit_detail_appauditdetkey_generator", sequenceName = "dmcredit.seq_pk_app_audit_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_audit_detail_appauditdetkey_generator")
	private Long appauditdetkey;
	private Long applicationkey;
	private Long appstagecompletionper;
	private String fieldname;
	private String fieldcode;
	private String oldfieldvalue;
	private String newfieldvalue;
	private Long updatedby;
	private Timestamp updatedt;
	public Long getAppauditdetkey() {
		return appauditdetkey;
	}
	public void setAppauditdetkey(Long appauditdetkey) {
		this.appauditdetkey = appauditdetkey;
	}
	public Long getApplicationkey() {
		return applicationkey;
	}
	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}
	public Long getAppstagecompletionper() {
		return appstagecompletionper;
	}
	public void setAppstagecompletionper(Long appstagecompletionper) {
		this.appstagecompletionper = appstagecompletionper;
	}
	public String getFieldname() {
		return fieldname;
	}
	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}
	public String getFieldcode() {
		return fieldcode;
	}
	public void setFieldcode(String fieldcode) {
		this.fieldcode = fieldcode;
	}
	public String getOldfieldvalue() {
		return oldfieldvalue;
	}
	public void setOldfieldvalue(String oldfieldvalue) {
		this.oldfieldvalue = oldfieldvalue;
	}
	public String getNewfieldvalue() {
		return newfieldvalue;
	}
	public void setNewfieldvalue(String newfieldvalue) {
		this.newfieldvalue = newfieldvalue;
	}
	public Long getUpdatedby() {
		return updatedby;
	}
	public void setUpdatedby(Long updatedby) {
		this.updatedby = updatedby;
	}
	public Timestamp getUpdatedt() {
		return updatedt;
	}
	public void setUpdatedt(Timestamp updatedt) {
		this.updatedt = updatedt;
	}
}
