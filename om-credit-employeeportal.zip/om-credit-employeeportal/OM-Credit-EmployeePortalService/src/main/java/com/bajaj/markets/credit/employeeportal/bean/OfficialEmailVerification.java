package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.util.Date;

public class OfficialEmailVerification implements Serializable {

	private static final long serialVersionUID = 1L;

	private String OffEmailIdVerificationFlag;
	private Date OffEmailIDVerificationDate;
	private String OffEmailVerificationStatus;
	private String offEmailIDVerificationSource;
	private String emailVerificationMethod;
	private String emailType;
	private Long applicantKey;
	private String manualOfficeVerification;
	public String getOffEmailIdVerificationFlag() {
		return OffEmailIdVerificationFlag;
	}
	public void setOffEmailIdVerificationFlag(String offEmailIdVerificationFlag) {
		OffEmailIdVerificationFlag = offEmailIdVerificationFlag;
	}
	public Date getOffEmailIDVerificationDate() {
		return OffEmailIDVerificationDate;
	}
	public void setOffEmailIDVerificationDate(Date offEmailIDVerificationDate) {
		OffEmailIDVerificationDate = offEmailIDVerificationDate;
	}
	public String getOffEmailVerificationStatus() {
		return OffEmailVerificationStatus;
	}
	public void setOffEmailVerificationStatus(String offEmailVerificationStatus) {
		OffEmailVerificationStatus = offEmailVerificationStatus;
	}
	public String getOffEmailIDVerificationSource() {
		return offEmailIDVerificationSource;
	}
	public void setOffEmailIDVerificationSource(String offEmailIDVerificationSource) {
		this.offEmailIDVerificationSource = offEmailIDVerificationSource;
	}
	public String getEmailVerificationMethod() {
		return emailVerificationMethod;
	}
	public void setEmailVerificationMethod(String emailVerificationMethod) {
		this.emailVerificationMethod = emailVerificationMethod;
	}
	public String getEmailType() {
		return emailType;
	}
	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}
	public Long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}
	public String getManualOfficeVerification() {
		return manualOfficeVerification;
	}
	public void setManualOfficeVerification(String manualOfficeVerification) {
		this.manualOfficeVerification = manualOfficeVerification;
	}
	
}
