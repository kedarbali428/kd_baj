package com.bajaj.markets.credit.employeeportal.controller;

import java.util.List;

import javax.validation.constraints.Digits;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.LoanRevisionBean;
import com.bajaj.markets.credit.employeeportal.bean.LoanRevisionResponse;
import com.bajaj.markets.credit.employeeportal.bean.LoanRevisionReviewRequest;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalLoanApprovalService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class EmployeePortalLoanApprovalController {

	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	EmployeePortalLoanApprovalService employeePortalLoanApprovalService;

	private static final String CLASSNAME = EmployeePortalLoanApprovalController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Loan revision found", notes = "Loan revision found", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Loan revision fetched successfully.", response = LoanRevisionResponse.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/credit/employeeportal/application/{applicationKey}/loanrevision", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> getloanRevision(
			@PathVariable("applicationKey") @Digits(fraction = 0, integer = 20, message = "applicationKey can not be other than digits") String applicationKey,
			@RequestHeader HttpHeaders headers,@RequestParam(name = "actionType", required = false) String actionType) {

		List<LoanRevisionResponse> response;
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getloanRevision method :" + applicationKey);
		response = employeePortalLoanApprovalService.getloanRevision(applicationKey, actionType);

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"GetloanRevision method for loanRevision completed suceessfully");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Loan revision updated  details", notes = "Loan revision updated details", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Loan revision updated successfully.", response = LoanRevisionResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/credit/employeeportal/application/{applicationKey}/loanrevision", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> updateloanRevision(@RequestBody LoanRevisionBean loanRevisionBean,
			@PathVariable("applicationKey") @Digits(fraction = 0, integer = 20, message = "applicationKey can not be other than digits") String applicationKey,
			@RequestParam(required = false) Long userRoleKey,BindingResult bindingResult, @RequestHeader HttpHeaders headers) {

		LoanRevisionResponse response;
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside Loan revision updated details method :" + loanRevisionBean.getL3productCode());
		response = employeePortalLoanApprovalService.updateloanRevision(loanRevisionBean, applicationKey, headers,userRoleKey);

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Loan revision details method for loanRevision completed suceessfully");
		return response.isCreated() ? new ResponseEntity<>(response, HttpStatus.CREATED)
				: new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Loan revision updated  details", notes = "Loan revision updated details", httpMethod = "PUT")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Loan revision updated successfully.", response = LoanRevisionResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/credit/employeeportal/application/{applicationKey}/loanrevision/review", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> reviewloanRevision(@RequestBody LoanRevisionReviewRequest loanRevisionReviewRequest,
			@PathVariable("applicationKey") @Digits(fraction = 0, integer = 20, message = "applicationKey can not be other than digits") String applicationKey,
			@RequestParam(required = false) Long userRoleKey, BindingResult bindingResult, @RequestHeader HttpHeaders headers) {

		LoanRevisionResponse response;
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside Loan revision updated details method :" + applicationKey);
		response = employeePortalLoanApprovalService.reviewloanRevision(loanRevisionReviewRequest, applicationKey,headers, userRoleKey);

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Loan revision details method for loanRevision completed suceessfully");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}