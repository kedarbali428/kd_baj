package com.bajaj.markets.credit.employeeportal.bean;

public class BureauApplicantDetails {

	private String applicantName;
	
	private String dob;
	
	private String idtype;

	private String idnumber;

	private String issuedate;

	private String expirydate;
	
	private String drivingLiscenceNbr;
	
	private String gender;
	
	private String pan;
	
	private String passportNbr;
	
	private String aadharNbr;
	
	
	/**
	 * @return the idtype
	 */
	public String getIdtype() {
		return idtype;
	} 

	/**
	 * @param idtype the idtype to set
	 */
	public void setIdtype(String idtype) {
		this.idtype = idtype;
	}

	/**
	 * @return the idnumber
	 */
	public String getIdnumber() {
		return idnumber;
	}

	/**
	 * @param idnumber the idnumber to set
	 */
	public void setIdnumber(String idnumber) {
		this.idnumber = idnumber;
	}

	/**
	 * @return the issuedate
	 */
	public String getIssuedate() {
		return issuedate;
	}

	/**
	 * @param issuedate the issuedate to set
	 */
	public void setIssuedate(String issuedate) {
		this.issuedate = issuedate;
	}

	/**
	 * @return the expirydate
	 */
	public String getExpirydate() {
		return expirydate;
	}

	/**
	 * @param expirydate the expirydate to set
	 */
	public void setExpirydate(String expirydate) {
		this.expirydate = expirydate;
	}

	/**
	 * @return the applicantName
	 */
	public String getApplicantName() {
		return applicantName;
	}

	/**
	 * @param applicantName the applicantName to set
	 */
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	/**
	 * @return the dob
	 */
	public String getDob() {
		return dob;
	}

	/**
	 * @param dob the dob to set
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}

	/**
	 * @return the drivingLiscenceNbr
	 */
	public String getDrivingLiscenceNbr() {
		return drivingLiscenceNbr;
	}

	/**
	 * @param drivingLiscenceNbr the drivingLiscenceNbr to set
	 */
	public void setDrivingLiscenceNbr(String drivingLiscenceNbr) {
		this.drivingLiscenceNbr = drivingLiscenceNbr;
	}

	/**
	 * @return the pan
	 */
	public String getPan() {
		return pan;
	}

	/**
	 * @param pan the pan to set
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}

	/**
	 * @return the passportNbr
	 */
	public String getPassportNbr() {
		return passportNbr;
	}

	/**
	 * @param passportNbr the passportNbr to set
	 */
	public void setPassportNbr(String passportNbr) {
		this.passportNbr = passportNbr;
	}

	/**
	 * @return the aadharNbr
	 */
	public String getAadharNbr() {
		return aadharNbr;
	}

	/**
	 * @param aadharNbr the aadharNbr to set
	 */
	public void setAadharNbr(String aadharNbr) {
		this.aadharNbr = aadharNbr;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

}
