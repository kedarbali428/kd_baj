package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="app_tranche_detail", schema = "dmcredit")
public class AppTrancheDetails implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5357484334399263063L;

	@Id
	@SequenceGenerator(name="app_tranche_detail_apptranchedetkey_generator", sequenceName="dmcredit.seq_pk_app_tranche_detail",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_tranche_detail_apptranchedetkey_generator")
	private Long apptranchedetkey;
	private Integer trancheamount;
	private Date tranchedate;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private String repaymentmode;
	private String disbursementmode;
	private Integer pendingdisbursementamt;
	private String tranchestatus;
	private Integer totaldisubursedamt;
	private Integer disbursementfailureflg;
	private String disbursementerror;
	private Integer tranchenumber;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="applicationbankdetkey")
	private ApplicationBankDetail applicationBankDetail;

	public Long getApptranchedetkey() {
		return apptranchedetkey;
	}

	public void setApptranchedetkey(Long apptranchedetkey) {
		this.apptranchedetkey = apptranchedetkey;
	}

	public Integer getTrancheamount() {
		return trancheamount;
	}

	public void setTrancheamount(Integer trancheamount) {
		this.trancheamount = trancheamount;
	}

	public Date getTranchedate() {
		return tranchedate;
	}

	public void setTranchedate(Date tranchedate) {
		this.tranchedate = tranchedate;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getRepaymentmode() {
		return repaymentmode;
	}

	public void setRepaymentmode(String repaymentmode) {
		this.repaymentmode = repaymentmode;
	}

	public String getDisbursementmode() {
		return disbursementmode;
	}

	public void setDisbursementmode(String disbursementmode) {
		this.disbursementmode = disbursementmode;
	}

	public Integer getPendingdisbursementamt() {
		return pendingdisbursementamt;
	}

	public void setPendingdisbursementamt(Integer pendingdisbursementamt) {
		this.pendingdisbursementamt = pendingdisbursementamt;
	}

	public String getTranchestatus() {
		return tranchestatus;
	}

	public void setTranchestatus(String tranchestatus) {
		this.tranchestatus = tranchestatus;
	}

	public Integer getTotaldisubursedamt() {
		return totaldisubursedamt;
	}

	public void setTotaldisubursedamt(Integer totaldisubursedamt) {
		this.totaldisubursedamt = totaldisubursedamt;
	}

	public Integer getDisbursementfailureflg() {
		return disbursementfailureflg;
	}

	public void setDisbursementfailureflg(Integer disbursementfailureflg) {
		this.disbursementfailureflg = disbursementfailureflg;
	}

	public String getDisbursementerror() {
		return disbursementerror;
	}

	public void setDisbursementerror(String disbursementerror) {
		this.disbursementerror = disbursementerror;
	}

	public Integer getTranchenumber() {
		return tranchenumber;
	}

	public void setTranchenumber(Integer tranchenumber) {
		this.tranchenumber = tranchenumber;
	}

	public ApplicationBankDetail getApplicationBankDetail() {
		return applicationBankDetail;
	}

	public void setApplicationBankDetail(ApplicationBankDetail applicationBankDetail) {
		this.applicationBankDetail = applicationBankDetail;
	}
	
}
