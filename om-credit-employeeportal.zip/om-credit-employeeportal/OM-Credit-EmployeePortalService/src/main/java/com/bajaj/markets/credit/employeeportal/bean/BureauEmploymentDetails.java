package com.bajaj.markets.credit.employeeportal.bean;

public class BureauEmploymentDetails {

    private String occupationcode;
    
    private String income;
    
    private String netgrossincomeindicator;
    
    private String monthorannualincomeindicator;

	/**
	 * @return the occupationcode
	 */
	public String getOccupationcode() {
		return occupationcode;
	}

	/**
	 * @param occupationcode the occupationcode to set
	 */
	public void setOccupationcode(String occupationcode) {
		this.occupationcode = occupationcode;
	}

	/**
	 * @return the income
	 */
	public String getIncome() {
		return income;
	}

	/**
	 * @param income the income to set
	 */
	public void setIncome(String income) {
		this.income = income;
	}

	/**
	 * @return the netgrossincomeindicator
	 */
	public String getNetgrossincomeindicator() {
		return netgrossincomeindicator;
	}

	/**
	 * @param netgrossincomeindicator the netgrossincomeindicator to set
	 */
	public void setNetgrossincomeindicator(String netgrossincomeindicator) {
		this.netgrossincomeindicator = netgrossincomeindicator;
	}

	/**
	 * @return the monthorannualincomeindicator
	 */
	public String getMonthorannualincomeindicator() {
		return monthorannualincomeindicator;
	}

	/**
	 * @param monthorannualincomeindicator the monthorannualincomeindicator to set
	 */
	public void setMonthorannualincomeindicator(String monthorannualincomeindicator) {
		this.monthorannualincomeindicator = monthorannualincomeindicator;
	}


}
