package com.bajaj.markets.credit.employeeportal.bean;

import java.util.ArrayList;
import java.util.List;

public class EMICycleDateBean {

	List<String> date = new ArrayList<>();

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EMICycleDateBean other = (EMICycleDateBean) obj;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		return true;
	}

	public List<String> getDate() {
		return date;
	}

	public void setDate(List<String> date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "EMICycleDateBean [date=" + date + "]";
	}

}

