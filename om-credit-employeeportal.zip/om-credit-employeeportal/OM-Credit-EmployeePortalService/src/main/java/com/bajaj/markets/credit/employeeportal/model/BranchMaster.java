package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "branch_master", schema = "dmmaster")

public class BranchMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "branchkey")
	private Long branchKey;

	@Column(name = "bankmastkey")
	private Long bankMasterKey;

	@Column(name = "branchcode")
	private String branchCode;

	@Column(name = "branchdescription")
	private String description;

	@Column(name = "branchifsccode")
	private String ifscCode;

	@Column(name = "branchmicrcode")
	private String micrCode;

	@Column(name = "branchfax")
	private String faxNumber;

	@Column(name = "branchtelnum")
	private String phoneNumber;

	@Column(name = "branchaddressline1")
	private String addressLine1;

	@Column(name = "branchaddressline2")
	private String addressLine2;

	@Column(name = "branchpincode")
	private Long pincodeKey;

	@Column(name = "branchcity")
	private Long cityKey;

	@Column(name = "branchstate")
	private Long stateKey;

	@Column(name = "branchcountry")
	private Long countryKey;

	@Column(name = "branchswiftbankcode")
	private String swiftBankCode;

	@Column(name = "branchswiftcountry")
	private String swiftCountry;

	@Column(name = "branchswiftloccode")
	private String swiftLocationCode;

	@Column(name = "branchswiftsortcode")
	private String swiftSortCode;

	@Column(name = "isactive")
	private Integer isActive;

	@Column(name = "lstupdateby")
	private Long lastUpdateBy;

	@Column(name = "lstupdatedt")
	private Timestamp lastUpdateDate;

	@Column(name = "branchifsccode",updatable = false,insertable = false)
	private String branchIfscCode;

	@Column(name = "branchmicrcode",updatable = false,insertable = false)
	private String branchMicrCode;

	@Column(name = "branchdescription",updatable = false,insertable = false)
	private String branchDescription;

	public BranchMaster() {
	}

	public Long getBranchKey() {
		return branchKey;
	}

	public void setBranchKey(Long branchKey) {
		this.branchKey = branchKey;
	}

	public Long getBankMasterKey() {
		return bankMasterKey;
	}

	public void setBankMasterKey(Long bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public Long getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(Long pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public Long getCityKey() {
		return cityKey;
	}

	public void setCityKey(Long cityKey) {
		this.cityKey = cityKey;
	}

	public Long getStateKey() {
		return stateKey;
	}

	public void setStateKey(Long stateKey) {
		this.stateKey = stateKey;
	}

	public Long getCountryKey() {
		return countryKey;
	}

	public void setCountryKey(Long countryKey) {
		this.countryKey = countryKey;
	}

	public String getSwiftBankCode() {
		return swiftBankCode;
	}

	public void setSwiftBankCode(String swiftBankCode) {
		this.swiftBankCode = swiftBankCode;
	}

	public String getSwiftCountry() {
		return swiftCountry;
	}

	public void setSwiftCountry(String swiftCountry) {
		this.swiftCountry = swiftCountry;
	}

	public String getSwiftLocationCode() {
		return swiftLocationCode;
	}

	public void setSwiftLocationCode(String swiftLocationCode) {
		this.swiftLocationCode = swiftLocationCode;
	}

	public String getSwiftSortCode() {
		return swiftSortCode;
	}

	public void setSwiftSortCode(String swiftSortCode) {
		this.swiftSortCode = swiftSortCode;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public Long getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(Long lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	public Timestamp getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Timestamp lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getBranchIfscCode() {
		return branchIfscCode;
	}

	public void setBranchIfscCode(String branchIfscCode) {
		this.branchIfscCode = branchIfscCode;
	}

	public String getBranchMicrCode() {
		return branchMicrCode;
	}

	public void setBranchMicrCode(String branchMicrCode) {
		this.branchMicrCode = branchMicrCode;
	}

	public String getBranchDescription() {
		return branchDescription;
	}

	public void setBranchDescription(String branchDescription) {
		this.branchDescription = branchDescription;
	}

}
