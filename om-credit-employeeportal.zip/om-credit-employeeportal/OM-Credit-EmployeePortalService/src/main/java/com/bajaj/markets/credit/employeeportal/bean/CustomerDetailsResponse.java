package com.bajaj.markets.credit.employeeportal.bean;

import java.util.Date;

public class CustomerDetailsResponse {
	private String name;
	private Date dob;
	private String mobile;
	private Long applicantkey;
	private String email;
	private Long appattrbkey;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Long getApplicantkey() {
		return applicantkey;
	}
	public void setApplicantkey(Long applicantkey) {
		this.applicantkey = applicantkey;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

}
