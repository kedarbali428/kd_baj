package com.bajaj.markets.credit.employeeportal.bean;

import javax.validation.constraints.NotNull;

public class FppBundleRequest {

	@NotNull(message = "occupationType can not be null")
	private String occupationType;

	private String companyCategory;

	private Integer cibilScore;

	private AdditionalParameterDetail additionalParameterDetail;
	
	@NotNull(message = "source can not be null")
	private String source;

	public String getOccupationType() {
		return occupationType;
	}

	public String getCompanyCategory() {
		return companyCategory;
	}

	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}

	public void setCompanyCategory(String companyCategory) {
		this.companyCategory = companyCategory;
	}

	public Integer getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(Integer cibilScore) {
		this.cibilScore = cibilScore;
	}

	public AdditionalParameterDetail getAdditionalParameterDetail() {
		return additionalParameterDetail;
	}

	public void setAdditionalParameterDetail(AdditionalParameterDetail additionalParameterDetail) {
		this.additionalParameterDetail = additionalParameterDetail;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
