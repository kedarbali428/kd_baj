package com.bajaj.markets.credit.employeeportal.helper;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.employeeportal.bean.AppAuditRequest;
import com.bajaj.markets.credit.employeeportal.bean.AuditDetails;
import com.bajaj.markets.credit.employeeportal.bean.CreditStatus;
import com.bajaj.markets.credit.employeeportal.bean.FieldData;
import com.bajaj.markets.credit.employeeportal.bean.FieldList;

@Component
public class AttributeFieldToValueMapperForAudit {
	@Autowired
	BFLLoggerUtilExt logger;
	private static final String CLASSNAME = AttributeFieldToValueMapperForAudit.class.getName();
	
	@SuppressWarnings({ "rawtypes" })
	public void mapValuesToFields(AuditDetails auditDetails, Object obj,
			Properties fieldValMap) {
		if (null != obj) {
			if (obj instanceof Collection<?>) {
				for (Object element : (Collection) obj) {
					try {
						mapValues(auditDetails, element, fieldValMap);
					} catch (Exception e) {
						logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
								"Technical exception occurred while fetching subsection details: ", e);
						throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(
								"OMCA_103", "Technical exception occurred while fetching subsection logs "));
					}
				}
			} else {
				try {
					mapValues(auditDetails, obj, fieldValMap);
				} catch (Exception e) {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
							"Technical exception occurred while fetching subsection  details: ", e);
					throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
							new ErrorBean("OMCA_103", "Technical exception occurred while fetching subsection logs "));
				}
			}
		}

	}
	public void mapValues(AuditDetails auditDetails, Object obj, Properties application)
			throws Exception {
		FieldData data = null;
		for (FieldList field : auditDetails.getFieldList()) { {
			String fieldName = null != ((String) application.get(field.getFieldcd().toString()))
					? ((String) application.get(field.getFieldcd().toString())).trim()
					: null;
			if (null != fieldName) {
				PropertyDescriptor pd;
				pd = new PropertyDescriptor(fieldName, obj.getClass());
				Object tmpObjec = pd.getReadMethod().invoke(obj);
				data = new FieldData();
				data.setValue(null != tmpObjec ? tmpObjec.toString() : null);
				field.getFieldValueList().add(data);
			} else {
				data = new FieldData();
				data.setValue(null);
				field.getFieldValueList().add(data);
			}
		}
	}
}
	public void mapUpdateValues(List<AppAuditRequest> appAuditRequest, Object obj,
			Properties ctaFieldValMap) {
		for (AppAuditRequest field : appAuditRequest) {
				// String fieldName = field.getKey();
				String fieldName = null != ((String) ctaFieldValMap.get(field.getFieldCode().toString()))
						? ((String) ctaFieldValMap.get(field.getFieldCode().toString())).trim()
						: null;
				if (null != fieldName) {
					PropertyDescriptor pd;

					try {
						pd = new PropertyDescriptor(fieldName, obj.getClass());
						Method setter = pd.getWriteMethod();
						setter.invoke(obj, field.getNewFieldValue());
					} catch (Exception e) {
						logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
								"Technical exception occurred while updating updating cta for audit: ", e);
						throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
								new ErrorBean("OMCA_103", "Technical exception occurred while updating cta for audit  "));
					}
				}
			}		
	}
}
