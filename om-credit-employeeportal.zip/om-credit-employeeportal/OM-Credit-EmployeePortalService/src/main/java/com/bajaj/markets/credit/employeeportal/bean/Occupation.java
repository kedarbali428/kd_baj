package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class Occupation {

	@NotNull(message = "ocupationType cannot be null or empty")
	private Reference ocupationType;

	@Valid
	@NotNull(message = "salariedDetail cannot be null or empty")
	private SalariedDetail salariedDetail;

	@Valid
	@NotNull(message = "businessOwnerDetail cannot be null or empty")
	private BusinessOwnerDetails businessOwnerDetails;

	private BigDecimal profitAfterTax;

	private BigDecimal averageBankBlance;

	private String employerType;

	public Reference getOcupationType() {
		return ocupationType;
	}

	public void setOcupationType(Reference ocupationType) {
		this.ocupationType = ocupationType;
	}

	public SalariedDetail getSalariedDetail() {
		return salariedDetail;
	}

	public void setSalariedDetail(SalariedDetail salariedDetail) {
		this.salariedDetail = salariedDetail;
	}

	public BusinessOwnerDetails getBusinessOwnerDetails() {
		return businessOwnerDetails;
	}

	public void setBusinessOwnerDetails(BusinessOwnerDetails businessOwnerDetails) {
		this.businessOwnerDetails = businessOwnerDetails;
	}

	public BigDecimal getProfitAfterTax() {
		return profitAfterTax;
	}

	public void setProfitAfterTax(BigDecimal profitAfterTax) {
		this.profitAfterTax = profitAfterTax;
	}

	public BigDecimal getAverageBankBlance() {
		return averageBankBlance;
	}

	public void setAverageBankBlance(BigDecimal averageBankBlance) {
		this.averageBankBlance = averageBankBlance;
	}

	public String getEmployerType() {
		return employerType;
	}

	public void setEmployerType(String employerType) {
		this.employerType = employerType;
	}
}
