package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class BusinessDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String businessName;
	private String totalBusinessExperience;
	private String natureOfBusiness;
	private String businessPan;
	private String gstNumber;
	private String businessTurnover;
	private String constitutionType;
	private String averageBankBalance;
	private String businessVintage;
	private String industryAsPerCustomer;
	private String netMonthlyIncome;
	private String subIndustry;
	private String industryAsPerCredit;
	private String subIndustryAsPerCredit;
	private BigDecimal profitAfterTax;

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getTotalBusinessExperience() {
		return totalBusinessExperience;
	}

	public void setTotalBusinessExperience(String totalBusinessExperience) {
		this.totalBusinessExperience = totalBusinessExperience;
	}

	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}

	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}

	public String getBusinessPan() {
		return businessPan;
	}

	public void setBusinessPan(String businessPan) {
		this.businessPan = businessPan;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public String getBusinessTurnover() {
		return businessTurnover;
	}

	public void setBusinessTurnover(String businessTurnover) {
		this.businessTurnover = businessTurnover;
	}

	public String getConstitutionType() {
		return constitutionType;
	}

	public void setConstitutionType(String constitutionType) {
		this.constitutionType = constitutionType;
	}

	public String getAverageBankBalance() {
		return averageBankBalance;
	}

	public void setAverageBankBalance(String averageBankBalance) {
		this.averageBankBalance = averageBankBalance;
	}

	public String getBusinessVintage() {
		return businessVintage;
	}

	public void setBusinessVintage(String businessVintage) {
		this.businessVintage = businessVintage;
	}

	public String getIndustryAsPerCustomer() {
		return industryAsPerCustomer;
	}

	public void setIndustryAsPerCustomer(String industryAsPerCustomer) {
		this.industryAsPerCustomer = industryAsPerCustomer;
	}

	public String getNetMonthlyIncome() {
		return netMonthlyIncome;
	}

	public void setNetMonthlyIncome(String netMonthlyIncome) {
		this.netMonthlyIncome = netMonthlyIncome;
	}

	public String getSubIndustry() {
		return subIndustry;
	}

	public void setSubIndustry(String subIndustry) {
		this.subIndustry = subIndustry;
	}

	public String getIndustryAsPerCredit() {
		return industryAsPerCredit;
	}

	public void setIndustryAsPerCredit(String industryAsPerCredit) {
		this.industryAsPerCredit = industryAsPerCredit;
	}

	public String getSubIndustryAsPerCredit() {
		return subIndustryAsPerCredit;
	}

	public void setSubIndustryAsPerCredit(String subIndustryAsPerCredit) {
		this.subIndustryAsPerCredit = subIndustryAsPerCredit;
	}

	public BigDecimal getProfitAfterTax() {
		return profitAfterTax;
	}

	public void setProfitAfterTax(BigDecimal profitAfterTax) {
		this.profitAfterTax = profitAfterTax;
	}

}