package com.bajaj.markets.credit.employeeportal.bean;

public class UserMgmtTabCTABean {
	private String name;
	private String ctaKey;
	private String tabKey;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the ctaKey
	 */
	public String getCtaKey() {
		return ctaKey;
	}
	/**
	 * @param ctaKey the ctaKey to set
	 */
	public void setCtaKey(String ctaKey) {
		this.ctaKey = ctaKey;
	}
	/**
	 * @return the tabKey
	 */
	public String getTabKey() {
		return tabKey;
	}
	/**
	 * @param tabKey the tabKey to set
	 */
	public void setTabKey(String tabKey) {
		this.tabKey = tabKey;
	}
	
	
}
