package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="app_credit_review_detail",schema = "dmcredit")
public class AppCreditReviewDetail implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long creditreviewdetkey; 
	private Long applicationkey;
	private Long prodkey;
	private Integer creditreviewkey;
	private String source;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	
	public Long getCreditreviewdetkey() {
		return creditreviewdetkey;
	}
	public void setCreditreviewdetkey(Long creditreviewdetkey) {
		this.creditreviewdetkey = creditreviewdetkey;
	}
	public Long getApplicationkey() {
		return applicationkey;
	}
	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}
	public Long getProdkey() {
		return prodkey;
	}
	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}
	public Integer getCreditreviewkey() {
		return creditreviewkey;
	}
	public void setCreditreviewkey(Integer creditreviewkey) {
		this.creditreviewkey = creditreviewkey;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	public Long getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
}