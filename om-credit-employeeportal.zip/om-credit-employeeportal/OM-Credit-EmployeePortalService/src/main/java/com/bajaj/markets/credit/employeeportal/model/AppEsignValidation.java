package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_esign_validation", schema = "dmcredit")
public class AppEsignValidation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_occupation_detail_appoccupationkey_generator", sequenceName = "dmcredit.seq_pk_app_occupation_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_occupation_detail_appoccupationkey_generator")
	private Long appesignvalidationkey;
	private Long appesigninfokey;
	private Integer otp;
	private Long mobile;
	private Date dateofbirth;
	private String ipaddress;
	private Double latitude;
	private Double longitude;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;

	public Long getAppesignvalidationkey() {
		return appesignvalidationkey;
	}

	public void setAppesignvalidationkey(Long appesignvalidationkey) {
		this.appesignvalidationkey = appesignvalidationkey;
	}

	public Long getAppesigninfokey() {
		return appesigninfokey;
	}

	public void setAppesigninfokey(Long appesigninfokey) {
		this.appesigninfokey = appesigninfokey;
	}

	public Integer getOtp() {
		return otp;
	}

	public void setOtp(Integer otp) {
		this.otp = otp;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getIpaddress() {
		return ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
}
