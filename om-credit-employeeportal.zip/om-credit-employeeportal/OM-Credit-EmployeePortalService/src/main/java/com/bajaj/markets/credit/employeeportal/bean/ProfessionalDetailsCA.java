package com.bajaj.markets.credit.employeeportal.bean;

public class ProfessionalDetailsCA {
	private Integer yearOfAttainingCertificateOfPractice;
	private String CARegitrationNumber;
	private String totalExperience;
	
	public Integer getYearOfAttainingCertificateOfPractice() {
		return yearOfAttainingCertificateOfPractice;
	}
	public void setYearOfAttainingCertificateOfPractice(Integer yearOfAttainingCertificateOfPractice) {
		this.yearOfAttainingCertificateOfPractice = yearOfAttainingCertificateOfPractice;
	}
	public String getCARegitrationNumber() {
		return CARegitrationNumber;
	}
	public void setCARegitrationNumber(String cARegitrationNumber) {
		CARegitrationNumber = cARegitrationNumber;
	}
	public String getTotalExperience() {
		return totalExperience;
	}
	public void setTotalExperience(String totalExperience) {
		this.totalExperience = totalExperience;
	}
	
}
