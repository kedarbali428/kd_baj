package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import javax.validation.constraints.NotNull;

public class FieldList {
	@NotNull(message = "fieldcd cannot be null or empty")
	private Integer fieldcd;
    
    @NotNull(message = "fieldname cannot be null or empty")
	private String fieldname;
    
    private String fieldurl;
    
    private List<FieldData> fieldValueList;

	public Integer getFieldcd() {
		return fieldcd;
	}

	public void setFieldcd(Integer fieldcd) {
		this.fieldcd = fieldcd;
	}

	public String getFieldname() {
		return fieldname;
	}

	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}

	public List<FieldData> getFieldValueList() {
		return fieldValueList;
	}

	public void setFieldValueList(List<FieldData> fieldValueList) {
		this.fieldValueList = fieldValueList;
	}
	
	public String getFieldurl() {
		return fieldurl;
	}

	public void setFieldurl(String fieldurl) {
		this.fieldurl = fieldurl;
	}

	public FieldList(@NotNull(message = "fieldcd cannot be null or empty") Integer fieldcd,
			@NotNull(message = "fieldname cannot be null or empty") String fieldname) {
		super();
		this.fieldcd = fieldcd;
		this.fieldname = fieldname;
	}

	public FieldList() {
	}
	
	
}