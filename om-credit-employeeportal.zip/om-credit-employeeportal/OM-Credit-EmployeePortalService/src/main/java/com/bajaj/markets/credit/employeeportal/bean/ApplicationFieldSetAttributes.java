package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import javax.validation.constraints.NotNull;

/**
 * Application Field Set Attribute Details resource 
 * @author 736919
 * 
 */
public class ApplicationFieldSetAttributes {
	
    @NotNull(message = "fieldcd cannot be null or empty")
	private Integer fieldcd;
    
    @NotNull(message = "fieldname cannot be null or empty")
	private String fieldname;
	
	
	@NotNull(message = "fieldtype cannot be null or empty")
	private Integer fieldtype;
	
	private String fieldurl;
	
	private Boolean editablebystage;
	
	private Integer requiredflg;
	
	private Integer displayorder;
	
	private List<FieldData> fieldValueList;

	/**
	 * @return the fieldcd
	 */
	public Integer getFieldcd() {
		return fieldcd;
	}

	/**
	 * @param fieldcd the fieldcd to set
	 */
	public void setFieldcd(Integer fieldcd) {
		this.fieldcd = fieldcd;
	}

	/**
	 * @return the fieldname
	 */
	public String getFieldname() {
		return fieldname;
	}

	/**
	 * @param fieldname the fieldname to set
	 */
	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}

	/**
	 * @return the fieldtype
	 */
	public Integer getFieldtype() {
		return fieldtype;
	}

	/**
	 * @param fieldtype the fieldtype to set
	 */
	public void setFieldtype(Integer fieldtype) {
		this.fieldtype = fieldtype;
	}

	/**
	 * @return the fieldurl
	 */
	public String getFieldurl() {
		return fieldurl;
	}

	/**
	 * @param fieldurl the fieldurl to set
	 */
	public void setFieldurl(String fieldurl) {
		this.fieldurl = fieldurl;
	}

	/**
	 * @return the editablebystage
	 */
	public Boolean getEditablebystage() {
		return editablebystage;
	}

	/**
	 * @param editablebystage the editablebystage to set
	 */
	public void setEditablebystage(Boolean editablebystage) {
		this.editablebystage = editablebystage;
	}

	/**
	 * @return the requiredflg
	 */
	public Integer getRequiredflg() {
		return requiredflg;
	}

	/**
	 * @param requiredflg the requiredflg to set
	 */
	public void setRequiredflg(Integer requiredflg) {
		this.requiredflg = requiredflg;
	}

	/**
	 * @return the displayorder
	 */
	public Integer getDisplayorder() {
		return displayorder;
	}

	/**
	 * @param displayorder the displayorder to set
	 */
	public void setDisplayorder(Integer displayorder) {
		this.displayorder = displayorder;
	}

	@Override
	public String toString() {
		return "ApplicationFieldSetAttributes [fieldcd=" + fieldcd + ", fieldname=" + fieldname + ", fieldtype="
				+ fieldtype + ", fieldurl=" + fieldurl + ", editablebystage=" + editablebystage + ", requiredflg="
				+ requiredflg + ", displayorder=" + displayorder + "]";
	}

	/**
	 * @return the fieldValueList
	 */
	public List<FieldData> getFieldValueList() {
		return fieldValueList;
	}

	/**
	 * @param fieldValueList the fieldValueList to set
	 */
	public void setFieldValueList(List<FieldData> fieldValueList) {
		this.fieldValueList = fieldValueList;
	}

	


}
