package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_loan_pricing", schema = "dmcredit")
public class AppLoanPricing implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_loan_pricing_apploanpricingkey_generator", sequenceName = "dmcredit.seq_pk_app_loan_pricing", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_loan_pricing_apploanpricingkey_generator")
	private Long apploanpricingkey;
	
	private Long applicationkey;

	private Long appprodlistkey;

	private Long approvedby;

	private Timestamp approveddt;

	private String baseratecode;

	private BigDecimal baseratevalue;

	private Integer droplineemi;

	private BigDecimal droplinetenure;

	private Integer dueday;

	private Integer emiamount;

	private BigDecimal finalloanamount;

	private BigDecimal finalroi;

	private Date firstduedate;

	private BigDecimal graceterm;

	private Integer isactive;

	private String isemi;

	private BigDecimal istenure;

	private BigDecimal loanamountwithbundle;

	private Integer loanamt;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Integer netdisbursementamt;

	private Date nextduedate;

	private String pennantloantype;

	private Long raisedby;

	private Timestamp raiseddt;

	private BigDecimal roi;

	private BigDecimal roiwithbundle;

	private String source;

	private String status;
	
	private Integer pricingflag;

	public Integer getPricingflag() {
		return pricingflag;
	}

	public void setPricingflag(Integer pricingflag) {
		this.pricingflag = pricingflag;
	}

	public Long getApploanpricingkey() {
		return apploanpricingkey;
	}

	public void setApploanpricingkey(Long apploanpricingkey) {
		this.apploanpricingkey = apploanpricingkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getAppprodlistkey() {
		return appprodlistkey;
	}

	public void setAppprodlistkey(Long appprodlistkey) {
		this.appprodlistkey = appprodlistkey;
	}

	public Long getApprovedby() {
		return approvedby;
	}

	public void setApprovedby(Long approvedby) {
		this.approvedby = approvedby;
	}

	public Timestamp getApproveddt() {
		return approveddt;
	}

	public void setApproveddt(Timestamp approveddt) {
		this.approveddt = approveddt;
	}

	public String getBaseratecode() {
		return baseratecode;
	}

	public void setBaseratecode(String baseratecode) {
		this.baseratecode = baseratecode;
	}

	public BigDecimal getBaseratevalue() {
		return baseratevalue;
	}

	public void setBaseratevalue(BigDecimal baseratevalue) {
		this.baseratevalue = baseratevalue;
	}

	public Integer getDroplineemi() {
		return droplineemi;
	}

	public void setDroplineemi(Integer droplineemi) {
		this.droplineemi = droplineemi;
	}

	public BigDecimal getDroplinetenure() {
		return droplinetenure;
	}

	public void setDroplinetenure(BigDecimal droplinetenure) {
		this.droplinetenure = droplinetenure;
	}

	public Integer getDueday() {
		return dueday;
	}

	public void setDueday(Integer dueday) {
		this.dueday = dueday;
	}

	public Integer getEmiamount() {
		return emiamount;
	}

	public void setEmiamount(Integer emiamount) {
		this.emiamount = emiamount;
	}

	public BigDecimal getFinalloanamount() {
		return finalloanamount;
	}

	public void setFinalloanamount(BigDecimal finalloanamount) {
		this.finalloanamount = finalloanamount;
	}

	public BigDecimal getFinalroi() {
		return finalroi;
	}

	public void setFinalroi(BigDecimal finalroi) {
		this.finalroi = finalroi;
	}

	public Date getFirstduedate() {
		return firstduedate;
	}

	public void setFirstduedate(Date firstduedate) {
		this.firstduedate = firstduedate;
	}

	public BigDecimal getGraceterm() {
		return graceterm;
	}

	public void setGraceterm(BigDecimal graceterm) {
		this.graceterm = graceterm;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public String getIsemi() {
		return isemi;
	}

	public void setIsemi(String isemi) {
		this.isemi = isemi;
	}

	public BigDecimal getIstenure() {
		return istenure;
	}

	public void setIstenure(BigDecimal istenure) {
		this.istenure = istenure;
	}

	public BigDecimal getLoanamountwithbundle() {
		return loanamountwithbundle;
	}

	public void setLoanamountwithbundle(BigDecimal loanamountwithbundle) {
		this.loanamountwithbundle = loanamountwithbundle;
	}

	public Integer getLoanamt() {
		return loanamt;
	}

	public void setLoanamt(Integer loanamt) {
		this.loanamt = loanamt;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Integer getNetdisbursementamt() {
		return netdisbursementamt;
	}

	public void setNetdisbursementamt(Integer netdisbursementamt) {
		this.netdisbursementamt = netdisbursementamt;
	}

	public Date getNextduedate() {
		return nextduedate;
	}

	public void setNextduedate(Date nextduedate) {
		this.nextduedate = nextduedate;
	}

	public String getPennantloantype() {
		return pennantloantype;
	}

	public void setPennantloantype(String pennantloantype) {
		this.pennantloantype = pennantloantype;
	}

	public Long getRaisedby() {
		return raisedby;
	}

	public void setRaisedby(Long raisedby) {
		this.raisedby = raisedby;
	}

	public Timestamp getRaiseddt() {
		return raiseddt;
	}

	public void setRaiseddt(Timestamp raiseddt) {
		this.raiseddt = raiseddt;
	}

	public BigDecimal getRoi() {
		return roi;
	}

	public void setRoi(BigDecimal roi) {
		this.roi = roi;
	}

	public BigDecimal getRoiwithbundle() {
		return roiwithbundle;
	}

	public void setRoiwithbundle(BigDecimal roiwithbundle) {
		this.roiwithbundle = roiwithbundle;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
