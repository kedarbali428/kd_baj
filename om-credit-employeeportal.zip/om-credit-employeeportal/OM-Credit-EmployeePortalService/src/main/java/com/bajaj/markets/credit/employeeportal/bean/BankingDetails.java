package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class BankingDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String fraudIndicator;
	private String statementStatus;
	private String sourceOfData;
	private String accountNumber;
	private String bankName;
	private String customerName;
	private String perfiosNameMatchPercentage;
	
	public String getFraudIndicator() {
		return fraudIndicator;
	}
	public void setFraudIndicator(String fraudIndicator) {
		this.fraudIndicator = fraudIndicator;
	}
	public String getStatementStatus() {
		return statementStatus;
	}
	public void setStatementStatus(String statementStatus) {
		this.statementStatus = statementStatus;
	}
	public String getSourceOfData() {
		return sourceOfData;
	}
	public void setSourceOfData(String sourceOfData) {
		this.sourceOfData = sourceOfData;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPerfiosNameMatchPercentage() {
		return perfiosNameMatchPercentage;
	}
	public void setPerfiosNameMatchPercentage(String perfiosNameMatchPercentage) {
		this.perfiosNameMatchPercentage = perfiosNameMatchPercentage;
	}
}
