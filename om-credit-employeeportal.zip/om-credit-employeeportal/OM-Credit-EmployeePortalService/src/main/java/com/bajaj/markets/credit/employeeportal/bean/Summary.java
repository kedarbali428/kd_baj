package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class Summary {
	private Long applicationId;
	private String firstName;
	private String lastName;
	private String owner;
	private String role;
	private Integer percentage;
	private String subStage;
	private String l2Product;
	private String l2productCode;
	private Long l2productKey;
	private String occupation;
	private String productVarient;
	// 19/5/2019_BFSDCC-642
	private Long childApplication;
	private List<CtaTypeBean> ctas;
	private String applicantId;
	private Boolean loggedInUserIsOwner;
	private String gender;
	private Boolean commentVisible;

	public String getL2productCode() {
		return l2productCode;
	}

	public void setL2productCode(String l2productCode) {
		this.l2productCode = l2productCode;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Integer getPercentage() {
		return percentage;
	}

	public void setPercentage(Integer percentage) {
		this.percentage = percentage;
	}

	public String getSubStage() {
		return subStage;
	}

	public void setSubStage(String subStage) {
		this.subStage = subStage;
	}

	public String getL2Product() {
		return l2Product;
	}

	public void setL2Product(String l2Product) {
		this.l2Product = l2Product;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getProductVarient() {
		return productVarient;
	}

	public void setProductVarient(String productVarient) {
		this.productVarient = productVarient;
	}

	public Long getChildApplication() {
		return childApplication;
	}

	public void setChildApplication(Long childApplication) {
		this.childApplication = childApplication;
	}

	public List<CtaTypeBean> getCtas() {
		return ctas;
	}

	public void setCtas(List<CtaTypeBean> ctas) {
		this.ctas = ctas;
	}

	/**
	 * @return the applicantId
	 */
	public String getApplicantId() {
		return applicantId;
	}

	/**
	 * @param applicantId the applicantId to set
	 */
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}

	/**
	 * @return the loggedInUserIsOwner
	 */
	public Boolean getLoggedInUserIsOwner() {
		return loggedInUserIsOwner;
	}

	/**
	 * @param loggedInUserIsOwner the loggedInUserIsOwner to set
	 */
	public void setLoggedInUserIsOwner(Boolean loggedInUserIsOwner) {
		this.loggedInUserIsOwner = loggedInUserIsOwner;
	}

	public Long getL2productKey() {
		return l2productKey;
	}

	public void setL2productKey(Long l2productKey) {
		this.l2productKey = l2productKey;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Boolean getCommentVisible() {
		return commentVisible;
	}

	public void setCommentVisible(Boolean commentVisible) {
		this.commentVisible = commentVisible;
	}

}
