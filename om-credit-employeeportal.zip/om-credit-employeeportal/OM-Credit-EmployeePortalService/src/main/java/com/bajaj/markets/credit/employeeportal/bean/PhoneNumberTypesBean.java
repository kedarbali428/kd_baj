package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.math.BigDecimal;
/**
 *
 * @author Pranoti.Pandole
 */
public class PhoneNumberTypesBean implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private Long phonetypekey;

	private String phonetypecode;

	private String phonetypedesc;

	private BigDecimal phonetypeisactive;

	private BigDecimal phonetypepriority;

	public Long getPhonetypekey() {
		return phonetypekey;
	}

	public void setPhonetypekey(Long phonetypekey) {
		this.phonetypekey = phonetypekey;
	}

	public String getPhonetypecode() {
		return phonetypecode;
	}

	public void setPhonetypecode(String phonetypecode) {
		this.phonetypecode = phonetypecode;
	}

	public String getPhonetypedesc() {
		return phonetypedesc;
	}

	public void setPhonetypedesc(String phonetypedesc) {
		this.phonetypedesc = phonetypedesc;
	}

	public BigDecimal getPhonetypeisactive() {
		return phonetypeisactive;
	}

	public void setPhonetypeisactive(BigDecimal phonetypeisactive) {
		this.phonetypeisactive = phonetypeisactive;
	}

	public BigDecimal getPhonetypepriority() {
		return phonetypepriority;
	}

	public void setPhonetypepriority(BigDecimal phonetypepriority) {
		this.phonetypepriority = phonetypepriority;
	}
	
}
