package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class BundleProduct implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7210009140806948361L;
	private String productCode;
	private String productName;
	private String productUserFriendlyName;
	private String productType;
	private Double premiumWithGst;
	private Double costWithGst;
	private Double premiumWithotGST;
	private Double sumAssured;
	private Integer tenure;
	private Double pv;
	private List<BundleProductRider> riders;
	private List<Benefits> benefits;
	private Set<QuestionAnswer> questions;
	private Double premiumwithoutgst ;
	private Double premiumWithoutGST;

	public Double getPremiumwithoutgst() {
		return premiumwithoutgst;
	}

	public void setPremiumwithoutgst(Double premiumwithoutgst) {
		this.premiumwithoutgst = premiumwithoutgst;
	}

	public Double getPremiumWithoutGST() {
		return premiumWithoutGST;
	}

	public void setPremiumWithoutGST(Double premiumWithoutGST) {
		this.premiumWithoutGST = premiumWithoutGST;
	}

	public Set<QuestionAnswer> getQuestions() {
		return questions;
	}

	public void setQuestions(Set<QuestionAnswer> questions) {
		this.questions = questions;
	}

	public List<Benefits> getBenefits() {
		return benefits;
	}

	public void setBenefits(List<Benefits> benefits) {
		this.benefits = benefits;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public void setPremiumWithGst(Double premiumWithGst) {
		this.premiumWithGst = premiumWithGst;
	}

	public void setCostWithGst(Double costWithGst) {
		this.costWithGst = costWithGst;
	}

	public void setPremiumWithotGST(Double premiumWithotGST) {
		this.premiumWithotGST = premiumWithotGST;
	}

	public void setSumAssured(Double sumAssured) {
		this.sumAssured = sumAssured;
	}

	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}

	public void setRiders(List<BundleProductRider> riders) {
		this.riders = riders;
	}

	public void setPv(Double pv) {
		this.pv = pv;
	}

	public String getProductCode() {
		return productCode;
	}

	public List<BundleProductRider> getRiders() {
		return riders;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setProductUserFriendlyName(String productUserFriendlyName) {
		this.productUserFriendlyName = productUserFriendlyName;
	}

	public String getProductName() {
		return productName;
	}

	public String getProductUserFriendlyName() {
		return productUserFriendlyName;
	}

	public Double getPremiumWithGst() {
		return premiumWithGst;
	}

	public Double getCostWithGst() {
		return costWithGst;
	}

	public Double getPremiumWithotGST() {
		return premiumWithotGST;
	}

	public Double getSumAssured() {
		return sumAssured;
	}

	public Integer getTenure() {
		return tenure;
	}

	public Double getPv() {
		return pv;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

}
