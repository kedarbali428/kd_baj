package com.bajaj.markets.credit.employeeportal.helper;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.employeeportal.bean.GenerateOTP;
import com.bajaj.markets.credit.employeeportal.bean.OTPBean;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class OtpBusinessHelper {

	@Autowired
	CreditEmployeePortalClientHelper creditEmployeePortalClientHelper;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Value("${api.otp.generate.POST.url}")
	private String otpGenerateUrl;
	
	private static final String CLASSNAME = OtpBusinessHelper.class.getName();

	public GenerateOTP invokeOtp(String mobileNumber, HttpHeaders headers) {
		OTPBean resBean = null;
		JSONObject jsonRequest = new JSONObject();
		jsonRequest.put("mobile", mobileNumber);
		ResponseEntity<?> otpResponse;
		otpResponse = (ResponseEntity<?>) creditEmployeePortalClientHelper.excuteRestCall(otpGenerateUrl,
				HttpMethod.POST, String.class, null, jsonRequest.toString(), headers);
		try {
			ObjectMapper mapper = new ObjectMapper();
			resBean = mapper.readValue(otpResponse.getBody().toString(), OTPBean.class);

		} catch (CreditEmployeePortalServiceException exception) {
			throw exception;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occurred." + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("OMEP_0135", e.getMessage()));
		}
		return resBean.getPayload();

	}
}