package com.bajaj.markets.credit.employeeportal.controller;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.AppDocVerificationRequest;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalAppDocVerificationService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
public class EmployeePortalAppDocVerificationController {

	@Autowired
	EmployeePortalAppDocVerificationService employeePortalAppDocVerificationService;

	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASSNAME = EmployeePortalAppDocVerificationController.class.getName();
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.SYSTEM, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update doc verification and sales hand-over details.", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Sales hand-over details saved successfully.", response = StatusBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/saleshandover", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> salesHandOverDetails(@RequestBody AppDocVerificationRequest appDocVerificationRequest,
			@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In salesHandOverDetails method for applicationId :" +applicationId+" with request: "+ appDocVerificationRequest);
		// service call
		StatusBean response = employeePortalAppDocVerificationService.saveSalesHandOverDetails(applicationId, appDocVerificationRequest,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out salesHandOverDetails method");
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.SYSTEM, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Update doc verification details.", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Doc verification  saved successfully.", response = StatusBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad request", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/verifications/{verificationflag}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateDocVerification(@PathVariable("verificationflag")  @NotNull(message = "verificationflag can not be null or empty") String verificationflag,
			@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateDocVerification method for applicationId :" +applicationId);
		StatusBean statusBean = new StatusBean();
		if(verificationflag.equalsIgnoreCase("true") || verificationflag.equalsIgnoreCase("false")) {
			String status = employeePortalAppDocVerificationService.updateDocVerification(applicationId, verificationflag,headers);
			statusBean.setStatus(status);
			if (statusBean.getStatus().equalsIgnoreCase(EmployeePortalConstants.SUCCESS)) {
				statusBean.setStatus(EmployeePortalConstants.SUCCESS);
				statusBean.setMessage(EmployeePortalConstants.DOC_VERIFICATION_SUCCESS);
				logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Successfully updated doc verification..");
			}else {
				statusBean.setStatus(EmployeePortalConstants.FAILURE);
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateDocVerification method");
			return new ResponseEntity<>(statusBean, HttpStatus.CREATED);
		}else {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateDocVerification method controller - resource validation failed");
			throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_22", "Please enter a valid verifiedflag value - TRUE or FALSE"));
		}
	}
}
