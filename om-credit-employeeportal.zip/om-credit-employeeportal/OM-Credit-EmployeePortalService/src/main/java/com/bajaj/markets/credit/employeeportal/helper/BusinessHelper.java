package com.bajaj.markets.credit.employeeportal.helper;

import static com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants.CIBIL_STATE_COMPLETED;
import static com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants.CIBIL_STATE_VERIFIED;

import java.math.BigDecimal;
import java.net.URI;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

import javax.validation.constraints.Digits;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.employeeportal.bean.AdditionalCustomerDetails;
import com.bajaj.markets.credit.employeeportal.bean.Address;
import com.bajaj.markets.credit.employeeportal.bean.AddressAuditDetails;
import com.bajaj.markets.credit.employeeportal.bean.AddressVerificationRequest;
import com.bajaj.markets.credit.employeeportal.bean.AppAuditRequest;
import com.bajaj.markets.credit.employeeportal.bean.AppDeviationBean;
import com.bajaj.markets.credit.employeeportal.bean.AppDeviationResponse;
import com.bajaj.markets.credit.employeeportal.bean.AppDocVerificationRequest;
import com.bajaj.markets.credit.employeeportal.bean.AppSecPDCDetail;
import com.bajaj.markets.credit.employeeportal.bean.AppUdfVerificationRequest;
import com.bajaj.markets.credit.employeeportal.bean.ApplicantCreateRequest;
import com.bajaj.markets.credit.employeeportal.bean.ApplicantProfile;
import com.bajaj.markets.credit.employeeportal.bean.ApplicationExceptionDetails;
import com.bajaj.markets.credit.employeeportal.bean.ApplicationStageDetails;
import com.bajaj.markets.credit.employeeportal.bean.AuditApplicantDetails;
import com.bajaj.markets.credit.employeeportal.bean.BankDetailsRequest;
import com.bajaj.markets.credit.employeeportal.bean.BankDetailsResponse;
import com.bajaj.markets.credit.employeeportal.bean.BreAddressReqOuput;
import com.bajaj.markets.credit.employeeportal.bean.BrePreferredMandateResponse;
import com.bajaj.markets.credit.employeeportal.bean.BusinessOwnerDetails;
import com.bajaj.markets.credit.employeeportal.bean.CibilDetails;
import com.bajaj.markets.credit.employeeportal.bean.CibilRequest;
import com.bajaj.markets.credit.employeeportal.bean.CibilResponse;
import com.bajaj.markets.credit.employeeportal.bean.CoapplicantRequest;
import com.bajaj.markets.credit.employeeportal.bean.CreditChecklistApproval;
import com.bajaj.markets.credit.employeeportal.bean.CreditStatus;
import com.bajaj.markets.credit.employeeportal.bean.DispositionDetails;
import com.bajaj.markets.credit.employeeportal.bean.DocPickupAddressRespBean;
import com.bajaj.markets.credit.employeeportal.bean.Email;
import com.bajaj.markets.credit.employeeportal.bean.EmailAuditDetails;
import com.bajaj.markets.credit.employeeportal.bean.EmailTypesBean;
import com.bajaj.markets.credit.employeeportal.bean.EmailVerificationDetail;
import com.bajaj.markets.credit.employeeportal.bean.EmailVerificationRequest;
import com.bajaj.markets.credit.employeeportal.bean.EmandateProviderResponseBean;
import com.bajaj.markets.credit.employeeportal.bean.EmandateRequest;
import com.bajaj.markets.credit.employeeportal.bean.EmandateResponse;
import com.bajaj.markets.credit.employeeportal.bean.EmployeeRequest;
import com.bajaj.markets.credit.employeeportal.bean.EmployerAuditDetails;
import com.bajaj.markets.credit.employeeportal.bean.EsignInfoRequest;
import com.bajaj.markets.credit.employeeportal.bean.EsignInfoResponse;
import com.bajaj.markets.credit.employeeportal.bean.EsignRequest;
import com.bajaj.markets.credit.employeeportal.bean.EsignResponse;
import com.bajaj.markets.credit.employeeportal.bean.FinalMandateResponse;
import com.bajaj.markets.credit.employeeportal.bean.GeoTaggingDetails;
import com.bajaj.markets.credit.employeeportal.bean.IncomeObligationRequest;
import com.bajaj.markets.credit.employeeportal.bean.IncomeObligationResponse;
import com.bajaj.markets.credit.employeeportal.bean.KycResponse;
import com.bajaj.markets.credit.employeeportal.bean.LoanRevisionBean;
import com.bajaj.markets.credit.employeeportal.bean.LoanRevisionResponse;
import com.bajaj.markets.credit.employeeportal.bean.LoanRevisionReviewRequest;
import com.bajaj.markets.credit.employeeportal.bean.LocationAddressBean;
import com.bajaj.markets.credit.employeeportal.bean.MandateBreRequest;
import com.bajaj.markets.credit.employeeportal.bean.MandateReference;
import com.bajaj.markets.credit.employeeportal.bean.NameDetail;
import com.bajaj.markets.credit.employeeportal.bean.NomineeAuditDetails;
import com.bajaj.markets.credit.employeeportal.bean.NotificationsRequest;
import com.bajaj.markets.credit.employeeportal.bean.OpenArcPerfiosCovertResponse;
import com.bajaj.markets.credit.employeeportal.bean.PanVerificationRequest;
import com.bajaj.markets.credit.employeeportal.bean.PanVerificationResponse;
import com.bajaj.markets.credit.employeeportal.bean.PerfiosCovertValidationRequest;
import com.bajaj.markets.credit.employeeportal.bean.PricingDetail;
import com.bajaj.markets.credit.employeeportal.bean.PricingStatus;
import com.bajaj.markets.credit.employeeportal.bean.RoleInfoBean;
import com.bajaj.markets.credit.employeeportal.bean.RoleMasterResponse;
import com.bajaj.markets.credit.employeeportal.bean.SendEmandateRequest;
import com.bajaj.markets.credit.employeeportal.bean.SendOkycRequest;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.bean.TranchBean;
import com.bajaj.markets.credit.employeeportal.bean.UTMRequest;
import com.bajaj.markets.credit.employeeportal.bean.UdfFlagDetailKeyBean;
import com.bajaj.markets.credit.employeeportal.bean.UserName;
import com.bajaj.markets.credit.employeeportal.bean.UserRoleBean;
import com.bajaj.markets.credit.employeeportal.model.AppDetailsVerification;
import com.bajaj.markets.credit.employeeportal.model.AppSecurityPDCDetail;
import com.bajaj.markets.credit.employeeportal.model.Application;
import com.bajaj.markets.credit.employeeportal.model.ApplicationAttribute;
import com.bajaj.markets.credit.employeeportal.model.BflBranchesMaster;
import com.bajaj.markets.credit.employeeportal.model.BureauHeader;
import com.bajaj.markets.credit.employeeportal.model.CibilReference;
import com.bajaj.markets.credit.employeeportal.model.PinCodeMaster;
import com.bajaj.markets.credit.employeeportal.repository.ApplicationAttributeRepository;
import com.bajaj.markets.credit.employeeportal.repository.ApplicationRepository;
import com.bajaj.markets.credit.employeeportal.repository.BureauHeaderRepository;
import com.bajaj.markets.credit.employeeportal.repository.CibilReferenceRepository;
import com.bajaj.markets.credit.employeeportal.repository.PinCodeMasterRepository;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.bajaj.markets.insurance.remoteapitrackinglib.bean.RemoteApiTrackingBean;
import com.bajaj.markets.insurance.remoteapitrackinglib.service.impl.RemoteApiTrackingImpl;

@Component
public class BusinessHelper {

	@Value("${api.usermanagement.userprofiles.GET.url}")
	private String userProfileUrl;

	@Value("${api.data.childapplication.url}")
	private String childApplicationUrl;

	@Value("${api.address.put.url}")
	private String appAddressUrl;

	@Value("${api.omcreditapplication.put.url}")
	private String callDispositionApplication;

	@Value("${api.masterdatamanagement.phone.GET.url}")
	private String phoneTypesUrl;

	@Value("${api.masterdatamanagement.email.GET.url}")
	private String emailTypesUrl;

	@Value("${api.bitly.url.GET.url}")
	private String shortenLinkUrl;

	@Value("${api.notifications.sendnotifications.POST.url}")
	private String sendNotificationUrl;

	@Value("${api.usermanagement.userroles.GET.url}")
	private String userRoleUrl;

	@Value("${api.omcibilverificationservice.cibil.get.url}")
	private String getCibilReferenceKeyUrl;

	@Value("${api.omcibilverificationservice.cibil.details.get.url}")
	private String getCibilDocumentUrl;

	@Value("${api.ckycbusiness.offline.initiate.POST.url}")
	private String getKycUrl;

	@Value("${api.ompaymentsemandatedomainservice.payment.mandates.POST.url}")
	private String getEmandateUrl;

	@Value("${api.data.esigndocument.put.url}")
	private String eSignUrl;

	@Value("${api.omcreditapplication.bankdetails.get.url}")
	private String getBankDetailsUrl;

	@Value("${api.omcreditapplication.bankdetails.put.url}")
	private String updateBankDetailsUrl;

	@Value("${api.omcreditapplication.bankdetails.post.url}")
	private String saveBankDetailsUrl;

	@Value("${api.omcreditapplication.application.put.url}")
	private String updateChildApplicationStatusUrl;

	@Value("${api.emandatedomaiin.payment.mandate.GET.url}")
	private String getMandateUrl;

	@Value("${api.omcreditapplication.getpreferredmandate.post.url}")
	private String getPreferredMandateUrl;

	@Value("${api.location.get.url}")
	private String pincodeLocationUrl;

	@Value("${api.omcreditapplication.updatecreditstatus.put.url}")
	private String updateCreditStatusUrl;

	@Value("${api.omcreditapplication.manualflag.put.url}")
	private String updateManualFlagUrl;

	@Autowired
	PinCodeMasterRepository pinCodeMasterRepository;

	@Value("${api.omcreditapplication.tranch.post.url}")
	private String tranchCtaPostUrl;

	@Value("${api.omcreditapplication.tranch.put.url}")
	private String tranchCtaPutUrl;

	@Value("${api.omcibilverificationservice.cibil.post.url}")
	private String performCibilPostUrl;

	@Value("${api.omcreditapplication.updatemandatekey.post.url}")
	private String updateMandateKeyUrl;

	@Value("${api.omcreditapplication.updateadditionalcustomerdetails.put.url}")
	private String updateAdditionalCustomerDetailsUrl;

	@Value("${api.omcreditapplicationservice.loan.loanrevision.POST.url}")
	private String saveLoanRevisionUrl;

	@Value("${api.omcreditapplicationservice.loan.loanrevision.review.PUT.url}")
	private String reviewloanRevisionUrl;

	@Value("${api.substage.url}")
	private String subStageUrl;

	@Value("${api.exception.update.url}")
	private String exceptionUpdateUrl;

	@Value("${api.application.deviation.POST.url}")
	private String updateDeviationDetailUrl;

	@Value("${api.applicant.openMarkets.createApplicant.POST.url}")
	private String createApplicantUrl;

	@Value("${api.applicant.openMarkets.getApplicantDocumentDetails.GET.url}")
	private String getApplicantDocumentUrl;

	@Value("${api.application.createApplicant.POST.url}")
	private String saveApplicantUrl;

	@Value("${api.application.updateApplicant.PUT.url}")
	private String updateApplicantUrl;
	
	@Value("${api.application.deleteapplicant.DELETE.url}")
	private String deleteApplicantUrl;

	@Value("${api.application.saleshandover.POST.url}")
	private String saveSalesHandsOverDetailsUrl;

	@Value("${api.omcreditapplication.updateIncomeObligation.put.url}")
	private String updateIncomeObligationUrl;

	@Value("${api.document.geotag.residence.GET.url}")
	private String geoTaggingUrlForRsidence;
	
	@Value("${api.document.geotag.office.GET.url}")
	private String geoTaggingUrlForOffice;

	@Value("${api.document.verifiedflag.POST.url}")
	private String saveVerifiedFlagUrl;

	@Value("${api.omcreditapplicationservice.application.creditapprovalchecklist.PUT.url}")
	private String updateCreditChecklistApprovalUrl;
	
	@Value("${bre.om.addressrequirement.resource.path}")
	private String openArchAddressReqBre;
	
	@Value("${api.application.addressverification.POST.url}")
	private String addressVerificationUrl;

	@Value("${api.omcreditapplication.spdc.PUT.url}")
	private String updateSPDCUrl;
	
	@Value("${api.omcreditapplication.email.GET.url}")
	private String getEmailUrl;
	
	@Value("${api.omverification.emailverification.POST.url}")
	private String saveEmailVerificationUrl;

	@Value("${api.omreferencedata.emandatebankmaster.GET.url}")
	private String getEmandateMasterDetailsUrl;
	
	@Value("${api.application.auditapplicationdetail.PUT.url}")
	private String updateAppicationDetailForAudit;
	
	@Value("${api.application.auditapplicantdetail.PUT.url}")
	private String updateApplicantDetailsForAudit;
	
	@Value("${api.application.auditaddressdetail.PUT.url}")
	private String updateAddressDetailsForAudit;
	
	@Value("${api.application.auditnomineedetail.PUT.url}")
	private String updateNomineeDetailsForAudit;
	
	@Value("${api.application.auditemployeedetail.PUT.url}")
	private String updateEmployeeDetailsForAudit;
	
	@Value("${api.application.policyissuance.PUT.url}")
	private String policyissuanceurl;
	
	@Value("${api.omverification.panverification.POST.url}")
	private String panVerificationUrl;

	@Value("${api.application.deviation.PUT.url}")
	private String editDeviationDetailsUrl;

	@Value("${api.application.auditutmdetail.PUT.url}")
	private String updateUTMDetailsForAudit;
	
	@Value("${api.ref.data.bflbranchdetails.GET.url}")
	private String getBflBranchDetails;

	@Value("${api.credit.application.loan.pricing.POST.url}")
	private String appLoanPricingUrl;
	
	@Value("${api.omcreditapplication.auditbusinessdetail.PUT.url}")
	private String updateBusinessDetailsForAudit;
	
	@Value("${api.omcreditapplication.auditnamedetail.PUT.url}")
	private String updateNameDetailsForAudit;
	
	@Value("${api.usermanagement.usersrole.mapping.GET.url}")
	private String roleInfoUrl;
	
	@Value("${api.usermanagement.rolemaster.GET.url}")
	private String roleMasterResponseUrl;
	
	@Value("${api.omcreditesignservice.fetchall.esign.GET.url}")
	private String esignInfoUrl;
	
	@Value("${api.omcreditesignservice.esign.PUT.url}")
	private String eSignInfoUpdateUrl;
	
	@Value("${api.application.auditemaildetail.PUT.url}")
	private String updateEmailDetailsForAudit;

	@Value("${api.credit.application.revise.pricing.update.PUT.url}")
	private String updatePricingStatus;
	
	@Value("${api.usermanagement.usersrole.mapping.GET.url}")
	private String rolekeyUrl;
	@Value("${api.omverificationverificationdomainservice.verification.income.estimation.GET.url}")
    private String getIncomeEstimationURL;
	
	@Autowired
	private ApplicationAttributeRepository applicationAttributeRepository;

	@Autowired
	private ApplicationRepository applicationepository;

	@Autowired
	CibilReferenceRepository cibilReferenceRepository;
	
	@Autowired
	CustomDefaultHeaders customDefaultHeaders;
	
	@Autowired
	BureauHeaderRepository bureauHeaderRepository;

	private static final String CLASS_NAME = BusinessHelper.class.getSimpleName();
	private static final String SOURCE = "EP";
	private static final String OFFICE_ADDRESS_KEY = "46";
	private static final String CURRENT_ADDRESS_KEY = "50";
	private static final String PERM_ADDRESS_KEY = "48";

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	CreditEmployeePortalClientHelper creditEmployeePortalClientHelper;
	
	@Autowired
	KibanaLoggingHelper kibanaLoggingHelper;
	
	@Value("${bre-auth-type}")
	private String authtype;

	@Value("${bre-auth-userName}")
	private String authuserName;

	@Value("${bre-auth-password}")
	private String authpassword;

	@Value("${bre.om.perfioscovert.resource.path}")
	private String openArchPerfiosCovertReqBre;
	
	@SuppressWarnings("unchecked")
	public List<UserName> getUserDetailsByUserRoleKey(Long userRoleKey, Boolean isPrincipleFlag, HttpHeaders headers) {
		Gson gson = new Gson();
		HashMap<String, String> params = new HashMap<>();
		params.put("userKey", userRoleKey.toString());
		params.put("isPrinciple", String.valueOf(isPrincipleFlag));
      	params.put("isUserkey", String.valueOf(false));
		List<UserName> userList = new ArrayList<UserName>();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(userProfileUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				String payload = getPayload(excuteRestCall.getBody().toString());
				UserName[] username = gson.fromJson(payload, UserName[].class);
				userList = Arrays.asList(username);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return userList;
	}
	
	@SuppressWarnings("unchecked")
	public List<UserName> getUserDetailsByUserKey(Long userRoleKey, Boolean isPrincipleFlag, HttpHeaders headers) {
		Gson gson = new Gson();
		HashMap<String, String> params = new HashMap<>();
		params.put("userKey", userRoleKey.toString());
		params.put("isPrinciple", String.valueOf(isPrincipleFlag));
		params.put("isUserkey", String.valueOf(true));
		List<UserName> userList = new ArrayList<UserName>();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(userProfileUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				String payload = getPayload(excuteRestCall.getBody().toString());
				UserName[] username = gson.fromJson(payload, UserName[].class);
				userList = Arrays.asList(username);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return userList;
	}

	@SuppressWarnings("unchecked")
	public List<com.bajaj.markets.credit.employeeportal.bean.Application> getChildApplicationDetails(Long applicationId,
			HttpHeaders headers) {
		Gson gson = new Gson();
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationkey", applicationId.toString());
		String isInProcessing = "true";
		UriComponents builder = UriComponentsBuilder.fromHttpUrl(childApplicationUrl)
				.queryParam("isInProcessing", isInProcessing).build();
		
		List<com.bajaj.markets.credit.employeeportal.bean.Application> applicationDetails = new ArrayList<>();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(builder.toUriString(), HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				String payload = getPayload(excuteRestCall.getBody().toString());
			   com.bajaj.markets.credit.employeeportal.bean.Application[] application =   gson
						.fromJson(payload, com.bajaj.markets.credit.employeeportal.bean.Application[].class);
				applicationDetails = Arrays.asList(application);
			}
			
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}

		return applicationDetails;
	}

	@SuppressWarnings("unchecked")
	public DispositionDetails updateDispositionDetails(DispositionDetails callCenterDisposition, String applicationId,
			String subSectionId, HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(callCenterDisposition);
		DispositionDetails callDispo = callApplicationServiceForDispositionUpdate(applicationId, subSectionId, headers,
				gson, jsonRequest);

		// update address for parent is child is updated successfully
		Application applicationDetail = applicationepository
				.findByApplicationkeyAndIsactive(Long.valueOf(applicationId), 1);
		if (applicationDetail.getApplicationkey().longValue() != applicationDetail.getParentapplicationkey()
				.longValue()) {
			callDispo = callApplicationServiceForDispositionUpdate(
					applicationDetail.getParentapplicationkey().toString(), subSectionId, headers, gson, jsonRequest);
		}
		return callDispo;
	}

	/**
	 * @param applicationId
	 * @param subSectionId
	 * @param headers
	 * @param gson
	 * @param jsonRequest
	 * @return
	 */
	public DispositionDetails callApplicationServiceForDispositionUpdate(String applicationId, String subSectionId,
			HttpHeaders headers, Gson gson, String jsonRequest) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		params.put("subsectionId", subSectionId);
		params.put("sectionId", "1");
		DispositionDetails callDispo = new DispositionDetails();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(callDispositionApplication, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				callDispo = gson.fromJson(excuteRestCall.getBody(), DispositionDetails.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return callDispo;
	}

	public Address updateAddressDetails(Address addressDetails, String applicationId, String subsectionId,
			HttpHeaders headers) {
		Address response = new Address();
		try {
			Gson gson = new Gson();

			Map<String, String> locationParam = new HashMap<>();
			locationParam.put("pincode", addressDetails.getPincodeKey());
			switch (Integer.valueOf(subsectionId)) {
			case 1015:
				addressDetails.setAddressTypeKey(OFFICE_ADDRESS_KEY);
				break;
			case 1016:
				addressDetails.setAddressTypeKey(CURRENT_ADDRESS_KEY);
				break;
			case 1017:
				addressDetails.setAddressTypeKey(PERM_ADDRESS_KEY);
				break;
			}

			ResponseEntity<String> locationResp = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(pincodeLocationUrl, HttpMethod.GET, String.class, locationParam, null, headers);

			if (null != locationResp.getBody().toString()) {

				LocationAddressBean locationAddressBean = gson.fromJson(locationResp.getBody().toString(),
						LocationAddressBean.class);
				if (null != locationAddressBean) {
					addressDetails.setStateKey(locationAddressBean.getStateId().toString());
					addressDetails.setCityKey(locationAddressBean.getCityId().toString());
					addressDetails.setCountryKey(locationAddressBean.getCountryId().toString());
				}
			}

			PinCodeMaster pinCodeMaster = pinCodeMasterRepository
					.findByPincodeAndIsactive(addressDetails.getPincodeKey(), 1);
			if (pinCodeMaster != null)
				addressDetails.setPincodeKey(pinCodeMaster.getPincodekey().toString());
			addressDetails.setAddressSource(SOURCE);

			response = callApplicationServiceForAddressUpdate(addressDetails, applicationId, headers, response, gson);

			// update address for parent is child is updated successfully
			Application applicationDetail = applicationepository
					.findByApplicationkeyAndIsactive(Long.valueOf(applicationId), 1);
			if (applicationDetail.getApplicationkey().longValue() != applicationDetail.getParentapplicationkey()
					.longValue()) {
				response = callApplicationServiceForAddressUpdate(addressDetails,
						applicationDetail.getParentapplicationkey().toString(), headers, response, gson);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return response;
	}

	/**
	 * @param addressDetails
	 * @param applicationId
	 * @param headers
	 * @param response
	 * @param gson
	 * @return
	 */
	public Address callApplicationServiceForAddressUpdate(Address addressDetails, String applicationId,
			HttpHeaders headers, Address response, Gson gson) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		List<ApplicationAttribute> appAttribute = applicationAttributeRepository
				.findByApplication_ApplicationkeyAndApplicanttypeAndIsactiveOrderByAppattrbkeyDesc(Long.parseLong(applicationId),1L, 1);
		AtomicLong appAttrKey =new AtomicLong();
				appAttribute.forEach(appAttr ->{
			if(appAttr.getApplicanttype().longValue()==1L) {
				appAttrKey.set(appAttr.getAppattrbkey().longValue());
			}
		});
		params.put("userattributekey", appAttrKey.longValue() != 0L ? appAttrKey.toString():  appAttribute.get(0).getAppattrbkey().toString());
		String jsonReq = gson.toJson(addressDetails);
		@SuppressWarnings("unchecked")
		ResponseEntity<String> addressResp = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(appAddressUrl, HttpMethod.PUT, String.class, params, jsonReq, headers);
		if (addressResp.getStatusCode().equals(HttpStatus.CREATED)) {
			response = gson.fromJson(addressResp.getBody().toString(), Address.class);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Error occurred in principle integration service." + addressResp.getBody().toString());
			throw new CreditEmployeePortalServiceException(addressResp.getStatusCode(),
					new ErrorBean("OMCA_012", "Error occurred in Credit Application service."));
		}
		return response;
	}

	private String getPayload(String requestBody) {
		String newStr = requestBody.substring(0, requestBody.indexOf("]"));
		String s1 = newStr.substring(newStr.indexOf("[") + 1);
		String s2 = s1.trim();
		String s3 = "[".concat(s2).concat("]");
		return s3;

	}

	@SuppressWarnings("unchecked")
	public Long getEmailTypeMaster(HttpHeaders headers) {
		Long emailTypeKey = null;
		Gson gson = new Gson();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(emailTypesUrl, HttpMethod.GET, String.class, null, null, headers);
		try {
			if (null != excuteRestCall.getBody().toString()) {

				String payload = getPayload(excuteRestCall.getBody().toString());
				EmailTypesBean[] emailTypes = gson.fromJson(payload, EmailTypesBean[].class);

				List<EmailTypesBean> list = Arrays.asList(emailTypes);

				for (EmailTypesBean emailtype : list) {
					if (emailtype.getEmailtypecode().equalsIgnoreCase("PERSON1")) {
						emailTypeKey = emailtype.getEmailtypekey();
					}
				}
			}

		} catch (Exception e) {
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response for getEmailTypeMaster.");
		}
		return emailTypeKey;
	}

	@SuppressWarnings("unchecked")
	public String shortenurl(String url, HttpHeaders headers) {
		String shrtUrl = null;
		try {

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Shorten url starts!");
			Map<String, String> params = new HashMap<>();
			params.put("url", url);
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(shortenLinkUrl, HttpMethod.GET, String.class, params, null, headers);
			if (null != excuteRestCall.getBody()) {
				shrtUrl = getShortUrl(excuteRestCall.getBody());
			}
		} catch (Exception e) {
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception on shorten url.");
		}
		return shrtUrl;
	}

	private String getShortUrl(String payload) {
		String s3[] = payload.split(": \"");
		String s4 = s3[2];
		String s5[] = s4.split("\"");
		return s5[0];
	}

	@SuppressWarnings("unchecked")
	public String sendNotification(NotificationsRequest notificationsRequest, HttpHeaders headers) {

		try {
			Gson gson = new Gson();
			String jsonReq = gson.toJson(notificationsRequest);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "sendNotification starts!");

			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(sendNotificationUrl, HttpMethod.POST, String.class, null, jsonReq, headers);
			if (excuteRestCall.getBody().toString().contains("SUCCESS")) {
				return "Complete";
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Send Notification exception.");
				throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
						new ErrorBean("OMCA_033", "Error while sending notification."));
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Send Notification exception.");
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("OMCA_033", "Error while sending notification."));
		}

	}

	@SuppressWarnings("unchecked")
	public String getUserRoleDetails(Long userKey, Long roleKey, HttpHeaders headers) {
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("userKey", userKey.toString());
		paramMap.put("roleKey", roleKey.toString());
		String userRoleKey = null;
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(userRoleUrl, HttpMethod.GET, String.class, paramMap, null, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				String payloadString = excuteRestCall.getBody().toString();
				userRoleKey = extractInt(payloadString);
				logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response ");
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return userRoleKey;
	}

	public String extractInt(String str) {
		str = str.replaceAll("[^\\d]", " ");
		str = str.trim();
		str = String.valueOf(str);
		return str.substring(0, str.indexOf(" "));
	}

	@SuppressWarnings("unchecked")
	public String getCibilDetails(String applicationId, HttpHeaders headers) {
		Gson gson = new Gson();
		String cibilString = null;
		HashMap<String, String> params = new HashMap<>();
		params.put("cibiltype", null);
		params.put("applicationkey", applicationId);
		params.put("applicantkey", null);

		// call for cibilReferencekey
		ResponseEntity<String> excuteRestCallForCibilReferenceKey = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(getCibilReferenceKeyUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCallForCibilReferenceKey.getBody()) {
				CibilDetails[] cibilDetail = gson.fromJson(excuteRestCallForCibilReferenceKey.getBody(),
						CibilDetails[].class);
				List<CibilDetails> list = Arrays.asList(cibilDetail);
				Long cibilReferenceKey = list.get(0).getCibilReferenceNumber();
				if (cibilReferenceKey != null) {
					// check for state
					Optional<CibilReference> cibilReference = cibilReferenceRepository.findById(cibilReferenceKey);
					if (CIBIL_STATE_VERIFIED.equalsIgnoreCase(cibilReference.get().getState())
							|| CIBIL_STATE_COMPLETED.equalsIgnoreCase(cibilReference.get().getState())) {
						HashMap<String, String> param = new HashMap<>();
						param.put("cibilreference", cibilReferenceKey.toString());

						// call for cibilDocument
						ResponseEntity<?> excuteRestCallForCibilDocument = (ResponseEntity<String>) creditEmployeePortalClientHelper
								.excuteRestCall(getCibilDocumentUrl, HttpMethod.GET, String.class, param, null,
										headers);

						if (null != excuteRestCallForCibilDocument.getBody()) {
							cibilString = excuteRestCallForCibilDocument.getBody().toString();
						}
					} else {
						logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
								"Cibil Report not generated for given application Id.");
						throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,
								new ErrorBean("OMCA_033", "Cibil Report not generated for given application Id."));
					}
				}
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Cibil Report not generated");
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,
					new ErrorBean("OMCA_033", "Cibil Report not generated"));
		}

		return cibilString;
	}

	@SuppressWarnings("unchecked")
	public KycResponse getKyc(SendOkycRequest sendokycrequest, HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(sendokycrequest);
		KycResponse callKyc = new KycResponse();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(getKycUrl, HttpMethod.POST, String.class, null, jsonRequest, headers);
		try {

			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping Response...");
				callKyc = gson.fromJson(excuteRestCall.getBody().toString(), KycResponse.class);

			}
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return callKyc;
	}

	@SuppressWarnings("unchecked")
	public EmandateResponse getEmandate(SendEmandateRequest sendEmandateRequest, HttpHeaders headers, EmandateRequest request) {
			sendEmandateRequest.setMandateType(request.isPhysicalMandate() == true
				? 2l
				: null);
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(sendEmandateRequest);
		EmandateResponse callEmandate = new EmandateResponse();
		MandateReference mandateReference = new MandateReference();
		String mandateBitlyUrl = null;
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(getEmandateUrl, HttpMethod.POST, String.class, null, jsonRequest, headers);
		try {

			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping Response...");
				callEmandate = gson.fromJson(excuteRestCall.getBody().toString(), EmandateResponse.class);
				mandateBitlyUrl = callEmandate.getMandateBitlyUrl();
				if (request.isPhysicalMandate() == true) {
					mandateReference.setApplicationId(Long.valueOf(sendEmandateRequest.getApplicationKey()));
					mandateReference.setFinalMandatekey(Long.valueOf(callEmandate.getMandateReference()));
					saveFinalMandate(mandateReference, Long.valueOf(sendEmandateRequest.getApplicationKey()), headers);
				}
			}
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return callEmandate;

	}

	public EsignResponse updateEsignDocument(EsignRequest esignRequest, String applicationKey, HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(esignRequest);
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);
		EsignResponse esignResponse = new EsignResponse();
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(eSignUrl, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				esignResponse = gson.fromJson(excuteRestCall.getBody(), EsignResponse.class);
			}
		} catch (CreditEmployeePortalServiceException creditException) {
			throw creditException;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response ", e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "Parsing exception");
		}
		return esignResponse;
	}

	@SuppressWarnings("unchecked")
	public List<BankDetailsResponse> getBankDetails(String applicationKey,Boolean isPreferedForRepayment, HttpHeaders headers) {
		Gson gson = new Gson();
		UriComponentsBuilder builder = null;
		URI uri;
		List<BankDetailsResponse> bankDetailsList = new ArrayList<>();
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);
		try {
			if (null != getBankDetailsUrl) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getBankDetails for" + applicationKey
						+ " isPreferedForRepayment:" + isPreferedForRepayment + " URL:" + getBankDetailsUrl);
				builder = UriComponentsBuilder.fromUriString(getBankDetailsUrl).queryParam("isPreferedForRepayment",
						null != isPreferedForRepayment ? isPreferedForRepayment.toString() : null);
				uri = builder.buildAndExpand(params).toUri();
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getBankDetails URI:" + uri);
				ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
						.excuteRestCall(uri.toString(), HttpMethod.GET, String.class, params, null, headers);
				if (null != excuteRestCall.getBody()) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
					BankDetailsResponse[] bankDetails = gson.fromJson(excuteRestCall.getBody(),
							BankDetailsResponse[].class);
					bankDetailsList = Arrays.asList(bankDetails);
				}
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return bankDetailsList;
	}

	@SuppressWarnings("unchecked")
	public BankDetailsResponse updateBankDetails(BankDetailsRequest bankDetailsRequest, String applicationKey,
			String bankdetailskey, HttpHeaders headers) {
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);
		params.put("bankdetailskey", bankdetailskey);
		String jsonRequestParam = gson.toJson(bankDetailsRequest);
		BankDetailsResponse bankDetailsResponse = new BankDetailsResponse();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateBankDetailsUrl, HttpMethod.PUT, String.class, params, jsonRequestParam, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				bankDetailsResponse = gson.fromJson(excuteRestCall.getBody(), BankDetailsResponse.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return bankDetailsResponse;
	}

	@SuppressWarnings("unchecked")
	public BankDetailsResponse saveBankDetails(BankDetailsRequest bankDetailsRequest, String applicationKey,
			HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(bankDetailsRequest);
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);
		BankDetailsResponse bankDetailsResponse = new BankDetailsResponse();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(saveBankDetailsUrl, HttpMethod.POST, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				bankDetailsResponse = gson.fromJson(excuteRestCall.getBody(), BankDetailsResponse.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return bankDetailsResponse;
	}

	@SuppressWarnings("unchecked")
	public String updateChildApplicationStatus(Long applicationId, HttpHeaders headers) {
		String status = null;
		HttpStatus statusCode = HttpStatus.OK;
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId.toString());
		try {

			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(updateChildApplicationStatusUrl, HttpMethod.PUT, StatusBean.class, params, null,
							headers);
			if (excuteRestCall.getStatusCode() == statusCode) {
				status = EmployeePortalConstants.APPLICATION_UPDATED_SUCCESS;
			}

		} catch (Exception e) {
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception occurred while calling updateChildApplicationStatus");
		}
		return status;

	}

	@SuppressWarnings("unchecked")
	public List<EmandateResponse> getEmandateDetails(String bankAccountNum, HttpHeaders headers) {
		Gson gson = new Gson();
		List<EmandateResponse> list = new ArrayList<EmandateResponse>();
		Map<String, String> params = new HashMap<>();
		params.put("bankAccount", bankAccountNum);
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(getMandateUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				EmandateResponse[] emandateResponse = gson.fromJson(excuteRestCall.getBody().toString(),
						EmandateResponse[].class);
				list = Arrays.asList(emandateResponse);
			}
		} catch (Exception e) {
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing getEmandateDetails response from application seervice .");
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	public BrePreferredMandateResponse getPreferredBREMandateDetails(MandateBreRequest mandateBreRequest,
			String applicationKey, String bankdetailskey, HttpHeaders headers) {
		Gson gson = new Gson();
		BrePreferredMandateResponse emandateResponse = new BrePreferredMandateResponse();
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);
		params.put("bankdetailskey", bankdetailskey);
		String jsonRequest = gson.toJson(mandateBreRequest);
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(getPreferredMandateUrl, HttpMethod.POST, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				emandateResponse = gson.fromJson(excuteRestCall.getBody().toString(),
						BrePreferredMandateResponse.class);

			}
		} catch (Exception e) {
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from application seervice .");
		}
		return emandateResponse;
	}

	@SuppressWarnings("unchecked")
	public TranchBean saveTranchDetails(TranchBean tranchBean, Long applicationKey, HttpHeaders headers) {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		String jsonRequest = gson.toJson(tranchBean);
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey.toString());
		TranchBean tranch = new TranchBean();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(tranchCtaPostUrl, HttpMethod.POST, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				tranch = gson.fromJson(excuteRestCall.getBody(), TranchBean.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}

		return tranch;
	}

	@SuppressWarnings("unchecked")
	public CreditStatus updateCreditStatusDetails(CreditStatus creditStatus, String applicationId,
			HttpHeaders headers) {
		CreditStatus response = new CreditStatus();
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		String jsonRequest = gson.toJson(creditStatus);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateCreditStatusUrl, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				response = gson.fromJson(excuteRestCall.getBody(), CreditStatus.class);
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "Exception while parsing response");
		}
		return response;
	}

	@SuppressWarnings("unchecked")
	public TranchBean updateTranchDetails(TranchBean tranchBean, Long applicationId, Long tranchKey,
			HttpHeaders headers) {
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		String jsonRequest = gson.toJson(tranchBean);
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationId.toString());
		params.put("tranchKey", tranchKey.toString());
		TranchBean tranch = new TranchBean();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(tranchCtaPutUrl, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				tranch = gson.fromJson(excuteRestCall.getBody(), TranchBean.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}

		return tranch;
	}

	@SuppressWarnings("unchecked")
	public CibilResponse performCibil(CibilRequest cibilRequest, HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(cibilRequest);
		CibilResponse cibilResponse = new CibilResponse();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(performCibilPostUrl, HttpMethod.POST, String.class, null, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				cibilResponse = gson.fromJson(excuteRestCall.getBody(), CibilResponse.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return cibilResponse;
	}

	public String updateManualFlag(Long applicationId, AppUdfVerificationRequest udfVerificationRequest,
			HttpHeaders headers) {
		String status = null;
		Map<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		UdfFlagDetailKeyBean udfBean = new UdfFlagDetailKeyBean();
		String jsonRequest = gson.toJson(udfVerificationRequest);
		params.put("applicationid", applicationId.toString());

		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateManualFlagUrl, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				udfBean = gson.fromJson(excuteRestCall.getBody(), UdfFlagDetailKeyBean.class);
				if (udfBean.getMessage().equalsIgnoreCase("SUCCESS"))
					status = EmployeePortalConstants.MANUAL_FLAG_ADDED;
				else
					status = EmployeePortalConstants.MANUAL_FLAG_FAILED;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}

		return status;
	}

	@SuppressWarnings("unchecked")
	public FinalMandateResponse saveFinalMandate(MandateReference mandateReference, Long applicationId,
			HttpHeaders headers) {
		FinalMandateResponse finalMandateResponse = new FinalMandateResponse();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId.toString());
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(mandateReference);
		try {
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(updateMandateKeyUrl, HttpMethod.POST, String.class, params, jsonRequest, headers);

			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				finalMandateResponse = gson.fromJson(excuteRestCall.getBody(), FinalMandateResponse.class);
				finalMandateResponse.setMessage(EmployeePortalConstants.FINAL_MANDATEKEY_UPDATED);
				finalMandateResponse.setStatus(EmployeePortalConstants.SUCCESS);
			} else {
				finalMandateResponse.setStatus(EmployeePortalConstants.FAILURE);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing Final mandate response from application service .");
		}
		return finalMandateResponse;

	}

	@SuppressWarnings("unchecked")
	public AdditionalCustomerDetails updateAdditionalCustomerDetails(
			AdditionalCustomerDetails additionalCustomerDetails, String applicationId, String subsectionId,
			HttpHeaders headers) {
		AdditionalCustomerDetails response = new AdditionalCustomerDetails();
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		additionalCustomerDetails.setTypeKey(49L);
		additionalCustomerDetails.setLstUpdateBy(customDefaultHeaders.getUserKey());
		String jsonRequest = gson.toJson(additionalCustomerDetails);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateAdditionalCustomerDetailsUrl, HttpMethod.PUT, String.class, params, jsonRequest,
						headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				response = gson.fromJson(excuteRestCall.getBody(), AdditionalCustomerDetails.class);
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "Exception while parsing response");
		}
		return response;
	}

	@SuppressWarnings("unchecked")
	public LoanRevisionResponse updateloanRevision(LoanRevisionBean loanRevisionBean, String applicationKey,
			HttpHeaders headers) {

		LoanRevisionResponse loanRevisionResponse = new LoanRevisionResponse();
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(loanRevisionBean);

		try {
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(saveLoanRevisionUrl, HttpMethod.POST, String.class, params, jsonRequest, headers);

			if (null != excuteRestCall && null != excuteRestCall.getBody()
					&& (excuteRestCall.getStatusCode().equals(HttpStatus.CREATED)
							|| excuteRestCall.getStatusCode().equals(HttpStatus.OK))) {

				loanRevisionResponse = gson.fromJson(excuteRestCall.getBody(), LoanRevisionResponse.class);
				loanRevisionResponse
						.setCreated(excuteRestCall.getStatusCode().equals(HttpStatus.CREATED) ? true : false);
				// loanRevisionResponse.setMessage(EmployeePortalConstants.UPDATED_LAON_REVISION);
				// loanRevisionResponse.setStatus(EmployeePortalConstants.SUCCESS);
			} else {
				loanRevisionResponse.setStatus(EmployeePortalConstants.FAILURE);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing loanRevisionResponse from application service .");
		}
		return loanRevisionResponse;

	}

	@SuppressWarnings("unchecked")
	public LoanRevisionResponse reviewloanRevision(LoanRevisionReviewRequest loanRevisionReviewRequest,
			@Digits(fraction = 0, integer = 20, message = "applicationKey can not be other than digits") String applicationKey,
			HttpHeaders headers) {

		LoanRevisionResponse loanRevisionResponse = new LoanRevisionResponse();
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);

		Gson gson = new Gson();
		String jsonRequest = gson.toJson(loanRevisionReviewRequest);

		try {
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(reviewloanRevisionUrl, HttpMethod.PUT, String.class, params, jsonRequest, headers);

			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				loanRevisionResponse = gson.fromJson(excuteRestCall.getBody(), LoanRevisionResponse.class);
				// loanRevisionResponse.setMessage(EmployeePortalConstants.UPDATED_LAON_REVISION);
				// loanRevisionResponse.setStatus(EmployeePortalConstants.SUCCESS);
			} else {
				loanRevisionResponse.setStatus(EmployeePortalConstants.FAILURE);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing reviewloanRevision from application service .");
		}
		return loanRevisionResponse;

	}

	@SuppressWarnings("unchecked")
	public ApplicationStageDetails getApplicationStageDetails(String applicationId, HttpHeaders headers) {
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);

		ApplicationStageDetails subStageDetails = new ApplicationStageDetails();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(subStageUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				subStageDetails = gson.fromJson(excuteRestCall.getBody(), ApplicationStageDetails.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}

		return subStageDetails;
	}

	@SuppressWarnings("unchecked")
	public void updateApplicationStageDetails(String applicationId, ApplicationStageDetails subStageDetails,
			ApplicationExceptionDetails exceptionDetails, String parentApplicationId, Long prodL2,HttpHeaders headers) {
		Gson gson = new Gson();
		Map<String, String> stageParams = new HashMap<>();
		stageParams.put("applicationid", applicationId);
		if(prodL2==10001)
			stageParams.put("applicationid", parentApplicationId);
		
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);

		String stageJsonrequest = gson.toJson(subStageDetails);
		String exceptionJsonrequest = gson.toJson(exceptionDetails);
		creditEmployeePortalClientHelper.excuteRestCall(subStageUrl, HttpMethod.PUT, String.class, stageParams,
				stageJsonrequest, headers);

		creditEmployeePortalClientHelper.excuteRestCall(exceptionUpdateUrl, HttpMethod.POST, String.class, params,
				exceptionJsonrequest, headers);

	}

	@SuppressWarnings("unchecked")
	public String saveDeviationDetails(AppDeviationBean appDeviationBean, Long applicationId, HttpHeaders headers) {
		AppDeviationResponse response = new AppDeviationResponse();
		Gson gson = new Gson();
		Map<String, String> param = new HashMap<>();
		param.put("applicationid", applicationId.toString());
		String jsonRequest = gson.toJson(appDeviationBean);
		try {
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(updateDeviationDetailUrl, HttpMethod.POST, String.class, param, jsonRequest,
							headers);

			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				response = gson.fromJson(excuteRestCall.getBody(), AppDeviationResponse.class);
				response.setStatus(EmployeePortalConstants.DEVIATION_ADDED);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing deviation response from application service .");
		}
		return response.getStatus();

	}

	public ApplicantProfile createApplicant(ApplicantCreateRequest applicantCreateRequest, HttpHeaders headers) {
		ApplicantProfile profile = new ApplicantProfile();
		Map<String, String> params = new HashMap<>();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		String jsonRequest = gson.toJson(applicantCreateRequest);

		try {
			@SuppressWarnings("unchecked")
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(createApplicantUrl, HttpMethod.POST, String.class, params, jsonRequest, headers);

			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				profile = gson.fromJson(excuteRestCall.getBody(), ApplicantProfile.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing applicant profile from application service .");
		}
		return profile;
	}

	@SuppressWarnings("unchecked")
	public ApplicantProfile getApplicantDocumentDetails(Long mobile, Date dob, HttpHeaders headers) {
		Gson gson = new Gson();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dateOfBirth = sdf.format(dob);
		Map<String, String> params = new HashMap<>();
		params.put("mobile", mobile.toString());
		params.put("dateOfBirth", dateOfBirth);
		ApplicantProfile applicantProfileDetails = new ApplicantProfile();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(getApplicantDocumentUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				applicantProfileDetails = gson.fromJson(excuteRestCall.getBody(), ApplicantProfile.class);
			} else {

				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "No applicant not found for application ");
				throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,
						new ErrorBean("OMCA_012", "No records found for given application"));
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return applicantProfileDetails;

	}

	public Long updateApplicantToApplicationAttribute(CoapplicantRequest applicantRequest, Long applicationId,
			HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId.toString());
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		Long appatrrbkey = 0L;
		String jsonRequest = gson.toJson(applicantRequest);
		try {
			@SuppressWarnings("unchecked")
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(updateApplicantUrl, HttpMethod.PUT, String.class, params, jsonRequest, headers);
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				appatrrbkey = gson.fromJson(excuteRestCall.getBody(), Long.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing applicant profile from application service .");
		}
		return appatrrbkey;
	}
	
	public Long saveApplicantToApplicationAttribute(ApplicantCreateRequest applicantCreateRequest, Long applicationId,
			HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId.toString());
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		Long appatrrbkey = 0L;
		String jsonRequest = gson.toJson(applicantCreateRequest);
		try {
			@SuppressWarnings("unchecked")
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(saveApplicantUrl, HttpMethod.POST, String.class, params, jsonRequest, headers);
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				appatrrbkey = gson.fromJson(excuteRestCall.getBody(), Long.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing applicant profile from application service .");
		}
		return appatrrbkey;
	}

	public Long deleteApplicant(Long applicationId, HttpHeaders headers) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId.toString());
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		Long appatrrbkey = 0L;
		try {
			@SuppressWarnings("unchecked")
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(deleteApplicantUrl, HttpMethod.DELETE, String.class, params, null, headers);
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				appatrrbkey = gson.fromJson(excuteRestCall.getBody(), Long.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing applicant profile from application service .");
		}
		return appatrrbkey;
	}

	@SuppressWarnings("unchecked")
	public String saveSalesHandOverDetails(AppDocVerificationRequest appDocVerificationRequest, Long applicationId,
			HttpHeaders headers) {

		Gson gson = new Gson();
		String status = null;
		Map<String, String> param = new HashMap<>();
		param.put("applicationid", applicationId.toString());
		HttpStatus statusCode = HttpStatus.CREATED;
		String jsonRequest = gson.toJson(appDocVerificationRequest);
		try {

			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(saveSalesHandsOverDetailsUrl, HttpMethod.POST, String.class, param, jsonRequest,
							headers);

			if (null != excuteRestCall && null != excuteRestCall.getBody()) {

				if (excuteRestCall.getStatusCode() == statusCode) {
					status = "SUCCESS";
				}

			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while saving sales hand-over details from application service .");
		}
		return status;
	}
	
	public String updateIncomeObligation(IncomeObligationRequest incomeObligationRequest, Long applicationId,HttpHeaders headers) 
	{
		String status = null;
		Map<String, String> params = new HashMap<>();
		Gson gson = new Gson();
		IncomeObligationResponse response = new IncomeObligationResponse();
		String jsonRequest = gson.toJson(incomeObligationRequest);
		params.put("applicationid", applicationId.toString());
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(updateIncomeObligationUrl, HttpMethod.PUT, String.class, params, jsonRequest,
							headers);
		try {
			if (null != excuteRestCall.getBody()){
				response = gson.fromJson(excuteRestCall.getBody(), IncomeObligationResponse.class);
				if(null != response)
					status = EmployeePortalConstants.INCOME_OBLIGATION_ADDED;
				else
					status=EmployeePortalConstants.FAILURE;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,"");
		}

		return status;
	}

	public List<GeoTaggingDetails> getResidentialGeoTaggingFields(String applicationId, HttpHeaders headers) {
		Gson gson = new Gson();
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationId", applicationId);
		List<GeoTaggingDetails> geoTaggingList = new ArrayList<>();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(geoTaggingUrlForRsidence, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				GeoTaggingDetails[] geoTaggingDetails = gson.fromJson(excuteRestCall.getBody(), GeoTaggingDetails[].class);
				geoTaggingList = Arrays.asList(geoTaggingDetails);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return geoTaggingList;
	}

	public List<GeoTaggingDetails> getOfficeGeoTaggingFields(String applicationId, HttpHeaders headers) {
		Gson gson = new Gson();
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationId", applicationId);
		List<GeoTaggingDetails> geoTaggingList = new ArrayList<>();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(geoTaggingUrlForOffice, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				GeoTaggingDetails[] geoTaggingDetails = gson.fromJson(excuteRestCall.getBody(), GeoTaggingDetails[].class);
				geoTaggingList = Arrays.asList(geoTaggingDetails);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return geoTaggingList;
	}

	public String updateDocVerification(Long applicationId, String verifiedflag, HttpHeaders headers) {
		String status = null;
		Gson gson = new Gson();
		Map<String, String> param = new HashMap<>();
		param.put("applicationid", applicationId.toString());
		param.put("verificationflag", verifiedflag);
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(saveVerifiedFlagUrl, HttpMethod.POST, String.class, param, null,headers);
		try {
			if (null != excuteRestCall.getBody()){
				Long response = gson.fromJson(excuteRestCall.getBody(), Long.class);
				if(null != response)
					status = EmployeePortalConstants.SUCCESS;
				else 
					status = EmployeePortalConstants.FAILURE;
			}
		}  catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,"");
		}
		return status;
	}
	public StatusBean updateAppSecPDCDetailFields(AppSecPDCDetail appSecPDCDetail, String applicationId,
			String subsectionId, HttpHeaders headers) {
		AppSecurityPDCDetail appSecurityPDCDetail = new AppSecurityPDCDetail();
		Gson gson = new Gson();
		StatusBean response = new StatusBean();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		String jsonRequest = gson.toJson(appSecPDCDetail);
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateSPDCUrl, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				appSecurityPDCDetail = gson.fromJson(excuteRestCall.getBody(), AppSecurityPDCDetail.class);
				if(null != appSecurityPDCDetail) {
					response.setStatus(EmployeePortalConstants.SUCCESS);
					response.setMessage(EmployeePortalConstants.SPDC_UPDATE_SUCCESS);
				}
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "Exception while parsing response");
		}
		return response;
		
	}
	
	@SuppressWarnings("unchecked")
	public CreditChecklistApproval updateCreditChecklistApprovalDetails(
			CreditChecklistApproval creditChecklistApproval, String applicationId, String subsectionId,
			HttpHeaders headers) {
		CreditChecklistApproval response = new CreditChecklistApproval();
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		String jsonRequest = gson.toJson(creditChecklistApproval);
		try {
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateCreditChecklistApprovalUrl, HttpMethod.PUT, String.class, params, jsonRequest,
						headers);
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				response = gson.fromJson(excuteRestCall.getBody(), CreditChecklistApproval.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "Exception while parsing response");
		}
		return response;
	}

	public BreAddressReqOuput getOpenArcAddressReqBreResponse(DocPickupAddressRespBean docPickupAddressRespBean, HttpHeaders headers, String applicationId ) {
		BreAddressReqOuput response = null;
		String errorMessage=null;
        String status=null;
		Gson gson = new Gson();
		String breRequest = gson.toJson(docPickupAddressRespBean);
		headers.add(HttpHeaders.AUTHORIZATION, getAuthDetails());
		Map<String, String> param = new HashMap<>();
		param.put("applicationid", applicationId);
		RemoteApiTrackingBean apiTrackingBean = kibanaLoggingHelper.apiTrackingBeanCreation (
				applicationId,
                applicationId,
                breRequest , appAddressUrl, EmployeePortalConstants.ADDRESSREQUIREMENTBRE_SOURCE, EmployeePortalConstants.ADDRESSREQUIREMENTBRE_TARGET);
		ResponseEntity<String> excuteRestCall = null;
		try {
		excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(openArchAddressReqBre, HttpMethod.POST, String.class, param, breRequest,headers);
		
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				response = gson.fromJson(excuteRestCall.getBody(), BreAddressReqOuput.class);
				status = "SUCCESS";
				apiTrackingBean.setResponsePayload(excuteRestCall.getBody());
				 apiTrackingBean.setStatus(status);
			}
		}  catch (Exception e) {
			errorMessage = "Exception while parsing in AddressRequirement response." + e;
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,"");
		}
		finally {

	        if(null != apiTrackingBean) {
	        	apiTrackingBean.setResponseTimeStamp(new Timestamp(System.currentTimeMillis()).toString());
	        	if (status == null || !status.equals("SUCCESS")) {
	            	apiTrackingBean.setResponsePayload(excuteRestCall != null ? excuteRestCall.toString() : null);
	            	apiTrackingBean.setStatus("FAILURE");
	            	apiTrackingBean.setError(errorMessage);
	            }
	            kibanaLoggingHelper.save(apiTrackingBean);
	        }
		}
		return response;
	}
	
	public AppDetailsVerification putAddressVerification(String applicationId, AddressVerificationRequest verificationDetReq, HttpHeaders headers) {
		AppDetailsVerification response = null;
		Gson gson = new Gson();
		String request = gson.toJson(verificationDetReq);
		Map<String, String> param = new HashMap<>();
		param.put("applicationid", applicationId);
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(addressVerificationUrl, HttpMethod.PUT, String.class, param, request,headers);
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				response = gson.fromJson(excuteRestCall.getBody(), AppDetailsVerification.class);
				}
		}  catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,"");
		}
		return response;
	}
	
	private String getAuthDetails() {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside getAuthDetails method - Start");
		String auth;
		String userNamePwd = authuserName + ":" + authpassword;
		auth = Base64.getEncoder().encodeToString(userNamePwd.getBytes());
		auth = authtype + " " + auth;
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside getAuthDetails method - End");
		return auth;
	}

	public Email getApplicationEmail(String applicationId, Long appattrbkey, String typeKey,HttpHeaders headers) {
		Email response = null;
		Gson gson = new Gson();
		Map<String, String> param = new HashMap<>();
		param.put("applicationid", applicationId);
		param.put("typeKey", typeKey);
		param.put("userattributekey", appattrbkey.toString());
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(getEmailUrl, HttpMethod.GET, String.class, param, null,headers);
		try {
			if (null != excuteRestCall.getBody()){
				response = gson.fromJson(excuteRestCall.getBody(), Email.class);
			}
		}  catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,"");
		}
		return response;
	}

	public EmailVerificationDetail saveEmailVerification(String applicationId,EmailVerificationRequest verificationRequest,Boolean verificationFlag,
			HttpHeaders headers) {
		EmailVerificationDetail response = null;
		Gson gson = new Gson();
		Map<String, String> param = new HashMap<>();
		param.put("verificationFlag", verificationFlag.toString());
		String jsonRequest = gson.toJson(verificationRequest);
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(saveEmailVerificationUrl, HttpMethod.POST, String.class, param, jsonRequest,headers);
		try {
			if (null != excuteRestCall.getBody()){
				response = gson.fromJson(excuteRestCall.getBody(), EmailVerificationDetail.class);
			}
		}  catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,"");
		}
		return response;
	}
	public EmandateProviderResponseBean getEmandateMasterDetails(Long principalkey, Long bankMstKey, HttpHeaders headers) {
		EmandateProviderResponseBean response = null;
		Gson gson = new Gson();
		Map<String, String> param = new HashMap<>();
		param.put("principalkey", principalkey.toString());
		param.put("bankMstKey", bankMstKey.toString());
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(getEmandateMasterDetailsUrl, HttpMethod.GET, String.class, param, null,headers);
		try {
			if (null != excuteRestCall.getBody()){
				response = gson.fromJson(excuteRestCall.getBody(), EmandateProviderResponseBean.class);
			}
		}  catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,"");
		}
		return response;
	}
	public Boolean callUpdateApplicationDetailsForAudit(String applicationId, List<AppAuditRequest> appAuditRequest,
			HttpHeaders headers) {
		boolean successFlag = false;
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(appAuditRequest);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateAppicationDetailForAudit, HttpMethod.POST, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				Object successFlagObj = gson.fromJson(excuteRestCall.getBody(), Object.class);
				successFlag = (boolean)successFlagObj;
				return successFlag;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return successFlag;
	}

	public void updateApplicantDetails(AuditApplicantDetails auditApplicantDetails, String applicationId,
			HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(auditApplicantDetails);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateApplicantDetailsForAudit, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				auditApplicantDetails = gson.fromJson(excuteRestCall.getBody(), AuditApplicantDetails.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return;
	}

	public void updateAddressDetails(AddressAuditDetails addressAuditDetails, String applicationId,
			HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(addressAuditDetails);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateAddressDetailsForAudit, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				addressAuditDetails = gson.fromJson(excuteRestCall.getBody(), AddressAuditDetails.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return;
		
	}

	public void updateNomineeDetails(NomineeAuditDetails nomineeAuditDetails, String applicationId,
			HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(nomineeAuditDetails);
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateNomineeDetailsForAudit, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				nomineeAuditDetails = gson.fromJson(excuteRestCall.getBody(), NomineeAuditDetails.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return;
	}

	public void updateEmployerDetails(EmployerAuditDetails employerAuditDetails, String applicationId,
			EmployeeRequest employeeRequest, HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(employeeRequest);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateEmployeeDetailsForAudit, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				employeeRequest = gson.fromJson(excuteRestCall.getBody(), EmployeeRequest.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return;	
	}
	
	@SuppressWarnings("unchecked")
	public String policyIssuance(String applicationKey,HttpHeaders headers) {
		Gson gson = new Gson();
		UriComponentsBuilder builder = null;
		URI uri;
		String response=null;
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);
		try {
			if (null != policyissuanceurl) {
				builder = UriComponentsBuilder.fromUriString(policyissuanceurl);
				uri = builder.buildAndExpand(params).toUri();
				ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
						.excuteRestCall(uri.toString(), HttpMethod.PUT, String.class, params, null, headers);
				if (null != excuteRestCall.getBody()) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
					response  = gson.fromJson(excuteRestCall.getBody().toString(),
							String.class);
				}
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return response;
	}
	public PanVerificationResponse verifyPan(PanVerificationRequest panVerificationRequest, HttpHeaders headers) {
		PanVerificationResponse panVerificationResponse = null;
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(panVerificationRequest);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(panVerificationUrl, HttpMethod.POST, String.class, null, jsonRequest,headers);
		try {
			if(null != excuteRestCall.getBody()) {
				panVerificationResponse =  gson.fromJson(excuteRestCall.getBody(), PanVerificationResponse.class);
			}
		}catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " +e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "Exception while parsing response.");
		}
		return panVerificationResponse;
	}
	
	@SuppressWarnings("unchecked")
	public String updateDeviationDetails(Long applicationid,Integer devaitioncodekey,Long prodkey, HttpHeaders headers) {
		List<AppDeviationResponse> appDeviationResponseListResponse = new ArrayList<>();
		AppDeviationResponse response = new AppDeviationResponse();
		Gson gson = new Gson();
		Map<String, String> param = new HashMap<>();
		param.put("applicationid", applicationid.toString());
		param.put("devaitioncodekey", devaitioncodekey.toString());
		param.put("prodkey", prodkey.toString());

		try {
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(editDeviationDetailsUrl, HttpMethod.PUT, String.class, param, null,
							headers);

			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				AppDeviationResponse[] appDeviationResponseList = gson.fromJson(excuteRestCall.getBody(), AppDeviationResponse[].class);
				appDeviationResponseListResponse = Arrays.asList(appDeviationResponseList);
				response.setStatus(EmployeePortalConstants.DEVIATION_UPDATED);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing deviation response from application service .");
		}
		return response.getStatus();

	}
	@SuppressWarnings("unchecked")
	public void updateUTMDetails(UTMRequest utmRequest, String applicationId, HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(utmRequest);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateUTMDetailsForAudit, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				utmRequest = gson.fromJson(excuteRestCall.getBody(), UTMRequest.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return;
	}
	
	@SuppressWarnings("unchecked")
	public BflBranchesMaster getBflBranchDetails(Long branchKey, HttpHeaders headers) {
		BflBranchesMaster response = new BflBranchesMaster();
		Gson gson = new Gson();
		Map<String, String> param = new HashMap<>();
		
		param.put("citykey", "1784");

		try {
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(getBflBranchDetails)
					.queryParam("branchKey", branchKey.toString());
			URI uri = null;

			uri = builder.buildAndExpand(param).toUri();
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(uri.toString(), HttpMethod.GET, String.class, param, null, headers);

			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				response = gson.fromJson(excuteRestCall.getBody(), BflBranchesMaster.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while fetching BFL Branch details from Reference data service.");
		}
		return response;

	}

	public OpenArcPerfiosCovertResponse getOpenArcPerfiosCovertReqBreResponse(
			PerfiosCovertValidationRequest request, HttpHeaders headers) {
		OpenArcPerfiosCovertResponse response = null;
		Gson gson = new Gson();
		String breRequest = gson.toJson(request);
		headers.add(HttpHeaders.AUTHORIZATION, getAuthDetails());
		Map<String, String> param = new HashMap<>();
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(openArchPerfiosCovertReqBre, HttpMethod.POST, String.class, param, breRequest,headers);
		try {
			if (null != excuteRestCall.getBody()){
				response = gson.fromJson(excuteRestCall.getBody(), OpenArcPerfiosCovertResponse.class);
			}
		}  catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,"");
		}
		return response;
	}

	@SuppressWarnings("unchecked")
	public String createOrUpdateApplicationLoanPricingDetails(Long applicationId, Integer tenure, BigDecimal amount,
			BigDecimal rate, HttpHeaders headers) {

		Gson gson = new Gson();
		UriComponentsBuilder builder = null;
		URI uri;
		String response = null;
		HttpStatus statusCode = HttpStatus.CREATED;
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId.toString());

		try {
			if (null != appLoanPricingUrl) {
				builder = UriComponentsBuilder.fromUriString(appLoanPricingUrl).queryParam("tenure", tenure.toString())
						.queryParam("amount", amount).queryParam("rate", rate);

				uri = builder.buildAndExpand(params).toUri();
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"createOrUpdateApplicationLoanPricingDetails URI:" + uri);
				ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
						.excuteRestCall(uri.toString(), HttpMethod.POST, String.class, params, null, headers);
				if (null != excuteRestCall && null != excuteRestCall.getBody()) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
					
					if (excuteRestCall.getStatusCode() == statusCode) 
						response = EmployeePortalConstants.SUCCESS;
					else
						response = EmployeePortalConstants.FAILURE;
				}
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Send Notification exception.");
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("OMCA_033", "Error while sending notification."));
		}
		return response;
	}
	public void updateBusinessDetails(BusinessOwnerDetails businessOwnerDetails, String bundleApplicationKey,
			HttpHeaders headers) {
		ApplicationAttribute appAttribute = applicationAttributeRepository
				.findByApplication_ApplicationkeyAndApplicanttypeAndIsactive(Long.valueOf(bundleApplicationKey), 1L, 1);
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(businessOwnerDetails);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", bundleApplicationKey);
		params.put("userattributekey", appAttribute.getAppattrbkey().toString());
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateBusinessDetailsForAudit, HttpMethod.PUT, String.class, params, jsonRequest,
						headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				businessOwnerDetails = gson.fromJson(excuteRestCall.getBody(), BusinessOwnerDetails.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return;
	}
	public void updateNameDetail(NameDetail nameDetail, String applicationId, HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(nameDetail);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateNameDetailsForAudit, HttpMethod.PUT, String.class, params, jsonRequest,
						headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				nameDetail = gson.fromJson(excuteRestCall.getBody(), NameDetail.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return;
	}
	
	@SuppressWarnings("unchecked")
	public RoleInfoBean getRoleInfoBeanByUserRoleKey(Long userRoleKey, HttpHeaders headers) {
		Gson gson = new Gson();
		HashMap<String, String> params = new HashMap<>();
		params.put("userRoleKey", userRoleKey.toString());
		RoleInfoBean infoBean = new RoleInfoBean();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(roleInfoUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				infoBean = gson.fromJson(excuteRestCall.getBody(), RoleInfoBean.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return infoBean;
	}
	
	@SuppressWarnings("unchecked")
	public RoleMasterResponse getRoleMasterByRoleKey(@PathVariable("rolekey") String roleKey, @RequestHeader HttpHeaders headers) {
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("rolekey", roleKey);
		RoleMasterResponse roleMasterResponse = new RoleMasterResponse();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(roleMasterResponseUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Getting response...");
				roleMasterResponse = gson.fromJson(excuteRestCall.getBody(), RoleMasterResponse.class);
			}
		} catch (CreditEmployeePortalServiceException creditException) {
			throw creditException;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while getting RoleMasterResponse", e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "Exception while getting RoleMasterResponse");
		}
		return roleMasterResponse;
	}
	
	public EsignInfoResponse getEsignInfo(String applicationKey,HttpHeaders headers) {
		Gson gson = new Gson();
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);
		List<EsignInfoResponse> esignInfoResponses = new ArrayList<EsignInfoResponse>();
		EsignInfoResponse esignInfoResponse = new EsignInfoResponse();
		try {
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(esignInfoUrl, HttpMethod.GET, String.class, params, null, headers);
		
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				String payload = getPayload(excuteRestCall.getBody().toString());
				EsignInfoResponse[] esignInfoRestResponse = gson.fromJson(payload, EsignInfoResponse[].class);
				esignInfoResponses = Arrays.asList(esignInfoRestResponse);
			}
			
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			return null;
		}
		for( EsignInfoResponse esignInfo : esignInfoResponses) {
			if(esignInfo.getIsactive()==1) {
				esignInfoResponse = esignInfo;
			}
		}
		return esignInfoResponse;
	}
	
	public EsignInfoResponse updateEsignInfo(EsignInfoRequest esignInfoRequest, String applicationKey,String esignKey, HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(esignInfoRequest);
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", applicationKey);
		params.put("esignKey", esignKey);
		EsignInfoResponse esignInfo = new EsignInfoResponse();
		@SuppressWarnings("unchecked")
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(eSignInfoUpdateUrl, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				esignInfo = gson.fromJson(excuteRestCall.getBody(), EsignInfoResponse.class);
			}
		} catch (CreditEmployeePortalServiceException creditException) {
			throw creditException;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response ", e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "Parsing exception");
		}
		return esignInfo;
	}
	
	@SuppressWarnings("unchecked")
	public void updateEmailDetails(EmailAuditDetails emailAuditDetails, String applicationId,
			HttpHeaders headers) {
		Gson gson = new Gson();
		String jsonRequest = gson.toJson(emailAuditDetails);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(updateEmailDetailsForAudit, HttpMethod.PUT, String.class, params, jsonRequest, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				emailAuditDetails = gson.fromJson(excuteRestCall.getBody(), EmailAuditDetails.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "");
		}
		return;
		
	}
	
	@SuppressWarnings("unchecked")
	public UserRoleBean getRolekeyByUserRoleKey(Long userRoleKey) {
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("userRoleKey", userRoleKey.toString());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("authtoken", customDefaultHeaders.getAuthtoken());
		UserRoleBean userRoleBean=new UserRoleBean();
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "In getCreditL2Products URI:");
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(rolekeyUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
		if (null != excuteRestCall.getBody()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
			userRoleBean= gson.fromJson(excuteRestCall.getBody(),
					UserRoleBean.class);
			
		}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while fetching Credit L2 Products.");
		}
		return userRoleBean;
	}
	
	@SuppressWarnings({ "static-access", "unchecked" })
	public PricingStatus updatePricingStatus(Long applicationId, PricingDetail details, PricingStatus status, HttpHeaders headers) {
		String jsonRequest = creditEmployeePortalClientHelper.objectToJson(status);
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", String.valueOf(applicationId));
		params.put("pricingkey", String.valueOf(details.getAppLoanPricingKey()));
		PricingStatus pricingStatus = null;
		try {
			ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
					.excuteRestCall(updatePricingStatus, HttpMethod.PUT, String.class, params, jsonRequest, headers);
						
			if (null != excuteRestCall.getBody()) {
				pricingStatus = gson.fromJson(excuteRestCall.getBody(), PricingStatus.class);
			}
		} catch (CreditEmployeePortalServiceException exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while updating Pricing Status : " + exception);
			throw exception;
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while updating Pricing Status ", exception);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception occurred while updating Pricing Status");
		}
		return pricingStatus;
	}

	@SuppressWarnings("unchecked")
	public UserRoleBean getRolekeyByUserRoleKey(Long userRoleKey, HttpHeaders headers) {
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		params.put("userRoleKey", userRoleKey.toString());
		UserRoleBean userRoleBean = new UserRoleBean();
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "In getCreditL2Products URI");
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditEmployeePortalClientHelper
				.excuteRestCall(rolekeyUrl, HttpMethod.GET, String.class, params, null, headers);
		try {
			if (null != excuteRestCall.getBody()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
				userRoleBean = gson.fromJson(excuteRestCall.getBody(), UserRoleBean.class);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while fetching Credit L2 Products.");
		}
		return userRoleBean;
	}
	
    public static JSONObject getJSONObject(Object object) {
        String jsonString = objectToJson(object);
        Gson g = new GsonBuilder().disableHtmlEscaping().create();
        return g.fromJson(jsonString, JSONObject.class);
    }
    public static String objectToJson(Object object) {
        if (object != null && object instanceof String)
            return object.toString();
        Gson gson = new GsonBuilder().disableHtmlEscaping().serializeNulls().create();
        return gson.toJson(object);
    }

    public JSONObject getIncomeEstimation(String applicationKey, String applicantkey, HttpHeaders headers) {
        logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
                "inside getIncomeEstimation method for applicationKey:- " + applicationKey);
        JSONObject incomeEstimationResponse = null;
        try {
            Map<String, String> params = new HashMap<>();
            params.put("applicationid", applicationKey);
            params.put("applicantkey", applicantkey);
          /*  ResponseEntity<?> incomeEstimationResponseEntity = creditEmployeePortalClientHelper
                    .excuteRestCall(getIncomeEstimationURL, HttpMethod.GET, JSONObject.class, params, null, headers);
            if (null != incomeEstimationResponseEntity.getBody()) {
                logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                        "income estimation data for application: " + applicationKey + "incomeEstimationResponseEntity="
                                + incomeEstimationResponseEntity.getBody());
                JSONObject output = getJSONObject(incomeEstimationResponseEntity.getBody());
                if (null != output.get("estimatedIncomeList")) {
                    List<Object> incomeEstimationResponseList = (List<Object>) output.get("estimatedIncomeList");
                    incomeEstimationResponse = getJSONObject(incomeEstimationResponseList.get(0));
                }
            }*/
            ResponseEntity<?> incomeEstimationResponseEntity = creditEmployeePortalClientHelper.invokeRestCall(getIncomeEstimationURL,HttpMethod.GET,List.class,
                    params, null, headers);
            if (null != incomeEstimationResponseEntity.getBody()) {
                List<Object> incomeEstimationResponseList = (ArrayList<Object>) incomeEstimationResponseEntity.getBody();
                incomeEstimationResponse = getJSONObject(incomeEstimationResponseList.get(0));
            }
        } catch (CreditEmployeePortalServiceException businessException) {
            if (HttpStatus.NOT_FOUND.equals(businessException.getCode())) {
                logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                        "income estimation not present for application: " + applicationKey);
            } else {
                logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
                        "Call failed while fetching income estimation details for application: " + applicationKey,
                        businessException);
                throw new CreditEmployeePortalServiceException(businessException.getCode(),
                        new ErrorBean("OMCA_103", "Service Call failure for income estimation details !"));
            }
        } catch (Exception exception) {
            logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
                    "Exception occurred while calling income estimation for application: " + applicationKey, exception);
            throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
                    new ErrorBean("OMCA_103", "Some technical exception occurred!"));
        }
        return incomeEstimationResponse;
    }
    
    /**
<<<<<<< HEAD
	 * @param parentApplicationId
	 * @param parentAppAttribute
	 * @param logger2 
	 * @return
	 */
	public List<BureauHeader> extractBureauHeaderDetails(String parentApplicationId,
			ApplicationAttribute parentAppAttribute) {
		List<BureauHeader> bureauHeaderList = null;
		if(null != parentAppAttribute.getCibilreferencekey() && parentAppAttribute.getCibilreferencekey()!= 0L) {
			bureauHeaderList = bureauHeaderRepository
					.findByCibilreferencekeyAndIsactive(parentAppAttribute.getCibilreferencekey(), 1);
		}else {
			bureauHeaderList = bureauHeaderRepository
					.findByApplicationkeyAndApplicantkeyAndIsactive(Long.valueOf(parentApplicationId),parentAppAttribute.getApplicantkey(), 1);
		}
		return bureauHeaderList;
	}
	
	public BureauHeader getBureauHeaderDetailsByCibilReferenceKey(Long cibilreferencekey){
		List<BureauHeader> bureauHeaderList = null;
		BureauHeader bureauHeader = null;
		bureauHeaderList = bureauHeaderRepository
					.findByCibilreferencekeyAndIsactive(cibilreferencekey, 1);
		if(!CollectionUtils.isEmpty(bureauHeaderList)) {
			bureauHeader = bureauHeaderList.get(0);
		}
		return bureauHeader;
	}
}
