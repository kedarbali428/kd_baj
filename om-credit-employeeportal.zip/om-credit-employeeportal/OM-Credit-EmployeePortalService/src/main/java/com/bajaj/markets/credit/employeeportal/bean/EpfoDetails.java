package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class EpfoDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String karzaId;
	private String officeEmailDomain;
	private String employmentScore;
	private String nameConfidence;
	private String accountStatus;
	private String isRecent;
	private String approach;
	private String employmentVerifiedApi;
	private String isNameExactFlag;
	private String verificationChannel;

	public String getKarzaId() {
		return karzaId;
	}

	public void setKarzaId(String karzaId) {
		this.karzaId = karzaId;
	}

	public String getOfficeEmailDomain() {
		return officeEmailDomain;
	}

	public void setOfficeEmailDomain(String officeEmailDomain) {
		this.officeEmailDomain = officeEmailDomain;
	}

	public String getEmploymentScore() {
		return employmentScore;
	}

	public void setEmploymentScore(String employmentScore) {
		this.employmentScore = employmentScore;
	}

	public String getNameConfidence() {
		return nameConfidence;
	}

	public void setNameConfidence(String nameConfidence) {
		this.nameConfidence = nameConfidence;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getIsRecent() {
		return isRecent;
	}

	public void setIsRecent(String isRecent) {
		this.isRecent = isRecent;
	}

	public String getApproach() {
		return approach;
	}

	public void setApproach(String approach) {
		this.approach = approach;
	}

	public String getEmploymentVerifiedApi() {
		return employmentVerifiedApi;
	}

	public void setEmploymentVerifiedApi(String employmentVerifiedApi) {
		this.employmentVerifiedApi = employmentVerifiedApi;
	}

	public String getIsNameExactFlag() {
		return isNameExactFlag;
	}

	public void setIsNameExactFlag(String isNameExactFlag) {
		this.isNameExactFlag = isNameExactFlag;
	}

	public String getVerificationChannel() {
		return verificationChannel;
	}

	public void setVerificationChannel(String verificationChannel) {
		this.verificationChannel = verificationChannel;
	}

}
