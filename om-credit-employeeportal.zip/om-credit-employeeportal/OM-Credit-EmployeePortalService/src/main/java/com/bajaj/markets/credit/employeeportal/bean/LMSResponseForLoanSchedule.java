package com.bajaj.markets.credit.employeeportal.bean;

public class LMSResponseForLoanSchedule {

	private String repaymentType;
	private String productType;
	private String productTypeCode;
	private String lmsResponse;
	private LoanRepaymentSchedule[] schedules;
	private LoanRepaymentSummary summary;
	private ReturnStatus returnStatus;
	
	public LoanRepaymentSummary getSummary() {
		return summary;
	}
	public void setSummary(LoanRepaymentSummary summary) {
		this.summary = summary;
	}
	public String getRepaymentType() {
		return repaymentType;
	}
	public void setRepaymentType(String repaymentType) {
		this.repaymentType = repaymentType;
	}
	public String getLmsResponse() {
		return lmsResponse;
	}
	public void setLmsResponse(String lmsResponse) {
		this.lmsResponse = lmsResponse;
	}
	
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public LoanRepaymentSchedule[] getSchedules() {
		return schedules;
	}
	public void setSchedules(LoanRepaymentSchedule[] schedules) {
		this.schedules = schedules;
	}
	public String getProductTypeCode() {
		return productTypeCode;
	}
	public void setProductTypeCode(String productTypeCode) {
		this.productTypeCode = productTypeCode;
	}
	
	public ReturnStatus getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(ReturnStatus returnStatus) {
		this.returnStatus = returnStatus;
	}


}
