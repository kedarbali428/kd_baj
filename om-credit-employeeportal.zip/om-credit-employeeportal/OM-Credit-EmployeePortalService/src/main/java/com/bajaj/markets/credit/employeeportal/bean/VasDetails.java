package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class VasDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	private String productAvailed;
	private String productName;
	private Integer costPrice;
	private Integer sellingPrice;
	private Integer premiumAmount;
	private Integer sumAssured;
	private String policyIssuanceStatus;
	private String policyNumber;
	private String policyIssuanceDate;
	private String failureReason;

	public String getProductAvailed() {
		return productAvailed;
	}

	public void setProductAvailed(String productAvailed) {
		this.productAvailed = productAvailed;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getCostPrice() {
		return costPrice;
	}

	public void setCostPrice(Integer costPrice) {
		this.costPrice = costPrice;
	}

	public Integer getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(Integer sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public Integer getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(Integer premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public Integer getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(Integer sumAssured) {
		this.sumAssured = sumAssured;
	}

	public String getPolicyIssuanceStatus() {
		return policyIssuanceStatus;
	}

	public void setPolicyIssuanceStatus(String policyIssuanceStatus) {
		this.policyIssuanceStatus = policyIssuanceStatus;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPolicyIssuanceDate() {
		return policyIssuanceDate;
	}

	public void setPolicyIssuanceDate(String policyIssuanceDate) {
		this.policyIssuanceDate = policyIssuanceDate;
	}

	public String getFailureReason() {
		return failureReason;
	}

	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}

}
