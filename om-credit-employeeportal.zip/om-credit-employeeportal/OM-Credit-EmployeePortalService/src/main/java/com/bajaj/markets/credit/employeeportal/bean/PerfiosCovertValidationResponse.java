package com.bajaj.markets.credit.employeeportal.bean;

public class PerfiosCovertValidationResponse {

	private OpenArcPerfiosCovertResponse openArcPerfiosCovertOutput;

	public OpenArcPerfiosCovertResponse getOpenArcPerfiosCovertOutput() {
		return openArcPerfiosCovertOutput;
	}

	public void setOpenArcPerfiosCovertOutput(OpenArcPerfiosCovertResponse openArcPerfiosCovertOutput) {
		this.openArcPerfiosCovertOutput = openArcPerfiosCovertOutput;
	}
}
