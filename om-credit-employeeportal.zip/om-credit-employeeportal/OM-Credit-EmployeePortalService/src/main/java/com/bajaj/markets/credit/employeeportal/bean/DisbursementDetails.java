package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class DisbursementDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String trancheStatus;
	private Double pendingAmountForDisbursal;
	private String trancheNumber;
	private Double trancheAmount;
	private String trancheDisbursementMode;
	private String disbursementAccountHolderName;
	private String trancheDisbursementAccountNumber;
	private Date dateOfTranche;
	private Double amountDisbursedTillNow;
	private String trancheErrorCodes;
	private String disbursementFailureFlag;
	private String disbursementError;
	private String disbursementSource;
	private String pennantLan;
	private Timestamp disbursementDate;

	public String getTrancheStatus() {
		return trancheStatus;
	}

	public void setTrancheStatus(String trancheStatus) {
		this.trancheStatus = trancheStatus;
	}

	public Double getPendingAmountForDisbursal() {
		return pendingAmountForDisbursal;
	}

	public void setPendingAmountForDisbursal(Double pendingAmountForDisbursal) {
		this.pendingAmountForDisbursal = pendingAmountForDisbursal;
	}

	public String getTrancheNumber() {
		return trancheNumber;
	}

	public void setTrancheNumber(String trancheNumber) {
		this.trancheNumber = trancheNumber;
	}

	public Double getTrancheAmount() {
		return trancheAmount;
	}

	public void setTrancheAmount(Double trancheAmount) {
		this.trancheAmount = trancheAmount;
	}

	public String getTrancheDisbursementMode() {
		return trancheDisbursementMode;
	}

	public void setTrancheDisbursementMode(String trancheDisbursementMode) {
		this.trancheDisbursementMode = trancheDisbursementMode;
	}

	public String getDisbursementAccountHolderName() {
		return disbursementAccountHolderName;
	}

	public void setDisbursementAccountHolderName(String disbursementAccountHolderName) {
		this.disbursementAccountHolderName = disbursementAccountHolderName;
	}

	public String getTrancheDisbursementAccountNumber() {
		return trancheDisbursementAccountNumber;
	}

	public void setTrancheDisbursementAccountNumber(String trancheDisbursementAccountNumber) {
		this.trancheDisbursementAccountNumber = trancheDisbursementAccountNumber;
	}

	public Date getDateOfTranche() {
		return dateOfTranche;
	}

	public void setDateOfTranche(Date dateOfTranche) {
		this.dateOfTranche = dateOfTranche;
	}

	public Double getAmountDisbursedTillNow() {
		return amountDisbursedTillNow;
	}

	public void setAmountDisbursedTillNow(Double amountDisbursedTillNow) {
		this.amountDisbursedTillNow = amountDisbursedTillNow;
	}

	public String getTrancheErrorCodes() {
		return trancheErrorCodes;
	}

	public void setTrancheErrorCodes(String trancheErrorCodes) {
		this.trancheErrorCodes = trancheErrorCodes;
	}

	public String getDisbursementFailureFlag() {
		return disbursementFailureFlag;
	}

	public void setDisbursementFailureFlag(String disbursementFailureFlag) {
		this.disbursementFailureFlag = disbursementFailureFlag;
	}

	public String getDisbursementError() {
		return disbursementError;
	}

	public void setDisbursementError(String disbursementError) {
		this.disbursementError = disbursementError;
	}

	public String getDisbursementSource() {
		return disbursementSource;
	}

	public void setDisbursementSource(String disbursementSource) {
		this.disbursementSource = disbursementSource;
	}

	public String getPennantLan() {
		return pennantLan;
	}

	public void setPennantLan(String pennantLan) {
		this.pennantLan = pennantLan;
	}

	public Timestamp getDisbursementDate() {
		return disbursementDate;
	}

	public void setDisbursementDate(Timestamp disbursementDate) {
		this.disbursementDate = disbursementDate;
	}

}