package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Date;

public class NomineeDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String nomineeName;
	private Date dob;
	private String relation;

	public String getNomineeName() {
		return nomineeName;
	}

	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

}
