package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CibilDetailsBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String cibilAdditionalMatchFlagApplicant;
	private String applicantName;
	private String dateOfBirth;
	private String genderAsPerCibil;
	private String pan;
	private String cibilTelephoneNumber;
	private String cibilAddressLineOne;
	private String passportNbr;
	private String cibilDateReported;
	private String addressMatchWithEp;

	public String getCibilAdditionalMatchFlagApplicant() {
		return cibilAdditionalMatchFlagApplicant;
	}

	public void setCibilAdditionalMatchFlagApplicant(String cibilAdditionalMatchFlagApplicant) {
		this.cibilAdditionalMatchFlagApplicant = cibilAdditionalMatchFlagApplicant;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGenderAsPerCibil() {
		return genderAsPerCibil;
	}

	public void setGenderAsPerCibil(String genderAsPerCibil) {
		this.genderAsPerCibil = genderAsPerCibil;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getCibilTelephoneNumber() {
		return cibilTelephoneNumber;
	}

	public void setCibilTelephoneNumber(String cibilTelephoneNumber) {
		this.cibilTelephoneNumber = cibilTelephoneNumber;
	}

	public String getCibilAddressLineOne() {
		return cibilAddressLineOne;
	}

	public void setCibilAddressLineOne(String cibilAddressLineOne) {
		this.cibilAddressLineOne = cibilAddressLineOne;
	}

	public String getPassportNbr() {
		return passportNbr;
	}

	public void setPassportNbr(String passportNbr) {
		this.passportNbr = passportNbr;
	}

	public String getCibilDateReported() {
		return cibilDateReported;
	}

	public void setCibilDateReported(String cibilDateReported) {
		this.cibilDateReported = cibilDateReported;
	}

	public String getAddressMatchWithEp() {
		return addressMatchWithEp;
	}

	public void setAddressMatchWithEp(String addressMatchWithEp) {
		this.addressMatchWithEp = addressMatchWithEp;
	}

}
