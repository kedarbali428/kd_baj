package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class ResidentialGeoTagging implements Serializable {

	private static final long serialVersionUID = 1L;

	private String pictureName;
	private String latLong;
	private String verificationType;
	private String checkInArea;
	private String checkInTime;
	private String checkBy;
	private String uploadedTime;
	private String checkInSource;

	public String getPictureName() {
		return pictureName;
	}

	public void setPictureName(String pictureName) {
		this.pictureName = pictureName;
	}

	public String getLatLong() {
		return latLong;
	}

	public void setLatLong(String latLong) {
		this.latLong = latLong;
	}

	public String getVerificationType() {
		return verificationType;
	}

	public void setVerificationType(String verificationType) {
		this.verificationType = verificationType;
	}

	public String getCheckInArea() {
		return checkInArea;
	}

	public void setCheckInArea(String checkInArea) {
		this.checkInArea = checkInArea;
	}

	public String getCheckInTime() {
		return checkInTime;
	}

	public void setCheckInTime(String checkInTime) {
		this.checkInTime = checkInTime;
	}

	public String getCheckBy() {
		return checkBy;
	}

	public void setCheckBy(String checkBy) {
		this.checkBy = checkBy;
	}

	public String getUploadedTime() {
		return uploadedTime;
	}

	public void setUploadedTime(String uploadedTime) {
		this.uploadedTime = uploadedTime;
	}

	public String getCheckInSource() {
		return checkInSource;
	}

	public void setCheckInSource(String checkInSource) {
		this.checkInSource = checkInSource;
	}

}
