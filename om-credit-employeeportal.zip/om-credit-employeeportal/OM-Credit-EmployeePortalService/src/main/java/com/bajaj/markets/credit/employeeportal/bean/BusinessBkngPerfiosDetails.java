package com.bajaj.markets.credit.employeeportal.bean;

public class BusinessBkngPerfiosDetails {
	private String ccLimit;
	private String abb;
	private String totalCreditM1;
	private String totalCreditM2;
	private String totalCreditM3;
	private String averageCCUtilisation;
	private String iwBounce;
	private String accountnumber;
	/**
	 * @return the ccLimit
	 */
	public String getCcLimit() {
		return ccLimit;
	}
	/**
	 * @param ccLimit the ccLimit to set
	 */
	public void setCcLimit(String ccLimit) {
		this.ccLimit = ccLimit;
	}
	
	/**
	 * @return the totalCreditM1
	 */
	public String getTotalCreditM1() {
		return totalCreditM1;
	}
	/**
	 * @param totalCreditM1 the totalCreditM1 to set
	 */
	public void setTotalCreditM1(String totalCreditM1) {
		this.totalCreditM1 = totalCreditM1;
	}
	/**
	 * @return the totalCreditM2
	 */
	public String getTotalCreditM2() {
		return totalCreditM2;
	}
	/**
	 * @param totalCreditM2 the totalCreditM2 to set
	 */
	public void setTotalCreditM2(String totalCreditM2) {
		this.totalCreditM2 = totalCreditM2;
	}
	/**
	 * @return the totalCreditM3
	 */
	public String getTotalCreditM3() {
		return totalCreditM3;
	}
	/**
	 * @param totalCreditM3 the totalCreditM3 to set
	 */
	public void setTotalCreditM3(String totalCreditM3) {
		this.totalCreditM3 = totalCreditM3;
	}
	/**
	 * @return the averageCCUtilisation
	 */
	public String getAverageCCUtilisation() {
		return averageCCUtilisation;
	}
	/**
	 * @param averageCCUtilisation the averageCCUtilisation to set
	 */
	public void setAverageCCUtilisation(String averageCCUtilisation) {
		this.averageCCUtilisation = averageCCUtilisation;
	}
	/**
	 * @return the iwBounce
	 */
	public String getIwBounce() {
		return iwBounce;
	}
	/**
	 * @param iwBounce the iwBounce to set
	 */
	public void setIwBounce(String iwBounce) {
		this.iwBounce = iwBounce;
	}
	
	/**
	 * @return the abb
	 */
	public String getAbb() {
		return abb;
	}
	/**
	 * @param abb the abb to set
	 */
	public void setAbb(String abb) {
		this.abb = abb;
	}
	/**
	 * @return the accountnumber
	 */
	public String getAccountnumber() {
		return accountnumber;
	}
	/**
	 * @param accountnumber the accountnumber to set
	 */
	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}
	
	

}