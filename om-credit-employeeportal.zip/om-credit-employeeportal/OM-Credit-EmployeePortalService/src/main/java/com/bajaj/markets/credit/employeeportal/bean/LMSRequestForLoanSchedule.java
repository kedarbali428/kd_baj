package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class LMSRequestForLoanSchedule {
	
	private FinanceDetail financeDetail;
	private List<Fee> fees;
	private List <IntervalFeeBean> intervalFee;

	
	public List<Fee> getFees() {
		return fees;
	}
	
	public void setFees(List<Fee> fees) {
		this.fees = fees;
	}
	public List <IntervalFeeBean> getIntervalFee() {
		return intervalFee;
	}

	public void setIntervalFee(List <IntervalFeeBean> intervalFee) {
		this.intervalFee = intervalFee;
	}

	public FinanceDetail getFinanceDetail() {
		return financeDetail;
	}
	public void setFinanceDetail(FinanceDetail financeDetail) {
		this.financeDetail = financeDetail;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fees == null) ? 0 : fees.hashCode());
		result = prime * result + ((financeDetail == null) ? 0 : financeDetail.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LMSRequestForLoanSchedule other = (LMSRequestForLoanSchedule) obj;
		if (fees == null) {
			if (other.fees != null)
				return false;
		} else if (!fees.equals(other.fees))
			return false;
		if (financeDetail == null) {
			if (other.financeDetail != null)
				return false;
		} else if (!financeDetail.equals(other.financeDetail))
			return false;
		return true;
	}

}
