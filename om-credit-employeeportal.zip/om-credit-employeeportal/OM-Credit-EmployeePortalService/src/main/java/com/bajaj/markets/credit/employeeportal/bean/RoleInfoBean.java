package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class RoleInfoBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long userRoleKey;
	private Long userKey;
	private Long roleKey;
	private String roleName;
	private Long userType;

	public Long getUserRoleKey() {
		return userRoleKey;
	}

	public void setUserRoleKey(Long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}

	public Long getUserKey() {
		return userKey;
	}

	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}

	public Long getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(Long roleKey) {
		this.roleKey = roleKey;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Long getUserType() {
		return userType;
	}

	public void setUserType(Long userType) {
		this.userType = userType;
	}
}