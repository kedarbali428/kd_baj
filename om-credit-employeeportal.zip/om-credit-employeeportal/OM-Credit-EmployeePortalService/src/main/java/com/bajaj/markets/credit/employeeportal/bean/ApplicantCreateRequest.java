package com.bajaj.markets.credit.employeeportal.bean;

import java.util.Date;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ApplicantCreateRequest {


	@Valid
	private NameVerificationDet name;

	@Valid
	private MobileVerificationDet mobileNumber;
	
	@NotNull(message = "DOB cannot be null")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date dateOfBirth;
	
	@Pattern(regexp="^[a-zA-Z0-9]*$",message = "Invalid Input gender")
	private String gender;
	
	@Pattern(regexp="^[a-zA-Z\\s]*$",message = "Invalid Input fatherName")
	private String fatherName;
	
	@Pattern(regexp="^[a-zA-Z\\s]*$",message = "Invalid Input motherName")
	private String motherName;
	
	@Pattern(regexp="^[A-Za-z]*$",message = "Invalid Input maritalStatus")
	private String maritalStatus;
	
	@Pattern(regexp="^[a-zA-Z0-9]*$",message = "Invalid Input pan")
	private String pan;
	
	@Digits(fraction = 0, integer = 20, message = "relation can not be other than digits")
	private String relation;
	
	@Pattern(regexp="^[a-zA-Z0-9]*$",message = "Invalid Input occupation")
	private String occupation;
	
	private String address1;
	private String address2;
	
	@Digits(fraction = 0, integer = 6, message = "pincode can not be other than digits")
	private Long pincode;
	
	@Email(message="Enter Valid email")
	private String email;
	
	@Digits(fraction = 0, integer = 10, message = "applicantKey can not be other than digits")
	private Long applicantKey;
	private boolean appStatusComplete;
	
	
	public NameVerificationDet getName() {
		return name;
	}
	public void setName(NameVerificationDet name) {
		this.name = name;
	}
	public MobileVerificationDet getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(MobileVerificationDet mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public Long getPincode() {
		return pincode;
	}
	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public Long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}
	public boolean isAppStatusComplete() {
		return appStatusComplete;
	}
	public void setAppStatusComplete(boolean appStatusComplete) {
		this.appStatusComplete = appStatusComplete;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
}
