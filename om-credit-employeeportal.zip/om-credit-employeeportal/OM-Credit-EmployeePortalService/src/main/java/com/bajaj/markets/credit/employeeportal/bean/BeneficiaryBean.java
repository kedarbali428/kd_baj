package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

public class BeneficiaryBean {

	private String cif;
	private BigDecimal beneficiaryID;
	private String bankCode;
	private String branchCode;
	private String ifsc;
	private String accountNo;
	private String acHolderName;
	private String phoneCountryCode;
	private String phoneAreaCode;
	private String phoneNumber;
	private String micr;
	private String city;
	private String email;	
	private Boolean beneficiaryActive;	
	private Boolean defaultBeneficiary;
	private String disbursementMode;
	
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public BigDecimal getBeneficiaryID() {
		return beneficiaryID;
	}
	public void setBeneficiaryID(BigDecimal beneficiaryID) {
		this.beneficiaryID = beneficiaryID;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAcHolderName() {
		return acHolderName;
	}
	public void setAcHolderName(String acHolderName) {
		this.acHolderName = acHolderName;
	}
	public String getPhoneCountryCode() {
		return phoneCountryCode;
	}
	public void setPhoneCountryCode(String phoneCountryCode) {
		this.phoneCountryCode = phoneCountryCode;
	}
	public String getPhoneAreaCode() {
		return phoneAreaCode;
	}
	public void setPhoneAreaCode(String phoneAreaCode) {
		this.phoneAreaCode = phoneAreaCode;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getMicr() {
		return micr;
	}
	public void setMicr(String micr) {
		this.micr = micr;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Boolean getBeneficiaryActive() {
		return beneficiaryActive;
	}
	public void setBeneficiaryActive(Boolean beneficiaryActive) {
		this.beneficiaryActive = beneficiaryActive;
	}
	public Boolean getDefaultBeneficiary() {
		return defaultBeneficiary;
	}
	public void setDefaultBeneficiary(Boolean defaultBeneficiary) {
		this.defaultBeneficiary = defaultBeneficiary;
	}
	public String getDisbursementMode() {
		return disbursementMode;
	}
	public void setDisbursementMode(String disbursementMode) {
		this.disbursementMode = disbursementMode;
	}
	
	
}
