package com.bajaj.markets.credit.employeeportal.bean;

public class MandateDetails {
	     private String mandateExpiryDate;
         private String mandateRegistrationNumber;
         private Long maxLimit;
         private Long balanceLimit;
         private String accountNo;
         private String bankBranchName;
         private String bankName;
         private String  cName ;
         private String ifscCode;
         private String micrCode;
         private String mandateCreatedsourceName;
         private String mandatereference;
         private String channelType;
         private String channelMandateReferenceId;
         private String sourceName;
		public void setMandateExpiryDate(String mandateExpiryDate) {
			this.mandateExpiryDate = mandateExpiryDate;
		}
		public void setMaxLimit(Long maxLimit) {
			this.maxLimit = maxLimit;
		}
		public void setBalanceLimit(Long balanceLimit) {
			this.balanceLimit = balanceLimit;
		}
		public void setAccountNo(String accountNo) {
			this.accountNo = accountNo;
		}
		public void setBankBranchName(String bankBranchName) {
			this.bankBranchName = bankBranchName;
		}
		public void setBankName(String bankName) {
			this.bankName = bankName;
		}
		public void setcName(String cName) {
			this.cName = cName;
		}
		public void setIfscCode(String ifscCode) {
			this.ifscCode = ifscCode;
		}
		public void setMicrCode(String micrCode) {
			this.micrCode = micrCode;
		}
		public void setMandateCreatedsourceName(String mandateCreatedsourceName) {
			this.mandateCreatedsourceName = mandateCreatedsourceName;
		}
		public void setMandatereference(String mandatereference) {
			this.mandatereference = mandatereference;
		}
		public void setChannelType(String channelType) {
			this.channelType = channelType;
		}
		public String getAccountNo() {
			return accountNo;
		}
		public String getMandatereference() {
			return mandatereference;
		}
		/**
		 * @return the sourceName
		 */
		public String getSourceName() {
			return sourceName;
		}
		/**
		 * @param sourceName the sourceName to set
		 */
		public void setSourceName(String sourceName) {
			this.sourceName = sourceName;
		}
		/**
		 * @return the mandateExpiryDate
		 */
		public String getMandateExpiryDate() {
			return mandateExpiryDate;
		}
		/**
		 * @return the maxLimit
		 */
		public Long getMaxLimit() {
			return maxLimit;
		}
		/**
		 * @return the balanceLimit
		 */
		public Long getBalanceLimit() {
			return balanceLimit;
		}
		/**
		 * @return the bankBranchName
		 */
		public String getBankBranchName() {
			return bankBranchName;
		}
		/**
		 * @return the bankName
		 */
		public String getBankName() {
			return bankName;
		}
		/**
		 * @return the cName
		 */
		public String getcName() {
			return cName;
		}
		/**
		 * @return the ifscCode
		 */
		public String getIfscCode() {
			return ifscCode;
		}
		/**
		 * @return the micrCode
		 */
		public String getMicrCode() {
			return micrCode;
		}
		/**
		 * @return the mandateCreatedsourceName
		 */
		public String getMandateCreatedsourceName() {
			return mandateCreatedsourceName;
		}
		/**
		 * @return the channelType
		 */
		public String getChannelType() {
			return channelType;
		}
		public String getMandateRegistrationNumber() {
			return mandateRegistrationNumber;
		}
		public void setMandateRegistrationNumber(String mandateRegistrationNumber) {
			this.mandateRegistrationNumber = mandateRegistrationNumber;
		}
		public String getChannelMandateReferenceId() {
			return channelMandateReferenceId;
		}
		public void setChannelMandateReferenceId(String channelMandateReferenceId) {
			this.channelMandateReferenceId = channelMandateReferenceId;
		}      	
}
