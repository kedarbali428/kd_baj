package com.bajaj.markets.credit.employeeportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.AppExceptionCodeBean;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalRaiseExceptionService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EmployeePortalRaiseExceptionController {
	private static final String CLASSNAME = EmployeePortalRaiseExceptionController.class.getName();
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	EmployeePortalRaiseExceptionService employeePortalRaiseExceptionService;
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Raise Exception", notes = "Raise Exception of applicationId", httpMethod = "PUT")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Raise Exception saved for applicationId", response = StatusBean.class),
			@ApiResponse(code = 404, message = "Raise Exception not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PutMapping(value = "/v1/employeeportal/credit/applications/{applicationid}/exception", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> saveRaiseExceptionDetails(@RequestParam("raiseExceptionId") int raiseExceptionId,
			@PathVariable("applicationid") String applicationId,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside saveRaiseExceptionDetails method controller - applicationId: "+ applicationId);
		StatusBean response = employeePortalRaiseExceptionService.saveRaiseExceptionDetails(raiseExceptionId,Long.valueOf(applicationId),headers);
		 return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch comment Detail", notes = "Fetch comment details on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Exceptions found for applicationId", response = AppExceptionCodeBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeeportal/credit/applications/{applicationid}/exception", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getExcptionDetails(@PathVariable("applicationid") String applicationId,@RequestHeader HttpHeaders headers){

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getExcptionDetails method controller - applicationId: "+ applicationId);

		return new ResponseEntity<>(employeePortalRaiseExceptionService.getExceptionDetails(Long.valueOf(applicationId)), HttpStatus.OK);
	}
	
	

}
