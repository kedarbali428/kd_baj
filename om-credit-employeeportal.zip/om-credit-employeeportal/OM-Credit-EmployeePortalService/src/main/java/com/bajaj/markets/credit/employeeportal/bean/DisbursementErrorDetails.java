package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class DisbursementErrorDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	private String disbursementErrorStatus;
	private String disbursementErrorStage;
	private String disbursementError;
	private String errorDescription;
	private String disbursementInitiatedBy;
	private Timestamp errorDateAndTime;
	public String getDisbursementErrorStatus() {
		return disbursementErrorStatus;
	}
	public void setDisbursementErrorStatus(String disbursementErrorStatus) {
		this.disbursementErrorStatus = disbursementErrorStatus;
	}
	public String getDisbursementErrorStage() {
		return disbursementErrorStage;
	}
	public void setDisbursementErrorStage(String disbursementErrorStage) {
		this.disbursementErrorStage = disbursementErrorStage;
	}
	public String getDisbursementError() {
		return disbursementError;
	}
	public void setDisbursementError(String disbursementError) {
		this.disbursementError = disbursementError;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public String getDisbursementInitiatedBy() {
		return disbursementInitiatedBy;
	}
	public void setDisbursementInitiatedBy(String disbursementInitiatedBy) {
		this.disbursementInitiatedBy = disbursementInitiatedBy;
	}
	public Timestamp getErrorDateAndTime() {
		return errorDateAndTime;
	}
	public void setErrorDateAndTime(Timestamp errorDateAndTime) {
		this.errorDateAndTime = errorDateAndTime;
	}
}
