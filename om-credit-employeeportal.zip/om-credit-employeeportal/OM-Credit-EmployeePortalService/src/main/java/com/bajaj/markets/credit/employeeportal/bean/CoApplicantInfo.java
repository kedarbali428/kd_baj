package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CoApplicantInfo implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String coApplicantFirstName;
	private String coApplicantMiddleName;
	private String coApplicantLastName;
	private String coApplicantDOB;
	private String coApplicantGender;
	private String coApplicantPanNo;
	private Long coApplicantApplicantId;
	private String coApplicantPennantCustId;
	private String coApplicantRelationWithApplicant;
	private Long coApplicantApplicantType;
	private Long coApplicantMobileNumber;
	private String coApplicantPersonalEmailId;
	private String coApplicantNameAsPerNSDL;
	private String coApplicantNSDLNameMatch;
	private String coApplicantMotherName;
	private String coApplicantFatherName;
	public String getCoApplicantFirstName() {
		return coApplicantFirstName;
	}
	public void setCoApplicantFirstName(String coApplicantFirstName) {
		this.coApplicantFirstName = coApplicantFirstName;
	}
	public String getCoApplicantMiddleName() {
		return coApplicantMiddleName;
	}
	public void setCoApplicantMiddleName(String coApplicantMiddleName) {
		this.coApplicantMiddleName = coApplicantMiddleName;
	}
	public String getCoApplicantLastName() {
		return coApplicantLastName;
	}
	public void setCoApplicantLastName(String coApplicantLastName) {
		this.coApplicantLastName = coApplicantLastName;
	}
	public String getCoApplicantDOB() {
		return coApplicantDOB;
	}
	public void setCoApplicantDOB(String coApplicantDOB) {
		this.coApplicantDOB = coApplicantDOB;
	}
	public String getCoApplicantGender() {
		return coApplicantGender;
	}
	public void setCoApplicantGender(String coApplicantGender) {
		this.coApplicantGender = coApplicantGender;
	}
	public String getCoApplicantPanNo() {
		return coApplicantPanNo;
	}
	public void setCoApplicantPanNo(String coApplicantPanNo) {
		this.coApplicantPanNo = coApplicantPanNo;
	}
	public Long getCoApplicantApplicantId() {
		return coApplicantApplicantId;
	}
	public void setCoApplicantApplicantId(Long coApplicantApplicantId) {
		this.coApplicantApplicantId = coApplicantApplicantId;
	}
	public String getCoApplicantPennantCustId() {
		return coApplicantPennantCustId;
	}
	public void setCoApplicantPennantCustId(String coApplicantPennantCustId) {
		this.coApplicantPennantCustId = coApplicantPennantCustId;
	}
	public String getCoApplicantRelationWithApplicant() {
		return coApplicantRelationWithApplicant;
	}
	public void setCoApplicantRelationWithApplicant(String coApplicantRelationWithApplicant) {
		this.coApplicantRelationWithApplicant = coApplicantRelationWithApplicant;
	}
	public Long getCoApplicantApplicantType() {
		return coApplicantApplicantType;
	}
	public void setCoApplicantApplicantType(Long coApplicantApplicantType) {
		this.coApplicantApplicantType = coApplicantApplicantType;
	}
	public Long getCoApplicantMobileNumber() {
		return coApplicantMobileNumber;
	}
	public void setCoApplicantMobileNumber(Long coApplicantMobileNumber) {
		this.coApplicantMobileNumber = coApplicantMobileNumber;
	}
	public String getCoApplicantPersonalEmailId() {
		return coApplicantPersonalEmailId;
	}
	public void setCoApplicantPersonalEmailId(String coApplicantPersonalEmailId) {
		this.coApplicantPersonalEmailId = coApplicantPersonalEmailId;
	}
	public String getCoApplicantNameAsPerNSDL() {
		return coApplicantNameAsPerNSDL;
	}
	public void setCoApplicantNameAsPerNSDL(String coApplicantNameAsPerNSDL) {
		this.coApplicantNameAsPerNSDL = coApplicantNameAsPerNSDL;
	}
	public String getCoApplicantNSDLNameMatch() {
		return coApplicantNSDLNameMatch;
	}
	public void setCoApplicantNSDLNameMatch(String coApplicantNSDLNameMatch) {
		this.coApplicantNSDLNameMatch = coApplicantNSDLNameMatch;
	}
	public String getCoApplicantMotherName() {
		return coApplicantMotherName;
	}
	public void setCoApplicantMotherName(String coApplicantMotherName) {
		this.coApplicantMotherName = coApplicantMotherName;
	}
	public String getCoApplicantFatherName() {
		return coApplicantFatherName;
	}
	public void setCoApplicantFatherName(String coApplicantFatherName) {
		this.coApplicantFatherName = coApplicantFatherName;
	}
	
}