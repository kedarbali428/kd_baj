package com.bajaj.markets.credit.employeeportal.bean;

import java.util.ArrayList;
import java.util.List;

public class ApplicationDetail {
	
	private Long applicationKey;

	private Long applicantKey;
	
	private String gender;
	
    private String mobileNumber;

    private String sourceApplicationKey;

    private  Name name;

    private String fppPlanCode;
	
	private Integer planKey;

    private String dateOfBirth;

    private List<Products> products  =  new ArrayList<>();
    
    private Integer sourceProductCategoryKey;
    
    private Integer sourceProductMasterKey;

    private String appstatus;
	public ApplicationDetail() {
		super();
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getSourceApplicationKey() {
		return sourceApplicationKey;
	}

	public void setSourceApplicationKey(String sourceApplicationKey) {
		this.sourceApplicationKey = sourceApplicationKey;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public String getFppPlanCode() {
		return fppPlanCode;
	}

	public void setFppPlanCode(String fppPlanCode) {
		this.fppPlanCode = fppPlanCode;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public List<Products> getProducts() {
		return products;
	}

	public void setProducts(List<Products> products) {
		this.products = products;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Integer getSourceProductCategoryKey() {
		return sourceProductCategoryKey;
	}

	public void setSourceProductCategoryKey(Integer sourceProductCategoryKey) {
		this.sourceProductCategoryKey = sourceProductCategoryKey;
	}

	public Integer getSourceProductMasterKey() {
		return sourceProductMasterKey;
	}

	public void setSourceProductMasterKey(Integer sourceProductMasterKey) {
		this.sourceProductMasterKey = sourceProductMasterKey;
	}

	public Integer getPlanKey() {
		return planKey;
	}

	public void setPlanKey(Integer planKey) {
		this.planKey = planKey;
	}

	public String getAppstatus() {
		return appstatus;
	}

	public void setAppstatus(String appstatus) {
		this.appstatus = appstatus;
	}

	@Override
	public String toString() {
		return "ApplicationDetail [applicationKey=" + applicationKey + ", applicantKey=" + applicantKey + ", gender="
				+ gender + ", mobileNumber=" + mobileNumber + ", sourceApplicationKey=" + sourceApplicationKey
				+ ", name=" + name + ", fppPlanCode=" + fppPlanCode + ", planKey=" + planKey + ", dateOfBirth="
				+ dateOfBirth + ", products=" + products + ", sourceProductCategoryKey=" + sourceProductCategoryKey
				+ ", sourceProductMasterKey=" + sourceProductMasterKey + "]";
	}

}
