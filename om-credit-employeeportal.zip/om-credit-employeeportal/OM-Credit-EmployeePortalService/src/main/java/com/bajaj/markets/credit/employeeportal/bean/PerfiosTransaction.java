package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class PerfiosTransaction implements Serializable {

	private static final long serialVersionUID = 1L;

	private Double salaryTransactionAmount;
	private String transactionDate;
	private String userSelectedSalary;
	private String perfiosSelectedSalary;
	private String narration;
	private String category;
	private String account;
	private Double balance;
	private String variations;

	public Double getSalaryTransactionAmount() {
		return salaryTransactionAmount;
	}

	public void setSalaryTransactionAmount(Double salaryTransactionAmount) {
		this.salaryTransactionAmount = salaryTransactionAmount;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getUserSelectedSalary() {
		return userSelectedSalary;
	}

	public void setUserSelectedSalary(String userSelectedSalary) {
		this.userSelectedSalary = userSelectedSalary;
	}

	public String getPerfiosSelectedSalary() {
		return perfiosSelectedSalary;
	}

	public void setPerfiosSelectedSalary(String perfiosSelectedSalary) {
		this.perfiosSelectedSalary = perfiosSelectedSalary;
	}

	public String getNarration() {
		return narration;
	}

	public void setNarration(String narration) {
		this.narration = narration;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public String getVariations() {
		return variations;
	}

	public void setVariations(String variations) {
		this.variations = variations;
	}

}