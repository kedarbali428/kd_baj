package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class PricingDetail {
	
	private String appLoanPricingKey;
	
	private String applicationKey;
	
	private String prodCategoryCode;
	
	private Integer isTenure;
	
	private Integer droplineTenure;
	
	private BigDecimal emiAmount;
	
	private String baseRateCode;
	
	private BigDecimal baseRateValue;
	
	private String firstDueDate;
	
	private Integer dueDay;
	
	private BigDecimal graceTerm;
	
	private String nextDueDate;
	
	private BigDecimal roi;
	
	private String isEmi;
	
	private BigDecimal droplineEmi;
	
	private String pennantLoanType;
	
	private BigDecimal netDisbursementAmount;
	
	private BigDecimal loanAmount;
	
	private List<PricingFees> fees;
	
	private String loanType;
	
	private String isBpiApplicable;
	
	private BigDecimal roiWithBundle;
	
	private BigDecimal roiWithoutBundle;
	
	private BigDecimal finalLoanAmount;
	
	private BigDecimal loanAmmountWithBundle;
	
	private BigDecimal loanAmmountWithoutBundle;
	
	private String pricingStatus;
	
	private BigDecimal raisedBy;
	
	private BigDecimal finalRoi;
	
	@NotBlank(message="source can not be blank or null")
	@Pattern(regexp = "JOURNEY|EP", flags = Pattern.Flag.CASE_INSENSITIVE)
	private String source;
	
	private List<BundlePrice> bundlePrice;
	
	private PricingStatus approval;
	
	private Integer bundleSelected;

	private BigDecimal totalFees;
	
	public PricingDetail() {
		super();
	}

	public BigDecimal getTotalFees() {
		return totalFees;
	}

	public void setTotalFees(BigDecimal totalFees) {
		this.totalFees = totalFees;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getIsBpiApplicable() {
		return isBpiApplicable;
	}

	public void setIsBpiApplicable(String isBpiApplicable) {
		this.isBpiApplicable = isBpiApplicable;
	}

	public String getAppLoanPricingKey() {
		return appLoanPricingKey;
	}

	public void setAppLoanPricingKey(String appLoanPricingKey) {
		this.appLoanPricingKey = appLoanPricingKey;
	}

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getProdCategoryCode() {
		return prodCategoryCode;
	}

	public void setProdCategoryCode(String prodCategoryCode) {
		this.prodCategoryCode = prodCategoryCode;
	}

	public Integer getIsTenure() {
		return isTenure;
	}

	public void setIsTenure(Integer isTenure) {
		this.isTenure = isTenure;
	}

	public Integer getDroplineTenure() {
		return droplineTenure;
	}

	public void setDroplineTenure(Integer droplineTenure) {
		this.droplineTenure = droplineTenure;
	}

	public BigDecimal getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(BigDecimal emiAmount) {
		this.emiAmount = emiAmount;
	}

	public String getBaseRateCode() {
		return baseRateCode;
	}

	public void setBaseRateCode(String baseRateCode) {
		this.baseRateCode = baseRateCode;
	}

	public BigDecimal getBaseRateValue() {
		return baseRateValue;
	}

	public void setBaseRateValue(BigDecimal baseRateValue) {
		this.baseRateValue = baseRateValue;
	}

	public String getFirstDueDate() {
		return firstDueDate;
	}

	public void setFirstDueDate(String firstDueDate) {
		this.firstDueDate = firstDueDate;
	}

	public Integer getDueDay() {
		return dueDay;
	}

	public void setDueDay(Integer dueDay) {
		this.dueDay = dueDay;
	}

	public BigDecimal getGraceTerm() {
		return graceTerm;
	}

	public void setGraceTerm(BigDecimal graceTerm) {
		this.graceTerm = graceTerm;
	}

	public String getNextDueDate() {
		return nextDueDate;
	}

	public void setNextDueDate(String nextDueDate) {
		this.nextDueDate = nextDueDate;
	}

	public BigDecimal getRoi() {
		return roi;
	}

	public void setRoi(BigDecimal roi) {
		this.roi = roi;
	}

	public String getIsEmi() {
		return isEmi;
	}

	public void setIsEmi(String isEmi) {
		this.isEmi = isEmi;
	}

	public BigDecimal getDroplineEmi() {
		return droplineEmi;
	}

	public void setDroplineEmi(BigDecimal droplineEmi) {
		this.droplineEmi = droplineEmi;
	}

	public String getPennantLoanType() {
		return pennantLoanType;
	}

	public void setPennantLoanType(String pennantLoanType) {
		this.pennantLoanType = pennantLoanType;
	}

	public BigDecimal getNetDisbursementAmount() {
		return netDisbursementAmount;
	}

	public void setNetDisbursementAmount(BigDecimal netDisbursementAmount) {
		this.netDisbursementAmount = netDisbursementAmount;
	}

	public BigDecimal getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}

	public List<PricingFees> getFees() {
		return fees;
	}

	public void setFees(List<PricingFees> fees) {
		this.fees = fees;
	}

	public BigDecimal getRoiWithBundle() {
		return roiWithBundle;
	}

	public void setRoiWithBundle(BigDecimal roiWithBundle) {
		this.roiWithBundle = roiWithBundle;
	}

	public BigDecimal getRoiWithoutBundle() {
		return roiWithoutBundle;
	}

	public void setRoiWithoutBundle(BigDecimal roiWithoutBundle) {
		this.roiWithoutBundle = roiWithoutBundle;
	}

	public BigDecimal getFinalLoanAmount() {
		return finalLoanAmount;
	}

	public void setFinalLoanAmount(BigDecimal finalLoanAmount) {
		this.finalLoanAmount = finalLoanAmount;
	}

	public BigDecimal getLoanAmmountWithBundle() {
		return loanAmmountWithBundle;
	}

	public void setLoanAmmountWithBundle(BigDecimal loanAmmountWithBundle) {
		this.loanAmmountWithBundle = loanAmmountWithBundle;
	}

	public BigDecimal getLoanAmmountWithoutBundle() {
		return loanAmmountWithoutBundle;
	}

	public void setLoanAmmountWithoutBundle(BigDecimal loanAmmountWithoutBundle) {
		this.loanAmmountWithoutBundle = loanAmmountWithoutBundle;
	}

	public String getPricingStatus() {
		return pricingStatus;
	}

	public void setPricingStatus(String pricingStatus) {
		this.pricingStatus = pricingStatus;
	}

	public BigDecimal getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(BigDecimal raisedBy) {
		this.raisedBy = raisedBy;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public List<BundlePrice> getBundlePrice() {
		return bundlePrice;
	}

	public void setBundlePrice(List<BundlePrice> bundlePrice) {
		this.bundlePrice = bundlePrice;
	}

	public PricingStatus getApproval() {
		return approval;
	}

	public void setApproval(PricingStatus approval) {
		this.approval = approval;
	}

	public BigDecimal getFinalRoi() {
		return finalRoi;
	}

	public void setFinalRoi(BigDecimal finalRoi) {
		this.finalRoi = finalRoi;
	}

	public Integer getBundleSelected() {
		return bundleSelected;
	}

	public void setBundleSelected(Integer bundleSelected) {
		this.bundleSelected = bundleSelected;
	}
	
}
