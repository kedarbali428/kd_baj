package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class IncomeObligationRequest {
	@NotNull(message = "obligationAmount can not be null/empty")
	@Min(value=1,message="Value should be grater than zero")
	private BigDecimal obligationAmount;
	
	@Pattern(regexp="^[a-zA-Z0-9\\s_-]+$", message = "source is invalid") 
	private String source;
	
	@NotNull(message = "incomeValue can not be null/empty")
	@Min(value=1,message="Value should be grater than zero")
	private BigDecimal incomeValue;

	public BigDecimal getObligationAmount() {
		return obligationAmount;
	}

	public void setObligationAmount(BigDecimal obligationAmount) {
		this.obligationAmount = obligationAmount;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public BigDecimal getIncomeValue() {
		return incomeValue;
	}

	public void setIncomeValue(BigDecimal incomeValue) {
		this.incomeValue = incomeValue;
	}
	
}

