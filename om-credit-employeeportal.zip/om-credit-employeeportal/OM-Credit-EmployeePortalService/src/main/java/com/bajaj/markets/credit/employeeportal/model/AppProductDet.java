package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_product_det", schema = "dmvas")
public class AppProductDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_product_det_appproddetkey_generator", sequenceName = "dmvas.seq_pk_app_product_det", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_product_det_appproddetkey_generator")
	private Long appproddetkey;

	private Long applicationkey;

	private BigDecimal costwithgst;

	private BigDecimal costwithoutgst;

	private Integer isactive;

	private String issuedpolicynum;

	private String issuetimeerror;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal perceivedvalue;

	private String policyissuestatus;

	private BigDecimal premiumwithgst;

	private BigDecimal premiumwithoutgst;

	private BigDecimal sumassured;

	private Integer tenure;

	// bi-directional many-to-one association to Product
	@ManyToOne
	@JoinColumn(name = "prodkey")
	private ProductVas productVas;

	public Long getAppproddetkey() {
		return appproddetkey;
	}

	public void setAppproddetkey(Long appproddetkey) {
		this.appproddetkey = appproddetkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public BigDecimal getCostwithgst() {
		return costwithgst;
	}

	public void setCostwithgst(BigDecimal costwithgst) {
		this.costwithgst = costwithgst;
	}

	public BigDecimal getCostwithoutgst() {
		return costwithoutgst;
	}

	public void setCostwithoutgst(BigDecimal costwithoutgst) {
		this.costwithoutgst = costwithoutgst;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public String getIssuedpolicynum() {
		return issuedpolicynum;
	}

	public void setIssuedpolicynum(String issuedpolicynum) {
		this.issuedpolicynum = issuedpolicynum;
	}

	public String getIssuetimeerror() {
		return issuetimeerror;
	}

	public void setIssuetimeerror(String issuetimeerror) {
		this.issuetimeerror = issuetimeerror;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getPerceivedvalue() {
		return perceivedvalue;
	}

	public void setPerceivedvalue(BigDecimal perceivedvalue) {
		this.perceivedvalue = perceivedvalue;
	}

	public String getPolicyissuestatus() {
		return policyissuestatus;
	}

	public void setPolicyissuestatus(String policyissuestatus) {
		this.policyissuestatus = policyissuestatus;
	}

	public BigDecimal getPremiumwithgst() {
		return premiumwithgst;
	}

	public void setPremiumwithgst(BigDecimal premiumwithgst) {
		this.premiumwithgst = premiumwithgst;
	}

	public BigDecimal getPremiumwithoutgst() {
		return premiumwithoutgst;
	}

	public void setPremiumwithoutgst(BigDecimal premiumwithoutgst) {
		this.premiumwithoutgst = premiumwithoutgst;
	}

	public BigDecimal getSumassured() {
		return sumassured;
	}

	public void setSumassured(BigDecimal sumassured) {
		this.sumassured = sumassured;
	}

	public Integer getTenure() {
		return tenure;
	}

	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}

	public ProductVas getProductVas() {
		return productVas;
	}

	public void setProductVas(ProductVas productVas) {
		this.productVas = productVas;
	}

}
