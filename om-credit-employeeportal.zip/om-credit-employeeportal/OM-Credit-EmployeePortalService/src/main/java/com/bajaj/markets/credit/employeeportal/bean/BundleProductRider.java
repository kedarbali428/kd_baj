package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class BundleProductRider implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7618471123485531802L;
	private String riderCode;
	private String riderDescription;
	private String riderUserFriendlyName;
	private Double sumAssured;
	private Double premiumAmount;
	private Integer tenure;

	public void setRiderCode(String riderCode) {
		this.riderCode = riderCode;
	}

	public void setSumAssured(Double sumAssured) {
		this.sumAssured = sumAssured;
	}

	public void setPremiumAmount(Double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}

	public String getRiderCode() {
		return riderCode;
	}

	public void setRiderDescription(String riderDescription) {
		this.riderDescription = riderDescription;
	}

	public void setRiderUserFriendlyName(String riderUserFriendlyName) {
		this.riderUserFriendlyName = riderUserFriendlyName;
	}

	public String getRiderDescription() {
		return riderDescription;
	}

	public String getRiderUserFriendlyName() {
		return riderUserFriendlyName;
	}

	public Double getSumAssured() {
		return sumAssured;
	}

	public Double getPremiumAmount() {
		return premiumAmount;
	}

	public Integer getTenure() {
		return tenure;
	}

}
