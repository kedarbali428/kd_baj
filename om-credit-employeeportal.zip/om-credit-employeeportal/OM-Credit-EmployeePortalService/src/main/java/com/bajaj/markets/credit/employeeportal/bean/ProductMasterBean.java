package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class ProductMasterBean {

	private long productMasterId;
	private String productMasterName;
	private String productMasterCode;
	private boolean isProductMasterActive;
	private List<ProductCategoryBean> categoryBeans;

	public List<ProductCategoryBean> getCategoryBeans() {
		return categoryBeans;
	}

	public void setCategoryBeans(List<ProductCategoryBean> categoryBeans) {
		this.categoryBeans = categoryBeans;
	}

	public long getProductMasterId() {
		return productMasterId;
	}

	public void setProductMasterId(long productMasterId) {
		this.productMasterId = productMasterId;
	}

	public String getProductMasterName() {
		return productMasterName;
	}

	public void setProductMasterName(String productMasterName) {
		this.productMasterName = productMasterName;
	}

	public boolean isProductMasterActive() {
		return isProductMasterActive;
	}

	public void setProductMasterActive(boolean isProductMasterActive) {
		this.isProductMasterActive = isProductMasterActive;
	}

	public String getProductMasterCode() {
		return productMasterCode;
	}

	public void setProductMasterCode(String productMasterCode) {
		this.productMasterCode = productMasterCode;
	}

	public long getId() {
		return productMasterId;
	}

	public String getName() {
		return productMasterName;
	}

}
