package com.bajaj.markets.credit.employeeportal.bean;

import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants;

public class PropertyBean {

	private String locality;

	private String area;

	private String name;

	private Long propKey;

	private String address;

	private String pincode;

	private Long key;

	private Long appApltKey;

	private Long docSourceType;

	private Long docSourceKey;

	public PropertyBean() {
		super();
	}

	public PropertyBean(Long propKey, String locality, String area, String address, String pincode) {
		this.area = area;
		this.locality = locality;
		this.setAddress(address);
		this.setPincode(pincode);
		this.propKey = propKey;
		this.name = EmployeePortalConstants.PROPERTY_ID + propKey;
		this.docSourceType = 2l;
		this.appApltKey = null;
		this.key = propKey;
	}

	public PropertyBean(Long appApltKey, Long key, String name) {

		this.name = name;
		this.docSourceType = 1l;
		this.appApltKey = appApltKey;
		this.key = key;
	}

	public PropertyBean(Long appApltKey, Long key, String name, Long docSourceType) {

		this.name = name;
		this.docSourceType = docSourceType;
		this.appApltKey = appApltKey;
		this.key = key;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getPropKey() {
		return propKey;
	}

	public void setPropKey(Long propKey) {
		this.propKey = propKey;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public Long getKey() {
		return key;
	}

	public void setKey(Long key) {
		this.key = key;
	}

	public Long getAppApltKey() {
		return appApltKey;
	}

	public void setAppApltKey(Long appApltKey) {
		this.appApltKey = appApltKey;
	}

	public Long getDocSourceType() {
		return docSourceType;
	}

	public void setDocSourceType(Long docSourceType) {
		this.docSourceType = docSourceType;
	}

	public Long getDocSourceKey() {
		return docSourceKey;
	}

	public void setDocSourceKey(Long docSourceKey) {
		this.docSourceKey = docSourceKey;
	}
}
