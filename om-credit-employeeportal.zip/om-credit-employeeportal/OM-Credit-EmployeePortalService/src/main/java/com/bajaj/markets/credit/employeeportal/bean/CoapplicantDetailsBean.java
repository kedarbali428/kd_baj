package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CoapplicantDetailsBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2042965882783957737L;
	
	private String coapplicantObligationAmount;
	
	private String coapplicantIncome;

	public String getCoapplicantObligationAmount() {
		return coapplicantObligationAmount;
	}

	public void setCoapplicantObligationAmount(String coapplicantObligationAmount) {
		this.coapplicantObligationAmount = coapplicantObligationAmount;
	}

	public String getCoapplicantIncome() {
		return coapplicantIncome;
	}

	public void setCoapplicantIncome(String coapplicantIncome) {
		this.coapplicantIncome = coapplicantIncome;
	}
	

}
