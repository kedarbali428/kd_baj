package com.bajaj.markets.credit.employeeportal.bean;

public class FeeCalculationResponse {
private FeeCalculationOutput feeCalculationOutput;

private Boolean Action;

public FeeCalculationOutput getFeeCalculationOutput() {
	return feeCalculationOutput;
}

public void setFeeCalculationOutput(FeeCalculationOutput feeCalculationOutput) {
	this.feeCalculationOutput = feeCalculationOutput;
}

public Boolean getAction() {
	return Action;
}

public void setAction(Boolean action) {
	Action = action;
}

}
