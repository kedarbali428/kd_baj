package com.bajaj.markets.credit.employeeportal.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "app_doc_verification", schema = "dmcredit")
public class AppDocVerification {
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long appdocverificationkey;

		private Long applicationkey;

		private Integer docscanned;

		private Integer disbursmentkittobops;

		private Integer doclegaltobops;

		private Integer docvaluationtobops;

		private Integer docverified;

		private Timestamp docscannedt;

		private Timestamp disbkittobopsdt;

		private Timestamp docverifieddt;

		private String docscannedby;

		private String docverifiedby;

		private Integer docverifiedstatus;

		private Integer callcenterqcstatus;

		private String ccqcverifiedby;

		private Timestamp ccqcverifieddt;

		private Integer isactive;

		private Integer lstupdateby;

		private Timestamp lstupdatedt;

		public Long getAppdocverificationkey() {
			return appdocverificationkey;
		}

		public void setAppdocverificationkey(Long appdocverificationkey) {
			this.appdocverificationkey = appdocverificationkey;
		}

		public Long getApplicationkey() {
			return applicationkey;
		}

		public void setApplicationkey(Long applicationkey) {
			this.applicationkey = applicationkey;
		}

		public Integer getDocscanned() {
			return docscanned;
		}

		public void setDocscanned(Integer docscanned) {
			this.docscanned = docscanned;
		}

		public Integer getDisbursmentkittobops() {
			return disbursmentkittobops;
		}

		public void setDisbursmentkittobops(Integer disbursmentkittobops) {
			this.disbursmentkittobops = disbursmentkittobops;
		}

		public Integer getDoclegaltobops() {
			return doclegaltobops;
		}

		public void setDoclegaltobops(Integer doclegaltobops) {
			this.doclegaltobops = doclegaltobops;
		}

		public Integer getDocvaluationtobops() {
			return docvaluationtobops;
		}

		public void setDocvaluationtobops(Integer docvaluationtobops) {
			this.docvaluationtobops = docvaluationtobops;
		}

		public Integer getDocverified() {
			return docverified;
		}

		public void setDocverified(Integer docverified) {
			this.docverified = docverified;
		}

		public Timestamp getDocscannedt() {
			return docscannedt;
		}

		public void setDocscannedt(Timestamp docscannedt) {
			this.docscannedt = docscannedt;
		}

		public Timestamp getDisbkittobopsdt() {
			return disbkittobopsdt;
		}

		public void setDisbkittobopsdt(Timestamp disbkittobopsdt) {
			this.disbkittobopsdt = disbkittobopsdt;
		}

		public Timestamp getDocverifieddt() {
			return docverifieddt;
		}

		public void setDocverifieddt(Timestamp docverifieddt) {
			this.docverifieddt = docverifieddt;
		}

		public String getDocscannedby() {
			return docscannedby;
		}

		public void setDocscannedby(String docscannedby) {
			this.docscannedby = docscannedby;
		}

		public String getDocverifiedby() {
			return docverifiedby;
		}

		public void setDocverifiedby(String docverifiedby) {
			this.docverifiedby = docverifiedby;
		}

		public Integer getDocverifiedstatus() {
			return docverifiedstatus;
		}

		public void setDocverifiedstatus(Integer docverifiedstatus) {
			this.docverifiedstatus = docverifiedstatus;
		}

		public Integer getCallcenterqcstatus() {
			return callcenterqcstatus;
		}

		public void setCallcenterqcstatus(Integer callcenterqcstatus) {
			this.callcenterqcstatus = callcenterqcstatus;
		}

		public String getCcqcverifiedby() {
			return ccqcverifiedby;
		}

		public void setCcqcverifiedby(String ccqcverifiedby) {
			this.ccqcverifiedby = ccqcverifiedby;
		}

		public Timestamp getCcqcverifieddt() {
			return ccqcverifieddt;
		}

		public void setCcqcverifieddt(Timestamp ccqcverifieddt) {
			this.ccqcverifieddt = ccqcverifieddt;
		}

		public Integer getIsactive() {
			return isactive;
		}

		public void setIsactive(Integer isactive) {
			this.isactive = isactive;
		}

		public Integer getLstupdateby() {
			return lstupdateby;
		}

		public void setLstupdateby(Integer lstupdateby) {
			this.lstupdateby = lstupdateby;
		}

		public Timestamp getLstupdatedt() {
			return lstupdatedt;
		}

		public void setLstupdatedt(Timestamp lstupdatedt) {
			this.lstupdatedt = lstupdatedt;
		}

}
