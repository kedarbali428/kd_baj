package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class ProductResponseBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
    private Long prodCatKey;
	
    private Long prodKey;
    
    private String prodCode;
    
    private String prodDesc;

	public ProductResponseBean() {
	}

	public Long getProdCatKey() {
		return prodCatKey;
	}

	public void setProdCatKey(Long prodCatKey) {
		this.prodCatKey = prodCatKey;
	}

	public Long getProdKey() {
		return prodKey;
	}

	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}

	public String getProdCode() {
		return prodCode;
	}

	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}

	public String getProdDesc() {
		return prodDesc;
	}

	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	@Override
	public String toString() {
		return "ProductResponseBean [prodCatKey=" + prodCatKey + ", prodKey=" + prodKey + ", prodCode=" + prodCode
				+ ", prodDesc=" + prodDesc + "]";
	}

}
