package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EmandateRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	 private String mandateExpiryDate;
	 private Integer limit;
	 private String barcode;
	 @JsonProperty
	 private boolean physicalMandate;
	
	 
	public String getMandateExpiryDate() {
		return mandateExpiryDate;
	}
	public void setMandateExpiryDate(String mandateExpiryDate) {
		this.mandateExpiryDate = mandateExpiryDate;
	}
	public Integer getLimit() {
		return limit;
	}
	public void setLimit(Integer limit) {
		this.limit = limit;
	}
	public String getBarcode() {
		return barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public boolean isPhysicalMandate() {
		return physicalMandate;
	}
	public void setPhysicalMandate(boolean physicalMandate) {
		this.physicalMandate = physicalMandate;
	}
	@Override
	public String toString() {
		return "EmandateRequest [mandateExpiryDate=" + mandateExpiryDate + ", limit=" + limit + ", barcode=" + barcode
				+ ", physicalMandate=" + physicalMandate + "]";
	}
	
}
