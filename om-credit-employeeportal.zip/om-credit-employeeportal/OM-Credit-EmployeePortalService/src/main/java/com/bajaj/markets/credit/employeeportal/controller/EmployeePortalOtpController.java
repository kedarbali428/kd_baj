/**
 * 
 */
package com.bajaj.markets.credit.employeeportal.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.CommentDetails;
import com.bajaj.markets.credit.employeeportal.bean.CommentsBean;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.helper.OtpBusinessHelper;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalCommentsServiceInterface;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author deepak.ray
 * Controller for persisting comments based on user input
 */
@RestController
public class EmployeePortalOtpController {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private OtpBusinessHelper otpBusinessHelper;
	
	private static final String CLASSNAME = EmployeePortalOtpController.class.getName();

	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch comment Detail", notes = "Fetch OTP on the basis of mobile", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OTP Success", response = CommentDetails.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PostMapping(value = "/v1/employeeportal/otp/{mobile}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getEmployeeOtp(@PathVariable("mobile") String mobileNumber,@RequestHeader HttpHeaders headers){

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getEmployeeOtp method controller - applicationId: "+ mobileNumber);

		return new ResponseEntity<>(otpBusinessHelper.invokeOtp(mobileNumber, headers), HttpStatus.CREATED);
	}
	
}