package com.bajaj.markets.credit.employeeportal.bean;

import java.sql.Timestamp;

public class ManualVerification {

	private String documentScanned;
	private Timestamp documentScannedDate;
	private String disbursementKitHandedOverToBOpsFlag;
	private Timestamp disbursementKitHandedOverToBOpsFlagDate;
	private String documentVerifiedFlag;
	private Timestamp documentVerifiedDate;
	private String disbursementKitHandedOverBy;
	private String documentVerifiedBy;

	public String getDocumentScanned() {
		return documentScanned;
	}

	public void setDocumentScanned(String documentScanned) {
		this.documentScanned = documentScanned;
	}

	public Timestamp getDocumentScannedDate() {
		return documentScannedDate;
	}

	public void setDocumentScannedDate(Timestamp documentScannedDate) {
		this.documentScannedDate = documentScannedDate;
	}

	public String getDisbursementKitHandedOverToBOpsFlag() {
		return disbursementKitHandedOverToBOpsFlag;
	}

	public void setDisbursementKitHandedOverToBOpsFlag(String disbursementKitHandedOverToBOpsFlag) {
		this.disbursementKitHandedOverToBOpsFlag = disbursementKitHandedOverToBOpsFlag;
	}

	public Timestamp getDisbursementKitHandedOverToBOpsFlagDate() {
		return disbursementKitHandedOverToBOpsFlagDate;
	}

	public void setDisbursementKitHandedOverToBOpsFlagDate(Timestamp disbursementKitHandedOverToBOpsFlagDate) {
		this.disbursementKitHandedOverToBOpsFlagDate = disbursementKitHandedOverToBOpsFlagDate;
	}

	public String getDocumentVerifiedFlag() {
		return documentVerifiedFlag;
	}

	public void setDocumentVerifiedFlag(String documentVerifiedFlag) {
		this.documentVerifiedFlag = documentVerifiedFlag;
	}

	public Timestamp getDocumentVerifiedDate() {
		return documentVerifiedDate;
	}

	public void setDocumentVerifiedDate(Timestamp documentVerifiedDate) {
		this.documentVerifiedDate = documentVerifiedDate;
	}

	public String getDisbursementKitHandedOverBy() {
		return disbursementKitHandedOverBy;
	}

	public void setDisbursementKitHandedOverBy(String disbursementKitHandedOverBy) {
		this.disbursementKitHandedOverBy = disbursementKitHandedOverBy;
	}

	public String getDocumentVerifiedBy() {
		return documentVerifiedBy;
	}

	public void setDocumentVerifiedBy(String documentVerifiedBy) {
		this.documentVerifiedBy = documentVerifiedBy;
	}

}
