package com.bajaj.markets.credit.employeeportal.bean;

public class EMIBouncePerfiosDetail {
	private String emiBounceDate;
	private String emiBounceNarration;
	private String emiBounceAmount;
	/**
	 * @return the emiBounceDate
	 */
	public String getEmiBounceDate() {
		return emiBounceDate;
	}
	/**
	 * @param emiBounceDate the emiBounceDate to set
	 */
	public void setEmiBounceDate(String emiBounceDate) {
		this.emiBounceDate = emiBounceDate;
	}
	/**
	 * @return the emiBounceNarration
	 */
	public String getEmiBounceNarration() {
		return emiBounceNarration;
	}
	/**
	 * @param emiBounceNarration the emiBounceNarration to set
	 */
	public void setEmiBounceNarration(String emiBounceNarration) {
		this.emiBounceNarration = emiBounceNarration;
	}
	/**
	 * @return the emiBounceAmount
	 */
	public String getEmiBounceAmount() {
		return emiBounceAmount;
	}
	/**
	 * @param emiBounceAmount the emiBounceAmount to set
	 */
	public void setEmiBounceAmount(String emiBounceAmount) {
		this.emiBounceAmount = emiBounceAmount;
	}
}