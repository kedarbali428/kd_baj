package com.bajaj.markets.credit.employeeportal.bean;

public class CkycRelatedPersonDetails {
	
	private String relationWithApplicant;
	
	private String rpCKYCNumber;
	
	private String rpKYCVerificationDate;
	
	private String rpFirstName;
	
	private String rpMiddleName;
	
	private String rpLastName;
	
	private String rpPAN;
	
	private String rpAadhar;

	public String getRelationWithApplicant() {
		return relationWithApplicant;
	}

	public void setRelationWithApplicant(String relationWithApplicant) {
		this.relationWithApplicant = relationWithApplicant;
	}

	public String getRpCKYCNumber() {
		return rpCKYCNumber;
	}

	public void setRpCKYCNumber(String rpCKYCNumber) {
		this.rpCKYCNumber = rpCKYCNumber;
	}

	public String getRpKYCVerificationDate() {
		return rpKYCVerificationDate;
	}

	public void setRpKYCVerificationDate(String rpKYCVerificationDate) {
		this.rpKYCVerificationDate = rpKYCVerificationDate;
	}

	public String getRpFirstName() {
		return rpFirstName;
	}

	public void setRpFirstName(String rpFirstName) {
		this.rpFirstName = rpFirstName;
	}

	public String getRpMiddleName() {
		return rpMiddleName;
	}

	public void setRpMiddleName(String rpMiddleName) {
		this.rpMiddleName = rpMiddleName;
	}

	public String getRpLastName() {
		return rpLastName;
	}

	public void setRpLastName(String rpLastName) {
		this.rpLastName = rpLastName;
	}

	public String getRpPAN() {
		return rpPAN;
	}

	public void setRpPAN(String rpPAN) {
		this.rpPAN = rpPAN;
	}

	public String getRpAadhar() {
		return rpAadhar;
	}

	public void setRpAadhar(String rpAadhar) {
		this.rpAadhar = rpAadhar;
	}
}