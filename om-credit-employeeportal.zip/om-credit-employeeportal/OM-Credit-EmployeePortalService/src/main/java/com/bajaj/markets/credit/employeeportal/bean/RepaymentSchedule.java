package com.bajaj.markets.credit.employeeportal.bean;

public class RepaymentSchedule {

	private String repaymentRefKey;
	private boolean isRecurring;
	private String frequency;
	private String firstCollectionDate;
	private String status;
	private String numberOfPayments;
	private String ammount;
	private String validThrough;
	private ProductInfo productInfo;

	public String getRepaymentRefKey() {
		return repaymentRefKey;
	}

	public void setRepaymentRefKey(String repaymentRefKey) {
		this.repaymentRefKey = repaymentRefKey;
	}

	public boolean isRecurring() {
		return isRecurring;
	}

	public void setRecurring(boolean isRecurring) {
		this.isRecurring = isRecurring;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getFirstCollectionDate() {
		return firstCollectionDate;
	}

	public void setFirstCollectionDate(String firstCollectionDate) {
		this.firstCollectionDate = firstCollectionDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNumberOfPayments() {
		return numberOfPayments;
	}

	public void setNumberOfPayments(String numberOfPayments) {
		this.numberOfPayments = numberOfPayments;
	}

	public String getAmmount() {
		return ammount;
	}

	public void setAmmount(String ammount) {
		this.ammount = ammount;
	}

	public String getValidThrough() {
		return validThrough;
	}

	public void setValidThrough(String validThrough) {
		this.validThrough = validThrough;
	}

	public ProductInfo getProductInfo() {
		return productInfo;
	}

	public void setProductInfo(ProductInfo productInfo) {
		this.productInfo = productInfo;
	}

	@Override
	public String toString() {
		return "RepaymentSchedule [repaymentRefKey=" + repaymentRefKey + ", isRecurring=" + isRecurring + ", frequency="
				+ frequency + ", firstCollectionDate=" + firstCollectionDate + ", status=" + status
				+ ", numberOfPayments=" + numberOfPayments + ", ammount=" + ammount + ", validThrough=" + validThrough
				+ ", productInfo=" + productInfo + "]";
	}

}
