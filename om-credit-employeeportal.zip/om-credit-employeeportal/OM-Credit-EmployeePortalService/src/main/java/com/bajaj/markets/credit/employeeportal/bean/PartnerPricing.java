package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class PartnerPricing {
	private BigDecimal partnerApprovedAmount;
	private BigDecimal partnerApprovedROI;
	private BigDecimal partnerApprovedTenor;
	private String updatedBy;
	private Timestamp updatedDatetime;
	
	public BigDecimal getPartnerApprovedAmount() {
		return partnerApprovedAmount;
	}
	public void setPartnerApprovedAmount(BigDecimal partnerApprovedAmount) {
		this.partnerApprovedAmount = partnerApprovedAmount;
	}
	public BigDecimal getPartnerApprovedROI() {
		return partnerApprovedROI;
	}
	public void setPartnerApprovedROI(BigDecimal partnerApprovedROI) {
		this.partnerApprovedROI = partnerApprovedROI;
	}
	public BigDecimal getPartnerApprovedTenor() {
		return partnerApprovedTenor;
	}
	public void setPartnerApprovedTenor(BigDecimal partnerApprovedTenor) {
		this.partnerApprovedTenor = partnerApprovedTenor;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Timestamp getUpdatedDatetime() {
		return updatedDatetime;
	}
	public void setUpdatedDatetime(Timestamp updatedDatetime) {
		this.updatedDatetime = updatedDatetime;
	}
	
	

}
