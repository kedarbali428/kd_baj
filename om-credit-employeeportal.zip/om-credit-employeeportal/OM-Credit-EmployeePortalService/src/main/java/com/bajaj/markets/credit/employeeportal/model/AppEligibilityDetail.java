package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_eligibility_detail", schema = "dmcredit")
public class AppEligibilityDetail implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_eligibility_detail_appeligibilitykey_generator", sequenceName = "dmcredit.seq_pk_app_eligibility_detail", allocationSize = 1)
	@GeneratedValue(generator = "app_eligibility_detail_appeligibilitykey_generator", strategy = GenerationType.SEQUENCE)
	private Long appeligibilitykey;
	private Long appattrbkey;
	private Double maxeligibility;
	private Float maxtenor;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;

	public Long getAppeligibilitykey() {
		return appeligibilitykey;
	}

	public void setAppeligibilitykey(Long appeligibilitykey) {
		this.appeligibilitykey = appeligibilitykey;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Double getMaxeligibility() {
		return maxeligibility;
	}

	public void setMaxeligibility(Double maxeligibility) {
		this.maxeligibility = maxeligibility;
	}

	public Float getMaxtenor() {
		return maxtenor;
	}

	public void setMaxtenor(Float maxtenor) {
		this.maxtenor = maxtenor;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}
