package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class BreAddressReqOuput implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private OpenAddressReqOuput openAddressReqOuput;
	
	private Boolean action;

	public OpenAddressReqOuput getOpenAddressReqOuput() {
		return openAddressReqOuput;
	}

	public void setOpenAddressReqOuput(OpenAddressReqOuput openAddressReqOuput) {
		this.openAddressReqOuput = openAddressReqOuput;
	}

	public Boolean getAction() {
		return action;
	}

	public void setAction(Boolean action) {
		this.action = action;
	}

}
