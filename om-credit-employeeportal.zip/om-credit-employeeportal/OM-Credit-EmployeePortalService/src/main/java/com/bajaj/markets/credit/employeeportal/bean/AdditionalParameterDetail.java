package com.bajaj.markets.credit.employeeportal.bean;


public class AdditionalParameterDetail {
	private String utmSource;
	private String utmCampaign;
	private String utmMedium;
	private String utmChannel;
	private String utmContent; 
	private String utmTerm;
	public String getUtmContent() {
		return utmContent;
	}

	public void setUtmContent(String utmContent) {
		this.utmContent = utmContent;
	}

	public String getUtmTerm() {
		return utmTerm;
	}

	public void setUtmTerm(String utmTerm) {
		this.utmTerm = utmTerm;
	}

	public void setUtmSource(String utmSource) {
		this.utmSource = utmSource;
	}

	public void setUtmCampaign(String utmCampaign) {
		this.utmCampaign = utmCampaign;
	}

	public void setUtmMedium(String utmMedium) {
		this.utmMedium = utmMedium;
	}

	public String getUtmSource() {
		return utmSource;
	}

	public String getUtmCampaign() {
		return utmCampaign;
	}

	public String getUtmMedium() {
		return utmMedium;
	}

	public String getUtmChannel() {
		return utmChannel;
	}

	public void setUtmChannel(String utmChannel) {
		this.utmChannel = utmChannel;
	}
}