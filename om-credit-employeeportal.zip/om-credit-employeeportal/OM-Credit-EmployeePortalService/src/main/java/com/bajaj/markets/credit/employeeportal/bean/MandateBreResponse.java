package com.bajaj.markets.credit.employeeportal.bean;

public class MandateBreResponse {
	
	 private Boolean bankDetailsEditableFlag;
	 private Boolean  mandateRequiredFlag; 
     private Boolean   accountNumberEditFlag;
     private MandateDetails mandateDetails;
     private BankDetails bankDetails;
	public Boolean getBankDetailsEditableFlag() {
		return bankDetailsEditableFlag;
	}
	public void setBankDetailsEditableFlag(Boolean bankDetailsEditableFlag) {
		this.bankDetailsEditableFlag = bankDetailsEditableFlag;
	}
	public Boolean getMandateRequiredFlag() {
		return mandateRequiredFlag;
	}
	public void setMandateRequiredFlag(Boolean mandateRequiredFlag) {
		this.mandateRequiredFlag = mandateRequiredFlag;
	}
	public Boolean getAccountNumberEditFlag() {
		return accountNumberEditFlag;
	}
	public void setAccountNumberEditFlag(Boolean accountNumberEditFlag) {
		this.accountNumberEditFlag = accountNumberEditFlag;
	}
	public MandateDetails getMandateDetails() {
		return mandateDetails;
	}
	public void setMandateDetails(MandateDetails mandateDetails) {
		this.mandateDetails = mandateDetails;
	}
	public BankDetails getBankDetails() {
		return bankDetails;
	}
	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}
     
     
}
