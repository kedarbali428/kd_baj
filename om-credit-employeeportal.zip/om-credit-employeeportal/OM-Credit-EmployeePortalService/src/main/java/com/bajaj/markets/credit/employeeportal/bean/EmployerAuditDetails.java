package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class EmployerAuditDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String otherEmployerName;
	
	private String employerName;
	
	private String officialEmailID;
	
	private String employerType;
	
	private String companyCategory;
	
	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public String getOfficialEmailID() {
		return officialEmailID;
	}
	public void setOfficialEmailID(String officialEmailID) {
		this.officialEmailID = officialEmailID;
	}
	public String getEmployerType() {
		return employerType;
	}
	public void setEmployerType(String employerType) {
		this.employerType = employerType;
	}
	public String getCompanyCategory() {
		return companyCategory;
	}
	public void setCompanyCategory(String companyCategory) {
		this.companyCategory = companyCategory;
	}
	public String getOtherEmployerName() {
		return otherEmployerName;
	}
	public void setOtherEmployerName(String otherEmployerName) {
		this.otherEmployerName = otherEmployerName;
	}
	
}
