package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

public class OfferDetailsList {

	private String offerProductVariant;
	private String offerAvailable;
	private Float offerroi;
	private String offerGenerationSource;
	private String offerGenerationRule;
	private BigDecimal offerAmount;
	private String offerExpiryDate;
	private String offerId;
	private String partnerOfferId;
	private String prospectId;
	private String riskOfferType;
	private String offerType;
	private Boolean offerAccepted;
	private String riskSegmentation;

	public String getOfferProductVariant() {
		return offerProductVariant;
	}

	public void setOfferProductVariant(String offerProductVariant) {
		this.offerProductVariant = offerProductVariant;
	}

	public String getOfferAvailable() {
		return offerAvailable;
	}

	public void setOfferAvailable(String offerAvailable) {
		this.offerAvailable = offerAvailable;
	}

	public Float getOfferroi() {
		return offerroi;
	}

	public void setOfferroi(Float offerroi) {
		this.offerroi = offerroi;
	}

	public String getOfferGenerationSource() {
		return offerGenerationSource;
	}

	public void setOfferGenerationSource(String offerGenerationSource) {
		this.offerGenerationSource = offerGenerationSource;
	}

	public String getOfferGenerationRule() {
		return offerGenerationRule;
	}

	public void setOfferGenerationRule(String offerGenerationRule) {
		this.offerGenerationRule = offerGenerationRule;
	}

	public BigDecimal getOfferAmount() {
		return offerAmount;
	}

	public void setOfferAmount(BigDecimal offerAmount) {
		this.offerAmount = offerAmount;
	}

	public String getOfferExpiryDate() {
		return offerExpiryDate;
	}

	public void setOfferExpiryDate(String offerExpiryDate) {
		this.offerExpiryDate = offerExpiryDate;
	}

	public String getOfferId() {
		return offerId;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	public String getPartnerOfferId() {
		return partnerOfferId;
	}

	public void setPartnerOfferId(String partnerOfferId) {
		this.partnerOfferId = partnerOfferId;
	}

	public String getProspectId() {
		return prospectId;
	}

	public void setProspectId(String prospectId) {
		this.prospectId = prospectId;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public Boolean getOfferAccepted() {
		return offerAccepted;
	}

	public void setOfferAccepted(Boolean offerAccepted) {
		this.offerAccepted = offerAccepted;
	}

	public String getRiskSegmentation() {
		return riskSegmentation;
	}

	public void setRiskSegmentation(String riskSegmentation) {
		this.riskSegmentation = riskSegmentation;
	}
}
