package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class FieldCodesAttribute implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private Integer fieldcd;

	private String fieldname;
	
	private String fieldurl;

	public Integer getFieldcd() {
		return fieldcd;
	}

	public void setFieldcd(Integer fieldcd) {
		this.fieldcd = fieldcd;
	}

	public String getFieldname() {
		return fieldname;
	}

	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}
	
	public String getFieldurl() {
		return fieldurl;
	}

	public void setFieldurl(String fieldurl) {
		this.fieldurl = fieldurl;
	}

	public FieldCodesAttribute(Integer fieldcd, String fieldname, String fieldurl) {
		super();
		this.fieldcd = fieldcd;
		this.fieldname = fieldname;
		this.fieldurl = fieldurl;
	}
}
