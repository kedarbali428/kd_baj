package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

/* Bean to hold required data of Application Attributes
*/
public class ApplicationAttributesBean implements Serializable {
	private static final long serialVersionUID = 5930241039807278472L;

	private String appAttrbKey;
	
	private String applicationKey;
	
	@NotNull(message = "Height can not be null")
    @Digits(fraction = 2, integer = 20, message = "Height can not be other than digits")
	private Float height;

	@NotNull(message = "Weight can not be null")
    @Digits(fraction = 2, integer = 20, message = "Weight can not be other than digits")
	private Float weight;
	  
    public ApplicationAttributesBean() {
    	//Constructor
	}

	public String getAppAttrbKey() {
		return appAttrbKey;
	}

	public void setAppAttrbKey(String appAttrbKey) {
		this.appAttrbKey = appAttrbKey;
	}

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Float getHeight() {
		return height;
	}

	public void setHeight(Float height) {
		this.height = height;
	}

	public Float getWeight() {
		return weight;
	}

	public void setWeight(Float weight) {
		this.weight = weight;
	}
    
}