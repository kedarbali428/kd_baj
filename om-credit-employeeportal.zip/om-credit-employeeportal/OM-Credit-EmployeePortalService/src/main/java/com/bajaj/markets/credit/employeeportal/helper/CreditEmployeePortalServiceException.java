package com.bajaj.markets.credit.employeeportal.helper;

import org.springframework.http.HttpStatus;

public class CreditEmployeePortalServiceException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	private HttpStatus code;
	private ErrorBean errorBean;
	private Object payload;
	
	public CreditEmployeePortalServiceException() {
		super();
	}
	
	public CreditEmployeePortalServiceException(HttpStatus code, ErrorBean errorBean) {
		super();
		this.code = code;
		this.errorBean = errorBean;
	}

	public CreditEmployeePortalServiceException(HttpStatus code, ErrorBean errorBean, Object payload) {
		super();
		this.code = code;
		this.errorBean = errorBean;
		this.payload = payload;
	}

	public CreditEmployeePortalServiceException(HttpStatus code, Object payload) {
		super();
		this.code = code;
		this.payload = payload;
	}

	
	public CreditEmployeePortalServiceException(HttpStatus code, ErrorBean errorBean, Object payload, Throwable cause) {
		super(cause);
		this.code = code;
		this.errorBean = errorBean;
		this.payload = payload;
	}

	public HttpStatus getCode() {
		return code;
	}

	public ErrorBean getErrorBean() {
		return errorBean;
	}

	public Object getPayload() {
		return payload;
	}

	@Override
	public String toString() {
		return "CreditApplicationServiceException [code=" + code + ", errorBean=" + errorBean + ", payload=" + payload
				+ "]";
	}
}
