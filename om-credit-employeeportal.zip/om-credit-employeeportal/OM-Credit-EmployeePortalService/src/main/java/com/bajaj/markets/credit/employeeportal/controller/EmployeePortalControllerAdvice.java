package com.bajaj.markets.credit.employeeportal.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.ResponseBean;

@ControllerAdvice
public class EmployeePortalControllerAdvice extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(value = { CreditEmployeePortalServiceException.class })
	protected ResponseEntity<?> handleConflict(RuntimeException ex, WebRequest request) {
		CreditEmployeePortalServiceException exception = (CreditEmployeePortalServiceException) ex;	
		if(null != exception.getErrorBean() && null != exception.getPayload()){
			return handleExceptionInternal(ex, new ResponseBean(exception.getPayload(), exception.getErrorBean()), new HttpHeaders(), exception.getCode(), request);
		}else if (null != exception.getErrorBean()){
			return handleExceptionInternal(ex, exception.getErrorBean(), new HttpHeaders(), exception.getCode(),request);
		}else if (null != exception.getPayload()){
			return handleExceptionInternal(ex, exception.getPayload(), new HttpHeaders(), exception.getCode(),request);
		}else{
			return handleExceptionInternal(ex, exception.getMessage(), new HttpHeaders(), exception.getCode(),request);
		}
	}

}
