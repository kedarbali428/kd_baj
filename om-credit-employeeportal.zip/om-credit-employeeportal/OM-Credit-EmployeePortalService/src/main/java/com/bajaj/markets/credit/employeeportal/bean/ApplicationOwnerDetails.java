package com.bajaj.markets.credit.employeeportal.bean;

public class ApplicationOwnerDetails 
{
	private String currentowner;
	private String currentownerrole;
	private String previousowner;
	private String previousownerrole;
	public String getCurrentowner() {
		return currentowner;
	}
	public void setCurrentowner(String currentowner) {
		this.currentowner = currentowner;
	}
	public String getCurrentownerrole() {
		return currentownerrole;
	}
	public void setCurrentownerrole(String currentownerrole) {
		this.currentownerrole = currentownerrole;
	}
	public String getPreviousowner() {
		return previousowner;
	}
	public void setPreviousowner(String previousowner) {
		this.previousowner = previousowner;
	}
	public String getPreviousownerrole() {
		return previousownerrole;
	}
	public void setPreviousownerrole(String previousownerrole) {
		this.previousownerrole = previousownerrole;
	}
}
