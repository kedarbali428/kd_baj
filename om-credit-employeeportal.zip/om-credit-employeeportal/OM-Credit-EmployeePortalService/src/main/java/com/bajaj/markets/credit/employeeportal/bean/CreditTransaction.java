package com.bajaj.markets.credit.employeeportal.bean;

public class CreditTransaction {

	private String creditTransactionNarration;
	private String creditTransactionAmount;
	private String creditTransactionDate;
	public String getCreditTransactionNarration() {
		return creditTransactionNarration;
	}
	public void setCreditTransactionNarration(String creditTransactionNarration) {
		this.creditTransactionNarration = creditTransactionNarration;
	}
	public String getCreditTransactionAmount() {
		return creditTransactionAmount;
	}
	public void setCreditTransactionAmount(String creditTransactionAmount) {
		this.creditTransactionAmount = creditTransactionAmount;
	}
	public String getCreditTransactionDate() {
		return creditTransactionDate;
	}
	public void setCreditTransactionDate(String creditTransactionDate) {
		this.creditTransactionDate = creditTransactionDate;
	}
	
	
}
