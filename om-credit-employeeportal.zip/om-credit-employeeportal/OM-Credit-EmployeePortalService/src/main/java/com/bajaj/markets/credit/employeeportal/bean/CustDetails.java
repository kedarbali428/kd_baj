package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.util.Date;

public class CustDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	private String firstName;
	private String lastName;
	private String nameAsPerNsdl;
	private Date dob;
	private String nsdlNameMatch;
	private Long mobile;
	private String personalEmailId;
	private String branch;
	private String Gender;
	private String pan;
	private String emailAddress;
	private String utmsource;
	private String loanApplicationCreatedDate;
	private String telecallerDispositionStatus;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNameAsPerNsdl() {
		return nameAsPerNsdl;
	}

	public void setNameAsPerNsdl(String nameAsPerNsdl) {
		this.nameAsPerNsdl = nameAsPerNsdl;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getNsdlNameMatch() {
		return nsdlNameMatch;
	}

	public void setNsdlNameMatch(String nsdlNameMatch) {
		this.nsdlNameMatch = nsdlNameMatch;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getPersonalEmailId() {
		return personalEmailId;
	}

	public void setPersonalEmailId(String personalEmailId) {
		this.personalEmailId = personalEmailId;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getUtmsource() {
		return utmsource;
	}

	public void setUtmsource(String utmsource) {
		this.utmsource = utmsource;
	}

	public String getLoanApplicationCreatedDate() {
		return loanApplicationCreatedDate;
	}

	public void setLoanApplicationCreatedDate(String loanApplicationCreatedDate) {
		this.loanApplicationCreatedDate = loanApplicationCreatedDate;
	}

	public String getTelecallerDispositionStatus() {
		return telecallerDispositionStatus;
	}

	public void setTelecallerDispositionStatus(String telecallerDispositionStatus) {
		this.telecallerDispositionStatus = telecallerDispositionStatus;
	}

}
