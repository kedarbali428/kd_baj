package com.bajaj.markets.credit.employeeportal.bean;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

public class ApplicationAttributeBean {
	private Long applicationKey;
	private String customerName;
	private String branch;
	private String acctnumber;
	private String productName;
	private String appAttrbKey;
	private List<PropertyBean> propertyList = new ArrayList<>();

	@NotNull(message = "Height can not be null")
	@Digits(fraction = 2, integer = 20, message = "Height can not be other than digits")
	private Float height;

	@NotNull(message = "Weight can not be null")
	@Digits(fraction = 2, integer = 20, message = "Weight can not be other than digits")
	private Float weight;

	public String getAppAttrbKey() {
		return appAttrbKey;
	}

	public void setAppAttrbKey(String appAttrbKey) {
		this.appAttrbKey = appAttrbKey;
	}

	public Float getHeight() {
		return height;
	}

	public void setHeight(Float height) {
		this.height = height;
	}

	public Float getWeight() {
		return weight;
	}

	public void setWeight(Float weight) {
		this.weight = weight;
	}
	public List<PropertyBean> getPropertyList() {
		return propertyList;
	}

	public void setPropertyList(List<PropertyBean> propertyList) {
		this.propertyList = propertyList;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAcctnumber() {
		return acctnumber;
	}

	public void setAcctnumber(String acctnumber) {
		this.acctnumber = acctnumber;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

}
