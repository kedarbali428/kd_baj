package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CoApplicantCIBILDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String coapplicantName;
	private String coapplicantPan;
	private String coApplicantBureauBasedObligation;
	private String coApplicantBureauBasedNetSalary;

	public String getCoapplicantName() {
		return coapplicantName;
	}

	public void setCoapplicantName(String coapplicantName) {
		this.coapplicantName = coapplicantName;
	}

	public String getCoapplicantPan() {
		return coapplicantPan;
	}

	public void setCoapplicantPan(String coapplicantPan) {
		this.coapplicantPan = coapplicantPan;
	}

	public String getCoApplicantBureauBasedObligation() {
		return coApplicantBureauBasedObligation;
	}

	public void setCoApplicantBureauBasedObligation(String coApplicantBureauBasedObligation) {
		this.coApplicantBureauBasedObligation = coApplicantBureauBasedObligation;
	}

	public String getCoApplicantBureauBasedNetSalary() {
		return coApplicantBureauBasedNetSalary;
	}

	public void setCoApplicantBureauBasedNetSalary(String coApplicantBureauBasedNetSalary) {
		this.coApplicantBureauBasedNetSalary = coApplicantBureauBasedNetSalary;
	}
}