package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class ObligationDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String obligationSource;
	private BigDecimal obligationAmount;
	private String obligationAddedBy;
	private Timestamp obligationAddedTime;

	public String getObligationSource() {
		return obligationSource;
	}

	public void setObligationSource(String obligationSource) {
		this.obligationSource = obligationSource;
	}

	public BigDecimal getObligationAmount() {
		return obligationAmount;
	}

	public void setObligationAmount(BigDecimal obligationAmount) {
		this.obligationAmount = obligationAmount;
	}

	public String getObligationAddedBy() {
		return obligationAddedBy;
	}

	public void setObligationAddedBy(String obligationAddedBy) {
		this.obligationAddedBy = obligationAddedBy;
	}

	public Timestamp getObligationAddedTime() {
		return obligationAddedTime;
	}

	public void setObligationAddedTime(Timestamp obligationAddedTime) {
		this.obligationAddedTime = obligationAddedTime;
	}
}
