package com.bajaj.markets.credit.employeeportal.bean;

public class LookupCodeValueBean {
	
	private String entityDisplayName;
	private String entityName;
	private String lookupCode;
	private String displayOrder;
	
	/**
	 * @return the entityDisplayName
	 */
	public String getEntityDisplayName() {
		return entityDisplayName;
	}
	/**
	 * @param entityDisplayName the entityDisplayName to set
	 */
	public void setEntityDisplayName(String entityDisplayName) {
		this.entityDisplayName = entityDisplayName;
	}
	/**
	 * @return the entityName
	 */
	public String getEntityName() {
		return entityName;
	}
	/**
	 * @param entityName the entityName to set
	 */
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	/**
	 * @return the lookupCode
	 */
	public String getLookupCode() {
		return lookupCode;
	}
	/**
	 * @param lookupCode the lookupCode to set
	 */
	public void setLookupCode(String lookupCode) {
		this.lookupCode = lookupCode;
	}
	@Override
	public String toString() {
		return "LookupCodeValueBean [entityDisplayName=" + entityDisplayName + ", entityName=" + entityName
				+ ", lookupCode=" + lookupCode + "]";
	}
	/**
	 * @return the displayOrder
	 */
	public String getDisplayOrder() {
		return displayOrder;
	}
	/**
	 * @param displayOrder the displayOrder to set
	 */
	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}
	
	

}
