package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "app_verification_detail", schema = "dmcredit")
public class AppVerificationDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long appverificationkey;

	private Long applicantkey;

	private Long applicationkey;

	private Integer isactive;

	private Integer isverified;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String verificationattrb;

	private Timestamp verificationdt;

	private Long verificationreference;

	private String verificationsrc;

	public AppVerificationDetail() {
	}

	public Long getAppverificationkey() {
		return appverificationkey;
	}

	public void setAppverificationkey(Long appverificationkey) {
		this.appverificationkey = appverificationkey;
	}

	public Long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(Long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Integer getIsverified() {
		return isverified;
	}

	public void setIsverified(Integer isverified) {
		this.isverified = isverified;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getVerificationattrb() {
		return verificationattrb;
	}

	public void setVerificationattrb(String verificationattrb) {
		this.verificationattrb = verificationattrb;
	}

	public Timestamp getVerificationdt() {
		return verificationdt;
	}

	public void setVerificationdt(Timestamp verificationdt) {
		this.verificationdt = verificationdt;
	}

	public Long getVerificationreference() {
		return verificationreference;
	}

	public void setVerificationreference(Long verificationreference) {
		this.verificationreference = verificationreference;
	}

	public String getVerificationsrc() {
		return verificationsrc;
	}

	public void setVerificationsrc(String verificationsrc) {
		this.verificationsrc = verificationsrc;
	}

}
