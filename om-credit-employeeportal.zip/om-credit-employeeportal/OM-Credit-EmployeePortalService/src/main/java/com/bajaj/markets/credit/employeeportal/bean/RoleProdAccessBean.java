package com.bajaj.markets.credit.employeeportal.bean;

public class RoleProdAccessBean {
	private Long userRoleKey;
	private Long prodMastKey;
	private Long prodCatKey;
	private String prodCode;
	private String prodDesc;
	private boolean access;
	
	public Long getUserRoleKey() {
		return userRoleKey;
	}
	public void setUserRoleKey(Long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}
	public Long getProdMastKey() {
		return prodMastKey;
	}
	public void setProdMastKey(Long prodMastKey) {
		this.prodMastKey = prodMastKey;
	}
	public Long getProdCatKey() {
		return prodCatKey;
	}
	public void setProdCatKey(Long prodCatKey) {
		this.prodCatKey = prodCatKey;
	}
	public String getProdCode() {
		return prodCode;
	}
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}
	public String getProdDesc() {
		return prodDesc;
	}
	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}
	public boolean isAccess() {
		return access;
	}
	public void setAccess(boolean access) {
		this.access = access;
	}
}
