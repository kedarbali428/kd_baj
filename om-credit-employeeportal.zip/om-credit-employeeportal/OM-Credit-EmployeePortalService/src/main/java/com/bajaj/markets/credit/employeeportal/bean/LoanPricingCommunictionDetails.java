package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class LoanPricingCommunictionDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String emailSentFrom;
	private String emailSentBy;
	private String channel;
	private Timestamp pricingSentDate;
	private String pricingTncAccepted;
	private Timestamp tncTimestamp;
	private String acceptedSources;
	private String consentStatus;
	private String consentUpdatedFromEp;
	private String consentUpdatedBy;
	private Timestamp consentUpdatedDateTime;

	public String getEmailSentFrom() {
		return emailSentFrom;
	}

	public void setEmailSentFrom(String emailSentFrom) {
		this.emailSentFrom = emailSentFrom;
	}

	public String getEmailSentBy() {
		return emailSentBy;
	}

	public void setEmailSentBy(String emailSentBy) {
		this.emailSentBy = emailSentBy;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public Timestamp getPricingSentDate() {
		return pricingSentDate;
	}

	public void setPricingSentDate(Timestamp pricingSentDate) {
		this.pricingSentDate = pricingSentDate;
	}

	public String getPricingTncAccepted() {
		return pricingTncAccepted;
	}

	public void setPricingTncAccepted(String pricingTncAccepted) {
		this.pricingTncAccepted = pricingTncAccepted;
	}

	public Timestamp getTncTimestamp() {
		return tncTimestamp;
	}

	public void setTncTimestamp(Timestamp tncTimestamp) {
		this.tncTimestamp = tncTimestamp;
	}

	public String getAcceptedSources() {
		return acceptedSources;
	}

	public void setAcceptedSources(String acceptedSources) {
		this.acceptedSources = acceptedSources;
	}

	public String getConsentStatus() {
		return consentStatus;
	}

	public void setConsentStatus(String consentStatus) {
		this.consentStatus = consentStatus;
	}

	public String getConsentUpdatedFromEp() {
		return consentUpdatedFromEp;
	}

	public void setConsentUpdatedFromEp(String consentUpdatedFromEp) {
		this.consentUpdatedFromEp = consentUpdatedFromEp;
	}

	public String getConsentUpdatedBy() {
		return consentUpdatedBy;
	}

	public void setConsentUpdatedBy(String consentUpdatedBy) {
		this.consentUpdatedBy = consentUpdatedBy;
	}

	public Timestamp getConsentUpdatedDateTime() {
		return consentUpdatedDateTime;
	}

	public void setConsentUpdatedDateTime(Timestamp consentUpdatedDateTime) {
		this.consentUpdatedDateTime = consentUpdatedDateTime;
	}

}