package com.bajaj.markets.credit.employeeportal.bean;

public class OfferDetailsPerfios {

	private String offerSource;
	private String  offerExpiryDate;
	private String 	offerAcceptedStatus;
	private String  offerID;
	private String  riskClassification;
	private String  offerProgramCode;
	private String 	isOfferAvailable;
	private String  riskOfferType;
	private String  offerType;
	private Integer offerAmount;
	public String getOfferSource() {
		return offerSource;
	}
	public void setOfferSource(String offerSource) {
		this.offerSource = offerSource;
	}
	public String getOfferExpiryDate() {
		return offerExpiryDate;
	}
	public void setOfferExpiryDate(String offerExpiryDate) {
		this.offerExpiryDate = offerExpiryDate;
	}
	public String getOfferAcceptedStatus() {
		return offerAcceptedStatus;
	}
	public void setOfferAcceptedStatus(String offerAcceptedStatus) {
		this.offerAcceptedStatus = offerAcceptedStatus;
	}
	public String getOfferID() {
		return offerID;
	}
	public void setOfferID(String offerID) {
		this.offerID = offerID;
	}
	public String getRiskClassification() {
		return riskClassification;
	}
	public void setRiskClassification(String riskClassification) {
		this.riskClassification = riskClassification;
	}
	public String getOfferProgramCode() {
		return offerProgramCode;
	}
	public void setOfferProgramCode(String offerProgramCode) {
		this.offerProgramCode = offerProgramCode;
	}
	public String getIsOfferAvailable() {
		return isOfferAvailable;
	}
	public void setIsOfferAvailable(String isOfferAvailable) {
		this.isOfferAvailable = isOfferAvailable;
	}
	public String getRiskOfferType() {
		return riskOfferType;
	}
	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public Integer getOfferAmount() {
		return offerAmount;
	}
	public void setOfferAmount(Integer offerAmount) {
		this.offerAmount = offerAmount;
	}
}
