package com.bajaj.markets.credit.employeeportal.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.Occupation;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EpOccupationDetailService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EmployeePortalOccupationDetailController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	EpOccupationDetailService occupationService;

	private static final String CLASSNAME = EmployeePortalOccupationDetailController.class.getName();

	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch the list of previous owners of an application", notes = "Fetch the list of previous owners of an application", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Occupation detail added Successfully.", response = Occupation.class),
			@ApiResponse(code = 201, message = "Occupation type added Successfully.", response = Occupation.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application occupation detail not found",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 409, message = "Existing Occupation type can not be changed.",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@RequestMapping(value = "/v1/employeeportal/applications/{applicationId}/occupation", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateOccupation(@PathVariable("applicationId") String applicationId, @RequestBody Occupation occupation,
			 @RequestHeader HttpHeaders headers) {
		if (StringUtils.isNumeric(applicationId)) {
			Occupation result = new Occupation();
			result = occupationService.updateOccupationDetails(applicationId, occupation, headers);
			return new ResponseEntity<>(result, HttpStatus.OK);
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,
					new ErrorBean("OMCA_033", "ApplicationId should be number."));
		}
	}
}
