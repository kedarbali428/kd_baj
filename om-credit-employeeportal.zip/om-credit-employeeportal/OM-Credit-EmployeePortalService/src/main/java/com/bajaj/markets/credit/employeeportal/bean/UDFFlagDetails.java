package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

public class UDFFlagDetails {

	private long udfflgkey;

	private String description;

	private BigDecimal flagcategory;

	private String flagcode;
	
	private String udfstatusvalues;

	public long getUdfflgkey() {
		return udfflgkey;
	}

	public void setUdfflgkey(long udfflgkey) {
		this.udfflgkey = udfflgkey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getFlagcategory() {
		return flagcategory;
	}

	public void setFlagcategory(BigDecimal flagcategory) {
		this.flagcategory = flagcategory;
	}

	public String getFlagcode() {
		return flagcode;
	}

	public void setFlagcode(String flagcode) {
		this.flagcode = flagcode;
	}

	public String getUdfstatusvalues() {
		return udfstatusvalues;
	}

	public void setUdfstatusvalues(String udfstatusvalues) {
		this.udfstatusvalues = udfstatusvalues;
	}
	
}
