package com.bajaj.markets.credit.employeeportal.bean;

import java.sql.Timestamp;

public class ImpsDetails {

	private String impsStatus;
	private String impsFailureReason;
	private Timestamp impsDateAndTime;
	private String impsBankAccountNumber;
	private String customerNameAsPerImps;
	private String impsSource;
	private String impsTriggerdBy;

	public String getImpsStatus() {
		return impsStatus;
	}

	public void setImpsStatus(String impsStatus) {
		this.impsStatus = impsStatus;
	}

	public String getImpsFailureReason() {
		return impsFailureReason;
	}

	public void setImpsFailureReason(String impsFailureReason) {
		this.impsFailureReason = impsFailureReason;
	}

	public Timestamp getImpsDateAndTime() {
		return impsDateAndTime;
	}

	public void setImpsDateAndTime(Timestamp impsDateAndTime) {
		this.impsDateAndTime = impsDateAndTime;
	}

	public String getImpsBankAccountNumber() {
		return impsBankAccountNumber;
	}

	public void setImpsBankAccountNumber(String impsBankAccountNumber) {
		this.impsBankAccountNumber = impsBankAccountNumber;
	}

	public String getCustomerNameAsPerImps() {
		return customerNameAsPerImps;
	}

	public void setCustomerNameAsPerImps(String customerNameAsPerImps) {
		this.customerNameAsPerImps = customerNameAsPerImps;
	}

	public String getImpsSource() {
		return impsSource;
	}

	public void setImpsSource(String impsSource) {
		this.impsSource = impsSource;
	}

	public String getImpsTriggerdBy() {
		return impsTriggerdBy;
	}

	public void setImpsTriggerdBy(String impsTriggerdBy) {
		this.impsTriggerdBy = impsTriggerdBy;
	}

}
