package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class ProductApplicationDetails {
	private Long mobileNumber;
	private Long applicationKey;
	private Integer isActive;
	private Integer appStageCompletionPercentage;
	private Long appStatusKey;
	private String appStatusDesc;
	private Long prodmastKey;
	private Long prodcdL2;
	private Long prodcdL3;
	private BigDecimal createdBy;
	private Timestamp createdDt;
	private BigDecimal lstupdateBy;
	private Timestamp lstupdateDt;
	
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Long getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}
	public Integer getIsActive() {
		return isActive;
	}
	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}
	public Integer getAppStageCompletionPercentage() {
		return appStageCompletionPercentage;
	}
	public void setAppStageCompletionPercentage(Integer appStageCompletionPercentage) {
		this.appStageCompletionPercentage = appStageCompletionPercentage;
	}
	public Long getAppStatusKey() {
		return appStatusKey;
	}
	public void setAppStatusKey(Long appStatusKey) {
		this.appStatusKey = appStatusKey;
	}
	public String getAppStatusDesc() {
		return appStatusDesc;
	}
	public void setAppStatusDesc(String appStatusDesc) {
		this.appStatusDesc = appStatusDesc;
	}
	public Long getProdmastKey() {
		return prodmastKey;
	}
	public void setProdmastKey(Long prodmastKey) {
		this.prodmastKey = prodmastKey;
	}
	public Long getProdcdL2() {
		return prodcdL2;
	}
	public void setProdcdL2(Long prodcdL2) {
		this.prodcdL2 = prodcdL2;
	}
	public Long getProdcdL3() {
		return prodcdL3;
	}
	public void setProdcdL3(Long prodcdL3) {
		this.prodcdL3 = prodcdL3;
	}
	public BigDecimal getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(BigDecimal createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}
	public BigDecimal getLstupdateBy() {
		return lstupdateBy;
	}
	public void setLstupdateBy(BigDecimal lstupdateBy) {
		this.lstupdateBy = lstupdateBy;
	}
	public Timestamp getLstupdateDt() {
		return lstupdateDt;
	}
	public void setLstupdateDt(Timestamp lstupdateDt) {
		this.lstupdateDt = lstupdateDt;
	}
}
