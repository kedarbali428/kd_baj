package com.bajaj.markets.credit.employeeportal.helper;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@Component
public class CreditBusinessHelper {


	private RestTemplate restTemplate;

	@Autowired
	private BFLLoggerUtilExt logger;

	@PostConstruct
	public void init() {
		restTemplate = RestTemplateInstance.getRestTemplateInstance();
	}

	private static final String CLASS_NAME = CreditBusinessHelper.class.getCanonicalName();

	public RestTemplate getRestTemplate() {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start getRestTemplate");
		SimpleClientHttpRequestFactory simpleClientHttpRequestFactory = new SimpleClientHttpRequestFactory();
		restTemplate.setRequestFactory(simpleClientHttpRequestFactory);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "End getRestTemplate");
		return restTemplate;

	}

	public ResponseEntity<?> invokeRestEndpoint(HttpMethod httpMethod, String url, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start invokeRestEndpoint");
		headers.add("Content-Type", "application/json");
		HttpEntity<Object> entity = null;
		ResponseEntity<?> responseEntity = null;
		RestTemplate restTemplateInstance = null;
		try {
			entity = new HttpEntity<>(requestJson, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "RequestEndpoint : " + url);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request JSON : " + requestJson);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request Type : " + httpMethod);
			restTemplateInstance = getRestTemplate();
			if (params != null) {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType);
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Response from endpoint : " + responseEntity.toString());
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "End excuteRestCall");
			return new ResponseEntity<>(responseEntity.getBody(), responseEntity.getHeaders(),
					responseEntity.getStatusCode());
		} catch (HttpClientErrorException e) {
			if (e.getRawStatusCode() == 409)
				return new ResponseEntity<>(e.getResponseBodyAsString(), e.getResponseHeaders(), e.getStatusCode());
			if(e.getRawStatusCode() == 404 ) {
				throw new CreditEmployeePortalServiceException(e.getStatusCode(),e.getResponseBodyAsString());
			}
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					" HttpClientErrorException during " + url + " call for " + requestJson + e);
			throw new CreditEmployeePortalServiceException(e.getStatusCode(), new ErrorBean("",
					"HttpClientErrorException while calling " + url + " " + e.getResponseBodyAsString()));
		} catch (HttpStatusCodeException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"HttpStatusCodeException during " + url + " call" + requestJson + e);
			throw new CreditEmployeePortalServiceException(e.getStatusCode(), new ErrorBean("",
					"HttpStatusCodeException while calling " + url + " " + e.getLocalizedMessage()));
		} catch (RestClientException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					" RestClientException during " + url + " call for" + requestJson + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("",
							"RestClientException while calling" + url + " " + e.getLocalizedMessage()));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					" Exception during " + url + " call for" + requestJson + e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(
					"", "Exception while calling" + url + " " + e.getLocalizedMessage()));
		}
	}
}