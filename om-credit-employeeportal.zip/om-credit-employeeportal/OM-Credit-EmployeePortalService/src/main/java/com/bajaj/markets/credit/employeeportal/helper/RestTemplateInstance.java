package com.bajaj.markets.credit.employeeportal.helper;

import org.springframework.web.client.RestTemplate;

public class RestTemplateInstance {
	
	private static RestTemplate client = null;
	
	private RestTemplateInstance() {
	}
	
	public static RestTemplate getRestTemplateInstance() {
		if(client == null) {
			client = new RestTemplate();
		}
		return client;
	}

}
