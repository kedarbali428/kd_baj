package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class RevisionDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String raisedBy;
	private Timestamp raisedDateAndTime;
	private String approvedBy;
	private Timestamp approvedDateAndTime;

	public String getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;
	}

	public Timestamp getRaisedDateAndTime() {
		return raisedDateAndTime;
	}

	public void setRaisedDateAndTime(Timestamp raisedDateAndTime) {
		this.raisedDateAndTime = raisedDateAndTime;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Timestamp getApprovedDateAndTime() {
		return approvedDateAndTime;
	}

	public void setApprovedDateAndTime(Timestamp approvedDateAndTime) {
		this.approvedDateAndTime = approvedDateAndTime;
	}

}
