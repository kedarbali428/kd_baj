package com.bajaj.markets.credit.employeeportal.bean;

public class AppScoreDetails {
	private Integer mlScore;
	private Integer lrScore;
	private Integer finalScore;
	private String customerSegment;
	private Integer appScoreV2;

	public Integer getMlScore() {
		return mlScore;
	}

	public void setMlScore(Integer mlScore) {
		this.mlScore = mlScore;
	}

	public Integer getLrScore() {
		return lrScore;
	}

	public void setLrScore(Integer lrScore) {
		this.lrScore = lrScore;
	}

	public Integer getFinalScore() {
		return finalScore;
	}

	public void setFinalScore(Integer finalScore) {
		this.finalScore = finalScore;
	}

	@Override
	public String toString() {
		return "AppScoreDetails [mlScore=" + mlScore + ", lrScore=" + lrScore + ", finalScore=" + finalScore + "]";
	}

	/**
	 * @return the customerSegment
	 */
	public String getCustomerSegment() {
		return customerSegment;
	}

	/**
	 * @param customerSegment the customerSegment to set
	 */
	public void setCustomerSegment(String customerSegment) {
		this.customerSegment = customerSegment;
	}

	public Integer getAppScoreV2() {
		return appScoreV2;
	}

	public void setAppScoreV2(Integer appScoreV2) {
		this.appScoreV2 = appScoreV2;
	}
}
