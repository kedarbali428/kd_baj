package com.bajaj.markets.credit.employeeportal.bean;

public class TabBean {

	private Long tabKey;
	private String tabName;
	private Long tabCode;
	private boolean selected;

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public Long getTabCode() {
		return tabCode;
	}

	public void setTabCode(Long tabCode) {
		this.tabCode = tabCode;
	}

	public Long getTabKey() {
		return tabKey;
	}

	public void setTabKey(Long tabKey) {
		this.tabKey = tabKey;
	}

	public String getTabName() {
		return tabName;
	}

	public void setTabName(String tabName) {
		this.tabName = tabName;
	}

}
