package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class CloneRoleAccessConfigureBean {
	private List<Long> roleKeysFrom;
	private long productkeyFrom;
	private long omSubprodkeyFrom;
	private List<Long> roleKeysTo;
	private long productkeyTo;
	private long omSubprodkeyTo;
	
	public List<Long> getRoleKeysFrom() {
		return roleKeysFrom;
	}
	public void setRoleKeysFrom(List<Long> roleKeysFrom) {
		this.roleKeysFrom = roleKeysFrom;
	}
	public long getProductkeyFrom() {
		return productkeyFrom;
	}
	public void setProductkeyFrom(long productkeyFrom) {
		this.productkeyFrom = productkeyFrom;
	}
	public long getOmSubprodkeyFrom() {
		return omSubprodkeyFrom;
	}
	public void setOmSubprodkeyFrom(long omSubprodkeyFrom) {
		this.omSubprodkeyFrom = omSubprodkeyFrom;
	}
	public List<Long> getRoleKeysTo() {
		return roleKeysTo;
	}
	public void setRoleKeysTo(List<Long> roleKeysTo) {
		this.roleKeysTo = roleKeysTo;
	}
	public long getProductkeyTo() {
		return productkeyTo;
	}
	public void setProductkeyTo(long productkeyTo) {
		this.productkeyTo = productkeyTo;
	}
	public long getOmSubprodkeyTo() {
		return omSubprodkeyTo;
	}
	public void setOmSubprodkeyTo(long omSubprodkeyTo) {
		this.omSubprodkeyTo = omSubprodkeyTo;
	}
}
