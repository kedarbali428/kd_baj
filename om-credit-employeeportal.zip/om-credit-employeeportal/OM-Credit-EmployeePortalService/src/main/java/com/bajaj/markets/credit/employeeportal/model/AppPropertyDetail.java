package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_property_detail", schema = "dmcredit")
public class AppPropertyDetail implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@SequenceGenerator(name = "app_property_detail_apppropertydetkey_generator", sequenceName = "dmcredit.seq_pk_app_property_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_property_detail_apppropertydetkey_generator")
	private Long apppropertydetkey;
	private Long applicationkey;
	private Integer ispropertyidentified;
	private BigDecimal propertysizebhk;
	private BigDecimal propertysizeinsqrfeet;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private String propertytype;
	private String propertyusage;
	private String propertystatus;
	private String projectname;
	private String buildername;
	private BigDecimal propertycost;
	private BigDecimal userbudget;
	private Integer searchassistrequired;
	private BigDecimal propertymarketvalue;
	public Long getApppropertydetkey() {
		return apppropertydetkey;
	}
	public void setApppropertydetkey(Long apppropertydetkey) {
		this.apppropertydetkey = apppropertydetkey;
	}
	public Long getApplicationkey() {
		return applicationkey;
	}
	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}
	public Integer getIspropertyidentified() {
		return ispropertyidentified;
	}
	public void setIspropertyidentified(Integer ispropertyidentified) {
		this.ispropertyidentified = ispropertyidentified;
	}
	public BigDecimal getPropertysizebhk() {
		return propertysizebhk;
	}
	public void setPropertysizebhk(BigDecimal propertysizebhk) {
		this.propertysizebhk = propertysizebhk;
	}
	public BigDecimal getPropertysizeinsqrfeet() {
		return propertysizeinsqrfeet;
	}
	public void setPropertysizeinsqrfeet(BigDecimal propertysizeinsqrfeet) {
		this.propertysizeinsqrfeet = propertysizeinsqrfeet;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	public Long getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	public String getPropertytype() {
		return propertytype;
	}
	public void setPropertytype(String propertytype) {
		this.propertytype = propertytype;
	}
	public String getPropertyusage() {
		return propertyusage;
	}
	public void setPropertyusage(String propertyusage) {
		this.propertyusage = propertyusage;
	}
	public String getPropertystatus() {
		return propertystatus;
	}
	public void setPropertystatus(String propertystatus) {
		this.propertystatus = propertystatus;
	}
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	public String getBuildername() {
		return buildername;
	}
	public void setBuildername(String buildername) {
		this.buildername = buildername;
	}
	public BigDecimal getPropertycost() {
		return propertycost;
	}
	public void setPropertycost(BigDecimal propertycost) {
		this.propertycost = propertycost;
	}
	public BigDecimal getUserbudget() {
		return userbudget;
	}
	public void setUserbudget(BigDecimal userbudget) {
		this.userbudget = userbudget;
	}
	public Integer getSearchassistrequired() {
		return searchassistrequired;
	}
	public void setSearchassistrequired(Integer searchassistrequired) {
		this.searchassistrequired = searchassistrequired;
	}
	public BigDecimal getPropertymarketvalue() {
		return propertymarketvalue;
	}
	public void setPropertymarketvalue(BigDecimal propertymarketvalue) {
		this.propertymarketvalue = propertymarketvalue;
	}
	
}
