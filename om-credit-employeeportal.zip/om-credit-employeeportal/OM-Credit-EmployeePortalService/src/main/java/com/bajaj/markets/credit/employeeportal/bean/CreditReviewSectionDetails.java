package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

import com.bajaj.markets.credit.employeeportal.model.Product;

public class CreditReviewSectionDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Long applicationId;
	private String reviewAddedOn;
	private String product;
	private String creditReviewReason;
	private String creditReviewCode;
	private Integer creditReviewStatus;
	private String updatedBy;
	private String uwSegment;
	
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public String getReviewAddedOn() {
		return reviewAddedOn;
	}
	public void setReviewAddedOn(String reviewAddedOn) {
		this.reviewAddedOn = reviewAddedOn;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getCreditReviewReason() {
		return creditReviewReason;
	}
	public void setCreditReviewReason(String creditReviewReason) {
		this.creditReviewReason = creditReviewReason;
	}
	public String getCreditReviewCode() {
		return creditReviewCode;
	}
	public void setCreditReviewCode(String creditReviewCode) {
		this.creditReviewCode = creditReviewCode;
	}
	public Integer getCreditReviewStatus() {
		return creditReviewStatus;
	}
	public void setCreditReviewStatus(Integer creditReviewStatus) {
		this.creditReviewStatus = creditReviewStatus;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUwSegment() {
		return uwSegment;
	}
	public void setUwSegment(String uwSegment) {
		this.uwSegment = uwSegment;
	}
	
}
