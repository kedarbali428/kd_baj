package com.bajaj.markets.credit.employeeportal.bean;

public class BankDetailsReponse {

	private Long bankDetailsKey;
	private String accoutNumber;
	private String userAttributeKey;
	private String branchKey;
	private String impsStatus;
	private String impsKey;
	private String source;
	private String bankAccountTypeKey;
	private String impsNameMatch;
	private String finalMandateKey;
	private String systemSelectedMandateKey;
	private String bankAccountCatagory;
	private String beneficiaryType;
	private Boolean preferedBank;
	private String beneficiaryNames;
	private String holderName;
	private String bankMasterKey;
	private String mandateAddedBy;
	private String disbursementAccountHolderType;
	private String bankName;
	private String bankIfsc;
	private String bankMicr;
	private String branchName;
	private String customerNameByImps;

	public Long getBankDetailsKey() {
		return bankDetailsKey;
	}

	public void setBankDetailsKey(Long bankDetailsKey) {
		this.bankDetailsKey = bankDetailsKey;
	}

	public String getAccoutNumber() {
		return accoutNumber;
	}

	public void setAccoutNumber(String accoutNumber) {
		this.accoutNumber = accoutNumber;
	}

	public String getUserAttributeKey() {
		return userAttributeKey;
	}

	public void setUserAttributeKey(String userAttributeKey) {
		this.userAttributeKey = userAttributeKey;
	}

	public String getBranchKey() {
		return branchKey;
	}

	public void setBranchKey(String branchKey) {
		this.branchKey = branchKey;
	}

	public String getImpsStatus() {
		return impsStatus;
	}

	public void setImpsStatus(String impsStatus) {
		this.impsStatus = impsStatus;
	}

	public String getImpsKey() {
		return impsKey;
	}

	public void setImpsKey(String impsKey) {
		this.impsKey = impsKey;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getBankAccountTypeKey() {
		return bankAccountTypeKey;
	}

	public void setBankAccountTypeKey(String bankAccountTypeKey) {
		this.bankAccountTypeKey = bankAccountTypeKey;
	}

	public String getImpsNameMatch() {
		return impsNameMatch;
	}

	public void setImpsNameMatch(String impsNameMatch) {
		this.impsNameMatch = impsNameMatch;
	}

	public String getFinalMandateKey() {
		return finalMandateKey;
	}

	public void setFinalMandateKey(String finalMandateKey) {
		this.finalMandateKey = finalMandateKey;
	}

	public String getSystemSelectedMandateKey() {
		return systemSelectedMandateKey;
	}

	public void setSystemSelectedMandateKey(String systemSelectedMandateKey) {
		this.systemSelectedMandateKey = systemSelectedMandateKey;
	}

	public String getBankAccountCatagory() {
		return bankAccountCatagory;
	}

	public void setBankAccountCatagory(String bankAccountCatagory) {
		this.bankAccountCatagory = bankAccountCatagory;
	}

	public String getBeneficiaryType() {
		return beneficiaryType;
	}

	public void setBeneficiaryType(String beneficiaryType) {
		this.beneficiaryType = beneficiaryType;
	}

	public Boolean getPreferedBank() {
		return preferedBank;
	}

	public void setPreferedBank(Boolean preferedBank) {
		this.preferedBank = preferedBank;
	}

	public String getBeneficiaryNames() {
		return beneficiaryNames;
	}

	public void setBeneficiaryNames(String beneficiaryNames) {
		this.beneficiaryNames = beneficiaryNames;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getBankMasterKey() {
		return bankMasterKey;
	}

	public void setBankMasterKey(String bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}

	public String getMandateAddedBy() {
		return mandateAddedBy;
	}

	public void setMandateAddedBy(String mandateAddedBy) {
		this.mandateAddedBy = mandateAddedBy;
	}

	public String getDisbursementAccountHolderType() {
		return disbursementAccountHolderType;
	}

	public void setDisbursementAccountHolderType(String disbursementAccountHolderType) {
		this.disbursementAccountHolderType = disbursementAccountHolderType;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankIfsc() {
		return bankIfsc;
	}

	public void setBankIfsc(String bankIfsc) {
		this.bankIfsc = bankIfsc;
	}

	public String getBankMicr() {
		return bankMicr;
	}

	public void setBankMicr(String bankMicr) {
		this.bankMicr = bankMicr;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getCustomerNameByImps() {
		return customerNameByImps;
	}

	public void setCustomerNameByImps(String customerNameByImps) {
		this.customerNameByImps = customerNameByImps;
	}

}
