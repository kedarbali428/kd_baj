package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CoApplicantCibilAddressDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String coapplicantName;
	private String coapplicantPan;
	private String coapplicantCibilAddressLine1;
	private String coapplicantCibilCategory;
	private String coapplicantCibilDateReported;
	private String coapplicantCibilResidenceCode;

	public String getCoapplicantName() {
		return coapplicantName;
	}

	public void setCoapplicantName(String coapplicantName) {
		this.coapplicantName = coapplicantName;
	}

	public String getCoapplicantPan() {
		return coapplicantPan;
	}

	public void setCoapplicantPan(String coapplicantPan) {
		this.coapplicantPan = coapplicantPan;
	}

	public String getCoapplicantCibilAddressLine1() {
		return coapplicantCibilAddressLine1;
	}

	public void setCoapplicantCibilAddressLine1(String coapplicantCibilAddressLine1) {
		this.coapplicantCibilAddressLine1 = coapplicantCibilAddressLine1;
	}

	public String getCoapplicantCibilCategory() {
		return coapplicantCibilCategory;
	}

	public void setCoapplicantCibilCategory(String coapplicantCibilCategory) {
		this.coapplicantCibilCategory = coapplicantCibilCategory;
	}

	public String getCoapplicantCibilDateReported() {
		return coapplicantCibilDateReported;
	}

	public void setCoapplicantCibilDateReported(String coapplicantCibilDateReported) {
		this.coapplicantCibilDateReported = coapplicantCibilDateReported;
	}

	public String getCoapplicantCibilResidenceCode() {
		return coapplicantCibilResidenceCode;
	}

	public void setCoapplicantCibilResidenceCode(String coapplicantCibilResidenceCode) {
		this.coapplicantCibilResidenceCode = coapplicantCibilResidenceCode;
	}

}