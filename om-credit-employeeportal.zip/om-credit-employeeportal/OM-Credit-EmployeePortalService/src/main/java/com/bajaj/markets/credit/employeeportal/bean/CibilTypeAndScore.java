package com.bajaj.markets.credit.employeeportal.bean;

public class CibilTypeAndScore {
	private String cibilType;
	private String scoreV3;
	private String scoreV1;
	private Long cibilReferenceNumber;
	
	public CibilTypeAndScore() {
	}
	public Long getCibilReferenceNumber() {
		return cibilReferenceNumber;
	}
	public void setCibilReferenceNumber(Long cibilReferenceNumber) {
		this.cibilReferenceNumber = cibilReferenceNumber;
	}
	public String getCibilType() {
		return cibilType;
	}
	public void setCibilType(String cibilType) {
		this.cibilType = cibilType;
	}
	public String getScoreV3() {
		return scoreV3;
	}
	public void setScoreV3(String score) {
		this.scoreV3 = score;
	}
	public String getScoreV1() {
		return scoreV1;
	}
	public void setScoreV1(String scorev1) {
		this.scoreV1 = scorev1;
	}
	
	@Override
	public String toString() {
		return "CibilTypeAndScore [cibilReferenceNumber =" + cibilReferenceNumber+ "cibilType=" + cibilType+ ", scoreV1=" + scoreV1 + ", scoreV3=" + scoreV3 + "]";
	}
}

