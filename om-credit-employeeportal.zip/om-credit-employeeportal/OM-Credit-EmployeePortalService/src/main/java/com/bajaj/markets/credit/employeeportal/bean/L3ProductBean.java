package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class L3ProductBean implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long l3ProdKey;
	private String l3ProdName;
	
	public long getL3ProdKey() {
		return l3ProdKey;
	}
	public void setL3ProdKey(long l3ProdKey) {
		this.l3ProdKey = l3ProdKey;
	}
	public String getL3ProdName() {
		return l3ProdName;
	}
	public void setL3ProdName(String l3ProdName) {
		this.l3ProdName = l3ProdName;
	}
	
	

}
