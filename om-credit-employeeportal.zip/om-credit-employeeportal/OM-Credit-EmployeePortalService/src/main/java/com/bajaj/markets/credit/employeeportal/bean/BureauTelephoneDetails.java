package com.bajaj.markets.credit.employeeportal.bean;

public class BureauTelephoneDetails {

private String telnumber;
    
    private String telextension;
    
    private String teltype;

	/**
	 * @return the telnumber
	 */
	public String getTelnumber() {
		return telnumber;
	}

	/**
	 * @param telnumber the telnumber to set
	 */
	public void setTelnumber(String telnumber) {
		this.telnumber = telnumber;
	}

	/**
	 * @return the telextension
	 */
	public String getTelextension() {
		return telextension;
	}

	/**
	 * @param telextension the telextension to set
	 */
	public void setTelextension(String telextension) {
		this.telextension = telextension;
	}

	/**
	 * @return the teltype
	 */
	public String getTeltype() {
		return teltype;
	}

	/**
	 * @param teltype the teltype to set
	 */
	public void setTeltype(String teltype) {
		this.teltype = teltype;
	}


}
