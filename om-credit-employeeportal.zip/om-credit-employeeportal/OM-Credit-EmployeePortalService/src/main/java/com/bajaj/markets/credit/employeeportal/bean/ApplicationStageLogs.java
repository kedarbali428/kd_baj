package com.bajaj.markets.credit.employeeportal.bean;

public class ApplicationStageLogs {
	private String appstageowner;
	private String appstageindt;
	private String appstageoutdt;
	private String appsubstageindt;
	private String appsubstageoutdt;
	private String applsubstagekey;
	private String nullValue;
	private String completedBy;
	private String owner;
	private String ownerInTimeAndDate;
	private String ownerOutTimeAndDate;

	/**
	 * @return the appstageowner
	 */
	public String getAppstageowner() {
		return appstageowner;
	}

	/**
	 * @param appstageowner the appstageowner to set
	 */
	public void setAppstageowner(String appstageowner) {
		this.appstageowner = appstageowner;
	}

	/**
	 * @return the appstageindt
	 */
	public String getAppstageindt() {
		return appstageindt;
	}

	/**
	 * @param appstageindt the appstageindt to set
	 */
	public void setAppstageindt(String appstageindt) {
		this.appstageindt = appstageindt;
	}

	/**
	 * @return the appstageoutdt
	 */
	public String getAppstageoutdt() {
		return appstageoutdt;
	}

	/**
	 * @param appstageoutdt the appstageoutdt to set
	 */
	public void setAppstageoutdt(String appstageoutdt) {
		this.appstageoutdt = appstageoutdt;
	}

	/**
	 * @return the appsubstageindt
	 */
	public String getAppsubstageindt() {
		return appsubstageindt;
	}

	/**
	 * @param appsubstageindt the appsubstageindt to set
	 */
	public void setAppsubstageindt(String appsubstageindt) {
		this.appsubstageindt = appsubstageindt;
	}

	/**
	 * @return the appsubstageoutdt
	 */
	public String getAppsubstageoutdt() {
		return appsubstageoutdt;
	}

	/**
	 * @param appsubstageoutdt the appsubstageoutdt to set
	 */
	public void setAppsubstageoutdt(String appsubstageoutdt) {
		this.appsubstageoutdt = appsubstageoutdt;
	}

	/**
	 * @return the applsubstagekey
	 */
	public String getApplsubstagekey() {
		return applsubstagekey;
	}

	/**
	 * @param applsubstagekey the applsubstagekey to set
	 */
	public void setApplsubstagekey(String applsubstagekey) {
		this.applsubstagekey = applsubstagekey;
	}

	/**
	 * @return the nullValue
	 */
	public String getNullValue() {
		return nullValue;
	}

	/**
	 * @param nullValue the nullValue to set
	 */
	public void setNullValue(String nullValue) {
		this.nullValue = nullValue;
	}

	public String getCompletedBy() {
		return completedBy;
	}

	public void setCompletedBy(String completedBy) {
		this.completedBy = completedBy;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getOwnerInTimeAndDate() {
		return ownerInTimeAndDate;
	}

	public void setOwnerInTimeAndDate(String ownerInTimeAndDate) {
		this.ownerInTimeAndDate = ownerInTimeAndDate;
	}

	public String getOwnerOutTimeAndDate() {
		return ownerOutTimeAndDate;
	}

	public void setOwnerOutTimeAndDate(String ownerOutTimeAndDate) {
		this.ownerOutTimeAndDate = ownerOutTimeAndDate;
	}

}
