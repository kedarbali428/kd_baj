package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the application_email database table.
 * 
 */
@Entity
@Table(name = "application_email", schema = "dmcredit")
public class ApplicationEmail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "application_email_appemaiidkey_generator", sequenceName = "dmcredit.seq_pk_application_email", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_email_appemaiidkey_generator")
	private Long appemaiidkey;

	private Long appattrbkey;

	private Timestamp bouncedt;

	private Integer bounceflg;

	private Integer cvrequiredflag;

	private String emailaddress;

	private Integer emailpriority;

	private Long emailtypekey;

	private Integer emailverificationrequiredflag;

	private Timestamp enddt;

	private Integer isactive;

	private Integer isverified;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Timestamp startdt;

	private Timestamp verificationdt;

	private String verificationsrc;

	/*
	 * @ManyToOne(fetch=FetchType.LAZY)
	 * 
	 * @JoinColumn(name="appattrbkey") private ApplicationAttribute
	 * applicationAttribute;
	 */

	public ApplicationEmail() {
	}

	public Long getAppemaiidkey() {
		return appemaiidkey;
	}

	public void setAppemaiidkey(Long appemaiidkey) {
		this.appemaiidkey = appemaiidkey;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Timestamp getBouncedt() {
		return bouncedt;
	}

	public void setBouncedt(Timestamp bouncedt) {
		this.bouncedt = bouncedt;
	}

	public Integer getBounceflg() {
		return bounceflg;
	}

	public void setBounceflg(Integer bounceflg) {
		this.bounceflg = bounceflg;
	}

	public Integer getCvrequiredflag() {
		return cvrequiredflag;
	}

	public void setCvrequiredflag(Integer cvrequiredflag) {
		this.cvrequiredflag = cvrequiredflag;
	}

	public String getEmailaddress() {
		return emailaddress;
	}

	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}

	public Integer getEmailpriority() {
		return emailpriority;
	}

	public void setEmailpriority(Integer emailpriority) {
		this.emailpriority = emailpriority;
	}

	public Long getEmailtypekey() {
		return emailtypekey;
	}

	public void setEmailtypekey(Long emailtypekey) {
		this.emailtypekey = emailtypekey;
	}

	public Integer getEmailverificationrequiredflag() {
		return emailverificationrequiredflag;
	}

	public void setEmailverificationrequiredflag(Integer emailverificationrequiredflag) {
		this.emailverificationrequiredflag = emailverificationrequiredflag;
	}

	public Timestamp getEnddt() {
		return enddt;
	}

	public void setEnddt(Timestamp enddt) {
		this.enddt = enddt;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Integer getIsverified() {
		return isverified;
	}

	public void setIsverified(Integer isverified) {
		this.isverified = isverified;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Timestamp getStartdt() {
		return startdt;
	}

	public void setStartdt(Timestamp startdt) {
		this.startdt = startdt;
	}

	public Timestamp getVerificationdt() {
		return verificationdt;
	}

	public void setVerificationdt(Timestamp verificationdt) {
		this.verificationdt = verificationdt;
	}

	public String getVerificationsrc() {
		return verificationsrc;
	}

	public void setVerificationsrc(String verificationsrc) {
		this.verificationsrc = verificationsrc;
	}

}