package com.bajaj.markets.credit.employeeportal.bean;

public class CoapplicantEnquiryDetails {

	private String coapplicantName ;
	private String coapplicantPan ;
	private String coapplicantEnquiryControlNumber ;
	private String coapplicantEnquiryTradeline ;
	private String coapplicantEnquiryDate ;
	private String coapplicantEnquiryProduct ;
	private String coapplicantEnquiryPurpose ;
	private String coapplicantEnquiryAmount ;
	private String coapplicantEnquiryMemberShortName ;
	public String getCoapplicantName() {
		return coapplicantName;
	}
	public void setCoapplicantName(String coapplicantName) {
		this.coapplicantName = coapplicantName;
	}
	public String getCoapplicantPan() {
		return coapplicantPan;
	}
	public void setCoapplicantPan(String coapplicantPan) {
		this.coapplicantPan = coapplicantPan;
	}
	public String getCoapplicantEnquiryControlNumber() {
		return coapplicantEnquiryControlNumber;
	}
	public void setCoapplicantEnquiryControlNumber(String coapplicantEnquiryControlNumber) {
		this.coapplicantEnquiryControlNumber = coapplicantEnquiryControlNumber;
	}
	public String getCoapplicantEnquiryTradeline() {
		return coapplicantEnquiryTradeline;
	}
	public void setCoapplicantEnquiryTradeline(String coapplicantEnquiryTradeline) {
		this.coapplicantEnquiryTradeline = coapplicantEnquiryTradeline;
	}
	public String getCoapplicantEnquiryDate() {
		return coapplicantEnquiryDate;
	}
	public void setCoapplicantEnquiryDate(String coapplicantEnquiryDate) {
		this.coapplicantEnquiryDate = coapplicantEnquiryDate;
	}
	public String getCoapplicantEnquiryProduct() {
		return coapplicantEnquiryProduct;
	}
	public void setCoapplicantEnquiryProduct(String coapplicantEnquiryProduct) {
		this.coapplicantEnquiryProduct = coapplicantEnquiryProduct;
	}
	public String getCoapplicantEnquiryPurpose() {
		return coapplicantEnquiryPurpose;
	}
	public void setCoapplicantEnquiryPurpose(String coapplicantEnquiryPurpose) {
		this.coapplicantEnquiryPurpose = coapplicantEnquiryPurpose;
	}
	public String getCoapplicantEnquiryAmount() {
		return coapplicantEnquiryAmount;
	}
	public void setCoapplicantEnquiryAmount(String coapplicantEnquiryAmount) {
		this.coapplicantEnquiryAmount = coapplicantEnquiryAmount;
	}
	public String getCoapplicantEnquiryMemberShortName() {
		return coapplicantEnquiryMemberShortName;
	}
	public void setCoapplicantEnquiryMemberShortName(String coapplicantEnquiryMemberShortName) {
		this.coapplicantEnquiryMemberShortName = coapplicantEnquiryMemberShortName;
	}
	
	
}
