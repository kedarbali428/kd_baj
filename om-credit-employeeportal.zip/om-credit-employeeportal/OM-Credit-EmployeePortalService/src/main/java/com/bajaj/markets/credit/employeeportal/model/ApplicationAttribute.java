package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Where;


/**
 * The persistent class for the application_attribute database table.
 * 
 */
@Entity
@Table(name = "application_attribute", schema = "dmcredit")
public class ApplicationAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "application_attribute_appattrbkey_generator", sequenceName = "dmcredit.seq_pk_application_attribute", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_attribute_appattrbkey_generator")
	private Long appattrbkey;

	@Temporal(TemporalType.DATE)
	private Date dob;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long mobile;

	private String firstname;

	private String middlename;

	private String lastname;

	private Long salutationkey;

	private Long maritalstatuskey;

	private Long genderkey;

	private Long residencetypekey;
	
	private Long applicantkey;

	private String pan;
	
	private String mothername;

	private String fathername;

	private Long applicanttype;
	
	private String qualification;

	private Long relationcodemastkey;
	
	private Long coapplicantobligation;
	
	private Long cibilreferencekey;
	
	private String segment;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "applicationkey")
	private Application application;
	
	@OneToMany(mappedBy = "appattrbkey" ,cascade=CascadeType.ALL)
	@Where(clause="isactive = 1")
	private Set<ApplicationAddress> applicationAddresses;

	public ApplicationAttribute() {
	}

	public Long getAppattrbkey() {
		return this.appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getMobile() {
		return this.mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Long getSalutationkey() {
		return salutationkey;
	}

	public void setSalutationkey(Long salutationkey) {
		this.salutationkey = salutationkey;
	}

	public Long getMaritalstatuskey() {
		return maritalstatuskey;
	}

	public void setMaritalstatuskey(Long maritalstatuskey) {
		this.maritalstatuskey = maritalstatuskey;
	}

	public Long getGenderkey() {
		return genderkey;
	}

	public void setGenderkey(Long genderkey) {
		this.genderkey = genderkey;
	}

	public Long getResidencetypekey() {
		return residencetypekey;
	}

	public void setResidencetypekey(Long residencetypekey) {
		this.residencetypekey = residencetypekey;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}
	
	public Long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(Long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public Set<ApplicationAddress> getApplicationAddresses() {
		return applicationAddresses;
	}

	public void setApplicationAddresses(Set<ApplicationAddress> applicationAddresses) {
		this.applicationAddresses = applicationAddresses;
	}

	public Long getApplicanttype() {
		return applicanttype;
	}

	public void setApplicanttype(Long applicanttype) {
		this.applicanttype = applicanttype;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	/**
	 * @return the mothername
	 */
	public String getMothername() {
		return mothername;
	}

	/**
	 * @param mothername the mothername to set
	 */
	public void setMothername(String mothername) {
		this.mothername = mothername;
	}

	public String getFathername() {
		return fathername;
	}

	public void setFathername(String fathername) {
		this.fathername = fathername;
	}

	public Long getRelationcodemastkey() {
		return relationcodemastkey;
	}

	public void setRelationcodemastkey(Long relationcodemastkey) {
		this.relationcodemastkey = relationcodemastkey;
	}
	
	public Long getCoapplicantobligation() {
		return coapplicantobligation;
	}

	public void setCoapplicantobligation(Long coapplicantobligation) {
		this.coapplicantobligation = coapplicantobligation;
	}
	
	/**
	 * @return the cibilreferencekey
	 */
	public Long getCibilreferencekey() {
		return cibilreferencekey;
	}

	/**
	 * @param cibilreferencekey the cibilreferencekey to set
	 */
	public void setCibilreferencekey(Long cibilreferencekey) {
		this.cibilreferencekey = cibilreferencekey;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}
	
}