package com.bajaj.markets.credit.employeeportal.bean;

public class SalariedDetail {

	private Reference employerName;

	private Reference designation;

	private String experience;

	private String decNetSalary;

	private String netSalary;

	private String industry;

	// private String emailaddress;
	private String officialEmailAddress;
	private String companyCategory;

	private String employerType;

	private String workExperienceInMonths;

	private String totalExperience;

	private String employerNameOther;

	private Reference principalIndustry;
	
     private String cvEmailId;
	
	private String cvRiskCategory;

	public SalariedDetail() {
		super();
	}

	public SalariedDetail(Reference employerName, Reference designation, String experience, String decNetSalary,
			String netSalary, String officialEmailAddress, String workExperienceInMonths, String totalExperience) {
		super();
		this.employerName = employerName;
		this.designation = designation;
		this.experience = experience;
		this.decNetSalary = decNetSalary;
		this.netSalary = netSalary;
		// this.emailaddress = emailaddress;
		this.officialEmailAddress = officialEmailAddress;
		this.workExperienceInMonths = workExperienceInMonths;
		this.totalExperience = totalExperience;
	}

	public Reference getEmployerName() {
		return employerName;
	}

	public void setEmployerName(Reference employerName) {
		this.employerName = employerName;
	}

	public Reference getDesignation() {
		return designation;
	}

	public void setDesignation(Reference designation) {
		this.designation = designation;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(String netSalary) {
		this.netSalary = netSalary;
	}

	@Override
	public String toString() {
		return "SalariedDetail [employerName=" + employerName + ", designation=" + designation + ", experience="
				+ experience + ", netSalary=" + decNetSalary + "]";
	}

	/**
	 * @return the decNetSalary
	 */
	public String getDecNetSalary() {
		return decNetSalary;
	}

	/**
	 * @param decNetSalary the decNetSalary to set
	 */
	public void setDecNetSalary(String decNetSalary) {
		this.decNetSalary = decNetSalary;
	}

	/**
	 * @return the industry
	 */
	public String getIndustry() {
		return industry;
	}

	/**
	 * @param industry the industry to set
	 */
	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getOfficialEmailAddress() {
		return officialEmailAddress;
	}

	public void setOfficialEmailAddress(String officialEmailAddress) {
		this.officialEmailAddress = officialEmailAddress;
	}

	/**
	 * @return the companyCategory
	 */
	public String getCompanyCategory() {
		return companyCategory;
	}

	/**
	 * @param companyCategory the companyCategory to set
	 */
	public void setCompanyCategory(String companyCategory) {
		this.companyCategory = companyCategory;
	}

	/**
	 * @return the employerType
	 */
	public String getEmployerType() {
		return employerType;
	}

	/**
	 * @param employerType the employerType to set
	 */
	public void setEmployerType(String employerType) {
		this.employerType = employerType;
	}

	public String getWorkExperienceInMonths() {
		return workExperienceInMonths;
	}

	public void setWorkExperienceInMonths(String workExperienceInMonths) {
		this.workExperienceInMonths = workExperienceInMonths;
	}

	public String getTotalExperience() {
		return totalExperience;
	}

	public void setTotalExperience(String totalExperience) {
		this.totalExperience = totalExperience;
	}

	public String getEmployerNameOther() {
		return employerNameOther;
	}

	public void setEmployerNameOther(String employerNameOther) {
		this.employerNameOther = employerNameOther;
	}

	public Reference getPrincipalIndustry() {
		return principalIndustry;
	}

	public void setPrincipalIndustry(Reference principalIndustry) {
		this.principalIndustry = principalIndustry;
	}

	public String getCvEmailId() {
		return cvEmailId;
	}

	public void setCvEmailId(String cvEmailId) {
		this.cvEmailId = cvEmailId;
	}

	public String getCvRiskCategory() {
		return cvRiskCategory;
	}

	public void setCvRiskCategory(String cvRiskCategory) {
		this.cvRiskCategory = cvRiskCategory;
	}
}
