package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the application_stage database table.
 * 
 */
@Entity
@Table(name="application_stage", schema = "dmcredit")
public class ApplicationStage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="application_stage_appstagekey_generator", sequenceName="dmcredit.seq_pk_application_stage", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="application_stage_appstagekey_generator")
	private Long appstagekey;

	private Long applsubstagekey;

	private Integer appstagecompletionper;

	private Timestamp appstageindt;

	private Timestamp appstageoutdt;

	private BigDecimal appstageowner;


	private Timestamp appsubstageindt;

	private Timestamp appsubstageoutdt;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to Application
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="applicationkey")
	private Application application;
	
	//bi-directional many-to-one association to StageMaster
		@ManyToOne(fetch=FetchType.LAZY)
		@JoinColumn(name="appstagestatus")
		private StatusMaster statusMaster;

	public ApplicationStage() {
	}

	public Long getAppstagekey() {
		return this.appstagekey;
	}

	public void setAppstagekey(Long appstagekey) {
		this.appstagekey = appstagekey;
	}

	public Long getApplsubstagekey() {
		return this.applsubstagekey;
	}

	public void setApplsubstagekey(Long applsubstagekey) {
		this.applsubstagekey = applsubstagekey;
	}

	public Integer getAppstagecompletionper() {
		return this.appstagecompletionper;
	}

	public void setAppstagecompletionper(Integer appstagecompletionper) {
		this.appstagecompletionper = appstagecompletionper;
	}

	public Timestamp getAppstageindt() {
		return this.appstageindt;
	}

	public void setAppstageindt(Timestamp appstageindt) {
		this.appstageindt = appstageindt;
	}

	public Timestamp getAppstageoutdt() {
		return this.appstageoutdt;
	}

	public void setAppstageoutdt(Timestamp appstageoutdt) {
		this.appstageoutdt = appstageoutdt;
	}

	public BigDecimal getAppstageowner() {
		return this.appstageowner;
	}

	public void setAppstageowner(BigDecimal appstageowner) {
		this.appstageowner = appstageowner;
	}


	public Timestamp getAppsubstageindt() {
		return this.appsubstageindt;
	}

	public void setAppsubstageindt(Timestamp appsubstageindt) {
		this.appsubstageindt = appsubstageindt;
	}

	public Timestamp getAppsubstageoutdt() {
		return this.appsubstageoutdt;
	}

	public void setAppsubstageoutdt(Timestamp appsubstageoutdt) {
		this.appsubstageoutdt = appsubstageoutdt;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	/**
	 * @return the statusMaster
	 */
	public StatusMaster getStatusMaster() {
		return statusMaster;
	}

	/**
	 * @param statusMaster the statusMaster to set
	 */
	public void setStatusMaster(StatusMaster statusMaster) {
		this.statusMaster = statusMaster;
	}

}