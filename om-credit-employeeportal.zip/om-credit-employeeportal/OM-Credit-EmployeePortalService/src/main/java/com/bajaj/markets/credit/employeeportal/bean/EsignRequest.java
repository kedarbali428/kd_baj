package com.bajaj.markets.credit.employeeportal.bean;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;

public class EsignRequest {

	@NotNull
	@AssertTrue
	private boolean isForced;
	
	@NotNull
	@AssertTrue
	private boolean generateBitly;
	
	@NotNull
	@AssertTrue
	private boolean generateDocument;
	
	private String l3productCode;
	
	private String l4productCode;
	
	public boolean getIsForced() {
		return isForced;
	}

	public void setIsForced(boolean isForced) {
		this.isForced = isForced;
	}

	public boolean isGenerateBitly() {
		return generateBitly;
	}

	public void setGenerateBitly(boolean generateBitly) {
		this.generateBitly = generateBitly;
	}

	public boolean isGenerateDocument() {
		return generateDocument;
	}

	public void setGenerateDocument(boolean generateDocument) {
		this.generateDocument = generateDocument;
	}

	public String getL3productCode() {
		return l3productCode;
	}

	public void setL3productCode(String l3productCode) {
		this.l3productCode = l3productCode;
	}

	public String getL4productCode() {
		return l4productCode;
	}

	public void setL4productCode(String l4productCode) {
		this.l4productCode = l4productCode;
	}

}
