package com.bajaj.markets.credit.employeeportal.helper;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.markets.credit.employeeportal.bean.OccupationMasterBean;
import com.google.gson.Gson;

@Component
public class CreditEmployeePortalOccupationDetails {

	@Autowired
	CreditEmployeePortalClientHelper creditEmployeePortalClientHelper;

	@Value("${ref.data.base.occupation.url}")
	private String refDataOccupationBaseUrl;
	
	public OccupationMasterBean getOccupationMaster(HttpHeaders headers, Long occupationKey) {
		OccupationMasterBean bean = null;
		Gson gson = new Gson();
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String> ) creditEmployeePortalClientHelper
				.excuteRestCall(refDataOccupationBaseUrl,
						HttpMethod.GET, String.class, null, null, headers);
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				OccupationMasterBean[] occupationArray = gson.fromJson(excuteRestCall.getBody().toString(),
						OccupationMasterBean[].class);
				List<OccupationMasterBean> list = Arrays.asList(occupationArray);
				list = list.stream().filter(item -> item.getOccupationKey() == occupationKey)
						.collect(Collectors.toList());
				if (!list.isEmpty()) {
					return list.get(0);
				}
				return bean;
			}
		} catch (Exception e) {
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while parsing response from application seervice .");
		}
		return bean;
	}
}
