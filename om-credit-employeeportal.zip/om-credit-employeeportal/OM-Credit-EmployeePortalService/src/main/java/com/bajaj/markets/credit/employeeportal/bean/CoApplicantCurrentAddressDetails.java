package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CoApplicantCurrentAddressDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String coapplicantName;
	private String coapplicantPan;
	private String coApplicantCurrAddress;
	private String coApplicantCurrOglFlag;

	public String getCoapplicantName() {
		return coapplicantName;
	}

	public void setCoapplicantName(String coapplicantName) {
		this.coapplicantName = coapplicantName;
	}

	public String getCoapplicantPan() {
		return coapplicantPan;
	}

	public void setCoapplicantPan(String coapplicantPan) {
		this.coapplicantPan = coapplicantPan;
	}

	public String getCoApplicantCurrAddress() {
		return coApplicantCurrAddress;
	}

	public void setCoApplicantCurrAddress(String coApplicantCurrAddress) {
		this.coApplicantCurrAddress = coApplicantCurrAddress;
	}

	public String getCoApplicantCurrOglFlag() {
		return coApplicantCurrOglFlag;
	}

	public void setCoApplicantCurrOglFlag(String coApplicantCurrOglFlag) {
		this.coApplicantCurrOglFlag = coApplicantCurrOglFlag;
	}
}