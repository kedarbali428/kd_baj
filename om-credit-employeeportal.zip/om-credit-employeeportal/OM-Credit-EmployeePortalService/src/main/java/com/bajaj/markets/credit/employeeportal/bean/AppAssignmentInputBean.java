package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class AppAssignmentInputBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long userRoleKey;
	private Long roleKey;
	private Long userKey;
	private String assignTo;
	private String comments;
	private Long tabKey;


	public Long getUserRoleKey() {
		return userRoleKey;
	}
	public void setUserRoleKey(Long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}
	public Long getRoleKey() {
		return roleKey;
	}
	public void setRoleKey(Long roleKey) {
		this.roleKey = roleKey;
	}
	public Long getUserKey() {
		return userKey;
	}
	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}
	public String getAssignTo() {
		return assignTo;
	}
	public void setAssignTo(String assignTo) {
		this.assignTo = assignTo;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return the tabKey
	 */
	public Long getTabKey() {
		return tabKey;
	}
	/**
	 * @param tabKey the tabKey to set
	 */
	public void setTabKey(Long tabKey) {
		this.tabKey = tabKey;
	}
	
}
