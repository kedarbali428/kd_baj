package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class PreferredMandateRequest {
	    private Long applicationId;
	
        private List<BankDetails> bankDetails;

		public Long getApplicationId() {
			return applicationId;
		}

		public void setApplicationId(Long applicationId) {
			this.applicationId = applicationId;
		}

		public List<BankDetails> getBankDetails() {
			return bankDetails;
		}

		public void setBankDetails(List<BankDetails> bankDetails) {
			this.bankDetails = bankDetails;
		}
        
        
		
}
