package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class Products {

	private String productCode;
	
	private String productName;
	
	private long productKey;
	
	private double premiumWithGst;

    private double sumAssured;

    private List<Riders> riders;

    private double costWithGst;
    
    private double premiumwithoutgst;
    
    private double perceivedvalue;

    private int tenure;

	public Products() {
		super();
	}

	public double getPremiumWithGst() {
		return premiumWithGst;
	}

	public void setPremiumWithGst(double premiumWithGst) {
		this.premiumWithGst = premiumWithGst;
	}

	public double getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(double sumAssured) {
		this.sumAssured = sumAssured;
	}

	public List<Riders> getRiders() {
		return riders;
	}

	public void setRiders(List<Riders> riders) {
		this.riders = riders;
	}

	public double getCostWithGst() {
		return costWithGst;
	}

	public void setCostWithGst(double costWithGst) {
		this.costWithGst = costWithGst;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public long getProductKey() {
		return productKey;
	}

	public void setProductKey(long productKey) {
		this.productKey = productKey;
	}
	
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getPremiumwithoutgst() {
		return premiumwithoutgst;
	}

	public void setPremiumwithoutgst(double premiumwithoutgst) {
		this.premiumwithoutgst = premiumwithoutgst;
	}

	public double getPerceivedvalue() {
		return perceivedvalue;
	}

	public void setPerceivedvalue(double perceivedvalue) {
		this.perceivedvalue = perceivedvalue;
	}

	@Override
	public String toString() {
		return "Products [productCode=" + productCode + ", productName=" + productName + ", productKey=" + productKey
				+ ", premiumWithGst=" + premiumWithGst + ", sumAssured=" + sumAssured + ", riders=" + riders
				+ ", costWithGst=" + costWithGst + ", premiumwithoutgst=" + premiumwithoutgst + ", perceivedvalue="
				+ perceivedvalue + ", tenure=" + tenure + "]";
	}

}
