package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author nikhil.more
 *
 */
@Entity
@Table(name = "app_deviation_detail", schema = "dmcredit")
public class AppDeviationDtl implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_deviation_detail_appdeviationkey_generator", sequenceName = "dmcredit.seq_pk_app_deviation_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_deviation_detail_appdeviationkey_generator")
	private Long appdeviationkey;
	private Long applicationkey;
	private Integer isactive;
	private String deviationauthority;
	private Timestamp createdtm;
	private Long createdby;
	@Column(updatable = false, insertable = false)
	private Integer devaitioncodekey;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private Long prodkey;

	@ManyToOne
	@JoinColumn(name = "devaitioncodekey")
	DeviationCode deviationCode;

	public String getDeviationauthority() {
		return deviationauthority;
	}

	public void setDeviationauthority(String deviationauthority) {
		this.deviationauthority = deviationauthority;
	}

	public Timestamp getCreatedtm() {
		return createdtm;
	}

	public void setCreatedtm(Timestamp createdtm) {
		this.createdtm = createdtm;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	/**
	 * @return the deviationCode
	 */
	public DeviationCode getDeviationCode() {
		return deviationCode;
	}

	/**
	 * @param deviationCode the deviationCode to set
	 */
	public void setDeviationCode(DeviationCode deviationCode) {
		this.deviationCode = deviationCode;
	}

	/**
	 * @return the appdeviationkey
	 */
	public Long getAppdeviationkey() {
		return appdeviationkey;
	}

	/**
	 * @param appdeviationkey the appdeviationkey to set
	 */
	public void setAppdeviationkey(Long appdeviationkey) {
		this.appdeviationkey = appdeviationkey;
	}

	public Long getCreatedby() {
		return createdby;
	}

	public void setCreatedby(Long createdby) {
		this.createdby = createdby;
	}

	public Integer getDevaitioncodekey() {
		return devaitioncodekey;
	}

	public void setDevaitioncodekey(Integer devaitioncodekey) {
		this.devaitioncodekey = devaitioncodekey;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

}
