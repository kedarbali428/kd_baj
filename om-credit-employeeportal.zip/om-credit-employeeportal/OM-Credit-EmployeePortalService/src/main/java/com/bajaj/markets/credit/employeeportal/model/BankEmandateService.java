package com.bajaj.markets.credit.employeeportal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "bank_emandate_service" ,schema = "dmmaster")
public class BankEmandateService {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="bankemandateservicekey")
	private Integer bankEmandateServiceKey;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="integrationservproviderkey")
	private IntegrationServProvider integrationServProvider;
	
	@Column(name="bankmastkey")
	private Integer bankMastKey;
	
	@Column(name="netbankingflg")
	private Integer netBankingFlg;
	
	@Column(name="debitcardflg")
	private Integer debitCardFlg;
	
	@Column(name="otpflg")
	private Integer otpFlg;
	
	@Column(name="isactive")
	private Integer isActive;

	public Integer getBankEmandateServiceKey() {
		return bankEmandateServiceKey;
	}

	public void setBankEmandateServiceKey(Integer bankEmandateServiceKey) {
		this.bankEmandateServiceKey = bankEmandateServiceKey;
	}

	public IntegrationServProvider getIntegrationServProvider() {
		return integrationServProvider;
	}

	public void setIntegrationServProvider(IntegrationServProvider integrationServProvider) {
		this.integrationServProvider = integrationServProvider;
	}

	public Integer getBankMastKey() {
		return bankMastKey;
	}

	public void setBankMastKey(Integer bankMastKey) {
		this.bankMastKey = bankMastKey;
	}

	public Integer getNetBankingFlg() {
		return netBankingFlg;
	}

	public void setNetBankingFlg(Integer netBankingFlg) {
		this.netBankingFlg = netBankingFlg;
	}

	public Integer getDebitCardFlg() {
		return debitCardFlg;
	}

	public void setDebitCardFlg(Integer debitCardFlg) {
		this.debitCardFlg = debitCardFlg;
	}

	public Integer getOtpFlg() {
		return otpFlg;
	}

	public void setOtpFlg(Integer otpFlg) {
		this.otpFlg = otpFlg;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

}
