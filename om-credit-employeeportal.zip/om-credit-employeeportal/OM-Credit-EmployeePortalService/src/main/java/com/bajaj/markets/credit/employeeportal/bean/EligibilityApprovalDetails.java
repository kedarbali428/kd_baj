package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class EligibilityApprovalDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String prodkey;
	private Long revisedEligibilityAmount;
	private Long revisedTenure;
	private String revisionRequestedBy;
	private String revisionApprovedBy;
	private Timestamp revisionRequestedDatetime;
	private Timestamp revisionApprovedDatetime;
	private String productType;
	private Long systemEligibility;
	private Long revisedEligibility;
	private String revisionStatus;
	private Long systemTenore;

	public String getProdkey() {
		return prodkey;
	}

	public void setProdkey(String prodkey) {
		this.prodkey = prodkey;
	}

	public Long getRevisedEligibilityAmount() {
		return revisedEligibilityAmount;
	}

	public void setRevisedEligibilityAmount(Long revisedEligibilityAmount) {
		this.revisedEligibilityAmount = revisedEligibilityAmount;
	}

	public Long getRevisedTenure() {
		return revisedTenure;
	}

	public void setRevisedTenure(Long revisedTenure) {
		this.revisedTenure = revisedTenure;
	}

	public String getRevisionRequestedBy() {
		return revisionRequestedBy;
	}

	public void setRevisionRequestedBy(String revisionRequestedBy) {
		this.revisionRequestedBy = revisionRequestedBy;
	}

	public String getRevisionApprovedBy() {
		return revisionApprovedBy;
	}

	public void setRevisionApprovedBy(String revisionApprovedBy) {
		this.revisionApprovedBy = revisionApprovedBy;
	}

	public Timestamp getRevisionRequestedDatetime() {
		return revisionRequestedDatetime;
	}

	public void setRevisionRequestedDatetime(Timestamp revisionRequestedDatetime) {
		this.revisionRequestedDatetime = revisionRequestedDatetime;
	}

	public Timestamp getRevisionApprovedDatetime() {
		return revisionApprovedDatetime;
	}

	public void setRevisionApprovedDatetime(Timestamp revisionApprovedDatetime) {
		this.revisionApprovedDatetime = revisionApprovedDatetime;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public Long getSystemEligibility() {
		return systemEligibility;
	}

	public void setSystemEligibility(Long systemEligibility) {
		this.systemEligibility = systemEligibility;
	}

	public Long getRevisedEligibility() {
		return revisedEligibility;
	}

	public void setRevisedEligibility(Long revisedEligibility) {
		this.revisedEligibility = revisedEligibility;
	}

	public String getRevisionStatus() {
		return revisionStatus;
	}

	public void setRevisionStatus(String revisionStatus) {
		this.revisionStatus = revisionStatus;
	}

	public Long getSystemTenore() {
		return systemTenore;
	}

	public void setSystemTenore(Long systemTenore) {
		this.systemTenore = systemTenore;
	}

}
