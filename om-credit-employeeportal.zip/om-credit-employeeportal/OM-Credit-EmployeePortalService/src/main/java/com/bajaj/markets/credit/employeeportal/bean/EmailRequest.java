package com.bajaj.markets.credit.employeeportal.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class EmailRequest {
	
	@NotNull(message = "typeKey can not be null")
	@Digits(fraction = 0, integer = 50,message = "typeKey should be numeric & should not exceeds size")
	private Long typeKey;
	
	@NotBlank(message = "email can not be null")
	@Email
	private String email;
	
	@NotNull(message = "isVerified can not be null")
	private boolean isVerified;

	public Long getTypeKey() {
		return typeKey;
	}

	public void setTypeKey(Long typeKey) {
		this.typeKey = typeKey;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isVerified() {
		return isVerified;
	}

	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}
}	
