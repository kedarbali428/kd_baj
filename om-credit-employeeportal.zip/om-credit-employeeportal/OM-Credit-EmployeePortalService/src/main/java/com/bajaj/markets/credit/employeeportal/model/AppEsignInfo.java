package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_esign_info", schema = "dmcredit")
public class AppEsignInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_occupation_detail_appoccupationkey_generator", sequenceName = "dmcredit.seq_pk_app_occupation_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_occupation_detail_appoccupationkey_generator")
	private Long appesigninfokey;
	private Integer status;
	private Long appdockey;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private String suspendreason;
	
	public Long getAppesigninfokey() {
		return appesigninfokey;
	}

	public void setAppesigninfokey(Long appesigninfokey) {
		this.appesigninfokey = appesigninfokey;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getAppdockey() {
		return appdockey;
	}

	public void setAppdockey(Long appdockey) {
		this.appdockey = appdockey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getSuspendreason() {
		return suspendreason;
	}

	public void setSuspendreason(String suspendreason) {
		this.suspendreason = suspendreason;
	}
	

}
