package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_plan_det", schema = "dmvas")
public class AppPlanDet implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_plan_det_appplandetkey_generator", sequenceName = "dmvas.seq_pk_app_plan_det", allocationSize = 1)
	@GeneratedValue(generator = "app_plan_det_appplandetkey_generator", strategy = GenerationType.SEQUENCE)
	private Long appplandetkey;
	private Long applicationkey;
	private Integer floorprice;
	private Integer maxprice;
	private Integer oldprofit;
	private Integer newprofit;
	private Integer actualprice;
	private Integer saveroi;
	private Integer withplanroi;
	private Integer savingammount;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private Integer sourcekey;
	private Integer statuskey;
	private Long raisedby;
	private Long approvedby;

	public Long getAppplandetkey() {
		return appplandetkey;
	}

	public void setAppplandetkey(Long appplandetkey) {
		this.appplandetkey = appplandetkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getFloorprice() {
		return floorprice;
	}

	public void setFloorprice(Integer floorprice) {
		this.floorprice = floorprice;
	}

	public Integer getMaxprice() {
		return maxprice;
	}

	public void setMaxprice(Integer maxprice) {
		this.maxprice = maxprice;
	}

	public Integer getOldprofit() {
		return oldprofit;
	}

	public void setOldprofit(Integer oldprofit) {
		this.oldprofit = oldprofit;
	}

	public Integer getNewprofit() {
		return newprofit;
	}

	public void setNewprofit(Integer newprofit) {
		this.newprofit = newprofit;
	}

	public Integer getActualprice() {
		return actualprice;
	}

	public void setActualprice(Integer actualprice) {
		this.actualprice = actualprice;
	}

	public Integer getSaveroi() {
		return saveroi;
	}

	public void setSaveroi(Integer saveroi) {
		this.saveroi = saveroi;
	}

	public Integer getWithplanroi() {
		return withplanroi;
	}

	public void setWithplanroi(Integer withplanroi) {
		this.withplanroi = withplanroi;
	}

	public Integer getSavingammount() {
		return savingammount;
	}

	public void setSavingammount(Integer savingammount) {
		this.savingammount = savingammount;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Integer getSourcekey() {
		return sourcekey;
	}

	public void setSourcekey(Integer sourcekey) {
		this.sourcekey = sourcekey;
	}

	public Integer getStatuskey() {
		return statuskey;
	}

	public void setStatuskey(Integer statuskey) {
		this.statuskey = statuskey;
	}

	public Long getRaisedby() {
		return raisedby;
	}

	public void setRaisedby(Long raisedby) {
		this.raisedby = raisedby;
	}

	public Long getApprovedby() {
		return approvedby;
	}

	public void setApprovedby(Long approvedby) {
		this.approvedby = approvedby;
	}

}
