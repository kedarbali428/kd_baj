package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class PropertyDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String propertyIdentifiedFlag;
	private String hlProductIntent;
	private String propertyStatus;
	private String propertyUsage;
	private String projectName;
	private String builderName;
	private BigDecimal propertyCost;
	private BigDecimal propertySizeInSuperBuiltUpArea;
	private BigDecimal customerBudget;
	private Integer propertyAssistanceRequired;
	
	public String getPropertyIdentifiedFlag() {
		return propertyIdentifiedFlag;
	}
	public void setPropertyIdentifiedFlag(String propertyIdentifiedFlag) {
		this.propertyIdentifiedFlag = propertyIdentifiedFlag;
	}
	public String getHlProductIntent() {
		return hlProductIntent;
	}
	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}
	public String getPropertyStatus() {
		return propertyStatus;
	}
	public void setPropertyStatus(String propertyStatus) {
		this.propertyStatus = propertyStatus;
	}
	public String getPropertyUsage() {
		return propertyUsage;
	}
	public void setPropertyUsage(String propertyUsage) {
		this.propertyUsage = propertyUsage;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getBuilderName() {
		return builderName;
	}
	public void setBuilderName(String builderName) {
		this.builderName = builderName;
	}
	public BigDecimal getPropertyCost() {
		return propertyCost;
	}
	public void setPropertyCost(BigDecimal propertyCost) {
		this.propertyCost = propertyCost;
	}
	public BigDecimal getPropertySizeInSuperBuiltUpArea() {
		return propertySizeInSuperBuiltUpArea;
	}
	public void setPropertySizeInSuperBuiltUpArea(BigDecimal propertySizeInSuperBuiltUpArea) {
		this.propertySizeInSuperBuiltUpArea = propertySizeInSuperBuiltUpArea;
	}
	public BigDecimal getCustomerBudget() {
		return customerBudget;
	}
	public void setCustomerBudget(BigDecimal customerBudget) {
		this.customerBudget = customerBudget;
	}
	public Integer getPropertyAssistanceRequired() {
		return propertyAssistanceRequired;
	}
	public void setPropertyAssistanceRequired(Integer propertyAssistanceRequired) {
		this.propertyAssistanceRequired = propertyAssistanceRequired;
	}
	@Override
	public String toString() {
		return "PropertyDetails [propertyIdentifiedFlag=" + propertyIdentifiedFlag + ", hlProductIntent="
				+ hlProductIntent + ", propertyStatus=" + propertyStatus + ", propertyUsage=" + propertyUsage
				+ ", projectName=" + projectName + ", builderName=" + builderName + ", propertyCost=" + propertyCost
				+ ", propertySizeInSuperBuiltUpArea=" + propertySizeInSuperBuiltUpArea + ", customerBudget="
				+ customerBudget + ", propertyAssistanceRequired=" + propertyAssistanceRequired + "]";
	}
	
}
