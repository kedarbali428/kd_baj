package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

import javax.validation.constraints.Pattern;

public class BusinessOwnerDetails {

	private String businessName;

	private String businesskey;

	private Reference natureOfBusiness;

	private String natureOfBusinessDesc;

	private Reference industryType;

	private Reference anualTurnover;

	private String netMonthlyIncome;

	@Pattern(regexp = "^(0|[1-9][0-9]*)$", message = "BusinessVintage is not valid.It should only be numeric")
	private String businessVintage;

	private String proprieterName;

	private String businessPan;

	private String gstNumber;

	private String qualification;

	private Reference subindumastkey;

	private String subindmastdesc;

	private Reference businessType;

	private BigDecimal profitAfterTax;

	private BigDecimal averageBankBalance;

	private Reference companyType;

	private Integer presentBusinessVintage;

	private String constitutionType;

	@Pattern(regexp = "OWN|RENTED", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Please enter a valid value - OWN|RENTAL")
	private String officetype;

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public Reference getBusinessType() {
		return businessType;
	}

	public void setBusinesskey(String businesskey) {
		this.businesskey = businesskey;
	}

	public Reference getNatureOfBusiness() {
		return natureOfBusiness;
	}

	public void setNatureOfBusiness(Reference natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}

	public Reference getIndustryType() {
		return industryType;
	}

	public void setIndustryType(Reference industryType) {
		this.industryType = industryType;
	}

	public Reference getAnualTurnover() {
		return anualTurnover;
	}

	public void setAnualTurnover(Reference anualTurnover) {
		this.anualTurnover = anualTurnover;
	}

	public String getNetMonthlyIncome() {
		return netMonthlyIncome;
	}

	public void setNetMonthlyIncome(String netMonthlyIncome) {
		this.netMonthlyIncome = netMonthlyIncome;
	}

	public String getProprieterName() {
		return proprieterName;
	}

	public void setProprieterName(String proprieterName) {
		this.proprieterName = proprieterName;
	}

	public String getBusinessPan() {
		return businessPan;
	}

	public void setBusinessPan(String businessPan) {
		this.businessPan = businessPan;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	/**
	 * @return the qualification
	 */
	public String getQualification() {
		return qualification;
	}

	/**
	 * @param qualification the qualification to set
	 */
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getNatureOfBusinessDesc() {
		return natureOfBusinessDesc;
	}

	public void setNatureOfBusinessDesc(String natureOfBusinessDesc) {
		this.natureOfBusinessDesc = natureOfBusinessDesc;
	}

	public Reference getSubindumastkey() {
		return subindumastkey;
	}

	public void setSubindumastkey(Reference subindumastkey) {
		this.subindumastkey = subindumastkey;
	}

	public String getSubindmastdesc() {
		return subindmastdesc;
	}

	public void setSubindmastdesc(String subindmastdesc) {
		this.subindmastdesc = subindmastdesc;
	}

	/**
	 * @return the businesskey
	 */
	public String getBusinesskey() {
		return businesskey;
	}

	public String getBusinessVintage() {
		return businessVintage;
	}

	public void setBusinessVintage(String businessVintage) {
		this.businessVintage = businessVintage;
	}

	public BigDecimal getProfitAfterTax() {
		return profitAfterTax;
	}

	public void setProfitAfterTax(BigDecimal profitAfterTax) {
		this.profitAfterTax = profitAfterTax;
	}

	public BigDecimal getAverageBankBalance() {
		return averageBankBalance;
	}

	public void setAverageBankBalance(BigDecimal averageBankBalance) {
		this.averageBankBalance = averageBankBalance;
	}

	public Reference getCompanyType() {
		return companyType;
	}

	public void setCompanyType(Reference companyType) {
		this.companyType = companyType;
	}

	public Integer getPresentBusinessVintage() {
		return presentBusinessVintage;
	}

	public void setPresentBusinessVintage(Integer presentBusinessVintage) {
		this.presentBusinessVintage = presentBusinessVintage;
	}

	public String getOfficetype() {
		return officetype;
	}

	public void setOfficetype(String officetype) {
		this.officetype = officetype;
	}

	public void setBusinessType(Reference businessType) {
		this.businessType = businessType;
	}

	public String getConstitutionType() {
		return constitutionType;
	}

	public void setConstitutionType(String constitutionType) {
		this.constitutionType = constitutionType;
	}

}
