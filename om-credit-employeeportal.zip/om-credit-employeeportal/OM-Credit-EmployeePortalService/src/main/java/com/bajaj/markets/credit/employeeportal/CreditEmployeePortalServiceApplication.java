package com.bajaj.markets.credit.employeeportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;

@RefreshScope
@SpringBootApplication(exclude = { MongoAutoConfiguration.class, MongoDataAutoConfiguration.class })
@ComponentScans(value = {@ComponentScan("com.bajaj.*")})
public class CreditEmployeePortalServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditEmployeePortalServiceApplication.class, args);
	}

}
