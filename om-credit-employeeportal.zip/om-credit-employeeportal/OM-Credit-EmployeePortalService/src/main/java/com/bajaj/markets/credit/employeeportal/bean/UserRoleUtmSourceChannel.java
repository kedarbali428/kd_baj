package com.bajaj.markets.credit.employeeportal.bean;

public class UserRoleUtmSourceChannel {
	private long userutmkey;
	private long utmsrcchnmastkey;
	private long userprodkey;
	private Boolean isactive;
	public long getUserutmkey() {
		return userutmkey;
	}
	public void setUserutmkey(long userutmkey) {
		this.userutmkey = userutmkey;
	}
	public long getUtmsrcchnmastkey() {
		return utmsrcchnmastkey;
	}
	public void setUtmsrcchnmastkey(long utmsrcchnmastkey) {
		this.utmsrcchnmastkey = utmsrcchnmastkey;
	}
	public long getUserprodkey() {
		return userprodkey;
	}
	public void setUserprodkey(long userprodkey) {
		this.userprodkey = userprodkey;
	}
	public Boolean isIsactive() {
		return isactive;
	}
	public void setIsactive(Boolean isactive) {
		this.isactive = isactive;
	}
	
}
