package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class CtaTypeBean {
	private Long ctakey;

	private String ctaactivity;

	private Integer ctacode;

	private String ctadescription;

	private BigDecimal ctalocation;

	private String ctaname;

	public Long getCtakey() {
		return ctakey;
	}

	public void setCtakey(Long ctakey) {
		this.ctakey = ctakey;
	}

	public String getCtaactivity() {
		return ctaactivity;
	}

	public void setCtaactivity(String ctaactivity) {
		this.ctaactivity = ctaactivity;
	}

	public Integer getCtacode() {
		return ctacode;
	}

	public void setCtacode(Integer ctacode) {
		this.ctacode = ctacode;
	}

	public String getCtadescription() {
		return ctadescription;
	}

	public void setCtadescription(String ctadescription) {
		this.ctadescription = ctadescription;
	}

	public BigDecimal getCtalocation() {
		return ctalocation;
	}

	public void setCtalocation(BigDecimal ctalocation) {
		this.ctalocation = ctalocation;
	}

	public String getCtaname() {
		return ctaname;
	}

	public void setCtaname(String ctaname) {
		this.ctaname = ctaname;
	}

}
