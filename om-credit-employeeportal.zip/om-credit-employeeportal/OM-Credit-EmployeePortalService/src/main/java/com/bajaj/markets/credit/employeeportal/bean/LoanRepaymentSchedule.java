package com.bajaj.markets.credit.employeeportal.bean;

public class LoanRepaymentSchedule {

	private String schDate;
	private String pftAmount;
	private String schdPft;
	private String schdPftPaid;
	private String schdPri;
	private String schdPriPaid;
	private String feeSchd;
	private String totalAmount;
	private String endBal;
	private String tDSAmount;

	public String gettDSAmount() {
		return tDSAmount;
	}

	public void settDSAmount(String tDSAmount) {
		this.tDSAmount = tDSAmount;
	}

	public String getSchDate() {
		return schDate;
	}

	public void setSchDate(String schDate) {
		this.schDate = schDate;
	}

	public String getPftAmount() {
		return pftAmount;
	}

	public void setPftAmount(String pftAmount) {
		this.pftAmount = pftAmount;
	}

	public String getSchdPft() {
		return schdPft;
	}

	public void setSchdPft(String schdPft) {
		this.schdPft = schdPft;
	}

	public String getSchdPftPaid() {
		return schdPftPaid;
	}

	public void setSchdPftPaid(String schdPftPaid) {
		this.schdPftPaid = schdPftPaid;
	}

	public String getSchdPri() {
		return schdPri;
	}

	public void setSchdPri(String schdPri) {
		this.schdPri = schdPri;
	}

	public String getSchdPriPaid() {
		return schdPriPaid;
	}

	public void setSchdPriPaid(String schdPriPaid) {
		this.schdPriPaid = schdPriPaid;
	}

	public String getFeeSchd() {
		return feeSchd;
	}

	public void setFeeSchd(String feeSchd) {
		this.feeSchd = feeSchd;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getEndBal() {
		return endBal;
	}

	public void setEndBal(String endBal) {
		this.endBal = endBal;
	}

	@Override
	public String toString() {
		return "Schedule [schDate=" + schDate + ", pftAmount=" + pftAmount + ", schdPft=" + schdPft + ", schdPftPaid="
				+ schdPftPaid + ", schdPri=" + schdPri + ", schdPriPaid=" + schdPriPaid + ", feeSchd=" + feeSchd
				+ ", totalAmount=" + totalAmount + ", endBal=" + endBal + "]";
	}



}
