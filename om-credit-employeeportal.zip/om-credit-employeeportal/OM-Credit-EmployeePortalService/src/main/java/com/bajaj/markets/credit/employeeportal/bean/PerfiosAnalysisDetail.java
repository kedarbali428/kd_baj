package com.bajaj.markets.credit.employeeportal.bean;

public class PerfiosAnalysisDetail {
	private String fraudIndicator;
	
	private String suspiciousBankStatement;

	/**
	 * @return the fraudIndicator
	 */
	public String getFraudIndicator() {
		return fraudIndicator;
	}

	/**
	 * @param fraudIndicator the fraudIndicator to set
	 */
	public void setFraudIndicator(String fraudIndicator) {
		this.fraudIndicator = fraudIndicator;
	}

	/**
	 * @return the suspiciousBankStatement
	 */
	public String getSuspiciousBankStatement() {
		return suspiciousBankStatement;
	}

	/**
	 * @param suspiciousBankStatement the suspiciousBankStatement to set
	 */
	public void setSuspiciousBankStatement(String suspiciousBankStatement) {
		this.suspiciousBankStatement = suspiciousBankStatement;
	}
	
}
