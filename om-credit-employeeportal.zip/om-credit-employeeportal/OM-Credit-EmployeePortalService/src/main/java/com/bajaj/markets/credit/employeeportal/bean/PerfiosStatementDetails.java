package com.bajaj.markets.credit.employeeportal.bean;

public class PerfiosStatementDetails {
	private String statementFileName;
	private String sourceOfData;
	private String perfiosTransactionId;	
	private String passwordProtected;
	private String statementStatus;
	private String bankName;
	/**
	 * @return the sourceOfData
	 */
	public String getSourceOfData() {
		return sourceOfData;
	}
	/**
	 * @param sourceOfData the sourceOfData to set
	 */
	public void setSourceOfData(String sourceOfData) {
		this.sourceOfData = sourceOfData;
	}
	/**
	 * @return the perfiosTransactionId
	 */
	public String getPerfiosTransactionId() {
		return perfiosTransactionId;
	}
	/**
	 * @param perfiosTransactionId the perfiosTransactionId to set
	 */
	public void setPerfiosTransactionId(String perfiosTransactionId) {
		this.perfiosTransactionId = perfiosTransactionId;
	}
	/**
	 * @return the passwordProtected
	 */
	public String getPasswordProtected() {
		return passwordProtected;
	}
	/**
	 * @param passwordProtected the passwordProtected to set
	 */
	public void setPasswordProtected(String passwordProtected) {
		this.passwordProtected = passwordProtected;
	}
	/**
	 * @return the statementStatus
	 */
	public String getStatementStatus() {
		return statementStatus;
	}
	/**
	 * @param statementStatus the statementStatus to set
	 */
	public void setStatementStatus(String statementStatus) {
		this.statementStatus = statementStatus;
	}
	/**
	 * @return the statementFileName
	 */
	public String getStatementFileName() {
		return statementFileName;
	}
	/**
	 * @param statementFileName the statementFileName to set
	 */
	public void setStatementFileName(String statementFileName) {
		this.statementFileName = statementFileName;
	}
	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}
	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
}
