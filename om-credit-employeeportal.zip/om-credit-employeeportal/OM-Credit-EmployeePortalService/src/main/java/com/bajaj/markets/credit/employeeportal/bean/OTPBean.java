/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OTPBean {
	@JsonProperty("payload")
	private GenerateOTP payload;
	
	@JsonProperty("status")
	private String status;
	
	@JsonProperty("errorBean")
	private List<ErrorBean> errorBean;
	

	

	/**
	 * @param payload the payload to set
	 */
	public void setPayload(GenerateOTP payload) {
		this.payload = payload;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the errorBean
	 */
	public List<ErrorBean> getErrorBean() {
		return errorBean;
	}

	/**
	 * @param errorBean the errorBean to set
	 */
	public void setErrorBean(List<ErrorBean> errorBean) {
		this.errorBean = errorBean;
	}

	/**
	 * @return the payload
	 */
	public GenerateOTP getPayload() {
		return payload;
	}

   
}