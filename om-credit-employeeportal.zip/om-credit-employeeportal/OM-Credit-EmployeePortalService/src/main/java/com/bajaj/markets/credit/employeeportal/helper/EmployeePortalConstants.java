package com.bajaj.markets.credit.employeeportal.helper;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class EmployeePortalConstants {

	public static final String ALLOCATION_CONFIG_PROPERTY_FILE = "application.properties";
	public static final String SQL_DATE_FORMAT = "yyyy-MM-dd";
	public static final BigDecimal STATUS_ACTIVE = BigDecimal.ONE;
	public static final BigDecimal FLAG_ASSIGN_TO_USER = BigDecimal.ONE;
	public static final BigDecimal FLAG_ASSIGN_TO_ROLE = new BigDecimal("2");
	
	public static final String PARAM_IS_ACTIVE = "isActive";
	public static final String EXCEPTION_DAO = "Exception occured while creating app user assignment";
	public static final String PARAM_APPLICATION_KEY = "applicationKey";
	
	public static final String QRY_ASSIGN_APP_TO_USER = "from AppUserAssignment aua WHERE aua.application.applicationkey= :applicationKey and aua.assignenddt between '9999-12-31 00:00:00' and '9999-12-31 23:59:59' and aua.isactive=1 ";
	public static final String QRY_GET_APPLICATION_BY_KEY = "SELECT a FROM Application a WHERE a.applicationkey= :applicationKey and a.isactive= :isActive";
	
	public static final String APPLICATION_NUMBER="application";
	public static final String MOBILE="mobile";
	public static final String CHILD_APPLICATION_NUMBER="child";
	public static final String CREDIT_CARD="Credit Card";
	
	public static final String UTM_SOURCE = "&utm_source=";
	public static final String UTM_SOURCE_EMAIL_VALUE= "intcamp_EMAIL";
	public static final String UTM_SOURCE_SMS_VALUE= "intcamp_SMS";
	public static final String UTM_MEDIUM= "&utm_medium=";
	public static final String UTM_CAMPAIGN="&utm_campaign=";
	public static final String UTM_CAMPAIGN_VALUE="CallCentre_SendLinkToCust";
	public static final String UTM_CONTENT="&utm_content=";
	public static final String UTM_CONTENT_EMAIL="EPsendresumelink_EMAIL";
	public static final String UTM_CONTENT_SMS="EPsendresumelink_SMS";
	public static final String SUCCESS = "Success";
	public static final String ADDRESS_UPDATE_SUCCESS = "Address updated successfully";
	public static final String DISPOSITION_ADDED = "Disposition added successfully";
	public static final String PARENT="P";
	public static final String CHILD="C";
	public static final Integer EDITABLEBYSTAGE_TRUE = 1;
	public static final Integer EDITABLEBYSTAGE_FALSE = 2;
	public static final String COMPLETE="Complete";
	public static final String FIELD_VALUE_PROP="fieldcd.value.mapper.properties";
	public static final String SUBSECTION_METHOD_PROP="subsection.method.mapper.properties";
	public static final Long CARD_PRODKEY= 10001L;
	public static final Long SECURED_PRODKEY= 10003L;
	public static final Long CARD_CTACD= 11L;
	public static final Long LOAN_CTACD= 12L;
	public static final Long SECURED_CTACD= 13L;
	public static final String UPDATE_SUBSECTION_METHOD_PROP="subsection.updatemethod.mapper.properties";
	public static final String CARD_IS_ELIGIBLE_YES = "YES";
	public static final String CARD_IS_ELIGIBLE_NO = "NO";
	public static final String IN_PROGRESS = "Inprogress";
	public static final Integer IS_ACTIVE = 1;
	public static final String APPLICATION_UPDATED_SUCCESS="InProcess flag of child application updated successfully";
	public static final String STATUS_OK="HttpStatus.OK";
	public static final String	MANUAL_FLAG_ADDED = "Manual Flag added successfully";
	public static final String	FAILURE="Failure";
	public static final String	MANUAL_FLAG_FAILED="This particular Flag is already present for this applicantion id.";
	public static final String	FINAL_MANDATEKEY_UPDATED="Final mandate details saved successfully";
	public static final String FLAG_IS_TRUE="Yes";
	public static final String FLAG_IS_FALSE="No";
	public static final String CIBIL_STATE_COMPLETED = "COMPLETED";
	public static final String CIBIL_STATE_VERIFIED = "VERIFIED";
	public static final String DEVIATION_ADDED = "Deviation details added";
	public static final String BOL="BOL";
	public static final String RAISE_LOAN="raiseLoan";
	public static final String APPROVE_LOAN="approveLoan";
	public static final String ACTIVE="ACTIVE";
	public static final String INACTIVE="INACTIVE";
	public static final String B2BPARTNER_ROLE = "b2bpartner";
	public static final List<String> CTA_KEY_FIELD_NAME = Collections.unmodifiableList(Arrays.asList("cta", "ctaKey",
			"ctaCode", "ctaId"));
	public static List<String> getCtaKeyFieldName() {
		return CTA_KEY_FIELD_NAME;
	}
	
	public static final List<String> APPLICATION_KEY_FIELD_NAME = Collections.unmodifiableList(Arrays.asList("applicationKey", "applicationId",
			"applicationid", "applicationkey"));

	public static final Long PERSONAL_EMAIL_TYPE_KEY=70L;
	public static final Long OFFICIAL_EMAIL_TYPE_KEY=67L;
	public static final Long OTHER_EMAIL_TYPE_KEY=68L;
	public static final String DELETE_SUCCESS_MSG = "Deleted successsfully";
	public static final String DELETE_FAILURE_MSG = "Deletion Failed";
	public static final String UPDATE_SUCCESS_MSG = "Updated successsfully";
	public static final String UPDATE_FAILURE_MSG = "Updation Failed";
	public static final String GENDER_MALE = "Male";
	public static final String GENDER_FEMALE = "Female";
	public static final String APPLICANT_UPDATE_SUCCESS_MSG = "Co-Applicant Updated successsfully";
	public static final String POLICY_ISSUANCE_SUCCESS_MSG = "Policy Issuance triggered successfully";
	public static final String POLICY_ISSUANCE_FAILURE_MSG = "Policy Issuance failed";
	public static final String ADDRESSREQUIREMENTBRE_SOURCE = "CREDIT";
	public static final String ADDRESSREQUIREMENTBRE_TARGET = "ADDRESSREQUIREMENTBRE";
    /**
     * Constant for APLN_KEY.
     */
    public static final String APLN_KEY = "APLN_KEY";
    
    /**
     * Constant for CUST_NAME.
     */
    public static final String CUST_NAME = "CUST_NAME";
    
    /**
     * Constant for LOAN_ACCT_NUM.
     */
    public static final String LOAN_ACCT_NUM = "LOAN_ACCT_NUM";
    
    /**
     * Constant for MOBILE.
     */
    public static final String MOBILEDOC = "MOBILE";
    
    /**
     * Constant for BRANCH.
     */
    public static final String BRANCH = "BRANCH";
    
    /**
     * Constant for BATCH.
     */
    public static final String BATCH = "BATCH";
    
    /**
     * Constant for COURIER.
     */
    public static final String COURIER = "COURIER";
    
    /**
     * Constant for BARCODE.
     */
    public static final String BARCODE = "BARCODE";
 
    
    /**
     * Constant for PROPERTY_ID.
     */
    /*----------Search criteria constants---------*/
    public static final String PROPERTY_ID = "Property ID: ";
	/**
	 * @return the b2bpartnerRole
	 */
	public static String getB2bpartnerRole() {
		return B2BPARTNER_ROLE;
	}


	/**
	 * @return the applicationKeyFieldName
	 */
	public static List<String> getApplicationKeyFieldName() {
		return APPLICATION_KEY_FIELD_NAME;
	}
    
	public static final String FPP = "FPP";
	public static final String NOT_REQUIRED = "notRequired";
	public static final String EP = "EP";
	public static final String JOURNEY = "JOURNEY";
	public static final String APPROVAL_PENDING =  "APPROVAL_PENDING";
	public static final String APPROVED  = 	"APPROVED";
	public static final String REJECTED  = 	"REJECTED";
	public static final String APPLICANT="applicant";
	public static final String LAN="loan account Number";
	public static final String INCOME_OBLIGATION_ADDED = "Income & Obligation added successfully";
	public static final String DOC_VERIFICATION_SUCCESS = "Doc verification flag details saved.";
	public static final Long APPLICANT_KEY = 1L;
	public static final String UNSECURED = "Unsecured";
	
	public static final String IDENTIFIER_TAXID = "TaxId";
	public static final String COMMERCIAL_CIBIL = "COMMERCIALCIBIL";
	public static final String PROVIDER_TRANSUNION = "TRANSUNION";
	
	public static final String SPDC_UPDATE_SUCCESS = "SPDC updated successfully";
	public static final String HLPRODUCTINTENT = "HLPRODUCTINTENT";

	public static final String VERIFIED = "VERIFIED";
	public static final String NOT_VERIFIED = "NOT VERIFIED";

	public static final String APPLICATION_KEY = "APPLICATION_KEY";
	
	public static final String EMANDATE_SENT_SUCCESS = "Emandate Link send successfully";
	public static final String EMANDATE_BANK_MAPPING_FAILURE = "E-mandate is not applicable for this Bank. Please check.";
	public static final String APPLICATION_ID = "APPLICATION_ID";
	public static final String PAN="PAN";
	
	public static final String REPAYMENT_BANK_DETAILS_SOURCE="EP";
	public static final String IDENTIFIER_METHOD_PROP = "identifier.mapper.properties";
	public static final String CTA_FIELD_VALUE_PROP = "cta.fieldcd.mapper.properties";
	public static final String PARENT_CREATED = "PARENT CREATED";
	public static final String DEVIATION_UPDATED = "Deviation details updated";
	public static final String NOT_FOUND = "NOT FOUND";
	
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String ADDR_PREFERRED_FLAG_TRUE="True";
	public static final String ADDR_PREFERRED_FLAG_FALSE="False";
	public static final String UBI_FIELDS_ADDED = "UBI fields saved";
	public static final String UBI_FIELDS_FAILED = "UBI fields failed to be saved";
	
	public static final String BANK_DET_SOURCE_EPCREDIT = "EPCREDIT";
	public static final String MOBILE_NUMBER = "Mobile No";
	public static final Long SELF_EMPLOYED_DOCTOR=9L;
	public static final Long SALARIED_DOCTOR=6L;
	
	public static final Long CA_OCCUPATION_TYPE=7L;
	public static final Long ONE = 1L;
	public static final String ACCEPTED = "ACCEPTED";
	public static final String DISBURSED = "Disbursed";
}
