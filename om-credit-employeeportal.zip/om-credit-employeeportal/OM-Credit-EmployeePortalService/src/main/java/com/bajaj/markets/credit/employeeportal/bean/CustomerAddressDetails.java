package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CustomerAddressDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String customerOfficeAddress;
	private String currentAddress;
	private String permanentAddress;
	private String custCurrentAddressResidenceType;

	public String getCustomerOfficeAddress() {
		return customerOfficeAddress;
	}

	public void setCustomerOfficeAddress(String customerOfficeAddress) {
		this.customerOfficeAddress = customerOfficeAddress;
	}

	public String getCurrentAddress() {
		return currentAddress;
	}

	public void setCurrentAddress(String currentAddress) {
		this.currentAddress = currentAddress;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getCustCurrentAddressResidenceType() {
		return custCurrentAddressResidenceType;
	}

	public void setCustCurrentAddressResidenceType(String custCurrentAddressResidenceType) {
		this.custCurrentAddressResidenceType = custCurrentAddressResidenceType;
	}

}
