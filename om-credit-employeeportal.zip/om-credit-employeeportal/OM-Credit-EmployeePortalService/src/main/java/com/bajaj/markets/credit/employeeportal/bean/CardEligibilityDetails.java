package com.bajaj.markets.credit.employeeportal.bean;

import java.sql.Timestamp;

public class CardEligibilityDetails {
	private String iseligible;

	private String annualfee;

	private String feature;

	private String rewardpoint;

	// replaced with card tag
	// private Integer preapproved;
	private String cardTag;

	private String applsubstagekey;

	private Integer appstagecompletionper;

	private String appstagestatus;

	private String prodkey;

	private String applstagekey;

	private String nullValue;

	private Timestamp lstupdatedt;

	private String offerOfTheMonth;
	
	private String principalETB;

	public String getIseligible() {
		return iseligible;
	}

	public void setIseligible(String iseligible) {
		this.iseligible = iseligible;
	}

	public String getAnnualfee() {
		return annualfee;
	}

	public void setAnnualfee(String annualfee) {
		this.annualfee = annualfee;
	}

	public String getFeature() {
		return feature;
	}

	public void setFeature(String feature) {
		this.feature = feature;
	}

	public String getRewardpoint() {
		return rewardpoint;
	}

	public void setRewardpoint(String rewardpoints) {
		this.rewardpoint = rewardpoints;
	}

	/*
	 * public Integer getPreapproved() { return preapproved; }
	 * 
	 * public void setPreapproved(Integer preapproved) { this.preapproved =
	 * preapproved; }
	 */

	public String getApplsubstagekey() {
		return applsubstagekey;
	}

	public String getCardTag() {
		return cardTag;
	}

	public void setCardTag(String cardTag) {
		this.cardTag = cardTag;
	}

	public void setApplsubstagekey(String applsubstagekey) {
		this.applsubstagekey = applsubstagekey;
	}

	public String getApplstagekey() {
		return applstagekey;
	}

	public void setApplstagekey(String applstagekey) {
		this.applstagekey = applstagekey;
	}

	public String getAppstagestatus() {
		return appstagestatus;
	}

	public void setAppstagestatus(String appstagestatus) {
		this.appstagestatus = appstagestatus;
	}

	public String getProdkey() {
		return prodkey;
	}

	public void setProdkey(String prodkey) {
		this.prodkey = prodkey;
	}

	public Integer getAppstagecompletionper() {
		return appstagecompletionper;
	}

	public void setAppstagecompletionper(Integer appstagecompletionper) {
		this.appstagecompletionper = appstagecompletionper;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;

	}

	public String getOfferOfTheMonth() {
		return offerOfTheMonth;
	}

	public void setOfferOfTheMonth(String offerOfTheMonth) {
		this.offerOfTheMonth = offerOfTheMonth;
	}

	/**
	 * @return the nullValue
	 */
	public String getNullValue() {
		return nullValue;
	}

	/**
	 * @param nullValue the nullValue to set
	 */
	public void setNullValue(String nullValue) {
		this.nullValue = nullValue;
	}

	/**
	 * @return the principalETB
	 */
	public String getPrincipalETB() {
		return principalETB;
	}

	/**
	 * @param principalETB the principalETB to set
	 */
	public void setPrincipalETB(String principalETB) {
		this.principalETB = principalETB;
	}

	

}
