package com.bajaj.markets.credit.employeeportal.bean;

public class Riders {

	private double sumAssured;

    private double premiumAmmount;

    private String riderCode;
    
    private String riderName;

    private String riderKey;

    private int tenure;

	public Riders() {
		super();
	}

	public double getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(double sumAssured) {
		this.sumAssured = sumAssured;
	}

	public double getPremiumAmmount() {
		return premiumAmmount;
	}

	public void setPremiumAmmount(double premiumAmmount) {
		this.premiumAmmount = premiumAmmount;
	}

	public String getRiderCode() {
		return riderCode;
	}

	public void setRiderCode(String riderCode) {
		this.riderCode = riderCode;
	}

	public String getRiderKey() {
		return riderKey;
	}

	public void setRiderKey(String riderKey) {
		this.riderKey = riderKey;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public String getRiderName() {
		return riderName;
	}

	public void setRiderName(String riderName) {
		this.riderName = riderName;
	}

	@Override
	public String toString() {
		return "Riders [sumAssured=" + sumAssured + ", premiumAmmount=" + premiumAmmount + ", riderCode=" + riderCode
				+ ", riderName=" + riderName + ", riderKey=" + riderKey + ", tenure=" + tenure + "]";
	}

}
