package com.bajaj.markets.credit.employeeportal.bean;

public class BureauEnquiryDetails {

	private String segmenttag;

	private String dateofenquiry;

	private String enquiringmembershortname;

	private String enquirypurpose;

	private String enquiryamount;
	
	private String enquirycontrolnumber;
	
	private String bureauName;
	
	private String nullValue;

	/**
	 * @return the segmenttag
	 */
	public String getSegmenttag() {
		return segmenttag;
	}

	/**
	 * @param segmenttag the segmenttag to set
	 */
	public void setSegmenttag(String segmenttag) {
		this.segmenttag = segmenttag;
	}

	/**
	 * @return the dateofenquiry
	 */
	public String getDateofenquiry() {
		return dateofenquiry;
	}

	/**
	 * @param dateofenquiry the dateofenquiry to set
	 */
	public void setDateofenquiry(String dateofenquiry) {
		this.dateofenquiry = dateofenquiry;
	}

	/**
	 * @return the enquirypurpose
	 */
	public String getEnquirypurpose() {
		return enquirypurpose;
	}

	/**
	 * @param enquirypurpose the enquirypurpose to set
	 */
	public void setEnquirypurpose(String enquirypurpose) {
		this.enquirypurpose = enquirypurpose;
	}

	/**
	 * @return the enquiryamount
	 */
	public String getEnquiryamount() {
		return enquiryamount;
	}

	/**
	 * @param enquiryamount the enquiryamount to set
	 */
	public void setEnquiryamount(String enquiryamount) {
		this.enquiryamount = enquiryamount;
	}

	/**
	 * @return the enquiringmembershortname
	 */
	public String getEnquiringmembershortname() {
		return enquiringmembershortname;
	}

	/**
	 * @param enquiringmembershortname the enquiringmembershortname to set
	 */
	public void setEnquiringmembershortname(String enquiringmembershortname) {
		this.enquiringmembershortname = enquiringmembershortname;
	}

	/**
	 * @return the enquirycontrolnumber
	 */
	public String getEnquirycontrolnumber() {
		return enquirycontrolnumber;
	}

	/**
	 * @param enquirycontrolnumber the enquirycontrolnumber to set
	 */
	public void setEnquirycontrolnumber(String enquirycontrolnumber) {
		this.enquirycontrolnumber = enquirycontrolnumber;
	}

	/**
	 * @return the bureauName
	 */
	public String getBureauName() {
		return bureauName;
	}

	/**
	 * @param bureauName the bureauName to set
	 */
	public void setBureauName(String bureauName) {
		this.bureauName = bureauName;
	}

	/**
	 * @return the nullValue
	 */
	public String getNullValue() {
		return nullValue;
	}

	/**
	 * @param nullValue the nullValue to set
	 */
	public void setNullValue(String nullValue) {
		this.nullValue = nullValue;
	}

	
}
