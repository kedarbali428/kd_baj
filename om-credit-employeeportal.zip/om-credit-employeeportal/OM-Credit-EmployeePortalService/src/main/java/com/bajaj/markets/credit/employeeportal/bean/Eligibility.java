package com.bajaj.markets.credit.employeeportal.bean;

public class Eligibility {

	private String eligibleProductVarient;
	private String eligibilityType;
	private Integer eligibilityAmount;
	private Integer eligibleTenor;
	private String riskOfferType;
	private String productType;
	private String producVarient;

	public String getEligibleProductVarient() {
		return eligibleProductVarient;
	}

	public void setEligibleProductVarient(String eligibleProductVarient) {
		this.eligibleProductVarient = eligibleProductVarient;
	}

	public String getEligibilityType() {
		return eligibilityType;
	}

	public void setEligibilityType(String eligibilityType) {
		this.eligibilityType = eligibilityType;
	}

	public Integer getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(Integer eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	public Integer getEligibleTenor() {
		return eligibleTenor;
	}

	public void setEligibleTenor(Integer eligibleTenor) {
		this.eligibleTenor = eligibleTenor;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProducVarient() {
		return producVarient;
	}

	public void setProducVarient(String producVarient) {
		this.producVarient = producVarient;
	}

}