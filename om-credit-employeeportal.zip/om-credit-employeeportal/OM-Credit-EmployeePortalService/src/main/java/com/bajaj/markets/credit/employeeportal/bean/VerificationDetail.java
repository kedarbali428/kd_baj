package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class VerificationDetail implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String permenentAddressRequired;
	private String officeAddressRequired;
	private String docPickUpAtOffice;
	private String docPickUpAtResidence;
	private String updatedBy;
	private Timestamp updatedDatetime;
	private String videoPDRequired;
	public String getPermenentAddressRequired() {
		return permenentAddressRequired;
	}
	public void setPermenentAddressRequired(String permenentAddressRequired) {
		this.permenentAddressRequired = permenentAddressRequired;
	}
	public String getOfficeAddressRequired() {
		return officeAddressRequired;
	}
	public void setOfficeAddressRequired(String officeAddressRequired) {
		this.officeAddressRequired = officeAddressRequired;
	}
	public String getDocPickUpAtOffice() {
		return docPickUpAtOffice;
	}
	public void setDocPickUpAtOffice(String docPickUpAtOffice) {
		this.docPickUpAtOffice = docPickUpAtOffice;
	}
	public String getDocPickUpAtResidence() {
		return docPickUpAtResidence;
	}
	public void setDocPickUpAtResidence(String docPickUpAtResidence) {
		this.docPickUpAtResidence = docPickUpAtResidence;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Timestamp getUpdatedDatetime() {
		return updatedDatetime;
	}
	public void setUpdatedDatetime(Timestamp updatedDatetime) {
		this.updatedDatetime = updatedDatetime;
	}
	public String getVideoPDRequired() {
		return videoPDRequired;
	}
	public void setVideoPDRequired(String videoPDRequired) {
		this.videoPDRequired = videoPDRequired;
	}
}
