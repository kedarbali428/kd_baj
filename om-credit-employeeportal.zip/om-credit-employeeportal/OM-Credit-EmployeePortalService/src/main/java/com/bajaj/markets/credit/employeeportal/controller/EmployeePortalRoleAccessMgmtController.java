package com.bajaj.markets.credit.employeeportal.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.CloneRoleAccessConfigureBean;
import com.bajaj.markets.credit.employeeportal.bean.RoleAccessConfigurationInputBean;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.helper.ResponseBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalRoleAccessMgmtService;
import com.bajaj.markets.credit.employeeportal.service.RoleAccessCloneService;
import com.bajaj.markets.credit.employeeportal.service.RoleAccessUpdateService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import net.bytebuddy.build.Plugin.Engine.Summary;

@RestController
public class EmployeePortalRoleAccessMgmtController {
	private static final String CLASSNAME = EmployeePortalRoleAccessMgmtController.class.getName();
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	EmployeePortalRoleAccessMgmtService employeePortalRoleAccessMgmtService;
	@Autowired
	RoleAccessUpdateService roleAccessUpdateService;
	@Autowired
	RoleAccessCloneService roleAccessCloneService;

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch product categories", notes = "Fetch product categories on the basis of prodMastKey", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Product Categories fetched", response = Summary.class),
			@ApiResponse(code = 404, message = "Product categories fetch failed", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/domain/credit/productMasters/{productMastKey}/productCategories", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUserMgmtProductCategories(@PathVariable("productMastKey") String prodMastKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getUserMgmtProductCategories method controller - parameter: " + prodMastKey);
		return new ResponseEntity<>(employeePortalRoleAccessMgmtService.fetchProductCategories(prodMastKey),
				HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch products", notes = "Fetch products on the basis of prodMastKey and prodCatKey", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Products fetched", response = Summary.class),
			@ApiResponse(code = 404, message = "Products fetch failed", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/domain/credit/productMasters/{productMastKey}/productCategories/{prodCatKey}/products", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUserMgmtProducts(@PathVariable("productMastKey") String prodMastKey,
			@PathVariable("prodCatKey") String prodCatKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getUserMgmtProducts method controller - parameter: " + prodMastKey);
		return new ResponseEntity<>(employeePortalRoleAccessMgmtService.fetchProducts(prodMastKey, prodCatKey),
				HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch functions", notes = "Fetch functions on the basis of search criteria", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Functions fetched", response = Summary.class),
			@ApiResponse(code = 404, message = "Function fetch failed", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/domain/credit/productMasters/{productMastKey}/functions", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUserMgmtFunctions(@PathVariable("productMastKey") String prodMastKey,
			final HttpServletRequest request, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getUserMgmtFunctions method controller - parameter: " + prodMastKey);
		String prodCd = request.getParameter("product");
		String prodCategory = request.getParameter("productCategory");
		return new ResponseEntity<>(
				employeePortalRoleAccessMgmtService.fetchFunctions(prodMastKey, prodCd, prodCategory), HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch tabs", notes = "Fetch tabs on the basis of product", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Tabs fetched", response = Summary.class),
			@ApiResponse(code = 404, message = "Tabs fetch failed", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/domain/credit/productMasters/{productMastKey}/tabs", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUserMgmtTabs(@PathVariable("productMastKey") String prodMastKey,
			final HttpServletRequest request, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getUserMgmtFunctions method controller - parameter: " + prodMastKey);
		String prodCd = request.getParameter("product");
		String roleKeys = request.getParameter("roleKeys");
		List<Long> roleKeyList = null != roleKeys && !roleKeys.isEmpty() ? Arrays.asList(roleKeys.split(",")).stream()
				.map(String::trim).map(Long::valueOf).collect(Collectors.toList()) : new ArrayList<>();
		return new ResponseEntity<>(employeePortalRoleAccessMgmtService.fetchTabKey(prodMastKey, prodCd, roleKeyList),
				HttpStatus.OK);
	}

	// @Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch fields", notes = "Fetch fields on the basis of search criteria", httpMethod = "GET")
//				@ApiImplicitParams({
//				    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
//				  })

	@ApiResponses(value = { @ApiResponse(code = 200, message = "fields fetched", response = Summary.class),
			@ApiResponse(code = 404, message = "fields fetch failed", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/domain/credit/productMasters/{productMastKey}/tabs/fields/configuration", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUserMgmtTabFields(@PathVariable("productMastKey") String prodMastKey,
			final HttpServletRequest request, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Start fetching field details for input :" + prodMastKey);
		String prodKey = request.getParameter("product");
		String tabKeys = request.getParameter("tabKeys");
		List<Long> tabKeyList = null != tabKeys && !tabKeys.isEmpty() ? Arrays.asList(tabKeys.split(",")).stream()
				.map(String::trim).map(Long::valueOf).collect(Collectors.toList()) : new ArrayList<>();
		String roleKeys = request.getParameter("roleKeys");
		List<Long> roleKeyList = null != roleKeys && !roleKeys.isEmpty() ? Arrays.asList(roleKeys.split(",")).stream()
				.map(String::trim).map(Long::valueOf).collect(Collectors.toList()) : new ArrayList<>();
		String groupKeys = request.getParameter("groupKeys");
		String sectionKeys = request.getParameter("sectionKeys");
		String subSectionKeys = request.getParameter("subSectionKeys");
		List<Long> reqGroupKeys = null != groupKeys && !groupKeys.isEmpty() ? Arrays.asList(groupKeys.split(","))
				.stream().map(String::trim).map(Long::valueOf).collect(Collectors.toList()) : new ArrayList<>();
		List<Long> reqSectionKeys = null != sectionKeys && !sectionKeys.isEmpty()
				? Arrays.asList(sectionKeys.split(",")).stream().map(String::trim).map(Long::valueOf).collect(
						Collectors.toList())
				: new ArrayList<>();
		List<Long> reqSubsectionKeys = null != subSectionKeys && !subSectionKeys.isEmpty()
				? Arrays.asList(subSectionKeys.split(",")).stream().map(String::trim).map(Long::valueOf).collect(
						Collectors.toList())
				: new ArrayList<>();
						
		String editFlag = request.getParameter("editFlag");
		// , List<Long> reqGroupKeys, List<Long> reqSectionKeys, List<Long>
		// reqSubsectionKeys,
		return new ResponseEntity<>(employeePortalRoleAccessMgmtService.fetchGroupRoleAccessConfiguration(
				Long.valueOf(prodMastKey), Long.valueOf(prodKey), tabKeyList, roleKeyList, reqGroupKeys, reqSectionKeys,
				reqSubsectionKeys, true, null != editFlag && !editFlag.isEmpty()), HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch CTA", notes = "Fetch CTA on the basis of tabKey", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })

	@ApiResponses(value = { @ApiResponse(code = 200, message = "CTA fetched", response = Summary.class),
			@ApiResponse(code = 404, message = "Function fetch failed", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/domain/credit/productMasters/{productMastKey}/tabs/{tabkey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUserMgmtTabCTA(@PathVariable("productMastKey") String prodMastKey,
			@PathVariable("tabkey") String tabKey, final HttpServletRequest request,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getUserMgmtTabCTA method controller - parameter: " + prodMastKey);
		String prodCd = request.getParameter("product");
		String prodCategory = request.getParameter("productCategory");
		return new ResponseEntity<>(
				employeePortalRoleAccessMgmtService.fetchTabKeyCTA(prodMastKey, prodCd, prodCategory, tabKey),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Get The Group, Section and sub Section details.", notes = "Get The Group, Section and sub Section details.", httpMethod = "GET")
	// @ApiImplicitParam(name = "cmptcorrid",required = true,dataType =
	// "string",paramType = "header")
	@GetMapping(value = "/v1/domain/credit/{productMastKey}/tabs/groups/configuration", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> fetchAllGroupSectionAndSubSectionDetailsBasedonL3(
			@PathVariable("productMastKey") String prodMastKey, final HttpServletRequest request,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Start fetching groups, section and sub section details for input :" + prodMastKey);
		String prodKey = request.getParameter("product");
		String tabKey = request.getParameter("tabKey");
		List<Long> tabKeyList = new ArrayList<>();
		tabKeyList.add(Long.valueOf(tabKey));
		String roleKeys = request.getParameter("roleKeys");
		List<Long> roleKeyList = Arrays.asList(roleKeys.split(",")).stream().map(String::trim).map(Long::valueOf)
				.collect(Collectors.toList());
		String editFlag = request.getParameter("editFlag");
		
		return new ResponseEntity<>(
				employeePortalRoleAccessMgmtService.fetchGroupRoleAccessConfiguration(Long.valueOf(prodMastKey),
						Long.valueOf(prodKey), tabKeyList, roleKeyList, null, null, null, false, null != editFlag && !editFlag.isEmpty()),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Get The CTA details.", notes = "Get The CTA details.", httpMethod = "GET")
	// @ApiImplicitParam(name = "cmptcorrid",required = true,dataType =
	// "string",paramType = "header")
	@GetMapping(value = "/v1/domain/credit/{productMastKey}/tabs/cta/configuration", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> fetchAllCTADetailsBasedonL3(@PathVariable("productMastKey") String prodMastKey,
			final HttpServletRequest request, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start fetching CTA details for input :" + prodMastKey);
		String prodKey = request.getParameter("product");
		String tabKeys = request.getParameter("tabKeys");
		List<Long> tabKeyList = Arrays.asList(tabKeys.split(",")).stream().map(String::trim).map(Long::valueOf)
				.collect(Collectors.toList());
		String roleKeys = request.getParameter("roleKeys");
		List<Long> roleKeyList = Arrays.asList(roleKeys.split(",")).stream().map(String::trim).map(Long::valueOf)
				.collect(Collectors.toList());
		return new ResponseEntity<>(employeePortalRoleAccessMgmtService.fetchCTARoleAccessConfiguration(
				Long.valueOf(prodMastKey), Long.valueOf(prodKey), tabKeyList, roleKeyList), HttpStatus.OK);
	}

	@ApiOperation(value = "Get The tab link details.", notes = "Get The tab link details.", httpMethod = "POST")
	// @ApiImplicitParam(name = "cmptcorrid",required = true,dataType =
	// "string",paramType = "header")
	@GetMapping(value = "/v1/domain/credit/tabs/links/configuration", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> fetchAllLinksWithRole(final HttpServletRequest request,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start fetching Link details for input :");
		String tabKeys = request.getParameter("tabKeys");
		List<Long> tabKeyList = Arrays.asList(tabKeys.split(",")).stream().map(String::trim).map(Long::valueOf)
				.collect(Collectors.toList());
		String roleKeys = request.getParameter("roleKeys");
		List<Long> roleKeyList = Arrays.asList(roleKeys.split(",")).stream().map(String::trim).map(Long::valueOf)
				.collect(Collectors.toList());
		return new ResponseEntity<>(
				employeePortalRoleAccessMgmtService.fetchLinkRoleAccessConfiguration(tabKeyList, roleKeyList),
				HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch tabs", notes = "Fetch tabs on the basis of role", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Tabs fetched", response = Summary.class),
			@ApiResponse(code = 404, message = "Tabs fetch failed", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/domain/credit/{rolekey}/tabs", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getLoginRoleTabs(@PathVariable("rolekey") String roleKey, final HttpServletRequest request,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getUserMgmtFunctions method controller - parameter: " + roleKey);
		return new ResponseEntity<>(employeePortalRoleAccessMgmtService.fetchTabByRole(Long.valueOf(roleKey)),
				HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Update Role Access configuration.", notes = "Update Role Access configuration.", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Role Access configuration updated successfully", response = Summary.class),
			@ApiResponse(code = 404, message = "Role Access configuration failed", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/domain/credit/roleaccess/configuration", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateRoleAccess(@RequestBody RoleAccessConfigurationInputBean roleAccessBean,
			@RequestHeader HttpHeaders headers) {
		boolean successFlag = false;
		try {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Start Role Access configuration :" + roleAccessBean);
			successFlag = roleAccessUpdateService.saveRoleAccessConfiguration(roleAccessBean);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Role Access configuration Successful" + roleAccessBean);
		} catch (CreditEmployeePortalServiceException exception) {
			throw exception;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Technical Exception occured while saving Role Access Configuration", e);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("", ""));
		}
		return new ResponseEntity<>(successFlag, HttpStatus.OK);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Clone the role aceces from one role to another.", notes = "Clone the role aceces from one role to another.", httpMethod = "POST")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Role Access configuration cloned successfully", response = Summary.class),
			@ApiResponse(code = 404, message = "Role Access configuration cloning failed", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/domain/credit/clone/roleaccess/configuration", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> cloneRoleAccessConfiguration(@RequestBody CloneRoleAccessConfigureBean cloneRoleAccessConfigBean,
			@RequestHeader HttpHeaders headers)  {
	
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "RoleManagementController : clone service role mgmnt Service execution invoked");
		boolean successFlag = false;
		try {	
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside cloneRoleAccessConfiguration() method of EmployeePortalRoleAccessMgmtController");
			
			successFlag = roleAccessCloneService.cloneRoleAccessConfiguration(cloneRoleAccessConfigBean);
			
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "EmployeePortalRoleAccessMgmtController : Service call execution completed");	
		} 
		catch (CreditEmployeePortalServiceException exception) {
			throw exception;
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Exception occured while cloning Role Access Configuration : " + exception);
			throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR, 
					new ErrorBean("OMCA_0135","Technical Exception occured while cloning Role Access Configuration"));
		}
			
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Exit from cloneRoleAccessConfiguration() method of EmployeePortalRoleAccessMgmtController");
		return new ResponseEntity<>(new ResponseBean("SUCCESS"), HttpStatus.OK);
	}
}