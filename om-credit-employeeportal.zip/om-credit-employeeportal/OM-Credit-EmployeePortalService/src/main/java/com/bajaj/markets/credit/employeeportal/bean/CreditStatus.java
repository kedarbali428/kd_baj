package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class CreditStatus implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String creditDisbursementStatus;
	
	private String creditEligibilityStatus;
	
	private String approvalStatus;
	
	@JsonIgnore
	private boolean created;
	
	private String rejectCode;
	
	private String individualCoapplicantRequired;
	
	private String entityCoapplicantRequired;

	public String getCreditDisbursementStatus() {
		return creditDisbursementStatus;
	}

	public void setCreditDisbursementStatus(String creditDisbursementStatus) {
		this.creditDisbursementStatus = creditDisbursementStatus;
	}

	public String getCreditEligibilityStatus() {
		return creditEligibilityStatus;
	}

	public void setCreditEligibilityStatus(String creditEligibilityStatus) {
		this.creditEligibilityStatus = creditEligibilityStatus;
	}
	public boolean isCreated() {
		return created;
	}

	public void setCreated(boolean created) {
		this.created = created;
	}
	
	public String getRejectCode() {
		return rejectCode;
	}

	public void setRejectCode(String rejectCode) {
		this.rejectCode = rejectCode;
	}
	
	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public String getIndividualCoapplicantRequired() {
		return individualCoapplicantRequired;
	}

	public void setIndividualCoapplicantRequired(String individualCoapplicantRequired) {
		this.individualCoapplicantRequired = individualCoapplicantRequired;
	}

	public String getEntityCoapplicantRequired() {
		return entityCoapplicantRequired;
	}

	public void setEntityCoapplicantRequired(String entityCoapplicantRequired) {
		this.entityCoapplicantRequired = entityCoapplicantRequired;
	}

	@Override
	public String toString() {
		return "CreditStatus [creditDisbursementStatus=" + creditDisbursementStatus + ", creditEligibilityStatus="
				+ creditEligibilityStatus + "]";
	}
	
}