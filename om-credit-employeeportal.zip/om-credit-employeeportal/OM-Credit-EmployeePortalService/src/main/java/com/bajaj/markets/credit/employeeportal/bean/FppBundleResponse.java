package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.util.List;

public class FppBundleResponse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3155332019475315571L;
	private Long applicationId;
	private Long l3ProductKey;
	private String l3ProductCode;
	private List<OpenArcFppOutput> openArcFppOutput;
	private String gender;
	private Name name;
	private Long mobileNumber;
    private String dateOfBirth;
    
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public Long getL3ProductKey() {
		return l3ProductKey;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public void setL3ProductKey(Long l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public List<OpenArcFppOutput> getOpenArcFppOutput() {
		return openArcFppOutput;
	}

	public void setOpenArcFppOutput(List<OpenArcFppOutput> openArcFppOutput) {
		this.openArcFppOutput = openArcFppOutput;
	}

}
