package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class LeadPushDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String productName;
	private String principalKey;
	private String principalReferenceId1;
	private String principalReferenceId2;
	private String principalReferenceId3;
	private String principalReferenceId4;
	private String statusMessage;
	private String statusCode;
	private String statusCode2;
	private String failureDescription;
	private Integer leadPushCount;
	private Integer statusApiCount;
	private String substatusMessage;
	private String substatusCode;
	private String rejectionReason;
	private Timestamp dateAndTimeStamp;
	private String leadPushInitiatedBy;
	private String statusCode1Description;

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(String principalKey) {
		this.principalKey = principalKey;
	}

	public String getPrincipalReferenceId1() {
		return principalReferenceId1;
	}

	public void setPrincipalReferenceId1(String principalReferenceId1) {
		this.principalReferenceId1 = principalReferenceId1;
	}

	public String getPrincipalReferenceId2() {
		return principalReferenceId2;
	}

	public void setPrincipalReferenceId2(String principalReferenceId2) {
		this.principalReferenceId2 = principalReferenceId2;
	}

	public String getPrincipalReferenceId3() {
		return principalReferenceId3;
	}

	public void setPrincipalReferenceId3(String principalReferenceId3) {
		this.principalReferenceId3 = principalReferenceId3;
	}

	public String getPrincipalReferenceId4() {
		return principalReferenceId4;
	}

	public void setPrincipalReferenceId4(String principalReferenceId4) {
		this.principalReferenceId4 = principalReferenceId4;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusCode2() {
		return statusCode2;
	}

	public void setStatusCode2(String statusCode2) {
		this.statusCode2 = statusCode2;
	}

	public String getFailureDescription() {
		return failureDescription;
	}

	public void setFailureDescription(String failureDescription) {
		this.failureDescription = failureDescription;
	}

	public Integer getLeadPushCount() {
		return leadPushCount;
	}

	public void setLeadPushCount(Integer leadPushCount) {
		this.leadPushCount = leadPushCount;
	}

	public Integer getStatusApiCount() {
		return statusApiCount;
	}

	public void setStatusApiCount(Integer statusApiCount) {
		this.statusApiCount = statusApiCount;
	}

	public String getSubstatusMessage() {
		return substatusMessage;
	}

	public void setSubstatusMessage(String substatusMessage) {
		this.substatusMessage = substatusMessage;
	}

	public String getSubstatusCode() {
		return substatusCode;
	}

	public void setSubstatusCode(String substatusCode) {
		this.substatusCode = substatusCode;
	}

	public String getRejectionReason() {
		return rejectionReason;
	}

	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}

	public Timestamp getDateAndTimeStamp() {
		return dateAndTimeStamp;
	}

	public void setDateAndTimeStamp(Timestamp dateAndTimeStamp) {
		this.dateAndTimeStamp = dateAndTimeStamp;
	}

	public String getLeadPushInitiatedBy() {
		return leadPushInitiatedBy;
	}

	public void setLeadPushInitiatedBy(String leadPushInitiatedBy) {
		this.leadPushInitiatedBy = leadPushInitiatedBy;
	}

	public String getStatusCode1Description() {
		return statusCode1Description;
	}

	public void setStatusCode1Description(String statusCode1Description) {
		this.statusCode1Description = statusCode1Description;
	}

}