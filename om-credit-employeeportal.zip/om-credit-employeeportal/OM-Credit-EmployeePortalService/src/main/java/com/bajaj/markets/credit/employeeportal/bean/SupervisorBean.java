package com.bajaj.markets.credit.employeeportal.bean;

public class SupervisorBean {

	private Long id;
	private String name;
	private boolean highestRole;
	private Long userRoleProdKey;
	private Long userRoleKey;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isHighestRole() {
		return highestRole;
	}

	public void setHighestRole(boolean highestRole) {
		this.highestRole = highestRole;
	}

	public Long getUserRoleProdKey() {
		return userRoleProdKey;
	}

	public void setUserRoleProdKey(Long userRoleProdKey) {
		this.userRoleProdKey = userRoleProdKey;
	}

	public Long getUserRoleKey() {
		return userRoleKey;
	}

	public void setUserRoleKey(Long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}

}
