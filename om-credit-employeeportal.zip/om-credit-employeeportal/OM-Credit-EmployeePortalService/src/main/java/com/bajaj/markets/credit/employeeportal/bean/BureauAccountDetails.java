package com.bajaj.markets.credit.employeeportal.bean;

/**
 * Application Bureau Details resource 
 * @author Deepak Ray
 * 
 */
public class BureauAccountDetails {	 
	
private Long cbacctkey; 

private String accountnumber;

private String accounttype;

private String dateopenedordisbursed;

private String datelastpayment;

private String dateclosed;

private String datereportedandcert;

private String daysPastDue;

private String currentbalance;

private String amountoverdue;

private String paymenthistory1;

private String paymenthistory2;

private String paymenthistorystartdate;

private String paymenthistoryenddate;

private String creditlimit;

private String cashlimit;

private String rateofinterest;

private String repaymenttenure;

private String emiamount;

private String writtenoffamounttotal;

private String writtenoffamtprincipal;

private String settlementamount;

private String SanctionedLoanAmt;

private String paymentfrequency;

private String actualpaymentamount;

private String dateforerrorcode;

private String errorcode;

private String dateforcibilremarkcd;

private String cibilremarkcode;

private String dateforerrorordisputecd;

private String forerrorordisputecode1;

private String forerrorordisputecode2;

private String reportingshortname;

private String segmenttag;

private String ownershipindicator;

private String suitfieldwilfuldefault;

private String writtenoffandsettledst;

private String valueofcollateral;

private String typeofcollateral;

private String highcreditsanctionamt;

private String nullValue;

/**
 * @return the cbacctkey
 */
public Long getCbacctkey() {
	return cbacctkey;
}

/**
 * @param cbacctkey the cbacctkey to set
 */
public void setCbacctkey(Long cbacctkey) {
	this.cbacctkey = cbacctkey;
}

/**
 * @return the accountnumber
 */
public String getAccountnumber() {
	return accountnumber;
}

/**
 * @param accountnumber the accountnumber to set
 */
public void setAccountnumber(String accountnumber) {
	this.accountnumber = accountnumber;
}

/**
 * @return the accounttype
 */
public String getAccounttype() {
	return accounttype;
}

/**
 * @param accounttype the accounttype to set
 */
public void setAccounttype(String accounttype) {
	this.accounttype = accounttype;
}

/**
 * @return the dateopenedordisbursed
 */
public String getDateopenedordisbursed() {
	return dateopenedordisbursed;
}

/**
 * @param dateopenedordisbursed the dateopenedordisbursed to set
 */
public void setDateopenedordisbursed(String dateopenedordisbursed) {
	this.dateopenedordisbursed = dateopenedordisbursed;
}

/**
 * @return the datelastpayment
 */
public String getDatelastpayment() {
	return datelastpayment;
}

/**
 * @param datelastpayment the datelastpayment to set
 */
public void setDatelastpayment(String datelastpayment) {
	this.datelastpayment = datelastpayment;
}

/**
 * @return the dateclosed
 */
public String getDateclosed() {
	return dateclosed;
}

/**
 * @param dateclosed the dateclosed to set
 */
public void setDateclosed(String dateclosed) {
	this.dateclosed = dateclosed;
}

/**
 * @return the datereportedandcert
 */
public String getDatereportedandcert() {
	return datereportedandcert;
}

/**
 * @param datereportedandcert the datereportedandcert to set
 */
public void setDatereportedandcert(String datereportedandcert) {
	this.datereportedandcert = datereportedandcert;
}

/**
 * @return the currentbalance
 */
public String getCurrentbalance() {
	return currentbalance;
}

/**
 * @param currentbalance the currentbalance to set
 */
public void setCurrentbalance(String currentbalance) {
	this.currentbalance = currentbalance;
}

/**
 * @return the amountoverdue
 */
public String getAmountoverdue() {
	return amountoverdue;
}

/**
 * @param amountoverdue the amountoverdue to set
 */
public void setAmountoverdue(String amountoverdue) {
	this.amountoverdue = amountoverdue;
}

/**
 * @return the paymenthistory1
 */
public String getPaymenthistory1() {
	return paymenthistory1;
}

/**
 * @param paymenthistory1 the paymenthistory1 to set
 */
public void setPaymenthistory1(String paymenthistory1) {
	this.paymenthistory1 = paymenthistory1;
}

/**
 * @return the paymenthistory2
 */
public String getPaymenthistory2() {
	return paymenthistory2;
}

/**
 * @param paymenthistory2 the paymenthistory2 to set
 */
public void setPaymenthistory2(String paymenthistory2) {
	this.paymenthistory2 = paymenthistory2;
}

/**
 * @return the paymenthistorystartdate
 */
public String getPaymenthistorystartdate() {
	return paymenthistorystartdate;
}

/**
 * @param paymenthistorystartdate the paymenthistorystartdate to set
 */
public void setPaymenthistorystartdate(String paymenthistorystartdate) {
	this.paymenthistorystartdate = paymenthistorystartdate;
}

/**
 * @return the paymenthistoryenddate
 */
public String getPaymenthistoryenddate() {
	return paymenthistoryenddate;
}

/**
 * @param paymenthistoryenddate the paymenthistoryenddate to set
 */
public void setPaymenthistoryenddate(String paymenthistoryenddate) {
	this.paymenthistoryenddate = paymenthistoryenddate;
}

/**
 * @return the creditlimit
 */
public String getCreditlimit() {
	return creditlimit;
}

/**
 * @param creditlimit the creditlimit to set
 */
public void setCreditlimit(String creditlimit) {
	this.creditlimit = creditlimit;
}

/**
 * @return the cashlimit
 */
public String getCashlimit() {
	return cashlimit;
}

/**
 * @param cashlimit the cashlimit to set
 */
public void setCashlimit(String cashlimit) {
	this.cashlimit = cashlimit;
}

/**
 * @return the rateofinterest
 */
public String getRateofinterest() {
	return rateofinterest;
}

/**
 * @param rateofinterest the rateofinterest to set
 */
public void setRateofinterest(String rateofinterest) {
	this.rateofinterest = rateofinterest;
}

/**
 * @return the repaymenttenure
 */
public String getRepaymenttenure() {
	return repaymenttenure;
}

/**
 * @param repaymenttenure the repaymenttenure to set
 */
public void setRepaymenttenure(String repaymenttenure) {
	this.repaymenttenure = repaymenttenure;
}

/**
 * @return the emiamount
 */
public String getEmiamount() {
	return emiamount;
}

/**
 * @param emiamount the emiamount to set
 */
public void setEmiamount(String emiamount) {
	this.emiamount = emiamount;
}

/**
 * @return the writtenoffamounttotal
 */
public String getWrittenoffamounttotal() {
	return writtenoffamounttotal;
}

/**
 * @param writtenoffamounttotal the writtenoffamounttotal to set
 */
public void setWrittenoffamounttotal(String writtenoffamounttotal) {
	this.writtenoffamounttotal = writtenoffamounttotal;
}

/**
 * @return the writtenoffamtprincipal
 */
public String getWrittenoffamtprincipal() {
	return writtenoffamtprincipal;
}

/**
 * @param writtenoffamtprincipal the writtenoffamtprincipal to set
 */
public void setWrittenoffamtprincipal(String writtenoffamtprincipal) {
	this.writtenoffamtprincipal = writtenoffamtprincipal;
}

/**
 * @return the settlementamount
 */
public String getSettlementamount() {
	return settlementamount;
}

/**
 * @param settlementamount the settlementamount to set
 */
public void setSettlementamount(String settlementamount) {
	this.settlementamount = settlementamount;
}

/**
 * @return the paymentfrequency
 */
public String getPaymentfrequency() {
	return paymentfrequency;
}

/**
 * @param paymentfrequency the paymentfrequency to set
 */
public void setPaymentfrequency(String paymentfrequency) {
	this.paymentfrequency = paymentfrequency;
}

/**
 * @return the actualpaymentamount
 */
public String getActualpaymentamount() {
	return actualpaymentamount;
}

/**
 * @param actualpaymentamount the actualpaymentamount to set
 */
public void setActualpaymentamount(String actualpaymentamount) {
	this.actualpaymentamount = actualpaymentamount;
}

/**
 * @return the dateforerrorcode
 */
public String getDateforerrorcode() {
	return dateforerrorcode;
}

/**
 * @param dateforerrorcode the dateforerrorcode to set
 */
public void setDateforerrorcode(String dateforerrorcode) {
	this.dateforerrorcode = dateforerrorcode;
}

/**
 * @return the errorcode
 */
public String getErrorcode() {
	return errorcode;
}

/**
 * @param errorcode the errorcode to set
 */
public void setErrorcode(String errorcode) {
	this.errorcode = errorcode;
}

/**
 * @return the dateforcibilremarkcd
 */
public String getDateforcibilremarkcd() {
	return dateforcibilremarkcd;
}

/**
 * @param dateforcibilremarkcd the dateforcibilremarkcd to set
 */
public void setDateforcibilremarkcd(String dateforcibilremarkcd) {
	this.dateforcibilremarkcd = dateforcibilremarkcd;
}

/**
 * @return the cibilremarkcode
 */
public String getCibilremarkcode() {
	return cibilremarkcode;
}

/**
 * @param cibilremarkcode the cibilremarkcode to set
 */
public void setCibilremarkcode(String cibilremarkcode) {
	this.cibilremarkcode = cibilremarkcode;
}

/**
 * @return the dateforerrorordisputecd
 */
public String getDateforerrorordisputecd() {
	return dateforerrorordisputecd;
}

/**
 * @param dateforerrorordisputecd the dateforerrorordisputecd to set
 */
public void setDateforerrorordisputecd(String dateforerrorordisputecd) {
	this.dateforerrorordisputecd = dateforerrorordisputecd;
}

/**
 * @return the forerrorordisputecode1
 */
public String getForerrorordisputecode1() {
	return forerrorordisputecode1;
}

/**
 * @param forerrorordisputecode1 the forerrorordisputecode1 to set
 */
public void setForerrorordisputecode1(String forerrorordisputecode1) {
	this.forerrorordisputecode1 = forerrorordisputecode1;
}

/**
 * @return the forerrorordisputecode2
 */
public String getForerrorordisputecode2() {
	return forerrorordisputecode2;
}

/**
 * @param forerrorordisputecode2 the forerrorordisputecode2 to set
 */
public void setForerrorordisputecode2(String forerrorordisputecode2) {
	this.forerrorordisputecode2 = forerrorordisputecode2;
}

/**
 * @return the reportingshortname
 */
public String getReportingshortname() {
	return reportingshortname;
}

/**
 * @param reportingshortname the reportingshortname to set
 */
public void setReportingshortname(String reportingshortname) {
	this.reportingshortname = reportingshortname;
}

/**
 * @return the segmenttag
 */
public String getSegmenttag() {
	return segmenttag;
}

/**
 * @param segmenttag the segmenttag to set
 */
public void setSegmenttag(String segmenttag) {
	this.segmenttag = segmenttag;
}

/**
 * @return the ownershipindicator
 */
public String getOwnershipindicator() {
	return ownershipindicator;
}

/**
 * @param ownershipindicator the ownershipindicator to set
 */
public void setOwnershipindicator(String ownershipindicator) {
	this.ownershipindicator = ownershipindicator;
}

/**
 * @return the suitfieldwilfuldefault
 */
public String getSuitfieldwilfuldefault() {
	return suitfieldwilfuldefault;
}

/**
 * @param suitfieldwilfuldefault the suitfieldwilfuldefault to set
 */
public void setSuitfieldwilfuldefault(String suitfieldwilfuldefault) {
	this.suitfieldwilfuldefault = suitfieldwilfuldefault;
}

/**
 * @return the writtenoffandsettledst
 */
public String getWrittenoffandsettledst() {
	return writtenoffandsettledst;
}

/**
 * @param writtenoffandsettledst the writtenoffandsettledst to set
 */
public void setWrittenoffandsettledst(String writtenoffandsettledst) {
	this.writtenoffandsettledst = writtenoffandsettledst;
}

/**
 * @return the valueofcollateral
 */
public String getValueofcollateral() {
	return valueofcollateral;
}

/**
 * @param valueofcollateral the valueofcollateral to set
 */
public void setValueofcollateral(String valueofcollateral) {
	this.valueofcollateral = valueofcollateral;
}

/**
 * @return the typeofcollateral
 */
public String getTypeofcollateral() {
	return typeofcollateral;
}

/**
 * @param typeofcollateral the typeofcollateral to set
 */
public void setTypeofcollateral(String typeofcollateral) {
	this.typeofcollateral = typeofcollateral;
}

/**
 * @return the highcreditsanctionamt
 */
public String getHighcreditsanctionamt() {
	return highcreditsanctionamt;
}

/**
 * @param highcreditsanctionamt the highcreditsanctionamt to set
 */
public void setHighcreditsanctionamt(String highcreditsanctionamt) {
	this.highcreditsanctionamt = highcreditsanctionamt;
}

/**
 * @return the daysPastDue
 */
public String getDaysPastDue() {
	return daysPastDue;
}

/**
 * @param daysPastDue the daysPastDue to set
 */
public void setDaysPastDue(String daysPastDue) {
	this.daysPastDue = daysPastDue;
}

/**
 * @return the sanctionedLoanAmt
 */
public String getSanctionedLoanAmt() {
	return SanctionedLoanAmt;
}

/**
 * @param sanctionedLoanAmt the sanctionedLoanAmt to set
 */
public void setSanctionedLoanAmt(String sanctionedLoanAmt) {
	SanctionedLoanAmt = sanctionedLoanAmt;
}

/**
 * @return the nullValue
 */
public String getNullValue() {
	return nullValue;
}

/**
 * @param nullValue the nullValue to set
 */
public void setNullValue(String nullValue) {
	this.nullValue = nullValue;
}

}
