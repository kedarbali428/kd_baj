package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class AuditApplicantDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String motherName;

	private String fatherName;
	
	private String maritalStatusKey;

	private String genderKey;
	
	private String firstName;
	
	private String middleName;
	
	private String lastName;

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	
	public String getMaritalStatusKey() {
		return maritalStatusKey;
	}

	public void setMaritalStatusKey(String maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}

	public String getGenderKey() {
		return genderKey;
	}

	public void setGenderKey(String genderKey) {
		this.genderKey = genderKey;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
}
