package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the OFFER_DETAILS database table.
 * 
 */
@Entity
@Table(name = "app_offer_det", schema = "dmcredit")
public class AppOfferDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long appofferdetkey;

	private long prodkey;

	private long applicationkey;

	private BigDecimal offeramt;

	private String offerid;

	private Timestamp offerexpirydt;

	private String offertypecode;

	private Integer isactive;

	private String riskoffertype;

	private String isofferavailable;

	private Float offerroi;

	private String partnerofferid;

	private String prospectid;

	private Integer offeracceptsts;

	private String risksegment;

	private String generationrule;

	private String offergenerationsource;

	private Integer offersrckey;
	
	private Integer offerpriority;
	
	private String riskclassification;
	
	 private Integer offertype;
	 
	 private String offerprogramcode;

	public AppOfferDet() {
	}

	/**
	 * @return the appofferdetkey
	 */
	public long getAppofferdetkey() {
		return appofferdetkey;
	}

	/**
	 * @param appofferdetkey the appofferdetkey to set
	 */
	public void setAppofferdetkey(long appofferdetkey) {
		this.appofferdetkey = appofferdetkey;
	}

	/**
	 * @return the prodkey
	 */
	public long getProdkey() {
		return prodkey;
	}

	/**
	 * @param prodkey the prodkey to set
	 */
	public void setProdkey(long prodkey) {
		this.prodkey = prodkey;
	}

	/**
	 * @return the applicationkey
	 */
	public long getApplicationkey() {
		return applicationkey;
	}

	/**
	 * @param applicationkey the applicationkey to set
	 */
	public void setApplicationkey(long applicationkey) {
		this.applicationkey = applicationkey;
	}

	/**
	 * @return the offerid
	 */
	public String getOfferid() {
		return offerid;
	}

	/**
	 * @param offerid the offerid to set
	 */
	public void setOfferid(String offerid) {
		this.offerid = offerid;
	}

	/**
	 * @return the offerexpirydt
	 */
	public Timestamp getOfferexpirydt() {
		return offerexpirydt;
	}

	/**
	 * @param offerexpirydt the offerexpirydt to set
	 */
	public void setOfferexpirydt(Timestamp offerexpirydt) {
		this.offerexpirydt = offerexpirydt;
	}

	/**
	 * @return the offertypecode
	 */
	public String getOffertypecode() {
		return offertypecode;
	}

	/**
	 * @param offertypecode the offertypecode to set
	 */
	public void setOffertypecode(String offertypecode) {
		this.offertypecode = offertypecode;
	}

	/**
	 * @return the isactive
	 */
	public Integer getIsactive() {
		return isactive;
	}

	/**
	 * @param isactive the isactive to set
	 */
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	/**
	 * @return the riskoffertype
	 */
	public String getRiskoffertype() {
		return riskoffertype;
	}

	/**
	 * @param riskoffertype the riskoffertype to set
	 */
	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}

	/**
	 * @return the offeramt
	 */
	public BigDecimal getOfferamt() {
		return offeramt;
	}

	/**
	 * @param offeramt the offeramt to set
	 */
	public void setOfferamt(BigDecimal offeramt) {
		this.offeramt = offeramt;
	}

	public String getIsofferavailable() {
		return isofferavailable;
	}

	public void setIsofferavailable(String isofferavailable) {
		this.isofferavailable = isofferavailable;
	}

	public Float getOfferroi() {
		return offerroi;
	}

	public void setOfferroi(Float offerroi) {
		this.offerroi = offerroi;
	}

	public String getPartnerofferid() {
		return partnerofferid;
	}

	public void setPartnerofferid(String partnerofferid) {
		this.partnerofferid = partnerofferid;
	}

	public String getProspectid() {
		return prospectid;
	}

	public void setProspectid(String prospectid) {
		this.prospectid = prospectid;
	}

	public Integer getOfferacceptsts() {
		return offeracceptsts;
	}

	public void setOfferacceptsts(Integer offeracceptsts) {
		this.offeracceptsts = offeracceptsts;
	}

	public String getRisksegment() {
		return risksegment;
	}

	public void setRisksegment(String risksegment) {
		this.risksegment = risksegment;
	}

	public String getGenerationrule() {
		return generationrule;
	}

	public void setGenerationrule(String generationrule) {
		this.generationrule = generationrule;
	}

	public String getOffergenerationsource() {
		return offergenerationsource;
	}

	public void setOffergenerationsource(String offergenerationsource) {
		this.offergenerationsource = offergenerationsource;
	}

	public Integer getOffersrckey() {
		return offersrckey;
	}

	public void setOffersrckey(Integer offersrckey) {
		this.offersrckey = offersrckey;
	}

	public Integer getOfferpriority() {
		return offerpriority;
	}

	public void setOfferpriority(Integer offerpriority) {
		this.offerpriority = offerpriority;
	}
	
	public String getRiskclassification() {
		return riskclassification;
	}

	public void setRiskclassification(String riskclassification) {
		this.riskclassification = riskclassification;
	}
	public Integer getOffertype() {
		return offertype;
	}

	public void setOffertype(Integer offertype) {
		this.offertype = offertype;
	}
	
	public String getOfferprogramcode() {
		return offerprogramcode;
	}

	public void setOfferprogramcode(String offerprogramcode) {
		this.offerprogramcode = offerprogramcode;
	}
}