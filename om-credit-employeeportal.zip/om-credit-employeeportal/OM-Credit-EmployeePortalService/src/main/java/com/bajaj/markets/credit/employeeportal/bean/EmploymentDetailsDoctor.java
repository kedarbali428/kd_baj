package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

public class EmploymentDetailsDoctor {

	private String qualification;
	private String specialisation;
	private BigDecimal yearOfPostGraduation;
	private BigDecimal yearOfGraduation;
	private String medicalRegistrationNumber;
	private String stateMedicalCouncil;
	private String professionType;
	private String hospitalName;
	private String degreeCategory;
	private String totalExperience;
	
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getSpecialisation() {
		return specialisation;
	}
	public void setSpecialisation(String specialisation) {
		this.specialisation = specialisation;
	}
	public BigDecimal getYearOfPostGraduation() {
		return yearOfPostGraduation;
	}
	public void setYearOfPostGraduation(BigDecimal yearOfPostGraduation) {
		this.yearOfPostGraduation = yearOfPostGraduation;
	}
	public BigDecimal getYearOfGraduation() {
		return yearOfGraduation;
	}
	public void setYearOfGraduation(BigDecimal yearOfGraduation) {
		this.yearOfGraduation = yearOfGraduation;
	}
	public String getMedicalRegistrationNumber() {
		return medicalRegistrationNumber;
	}
	public void setMedicalRegistrationNumber(String medicalRegistrationNumber) {
		this.medicalRegistrationNumber = medicalRegistrationNumber;
	}
	public String getStateMedicalCouncil() {
		return stateMedicalCouncil;
	}
	public void setStateMedicalCouncil(String stateMedicalCouncil) {
		this.stateMedicalCouncil = stateMedicalCouncil;
	}
	public String getProfessionType() {
		return professionType;
	}
	public void setProfessionType(String professionType) {
		this.professionType = professionType;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getDegreeCategory() {
		return degreeCategory;
	}
	public void setDegreeCategory(String degreeCategory) {
		this.degreeCategory = degreeCategory;
	}
	public String getTotalExperience() {
		return totalExperience;
	}
	public void setTotalExperience(String totalExperience) {
		this.totalExperience = totalExperience;
	}
	
}
