package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_disbursment_tracking", schema = "dmcredit")
public class AppDisbursmentTracking implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long appdisbursmenttrackkey;
	private Long apptranchedetkey;
	private String status; 
	private String disbursmentstage;
	private String error;
	private Integer errorretryable;
	private String errorreason;
	private Integer isactive;
	private String lstupdateby;
	private Timestamp lstupdatedt;
	public Long getAppdisbursmenttrackkey() {
		return appdisbursmenttrackkey;
	}
	public void setAppdisbursmenttrackkey(Long appdisbursmenttrackkey) {
		this.appdisbursmenttrackkey = appdisbursmenttrackkey;
	}
	public Long getApptranchedetkey() {
		return apptranchedetkey;
	}
	public void setApptranchedetkey(Long apptranchedetkey) {
		this.apptranchedetkey = apptranchedetkey;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDisbursmentstage() {
		return disbursmentstage;
	}
	public void setDisbursmentstage(String disbursmentstage) {
		this.disbursmentstage = disbursmentstage;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public Integer getErrorretryable() {
		return errorretryable;
	}
	public void setErrorretryable(Integer errorretryable) {
		this.errorretryable = errorretryable;
	}
	public String getErrorreason() {
		return errorreason;
	}
	public void setErrorreason(String errorreason) {
		this.errorreason = errorreason;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	public String getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
}
