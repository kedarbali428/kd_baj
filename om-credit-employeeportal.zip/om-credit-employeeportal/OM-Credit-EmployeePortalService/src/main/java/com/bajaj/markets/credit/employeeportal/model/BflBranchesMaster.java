package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="bfl_branches", schema="dmmaster")
public class BflBranchesMaster implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long bflbranchkey;
	
	private String bflbranchcode;
	
	private Long citykey;
	
	@JsonIgnore
	private Integer bflbranchisactive;
	
	private String bflbranchname;

	public Long getBflbranchkey() {
		return bflbranchkey;
	}

	public void setBflbranchkey(Long bflbranchkey) {
		this.bflbranchkey = bflbranchkey;
	}

	public String getBflbranchcode() {
		return bflbranchcode;
	}

	public void setBflbranchcode(String bflbranchcode) {
		this.bflbranchcode = bflbranchcode;
	}

	public Long getCitykey() {
		return citykey;
	}

	public void setCitykey(Long citykey) {
		this.citykey = citykey;
	}

	public Integer getBflbranchisactive() {
		return bflbranchisactive;
	}

	public void setBflbranchisactive(Integer bflbranchisactive) {
		this.bflbranchisactive = bflbranchisactive;
	}

	public String getBflbranchname() {
		return bflbranchname;
	}

	public void setBflbranchname(String bflbranchname) {
		this.bflbranchname = bflbranchname;
	}
	
}