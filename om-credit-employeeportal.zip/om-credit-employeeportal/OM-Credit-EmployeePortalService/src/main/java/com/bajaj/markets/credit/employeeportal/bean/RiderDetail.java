package com.bajaj.markets.credit.employeeportal.bean;

public class RiderDetail {

	private String riderKey;
	private String riderCode;
	private String riderDescription;
	private String riderUserFriendlyName;
	public String getRiderKey() {
		return riderKey;
	}
	public void setRiderKey(String riderKey) {
		this.riderKey = riderKey;
	}
	public String getRiderCode() {
		return riderCode;
	}
	public void setRiderCode(String riderCode) {
		this.riderCode = riderCode;
	}
	public String getRiderDescription() {
		return riderDescription;
	}
	public void setRiderDescription(String riderDescription) {
		this.riderDescription = riderDescription;
	}
	public String getRiderUserFriendlyName() {
		return riderUserFriendlyName;
	}
	public void setRiderUserFriendlyName(String riderUserFriendlyName) {
		this.riderUserFriendlyName = riderUserFriendlyName;
	}
	
}
