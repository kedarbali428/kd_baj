package com.bajaj.markets.credit.employeeportal.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MonthwiseDetails {
    private String avgBalance;
    
    private String month;
    
	public String getAvgBalance() {
		return avgBalance;
	}
	public void setAvgBalance(String avgBalance) {
		this.avgBalance = avgBalance;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	

}