package com.bajaj.markets.credit.employeeportal.bean;

public class CityMasterBean {
	private Long citykey;
	private Long statekey;
	private String citycode;
	private String cityname;

	public Long getCitykey() {
		return citykey;
	}

	public void setCitykey(Long citykey) {
		this.citykey = citykey;
	}

	public Long getStatekey() {
		return statekey;
	}

	public void setStatekey(Long statekey) {
		this.statekey = statekey;
	}

	public String getCitycode() {
		return citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

}
