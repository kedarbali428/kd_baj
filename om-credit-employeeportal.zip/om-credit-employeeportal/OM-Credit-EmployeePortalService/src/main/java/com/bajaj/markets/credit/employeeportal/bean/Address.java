package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

public class Address implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String addressKey;
	@NotBlank(message = "addressTypeKey can not be null")
	private String addressTypeKey;
	private String resiType;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;	
	private String pincode;
	@NotBlank(message = "pincodeKey can not be null")
	private String pincodeKey;
	private String cityKey;
	private String cityName;
	private String stateKey;
	private String stateName;
	private String countryKey;
	private String source;
	private String latitude;
	private String addressSource;
	private String localitykey;
	private String localityCd;
	private Integer cardDeliveryAddress;
	private String residenceType;
	private String addressSourceStatus;
	private String preferredAddress;
	private String documentName;
	private String documentValue;
	private String documentCategory;
	public String getAddressKey() {
		return addressKey;
	}
	public void setAddressKey(String addressKey) {
		this.addressKey = addressKey;
	}
	public String getAddressTypeKey() {
		return addressTypeKey;
	}
	public void setAddressTypeKey(String addressTypeKey) {
		this.addressTypeKey = addressTypeKey;
	}
	public String getResiType() {
		return resiType;
	}
	public void setResiType(String resiType) {
		this.resiType = resiType;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getPincodeKey() {
		return pincodeKey;
	}
	public void setPincodeKey(String pincodeKey) {
		this.pincodeKey = pincodeKey;
	}
	public String getCityKey() {
		return cityKey;
	}
	public void setCityKey(String cityKey) {
		this.cityKey = cityKey;
	}
	public String getStateKey() {
		return stateKey;
	}
	public void setStateKey(String stateKey) {
		this.stateKey = stateKey;
	}
	public String getCountryKey() {
		return countryKey;
	}
	public void setCountryKey(String countryKey) {
		this.countryKey = countryKey;
	}
	
	public String getAddressSource() {
		return addressSource;
	}
	public void setAddressSource(String addressSource) {
		this.addressSource = addressSource;
	}
	/**
	 * @return the addressLine3
	 */
	public String getAddressLine3() {
		return addressLine3;
	}
	/**
	 * @param addressLine3 the addressLine3 to set
	 */
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}
	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}
	public String getLocalitykey() {
		return localitykey;
	}
	public void setLocalitykey(String localitykey) {
		this.localitykey = localitykey;
	}
	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}
	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	/**
	 * @return the stateName
	 */
	public String getStateName() {
		return stateName;
	}
	/**
	 * @param stateName the stateName to set
	 */
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	/**
	 * @return the latitude
	 */
	public String getLatitude() {
		return latitude;
	}
	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public Integer getCardDeliveryAddress() {
		return cardDeliveryAddress;
	}

	public void setCardDeliveryAddress(Integer cardDeliveryAddress) {
		this.cardDeliveryAddress = cardDeliveryAddress;
	}
	/**
	 * @return the localityCd
	 */
	public String getLocalityCd() {
		return localityCd;
	}
	/**
	 * @param localityCd the localityCd to set
	 */
	public void setLocalityCd(String localityCd) {
		this.localityCd = localityCd;
	}

	public String getResidenceType() {
		return residenceType;
	}

	public void setResidenceType(String residenceType) {
		this.residenceType = residenceType;
	}
	public String getAddressSourceStatus() {
		return addressSourceStatus;
	}
	public void setAddressSourceStatus(String addressSourceStatus) {
		this.addressSourceStatus = addressSourceStatus;
	}
	public String getPreferredAddress() {
		return preferredAddress;
	}
	public void setPreferredAddress(String preferredAddress) {
		this.preferredAddress = preferredAddress;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentValue() {
		return documentValue;
	}
	public void setDocumentValue(String documentValue) {
		this.documentValue = documentValue;
	}
	public String getDocumentCategory() {
		return documentCategory;
	}
	public void setDocumentCategory(String documentCategory) {
		this.documentCategory = documentCategory;
	}
}
