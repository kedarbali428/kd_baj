package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class AppDeviationBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
    
	@NotNull
	private Integer deviationcodeKey;
	
	private Long prodKey;

	public Integer getDeviationcodeKey() {
		return deviationcodeKey;
	}

	public void setDeviationcodeKey(Integer deviationcodeKey) {
		this.deviationcodeKey = deviationcodeKey;
	}

	public Long getProdKey() {
		return prodKey;
	}

	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}

	@Override
	public String toString() {
		return "AppDeviationBean [deviationcodeKey=" + deviationcodeKey + ", prodKey=" + prodKey + "]";
	}
}

