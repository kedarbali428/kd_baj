package com.bajaj.markets.credit.employeeportal.customannotation;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.employeeportal.bean.AuthUserBean;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.model.Application;
import com.bajaj.markets.credit.employeeportal.model.CtaProduct;
import com.bajaj.markets.credit.employeeportal.model.CtaRole;
import com.bajaj.markets.credit.employeeportal.model.CtaSetMaster;
import com.bajaj.markets.credit.employeeportal.model.CtaType;
import com.bajaj.markets.credit.employeeportal.model.ProductCategory;
import com.bajaj.markets.credit.employeeportal.model.RoleProductMapping;
import com.bajaj.markets.credit.employeeportal.repository.ApplicationRepository;
import com.bajaj.markets.credit.employeeportal.repository.CTAProductRepository;
import com.bajaj.markets.credit.employeeportal.repository.CTARoleRepository;
import com.bajaj.markets.credit.employeeportal.repository.CTASetMasterRepository;
import com.bajaj.markets.credit.employeeportal.repository.CTATypesRepository;
import com.bajaj.markets.credit.employeeportal.repository.ProductCategoryRepository;
import com.bajaj.markets.credit.employeeportal.repository.RoleProdMappingRepository;
import com.bajaj.markets.credit.employeeportal.repository.UserRolesRepository;
import com.bajaj.markets.credit.employeeportal.util.EmployeePortalUtil;

/**
 * @author Deepak Ray
 * 
 *         Perform cta access check on requested object.
 *
 */
@Aspect
@Configuration
public class CTARoleAccessCheck {
	@Value("${openmarket.isfinegrain.validation.required}")
	private boolean isFineGrainRequired;


	@Value("#{'${applicationservice.finegrain.skip.roles}'.split(',')}")
	private List<String> skipFineGrainRoles;
	


	@Autowired
	BFLLoggerUtilExt logger;
	private static final String CLASSNAME = CTARoleAccessCheck.class.getName();
	
	@Autowired
	CTATypesRepository ctaTypesRepository;
	
	@Autowired
	CTAProductRepository ctaProductRepository;
	
	@Autowired
	CTARoleRepository ctaRoleRepository;
	
	@Autowired
	ApplicationRepository applicationRepository;
	
	@Autowired
	ProductCategoryRepository productCategoryRepository;
	
	@Autowired
	RoleProdMappingRepository roleProdMappingRepository;
	
	@Autowired
	UserRolesRepository userRolesRepository;
	
	@Autowired
	CTASetMasterRepository ctaSetMasterRepository;

	/**
	 * Perform role access check on cta
	 * 
	 * @param joinPoint
	 */
	@Before("@annotation(com.bajaj.markets.credit.employeeportal.customannotation.EnableCTARoleAccessCheck)")
	public void fineGrainCheck(JoinPoint joinPoint) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "fineGrainCheck Started.");
		AuthUserBean authUserBean =EmployeePortalUtil.getAuthUserInfo();
		 if(null != authUserBean && skipFineGrainRoles.contains(authUserBean.getRole()) && !EmployeePortalConstants.B2BPARTNER_ROLE.equals(authUserBean.getRole())) {
				String ctaCode = validateRqstMethodAndfieldType(joinPoint, authUserBean, EmployeePortalConstants.getCtaKeyFieldName());
				String applicationId = validateRqstMethodAndfieldType(joinPoint, authUserBean, EmployeePortalConstants.getApplicationKeyFieldName());
				if(null != ctaCode && null != applicationId && validateRoleAccessForCTA(ctaCode, applicationId, authUserBean)) {
					//Do nothing - valid cta and role
				}else {
					// throw exception when token don't have additional info
					throwFineGrainException();
				}
		} else {
			// throw exception when token don't have additional info
			throwFineGrainException();
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "fineGrainCheck End.");
	}

	
	private Boolean validateRoleAccessForCTA(String ctaCode, String applicationId, AuthUserBean authUserBean) {
		CtaRole ctaRole = null;
		Long ctaSetcd=null;
		try {
		Application applicationDetail = applicationRepository.findByApplicationkeyAndIsactive(Long.valueOf(applicationId), 1);
		ProductCategory productCategory = productCategoryRepository
				.findByprodcatkeyAndIsactive(applicationDetail.getProdcdl2(), 1);
		   if(null != productCategory) {
				if(productCategory.getProdcatcode().equalsIgnoreCase("CC"))
					ctaSetcd=11l;
				else if(productCategory.getProdcatcode().equalsIgnoreCase("OMPL"))
					ctaSetcd=12l;
				else if(productCategory.getProdcatcode().equalsIgnoreCase("OMSL"))
					ctaSetcd=13l;
			}
		    CtaSetMaster ctaSetMaster =ctaSetMasterRepository.findByCtasetcdAndIsactive(ctaSetcd, 1);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside applicationDetail not null : ");
			CtaType ctaType = ctaTypesRepository.findByCtacodeAndCtaSetMaster_CtasetkeyAndIsactive(Integer.valueOf(ctaCode),ctaSetMaster.getCtasetkey(), 1);
			
		Long loggedInUserRoleKey = null != authUserBean.getUserId() && null != authUserBean.getUserRoleKey() ?
				userRolesRepository.findByUserrolekeyAndUserkeyAndIsactive(Long.valueOf(authUserBean.getUserRoleKey()), Long.valueOf(authUserBean.getUserId()), 1) : null;
		RoleProductMapping roleProdMapping = roleProdMappingRepository.findByProdmastkeyAndSubprodkeyAndRolekeyAndIsactive(productCategory.getProdmastkey(), applicationDetail.getProdcdl2(), Integer.valueOf(loggedInUserRoleKey.toString()),1);
		CtaProduct ctaProduct = ctaProductRepository.findByCtakeyAndProdmastkeyAndSubprodtypekeyAndIsactive(ctaType.getCtakey(), productCategory.getProdmastkey(), applicationDetail.getProdcdl2(), 1);
		ctaRole= ctaRoleRepository.findByCtaprodkeyAndRoleprodkeyAndIsactive(ctaProduct.getCtaprodkey(), Integer.valueOf(roleProdMapping.getRoleprodkey().toString()),1);
	
		
		
	} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
						"No CT code found in request : " + e);
			}
		return null != ctaRole;
	}


	/**
	 * @param joinPoint
	 * @param authUserBean
	 * @return 
	 * Extract the application id received in request param or path variable
	 * or directly in method arguments. Compare the method name available in
	 * requested controller and extract the application key by comparing the
	 * argument of that method.
	 */
	public String validateRqstMethodAndfieldType(JoinPoint joinPoint, AuthUserBean authUserBean, List<String> fieldTypes) {
		String reqField = null;
		Object[] inputArgArray = joinPoint.getArgs();
		String methodName = joinPoint.getSignature().getName();
		Method[] methods = joinPoint.getTarget().getClass().getDeclaredMethods();
		for (Method method : methods) {
			if (StringUtils.equals(methodName, method.getName())) {
				Parameter[] parameters = method.getParameters();
				for (int i = 0; i < parameters.length; i++) {
					if (parameters[i].isNamePresent()) {
						String paramName = parameters[i].getName();
						if (fieldTypes.contains(paramName)) {
							reqField = String.valueOf(inputArgArray[i]);
							// break inner loop once application key is found.
							break;
						}
					}
				}
				// break the outer loop once we find the requested method from all the
				// method available in particular class.
				break;
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
				"reqField after method arg check : " + reqField);
		
	
		if (null == reqField) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"FineGrain validation Failed.");
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND,
					new ErrorBean("CAS-1023", "Resource Not Found."));
		}
		return reqField;
	}

	
	
	/**
	 * 
	 */
	private void throwFineGrainException() {
		logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
				"Role CTA access validation Failed.");
		throw new CreditEmployeePortalServiceException(HttpStatus.FORBIDDEN,
				new ErrorBean("CEPS-1001", "User does not have access to this CTA"));
	}

	

}
