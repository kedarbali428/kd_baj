package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class AddressReqInput {
	private String city;
	private String applicationId;
	private String l2Product;
	private String l3Product;
	private String l4Product;
	private Integer subStagePercentage;
	private String currentResidenceType;
	private Integer age;
	private String companyType;
	private String perfiosDetails;
	private ExistingCustomerDetails existingCustomerDetails;
	private List<BureauAddressPinCode> bureauAddressPinCodeList;
	private Boolean oglFlag;
	private Integer customerEnteredPincode;
	private String creditVidyaOutput;
	private Boolean existingHlCustomerFlag;
	private Boolean existingPlCustomerWithMobFlag;
	private Boolean existingCdCustomerFlag;
	private String pan;
	private String analyticsCibilDerog;
	private String companyCategory;
	private String maritalStatus;
	private List<PerfiosEmailDetails> officialEmailIdVerification;
	private List<OfferDetailsList> offerDetailsList;
	private String customerSegmentation;
	private Integer cibilScore;
	private Boolean wantMoreFlag;
	private String programCode;
	private Integer migrationCibilScore;
	private Integer userSelectedSalaryCount;
	private Integer perfiosSelectedSalaryCount;
	private String customerProfileSegment;
	private String microSegment;
	private String journeyStamp;
	private String employerClassification;
	private Integer requiredLoanAmount;
	
	private List<PerfiosSalaryDetails>perfiosTransactionList;

	public Integer getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	public void setRequiredLoanAmount(Integer requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	public String getEmployerClassification() {
		return employerClassification;
	}

	public void setEmployerClassification(String employerClassification) {
		this.employerClassification = employerClassification;
	}
	
	public String getJourneyStamp() {
		return journeyStamp;
	}

	public void setJourneyStamp(String journeyStamp) {
		this.journeyStamp = journeyStamp;
	}

	public String getCustomerProfileSegment() {
		return customerProfileSegment;
	}

	public void setCustomerProfileSegment(String customerProfileSegment) {
		this.customerProfileSegment = customerProfileSegment;
	}

	public String getMicroSegment() {
		return microSegment;
	}

	public void setMicroSegment(String microSegment) {
		this.microSegment = microSegment;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the applicationId
	 */
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * @return the l2Product
	 */
	public String getL2Product() {
		return l2Product;
	}

	/**
	 * @param l2Product the l2Product to set
	 */
	public void setL2Product(String l2Product) {
		this.l2Product = l2Product;
	}

	/**
	 * @return the l3Product
	 */
	public String getL3Product() {
		return l3Product;
	}

	/**
	 * @param l3Product the l3Product to set
	 */
	public void setL3Product(String l3Product) {
		this.l3Product = l3Product;
	}

	/**
	 * @return the l4Product
	 */
	public String getL4Product() {
		return l4Product;
	}

	/**
	 * @param l4Product the l4Product to set
	 */
	public void setL4Product(String l4Product) {
		this.l4Product = l4Product;
	}

	/**
	 * @return the subStagePercentage
	 */
	public Integer getSubStagePercentage() {
		return subStagePercentage;
	}

	/**
	 * @param subStagePercentage the subStagePercentage to set
	 */
	public void setSubStagePercentage(Integer subStagePercentage) {
		this.subStagePercentage = subStagePercentage;
	}

	/**
	 * @return the currentResidenceType
	 */
	public String getCurrentResidenceType() {
		return currentResidenceType;
	}

	/**
	 * @param currentResidenceType the currentResidenceType to set
	 */
	public void setCurrentResidenceType(String currentResidenceType) {
		this.currentResidenceType = currentResidenceType;
	}

	/**
	 * @return the age
	 */
	public Integer getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(Integer age) {
		this.age = age;
	}

	/**
	 * @return the companyType
	 */
	public String getCompanyType() {
		return companyType;
	}

	/**
	 * @param companyType the companyType to set
	 */
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	/**
	 * @return the perfiosDetails
	 */
	public String getPerfiosDetails() {
		return perfiosDetails;
	}

	/**
	 * @param perfiosDetails the perfiosDetails to set
	 */
	public void setPerfiosDetails(String perfiosDetails) {
		this.perfiosDetails = perfiosDetails;
	}

	/**
	 * @return the existingCustDetails
	 */

	public List<BureauAddressPinCode> getBureauAddressPinCodeList() {
		return bureauAddressPinCodeList;
	}

	public ExistingCustomerDetails getExistingCustomerDetails() {
		return existingCustomerDetails;
	}

	public void setExistingCustomerDetails(ExistingCustomerDetails existingCustomerDetails) {
		this.existingCustomerDetails = existingCustomerDetails;
	}

	public void setBureauAddressPinCodeList(List<BureauAddressPinCode> bureauAddressPinCodeList) {
		this.bureauAddressPinCodeList = bureauAddressPinCodeList;
	}

	public Boolean getOglFlag() {
		return oglFlag;
	}

	public void setOglFlag(Boolean oglFlag) {
		this.oglFlag = oglFlag;
	}

	public Integer getCustomerEnteredPincode() {
		return customerEnteredPincode;
	}

	public void setCustomerEnteredPincode(Integer customerEnteredPincode) {
		this.customerEnteredPincode = customerEnteredPincode;
	}

	/**
	 * @return the creditVidyaOutput
	 */
	public String getCreditVidyaOutput() {
		return creditVidyaOutput;
	}

	/**
	 * @param creditVidyaOutput the creditVidyaOutput to set
	 */
	public void setCreditVidyaOutput(String creditVidyaOutput) {
		this.creditVidyaOutput = creditVidyaOutput;
	}

	/**
	 * @return the existingHlCustomerFlag
	 */
	public Boolean getExistingHlCustomerFlag() {
		return existingHlCustomerFlag;
	}

	/**
	 * @param existingHlCustomerFlag the existingHlCustomerFlag to set
	 */
	public void setExistingHlCustomerFlag(Boolean existingHlCustomerFlag) {
		this.existingHlCustomerFlag = existingHlCustomerFlag;
	}

	/**
	 * @return the existingPlCustomerWithMobFlag
	 */
	public Boolean getExistingPlCustomerWithMobFlag() {
		return existingPlCustomerWithMobFlag;
	}

	/**
	 * @param existingPlCustomerWithMobFlag the existingPlCustomerWithMobFlag to set
	 */
	public void setExistingPlCustomerWithMobFlag(Boolean existingPlCustomerWithMobFlag) {
		this.existingPlCustomerWithMobFlag = existingPlCustomerWithMobFlag;
	}

	/**
	 * @return the existingCdCustomerFlag
	 */
	public Boolean getExistingCdCustomerFlag() {
		return existingCdCustomerFlag;
	}

	/**
	 * @param existingCdCustomerFlag the existingCdCustomerFlag to set
	 */
	public void setExistingCdCustomerFlag(Boolean existingCdCustomerFlag) {
		this.existingCdCustomerFlag = existingCdCustomerFlag;
	}

	/**
	 * @return the pan
	 */
	public String getPan() {
		return pan;
	}

	/**
	 * @param pan the pan to set
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}

	/**
	 * @return the analyticsCibilDerog
	 */
	public String getAnalyticsCibilDerog() {
		return analyticsCibilDerog;
	}

	/**
	 * @param analyticsCibilDerog the analyticsCibilDerog to set
	 */
	public void setAnalyticsCibilDerog(String analyticsCibilDerog) {
		this.analyticsCibilDerog = analyticsCibilDerog;
	}

	/**
	 * @return the companyCategory
	 */
	public String getCompanyCategory() {
		return companyCategory;
	}

	/**
	 * @param companyCategory the companyCategory to set
	 */
	public void setCompanyCategory(String companyCategory) {
		this.companyCategory = companyCategory;
	}

	/**
	 * @return the maritalStatus
	 */
	public String getMaritalStatus() {
		return maritalStatus;
	}

	/**
	 * @param maritalStatus the maritalStatus to set
	 */
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	/**
	 * @return the customerSegmentation
	 */
	public String getCustomerSegmentation() {
		return customerSegmentation;
	}

	/**
	 * @param customerSegmentation the customerSegmentation to set
	 */
	public void setCustomerSegmentation(String customerSegmentation) {
		this.customerSegmentation = customerSegmentation;
	}
	
	public Integer getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(Integer cibilScore) {
		this.cibilScore = cibilScore;
	}

	/**
	 * @return the wantMoreFlag
	 */
	public Boolean getWantMoreFlag() {
		return wantMoreFlag;
	}

	/**
	 * @param wantMoreFlag the wantMoreFlag to set
	 */
	public void setWantMoreFlag(Boolean wantMoreFlag) {
		this.wantMoreFlag = wantMoreFlag;
	}

	/**
	 * @return the programCode
	 */
	public String getProgramCode() {
		return programCode;
	}

	/**
	 * @param programCode the programCode to set
	 */
	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	/**
	 * @return the migrationCibilScore
	 */
	public Integer getMigrationCibilScore() {
		return migrationCibilScore;
	}

	/**
	 * @param migrationCibilScore the migrationCibilScore to set
	 */
	public void setMigrationCibilScore(Integer migrationCibilScore) {
		this.migrationCibilScore = migrationCibilScore;
	}

	public List<PerfiosEmailDetails> getOfficialEmailIdVerification() {
		return officialEmailIdVerification;
	}

	public void setOfficialEmailIdVerification(List<PerfiosEmailDetails> officialEmailIdVerification) {
		this.officialEmailIdVerification = officialEmailIdVerification;
	}

	public List<OfferDetailsList> getOfferDetailsList() {
		return offerDetailsList;
	}

	public void setOfferDetailsList(List<OfferDetailsList> offerDetailsList) {
		this.offerDetailsList = offerDetailsList;
	}

	public Integer getUserSelectedSalaryCount() {
		return userSelectedSalaryCount;
	}

	public void setUserSelectedSalaryCount(Integer userSelectedSalaryCount) {
		this.userSelectedSalaryCount = userSelectedSalaryCount;
	}

	public Integer getPerfiosSelectedSalaryCount() {
		return perfiosSelectedSalaryCount;
	}

	public void setPerfiosSelectedSalaryCount(Integer perfiosSelectedSalaryCount) {
		this.perfiosSelectedSalaryCount = perfiosSelectedSalaryCount;
	}

    public List<PerfiosSalaryDetails> getPerfiosTransactionList() {
        return perfiosTransactionList;
    }

    public void setPerfiosTransactionList(List<PerfiosSalaryDetails> perfiosTransactionList) {
        this.perfiosTransactionList = perfiosTransactionList;
    }

    
	
}