package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the rejection_code database table.
 * 
 */
@Entity
@Table(name = "bfsd_functions", schema = "dmmaster")
public class BFSDFunctions implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer functionkey;

	private Integer functioncd;

	private String functiondesc;

	private Integer isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	/**
	 * @return the functionkey
	 */
	public Integer getFunctionkey() {
		return functionkey;
	}

	/**
	 * @param functionkey the functionkey to set
	 */
	public void setFunctionkey(Integer functionkey) {
		this.functionkey = functionkey;
	}

	/**
	 * @return the functioncd
	 */
	public Integer getFunctioncd() {
		return functioncd;
	}

	/**
	 * @param functioncd the functioncd to set
	 */
	public void setFunctioncd(Integer functioncd) {
		this.functioncd = functioncd;
	}

	/**
	 * @return the functiondesc
	 */
	public String getFunctiondesc() {
		return functiondesc;
	}

	/**
	 * @param functiondesc the functiondesc to set
	 */
	public void setFunctiondesc(String functiondesc) {
		this.functiondesc = functiondesc;
	}

	/**
	 * @return the isactive
	 */
	public Integer getIsactive() {
		return isactive;
	}

	/**
	 * @param isactive the isactive to set
	 */
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	/**
	 * @return the lstupdateby
	 */
	public String getLstupdateby() {
		return lstupdateby;
	}

	/**
	 * @param lstupdateby the lstupdateby to set
	 */
	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	/**
	 * @return the lstupdatedt
	 */
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	/**
	 * @param lstupdatedt the lstupdatedt to set
	 */
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}


}