package com.bajaj.markets.credit.employeeportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.AppAuditRequest;
import com.bajaj.markets.credit.employeeportal.bean.AuditDetails;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.model.AppAuditDetail;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalAuditDetailsService;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalUpdateAuditDetailsService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Kajal Korde
 * Controller for AuditDetails
 */
@RestController
public class EmployeePortalAuditDetailsController {
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private EmployeePortalAuditDetailsService employeePortalAuditDetailsService;
	
	@Autowired
	private EmployeePortalUpdateAuditDetailsService employeePortalUpdateAuditDetailsService;
	
	private static final String CLASSNAME = EmployeePortalAuditDetailsController.class.getName();
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Get Application details for audit", notes = "Get Application details for audit", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application subsection field details", response = AuditDetails.class),
			@ApiResponse(code = 404, message = "Stage subsection field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/ctacodes/{ctacode}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationDetailsForAudit(@PathVariable("applicationid") String applicationId,
			@PathVariable("ctacode") Integer identifier,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In getApplicationAuditDetailsField method with applicationId :" +applicationId+ " and identifier :"+identifier);
		AuditDetails auditDetails = employeePortalAuditDetailsService.getApplicationAuditDetailsField(applicationId,identifier,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out getApplicationAuditDetailsField method with auditDetails :"+auditDetails);
		return new ResponseEntity<>(auditDetails, HttpStatus.OK);
	}
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Update Application details for audit", notes = "Update Application details for audit", httpMethod = "PUT")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Application field details updated", response = StatusBean.class),
			@ApiResponse(code = 404, message = "Stage subsection field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/ctacodes/{ctacode}", produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateApplicationDetailsForAudit(@PathVariable("applicationid") String applicationId,
			@PathVariable("ctacode") Integer identifier,@RequestBody List<AppAuditRequest> appAuditRequest,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "In updateApplicationDetailsForAudit method with applicationId :" +applicationId+ " and identifier :"+identifier);
		StatusBean statusBean = employeePortalUpdateAuditDetailsService.updateApplicationDetailsForAudit(applicationId,identifier,appAuditRequest,headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateApplicationDetailsForAudit method with statusBean :"+statusBean);
		return new ResponseEntity<>(statusBean, HttpStatus.CREATED);
	}
	}

