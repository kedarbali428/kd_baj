package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class Email {
	
		@NotNull(message = "typeKey can not be null")
		private Long typeKey;
		
		@NotBlank(message = "email can not be null")
		private String email;
		
		private Verification verification;

		private List<Verification> verifications;

		public Long getTypeKey() {
			return typeKey;
		}

		public void setTypeKey(Long typeKey) {
			this.typeKey = typeKey;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public Verification getVerification() {
			return verification;
		}

		public void setVerification(Verification verification) {
			this.verification = verification;
		}

		public List<Verification> getVerifications() {
			return verifications;
		}

		public void setVerifications(List<Verification> verifications) {
			this.verifications = verifications;
		}
		
		

}
