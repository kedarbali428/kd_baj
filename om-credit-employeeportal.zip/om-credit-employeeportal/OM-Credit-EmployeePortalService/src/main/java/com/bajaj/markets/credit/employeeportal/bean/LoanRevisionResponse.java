package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class LoanRevisionResponse {

	private Long revisionKey;
	private Long appprodlistkey;
	private String l3productCode;
	private String productOffer;
	private String l4productVariant;
	private Long prodkey;
	private Long prodtypekey;
	private Integer revisedEligibilityAmmount;
	private Integer revisedEligibilityTenure;
	private Integer revisedLoanRequirement;
	private Integer revisedLoanTenure;
	private String status;
	private Integer reviewer;
	private Integer raisedBy;
	private BigDecimal eligibility;
	private BigDecimal tenor;
	
	List<String> riskOfferTypes;
	
	@JsonIgnore
	private boolean isCreated;

	public Long getRevisionKey() {
		return revisionKey;
	}

	public void setRevisionKey(Long revisionKey) {
		this.revisionKey = revisionKey;
	}

	public Long getAppprodlistkey() {
		return appprodlistkey;
	}

	public void setAppprodlistkey(Long appprodlistkey) {
		this.appprodlistkey = appprodlistkey;
	}

	public String getL3productCode() {
		return l3productCode;
	}

	public void setL3productCode(String l3productCode) {
		this.l3productCode = l3productCode;
	}

	public String getProductOffer() {
		return productOffer;
	}

	public void setProductOffer(String productOffer) {
		this.productOffer = productOffer;
	}

	public String getL4productVariant() {
		return l4productVariant;
	}

	public void setL4productVariant(String l4productVariant) {
		this.l4productVariant = l4productVariant;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public Long getProdtypekey() {
		return prodtypekey;
	}

	public void setProdtypekey(Long prodtypekey) {
		this.prodtypekey = prodtypekey;
	}

	public Integer getRevisedEligibilityAmmount() {
		return revisedEligibilityAmmount;
	}

	public void setRevisedEligibilityAmmount(Integer revisedEligibilityAmmount) {
		this.revisedEligibilityAmmount = revisedEligibilityAmmount;
	}

	public Integer getRevisedEligibilityTenure() {
		return revisedEligibilityTenure;
	}

	public void setRevisedEligibilityTenure(Integer revisedEligibilityTenure) {
		this.revisedEligibilityTenure = revisedEligibilityTenure;
	}

	public Integer getRevisedLoanRequirement() {
		return revisedLoanRequirement;
	}

	public void setRevisedLoanRequirement(Integer revisedLoanRequirement) {
		this.revisedLoanRequirement = revisedLoanRequirement;
	}

	public Integer getRevisedLoanTenure() {
		return revisedLoanTenure;
	}

	public void setRevisedLoanTenure(Integer revisedLoanTenure) {
		this.revisedLoanTenure = revisedLoanTenure;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getReviewer() {
		return reviewer;
	}

	public void setReviewer(Integer reviewer) {
		this.reviewer = reviewer;
	}

	public Integer getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(Integer raisedBy) {
		this.raisedBy = raisedBy;
	}

	public BigDecimal getEligibility() {
		return eligibility;
	}

	public void setEligibility(BigDecimal eligibility) {
		this.eligibility = eligibility;
	}

	public BigDecimal getTenor() {
		return tenor;
	}

	public void setTenor(BigDecimal tenor) {
		this.tenor = tenor;
	}

	public boolean isCreated() {
		return isCreated;
	}

	public void setCreated(boolean isCreated) {
		this.isCreated = isCreated;
	}

	@Override
	public String toString() {
		return "LoanRevisionResponse [revisionKey=" + revisionKey + ", appprodlistkey=" + appprodlistkey
				+ ", l3productCode=" + l3productCode + ", productOffer=" + productOffer + ", l4productVariant="
				+ l4productVariant + ", prodkey=" + prodkey + ", prodtypekey=" + prodtypekey
				+ ", revisedEligibilityAmmount=" + revisedEligibilityAmmount + ", revisedEligibilityTenure="
				+ revisedEligibilityTenure + ", revisedLoanRequirement=" + revisedLoanRequirement
				+ ", revisedLoanTenure=" + revisedLoanTenure + ", status=" + status + ", reviewer=" + reviewer
				+ ", raisedBy=" + raisedBy + ", eligibility=" + eligibility + ", tenor=" + tenor + ", isCreated="
				+ isCreated + "]";
	}

	/**
	 * @return the riskOfferTypes
	 */
	public List<String> getRiskOfferTypes() {
		return riskOfferTypes;
	}

	/**
	 * @param riskOfferTypes the riskOfferTypes to set
	 */
	public void setRiskOfferTypes(List<String> riskOfferTypes) {
		this.riskOfferTypes = riskOfferTypes;
	}

}