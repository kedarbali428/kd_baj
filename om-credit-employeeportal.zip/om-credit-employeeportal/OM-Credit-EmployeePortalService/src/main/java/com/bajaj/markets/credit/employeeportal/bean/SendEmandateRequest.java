package com.bajaj.markets.credit.employeeportal.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SendEmandateRequest {

	private String name;
	private Boolean isRecurring;
	private String frequency;
	private Boolean sendMandateBitly;
	private String mandateBitlyUrl;
	private String tansactionMessage;
	private String firstCollectionDate;
	private String numberOfPayments;
	private Integer repaymentAmmount;
	private String validThrough;
	private String applicantKey;
	private Long mobileNumber;
	private String emailId;
	private String applicationKey;
	private String productCategoryCode;
	private String productCode;
	private String productMasterKey;
	private String principal;
	private String chanelMandateRefId;
	private String chaneltransactionID;
	private String modeofPayment;
	private String status;
	private String micrCode;
	private String authenticationTime;
	private String umrn;
	private String enachId;
	private String authMode;
	private String mandateCategory;
	private Integer limit;
	private String accountNumber;
	private String ifscCode;
	private String accountType;
	private String bankName;
	private String mandateExpiryDate;
	private String mandateCreationSource;
	private String mandateUpdateSource;
	private String barcode;
    private Long mandateType;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getIsRecurring() {
		return isRecurring;
	}

	public void setIsRecurring(Boolean isRecurring) {
		this.isRecurring = isRecurring;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public Boolean getSendMandateBitly() {
		return sendMandateBitly;
	}

	public void setSendMandateBitly(Boolean sendMandateBitly) {
		this.sendMandateBitly = sendMandateBitly;
	}

	public String getMandateBitlyUrl() {
		return mandateBitlyUrl;
	}

	public void setMandateBitlyUrl(String mandateBitlyUrl) {
		this.mandateBitlyUrl = mandateBitlyUrl;
	}

	public String getTansactionMessage() {
		return tansactionMessage;
	}

	public void setTansactionMessage(String tansactionMessage) {
		this.tansactionMessage = tansactionMessage;
	}

	public String getFirstCollectionDate() {
		return firstCollectionDate;
	}

	public void setFirstCollectionDate(String firstCollectionDate) {
		this.firstCollectionDate = firstCollectionDate;
	}

	public String getNumberOfPayments() {
		return numberOfPayments;
	}

	public void setNumberOfPayments(String numberOfPayments) {
		this.numberOfPayments = numberOfPayments;
	}

	public Integer getRepaymentAmmount() {
		return repaymentAmmount;
	}

	public void setRepaymentAmmount(Integer repaymentAmmount) {
		this.repaymentAmmount = repaymentAmmount;
	}

	public String getValidThrough() {
		return validThrough;
	}

	public void setValidThrough(String validThrough) {
		this.validThrough = validThrough;
	}

	public String getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getProductCategoryCode() {
		return productCategoryCode;
	}

	public void setProductCategoryCode(String productCategoryCode) {
		this.productCategoryCode = productCategoryCode;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductMasterKey() {
		return productMasterKey;
	}

	public void setProductMasterKey(String productMasterKey) {
		this.productMasterKey = productMasterKey;
	}

	public String getPrincipal() {
		return principal;
	}

	public void setPrincipal(String principal) {
		this.principal = principal;
	}

	public String getChanelMandateRefId() {
		return chanelMandateRefId;
	}

	public void setChanelMandateRefId(String chanelMandateRefId) {
		this.chanelMandateRefId = chanelMandateRefId;
	}

	public String getChaneltransactionID() {
		return chaneltransactionID;
	}

	public void setChaneltransactionID(String chaneltransactionID) {
		this.chaneltransactionID = chaneltransactionID;
	}

	public String getModeofPayment() {
		return modeofPayment;
	}

	public void setModeofPayment(String modeofPayment) {
		this.modeofPayment = modeofPayment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public String getAuthenticationTime() {
		return authenticationTime;
	}

	public void setAuthenticationTime(String authenticationTime) {
		this.authenticationTime = authenticationTime;
	}

	public String getUmrn() {
		return umrn;
	}

	public void setUmrn(String umrn) {
		this.umrn = umrn;
	}

	public String getEnachId() {
		return enachId;
	}

	public void setEnachId(String enachId) {
		this.enachId = enachId;
	}

	public String getAuthMode() {
		return authMode;
	}

	public void setAuthMode(String authMode) {
		this.authMode = authMode;
	}

	public String getMandateCategory() {
		return mandateCategory;
	}

	public void setMandateCategory(String mandateCategory) {
		this.mandateCategory = mandateCategory;
	}

	public Integer getLimit() {
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getMandateExpiryDate() {
		return mandateExpiryDate;
	}

	public void setMandateExpiryDate(String mandateExpiryDate) {
		this.mandateExpiryDate = mandateExpiryDate;
	}

	public String getMandateCreationSource() {
		return mandateCreationSource;
	}

	public void setMandateCreationSource(String mandateCreationSource) {
		this.mandateCreationSource = mandateCreationSource;
	}

	public String getMandateUpdateSource() {
		return mandateUpdateSource;
	}

	public void setMandateUpdateSource(String mandateUpdateSource) {
		this.mandateUpdateSource = mandateUpdateSource;
	}
	
	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public Long getMandateType() {
		return mandateType;
	}

	public void setMandateType(Long mandateType) {
		this.mandateType = mandateType;
	}

	@Override
	public String toString() {
		return "SendEmandateRequest [name=" + name + ", isRecurring=" + isRecurring + ", frequency=" + frequency
				+ ", sendMandateBitly=" + sendMandateBitly + ", mandateBitlyUrl=" + mandateBitlyUrl
				+ ", tansactionMessage=" + tansactionMessage + ", firstCollectionDate=" + firstCollectionDate
				+ ", numberOfPayments=" + numberOfPayments + ", repaymentAmmount=" + repaymentAmmount
				+ ", validThrough=" + validThrough + ", applicantKey=" + applicantKey + ", mobileNumber=" + mobileNumber
				+ ", emailId=" + emailId + ", applicationKey=" + applicationKey + ", productCategoryCode="
				+ productCategoryCode + ", productCode=" + productCode + ", productMasterKey=" + productMasterKey
				+ ", principal=" + principal + ", chanelMandateRefId=" + chanelMandateRefId + ", chaneltransactionID="
				+ chaneltransactionID + ", modeofPayment=" + modeofPayment + ", status=" + status + ", micrCode="
				+ micrCode + ", authenticationTime=" + authenticationTime + ", umrn=" + umrn + ", enachId=" + enachId
				+ ", authMode=" + authMode + ", mandateCategory=" + mandateCategory + ", limit=" + limit
				+ ", accountNumber=" + accountNumber + ", ifscCode=" + ifscCode + ", accountType=" + accountType
				+ ", bankName=" + bankName + ", mandateExpiryDate=" + mandateExpiryDate + ", mandateCreationSource="
				+ mandateCreationSource + ", mandateUpdateSource=" + mandateUpdateSource + ", barcode=" + barcode
				+ ", mandateType=" + mandateType + "]";
	}
	





}
