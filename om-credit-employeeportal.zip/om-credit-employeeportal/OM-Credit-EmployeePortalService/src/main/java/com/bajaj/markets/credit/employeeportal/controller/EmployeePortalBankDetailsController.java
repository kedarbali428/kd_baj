package com.bajaj.markets.credit.employeeportal.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.BankDetailsRequest;
import com.bajaj.markets.credit.employeeportal.bean.BankDetailsResponse;
import com.bajaj.markets.credit.employeeportal.bean.BrePreferredMandateResponse;
import com.bajaj.markets.credit.employeeportal.bean.EmandateResponse;
import com.bajaj.markets.credit.employeeportal.bean.FinalMandateResponse;
import com.bajaj.markets.credit.employeeportal.bean.MandateBreRequest;
import com.bajaj.markets.credit.employeeportal.bean.MandateReference;
import com.bajaj.markets.credit.employeeportal.bean.PreferredMandateRequest;
import com.bajaj.markets.credit.employeeportal.bean.Section;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalBankDetailsService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EmployeePortalBankDetailsController {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private EmployeePortalBankDetailsService employeePortalBankDetailsService;
	
	private static final String CLASSNAME = EmployeePortalBankDetailsController.class.getName();

	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch bank details.", notes = "Fetch bank details on the basis of applicationKey.", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Fetching bank details successfully.", response = BankDetailsResponse.class ,responseContainer = "List"),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/employeeportal/credit/applications/{applicationKey}/bankdetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getBankDetails(@PathVariable(name = "applicationKey") @NotNull(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") String applicationKey , 
			@RequestParam(name = "isPreferedForRepayment", required = false)Boolean isPreferedForRepayment,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getBankDetails method controller - applicationKey: "+ applicationKey);
		List<BankDetailsResponse> response = employeePortalBankDetailsService.getBankDetails(applicationKey,isPreferedForRepayment,headers);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "update bank details endpoint", notes = "update user bank details", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Bank details added successfully.", response = BankDetailsResponse.class),
			@ApiResponse(code = 200, message = "Bank details updated sucessfully", response = BankDetailsResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Bad Request", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value ="/v1/employeeportal/credit/applications/{applicationKey}/bankdetails/{bankdetailskey}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateBankDetails(@Valid @RequestBody BankDetailsRequest bankDetailsRequest,BindingResult result, 
			@PathVariable(name = "applicationKey") @NotNull(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size")  String applicationKey,
			@PathVariable(name = "bankdetailskey") @NotNull(message = "bankdetailskey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "bankdetailskey should be numeric & should not exceeds size") String bankdetailsKey,
			@RequestHeader HttpHeaders headers) {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside EmployeePortalBankDetailsController :: updateBankDetails method started - applicationKey :" + applicationKey);
			if (result.hasFieldErrors()) {
				logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside saveDocumentDetails method - invalid parameters passed");
		            throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-11011", result.getFieldError().getDefaultMessage()));
		        }
			BankDetailsResponse response = employeePortalBankDetailsService.updateBankDetails(bankDetailsRequest,applicationKey,bankdetailsKey,headers);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Completed ApplicationBankDetailsController :: updateBankDetails method");
			return new ResponseEntity<>(response, HttpStatus.OK);
	}
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "save bank details endpoint", notes = "Save user bank details", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Bank details added successfully.", response = BankDetailsResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Bad Request", response = ErrorBean.class),
			
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/employeeportal/credit/applications/{applicationKey}/bankdetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> saveBankDetails(@Valid @RequestBody BankDetailsRequest bankDetailsRequest,BindingResult result,
			@PathVariable(name = "applicationKey") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") String applicationKey,
			@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside EmployeePortalBankDetailsController :: saveBankDetails method started - applicationKey :" + applicationKey);
		if (result.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside saveDocumentDetails method - invalid parameters passed");
	            throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-11011", result.getFieldError().getDefaultMessage()));
	        }
		BankDetailsResponse response = employeePortalBankDetailsService.saveBankDetails(bankDetailsRequest, applicationKey, headers);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch Mandate Detail", notes = "Fetch Mandate Details based on bank account number", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Mandate Details  fetched Successfully", response = Section.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/credit/employeeportal/applications/getmandate/{bankAccount}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getMandateDetails(@PathVariable("bankAccount") String bankAccountNum,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getMandateDetails method controller - bankAccount: "+ bankAccountNum);
		List<EmandateResponse> emandateResponse = employeePortalBankDetailsService.getMandateDetails(bankAccountNum,headers);
		return new ResponseEntity<>(emandateResponse, HttpStatus.OK);
	}
	
	
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Get Prefrred Mandate  from BRE", notes = "Get Prefrred Mandate  from BRE", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Preferred Mandate fetched Successfully", response = Section.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Emandate not available",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PostMapping(value = "/v1/credit/employeeportal/{applicationKey}/preferedMandate/{bankdetailskey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getPreferredBREMandateDetails(@RequestBody PreferredMandateRequest preferredMandateRequest,@PathVariable("applicationKey") String applicationKey,@PathVariable("bankdetailskey") String bankdetailskey,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getPreferredBREMandateDetails method controller - bankAccount: "+ bankdetailskey + " applicationKey: "+applicationKey);
		MandateBreRequest mandateBreRequest = new MandateBreRequest();
		mandateBreRequest.setBankDetails(preferredMandateRequest.getBankDetails());
		mandateBreRequest.setApplicationId(preferredMandateRequest.getApplicationId());
		BrePreferredMandateResponse mandateBreResponse = employeePortalBankDetailsService.getPreferredBREMandateDetails(mandateBreRequest,applicationKey,bankdetailskey,headers);
		return new ResponseEntity<>(mandateBreResponse, HttpStatus.OK);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Save final mandate in repayment bank details", notes = "Save final mandatekey in repayment bank details", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Final mandatekey updated Successfully.", response = FinalMandateResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/updatemandate", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> saveFinalMandate(@RequestBody MandateReference mandateReference,
			@PathVariable("applicationid") Long applicationId, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In saveFinalMandate method for applicationId : " + applicationId);
		
		// service call
		FinalMandateResponse response = employeePortalBankDetailsService.saveFinalMandate(mandateReference,
				applicationId, headers);

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out saveFinalMandate method.");
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch Mandate Detail", notes = "Fetch Mandate Details based on bank account number", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Mandate Details  fetched Successfully", response = Section.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/credit/employeeportal/applications/getfilteredmandate/{bankAccountKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getfilteredMandateDetails(@PathVariable("bankAccountKey") String bankAccountNum,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getMandateDetails method controller - bankAccount: "+ bankAccountNum);
		List<EmandateResponse> emandateResponse = employeePortalBankDetailsService.getfilteredMandateDetails(bankAccountNum,headers);
		return new ResponseEntity<>(emandateResponse, HttpStatus.OK);
	}
	
}
