package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class StampDutyBREBean {
private String applicationId;
private String product;
private BigDecimal subStagePercentage;
private String occupationType;


private List<PrincipleProductDetails> principleProductDetails =  new ArrayList<>();
public String getApplicationId() {
	return applicationId;
}
public void setApplicationId(String applicationId) {
	this.applicationId = applicationId;
}
public String getProduct() {
	return product;
}
public void setProduct(String product) {
	this.product = product;
}
public BigDecimal getSubStagePercentage() {
	return subStagePercentage;
}
public void setSubStagePercentage(BigDecimal subStagePercentage) {
	this.subStagePercentage = subStagePercentage;
}
public String getOccupationType() {
	return occupationType;
}
public void setOccupationType(String occupationType) {
	this.occupationType = occupationType;
}
public List<PrincipleProductDetails> getPrincipleProductDetails() {
	return principleProductDetails;
}
public void setPrincipleProductDetails(List<PrincipleProductDetails> principleProductDetails) {
	this.principleProductDetails = principleProductDetails;
}


}
