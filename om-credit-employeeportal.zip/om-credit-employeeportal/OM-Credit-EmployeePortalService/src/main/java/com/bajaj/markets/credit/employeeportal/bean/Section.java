package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 
 * 
 *
 */
public class Section{

	@NotNull(message = "sectionId can not be null")
	private Integer sectionId;
	
	@NotBlank(message = "sectionName can not be null")
	private String sectionName;
	
	//TODO - change group name to string
	//@NotNull(message = "groupName can not be null")
	//private String groupName;
	
	private List<String> cta;
	
	private List<Integer> subSections;
	
	private long sectionKey;

	/**
	 * @return the sectionId
	 */
	public Integer getSectionId() {
		return sectionId;
	}

	/**
	 * @param sectionId the sectionId to set
	 */
	public void setSectionId(Integer sectionId) {
		this.sectionId = sectionId;
	}

	/**
	 * @return the sectionName
	 */
	public String getSectionName() {
		return sectionName;
	}

	/**
	 * @param sectionName the sectionName to set
	 */
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	

	/**
	 * @return the cta
	 */
	public List<String> getCta() {
		return cta;
	}

	/**
	 * @param cta the cta to set
	 */
	public void setCta(List<String> cta) {
		this.cta = cta;
	}

	/**
	 * @return the subSections
	 */
	public List<Integer> getSubSections() {
		return subSections;
	}

	/**
	 * @param subSections the subSections to set
	 */
	public void setSubSections(List<Integer> subSections) {
		this.subSections = subSections;
	}

//	/**
//	 * @return the groupName
//	 */
//	public String getGroupName() {
//		return groupName;
//	}
//
//	/**
//	 * @param groupName the groupName to set
//	 */
//	public void setGroupName(String groupName) {
//		this.groupName = groupName;
//	}

	/**
	 * @return the sectionKey
	 */
	public long getSectionKey() {
		return sectionKey;
	}

	/**
	 * @param sectionKey the sectionKey to set
	 */
	public void setSectionKey(long sectionKey) {
		this.sectionKey = sectionKey;
	}

	
}
