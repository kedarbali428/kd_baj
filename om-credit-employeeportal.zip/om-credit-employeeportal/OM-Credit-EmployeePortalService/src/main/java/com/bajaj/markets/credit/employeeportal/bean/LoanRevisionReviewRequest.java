package com.bajaj.markets.credit.employeeportal.bean;

public class LoanRevisionReviewRequest {
	
	private String status;

	private Long prodkey;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

}
