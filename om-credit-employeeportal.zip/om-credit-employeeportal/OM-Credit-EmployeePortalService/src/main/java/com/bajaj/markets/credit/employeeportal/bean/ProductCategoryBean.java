package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class ProductCategoryBean {

	private long productCategoryId;
	private String productCategoryName;
	private String productCategoryCode;
	private long master;
	private boolean isProductCategoryActive;
	private List<ProductBean> productBeans;
	public long getProductCategoryId() {
		return productCategoryId;
	}
	public void setProductCategoryId(long productCategoryId) {
		this.productCategoryId = productCategoryId;
	}
	public String getProductCategoryName() {
		return productCategoryName;
	}
	public void setProductCategoryName(String productCategoryName) {
		this.productCategoryName = productCategoryName;
	}
	public String getProductCategoryCode() {
		return productCategoryCode;
	}
	public void setProductCategoryCode(String productCategoryCode) {
		this.productCategoryCode = productCategoryCode;
	}
	public long getMaster() {
		return master;
	}
	public void setMaster(long master) {
		this.master = master;
	}
	public boolean isProductCategoryActive() {
		return isProductCategoryActive;
	}
	public void setProductCategoryActive(boolean isProductCategoryActive) {
		this.isProductCategoryActive = isProductCategoryActive;
	}
	public List<ProductBean> getProductBeans() {
		return productBeans;
	}
	public void setProductBeans(List<ProductBean> productBeans) {
		this.productBeans = productBeans;
	}
	
}
