package com.bajaj.markets.credit.employeeportal.bean;

import java.util.Date;

public class EsignInfoResponse {
	
	private Long appEsignInfokey;

	private Status status;
	
	private Long appDocKey;

	private String suspendReason;
	
	private Long appPricingkey;
	
	private Integer isactive;
	
	private Long lstUpdateBy;

	private Date lstUpdateDt;
	
	public Long getAppEsignInfokey() {
		return appEsignInfokey;
	}

	public void setAppEsignInfokey(Long appEsignInfokey) {
		this.appEsignInfokey = appEsignInfokey;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getAppDocKey() {
		return appDocKey;
	}

	public void setAppDocKey(Long appDocKey) {
		this.appDocKey = appDocKey;
	}

	public String getSuspendReason() {
		return suspendReason;
	}

	public void setSuspendReason(String suspendReason) {
		this.suspendReason = suspendReason;
	}

	public Long getAppPricingkey() {
		return appPricingkey;
	}

	public void setAppPricingkey(Long appPricingkey) {
		this.appPricingkey = appPricingkey;
	}

	public Long getLstUpdateBy() {
		return lstUpdateBy;
	}

	public void setLstUpdateBy(Long lstUpdateBy) {
		this.lstUpdateBy = lstUpdateBy;
	}

	public Date getLstUpdateDt() {
		return lstUpdateDt;
	}

	public void setLstUpdateDt(Date lstUpdateDt) {
		this.lstUpdateDt = lstUpdateDt;
	}

	@Override
	public String toString() {
		return "EsignInfoResponse [appEsignInfokey=" + appEsignInfokey + ", status=" + status + ", appDocKey="
				+ appDocKey + ", suspendReason=" + suspendReason + ", appPricingkey=" + appPricingkey + ", isactive="
				+ isactive + ", lstUpdateBy=" + lstUpdateBy + ", lstUpdateDt=" + lstUpdateDt + "]";
	}

}
