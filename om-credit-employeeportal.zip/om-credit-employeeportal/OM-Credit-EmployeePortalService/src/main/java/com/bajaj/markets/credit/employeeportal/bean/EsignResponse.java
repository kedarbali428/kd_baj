package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class EsignResponse {

	private EsignStatusCode  status ;
	private List<DocumentInfo>  documentInfo;
	private boolean isCreated;
	private boolean isEsigned;
	private boolean isGenerated;
	private String esignReferenceNumber;
	public EsignStatusCode getStatus() {
		return status;
	}
	public void setStatus(EsignStatusCode status) {
		this.status = status;
	}
	public List<DocumentInfo> getDocumentInfo() {
		return documentInfo;
	}
	public void setDocumentInfo(List<DocumentInfo> documentInfo) {
		this.documentInfo = documentInfo;
	}
	public boolean isCreated() {
		return isCreated;
	}
	public void setCreated(boolean isCreated) {
		this.isCreated = isCreated;
	}
	public boolean isEsigned() {
		return isEsigned;
	}
	public void setEsigned(boolean isEsigned) {
		this.isEsigned = isEsigned;
	}
	public boolean isGenerated() {
		return isGenerated;
	}
	public void setGenerated(boolean isGenerated) {
		this.isGenerated = isGenerated;
	}
	public String getEsignReferenceNumber() {
		return esignReferenceNumber;
	}
	public void setEsignReferenceNumber(String esignReferenceNumber) {
		this.esignReferenceNumber = esignReferenceNumber;
	}
}