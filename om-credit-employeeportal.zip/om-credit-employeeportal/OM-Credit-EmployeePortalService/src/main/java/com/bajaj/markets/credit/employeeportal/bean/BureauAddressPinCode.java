package com.bajaj.markets.credit.employeeportal.bean;

public class BureauAddressPinCode {
	
	private String segmentTag;
	private Integer pincode;
	/**
	 * @return the segmentTag
	 */
	public String getSegmentTag() {
		return segmentTag;
	}
	/**
	 * @param segmentTag the segmentTag to set
	 */
	public void setSegmentTag(String segmentTag) {
		this.segmentTag = segmentTag;
	}
	/**
	 * @return the pinCode
	 */
	public Integer getPincode() {
		return pincode;
	}
	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}
	
}
