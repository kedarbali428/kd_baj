package com.bajaj.markets.credit.employeeportal.bean;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class SalaryAccountDet {
	private String salaryBankNames;
	private String salaryAccountNumber;
	public String getSalaryBankNames() {
		return salaryBankNames;
	}
	public void setSalaryBankNames(String salaryBankNames) {
		this.salaryBankNames = salaryBankNames;
	}
	public String getSalaryAccountNumber() {
		return salaryAccountNumber;
	}
	public void setSalaryAccountNumber(String salaryAccountNumber) {
		this.salaryAccountNumber = salaryAccountNumber;
	}
}
