package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;
import java.util.Set;

public class ProductDetail {

	private String productKey;
	private String productCode;
	private String productName;
	private String productUserFriendlyName;
	private String productType;
	private List<Benefits> benefits;
	private List<RiderDetail> riders;
	private Set<QuestionAnswer> questions;
	
	public Set<QuestionAnswer> getQuestions() {
		return questions;
	}
	public void setQuestions(Set<QuestionAnswer> questions) {
		this.questions = questions;
	}
	public String getProductKey() {
		return productKey;
	}
	public void setProductKey(String productKey) {
		this.productKey = productKey;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductUserFriendlyName() {
		return productUserFriendlyName;
	}
	public void setProductUserFriendlyName(String productUserFriendlyName) {
		this.productUserFriendlyName = productUserFriendlyName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public List<RiderDetail> getRiders() {
		return riders;
	}
	public void setRiders(List<RiderDetail> riders) {
		this.riders = riders;
	}
	public List<Benefits> getBenefits() {
		return benefits;
	}
	public void setBenefits(List<Benefits> benefits) {
		this.benefits = benefits;
	}
	
}
