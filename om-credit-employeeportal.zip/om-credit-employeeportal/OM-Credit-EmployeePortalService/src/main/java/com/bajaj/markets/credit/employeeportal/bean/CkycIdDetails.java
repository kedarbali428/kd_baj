package com.bajaj.markets.credit.employeeportal.bean;

public class CkycIdDetails {
	private String idType;

	private String idExpiryDate;

	private String idProofSubmitted;

	private String idVerificationStatus;

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getIdExpiryDate() {
		return idExpiryDate;
	}

	public void setIdExpiryDate(String idExpiryDate) {
		this.idExpiryDate = idExpiryDate;
	}

	public String getIdProofSubmitted() {
		return idProofSubmitted;
	}

	public void setIdProofSubmitted(String idProofSubmitted) {
		this.idProofSubmitted = idProofSubmitted;
	}

	public String getIdVerificationStatus() {
		return idVerificationStatus;
	}

	public void setIdVerificationStatus(String idVerificationStatus) {
		this.idVerificationStatus = idVerificationStatus;
	}
	
}