package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class BTBankDetails implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String btBankName;

	public String getBtBankName() {
		return btBankName;
	}

	public void setBtBankName(String btBankName) {
		this.btBankName = btBankName;
	}
	
}
