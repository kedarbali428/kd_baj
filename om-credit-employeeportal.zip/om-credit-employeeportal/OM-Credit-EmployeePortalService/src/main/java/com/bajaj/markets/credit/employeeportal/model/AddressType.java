package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "address_type", schema = "dmmaster")
public class AddressType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "address_type_addrtypkey_generator", sequenceName = "dmmaster.seq_pk_address_type", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "address_type_addrtypkey_generator")
	private Long addrtypkey;
	private String addrtypcodes;
	private String addrtypdesc;
	private Integer addrtyppriority;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;

	public Long getAddrtypkey() {
		return addrtypkey;
	}

	public void setAddrtypkey(Long addrtypkey) {
		this.addrtypkey = addrtypkey;
	}

	public String getAddrtypcodes() {
		return addrtypcodes;
	}

	public void setAddrtypcodes(String addrtypcodes) {
		this.addrtypcodes = addrtypcodes;
	}

	public String getAddrtypdesc() {
		return addrtypdesc;
	}

	public void setAddrtypdesc(String addrtypdesc) {
		this.addrtypdesc = addrtypdesc;
	}

	public Integer getAddrtyppriority() {
		return addrtyppriority;
	}

	public void setAddrtyppriority(Integer addrtyppriority) {
		this.addrtyppriority = addrtyppriority;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}