package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CoApplicantCibilTelephoneDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String coapplicantName;
	private String coapplicantPan;
	private String coapplicantCibilTelephoneType;
	private String coapplicantCibilTelephoneNumber;
	private String coapplicantCibilTelephoneExtension;

	public String getCoapplicantName() {
		return coapplicantName;
	}

	public void setCoapplicantName(String coapplicantName) {
		this.coapplicantName = coapplicantName;
	}

	public String getCoapplicantPan() {
		return coapplicantPan;
	}

	public void setCoapplicantPan(String coapplicantPan) {
		this.coapplicantPan = coapplicantPan;
	}

	public String getCoapplicantCibilTelephoneType() {
		return coapplicantCibilTelephoneType;
	}

	public void setCoapplicantCibilTelephoneType(String coapplicantCibilTelephoneType) {
		this.coapplicantCibilTelephoneType = coapplicantCibilTelephoneType;
	}

	public String getCoapplicantCibilTelephoneNumber() {
		return coapplicantCibilTelephoneNumber;
	}

	public void setCoapplicantCibilTelephoneNumber(String coapplicantCibilTelephoneNumber) {
		this.coapplicantCibilTelephoneNumber = coapplicantCibilTelephoneNumber;
	}

	public String getCoapplicantCibilTelephoneExtension() {
		return coapplicantCibilTelephoneExtension;
	}

	public void setCoapplicantCibilTelephoneExtension(String coapplicantCibilTelephoneExtension) {
		this.coapplicantCibilTelephoneExtension = coapplicantCibilTelephoneExtension;
	}

}