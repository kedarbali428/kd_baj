package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bfsd_role_master",schema="dmmaster")
public class BFSDRoleMaster implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long rolekey;
	
	private Long rolecd; 
	
	private String rolename;
	
	private Integer parentrole;
	
	private Integer isactive; 
	
	private Integer systemroleflg;
	
	private String lstupdateby; 
	
	private Timestamp lstupdatedt;
	
	public Long getRolekey() {
		return rolekey;
	}
	public void setRolekey(Long rolekey) {
		this.rolekey = rolekey;
	}
	public Long getRolecd() {
		return rolecd;
	}
	public void setRolecd(Long rolecd) {
		this.rolecd = rolecd;
	}
	public String getRolename() {
		return rolename;
	}
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
	public Integer getParentrole() {
		return parentrole;
	}
	public void setParentrole(Integer parentrole) {
		this.parentrole = parentrole;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	public Integer getSystemroleflg() {
		return systemroleflg;
	}
	public void setSystemroleflg(Integer systemroleflg) {
		this.systemroleflg = systemroleflg;
	}
	public String getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	
}
