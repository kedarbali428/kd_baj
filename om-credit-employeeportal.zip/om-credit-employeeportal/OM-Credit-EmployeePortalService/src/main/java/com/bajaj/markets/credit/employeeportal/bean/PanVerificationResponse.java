package com.bajaj.markets.credit.employeeportal.bean;

import javax.validation.constraints.NotBlank;

public class PanVerificationResponse {
	@NotBlank(message = "panNumber cannot be null or empty")
	private String panNumber;

	private boolean forcedVerification;

	private String applicationKey;

	private String applicantKey;

	private String fullName;

	private String nameRecieved;

	private boolean nameMatch;

	private PanVerificationDetails verification;

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public boolean isForcedVerification() {
		return forcedVerification;
	}

	public void setForcedVerification(boolean forcedVerification) {
		this.forcedVerification = forcedVerification;
	}

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public PanVerificationDetails getVerification() {
		return verification;
	}

	public void setVerification(PanVerificationDetails verification) {
		this.verification = verification;
	}

	public boolean isNameMatch() {
		return nameMatch;
	}

	public void setNameMatch(boolean nameMatch) {
		this.nameMatch = nameMatch;
	}

	public String getNameRecieved() {
		return nameRecieved;
	}

	public void setNameRecieved(String nameRecieved) {
		this.nameRecieved = nameRecieved;
	}

	@Override
	public String toString() {
		return "PanVerificationResponse [panNumber=" + panNumber + ", forcedVerification=" + forcedVerification
				+ ", applicationKey=" + applicationKey + ", applicantKey=" + applicantKey + ", fullName=" + fullName
				+ ", nameRecieved=" + nameRecieved + ", nameMatch=" + nameMatch + ", verification=" + verification
				+ "]";
	}

}
