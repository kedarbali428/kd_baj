package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the OFFER_DETAILS database table.
 * 
 */
@Entity
@Table(name = "bfsd_function_products", schema = "dmcredit")
public class BfsdFunctionProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long prodfunctionkey;

	private Long functionkey;

	private Long prodmastkey;

	private Long subprodkey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	public Long getProdfunctionkey() {
		return prodfunctionkey;
	}

	public void setProdfunctionkey(Long prodfunctionkey) {
		this.prodfunctionkey = prodfunctionkey;
	}

	public Long getFunctionkey() {
		return functionkey;
	}

	public void setFunctionkey(Long functionkey) {
		this.functionkey = functionkey;
	}

	public Long getProdmastkey() {
		return prodmastkey;
	}

	public void setProdmastkey(Long prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public Long getSubprodkey() {
		return subprodkey;
	}

	public void setSubprodkey(Long subprodkey) {
		this.subprodkey = subprodkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BfsdFunctionProduct() {
	}

}