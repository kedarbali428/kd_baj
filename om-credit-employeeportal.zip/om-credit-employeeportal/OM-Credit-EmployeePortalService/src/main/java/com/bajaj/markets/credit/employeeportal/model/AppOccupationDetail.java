package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the app_occupation_detail database table.
 * 
 */
@Entity
@Table(name = "app_occupation_detail", schema = "dmcredit")
public class AppOccupationDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long appoccupationkey;

	private String annualturnover;

	private Long appattrbkey;

	private BigDecimal avgbankbalance;

	private Long businesskey;

	private String businessname;

	private String businesspan;

	//private Integer businesssubsectorkey;

	private Integer businessvintage;

	private String cif;

	private Integer currentexperience;

	private Long custindmastkey;

	private Integer declaredexperience;

	private Long declaredincome;

	private String designforoth;

	private String emplrcategory;

	private Long emplrdesigkey;

	private Long emplrtype;

	private String empnameforoth;

	private Long emprmastid;

	private Integer finalexperience;

	private String gstnumber;

	private String industryother;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String medicalregistrationnumber;

	private BigDecimal netmonthlysalary;

	private BigDecimal netmthincome;

	private Long nobkey;

	private Long occupationtype;

	private String officetype;

	//private String othbusinesssubsector;

	private BigDecimal pat;

	private Long perfiosincome;

	private String practicetype;

	private Integer presentbusinessvintage;

	private BigDecimal profitaftertax;

	private Long smsincome;

	private Long subindumastkey;
	
	private String caregistrationnumber;

	private Integer certificateofpractice;

	private Long qlfymastkey;

	private Long spclmastkey;

	private BigDecimal graduationyear;

	private BigDecimal postgraduationyear;
	
	private Long rcmastkey;

	private Long hospitalkey;

	private String degreecategory;
	//private Integer subsectorinvestkey;
	
	private String profileemptype;

	public String getProfileemptype() {
		return profileemptype;
	}

	public void setProfileemptype(String profileemptype) {
		this.profileemptype = profileemptype;
	}

	public AppOccupationDetail() {
	}

	public Long getAppoccupationkey() {
		return appoccupationkey;
	}

	public void setAppoccupationkey(Long appoccupationkey) {
		this.appoccupationkey = appoccupationkey;
	}

	public String getAnnualturnover() {
		return annualturnover;
	}

	public void setAnnualturnover(String annualturnover) {
		this.annualturnover = annualturnover;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public BigDecimal getAvgbankbalance() {
		return avgbankbalance;
	}

	public void setAvgbankbalance(BigDecimal avgbankbalance) {
		this.avgbankbalance = avgbankbalance;
	}

	public Long getBusinesskey() {
		return businesskey;
	}

	public void setBusinesskey(Long businesskey) {
		this.businesskey = businesskey;
	}

	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public String getBusinesspan() {
		return businesspan;
	}

	public void setBusinesspan(String businesspan) {
		this.businesspan = businesspan;
	}

	/*
	 * public Integer getBusinesssubsectorkey() { return businesssubsectorkey; }
	 * 
	 * public void setBusinesssubsectorkey(Integer businesssubsectorkey) {
	 * this.businesssubsectorkey = businesssubsectorkey; }
	 */

	public Integer getBusinessvintage() {
		return businessvintage;
	}

	public void setBusinessvintage(Integer businessvintage) {
		this.businessvintage = businessvintage;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public Integer getCurrentexperience() {
		return currentexperience;
	}

	public void setCurrentexperience(Integer currentexperience) {
		this.currentexperience = currentexperience;
	}

	public Long getCustindmastkey() {
		return custindmastkey;
	}

	public void setCustindmastkey(Long custindmastkey) {
		this.custindmastkey = custindmastkey;
	}

	public Integer getDeclaredexperience() {
		return declaredexperience;
	}

	public void setDeclaredexperience(Integer declaredexperience) {
		this.declaredexperience = declaredexperience;
	}

	public Long getDeclaredincome() {
		return declaredincome;
	}

	public void setDeclaredincome(Long declaredincome) {
		this.declaredincome = declaredincome;
	}

	public String getDesignforoth() {
		return designforoth;
	}

	public void setDesignforoth(String designforoth) {
		this.designforoth = designforoth;
	}

	public String getEmplrcategory() {
		return emplrcategory;
	}

	public void setEmplrcategory(String emplrcategory) {
		this.emplrcategory = emplrcategory;
	}

	public Long getEmplrdesigkey() {
		return emplrdesigkey;
	}

	public void setEmplrdesigkey(Long emplrdesigkey) {
		this.emplrdesigkey = emplrdesigkey;
	}

	public Long getEmplrtype() {
		return emplrtype;
	}

	public void setEmplrtype(Long emplrtype) {
		this.emplrtype = emplrtype;
	}

	public String getEmpnameforoth() {
		return empnameforoth;
	}

	public void setEmpnameforoth(String empnameforoth) {
		this.empnameforoth = empnameforoth;
	}

	public Long getEmprmastid() {
		return emprmastid;
	}

	public void setEmprmastid(Long emprmastid) {
		this.emprmastid = emprmastid;
	}

	public Integer getFinalexperience() {
		return finalexperience;
	}

	public void setFinalexperience(Integer finalexperience) {
		this.finalexperience = finalexperience;
	}

	public String getGstnumber() {
		return gstnumber;
	}

	public void setGstnumber(String gstnumber) {
		this.gstnumber = gstnumber;
	}

	public String getIndustryother() {
		return industryother;
	}

	public void setIndustryother(String industryother) {
		this.industryother = industryother;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getMedicalregistrationnumber() {
		return medicalregistrationnumber;
	}

	public void setMedicalregistrationnumber(String medicalregistrationnumber) {
		this.medicalregistrationnumber = medicalregistrationnumber;
	}

	public BigDecimal getNetmonthlysalary() {
		return netmonthlysalary;
	}

	public void setNetmonthlysalary(BigDecimal netmonthlysalary) {
		this.netmonthlysalary = netmonthlysalary;
	}

	public BigDecimal getNetmthincome() {
		return netmthincome;
	}

	public void setNetmthincome(BigDecimal netmthincome) {
		this.netmthincome = netmthincome;
	}

	public Long getNobkey() {
		return nobkey;
	}

	public void setNobkey(Long nobkey) {
		this.nobkey = nobkey;
	}

	public Long getOccupationtype() {
		return occupationtype;
	}

	public void setOccupationtype(Long occupationtype) {
		this.occupationtype = occupationtype;
	}

	public String getOfficetype() {
		return officetype;
	}

	public void setOfficetype(String officetype) {
		this.officetype = officetype;
	}

	/*
	 * public String getOthbusinesssubsector() { return othbusinesssubsector; }
	 * 
	 * public void setOthbusinesssubsector(String othbusinesssubsector) {
	 * this.othbusinesssubsector = othbusinesssubsector; }
	 */

	public BigDecimal getPat() {
		return pat;
	}

	public void setPat(BigDecimal pat) {
		this.pat = pat;
	}

	public Long getPerfiosincome() {
		return perfiosincome;
	}

	public void setPerfiosincome(Long perfiosincome) {
		this.perfiosincome = perfiosincome;
	}

	public String getPracticetype() {
		return practicetype;
	}

	public void setPracticetype(String practicetype) {
		this.practicetype = practicetype;
	}

	public Integer getPresentbusinessvintage() {
		return presentbusinessvintage;
	}

	public void setPresentbusinessvintage(Integer presentbusinessvintage) {
		this.presentbusinessvintage = presentbusinessvintage;
	}

	public BigDecimal getProfitaftertax() {
		return profitaftertax;
	}

	public void setProfitaftertax(BigDecimal profitaftertax) {
		this.profitaftertax = profitaftertax;
	}

	public Long getSmsincome() {
		return smsincome;
	}

	public void setSmsincome(Long smsincome) {
		this.smsincome = smsincome;
	}

	public Long getSubindumastkey() {
		return subindumastkey;
	}

	public void setSubindumastkey(Long subindumastkey) {
		this.subindumastkey = subindumastkey;
	}

	public String getCaregistrationnumber() {
		return caregistrationnumber;
	}

	public void setCaregistrationnumber(String caregistrationnumber) {
		this.caregistrationnumber = caregistrationnumber;
	}

	public Integer getCertificateofpractice() {
		return certificateofpractice;
	}

	public void setCertificateofpractice(Integer certificateofpractice) {
		this.certificateofpractice = certificateofpractice;
	}

	public Long getQlfymastkey() {
		return qlfymastkey;
	}

	public void setQlfymastkey(Long qlfymastkey) {
		this.qlfymastkey = qlfymastkey;
	}

	public Long getSpclmastkey() {
		return spclmastkey;
	}

	public void setSpclmastkey(Long spclmastkey) {
		this.spclmastkey = spclmastkey;
	}

	public BigDecimal getGraduationyear() {
		return graduationyear;
	}

	public void setGraduationyear(BigDecimal graduationyear) {
		this.graduationyear = graduationyear;
	}

	public BigDecimal getPostgraduationyear() {
		return postgraduationyear;
	}

	public void setPostgraduationyear(BigDecimal postgraduationyear) {
		this.postgraduationyear = postgraduationyear;
	}

	public Long getRcmastkey() {
		return rcmastkey;
	}

	public void setRcmastkey(Long rcmastkey) {
		this.rcmastkey = rcmastkey;
	}

	public Long getHospitalkey() {
		return hospitalkey;
	}

	public void setHospitalkey(Long hospitalkey) {
		this.hospitalkey = hospitalkey;
	}

	public String getDegreecategory() {
		return degreecategory;
	}

	public void setDegreecategory(String degreecategory) {
		this.degreecategory = degreecategory;
	}
	
	/*
	 * public Integer getSubsectorinvestkey() { return subsectorinvestkey; }
	 * 
	 * public void setSubsectorinvestkey(Integer subsectorinvestkey) {
	 * this.subsectorinvestkey = subsectorinvestkey; }
	 */

}