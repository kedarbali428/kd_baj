package com.bajaj.markets.credit.employeeportal.bean;

public class PerfiosBankDetails {
	private String statementEndDate;
	private String statementStartDate;
	private String accountType;	
	private String accountNumber;
	private String bankName;
	private String pan;
	private String email;	
	private String mobile;
	private String landline;
	private String address;
	private String customerName;
	private String authenticity;
	private String statementStatus;
	private String statementFileName;
	private String passwordProtected;
	private String inwardBounceCount;
	private String maxCreditAmount;
	
	/**
	 * @return the statementEndDate
	 */
	public String getStatementEndDate() {
		return statementEndDate;
	}
	/**
	 * @param statementEndDate the statementEndDate to set
	 */
	public void setStatementEndDate(String statementEndDate) {
		this.statementEndDate = statementEndDate;
	}
	/**
	 * @return the statementStartDate
	 */
	public String getStatementStartDate() {
		return statementStartDate;
	}
	/**
	 * @param statementStartDate the statementStartDate to set
	 */
	public void setStatementStartDate(String statementStartDate) {
		this.statementStartDate = statementStartDate;
	}
	/**
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}
	/**
	 * @param accountType the accountType to set
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}
	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	/**
	 * @return the pan
	 */
	public String getPan() {
		return pan;
	}
	/**
	 * @param pan the pan to set
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}
	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	/**
	 * @return the landline
	 */
	public String getLandline() {
		return landline;
	}
	/**
	 * @param landline the landline to set
	 */
	public void setLandline(String landline) {
		this.landline = landline;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the authenticity
	 */
	public String getAuthenticity() {
		return authenticity;
	}
	/**
	 * @param authenticity the authenticity to set
	 */
	public void setAuthenticity(String authenticity) {
		this.authenticity = authenticity;
	}
	/**
	 * @return the statementStatus
	 */
	public String getStatementStatus() {
		return statementStatus;
	}
	/**
	 * @param statementStatus the statementStatus to set
	 */
	public void setStatementStatus(String statementStatus) {
		this.statementStatus = statementStatus;
	}
	/**
	 * @return the statementFileName
	 */
	public String getStatementFileName() {
		return statementFileName;
	}
	/**
	 * @param statementFileName the statementFileName to set
	 */
	public void setStatementFileName(String statementFileName) {
		this.statementFileName = statementFileName;
	}
	/**
	 * @return the passwordProtected
	 */
	public String getPasswordProtected() {
		return passwordProtected;
	}
	/**
	 * @param passwordProtected the passwordProtected to set
	 */
	public void setPasswordProtected(String passwordProtected) {
		this.passwordProtected = passwordProtected;
	}
	public String getInwardBounceCount() {
		return inwardBounceCount;
	}
	public void setInwardBounceCount(String inwardBounceCount) {
		this.inwardBounceCount = inwardBounceCount;
	}
	public String getMaxCreditAmount() {
		return maxCreditAmount;
	}
	public void setMaxCreditAmount(String maxCreditAmount) {
		this.maxCreditAmount = maxCreditAmount;
	}
}


