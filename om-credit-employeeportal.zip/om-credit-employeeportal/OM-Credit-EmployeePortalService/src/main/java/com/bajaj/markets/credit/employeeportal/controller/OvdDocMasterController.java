package com.bajaj.markets.credit.employeeportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.model.OvdDocMaster;
import com.bajaj.markets.credit.employeeportal.service.OvdDocMasterService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class OvdDocMasterController {
	@Autowired
	BFLLoggerUtil logger;
	
	@Autowired
	private OvdDocMasterService ovdDocMasterService;
	
	private static final String CLASSNAME = OvdDocMasterController.class.getName();
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch ovd doc master.", notes = "Fetch ovd doc master.", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "ovd doc master details", response = OvdDocMaster.class),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/employeeportal/credit/ovddocmaster", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getOvdDocMasterDetails(@RequestHeader HttpHeaders headers, @RequestParam(value = "addrTypeKey", required = false) Integer addrTypeKey){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getOvdDocMasterDetails method controller");
		List<OvdDocMaster> response = ovdDocMasterService.getovdDocMasterDetails(addrTypeKey);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
}
