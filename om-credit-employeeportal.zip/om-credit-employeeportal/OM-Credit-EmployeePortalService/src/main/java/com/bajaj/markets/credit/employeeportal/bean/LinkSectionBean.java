package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class LinkSectionBean {

	private long tabkey;
	private String tabname;
	List<LinkBean> links;

	public long getTabkey() {
		return tabkey;
	}

	public void setTabkey(long tabkey) {
		this.tabkey = tabkey;
	}

	public String getTabname() {
		return tabname;
	}

	public void setTabname(String tabname) {
		this.tabname = tabname;
	}

	public List<LinkBean> getLinks() {
		return links;
	}

	public void setLinks(List<LinkBean> links) {
		this.links = links;
	}

}
