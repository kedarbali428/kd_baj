package com.bajaj.markets.credit.employeeportal.bean;

public class ApplicationSource {
    
	private Long validApplicationId;
	
	private String Source;

	/**
	 * @return the validApplicationId
	 */
	public Long getValidApplicationId() {
		return validApplicationId;
	}

	/**
	 * @param validApplicationId the validApplicationId to set
	 */
	public void setValidApplicationId(Long validApplicationId) {
		this.validApplicationId = validApplicationId;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return Source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		Source = source;
	}
	
	

}
