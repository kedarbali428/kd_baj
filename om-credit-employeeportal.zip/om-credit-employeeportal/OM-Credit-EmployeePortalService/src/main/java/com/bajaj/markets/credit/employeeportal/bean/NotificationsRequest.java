package com.bajaj.markets.credit.employeeportal.bean;

import java.util.Map;

public class NotificationsRequest {

	private String notificationTypeCode;
	private Long applicationApplicantId;
	private Map<String, Object> templateDataMap;

	public String getNotificationTypeCode() {
		return notificationTypeCode;
	}

	public void setNotificationTypeCode(String notificationTypeCode) {
		this.notificationTypeCode = notificationTypeCode;
	}

	public Map<String, Object> getTemplateDataMap() {
		return templateDataMap;
	}

	public void setTemplateDataMap(Map<String, Object> templateDataMap) {
		this.templateDataMap = templateDataMap;
	}
	public Long getApplicationApplicantId() {
		return applicationApplicantId;
	}

	public void setApplicationApplicantId(Long applicationApplicantId) {
		this.applicationApplicantId = applicationApplicantId;
	}
	

}
