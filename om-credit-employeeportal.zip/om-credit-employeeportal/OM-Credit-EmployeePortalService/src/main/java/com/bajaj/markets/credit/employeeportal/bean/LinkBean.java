package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class LinkBean {

	@Id
	private Long linkkey;
	private String linkname;
	private BigDecimal linkcode;
	private boolean selected;

	public Long getLinkkey() {
		return linkkey;
	}

	public void setLinkkey(Long linkkey) {
		this.linkkey = linkkey;
	}

	public String getLinkname() {
		return linkname;
	}

	public void setLinkname(String linkname) {
		this.linkname = linkname;
	}

	public BigDecimal getLinkcode() {
		return linkcode;
	}

	public void setLinkcode(BigDecimal linkcode) {
		this.linkcode = linkcode;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}



}
