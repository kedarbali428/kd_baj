package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankStmntDetails {
	private List<BankStmnt> bankStmnt;

	public List<BankStmnt> getBankStmnt() {
		return bankStmnt;
	}

	public void setBankStmnt(List<BankStmnt> bankStmnt) {
		this.bankStmnt = bankStmnt;
	}

}
