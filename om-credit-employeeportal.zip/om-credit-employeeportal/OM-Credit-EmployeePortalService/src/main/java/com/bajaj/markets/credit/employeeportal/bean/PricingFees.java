package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class PricingFees implements Serializable,Cloneable{

	private static final long serialVersionUID = 1L;
	
	private Long feesKey;
	
    private Long appLoanPricingKey;
    
    private BigDecimal feesInPercent;
    
    private BigDecimal feesInAmount;
    
    private String feeCode;

	public PricingFees() {
		super();
	}

	public Long getFeesKey() {
		return feesKey;
	}

	public void setFeesKey(Long feesKey) {
		this.feesKey = feesKey;
	}

	public Long getAppLoanPricingKey() {
		return appLoanPricingKey;
	}

	public void setAppLoanPricingKey(Long appLoanPricingKey) {
		this.appLoanPricingKey = appLoanPricingKey;
	}

	public BigDecimal getFeesInPercent() {
		return feesInPercent;
	}

	public void setFeesInPercent(BigDecimal feesInPercent) {
		this.feesInPercent = feesInPercent;
	}

	public BigDecimal getFeesInAmount() {
		return feesInAmount;
	}

	public void setFeesInAmount(BigDecimal feesInAmount) {
		this.feesInAmount = feesInAmount;
	}

	public String getFeeCode() {
		return feeCode;
	}

	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}
    
}