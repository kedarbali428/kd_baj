package com.bajaj.markets.credit.employeeportal.bean;

import java.util.Date;
public class PanVerificationDetails {
	private Boolean isVerified;
   	private VerificationSource verificationSource;
    private String verifiedFor;
    private Date verificationDate;
    private Long verificationReference;
    
	public Boolean getIsVerified() {
		return isVerified;
	}
	public void setIsVerified(Boolean isVerified) {
		this.isVerified = isVerified;
	}		
	public VerificationSource getVerificationSource() {
		return verificationSource;
	}
	public void setVerificationSource(VerificationSource verificationSource) {
		this.verificationSource = verificationSource;
	}
	public String getVerifiedFor() {
		return verifiedFor;
	}
	public void setVerifiedFor(String verifiedFor) {
		this.verifiedFor = verifiedFor;
	}
	
	public Date getVerificationDate() {
		return verificationDate;
	}
	public void setVerificationDate(Date verificationDate) {
		this.verificationDate = verificationDate;
	}
	public Long getVerificationReference() {
		return verificationReference;
	}
	public void setVerificationReference(Long verificationReference) {
		this.verificationReference = verificationReference;
	}
	@Override
	public String toString() {
		return "VerificationDetail [isVerified=" + isVerified + ", verificationSource=" + verificationSource
				+ ", verifiedFor=" + verifiedFor + ", verificationDate=" + verificationDate + ", verificationReference="
				+ verificationReference + "]";
	}
}
