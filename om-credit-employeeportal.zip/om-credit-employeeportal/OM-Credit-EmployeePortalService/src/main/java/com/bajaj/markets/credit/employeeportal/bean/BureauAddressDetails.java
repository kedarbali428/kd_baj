package com.bajaj.markets.credit.employeeportal.bean;

public class BureauAddressDetails {

	private String segmenttag;

	private String addressline1;

	private String addressline2;

	private String addressline3;

	private String statecode;

	private String pincode;

	private String addresscategory;

	private String residencecode;
	
	 private String datereported;

	/**
	 * @return the segmenttag
	 */
	public String getSegmenttag() {
		return segmenttag;
	}

	/**
	 * @param segmenttag the segmenttag to set
	 */
	public void setSegmenttag(String segmenttag) {
		this.segmenttag = segmenttag;
	}

	/**
	 * @return the addressline1
	 */
	public String getAddressline1() {
		return addressline1;
	}

	/**
	 * @param addressline1 the addressline1 to set
	 */
	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	/**
	 * @return the addressline2
	 */
	public String getAddressline2() {
		return addressline2;
	}

	/**
	 * @param addressline2 the addressline2 to set
	 */
	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}

	/**
	 * @return the addressline3
	 */
	public String getAddressline3() {
		return addressline3;
	}

	/**
	 * @param addressline3 the addressline3 to set
	 */
	public void setAddressline3(String addressline3) {
		this.addressline3 = addressline3;
	}

	/**
	 * @return the statecode
	 */
	public String getStatecode() {
		return statecode;
	}

	/**
	 * @param statecode the statecode to set
	 */
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}

	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}

	/**
	 * @param pincode the pincode to set
	 */
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	/**
	 * @return the addresscategory
	 */
	public String getAddresscategory() {
		return addresscategory;
	}

	/**
	 * @param addresscategory the addresscategory to set
	 */
	public void setAddresscategory(String addresscategory) {
		this.addresscategory = addresscategory;
	}

	/**
	 * @return the residencecode
	 */
	public String getResidencecode() {
		return residencecode;
	}

	/**
	 * @param residencecode the residencecode to set
	 */
	public void setResidencecode(String residencecode) {
		this.residencecode = residencecode;
	}

	

	/**
	 * @return the datereported
	 */
	public String getDatereported() {
		return datereported;
	}

	/**
	 * @param datereported the datereported to set
	 */
	public void setDatereported(String datereported) {
		this.datereported = datereported;
	}

}
