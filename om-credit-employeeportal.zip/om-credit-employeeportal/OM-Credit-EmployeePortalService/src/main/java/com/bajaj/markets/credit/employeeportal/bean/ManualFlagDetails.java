package com.bajaj.markets.credit.employeeportal.bean;

import java.sql.Timestamp;

public class ManualFlagDetails {
	
	private String flagName;
	private String flagDescription;
	private String flagStatus;
	private String flagAddedBy;
	private Timestamp flagCreatedDate;
	private String flagAddedOn;
	private Long applicationId;
	
	public String getFlagName() {
		return flagName;
	}
	public void setFlagName(String flagName) {
		this.flagName = flagName;
	}
	public String getFlagDescription() {
		return flagDescription;
	}
	public void setFlagDescription(String flagDescription) {
		this.flagDescription = flagDescription;
	}
	public String getFlagStatus() {
		return flagStatus;
	}
	public void setFlagStatus(String flagStatus) {
		this.flagStatus = flagStatus;
	}
	public String getFlagAddedBy() {
		return flagAddedBy;
	}
	public void setFlagAddedBy(String flagAddedBy) {
		this.flagAddedBy = flagAddedBy;
	}
	public Timestamp getFlagCreatedDate() {
		return flagCreatedDate;
	}
	public void setFlagCreatedDate(Timestamp flagCreatedDate) {
		this.flagCreatedDate = flagCreatedDate;
	}
	public String getFlagAddedOn() {
		return flagAddedOn;
	}
	public void setFlagAddedOn(String flagAddedOn) {
		this.flagAddedOn = flagAddedOn;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	
}
