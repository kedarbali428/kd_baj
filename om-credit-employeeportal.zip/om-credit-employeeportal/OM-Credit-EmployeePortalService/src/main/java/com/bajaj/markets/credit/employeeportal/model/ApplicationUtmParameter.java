package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the application_utm_parameter database table.
 * 
 */
@Entity
@Table(name = "application_utm_parameter", schema = "dmcredit")
public class ApplicationUtmParameter implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long apputmparamkey;

	private Long applicationkey;

	private Timestamp createdt;

	private String gclid;

	private Integer isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private Integer recversion;

	private String sourcingchannel;

	private String utmcampaign;

	private String utmcontent;

	private String utmmedium;

	private String utmreferralcode;

	private String utmsource;

	private String utmterm;

	private String event;

	public ApplicationUtmParameter() {
	}

	public Long getApputmparamkey() {
		return this.apputmparamkey;
	}

	public void setApputmparamkey(Long apputmparamkey) {
		this.apputmparamkey = apputmparamkey;
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Timestamp getCreatedt() {
		return this.createdt;
	}

	public void setCreatedt(Timestamp createdt) {
		this.createdt = createdt;
	}

	public String getGclid() {
		return this.gclid;
	}

	public void setGclid(String gclid) {
		this.gclid = gclid;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Integer getRecversion() {
		return this.recversion;
	}

	public void setRecversion(Integer recversion) {
		this.recversion = recversion;
	}

	public String getSourcingchannel() {
		return this.sourcingchannel;
	}

	public void setSourcingchannel(String sourcingchannel) {
		this.sourcingchannel = sourcingchannel;
	}

	public String getUtmcampaign() {
		return this.utmcampaign;
	}

	public void setUtmcampaign(String utmcampaign) {
		this.utmcampaign = utmcampaign;
	}

	public String getUtmcontent() {
		return this.utmcontent;
	}

	public void setUtmcontent(String utmcontent) {
		this.utmcontent = utmcontent;
	}

	public String getUtmmedium() {
		return this.utmmedium;
	}

	public void setUtmmedium(String utmmedium) {
		this.utmmedium = utmmedium;
	}

	public String getUtmreferralcode() {
		return this.utmreferralcode;
	}

	public void setUtmreferralcode(String utmreferralcode) {
		this.utmreferralcode = utmreferralcode;
	}

	public String getUtmsource() {
		return this.utmsource;
	}

	public void setUtmsource(String utmsource) {
		this.utmsource = utmsource;
	}

	public String getUtmterm() {
		return this.utmterm;
	}

	public void setUtmterm(String utmterm) {
		this.utmterm = utmterm;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

}