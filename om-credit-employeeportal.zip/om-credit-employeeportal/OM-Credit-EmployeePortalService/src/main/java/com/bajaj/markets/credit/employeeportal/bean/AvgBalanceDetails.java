package com.bajaj.markets.credit.employeeportal.bean;

public class AvgBalanceDetails {
	private String avgBalanceAmount;
	private String avgLastBalance;
	private String avgMinBalance;
	private String avgMaxBalance;
	
	private String balanceMonth;
	private String accountnumber;
	
	public String getAvgBalanceAmount() {
		return avgBalanceAmount;
	}
	public void setAvgBalanceAmount(String avgBalanceAmount) {
		this.avgBalanceAmount = avgBalanceAmount;
	}
	public String getBalanceMonth() {
		return balanceMonth;
	}
	public void setBalanceMonth(String balanceMonth) {
		this.balanceMonth = balanceMonth;
	}
	/**
	 * @return the avgLastBalance
	 */
	public String getAvgLastBalance() {
		return avgLastBalance;
	}
	/**
	 * @param avgLastBalance the avgLastBalance to set
	 */
	public void setAvgLastBalance(String avgLastBalance) {
		this.avgLastBalance = avgLastBalance;
	}
	/**
	 * @return the avgMinBalance
	 */
	public String getAvgMinBalance() {
		return avgMinBalance;
	}
	/**
	 * @param avgMinBalance the avgMinBalance to set
	 */
	public void setAvgMinBalance(String avgMinBalance) {
		this.avgMinBalance = avgMinBalance;
	}
	/**
	 * @return the avgMaxBalance
	 */
	public String getAvgMaxBalance() {
		return avgMaxBalance;
	}
	/**
	 * @param avgMaxBalance the avgMaxBalance to set
	 */
	public void setAvgMaxBalance(String avgMaxBalance) {
		this.avgMaxBalance = avgMaxBalance;
	}
	/**
	 * @return the accountnumber
	 */
	public String getAccountnumber() {
		return accountnumber;
	}
	/**
	 * @param accountnumber the accountnumber to set
	 */
	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}
	
}