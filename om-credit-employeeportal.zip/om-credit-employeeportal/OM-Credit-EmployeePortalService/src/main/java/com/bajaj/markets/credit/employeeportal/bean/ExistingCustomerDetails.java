package com.bajaj.markets.credit.employeeportal.bean;

public class ExistingCustomerDetails {
	private String principalName;
	private Boolean existingCustomerFlag;
	private String principalCustType;
	private String principalCustSegment;
	/**
	 * @return the principalName
	 */
	public String getPrincipalName() {
		return principalName;
	}
	/**
	 * @param principalName the principalName to set
	 */
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}
	/**
	 * @return the principalCustType
	 */
	public String getPrincipalCustType() {
		return principalCustType;
	}
	/**
	 * @param principalCustType the principalCustType to set
	 */
	public void setPrincipalCustType(String principalCustType) {
		this.principalCustType = principalCustType;
	}
	/**
	 * @return the principalCustSegment
	 */
	public String getPrincipalCustSegment() {
		return principalCustSegment;
	}
	/**
	 * @param principalCustSegment the principalCustSegment to set
	 */
	public void setPrincipalCustSegment(String principalCustSegment) {
		this.principalCustSegment = principalCustSegment;
	}
	/**
	 * @return the existingCustomerFlag
	 */
	public Boolean getExistingCustomerFlag() {
		return existingCustomerFlag;
	}
	/**
	 * @param existingCustomerFlag the existingCustomerFlag to set
	 */
	public void setExistingCustomerFlag(Boolean existingCustomerFlag) {
		this.existingCustomerFlag = existingCustomerFlag;
	}
}
