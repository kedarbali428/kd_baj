package com.bajaj.markets.credit.employeeportal.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.Email;
import com.bajaj.markets.credit.employeeportal.bean.EmailRequest;
import com.bajaj.markets.credit.employeeportal.bean.EmailVerificationDetail;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.model.ApplicationEmail;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalEmailService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EmployeePortalEmailController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private EmployeePortalEmailService employeePortalEmailService;

	private static final String CLASSNAME = EmployeePortalEmailController.class.getName();

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch email details based on ApplicationId", notes = "Fetch email details based on applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Email details", response = ApplicationEmail.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		 	@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		 	@ApiResponse(code = 400, message = "Bad request", response = ErrorBean.class),
		 	@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/credit/employeeportal/{applicationid}/email", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getEmailDetails(@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestParam  @NotBlank(message = "typeKey can not be null or empty") @Digits(fraction = 0, integer = 10,message = "typeKey should be numeric & should not exceeds size") Long typeKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In getEmailDetails method with applicationid : " + applicationId);
		Email email = employeePortalEmailService.getEmailDetails(applicationId.toString(),typeKey.toString(),headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out getEmailDetails method");
		return new ResponseEntity<>(email, HttpStatus.OK);
		
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE})
	@ApiOperation(value = "Update email id", notes = "Update email for user ", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			 	@ApiResponse(code = 200, message = "Email verification updated successfully.", response = EmailVerificationDetail.class),
			 	@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			 	@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			 	@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
		        @ApiResponse(code = 404, message = "ApplicationId not found",response = ErrorBean.class),
			 	@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PutMapping(value = "/v1/credit/employeeportal/{applicationid}/email", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> saveEmailVerification(
			@PathVariable(name = "applicationid", required = true) @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") Long applicationId, 
			@Valid @RequestBody EmailRequest emailRequest,BindingResult bindingResult,
			@RequestHeader HttpHeaders headers){
		if (bindingResult.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside saveEmailVerification method - Invalid parameters passed");
			throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-1022", bindingResult.getFieldErrors().get(0).getDefaultMessage()));
		}else {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside saveEmailVerification method controller - email resource :" + emailRequest);
			return new ResponseEntity<>(employeePortalEmailService.saveEmailVerification(applicationId.toString(), emailRequest, headers), HttpStatus.OK);
		}
	}

	
}

