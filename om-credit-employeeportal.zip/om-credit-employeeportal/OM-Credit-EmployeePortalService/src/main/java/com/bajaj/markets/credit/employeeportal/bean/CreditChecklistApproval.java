package com.bajaj.markets.credit.employeeportal.bean;

public class CreditChecklistApproval {

	private String businessVintageProof;
	private String covertDone;
	private String dedupeCheckFinal;
	private String deviationCapturedFinal;
	private String emiBankingChecked;
	private String fvDone;
	private String geoTagPicsChecked;
	private String negativeAreaChecked;
	private String ownHouseProof;
	private String recentLoanCreditCheck;
	private String repaymentFromSameAccount;
	private String salesVisitReportChecked;
	private String schemeChange;
	private String degreeExperienceCheck;
	private String addressMatchWithEp;
	private String caseDeviationApproved;
	private String deviationCapturedSoft;
	private String salaryAccountCheckedDoctor;
	private String degreeExperienceCheckSoft;

	public String getBusinessVintageProof() {
		return businessVintageProof;
	}

	public void setBusinessVintageProof(String businessVintageProof) {
		this.businessVintageProof = businessVintageProof;
	}

	public String getCovertDone() {
		return covertDone;
	}

	public void setCovertDone(String covertDone) {
		this.covertDone = covertDone;
	}

	public String getDedupeCheckFinal() {
		return dedupeCheckFinal;
	}

	public void setDedupeCheckFinal(String dedupeCheckFinal) {
		this.dedupeCheckFinal = dedupeCheckFinal;
	}

	public String getDeviationCapturedFinal() {
		return deviationCapturedFinal;
	}

	public void setDeviationCapturedFinal(String deviationCapturedFinal) {
		this.deviationCapturedFinal = deviationCapturedFinal;
	}

	public String getEmiBankingChecked() {
		return emiBankingChecked;
	}

	public void setEmiBankingChecked(String emiBankingChecked) {
		this.emiBankingChecked = emiBankingChecked;
	}

	public String getFvDone() {
		return fvDone;
	}

	public void setFvDone(String fvDone) {
		this.fvDone = fvDone;
	}

	public String getGeoTagPicsChecked() {
		return geoTagPicsChecked;
	}

	public void setGeoTagPicsChecked(String geoTagPicsChecked) {
		this.geoTagPicsChecked = geoTagPicsChecked;
	}

	public String getNegativeAreaChecked() {
		return negativeAreaChecked;
	}

	public void setNegativeAreaChecked(String negativeAreaChecked) {
		this.negativeAreaChecked = negativeAreaChecked;
	}

	public String getOwnHouseProof() {
		return ownHouseProof;
	}

	public void setOwnHouseProof(String ownHouseProof) {
		this.ownHouseProof = ownHouseProof;
	}

	public String getRecentLoanCreditCheck() {
		return recentLoanCreditCheck;
	}

	public void setRecentLoanCreditCheck(String recentLoanCreditCheck) {
		this.recentLoanCreditCheck = recentLoanCreditCheck;
	}

	public String getRepaymentFromSameAccount() {
		return repaymentFromSameAccount;
	}

	public void setRepaymentFromSameAccount(String repaymentFromSameAccount) {
		this.repaymentFromSameAccount = repaymentFromSameAccount;
	}

	public String getSalesVisitReportChecked() {
		return salesVisitReportChecked;
	}

	public void setSalesVisitReportChecked(String salesVisitReportChecked) {
		this.salesVisitReportChecked = salesVisitReportChecked;
	}

	public String getSchemeChange() {
		return schemeChange;
	}

	public void setSchemeChange(String schemeChange) {
		this.schemeChange = schemeChange;
	}

	public String getDegreeExperienceCheck() {
		return degreeExperienceCheck;
	}

	public void setDegreeExperienceCheck(String degreeExperienceCheck) {
		this.degreeExperienceCheck = degreeExperienceCheck;
	}

	public String getAddressMatchWithEp() {
		return addressMatchWithEp;
	}

	public void setAddressMatchWithEp(String addressMatchWithEp) {
		this.addressMatchWithEp = addressMatchWithEp;
	}

	public String getCaseDeviationApproved() {
		return caseDeviationApproved;
	}

	public void setCaseDeviationApproved(String caseDeviationApproved) {
		this.caseDeviationApproved = caseDeviationApproved;
	}

	public String getDeviationCapturedSoft() {
		return deviationCapturedSoft;
	}

	public void setDeviationCapturedSoft(String deviationCapturedSoft) {
		this.deviationCapturedSoft = deviationCapturedSoft;
	}

	public String getSalaryAccountCheckedDoctor() {
		return salaryAccountCheckedDoctor;
	}

	public void setSalaryAccountCheckedDoctor(String salaryAccountCheckedDoctor) {
		this.salaryAccountCheckedDoctor = salaryAccountCheckedDoctor;
	}

	public String getDegreeExperienceCheckSoft() {
		return degreeExperienceCheckSoft;
	}

	public void setDegreeExperienceCheckSoft(String degreeExperienceCheckSoft) {
		this.degreeExperienceCheckSoft = degreeExperienceCheckSoft;
	}

}
