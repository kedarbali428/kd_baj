package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CreateApplicationRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2791466815044255565L;
	
	private String applicationKey;
	private String mobile;
	private String dateOfBirth;
	private Integer l2ProductKey;
	public String getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	public Integer getL2ProductKey() {
		return l2ProductKey;
	}
	
	public void setL2ProductKey(Integer l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}
	/**
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	

}
