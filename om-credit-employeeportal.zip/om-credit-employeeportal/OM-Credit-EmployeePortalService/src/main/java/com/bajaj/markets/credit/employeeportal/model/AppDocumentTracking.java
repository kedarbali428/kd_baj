package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the app_document_tracking database table.
 * 
 */
@Entity
@Table(name="app_document_tracking",schema = "dmcredit")
public class AppDocumentTracking implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long appdocumenttrackingkey;

	private Long applicationkey;

	private String docerrorcode;

	private String docerrordesc;

	private Timestamp docerrordt;

	private Long docsentby;

	private Timestamp docsentdate;

	private String docsentstatus;

	private String docsource;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String partnerrefid;

	//bi-directional many-to-one association to CreditDocumentType
	@ManyToOne
	@JoinColumn(name="creditdoctype")
	private CreditDocumentType creditDocumentType;

	public AppDocumentTracking() {
	}

	public Long getAppdocumenttrackingkey() {
		return this.appdocumenttrackingkey;
	}

	public void setAppdocumenttrackingkey(Long appdocumenttrackingkey) {
		this.appdocumenttrackingkey = appdocumenttrackingkey;
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public String getDocerrorcode() {
		return this.docerrorcode;
	}

	public void setDocerrorcode(String docerrorcode) {
		this.docerrorcode = docerrorcode;
	}

	public String getDocerrordesc() {
		return this.docerrordesc;
	}

	public void setDocerrordesc(String docerrordesc) {
		this.docerrordesc = docerrordesc;
	}

	public Timestamp getDocerrordt() {
		return this.docerrordt;
	}

	public void setDocerrordt(Timestamp docerrordt) {
		this.docerrordt = docerrordt;
	}

	public Long getDocsentby() {
		return this.docsentby;
	}

	public void setDocsentby(Long docsentby) {
		this.docsentby = docsentby;
	}

	public Timestamp getDocsentdate() {
		return this.docsentdate;
	}

	public void setDocsentdate(Timestamp docsentdate) {
		this.docsentdate = docsentdate;
	}

	public String getDocsentstatus() {
		return this.docsentstatus;
	}

	public void setDocsentstatus(String docsentstatus) {
		this.docsentstatus = docsentstatus;
	}

	public String getDocsource() {
		return this.docsource;
	}

	public void setDocsource(String docsource) {
		this.docsource = docsource;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getPartnerrefid() {
		return this.partnerrefid;
	}

	public void setPartnerrefid(String partnerrefid) {
		this.partnerrefid = partnerrefid;
	}

	public CreditDocumentType getCreditDocumentType() {
		return this.creditDocumentType;
	}

	public void setCreditDocumentType(CreditDocumentType creditDocumentType) {
		this.creditDocumentType = creditDocumentType;
	}

}