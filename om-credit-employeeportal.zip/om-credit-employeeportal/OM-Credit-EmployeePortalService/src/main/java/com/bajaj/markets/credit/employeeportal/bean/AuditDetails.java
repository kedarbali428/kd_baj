package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotNull;

public class AuditDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	    private List<FieldList> fieldList;
		
		private String applicationId;

		
		public List<FieldList> getFieldList() {
			return fieldList;
		}

		public void setFieldList(List<FieldList> fieldList) {
			this.fieldList = fieldList;
		}

		public String getApplicationId() {
			return applicationId;
		}

		public void setApplicationId(String applicationId) {
			this.applicationId = applicationId;
		}
		
}
