package com.bajaj.markets.credit.employeeportal.bean;

public class LoanRepaymentSummary {

	private String effectiveRateOfReturn;
	private String totalGracePft;
	private String totalGraceCpz;
	private String totalGrossGrcPft;
	private String totalCpz;
	private String totalProfit;
	private String totalRepayAmt;
	private String feeChargeAmount;
	private String numberOfTerms;
	private String loanTenor;	
	private String maturityDate;
	private String firstEmiAmount;
	private String nextSchDate;
	private String nextRepayAmount;
	private String futureInst;
	private String futureTenor;
	private String firstInstDate;
	private String paidTotal;
	private String paidPri;
	private String paidPft;
	private String lastRepayDate;
	private String outstandingTotal;
	private String outstandingPri;
	private String outstandingPft;
	private String overdueTotal;
	private String overduePri;
	private String overduePft;
	private String overdueInst;
	private String advPaymentAmount;
	private String finActiveStatus;
	private String fullyDisb;
	
	public String getLoanTenor() {
		return loanTenor;
	}

	public void setLoanTenor(String loanTenor) {
		this.loanTenor = loanTenor;
	}

	public String getFirstEmiAmount() {
		return firstEmiAmount;
	}

	public void setFirstEmiAmount(String firstEmiAmount) {
		this.firstEmiAmount = firstEmiAmount;
	}

	public String getNextSchDate() {
		return nextSchDate;
	}

	public void setNextSchDate(String nextSchDate) {
		this.nextSchDate = nextSchDate;
	}

	public String getNextRepayAmount() {
		return nextRepayAmount;
	}

	public void setNextRepayAmount(String nextRepayAmount) {
		this.nextRepayAmount = nextRepayAmount;
	}

	public String getFutureInst() {
		return futureInst;
	}

	public void setFutureInst(String futureInst) {
		this.futureInst = futureInst;
	}

	public String getFutureTenor() {
		return futureTenor;
	}

	public void setFutureTenor(String futureTenor) {
		this.futureTenor = futureTenor;
	}

	public String getFirstInstDate() {
		return firstInstDate;
	}

	public void setFirstInstDate(String firstInstDate) {
		this.firstInstDate = firstInstDate;
	}

	public String getPaidTotal() {
		return paidTotal;
	}

	public void setPaidTotal(String paidTotal) {
		this.paidTotal = paidTotal;
	}

	public String getPaidPri() {
		return paidPri;
	}

	public void setPaidPri(String paidPri) {
		this.paidPri = paidPri;
	}

	public String getPaidPft() {
		return paidPft;
	}

	public void setPaidPft(String paidPft) {
		this.paidPft = paidPft;
	}

	public String getLastRepayDate() {
		return lastRepayDate;
	}

	public void setLastRepayDate(String lastRepayDate) {
		this.lastRepayDate = lastRepayDate;
	}

	public String getOutstandingTotal() {
		return outstandingTotal;
	}

	public void setOutstandingTotal(String outstandingTotal) {
		this.outstandingTotal = outstandingTotal;
	}

	public String getOutstandingPri() {
		return outstandingPri;
	}

	public void setOutstandingPri(String outstandingPri) {
		this.outstandingPri = outstandingPri;
	}

	public String getOutstandingPft() {
		return outstandingPft;
	}

	public void setOutstandingPft(String outstandingPft) {
		this.outstandingPft = outstandingPft;
	}

	public String getOverdueTotal() {
		return overdueTotal;
	}

	public void setOverdueTotal(String overdueTotal) {
		this.overdueTotal = overdueTotal;
	}

	public String getOverduePri() {
		return overduePri;
	}

	public void setOverduePri(String overduePri) {
		this.overduePri = overduePri;
	}

	public String getOverduePft() {
		return overduePft;
	}

	public void setOverduePft(String overduePft) {
		this.overduePft = overduePft;
	}

	public String getOverdueInst() {
		return overdueInst;
	}

	public void setOverdueInst(String overdueInst) {
		this.overdueInst = overdueInst;
	}

	public String getAdvPaymentAmount() {
		return advPaymentAmount;
	}

	public void setAdvPaymentAmount(String advPaymentAmount) {
		this.advPaymentAmount = advPaymentAmount;
	}

	public String getFinActiveStatus() {
		return finActiveStatus;
	}

	public void setFinActiveStatus(String finActiveStatus) {
		this.finActiveStatus = finActiveStatus;
	}

	public String getFullyDisb() {
		return fullyDisb;
	}

	public void setFullyDisb(String fullyDisb) {
		this.fullyDisb = fullyDisb;
	}

	public String getEffectiveRateOfReturn() {
		return effectiveRateOfReturn;
	}

	public void setEffectiveRateOfReturn(String effectiveRateOfReturn) {
		this.effectiveRateOfReturn = effectiveRateOfReturn;
	}

	public String getTotalGracePft() {
		return totalGracePft;
	}

	public void setTotalGracePft(String totalGracePft) {
		this.totalGracePft = totalGracePft;
	}

	public String getTotalGraceCpz() {
		return totalGraceCpz;
	}

	public void setTotalGraceCpz(String totalGraceCpz) {
		this.totalGraceCpz = totalGraceCpz;
	}

	public String getTotalGrossGrcPft() {
		return totalGrossGrcPft;
	}

	public void setTotalGrossGrcPft(String totalGrossGrcPft) {
		this.totalGrossGrcPft = totalGrossGrcPft;
	}

	public String getTotalCpz() {
		return totalCpz;
	}

	public void setTotalCpz(String totalCpz) {
		this.totalCpz = totalCpz;
	}

	public String getTotalProfit() {
		return totalProfit;
	}

	public void setTotalProfit(String totalProfit) {
		this.totalProfit = totalProfit;
	}

	public String getTotalRepayAmt() {
		return totalRepayAmt;
	}

	public void setTotalRepayAmt(String totalRepayAmt) {
		this.totalRepayAmt = totalRepayAmt;
	}

	public String getFeeChargeAmount() {
		return feeChargeAmount;
	}

	public void setFeeChargeAmount(String feeChargeAmount) {
		this.feeChargeAmount = feeChargeAmount;
	}

	public String getNumberOfTerms() {
		return numberOfTerms;
	}

	public void setNumberOfTerms(String numberOfTerms) {
		this.numberOfTerms = numberOfTerms;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

}
