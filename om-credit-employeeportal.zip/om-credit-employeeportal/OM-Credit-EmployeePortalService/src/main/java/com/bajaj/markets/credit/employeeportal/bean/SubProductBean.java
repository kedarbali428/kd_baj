package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

public class SubProductBean {

	private BigDecimal loanProdKey;
	private String loanProdDesc;
	private String loanProdCode;
	
	public BigDecimal getLoanProdKey() {
		return loanProdKey;
	}
	public void setLoanProdKey(BigDecimal loanProdKey) {
		this.loanProdKey = loanProdKey;
	}
	public String getLoanProdDesc() {
		return loanProdDesc;
	}
	public void setLoanProdDesc(String loanProdDesc) {
		this.loanProdDesc = loanProdDesc;
	}
	public String getLoanProdCode() {
		return loanProdCode;
	}
	public void setLoanProdCode(String loanProdCode) {
		this.loanProdCode = loanProdCode;
	}
}
