package com.bajaj.markets.credit.employeeportal.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.AppAssignmentInputBean;
import com.bajaj.markets.credit.employeeportal.bean.AppAssignmentResponseBean;
import com.bajaj.markets.credit.employeeportal.bean.OwnerResponseBean;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalAllocationService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EmployeePortalAllocationController {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private EmployeePortalAllocationService allocationService;
	
	private static final String CLASSNAME = EmployeePortalAllocationController.class.getName();
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch the list of previous owners of an application", notes = "Fetch the list of previous owners of an application", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
	@ApiResponse(code = 200, message = "Previous Owner details", response = OwnerResponseBean.class),
	@ApiResponse(code = 404, message = "Previous owner details not found", response = ErrorBean.class),
	@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@RequestMapping(value = "/v1/employeeportal/{applicationId}/assignment", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getPreOwnerList(@PathVariable("applicationId") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		List<OwnerResponseBean> previousOwnersList = new ArrayList<>();
		previousOwnersList = allocationService.getPreOwnerList(applicationId,headers);
		return new ResponseEntity<>(previousOwnersList, headers, HttpStatus.OK);
	}
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Assign appliction to self or user or previous user or role.", notes = "Assign application.")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
	@ApiResponse(code = 200, message = "Assign application to self or others", response = AppAssignmentResponseBean.class),
	@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
	@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@RequestMapping(value = "/v1/employeeportal/{applicationId}/assignment", method = RequestMethod.POST)
	@CrossOrigin
	public ResponseEntity<?> appAssignment(@PathVariable("applicationId") Long applicationId,@RequestBody AppAssignmentInputBean inputBean,
			 @RequestHeader HttpHeaders headers) {
		AppAssignmentResponseBean result = new AppAssignmentResponseBean();
		result = allocationService.appAssignmentToUser(applicationId,inputBean,headers);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
}
