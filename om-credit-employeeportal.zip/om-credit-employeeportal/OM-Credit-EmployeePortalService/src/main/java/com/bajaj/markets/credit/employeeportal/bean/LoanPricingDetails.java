package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

public class LoanPricingDetails {

	private String prodkey;
	private Integer totalEligibility;
	private Integer requiredLoanAmount;
	private BigDecimal loanAmountInsAndVas;
	private String loanType;
	private Integer emiAmount;
	private Integer isEmiAmount;
	private Integer droplineEmiAmount;
	private Integer emiCycleDate;
	private Integer tenor;
	private BigDecimal isTenor;
	private BigDecimal droplineTenor;
	private BigDecimal baseInterestRate;
	private BigDecimal interestRateAfterInsVas;
	private BigDecimal finalInterestRate;
	private Integer processingFee;
	private Integer convenienceFee;
	private Integer stampFee;
	private Integer amcCharges;
	private String vasProductAvailed;
	private String vasProductName;
	private Integer vasProductFee;
	private String pricingType;
	private String pricingStatus;
	private String raisedBy;
	private Timestamp raisedDateAndTime;
	private String approvedBy;
	private Timestamp approvedDateAndTime;
	private Date firstDueDate;
	private Integer netDisbursementAmount;
	private Integer pricingFlag ;

	public Integer getPricingFlag() {
		return pricingFlag;
	}

	public void setPricingFlag(Integer pricingFlag) {
		this.pricingFlag = pricingFlag;
	}

	public String getProdkey() {
		return prodkey;
	}

	public void setProdkey(String prodkey) {
		this.prodkey = prodkey;
	}

	public Integer getTotalEligibility() {
		return totalEligibility;
	}

	public void setTotalEligibility(Integer totalEligibility) {
		this.totalEligibility = totalEligibility;
	}

	public Integer getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	public void setRequiredLoanAmount(Integer requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	public BigDecimal getLoanAmountInsAndVas() {
		return loanAmountInsAndVas;
	}

	public void setLoanAmountInsAndVas(BigDecimal loanAmountInsAndVas) {
		this.loanAmountInsAndVas = loanAmountInsAndVas;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public Integer getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(Integer emiAmount) {
		this.emiAmount = emiAmount;
	}

	public Integer getIsEmiAmount() {
		return isEmiAmount;
	}

	public void setIsEmiAmount(Integer isEmiAmount) {
		this.isEmiAmount = isEmiAmount;
	}

	public Integer getDroplineEmiAmount() {
		return droplineEmiAmount;
	}

	public void setDroplineEmiAmount(Integer droplineEmiAmount) {
		this.droplineEmiAmount = droplineEmiAmount;
	}

	public Integer getEmiCycleDate() {
		return emiCycleDate;
	}

	public void setEmiCycleDate(Integer emiCycleDate) {
		this.emiCycleDate = emiCycleDate;
	}

	public Integer getTenor() {
		return tenor;
	}

	public void setTenor(Integer tenor) {
		this.tenor = tenor;
	}

	public BigDecimal getIsTenor() {
		return isTenor;
	}

	public void setIsTenor(BigDecimal isTenor) {
		this.isTenor = isTenor;
	}

	public BigDecimal getDroplineTenor() {
		return droplineTenor;
	}

	public void setDroplineTenor(BigDecimal droplineTenor) {
		this.droplineTenor = droplineTenor;
	}

	public BigDecimal getBaseInterestRate() {
		return baseInterestRate;
	}

	public void setBaseInterestRate(BigDecimal baseInterestRate) {
		this.baseInterestRate = baseInterestRate;
	}

	public BigDecimal getInterestRateAfterInsVas() {
		return interestRateAfterInsVas;
	}

	public void setInterestRateAfterInsVas(BigDecimal interestRateAfterInsVas) {
		this.interestRateAfterInsVas = interestRateAfterInsVas;
	}

	public BigDecimal getFinalInterestRate() {
		return finalInterestRate;
	}

	public void setFinalInterestRate(BigDecimal finalInterestRate) {
		this.finalInterestRate = finalInterestRate;
	}

	public Integer getProcessingFee() {
		return processingFee;
	}

	public void setProcessingFee(Integer processingFee) {
		this.processingFee = processingFee;
	}

	public Integer getConvenienceFee() {
		return convenienceFee;
	}

	public void setConvenienceFee(Integer convenienceFee) {
		this.convenienceFee = convenienceFee;
	}

	public Integer getStampFee() {
		return stampFee;
	}

	public void setStampFee(Integer stampFee) {
		this.stampFee = stampFee;
	}

	public Integer getAmcCharges() {
		return amcCharges;
	}

	public void setAmcCharges(Integer amcCharges) {
		this.amcCharges = amcCharges;
	}

	public String getVasProductAvailed() {
		return vasProductAvailed;
	}

	public void setVasProductAvailed(String vasProductAvailed) {
		this.vasProductAvailed = vasProductAvailed;
	}

	public String getVasProductName() {
		return vasProductName;
	}

	public void setVasProductName(String vasProductName) {
		this.vasProductName = vasProductName;
	}

	public Integer getVasProductFee() {
		return vasProductFee;
	}

	public void setVasProductFee(Integer vasProductFee) {
		this.vasProductFee = vasProductFee;
	}

	public String getPricingType() {
		return pricingType;
	}

	public void setPricingType(String pricingType) {
		this.pricingType = pricingType;
	}

	public String getPricingStatus() {
		return pricingStatus;
	}

	public void setPricingStatus(String pricingStatus) {
		this.pricingStatus = pricingStatus;
	}

	public String getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;
	}

	public Timestamp getRaisedDateAndTime() {
		return raisedDateAndTime;
	}

	public void setRaisedDateAndTime(Timestamp raisedDateAndTime) {
		this.raisedDateAndTime = raisedDateAndTime;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Timestamp getApprovedDateAndTime() {
		return approvedDateAndTime;
	}

	public void setApprovedDateAndTime(Timestamp approvedDateAndTime) {
		this.approvedDateAndTime = approvedDateAndTime;
	}

	public Date getFirstDueDate() {
		return firstDueDate;
	}

	public void setFirstDueDate(Date firstDueDate) {
		this.firstDueDate = firstDueDate;
	}

	public Integer getNetDisbursementAmount() {
		return netDisbursementAmount;
	}

	public void setNetDisbursementAmount(Integer netDisbursementAmount) {
		this.netDisbursementAmount = netDisbursementAmount;
	}

}
