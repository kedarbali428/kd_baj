package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "application", schema = "dmvas")
public class ApplicationVas implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "application_applicationkey_generator", sequenceName = "dmvas.seq_pk_application", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_applicationkey_generator")
	private Long applicationkey;
	private Long applicantkey;
	private Long mobilenumber;
	private Date dateofbirth;
	private String firstname;
	private String lastname;
	private String middlename;
	private Long sourceapplicationkey;
	private Integer plankey;
	private Integer appstatus;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private Integer prodkey;
	private Integer sourceprodcatkey;
	private Integer sourceprodmastkey;
	private String invoicestatus;
	private String invoicenum;
	private Timestamp invoiceissuedt;
	
	@OneToMany(mappedBy = "applicationkey", cascade = CascadeType.ALL)
	private Set<ApplicationAttributeVas> applicationAttributeVas;

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(Long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public Long getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(Long mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public Long getSourceapplicationkey() {
		return sourceapplicationkey;
	}

	public void setSourceapplicationkey(Long sourceapplicationkey) {
		this.sourceapplicationkey = sourceapplicationkey;
	}

	public Integer getPlankey() {
		return plankey;
	}

	public void setPlankey(Integer plankey) {
		this.plankey = plankey;
	}

	public Integer getAppstatus() {
		return appstatus;
	}

	public void setAppstatus(Integer appstatus) {
		this.appstatus = appstatus;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Integer getProdkey() {
		return prodkey;
	}

	public void setProdkey(Integer prodkey) {
		this.prodkey = prodkey;
	}

	public Integer getSourceprodcatkey() {
		return sourceprodcatkey;
	}

	public void setSourceprodcatkey(Integer sourceprodcatkey) {
		this.sourceprodcatkey = sourceprodcatkey;
	}

	public Integer getSourceprodmastkey() {
		return sourceprodmastkey;
	}

	public void setSourceprodmastkey(Integer sourceprodmastkey) {
		this.sourceprodmastkey = sourceprodmastkey;
	}

	/**
	 * @return the applicationAttributeVas
	 */
	public Set<ApplicationAttributeVas> getApplicationAttributeVas() {
		return applicationAttributeVas;
	}

	/**
	 * @param applicationAttributeVas the applicationAttributeVas to set
	 */
	public void setApplicationAttributeVas(Set<ApplicationAttributeVas> applicationAttributeVas) {
		this.applicationAttributeVas = applicationAttributeVas;
	}

	public String getInvoicestatus() {
		return invoicestatus;
	}

	public void setInvoicestatus(String invoicestatus) {
		this.invoicestatus = invoicestatus;
	}

	public String getInvoicenum() {
		return invoicenum;
	}

	public void setInvoicenum(String invoicenum) {
		this.invoicenum = invoicenum;
	}

	public Timestamp getInvoiceissuedt() {
		return invoiceissuedt;
	}

	public void setInvoiceissuedt(Timestamp invoiceissuedt) {
		this.invoiceissuedt = invoiceissuedt;
	}

}
