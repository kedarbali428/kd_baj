package com.bajaj.markets.credit.employeeportal.bean;

public class PerfiosFraudDetails {
	private String fraudIndicator;
	private String pan;
	private String email;	
	private String mobile;
	private String landline;
	private String address;
	private String customerName;
	private String authenticity;
	/**
	 * @return the fraudIndicator
	 */
	public String getFraudIndicator() {
		return fraudIndicator;
	}
	/**
	 * @param fraudIndicator the fraudIndicator to set
	 */
	public void setFraudIndicator(String fraudIndicator) {
		this.fraudIndicator = fraudIndicator;
	}
	/**
	 * @return the pan
	 */
	public String getPan() {
		return pan;
	}
	/**
	 * @param pan the pan to set
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}
	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	/**
	 * @return the landline
	 */
	public String getLandline() {
		return landline;
	}
	/**
	 * @param landline the landline to set
	 */
	public void setLandline(String landline) {
		this.landline = landline;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the authenticity
	 */
	public String getAuthenticity() {
		return authenticity;
	}
	/**
	 * @param authenticity the authenticity to set
	 */
	public void setAuthenticity(String authenticity) {
		this.authenticity = authenticity;
	}
}
