package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class OPSDisbApprovalDetail implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String approvalStatus;
	private String statusUpdatedBy;
	private Timestamp statusUpdatedDateTime;
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public String getStatusUpdatedBy() {
		return statusUpdatedBy;
	}
	public void setStatusUpdatedBy(String statusUpdatedBy) {
		this.statusUpdatedBy = statusUpdatedBy;
	}
	public Timestamp getStatusUpdatedDateTime() {
		return statusUpdatedDateTime;
	}
	public void setStatusUpdatedDateTime(Timestamp statusUpdatedDateTime) {
		this.statusUpdatedDateTime = statusUpdatedDateTime;
	}
}