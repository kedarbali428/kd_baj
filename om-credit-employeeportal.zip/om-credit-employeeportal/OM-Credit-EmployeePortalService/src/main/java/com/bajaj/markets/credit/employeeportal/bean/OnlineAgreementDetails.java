package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class OnlineAgreementDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String onlineAgreementTyp;
	private String onlineConsentMobileNumber;
	private String ipAddress;
	private Timestamp esignConsentDatetime;
	private String esignConsentStatus;
	private String onlineConsentStatus;
	private String onlineConsentSuspendedReason;

	public String getOnlineAgreementTyp() {
		return onlineAgreementTyp;
	}

	public void setOnlineAgreementTyp(String onlineAgreementTyp) {
		this.onlineAgreementTyp = onlineAgreementTyp;
	}

	public String getOnlineConsentMobileNumber() {
		return onlineConsentMobileNumber;
	}

	public void setOnlineConsentMobileNumber(String onlineConsentMobileNumber) {
		this.onlineConsentMobileNumber = onlineConsentMobileNumber;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Timestamp getEsignConsentDatetime() {
		return esignConsentDatetime;
	}

	public void setEsignConsentDatetime(Timestamp esignConsentDatetime) {
		this.esignConsentDatetime = esignConsentDatetime;
	}

	public String getEsignConsentStatus() {
		return esignConsentStatus;
	}

	public void setEsignConsentStatus(String esignConsentStatus) {
		this.esignConsentStatus = esignConsentStatus;
	}

	public String getOnlineConsentStatus() {
		return onlineConsentStatus;
	}

	public void setOnlineConsentStatus(String onlineConsentStatus) {
		this.onlineConsentStatus = onlineConsentStatus;
	}

	public String getOnlineConsentSuspendedReason() {
		return onlineConsentSuspendedReason;
	}

	public void setOnlineConsentSuspendedReason(String onlineConsentSuspendedReason) {
		this.onlineConsentSuspendedReason = onlineConsentSuspendedReason;
	}
}
