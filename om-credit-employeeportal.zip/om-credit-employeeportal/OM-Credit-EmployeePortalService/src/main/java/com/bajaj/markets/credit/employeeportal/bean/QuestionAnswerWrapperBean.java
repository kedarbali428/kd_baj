package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotEmpty;

/* Bean to hold required data of Questions and answers
*/
public class QuestionAnswerWrapperBean implements Serializable {
	private static final long serialVersionUID = 6663535287565983407L;

	private String applicationKey;
	
	@NotEmpty(message = "There should be atleast one question and answer set")
	List<QuestionAnswer> questionAnswerList;
	
	Boolean rejectStatus;
	List<String> rejectCodes;
	
    public QuestionAnswerWrapperBean() {
    	//No arg constructor
	}

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public List<QuestionAnswer> getQuestionAnswerList() {
		return questionAnswerList;
	}

	public void setQuestionAnswerList(List<QuestionAnswer> questionAnswerList) {
		this.questionAnswerList = questionAnswerList;
	}

	public Boolean getRejectStatus() {
		return rejectStatus;
	}

	public void setRejectStatus(Boolean rejectStatus) {
		this.rejectStatus = rejectStatus;
	}

	public List<String> getRejectCodes() {
		return rejectCodes;
	}

	public void setRejectCodes(List<String> rejectCodes) {
		this.rejectCodes = rejectCodes;
	}

	@Override
	public String toString() {
		return "QuestionAnswerWrapperBean [applicationKey=" + applicationKey + ", questionAnswerList="
				+ questionAnswerList + ", rejectStatus=" + rejectStatus + ", rejectCodes=" + rejectCodes + "]";
	}

}