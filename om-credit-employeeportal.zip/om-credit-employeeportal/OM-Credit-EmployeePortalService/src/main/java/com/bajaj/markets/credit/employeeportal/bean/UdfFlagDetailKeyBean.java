package com.bajaj.markets.credit.employeeportal.bean;

public class UdfFlagDetailKeyBean {

	private long appudfverificationkey;
	private String message;
	public long getAppudfverificationkey() {
		return appudfverificationkey;
	}
	public void setAppudfverificationkey(long appudfverificationkey) {
		this.appudfverificationkey = appudfverificationkey;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
