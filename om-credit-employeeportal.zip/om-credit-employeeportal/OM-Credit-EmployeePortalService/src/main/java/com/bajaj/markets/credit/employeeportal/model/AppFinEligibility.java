package com.bajaj.markets.credit.employeeportal.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="app_fin_eligibility" , schema="dmcredit")
public class AppFinEligibility {
	
	@Id
	private Long appfineligibilitykey;
	
	private Long applicationkey;
	
	private Integer  finalunsecuredfoir;
	
	private Integer applicablemultiplier;
	
	private Integer multipliereligibility;
	
	private Integer finalfoir;
	
	private Integer finalmultiplier;
	
	private Integer maxemiasperfoir;
	
	private Integer foireligibilityemi;
	
	private Integer imputedsalary;
	
	private Integer isactive;
	
	private Long lstupdateby;

	private Long appprodlistkey;

	private Integer eligibilityAmount;

	public Long getAppfineligibilitykey() {
		return appfineligibilitykey;
	}

	public void setAppfineligibilitykey(Long appfineligibilitykey) {
		this.appfineligibilitykey = appfineligibilitykey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getFinalunsecuredfoir() {
		return finalunsecuredfoir;
	}

	public void setFinalunsecuredfoir(Integer finalunsecuredfoir) {
		this.finalunsecuredfoir = finalunsecuredfoir;
	}

	public Integer getApplicablemultiplier() {
		return applicablemultiplier;
	}

	public void setApplicablemultiplier(Integer applicablemultiplier) {
		this.applicablemultiplier = applicablemultiplier;
	}

	public Integer getMultipliereligibility() {
		return multipliereligibility;
	}

	public void setMultipliereligibility(Integer multipliereligibility) {
		this.multipliereligibility = multipliereligibility;
	}

	public Integer getFinalfoir() {
		return finalfoir;
	}

	public void setFinalfoir(Integer finalfoir) {
		this.finalfoir = finalfoir;
	}

	public Integer getFinalmultiplier() {
		return finalmultiplier;
	}

	public void setFinalmultiplier(Integer finalmultiplier) {
		this.finalmultiplier = finalmultiplier;
	}

	public Integer getMaxemiasperfoir() {
		return maxemiasperfoir;
	}

	public void setMaxemiasperfoir(Integer maxemiasperfoir) {
		this.maxemiasperfoir = maxemiasperfoir;
	}

	public Integer getFoireligibilityemi() {
		return foireligibilityemi;
	}

	public void setFoireligibilityemi(Integer foireligibilityemi) {
		this.foireligibilityemi = foireligibilityemi;
	}

	public Integer getImputedsalary() {
		return imputedsalary;
	}

	public void setImputedsalary(Integer imputedsalary) {
		this.imputedsalary = imputedsalary;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Long getAppprodlistkey() {
		return appprodlistkey;
	}

	public void setAppprodlistkey(Long appprodlistkey) {
		this.appprodlistkey = appprodlistkey;
	}

	public Integer getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(Integer eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

}
