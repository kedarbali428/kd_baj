package com.bajaj.markets.credit.employeeportal.bean;

public class BureauGeneralDetails {

	private String bureauName;

	private String score;

	private String dateprocessed;

	private String nullValue;

	private String cibilScoreV3;

	private String additionalMatchFlag;

	/**
	 * @return the bureauName
	 */
	public String getBureauName() {
		return bureauName;
	}

	/**
	 * @param bureauName the bureauName to set
	 */
	public void setBureauName(String bureauName) {
		this.bureauName = bureauName;
	}

	/**
	 * @return the score
	 */
	public String getScore() {
		return score;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(String score) {
		this.score = score;
	}

	/**
	 * @return the dateprocessed
	 */
	public String getDateprocessed() {
		return dateprocessed;
	}

	/**
	 * @param dateprocessed the dateprocessed to set
	 */
	public void setDateprocessed(String dateprocessed) {
		this.dateprocessed = dateprocessed;
	}

	/**
	 * @return the nullValue
	 */
	public String getNullValue() {
		return nullValue;
	}

	/**
	 * @param nullValue the nullValue to set
	 */
	public void setNullValue(String nullValue) {
		this.nullValue = nullValue;
	}

	public String getCibilScoreV3() {
		return cibilScoreV3;
	}

	public void setCibilScoreV3(String cibilScoreV3) {
		this.cibilScoreV3 = cibilScoreV3;
	}

	public String getAdditionalMatchFlag() {
		return additionalMatchFlag;
	}

	public void setAdditionalMatchFlag(String additionalMatchFlag) {
		this.additionalMatchFlag = additionalMatchFlag;
	}

}
