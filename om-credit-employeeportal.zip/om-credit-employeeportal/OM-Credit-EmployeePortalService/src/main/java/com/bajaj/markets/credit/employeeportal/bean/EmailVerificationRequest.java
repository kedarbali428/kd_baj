package com.bajaj.markets.credit.employeeportal.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


public class EmailVerificationRequest {
	
	@NotNull(message = "applicantId cannot be null or empty")
	@Digits(fraction = 0, integer = 20, message = "applicantId cannot be in fraction & should not exceed size")
	@Min(value = 1, message = "applicantId must be greater than zero")
	private Long applicantId;
	
	@Digits(fraction = 0, integer = 20, message = "applicationId cannot be in fraction & should not exceed size")
	@NotNull(message = "applicationId cannot be null or empty")
	@Min(value = 1, message = "applicationId must be greater than zero")
	private Long applicationId;
	
	@Digits(fraction = 0, integer = 20, message = "productCatkey cannot be in fraction & should not exceed size")
	@NotNull(message = "productCatkey cannot be null or empty")
	@Min(value = 1, message = "productCatkey must be greater than zero")
	private Long productCatkey;
	
	@Digits(fraction = 0, integer = 20, message = "productMastserkey cannot be in fraction & should not exceed size")
	@NotNull(message = "productMastserkey cannot be null or empty")
	@Min(value = 1, message = "productMastserkey must be greater than zero")
	private Integer productMastserkey;
	
	@Pattern(regexp = "PERSONAL|OFFICIAL", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Please enter a valid emailType - PERSONAL|OFFICIAL")
    @NotBlank(message = "emailType can not be null/empty")
	private String emailType; // PERSONAL,
	
	@Digits(fraction = 0, integer = 20, message = "parentApplicationKey is not valid")
	private String parentApplicationKey;

	public Long getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Long getProductCatkey() {
		return productCatkey;
	}

	public void setProductCatkey(Long productCatkey) {
		this.productCatkey = productCatkey;
	}

	public Integer getProductMastserkey() {
		return productMastserkey;
	}

	public void setProductMastserkey(Integer productMastserkey) {
		this.productMastserkey = productMastserkey;
	}

	public String getEmailType() {
		return emailType;
	}

	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}

	public String getParentApplicationKey() {
		return parentApplicationKey;
	}

	public void setParentApplicationKey(String parentApplicationKey) {
		this.parentApplicationKey = parentApplicationKey;
	}
	
}
