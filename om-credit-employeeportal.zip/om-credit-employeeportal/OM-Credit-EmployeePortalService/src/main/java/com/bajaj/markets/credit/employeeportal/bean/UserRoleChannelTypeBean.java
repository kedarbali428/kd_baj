package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class UserRoleChannelTypeBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long userchannelkey;
	private long userprodkey;
	private long channeltypekey;
	private Boolean isactive;
	public long getUserchannelkey() {
		return userchannelkey;
	}
	public void setUserchannelkey(long userchannelkey) {
		this.userchannelkey = userchannelkey;
	}
	public long getUserprodkey() {
		return userprodkey;
	}
	public void setUserprodkey(long userprodkey) {
		this.userprodkey = userprodkey;
	}
	public long getChanneltypekey() {
		return channeltypekey;
	}
	public void setChanneltypekey(long channeltypekey) {
		this.channeltypekey = channeltypekey;
	}
	public Boolean getIsactive() {
		return isactive;
	}
	public void setIsactive(Boolean isactive) {
		this.isactive = isactive;
	}
	
}
