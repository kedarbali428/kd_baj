package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.math.BigDecimal;
/**
 *
 * @author Pranoti.Pandole
 */
public class EmailTypesBean implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private Long emailtypekey;

	private String emailtypecode;

	private String emailtypedesc;

	private BigDecimal emailtypeisactive;

	private BigDecimal emailtypepriority;

	public Long getEmailtypekey() {
		return emailtypekey;
	}

	public void setEmailtypekey(Long emailtypekey) {
		this.emailtypekey = emailtypekey;
	}

	public String getEmailtypecode() {
		return emailtypecode;
	}

	public void setEmailtypecode(String emailtypecode) {
		this.emailtypecode = emailtypecode;
	}

	public String getEmailtypedesc() {
		return emailtypedesc;
	}

	public void setEmailtypedesc(String emailtypedesc) {
		this.emailtypedesc = emailtypedesc;
	}

	public BigDecimal getEmailtypeisactive() {
		return emailtypeisactive;
	}

	public void setEmailtypeisactive(BigDecimal emailtypeisactive) {
		this.emailtypeisactive = emailtypeisactive;
	}

	public BigDecimal getEmailtypepriority() {
		return emailtypepriority;
	}

	public void setEmailtypepriority(BigDecimal emailtypepriority) {
		this.emailtypepriority = emailtypepriority;
	}
}
