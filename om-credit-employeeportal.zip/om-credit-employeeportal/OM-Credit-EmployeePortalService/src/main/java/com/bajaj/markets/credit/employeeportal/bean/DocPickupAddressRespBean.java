package com.bajaj.markets.credit.employeeportal.bean;

public class DocPickupAddressRespBean {

	private AdditionalParameterDetail additionalParameterDetail;

	private AddressReqInput openAddressReqInput;

	/**
	 * @return the additionalParameterDetail
	 */
	public AdditionalParameterDetail getAdditionalParameterDetail() {
		return additionalParameterDetail;
	}

	/**
	 * @param additionalParameterDetail the additionalParameterDetail to set
	 */
	public void setAdditionalParameterDetail(AdditionalParameterDetail additionalParameterDetail) {
		this.additionalParameterDetail = additionalParameterDetail;
	}

	public AddressReqInput getOpenAddressReqInput() {
		return openAddressReqInput;
	}

	public void setOpenAddressReqInput(AddressReqInput openAddressReqInput) {
		this.openAddressReqInput = openAddressReqInput;
	}

}