package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import javax.validation.constraints.NotNull;

/**
 * Application Field Set Attribute Details resource 
 * @author 736919
 * 
 */
public class SubSection {
    
    @NotNull(message = "name cannot be null or empty")
	private String name;
	
	
	@NotNull(message = "subSectionId cannot be null or empty")
	private Long subSectionId;
	
	private String description;
	
	private Integer subsectioncd;
	
	private String source;
	
	private String applicationId;
	
	private List<ApplicationFieldSetAttributes> fieldSetAttributeList;
	
	private String sectionCd;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the subSectionId
	 */
	public Long getSubSectionId() {
		return subSectionId;
	}

	/**
	 * @param subSectionId the subSectionId to set
	 */
	public void setSubSectionId(Long subSectionId) {
		this.subSectionId = subSectionId;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the fieldSetAttributeList
	 */
	public List<ApplicationFieldSetAttributes> getFieldSetAttributeList() {
		return fieldSetAttributeList;
	}

	/**
	 * @param fieldSetAttributeList the fieldSetAttributeList to set
	 */
	public void setFieldSetAttributeList(List<ApplicationFieldSetAttributes> fieldSetAttributeList) {
		this.fieldSetAttributeList = fieldSetAttributeList;
	}
	
	

	public Integer getSubsectioncd() {
		return subsectioncd;
	}

	public void setSubsectioncd(Integer subsectioncd) {
		this.subsectioncd = subsectioncd;
	}

	@Override
	public String toString() {
		return "SubSection [name=" + name + ", subSectionId=" + subSectionId + ", description=" + description
				+ ", subsectioncd=" + subsectioncd + ", fieldSetAttributeList=" + fieldSetAttributeList + "]";
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return the applicationId
	 */
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * @return the sectionCd
	 */
	public String getSectionCd() {
		return sectionCd;
	}

	/**
	 * @param sectionCd the sectionCd to set
	 */
	public void setSectionCd(String sectionCd) {
		this.sectionCd = sectionCd;
	}

	

	


}
