package com.bajaj.markets.credit.employeeportal.bean;

import java.sql.Timestamp;

public class DocumentPushDetails {

	private String partnerName;
	private String productName;
	private String documentCategoryCode;
	private String documentCategoryDescription;
	private String partnerDocumentType;
	private String partnerDocumentName;
	private Integer fileSize;
	private String documentFormat;
	private String partnerReferenceId;
	private String documentStatus;
	private String documentSentBy;
	private Timestamp documentSentDateAndTime;
	private String documentErrorCode;
	private String documentErrorDescription;

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDocumentCategoryCode() {
		return documentCategoryCode;
	}

	public void setDocumentCategoryCode(String documentCategoryCode) {
		this.documentCategoryCode = documentCategoryCode;
	}

	public String getDocumentCategoryDescription() {
		return documentCategoryDescription;
	}

	public void setDocumentCategoryDescription(String documentCategoryDescription) {
		this.documentCategoryDescription = documentCategoryDescription;
	}

	public String getPartnerDocumentType() {
		return partnerDocumentType;
	}

	public void setPartnerDocumentType(String partnerDocumentType) {
		this.partnerDocumentType = partnerDocumentType;
	}

	public String getPartnerDocumentName() {
		return partnerDocumentName;
	}

	public void setPartnerDocumentName(String partnerDocumentName) {
		this.partnerDocumentName = partnerDocumentName;
	}

	public Integer getFileSize() {
		return fileSize;
	}

	public void setFileSize(Integer fileSize) {
		this.fileSize = fileSize;
	}

	public String getDocumentFormat() {
		return documentFormat;
	}

	public void setDocumentFormat(String documentFormat) {
		this.documentFormat = documentFormat;
	}

	public String getPartnerReferenceId() {
		return partnerReferenceId;
	}

	public void setPartnerReferenceId(String partnerReferenceId) {
		this.partnerReferenceId = partnerReferenceId;
	}

	public String getDocumentStatus() {
		return documentStatus;
	}

	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}

	public String getDocumentSentBy() {
		return documentSentBy;
	}

	public void setDocumentSentBy(String documentSentBy) {
		this.documentSentBy = documentSentBy;
	}

	public Timestamp getDocumentSentDateAndTime() {
		return documentSentDateAndTime;
	}

	public void setDocumentSentDateAndTime(Timestamp documentSentDateAndTime) {
		this.documentSentDateAndTime = documentSentDateAndTime;
	}

	public String getDocumentErrorCode() {
		return documentErrorCode;
	}

	public void setDocumentErrorCode(String documentErrorCode) {
		this.documentErrorCode = documentErrorCode;
	}

	public String getDocumentErrorDescription() {
		return documentErrorDescription;
	}

	public void setDocumentErrorDescription(String documentErrorDescription) {
		this.documentErrorDescription = documentErrorDescription;
	}

}