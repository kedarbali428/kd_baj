package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class Reports implements Serializable {

	private static final long serialVersionUID = 1L;

	private String posidexReport;
	private String rtOfferRuleAndAmountReport;

	public String getPosidexReport() {
		return posidexReport;
	}

	public void setPosidexReport(String posidexReport) {
		this.posidexReport = posidexReport;
	}

	public String getRtOfferRuleAndAmountReport() {
		return rtOfferRuleAndAmountReport;
	}

	public void setRtOfferRuleAndAmountReport(String rtOfferRuleAndAmountReport) {
		this.rtOfferRuleAndAmountReport = rtOfferRuleAndAmountReport;
	}
}
