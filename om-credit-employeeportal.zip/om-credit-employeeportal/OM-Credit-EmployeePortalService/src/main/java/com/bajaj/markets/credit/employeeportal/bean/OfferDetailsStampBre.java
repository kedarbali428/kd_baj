package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

public class OfferDetailsStampBre {
private boolean  offerAcceptedStatus;
private String  riskClassification;
private String offerSource;
private String  offerId;
private String riskOfferType;
private String offerGenerationRule;
private Float offerROI;
private String  offerProgramCode;
private String  offerType;
private BigDecimal offerAmount;
public BigDecimal getOfferAmount() {
	return offerAmount;
}
public void setOfferAmount(BigDecimal offerAmount) {
	this.offerAmount = offerAmount;
}
public String getOfferType() {
	return offerType;
}
public void setOfferType(String offerType) {
	this.offerType = offerType;
}
public boolean isOfferAcceptedStatus() {
	return offerAcceptedStatus;
}
public void setOfferAcceptedStatus(boolean offerAcceptedStatus) {
	this.offerAcceptedStatus = offerAcceptedStatus;
}

public Float getOfferROI() {
	return offerROI;
}
public void setOfferROI(Float offerROI) {
	this.offerROI = offerROI;
}
public String getRiskClassification() {
	return riskClassification;
}
public void setRiskClassification(String riskClassification) {
	this.riskClassification = riskClassification;
}
public String getOfferSource() {
	return offerSource;
}
public void setOfferSource(String offerSource) {
	this.offerSource = offerSource;
}
public String getOfferId() {
	return offerId;
}
public void setOfferId(String offerId) {
	this.offerId = offerId;
}
public String getRiskOfferType() {
	return riskOfferType;
}
public void setRiskOfferType(String riskOfferType) {
	this.riskOfferType = riskOfferType;
}
public String getOfferGenerationRule() {
	return offerGenerationRule;
}
public void setOfferGenerationRule(String offerGenerationRule) {
	this.offerGenerationRule = offerGenerationRule;
}
public String getOfferProgramCode() {
	return offerProgramCode;
}
public void setOfferProgramCode(String offerProgramCode) {
	this.offerProgramCode = offerProgramCode;
}


}
