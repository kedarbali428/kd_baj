package com.bajaj.markets.credit.employeeportal.bean;

public class CoapplicantAccountDetails {

	public String coapplicantName;

	public String coapplicantPan;

	public String coapplicantMemberName;

	public String coapplicantAccountNumber;

	public String coapplicantAccountType;

	public String coapplicantOwnershipIndicator;

	public String coapplicantDateOpened;

	public String coapplicantDateLastPayment;

	public String coapplicantDateClosed;

	public String coapplicantDateReportedAndCert;

	public String coapplicantHighCreditSanctionAmt;

	public String coapplicantCurrentBalance;

	public String coapplicantAmountOverdue;

	public String coapplicantPaymentHistory1;

	public String coapplicantPaymentHistory2DaysPastDue;

	public String coapplicantPaymentHistoryStartDate;

	public String coapplicantPaymentHistoryEndDate;

	public String coapplicantSuitFieldWilfulDefault;

	public String coapplicantWrittenOffAndSettledStatus;

	public String coapplicantValueOfCollateral;

	public String coapplicantTypeOfCollateral;

	public String coapplicantCreditLimit;

	public String coapplicantCashLimit;

	public String coapplicantRateOfInterest;

	public String coapplicantRepaymentTenure;

	public String coapplicantWrittenOffAmountTotal;

	public String coapplicantWrittenOffAmountPrincipal;

	public String coapplicantSettlementAmount;

	public String coapplicantPaymentFrequency;

	public String coapplicantActualPaymentAmount;

	public String coapplicantEmiAmount;

	public String coapplicantDateReported;

	public String coapplicantSanctionedLoanAmount;

	public String getCoapplicantName() {
		return coapplicantName;
	}

	public void setCoapplicantName(String coapplicantName) {
		this.coapplicantName = coapplicantName;
	}

	public String getCoapplicantPan() {
		return coapplicantPan;
	}

	public void setCoapplicantPan(String coapplicantPan) {
		this.coapplicantPan = coapplicantPan;
	}

	public String getCoapplicantMemberName() {
		return coapplicantMemberName;
	}

	public void setCoapplicantMemberName(String coapplicantMemberName) {
		this.coapplicantMemberName = coapplicantMemberName;
	}

	public String getCoapplicantAccountNumber() {
		return coapplicantAccountNumber;
	}

	public void setCoapplicantAccountNumber(String coapplicantAccountNumber) {
		this.coapplicantAccountNumber = coapplicantAccountNumber;
	}

	public String getCoapplicantAccountType() {
		return coapplicantAccountType;
	}

	public void setCoapplicantAccountType(String coapplicantAccountType) {
		this.coapplicantAccountType = coapplicantAccountType;
	}

	public String getCoapplicantOwnershipIndicator() {
		return coapplicantOwnershipIndicator;
	}

	public void setCoapplicantOwnershipIndicator(String coapplicantOwnershipIndicator) {
		this.coapplicantOwnershipIndicator = coapplicantOwnershipIndicator;
	}

	public String getCoapplicantDateOpened() {
		return coapplicantDateOpened;
	}

	public void setCoapplicantDateOpened(String coapplicantDateOpened) {
		this.coapplicantDateOpened = coapplicantDateOpened;
	}

	public String getCoapplicantDateLastPayment() {
		return coapplicantDateLastPayment;
	}

	public void setCoapplicantDateLastPayment(String coapplicantDateLastPayment) {
		this.coapplicantDateLastPayment = coapplicantDateLastPayment;
	}

	public String getCoapplicantDateClosed() {
		return coapplicantDateClosed;
	}

	public void setCoapplicantDateClosed(String coapplicantDateClosed) {
		this.coapplicantDateClosed = coapplicantDateClosed;
	}

	public String getCoapplicantDateReportedAndCert() {
		return coapplicantDateReportedAndCert;
	}

	public void setCoapplicantDateReportedAndCert(String coapplicantDateReportedAndCert) {
		this.coapplicantDateReportedAndCert = coapplicantDateReportedAndCert;
	}

	public String getCoapplicantHighCreditSanctionAmt() {
		return coapplicantHighCreditSanctionAmt;
	}

	public void setCoapplicantHighCreditSanctionAmt(String coapplicantHighCreditSanctionAmt) {
		this.coapplicantHighCreditSanctionAmt = coapplicantHighCreditSanctionAmt;
	}

	public String getCoapplicantCurrentBalance() {
		return coapplicantCurrentBalance;
	}

	public void setCoapplicantCurrentBalance(String coapplicantCurrentBalance) {
		this.coapplicantCurrentBalance = coapplicantCurrentBalance;
	}

	public String getCoapplicantAmountOverdue() {
		return coapplicantAmountOverdue;
	}

	public void setCoapplicantAmountOverdue(String coapplicantAmountOverdue) {
		this.coapplicantAmountOverdue = coapplicantAmountOverdue;
	}

	public String getCoapplicantPaymentHistory1() {
		return coapplicantPaymentHistory1;
	}

	public void setCoapplicantPaymentHistory1(String coapplicantPaymentHistory1) {
		this.coapplicantPaymentHistory1 = coapplicantPaymentHistory1;
	}

	public String getCoapplicantPaymentHistory2DaysPastDue() {
		return coapplicantPaymentHistory2DaysPastDue;
	}

	public void setCoapplicantPaymentHistory2DaysPastDue(String coapplicantPaymentHistory2DaysPastDue) {
		this.coapplicantPaymentHistory2DaysPastDue = coapplicantPaymentHistory2DaysPastDue;
	}

	public String getCoapplicantPaymentHistoryStartDate() {
		return coapplicantPaymentHistoryStartDate;
	}

	public void setCoapplicantPaymentHistoryStartDate(String coapplicantPaymentHistoryStartDate) {
		this.coapplicantPaymentHistoryStartDate = coapplicantPaymentHistoryStartDate;
	}

	public String getCoapplicantPaymentHistoryEndDate() {
		return coapplicantPaymentHistoryEndDate;
	}

	public void setCoapplicantPaymentHistoryEndDate(String coapplicantPaymentHistoryEndDate) {
		this.coapplicantPaymentHistoryEndDate = coapplicantPaymentHistoryEndDate;
	}

	public String getCoapplicantSuitFieldWilfulDefault() {
		return coapplicantSuitFieldWilfulDefault;
	}

	public void setCoapplicantSuitFieldWilfulDefault(String coapplicantSuitFieldWilfulDefault) {
		this.coapplicantSuitFieldWilfulDefault = coapplicantSuitFieldWilfulDefault;
	}

	public String getCoapplicantWrittenOffAndSettledStatus() {
		return coapplicantWrittenOffAndSettledStatus;
	}

	public void setCoapplicantWrittenOffAndSettledStatus(String coapplicantWrittenOffAndSettledStatus) {
		this.coapplicantWrittenOffAndSettledStatus = coapplicantWrittenOffAndSettledStatus;
	}

	public String getCoapplicantValueOfCollateral() {
		return coapplicantValueOfCollateral;
	}

	public void setCoapplicantValueOfCollateral(String coapplicantValueOfCollateral) {
		this.coapplicantValueOfCollateral = coapplicantValueOfCollateral;
	}

	public String getCoapplicantTypeOfCollateral() {
		return coapplicantTypeOfCollateral;
	}

	public void setCoapplicantTypeOfCollateral(String coapplicantTypeOfCollateral) {
		this.coapplicantTypeOfCollateral = coapplicantTypeOfCollateral;
	}

	public String getCoapplicantCreditLimit() {
		return coapplicantCreditLimit;
	}

	public void setCoapplicantCreditLimit(String coapplicantCreditLimit) {
		this.coapplicantCreditLimit = coapplicantCreditLimit;
	}

	public String getCoapplicantCashLimit() {
		return coapplicantCashLimit;
	}

	public void setCoapplicantCashLimit(String coapplicantRashLimit) {
		this.coapplicantCashLimit = coapplicantRashLimit;
	}

	public String getCoapplicantRateOfInterest() {
		return coapplicantRateOfInterest;
	}

	public void setCoapplicantRateOfInterest(String coapplicantRateOfInterest) {
		this.coapplicantRateOfInterest = coapplicantRateOfInterest;
	}

	public String getCoapplicantRepaymentTenure() {
		return coapplicantRepaymentTenure;
	}

	public void setCoapplicantRepaymentTenure(String coapplicantRepaymentTenure) {
		this.coapplicantRepaymentTenure = coapplicantRepaymentTenure;
	}

	public String getCoapplicantWrittenOffAmountTotal() {
		return coapplicantWrittenOffAmountTotal;
	}

	public void setCoapplicantWrittenOffAmountTotal(String coapplicantWrittenOffAmountTotal) {
		this.coapplicantWrittenOffAmountTotal = coapplicantWrittenOffAmountTotal;
	}

	public String getCoapplicantWrittenOffAmountPrincipal() {
		return coapplicantWrittenOffAmountPrincipal;
	}

	public void setCoapplicantWrittenOffAmountPrincipal(String coapplicantWrittenOffAmountPrincipal) {
		this.coapplicantWrittenOffAmountPrincipal = coapplicantWrittenOffAmountPrincipal;
	}

	public String getCoapplicantSettlementAmount() {
		return coapplicantSettlementAmount;
	}

	public void setCoapplicantSettlementAmount(String coapplicantSettlementAmount) {
		this.coapplicantSettlementAmount = coapplicantSettlementAmount;
	}

	public String getCoapplicantPaymentFrequency() {
		return coapplicantPaymentFrequency;
	}

	public void setCoapplicantPaymentFrequency(String coapplicantPaymentFrequency) {
		this.coapplicantPaymentFrequency = coapplicantPaymentFrequency;
	}

	public String getCoapplicantActualPaymentAmount() {
		return coapplicantActualPaymentAmount;
	}

	public void setCoapplicantActualPaymentAmount(String coapplicantActualPaymentAmount) {
		this.coapplicantActualPaymentAmount = coapplicantActualPaymentAmount;
	}

	public String getCoapplicantEmiAmount() {
		return coapplicantEmiAmount;
	}

	public void setCoapplicantEmiAmount(String coapplicantEmiAmount) {
		this.coapplicantEmiAmount = coapplicantEmiAmount;
	}

	public String getCoapplicantDateReported() {
		return coapplicantDateReported;
	}

	public void setCoapplicantDateReported(String coapplicantDateReported) {
		this.coapplicantDateReported = coapplicantDateReported;
	}

	public String getCoapplicantSanctionedLoanAmount() {
		return coapplicantSanctionedLoanAmount;
	}

	public void setCoapplicantSanctionedLoanAmount(String coapplicantSanctionedLoanAmount) {
		this.coapplicantSanctionedLoanAmount = coapplicantSanctionedLoanAmount;
	}

}
