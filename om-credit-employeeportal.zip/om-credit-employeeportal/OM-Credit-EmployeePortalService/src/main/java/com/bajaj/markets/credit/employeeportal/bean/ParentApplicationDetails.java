package com.bajaj.markets.credit.employeeportal.bean;

public class ParentApplicationDetails {
	private String applicationKey;

	private String appDate;

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getAppDate() {
		return appDate;
	}

	public void setAppDate(String appDate) {
		this.appDate = appDate;
	}
	
}
