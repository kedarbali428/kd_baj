package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class EligibilityBol implements Serializable {

	private static final long serialVersionUID = 1L;

	private BigDecimal offerAmount;
	private String programCode;
	private String revisedEligibilityAmount;

	public BigDecimal getOfferAmount() {
		return offerAmount;
	}

	public void setOfferAmount(BigDecimal offerAmount) {
		this.offerAmount = offerAmount;
	}

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public String getRevisedEligibilityAmount() {
		return revisedEligibilityAmount;
	}

	public void setRevisedEligibilityAmount(String revisedEligibilityAmount) {
		this.revisedEligibilityAmount = revisedEligibilityAmount;
	}

}
