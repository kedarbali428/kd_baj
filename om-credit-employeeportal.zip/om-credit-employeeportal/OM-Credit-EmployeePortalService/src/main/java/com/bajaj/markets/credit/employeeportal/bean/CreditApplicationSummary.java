package com.bajaj.markets.credit.employeeportal.bean;

public class CreditApplicationSummary {
	private Long applicationId;
	private String customerName;
	private String owner;
	private String status;
	private String subStage;
	private String l2Product;
	private String l2productCode ;
	private String productVarient;
	private String creationDate;
	private String source;
	private String occupationType;
	/**
	 * @return the applicationId
	 */
	public Long getApplicationId() {
		return applicationId;
	}
	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the subStage
	 */
	public String getSubStage() {
		return subStage;
	}
	/**
	 * @param subStage the subStage to set
	 */
	public void setSubStage(String subStage) {
		this.subStage = subStage;
	}
	/**
	 * @return the l2Product
	 */
	public String getL2Product() {
		return l2Product;
	}
	/**
	 * @param l2Product the l2Product to set
	 */
	public void setL2Product(String l2Product) {
		this.l2Product = l2Product;
	}
	/**
	 * @return the l2productCode
	 */
	public String getL2productCode() {
		return l2productCode;
	}
	/**
	 * @param l2productCode the l2productCode to set
	 */
	public void setL2productCode(String l2productCode) {
		this.l2productCode = l2productCode;
	}
	/**
	 * @return the productVarient
	 */
	public String getProductVarient() {
		return productVarient;
	}
	/**
	 * @param productVarient the productVarient to set
	 */
	public void setProductVarient(String productVarient) {
		this.productVarient = productVarient;
	}
	/**
	 * @return the creationDate
	 */
	public String getCreationDate() {
		return creationDate;
	}
	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}
	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}
	/**
	 * @return the occupationType
	 */
	public String getOccupationType() {
		return occupationType;
	}
	/**
	 * @param occupationType the occupationType to set
	 */
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	
}

