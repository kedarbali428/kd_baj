package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "bureau_address", schema = "dmverification")
public class BureauAddress implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name = "bureau_address_cbakey_generator", sequenceName = "dmcredit.seq_pk_bureau_address", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bureau_address_cbakey_generator")
	private Long cbakey;
	
	private Long cbhkey;
	
    private String segmenttag;
    
    private String addressline1;
    
    private String addressline2;
    
    private String addressline3;
    
    private String statecode;
    
    private String pincode;
    
    private String datereported;
    
    private String addresscategory;
    
    private String residencecode;
    
    private Integer isactive;
    
    private BigDecimal lstupdateby;
    
    private Timestamp lstupdatedt;
    

	/**
	 * @return the cbakey
	 */
	public Long getCbakey() {
		return cbakey;
	}

	/**
	 * @param cbakey the cbakey to set
	 */
	public void setCbakey(Long cbakey) {
		this.cbakey = cbakey;
	}

	/**
	 * @return the segmenttag
	 */
	public String getSegmenttag() {
		return segmenttag;
	}

	/**
	 * @param segmenttag the segmenttag to set
	 */
	public void setSegmenttag(String segmenttag) {
		this.segmenttag = segmenttag;
	}

	/**
	 * @return the addressline1
	 */
	public String getAddressline1() {
		return addressline1;
	}

	/**
	 * @param addressline1 the addressline1 to set
	 */
	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	/**
	 * @return the addressline2
	 */
	public String getAddressline2() {
		return addressline2;
	}

	/**
	 * @param addressline2 the addressline2 to set
	 */
	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}

	/**
	 * @return the addressline3
	 */
	public String getAddressline3() {
		return addressline3;
	}

	/**
	 * @param addressline3 the addressline3 to set
	 */
	public void setAddressline3(String addressline3) {
		this.addressline3 = addressline3;
	}

	/**
	 * @return the statecode
	 */
	public String getStatecode() {
		return statecode;
	}

	/**
	 * @param statecode the statecode to set
	 */
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}

	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}

	/**
	 * @param pincode the pincode to set
	 */
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	/**
	 * @return the addresscategory
	 */
	public String getAddresscategory() {
		return addresscategory;
	}

	/**
	 * @param addresscategory the addresscategory to set
	 */
	public void setAddresscategory(String addresscategory) {
		this.addresscategory = addresscategory;
	}

	/**
	 * @return the residencecode
	 */
	public String getResidencecode() {
		return residencecode;
	}

	/**
	 * @param residencecode the residencecode to set
	 */
	public void setResidencecode(String residencecode) {
		this.residencecode = residencecode;
	}

	/**
	 * @return the isactive
	 */
	public Integer getIsactive() {
		return isactive;
	}

	/**
	 * @param isactive the isactive to set
	 */
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	/**
	 * @return the lstupdateby
	 */
	public BigDecimal getLstupdateby() {
		return lstupdateby;
	}

	/**
	 * @param lstupdateby the lstupdateby to set
	 */
	public void setLstupdateby(BigDecimal lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	/**
	 * @return the lstupdatedt
	 */
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	/**
	 * @param lstupdatedt the lstupdatedt to set
	 */
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	/**
	 * @return the datereported
	 */
	public String getDatereported() {
		return datereported;
	}

	/**
	 * @param datereported the datereported to set
	 */
	public void setDatereported(String datereported) {
		this.datereported = datereported;
	}

	/**
	 * @return the cbhkey
	 */
	public Long getCbhkey() {
		return cbhkey;
	}

	/**
	 * @param cbhkey the cbhkey to set
	 */
	public void setCbhkey(Long cbhkey) {
		this.cbhkey = cbhkey;
	}

	
		}
