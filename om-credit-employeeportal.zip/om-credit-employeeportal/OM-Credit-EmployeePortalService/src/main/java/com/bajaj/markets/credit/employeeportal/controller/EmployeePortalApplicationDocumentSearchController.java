package com.bajaj.markets.credit.employeeportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.Application;
import com.bajaj.markets.credit.employeeportal.bean.ApplicationAttributeBean;
import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalApplicationDocumentSearchService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EmployeePortalApplicationDocumentSearchController {
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	private EmployeePortalApplicationDocumentSearchService employeePortalApplicationDocumentSearchService;
	private static final String CLASSNAME = EmployeePortalApplicationDocumentSearchController.class.getName();

	@ApiOperation(value = "Search application document", notes = "Search application document", httpMethod = "GET")
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Search application document ", response = ApplicationAttributeBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/application/search/{selectCriteria}/{searchValue}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> searchApplicationDocument(@PathVariable("selectCriteria") String selectCriteria,
			@PathVariable("searchValue") String searchValue, @RequestHeader HttpHeaders headers) {
		ApplicationAttributeBean bean = new ApplicationAttributeBean();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "searchApplicationDocument " + " selectCriteria " +selectCriteria +" searchValue "+searchValue);
			bean = employeePortalApplicationDocumentSearchService.findApplicationDocument(selectCriteria.trim(), searchValue.trim());
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "searchApplicationDocument - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while searchApplicationDocument", exception);
			throw exception;
		}
		return new ResponseEntity<>(bean, HttpStatus.OK);
	}

	@ApiOperation(value = "Search application document top level info", notes = "Search application document top level info", httpMethod = "GET")
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Search application document top level info ", response = ApplicationAttributeBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/application/search/properties/{applicationKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getProperties(@PathVariable("applicationKey") Long applicationKey,
			@RequestHeader HttpHeaders headers) {
		ApplicationAttributeBean bean = new ApplicationAttributeBean();
		bean  = employeePortalApplicationDocumentSearchService.searchDocument(applicationKey);
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "data passing to UI" +bean);
		return new ResponseEntity<>(bean,HttpStatus.OK);
	}
	
	@ApiOperation(value = "Check for application present ", notes = "Check for application present ", httpMethod = "GET")
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Search application document top level info ", response = ApplicationAttributeBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/application/plugin/{applicationid}/{selectCriteria}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplication(@PathVariable("applicationid") String applicationKey,
			@PathVariable("selectCriteria") String selectCriteria, @RequestHeader HttpHeaders headers) {
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Finding  application for application key  start controller " + applicationKey);
		Application bean = new Application();
		if(selectCriteria.equals(EmployeePortalConstants.APLN_KEY) ||selectCriteria.equals(EmployeePortalConstants.APPLICATION_KEY) || 
				selectCriteria.equals(EmployeePortalConstants.APPLICATION_ID)){
			bean  = employeePortalApplicationDocumentSearchService.finAplicationByApplicationKey(Long.parseLong(applicationKey));
		}else if(selectCriteria.equals(EmployeePortalConstants.LOAN_ACCT_NUM)){
			bean  = employeePortalApplicationDocumentSearchService.finAplicationByLAN(applicationKey);
		}
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "data passing to BAU service" +bean);
		logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Finding  application for application key  end controller " + applicationKey);
		return new ResponseEntity<>(bean,HttpStatus.OK);
	}
}
