package com.bajaj.markets.credit.employeeportal.helper;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.bajaj.markets.insurance.remoteapitrackinglib.bean.RemoteApiTrackingBean;
import com.bajaj.markets.insurance.remoteapitrackinglib.service.impl.RemoteApiTrackingImpl;

@Component
public class KibanaLoggingHelper {
	

	@Autowired
	private RemoteApiTrackingImpl remoteApiTrackingImpl;

	 @Autowired
	private BFLLoggerUtilExt logger;

	 private static final String THIS_CLASS = KibanaLoggingHelper.class.getCanonicalName();

	 public RemoteApiTrackingBean apiTrackingBeanCreation(Object applicationId, Object applicantId, Object request,
	String apiURL, String source, String target) {
	Gson gson = new GsonBuilder().serializeNulls().create();
	RemoteApiTrackingBean remoteApiTrackingBean = new RemoteApiTrackingBean();
	remoteApiTrackingBean.setApplicantId(null != applicantId ? applicantId.toString() : null);
	remoteApiTrackingBean.setApplicationId(null != applicationId ? applicationId.toString() : null);
	remoteApiTrackingBean.setRequestPayload(request instanceof String ? request.toString() : gson.toJson(request));
	remoteApiTrackingBean.setRequestTimeStamp(new Timestamp(System.currentTimeMillis()).toString());
	remoteApiTrackingBean.setSource(source);
	remoteApiTrackingBean.setTarget(target);
	remoteApiTrackingBean.setTargetApi(apiURL);

	 return remoteApiTrackingBean;
	}

	 public void save(RemoteApiTrackingBean apiTrackingBean) {
	try {
	remoteApiTrackingImpl.saveRequestResponse(apiTrackingBean);
	} catch (Exception e) {
	logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
	"Error occured while api tracking: " + apiTrackingBean.getApplicationId());
	}
	}

	}
