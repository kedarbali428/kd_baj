package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_security_pdc_detail", schema = "dmcredit")
public class AppSecurityPDCDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_security_pdc_detail_secpdckey_generator", sequenceName = "dmcredit.seq_pk_app_security_pdc_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_security_pdc_detail_secpdckey_generator")
	private Long secpdckey;
	private Long applicationkey;
	private String pdcnumber1;
	private Integer pdcamount1;
	private String pdcnumber2;
	private Integer pdcamount2;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private String pdcnumber3;
	private Integer pdcamount3;
	private String pdcnumber4;
	private Integer pdcamount4;
	/**
	 * @return the secpdckey
	 */
	public Long getSecpdckey() {
		return secpdckey;
	}
	/**
	 * @param secpdckey the secpdckey to set
	 */
	public void setSecpdckey(Long secpdckey) {
		this.secpdckey = secpdckey;
	}
	/**
	 * @return the applicationkey
	 */
	public Long getApplicationkey() {
		return applicationkey;
	}
	/**
	 * @param applicationkey the applicationkey to set
	 */
	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}
	/**
	 * @return the pdcnumber1
	 */
	public String getPdcnumber1() {
		return pdcnumber1;
	}
	/**
	 * @param pdcnumber1 the pdcnumber1 to set
	 */
	public void setPdcnumber1(String pdcnumber1) {
		this.pdcnumber1 = pdcnumber1;
	}
	/**
	 * @return the pdcamount1
	 */
	public Integer getPdcamount1() {
		return pdcamount1;
	}
	/**
	 * @param pdcamount1 the pdcamount1 to set
	 */
	public void setPdcamount1(Integer pdcamount1) {
		this.pdcamount1 = pdcamount1;
	}
	/**
	 * @return the pdcnumber2
	 */
	public String getPdcnumber2() {
		return pdcnumber2;
	}
	/**
	 * @param pdcnumber2 the pdcnumber2 to set
	 */
	public void setPdcnumber2(String pdcnumber2) {
		this.pdcnumber2 = pdcnumber2;
	}
	/**
	 * @return the pdcamount2
	 */
	public Integer getPdcamount2() {
		return pdcamount2;
	}
	/**
	 * @param pdcamount2 the pdcamount2 to set
	 */
	public void setPdcamount2(Integer pdcamount2) {
		this.pdcamount2 = pdcamount2;
	}
	/**
	 * @return the isactive
	 */
	public Integer getIsactive() {
		return isactive;
	}
	/**
	 * @param isactive the isactive to set
	 */
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	/**
	 * @return the lstupdateby
	 */
	public Long getLstupdateby() {
		return lstupdateby;
	}
	/**
	 * @param lstupdateby the lstupdateby to set
	 */
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	/**
	 * @return the lstupdatedt
	 */
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	/**
	 * @param lstupdatedt the lstupdatedt to set
	 */
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	/**
	 * @return the pdcnumber3
	 */
	public String getPdcnumber3() {
		return pdcnumber3;
	}
	/**
	 * @param pdcnumber3 the pdcnumber3 to set
	 */
	public void setPdcnumber3(String pdcnumber3) {
		this.pdcnumber3 = pdcnumber3;
	}
	/**
	 * @return the pdcamount3
	 */
	public Integer getPdcamount3() {
		return pdcamount3;
	}
	/**
	 * @param pdcamount3 the pdcamount3 to set
	 */
	public void setPdcamount3(Integer pdcamount3) {
		this.pdcamount3 = pdcamount3;
	}
	/**
	 * @return the pdcnumber4
	 */
	public String getPdcnumber4() {
		return pdcnumber4;
	}
	/**
	 * @param pdcnumber4 the pdcnumber4 to set
	 */
	public void setPdcnumber4(String pdcnumber4) {
		this.pdcnumber4 = pdcnumber4;
	}
	/**
	 * @return the pdcamount4
	 */
	public Integer getPdcamount4() {
		return pdcamount4;
	}
	/**
	 * @param pdcamount4 the pdcamount4 to set
	 */
	public void setPdcamount4(Integer pdcamount4) {
		this.pdcamount4 = pdcamount4;
	}

	
}
