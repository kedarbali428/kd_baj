package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class UserRoleProductTypeBean implements Serializable{
	

	private BigDecimal userroleprodtypekey ;
	private Integer    userprodkey ;
	private Integer  subprodtypekey ;
	private BigDecimal isactive;
	private String lstupdateby;
	private Timestamp lstupdatedt;
	private String productName;
	private String productCode;
	private String productDesc;
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public String getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	public BigDecimal getUserroleprodtypekey() {
		return userroleprodtypekey;
	}
	public void setUserroleprodtypekey(BigDecimal userroleprodtypekey) {
		this.userroleprodtypekey = userroleprodtypekey;
	}
	public Integer getUserprodkey() {
		return userprodkey;
	}
	public void setUserprodkey(Integer userprodkey) {
		this.userprodkey = userprodkey;
	}
	public Integer getSubprodtypekey() {
		return subprodtypekey;
	}
	public void setSubprodtypekey(Integer subprodtypekey) {
		this.subprodtypekey = subprodtypekey;
	}
	public BigDecimal getIsactive() {
		return isactive;
	}
	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}
	
}
