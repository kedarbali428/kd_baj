package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class FppPlan {

	private String planCode;
	private String planKey;
	private String planName;
	private String planFriendlyName;
	private String planType;
	private List<ProductDetail> bundle;
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getPlanKey() {
		return planKey;
	}
	public void setPlanKey(String planKey) {
		this.planKey = planKey;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPlanFriendlyName() {
		return planFriendlyName;
	}
	public void setPlanFriendlyName(String planFriendlyName) {
		this.planFriendlyName = planFriendlyName;
	}
	public String getPlanType() {
		return planType;
	}
	public void setPlanType(String planType) {
		this.planType = planType;
	}
	public List<ProductDetail> getBundle() {
		return bundle;
	}
	public void setBundle(List<ProductDetail> bundle) {
		this.bundle = bundle;
	}
	
	
}
