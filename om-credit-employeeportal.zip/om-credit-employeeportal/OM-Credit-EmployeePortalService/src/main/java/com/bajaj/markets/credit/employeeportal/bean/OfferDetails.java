package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

public class OfferDetails {
	private String riskOfferType;
	private String offerType;
	private BigDecimal offerAmount;
	private String offerId;
	private String offerExpiryDt;
	private long prodkey;
	private String proddesc;
	private String customerType;
	private Float offerRoi;
	private String offerAvailable;
	private String partnerOfferId;
	private String prospectId;
	private String offerAccepted;
	private String riskSegmentation;
	private String offerName;
	private String generationrule;
	private String offergenerationsource;
	private String offerProductVariant;
	private String finalEligibility;
	private String offerRate;
	private String addresscategory;
	private Integer businessPriority;
	private String offerprogramcode;
	private String finalOfferFlag;
	/**
	 * @return the riskOfferType
	 */
	public String getRiskOfferType() {
		return riskOfferType;
	}

	/**
	 * @param riskOfferType the riskOfferType to set
	 */
	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	/**
	 * @return the offerType
	 */
	public String getOfferType() {
		return offerType;
	}

	/**
	 * @param offerType the offerType to set
	 */
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	/**
	 * @return the offerAmount
	 */
	public BigDecimal getOfferAmount() {
		return offerAmount;
	}

	/**
	 * @param offerAmount the offerAmount to set
	 */
	public void setOfferAmount(BigDecimal offerAmount) {
		this.offerAmount = offerAmount;
	}

	/**
	 * @return the offerId
	 */
	public String getOfferId() {
		return offerId;
	}

	/**
	 * @param offerId the offerId to set
	 */
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	/**
	 * @return the offerExpiryDt
	 */
	public String getOfferExpiryDt() {
		return offerExpiryDt;
	}

	/**
	 * @param offerExpiryDt the offerExpiryDt to set
	 */
	public void setOfferExpiryDt(String offerExpiryDt) {
		this.offerExpiryDt = offerExpiryDt;
	}

	/**
	 * @return the prodkey
	 */
	public long getProdkey() {
		return prodkey;
	}

	/**
	 * @param prodkey the prodkey to set
	 */
	public void setProdkey(long prodkey) {
		this.prodkey = prodkey;
	}

	/**
	 * 
	 * @return
	 */
	public String getProddesc() {
		return proddesc;
	}

	/**
	 * 
	 * @param proddesc
	 */
	public void setProddesc(String proddesc) {
		this.proddesc = proddesc;
	}

	/**
	 * @return the customerType
	 */
	public String getCustomerType() {
		return customerType;
	}

	/**
	 * @param customerType the customerType to set
	 */
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public Float getOfferRoi() {
		return offerRoi;
	}

	public void setOfferRoi(Float offerRoi) {
		this.offerRoi = offerRoi;
	}

	public String getOfferAvailable() {
		return offerAvailable;
	}

	public void setOfferAvailable(String offerAvailable) {
		this.offerAvailable = offerAvailable;
	}

	public String getPartnerOfferId() {
		return partnerOfferId;
	}

	public void setPartnerOfferId(String partnerOfferId) {
		this.partnerOfferId = partnerOfferId;
	}

	public String getProspectId() {
		return prospectId;
	}

	public void setProspectId(String prospectId) {
		this.prospectId = prospectId;
	}

	public String getOfferAccepted() {
		return offerAccepted;
	}

	public void setOfferAccepted(String offerAccepted) {
		this.offerAccepted = offerAccepted;
	}

	public String getRiskSegmentation() {
		return riskSegmentation;
	}

	public void setRiskSegmentation(String riskSegmentation) {
		this.riskSegmentation = riskSegmentation;
	}

	public String getOfferName() {
		return offerName;
	}

	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}

	public String getGenerationrule() {
		return generationrule;
	}

	public void setGenerationrule(String generationrule) {
		this.generationrule = generationrule;
	}

	public String getOffergenerationsource() {
		return offergenerationsource;
	}

	public void setOffergenerationsource(String offergenerationsource) {
		this.offergenerationsource = offergenerationsource;
	}

	public String getOfferProductVariant() {
		return offerProductVariant;
	}

	public void setOfferProductVariant(String offerProductVariant) {
		this.offerProductVariant = offerProductVariant;
	}

	public String getFinalEligibility() {
		return finalEligibility;
	}

	public void setFinalEligibility(String finalEligibility) {
		this.finalEligibility = finalEligibility;
	}

	public String getOfferRate() {
		return offerRate;
	}

	public void setOfferRate(String offerRate) {
		this.offerRate = offerRate;
	}

	public String getAddresscategory() {
		return addresscategory;
	}

	public void setAddresscategory(String addresscategory) {
		this.addresscategory = addresscategory;
	}

	public Integer getBusinessPriority() {
		return businessPriority;
	}

	public void setBusinessPriority(Integer businessPriority) {
		this.businessPriority = businessPriority;
	}

	public String getOfferprogramcode() {
		return offerprogramcode;
	}

	public void setOfferprogramcode(String offerprogramcode) {
		this.offerprogramcode = offerprogramcode;
	}

	public String getFinalOfferFlag() {
		return finalOfferFlag;
	}

	public void setFinalOfferFlag(String finalOfferFlag) {
		this.finalOfferFlag = finalOfferFlag;
	}
}
