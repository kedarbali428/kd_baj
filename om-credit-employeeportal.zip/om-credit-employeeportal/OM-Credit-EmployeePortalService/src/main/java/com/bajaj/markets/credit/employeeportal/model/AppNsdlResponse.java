package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_nsdl_response", schema = "dmverification")
public class AppNsdlResponse implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_nsdl_response_appnsdlrespbkey_generator", sequenceName = "dmverification.seq_pk_app_nsdl_response", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_nsdl_response_appnsdlrespbkey_generator")
	private Long nsdlkey;
	private String pan;
	private String panstatus;
	private String firstname;
	private String middlename;
	private String lastname;
	private Timestamp requestdt;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private Long applicationkey;
	private Long applicantkey;

	public Long getNsdlkey() {
		return nsdlkey;
	}

	public void setNsdlkey(Long nsdlkey) {
		this.nsdlkey = nsdlkey;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getPanstatus() {
		return panstatus;
	}

	public void setPanstatus(String panstatus) {
		this.panstatus = panstatus;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Timestamp getRequestdt() {
		return requestdt;
	}

	public void setRequestdt(Timestamp requestdt) {
		this.requestdt = requestdt;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(Long applicantkey) {
		this.applicantkey = applicantkey;
	}

	
}
