package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;

public class TranchBean {
	
	@Digits(fraction = 0, integer = 5,message = "tranchkey can not be other than digits")
	private long tranchkey;
	
	@Pattern(regexp="^[A-Za-z ]*$",message = "Invalid Input accountHolderName")
	private String accountHolderName;
	
	private BigDecimal accountHolderType;
	
	
	@Digits(fraction = 0, integer = 20,message = "accountNumber can not be other than digits")
	private String accountNumber;
	
	@Digits(fraction = 0, integer = 5,message = "accountTypeKey can not be other than digits")
	private Integer accountTypeKey;

	private String disbursementDate;
	
	@Pattern(regexp="^[A-Za-z]*$",message = "Invalid Input disbursementMode")
	private String disbursementMode;

	@Digits(fraction = 0, integer = 20,message = "trancheAmount can not be other than digits")
	private Integer trancheAmount;
	
	private String trancheStatus;
	
	@Digits(fraction = 0, integer = 5,message = "tranchenum can not be other than digits")
	private Integer tranchenum;
	
	@JsonFormat(pattern="yyyy/MM/dd",timezone = "IST")
	private String trancheDate;
	
	@Digits(fraction = 0, integer = 5,message = "tranchkey can not be other than digits")
	private Integer beneficiaryTypeKey;

	@Pattern(regexp="^[a-zA-Z0-9]*$",message = "Invalid Input ifsccode")
	private String ifsccode;
	
	@Digits(fraction = 0, integer = 20,message = "applicationBankDetKey can not be other than digits")
	private Long applicationBankDetKey;
	
	public long getTranchkey() {
		return tranchkey;
	}
	public void setTranchkey(long tranchkey) {
		this.tranchkey = tranchkey;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public BigDecimal getAccountHolderType() {
		return accountHolderType;
	}
	public void setAccountHolderType(BigDecimal accountHolderType) {
		this.accountHolderType = accountHolderType;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Integer getAccountTypeKey() {
		return accountTypeKey;
	}
	public void setAccountTypeKey(Integer accountTypeKey) {
		this.accountTypeKey = accountTypeKey;
	}
	public String getDisbursementDate() {
		return disbursementDate;
	}
	public void setDisbursementDate(String disbursementDate) {
		this.disbursementDate = disbursementDate;
	}
	public String getDisbursementMode() {
		return disbursementMode;
	}
	public void setDisbursementMode(String disbursementMode) {
		this.disbursementMode = disbursementMode;
	}
	public Integer getTrancheAmount() {
		return trancheAmount;
	}
	public void setTrancheAmount(Integer trancheAmount) {
		this.trancheAmount = trancheAmount;
	}
	public String getTrancheStatus() {
		return trancheStatus;
	}
	public void setTrancheStatus(String trancheStatus) {
		this.trancheStatus = trancheStatus;
	}
	public Integer getTranchenum() {
		return tranchenum;
	}
	public void setTranchenum(Integer tranchenum) {
		this.tranchenum = tranchenum;
	}
	public String getTrancheDate() {
		return trancheDate;
	}
	public void setTrancheDate(String trancheDate) {
		this.trancheDate = trancheDate;
	}
	public Integer getBeneficiaryTypeKey() {
		return beneficiaryTypeKey;
	}
	public void setBeneficiaryTypeKey(Integer beneficiaryTypeKey) {
		this.beneficiaryTypeKey = beneficiaryTypeKey;
	}
	public String getIfsccode() {
		return ifsccode;
	}
	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}
	public Long getApplicationBankDetKey() {
		return applicationBankDetKey;
	}
	public void setApplicationBankDetKey(Long applicationBankDetKey) {
		this.applicationBankDetKey = applicationBankDetKey;
	}
	
}
