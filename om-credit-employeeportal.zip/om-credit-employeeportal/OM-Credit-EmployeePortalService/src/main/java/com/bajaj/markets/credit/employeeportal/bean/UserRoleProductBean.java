package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserRoleProductBean  {

	private long userprodkey;

	private long userrolekey;

	private long prodmastkey;

	private long subprodkey;

	private BigDecimal isactive;
	private String lstupdateby;
	private Timestamp lstupdatedt;
	private List<UserRoleProductTypeBean> userRoleProductTypes = new ArrayList<>();
	private List<UserRoleLocationsBean> userRoleLocations=new ArrayList<>();
	private Long prodCatKey;
	private List<UserRoleUtmSourceChannel> userRoleUtmSourceChannels=new ArrayList<>();
	private BigDecimal creditlimit;
	private BigDecimal pricinglimit;
	private List<UserRoleChannelTypeBean> channels =  new ArrayList<>();
	private Long superViosrRole ;
	private String prodCatCode;
	private String prodCatDesc;
	private List<Long> l3Products = new ArrayList<>();
	private boolean isHighRole;
	
	private List<UserRolePincodeBean> userRolePincodes;
	
	public String getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public List<UserRoleLocationsBean> getUserRoleLocations() {
		return userRoleLocations;
	}

	public void setUserRoleLocations(List<UserRoleLocationsBean> userRoleLocations) {
		this.userRoleLocations = userRoleLocations;
	}

	public List<UserRoleProductTypeBean> getUserRoleProductTypes() {
		return userRoleProductTypes;
	}

	public void setUserRoleProductTypes(List<UserRoleProductTypeBean> userRoleProductTypes) {
		this.userRoleProductTypes = userRoleProductTypes;
	}

	public long getUserprodkey() {
		return userprodkey;
	}

	public void setUserprodkey(long userprodkey) {
		this.userprodkey = userprodkey;
	}

	public long getUserrolekey() {
		return userrolekey;
	}

	public void setUserrolekey(long userrolekey) {
		this.userrolekey = userrolekey;
	}

	public long getProdmastkey() {
		return prodmastkey;
	}

	public void setProdmastkey(long prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public long getSubprodkey() {
		return subprodkey;
	}

	public void setSubprodkey(long subprodkey) {
		this.subprodkey = subprodkey;
	}

	public BigDecimal getIsactive() {
		return isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public Long getProdCatKey() {
		return prodCatKey;
	}

	public void setProdCatKey(Long prodCatKey) {
		this.prodCatKey = prodCatKey;
	}

	public List<UserRoleUtmSourceChannel> getUserRoleUtmSourceChannels() {
		return userRoleUtmSourceChannels;
	}

	public void setUserRoleUtmSourceChannels(List<UserRoleUtmSourceChannel> userRoleUtmSourceChannels) {
		this.userRoleUtmSourceChannels = userRoleUtmSourceChannels;
	}

	public BigDecimal getCreditlimit() {
		return creditlimit;
	}

	public void setCreditlimit(BigDecimal creditlimit) {
		this.creditlimit = creditlimit;
	}

	public BigDecimal getPricinglimit() {
		return pricinglimit;
	}

	public void setPricinglimit(BigDecimal pricinglimit) {
		this.pricinglimit = pricinglimit;
	}

	public List<UserRoleChannelTypeBean> getChannels() {
		return channels;
	}

	public void setChannels(List<UserRoleChannelTypeBean> channels) {
		this.channels = channels;
	}

	public Long getSuperViosrRole() {
		return superViosrRole;
	}

	public void setSuperViosrRole(Long superViosrRole) {
		this.superViosrRole = superViosrRole;
	}

	public String getProdCatCode() {
		return prodCatCode;
	}

	public void setProdCatCode(String prodCatCode) {
		this.prodCatCode = prodCatCode;
	}

	public String getProdCatDesc() {
		return prodCatDesc;
	}

	public void setProdCatDesc(String prodCatDesc) {
		this.prodCatDesc = prodCatDesc;
	}

	public List<Long> getL3Products() {
		return l3Products;
	}

	public void setL3Products(List<Long> l3Products) {
		this.l3Products = l3Products;
	}

	@JsonProperty("isHighRole")
	public boolean isHighRole() {
		return isHighRole;
	}

	public void setHighRole(boolean isHighRole) {
		this.isHighRole = isHighRole;
	}

	public List<UserRolePincodeBean> getUserRolePincodes() {
		return userRolePincodes;
	}

	public void setUserRolePincodes(List<UserRolePincodeBean> userRolePincodes) {
		this.userRolePincodes = userRolePincodes;
	}
}
