package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class BfsdEligibilityDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private Double maxHtsEligibility;
	private Float maxHtsTenor;
	private Double maxStsEligibility;
	private Float maxStsTenor;
	private Integer loanAmountEnteredByCustomer;
	private String eligibileProgramCode;

	public Double getMaxHtsEligibility() {
		return maxHtsEligibility;
	}

	public void setMaxHtsEligibility(Double maxHtsEligibility) {
		this.maxHtsEligibility = maxHtsEligibility;
	}

	public Float getMaxHtsTenor() {
		return maxHtsTenor;
	}

	public void setMaxHtsTenor(Float maxHtsTenor) {
		this.maxHtsTenor = maxHtsTenor;
	}

	public Double getMaxStsEligibility() {
		return maxStsEligibility;
	}

	public void setMaxStsEligibility(Double maxStsEligibility) {
		this.maxStsEligibility = maxStsEligibility;
	}

	public Float getMaxStsTenor() {
		return maxStsTenor;
	}

	public void setMaxStsTenor(Float maxStsTenor) {
		this.maxStsTenor = maxStsTenor;
	}

	public Integer getLoanAmountEnteredByCustomer() {
		return loanAmountEnteredByCustomer;
	}

	public void setLoanAmountEnteredByCustomer(Integer loanAmountEnteredByCustomer) {
		this.loanAmountEnteredByCustomer = loanAmountEnteredByCustomer;
	}

	public String getEligibileProgramCode() {
		return eligibileProgramCode;
	}

	public void setEligibileProgramCode(String eligibileProgramCode) {
		this.eligibileProgramCode = eligibileProgramCode;
	}

}