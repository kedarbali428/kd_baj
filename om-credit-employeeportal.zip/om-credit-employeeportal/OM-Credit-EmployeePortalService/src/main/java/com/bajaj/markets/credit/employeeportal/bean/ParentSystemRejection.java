package com.bajaj.markets.credit.employeeportal.bean;

import java.sql.Timestamp;

public class ParentSystemRejection 
{
	private String rejectcode;
	private String rejectcodedesc;
	private Timestamp rejectiondt;
	private String prodkey;
	private Integer coolingperiod;
	
	public String getRejectcode() {
		return rejectcode;
	}
	public void setRejectcode(String rejectcode) {
		this.rejectcode = rejectcode;
	}
	public Timestamp getRejectiondt() {
		return rejectiondt;
	}
	public void setRejectiondt(Timestamp rejectiondt) {
		this.rejectiondt = rejectiondt;
	}
	public String getRejectcodedesc() {
		return rejectcodedesc;
	}
	public void setRejectcodedesc(String rejectcodedesc) {
		this.rejectcodedesc = rejectcodedesc;
	}
	public String getProdkey() {
		return prodkey;
	}
	public void setProdkey(String prodkey) {
		this.prodkey = prodkey;
	}
	public Integer getCoolingperiod() {
		return coolingperiod;
	}
	public void setCoolingperiod(Integer coolingperiod) {
		this.coolingperiod = coolingperiod;
	}
}
