package com.bajaj.markets.credit.employeeportal.bean;

public class BureauEmailDetails {

	   private String emailsegmenttag;
	    
	    private String emailid;

		/**
		 * @return the emailsegmenttag
		 */
		public String getEmailsegmenttag() {
			return emailsegmenttag;
		}

		/**
		 * @param emailsegmenttag the emailsegmenttag to set
		 */
		public void setEmailsegmenttag(String emailsegmenttag) {
			this.emailsegmenttag = emailsegmenttag;
		}

		/**
		 * @return the emailid
		 */
		public String getEmailid() {
			return emailid;
		}

		/**
		 * @param emailid the emailid to set
		 */
		public void setEmailid(String emailid) {
			this.emailid = emailid;
		}
	    }
