package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class EmandateDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String doneFrom;
	private String bankName;
	private String bankAccountNumber;
	private String ifscCode;
	private String micrNumber;
	private String registrationId;
	private String refernaceId;
	private Float maxLimit;
	private String paymentStatus;
	private String registeredFor;
	private String partner;
	private String subRepaymentMode;
	private Timestamp doneTimeStamp;
	private String linkSentBy;
	private Timestamp linkSentDateAndTime;
	private String transactionMessage;
	private String emandateChannelReferanceId;

	public String getDoneFrom() {
		return doneFrom;
	}

	public void setDoneFrom(String doneFrom) {
		this.doneFrom = doneFrom;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getMicrNumber() {
		return micrNumber;
	}

	public void setMicrNumber(String micrNumber) {
		this.micrNumber = micrNumber;
	}

	public String getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}

	public String getRefernaceId() {
		return refernaceId;
	}

	public void setRefernaceId(String refernaceId) {
		this.refernaceId = refernaceId;
	}

	public Float getMaxLimit() {
		return maxLimit;
	}

	public void setMaxLimit(Float maxLimit) {
		this.maxLimit = maxLimit;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getRegisteredFor() {
		return registeredFor;
	}

	public void setRegisteredFor(String registeredFor) {
		this.registeredFor = registeredFor;
	}

	public String getPartner() {
		return partner;
	}

	public void setPartner(String partner) {
		this.partner = partner;
	}

	public String getSubRepaymentMode() {
		return subRepaymentMode;
	}

	public void setSubRepaymentMode(String subRepaymentMode) {
		this.subRepaymentMode = subRepaymentMode;
	}

	public Timestamp getDoneTimeStamp() {
		return doneTimeStamp;
	}

	public void setDoneTimeStamp(Timestamp doneTimeStamp) {
		this.doneTimeStamp = doneTimeStamp;
	}
	public String getLinkSentBy() {
		return linkSentBy;
	}

	public void setLinkSentBy(String linkSentBy) {
		this.linkSentBy = linkSentBy;
	}

	public Timestamp getLinkSentDateAndTime() {
		return linkSentDateAndTime;
	}

	public void setLinkSentDateAndTime(Timestamp linkSentDateAndTime) {
		this.linkSentDateAndTime = linkSentDateAndTime;
	}

	public String getTransactionMessage() {
		return transactionMessage;
	}

	public void setTransactionMessage(String transactionMessage) {
		this.transactionMessage = transactionMessage;
	}

	public String getEmandateChannelReferanceId() {
		return emandateChannelReferanceId;
	}

	public void setEmandateChannelReferanceId(String emandateChannelReferanceId) {
		this.emandateChannelReferanceId = emandateChannelReferanceId;
	}

}
