package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class UserRoleLocationsBean implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private Long userlockey;
	private Long userprodkey;
	private Long citykey;
	private Long isactive;
	private String lstupdateby;
	private Timestamp lstupdatedt;
	public Long getUserlockey() {
		return userlockey;
	}
	public void setUserlockey(Long userlockey) {
		this.userlockey = userlockey;
	}
	public Long getUserprodkey() {
		return userprodkey;
	}
	public void setUserprodkey(Long userprodkey) {
		this.userprodkey = userprodkey;
	}
	public Long getCitykey() {
		return citykey;
	}
	public void setCitykey(Long citykey) {
		this.citykey = citykey;
	}
	public Long getIsactive() {
		return isactive;
	}
	public void setIsactive(Long isactive) {
		this.isactive = isactive;
	}
	public String getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	
}
