package com.bajaj.markets.credit.employeeportal.controller;

import java.util.Date;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.ApplicantCreateRequest;
import com.bajaj.markets.credit.employeeportal.bean.ApplicantDetails;
import com.bajaj.markets.credit.employeeportal.bean.ApplicantProfile;
import com.bajaj.markets.credit.employeeportal.bean.CoapplicantRequest;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.helper.ResponseBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalApplicantService;
import com.google.gson.Gson;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EmployeePortalApplicantController {

	@Autowired
	EmployeePortalApplicantService employeePortalApplicantService;

	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASSNAME = EmployeePortalApplicantController.class.getName();

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Get co-applicant details for Mob-DOB", notes = "Get applicant details for MOB-DOB", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header")
			})
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Applicant fetched sucessfully", response = ApplicantProfile.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Applicant Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid Input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })

	@GetMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/applicant",  produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicantByMobDob(
			@PathVariable(name = "applicationid")@Digits(fraction = 0, integer = 20, message = "applicationId can not be other than digits") Long applicationId,
			@RequestParam(value="mobile",required = true)@Size(min = 10, max = 10, message= "Mobile number  can not be less than 10 or greater than 10")  Long mobile , 
			@RequestParam(value="dateOfBirth",required = true) @DateTimeFormat(pattern="yyyy-MM-dd") Date dateOfBirth,
			@RequestHeader HttpHeaders headers) {
		Gson gson = new Gson();
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Started - getApplicant for the mob-dob : " );
		ApplicantProfile profile = employeePortalApplicantService.getApplicantByMobDob(applicationId,mobile,dateOfBirth, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Ended - Open Market - getApplicant with applicantKey : " + gson.toJson(profile));
		return new ResponseEntity<>(profile, HttpStatus.OK);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Save coapplicant details for application", notes = "Save coapplicant details for  an application", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Applicant saved sucessfully", response = ApplicantProfile.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Applicant Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid Input",response = ErrorBean.class),
			@ApiResponse(code = 409, message = "Conflict",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/applicant", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> createApplicant(
			@PathVariable(name = "applicationid")@Digits(fraction = 0, integer = 20, message = "applicationId can not be other than digits") Long applicationId,
			@Valid @RequestBody ApplicantCreateRequest applicantCreateRequest,BindingResult bindingResult, @RequestHeader HttpHeaders headers) {
		Gson gson = new Gson();
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Started - createApplicant for the request : " + gson.toJson(applicantCreateRequest));
		ApplicantProfile profile;
		if (bindingResult.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside saveApplicant method - Invalid parameters passed");
			throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-1022", bindingResult.getFieldErrors().get(0).getDefaultMessage()));
		}else {
			profile = employeePortalApplicantService.createApplicant(applicantCreateRequest,applicationId, headers);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Ended - Open Market - createApplicant with applicantKey : " + gson.toJson(profile));
			return new ResponseEntity<>(profile, HttpStatus.CREATED);
		}
	}
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch co-applicant Detail on the basis of applicationId", notes = "Fetch co-applicant details on the basis of applicationId", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "applicant fetched successfully", response = ApplicantDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Applicant Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/applicantdetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicantDetailsByApplication(@PathVariable("applicationid") String applicationId,@RequestHeader HttpHeaders headers, 
			@RequestParam(required = false)String applicantType){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getApplicantDetailsByApplication method controller - applicationId: "+ applicationId);
		return new ResponseEntity<>(employeePortalApplicantService.getApplicantDetailsByApplication(Long.valueOf(applicationId),headers,applicantType), HttpStatus.OK);
	}
	
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Delete co-applicant Detail", notes = "Delete co-applicant details on the basis of applicationId", httpMethod = "DELETE")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Applicant Deleted successfully", response = StatusBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Applicant Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@DeleteMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/applicant", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> deleteApplicantDetails(@PathVariable("applicationid") String applicationId,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getApplicantDetailsByApplication method controller - applicationId: "+ applicationId);
		StatusBean deleteStatus = employeePortalApplicantService.deleteApplicantDetails(Long.valueOf(applicationId),headers);
		if (EmployeePortalConstants.FAILURE.equals(deleteStatus.getStatus())) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Delete applicant Failed");
			throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "Delete applicant Failed, applicant not Found.");
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"ApplicantController : Delete applicant Service class completed");
		return new ResponseEntity<>(new ResponseBean(deleteStatus), HttpStatus.OK);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Update co-applicant details for application", notes = "Update co-applicant details for  an application", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Applicant updated sucessfully", response = StatusBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Applicant Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid Input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/applicant", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateApplicant(
			@PathVariable(name = "applicationid")@Digits(fraction = 0, integer = 20, message = "applicationId can not be other than digits") Long applicationId,
			@Valid @RequestBody CoapplicantRequest applicantRequest,BindingResult bindingResult, @RequestHeader HttpHeaders headers) {
		Gson gson = new Gson();
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Started - updateApplicant for the request : " + gson.toJson(applicantRequest));
		if (bindingResult.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateApplicant method - Invalid parameters passed");
			throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-1022", bindingResult.getFieldErrors().get(0).getDefaultMessage()));
		}else {
			StatusBean updateStatus = employeePortalApplicantService.updateApplicant(applicantRequest,applicationId, headers);
			if (EmployeePortalConstants.FAILURE.equals(updateStatus.getStatus())) {
				logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "update applicant Failed");
				throw new CreditEmployeePortalServiceException(HttpStatus.NOT_FOUND, "udpate applicant Failed, applicant not Found.");
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Ended - Open Market - updateApplicant with update status : " + gson.toJson(updateStatus));
			return new ResponseEntity<>(updateStatus, HttpStatus.OK);
		}
	}
}
