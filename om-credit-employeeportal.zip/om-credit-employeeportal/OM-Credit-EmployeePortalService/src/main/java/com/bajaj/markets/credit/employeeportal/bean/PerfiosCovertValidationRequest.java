package com.bajaj.markets.credit.employeeportal.bean;

public class PerfiosCovertValidationRequest {

	private AdditionalParameterDetail additionalParameterDetail;
	
	private OpenArcPerfiosCovertInput openArcPerfiosCovertInput;

	public AdditionalParameterDetail getAdditionalParameterDetail() {
		return additionalParameterDetail;
	}

	public void setAdditionalParameterDetail(AdditionalParameterDetail additionalParameterDetail) {
		this.additionalParameterDetail = additionalParameterDetail;
	}

	public OpenArcPerfiosCovertInput getOpenArcPerfiosCovertInput() {
		return openArcPerfiosCovertInput;
	}

	public void setOpenArcPerfiosCovertInput(OpenArcPerfiosCovertInput openArcPerfiosCovertInput) {
		this.openArcPerfiosCovertInput = openArcPerfiosCovertInput;
	}
}
