package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class RepaymentRevisedEmiResponse {
	private List<YearwiseInstallmentBean> yearwiseInstallment;
	private BigDecimal revisedEmi;
	private String firstEmiDate;
	private String nextGrcPftDate;
	private String nextRepayDate;
	private String repaymentType;
	EMICycleDateBean emiCycleDate;
	List<String> emiMonthList;
	private boolean isPricingAvailable;
	private ReturnStatus lmsReturnStatus;
	private String applicationId;
	private Date lstupdateDateTime;
	private String repaymentSource;

	public String getNextGrcPftDate() {
		return nextGrcPftDate;
	}

	public void setNextGrcPftDate(String nextGrcPftDate) {
		this.nextGrcPftDate = nextGrcPftDate;
	}

	public String getNextRepayDate() {
		return nextRepayDate;
	}

	public void setNextRepayDate(String nextRepayDate) {
		this.nextRepayDate = nextRepayDate;
	}
	
	public EMICycleDateBean getEmiCycleDate() {
		return emiCycleDate;
	}

	public void setEmiCycleDate(EMICycleDateBean emiCycleDate) {
		this.emiCycleDate = emiCycleDate;
	}

	public BigDecimal getRevisedEmi() {
		return revisedEmi;
	}

	public void setRevisedEmi(BigDecimal revisedEmi) {
		this.revisedEmi = revisedEmi;
	}

	public String getFirstEmiDate() {
		return firstEmiDate;
	}

	public void setFirstEmiDate(String firstEmiDate) {
		this.firstEmiDate = firstEmiDate;
	}

	public String getRepaymentType() {
		return repaymentType;
	}

	public void setRepaymentType(String repaymentType) {
		this.repaymentType = repaymentType;
	}

	public List<String> getEmiMonthList() {
		return emiMonthList;
	}

	public void setEmiMonthList(List<String> emiMonthList) {
		this.emiMonthList = emiMonthList;
	}


	public List<YearwiseInstallmentBean> getYearwiseInstallment() {
		return yearwiseInstallment;
	}

	public void setYearwiseInstallment(List<YearwiseInstallmentBean> yearwiseInstallment) {
		this.yearwiseInstallment = yearwiseInstallment;
	}

	public boolean isPricingAvailable() {
		return isPricingAvailable;
	}

	public void setPricingAvailable(boolean isPricingAvailable) {
		this.isPricingAvailable = isPricingAvailable;
	}

	public ReturnStatus getLmsReturnStatus() {
		return lmsReturnStatus;
	}

	public void setLmsReturnStatus(ReturnStatus lmsReturnStatus) {
		this.lmsReturnStatus = lmsReturnStatus;
	}

	public Date getLstupdateDateTime() {
		return lstupdateDateTime;
	}

	public void setLstupdateDateTime(Date lstupdateDateTime) {
		this.lstupdateDateTime = lstupdateDateTime;
	}

	public String getRepaymentSource() {
		return repaymentSource;
	}

	public void setRepaymentSource(String repaymentSource) {
		this.repaymentSource = repaymentSource;
	}
	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	
	@Override
	public String toString() {
		return "RepaymentRevisedEmiResponse [yearwiseInstallment=" + yearwiseInstallment + ", revisedEmi=" + revisedEmi
				+ ", firstEmiDate=" + firstEmiDate + ", nextGrcPftDate=" + nextGrcPftDate + ", nextRepayDate="
				+ nextRepayDate + ", repaymentType=" + repaymentType + ", emiCycleDate=" + emiCycleDate
				+ ", emiMonthList=" + emiMonthList + ", isPricingAvailable=" + isPricingAvailable + ", lmsReturnStatus="
				+ lmsReturnStatus + ", applicationId=" + applicationId + ", lstupdateDateTime=" + lstupdateDateTime
				+ ", repaymentSource=" + repaymentSource + "]";
	}
}
