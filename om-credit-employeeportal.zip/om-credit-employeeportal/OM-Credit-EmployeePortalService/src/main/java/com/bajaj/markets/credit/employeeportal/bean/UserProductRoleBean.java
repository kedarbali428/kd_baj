package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class UserProductRoleBean {
	private List<Long> userRoleKey;

	public List<Long> getUserRoleKey() {
		return userRoleKey;
	}

	public void setUserRoleKey(List<Long> userRoleKey) {
		this.userRoleKey = userRoleKey;
	}

}
