package com.bajaj.markets.credit.employeeportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.BreAddressReqOuput;
import com.bajaj.markets.credit.employeeportal.bean.DocPickupAddressRespBean;
import com.bajaj.markets.credit.employeeportal.helper.BusinessHelper;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.helper.ResponseBean;
import com.bajaj.markets.credit.employeeportal.model.AppDetailsVerification;
import com.bajaj.markets.credit.employeeportal.service.DocumentPickupAddressService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
/**
 * @author Deepak Ray
 * Controller for DocPickupAddress
 */
@RestController
public class DocumentPickupAddressController {
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private DocumentPickupAddressService docPickupAddressSvc;
	
	@Autowired
	BusinessHelper businessHelper;

	private static final String CLASSNAME = DocumentPickupAddressController.class.getName();

	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL,Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER})
	@ApiOperation(value = "Update Document Pickup Address", notes = "Document Pickup Address for customer", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	  
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Document Pickup Address Detail found for applicationId", response = AppDetailsVerification.class),
			@ApiResponse(code = 404, message = "Document Pickup Address Detail not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PostMapping(value = "/v1/credit/employeeportal/docpickup/address/{applicationKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateDocPickupAddressDetails(@PathVariable(value = "applicationKey") String applicationId,@RequestHeader HttpHeaders headers){
		AppDetailsVerification appDetailsVerification = new AppDetailsVerification();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "update DocPickup Address Details. ");
			DocPickupAddressRespBean response = docPickupAddressSvc.getDocPickupAddress(applicationId,headers);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Calling open Arch Address Requirement BRE .");
			BreAddressReqOuput openAddressReqOuput = businessHelper.getOpenArcAddressReqBreResponse(response, headers,applicationId);
	        appDetailsVerification = docPickupAddressSvc.getAddressVerification(applicationId, openAddressReqOuput, headers);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "updateDocPickupAddressDetails - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while updating DocPickup Address Details", exception);
			throw exception;
		} 
		return new ResponseEntity<>(new ResponseBean(appDetailsVerification), HttpStatus.OK);
	}
}