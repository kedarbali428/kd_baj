package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the app_disposition_status database table.
 * 
 */
@Entity
@Table(name = "app_disposition_status", schema = "dmcredit")
public class AppDispositionStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_disposition_status_appdisposstskey_generator", sequenceName = "dmcredit.seq_pk_app_disposition_status", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_disposition_status_appdisposstskey_generator")
	private Long appdisposstskey;

	private Long applicationkey;

	private Integer appstatus;

	private Long applsubstagekey;

	private Timestamp followupdt;

	private String followuptime;
	
	private Integer functionkey;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Integer isactive;
	
	@ManyToOne
	@JoinColumn(name="subdispostionkey")
	private SubDispositionCode subDispositionCode;

	public AppDispositionStatus() {
	}

	/**
	 * @return the appdisposstskey
	 */
	public Long getAppdisposstskey() {
		return appdisposstskey;
	}

	/**
	 * @param appdisposstskey the appdisposstskey to set
	 */
	public void setAppdisposstskey(Long appdisposstskey) {
		this.appdisposstskey = appdisposstskey;
	}

	/**
	 * @return the applicationkey
	 */
	public Long getApplicationkey() {
		return applicationkey;
	}

	/**
	 * @param applicationkey the applicationkey to set
	 */
	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	/**
	 * @return the appstatus
	 */
	public Integer getAppstatus() {
		return appstatus;
	}

	/**
	 * @param appstatus the appstatus to set
	 */
	public void setAppstatus(Integer appstatus) {
		this.appstatus = appstatus;
	}

	/**
	 * @return the applsubstagekey
	 */
	public Long getApplsubstagekey() {
		return applsubstagekey;
	}

	/**
	 * @param applsubstagekey the applsubstagekey to set
	 */
	public void setApplsubstagekey(Long applsubstagekey) {
		this.applsubstagekey = applsubstagekey;
	}

	/**
	 * @return the followupdt
	 */
	public Timestamp getFollowupdt() {
		return followupdt;
	}

	/**
	 * @param followupdt the followupdt to set
	 */
	public void setFollowupdt(Timestamp followupdt) {
		this.followupdt = followupdt;
	}

	/**
	 * @return the followuptime
	 */
	public String getFollowuptime() {
		return followuptime;
	}

	/**
	 * @param followuptime the followuptime to set
	 */
	public void setFollowuptime(String followuptime) {
		this.followuptime = followuptime;
	}

	/**
	 * @return the lstupdateby
	 */
	public Long getLstupdateby() {
		return lstupdateby;
	}

	/**
	 * @param lstupdateby the lstupdateby to set
	 */
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	/**
	 * @return the lstupdatedt
	 */
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	/**
	 * @param lstupdatedt the lstupdatedt to set
	 */
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	/**
	 * @return the subDispositionCode
	 */
	public SubDispositionCode getSubDispositionCode() {
		return subDispositionCode;
	}

	/**
	 * @param subDispositionCode the subDispositionCode to set
	 */
	public void setSubDispositionCode(SubDispositionCode subDispositionCode) {
		this.subDispositionCode = subDispositionCode;
	}

	/**
	 * @return the isactive
	 */
	public Integer getIsactive() {
		return isactive;
	}

	/**
	 * @param isactive the isactive to set
	 */
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	/**
	 * @return the functionkey
	 */
	public Integer getFunctionkey() {
		return functionkey;
	}

	/**
	 * @param functionkey the functionkey to set
	 */
	public void setFunctionkey(Integer functionkey) {
		this.functionkey = functionkey;
	}

	

}