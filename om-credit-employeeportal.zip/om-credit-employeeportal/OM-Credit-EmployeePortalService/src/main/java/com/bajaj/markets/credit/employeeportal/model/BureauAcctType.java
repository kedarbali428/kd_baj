package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "bureau_acct_type", schema = "dmverification")
public class BureauAcctType implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "bureau_acct_type__batkey_generator", sequenceName = "dmverification.seq_pk_bureau_acct_type", allocationSize = 1)
	@GeneratedValue(generator = "bureau_acct_type__batkey_generator", strategy = GenerationType.SEQUENCE)
	private Integer batkey;
	private String batvalue;
	private String batacronym;
	private String batuse;
	private String bataccounttype;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private String batclassification;

	// bi-directional many-to-one association to AppExceptionDetail
	@OneToMany(mappedBy = "bureauAcctType")
	private List<BureauAccount> bureauAccount;

	public Integer getBatkey() {
		return batkey;
	}

	public void setBatkey(Integer batkey) {
		this.batkey = batkey;
	}

	public String getBatvalue() {
		return batvalue;
	}

	public void setBatvalue(String batvalue) {
		this.batvalue = batvalue;
	}

	public String getBatacronym() {
		return batacronym;
	}

	public void setBatacronym(String batacronym) {
		this.batacronym = batacronym;
	}

	public String getBatuse() {
		return batuse;
	}

	public void setBatuse(String batuse) {
		this.batuse = batuse;
	}

	public String getBataccounttype() {
		return bataccounttype;
	}

	public void setBataccounttype(String bataccounttype) {
		this.bataccounttype = bataccounttype;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public List<BureauAccount> getBureauAccount() {
		return bureauAccount;
	}

	public void setBureauAccount(List<BureauAccount> bureauAccount) {
		this.bureauAccount = bureauAccount;
	}

	public String getBatclassification() {
		return batclassification;
	}

	public void setBatclassification(String batclassification) {
		this.batclassification = batclassification;
	}
	

}
