package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class VasInvoiceDetailsBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8153075293534791334L;

	private String invoiceStatus;

	private String invoiceNumber;

	private String invoiceDateAndTime;

	public String getInvoiceStatus() {
		return invoiceStatus;
	}

	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getInvoiceDateAndTime() {
		return invoiceDateAndTime;
	}

	public void setInvoiceDateAndTime(String invoiceDateAndTime) {
		this.invoiceDateAndTime = invoiceDateAndTime;
	}

}
