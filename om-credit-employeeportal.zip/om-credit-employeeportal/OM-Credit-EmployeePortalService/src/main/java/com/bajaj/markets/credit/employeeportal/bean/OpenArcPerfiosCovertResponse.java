package com.bajaj.markets.credit.employeeportal.bean;

public class OpenArcPerfiosCovertResponse {

	private OpenArcPerfiosCovertOutput openArcPerfiosCovertOutput;

	public OpenArcPerfiosCovertOutput getOpenArcPerfiosCovertOutput() {
		return openArcPerfiosCovertOutput;
	}

	public void setOpenArcPerfiosCovertOutput(OpenArcPerfiosCovertOutput openArcPerfiosCovertOutput) {
		this.openArcPerfiosCovertOutput = openArcPerfiosCovertOutput;
	}
}
