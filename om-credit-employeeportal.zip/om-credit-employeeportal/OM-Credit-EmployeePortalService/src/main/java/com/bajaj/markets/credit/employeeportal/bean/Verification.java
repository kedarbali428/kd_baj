package com.bajaj.markets.credit.employeeportal.bean;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Verification {

	private boolean isVerified;
	private String verifiedFor;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date verificationDate;
	private String verificationSource;
	private Long verificationReference;
	

	
	public boolean isVerified() {
		return isVerified;
	}
	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}
	public String getVerifiedFor() {
		return verifiedFor;
	}
	public void setVerifiedFor(String verifiedFor) {
		this.verifiedFor = verifiedFor;
	}
	public Date getVerificationDate() {
		return verificationDate;
	}
	public void setVerificationDate(Date verificationDate) {
		this.verificationDate = verificationDate;
	}
	public String getVerificationSource() {
		return verificationSource;
	}
	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}
	public Long getVerificationReference() {
		return verificationReference;
	}
	public void setVerificationReference(Long verificationReference) {
		this.verificationReference = verificationReference;
	}
	
}
