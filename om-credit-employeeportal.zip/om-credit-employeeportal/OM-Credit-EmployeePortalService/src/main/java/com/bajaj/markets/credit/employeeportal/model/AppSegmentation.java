package com.bajaj.markets.credit.employeeportal.model;



import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the app_segmentation database table.
 * 
 */
@Entity
@Table(name="app_segmentation", schema="dmcredit")
public class AppSegmentation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="app_segmentation_appsegmentkey_generator", sequenceName="dmcredit.seq_pk_app_segmentation",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_segmentation_appsegmentkey_generator")
	private Long appsegmentkey;

	private Long applicationkey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long segkey;
	
	private String profilesegment;
	
	private String profilemicrosegment;
	
	private String profileincomesegment;

	public String getProfilesegment() {
		return profilesegment;
	}

	public void setProfilesegment(String profilesegment) {
		this.profilesegment = profilesegment;
	}

	public String getProfilemicrosegment() {
		return profilemicrosegment;
	}

	public void setProfilemicrosegment(String profilemicrosegment) {
		this.profilemicrosegment = profilemicrosegment;
	}

	public AppSegmentation() {
	}

	public Long getAppsegmentkey() {
		return this.appsegmentkey;
	}

	public void setAppsegmentkey(Long appsegmentkey) {
		this.appsegmentkey = appsegmentkey;
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getSegkey() {
		return this.segkey;
	}

	public void setSegkey(Long segkey) {
		this.segkey = segkey;
	}

	public String getProfileincomesegment() {
		return profileincomesegment;
	}

	public void setProfileincomesegment(String profileincomesegment) {
		this.profileincomesegment = profileincomesegment;
	}
}