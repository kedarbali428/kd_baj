package com.bajaj.markets.credit.employeeportal.bean;

public class UserName {

	private String userName;
	
	private long userKey;
	
	private long roleKey;
	
	private long userRoleKey;
	
	private short userType;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}

	public long getRoleKey() {
		return roleKey;
	}

	public void setRoleKey(long roleKey) {
		this.roleKey = roleKey;
	}

	public long getUserRoleKey() {
		return userRoleKey;
	}

	public void setUserRoleKey(long userRoleKey) {
		this.userRoleKey = userRoleKey;
	}

	public short getUserType() {
		return userType;
	}

	public void setUserType(short userType) {
		this.userType = userType;
	}
}
