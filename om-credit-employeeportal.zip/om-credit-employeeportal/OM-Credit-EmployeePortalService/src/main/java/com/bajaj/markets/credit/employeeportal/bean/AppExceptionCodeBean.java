package com.bajaj.markets.credit.employeeportal.bean;

/**
 * Application Stage Details resource 
 * @author 736919
 * 
 */
public class AppExceptionCodeBean {	

	private String appExceptionCode;	
	
	private String appExceptionDesc;	
	
	private String categoryCode;

	public String getAppExceptionCode() {
		return appExceptionCode;
	}

	public void setAppExceptionCode(String appExceptionCode) {
		this.appExceptionCode = appExceptionCode;
	}

	public String getAppExceptionDesc() {
		return appExceptionDesc;
	}

	public void setAppExceptionDesc(String appExceptionDesc) {
		this.appExceptionDesc = appExceptionDesc;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	
	

}
