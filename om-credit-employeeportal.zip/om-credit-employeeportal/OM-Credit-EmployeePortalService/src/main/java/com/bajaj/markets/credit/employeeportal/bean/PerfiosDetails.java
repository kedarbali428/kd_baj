package com.bajaj.markets.credit.employeeportal.bean;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class PerfiosDetails {
	@Id
	private String _id;
	private String applicantkey;
	private String applicationKey;
	private String channel;
	private String channelResponse;
	private String _class;
	
	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}	
	public String getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(String applicantkey) {
		this.applicantkey = applicantkey;
	}

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getChannelResponse() {
		return channelResponse;
	}

	public void setChannelResponse(String channelResponse) {
		this.channelResponse = channelResponse;
	}

	public String get_class() {
		return _class;
	}

	public void set_class(String _class) {
		this._class = _class;
	}

}