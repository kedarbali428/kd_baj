package com.bajaj.markets.credit.employeeportal.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.AppDeviationBean;
import com.bajaj.markets.credit.employeeportal.bean.DeviationByCreditBean;
import com.bajaj.markets.credit.employeeportal.bean.DeviationCodeBean;
import com.bajaj.markets.credit.employeeportal.bean.DeviationDetails;
import com.bajaj.markets.credit.employeeportal.bean.ProductResponseBean;
import com.bajaj.markets.credit.employeeportal.bean.ProductTypeBean;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalDeviationService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EmployeePortalDeviationController {
	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private EmployeePortalDeviationService employeePortalDeviationService;

	private static final String CLASSNAME = EmployeePortalDeviationController.class.getName();

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch product details based on L3 products", notes = "Fetch product details based on applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Product details", response = List.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/credit/applications/{applicationid}/productdetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getProductDetails(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In getProductDetails method with applicationid : " + applicationId);
		// service call
		List<ProductResponseBean> productTypeList = employeePortalDeviationService.getProductDetails(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out getProductDetails method");
		return new ResponseEntity<>(productTypeList, HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch deviation details based on L3 or (L2 and L3)product and applicationId", notes = "Fetch deviation details based on L3 or(L2 and L3)product and applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Deviation details fetched successfully", response = List.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/credit/applications/{applicationid}/product/deviationdetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getDeviationDetail(
			@PathVariable(name = "applicationid", required = true) Long applicationId,
			@RequestParam(value = "prodKey", required = false) Long prodKey, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In getDeviationDetail method with applicationid : " + applicationId + "prodKey : " + prodKey);
		// service call
		List<DeviationCodeBean> deviationCodeList = employeePortalDeviationService.getDeviationDetail(applicationId,
				prodKey);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out getDeviationDetail method");
		return new ResponseEntity<>(deviationCodeList, HttpStatus.OK);
	}
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Add deviation details for applicationId", notes = "Add deviation details for applicationId", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Deviation details added successfully", response = StatusBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/employeeportal/credit/applications/{applicationid}/product/deviationdetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> saveDeviationDetails(@Valid @RequestBody AppDeviationBean appDeviationBean,
			BindingResult result,
			@PathVariable(name = "applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In saveDeviationDetails method with request :" + appDeviationBean);
		StatusBean statusBean = new StatusBean();
		//service call
		 String status = employeePortalDeviationService.saveDeviationDetails(appDeviationBean, applicationId, headers); 
		 statusBean.setMessage(status);
			if (statusBean.getMessage().equalsIgnoreCase(EmployeePortalConstants.DEVIATION_ADDED)) {
				statusBean.setStatus(EmployeePortalConstants.SUCCESS);
				logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Successfully added deviation details");
			}else {
				statusBean.setStatus(EmployeePortalConstants.FAILURE);
			}
		 logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out saveDeviationDetails method");
		return new ResponseEntity<>(statusBean, HttpStatus.CREATED);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Updated deviation details for applicationId", notes = "Add deviation details for applicationId", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Deviation details updated successfully", response = StatusBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "v1/employeeportal/credit/applications/{applicationid}/deviation/{devaitioncodekey}/products/{prodkey}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateDeviationDetails(
			@PathVariable(name = "applicationid") Long applicationid,
			@PathVariable(name = "devaitioncodekey") Integer devaitioncodekey,
			@PathVariable(name = "prodkey") Long prodkey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In updateDeviationDetails method with applicationid :" + applicationid+" devaitioncodekey "+devaitioncodekey+" prodkey "+prodkey);
		StatusBean statusBean = new StatusBean();
		//service call
		 String status = employeePortalDeviationService.updateDeviationDetails(applicationid, devaitioncodekey,prodkey,headers); 
		 statusBean.setMessage(status);
			if (statusBean.getMessage().equalsIgnoreCase(EmployeePortalConstants.DEVIATION_UPDATED)) {
				statusBean.setStatus(EmployeePortalConstants.SUCCESS);
				logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Successfully updated deviation details");
			}else {
				statusBean.setStatus(EmployeePortalConstants.FAILURE);
			}
		 logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateDeviationDetails method");
		return new ResponseEntity<>(statusBean, HttpStatus.CREATED);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetching deviation details for applicationId", notes = "Fetching deviation details for applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Deviation details fetched successfully", response = StatusBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "v1/employeeportal/credit/applications/{applicationid}/deviation", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> fetchDeviationDetails(
			@PathVariable(name = "applicationid") Long applicationid,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In fetchDeviationDetails method with applicationid : " + applicationid);
		 List<DeviationDetails> deviationByCreditBeanList=new ArrayList<DeviationDetails>();
		 deviationByCreditBeanList= employeePortalDeviationService.fetchDeviationDetails(applicationid,headers); 
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Successfully fetched deviation details");
		 logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out fetchDeviationDetails method");
		return new ResponseEntity<>(deviationByCreditBeanList, HttpStatus.CREATED);
	}
}