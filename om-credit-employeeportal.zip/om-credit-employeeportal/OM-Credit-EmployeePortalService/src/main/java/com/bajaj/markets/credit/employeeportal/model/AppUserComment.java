package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "app_user_comment",schema ="dmcredit")
public class AppUserComment implements Serializable{

	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long commentkey;

	private Long applicationkey;

	private Long userrolekey;
	
	private String appcomment;
	
	private Timestamp addeddt;
	
	private Integer isactive;

	private Integer lstupdateby;

	private Timestamp lstupdatedt;

	public Long getCommentkey() {
		return commentkey;
	}

	public void setCommentkey(Long commentkey) {
		this.commentkey = commentkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getUserrolekey() {
		return userrolekey;
	}

	public void setUserrolekey(Long userrolekey) {
		this.userrolekey = userrolekey;
	}

	public String getAppcomment() {
		return appcomment;
	}

	public void setAppcomment(String appcomment) {
		this.appcomment = appcomment;
	}

	public Timestamp getAddeddt() {
		return addeddt;
	}

	public void setAddeddt(Timestamp addeddt) {
		this.addeddt = addeddt;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Integer getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Integer lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}
