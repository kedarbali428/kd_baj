package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class RoleAccessConfigurationBean {

	private Long productTypeKey;
	private Long functionKey;
	private List<Long> roleKeys;
	private List<Long> tabKeys;
	private List<String> tabName;
	private List<TabBean> tabBeanList;
	private List<LinkSectionBean> linkBeanList;
	private List<SectionConfig> ctaSectionList;
	private List<UIFieldSection> uiFieldSectionList;
	private UserRoleBean userRole;
	private List<Long> subprodkey;
	private List<Long> roleProdKeys;
	
	

	private List<Long> groupKeys;
	private List<Long> sectionKeys;
	private List<Long> subSectionKeys;
	private List<FieldSetGroupBean> fieldSetGroups;
	
	
	public List<Long> getGroupKeys() {
		return groupKeys;
	}

	public void setGroupKeys(List<Long> groupKeys) {
		this.groupKeys = groupKeys;
	}

	public List<Long> getSectionKeys() {
		return sectionKeys;
	}

	public void setSectionKeys(List<Long> sectionKeys) {
		this.sectionKeys = sectionKeys;
	}

	public List<Long> getSubSectionKeys() {
		return subSectionKeys;
	}

	public void setSubSectionKeys(List<Long> subSectionKeys) {
		this.subSectionKeys = subSectionKeys;
	}

	public List<FieldSetGroupBean> getFieldSetGroups() {
		return fieldSetGroups;
	}

	public void setFieldSetGroups(List<FieldSetGroupBean> fieldSetGroups) {
		this.fieldSetGroups = fieldSetGroups;
	}

	public List<String> getTabName() {
		return tabName;
	}

	public void setTabName(List<String> tabName) {
		this.tabName = tabName;
	}

	public Long getProductTypeKey() {
		return productTypeKey;
	}

	public void setProductTypeKey(Long productTypeKey) {
		this.productTypeKey = productTypeKey;
	}

	public Long getFunctionKey() {
		return functionKey;
	}

	public void setFunctionKey(Long functionKey) {
		this.functionKey = functionKey;
	}

	public List<Long> getRoleKeys() {
		return roleKeys;
	}

	public void setRoleKeys(List<Long> roleKeys) {
		this.roleKeys = roleKeys;
	}

	public List<Long> getTabKeys() {
		return tabKeys;
	}

	public void setTabKeys(List<Long> tabKeys) {
		this.tabKeys = tabKeys;
	}

	public List<TabBean> getTabBeanList() {
		return tabBeanList;
	}

	public void setTabBeanList(List<TabBean> tabBeanList) {
		this.tabBeanList = tabBeanList;
	}

	public List<SectionConfig> getCtaSectionList() {
		return ctaSectionList;
	}

	public void setCtaSectionList(List<SectionConfig> ctaSectionList) {
		this.ctaSectionList = ctaSectionList;
	}

	public List<UIFieldSection> getUiFieldSectionList() {
		return uiFieldSectionList;
	}

	public void setUiFieldSectionList(List<UIFieldSection> uiFieldSectionList) {
		this.uiFieldSectionList = uiFieldSectionList;
	}
	
	/**
	 * @return the subprodkey
	 */
	public List<Long> getSubprodkey() {
		return subprodkey;
	}

	/**
	 * @param subprodkey the subprodkey to set
	 */
	public void setSubprodkey(List<Long> subprodkey) {
		this.subprodkey = subprodkey;
	}

	public List<LinkSectionBean> getLinkBeanList() {
		return linkBeanList;
	}

	public void setLinkBeanList(List<LinkSectionBean> linkBeanList) {
		this.linkBeanList = linkBeanList;
	}

	@Override
	public String toString() {
		return "RoleAccessConfigurationBean [productTypeKey=" + productTypeKey + ", functionKey=" + functionKey
				+ ", roleKeys=" + roleKeys + ", tabKeys=" + tabKeys + ", tabName=" + tabName + ", tabBeanList="
				+ tabBeanList + ", linkBeanList=" + linkBeanList + ", ctaSectionList=" + ctaSectionList
				+ ", uiFieldSectionList=" + uiFieldSectionList + ", userRole=" + userRole + ", subprodkey=" + subprodkey
				+ ", roleProdKeys=" + roleProdKeys + ", groupKeys=" + groupKeys + ", sectionKeys=" + sectionKeys
				+ ", subSectionKeys=" + subSectionKeys + ", fieldSetGroups=" + fieldSetGroups + "]";
	}

	public UserRoleBean getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRoleBean userRole) {
		this.userRole = userRole;
	}

	/**
	 * @return the roleProdKeys
	 */
	public List<Long> getRoleProdKeys() {
		return roleProdKeys;
	}

	/**
	 * @param roleProdKeys the roleProdKeys to set
	 */
	public void setRoleProdKeys(List<Long> roleProdKeys) {
		this.roleProdKeys = roleProdKeys;
	}
	
	

}
