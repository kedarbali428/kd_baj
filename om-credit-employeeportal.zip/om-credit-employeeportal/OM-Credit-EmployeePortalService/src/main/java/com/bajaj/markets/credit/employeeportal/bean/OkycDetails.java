package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class OkycDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String okycLinkSentBy;
	private String okycLinkSentDateTimeStamp;
	private Long okycId;
	private String okycStatus;
	private String okycStatusChagendBy;
	private String okycStatusChagedDateTime;
	private Timestamp okycTransactionDate;
	private Long applicationKey;
	private Long applicantKey;

	public String getOkycLinkSentBy() {
		return okycLinkSentBy;
	}

	public void setOkycLinkSentBy(String okycLinkSentBy) {
		this.okycLinkSentBy = okycLinkSentBy;
	}

	public String getOkycLinkSentDateTimeStamp() {
		return okycLinkSentDateTimeStamp;
	}

	public void setOkycLinkSentDateTimeStamp(String okycLinkSentDateTimeStamp) {
		this.okycLinkSentDateTimeStamp = okycLinkSentDateTimeStamp;
	}

	public Long getOkycId() {
		return okycId;
	}

	public void setOkycId(Long okycId) {
		this.okycId = okycId;
	}

	public String getOkycStatus() {
		return okycStatus;
	}

	public void setOkycStatus(String okycStatus) {
		this.okycStatus = okycStatus;
	}

	public String getOkycStatusChagendBy() {
		return okycStatusChagendBy;
	}

	public void setOkycStatusChagendBy(String okycStatusChagendBy) {
		this.okycStatusChagendBy = okycStatusChagendBy;
	}

	public String getOkycStatusChagedDateTime() {
		return okycStatusChagedDateTime;
	}

	public void setOkycStatusChagedDateTime(String okycStatusChagedDateTime) {
		this.okycStatusChagedDateTime = okycStatusChagedDateTime;
	}

	public Timestamp getOkycTransactionDate() {
		return okycTransactionDate;
	}

	public void setOkycTransactionDate(Timestamp okycTransactionDate) {
		this.okycTransactionDate = okycTransactionDate;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

}
