package com.bajaj.markets.credit.employeeportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.ApplicationSource;
import com.bajaj.markets.credit.employeeportal.bean.FieldData;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.bean.SubSection;
import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalServiceUtility;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalChildApplicationService;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalSubSectionFieldsServiceInterface;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalUpdateSubSectionFieldsServiceInterface;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author deepak.ray
 * Controller for fetching subsection and field details
 */
@RestController
public class EmployeePortalSubSectionFieldsController {
	
	@Autowired
	EmployeePortalSubSectionFieldsServiceInterface employeePortalSubSectionFieldsService;
	
	@Autowired
	EmployeePortalUpdateSubSectionFieldsServiceInterface employeePortalUpdateSubSectionFieldsServiceInterface;
	
	@Autowired
	EmployeePortalChildApplicationService employeePortalChildRecordListService;
	
	@Autowired
	private EmployeePortalServiceUtility employeePortalServiceUtility;

	
	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASSNAME = EmployeePortalSubSectionFieldsController.class.getName();
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Get Application Subsection fields details", notes = "Get subsections field details with applicationId", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application subsection field details", response = SubSection.class),
			@ApiResponse(code = 404, message = "Stage subsection field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/sections/{sectionId}/subsection/{subsectionId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationSubsectionFields(@PathVariable("applicationid") String applicationId,
			@PathVariable("sectionId") String sectionId, @PathVariable("subsectionId") String subsectionId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Start getApplicationSubsectionFields method controller - for applicationId: " + applicationId);
		// method call to get child records
		ApplicationSource appSource = employeePortalServiceUtility.getValidApplicationId(applicationId,headers,true); 
		// method call to get field attributes
		SubSection subSection = employeePortalSubSectionFieldsService.getApplicationSubsectionFields(

				String.valueOf(appSource.getValidApplicationId()), sectionId, subsectionId, headers);

		// method call to get values for corresponding attributes
		if (null != subSection) {
			subSection = employeePortalSubSectionFieldsService.getSubsectionFieldValues(String.valueOf(appSource.getValidApplicationId()), subSection,
					subsectionId);
			subSection.setSource(appSource.getSource());
			subSection.setApplicationId(String.valueOf(appSource.getValidApplicationId()));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "End getApplicationSubsectionFields method controller.");
		return new ResponseEntity<>(subSection, HttpStatus.OK);
	}
	
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Update subsection", notes = "This resource will be used to update subsection on application", httpMethod = "PUT")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "subsection updated successfully.", response = StatusBean.class),
	@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
	@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
	@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class)})
	@PutMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/sections/{sectionId}/subsection/{subsectionId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateSubsectionFields(@RequestBody List<FieldData> fieldValues,@PathVariable("applicationid") String applicationId,
		@PathVariable("sectionId") String sectionId, @PathVariable("subsectionId") String subsectionId,@RequestHeader HttpHeaders headers) {
	logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
			"Start update subsection method controller - for applicationId: " + applicationId);		
	StatusBean saveStatus = employeePortalUpdateSubSectionFieldsServiceInterface.updateSubsectionFieldValues(fieldValues,applicationId,subsectionId,headers);	
	logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "End update subsection method controller.");
	return new ResponseEntity<>(saveStatus, HttpStatus.OK);
	}
}
