package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class IncomeDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String incomeSource;
	private BigDecimal incomeAmount;
	private String incomeAddedBy;
	private Timestamp incomeAddedTime;

	public String getIncomeSource() {
		return incomeSource;
	}

	public void setIncomeSource(String incomeSource) {
		this.incomeSource = incomeSource;
	}

	public BigDecimal getIncomeAmount() {
		return incomeAmount;
	}

	public void setIncomeAmount(BigDecimal incomeAmount) {
		this.incomeAmount = incomeAmount;
	}

	public String getIncomeAddedBy() {
		return incomeAddedBy;
	}

	public void setIncomeAddedBy(String incomeAddedBy) {
		this.incomeAddedBy = incomeAddedBy;
	}

	public Timestamp getIncomeAddedTime() {
		return incomeAddedTime;
	}

	public void setIncomeAddedTime(Timestamp incomeAddedTime) {
		this.incomeAddedTime = incomeAddedTime;
	}

}
