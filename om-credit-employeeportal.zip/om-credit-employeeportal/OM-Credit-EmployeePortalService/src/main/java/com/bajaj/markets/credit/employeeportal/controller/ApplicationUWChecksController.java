package com.bajaj.markets.credit.employeeportal.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.ApplicationUWChecksBean;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.model.ApplicationUWChecks;
import com.bajaj.markets.credit.employeeportal.service.ApplicationUWChecksService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationUWChecksController {

	@Autowired
	BFLLoggerUtil logger;
	
	@Autowired
	ApplicationUWChecksService applicationUWChecksService;

	private static final String CLASSNAME = ApplicationUWChecksController.class.getName();

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Update UW check status and UW check comments", notes = "Update UW check status and UW check comments", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "UW check status and UW check comments updated successfully", response = ApplicationUWChecksBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "No such record found to update", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@RequestMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/uwchecksdetails", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateUWChecksDetails(
			@PathVariable(name = "applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceed size") String applicationId,
			@RequestBody List<ApplicationUWChecksBean> applicationUWChecksBeanList, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateUWChecksDetails method of ApplicationUWChecksController with applicationId : " + applicationId);
		
		List<ApplicationUWChecks> updatedApplicationUWChecksList = new ArrayList<ApplicationUWChecks>();
		updatedApplicationUWChecksList = applicationUWChecksService.updateUWChecksDetails(applicationId, applicationUWChecksBeanList);
		
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Returning from updateUWChecksDetails method of ApplicationUWChecksController");
		return new ResponseEntity<>(updatedApplicationUWChecksList, HttpStatus.OK);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Get UW check details", notes = "Get UW check details", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "UW check details fetched  successfully", response = ApplicationUWChecksBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "No such record found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@RequestMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/uwchecksdetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUWChecksDetails(
			@PathVariable(name = "applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceed size") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getUWChecksDetails method of ApplicationUWChecksController with applicationId : " + applicationId);
		
		List<ApplicationUWChecksBean> applicationUWChecksBeanList = applicationUWChecksService.getUWChecksDetails(applicationId, headers);
		
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Returning from getUWChecksDetails method of ApplicationUWChecksController");
		return new ResponseEntity<>(applicationUWChecksBeanList, HttpStatus.OK);
	}
}