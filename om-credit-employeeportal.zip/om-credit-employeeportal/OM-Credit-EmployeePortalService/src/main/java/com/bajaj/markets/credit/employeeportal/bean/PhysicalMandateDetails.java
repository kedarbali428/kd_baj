package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class PhysicalMandateDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private Float maxLimit;
	private String barcodeNo;
	private String regitrationId;
	private String referanceId;
	private Timestamp expiryDate;
	private String emiStartDate;
	private String emiEndDate;
	private String mandateAddedBy;
	private Timestamp mandateAddedDatetime;
	private String bankAccountNumber;
	private String mandateIfscCode;
	private String mandatesource;

	public Float getMaxLimit() {
		return maxLimit;
	}

	public void setMaxLimit(Float maxLimit) {
		this.maxLimit = maxLimit;
	}

	public String getBarcodeNo() {
		return barcodeNo;
	}

	public void setBarcodeNo(String barcodeNo) {
		this.barcodeNo = barcodeNo;
	}

	public String getRegitrationId() {
		return regitrationId;
	}

	public void setRegitrationId(String regitrationId) {
		this.regitrationId = regitrationId;
	}

	public String getReferanceId() {
		return referanceId;
	}

	public void setReferanceId(String referanceId) {
		this.referanceId = referanceId;
	}

	public Timestamp getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getEmiStartDate() {
		return emiStartDate;
	}

	public void setEmiStartDate(String emiStartDate) {
		this.emiStartDate = emiStartDate;
	}

	public String getEmiEndDate() {
		return emiEndDate;
	}

	public void setEmiEndDate(String emiEndDate) {
		this.emiEndDate = emiEndDate;
	}

	public String getMandateAddedBy() {
		return mandateAddedBy;
	}

	public void setMandateAddedBy(String mandateAddedBy) {
		this.mandateAddedBy = mandateAddedBy;
	}

	public Timestamp getMandateAddedDatetime() {
		return mandateAddedDatetime;
	}

	public void setMandateAddedDatetime(Timestamp mandateAddedDatetime) {
		this.mandateAddedDatetime = mandateAddedDatetime;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getMandateIfscCode() {
		return mandateIfscCode;
	}

	public void setMandateIfscCode(String mandateIfscCode) {
		this.mandateIfscCode = mandateIfscCode;
	}

	public String getMandatesource() {
		return mandatesource;
	}

	public void setMandatesource(String mandatesource) {
		this.mandatesource = mandatesource;
	}

}