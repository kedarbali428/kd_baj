package com.bajaj.markets.credit.employeeportal.bean;

public class CibilTradelineResponse {
	private String accType;
	private String creditSanctionAmt;
	private String currentBal;
	private String amountOverdue;
	private String opendisbDt;
	private String closeDt;
	private String lastpmtDt;
	private String reportcertDt;
	private String pmtHistory1;
	private String pmtHistory2;
	private String dpdinTradeline;

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getCreditSanctionAmt() {
		return creditSanctionAmt;
	}

	public void setCreditSanctionAmt(String creditSanctionAmt) {
		this.creditSanctionAmt = creditSanctionAmt;
	}

	public String getCurrentBal() {
		return currentBal;
	}

	public void setCurrentBal(String currentBal) {
		this.currentBal = currentBal;
	}

	public String getAmountOverdue() {
		return amountOverdue;
	}

	public void setAmountOverdue(String amountOverdue) {
		this.amountOverdue = amountOverdue;
	}

	public String getOpendisbDt() {
		return opendisbDt;
	}

	public void setOpendisbDt(String opendisbDt) {
		this.opendisbDt = opendisbDt;
	}

	public String getCloseDt() {
		return closeDt;
	}

	public void setCloseDt(String closeDt) {
		this.closeDt = closeDt;
	}

	public String getLastpmtDt() {
		return lastpmtDt;
	}

	public void setLastpmtDt(String lastpmtDt) {
		this.lastpmtDt = lastpmtDt;
	}

	public String getReportcertDt() {
		return reportcertDt;
	}

	public void setReportcertDt(String reportcertDt) {
		this.reportcertDt = reportcertDt;
	}

	public String getPmtHistory1() {
		return pmtHistory1;
	}

	public void setPmtHistory1(String pmtHistory1) {
		this.pmtHistory1 = pmtHistory1;
	}

	public String getPmtHistory2() {
		return pmtHistory2;
	}

	public void setPmtHistory2(String pmtHistory2) {
		this.pmtHistory2 = pmtHistory2;
	}

	public String getDpdinTradeline() {
		return dpdinTradeline;
	}

	public void setDpdinTradeline(String dpdinTradeline) {
		this.dpdinTradeline = dpdinTradeline;
	}

}
