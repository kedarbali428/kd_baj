package com.bajaj.markets.credit.employeeportal.controller;

import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.AppUdfVerificationRequest;
import com.bajaj.markets.credit.employeeportal.bean.CibilRequest;
import com.bajaj.markets.credit.employeeportal.bean.CibilResponse;
import com.bajaj.markets.credit.employeeportal.bean.CustomerDetailsResponse;
import com.bajaj.markets.credit.employeeportal.bean.EmandateRequest;
import com.bajaj.markets.credit.employeeportal.bean.IncomeObligationRequest;
import com.bajaj.markets.credit.employeeportal.bean.IncomeObligationResponse;
import com.bajaj.markets.credit.employeeportal.bean.PanVerificationResponse;
import com.bajaj.markets.credit.employeeportal.bean.SendEmandateRequest;
import com.bajaj.markets.credit.employeeportal.bean.SendNotificationRequest;
import com.bajaj.markets.credit.employeeportal.bean.SendOkycRequest;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.bean.UDFFlagDetails;
import com.bajaj.markets.credit.employeeportal.bean.ValidateCta;
import com.bajaj.markets.credit.employeeportal.customannotation.EnableCTARoleAccessCheck;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.helper.ResponseBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalCtaService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
/**
 * @author Pranoti.Pandole
 * Controller for CTA Validations
 */
@RestController
public class EmployeePortalCtaController {
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private EmployeePortalCtaService employeePortalCtaService;
	
	private static final String CLASSNAME = EmployeePortalCtaController.class.getName();

	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Validate CTA Stage", notes = "Validate send link to customer CTA Stage", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	  
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "CTA Detail found for applicationId", response = ValidateCta.class),
			@ApiResponse(code = 404, message = "CTA Detail not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeeportal/validate/cta/stage/{applicationKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	@EnableCTARoleAccessCheck
	public ResponseEntity<?> validateCtaStage(@PathVariable(value = "applicationKey") Long applicationId,
			@RequestParam(value = "ctaCode") Integer ctaCode, @RequestHeader HttpHeaders headers){
		ValidateCta validateCta = new ValidateCta();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Validating cta stage. ");
			validateCta.setValidStage(employeePortalCtaService.validateCtaStage(applicationId,ctaCode));
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "validateCtaStage - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while validating cta stage", exception);
			throw exception;
		} 
		return new ResponseEntity<>(new ResponseBean(validateCta), HttpStatus.OK);
	}

	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch Customer Details", notes = "Fetch Customer Details", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	  
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Customer Details found for applicationId", response = CustomerDetailsResponse.class),
			@ApiResponse(code = 404, message = "Customer Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeeportal/custdetails/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity <ResponseBean> getCustomer(@PathVariable("applicationId") long applicationKey,
			@RequestParam(name="resume")boolean resume,
			@RequestParam(name="flag",required = false, defaultValue = "false") boolean flag,
			@RequestHeader HttpHeaders headers) {
		 CustomerDetailsResponse customerDetailsResponse = new CustomerDetailsResponse();
		try {
			if(applicationKey==0) {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Application Id required.");
				throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
						new ErrorBean("OMCA_034", "Invalid input."));
			}
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getCustomer starts!. ");
			customerDetailsResponse=employeePortalCtaService.getCustomerDetails(applicationKey, resume, flag,headers);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getCustomer - Completed");
			
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while getting cutomer details", exception);
			throw exception;
		} 
		return new ResponseEntity<>(new ResponseBean(customerDetailsResponse), HttpStatus.OK);
	}
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Send application link", notes = "Send application link", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	  
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application link sent successfully", response = StatusBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Error while sending notification",response = ErrorBean.class)})
	@PostMapping(value = "/v1/employeeportal/links", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity <ResponseBean> sendApplicationLink(@RequestBody SendNotificationRequest sendNotificationrequest,			
			@RequestHeader HttpHeaders headers) {
		StatusBean statusBean = new StatusBean();
		try {
			if(sendNotificationrequest.getApplicationId()==0) {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Application Id required.");
				throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
						new ErrorBean("OMCA_034", "Invalid input."));
			}
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "sendApplicationLink starts!. ");
			statusBean.setMessage(employeePortalCtaService.sendApplicationLink(sendNotificationrequest,headers));
			if(statusBean.getMessage().equalsIgnoreCase(EmployeePortalConstants.COMPLETE))
			statusBean.setStatus(EmployeePortalConstants.SUCCESS);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "sendApplicationLink - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while sending ApplicationLink", exception);
			throw exception;
		} 
		return new ResponseEntity<>(new ResponseBean(statusBean), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Fetch Cibil Details", notes = "Fetch Cibil Details", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Get cibil detail", response = String.class),
			@ApiResponse(code = 404, message = "Application Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/credit/employeeportal/cibil/{applicationid}/details", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getCibilDetails(@PathVariable(name = "applicationid") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In getCibilDetail() for applicationId : " + applicationId);
		
		String cibilString = employeePortalCtaService.getCibilDetails(applicationId, headers);

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out getCibilDetail() with response : " + cibilString);
		return new ResponseEntity<>(cibilString, HttpStatus.OK);

	}
	
		@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "send OKYC Link", notes = "send OKYC Link", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })

	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OKYC link sent successfully", response = StatusBean.class),
			
			@ApiResponse(code = 500, message = "Error while sending notification", response = ErrorBean.class) })
	@PostMapping(value = "/v1/credit/employeeportal/okyc/links", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> sendOkycLink(@RequestBody SendOkycRequest sendokycrequest,
			@RequestHeader HttpHeaders headers) {
		StatusBean statusBean = new StatusBean();
		try {
			if(sendokycrequest.getApplicationKey() ==0) {
				logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Application Id required.");
				throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
						new ErrorBean("OMCA_034", "Invalid input."));
			}
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "sendOkycLink starts!. ");
			statusBean.setMessage(employeePortalCtaService.sendOkycLink(sendokycrequest,headers));
			if(statusBean.getMessage().equalsIgnoreCase(EmployeePortalConstants.COMPLETE))
				statusBean.setStatus(EmployeePortalConstants.SUCCESS);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "sendOkycLink - Completed");
		}catch (Exception exception) {
				logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, 
						"Business Exception occured while sending ApplicationLink", exception);
				throw exception;
			}
			return new ResponseEntity<>(new ResponseBean(statusBean), HttpStatus.OK);
			
		}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "send EMANDATE Link", notes = "send EMANDATE Link", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })

	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "EMANDATE link sent successfully", response = StatusBean.class),
			
			@ApiResponse(code = 500, message = "Error while sending notification", response = ErrorBean.class) })
	@PostMapping(value = "/v1/credit/employeeportal/emandate/links", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> sendEmandateLink(@RequestParam(required = true) String applicationKey,
			@RequestBody EmandateRequest request,
			@RequestHeader HttpHeaders headers) {
		StatusBean statusBean = new StatusBean();
		try {
			if (applicationKey.equals("0")) {
				logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Application Id required.");
				throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
						new ErrorBean("OMCA_034", "Invalid input."));
			}
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "sendOEmandateLink starts!. ");
			SendEmandateRequest sendEmandateRequest = new SendEmandateRequest();
			sendEmandateRequest.setApplicationKey(applicationKey);
			statusBean = employeePortalCtaService.sendEmandateLink(sendEmandateRequest,request,headers);
		
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "sendOEmandateLink - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while sending ApplicationLink", exception);
			throw exception;
		}
		return new ResponseEntity<>(new ResponseBean(statusBean), HttpStatus.OK);

	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Perform CIBIL for an application", notes = "Perform CIBIL for an application", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Cibil Perfomed with requested cibil type and provider and updated Cibil Reference", response = CibilResponse.class),
			@ApiResponse(code = 404, message = "Application Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })

	@PostMapping(value = "/v1/credit/employeeportal/cibil/{applicationid}/details", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> performCibil(
			@PathVariable(name = "applicationid")@Digits(fraction = 0, integer = 20, message = "applicationId can not be other than digits") String applicationId,
			@RequestBody CibilRequest cibilRequest, BindingResult bindingResult, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In performCibil() - start with request: " + cibilRequest);
		CibilResponse cibilResponse = new CibilResponse();
		try {
			if(cibilRequest.getApplicationKey() == 0) {
				logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Application Id required.");
				throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
						new ErrorBean("OMCA_034", "Invalid input."));
			}
		//service call
		cibilResponse = employeePortalCtaService.performCibil(cibilRequest,applicationId, headers);
		
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out performCibil() - with cibilResponse : "+cibilResponse);
	} catch (Exception exception) {
		logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Business Exception occured while adding cibil details", exception);
		throw exception;
	} 
		return new ResponseEntity<>(cibilResponse, HttpStatus.CREATED);

	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Update manual flag for application", notes = "Update manual flag", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Manual Flag updated Successfully.", response = StatusBean.class),
			@ApiResponse(code = 422, message = "Invalid application Id", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Bad Request", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/credit/employeeportal/{applicationid}/manualflag", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateManualFlag(@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@Valid @RequestBody AppUdfVerificationRequest udfVerificationRequest ,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In updateManualFlag for applicationId : " + applicationId);
		StatusBean statusBean = new StatusBean();
		String status = employeePortalCtaService.updateManualFlag(applicationId, udfVerificationRequest,headers);
		statusBean.setMessage(status);
		if (statusBean.getMessage().equalsIgnoreCase(EmployeePortalConstants.MANUAL_FLAG_ADDED)) {
			statusBean.setStatus(EmployeePortalConstants.SUCCESS);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Successfully updated Manual Flag");
		}else {
			statusBean.setStatus(EmployeePortalConstants.FAILURE);
		}
		return new ResponseEntity<>(statusBean, HttpStatus.OK);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch Manual Flag Details", notes = "Fetch Manual Flag Details", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Get Manual Flag detail", response = String.class),
			@ApiResponse(code = 404, message = "Bad Request", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/credit/employeeportal/{applicationid}/manualflag", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getManualFlagDetails(@PathVariable(name = "applicationid")@NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In getManualFlagDetails() for applicationId : " + applicationId);
		List<UDFFlagDetails> flagdetails = employeePortalCtaService.getManualFlagDetails(applicationId, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "fetched Manual Flag details with response : " + flagdetails);
		return new ResponseEntity<>(flagdetails, HttpStatus.OK);	
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Save Obligation and Income Amount", notes = "This resource will be used to save obligation and income amount", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "obligation and income Amount saved/updated successfully.", response = IncomeObligationResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class)})
	@PutMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/incomeobligation", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> updateIncomeObligation(@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@Valid @RequestBody IncomeObligationRequest request, @RequestHeader HttpHeaders headers,BindingResult bindingResult) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In updateIncomeObligation for applicationId : " + applicationId);
		StatusBean statusBean = new StatusBean();
		if (bindingResult.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateIncomeObligation method - Invalid parameters passed");
			throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-1022", bindingResult.getFieldErrors().get(0).getDefaultMessage()));
		}else {
			String status = employeePortalCtaService.updateIncomeObligation(request,applicationId,headers);
			statusBean.setMessage(status);
			if (statusBean.getMessage().equalsIgnoreCase(EmployeePortalConstants.INCOME_OBLIGATION_ADDED)) {
				statusBean.setStatus(EmployeePortalConstants.SUCCESS);
				logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Successfully updated income and obligation..");
			}else {
				statusBean.setStatus(EmployeePortalConstants.FAILURE);
			}
		}
		return new ResponseEntity<>(statusBean, HttpStatus.OK);
	}
	
	
	@ApiOperation(value = "Perform CIBIL for an applicant", notes = "Perform CIBIL for an applicant", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Cibil Perfomed with requested cibil type and provider and updated Cibil Reference", response = CibilResponse.class),
			@ApiResponse(code = 404, message = "Application Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })

	@PostMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/applicant/{applicantkey}/cibil",produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> performCibilForApplicant(	@PathVariable(name = "applicationid")@Digits(fraction = 0, integer = 20, message = "applicationId can not be other than digits") String applicationId,
			@PathVariable(name = "applicantkey")@Digits(fraction = 0, integer = 20, message = "applicantkey can not be other than digits") String applicantkey,
			 @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In performCibilForApplicant() - start with applicantkey: " + applicantkey);
		CibilResponse cibilResponse = new CibilResponse();
		cibilResponse = employeePortalCtaService.performCibilForApplicant(applicationId,applicantkey, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out performCibilForApplicant() - with cibilResponse : "+cibilResponse);
		return new ResponseEntity<>(cibilResponse, HttpStatus.CREATED);


	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Policy Issuance CTA", notes = "Policy Issuance CTA", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Policy issuance triggered successfully", response = StatusBean.class),
			@ApiResponse(code = 404, message = "Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })

	@PutMapping(value = "/v1/credit/employeeportal/applications/{applicationKey}/policyissuance" ,consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> policyIssuance(@PathVariable("applicationKey") @NotBlank(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationKey should be numeric & should not exceeds size") String applicationKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In policyIssuance() - start with applicationKey: " + applicationKey);
		StatusBean statusBean=new StatusBean();
		try {
		String response = employeePortalCtaService.policyIssuance(applicationKey,headers);
		statusBean.setMessage(EmployeePortalConstants.POLICY_ISSUANCE_SUCCESS_MSG);
		statusBean.setStatus(EmployeePortalConstants.SUCCESS);
		
		}catch(Exception e) {
			
			statusBean.setMessage(EmployeePortalConstants.POLICY_ISSUANCE_FAILURE_MSG);
			statusBean.setStatus(EmployeePortalConstants.FAILURE);
		}
		
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out policyIssuance()");
		return new ResponseEntity<>(statusBean, HttpStatus.OK);

	}
	
	@ApiOperation(value = "Perform NSDL for an applicant", notes = "Perform NSDL for an applicant", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "NSDL Perfomed with requested cibil type and provider and updated NSDL Reference", response = CibilResponse.class),
			@ApiResponse(code = 404, message = "Application Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })

	@PostMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/applicants/{applicantid}/nsdl",produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> callNSDLForApplicant(@PathVariable(name = "applicationid")@Digits(fraction = 0, integer = 20, message = "applicationId can not be other than digits") String applicationId,
			@PathVariable(name = "applicantid")@Digits(fraction = 0, integer = 20, message = "applicantkey can not be other than digits") String applicantkey,
			 @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In callNSDLForApplicant() - start with applicantkey: " + applicantkey);
		PanVerificationResponse nsdlResponse = new PanVerificationResponse();
		nsdlResponse = employeePortalCtaService.callNSDLForApplicant(applicationId,applicantkey, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out callNSDLForApplicant() - with nsdlResponse : "+nsdlResponse);
		return new ResponseEntity<>(nsdlResponse, HttpStatus.CREATED);


	}
}
