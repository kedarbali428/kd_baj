package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class FeeCalculationOutput {
private List<PrincipleProductDetailsResponse> principleProductDetails;

public List<PrincipleProductDetailsResponse> getPrincipleProductDetails() {
	return principleProductDetails;
}

public void setPrincipleProductDetails(List<PrincipleProductDetailsResponse> principleProductDetails) {
	this.principleProductDetails = principleProductDetails;
}



}
