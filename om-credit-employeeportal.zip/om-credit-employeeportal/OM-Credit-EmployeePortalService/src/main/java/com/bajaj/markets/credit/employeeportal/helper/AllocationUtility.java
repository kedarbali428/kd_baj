package com.bajaj.markets.credit.employeeportal.helper;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;

/**
 * 	@Description
 *  This class contains utility methods like read property file.
 *
 */
public class AllocationUtility {

	private static final String CLASSNAME = AllocationUtility.class.getCanonicalName();
	
	private AllocationUtility() {
	
	}
	public static Properties readPropertyFile(String propertyFileName, String correlationId){
		Properties prop = new Properties();
		InputStream input = null;

		try {
			input = AllocationUtility.class.getClassLoader().getResourceAsStream(propertyFileName);
			if (input == null) {
				BFLLoggerUtil.info(correlationId, CLASSNAME, BFLLoggerComponent.SERVICE, "Sorry, unable to find file : " );
			}else{
				prop.load(input);
			}

		} catch (IOException ex) {
			BFLLoggerUtil.error(correlationId, CLASSNAME, BFLLoggerComponent.SERVICE,"Unable to read config file. ");
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					BFLLoggerUtil.error(correlationId, CLASSNAME, BFLLoggerComponent.SERVICE,"Exception in closing stream ");
				}
			}
		}
		return prop;
	}
	

	
	/**
	 * @Desc This method is used to get current Timestamp
	 * @return Date
	 */
	public static Timestamp getCurrentDateTimeStamp() {
		Date date=Calendar.getInstance().getTime();
		return new Timestamp(date.getTime());
	}
	
	/**
	 * @Desc This method is used to get effective end date to be stored in db
	 * @return Date
	 */
	public static Date getEffectiveEndDate() {
		try{
			String endDate = getPropertyValue(EmployeePortalConstants.ALLOCATION_CONFIG_PROPERTY_FILE, "default.endDate", null);
			SimpleDateFormat sdf = new SimpleDateFormat(EmployeePortalConstants.SQL_DATE_FORMAT);
			return sdf.parse(endDate);
		} catch(DateTimeParseException pex){
			BFLLoggerUtil.error(null, CLASSNAME, BFLLoggerComponent.SERVICE,"Error in parsing effective end date : ");
			return null;
		} catch(Exception ex){
			BFLLoggerUtil.error(null, CLASSNAME, BFLLoggerComponent.SERVICE,"Error in parsing effective end date : ");
			return null;
		}
	}
	
	public static String getPropertyValue(String propertyFileName, String key, String correlationId){
		Properties prop = new Properties();
		InputStream input = null;
		String propertyValue = null;
		try {
			input = AllocationUtility.class.getClassLoader().getResourceAsStream(propertyFileName);
			if (input == null) {
				BFLLoggerUtil.info(correlationId, CLASSNAME, BFLLoggerComponent.SERVICE,
						"Sorry, unable to find the file :" + propertyFileName);
			}else{
				prop.load(input);
			}

			// get the property value and print it out
			propertyValue = prop.getProperty(key); 

		} catch (IOException ex) {
			BFLLoggerUtil.error(correlationId, CLASSNAME, BFLLoggerComponent.SERVICE, "Unable to read config file. " );
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					BFLLoggerUtil.error(correlationId, CLASSNAME, BFLLoggerComponent.SERVICE, "Exception in closing stream " );
				}
			}
		}
		return propertyValue;
	}
	public static String getExceptionTrace(Exception ex) {
		try {
			StringWriter strbufLog = new StringWriter();
			ex.printStackTrace(new PrintWriter(strbufLog));
			return  strbufLog.toString();
		} catch(Exception e) {
			BFLLoggerUtil.error(null, CLASSNAME, BFLLoggerComponent.SERVICE,"Error in creating Exception Trace"+getExceptionTrace(e));
		}
		return "";
	}

}
