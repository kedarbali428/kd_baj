package com.bajaj.markets.credit.employeeportal.bean;

public class EmailAuditDetails {

	private Long typeKey;
	
	private String emailAddress;

	public Long getTypeKey() {
		return typeKey;
	}

	public void setTypeKey(Long typeKey) {
		this.typeKey = typeKey;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	
}
