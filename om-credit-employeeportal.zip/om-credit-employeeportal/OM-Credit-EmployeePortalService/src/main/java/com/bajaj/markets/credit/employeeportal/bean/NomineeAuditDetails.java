package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class NomineeAuditDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String name;
	private String dateOfBirth;
	private String relationship;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	
}
