package com.bajaj.markets.credit.employeeportal.bean;

import java.util.ArrayList;
import java.util.List;

public class BeneficiaryResponseBean {

	private List<BeneficiaryBean> appDisbAcct = new ArrayList<>();

	public List<BeneficiaryBean> getAppDisbAcct() {
		return appDisbAcct;
	}

	public void setAppDisbAcct(List<BeneficiaryBean> appDisbAcct) {
		this.appDisbAcct = appDisbAcct;
	}
}

