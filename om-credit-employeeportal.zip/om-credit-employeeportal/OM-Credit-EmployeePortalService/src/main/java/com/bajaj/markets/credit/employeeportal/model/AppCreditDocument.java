package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_credit_document", schema = "dmcredit")
public class AppCreditDocument implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_credit_document_appdockey_generator", sequenceName = "dmcredit.seq_pkapp_credit_document", allocationSize = 1)
	@GeneratedValue(generator = "app_credit_document_appdockey_generator", strategy = GenerationType.SEQUENCE)
	private Long appdockey;
	private Long applicationkey;
	private Integer bfsdrefdockey;
	private Integer iscreated;
	private Integer isesignd;
	private Integer generated;
	private Long appdmsdocrefkey;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;

	public Long getAppdockey() {
		return appdockey;
	}

	public void setAppdockey(Long appdockey) {
		this.appdockey = appdockey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getBfsdrefdockey() {
		return bfsdrefdockey;
	}

	public void setBfsdrefdockey(Integer bfsdrefdockey) {
		this.bfsdrefdockey = bfsdrefdockey;
	}

	public Integer getIscreated() {
		return iscreated;
	}

	public void setIscreated(Integer iscreated) {
		this.iscreated = iscreated;
	}

	public Integer getIsesignd() {
		return isesignd;
	}

	public void setIsesignd(Integer isesignd) {
		this.isesignd = isesignd;
	}

	public Integer getGenerated() {
		return generated;
	}

	public void setGenerated(Integer generated) {
		this.generated = generated;
	}

	public Long getAppdmsdocrefkey() {
		return appdmsdocrefkey;
	}

	public void setAppdmsdocrefkey(Long appdmsdocrefkey) {
		this.appdmsdocrefkey = appdmsdocrefkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}
