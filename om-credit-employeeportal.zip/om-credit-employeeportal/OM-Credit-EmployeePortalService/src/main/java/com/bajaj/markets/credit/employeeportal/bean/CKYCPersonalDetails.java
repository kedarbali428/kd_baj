package com.bajaj.markets.credit.employeeportal.bean;

public class CKYCPersonalDetails {

	private String ckycRequestStatus;

	private String accountType;

	private String ckycNumber;

	private String kycVerificationDate;

	private String customerName;

	private String dob;

	private String mobile;

	private String emailAddress;

	private String fatherName;

	private String spouseName;
	
	private String motherName;

	private String gender;

	private String occupation;

	private String addressType;

	private String remarks;


	public String getCkycRequestStatus() {
		return ckycRequestStatus;
	}

	public void setCkycRequestStatus(String ckycRequestStatus) {
		this.ckycRequestStatus = ckycRequestStatus;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCkycNumber() {
		return ckycNumber;
	}

	public void setCkycNumber(String ckycNumber) {
		this.ckycNumber = ckycNumber;
	}

	public String getKycVerificationDate() {
		return kycVerificationDate;
	}

	public void setKycVerificationDate(String kycVerificationDate) {
		this.kycVerificationDate = kycVerificationDate;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getSpouseName() {
		return spouseName;
	}

	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}