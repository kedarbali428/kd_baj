/**
 * 
 */
package com.bajaj.markets.credit.employeeportal.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.employeeportal.bean.IndustryMasterBean;
import com.bajaj.markets.credit.employeeportal.bean.SubIndustryMasterBean;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.IndustrymasterServiceInterface;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author deepak.ray
 * Controller for fetching industry master data
 */
@RestController
public class EmployeePortalIndustryMasterController {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private IndustrymasterServiceInterface industrymasterServiceInterface;
	
	private static final String CLASSNAME = EmployeePortalIndustryMasterController.class.getName();
	
	//@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch Industry Master data", notes = "Fetch Industry Master data", httpMethod = "GET")
//	@ApiImplicitParams({
//	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
//	  })
	  
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Industry Master data found.", response = IndustryMasterBean.class),
			@ApiResponse(code = 404, message = "Industry Master data not found.",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/credit/employeeportal/industrymaster", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getIndustryMasterData(){

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getIndustryMasterData method controller");
		return new ResponseEntity<>(industrymasterServiceInterface.getIndustryMasterData(), HttpStatus.OK);
	}
	
	//@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
		@ApiOperation(value = "Fetch Sub Industry Master data", notes = "Fetch Sub Industry Master data based on indMastKey", httpMethod = "GET")
//		@ApiImplicitParams({
//		    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
//		  })
		  
		@ApiResponses(value = {
				@ApiResponse(code = 200, message = "Sub Industry Master data found.", response = SubIndustryMasterBean.class),
				@ApiResponse(code = 404, message = "Sub Industry Master data not found.",response = ErrorBean.class),
				@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
		@GetMapping(value = "/v1/credit/employeeportal/subindustrymaster/{indMastKey}", produces = MediaType.APPLICATION_JSON_VALUE)
		@CrossOrigin
		public ResponseEntity<?> getSubIndustryMasterData(@PathVariable("indMastKey") String indMastKey ){

			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getIndustryMasterData method controller");
			return new ResponseEntity<>(industrymasterServiceInterface.getSubIndustryMasterData(Long.valueOf(indMastKey)), HttpStatus.OK);
		}
}