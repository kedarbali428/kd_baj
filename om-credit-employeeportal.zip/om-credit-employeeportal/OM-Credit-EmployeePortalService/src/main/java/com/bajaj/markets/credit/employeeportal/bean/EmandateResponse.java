package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.util.List;

public class EmandateResponse {

	private String mandateBitlyUrl;
	private String transactionMessage;
	private String mandateExpiryDate;
	private String mandateCreationSource;
	private String mandateUpdateSource;
	private String mandateReference;
	private String chanelMandateRefId;
	private String chanelTransactionId;
	private String modeofPayment;
	private String status;
	private String micrCode;
	private String authenticationTime;
	private String umrn;
	private String enachId;
	private String authMode;
	private String channel;
	private String mandateCategory;
	private BigDecimal limit;
	private BigDecimal availableLimit;
	private UserInfo userInfo;
	private DestinationBankInfo destinationBankInfo;
	private List<MandateSchedule> mandateSchedule;
	private String barcode;
	private Integer isActive;

	public String getMandateReference() {
		return mandateReference;
	}

	public void setMandateReference(String mandateReference) {
		this.mandateReference = mandateReference;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public String getAuthenticationTime() {
		return authenticationTime;
	}

	public void setAuthenticationTime(String authenticationTime) {
		this.authenticationTime = authenticationTime;
	}

	public String getUmrn() {
		return umrn;
	}

	public void setUmrn(String umrn) {
		this.umrn = umrn;
	}

	public String getEnachId() {
		return enachId;
	}

	public void setEnachId(String enachId) {
		this.enachId = enachId;
	}

	public String getAuthMode() {
		return authMode;
	}

	public void setAuthMode(String authMode) {
		this.authMode = authMode;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getMandateCategory() {
		return mandateCategory;
	}

	public void setMandateCategory(String mandateCategory) {
		this.mandateCategory = mandateCategory;
	}

	public BigDecimal getLimit() {
		return limit;
	}

	public void setLimit(BigDecimal limit) {
		this.limit = limit;
	}

	public BigDecimal getAvailableLimit() {
		return availableLimit;
	}

	public void setAvailableLimit(BigDecimal availableLimit) {
		this.availableLimit = availableLimit;
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public DestinationBankInfo getDestinationBankInfo() {
		return destinationBankInfo;
	}

	public void setDestinationBankInfo(DestinationBankInfo destinationBankInfo) {
		this.destinationBankInfo = destinationBankInfo;
	}

	public List<MandateSchedule> getMandateSchedule() {
		return mandateSchedule;
	}

	public void setMandateSchedule(List<MandateSchedule> mandateSchedule) {
		this.mandateSchedule = mandateSchedule;
	}

	public String getMandateBitlyUrl() {
		return mandateBitlyUrl;
	}

	public void setMandateBitlyUrl(String mandateBitlyUrl) {
		this.mandateBitlyUrl = mandateBitlyUrl;
	}

	public String getChanelMandateRefId() {
		return chanelMandateRefId;
	}

	public void setChanelMandateRefId(String chanelMandateRefId) {
		this.chanelMandateRefId = chanelMandateRefId;
	}

	public String getTransactionMessage() {
		return transactionMessage;
	}

	public void setTransactionMessage(String transactionMessage) {
		this.transactionMessage = transactionMessage;
	}

	public String getChanelTransactionId() {
		return chanelTransactionId;
	}

	public void setChanelTransactionId(String chanelTransactionId) {
		this.chanelTransactionId = chanelTransactionId;
	}

	public String getModeofPayment() {
		return modeofPayment;
	}

	public void setModeofPayment(String modeofPayment) {
		this.modeofPayment = modeofPayment;
	}

	public String getMandateExpiryDate() {
		return mandateExpiryDate;
	}

	public void setMandateExpiryDate(String mandateExpiryDate) {
		this.mandateExpiryDate = mandateExpiryDate;
	}

	public String getMandateCreationSource() {
		return mandateCreationSource;
	}

	public void setMandateCreationSource(String mandateCreationSource) {
		this.mandateCreationSource = mandateCreationSource;
	}

	public String getMandateUpdateSource() {
		return mandateUpdateSource;
	}

	public void setMandateUpdateSource(String mandateUpdateSource) {
		this.mandateUpdateSource = mandateUpdateSource;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "EmandateResponse [mandateBitlyUrl=" + mandateBitlyUrl + ", transactionMessage=" + transactionMessage
				+ ", mandateExpiryDate=" + mandateExpiryDate + ", mandateCreationSource=" + mandateCreationSource
				+ ", mandateUpdateSource=" + mandateUpdateSource + ", mandateReference=" + mandateReference
				+ ", chanelMandateRefId=" + chanelMandateRefId + ", chanelTransactionId=" + chanelTransactionId
				+ ", modeofPayment=" + modeofPayment + ", status=" + status + ", micrCode=" + micrCode
				+ ", authenticationTime=" + authenticationTime + ", umrn=" + umrn + ", enachId=" + enachId
				+ ", authMode=" + authMode + ", channel=" + channel + ", mandateCategory=" + mandateCategory
				+ ", limit=" + limit + ", availableLimit=" + availableLimit + ", userInfo=" + userInfo
				+ ", destinationBankInfo=" + destinationBankInfo + ", mandateSchedule=" + mandateSchedule + ", barcode="
				+ barcode + ", isActive=" + isActive + "]";
	}

}
