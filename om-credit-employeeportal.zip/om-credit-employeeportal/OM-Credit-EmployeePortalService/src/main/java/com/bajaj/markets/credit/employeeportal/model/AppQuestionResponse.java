package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

@Entity
@Table(name = "app_question_response", schema = "dmvas")
public class AppQuestionResponse implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_question_response_appquestionresponsekey_generator", sequenceName = "dmvas.seq_pk_app_question_response", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_question_response_appquestionresponsekey_generator")
	private Integer appquestionresponsekey;
	private String userresponse;
	private Long appproddetkey;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "questionkey")
	@Where(clause = "isvisibletoui = 1")
	private Question question;
	
	public Integer getAppquestionresponsekey() {
		return appquestionresponsekey;
	}

	public void setAppquestionresponsekey(Integer appquestionresponsekey) {
		this.appquestionresponsekey = appquestionresponsekey;
	}

	
	public String getUserresponse() {
		return userresponse;
	}

	public void setUserresponse(String userresponse) {
		this.userresponse = userresponse;
	}

	public Long getAppproddetkey() {
		return appproddetkey;
	}

	public void setAppproddetkey(Long appproddetkey) {
		this.appproddetkey = appproddetkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	/**
	 * @return the question
	 */
	public Question getQuestion() {
		return question;
	}

	/**
	 * @param question the question to set
	 */
	public void setQuestion(Question question) {
		this.question = question;
	}

}
