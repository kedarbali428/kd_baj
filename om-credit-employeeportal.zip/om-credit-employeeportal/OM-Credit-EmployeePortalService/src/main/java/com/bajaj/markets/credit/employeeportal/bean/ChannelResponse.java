package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ChannelResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<MonthwiseDetails> monthwiseDetails;

	public List<MonthwiseDetails> getMonthwiseDetails() {
		return monthwiseDetails;
	}

	public void setMonthwiseDetails(List<MonthwiseDetails> monthwiseDetails) {
		this.monthwiseDetails = monthwiseDetails;
	}

}