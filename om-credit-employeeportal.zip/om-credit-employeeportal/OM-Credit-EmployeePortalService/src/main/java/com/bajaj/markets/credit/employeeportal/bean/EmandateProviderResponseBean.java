package com.bajaj.markets.credit.employeeportal.bean;

public class EmandateProviderResponseBean {

	private Integer bankEmandateServiceKey;
	
	private Integer bankMastKey;
	
	private Integer netBankingFlg;
	
	private Integer debitCardFlg;

	private Integer otpFlg;
	
	private Integer integrationServProviderKey;
	
	private Integer integrationsyskey;
	
	private Integer integrationserviceKey;
	
	private Integer intergrationSysTypeKey;

	private Long principalKey;

	private String integrationsyscd;

	private String integrationsysname;

	public Integer getBankEmandateServiceKey() {
		return bankEmandateServiceKey;
	}

	public void setBankEmandateServiceKey(Integer bankEmandateServiceKey) {
		this.bankEmandateServiceKey = bankEmandateServiceKey;
	}

	public Integer getBankMastKey() {
		return bankMastKey;
	}

	public void setBankMastKey(Integer bankMastKey) {
		this.bankMastKey = bankMastKey;
	}

	public Integer getNetBankingFlg() {
		return netBankingFlg;
	}

	public void setNetBankingFlg(Integer netBankingFlg) {
		this.netBankingFlg = netBankingFlg;
	}

	public Integer getDebitCardFlg() {
		return debitCardFlg;
	}

	public void setDebitCardFlg(Integer debitCardFlg) {
		this.debitCardFlg = debitCardFlg;
	}

	public Integer getOtpFlg() {
		return otpFlg;
	}

	public void setOtpFlg(Integer otpFlg) {
		this.otpFlg = otpFlg;
	}

	public Integer getIntegrationServProviderKey() {
		return integrationServProviderKey;
	}

	public void setIntegrationServProviderKey(Integer integrationServProviderKey) {
		this.integrationServProviderKey = integrationServProviderKey;
	}

	public Integer getIntegrationsyskey() {
		return integrationsyskey;
	}

	public void setIntegrationsyskey(Integer integrationsyskey) {
		this.integrationsyskey = integrationsyskey;
	}

	public Integer getIntegrationserviceKey() {
		return integrationserviceKey;
	}

	public void setIntegrationserviceKey(Integer integrationserviceKey) {
		this.integrationserviceKey = integrationserviceKey;
	}

	public Integer getIntergrationSysTypeKey() {
		return intergrationSysTypeKey;
	}

	public void setIntergrationSysTypeKey(Integer intergrationSysTypeKey) {
		this.intergrationSysTypeKey = intergrationSysTypeKey;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public String getIntegrationsyscd() {
		return integrationsyscd;
	}

	public void setIntegrationsyscd(String integrationsyscd) {
		this.integrationsyscd = integrationsyscd;
	}

	public String getIntegrationsysname() {
		return integrationsysname;
	}

	public void setIntegrationsysname(String integrationsysname) {
		this.integrationsysname = integrationsysname;
	}
	
}
