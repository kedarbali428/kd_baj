package com.bajaj.markets.credit.employeeportal.bean;

import java.sql.Timestamp;

public class PerfiosManualFlagDetails {

	private String flagName;
	private String flagDescription;
	private String flagStatus;
	private String flagAddedBy;
	private String flagCreatedDate;
	private String flagAddedOn;
	private String applicationId;
	public String getFlagName() {
		return flagName;
	}
	public void setFlagName(String flagName) {
		this.flagName = flagName;
	}
	public String getFlagDescription() {
		return flagDescription;
	}
	public void setFlagDescription(String flagDescription) {
		this.flagDescription = flagDescription;
	}
	public String getFlagStatus() {
		return flagStatus;
	}
	public void setFlagStatus(String flagStatus) {
		this.flagStatus = flagStatus;
	}
	public String getFlagAddedBy() {
		return flagAddedBy;
	}
	public void setFlagAddedBy(String flagAddedBy) {
		this.flagAddedBy = flagAddedBy;
	}
	public String getFlagCreatedDate() {
		return flagCreatedDate;
	}
	public void setFlagCreatedDate(String flagCreatedDate) {
		this.flagCreatedDate = flagCreatedDate;
	}
	public String getFlagAddedOn() {
		return flagAddedOn;
	}
	public void setFlagAddedOn(String flagAddedOn) {
		this.flagAddedOn = flagAddedOn;
	}
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
}
