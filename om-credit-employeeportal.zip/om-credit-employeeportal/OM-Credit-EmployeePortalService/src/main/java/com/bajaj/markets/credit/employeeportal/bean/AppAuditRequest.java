package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class AppAuditRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Integer fieldCode;
    private String fieldName;
    private String oldFieldValue;
    private String newFieldValue;
    @JsonIgnore
	private boolean created;
	public Integer getFieldCode() {
		return fieldCode;
	}
	public void setFieldCode(Integer fieldCode) {
		this.fieldCode = fieldCode;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getOldFieldValue() {
		return oldFieldValue;
	}
	public void setOldFieldValue(String oldFieldValue) {
		this.oldFieldValue = oldFieldValue;
	}
	public String getNewFieldValue() {
		return newFieldValue;
	}
	public void setNewFieldValue(String newFieldValue) {
		this.newFieldValue = newFieldValue;
	}
	public boolean isCreated() {
		return created;
	}
	public void setCreated(boolean created) {
		this.created = created;
	}
}
