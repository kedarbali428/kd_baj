package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class ProductBean {
	private long productId;
	private String productName;
	private String productCode;
	private boolean isActive;
	private List<ProductTypeBean> productTypeBeans;
	private long productCatKey; 
	private String productCatName;
	private long productMastKey;
	private String productMastName;
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public List<ProductTypeBean> getProductTypeBeans() {
		return productTypeBeans;
	}
	public void setProductTypeBeans(List<ProductTypeBean> productTypeBeans) {
		this.productTypeBeans = productTypeBeans;
	}
	public long getProductCatKey() {
		return productCatKey;
	}
	public void setProductCatKey(long productCatKey) {
		this.productCatKey = productCatKey;
	}
	public String getProductCatName() {
		return productCatName;
	}
	public void setProductCatName(String productCatName) {
		this.productCatName = productCatName;
	}
	public long getProductMastKey() {
		return productMastKey;
	}
	public void setProductMastKey(long productMastKey) {
		this.productMastKey = productMastKey;
	}
	public String getProductMastName() {
		return productMastName;
	}
	public void setProductMastName(String productMastName) {
		this.productMastName = productMastName;
	}

	
}
