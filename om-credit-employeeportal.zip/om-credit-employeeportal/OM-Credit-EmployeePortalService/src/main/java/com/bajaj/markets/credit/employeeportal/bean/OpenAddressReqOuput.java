package com.bajaj.markets.credit.employeeportal.bean;

import java.util.ArrayList;
import java.util.List;

public class OpenAddressReqOuput {

	private List<String> rejectCode = new ArrayList<String>();
	private Boolean permenantAddressRequired;
	private Boolean officeAddressRequired;
	private Boolean documentPickatResidence;
	private Boolean documentPickatOffice;
	private Boolean stpFlagOutput;
	private Boolean videoPdRequiredFlag;
	
	public Boolean getVideoPdRequiredFlag() {
		return videoPdRequiredFlag;
	}

	public void setVideoPdRequiredFlag(Boolean videoPdRequiredFlag) {
		this.videoPdRequiredFlag = videoPdRequiredFlag;
	}

	public List<String> getRejectCode() {
		return rejectCode;
	}

	public void setRejectCode(List<String> rejectCode) {
		this.rejectCode = rejectCode;
	}

	public Boolean getPermenantAddressRequired() {
		return permenantAddressRequired;
	}

	public void setPermenantAddressRequired(Boolean permenantAddressRequired) {
		this.permenantAddressRequired = permenantAddressRequired;
	}

	public Boolean getOfficeAddressRequired() {
		return officeAddressRequired;
	}

	public void setOfficeAddressRequired(Boolean officeAddressRequired) {
		this.officeAddressRequired = officeAddressRequired;
	}

	public Boolean getDocumentPickatResidence() {
		return documentPickatResidence;
	}

	public void setDocumentPickatResidence(Boolean documentPickatResidence) {
		this.documentPickatResidence = documentPickatResidence;
	}

	public Boolean getDocumentPickatOffice() {
		return documentPickatOffice;
	}

	public void setDocumentPickatOffice(Boolean documentPickatOffice) {
		this.documentPickatOffice = documentPickatOffice;
	}

	public Boolean getStpFlagOutput() {
		return stpFlagOutput;
	}

	public void setStpFlagOutput(Boolean stpFlagOutput) {
		this.stpFlagOutput = stpFlagOutput;
	}

}
