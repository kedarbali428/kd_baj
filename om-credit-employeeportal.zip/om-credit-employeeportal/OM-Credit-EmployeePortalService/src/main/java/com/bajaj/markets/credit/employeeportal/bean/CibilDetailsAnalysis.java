package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CibilDetailsAnalysis implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String numberOfUslTwelveMonths;
	private String totalLoanAmountUslTwelveMonths;
	private String numberOfEnquiriesSixMonths;
	private String everWriteoffSettled;
	
	public String getNumberOfUslTwelveMonths() {
		return numberOfUslTwelveMonths;
	}
	public void setNumberOfUslTwelveMonths(String numberOfUslTwelveMonths) {
		this.numberOfUslTwelveMonths = numberOfUslTwelveMonths;
	}
	public String getTotalLoanAmountUslTwelveMonths() {
		return totalLoanAmountUslTwelveMonths;
	}
	public void setTotalLoanAmountUslTwelveMonths(String totalLoanAmountUslTwelveMonths) {
		this.totalLoanAmountUslTwelveMonths = totalLoanAmountUslTwelveMonths;
	}
	public String getNumberOfEnquiriesSixMonths() {
		return numberOfEnquiriesSixMonths;
	}
	public void setNumberOfEnquiriesSixMonths(String numberOfEnquiriesSixMonths) {
		this.numberOfEnquiriesSixMonths = numberOfEnquiriesSixMonths;
	}
	public String getEverWriteoffSettled() {
		return everWriteoffSettled;
	}
	public void setEverWriteoffSettled(String everWriteoffSettled) {
		this.everWriteoffSettled = everWriteoffSettled;
	}
	
}
