package com.bajaj.markets.credit.employeeportal.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.AuthUserBean;
import com.bajaj.markets.credit.employeeportal.bean.RoleProdAccessBean;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.RoleProdAccessService;
import com.bajaj.markets.credit.employeeportal.util.EmployeePortalUtil;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class RoleProdAccessController {
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	RoleProdAccessService roleProdAccessService;
	
	private static final String CLASSNAME = RoleProdAccessController.class.getName();
	
	@ApiOperation(value = "Get RoleProductAccess bean", notes = "Get RoleProductAccess bean", httpMethod = "GET")
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get RoleProductAccess bean", response = RoleProdAccessBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/credit/employeeportal/role/products", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin	
	public ResponseEntity<?> getRoleProductAccess(@RequestParam(name="prodCode") String prodCode, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getRoleProductAccess method controller with prodCode : " + prodCode);
		List<RoleProdAccessBean> roleProdAccessBeans = new ArrayList<RoleProdAccessBean>();
		try {
			roleProdAccessBeans = roleProdAccessService.getRoleProductAccess(prodCode);
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Technical Exception occured while getting roleProdAccessBeans", exception);
			throw exception;
		} 
		return new ResponseEntity<>(roleProdAccessBeans, HttpStatus.OK);
	}
}
