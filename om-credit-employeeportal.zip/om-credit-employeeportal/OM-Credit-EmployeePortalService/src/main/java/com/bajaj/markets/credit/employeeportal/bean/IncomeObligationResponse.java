package com.bajaj.markets.credit.employeeportal.bean;

public class IncomeObligationResponse {

	private String appoccupationsalarykey;
	private String obligationkey;
	
	public String getAppoccupationsalarykey() {
		return appoccupationsalarykey;
	}
	public void setAppoccupationsalarykey(String appoccupationsalarykey) {
		this.appoccupationsalarykey = appoccupationsalarykey;
	}
	public String getObligationkey() {
		return obligationkey;
	}
	public void setObligationkey(String obligationkey) {
		this.obligationkey = obligationkey;
	} 
	
}
