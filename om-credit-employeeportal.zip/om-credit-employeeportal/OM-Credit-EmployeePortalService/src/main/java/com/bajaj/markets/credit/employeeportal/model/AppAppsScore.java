package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_apps_score", schema = "dmcredit")
public class AppAppsScore implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_apps_score_appsscorekey_generator", sequenceName = "dmcredit.seq_pk_app_apps_score", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_apps_score_appsscorekey_generator")
	private Long appsscorekey;
	private Long applicationkey;
	private Integer finalscore;
	private Integer lrscore;
	private Integer miscore;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	private Integer lrscorev2;

	public Long getAppsscorekey() {
		return appsscorekey;
	}

	public void setAppsscorekey(Long appsscorekey) {
		this.appsscorekey = appsscorekey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Integer getFinalscore() {
		return finalscore;
	}

	public void setFinalscore(Integer finalscore) {
		this.finalscore = finalscore;
	}

	public Integer getLrscore() {
		return lrscore;
	}

	public void setLrscore(Integer lrscore) {
		this.lrscore = lrscore;
	}

	public Integer getMiscore() {
		return miscore;
	}

	public void setMiscore(Integer miscore) {
		this.miscore = miscore;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Integer getLrscorev2() {
		return lrscorev2;
	}

	public void setLrscorev2(Integer lrscorev2) {
		this.lrscorev2 = lrscorev2;
	}

	@Override
	public String toString() {
		return "AppAppsScore [appsscorekey=" + appsscorekey + ", applicationkey=" + applicationkey + ", finalscore="
				+ finalscore + ", lrscore=" + lrscore + ", miscore=" + miscore + ", isactive=" + isactive
				+ ", lstupdateby=" + lstupdateby + ", lstupdatedt=" + lstupdatedt + ", lrscorev2=" + lrscorev2 + "]";
	}

}
