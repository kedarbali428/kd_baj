package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class QualificationDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String registrationNo;
	private String degreeAsPerCustomer;
	private String specializationAsPerCustomer;
	private String experienceAsPerCustomerEntered;
	private String yearOfUg;
	private String yearOfPg;
	private String occupation;
	private String occupationType;
	private String certificateOfPracticeYear;

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public String getDegreeAsPerCustomer() {
		return degreeAsPerCustomer;
	}

	public void setDegreeAsPerCustomer(String degreeAsPerCustomer) {
		this.degreeAsPerCustomer = degreeAsPerCustomer;
	}

	public String getSpecializationAsPerCustomer() {
		return specializationAsPerCustomer;
	}

	public void setSpecializationAsPerCustomer(String specializationAsPerCustomer) {
		this.specializationAsPerCustomer = specializationAsPerCustomer;
	}

	public String getExperienceAsPerCustomerEntered() {
		return experienceAsPerCustomerEntered;
	}

	public void setExperienceAsPerCustomerEntered(String experienceAsPerCustomerEntered) {
		this.experienceAsPerCustomerEntered = experienceAsPerCustomerEntered;
	}

	public String getYearOfUg() {
		return yearOfUg;
	}

	public void setYearOfUg(String yearOfUg) {
		this.yearOfUg = yearOfUg;
	}

	public String getYearOfPg() {
		return yearOfPg;
	}

	public void setYearOfPg(String yearOfPg) {
		this.yearOfPg = yearOfPg;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getOccupationType() {
		return occupationType;
	}

	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}

	public String getCertificateOfPracticeYear() {
		return certificateOfPracticeYear;
	}

	public void setCertificateOfPracticeYear(String certificateOfPracticeYear) {
		this.certificateOfPracticeYear = certificateOfPracticeYear;
	}

}
