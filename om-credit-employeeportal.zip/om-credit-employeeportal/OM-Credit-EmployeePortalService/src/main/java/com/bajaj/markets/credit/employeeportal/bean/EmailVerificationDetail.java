package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.util.Date;

public class EmailVerificationDetail {

	private Long emailVerificationKey;
	private Long applicantId;
	private Long applicationId;
	private Long productCatkey;
	private Integer productMastserkey;
	private String emailId;// "user@example.com",
	private String emailType; // PERSONAL,
	private String status; // INITIATED, EXPIRED, VERIFIED
	private Boolean emailSentFlag;
	private Long verificationIdKey;
	private String verificationSrc;
	private String verificationProcessStatus;//PENDING or COMPLETED
	private String verificationMethod; // "TOKEN", "OTP"
	private String token; // "3fa85f64-5717-4562-b3fc-2c963f66afa6",
	private BigDecimal otp;
	private Boolean verifiedFlag;
	private Date verificationdt;
	public Long getEmailVerificationKey() {
		return emailVerificationKey;
	}
	public void setEmailVerificationKey(Long emailVerificationKey) {
		this.emailVerificationKey = emailVerificationKey;
	}
	public Long getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public Long getProductCatkey() {
		return productCatkey;
	}
	public void setProductCatkey(Long productCatkey) {
		this.productCatkey = productCatkey;
	}
	public Integer getProductMastserkey() {
		return productMastserkey;
	}
	public void setProductMastserkey(Integer productMastserkey) {
		this.productMastserkey = productMastserkey;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getEmailType() {
		return emailType;
	}
	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Boolean getEmailSentFlag() {
		return emailSentFlag;
	}
	public void setEmailSentFlag(Boolean emailSentFlag) {
		this.emailSentFlag = emailSentFlag;
	}
	public Long getVerificationIdKey() {
		return verificationIdKey;
	}
	public void setVerificationIdKey(Long verificationIdKey) {
		this.verificationIdKey = verificationIdKey;
	}
	public String getVerificationSrc() {
		return verificationSrc;
	}
	public void setVerificationSrc(String verificationSrc) {
		this.verificationSrc = verificationSrc;
	}
	public String getVerificationProcessStatus() {
		return verificationProcessStatus;
	}
	public void setVerificationProcessStatus(String verificationProcessStatus) {
		this.verificationProcessStatus = verificationProcessStatus;
	}
	public String getVerificationMethod() {
		return verificationMethod;
	}
	public void setVerificationMethod(String verificationMethod) {
		this.verificationMethod = verificationMethod;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public BigDecimal getOtp() {
		return otp;
	}
	public void setOtp(BigDecimal otp) {
		this.otp = otp;
	}
	public Boolean getVerifiedFlag() {
		return verifiedFlag;
	}
	public void setVerifiedFlag(Boolean verifiedFlag) {
		this.verifiedFlag = verifiedFlag;
	}
	public Date getVerificationdt() {
		return verificationdt;
	}
	public void setVerificationdt(Date verificationdt) {
		this.verificationdt = verificationdt;
	}
	
}
