package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class ValidateCta implements Serializable{

	private static final long serialVersionUID = 1L;

	private boolean isValidStage;

	/**
	 * @return the isValidStage
	 */
	public boolean isValidStage() {
		return isValidStage;
	}

	/**
	 * @param isValidStage the isValidStage to set
	 */
	public void setValidStage(boolean isValidStage) {
		this.isValidStage = isValidStage;
	}


	
	
	
}
