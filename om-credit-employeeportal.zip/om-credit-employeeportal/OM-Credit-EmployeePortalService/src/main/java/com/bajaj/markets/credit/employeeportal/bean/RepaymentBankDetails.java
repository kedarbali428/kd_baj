package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class RepaymentBankDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String source;
	private String repaymentBankName;
	private String accountHolderName;
	private String repaymentAccountNumber;
	private String repaymentBankMicrNo;
	private String repaymentBankIfscCode;
	private String repaymentMode;
	private String bankBranch;
	private String accounttype;
	private String applicableMandate;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getRepaymentBankName() {
		return repaymentBankName;
	}

	public void setRepaymentBankName(String repaymentBankName) {
		this.repaymentBankName = repaymentBankName;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getRepaymentAccountNumber() {
		return repaymentAccountNumber;
	}

	public void setRepaymentAccountNumber(String repaymentAccountNumber) {
		this.repaymentAccountNumber = repaymentAccountNumber;
	}

	public String getRepaymentBankMicrNo() {
		return repaymentBankMicrNo;
	}

	public void setRepaymentBankMicrNo(String repaymentBankMicrNo) {
		this.repaymentBankMicrNo = repaymentBankMicrNo;
	}

	public String getRepaymentBankIfscCode() {
		return repaymentBankIfscCode;
	}

	public void setRepaymentBankIfscCode(String repaymentBankIfscCode) {
		this.repaymentBankIfscCode = repaymentBankIfscCode;
	}

	public String getRepaymentMode() {
		return repaymentMode;
	}

	public void setRepaymentMode(String repaymentMode) {
		this.repaymentMode = repaymentMode;
	}

	public String getBankBranch() {
		return bankBranch;
	}

	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}

	public String getAccounttype() {
		return accounttype;
	}

	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}

	public String getApplicableMandate() {
		return applicableMandate;
	}

	public void setApplicableMandate(String applicableMandate) {
		this.applicableMandate = applicableMandate;
	}
}
