package com.bajaj.markets.credit.employeeportal.bean;

public class UserMgmtProdCatBean {
	private String name;
	private String key;
	private String code;
	private String productMasterRef;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}
	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the productMasterRef
	 */
	public String getProductMasterRef() {
		return productMasterRef;
	}
	/**
	 * @param productMasterRef the productMasterRef to set
	 */
	public void setProductMasterRef(String productMasterRef) {
		this.productMasterRef = productMasterRef;
	}
	
}
