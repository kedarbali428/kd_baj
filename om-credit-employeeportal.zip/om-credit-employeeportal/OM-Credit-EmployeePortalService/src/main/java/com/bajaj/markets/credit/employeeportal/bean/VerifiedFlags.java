package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class VerifiedFlags implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer mobileNumberVerified;
	private String panVerified;
	private String panVerificationSource;
	private Timestamp panVerificationDate;
	private String panNameMatchFlag;
	private Integer panNameMatchScore;

	public Integer getMobileNumberVerified() {
		return mobileNumberVerified;
	}

	public void setMobileNumberVerified(Integer mobileNumberVerified) {
		this.mobileNumberVerified = mobileNumberVerified;
	}

	public String getPanVerified() {
		return panVerified;
	}

	public void setPanVerified(String panVerified) {
		this.panVerified = panVerified;
	}

	public String getPanVerificationSource() {
		return panVerificationSource;
	}

	public void setPanVerificationSource(String panVerificationSource) {
		this.panVerificationSource = panVerificationSource;
	}

	public Timestamp getPanVerificationDate() {
		return panVerificationDate;
	}

	public void setPanVerificationDate(Timestamp panVerificationDate) {
		this.panVerificationDate = panVerificationDate;
	}

	public String getPanNameMatchFlag() {
		return panNameMatchFlag;
	}

	public void setPanNameMatchFlag(String panNameMatchFlag) {
		this.panNameMatchFlag = panNameMatchFlag;
	}

	public Integer getPanNameMatchScore() {
		return panNameMatchScore;
	}

	public void setPanNameMatchScore(Integer panNameMatchScore) {
		this.panNameMatchScore = panNameMatchScore;
	}

}
