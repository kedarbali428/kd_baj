package com.bajaj.markets.credit.employeeportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.ChildRecord;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.helper.ResponseBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalChildApplicationService;
import com.google.common.base.Strings;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author mahesh.nandure
 * Fetching child record list CTA
 */

@RestController
public class EmployeePortalApplicationController {
	@Autowired
	EmployeePortalChildApplicationService employeePortalChildRecordListService;

	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASSNAME = EmployeePortalApplicationController.class.getName();

	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Get Application ChildRecordList fields details", notes = "Get ChildRecordList field details with parentapplicationid", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application ChildRecord field details", response = ChildRecord.class),
			@ApiResponse(code = 404, message = "Stage ChildRecord field details not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/credit/applications/{parentapplicationid}/childapplicationdetails", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationSubsectionFields(
			@PathVariable("parentapplicationid") Long parentapplicationid,@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Start getApplicationChildRecords method controller - for parentapplicationid: " + parentapplicationid);
		
		// method call to get child records
		List<ChildRecord> childRecords = employeePortalChildRecordListService
				.getApplicationChildRecords(parentapplicationid);

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "End getApplicationChildRecords method controller.");
		return new ResponseEntity<>(childRecords, HttpStatus.OK);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Update child application status", notes = "Update child application inProcess flag to active status", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Child application status updated Successfully.", response = StatusBean.class),
			@ApiResponse(code = 404, message = "Invalid application Id", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/activate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateChildApplicationStatus(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In updateChildApplicationStatus for applicationId : " + applicationId);
		StatusBean statusBean = new StatusBean();

		// service call
		String status = employeePortalChildRecordListService.updateChildApplicationStatus(applicationId, headers);

		if (!Strings.isNullOrEmpty(status)) {
			statusBean.setMessage(status);
			if (statusBean.getMessage().equalsIgnoreCase(EmployeePortalConstants.APPLICATION_UPDATED_SUCCESS))
				statusBean.setStatus(EmployeePortalConstants.SUCCESS);

			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out updateChildApplicationStatus method.");

		}
		return new ResponseEntity<>(new ResponseBean(statusBean), HttpStatus.OK);
	}
}
