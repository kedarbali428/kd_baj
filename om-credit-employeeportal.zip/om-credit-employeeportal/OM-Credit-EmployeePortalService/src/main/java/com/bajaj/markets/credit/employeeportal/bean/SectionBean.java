package com.bajaj.markets.credit.employeeportal.bean;

import java.util.ArrayList;
import java.util.List;

public class SectionBean {

	private long sectionId;
	private String sectionName;
	private long sectionCode;
	private long sectionOrder;
	
	private List<SubSectionalBean> childSections = new ArrayList<>();
	
	
	public List<SubSectionalBean> getChildSections() {
		return childSections;
	}
	public void setChildSections(List<SubSectionalBean> childSections) {
		this.childSections = childSections;
	}
	public long getSectionId() {
		return sectionId;
	}
	public void setSectionId(long sectionId) {
		this.sectionId = sectionId;
	}
	
	public String getSectionName() {
		return sectionName;
	}


	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}


	public long getSectionCode() {
		return sectionCode;
	}


	public void setSectionCode(long sectionCode) {
		this.sectionCode = sectionCode;
	}


	public long getSectionOrder() {
		return sectionOrder;
	}


	public void setSectionOrder(long sectionOrder) {
		this.sectionOrder = sectionOrder;
	}
	@Override
	public String toString() {
		return "SectionBean [sectionId=" + sectionId + ", sectionName=" + sectionName + ", sectionCode=" + sectionCode
				+ ", sectionOrder=" + sectionOrder + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (sectionCode ^ (sectionCode >>> 32));
		result = prime * result + (int) (sectionId ^ (sectionId >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SectionBean other = (SectionBean) obj;
		if (sectionCode != other.sectionCode)
			return false;
		if (sectionId != other.sectionId)
			return false;
		return true;
	}
	
	
}
