package com.bajaj.markets.credit.employeeportal.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Transactions {

	private Long transactionId;
	private Double tansactionAmount;
	private String transactionDateTime;
	private Boolean isUserSelectedSalaryTransaction;
	private Boolean isSalaryTransaction;
	private String chequeNo;
	private String narration;
	private String category;
	private Double balance;
	private String account;
	private String variation;

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public Double getTansactionAmount() {
		return tansactionAmount;
	}

	public void setTansactionAmount(Double tansactionAmount) {
		this.tansactionAmount = tansactionAmount;
	}

	public String getTransactionDateTime() {
		return transactionDateTime;
	}

	public void setTransactionDateTime(String transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}

	public Boolean getIsUserSelectedSalaryTransaction() {
		return isUserSelectedSalaryTransaction;
	}

	public void setIsUserSelectedSalaryTransaction(Boolean isUserSelectedSalaryTransaction) {
		this.isUserSelectedSalaryTransaction = isUserSelectedSalaryTransaction;
	}

	public Boolean getIsSalaryTransaction() {
		return isSalaryTransaction;
	}

	public void setIsSalaryTransaction(Boolean isSalaryTransaction) {
		this.isSalaryTransaction = isSalaryTransaction;
	}

	public String getChequeNo() {
		return chequeNo;
	}

	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}

	public String getNarration() {
		return narration;
	}

	public void setNarration(String narration) {
		this.narration = narration;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getVariation() {
		return variation;
	}

	public void setVariation(String variation) {
		this.variation = variation;
	}

}