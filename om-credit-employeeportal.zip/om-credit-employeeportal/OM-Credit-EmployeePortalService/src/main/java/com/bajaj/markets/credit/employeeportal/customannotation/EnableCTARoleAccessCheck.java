package com.bajaj.markets.credit.employeeportal.customannotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author Deepak Ray
 * 
 *         Method annotated with this annotation will perform the fine grain
 *         check for required parameter.This will help in enhancing third layer
 *         of security for api.
 *
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface EnableCTARoleAccessCheck {

}
