package com.bajaj.markets.credit.employeeportal.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.CityMasterBean;
import com.bajaj.markets.credit.employeeportal.bean.FunctionBean;
import com.bajaj.markets.credit.employeeportal.bean.ProductMasterBean;
import com.bajaj.markets.credit.employeeportal.bean.SupervisorBean;
import com.bajaj.markets.credit.employeeportal.bean.UserProductRoleBean;
import com.bajaj.markets.credit.employeeportal.bean.UserProducts;
import com.bajaj.markets.credit.employeeportal.bean.UserRoleProductBean;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.model.UserRoleProduct;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalUserService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import net.bytebuddy.build.Plugin.Engine.Summary;

@RestController
public class EmployeePortalUserController {
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private EmployeePortalUserService employeePortalUserService;
	
	private static final String CLASSNAME = EmployeePortalUserController.class.getName();
	
	@ApiOperation(value = "Get L2 And L3 products", notes = "Get L2 And L3 products", httpMethod = "GET")
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get L2 And L3 products ", response = ProductMasterBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeeportal/products/{l1ProductKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getProductsCategory(@PathVariable("l1ProductKey") Long l1ProductKey, @RequestHeader HttpHeaders headers){
		ProductMasterBean masterBean = new ProductMasterBean();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getProductsCategory");
			masterBean = employeePortalUserService.findProductCategories(l1ProductKey);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getProductsCategory - Completed");
			
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while getProductsCategory", exception);
			throw exception;
		} 
		return new ResponseEntity<>(masterBean, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get function for l3 product", notes = "Get function for l3 product", httpMethod = "GET")
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })

	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get function for l3 product ", response = FunctionBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeeportal/products/functions", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getProductCategoryFunctions(@RequestParam(name = "l1ProdKey") Long l1ProdcuctKey,
			@RequestParam(name = "l3ProdKey") Long l3ProdcuctKey, @RequestHeader HttpHeaders headers){
		List<FunctionBean> bfsdFunctions = new ArrayList<>();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getProductCategoryFunctions");
			bfsdFunctions = employeePortalUserService.findProductCategoriesFunctions(l1ProdcuctKey,l3ProdcuctKey);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getProductCategoryFunctions - Completed");
			
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while getProductCategoryFunctions", exception);
			throw exception;
		} 
		return new ResponseEntity<>(bfsdFunctions, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get supervisor city location ", notes = "Get supervisor city location", httpMethod = "GET")
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })

	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get supervisor city location ", response = CityMasterBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeeportal/users/supervisors/location", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getSupervisorLocations(@RequestParam(name= "userProdRoleKey") Long userProdRoleKey,
			@RequestHeader HttpHeaders headers){
		List<CityMasterBean> locations = new ArrayList<>();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getSupervisorLocations");
			if(null == userProdRoleKey || 0 ==userProdRoleKey) {
				locations = employeePortalUserService.findAllSupervisorCityLocation();
			}else {
				locations = employeePortalUserService.getSupervisorCityLocation(userProdRoleKey);
			}
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getSupervisorLocations - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while getSupervisorLocations", exception);
			throw exception;
		} 
		return new ResponseEntity<>(locations, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get User role product ", notes = "Get User role product ", httpMethod = "GET")
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get User role product  ", response = UserRoleProduct.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeeportal/userroleproduct", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUserRoleProduct(@RequestParam("userRoleKey") Long userRoleKey,
			@RequestParam("l1ProdKey") Long l1Key,
			@RequestParam("l2ProdKey") Long l3Key,
			@RequestParam(name  = "userRoleProdKey", required = false)Long  userRoleProdKey,
			@RequestHeader HttpHeaders headers){
		UserRoleProductBean userRoleProduct =  new UserRoleProductBean();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getUserRoleProduct"); 
			if( null != userRoleProdKey && 0 != userRoleProdKey) {
				userRoleProduct = employeePortalUserService.findUserRoleProductByUserROleProdKey(userRoleProdKey, headers);
			}else {
				userRoleProduct = employeePortalUserService.findUserRoleProduct(userRoleKey,l1Key,l3Key, headers);
			}
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getUserRoleProduct - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while getUserRoleProduct", exception);
			throw exception;
		} 
		return new ResponseEntity<>(userRoleProduct, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Save User role product ", notes = "Get User role product ", httpMethod = "POST")
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Save User role product  ", response = UserRoleProduct.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@PostMapping(value = "/v1/employeeportal/userroleproduct", consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> saveUserRoleProduct(@RequestBody UserRoleProductBean userRoleProduct,
			@RequestHeader HttpHeaders headers){
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "saveUserRoleProduct");
			userRoleProduct = employeePortalUserService.saveUserRoleProduct(userRoleProduct);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "saveUserRoleProduct - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while saveUserRoleProduct", exception);
			throw exception;
		} 
		return new ResponseEntity<>(userRoleProduct, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get Supervisor Name", notes = "Get Supervisor Name", httpMethod = "GET")
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get Supervisor Name", response = SupervisorBean.class, responseContainer = "List"),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = Exception.class) })
	@GetMapping(value = "/v1/employeeportal/users/supervisors/{roleKey}/{l1ProdKey}/{l2ProdKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getSupervisorName(@PathVariable(name = "roleKey") Long roleKey,
			@PathVariable(name = "l1ProdKey") Long l1ProdKey, @PathVariable(name = "l2ProdKey") Long l2ProdKey,
			@RequestHeader HttpHeaders headers) {
		List<SupervisorBean> supervisorList = new ArrayList<>();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"getSupervisorName - roleKey: " + roleKey + "--l1ProdKey" + l1ProdKey + "--l2ProdKey" + l2ProdKey);
			supervisorList = employeePortalUserService.findSuperVisorName(roleKey, l1ProdKey, l2ProdKey);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getSupervisorName - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Business Exception occured while getSupervisorName",
					exception);
			throw exception;
		}
		return new ResponseEntity<>(supervisorList, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get user mapping", notes = "Get User mapping", httpMethod = "GET")
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get User role mapping", response = SupervisorBean.class, responseContainer = "List"),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = Exception.class) })
	@GetMapping(value = "/v1/employeeportal/users/roles/mapping/{userRoleKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUserRoleProductMapping(@PathVariable(name = "userRoleKey") Long userRoleKey,
			@RequestHeader HttpHeaders headers) {
		List<SupervisorBean> supervisorList = new ArrayList<>();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"getSupervisorName - roleKey: " + userRoleKey );
			supervisorList = employeePortalUserService.getUserRoleProductMapping(userRoleKey);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getUserRoleProductMapping - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Business Exception occured while getUserRoleProductMapping",
					exception);
			throw exception;
		}
		return new ResponseEntity<>(supervisorList, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get user mapping", notes = "Get User mapping", httpMethod = "POST")
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get User role mapping", response = UserRoleProductBean.class, responseContainer = "List"),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = Exception.class) })
	@PostMapping(value = "/v1/employeeportal/users/roles/mapping", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getUserRolesProductMapping(@RequestBody UserProductRoleBean userProductRoleBean,
			@RequestHeader HttpHeaders headers) {
		List<UserRoleProductBean> userRoleProductList = new ArrayList<>();
		try {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"getUserRolesProductMapping - roleKey: " + userProductRoleBean.getUserRoleKey() );
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"getUserRolesProductMapping - roleKey: " + userProductRoleBean.getUserRoleKey().toString() );
			userProductRoleBean.getUserRoleKey().stream().forEach(item->{
				logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
						"getUserRolesProductMapping - roleKey: " + item);
			});
			userRoleProductList = employeePortalUserService.getUserRolesProductMapping(userProductRoleBean, headers);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getUserRoleProductMapping - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Business Exception occured while getUserRoleProductMapping",
					exception);
			throw exception;
		}
		return new ResponseEntity<>(userRoleProductList, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get function for l3 product", notes = "Get function for l3 product", httpMethod = "GET")
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })

	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get function for l3 product ", response = FunctionBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/employeeportal/l3/products/functions", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getL3ProductCategoryFunctions(@RequestParam(name = "l1ProdKey") Long l1ProdcuctKey,
			@RequestParam(name = "l3ProdKey") String l3ProdcuctKey, @RequestHeader HttpHeaders headers){
		List<FunctionBean> bfsdFunctions = new ArrayList<>();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getProductCategoryFunctions");
			bfsdFunctions = employeePortalUserService.findL3ProductCategoriesFunctions(l1ProdcuctKey,l3ProdcuctKey);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getProductCategoryFunctions - Completed");
			
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Business Exception occured while getProductCategoryFunctions", exception);
			throw exception;
		} 
		return new ResponseEntity<>(bfsdFunctions, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Get Supervisor Name", notes = "Get Supervisor Name", httpMethod = "GET")
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get Supervisor Name", response = SupervisorBean.class, responseContainer = "List"),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = Exception.class) })
	@GetMapping(value = "/v1/employeeportal/multi/l3/users/supervisors/{roleKey}/{l1ProdKey}/{l2ProdKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getSupervisorName(@PathVariable(name = "roleKey") Long roleKey,
			@PathVariable(name = "l1ProdKey") Long l1ProdKey, @PathVariable(name = "l2ProdKey") String l2ProdKey,
			@RequestHeader HttpHeaders headers) {
		List<SupervisorBean> supervisorList = new ArrayList<>();
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"getSupervisorName - roleKey: " + roleKey + "--l1ProdKey" + l1ProdKey + "--l2ProdKey" + l2ProdKey);
			supervisorList = employeePortalUserService.findMultiL3SuperVisorName(roleKey, l1ProdKey, l2ProdKey);
			logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER, "getSupervisorName - Completed");
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Business Exception occured while getSupervisorName",
					exception);
			throw exception;
		}
		return new ResponseEntity<>(supervisorList, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Update User Role Product.", notes = "Update User Role Product.", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "User Role Product updated successfully", response = Summary.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = Exception.class) })
	@PutMapping(value = "/v1/employeeportal/userroleproducts/{userRoleProdKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateUserRoleProduct(@PathVariable(name = "userRoleProdKey") Long userRoleProdKey,
			@RequestHeader HttpHeaders headers) {
		boolean successFlag = false;
		try {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Start User Role Product updation :" + userRoleProdKey);
			successFlag = employeePortalUserService.updateUserRoleProduct(userRoleProdKey);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"User Role Product updation Successful" + userRoleProdKey);
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Technical Exception occured while updating User Role Product", exception);
			throw exception;
		} 
		return new ResponseEntity<>(successFlag, HttpStatus.OK);
	}
	@ApiOperation(value = "Get L2 Product based on userRoleKey.", notes = "Get L2 Product based on userRoleKey.", httpMethod = "GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
		})
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "User Role Product updated successfully", response = List.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = Exception.class) })
	@GetMapping(value = "/v1/credit/employeeportal/products/{userRoleKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getProductListForUser(@PathVariable(name = "userRoleKey") Long userRoleKey,
			@RequestHeader HttpHeaders headers) {
		List<UserProducts> userProducts = new ArrayList<>();
		try {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Start getProductListForUser for userRoleKey :" + userRoleKey);
			userProducts = employeePortalUserService.getProductListForUser(userRoleKey);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"End getProductListForUser for userRoleKey : " + userRoleKey);
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Technical Exception occured while updating User Role Product", exception);
			throw exception;
		} 
		return new ResponseEntity<>(userProducts, HttpStatus.OK);
	}
}