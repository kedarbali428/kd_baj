package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "app_occupation_salary", schema = "dmcredit")
public class AppOccupationSalary implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long appoccupationsalarykey;

	private Long appoccupationkey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal salary;

	private String salarysource;

	public Long getAppoccupationsalarykey() {
		return appoccupationsalarykey;
	}

	public void setAppoccupationsalarykey(Long appoccupationsalarykey) {
		this.appoccupationsalarykey = appoccupationsalarykey;
	}

	public Long getAppoccupationkey() {
		return appoccupationkey;
	}

	public void setAppoccupationkey(Long appoccupationkey) {
		this.appoccupationkey = appoccupationkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public String getSalarysource() {
		return salarysource;
	}

	public void setSalarysource(String salarysource) {
		this.salarysource = salarysource;
	}

}
