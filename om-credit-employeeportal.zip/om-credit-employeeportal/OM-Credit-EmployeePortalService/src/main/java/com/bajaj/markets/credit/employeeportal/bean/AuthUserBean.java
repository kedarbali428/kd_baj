package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class AuthUserBean implements Serializable{

	private static final long serialVersionUID = 1L;

	private String userId;
	private String userRoleKey;
	private String role;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserRoleKey() {
		return userRoleKey;
	}
	public void setUserRoleKey(String userRoleKey) {
		this.userRoleKey = userRoleKey;
	}
	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}
	
	
}
