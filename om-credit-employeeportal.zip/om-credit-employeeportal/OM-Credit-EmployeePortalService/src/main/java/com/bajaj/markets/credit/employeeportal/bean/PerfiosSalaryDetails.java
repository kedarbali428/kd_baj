package com.bajaj.markets.credit.employeeportal.bean;

public class PerfiosSalaryDetails {
private Double salaryTransactionAmount;
private String transactionDate;
private String narration;
public Double getSalaryTransactionAmount() {
    return salaryTransactionAmount;
}
public void setSalaryTransactionAmount(Double salaryTransactionAmount) {
    this.salaryTransactionAmount = salaryTransactionAmount;
}
public String getTransactionDate() {
    return transactionDate;
}
public void setTransactionDate(String transactionDate) {
    this.transactionDate = transactionDate;
}
public String getNarration() {
    return narration;
}
public void setNarration(String narration) {
    this.narration = narration;
}
@Override
public String toString() {
    return "PerfiosSalaryDetails [salaryTransactionAmount=" + salaryTransactionAmount + ", transactionDate="
            + transactionDate + ", narration=" + narration + "]";
}

}
