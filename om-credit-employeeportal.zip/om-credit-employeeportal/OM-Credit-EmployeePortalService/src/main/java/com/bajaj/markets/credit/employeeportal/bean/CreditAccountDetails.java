package com.bajaj.markets.credit.employeeportal.bean;

public class CreditAccountDetails {
	
	private String accountnumber;
	private String bankBranch;
	private String bankAccountType;
	private String bankIfscCode;
	private String bankName;
	private String bankMicrNumber;
	public String getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getBankBranch() {
		return bankBranch;
	}
	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}
	public String getBankAccountType() {
		return bankAccountType;
	}
	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}
	public String getBankIfscCode() {
		return bankIfscCode;
	}
	public void setBankIfscCode(String bankIfscCode) {
		this.bankIfscCode = bankIfscCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankMicrNumber() {
		return bankMicrNumber;
	}
	public void setBankMicrNumber(String bankMicrNumber) {
		this.bankMicrNumber = bankMicrNumber;
	}
	

}
