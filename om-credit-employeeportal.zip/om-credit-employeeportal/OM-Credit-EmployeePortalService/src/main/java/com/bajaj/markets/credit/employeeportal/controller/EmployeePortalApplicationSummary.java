package com.bajaj.markets.credit.employeeportal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.ApplicationSummmaryServiceImpl;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import net.bytebuddy.build.Plugin.Engine.Summary;

@RestController
public class EmployeePortalApplicationSummary {
	private static final String CLASSNAME = EmployeePortalApplicationSummary.class.getName();
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	ApplicationSummmaryServiceImpl applicationSummmaryService;

	// app view defination
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch application top level details and CTA", notes = "Fetch application top level details and CTA on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Section Detail found for the user attribute", response = Summary.class),
			@ApiResponse(code = 404, message = "application top level details and CTA", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/summary", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationCtaAndUserTopLevelInfo(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getApplicationSectionDetails method controller - applicationId: " + applicationId);
		return new ResponseEntity<>(
				applicationSummmaryService.fetchApplicationCtaAndUserTopLevelInfo(applicationId, headers),
				HttpStatus.OK);
	}
	
	

	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch application summary details and CTA", notes = "Fetch application  all summary details and CTA on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Section Detail found for the user attribute", response = Summary.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Applicant Details not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/summaryall", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationSummary(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getApplicationSummary method controller - applicationId: " + applicationId);
		return new ResponseEntity<>(
				applicationSummmaryService.getApplicationSummary(applicationId, headers),
				HttpStatus.OK);
	}
}
