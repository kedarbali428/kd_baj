package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class ApplicationUWChecksDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String applicationId;
	private String uwCheckCode;
	private String uwCheckDesc;
	private String applicationValue;
	private String verificationValue;
	private Long matchPercentage;
	private String matchFlag;
	private String uwCheckStatus;
	private String uwCheckComments;
	private Timestamp uwVerifiedDateTime;
	private String uwVerifiedBy;

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getUwCheckCode() {
		return uwCheckCode;
	}

	public void setUwCheckCode(String uwCheckCode) {
		this.uwCheckCode = uwCheckCode;
	}

	public String getUwCheckDesc() {
		return uwCheckDesc;
	}

	public void setUwCheckDesc(String uwCheckDesc) {
		this.uwCheckDesc = uwCheckDesc;
	}

	public String getApplicationValue() {
		return applicationValue;
	}

	public void setApplicationValue(String applicationValue) {
		this.applicationValue = applicationValue;
	}

	public String getVerificationValue() {
		return verificationValue;
	}

	public void setVerificationValue(String verificationValue) {
		this.verificationValue = verificationValue;
	}

	public Long getMatchPercentage() {
		return matchPercentage;
	}

	public void setMatchPercentage(Long matchPercentage) {
		this.matchPercentage = matchPercentage;
	}

	public String getMatchFlag() {
		return matchFlag;
	}

	public void setMatchFlag(String matchFlag) {
		this.matchFlag = matchFlag;
	}

	public String getUwCheckStatus() {
		return uwCheckStatus;
	}

	public void setUwCheckStatus(String uwCheckStatus) {
		this.uwCheckStatus = uwCheckStatus;
	}

	public String getUwCheckComments() {
		return uwCheckComments;
	}

	public void setUwCheckComments(String uwCheckComments) {
		this.uwCheckComments = uwCheckComments;
	}

	public Timestamp getUwVerifiedDateTime() {
		return uwVerifiedDateTime;
	}

	public void setUwVerifiedDateTime(Timestamp uwVerifiedDateTime) {
		this.uwVerifiedDateTime = uwVerifiedDateTime;
	}

	public String getUwVerifiedBy() {
		return uwVerifiedBy;
	}

	public void setUwVerifiedBy(String uwVerifiedBy) {
		this.uwVerifiedBy = uwVerifiedBy;
	}

}