package com.bajaj.markets.credit.employeeportal.bean;

public class LoanPerfiosDetails {
	private String loanAmountCreditDate;
	private String loanAmountCreditNarration;
	private String loanAmountCreditAmount;
	/**
	 * @return the loanAmountCreditDate
	 */
	public String getLoanAmountCreditDate() {
		return loanAmountCreditDate;
	}
	/**
	 * @param loanAmountCreditDate the loanAmountCreditDate to set
	 */
	public void setLoanAmountCreditDate(String loanAmountCreditDate) {
		this.loanAmountCreditDate = loanAmountCreditDate;
	}
	/**
	 * @return the loanAmountCreditNarration
	 */
	public String getLoanAmountCreditNarration() {
		return loanAmountCreditNarration;
	}
	/**
	 * @param loanAmountCreditNarration the loanAmountCreditNarration to set
	 */
	public void setLoanAmountCreditNarration(String loanAmountCreditNarration) {
		this.loanAmountCreditNarration = loanAmountCreditNarration;
	}
	/**
	 * @return the loanAmountCreditAmount
	 */
	public String getLoanAmountCreditAmount() {
		return loanAmountCreditAmount;
	}
	/**
	 * @param loanAmountCreditAmount the loanAmountCreditAmount to set
	 */
	public void setLoanAmountCreditAmount(String loanAmountCreditAmount) {
		this.loanAmountCreditAmount = loanAmountCreditAmount;
	}

}