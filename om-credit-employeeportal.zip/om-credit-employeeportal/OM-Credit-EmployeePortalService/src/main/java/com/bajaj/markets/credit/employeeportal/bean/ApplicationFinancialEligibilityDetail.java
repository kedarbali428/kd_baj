package com.bajaj.markets.credit.employeeportal.bean;

public class ApplicationFinancialEligibilityDetail {

	private Integer finalUnsecuredFoir;
	private Integer applicableMultiplier;
	private Integer MultiplierEligibility;
	private Integer finalFoir;
	private Integer finalMultiplier;
	private String producVarient;
	private Integer eligibilityAmount;
	private Integer imputedSalary;

	public Integer getFinalUnsecuredFoir() {
		return finalUnsecuredFoir;
	}

	public void setFinalUnsecuredFoir(Integer finalUnsecuredFoir) {
		this.finalUnsecuredFoir = finalUnsecuredFoir;
	}

	public Integer getApplicableMultiplier() {
		return applicableMultiplier;
	}

	public void setApplicableMultiplier(Integer applicableMultiplier) {
		this.applicableMultiplier = applicableMultiplier;
	}

	public Integer getMultiplierEligibility() {
		return MultiplierEligibility;
	}

	public void setMultiplierEligibility(Integer multiplierEligibility) {
		MultiplierEligibility = multiplierEligibility;
	}

	public Integer getFinalFoir() {
		return finalFoir;
	}

	public void setFinalFoir(Integer finalFoir) {
		this.finalFoir = finalFoir;
	}

	public Integer getFinalMultiplier() {
		return finalMultiplier;
	}

	public void setFinalMultiplier(Integer finalMultiplier) {
		this.finalMultiplier = finalMultiplier;
	}

	public String getProducVarient() {
		return producVarient;
	}

	public void setProducVarient(String producVarient) {
		this.producVarient = producVarient;
	}

	public Integer getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(Integer eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	public Integer getImputedSalary() {
		return imputedSalary;
	}

	public void setImputedSalary(Integer imputedSalary) {
		this.imputedSalary = imputedSalary;
	}

}
