package com.bajaj.markets.credit.employeeportal.bean;

public class BounceTransactionDetails {
	
	private String bounceTransactionAmount;
	private String bounceTransactionCategory;
	private String bounceTransactionDate;
	private String bounceTransactionNarration;
	
	public String getBounceTransactionAmount() {
		return bounceTransactionAmount;
	}
	public void setBounceTransactionAmount(String bounceTransactionAmount) {
		this.bounceTransactionAmount = bounceTransactionAmount;
	}
	public String getBounceTransactionCategory() {
		return bounceTransactionCategory;
	}
	public void setBounceTransactionCategory(String bounceTransactionCategory) {
		this.bounceTransactionCategory = bounceTransactionCategory;
	}
	public String getBounceTransactionDate() {
		return bounceTransactionDate;
	}
	public void setBounceTransactionDate(String bounceTransactionDate) {
		this.bounceTransactionDate = bounceTransactionDate;
	}
	public String getBounceTransactionNarration() {
		return bounceTransactionNarration;
	}
	public void setBounceTransactionNarration(String bounceTransactionNarration) {
		this.bounceTransactionNarration = bounceTransactionNarration;
	}
	
	
	
	

}
