package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CreditReview implements Serializable {

	private static final long serialVersionUID = 1L;

	private String creditReviewFlag;
	private String finalCustomerSegmentation;
	private String finnoneCustId;
	private String dedupeStatus;
	private String dedupeMatch;
	private String creditStatusEligibility;
	private String creditStatusDisbursement;

	public String getCreditReviewFlag() {
		return creditReviewFlag;
	}

	public void setCreditReviewFlag(String creditReviewFlag) {
		this.creditReviewFlag = creditReviewFlag;
	}

	public String getFinalCustomerSegmentation() {
		return finalCustomerSegmentation;
	}

	public void setFinalCustomerSegmentation(String finalCustomerSegmentation) {
		this.finalCustomerSegmentation = finalCustomerSegmentation;
	}

	public String getFinnoneCustId() {
		return finnoneCustId;
	}

	public void setFinnoneCustId(String finnoneCustId) {
		this.finnoneCustId = finnoneCustId;
	}

	public String getDedupeStatus() {
		return dedupeStatus;
	}

	public void setDedupeStatus(String dedupeStatus) {
		this.dedupeStatus = dedupeStatus;
	}

	public String getDedupeMatch() {
		return dedupeMatch;
	}

	public void setDedupeMatch(String dedupeMatch) {
		this.dedupeMatch = dedupeMatch;
	}

	public String getCreditStatusEligibility() {
		return creditStatusEligibility;
	}

	public void setCreditStatusEligibility(String creditStatusEligibility) {
		this.creditStatusEligibility = creditStatusEligibility;
	}

	public String getCreditStatusDisbursement() {
		return creditStatusDisbursement;
	}

	public void setCreditStatusDisbursement(String creditStatusDisbursement) {
		this.creditStatusDisbursement = creditStatusDisbursement;
	}
}
