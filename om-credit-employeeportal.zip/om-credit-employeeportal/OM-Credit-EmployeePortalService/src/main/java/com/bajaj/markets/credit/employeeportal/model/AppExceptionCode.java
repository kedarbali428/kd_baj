package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the disposition_code database table.
 * 
 */
@Entity
@Table(name="app_exception_code",schema = "dmcredit")
public class AppExceptionCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer appexceptionkey;

	private String appexceptioncd;
	
	private Long prodcatkey;
	
	private String appexceptiondscr;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;
	
	private String categorycd;


	public AppExceptionCode() {
	}


	public Integer getAppexceptionkey() {
		return appexceptionkey;
	}


	public void setAppexceptionkey(Integer appexceptionkey) {
		this.appexceptionkey = appexceptionkey;
	}


	public String getAppexceptioncd() {
		return appexceptioncd;
	}


	public void setAppexceptioncd(String appexceptioncd) {
		this.appexceptioncd = appexceptioncd;
	}


	public Long getProdcatkey() {
		return prodcatkey;
	}


	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}


	public String getAppexceptiondscr() {
		return appexceptiondscr;
	}


	public void setAppexceptiondscr(String appexceptiondscr) {
		this.appexceptiondscr = appexceptiondscr;
	}


	public Integer getIsactive() {
		return isactive;
	}


	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}


	public Long getLstupdateby() {
		return lstupdateby;
	}


	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}


	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}


	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}


	public String getCategorycd() {
		return categorycd;
	}


	public void setCategorycd(String categorycd) {
		this.categorycd = categorycd;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	}