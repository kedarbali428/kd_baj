package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class AppPricingAlertDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long mobileNumber;
	private String personalEmailAddress;
	private String officialEmailAddress;
	
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPersonalEmailAddress() {
		return personalEmailAddress;
	}
	public void setPersonalEmailAddress(String personalEmailAddress) {
		this.personalEmailAddress = personalEmailAddress;
	}
	public String getOfficialEmailAddress() {
		return officialEmailAddress;
	}
	public void setOfficialEmailAddress(String officialEmailAddress) {
		this.officialEmailAddress = officialEmailAddress;
	}
	
	@Override
	public String toString() {
		return "AppPricingAlertDetails [mobileNumber=" + mobileNumber + ", personalEmailAddress=" + personalEmailAddress
				+ ", officialEmailAddress=" + officialEmailAddress + "]";
	}
	
}
