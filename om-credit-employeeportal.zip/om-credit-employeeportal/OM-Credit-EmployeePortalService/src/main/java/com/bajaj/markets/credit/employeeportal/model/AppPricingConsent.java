package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_pricing_consent", schema = "dmcredit")
public class AppPricingConsent implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_pricing_consent_appconsentkey_generator", sequenceName = "dmcredit.seq_pk_app_pricing_consent", allocationSize = 1)
	@GeneratedValue(generator = "app_pricing_consent_appconsentkey_generator", strategy = GenerationType.SEQUENCE)
	private Long appconsentkey;

	private Long apploanpricingkey;

	private Timestamp consentaccepteddt;

	private Integer consentcapturedflg;

	private String consentmechanism;

	private String consentpasscode;

	private Timestamp consentsentdt;

	private Integer consentsentflg;

	private String consentsource;

	private String consentstatus;

	private Integer employeecatureflg;

	private Long employeeuserkey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long mobile;

	private String officialemail;

	private String personalemail;

	public Long getAppconsentkey() {
		return appconsentkey;
	}

	public void setAppconsentkey(Long appconsentkey) {
		this.appconsentkey = appconsentkey;
	}

	public Long getApploanpricingkey() {
		return apploanpricingkey;
	}

	public void setApploanpricingkey(Long apploanpricingkey) {
		this.apploanpricingkey = apploanpricingkey;
	}

	public Timestamp getConsentaccepteddt() {
		return consentaccepteddt;
	}

	public void setConsentaccepteddt(Timestamp consentaccepteddt) {
		this.consentaccepteddt = consentaccepteddt;
	}

	public Integer getConsentcapturedflg() {
		return consentcapturedflg;
	}

	public void setConsentcapturedflg(Integer consentcapturedflg) {
		this.consentcapturedflg = consentcapturedflg;
	}

	public String getConsentmechanism() {
		return consentmechanism;
	}

	public void setConsentmechanism(String consentmechanism) {
		this.consentmechanism = consentmechanism;
	}

	public String getConsentpasscode() {
		return consentpasscode;
	}

	public void setConsentpasscode(String consentpasscode) {
		this.consentpasscode = consentpasscode;
	}

	public Timestamp getConsentsentdt() {
		return consentsentdt;
	}

	public void setConsentsentdt(Timestamp consentsentdt) {
		this.consentsentdt = consentsentdt;
	}

	public Integer getConsentsentflg() {
		return consentsentflg;
	}

	public void setConsentsentflg(Integer consentsentflg) {
		this.consentsentflg = consentsentflg;
	}

	public String getConsentsource() {
		return consentsource;
	}

	public void setConsentsource(String consentsource) {
		this.consentsource = consentsource;
	}

	public String getConsentstatus() {
		return consentstatus;
	}

	public void setConsentstatus(String consentstatus) {
		this.consentstatus = consentstatus;
	}

	public Integer getEmployeecatureflg() {
		return employeecatureflg;
	}

	public void setEmployeecatureflg(Integer employeecatureflg) {
		this.employeecatureflg = employeecatureflg;
	}

	public Long getEmployeeuserkey() {
		return employeeuserkey;
	}

	public void setEmployeeuserkey(Long employeeuserkey) {
		this.employeeuserkey = employeeuserkey;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getOfficialemail() {
		return officialemail;
	}

	public void setOfficialemail(String officialemail) {
		this.officialemail = officialemail;
	}

	public String getPersonalemail() {
		return personalemail;
	}

	public void setPersonalemail(String personalemail) {
		this.personalemail = personalemail;
	}

}