package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_exception_detail", schema = "dmcredit")
public class AppExceptionDetail implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_exception_detail_appexceptiondtlkey_generator", sequenceName = "dmcredit.seq_pk_app_exception_detail", allocationSize = 1)
	@GeneratedValue(generator = "app_exception_detail_appexceptiondtlkey_generator", strategy = GenerationType.SEQUENCE)
	private Long appexceptiondtlkey;
	private Long applicationkey;
	@Column(insertable = false, updatable = false)
	private Long substagekey;
	private Float appcompletionper;
	private Long raisedby;
	private Timestamp raiseddt;
	private String status;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;
	@Column(insertable = false, updatable = false)
	private Long exceptionraisedto;

	// bi-directional many-to-one association to SubstageMaster
	@ManyToOne
	@JoinColumn(name = "substagekey")
	private SubstageMaster substageMaster1;

	// bi-directional many-to-one association to SubstageMaster
	@ManyToOne
	@JoinColumn(name = "exceptionraisedto")
	private SubstageMaster substageMaster2;

	public Long getAppexceptiondtlkey() {
		return appexceptiondtlkey;
	}

	public void setAppexceptiondtlkey(Long appexceptiondtlkey) {
		this.appexceptiondtlkey = appexceptiondtlkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getSubstagekey() {
		return substagekey;
	}

	public void setSubstagekey(Long substagekey) {
		this.substagekey = substagekey;
	}

	public Float getAppcompletionper() {
		return appcompletionper;
	}

	public void setAppcompletionper(Float appcompletionper) {
		this.appcompletionper = appcompletionper;
	}

	public Long getRaisedby() {
		return raisedby;
	}

	public void setRaisedby(Long raisedby) {
		this.raisedby = raisedby;
	}

	public Timestamp getRaiseddt() {
		return raiseddt;
	}

	public void setRaiseddt(Timestamp raiseddt) {
		this.raiseddt = raiseddt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getExceptionraisedto() {
		return exceptionraisedto;
	}

	public void setExceptionraisedto(Long exceptionraisedto) {
		this.exceptionraisedto = exceptionraisedto;
	}

	public SubstageMaster getSubstageMaster1() {
		return substageMaster1;
	}

	public void setSubstageMaster1(SubstageMaster substageMaster1) {
		this.substageMaster1 = substageMaster1;
	}

	public SubstageMaster getSubstageMaster2() {
		return substageMaster2;
	}

	public void setSubstageMaster2(SubstageMaster substageMaster2) {
		this.substageMaster2 = substageMaster2;
	}

}
