package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class PrincipleProductDetailsResponse {
private String loanTypeRecommendation;
private String principleProductCode;
private String riskOfferType;
private List<PricingFees> feesList;
public String getLoanTypeRecommendation() {
	return loanTypeRecommendation;
}
public void setLoanTypeRecommendation(String loanTypeRecommendation) {
	this.loanTypeRecommendation = loanTypeRecommendation;
}
public String getPrincipleProductCode() {
	return principleProductCode;
}
public void setPrincipleProductCode(String principleProductCode) {
	this.principleProductCode = principleProductCode;
}
public String getRiskOfferType() {
	return riskOfferType;
}
public void setRiskOfferType(String riskOfferType) {
	this.riskOfferType = riskOfferType;
}
public List<PricingFees> getFeesList() {
	return feesList;
}
public void setFeesList(List<PricingFees> feesList) {
	this.feesList = feesList;
}
}
