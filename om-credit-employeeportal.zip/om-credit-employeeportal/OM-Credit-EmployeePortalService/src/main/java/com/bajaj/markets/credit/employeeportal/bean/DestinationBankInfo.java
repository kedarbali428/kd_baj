package com.bajaj.markets.credit.employeeportal.bean;

public class DestinationBankInfo {
	
	private String accountNumber;
	
	private String ifscCode;
	
	private String accountType;
	
	private String bankName;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Override
	public String toString() {
		return "DestinationBankInfo [accountNumber=" + accountNumber + ", ifscCode=" + ifscCode + ", accountType="
				+ accountType + ", bankName=" + bankName + "]";
	}
	
	
	
	

}
