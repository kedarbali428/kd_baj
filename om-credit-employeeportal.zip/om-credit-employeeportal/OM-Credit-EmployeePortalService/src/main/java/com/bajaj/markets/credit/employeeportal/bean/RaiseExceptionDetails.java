package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class RaiseExceptionDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long exceptionRaisedApplication;
	private String subStage;
	private Float percentageCompletion;
	private String excpRaisedTo;
	private String excpStatus;
	private String excpRaisedBy;
	private Timestamp excpRaisedDateTime;

	public Long getExceptionRaisedApplication() {
		return exceptionRaisedApplication;
	}

	public void setExceptionRaisedApplication(Long exceptionRaisedApplication) {
		this.exceptionRaisedApplication = exceptionRaisedApplication;
	}

	public String getSubStage() {
		return subStage;
	}

	public void setSubStage(String subStage) {
		this.subStage = subStage;
	}

	public Float getPercentageCompletion() {
		return percentageCompletion;
	}

	public void setPercentageCompletion(Float percentageCompletion) {
		this.percentageCompletion = percentageCompletion;
	}

	public String getExcpRaisedTo() {
		return excpRaisedTo;
	}

	public void setExcpRaisedTo(String excpRaisedTo) {
		this.excpRaisedTo = excpRaisedTo;
	}

	public String getExcpStatus() {
		return excpStatus;
	}

	public void setExcpStatus(String excpStatus) {
		this.excpStatus = excpStatus;
	}

	public String getExcpRaisedBy() {
		return excpRaisedBy;
	}

	public void setExcpRaisedBy(String excpRaisedBy) {
		this.excpRaisedBy = excpRaisedBy;
	}

	public Timestamp getExcpRaisedDateTime() {
		return excpRaisedDateTime;
	}

	public void setExcpRaisedDateTime(Timestamp excpRaisedDateTime) {
		this.excpRaisedDateTime = excpRaisedDateTime;
	}

}
