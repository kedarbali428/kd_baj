package com.bajaj.markets.credit.employeeportal.bean;

public class LoanEligibilityDetails {
	private String eligibleProductVarient;
	private String eligibilityType;
	private String riskOfferType;
	// private String loanType;
	private String fppApplicable;
	private Long bscore;
	private String features;
	private String monthOffer;
	private String rewardPoints;
	private String preApprovedFlag;
	private String recommendedProduct;
	private Long childAppID;
	private String childAppStatus;
	private String childRecordStage;
	private String childRecSubstage;
	private String childRecPercentage;
	private String productType;
	private String perfiosRequired;
	private String emailVerificationReq;
	private String approvalChance;
	private String doeFlag;
	private Integer imputedSalary;
	private Integer finalUnsecuredFoir;
	private Integer applicableMultiplier;
	private Integer multiplierEligibility;
	private Integer finalFoir;
	private String producVarient;
	private Integer finalMultiplier;
	private Integer eligibilityAmount;
	private Integer eligibleTenor;
	private Integer priorityOrder;
	private Integer maxEmiAsPerFoir;
	private Integer foirEligibility;

	public String getEligibleProductVarient() {
		return eligibleProductVarient;
	}

	public void setEligibleProductVarient(String eligibleProductVarient) {
		this.eligibleProductVarient = eligibleProductVarient;
	}

	public String getEligibilityType() {
		return eligibilityType;
	}

	public void setEligibilityType(String eligibilityType) {
		this.eligibilityType = eligibilityType;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public String getFppApplicable() {
		return fppApplicable;
	}

	public void setFppApplicable(String fppApplicable) {
		this.fppApplicable = fppApplicable;
	}

	public Long getBscore() {
		return bscore;
	}

	public void setBscore(Long bscore) {
		this.bscore = bscore;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	public String getMonthOffer() {
		return monthOffer;
	}

	public void setMonthOffer(String monthOffer) {
		this.monthOffer = monthOffer;
	}

	public String getRewardPoints() {
		return rewardPoints;
	}

	public void setRewardPoints(String rewardPoints) {
		this.rewardPoints = rewardPoints;
	}

	public String getPreApprovedFlag() {
		return preApprovedFlag;
	}

	public void setPreApprovedFlag(String preApprovedFlag) {
		this.preApprovedFlag = preApprovedFlag;
	}

	public String getRecommendedProduct() {
		return recommendedProduct;
	}

	public void setRecommendedProduct(String recommendedProduct) {
		this.recommendedProduct = recommendedProduct;
	}

	public Long getChildAppID() {
		return childAppID;
	}

	public void setChildAppID(Long childAppID) {
		this.childAppID = childAppID;
	}

	public String getChildAppStatus() {
		return childAppStatus;
	}

	public void setChildAppStatus(String childAppStatus) {
		this.childAppStatus = childAppStatus;
	}

	public String getChildRecordStage() {
		return childRecordStage;
	}

	public void setChildRecordStage(String childRecordStage) {
		this.childRecordStage = childRecordStage;
	}

	public String getChildRecSubstage() {
		return childRecSubstage;
	}

	public void setChildRecSubstage(String childRecSubstage) {
		this.childRecSubstage = childRecSubstage;
	}

	public String getChildRecPercentage() {
		return childRecPercentage;
	}

	public void setChildRecPercentage(String childRecPercentage) {
		this.childRecPercentage = childRecPercentage;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getPerfiosRequired() {
		return perfiosRequired;
	}

	public void setPerfiosRequired(String perfiosRequired) {
		this.perfiosRequired = perfiosRequired;
	}

	public String getEmailVerificationReq() {
		return emailVerificationReq;
	}

	public void setEmailVerificationReq(String emailVerificationReq) {
		this.emailVerificationReq = emailVerificationReq;
	}

	public String getApprovalChance() {
		return approvalChance;
	}

	public void setApprovalChance(String approvalChance) {
		this.approvalChance = approvalChance;
	}

	public String getDoeFlag() {
		return doeFlag;
	}

	public void setDoeFlag(String doeFlag) {
		this.doeFlag = doeFlag;
	}

	public Integer getImputedSalary() {
		return imputedSalary;
	}

	public void setImputedSalary(Integer imputedSalary) {
		this.imputedSalary = imputedSalary;
	}

	public Integer getFinalUnsecuredFoir() {
		return finalUnsecuredFoir;
	}

	public void setFinalUnsecuredFoir(Integer finalUnsecuredFoir) {
		this.finalUnsecuredFoir = finalUnsecuredFoir;
	}

	public Integer getApplicableMultiplier() {
		return applicableMultiplier;
	}

	public void setApplicableMultiplier(Integer applicableMultiplier) {
		this.applicableMultiplier = applicableMultiplier;
	}

	public Integer getMultiplierEligibility() {
		return multiplierEligibility;
	}

	public void setMultiplierEligibility(Integer multiplierEligibility) {
		this.multiplierEligibility = multiplierEligibility;
	}

	public Integer getFinalFoir() {
		return finalFoir;
	}

	public void setFinalFoir(Integer finalFoir) {
		this.finalFoir = finalFoir;
	}

	public String getProducVarient() {
		return producVarient;
	}

	public void setProducVarient(String producVarient) {
		this.producVarient = producVarient;
	}

	public Integer getFinalMultiplier() {
		return finalMultiplier;
	}

	public void setFinalMultiplier(Integer finalMultiplier) {
		this.finalMultiplier = finalMultiplier;
	}

	public Integer getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(Integer eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	public Integer getEligibleTenor() {
		return eligibleTenor;
	}

	public void setEligibleTenor(Integer eligibleTenor) {
		this.eligibleTenor = eligibleTenor;
	}

	public Integer getPriorityOrder() {
		return priorityOrder;
	}

	public void setPriorityOrder(Integer priorityOrder) {
		this.priorityOrder = priorityOrder;
	}

	public Integer getMaxEmiAsPerFoir() {
		return maxEmiAsPerFoir;
	}

	public void setMaxEmiAsPerFoir(Integer maxEmiAsPerFoir) {
		this.maxEmiAsPerFoir = maxEmiAsPerFoir;
	}

	public Integer getFoirEligibility() {
		return foirEligibility;
	}

	public void setFoirEligibility(Integer foirEligibility) {
		this.foirEligibility = foirEligibility;
	}

}
