package com.bajaj.markets.credit.employeeportal.bean;

public class FinanceDetail {

	private Long applicationNo;
	private String cif;
	private String finType;
	private String finCcy;
	private String finBranch;
	private String profitDaysBasis;
	private String finAmount;
	private String finAssetValue;
	private String downPayBank;
	private String downPaySupl;
	private String finRepayMethod;
	private String finStartDate;
	private String allowGrcPeriod;
	private String tdsApplicable;
	private String manualSchedule;
	private String planDeferCount;
	private String stepFinance;
	private String repayRateBasis;
	private String repaySpecialRate;
	private String repayMargin;
	private String scheduleMethod;
	private String repayBaseRate;
	private String numberOfTerms;
	private String finRepayPftOnFrq;
	private String alwManualSteps;
	private String stepPolicy;
	private String stepType;
	private String reqRepayAmount;
	private String repayPftRate;
	private String repayFrq;
	private String nextRepayDate;
	private String repayPftFrq;
	private String nextRepayPftDate;
	private String repayRvwFrq;
	private String nextRepayRvwDate;
	private String repayCpzFrq;
	private String nextRepayCpzDate;
	private String maturityDate;
	private String repayMinRate;
	private String repayMaxRate;
	private String planEMIHAlw;
	private String planEMIHMethod;
	private String planEMIHMaxPerYear;
	private String planEMIHMax;
	private String planEMIHLockPeriod;
	private String planEMICpz;
	private String alwBpiTreatment;
	private String grcTerms;
	private String grcBaseRate;
	private String grcPftRate;
	private String grcSpecialRate;
	private String grcMargin;
	private String grcPftFrq;
	private String nextGrcPftDate;
	private String grcCpzFrq;
	private String nextGrcCpzDate;
	private String allowGrcRepay;
	private String grcSchdMthd;
	private String alwFlexi;
	private String flexiType;
	
	
	
	public String getAlwFlexi() {
		return alwFlexi;
	}
	public void setAlwFlexi(String alwFlexi) {
		this.alwFlexi = alwFlexi;
	}
	public String getFlexiType() {
		return flexiType;
	}
	public void setFlexiType(String flexiType) {
		this.flexiType = flexiType;
	}
	
	public Long getApplicationNo() {
		return applicationNo;
	}
	public void setApplicationNo(Long applicationNo) {
		this.applicationNo = applicationNo;
	}
	public String getFinType() {
		return finType;
	}
	public void setFinType(String finType) {
		this.finType = finType;
	}
	public String getFinCcy() {
		return finCcy;
	}
	public void setFinCcy(String finCcy) {
		this.finCcy = finCcy;
	}
	public String getProfitDaysBasis() {
		return profitDaysBasis;
	}
	public void setProfitDaysBasis(String profitDaysBasis) {
		this.profitDaysBasis = profitDaysBasis;
	}
	public String getFinAmount() {
		return finAmount;
	}
	public void setFinAmount(String finAmount) {
		this.finAmount = finAmount;
	}
	public String getFinStartDate() {
		return finStartDate;
	}
	public void setFinStartDate(String finStartDate) {
		this.finStartDate = finStartDate;
	}
	public String getAllowGrcPeriod() {
		return allowGrcPeriod;
	}
	public void setAllowGrcPeriod(String allowGrcPeriod) {
		this.allowGrcPeriod = allowGrcPeriod;
	}
	public String getTdsApplicable() {
		return tdsApplicable;
	}
	public void setTdsApplicable(String tdsApplicable) {
		this.tdsApplicable = tdsApplicable;
	}
	public String getManualSchedule() {
		return manualSchedule;
	}
	public void setManualSchedule(String manualSchedule) {
		this.manualSchedule = manualSchedule;
	}
	public String getPlanDeferCount() {
		return planDeferCount;
	}
	public void setPlanDeferCount(String planDeferCount) {
		this.planDeferCount = planDeferCount;
	}
	public String getStepFinance() {
		return stepFinance;
	}
	public void setStepFinance(String stepFinance) {
		this.stepFinance = stepFinance;
	}
	public String getRepayRateBasis() {
		return repayRateBasis;
	}
	public void setRepayRateBasis(String repayRateBasis) {
		this.repayRateBasis = repayRateBasis;
	}
	public String getRepaySpecialRate() {
		return repaySpecialRate;
	}
	public void setRepaySpecialRate(String repaySpecialRate) {
		this.repaySpecialRate = repaySpecialRate;
	}
	public String getRepayMargin() {
		return repayMargin;
	}
	public void setRepayMargin(String repayMargin) {
		this.repayMargin = repayMargin;
	}
	public String getScheduleMethod() {
		return scheduleMethod;
	}
	public void setScheduleMethod(String scheduleMethod) {
		this.scheduleMethod = scheduleMethod;
	}
	public String getRepayBaseRate() {
		return repayBaseRate;
	}
	public void setRepayBaseRate(String repayBaseRate) {
		this.repayBaseRate = repayBaseRate;
	}
	public String getNumberOfTerms() {
		return numberOfTerms;
	}
	public void setNumberOfTerms(String numberOfTerms) {
		this.numberOfTerms = numberOfTerms;
	}
	public String getFinRepayPftOnFrq() {
		return finRepayPftOnFrq;
	}
	public void setFinRepayPftOnFrq(String finRepayPftOnFrq) {
		this.finRepayPftOnFrq = finRepayPftOnFrq;
	}
	public String getAlwManualSteps() {
		return alwManualSteps;
	}
	public void setAlwManualSteps(String alwManualSteps) {
		this.alwManualSteps = alwManualSteps;
	}
	public String getStepPolicy() {
		return stepPolicy;
	}
	public void setStepPolicy(String stepPolicy) {
		this.stepPolicy = stepPolicy;
	}
	public String getStepType() {
		return stepType;
	}
	public void setStepType(String stepType) {
		this.stepType = stepType;
	}
	public String getCif() {
		return cif;
	}
	public void setCif(String cif) {
		this.cif = cif;
	}
	public String getFinBranch() {
		return finBranch;
	}
	public void setFinBranch(String finBranch) {
		this.finBranch = finBranch;
	}
	public String getDownPayBank() {
		return downPayBank;
	}
	public void setDownPayBank(String downPayBank) {
		this.downPayBank = downPayBank;
	}
	public String getDownPaySupl() {
		return downPaySupl;
	}
	public void setDownPaySupl(String downPaySupl) {
		this.downPaySupl = downPaySupl;
	}
	public String getFinRepayMethod() {
		return finRepayMethod;
	}
	public void setFinRepayMethod(String finRepayMethod) {
		this.finRepayMethod = finRepayMethod;
	}
	public String getReqRepayAmount() {
		return reqRepayAmount;
	}
	public void setReqRepayAmount(String reqRepayAmount) {
		this.reqRepayAmount = reqRepayAmount;
	}
	public String getRepayPftRate() {
		return repayPftRate;
	}
	public void setRepayPftRate(String repayPftRate) {
		this.repayPftRate = repayPftRate;
	}
	public String getRepayFrq() {
		return repayFrq;
	}
	public void setRepayFrq(String repayFrq) {
		this.repayFrq = repayFrq;
	}
	public String getNextRepayDate() {
		return nextRepayDate;
	}
	public void setNextRepayDate(String nextRepayDate) {
		this.nextRepayDate = nextRepayDate;
	}
	public String getRepayPftFrq() {
		return repayPftFrq;
	}
	public void setRepayPftFrq(String repayPftFrq) {
		this.repayPftFrq = repayPftFrq;
	}
	public String getNextRepayPftDate() {
		return nextRepayPftDate;
	}
	public void setNextRepayPftDate(String nextRepayPftDate) {
		this.nextRepayPftDate = nextRepayPftDate;
	}
	public String getRepayRvwFrq() {
		return repayRvwFrq;
	}
	public void setRepayRvwFrq(String repayRvwFrq) {
		this.repayRvwFrq = repayRvwFrq;
	}
	public String getNextRepayRvwDate() {
		return nextRepayRvwDate;
	}
	public void setNextRepayRvwDate(String nextRepayRvwDate) {
		this.nextRepayRvwDate = nextRepayRvwDate;
	}
	public String getRepayCpzFrq() {
		return repayCpzFrq;
	}
	public void setRepayCpzFrq(String repayCpzFrq) {
		this.repayCpzFrq = repayCpzFrq;
	}
	public String getNextRepayCpzDate() {
		return nextRepayCpzDate;
	}
	public void setNextRepayCpzDate(String nextRepayCpzDate) {
		this.nextRepayCpzDate = nextRepayCpzDate;
	}
	public String getMaturityDate() {
		return maturityDate;
	}
	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}
	public String getRepayMinRate() {
		return repayMinRate;
	}
	public void setRepayMinRate(String repayMinRate) {
		this.repayMinRate = repayMinRate;
	}
	public String getRepayMaxRate() {
		return repayMaxRate;
	}
	public void setRepayMaxRate(String repayMaxRate) {
		this.repayMaxRate = repayMaxRate;
	}
	public String getPlanEMIHAlw() {
		return planEMIHAlw;
	}
	public void setPlanEMIHAlw(String planEMIHAlw) {
		this.planEMIHAlw = planEMIHAlw;
	}
	public String getPlanEMIHMethod() {
		return planEMIHMethod;
	}
	public void setPlanEMIHMethod(String planEMIHMethod) {
		this.planEMIHMethod = planEMIHMethod;
	}
	public String getPlanEMIHMaxPerYear() {
		return planEMIHMaxPerYear;
	}
	public void setPlanEMIHMaxPerYear(String planEMIHMaxPerYear) {
		this.planEMIHMaxPerYear = planEMIHMaxPerYear;
	}
	public String getPlanEMIHMax() {
		return planEMIHMax;
	}
	public void setPlanEMIHMax(String planEMIHMax) {
		this.planEMIHMax = planEMIHMax;
	}
	public String getPlanEMIHLockPeriod() {
		return planEMIHLockPeriod;
	}
	public void setPlanEMIHLockPeriod(String planEMIHLockPeriod) {
		this.planEMIHLockPeriod = planEMIHLockPeriod;
	}
	public String getPlanEMICpz() {
		return planEMICpz;
	}
	public void setPlanEMICpz(String planEMICpz) {
		this.planEMICpz = planEMICpz;		
	}
	public String getAlwBpiTreatment() {
		return alwBpiTreatment;
	}
	public void setAlwBpiTreatment(String alwBpiTreatment) {
		this.alwBpiTreatment = alwBpiTreatment;
	}
	public String getFinAssetValue() {
		return finAssetValue;
	}
	public void setFinAssetValue(String finAssetValue) {
		this.finAssetValue = finAssetValue;
	}
	public String getGrcTerms() {
		return grcTerms;
	}
	public void setGrcTerms(String grcTerms) {
		this.grcTerms = grcTerms;
	}
	public String getGrcBaseRate() {
		return grcBaseRate;
	}
	public void setGrcBaseRate(String grcBaseRate) {
		this.grcBaseRate = grcBaseRate;
	}
	public String getGrcSpecialRate() {
		return grcSpecialRate;
	}
	public void setGrcSpecialRate(String grcSpecialRate) {
		this.grcSpecialRate = grcSpecialRate;
	}
	public String getGrcMargin() {
		return grcMargin;
	}
	public void setGrcMargin(String grcMargin) {
		this.grcMargin = grcMargin;
	}
	public String getGrcPftFrq() {
		return grcPftFrq;
	}
	public void setGrcPftFrq(String grcPftFrq) {
		this.grcPftFrq = grcPftFrq;
	}
	public String getNextGrcPftDate() {
		return nextGrcPftDate;
	}
	public void setNextGrcPftDate(String nextGrcPftDate) {
		this.nextGrcPftDate = nextGrcPftDate;
	}
	public String getGrcCpzFrq() {
		return grcCpzFrq;
	}
	public void setGrcCpzFrq(String grcCpzFrq) {
		this.grcCpzFrq = grcCpzFrq;
	}
	public String getNextGrcCpzDate() {
		return nextGrcCpzDate;
	}
	public void setNextGrcCpzDate(String nextGrcCpzDate) {
		this.nextGrcCpzDate = nextGrcCpzDate;
	}
	public String getGrcPftRate() {
		return grcPftRate;
	}
	public void setGrcPftRate(String grcPftRate) {
		this.grcPftRate = grcPftRate;
	}
	public String getAllowGrcRepay() {
		return allowGrcRepay;
	}
	public void setAllowGrcRepay(String allowGrcRepay) {
		this.allowGrcRepay = allowGrcRepay;
	}
	public String getGrcSchdMthd() {
		return grcSchdMthd;
	}
	public void setGrcSchdMthd(String grcSchdMthd) {
		this.grcSchdMthd = grcSchdMthd;
	}
	


}
