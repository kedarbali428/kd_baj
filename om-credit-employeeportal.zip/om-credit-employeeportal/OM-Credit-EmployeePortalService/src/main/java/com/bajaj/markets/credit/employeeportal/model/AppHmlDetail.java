package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_hml_detail", schema = "dmcredit")
public class AppHmlDetail implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@SequenceGenerator(name = "app_hml_detail_apphmldetkey_generator", sequenceName = "dmcredit.seq_pk_app_hml_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_hml_detail_apphmldetkey_generator")
	private Long apphmldetkey;
	private Long applicationkey;
	private Long hmlscore;
	private String hmlsegment;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;

	public Long getApphmldetkey() {
		return apphmldetkey;
	}

	public void setApphmldetkey(Long apphmldetkey) {
		this.apphmldetkey = apphmldetkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getHmlscore() {
		return hmlscore;
	}

	public void setHmlscore(Long hmlscore) {
		this.hmlscore = hmlscore;
	}

	public String getHmlsegment() {
		return hmlsegment;
	}

	public void setHmlsegment(String hmlsegment) {
		this.hmlsegment = hmlsegment;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
}
