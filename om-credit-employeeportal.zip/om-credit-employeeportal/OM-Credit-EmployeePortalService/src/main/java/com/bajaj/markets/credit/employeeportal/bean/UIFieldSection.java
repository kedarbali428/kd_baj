package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class UIFieldSection {

	private Long tabKey;
	private String sectionName;
	private List<List<UIFieldBean>> uiFieldSectionList;

	public Long getTabKey() {
		return tabKey;
	}

	public void setTabKey(Long tabKey) {
		this.tabKey = tabKey;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public List<List<UIFieldBean>> getUiFieldSectionList() {
		return uiFieldSectionList;
	}

	public void setUiFieldSectionList(List<List<UIFieldBean>> uiFieldSectionList) {
		this.uiFieldSectionList = uiFieldSectionList;
	}

}
