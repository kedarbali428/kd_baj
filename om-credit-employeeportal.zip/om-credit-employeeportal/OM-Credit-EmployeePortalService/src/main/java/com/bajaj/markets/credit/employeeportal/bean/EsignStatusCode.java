package com.bajaj.markets.credit.employeeportal.bean;

public enum EsignStatusCode {
	CREATED,INITIAITED,COMPLETED,FAILED,EXPIRED
}
