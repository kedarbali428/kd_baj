package com.bajaj.markets.credit.employeeportal.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class UserProfile {

	private String applicationKey;

	private String applicationUserAttributeKey;

	private String applicationUserAttributeType;

	private String mobile;

	private String dateOfBirth;

	private String firstName;

	private String middleName;

	private String lastName;

	private String motherName;

	private String fatherName;

	private Long bfsdApplicantId;

	private String emailAddress;

	private String officialEmailAddress;

	private String nameAsPerNsdl;

	private String bureauName;

	private String currentAddress;

	private String currentAddressPin;

	private String permanentAddressPin;

	private String score;

	private String occupationType;

	private String nullValue;

	private String cibilScoreV1;

	private String cibilScoreV3;
	private String nsdlPanStatus;
	private String nameMatchStatus;

	@Digits(fraction = 0, integer = 5, message = "maritalStatusKey cannot be in fraction & should not exceed size")
	@NotNull(message = "maritalStatusKey cannot be null or empty")
	private String maritalStatusKey;

	@Digits(fraction = 0, integer = 5, message = "gender cannot be in fraction & should not exceed size")
	@NotNull(message = "gender cannot be null or empty")
	private String gender;

	@NotNull(message = "residenceTypeKey can not be null")
	private String residenceTypeKey;

	@NotBlank(message = "qualification cannot be null or empty")
	@NotBlank(message = "qualification cannot be null or empty")
	private String qualification;

	// Adding Additional parameter as part of JIRAID Len-535
	private String panNumber;
	private String finalCustomerSegmentation;
	private String finnoneCustId;
	private String hlProductIntent;
	private String pennantId;
    private String individualCoapplicantRequired;
	private String entityCoapplicantRequired;
	
	private String otherEmailAddress;
	
	private Boolean reKYCFlag;
	
	private String profileEmployerType;
	
	private String profileIncomeSegment;
	
	private String profileSegment;
	
	private String profileMicroSegment;
	
	private String profileIncomeAmount;

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getApplicationUserAttributeKey() {
		return applicationUserAttributeKey;
	}

	public void setApplicationUserAttributeKey(String applicationUserAttributeKey) {
		this.applicationUserAttributeKey = applicationUserAttributeKey;
	}

	public String getApplicationUserAttributeType() {
		return applicationUserAttributeType;
	}

	public void setApplicationUserAttributeType(String applicationUserAttributeType) {
		this.applicationUserAttributeType = applicationUserAttributeType;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMaritalStatusKey() {
		return maritalStatusKey;
	}

	public void setMaritalStatusKey(String maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}



	public String getResidenceTypeKey() {
		return residenceTypeKey;
	}

	public void setResidenceTypeKey(String residenceTypeKey) {
		this.residenceTypeKey = residenceTypeKey;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	@Override
	public String toString() {
		return "UserProfile [applicationKey=" + applicationKey + ", applicationUserAttributeKey="
				+ applicationUserAttributeKey + ", applicationUserAttributeType=" + applicationUserAttributeType
				+ ", mobile=" + mobile + ", dateOfBirth=" + dateOfBirth + ", maritalStatusKey=" + maritalStatusKey
				+ ", genderKey=" + gender + ", residenceTypeKey=" + residenceTypeKey + ", qualification="
				+ qualification + ",panNumber= " + panNumber + "]";
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * @return the motherName
	 */
	public String getMotherName() {
		return motherName;
	}

	/**
	 * @param motherName the motherName to set
	 */
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public Long getBfsdApplicantId() {
		return bfsdApplicantId;
	}

	public void setBfsdApplicantId(Long bfsdApplicantId) {
		this.bfsdApplicantId = bfsdApplicantId;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getOfficialEmailAddress() {
		return officialEmailAddress;
	}

	public void setOfficialEmailAddress(String officialEmailAddress) {
		this.officialEmailAddress = officialEmailAddress;
	}

	/**
	 * @return the nameAsPerNsdl
	 */
	public String getNameAsPerNsdl() {
		return nameAsPerNsdl;
	}

	/**
	 * @param nameAsPerNsdl the nameAsPerNsdl to set
	 */
	public void setNameAsPerNsdl(String nameAsPerNsdl) {
		this.nameAsPerNsdl = nameAsPerNsdl;
	}

	/**
	 * @return the bureauName
	 */
	public String getBureauName() {
		return bureauName;
	}

	/**
	 * @param bureauName the bureauName to set
	 */
	public void setBureauName(String bureauName) {
		this.bureauName = bureauName;
	}

	/**
	 * @return the currentAddress
	 */
	public String getCurrentAddress() {
		return currentAddress;
	}

	/**
	 * @param currentAddress the currentAddress to set
	 */
	public void setCurrentAddress(String currentAddress) {
		this.currentAddress = currentAddress;
	}

	/**
	 * @return the score
	 */
	public String getScore() {
		return score;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(String score) {
		this.score = score;
	}

	/**
	 * @return the nullValue
	 */
	public String getNullValue() {
		return nullValue;
	}

	/**
	 * @param nullValue the nullValue to set
	 */
	public void setNullValue(String nullValue) {
		this.nullValue = nullValue;
	}

	/**
	 * @return the occupationType
	 */
	public String getOccupationType() {
		return occupationType;
	}

	/**
	 * @param occupationType the occupationType to set
	 */
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}

	/**
	 * @return the currentAddressPin
	 */
	public String getCurrentAddressPin() {
		return currentAddressPin;
	}

	/**
	 * @param currentAddressPin the currentAddressPin to set
	 */
	public void setCurrentAddressPin(String currentAddressPin) {
		this.currentAddressPin = currentAddressPin;
	}

	/**
	 * @return the permanentAddressPin
	 */
	public String getPermanentAddressPin() {
		return permanentAddressPin;
	}

	/**
	 * @param permanentAddressPin the permanentAddressPin to set
	 */
	public void setPermanentAddressPin(String permanentAddressPin) {
		this.permanentAddressPin = permanentAddressPin;
	}

	public String getCibilScoreV1() {
		return cibilScoreV1;
	}

	public void setCibilScoreV1(String cibilScoreV1) {
		this.cibilScoreV1 = cibilScoreV1;
	}

	public String getCibilScoreV3() {
		return cibilScoreV3;
	}

	public void setCibilScoreV3(String cibilScoreV3) {
		this.cibilScoreV3 = cibilScoreV3;
	}

	public String getNsdlPanStatus() {
		return nsdlPanStatus;
	}

	public void setNsdlPanStatus(String nsdlPanStatus) {
		this.nsdlPanStatus = nsdlPanStatus;
	}

	public String getNameMatchStatus() {
		return nameMatchStatus;
	}

	public void setNameMatchStatus(String nameMatchStatus) {
		this.nameMatchStatus = nameMatchStatus;
	}

	public String getFinalCustomerSegmentation() {
		return finalCustomerSegmentation;
	}

	public void setFinalCustomerSegmentation(String finalCustomerSegmentation) {
		this.finalCustomerSegmentation = finalCustomerSegmentation;
	}

	public String getFinnoneCustId() {
		return finnoneCustId;
	}

	public void setFinnoneCustId(String finnoneCustId) {
		this.finnoneCustId = finnoneCustId;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getHlProductIntent() {
		return hlProductIntent;
	}

	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public String getPennantId() {
		return pennantId;
	}

	public void setPennantId(String pennantId) {
		this.pennantId = pennantId;
	}

	public String getIndividualCoapplicantRequired() {
		return individualCoapplicantRequired;
	}

	public void setIndividualCoapplicantRequired(String individualCoapplicantRequired) {
		this.individualCoapplicantRequired = individualCoapplicantRequired;
	}

	public String getEntityCoapplicantRequired() {
		return entityCoapplicantRequired;
	}

	public void setEntityCoapplicantRequired(String entityCoapplicantRequired) {
		this.entityCoapplicantRequired = entityCoapplicantRequired;
	}

	public String getOtherEmailAddress() {
		return otherEmailAddress;
	}

	public void setOtherEmailAddress(String otherEmailAddress) {
		this.otherEmailAddress = otherEmailAddress;
	}

	public Boolean getReKYCFlag() {
		return reKYCFlag;
	}

	public void setReKYCFlag(Boolean reKYCFlag) {
		this.reKYCFlag = reKYCFlag;
	}

	public String getProfileEmployerType() {
		return profileEmployerType;
	}

	public void setProfileEmployerType(String profileEmployerType) {
		this.profileEmployerType = profileEmployerType;
	}

	public String getProfileIncomeSegment() {
		return profileIncomeSegment;
	}

	public void setProfileIncomeSegment(String profileIncomeSegment) {
		this.profileIncomeSegment = profileIncomeSegment;
	}

	public String getProfileSegment() {
		return profileSegment;
	}

	public void setProfileSegment(String profileSegment) {
		this.profileSegment = profileSegment;
	}

	public String getProfileMicroSegment() {
		return profileMicroSegment;
	}

	public void setProfileMicroSegment(String profileMicroSegment) {
		this.profileMicroSegment = profileMicroSegment;
	}

	public String getProfileIncomeAmount() {
		return profileIncomeAmount;
	}

	public void setProfileIncomeAmount(String profileIncomeAmount) {
		this.profileIncomeAmount = profileIncomeAmount;
	}
}
