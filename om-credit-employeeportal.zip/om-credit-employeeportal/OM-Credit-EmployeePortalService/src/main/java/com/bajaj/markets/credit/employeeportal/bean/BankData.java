package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Document
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankData {
	private AccountSummary accountSummary;
	private List<BankStmntDetails> bankStmntDetails;

	public AccountSummary getAccountSummary() {
		return accountSummary;
	}

	public void setAccountSummary(AccountSummary accountSummary) {
		this.accountSummary = accountSummary;
	}

	public List<BankStmntDetails> getBankStmntDetails() {
		return bankStmntDetails;
	}

	public void setBankStmntDetails(List<BankStmntDetails> bankStmntDetails) {
		this.bankStmntDetails = bankStmntDetails;
	}
}
