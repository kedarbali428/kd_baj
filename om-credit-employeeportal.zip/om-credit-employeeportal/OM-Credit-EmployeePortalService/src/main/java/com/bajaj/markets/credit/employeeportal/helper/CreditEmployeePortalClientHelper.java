package com.bajaj.markets.credit.employeeportal.helper;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.google.gson.Gson;

@Component
public class CreditEmployeePortalClientHelper {
	@Value("${creditemployeeportal.connectiontimeout.milli}")
	private int connectionTimeOut;
	@Value("${creditemployeeportal.readtimeout.milli}")
	private int readTimeOut;
	@Value("${openmarket.proxy.host}")
	private String proxyAddress;
	@Value("${openmarket.proxy.port}")
	private String proxyPort;
	@Value("${openmarket.isproxyrequired}")
	private boolean isProxyRequired;
	@Value("${bre-auth-type}")
	private String authtype;

	@Value("${bre-auth-userName}")
	private String authuserName;

	@Value("${bre-auth-password}")
	private String authpassword;


	private RestTemplate restTemplate;
	@Autowired
	private BFLLoggerUtilExt logger;

	@PostConstruct
	public void init() {
		restTemplate = RestTemplateInstance.getRestTemplateInstance();
	}

	private static final String CLASS_NAME = CreditEmployeePortalClientHelper.class.getName();
	
	public RestTemplate getRestTemplate() {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start getRestTemplate");
		SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
		clientHttpRequestFactory.setReadTimeout(readTimeOut);
		clientHttpRequestFactory.setConnectTimeout(connectionTimeOut);
		if (isProxyRequired && !StringUtils.isEmpty(proxyAddress) && !StringUtils.isEmpty(proxyPort)) {
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyAddress, Integer.parseInt(proxyPort)));
			clientHttpRequestFactory.setProxy(proxy);
			restTemplate.setRequestFactory(clientHttpRequestFactory);
		} else {
			restTemplate.setRequestFactory(clientHttpRequestFactory);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "End getRestTemplate");
		return restTemplate;
	}

	public ResponseEntity<?> excuteRestCall(String url, HttpMethod httpMethod, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start excuteRestCall");
		headers.add("Content-Type", "application/json");
		HttpEntity<Object> entity = null;
		String jsonRes = null;
		ResponseEntity<?> responseEntity = null;
		RestTemplate restTemplateInstance = null;
		try {
			restTemplateInstance = getRestTemplate();
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,"Method: "+ httpMethod.name()+" URL  : "  + url);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request  : " + requestJson);
			entity = new HttpEntity<>(requestJson, headers);
			if (params != null) {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType);
			}
			if(responseEntity.getBody()!=null) 
				jsonRes = responseEntity.getBody().toString();
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
						"Response  : " +"URL :"+ url+ "Response entity"+responseEntity.toString());
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "End excuteRestCall");
			return new ResponseEntity<>(jsonRes, responseEntity.getHeaders(), responseEntity.getStatusCode());
		} catch (HttpClientErrorException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					" HttpClientErrorException during " + "URL "+url +"HTTP method " + httpMethod.name() + " call. " + e);
			throw new CreditEmployeePortalServiceException(
					HttpStatus.NO_CONTENT,
					"HttpClientErrorException while calling  api."+url);
		} catch (HttpStatusCodeException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"HttpStatusCodeException during " +"URL "+url +"HTTP method " + httpMethod.name() + " call", e);
			throw new CreditEmployeePortalServiceException(
					HttpStatus.INTERNAL_SERVER_ERROR,
					"HttpStatusCodeException while calling api "+url);
		} catch (RestClientException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					" RestClientException during " + "URL "+url +"HTTP method " +httpMethod.name() + " call ", e);
			throw new CreditEmployeePortalServiceException(
					HttpStatus.INTERNAL_SERVER_ERROR, "RestClientException while calling api "+url);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, " Exception during " + "URL "+url +"HTTP method " + httpMethod.name() + " call ",
					e);
			throw new CreditEmployeePortalServiceException(
					HttpStatus.INTERNAL_SERVER_ERROR, "Exception while calling api "+url);
		}
	}
	
	
    public ResponseEntity<?> invokeRestCall(String url, HttpMethod httpMethod, Class<?> responseType,
            Map<String, String> params, String requestJson, HttpHeaders headers) {
        logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start excuteRestCall");
        headers.add("Content-Type", "application/json");
        HttpEntity<Object> entity = null;
        ResponseEntity<?> responseEntity = null;
        RestTemplate restTemplateInstance = null;
        try {
            restTemplateInstance = getRestTemplate();
            logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Method: " + httpMethod.name() + " URL  : " + url);
            logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request  : " + requestJson);
            entity = new HttpEntity<>(requestJson, headers);
            if (params != null) {
                responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType, params);
            } else {
                responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType);
            }
            if (responseEntity.getBody() != null)

                logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
                        "Response  : " + "URL :" + url + "Response entity" + responseEntity.toString());
            logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "End excuteRestCall");
            return new ResponseEntity<>(responseEntity.getBody(), responseEntity.getHeaders(),
                    responseEntity.getStatusCode());
        } catch (HttpClientErrorException e) {
            logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, " HttpClientErrorException during " + "URL " + url
                    + "HTTP method " + httpMethod.name() + " call. " + e);
            throw new CreditEmployeePortalServiceException(HttpStatus.NO_CONTENT,
                    "HttpClientErrorException while calling  api." + url);
        } catch (HttpStatusCodeException e) {
            logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
                    "HttpStatusCodeException during " + "URL " + url + "HTTP method " + httpMethod.name() + " call", e);
            throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "HttpStatusCodeException while calling api " + url);
        } catch (RestClientException e) {
            logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
                    " RestClientException during " + "URL " + url + "HTTP method " + httpMethod.name() + " call ", e);
            throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "RestClientException while calling api " + url);
        } catch (Exception e) {
            logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
                    " Exception during " + "URL " + url + "HTTP method " + httpMethod.name() + " call ", e);
            throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Exception while calling api " + url);
        }
    }

	public static String objectToJson(Object o) {
		Gson gson = new Gson();
		return gson.toJson(o);
	}
	public JSONObject getJSONObject(Object responsePayload) throws ParseException {
		String jsonString = objectToJson(responsePayload);
		Gson g = new Gson();
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(responsePayload.toString());
		return json;
	}
	public String prepareNameToPrintOnCard(String fullName) {
		String nameOnCard;
		if (fullName.length() > 19) {
			String[] nameChar = fullName.split(" ");
			nameOnCard = MessageFormat.format("{0} {1}", nameChar[0], nameChar[nameChar.length - 1]);
		} else {
			nameOnCard = fullName;
		}
		return nameOnCard;
	}

	public String prepareFullName(String firstName, String middleName, String lastName) {
		StringBuilder fullname = new StringBuilder();
		if (!StringUtils.isBlank(firstName)) {
			fullname.append(firstName);
			if (!StringUtils.isBlank(middleName)) {
				fullname.append(" ").append(middleName);
			}
			if (!StringUtils.isBlank(lastName)) {
				fullname.append(" ").append(lastName);
			}
		}
		return fullname.toString();
	}

	public Date stringToDate(String date, String inputDateFormat) {
		SimpleDateFormat sdf = new SimpleDateFormat(inputDateFormat);
		try {
			return sdf.parse(date);
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Exception while parsing date " + e);
			return null;
		}
	}

	public HttpHeaders getHeaders() {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "getHeaders()--Start");
		String securedAuthDetails = getAuthDetails();
		HttpHeaders securedHeader = new HttpHeaders();
		securedHeader.setContentType(MediaType.APPLICATION_JSON);
		securedHeader.add(HttpHeaders.AUTHORIZATION, securedAuthDetails);
		securedHeader.setAccept(Arrays.asList(new MediaType[] { MediaType.APPLICATION_JSON }));
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "getHeaders()--Ends");
		return securedHeader;
	}

	public String getAuthDetails() {
		String breAuth;
		String userNamePwd = authuserName + ":" + authpassword;
		breAuth = Base64.getEncoder().encodeToString(userNamePwd.getBytes());
		breAuth = authtype + " " + breAuth;
		return breAuth;
	}


}
