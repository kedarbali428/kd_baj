package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.util.List;

public class PrincipleProductDetails {
private String loanTypeRecommendation;
private String principleProductCode;
private Long isTenor;
private Integer dropLineTenor;
private BigDecimal emiAmount;
private BigDecimal roi;
private Long totalLoanAmount;
private String city;

private List<OfferDetailsStampBre> offerDetails;
public String getLoanTypeRecommendation() {
	return loanTypeRecommendation;
}
public void setLoanTypeRecommendation(String loanTypeRecommendation) {
	this.loanTypeRecommendation = loanTypeRecommendation;
}
public String getPrincipleProductCode() {
	return principleProductCode;
}
public void setPrincipleProductCode(String principleProductCode) {
	this.principleProductCode = principleProductCode;
}

public List<OfferDetailsStampBre> getOfferDetails() {
	return offerDetails;
}
public void setOfferDetails(List<OfferDetailsStampBre> offerDetails) {
	this.offerDetails = offerDetails;
}

public Long getIsTenor() {
	return isTenor;
}
public void setIsTenor(Long isTenor) {
	this.isTenor = isTenor;
}
public Integer getDropLineTenor() {
	return dropLineTenor;
}
public void setDropLineTenor(Integer dropLineTenor) {
	this.dropLineTenor = dropLineTenor;
}
public BigDecimal getEmiAmount() {
	return emiAmount;
}
public void setEmiAmount(BigDecimal emiAmount) {
	this.emiAmount = emiAmount;
}
public BigDecimal getRoi() {
	return roi;
}
public void setRoi(BigDecimal roi) {
	this.roi = roi;
}
public Long getTotalLoanAmount() {
	return totalLoanAmount;
}
public void setTotalLoanAmount(Long totalLoanAmount) {
	this.totalLoanAmount = totalLoanAmount;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

}
