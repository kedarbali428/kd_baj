package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class UserProducts implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String prodCode;
	private Long prodKey;
	private String prodName;
	public String getProdCode() {
		return prodCode;
	}
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}
	public Long getProdKey() {
		return prodKey;
	}
	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
}

