package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class EmploymentDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String employerName;
	private String designation;
	private String officialEmailAddress;
	private String companyCategory;
	private String otherEmployerName;
	private String otherDesignation;
	private String creditVidyaReportStatus;
	private String cvEmailId;
	private String cvRiskCategory;
	private String employerType;
	private String otherEmailAddress;

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getOfficialEmailAddress() {
		return officialEmailAddress;
	}

	public void setOfficialEmailAddress(String officialEmailAddress) {
		this.officialEmailAddress = officialEmailAddress;
	}

	public String getCompanyCategory() {
		return companyCategory;
	}

	public void setCompanyCategory(String companyCategory) {
		this.companyCategory = companyCategory;
	}

	public String getOtherEmployerName() {
		return otherEmployerName;
	}

	public void setOtherEmployerName(String otherEmployerName) {
		this.otherEmployerName = otherEmployerName;
	}

	public String getOtherDesignation() {
		return otherDesignation;
	}

	public void setOtherDesignation(String otherDesignation) {
		this.otherDesignation = otherDesignation;
	}

	public String getCreditVidyaReportStatus() {
		return creditVidyaReportStatus;
	}

	public void setCreditVidyaReportStatus(String creditVidyaReportStatus) {
		this.creditVidyaReportStatus = creditVidyaReportStatus;
	}

	public String getCvEmailId() {
		return cvEmailId;
	}

	public void setCvEmailId(String cvEmailId) {
		this.cvEmailId = cvEmailId;
	}

	public String getCvRiskCategory() {
		return cvRiskCategory;
	}

	public void setCvRiskCategory(String cvRiskCategory) {
		this.cvRiskCategory = cvRiskCategory;
	}

	public String getEmployerType() {
		return employerType;
	}

	public void setEmployerType(String employerType) {
		this.employerType = employerType;
	}

	public String getOtherEmailAddress() {
		return otherEmailAddress;
	}

	public void setOtherEmailAddress(String otherEmailAddress) {
		this.otherEmailAddress = otherEmailAddress;
	}
}
