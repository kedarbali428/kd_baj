package com.bajaj.markets.credit.employeeportal.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Predicate;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.AppBundleDetails;
import com.bajaj.markets.credit.employeeportal.bean.AppPlanDetCostBean;
import com.bajaj.markets.credit.employeeportal.bean.AppPricingAlertDetails;
import com.bajaj.markets.credit.employeeportal.bean.ApplicationAttributeBean;
import com.bajaj.markets.credit.employeeportal.bean.ApplicationDetail;
import com.bajaj.markets.credit.employeeportal.bean.FppBundleRequest;
import com.bajaj.markets.credit.employeeportal.bean.FppBundleResponse;
import com.bajaj.markets.credit.employeeportal.bean.FppPlan;
import com.bajaj.markets.credit.employeeportal.bean.Nominee;
import com.bajaj.markets.credit.employeeportal.bean.PricingDetail;
import com.bajaj.markets.credit.employeeportal.bean.PricingFees;
import com.bajaj.markets.credit.employeeportal.bean.QuestionAnswerWrapperBean;
import com.bajaj.markets.credit.employeeportal.bean.SavePricingBundle;
import com.bajaj.markets.credit.employeeportal.bean.StatusBean;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalConstants;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalPricingService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EmployeePortalApplicationPricingController {
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	EmployeePortalPricingService employeePortalPricingService;

	private static final String CLASSNAME = EmployeePortalApplicationPricingController.class.getName();

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch Application pricing Detail", notes = "Fetch comment details on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Pricing found for given application", response = PricingDetail.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/application/{applicationid}/pricing", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationPricingDetails(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getApplicationPricingDetails method controller - applicationId: " + applicationId);
		ArrayList<PricingDetail> pricing = employeePortalPricingService.findApplicationPricingDetails(headers,
				applicationId);
       
		Predicate<PricingDetail> condition  = pricingObj-> (pricingObj.getSource().equals(EmployeePortalConstants.EP) &&  pricingObj.getPricingStatus().equals(EmployeePortalConstants.REJECTED));
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getApplicationPricingDetails method controller - applicationId: " + applicationId +"object selected for removal: "+condition);
		pricing.removeIf(condition);

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside pricing Object size if removed   - applicationId: " + applicationId +" size: "+pricing.size());
		
		if (pricing.size() == 1) {
			PricingDetail pricingDetail = new PricingDetail();
			BeanUtils.copyProperties(pricing.get(0), pricingDetail);
			BigDecimal totalFees = new BigDecimal(0);
			pricingDetail.getFees().forEach(item -> {
				totalFees.add(item.getFeesInAmount());
			});
			pricingDetail.setSource("EP");
			pricingDetail.setPricingStatus("REJECTED");
			pricing.add(pricingDetail);
		}
		
		pricing.stream().forEach(pricingObj -> {
			pricingObj.getFees().sort(Comparator.comparing(PricingFees::getFeeCode));
			double totalSum = pricingObj.getFees().stream().mapToLong(i -> i.getFeesInAmount().longValue()).sum();
			pricingObj.setTotalFees(new BigDecimal(totalSum));
		});
		
		return new ResponseEntity<>(pricing, HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch aplication bundle Detail", notes = "Fetch bundle  details on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "GET bundle details for application", response = AppBundleDetails.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/creditapplications/{applicationid}/bundle", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationBundleDetails(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getApplicationBundleDetails method controller - applicationId: " + applicationId);
		return new ResponseEntity<>(employeePortalPricingService.findLatestBundleDetails(headers, applicationId),
				HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch finserv protection plan Detail", notes = "Fetch finserv protection plan  details on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "FPP plan found for given application", response = ApplicationDetail.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/vas/finservprotectionplan/applications/{applicationid}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getFPPApplicationBundleDetails(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getFPPApplicationBundleDetails method controller - applicationId: " + applicationId);
		return new ResponseEntity<>(employeePortalPricingService.getFppBundleDetails(headers, applicationId),
				HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch application applicant attributes Detail", notes = "Fetch applicant atributes details on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Attributes  found for given application", response = ApplicationAttributeBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/vas/finservprotectionplan/applications/{applicationid}/attributes", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationAtttributeDetails(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getApplicationAtttributeDetails method controller - applicationId: " + applicationId);
		return new ResponseEntity<>(
				employeePortalPricingService.findApplicationAtttributeDetails(headers, applicationId), HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch application bundle saved cost Detail", notes = "Fetch applicant atributes details on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Vas application cost  found for given application", response = AppPlanDetCostBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/vas/finservprotectionplan/applications/{applicationid}/cost", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationCostDetails(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getApplicationCostDetails method controller - applicationId: " + applicationId);
		return new ResponseEntity<>(employeePortalPricingService.findApplicationCostDetails(headers, applicationId),
				HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch application applicant nominee Detail", notes = "Fetch applicant atributes details on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application nominee  found for given application", response = Nominee.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/vas/finservprotectionplan/applications/{applicationid}/nominee", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationNomineeDetails(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getApplicationNomineeDetails method controller - applicationId: " + applicationId);
		return new ResponseEntity<>(employeePortalPricingService.findApplicationNomineeDetails(headers, applicationId),
				HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch application insurandce questions  Detail", notes = "Fetch application insurance questions details on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application insurance questions   found for given application", response = QuestionAnswerWrapperBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/vas/finservprotectionplan/applications/{applicationid}/questions", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationInsuranceQuestionsDetails(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getApplicationInsuranceQuestionsDetails method controller - applicationId: " + applicationId);
		return new ResponseEntity<>(
				employeePortalPricingService.findApplicationInsuranceQuestionsDetails(headers, applicationId),
				HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch fpp application Detail", notes = "Fetch fpp application details on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "FPP Application details   found for given application", response = FppPlan.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/employeeportal/vas/finservprotectionplan/{fppplancode}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationbyFPPPlanCode(@PathVariable("fppplancode") String fppPlanCode,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getApplicationbyFPPPlanCode method controller - fppPlanCode: " + fppPlanCode);
		return new ResponseEntity<>(employeePortalPricingService.findApplicationbyFPPPlanCode(headers, fppPlanCode),
				HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch fpp master details ", notes = "Fetch fpp master details on the basis of user applicationId", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "FPP master details   found for given application", response = FppBundleResponse.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/employeeportal/vas/product/bundle/{applicationid}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getProductBundle(@PathVariable("applicationid") Long applicationId,
			@Valid @RequestBody FppBundleRequest request, BindingResult result, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start  - fetchFppBundle method  :");
		if (result.hasErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
			throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_030", result.getFieldErrors().get(0).getDefaultMessage()));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getProductBundle method controller - applicationId: " + applicationId);

		FppBundleResponse response = employeePortalPricingService.findProductBundle(headers, applicationId, request);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Save  pricing ", notes = "Save pricing ", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Pricing save successfully", response = SavePricingBundle.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/employeeportal/application/{applicationid}/pricing", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> savePricing(@PathVariable("applicationid") Long applicationId,
			@RequestBody SavePricingBundle request , BindingResult result , @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start  - save pricing  method  :");

		if (result.hasErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
			throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_030", result.getFieldErrors().get(0).getDefaultMessage()));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside getProductBundle method controller - applicationId: " + applicationId);
		SavePricingBundle response = employeePortalPricingService.savePricing(headers, applicationId, request);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Update  pricing ", notes = "Update pricing ", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Pricing updated successfully", response = SavePricingBundle.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value = "/v1/employeeportal/application/{applicationid}/pricing", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateSavePricing(@PathVariable("applicationid") Long applicationId,
			@RequestBody SavePricingBundle request , BindingResult result , @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start  - save pricing  method  :");
		if (result.hasErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Field validation exception.");
			throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCA_030", result.getFieldErrors().get(0).getDefaultMessage()));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside updateSavePricing method controller - applicationId: " + applicationId);
		SavePricingBundle response = employeePortalPricingService.updatePricing(headers, applicationId, request);
		return new ResponseEntity<>(request, HttpStatus.OK);
	}
	
	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL })
	@ApiOperation(value = "Fetch application details for pricing confirmation alert", notes = "Fetch application details for pricing confirmation alert", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Application details for pricing confirmation alert", response = AppPricingAlertDetails.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/pricingalert", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationPricingAlertDetails(@PathVariable("applicationid") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"In getApplicationPricingAlertDetails method controller - applicationId: " + applicationId);
		AppPricingAlertDetails appPricingAlertDetails = employeePortalPricingService.getApplicationPricingAlertDetails(applicationId);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out getApplicationPricingAlertDetails method");
		return new ResponseEntity<>(appPricingAlertDetails,HttpStatus.OK);						
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Create Application Loan Pricing record", notes = "Create Application Loan Pricing record on the basis of tenure,amount,rate ", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "AppLoanPricing record created Successfully.", response = String.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/employeeportal/{applicationid}/loanpricing", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> createAppLoanPricingRecord(@PathVariable("applicationid")@NotBlank(message = "applicationkey cannot be null or empty") Long applicationid,
			@RequestParam Integer tenure,@RequestParam BigDecimal amount,@RequestParam BigDecimal rate,@RequestHeader HttpHeaders headers) {
		
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside createApplicationRecord method controller - application resource :" + applicationid);

		StatusBean statusBean = new StatusBean();
		String response = employeePortalPricingService.createOrUpdateAppLoanPricingDetails(applicationid, tenure, amount, rate, headers);
		statusBean.setStatus(response);
		if(statusBean.getStatus().equalsIgnoreCase(EmployeePortalConstants.SUCCESS)) {
			statusBean.setMessage(EmployeePortalConstants.UBI_FIELDS_ADDED);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Successfully added Ubi details");
		}
		else
			statusBean.setMessage(EmployeePortalConstants.UBI_FIELDS_FAILED);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Out of createAppLoanPricingRecord method");
		return new ResponseEntity<>(statusBean,HttpStatus.CREATED);
	}	
}