package com.bajaj.markets.credit.employeeportal.bean;

public enum VerificationSource {
	NSDL,
	KARZA,
	CREDIT_VIDYA;
}
