package com.bajaj.markets.credit.employeeportal.bean;

/**
 * Application Resource for creating parent & child application
 * @author 738768
 *
 */
public class Application{

	private String applicationKey;
	
	private String parentApplicationKey;

	private String mobile;
	
	private String dateOfBirth;
	
	private String applicantKey;
	
	private Integer l3ProductKey;
	
	private Integer l2ProductKey;
	
	private String firstName;
	private String lastName;
	private String lanNumber;
	private String productDesc;
	
	private String principleKey;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLanNumber() {
		return lanNumber;
	}
	public void setLanNumber(String lanNumber) {
		this.lanNumber = lanNumber;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public String getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}
	public String getParentApplicationKey() {
		return parentApplicationKey;
	}
	public void setParentApplicationKey(String parentApplicationKey) {
		this.parentApplicationKey = parentApplicationKey;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}
	public Integer getL3ProductKey() {
		return l3ProductKey;
	}
	public void setL3ProductKey(Integer l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}
	public Integer getL2ProductKey() {
		return l2ProductKey;
	}
	public void setL2ProductKey(Integer l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}
	
	public String getPrincipleKey() {
		return principleKey;
	}
	public void setPrincipleKey(String principleKey) {
		this.principleKey = principleKey;
	}
	
	@Override
	public String toString() {
		return "Application [applicationKey=" + applicationKey + ", parentApplicationKey=" + parentApplicationKey
				+ ", mobile=" + mobile + ", dateOfBirth=" + dateOfBirth + ", applicantKey=" + applicantKey
				+ ", l3ProductKey=" + l3ProductKey + ", l2ProductKey=" + l2ProductKey + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", lanNumber=" + lanNumber + ", productDesc=" + productDesc
				+ ", principleKey=" + principleKey + "]";
	}
}
