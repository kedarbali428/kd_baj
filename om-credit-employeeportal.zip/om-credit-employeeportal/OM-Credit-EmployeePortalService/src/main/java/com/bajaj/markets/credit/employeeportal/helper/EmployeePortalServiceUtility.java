package com.bajaj.markets.credit.employeeportal.helper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.employeeportal.bean.ApplicationSource;
import com.bajaj.markets.credit.employeeportal.bean.AuthUserBean;
import com.bajaj.markets.credit.employeeportal.bean.ChildRecord;
import com.bajaj.markets.credit.employeeportal.bean.UserName;
import com.bajaj.markets.credit.employeeportal.model.ApplicationAddress;
import com.bajaj.markets.credit.employeeportal.model.BureauHeader;
import com.bajaj.markets.credit.employeeportal.model.CibilReference;
import com.bajaj.markets.credit.employeeportal.model.UserRoleProduct;
import com.bajaj.markets.credit.employeeportal.repository.CibilReferenceRepository;
import com.bajaj.markets.credit.employeeportal.repository.UserRoleProductRepository;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalChildApplicationService;
import com.bajaj.markets.credit.employeeportal.util.EmployeePortalUtil;

@Component
public class EmployeePortalServiceUtility {

	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASSNAME = EmployeePortalServiceUtility.class.getName();

	List<Integer> appDetailsAttrList = Arrays.asList(30001, 30002, 30003, 30004, 30005, 30006, 30007);

	Map<String, String> addressCategory = new HashMap<>();
	Map<String, String> bureauResidenceCode = new HashMap<>();

	Map<String, String> occupationCode = new HashMap<>();

	Map<String, String> netGrossIncomeIndicator = new HashMap<>();

	Map<String, String> incomeIndicator = new HashMap<>();
	
	Map<Integer, String> planType = new HashMap<>();
	
	Map<Integer, List<Integer>> dispositionMasterMap = new HashMap<>();
	
	Map<String, List<String>> cibilRefSectionMap = new HashMap<>();
	
	Map<String, List<String>> prodCategoryMap = new HashMap<>();
	
	Map<Integer , String> vasMap = new HashMap<>();
	
	Map<Integer , Integer> vasSourceMap = new HashMap<>();
	
	Map<Integer , String> officialEmailVerificationMap = new HashMap<>();
	
	Map<String , String> getTelType = new HashMap<>();
	
    Map<Integer, List<Integer>> auditFieldCodes = new HashMap<>();
	
	Map<Integer, String> auditMethodName = new HashMap<>();
	
	Map<String,List<Integer>> prodKeys = new HashMap<>();
	
	Map<String ,List<String>> riskOfferType = new HashMap<>(); 
	
	@Autowired
	EmployeePortalChildApplicationService employeePortalChildRecordListService;
	
	@Autowired
	BusinessHelper businessHelper;
	
	@Autowired
	UserRoleProductRepository userRoleProductRepository;
	
	@Autowired
	CibilReferenceRepository cibilReferenceRepository;

	@PostConstruct
	public void init() {

	}

	/**
	 * @return the addressCategory
	 */
	public Map<String, String> getAddressCategory() {
		this.addressCategory.put("01", "Permanent Address");
		this.addressCategory.put("02", "Residence Address");
		this.addressCategory.put("03", "Office Address");
		this.addressCategory.put("04", "Not Categorized");
		return addressCategory;
	}

	/**
	 * @param addressCategory the addressCategory to set
	 */
	public void setAddressCategory(Map<String, String> addressCategory) {
		this.addressCategory = addressCategory;
	}

	/**
	 * @return the bureauResidenceCode
	 */
	public Map<String, String> getBureauResidenceCode() {
		this.bureauResidenceCode.put("01", "Owned");
		this.bureauResidenceCode.put("02", "Rented");
		return bureauResidenceCode;
	}

	/**
	 * @param bureauResidenceCode the bureauResidenceCode to set
	 */
	public void setBureauResidenceCode(Map<String, String> bureauResidenceCode) {
		this.bureauResidenceCode = bureauResidenceCode;
	}

	/**
	 * @return the occupationCode
	 */
	public Map<String, String> getOccupationCode() {
		this.occupationCode.put("01", "Salaried");
		this.occupationCode.put("02", "Self Employed Professional");
		this.occupationCode.put("03", "Self Employed");
		this.occupationCode.put("04", "Others");
		return occupationCode;
	}

	/**
	 * @param occupationCode the occupationCode to set
	 */
	public void setOccupationCode(Map<String, String> occupationCode) {
		this.occupationCode = occupationCode;
	}

	/**
	 * @return the netGrossIncomeIndicator
	 */
	public Map<String, String> getNetGrossIncomeIndicator() {
		this.netGrossIncomeIndicator.put("G", "Gross Income");
		this.netGrossIncomeIndicator.put("N", "Net Income");
		return netGrossIncomeIndicator;
	}

	/**
	 * @param netGrossIncomeIndicator the netGrossIncomeIndicator to set
	 */
	public void setNetGrossIncomeIndicator(Map<String, String> netGrossIncomeIndicator) {
		this.netGrossIncomeIndicator = netGrossIncomeIndicator;
	}

	/**
	 * @return the incomeIndicator
	 */
	public Map<String, String> getIncomeIndicator() {
		this.incomeIndicator.put("M", "Monthly");
		this.incomeIndicator.put("A", "Annual");
		return incomeIndicator;
	}

	/**
	 * @param incomeIndicator the incomeIndicator to set
	 */
	public void setIncomeIndicator(Map<String, String> incomeIndicator) {
		this.incomeIndicator = incomeIndicator;
	}

	/**
	 * @return the dispositionMasterMap
	 */
	public Map<Integer, List<Integer>> getDispositionMasterMap() {
		this.dispositionMasterMap.put(1, Arrays.asList(1002,1048,1175,1176,1178));
		this.dispositionMasterMap.put(2, Arrays.asList(1008,1052,1174,1177,1179));
		this.dispositionMasterMap.put(42, Arrays.asList(1186));
		return dispositionMasterMap;
	}

	/**
	 * @param dispositionMasterMap the dispositionMasterMap to set
	 */
	public void setDispositionMasterMap(Map<Integer, List<Integer>> dispositionMasterMap) {
		this.dispositionMasterMap = dispositionMasterMap;
	}
	
	public Map<Integer, List<Integer>> getAuditFieldCodes() {
		this.auditFieldCodes.put(284, Arrays.asList(30800,30035,30024,30025,30026,30261,30966));
		this.auditFieldCodes.put(285, Arrays.asList(30476,30477,30293));
		this.auditFieldCodes.put(286, Arrays.asList(30118,30119,30120,30121,30123,30124,31443,31444,31445));
		this.auditFieldCodes.put(287, Arrays.asList(30038,30044,30768,31004,30039));
		this.auditFieldCodes.put(290, Arrays.asList(30100,30101,30102,30103,30104,30971));
		this.auditFieldCodes.put(298, Arrays.asList(30048));
		this.auditFieldCodes.put(299, Arrays.asList(30024,30025,30026));
		this.auditFieldCodes.put(303, Arrays.asList(30031));
		this.auditFieldCodes.put(243,Arrays.asList(30827,30828,30825,30826,30824,30823,99999));
		return auditFieldCodes;
	}

	public void setAuditFieldCodes(Map<Integer, List<Integer>> auditFieldCodes) {
		this.auditFieldCodes = auditFieldCodes;
	}

	public Map<Integer, String> getAuditMethodName() {
		this.auditMethodName.put(284, "updateApplicantDetails");
		this.auditMethodName.put(286, "updateAddressDetails");
		this.auditMethodName.put(287, "updateEmployeeDetails");
		this.auditMethodName.put(285, "updateNomineeDetails");
		this.auditMethodName.put(290, "updateUTMDetails");
		this.auditMethodName.put(298, "updateBusinessDetails");
		this.auditMethodName.put(299, "updateNameDetail");
		this.auditMethodName.put(303, "updateEmailDetails");
		this.auditMethodName.put(243, "updateCreditReviewDetails");
		return auditMethodName;
	}

	public void setAuditMethodName(Map<Integer, String> auditMethodName) {
		this.auditMethodName = auditMethodName;
	}
	public Map<String, List<Integer>> getProdKeys() {
		this.prodKeys.put("prodKey", Arrays.asList(11,12,13,15,75));
		return prodKeys;
	}

	public void setProdKeys(Map<String, List<Integer>> prodKeys) {
		this.prodKeys = prodKeys;
	}
	public Map<String, List<String>> getRiskOfferType() {
		this.riskOfferType.put("riskOffer", Arrays.asList("SOL_LINE","BFL_LINE","BFSD_LINE"));
		return riskOfferType;
	}

	public void setRiskOfferType(Map<String, List<String>> riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public ApplicationSource getValidApplicationId(String applicationId, HttpHeaders headers, Boolean roleAuthenticationRequired) {
		ApplicationSource appSource = new ApplicationSource();
		List<UserRoleProduct> userRoleProdList=null;
		List<Long> prodKeyList = new ArrayList<>();
		short userType = 0;
		List<ChildRecord> childRecords = employeePortalChildRecordListService
				.getApplicationChildRecords(Long.valueOf(applicationId));
		if(roleAuthenticationRequired) {
			AuthUserBean authUserBean =EmployeePortalUtil.getAuthUserInfo();
			List<UserName> userList = businessHelper
					.getUserDetailsByUserRoleKey(null != authUserBean && null != authUserBean.getUserRoleKey()
							? Long.valueOf(authUserBean.getUserRoleKey())
							: 0, true, headers);
			
			 userType = userList.get(0).getUserType();
			
			userRoleProdList = userRoleProductRepository.findByUserrolekey(Long.valueOf(authUserBean.getUserRoleKey()));
			userRoleProdList.forEach(userRoleProd -> {
				prodKeyList.add(userRoleProd.getSubprodkey());
			});
		}
		
		if(userType == 6 || !roleAuthenticationRequired ) {
			if(!CollectionUtils.isEmpty(childRecords)) {
				for(ChildRecord childApp :childRecords) {
					if (childApp.getInProgress() && prodKeyList.contains(childApp.getProductKey())) {
						appSource.setValidApplicationId(childApp.getChildApplicationId());
						appSource.setSource(EmployeePortalConstants.CHILD);
						break;
					}else if(prodKeyList.contains(childApp.getProductKey())) {
						appSource.setValidApplicationId(childApp.getChildApplicationId());
						appSource.setSource(EmployeePortalConstants.CHILD);
					}
				}
			}
		}else
		if (!CollectionUtils.isEmpty(childRecords)) {
			childRecords.forEach(childApp -> {
				if (childApp.getInProgress()) {
					appSource.setValidApplicationId(childApp.getChildApplicationId());
					appSource.setSource(EmployeePortalConstants.CHILD);
				}
			});
		} else {
			appSource.setValidApplicationId(Long.valueOf(applicationId));
			appSource.setSource(EmployeePortalConstants.PARENT);
		}
		
		if(null == appSource.getValidApplicationId()) {
			appSource.setValidApplicationId(Long.valueOf(applicationId));
			appSource.setSource(EmployeePortalConstants.PARENT);
		}
		return appSource;
	}

		/**
	 * @return the planType
	 */
	public Map<Integer, String> getPlanType() {
		this.planType.put(1, "Retail");
		this.planType.put(2, "Bundle");
		return planType;
	}

	/**
	 * @param planType the planType to set
	 */
	public void setPlanType(Map<Integer, String> planType) {
		this.planType = planType;
	}

	/**
	 * @return the cibilRefSubSectionMap
	 */
	public Map<String, List<String>> getCibilRefSectionMap() {
		this.cibilRefSectionMap.put("COMMERCIALCIBIL", Arrays.asList("312", "314", "315"));
		this.cibilRefSectionMap.put("CONSUMERCIBIL", Arrays.asList("341", "342", "343"));
		return cibilRefSectionMap;
	}

	/**
	 * @param cibilRefSubSectionMap the cibilRefSubSectionMap to set
	 */
	public void setCibilRefSectionMap(Map<String, List<String>> cibilRefSectionMap) {
		this.cibilRefSectionMap = cibilRefSectionMap;
	}

	/**
	 * @return the prodCategoryMap
	 */
	public Map<String, List<String>> getProdCategoryMap() {
		this.prodCategoryMap.put("CC", Arrays.asList("CC"));
		this.prodCategoryMap.put("OMPL", Arrays.asList("OMPL","OMSL"));
		return prodCategoryMap;
	}

	/**
	 * @param prodCategoryMap the prodCategoryMap to set
	 */
	public void setProdCategoryMap(Map<String, List<String>> prodCategoryMap) {
		this.prodCategoryMap = prodCategoryMap;
	}
	
	public Map<Integer,String> getVasMap(){
		this.vasMap.put(1062,"JOURNEY");
		this.vasMap.put(1125,"EP");
		return vasMap;
	}
	
	public Map<Integer,Integer> getVasSourceMap(){
		this.vasSourceMap.put(1062,1);
		this.vasSourceMap.put(1125,2);
		return vasSourceMap;
	}
	
	public Map<Integer, String> getOfficialEmailVerificationMap(){
		this.officialEmailVerificationMap.put(0, "Not Required");
		this.officialEmailVerificationMap.put(1, "Required");
		this.officialEmailVerificationMap.put(2, "Not Applicable");
		return officialEmailVerificationMap;
	}
	
	public Map<String, String> getTelType() {
		this.getTelType.put("00", "Not Specified");
		this.getTelType.put("01", "Mobile Phone");
		this.getTelType.put("02", "Home Phone");
		this.getTelType.put("03", "Office Phone");
		return getTelType;
	}
	
	public String nameBuilder(String firstName, String middleName, String lastName) {
		StringBuilder nameBuilder = new StringBuilder();
		nameBuilder = null!= firstName ? nameBuilder.append(firstName) : nameBuilder;
		nameBuilder.append(" ");
		nameBuilder = null!= middleName ? nameBuilder.append(middleName) : nameBuilder;
		nameBuilder.append(" ");
		nameBuilder = null!= lastName ? nameBuilder.append(lastName) : nameBuilder;
		return nameBuilder.toString();
	}
	
	public String addressBuilder(String line1, String line2, String line3, String city, String state, String pinCode) {
		StringBuilder addressBuilder = new StringBuilder();
		addressBuilder = null!= line1 ? addressBuilder.append(line1).append(", ") : addressBuilder;
		addressBuilder = null!= line2 ? addressBuilder.append(line2).append(", ") : addressBuilder;
		addressBuilder = null!= line3 ? addressBuilder.append(line3).append(", ") : addressBuilder;
		addressBuilder = null!= city ? addressBuilder.append(city).append(", ") : addressBuilder;
		addressBuilder = null!= state ? addressBuilder.append(state).append(", ") : addressBuilder;
		addressBuilder = null!= pinCode ? addressBuilder.append(pinCode) : addressBuilder;
		return addressBuilder.toString();
	}
	public String removeLeadingZero(String accNumber) {
		int i = 0;
		while(i<accNumber.length()&& accNumber.charAt(i)== '0')
			i++;
		StringBuffer stringBuffer = new StringBuffer(accNumber);
		stringBuffer.replace(0, i, "");
		return stringBuffer.toString();
	}
	
	public List<ApplicationAddress> filterAddressDetails(List<ApplicationAddress> addressList) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside fetchAddresses method before filter");
		for(int i=0;i<addressList.size();i++) {
			for(int j=i+1;j<addressList.size();j++) {
				if(addressList.get(i).getAddrtypkey()==addressList.get(j).getAddrtypkey()) {
					if(null!=addressList.get(i).getPrefferedflg() && addressList.get(i).getPrefferedflg()==1 ) {
						addressList.remove(addressList.get(j));
						}else {
							addressList.remove(addressList.get(i));
						}
					}
				}
			}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside fetchAddresses method - End");
		return addressList;
	}
	
	public String convertMonthsToYears(Integer months) {
		return ((months / 12) + "." + (months % 12));
	}
	
}
