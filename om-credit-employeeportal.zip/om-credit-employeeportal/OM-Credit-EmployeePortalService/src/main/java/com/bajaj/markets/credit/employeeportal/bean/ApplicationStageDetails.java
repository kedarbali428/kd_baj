package com.bajaj.markets.credit.employeeportal.bean;

/**
 * Application Stage Details resource
 * 
 * @author 736919
 * 
 */
public class ApplicationStageDetails {

	private Integer stageKey;

	private Integer subStageKey;

	private String subStageDesc;

	private Integer statusKey;

	private Integer percentageCompletion;

	private String stageCd;

	private String subStageCd;

	private String statusCd;

	private String applicationKey;

	private String appDate;

	private String city;

	private String principalName;

	private String occupationType;

	private String hmlFlag;

	private String hlProductIntent;

	private String bflBranch;

	private String l2Product;

	public Integer getStageKey() {
		return stageKey;
	}

	public void setStageKey(Integer stageKey) {
		this.stageKey = stageKey;
	}

	public Integer getSubStageKey() {
		return subStageKey;
	}

	public void setSubStageKey(Integer subStageKey) {
		this.subStageKey = subStageKey;
	}

	public String getSubStageDesc() {
		return subStageDesc;
	}

	public void setSubStageDesc(String subStageDesc) {
		this.subStageDesc = subStageDesc;
	}

	public Integer getStatusKey() {
		return statusKey;
	}

	public void setStatusKey(Integer statusKey) {
		this.statusKey = statusKey;
	}

	public Integer getPercentageCompletion() {
		return percentageCompletion;
	}

	public void setPercentageCompletion(Integer percentageCompletion) {
		this.percentageCompletion = percentageCompletion;
	}

	@Override
	public String toString() {
		return "ApplicationStageDetails [stageKey=" + stageKey + ", subStageKey=" + subStageKey + ", statusKey="
				+ statusKey + ", percentageCompletion=" + percentageCompletion + "]";
	}

	/**
	 * @return the stageCd
	 */
	public String getStageCd() {
		return stageCd;
	}

	/**
	 * @param stageCd the stageCd to set
	 */
	public void setStageCd(String stageCd) {
		this.stageCd = stageCd;
	}

	/**
	 * @return the subStageCd
	 */
	public String getSubStageCd() {
		return subStageCd;
	}

	/**
	 * @param subStageCd the subStageCd to set
	 */
	public void setSubStageCd(String subStageCd) {
		this.subStageCd = subStageCd;
	}

	/**
	 * @return the statusCd
	 */
	public String getStatusCd() {
		return statusCd;
	}

	/**
	 * @param statusCd the statusCd to set
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	/**
	 * @return the applicationKey
	 */
	public String getApplicationKey() {
		return applicationKey;
	}

	/**
	 * @param applicationKey the applicationKey to set
	 */
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	/**
	 * @return the appDate
	 */
	public String getAppDate() {
		return appDate;
	}

	/**
	 * @param appDate the appDate to set
	 */
	public void setAppDate(String appDate) {
		this.appDate = appDate;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getOccupationType() {
		return occupationType;
	}

	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}

	public String getHmlFlag() {
		return hmlFlag;
	}

	public void setHmlFlag(String hmlFlag) {
		this.hmlFlag = hmlFlag;
	}

	public String getHlProductIntent() {
		return hlProductIntent;
	}

	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public String getBflBranch() {
		return bflBranch;
	}

	public void setBflBranch(String bflBranch) {
		this.bflBranch = bflBranch;
	}

	public String getL2Product() {
		return l2Product;
	}

	public void setL2Product(String l2Product) {
		this.l2Product = l2Product;
	}

}