package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class LookupCodeBean {
	
	private long lookupCodeId;
	private String lookupCodeName;
	private String lookupCodeCode;
	private String lookupCodeType;
	private Integer isActive;
	
	List<LookupCodeValueBean> codeValueBeans;

	public long getId() {
		return lookupCodeId;
	}
	
	public String getName() {
		return lookupCodeName;
	}
	
	public long getLookupCodeId() {
		return lookupCodeId;
	}

	public void setLookupCodeId(long lookupCodeId) {
		this.lookupCodeId = lookupCodeId;
	}

	public String getLookupCodeName() {
		return lookupCodeName;
	}

	public void setLookupCodeName(String lookupCodeName) {
		this.lookupCodeName = lookupCodeName;
	}

	public String getLookupCodeCode() {
		return lookupCodeCode;
	}

	public void setLookupCodeCode(String lookupCodeCode) {
		this.lookupCodeCode = lookupCodeCode;
	}

	public String getLookupCodeType() {
		return lookupCodeType;
	}

	public void setLookupCodeType(String lookupCodeType) {
		this.lookupCodeType = lookupCodeType;
	}

	public Integer isActive() {
		return isActive;
	}

	public void setActive(Integer isActive) {
		this.isActive = isActive;
	}

	public List<LookupCodeValueBean> getCodeValueBeans() {
		return codeValueBeans;
	}

	public void setCodeValueBeans(List<LookupCodeValueBean> codeValueBeans) {
		this.codeValueBeans = codeValueBeans;
	}

	/**
	 * @return the isActive
	 */
	public Integer getIsActive() {
		return isActive;
	}

	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}
}
