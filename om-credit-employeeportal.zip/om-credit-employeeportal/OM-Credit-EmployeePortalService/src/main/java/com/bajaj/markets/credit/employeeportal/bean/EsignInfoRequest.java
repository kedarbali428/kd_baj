package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

public class EsignInfoRequest {
	
	private Long appEsignInfokey;

	private Status status; 

	private String suspendReason;
	
	private Long appPricingkey;
	
	private Long appDocKey;
	
	private BigDecimal isActive;

	public Long getAppDocKey() {
		return appDocKey;
	}

	public void setAppDocKey(Long appDocKey) {
		this.appDocKey = appDocKey;
	}

	public Long getAppEsignInfokey() {
		return appEsignInfokey;
	}

	public void setAppEsignInfokey(Long appEsignInfokey) {
		this.appEsignInfokey = appEsignInfokey;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getSuspendReason() {
		return suspendReason;
	}

	public void setSuspendReason(String suspendReason) {
		this.suspendReason = suspendReason;
	}

	public Long getAppPricingkey() {
		return appPricingkey;
	}

	public void setAppPricingkey(Long appPricingkey) {
		this.appPricingkey = appPricingkey;
	}

	public BigDecimal getIsActive() {
		return isActive;
	}

	public void setIsActive(BigDecimal isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "EsignInfoRequest [appEsignInfokey=" + appEsignInfokey + ", status=" + status + ", suspendReason="
				+ suspendReason + ", appPricingkey=" + appPricingkey + ", appDocKey=" + appDocKey + ", isActive="
				+ isActive + "]";
	}
}
