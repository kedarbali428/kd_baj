package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class SystemSelectedMandateDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String mandateSource;
	private Float mandateMaxLimit;
	private Float ecsUtilizedLimit;
	private String openEcsFlag;
	private Timestamp expiryDate;
	private String accountNumber;
	private String ifscCode;
	private String regitrationId;
	private String barcodeNumber;
	private Long finnOneECSId;
	private String finnOneRepayMode;
	private String finnOneSubrepayMode;

	public String getMandateSource() {
		return mandateSource;
	}

	public void setMandateSource(String mandateSource) {
		this.mandateSource = mandateSource;
	}

	public Float getMandateMaxLimit() {
		return mandateMaxLimit;
	}

	public void setMandateMaxLimit(Float mandateMaxLimit) {
		this.mandateMaxLimit = mandateMaxLimit;
	}

	public Float getEcsUtilizedLimit() {
		return ecsUtilizedLimit;
	}

	public void setEcsUtilizedLimit(Float ecsUtilizedLimit) {
		this.ecsUtilizedLimit = ecsUtilizedLimit;
	}

	public String getOpenEcsFlag() {
		return openEcsFlag;
	}

	public void setOpenEcsFlag(String openEcsFlag) {
		this.openEcsFlag = openEcsFlag;
	}

	public Timestamp getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getRegitrationId() {
		return regitrationId;
	}

	public void setRegitrationId(String regitrationId) {
		this.regitrationId = regitrationId;
	}

	public String getBarcodeNumber() {
		return barcodeNumber;
	}

	public void setBarcodeNumber(String barcodeNumber) {
		this.barcodeNumber = barcodeNumber;
	}

	public Long getFinnOneECSId() {
		return finnOneECSId;
	}

	public void setFinnOneECSId(Long finnOneECSId) {
		this.finnOneECSId = finnOneECSId;
	}

	public String getFinnOneRepayMode() {
		return finnOneRepayMode;
	}

	public void setFinnOneRepayMode(String finnOneRepayMode) {
		this.finnOneRepayMode = finnOneRepayMode;
	}

	public String getFinnOneSubrepayMode() {
		return finnOneSubrepayMode;
	}

	public void setFinnOneSubrepayMode(String finnOneSubrepayMode) {
		this.finnOneSubrepayMode = finnOneSubrepayMode;
	}

}
