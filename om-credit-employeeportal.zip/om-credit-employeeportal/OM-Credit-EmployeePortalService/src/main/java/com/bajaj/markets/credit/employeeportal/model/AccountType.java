package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;




@Entity
@Table(name = "account_type", schema = "dmmaster")

public class AccountType implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long acctypkey;
	
	private String acctypcode;
	private String acctypdesc;
	private String acctyppurpose;
	private String acctypheadcode;
	private Long acctypinternalacc;
	private Long acctypcustsysacc;
	private String acctypacclimtcategory;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;

	public Long getAcctypkey() {
		return acctypkey;
	}

	public void setAcctypkey(Long acctypkey) {
		this.acctypkey = acctypkey;
	}

	public String getAcctypcode() {
		return acctypcode;
	}

	public void setAcctypcode(String acctypcode) {
		this.acctypcode = acctypcode;
	}

	public String getAcctypdesc() {
		return acctypdesc;
	}

	public void setAcctypdesc(String acctypdesc) {
		this.acctypdesc = acctypdesc;
	}

	public String getAcctyppurpose() {
		return acctyppurpose;
	}

	public void setAcctyppurpose(String acctyppurpose) {
		this.acctyppurpose = acctyppurpose;
	}

	public String getAcctypheadcode() {
		return acctypheadcode;
	}

	public void setAcctypheadcode(String acctypheadcode) {
		this.acctypheadcode = acctypheadcode;
	}

	public Long getAcctypinternalacc() {
		return acctypinternalacc;
	}

	public void setAcctypinternalacc(Long acctypinternalacc) {
		this.acctypinternalacc = acctypinternalacc;
	}

	public Long getAcctypcustsysacc() {
		return acctypcustsysacc;
	}

	public void setAcctypcustsysacc(Long acctypcustsysacc) {
		this.acctypcustsysacc = acctypcustsysacc;
	}

	public String getAcctypacclimtcategory() {
		return acctypacclimtcategory;
	}

	public void setAcctypacclimtcategory(String acctypacclimtcategory) {
		this.acctypacclimtcategory = acctypacclimtcategory;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	@Override
	public String toString() {
		return "AccountType [acctypkey=" + acctypkey + ", acctypcode=" + acctypcode + ", acctypdesc=" + acctypdesc
				+ ", acctyppurpose=" + acctyppurpose + ", acctypheadcode=" + acctypheadcode + ", acctypinternalacc="
				+ acctypinternalacc + ", acctypcustsysacc=" + acctypcustsysacc + ", acctypacclimtcategory="
				+ acctypacclimtcategory + ", isactive=" + isactive + ", lstupdateby=" + lstupdateby + ", lstupdatedt="
				+ lstupdatedt + "]";
	}

}
