package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the application database table.
 * 
 */
@Entity
@Table(name = "application", schema = "dmcredit")
public class Application implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "application_applicationkey_generator", sequenceName = "dmcredit.seq_pk_application", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_applicationkey_generator")
	private Long applicationkey;

	private Timestamp appdate;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long parentapplicationkey;

	private Long prodcdl2;

	private Long prodcdl3;

	private Integer inprocessflg;

	private Integer isbundleselected;

	private String productrefno;
	
	private Long prodtypekey;	

	@OneToMany(mappedBy = "application", cascade = CascadeType.ALL)
	private List<ApplicationAttribute> applicationAttributes;

	@OneToMany(mappedBy = "application", cascade = CascadeType.ALL)
	private List<AppUserAssignment> AppUserAssignments;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "appstatus")
	private StatusMaster statusMaster;

	private String hlproductintent;

	private Integer citykey;

	private Long bflbranchkey;

	private String riskoffertype;
	
	private String createdby;
	
	private String appprocessidentifier;
	
	private Integer requestedcreditamount;

	private Long pincodekey;
	
	public Integer getRequestedcreditamount() {
		return requestedcreditamount;
	}

	public void setRequestedcreditamount(Integer requestedcreditamount) {
		this.requestedcreditamount = requestedcreditamount;
	}

	public String getAppprocessidentifier() {
		return appprocessidentifier;
	}

	public void setAppprocessidentifier(String appprocessidentifier) {
		this.appprocessidentifier = appprocessidentifier;
	}

	public Application() {
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Timestamp getAppdate() {
		return this.appdate;
	}

	public void setAppdate(Timestamp appdate) {
		this.appdate = appdate;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getParentapplicationkey() {
		return parentapplicationkey;
	}

	public void setParentapplicationkey(Long parentapplicationkey) {
		this.parentapplicationkey = parentapplicationkey;
	}

	public Long getProdcdl2() {
		return this.prodcdl2;
	}

	public void setProdcdl2(Long prodcdl2) {
		this.prodcdl2 = prodcdl2;
	}

	public List<ApplicationAttribute> getApplicationAttributes() {
		return this.applicationAttributes;
	}

	public void setApplicationAttributes(List<ApplicationAttribute> applicationAttributes) {
		this.applicationAttributes = applicationAttributes;
	}

	/**
	 * @return the prodcdl3
	 */
	public Long getProdcdl3() {
		return prodcdl3;
	}

	/**
	 * @param prodcdl3 the prodcdl3 to set
	 */
	public void setProdcdl3(Long prodcdl3) {
		this.prodcdl3 = prodcdl3;
	}

	public List<AppUserAssignment> getAppUserAssignments() {
		return AppUserAssignments;
	}

	public void setAppUserAssignments(List<AppUserAssignment> appUserAssignments) {
		AppUserAssignments = appUserAssignments;
	}

	/**
	 * @return the statusMaster
	 */
	public StatusMaster getStatusMaster() {
		return statusMaster;
	}

	/**
	 * @param statusMaster the statusMaster to set
	 */
	public void setStatusMaster(StatusMaster statusMaster) {
		this.statusMaster = statusMaster;
	}

	/**
	 * @return the inprocessflg
	 */
	public Integer getInprocessflg() {
		return inprocessflg;
	}

	/**
	 * @param inprocessflg the inprocessflg to set
	 */
	public void setInprocessflg(Integer inprocessflg) {
		this.inprocessflg = inprocessflg;
	}

	public Integer getIsbundleselected() {
		return isbundleselected;
	}

	public void setIsbundleselected(Integer isbundleselected) {
		this.isbundleselected = isbundleselected;
	}

	/**
	 * @return the productrefno
	 */
	public String getProductrefno() {
		return productrefno;
	}

	/**
	 * @param productrefno the productrefno to set
	 */
	public void setProductrefno(String productrefno) {
		this.productrefno = productrefno;
	}

	public String getHlproductintent() {
		return hlproductintent;
	}

	public void setHlproductintent(String hlproductintent) {
		this.hlproductintent = hlproductintent;
	}

	/**
	 * @return the citykey
	 */
	public Integer getCitykey() {
		return citykey;
	}

	/**
	 * @param citykey the citykey to set
	 */
	public void setCitykey(Integer citykey) {
		this.citykey = citykey;
	}

	public Long getBflbranchkey() {
		return bflbranchkey;
	}

	public void setBflbranchkey(Long bflbranchkey) {
		this.bflbranchkey = bflbranchkey;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public Long getProdtypekey() {
		return prodtypekey;
	}

	public void setProdtypekey(Long prodtypekey) {
		this.prodtypekey = prodtypekey;
	}

	public Long getPincodekey() {
		return pincodekey;
	}

	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}
	
}