package com.bajaj.markets.credit.employeeportal.bean;

public class AppSecPDCDetail {
	private String pdcnumber1;
	private String pdcnumber2;
	private String pdcnumber3;
	private String pdcnumber4;
	private String pdcamount1;
	private String pdcamount2;
	private String pdcamount3;
	private String pdcamount4;
	/**
	 * @return the pdcnumber1
	 */
	public String getPdcnumber1() {
		return pdcnumber1;
	}
	/**
	 * @param pdcnumber1 the pdcnumber1 to set
	 */
	public void setPdcnumber1(String pdcnumber1) {
		this.pdcnumber1 = pdcnumber1;
	}
	/**
	 * @return the pdcnumber2
	 */
	public String getPdcnumber2() {
		return pdcnumber2;
	}
	/**
	 * @param pdcnumber2 the pdcnumber2 to set
	 */
	public void setPdcnumber2(String pdcnumber2) {
		this.pdcnumber2 = pdcnumber2;
	}
	/**
	 * @return the pdcnumber3
	 */
	public String getPdcnumber3() {
		return pdcnumber3;
	}
	/**
	 * @param pdcnumber3 the pdcnumber3 to set
	 */
	public void setPdcnumber3(String pdcnumber3) {
		this.pdcnumber3 = pdcnumber3;
	}
	/**
	 * @return the pdcnumber4
	 */
	public String getPdcnumber4() {
		return pdcnumber4;
	}
	/**
	 * @param pdcnumber4 the pdcnumber4 to set
	 */
	public void setPdcnumber4(String pdcnumber4) {
		this.pdcnumber4 = pdcnumber4;
	}
	/**
	 * @return the pdcamount1
	 */
	public String getPdcamount1() {
		return pdcamount1;
	}
	/**
	 * @param pdcamount1 the pdcamount1 to set
	 */
	public void setPdcamount1(String pdcamount1) {
		this.pdcamount1 = pdcamount1;
	}
	/**
	 * @return the pdcamount2
	 */
	public String getPdcamount2() {
		return pdcamount2;
	}
	/**
	 * @param pdcamount2 the pdcamount2 to set
	 */
	public void setPdcamount2(String pdcamount2) {
		this.pdcamount2 = pdcamount2;
	}
	/**
	 * @return the pdcamount3
	 */
	public String getPdcamount3() {
		return pdcamount3;
	}
	/**
	 * @param pdcamount3 the pdcamount3 to set
	 */
	public void setPdcamount3(String pdcamount3) {
		this.pdcamount3 = pdcamount3;
	}
	/**
	 * @return the pdcamount4
	 */
	public String getPdcamount4() {
		return pdcamount4;
	}
	/**
	 * @param pdcamount4 the pdcamount4 to set
	 */
	public void setPdcamount4(String pdcamount4) {
		this.pdcamount4 = pdcamount4;
	}
}
