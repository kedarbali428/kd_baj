package com.bajaj.markets.credit.employeeportal.bean;

public class SubIndustryMasterBean {

	private Long subIndMastKey;
	
	private Long indMastKey;
	
	private String subIndMastCode;
	
	private String subIndMastDesc;

	/**
	 * @return the subIndMastKey
	 */
	public Long getSubIndMastKey() {
		return subIndMastKey;
	}

	/**
	 * @param subIndMastKey the subIndMastKey to set
	 */
	public void setSubIndMastKey(Long subIndMastKey) {
		this.subIndMastKey = subIndMastKey;
	}

	/**
	 * @return the indMastKey
	 */
	public Long getIndMastKey() {
		return indMastKey;
	}

	/**
	 * @param indMastKey the indMastKey to set
	 */
	public void setIndMastKey(Long indMastKey) {
		this.indMastKey = indMastKey;
	}

	/**
	 * @return the subIndMastCode
	 */
	public String getSubIndMastCode() {
		return subIndMastCode;
	}

	/**
	 * @param subIndMastCode the subIndMastCode to set
	 */
	public void setSubIndMastCode(String subIndMastCode) {
		this.subIndMastCode = subIndMastCode;
	}

	/**
	 * @return the subIndMastDesc
	 */
	public String getSubIndMastDesc() {
		return subIndMastDesc;
	}

	/**
	 * @param subIndMastDesc the subIndMastDesc to set
	 */
	public void setSubIndMastDesc(String subIndMastDesc) {
		this.subIndMastDesc = subIndMastDesc;
	}

	
}
