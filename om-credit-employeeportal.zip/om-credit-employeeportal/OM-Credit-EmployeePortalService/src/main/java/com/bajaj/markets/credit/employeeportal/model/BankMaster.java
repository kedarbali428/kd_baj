package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the BANK_MASTER database table.
 * 
 */
@Entity
@Table(name = "bank_master", schema = "dmmaster")
public class BankMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long bankmastkey;

	private String bankcode;

	private String bankname;

	private String banktypofinstitution;

	private String banksegment;

	private Long bankdirectdebitflg;

	private Long bankimpsflg;

	private Long bankemandateflg;

	private Long bankpaygatewayflg;

	private Integer bankmastisactive;

	private String bankmastlstupdateby;

	private Timestamp bankmastlstupdatedt;

	private Long bankmastaccnumlength;

	private String bankshortcode;

	private Long banknachflg;

	private Long bankneftflg;

	private Long perfiosenableflg;

	private String preferredmode1;

//	// bi-directional many-to-one association to BranchMaster
//	@OneToMany(mappedBy = "bankMaster")
//	private List<BranchMaster> branchMasters;

	public BankMaster() {
	}

	public Long getBankmastkey() {
		return bankmastkey;
	}

	public void setBankmastkey(Long bankmastkey) {
		this.bankmastkey = bankmastkey;
	}

	public String getBankcode() {
		return bankcode;
	}

	public void setBankcode(String bankcode) {
		this.bankcode = bankcode;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getBanktypofinstitution() {
		return banktypofinstitution;
	}

	public void setBanktypofinstitution(String banktypofinstitution) {
		this.banktypofinstitution = banktypofinstitution;
	}

	public String getBanksegment() {
		return banksegment;
	}

	public void setBanksegment(String banksegment) {
		this.banksegment = banksegment;
	}

	public Long getBankdirectdebitflg() {
		return bankdirectdebitflg;
	}

	public void setBankdirectdebitflg(Long bankdirectdebitflg) {
		this.bankdirectdebitflg = bankdirectdebitflg;
	}

	public Long getBankimpsflg() {
		return bankimpsflg;
	}

	public void setBankimpsflg(Long bankimpsflg) {
		this.bankimpsflg = bankimpsflg;
	}

	public Long getBankemandateflg() {
		return bankemandateflg;
	}

	public void setBankemandateflg(Long bankemandateflg) {
		this.bankemandateflg = bankemandateflg;
	}

	public Long getBankpaygatewayflg() {
		return bankpaygatewayflg;
	}

	public void setBankpaygatewayflg(Long bankpaygatewayflg) {
		this.bankpaygatewayflg = bankpaygatewayflg;
	}

	public Integer getBankmastisactive() {
		return bankmastisactive;
	}

	public void setBankmastisactive(Integer bankmastisactive) {
		this.bankmastisactive = bankmastisactive;
	}

	public String getBankmastlstupdateby() {
		return bankmastlstupdateby;
	}

	public void setBankmastlstupdateby(String bankmastlstupdateby) {
		this.bankmastlstupdateby = bankmastlstupdateby;
	}

	public Timestamp getBankmastlstupdatedt() {
		return bankmastlstupdatedt;
	}

	public void setBankmastlstupdatedt(Timestamp bankmastlstupdatedt) {
		this.bankmastlstupdatedt = bankmastlstupdatedt;
	}

	public Long getBankmastaccnumlength() {
		return bankmastaccnumlength;
	}

	public void setBankmastaccnumlength(Long bankmastaccnumlength) {
		this.bankmastaccnumlength = bankmastaccnumlength;
	}

	public String getBankshortcode() {
		return bankshortcode;
	}

	public void setBankshortcode(String bankshortcode) {
		this.bankshortcode = bankshortcode;
	}

	public Long getBanknachflg() {
		return banknachflg;
	}

	public void setBanknachflg(Long banknachflg) {
		this.banknachflg = banknachflg;
	}

	public Long getBankneftflg() {
		return bankneftflg;
	}

	public void setBankneftflg(Long bankneftflg) {
		this.bankneftflg = bankneftflg;
	}

	public Long getPerfiosenableflg() {
		return perfiosenableflg;
	}

	public void setPerfiosenableflg(Long perfiosenableflg) {
		this.perfiosenableflg = perfiosenableflg;
	}

	public String getPreferredmode1() {
		return preferredmode1;
	}

	public void setPreferredmode1(String preferredmode1) {
		this.preferredmode1 = preferredmode1;
	}




}