package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class AppAssignmentResponseBean implements Serializable{

	private static final long serialVersionUID = 1L;

	private boolean assignedToFlag;

	public boolean isAssignedToFlag() {
		return assignedToFlag;
	}

	public void setAssignedToFlag(boolean assignedToFlag) {
		this.assignedToFlag = assignedToFlag;
	}
	
	
	
}
