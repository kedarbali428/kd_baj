package com.bajaj.markets.credit.employeeportal.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.AppTranchResponse;
import com.bajaj.markets.credit.employeeportal.bean.BeneficiaryResponseBean;
import com.bajaj.markets.credit.employeeportal.bean.TranchBean;
import com.bajaj.markets.credit.employeeportal.helper.CreditEmployeePortalServiceException;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalTranchService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class EmployeePortalTranchController {
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	EmployeePortalTranchService employeePortalTranchCtaService;
	
	private static final String CLASSNAME = EmployeePortalTranchController.class.getName();
	
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Applications tranch details endpoint", notes = "Save user tranch details", httpMethod = "POST")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Tranch details added successfully.", response = TranchBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Not found", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid Input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(value = "/v1/credit/employeeportal/applications/{applicationKey}/tranches", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> saveTrancheDetails(@Valid @RequestBody TranchBean inputBean, 
			@PathVariable("applicationKey") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") Long applicationKey,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers) {
		TranchBean result = new TranchBean();
		if (bindingResult.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getApplicant method - Invalid parameters passed");
			throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-1022", bindingResult.getFieldErrors().get(0).getDefaultMessage()));
		}else {
		result = employeePortalTranchCtaService.saveTrancheDetails(inputBean,applicationKey,headers);
		return new ResponseEntity<>(result, HttpStatus.CREATED);
		}
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER,Role.EMPLOYEE})
	@ApiOperation(value = "Applications tranch details endpoint", notes = "Update user tranch details", httpMethod = "PUT")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Tranch details updated successfully.", response = TranchBean.class),
			@ApiResponse(code = 200, message = "Tranch details updated sucessfully", response = TranchBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Not found", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid Input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PutMapping(value ="/v1/credit/employeeportal/applications/{applicationKey}/tranches/{trancheKey}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateTranchDetails(@Valid @RequestBody TranchBean tranchCta,
			@PathVariable(name = "applicationKey")@Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") Long applicationId,
			@PathVariable("trancheKey")@Digits(fraction = 0, integer = 10,message = "trancheKey should be numeric & should not exceeds size") Long trancheKey,
			BindingResult bindingResult,@RequestHeader HttpHeaders headers){
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
				"Inside ApplicationBankDetailsController :: updateTranchDetails method started - applicationKey :" + applicationId);
		if (bindingResult.hasFieldErrors()) {
			logger.error(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside updateTranchDetails method - Invalid parameters passed");
			throw new CreditEmployeePortalServiceException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CAS-1022", bindingResult.getFieldErrors().get(0).getDefaultMessage()));
		}else {
			TranchBean response = employeePortalTranchCtaService.updateTranchDetails(tranchCta, applicationId,trancheKey, headers);;
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,
					"Completed ApplicationTranchCtaController :: updateTranchDetails method");
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER,Role.EMPLOYEE})
	@ApiOperation(value = "Fetch Tranche details.", notes = "Fetch Tranche details on the basis of applicationKey and bankdetailskey.", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Tranche details fetched successfully.", response = AppTranchResponse.class),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 400, message = "Bad Request", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/credit/employeeportal/applications/{tranchApplicationKey}/tranches", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> fetchTrancheDetails(@PathVariable("tranchApplicationKey") @NotNull(message = "tranchApplicationKey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "tranchApplicationKey should be numeric & should not exceeds size") String tranchdetailsKey,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER,"Inside ApplicationTrancheDetailsController :: fetchTrancheDetails method started - applicationKey :" + tranchdetailsKey);
		AppTranchResponse tranchResponse= new AppTranchResponse();
		tranchResponse = employeePortalTranchCtaService.fetchTrancheDetails(tranchdetailsKey, headers);
		return new ResponseEntity<>(tranchResponse , HttpStatus.OK);
	}
	
	

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER,Role.EMPLOYEE})
	@ApiOperation(value = "Fetch  Beneficiary details.", notes = "Fetch  Beneficiary details on the basis of applicationKey ", httpMethod = "GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = " Beneficiary details fetched successfully.", response = AppTranchResponse.class),
		@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
		@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
		@ApiResponse(code = 400, message = "Bad Request", response = ErrorBean.class),
		@ApiResponse(code = 404, message = "Not found", response = ErrorBean.class),
		@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/credit/employeeportal/beneficiary/{accHoldertype}/{applicationKey}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> fetchBeneficiary(
			@PathVariable ("accHoldertype") @NotNull(message = "accHoldertype can not be null or empty") @Digits(fraction = 0, integer = 5,message = "accHoldertype should be numeric & should not exceeds size") Long accHoldertype,	
			@PathVariable ("applicationKey") @NotNull(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") Long applicationKey,
			@RequestHeader HttpHeaders headers){
		BeneficiaryResponseBean beneficiaryResp = new BeneficiaryResponseBean();
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "INside fetchBeneficiary");
		beneficiaryResp.setAppDisbAcct(employeePortalTranchCtaService.fetchBeneficiary(accHoldertype,applicationKey,headers));
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Completed fetchBeneficiary");
		return new ResponseEntity<>(beneficiaryResp, HttpStatus.OK);
	}
	
}
