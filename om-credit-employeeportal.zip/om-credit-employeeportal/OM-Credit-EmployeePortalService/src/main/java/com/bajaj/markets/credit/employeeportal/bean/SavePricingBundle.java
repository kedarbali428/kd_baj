package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties
public class SavePricingBundle {
	// PUT /v1/applications/{applicationid}/pricing/calculations when to call.
	// PUT /v1/application/{applicationKey}/pricing save pricing /update pricing.

	private List<PricingDetail> pricingBundle ;
	private Nominee nominee;
	private ApplicationAttributeBean attributeBean;
	private ApplicationDetail applicationDetail;
	private AppPlanDetCostBean appPlanDetCostBean;
	 private QuestionAnswerWrapperBean questionAnswerWrapperBean;

	public AppPlanDetCostBean getAppPlanDetCostBean() {
		return appPlanDetCostBean;
	}

	public void setAppPlanDetCostBean(AppPlanDetCostBean appPlanDetCostBean) {
		this.appPlanDetCostBean = appPlanDetCostBean;
	}

	public QuestionAnswerWrapperBean getQuestionAnswerWrapperBean() {
		return questionAnswerWrapperBean;
	}

	public void setQuestionAnswerWrapperBean(QuestionAnswerWrapperBean questionAnswerWrapperBean) {
		this.questionAnswerWrapperBean = questionAnswerWrapperBean;
	}

	public List<PricingDetail> getPricingBundle() {
		return pricingBundle;
	}

	public void setPricingBundle(List<PricingDetail> pricingBundle) {
		this.pricingBundle = pricingBundle;
	}

	public Nominee getNominee() {
		return nominee;
	}

	public void setNominee(Nominee nominee) {
		this.nominee = nominee;
	}

	public ApplicationAttributeBean getAttributeBean() {
		return attributeBean;
	}

	public void setAttributeBean(ApplicationAttributeBean attributeBean) {
		this.attributeBean = attributeBean;
	}

	public ApplicationDetail getApplicationDetail() {
		return applicationDetail;
	}

	public void setApplicationDetail(ApplicationDetail applicationDetail) {
		this.applicationDetail = applicationDetail;
	}
}
