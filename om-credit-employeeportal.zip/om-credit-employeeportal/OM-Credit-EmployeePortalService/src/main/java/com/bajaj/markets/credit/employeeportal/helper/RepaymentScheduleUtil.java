package com.bajaj.markets.credit.employeeportal.helper;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.employeeportal.util.RepaymentScheduleServiceConstants;

@Configuration
@Component
public class RepaymentScheduleUtil {

	/**
	 * Constant for THIS_CLASS.
	 */
	private static final String THIS_CLASS = RepaymentScheduleUtil.class.getCanonicalName();
	private static final String RS_003 = "RS-003";

	@Autowired
	Environment env;

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Value("${pennantCode}")
	private String pennantCode;

	public static String getMonthName(int monthNumber) { 
		return Month.of(monthNumber).name();
	}

	public static Timestamp getCurrentTimestamp() {
		Date date = Calendar.getInstance().getTime();
		return new Timestamp(date.getTime());
	}


	public String getCurrentTimestampforPennant(String pennantSystemDate) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");//Format of the Due Date received from BRE
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");//Format of the Date to be sent to the Pennant
		Date date = null;
		try {
			date = sdf.parse(pennantSystemDate);
		} catch (ParseException e) {
			logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error in parsing the Pennant Date " + e);
		}
		return df.format(date);
	}

	public static String calculateMargin(float roi, float baseRateValue) {

		float margin = roi - baseRateValue;

		return Float.toString(margin);

	}

	public static String getLoanStartDate(Date date) {

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

		String reportDate = df.format(date);

		return reportDate+RepaymentScheduleServiceConstants.DATE_FORMAT.getValue();



	}

	/**
	 * @Desc This method is used to get yesterdays date
	 * @return Date
	 */
	public static List<String> getEMIMonths(int month) {
		List<String> monthList = new ArrayList<>();
		for(int monthIndex = 0; monthIndex < month; monthIndex++){
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH, 7);//To get EMI Holiday Months 6 months later from the current Month
			cal.add(Calendar.MONTH, monthIndex);
			monthList.add(new SimpleDateFormat("MMMM").format(cal.getTime()));				

		}
		return monthList;
	}

	/**
	 * @Desc This method is used to get emi Holiday default month
	 * @return String
	 */
	public static String getEMIMonthString() {
		String month;

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 7);//To get default EMI Holiday Month which is 6 months later from the current Month
		month = new SimpleDateFormat("MMMM").format(cal.getTime());				

		return month;
	}

	public static String getEMIMonthNumber() {
		String month;

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 7);//To get default EMI Holiday Month which is 6 months later from the current Month
		month = new SimpleDateFormat("MM").format(cal.getTime());				
		Integer emiMonth = Integer.parseInt(month);
		return emiMonth.toString();
	}

	public static String convertPaiseToRs(String value){
		BigDecimal amount = new BigDecimal(value);
		int quotient = amount.intValue();
		BigDecimal bigDecquotient = new BigDecimal(quotient);
		return bigDecquotient.toString();
	}
}
