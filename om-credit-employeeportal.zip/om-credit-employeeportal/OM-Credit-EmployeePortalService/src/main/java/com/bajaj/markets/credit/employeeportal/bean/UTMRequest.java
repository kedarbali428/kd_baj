package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class UTMRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	private String utmsource;
	private String utmmedium;
	private String utmcontent;
	private String utmterm;
	private String utmCampaign;
	
	public String getUtmsource() {
		return utmsource;
	}
	public void setUtmsource(String utmsource) {
		this.utmsource = utmsource;
	}
	public String getUtmmedium() {
		return utmmedium;
	}
	public void setUtmmedium(String utmmedium) {
		this.utmmedium = utmmedium;
	}
	public String getUtmcontent() {
		return utmcontent;
	}
	public void setUtmcontent(String utmcontent) {
		this.utmcontent = utmcontent;
	}
	public String getUtmterm() {
		return utmterm;
	}
	public void setUtmterm(String utmterm) {
		this.utmterm = utmterm;
	}
	public String getUtmCampaign() {
		return utmCampaign;
	}
	public void setUtmCampaign(String utmCampaign) {
		this.utmCampaign = utmCampaign;
	}
	
}
