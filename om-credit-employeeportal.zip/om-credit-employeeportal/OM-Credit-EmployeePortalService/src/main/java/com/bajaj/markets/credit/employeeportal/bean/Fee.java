package com.bajaj.markets.credit.employeeportal.bean;

public class Fee {

	private String feeCode;
	private String feeAmount;
	private String waiverAmount;
	private String paidAmount;
	private String feeMethod;
	private String scheduleTerms;
	private String feeBalance;

	public String getFeeMethod() {
		return feeMethod;
	}

	public void setFeeMethod(String feeMethod) {
		this.feeMethod = feeMethod;
	}

	public String getScheduleTerms() {
		return scheduleTerms;
	}

	public void setScheduleTerms(String scheduleTerms) {
		this.scheduleTerms = scheduleTerms;
	}

	public String getFeeBalance() {
		return feeBalance;
	}

	public void setFeeBalance(String feeBalance) {
		this.feeBalance = feeBalance;
	}

	public String getFeeCode() {
		return feeCode;
	}

	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}

	public String getFeeAmount() {
		return feeAmount;
	}

	public void setFeeAmount(String feeAmount) {
		this.feeAmount = feeAmount;
	}

	public String getWaiverAmount() {
		return waiverAmount;
	}

	public void setWaiverAmount(String waiverAmount) {
		this.waiverAmount = waiverAmount;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

}
