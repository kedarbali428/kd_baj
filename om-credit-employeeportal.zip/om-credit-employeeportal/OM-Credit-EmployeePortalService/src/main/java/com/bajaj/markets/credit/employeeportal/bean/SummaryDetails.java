package com.bajaj.markets.credit.employeeportal.bean;

public class SummaryDetails {

	private Long applicationId;
	private String firstName;
	private String lastName;
	private String owner;
	private String role;
	private Integer percentage;
	private String subStage;
	private String l2Product;
	private String l2productCode;
	private String occupation;
	private String productVarient;
	private Long childApplication;
	private String applicantId;
	private Boolean loggedInUserIsOwner;
	private String occupationCode;
	private String hlproductintent;
	
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Integer getPercentage() {
		return percentage;
	}
	public void setPercentage(Integer percentage) {
		this.percentage = percentage;
	}
	public String getSubStage() {
		return subStage;
	}
	public void setSubStage(String subStage) {
		this.subStage = subStage;
	}
	public String getL2Product() {
		return l2Product;
	}
	public void setL2Product(String l2Product) {
		this.l2Product = l2Product;
	}
	public String getL2productCode() {
		return l2productCode;
	}
	public void setL2productCode(String l2productCode) {
		this.l2productCode = l2productCode;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getProductVarient() {
		return productVarient;
	}
	public void setProductVarient(String productVarient) {
		this.productVarient = productVarient;
	}
	public Long getChildApplication() {
		return childApplication;
	}
	public void setChildApplication(Long childApplication) {
		this.childApplication = childApplication;
	}
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	public Boolean getLoggedInUserIsOwner() {
		return loggedInUserIsOwner;
	}
	public void setLoggedInUserIsOwner(Boolean loggedInUserIsOwner) {
		this.loggedInUserIsOwner = loggedInUserIsOwner;
	}
	public String getOccupationCode() {
		return occupationCode;
	}
	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}
	public String getHlproductintent() {
		return hlproductintent;
	}
	public void setHlproductintent(String hlproductintent) {
		this.hlproductintent = hlproductintent;
	}
	
}
