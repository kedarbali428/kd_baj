package com.bajaj.markets.credit.employeeportal.bean;

public class CreditReviewStatusBean {

	private String individualCoapplicantRequired;
	private String entityCoapplicantRequired;
	
	public String getIndividualCoapplicantRequired() {
		return individualCoapplicantRequired;
	}
	public void setIndividualCoapplicantRequired(String individualCoapplicantRequired) {
		this.individualCoapplicantRequired = individualCoapplicantRequired;
	}
	public String getEntityCoapplicantRequired() {
		return entityCoapplicantRequired;
	}
	public void setEntityCoapplicantRequired(String entityCoapplicantRequired) {
		this.entityCoapplicantRequired = entityCoapplicantRequired;
	}
}
