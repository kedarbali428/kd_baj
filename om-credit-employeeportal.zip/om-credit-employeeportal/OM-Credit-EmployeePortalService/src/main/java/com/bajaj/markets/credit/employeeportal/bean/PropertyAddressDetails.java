package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class PropertyAddressDetails implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String propertyCity;
	private String propertyState;
	private String propertyPinCode;
	private String propertyAddressLine3;
	private String propertyAddressLine2;
	private String propertyAddressLine1;
	private String propertyAreaLocality;
	
	public String getPropertyCity() {
		return propertyCity;
	}
	public void setPropertyCity(String propertyCity) {
		this.propertyCity = propertyCity;
	}
	public String getPropertyState() {
		return propertyState;
	}
	public void setPropertyState(String propertyState) {
		this.propertyState = propertyState;
	}
	public String getPropertyPinCode() {
		return propertyPinCode;
	}
	public void setPropertyPinCode(String propertyPinCode) {
		this.propertyPinCode = propertyPinCode;
	}
	public String getPropertyAddressLine3() {
		return propertyAddressLine3;
	}
	public void setPropertyAddressLine3(String propertyAddressLine3) {
		this.propertyAddressLine3 = propertyAddressLine3;
	}
	public String getPropertyAddressLine2() {
		return propertyAddressLine2;
	}
	public void setPropertyAddressLine2(String propertyAddressLine2) {
		this.propertyAddressLine2 = propertyAddressLine2;
	}
	public String getPropertyAddressLine1() {
		return propertyAddressLine1;
	}
	public void setPropertyAddressLine1(String propertyAddressLine1) {
		this.propertyAddressLine1 = propertyAddressLine1;
	}
	public String getPropertyAreaLocality() {
		return propertyAreaLocality;
	}
	public void setPropertyAreaLocality(String propertyAreaLocality) {
		this.propertyAreaLocality = propertyAreaLocality;
	}
	
}
