package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "app_bundle", schema = "dmcredit")
public class AppBundle implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Long appbundlekey;

	private Long applicationkey;

	private Long apploanpricingkey;

	private Long bundleapplicationkey;

	private Integer bundleplankey;

	private Integer bundlerevision;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private String source;

	public AppBundle() {
	}

	public Long getAppbundlekey() {
		return appbundlekey;
	}

	public void setAppbundlekey(Long appbundlekey) {
		this.appbundlekey = appbundlekey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Long getApploanpricingkey() {
		return apploanpricingkey;
	}

	public void setApploanpricingkey(Long apploanpricingkey) {
		this.apploanpricingkey = apploanpricingkey;
	}

	public Long getBundleapplicationkey() {
		return bundleapplicationkey;
	}

	public void setBundleapplicationkey(Long bundleapplicationkey) {
		this.bundleapplicationkey = bundleapplicationkey;
	}

	public Integer getBundleplankey() {
		return bundleplankey;
	}

	public void setBundleplankey(Integer bundleplankey) {
		this.bundleplankey = bundleplankey;
	}

	public Integer getBundlerevision() {
		return bundlerevision;
	}

	public void setBundlerevision(Integer bundlerevision) {
		this.bundlerevision = bundlerevision;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
}
