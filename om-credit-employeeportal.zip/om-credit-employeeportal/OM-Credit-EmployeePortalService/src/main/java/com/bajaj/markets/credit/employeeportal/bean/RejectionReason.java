package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class RejectionReason implements Serializable {

	private static final long serialVersionUID = 1L;

	private Timestamp rejectionDate;
	private String rejecode;
	private String rejectcodedesc;
	private String rejectedbyuserkey;

	public Timestamp getRejectionDate() {
		return rejectionDate;
	}

	public void setRejectionDate(Timestamp rejectionDate) {
		this.rejectionDate = rejectionDate;
	}

	public String getRejecode() {
		return rejecode;
	}

	public void setRejecode(String rejecode) {
		this.rejecode = rejecode;
	}

	public String getRejectcodedesc() {
		return rejectcodedesc;
	}

	public void setRejectcodedesc(String rejectcodedesc) {
		this.rejectcodedesc = rejectcodedesc;
	}

	public String getRejectedbyuserkey() {
		return rejectedbyuserkey;
	}

	public void setRejectedbyuserkey(String rejectedbyuserkey) {
		this.rejectedbyuserkey = rejectedbyuserkey;
	}

}
