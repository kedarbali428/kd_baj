package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class CreditStatusDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String creditEligibilityStatus;
	private String creditDisbursementStatus;
	private String creditEligibilityStatusAddedBy;
	private Timestamp creditEligibilityStatusDateTime;
	private String creditDisbursementStatusAddedBy;
	private Timestamp creditDisbursementStatusDateTime;

	public String getCreditEligibilityStatus() {
		return creditEligibilityStatus;
	}

	public void setCreditEligibilityStatus(String creditEligibilityStatus) {
		this.creditEligibilityStatus = creditEligibilityStatus;
	}

	public String getCreditDisbursementStatus() {
		return creditDisbursementStatus;
	}

	public void setCreditDisbursementStatus(String creditDisbursementStatus) {
		this.creditDisbursementStatus = creditDisbursementStatus;
	}

	public String getCreditEligibilityStatusAddedBy() {
		return creditEligibilityStatusAddedBy;
	}

	public void setCreditEligibilityStatusAddedBy(String creditEligibilityStatusAddedBy) {
		this.creditEligibilityStatusAddedBy = creditEligibilityStatusAddedBy;
	}

	public Timestamp getCreditEligibilityStatusDateTime() {
		return creditEligibilityStatusDateTime;
	}

	public void setCreditEligibilityStatusDateTime(Timestamp creditEligibilityStatusDateTime) {
		this.creditEligibilityStatusDateTime = creditEligibilityStatusDateTime;
	}

	public String getCreditDisbursementStatusAddedBy() {
		return creditDisbursementStatusAddedBy;
	}

	public void setCreditDisbursementStatusAddedBy(String creditDisbursementStatusAddedBy) {
		this.creditDisbursementStatusAddedBy = creditDisbursementStatusAddedBy;
	}

	public Timestamp getCreditDisbursementStatusDateTime() {
		return creditDisbursementStatusDateTime;
	}

	public void setCreditDisbursementStatusDateTime(Timestamp creditDisbursementStatusDateTime) {
		this.creditDisbursementStatusDateTime = creditDisbursementStatusDateTime;
	}

}
