package com.bajaj.markets.credit.employeeportal.bean;

import java.sql.Timestamp;

public class UserRolePincodeBean {

	private Long userpincodekey;
	private Long userprodkey;
	private Long pincodekey;
	private Long isactive;
	private String lstupdateby;
	private Timestamp lstupdatedt;
	
	public Long getUserpincodekey() {
		return userpincodekey;
	}
	public void setUserpincodekey(Long userpincodekey) {
		this.userpincodekey = userpincodekey;
	}
	public Long getUserprodkey() {
		return userprodkey;
	}
	public void setUserprodkey(Long userprodkey) {
		this.userprodkey = userprodkey;
	}
	public Long getPincodekey() {
		return pincodekey;
	}
	public void setPincodekey(Long pincodekey) {
		this.pincodekey = pincodekey;
	}
	public Long getIsactive() {
		return isactive;
	}
	public void setIsactive(Long isactive) {
		this.isactive = isactive;
	}
	public String getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
}
