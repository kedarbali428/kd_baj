package com.bajaj.markets.credit.employeeportal.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.EsignInfoResponse;
import com.bajaj.markets.credit.employeeportal.bean.EsignRequest;
import com.bajaj.markets.credit.employeeportal.bean.EsignResponse;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalEsignService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EmployeePortalEsignController {

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private EmployeePortalEsignService employeePortalEsignService;
	
	private static final String CLASS_NAME = EmployeePortalEsignController.class.getCanonicalName();
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Create or update consolidated Esign doc into dms and stamp in db ", notes = "Create or update consolidated Esign doc into dms and stamp in db", httpMethod = "PUT")
	@ApiImplicitParams({ 
		@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header")
	  })
	@ApiResponses(value = {
					@ApiResponse(code = 200, message = "Esign created Successfully", response = EsignResponse.class),
					@ApiResponse(code = 404, message = "Error in esign document generation ",response = ErrorBean.class),
					@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
					@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
    @PutMapping(path = "/v1/credit/employeeportal/{applicationKey}/esign", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateEsignDocument(@PathVariable("applicationKey")  @NotNull(message = "applicationKey can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") String  applicationKey ,
			@Valid @RequestBody EsignRequest esignRequest,@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside updateEmandate method controller for mandate reference Id :" + applicationKey);
		return new ResponseEntity<>(employeePortalEsignService.updateEsignDocument(applicationKey,esignRequest,headers), HttpStatus.OK);
	}
	
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Update Esign Info", notes = "Update Esign Info", httpMethod = "PUT")
	@ApiImplicitParams({ 
		@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header")
	  })
	@ApiResponses(value = {
					@ApiResponse(code = 200, message = "Esign updated Successfully", response = EsignInfoResponse.class),
					@ApiResponse(code = 404, message = "Esign record not found for ApplicationKey",response = ErrorBean.class),
					@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
					@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
    @PutMapping(path = "/v1/credit/employeeportal/applications/{applicationid}/esign", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> updateEsignInfo(@PathVariable("applicationid")@NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20,message = "applicationKey should be numeric & should not exceeds size") String  applicationKey ,
			@RequestParam(value = "ctaCode", required = false) String ctaCode,@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside updateEsignInfo method controller for Id :" + applicationKey);
		return new ResponseEntity<>(employeePortalEsignService.updateEsignInfo(applicationKey,ctaCode,headers), HttpStatus.OK);
	}
}
