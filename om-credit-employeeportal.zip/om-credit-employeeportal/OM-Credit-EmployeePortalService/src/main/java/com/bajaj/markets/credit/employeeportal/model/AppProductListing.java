package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the app_product_listing database table.
 * 
 */
@Entity
@Table(name = "app_product_listing", schema = "dmcredit")
public class AppProductListing implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_product_listingkey_generator", sequenceName = "dmcredit.seq_pk_app_product_listing", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_product_listingkey_generator")
	private Long appprodlistkey;

	private BigDecimal annualfee;

	private Long applicationkey;

	private String feature;

	private Integer isactive;

	private Long lstupdateby;

	private BigDecimal iseligible;

	private Timestamp lstupdatedt;

	private Long prodkey;

	private String promotionaloffer;

	private String rewardpoint;

	private Integer priorityorder;

	private String cardtag;

	private String approvalchance;

	private Integer preapproved;

	private Long prodtypekey;

	private Integer tenure;

	private String fppapplicable;

	private Long bscore;

	private String pennantloantyperecommendation;

	private Integer requiredloanamount;

	private String pefiosrequiredflag;

	private String riskoffertype;

	private String eligibilitytype;

	public AppProductListing() {
	}

	public Long getAppprodlistkey() {
		return this.appprodlistkey;
	}

	public void setAppprodlistkey(Long appprodlistkey) {
		this.appprodlistkey = appprodlistkey;
	}

	public BigDecimal getAnnualfee() {
		return this.annualfee;
	}

	public void setAnnualfee(BigDecimal annualfee) {
		this.annualfee = annualfee;
	}

	public Long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public String getFeature() {
		return this.feature;
	}

	public void setFeature(String feature) {
		this.feature = feature;
	}

	public Integer getIsactive() {
		return this.isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getProdkey() {
		return this.prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getPromotionaloffer() {
		return this.promotionaloffer;
	}

	public void setPromotionaloffer(String promotionaloffer) {
		this.promotionaloffer = promotionaloffer;
	}

	public String getRewardpoint() {
		return this.rewardpoint;
	}

	public void setRewardpoint(String rewardPoint) {
		this.rewardpoint = rewardPoint;
	}

	public BigDecimal getIseligible() {
		return iseligible;
	}

	public void setIseligible(BigDecimal iseligible) {
		this.iseligible = iseligible;
	}

	public Integer getPriorityorder() {
		return priorityorder;
	}

	public void setPriorityorder(Integer priorityorder) {
		this.priorityorder = priorityorder;
	}

	public String getCardtag() {
		return cardtag;
	}

	public void setCardtag(String cardtag) {
		this.cardtag = cardtag;
	}

	public String getApprovalchance() {
		return approvalchance;
	}

	public void setApprovalchance(String approvalchance) {
		this.approvalchance = approvalchance;
	}

	public Integer getPreapproved() {
		return preapproved;
	}

	public void setPreapproved(Integer preapproved) {
		this.preapproved = preapproved;
	}

	public Long getProdtypekey() {
		return prodtypekey;
	}

	public void setProdtypekey(Long prodtypekey) {
		this.prodtypekey = prodtypekey;
	}

	public Integer getTenure() {
		return tenure;
	}

	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}

	public String getFppapplicable() {
		return fppapplicable;
	}

	public void setFppapplicable(String fppapplicable) {
		this.fppapplicable = fppapplicable;
	}

	public Long getBscore() {
		return bscore;
	}

	public void setBscore(Long bscore) {
		this.bscore = bscore;
	}

	public String getPennantloantyperecommendation() {
		return pennantloantyperecommendation;
	}

	public void setPennantloantyperecommendation(String pennantloantyperecommendation) {
		this.pennantloantyperecommendation = pennantloantyperecommendation;
	}

	public Integer getRequiredloanamount() {
		return requiredloanamount;
	}

	public void setRequiredloanamount(Integer requiredloanamount) {
		this.requiredloanamount = requiredloanamount;
	}

	public String getPefiosrequiredflag() {
		return pefiosrequiredflag;
	}

	public void setPefiosrequiredflag(String pefiosrequiredflag) {
		this.pefiosrequiredflag = pefiosrequiredflag;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}

	public String getEligibilitytype() {
		return eligibilitytype;
	}

	public void setEligibilitytype(String eligibilitytype) {
		this.eligibilitytype = eligibilitytype;
	}

}