package com.bajaj.markets.credit.employeeportal.bean;

public class LocationAddressBean {

	private String city;
	private Long cityId;
	private String state;
	private Long stateId;
	private String stateShortName;
	private String pinCode;
	private Long pinId;
	private String country;
	private Long countryId;
	private String formattedAddress;
	private Integer pinNegativeAreaFlg;
	private Integer pinOglFlg;
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Long getCityId() {
		return cityId;
	}

	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public String getStateShortName() {
		return stateShortName;
	}

	public void setStateShortName(String stateShortName) {
		this.stateShortName = stateShortName;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public Long getPinId() {
		return pinId;
	}

	public void setPinId(Long pinId) {
		this.pinId = pinId;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getFormattedAddress() {
		return formattedAddress;
	}

	public void setFormattedAddress(String formattedAddress) {
		this.formattedAddress = formattedAddress;
	}

	public Integer getPinNegativeAreaFlg() {
		return pinNegativeAreaFlg;
	}

	public void setPinNegativeAreaFlg(Integer pinNegativeAreaFlg) {
		this.pinNegativeAreaFlg = pinNegativeAreaFlg;
	}

	public Integer getPinOglFlg() {
		return pinOglFlg;
	}

	public void setPinOglFlg(Integer pinOglFlg) {
		this.pinOglFlg = pinOglFlg;
	}

	@Override
	public String toString() {
		return "LocationAddressBean [city=" + city + ", cityId=" + cityId + ", state=" + state + ", stateId=" + stateId
				+ ", stateShortName=" + stateShortName + ", pinCode=" + pinCode + ", pinId=" + pinId + ", country="
				+ country + ", countryId=" + countryId + ", formattedAddress=" + formattedAddress
				+ ", pinNegativeAreaFlg=" + pinNegativeAreaFlg + ", pinOglFlg=" + pinOglFlg + "]";
	}

}
