package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class DedupeDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String dedupeMatch;
	private String principalName;
	private String dedupeSource;
	private String dedupeCustType;
	private String dedupeCustSegment;
	private String existingCustomerId;
	private String existingCustomerIdFinnone;
	private String dedupeStatus;
	private String bflExistingCustomerFlag;
	private String bmrApprovedFlag;
	private String bmrWIPFlag;
	private String bmrTwoApprovedFlag;
	private String bmrRejectFlag;
	private String bmrOneApprovedFlag;
	private String bmrFraudFlag;
	private String bmrTwoDisbursementFlag;
	private String bmrTwoBadFlag;
	private String bmrTwoRejectFlag;
	private String livePOS;
	private String edwstatus;
	private String bmrOneFraudReason;
	
	public String getDedupeMatch() {
		return dedupeMatch;
	}

	public void setDedupeMatch(String dedupeMatch) {
		this.dedupeMatch = dedupeMatch;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getDedupeSource() {
		return dedupeSource;
	}

	public void setDedupeSource(String dedupeSource) {
		this.dedupeSource = dedupeSource;
	}

	public String getDedupeCustType() {
		return dedupeCustType;
	}

	public void setDedupeCustType(String dedupeCustType) {
		this.dedupeCustType = dedupeCustType;
	}

	public String getDedupeCustSegment() {
		return dedupeCustSegment;
	}

	public void setDedupeCustSegment(String dedupeCustSegment) {
		this.dedupeCustSegment = dedupeCustSegment;
	}

	public String getExistingCustomerId() {
		return existingCustomerId;
	}

	public void setExistingCustomerId(String existingCustomerId) {
		this.existingCustomerId = existingCustomerId;
	}

	/**
	 * @return the existingCustomerIdFinnone
	 */
	public String getExistingCustomerIdFinnone() {
		return existingCustomerIdFinnone;
	}

	/**
	 * @param existingCustomerIdFinnone the existingCustomerIdFinnone to set
	 */
	public void setExistingCustomerIdFinnone(String existingCustomerIdFinnone) {
		this.existingCustomerIdFinnone = existingCustomerIdFinnone;
	}

	/**
	 * @return the dedupeStatus
	 */
	public String getDedupeStatus() {
		return dedupeStatus;
	}

	/**
	 * @param dedupeStatus the dedupeStatus to set
	 */
	public void setDedupeStatus(String dedupeStatus) {
		this.dedupeStatus = dedupeStatus;
	}

	public String getBflExistingCustomerFlag() {
		return bflExistingCustomerFlag;
	}

	public void setBflExistingCustomerFlag(String bflExistingCustomerFlag) {
		this.bflExistingCustomerFlag = bflExistingCustomerFlag;
	}

	public String getBmrApprovedFlag() {
		return bmrApprovedFlag;
	}

	public void setBmrApprovedFlag(String bmrApprovedFlag) {
		this.bmrApprovedFlag = bmrApprovedFlag;
	}

	public String getBmrWIPFlag() {
		return bmrWIPFlag;
	}

	public void setBmrWIPFlag(String bmrWIPFlag) {
		this.bmrWIPFlag = bmrWIPFlag;
	}

	public String getBmrTwoApprovedFlag() {
		return bmrTwoApprovedFlag;
	}

	public void setBmrTwoApprovedFlag(String bmrTwoApprovedFlag) {
		this.bmrTwoApprovedFlag = bmrTwoApprovedFlag;
	}

	public String getBmrRejectFlag() {
		return bmrRejectFlag;
	}

	public void setBmrRejectFlag(String bmrRejectFlag) {
		this.bmrRejectFlag = bmrRejectFlag;
	}

	public String getBmrOneApprovedFlag() {
		return bmrOneApprovedFlag;
	}

	public void setBmrOneApprovedFlag(String bmrOneApprovedFlag) {
		this.bmrOneApprovedFlag = bmrOneApprovedFlag;
	}

	public String getBmrFraudFlag() {
		return bmrFraudFlag;
	}

	public void setBmrFraudFlag(String bmrFraudFlag) {
		this.bmrFraudFlag = bmrFraudFlag;
	}

	public String getBmrTwoDisbursementFlag() {
		return bmrTwoDisbursementFlag;
	}

	public void setBmrTwoDisbursementFlag(String bmrTwoDisbursementFlag) {
		this.bmrTwoDisbursementFlag = bmrTwoDisbursementFlag;
	}

	public String getBmrTwoBadFlag() {
		return bmrTwoBadFlag;
	}

	public void setBmrTwoBadFlag(String bmrTwoBadFlag) {
		this.bmrTwoBadFlag = bmrTwoBadFlag;
	}

	public String getBmrTwoRejectFlag() {
		return bmrTwoRejectFlag;
	}

	public void setBmrTwoRejectFlag(String bmrTwoRejectFlag) {
		this.bmrTwoRejectFlag = bmrTwoRejectFlag;
	}

	public String getLivePOS() {
		return livePOS;
	}

	public void setLivePOS(String livePOS) {
		this.livePOS = livePOS;
	}

	public String getEdwstatus() {
		return edwstatus;
	}

	public void setEdwstatus(String edwstatus) {
		this.edwstatus = edwstatus;
	}

	public String getBmrOneFraudReason() {
		return bmrOneFraudReason;
	}

	public void setBmrOneFraudReason(String bmrOneFraudReason) {
		this.bmrOneFraudReason = bmrOneFraudReason;
	}
	
}
