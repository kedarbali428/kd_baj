package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

public class AppUdfVerificationRequest {

	@NotNull
	@Digits(fraction = 0, integer = 5)
	private long udfflagkey;
	@Digits(fraction = 0, integer = 10)
	private long userrolekey;
	@NotNull
	@Digits(fraction = 0, integer = 5)
	private BigDecimal flagstatus;

	public long getUdfflagkey() {
		return udfflagkey;
	}
	public void setUdfflagkey(long udfflagkey) {
		this.udfflagkey = udfflagkey;
	}
	public long getUserrolekey() {
		return userrolekey;
	}
	public void setUserrolekey(long userrolekey) {
		this.userrolekey = userrolekey;
	}
	public BigDecimal getFlagstatus() {
		return flagstatus;
	}
	public void setFlagstatus(BigDecimal flagstatus) {
		this.flagstatus = flagstatus;
	}
}
