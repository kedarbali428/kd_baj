package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CoApplicantCibilEmailDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String coapplicantName;
	private String coapplicantPan;
	private String coapplicantCibilEmailId;

	public String getCoapplicantName() {
		return coapplicantName;
	}

	public void setCoapplicantName(String coapplicantName) {
		this.coapplicantName = coapplicantName;
	}

	public String getCoapplicantPan() {
		return coapplicantPan;
	}

	public void setCoapplicantPan(String coapplicantPan) {
		this.coapplicantPan = coapplicantPan;
	}

	public String getCoapplicantCibilEmailId() {
		return coapplicantCibilEmailId;
	}

	public void setCoapplicantCibilEmailId(String coapplicantCibilEmailId) {
		this.coapplicantCibilEmailId = coapplicantCibilEmailId;
	}

}