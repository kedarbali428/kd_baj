package com.bajaj.markets.credit.employeeportal.bean;

public class FinalMandateResponse {

	private Long appattrbKey;

	private Long finalMandateKey;
	
	private String message;
	
	private String status;

	public Long getAppattrbKey() {
		return appattrbKey;
	}

	public void setAppattrbKey(Long appattrbKey) {
		this.appattrbKey = appattrbKey;
	}

	public Long getFinalMandateKey() {
		return finalMandateKey;
	}

	public void setFinalMandateKey(Long finalMandateKey) {
		this.finalMandateKey = finalMandateKey;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
