package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CoApplicantGeneralDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String coapplicantName;
	private String coapplicantPan;
	private String coApplicantBureauName;
	private String coApplicantCIBILScoreV1;
	private String coApplicantCIBILScoreV3;
	private String coApplicantCIBILDate;
	private String coApplicantCIBILTimestamp;
	private String coApplicantCIBILAdditionalMatchFlag;
	private String coApplicantTotalEnquiries;
	private String coApplicantTotalLoans;
	private String coApplicantEntity;
	private String coApplicantCIBILErrorCode;

	public String getCoapplicantName() {
		return coapplicantName;
	}

	public void setCoapplicantName(String coapplicantName) {
		this.coapplicantName = coapplicantName;
	}

	public String getCoapplicantPan() {
		return coapplicantPan;
	}

	public void setCoapplicantPan(String coapplicantPan) {
		this.coapplicantPan = coapplicantPan;
	}

	public String getCoApplicantBureauName() {
		return coApplicantBureauName;
	}

	public void setCoApplicantBureauName(String coApplicantBureauName) {
		this.coApplicantBureauName = coApplicantBureauName;
	}

	public String getCoApplicantCIBILScoreV1() {
		return coApplicantCIBILScoreV1;
	}

	public void setCoApplicantCIBILScoreV1(String coApplicantCIBILScoreV1) {
		this.coApplicantCIBILScoreV1 = coApplicantCIBILScoreV1;
	}

	public String getCoApplicantCIBILScoreV3() {
		return coApplicantCIBILScoreV3;
	}

	public void setCoApplicantCIBILScoreV3(String coApplicantCIBILScoreV3) {
		this.coApplicantCIBILScoreV3 = coApplicantCIBILScoreV3;
	}

	public String getCoApplicantCIBILDate() {
		return coApplicantCIBILDate;
	}

	public void setCoApplicantCIBILDate(String coApplicantCIBILDate) {
		this.coApplicantCIBILDate = coApplicantCIBILDate;
	}

	public String getCoApplicantCIBILTimestamp() {
		return coApplicantCIBILTimestamp;
	}

	public void setCoApplicantCIBILTimestamp(String coApplicantCIBILTimestamp) {
		this.coApplicantCIBILTimestamp = coApplicantCIBILTimestamp;
	}

	public String getCoApplicantCIBILAdditionalMatchFlag() {
		return coApplicantCIBILAdditionalMatchFlag;
	}

	public void setCoApplicantCIBILAdditionalMatchFlag(String coApplicantCIBILAdditionalMatchFlag) {
		this.coApplicantCIBILAdditionalMatchFlag = coApplicantCIBILAdditionalMatchFlag;
	}

	public String getCoApplicantTotalEnquiries() {
		return coApplicantTotalEnquiries;
	}

	public void setCoApplicantTotalEnquiries(String coApplicantTotalEnquiries) {
		this.coApplicantTotalEnquiries = coApplicantTotalEnquiries;
	}

	public String getCoApplicantTotalLoans() {
		return coApplicantTotalLoans;
	}

	public void setCoApplicantTotalLoans(String coApplicantTotalLoans) {
		this.coApplicantTotalLoans = coApplicantTotalLoans;
	}

	public String getCoApplicantEntity() {
		return coApplicantEntity;
	}

	public void setCoApplicantEntity(String coApplicantEntity) {
		this.coApplicantEntity = coApplicantEntity;
	}

	public String getCoApplicantCIBILErrorCode() {
		return coApplicantCIBILErrorCode;
	}

	public void setCoApplicantCIBILErrorCode(String coApplicantCIBILErrorCode) {
		this.coApplicantCIBILErrorCode = coApplicantCIBILErrorCode;
	}

}