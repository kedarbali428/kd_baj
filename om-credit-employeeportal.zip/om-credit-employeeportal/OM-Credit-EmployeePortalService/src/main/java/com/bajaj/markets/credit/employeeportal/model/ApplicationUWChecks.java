package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "application_uwchecks", schema = "dmcredit")
public class ApplicationUWChecks implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "application_uwchecks_appluwchkkey_generator", sequenceName = "dmcredit.seq_application_uwchecks", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_uwchecks_appluwchkkey_generator")
	private Long appluwchkkey;
	private Long applicationkey;
	private String uwcheckcode;
	private String uwcheckdesc;
	private String applicationvalue;
	private String verificationvalue;
	private Long matchpercentage;
	private Long matchflag;
	private String uwcheckstatus;
	private String uwcheckcomments;
	private Timestamp uwcheckdatetime;
	private String uwcheckby;
	private String createdby;
	private Timestamp createdtimestamp;
	private String modifiedby;
	private Timestamp modifiedtimestamp;
	private Integer isactive;
	private Long lstupdateby;
	private Timestamp lstupdatedt;

	public Long getAppluwchkkey() {
		return appluwchkkey;
	}

	public void setAppluwchkkey(Long appluwchkkey) {
		this.appluwchkkey = appluwchkkey;
	}

	public Long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(Long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public String getUwcheckcode() {
		return uwcheckcode;
	}

	public void setUwcheckcode(String uwcheckcode) {
		this.uwcheckcode = uwcheckcode;
	}

	public String getUwcheckdesc() {
		return uwcheckdesc;
	}

	public void setUwcheckdesc(String uwcheckdesc) {
		this.uwcheckdesc = uwcheckdesc;
	}

	public String getApplicationvalue() {
		return applicationvalue;
	}

	public void setApplicationvalue(String applicationvalue) {
		this.applicationvalue = applicationvalue;
	}

	public String getVerificationvalue() {
		return verificationvalue;
	}

	public void setVerificationvalue(String verificationvalue) {
		this.verificationvalue = verificationvalue;
	}

	public Long getMatchpercentage() {
		return matchpercentage;
	}

	public void setMatchpercentage(Long matchpercentage) {
		this.matchpercentage = matchpercentage;
	}

	public Long getMatchflag() {
		return matchflag;
	}

	public void setMatchflag(Long matchflag) {
		this.matchflag = matchflag;
	}

	public String getUwcheckstatus() {
		return uwcheckstatus;
	}

	public void setUwcheckstatus(String uwcheckstatus) {
		this.uwcheckstatus = uwcheckstatus;
	}

	public String getUwcheckcomments() {
		return uwcheckcomments;
	}

	public void setUwcheckcomments(String uwcheckcomments) {
		this.uwcheckcomments = uwcheckcomments;
	}

	public Timestamp getUwcheckdatetime() {
		return uwcheckdatetime;
	}

	public void setUwcheckdatetime(Timestamp uwcheckdatetime) {
		this.uwcheckdatetime = uwcheckdatetime;
	}

	public String getUwcheckby() {
		return uwcheckby;
	}

	public void setUwcheckby(String uwcheckby) {
		this.uwcheckby = uwcheckby;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public Timestamp getCreatedtimestamp() {
		return createdtimestamp;
	}

	public void setCreatedtimestamp(Timestamp createdtimestamp) {
		this.createdtimestamp = createdtimestamp;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public Timestamp getModifiedtimestamp() {
		return modifiedtimestamp;
	}

	public void setModifiedtimestamp(Timestamp modifiedtimestamp) {
		this.modifiedtimestamp = modifiedtimestamp;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

}