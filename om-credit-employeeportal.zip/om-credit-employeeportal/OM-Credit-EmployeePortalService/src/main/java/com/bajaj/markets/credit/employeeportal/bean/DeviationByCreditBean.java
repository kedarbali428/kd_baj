package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class DeviationByCreditBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String appdeviationcd;
	private String appdeviationdscr;
	private String deviationauthority;
	private Timestamp createdtm;
	private String deviationProduct;
	private String deviationAddedBy;
	private String deviationStatus;

	public String getAppdeviationcd() {
		return appdeviationcd;
	}

	public void setAppdeviationcd(String appdeviationcd) {
		this.appdeviationcd = appdeviationcd;
	}

	public String getAppdeviationdscr() {
		return appdeviationdscr;
	}

	public void setAppdeviationdscr(String appdeviationdscr) {
		this.appdeviationdscr = appdeviationdscr;
	}

	public String getDeviationauthority() {
		return deviationauthority;
	}

	public void setDeviationauthority(String deviationauthority) {
		this.deviationauthority = deviationauthority;
	}

	public Timestamp getCreatedtm() {
		return createdtm;
	}

	public void setCreatedtm(Timestamp createdtm) {
		this.createdtm = createdtm;
	}

	public String getDeviationProduct() {
		return deviationProduct;
	}

	public void setDeviationProduct(String deviationProduct) {
		this.deviationProduct = deviationProduct;
	}

	public String getDeviationAddedBy() {
		return deviationAddedBy;
	}

	public void setDeviationAddedBy(String deviationAddedBy) {
		this.deviationAddedBy = deviationAddedBy;
	}

	public String getDeviationStatus() {
		return deviationStatus;
	}

	public void setDeviationStatus(String deviationStatus) {
		this.deviationStatus = deviationStatus;
	}

}