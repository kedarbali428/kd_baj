package com.bajaj.markets.credit.employeeportal.bean;

public class Benefits {

	private String benefitCode;
	private String benefitName;
	private double perceivedValue;
	private String benefitValue;
	private Integer benefitKey;
	public String getBenefitCode() {
		return benefitCode;
	}
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}
	public String getBenefitName() {
		return benefitName;
	}
	public void setBenefitName(String benefitName) {
		this.benefitName = benefitName;
	}
	public double getPerceivedValue() {
		return perceivedValue;
	}
	public void setPerceivedValue(double perceivedValue) {
		this.perceivedValue = perceivedValue;
	}
	public String getBenefitValue() {
		return benefitValue;
	}
	public void setBenefitValue(String benefitValue) {
		this.benefitValue = benefitValue;
	}
	public Integer getBenefitKey() {
		return benefitKey;
	}
	public void setBenefitKey(Integer benefitKey) {
		this.benefitKey = benefitKey;
	}
	
	
}
