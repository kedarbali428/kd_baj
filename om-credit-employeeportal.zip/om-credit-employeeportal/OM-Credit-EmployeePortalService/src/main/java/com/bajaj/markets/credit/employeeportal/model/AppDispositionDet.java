package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the app_disposition_det database table.
 * 
 */
@Entity
@Table(name="app_disposition_det",schema = "dmcredit")
public class AppDispositionDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="app_disposition_det_appdispdetkey_generator", sequenceName="dmcredit.seq_pk_app_disposition_det",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="app_disposition_det_appdispdetkey_generator")
	private Long appdispdetkey;

	private Long appdisposstskey;

	private String dispositiondesc;
	
	private Integer copslstupdateby;
	
	private Timestamp copslstupdatedt;
	
	private Integer saleslstupdateby;
	
	private Timestamp saleslstupdatedt;

	private Long lstupdateby;

	private Timestamp lstupdatedt;
	
	private Integer isactive;

	public AppDispositionDet() {
	}

	/**
	 * @return the appdispdetkey
	 */
	public Long getAppdispdetkey() {
		return appdispdetkey;
	}

	/**
	 * @param appdispdetkey the appdispdetkey to set
	 */
	public void setAppdispdetkey(Long appdispdetkey) {
		this.appdispdetkey = appdispdetkey;
	}

	/**
	 * @return the appdisposstskey
	 */
	public Long getAppdisposstskey() {
		return appdisposstskey;
	}

	/**
	 * @param appdisposstskey the appdisposstskey to set
	 */
	public void setAppdisposstskey(Long appdisposstskey) {
		this.appdisposstskey = appdisposstskey;
	}

	/**
	 * @return the dispositiondesc
	 */
	public String getDispositiondesc() {
		return dispositiondesc;
	}

	/**
	 * @param dispositiondesc the dispositiondesc to set
	 */
	public void setDispositiondesc(String dispositiondesc) {
		this.dispositiondesc = dispositiondesc;
	}

	/**
	 * @return the copslstupdateby
	 */
	public Integer getCopslstupdateby() {
		return copslstupdateby;
	}

	/**
	 * @param copslstupdateby the copslstupdateby to set
	 */
	public void setCopslstupdateby(Integer copslstupdateby) {
		this.copslstupdateby = copslstupdateby;
	}

	/**
	 * @return the copslstupdatedt
	 */
	public Timestamp getCopslstupdatedt() {
		return copslstupdatedt;
	}

	/**
	 * @param copslstupdatedt the copslstupdatedt to set
	 */
	public void setCopslstupdatedt(Timestamp copslstupdatedt) {
		this.copslstupdatedt = copslstupdatedt;
	}

	/**
	 * @return the lstupdateby
	 */
	public Long getLstupdateby() {
		return lstupdateby;
	}

	/**
	 * @param lstupdateby the lstupdateby to set
	 */
	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	/**
	 * @return the lstupdatedt
	 */
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	/**
	 * @param lstupdatedt the lstupdatedt to set
	 */
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	/**
	 * @return the isactive
	 */
	public Integer getIsactive() {
		return isactive;
	}

	/**
	 * @param isactive the isactive to set
	 */
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	/**
	 * @return the saleslstupdateby
	 */
	public Integer getSaleslstupdateby() {
		return saleslstupdateby;
	}

	/**
	 * @param saleslstupdateby the saleslstupdateby to set
	 */
	public void setSaleslstupdateby(Integer saleslstupdateby) {
		this.saleslstupdateby = saleslstupdateby;
	}

	/**
	 * @return the saleslstupdatedt
	 */
	public Timestamp getSaleslstupdatedt() {
		return saleslstupdatedt;
	}

	/**
	 * @param saleslstupdatedt the saleslstupdatedt to set
	 */
	public void setSaleslstupdatedt(Timestamp saleslstupdatedt) {
		this.saleslstupdatedt = saleslstupdatedt;
	}


}