package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/* Bean to hold required data of Questions and answers
*/
public class QuestionAnswer implements Serializable {
	private static final long serialVersionUID = -6481669742698523351L;

	@NotNull(message = "QuestionKey can not be null")
	@NotBlank(message = "QuestionKey can not be null or blank")
	@Digits(fraction = 0, integer = 20, message = "QuestionKey can not be other than digits")
	private Integer questionKey;
	
	@NotBlank(message = "QuestionCode can not be null or blank")
	private String questionCode;
	
	private String questionString;
	
	private Boolean visibleToUiFlag;

	private Integer appQuestionResponseKey;
	
	@NotBlank(message = "UserResponse can not be null or blank")
	private String userResponse;
	
    public QuestionAnswer() {
    	//Constructor
	}

	public Integer getQuestionKey() {
		return questionKey;
	}

	public void setQuestionKey(Integer questionKey) {
		this.questionKey = questionKey;
	}

	public String getUserResponse() {
		return userResponse;
	}

	public void setUserResponse(String userResponse) {
		this.userResponse = userResponse;
	}

	public String getQuestionString() {
		return questionString;
	}

	public void setQuestionString(String questionString) {
		this.questionString = questionString;
	}

	public Boolean getVisibleToUiFlag() {
		return visibleToUiFlag;
	}

	public void setVisibleToUiFlag(Boolean visibleToUiFlag) {
		this.visibleToUiFlag = visibleToUiFlag;
	}

	public String getQuestionCode() {
		return questionCode;
	}

	public void setQuestionCode(String questionCode) {
		this.questionCode = questionCode;
	}

	public Integer getAppQuestionResponseKey() {
		return appQuestionResponseKey;
	}

	public void setAppQuestionResponseKey(Integer appQuestionResponseKey) {
		this.appQuestionResponseKey = appQuestionResponseKey;
	}

}