package com.bajaj.markets.credit.employeeportal.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="APP_UDF_VERIFICATION",schema="dmcredit")
public class AppUdfVerification {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long appudfverificationkey; 
	
	private long applicationkey;
	
	private long udfflgkey;
	
	private int status;
	
	private Timestamp createdt; 
	
	private String remarks; 
	
	private int addedbyuserrolekey; 
	
	private int isactive;
	
	private String lstupdateby;
	
	private Timestamp lstupdatedt;

	public long getAppudfverificationkey() {
		return appudfverificationkey;
	}

	public void setAppudfverificationkey(long appudfverificationkey) {
		this.appudfverificationkey = appudfverificationkey;
	}

	public long getApplicationkey() {
		return applicationkey;
	}

	public void setApplicationkey(long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public long getUdfflgkey() {
		return udfflgkey;
	}

	public void setUdfflgkey(long udfflgkey) {
		this.udfflgkey = udfflgkey;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Timestamp getCreatedt() {
		return createdt;
	}

	public void setCreatedt(Timestamp createdt) {
		this.createdt = createdt;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getAddedbyuserrolekey() {
		return addedbyuserrolekey;
	}

	public void setAddedbyuserrolekey(int addedbyuserrolekey) {
		this.addedbyuserrolekey = addedbyuserrolekey;
	}

	public int getIsactive() {
		return isactive;
	}

	public void setIsactive(int isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	
}
