/**
 * 
 */
package com.bajaj.markets.credit.employeeportal.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.employeeportal.bean.ApplicationSource;
import com.bajaj.markets.credit.employeeportal.bean.Section;
import com.bajaj.markets.credit.employeeportal.helper.EmployeePortalServiceUtility;
import com.bajaj.markets.credit.employeeportal.helper.ErrorBean;
import com.bajaj.markets.credit.employeeportal.service.EmployeePortalSectionServiceInterface;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author deepak.ray
 * Controller for persisting section id's based on user input
 */
@RestController
public class EmployeePortalSectionsController {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private EmployeePortalSectionServiceInterface employeePortalSectionService;
	
	@Autowired
	private EmployeePortalServiceUtility employeePortalServiceUtility;
	
	private static final String CLASSNAME = EmployeePortalSectionsController.class.getName();
	@Secured(value = {Role.EMPLOYEE,Role.VENDORPARTNER,Role.PRINCIPAL})
	@ApiOperation(value = "Fetch section/sub-section Detail", notes = "Fetch section/sub-section details on the basis of user applicationId", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	  
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Section Detail found for applicationId", response = Section.class),
			@ApiResponse(code = 404, message = "Section Detail not found for applicationId",response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
	@GetMapping(value = "/v1/credit/employeeportal/applications/{applicationid}/sections", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getApplicationSectionDetails(@PathVariable("applicationid") String applicationId,@RequestHeader HttpHeaders headers){

		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside getApplicationSectionDetails method controller - applicationId: "+ applicationId);
		ApplicationSource appSource = employeePortalServiceUtility.getValidApplicationId(applicationId,headers,true); 
		return new ResponseEntity<>(employeePortalSectionService.getApplicationSectionDetails(Long.valueOf(appSource.getValidApplicationId()), appSource.getSource()), HttpStatus.OK);
	}
}