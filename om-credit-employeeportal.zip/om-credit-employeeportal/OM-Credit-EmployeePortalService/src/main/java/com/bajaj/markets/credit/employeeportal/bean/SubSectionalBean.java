package com.bajaj.markets.credit.employeeportal.bean;

import java.util.ArrayList;
import java.util.List;

public class SubSectionalBean extends SectionBean {

	private long parentSectionId;
	private List<UIFieldBean> fields = new ArrayList<>();

	public long getParentSectionId() {
		return parentSectionId;
	}

	public void setParentSectionId(long parentSectionId) {
		this.parentSectionId = parentSectionId;
	}

	public List<UIFieldBean> getFields() {
		return fields;
	}

	public void setFields(List<UIFieldBean> fields) {
		this.fields = fields;
	}
	
}
