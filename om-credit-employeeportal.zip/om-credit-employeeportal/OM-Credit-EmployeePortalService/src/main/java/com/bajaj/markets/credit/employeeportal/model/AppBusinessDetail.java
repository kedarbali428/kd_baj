package com.bajaj.markets.credit.employeeportal.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "app_occupation_detail", schema = "dmcredit")
public class AppBusinessDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "app_occupation_detail_appoccupationkey_generator", sequenceName = "dmcredit.seq_pk_app_occupation_detail", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_occupation_detail_appoccupationkey_generator")
	private Long appoccupationkey;

	private Long appattrbkey;

	private String businessname;

	private String businesspan;

	private String businesskey;

	private Integer businessvintage;

	private String industryother;

	private String annualturnover;

	private Long declaredincome;

	private String gstnumber;

	private Long occupationtype;
	
	private Long nobkey;

	private BigDecimal netmthincome;

	private Long subindumastkey;

	private Long custindmastkey;

	private Integer isactive;

	private Long lstupdateby;

	private Timestamp lstupdatedt;

	private Long emplrtype;

	private Integer declaredexperience;

	private BigDecimal profitaftertax;

	public Long getAppoccupationkey() {
		return appoccupationkey;
	}

	public void setAppoccupationkey(Long appoccupationkey) {
		this.appoccupationkey = appoccupationkey;
	}

	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public String getBusinesspan() {
		return businesspan;
	}

	public void setBusinesspan(String businesspan) {
		this.businesspan = businesspan;
	}

	public String getBusinesskey() {
		return businesskey;
	}

	public void setBusinesskey(String businesskey) {
		this.businesskey = businesskey;
	}

	public Integer getBusinessvintage() {
		return businessvintage;
	}

	public void setBusinessvintage(Integer businessvintage) {
		this.businessvintage = businessvintage;
	}

	public String getIndustryother() {
		return industryother;
	}

	public void setIndustryother(String industryother) {
		this.industryother = industryother;
	}

	public String getAnnualturnover() {
		return annualturnover;
	}

	public void setAnnualturnover(String annualturnover) {
		this.annualturnover = annualturnover;
	}

	public Long getDeclaredincome() {
		return declaredincome;
	}

	public void setDeclaredincome(Long declaredincome) {
		this.declaredincome = declaredincome;
	}

	public String getGstnumber() {
		return gstnumber;
	}

	public void setGstnumber(String gstnumber) {
		this.gstnumber = gstnumber;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	public Long getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(Long lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Long getOccupationtype() {
		return occupationtype;
	}

	public void setOccupationtype(Long occupationtype) {
		this.occupationtype = occupationtype;
	}

	public Long getNobkey() {
		return nobkey;
	}

	public void setNobkey(Long nobkey) {
		this.nobkey = nobkey;
	}

	public Long getCustindmastkey() {
		return custindmastkey;
	}

	public void setCustindmastkey(Long custindmastkey) {
		this.custindmastkey = custindmastkey;
	}

	public BigDecimal getNetmthincome() {
		return netmthincome;
	}

	public void setNetmthincome(BigDecimal netmthincome) {
		this.netmthincome = netmthincome;
	}

	public Long getSubindumastkey() {
		return subindumastkey;
	}

	public void setSubindumastkey(Long subindumastkey) {
		this.subindumastkey = subindumastkey;
	}

	/**
	 * @return the emplrtype
	 */
	public Long getEmplrtype() {
		return emplrtype;
	}

	/**
	 * @param emplrtype the emplrtype to set
	 */
	public void setEmplrtype(Long emplrtype) {
		this.emplrtype = emplrtype;
	}

	public Integer getDeclaredexperience() {
		return declaredexperience;
	}

	public void setDeclaredexperience(Integer declaredexperience) {
		this.declaredexperience = declaredexperience;
	}

	public BigDecimal getProfitaftertax() {
		return profitaftertax;
	}

	public void setProfitaftertax(BigDecimal profitaftertax) {
		this.profitaftertax = profitaftertax;
	}

}