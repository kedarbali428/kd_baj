package com.bajaj.markets.credit.employeeportal.helper;

public class CreditApplicationConstant {

	public interface ParentApplication{}
	public interface ChildApplication{}
	public interface Salaried{}
	public interface Business{}
	public interface Doctor{}
	public interface CA{}
	public interface OccupationType{}
	public interface Qualification{}
	public interface UserProfileAttribute{}
	public interface BundleSelected{}
	public interface BundleNotSelected{}

	public interface Residence {
	}	
	
}
