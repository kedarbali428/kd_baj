package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class LoanApplicationDeviations implements Serializable {

	private static final long serialVersionUID = 1L;

	private String appdeviationcd;
	private String appdeviationdscr;
	private String deviationauthority;
	private Timestamp createdtm;
	private String deviationAddedBy;
	private String deviationProduct;
	private Long applicationKey;
	private String deviationCreatedBy;
	private String productVarient;
	private String deviationStatus;

	public String getAppdeviationcd() {
		return appdeviationcd;
	}

	public void setAppdeviationcd(String appdeviationcd) {
		this.appdeviationcd = appdeviationcd;
	}

	public String getAppdeviationdscr() {
		return appdeviationdscr;
	}

	public void setAppdeviationdscr(String appdeviationdscr) {
		this.appdeviationdscr = appdeviationdscr;
	}

	public String getDeviationauthority() {
		return deviationauthority;
	}

	public void setDeviationauthority(String deviationauthority) {
		this.deviationauthority = deviationauthority;
	}

	public Timestamp getCreatedtm() {
		return createdtm;
	}

	public void setCreatedtm(Timestamp createdtm) {
		this.createdtm = createdtm;
	}

	public String getDeviationAddedBy() {
		return deviationAddedBy;
	}

	public void setDeviationAddedBy(String deviationAddedBy) {
		this.deviationAddedBy = deviationAddedBy;
	}

	public String getDeviationProduct() {
		return deviationProduct;
	}

	public void setDeviationProduct(String deviationProduct) {
		this.deviationProduct = deviationProduct;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getDeviationCreatedBy() {
		return deviationCreatedBy;
	}

	public void setDeviationCreatedBy(String deviationCreatedBy) {
		this.deviationCreatedBy = deviationCreatedBy;
	}

	public String getProductVarient() {
		return productVarient;
	}

	public void setProductVarient(String productVarient) {
		this.productVarient = productVarient;
	}

	public String getDeviationStatus() {
		return deviationStatus;
	}

	public void setDeviationStatus(String deviationStatus) {
		this.deviationStatus = deviationStatus;
	}

}