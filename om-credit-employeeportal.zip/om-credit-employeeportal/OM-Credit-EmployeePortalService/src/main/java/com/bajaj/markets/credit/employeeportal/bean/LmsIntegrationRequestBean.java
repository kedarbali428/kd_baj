package com.bajaj.markets.credit.employeeportal.bean;

import org.springframework.http.HttpMethod;

public class LmsIntegrationRequestBean {
	
	private Long applicationId;
	private Boolean insertNoSQL;
	private Boolean asyncRequired;
	private HttpMethod httpMethod;
	private String productCode;
	private String requestPayload;
	private String source;
	private String params;
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public Boolean getInsertNoSQL() {
		return insertNoSQL;
	}
	public void setInsertNoSQL(Boolean insertNoSQL) {
		this.insertNoSQL = insertNoSQL;
	}
	public Boolean getAsyncRequired() {
		return asyncRequired;
	}
	public void setAsyncRequired(Boolean asyncRequired) {
		this.asyncRequired = asyncRequired;
	}
	public HttpMethod getHttpMethod() {
		return httpMethod;
	}
	public void setHttpMethod(HttpMethod httpMethod) {
		this.httpMethod = httpMethod;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getRequestPayload() {
		return requestPayload;
	}
	public void setRequestPayload(String requestPayload) {
		this.requestPayload = requestPayload;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getParams() {
		return params;
	}
	public void setParams(String params) {
		this.params = params;
	}

}
