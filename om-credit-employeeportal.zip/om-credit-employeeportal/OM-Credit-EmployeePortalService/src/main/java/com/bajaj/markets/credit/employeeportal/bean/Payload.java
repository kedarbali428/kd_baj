package com.bajaj.markets.credit.employeeportal.bean;

public class Payload {
	
	private Long applicantKey;

	private Long applicationKey;

	private Long kycId;

	private String bitlyUrl;

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getKycId() {
		return kycId;
	}

	public void setKycId(Long kycId) {
		this.kycId = kycId;
	}

	public String getBitlyUrl() {
		return bitlyUrl;
	}

	public void setBitlyUrl(String bitlyUrl) {
		this.bitlyUrl = bitlyUrl;
	}

	@Override
	public String toString() {
		return "Payload [applicantKey=" + applicantKey + ", applicationKey=" + applicationKey + ", kycId=" + kycId
				+ ", bitlyUrl=" + bitlyUrl + "]";
	}
	
	
	

}
