package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class CibilCoApplicantDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String coapplicantApplicantName;
	private String coapplicantDateOfBirth;
	private String coapplicantGenderAsPerCibil;
	private String coapplicantPanNumber;
	private String coapplicantPassportNumber;
	private String coapplicantDrivingLicenceNumber;
	private String coapplicantAadharNumber;

	public String getCoapplicantApplicantName() {
		return coapplicantApplicantName;
	}

	public void setCoapplicantApplicantName(String coapplicantApplicantName) {
		this.coapplicantApplicantName = coapplicantApplicantName;
	}

	public String getCoapplicantDateOfBirth() {
		return coapplicantDateOfBirth;
	}

	public void setCoapplicantDateOfBirth(String coapplicantDateOfBirth) {
		this.coapplicantDateOfBirth = coapplicantDateOfBirth;
	}

	public String getCoapplicantGenderAsPerCibil() {
		return coapplicantGenderAsPerCibil;
	}

	public void setCoapplicantGenderAsPerCibil(String coapplicantGenderAsPerCibil) {
		this.coapplicantGenderAsPerCibil = coapplicantGenderAsPerCibil;
	}

	public String getCoapplicantPanNumber() {
		return coapplicantPanNumber;
	}

	public void setCoapplicantPanNumber(String coapplicantPanNumber) {
		this.coapplicantPanNumber = coapplicantPanNumber;
	}

	public String getCoapplicantPassportNumber() {
		return coapplicantPassportNumber;
	}

	public void setCoapplicantPassportNumber(String coapplicantPassportNumber) {
		this.coapplicantPassportNumber = coapplicantPassportNumber;
	}

	public String getCoapplicantDrivingLicenceNumber() {
		return coapplicantDrivingLicenceNumber;
	}

	public void setCoapplicantDrivingLicenceNumber(String coapplicantDrivingLicenceNumber) {
		this.coapplicantDrivingLicenceNumber = coapplicantDrivingLicenceNumber;
	}

	public String getCoapplicantAadharNumber() {
		return coapplicantAadharNumber;
	}

	public void setCoapplicantAadharNumber(String coapplicantAadharNumber) {
		this.coapplicantAadharNumber = coapplicantAadharNumber;
	}

}