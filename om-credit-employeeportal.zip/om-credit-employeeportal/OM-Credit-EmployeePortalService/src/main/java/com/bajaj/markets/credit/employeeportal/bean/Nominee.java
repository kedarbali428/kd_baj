package com.bajaj.markets.credit.employeeportal.bean;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class Nominee {
	private Integer nomineeKey;
	
	@NotBlank(message = "name can not be null")
	private String name;
	
	@NotBlank(message = "dateOfBirth cannot be null or empty")
    @Pattern(regexp = "\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])*", message = "Invalid date format. Please pass date in yyyy-MM-dd")
	private String dateOfBirth;
	private String relationship;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public Integer getNomineeKey() {
		return nomineeKey;
	}

	public void setNomineeKey(Integer nomineeKey) {
		this.nomineeKey = nomineeKey;
	}

}
