package com.bajaj.markets.credit.employeeportal.bean;

public class BankDetailsRequestBean {

	private String applicationKey;
	private Boolean isPreferedForRepayment;
	public String getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}
	public Boolean getIsPreferedForRepayment() {
		return isPreferedForRepayment;
	}
	public void setIsPreferedForRepayment(Boolean isPreferedForRepayment) {
		this.isPreferedForRepayment = isPreferedForRepayment;
	}
	
}
