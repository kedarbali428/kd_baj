package com.bajaj.markets.credit.employeeportal.bean;

public class CibilRequest {

	private String cibilType;
	private Long applicationKey;
	private Long applicantKey;
	private String provider;
	private UserData userData;
	public String getCibilType() {
		return cibilType;
	}
	public void setCibilType(String cibilType) {
		this.cibilType = cibilType;
	}
	public Long getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}
	public Long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}
	public String getProvider() {
		return provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
	public UserData getUserData() {
		return userData;
	}
	public void setUserData(UserData userData) {
		this.userData = userData;
	}
	@Override
	public String toString() {
		return "CibilRequest [cibilType=" + cibilType + ", applicationKey=" + applicationKey + ", applicantKey="
				+ applicantKey + ", provider=" + provider + ", userData=" + userData + "]";
	}
	
}
