package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class AppDeviationResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer deviationCodeKey;

	private Long createdBy;

	private Timestamp createDateTime;

	private String deviationAuthority;
	
	private Long prodKey;
	
	private String status;

	public AppDeviationResponse() {
	}

	public Integer getDeviationCodeKey() {
		return deviationCodeKey;
	}

	public void setDeviationCodeKey(Integer deviationCodeKey) {
		this.deviationCodeKey = deviationCodeKey;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(Timestamp createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getDeviationAuthority() {
		return deviationAuthority;
	}

	public void setDeviationAuthority(String deviationAuthority) {
		this.deviationAuthority = deviationAuthority;
	}

	public Long getProdKey() {
		return prodKey;
	}

	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "AppDeviationResponse [deviationCodeKey=" + deviationCodeKey + ", createdBy=" + createdBy
				+ ", createDateTime=" + createDateTime + ", deviationAuthority=" + deviationAuthority + ", prodKey="
				+ prodKey + "]";
	}
	
}