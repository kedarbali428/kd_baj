package com.bajaj.markets.credit.employeeportal.bean;

public class UserMgmtTabFieldsBean {
	private String fieldId;
	private String fieldName;
	private String tabKey;
	private String prodMastKey;
	
	/**
	 * @return the tabKey
	 */
	public String getTabKey() {
		return tabKey;
	}
	/**
	 * @param tabKey the tabKey to set
	 */
	public void setTabKey(String tabKey) {
		this.tabKey = tabKey;
	}
	/**
	 * @return the prodMastKey
	 */
	public String getProdMastKey() {
		return prodMastKey;
	}
	/**
	 * @param prodMastKey the prodMastKey to set
	 */
	public void setProdMastKey(String prodMastKey) {
		this.prodMastKey = prodMastKey;
	}
	/**
	 * @return the fieldId
	 */
	public String getFieldId() {
		return fieldId;
	}
	/**
	 * @param fieldId the fieldId to set
	 */
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}
	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}
	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	
}
