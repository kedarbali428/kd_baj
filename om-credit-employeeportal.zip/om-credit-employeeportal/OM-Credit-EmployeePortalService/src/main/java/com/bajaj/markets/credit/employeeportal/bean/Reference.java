package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

public class Reference implements Serializable {

	private static final long serialVersionUID = -8924740301469375486L;
	private Long key;
	private String code;
	private String value;

	@Override
	public String toString() {
		return "Reference [key=" + key + ", code=" + code + ", value=" + value + "]";
	}

	public Reference() {
		super();
	}

	public Reference(Long key, String code, String value) {
		super();
		this.key = key;
		this.code = code;
		this.value = value;
	}

	public Long getKey() {
		return key;
	}

	public void setKey(Long key) {
		this.key = key;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
