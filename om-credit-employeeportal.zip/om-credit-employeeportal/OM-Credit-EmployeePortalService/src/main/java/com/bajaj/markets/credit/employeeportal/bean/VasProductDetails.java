package com.bajaj.markets.credit.employeeportal.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class VasProductDetails {

	private String vasProductName;
	private String vasProductManufacturer;
	private String vasIssunanceNumber;
	private String errorMessage;
	private Timestamp dateAndTime;
	private BigDecimal premiumAmount;
	private BigDecimal sumAssured;

	public String getVasProductName() {
		return vasProductName;
	}

	public void setVasProductName(String vasProductName) {
		this.vasProductName = vasProductName;
	}

	public String getVasProductManufacturer() {
		return vasProductManufacturer;
	}

	public void setVasProductManufacturer(String vasProductManufacturer) {
		this.vasProductManufacturer = vasProductManufacturer;
	}

	public String getVasIssunanceNumber() {
		return vasIssunanceNumber;
	}

	public void setVasIssunanceNumber(String vasIssunanceNumber) {
		this.vasIssunanceNumber = vasIssunanceNumber;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Timestamp getDateAndTime() {
		return dateAndTime;
	}

	public void setDateAndTime(Timestamp dateAndTime) {
		this.dateAndTime = dateAndTime;
	}

	public BigDecimal getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(BigDecimal premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public BigDecimal getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(BigDecimal sumAssured) {
		this.sumAssured = sumAssured;
	}

}
