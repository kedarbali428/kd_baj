package com.bajaj.markets.credit.employeeportal.bean;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ChannelDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	private Long incomeImputationKey;
	@Indexed
	private Long applicantkey;
	@Indexed
	private Long applicationKey;
	
	String channel;
	String channelResponse;
	
	public String getChannel() {
		return channel;
	}
	
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	public String getChannelResponse() {
		return channelResponse;
	}
	
	public void setChannelResponse(String channelResponse) {
		this.channelResponse = channelResponse;
	}
	
	
	public Long getIncomeImputationKey() {
		return incomeImputationKey;
	}

	public void setIncomeImputationKey(Long incomeImputationKey) {
		this.incomeImputationKey = incomeImputationKey;
	}

	public Long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(Long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	@Override
	public String toString() {
		return "ChannelDetails [incomeImputationKey=" + incomeImputationKey + ", applicantkey=" + applicantkey
				+ ", applicationKey=" + applicationKey + ", channel=" + channel + "]";
	}

}
