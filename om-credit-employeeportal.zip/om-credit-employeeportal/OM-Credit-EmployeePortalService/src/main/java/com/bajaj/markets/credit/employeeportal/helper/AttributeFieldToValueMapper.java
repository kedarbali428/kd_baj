package com.bajaj.markets.credit.employeeportal.helper;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.employeeportal.bean.ApplicationFieldSetAttributes;
import com.bajaj.markets.credit.employeeportal.bean.FieldData;
import com.bajaj.markets.credit.employeeportal.bean.GeoTaggingDetails;
import com.bajaj.markets.credit.employeeportal.bean.Occupation;
import com.bajaj.markets.credit.employeeportal.bean.SubSection;
@Component
public class AttributeFieldToValueMapper {
	@Autowired
	BFLLoggerUtilExt logger;
	private static final String CLASSNAME = AttributeFieldToValueMapper.class.getName();
	
	/**
	 * @param subSection
	 * @param applicationStageDetails
	 * @param application
	 */
	@SuppressWarnings({ "rawtypes" })
	public void mapValuesToFields(SubSection subSection, Object obj,
			Properties fieldValMap) {
		if (null != obj) {
			if (obj instanceof Collection<?>) {
				for (Object element : (Collection) obj) {
					try {
						mapValues(subSection, element, fieldValMap);
					} catch (Exception e) {
						logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
								"Technical exception occurred while fetching subsection details: ", e);
						throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(
								"OMCA_103", "Technical exception occurred while fetching subsection logs "));
					}
				}
			} else {
				try {
					mapValues(subSection, obj, fieldValMap);
				} catch (Exception e) {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
							"Technical exception occurred while fetching subsection  details: ", e);
					throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
							new ErrorBean("OMCA_103", "Technical exception occurred while fetching subsection logs "));
				}
			}
		}

	}

	/**
	 * @param subSection
	 * @param obj
	 * @param application
	 * @throws IntrospectionException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	public void mapValues(SubSection subSection, Object obj, Properties application)
			throws Exception {
		FieldData data = null;
		for (ApplicationFieldSetAttributes field : subSection.getFieldSetAttributeList()) {
			String fieldName = null != ((String) application.get(field.getFieldcd().toString()))
					? ((String) application.get(field.getFieldcd().toString())).trim()
					: null;
			if (null != fieldName) {
				PropertyDescriptor pd;
				pd = new PropertyDescriptor(fieldName, obj.getClass());
				Object tmpObjec = pd.getReadMethod().invoke(obj);
				data = new FieldData();
				data.setValue(null != tmpObjec ? tmpObjec.toString() : null);
				field.getFieldValueList().add(data);
			} else {
				data = new FieldData();
				data.setValue(null);
				field.getFieldValueList().add(data);
			}
		}
	}
	
	/**
	 * @param subSection
	 * @param occupation
	 */
	public void mapBusinessOccupationFields(SubSection subSection, Occupation occupation) {
		if (null != occupation) {
			FieldData data = null;
			for (ApplicationFieldSetAttributes field : subSection.getFieldSetAttributeList()) {
				switch (field.getFieldcd()) {
				case 30048:
					data = new FieldData();
					data.setValue(occupation.getBusinessOwnerDetails().getBusinessName());
					field.getFieldValueList().add(data);
					break;
				case 30049:
					data = new FieldData();
					data.setValue(null != occupation.getBusinessOwnerDetails().getBusinessVintage()?
							occupation.getBusinessOwnerDetails().getBusinessVintage(): null);
					field.getFieldValueList().add(data);
					break;
				case 30050 :
					data = new FieldData();
					data.setValue(null != occupation.getBusinessOwnerDetails().getConstitutionType()?
							occupation.getBusinessOwnerDetails().getConstitutionType(): null);
					field.getFieldValueList().add(data);
					break;
				case 30051:
					data = new FieldData();
					data.setValue(occupation.getBusinessOwnerDetails().getNatureOfBusinessDesc());
					//field.getFieldValueList()
						//	.add(occupation.getBusinessOwnerDetails().getNatureOfBusiness().getValue());
					field.getFieldValueList().add(data);
					break;
				case 30052:
					data = new FieldData();
					data.setValue(null != occupation.getBusinessOwnerDetails().getAnualTurnover() ?
							occupation.getBusinessOwnerDetails().getAnualTurnover().getValue() : null);
					field.getFieldValueList().add(data);
					break;
				case 30053:
					data = new FieldData();
					data.setValue(occupation.getBusinessOwnerDetails().getBusinessPan());
					field.getFieldValueList().add(data);
					break;
				case 30054:
					data = new FieldData();
					data.setValue(occupation.getBusinessOwnerDetails().getGstNumber());
					field.getFieldValueList().add(data);
					break;
				// TODO - Below DB mappings are not available
				case 30055:
					data = new FieldData();
					data.setValue(null);
					field.getFieldValueList().add(data);
					break;
				case 30056:
					data = new FieldData();
					data.setValue(null);
					field.getFieldValueList().add(data);
					break;
				case 30057:
					data = new FieldData();
					data.setValue(null != occupation.getBusinessOwnerDetails().getIndustryType() ?occupation.getBusinessOwnerDetails().getIndustryType().getValue() : null);
					field.getFieldValueList().add(data);
					break;
				case 30802:
					data = new FieldData();
					data.setValue(occupation.getBusinessOwnerDetails().getNetMonthlyIncome());
					field.getFieldValueList().add(data);
					break;	
				case 30058:
					data = new FieldData();
					data.setValue(occupation.getBusinessOwnerDetails().getSubindmastdesc());
					//field.getFieldValueList().add(occupation.getBusinessOwnerDetails().getIndustryType().getValue());
					//field.getFieldValueList().add(occupation.getBusinessOwnerDetails().getSubindumastkey().getValue());
					field.getFieldValueList().add(data);
					break;
				case 31000:
					data = new FieldData();
					data.setValue(null != occupation.getBusinessOwnerDetails().getProfitAfterTax() ? occupation.getBusinessOwnerDetails().getProfitAfterTax().toString() : null);
					field.getFieldValueList().add(data);
					break;
				}
			}
		}
	}
	
	/**
	 * @param subSection
	 * @param occupation
	 */
	public void mapSalariedOccupationFields(SubSection subSection, Occupation occupation) {
		if (null != occupation) {
			FieldData data = null;
			for (ApplicationFieldSetAttributes field : subSection.getFieldSetAttributeList()) {
				switch (field.getFieldcd()) {
				case 30038:
					data = new FieldData();
					data.setValue(null != occupation.getSalariedDetail().getEmployerName() ?
							occupation.getSalariedDetail().getEmployerName().getValue() : null);
					field.getFieldValueList().add(data);
					break;
				// TODO - Below DB mappings are not available
				case 31004:
					data = new FieldData();
					data.setValue(occupation.getSalariedDetail().getCompanyCategory());
					field.getFieldValueList().add(data);
					break;
				case 30040:
					data = new FieldData();
					data.setValue(null != occupation.getSalariedDetail().getDesignation()?
							occupation.getSalariedDetail().getDesignation().getValue() : null);
					field.getFieldValueList().add(data);
					break;
				case 30041:
					data = new FieldData();
					data.setValue(occupation.getSalariedDetail().getDecNetSalary());
					field.getFieldValueList().add(data);
					break;
				case 30042:
					data = new FieldData();
					data.setValue(occupation.getSalariedDetail().getNetSalary());
					field.getFieldValueList().add(data);
					break;
				// TODO - Below DB mappings are not available
				case 30043:
					data = new FieldData();
					data.setValue(null);
					field.getFieldValueList().add(data);
					break;
				case 30044:
					data = new FieldData();
					data.setValue(occupation.getSalariedDetail().getOfficialEmailAddress());
					field.getFieldValueList().add(data);
					break;
				case 30045:
					data = new FieldData();
					data.setValue(occupation.getSalariedDetail().getIndustry());
					field.getFieldValueList().add(data);
					break;
				case 30039:
					data = new FieldData();
					data.setValue(occupation.getSalariedDetail().getEmployerType());
					field.getFieldValueList().add(data);
					break;
				case 30047:
					data = new FieldData();
					data.setValue(null);
					field.getFieldValueList().add(data);
					break;
				case 30803:
					data = new FieldData();
					data.setValue(occupation.getSalariedDetail().getWorkExperienceInMonths());
					field.getFieldValueList().add(data);
					break;
				case 30804:
					data = new FieldData();
					data.setValue(occupation.getSalariedDetail().getTotalExperience());
					field.getFieldValueList().add(data);
					break;
				case 30972:
					data = new FieldData();
					data.setValue(occupation.getSalariedDetail().getCvEmailId());
					field.getFieldValueList().add(data);
					break;
				case 30973:
					data = new FieldData();
					data.setValue(occupation.getSalariedDetail().getCvRiskCategory());
					field.getFieldValueList().add(data);
					break;
					
				}
			}
		}
	}
	
	public void mapUpdateValues(List<FieldData> fieldValues, Object obj, Properties fieldValMap) throws Exception {
		for (FieldData field : fieldValues) {
			// String fieldName = field.getKey();
			String fieldName = null != ((String) fieldValMap.get(field.getKey()))
					? ((String) fieldValMap.get(field.getKey().toString())).trim()
					: null;
			if (null != fieldName) {
				PropertyDescriptor pd;

				try {
					pd = new PropertyDescriptor(fieldName, obj.getClass());
					Method setter = pd.getWriteMethod();
					setter.invoke(obj, field.getValue());
				} catch (Exception e) {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
							"Technical exception occurred while updating subsection  details: ", e);
					throw new CreditEmployeePortalServiceException(HttpStatus.INTERNAL_SERVER_ERROR,
							new ErrorBean("OMCA_103", "Technical exception occurred while updating subsection  "));
				}
			}
		}

	}

	
}
