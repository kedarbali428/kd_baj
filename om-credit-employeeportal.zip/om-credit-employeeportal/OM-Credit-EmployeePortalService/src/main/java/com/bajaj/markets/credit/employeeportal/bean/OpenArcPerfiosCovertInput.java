package com.bajaj.markets.credit.employeeportal.bean;

import java.util.List;

public class OpenArcPerfiosCovertInput {
	
	private String l2ProductCode;
	private String l3ProductCode;
	private Boolean existingCustomerFlag;
	private List<OfferDetailsPerfios> offerDetails;
	private String perfiosJson;
	private List<String> deviations;
	private Integer incomeObligationEntered;
	private List<PerfiosManualFlagDetails> manualFlags;
	private Boolean perfiosDone;
	
	public String getL2ProductCode() {
		return l2ProductCode;
	}
	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}
	public String getL3ProductCode() {
		return l3ProductCode;
	}
	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}
	public Boolean getExistingCustomerFlag() {
		return existingCustomerFlag;
	}
	public void setExistingCustomerFlag(Boolean existingCustomerFlag) {
		this.existingCustomerFlag = existingCustomerFlag;
	}
	public List<OfferDetailsPerfios> getOfferDetails() {
		return offerDetails;
	}
	public void setOfferDetails(List<OfferDetailsPerfios> offerDetails) {
		this.offerDetails = offerDetails;
	}
	public String getPerfiosJson() {
		return perfiosJson;
	}
	public void setPerfiosJson(String perfiosJson) {
		this.perfiosJson = perfiosJson;
	}
	public List<String> getDeviations() {
		return deviations;
	}
	public void setDeviations(List<String> deviations) {
		this.deviations = deviations;
	}
	public Integer getIncomeObligationEntered() {
		return incomeObligationEntered;
	}
	public void setIncomeObligationEntered(Integer incomeObligationEntered) {
		this.incomeObligationEntered = incomeObligationEntered;
	}
	public List<PerfiosManualFlagDetails> getManualFlags() {
		return manualFlags;
	}
	public void setManualFlags(List<PerfiosManualFlagDetails> manualFlags) {
		this.manualFlags = manualFlags;
	}
	public Boolean getPerfiosDone() {
		return perfiosDone;
	}
	public void setPerfiosDone(Boolean perfiosDone) {
		this.perfiosDone = perfiosDone;
	}
}
