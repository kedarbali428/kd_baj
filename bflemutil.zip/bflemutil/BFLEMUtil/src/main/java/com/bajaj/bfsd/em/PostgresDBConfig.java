package com.bajaj.bfsd.em;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@Component
@EnableJpaRepositories(
	    basePackages = {"com.bajaj.bfsd.repositories.pg"}, 
	    entityManagerFactoryRef = "postgresEntityManager",
	    transactionManagerRef = "postgresTransactionManager"
	)
public class PostgresDBConfig {

      @Autowired
      PostgresDBPropertyConfigure postgresDBPropertyConfigure;

      public static final String THIS_CLASS = PostgresDBConfig.class.getName();

      @Bean("postgresEntityManager")
      @ConditionalOnProperty(name="db.accessscope.pg", havingValue="true")
      public LocalContainerEntityManagerFactoryBean postgresEntityManager() {

            LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
            em.setDataSource(postgresDataSource());
            em.setPackagesToScan(new String[] {"com.bajaj.bfsd.repositories.pg"});

            HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
            em.setJpaVendorAdapter(vendorAdapter);
            HashMap<String, Object> properties = new HashMap<String, Object>();
            properties.put("hibernate.hbm2ddl.auto", postgresDBPropertyConfigure.getHibernateProperty());
            properties.put("hibernate.dialect", postgresDBPropertyConfigure.getDialect());
            em.setJpaPropertyMap(properties);
            
            return em;
      }

      @Bean(name="postgresDataSource")
      //@Primary
      @ConditionalOnProperty(name="db.accessscope.pg", havingValue="true")
      public DataSource postgresDataSource() {

            DriverManagerDataSource dataSource = new DriverManagerDataSource();
            dataSource.setDriverClassName(postgresDBPropertyConfigure.getDriver());
            dataSource.setUrl(postgresDBPropertyConfigure.getDbUrl());
            dataSource.setUsername(postgresDBPropertyConfigure.getUserName());
            dataSource.setPassword(postgresDBPropertyConfigure.getPassword());
            return dataSource;
      }
      
      @Bean(name="postgresTransactionManager")
      @ConditionalOnProperty(name="db.accessscope.pg", havingValue="true")
      public PlatformTransactionManager postgresTransactionManager() {
    
          JpaTransactionManager transactionManager
            = new JpaTransactionManager();
          transactionManager.setEntityManagerFactory(postgresEntityManager().getObject());
          return transactionManager;
      }

     /* @PostConstruct
      public void test(){
            DataSource ds = secondaryDataSource();
            System.out.println("DS props:" + ds);
            
      }*/
     
      
}

