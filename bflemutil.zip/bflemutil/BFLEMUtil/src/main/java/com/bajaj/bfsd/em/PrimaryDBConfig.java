package com.bajaj.bfsd.em;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@Component
@EnableJpaRepositories(
	    basePackages = {"com.bajaj.bfsd.repositories.ora1"}, 
	    entityManagerFactoryRef = "primaryEntityManager",
	    transactionManagerRef = "primaryTransactionManager"
	)
public class PrimaryDBConfig {

      @Autowired
      PrimaryDBPropertyConfigure primaryDBPropertyConfigure;

      public static final String THIS_CLASS = PrimaryDBConfig.class.getName();

      @Bean("primaryEntityManager")
      @Primary
      @ConditionalOnProperty(name="db.accessscope.ora1", havingValue="true")
      public LocalContainerEntityManagerFactoryBean primaryEntityManager() {

            LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
            em.setDataSource(primaryDataSource());
            em.setPackagesToScan(new String[] {"com.bajaj.bfsd.repositories.ora1"});
            HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
            em.setJpaVendorAdapter(vendorAdapter);
            HashMap<String, Object> properties = new HashMap<String, Object>();
            properties.put("hibernate.hbm2ddl.auto", primaryDBPropertyConfigure.getHibernateProperty());
            properties.put("hibernate.dialect", primaryDBPropertyConfigure.getDialect());
            em.setJpaPropertyMap(properties);
            
            return em;
      }

      
      @Bean(name="primaryDataSource")
      @Primary
      @ConditionalOnProperty(name="db.accessscope.ora1", havingValue="true")
      public DataSource primaryDataSource() {
    	  DriverManagerDataSource dataSource = new DriverManagerDataSource();
          dataSource.setDriverClassName(primaryDBPropertyConfigure.getDriver());
          dataSource.setUrl(primaryDBPropertyConfigure.getDbUrl());
          dataSource.setUsername(primaryDBPropertyConfigure.getUserName());
          dataSource.setPassword(primaryDBPropertyConfigure.getPassword());
          return dataSource;
      }
      
      @Bean(name="primaryTransactionManager")
      @Primary
      @ConditionalOnProperty(name="db.accessscope.ora1", havingValue="true")
      public PlatformTransactionManager primaryTransactionManager() {
    
          JpaTransactionManager transactionManager
            = new JpaTransactionManager();
          transactionManager.setEntityManagerFactory(primaryEntityManager().getObject());
          return transactionManager;
      }

     /* @PostConstruct
      public void test(){
            DataSource ds = primaryDataSource();
            System.out.println("DS props:" + ds);
            
      }*/
}

