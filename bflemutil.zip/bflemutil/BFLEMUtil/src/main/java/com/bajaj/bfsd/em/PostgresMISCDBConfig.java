package com.bajaj.bfsd.em;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@Component
@EnableJpaRepositories(
		basePackages = { "com.bajaj.bfsd.repositories.misc" },
		entityManagerFactoryRef = "miscEntityManager",
		transactionManagerRef = "miscTransactionManager"
)
public class PostgresMISCDBConfig {

	@Autowired
	PostgresMISCDBPropertyConfigure propertyConfigurer;

	public static final String THIS_CLASS = PostgresMISCDBConfig.class.getName();

	@Bean("miscEntityManager")
	@ConditionalOnProperty(name = "db.accessscope.misc", havingValue = "true")
	public LocalContainerEntityManagerFactoryBean miscEntityManager() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(miscDataSource());
		em.setPackagesToScan(new String[] { "com.bajaj.bfsd.repositories.pg" });
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		HashMap<String, Object> properties = new HashMap<String, Object>();
		properties.put("hibernate.hbm2ddl.auto", propertyConfigurer.getHibernateProperty());
		properties.put("hibernate.dialect", propertyConfigurer.getDialect());
		em.setJpaPropertyMap(properties);
		return em;
	}

	@Bean(name = "miscDataSource")
	@ConditionalOnProperty(name = "db.accessscope.misc", havingValue = "true")
	public DataSource miscDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(propertyConfigurer.getDriver());
		dataSource.setUrl(propertyConfigurer.getDbUrl());
		dataSource.setUsername(propertyConfigurer.getUserName());
		dataSource.setPassword(propertyConfigurer.getPassword());
		return dataSource;
	}

	@Bean(name = "miscTransactionManager")
	@ConditionalOnProperty(name = "db.accessscope.misc", havingValue = "true")
	public PlatformTransactionManager miscTransactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(miscEntityManager().getObject());
		return transactionManager;
	}

}
