package com.bajaj.bfsd.em;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@RefreshScope
@Component
public class PostgresMISCDBPropertyConfigure {

	 @Value("${bfdl.misc.postgres.datasource.url}")
     private String dbUrl;

     @Value("${bfdl.misc.postgres.datasource.username}")
     private String userName;

     @Value("${bfdl.misc.postgres.datasource.password}")
     private String password;

     @Value("${bfdl.misc.postgres.datasource.driver-class-name}")
     private String driver;

     @Value("${bfdl.misc.postgres.jpa.show-sql}")
     private String showSql;

     @Value("${bfdl.misc.postgres.jpa.properties.hibernate.dialect}")
     private String dialect;

     @Value("${bfdl.misc.postgres.jpa.hibernate.ddl-auto}")
     private String hibernateProperty;

	/**
	 * @return the dbUrl
	 */
	public String getDbUrl() {
		return dbUrl;
	}

	/**
	 * @param dbUrl the dbUrl to set
	 */
	public void setDbUrl(String dbUrl) {
		this.dbUrl = dbUrl;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the driver
	 */
	public String getDriver() {
		return driver;
	}

	/**
	 * @param driver the driver to set
	 */
	public void setDriver(String driver) {
		this.driver = driver;
	}

	/**
	 * @return the showSql
	 */
	public String getShowSql() {
		return showSql;
	}

	/**
	 * @param showSql the showSql to set
	 */
	public void setShowSql(String showSql) {
		this.showSql = showSql;
	}

	/**
	 * @return the dialect
	 */
	public String getDialect() {
		return dialect;
	}

	/**
	 * @param dialect the dialect to set
	 */
	public void setDialect(String dialect) {
		this.dialect = dialect;
	}

	/**
	 * @return the hibernateProperty
	 */
	public String getHibernateProperty() {
		return hibernateProperty;
	}

	/**
	 * @param hibernateProperty the hibernateProperty to set
	 */
	public void setHibernateProperty(String hibernateProperty) {
		this.hibernateProperty = hibernateProperty;
	}
}

