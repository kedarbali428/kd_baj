package com.bajaj.bfsd.em;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@Configuration
@Component
@EnableJpaRepositories(
	    basePackages = {"com.bajaj.bfsd.repositories.ora2"}, 
	    entityManagerFactoryRef = "secondaryEntityManager",
	    transactionManagerRef = "secondaryTransactionManager"
	)
public class SecondaryDBConfig {

      @Autowired
      Environment env;

      @Autowired
      SecondaryDBPropertyConfigure secondaryDBPropertyConfigure;

      @Autowired
      BFLLoggerUtilExt bflLoggerUtilExt;

      public static final String THIS_CLASS = SecondaryDBConfig.class.getName();

      @Bean("secondaryEntityManager")
     // @Primary
      @ConditionalOnProperty(name="db.accessscope.ora2", havingValue="true")
      public LocalContainerEntityManagerFactoryBean secondaryEntityManager() {

            LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
            em.setDataSource(secondaryDataSource());
            em.setPackagesToScan(new String[] {"com.bajaj.bfsd.repositories.ora1"});

            HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
            em.setJpaVendorAdapter(vendorAdapter);
            HashMap<String, Object> properties = new HashMap<String, Object>();
            properties.put("hibernate.hbm2ddl.auto", secondaryDBPropertyConfigure.getHibernateProperty());
            properties.put("hibernate.dialect", secondaryDBPropertyConfigure.getDialect());
            em.setJpaPropertyMap(properties);
            
            return em;
      }

      
      @Bean(name="secondaryDataSource")
      @ConditionalOnProperty(name="db.accessscope.ora2", havingValue="true")
      public DataSource secondaryDataSource() {

            DriverManagerDataSource dataSource = new DriverManagerDataSource();
            dataSource.setDriverClassName(secondaryDBPropertyConfigure.getDriver());
            dataSource.setUrl(secondaryDBPropertyConfigure.getDbUrl());
            dataSource.setUsername(secondaryDBPropertyConfigure.getUserName());
            dataSource.setPassword(secondaryDBPropertyConfigure.getPassword());
            return dataSource;
      }
      
      @Bean(name="secondaryTransactionManager")
      @ConditionalOnProperty(name="db.accessscope.ora2", havingValue="true")
      public PlatformTransactionManager secondaryTransactionManager() {
    
          JpaTransactionManager transactionManager
            = new JpaTransactionManager();
          transactionManager.setEntityManagerFactory(secondaryEntityManager().getObject());
          return transactionManager;
      }

     /* @PostConstruct
      public void test(){
            DataSource ds = secondaryDataSource();
            System.out.println("DS props:" + ds);
            
      }*/
     
      
}

