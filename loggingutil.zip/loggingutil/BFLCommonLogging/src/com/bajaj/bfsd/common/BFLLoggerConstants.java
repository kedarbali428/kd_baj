package com.bajaj.bfsd.common;

enum BFLLoggerConstants {
	SERVICE_APP("Service_Application"),
	SERVICE_EXC("Service_Exception"),
	SERVICE_PERF("Service_Performance");

	private String value;
	private BFLLoggerConstants(String value) {
        this.value = value;
	}
	public String getValue() {
        return this.value;
	}
	
}
