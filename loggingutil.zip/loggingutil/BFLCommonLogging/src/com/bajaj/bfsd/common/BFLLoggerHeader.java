package com.bajaj.bfsd.common;

public enum BFLLoggerHeader {
	ID("cmptcorrid");
	private String value;
	private BFLLoggerHeader(String value) {
        this.value = value;
	}
	public String getValue() {
        return this.value;
	}
}
