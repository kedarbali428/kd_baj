package com.bajaj.bfsd.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;

@Service
public class BFLLoggerUtilExt{
	
	@Autowired
	CustomDefaultHeaders customHeader;
	
	@Autowired
	BFLLoggerUtil loggerUtil;
	
	public void debug(String classname, BFLLoggerComponent componentCategory, String message){
		loggerUtil.debugExt(getCorrelationID(), classname, componentCategory, message);
	}
	
	public void error(String classname, BFLLoggerComponent componentCategory, String message){
		loggerUtil.errorExt(getCorrelationID(), classname, componentCategory, message);
	}

	public void error(String classname, BFLLoggerComponent componentCategory, String message, Throwable error){
		loggerUtil.errorExt(getCorrelationID(), classname, componentCategory, message, error);
	}
	
	public void info(String classname, BFLLoggerComponent componentCategory, String message){
		loggerUtil.infoExt(getCorrelationID(), classname, componentCategory, message);
	}

	public void warn(String classname, BFLLoggerComponent componentCategory, String message){
		loggerUtil.warnExt(getCorrelationID(), classname, componentCategory, message);
	}

	public void warn(String classname, BFLLoggerComponent componentCategory, String message, Throwable error){
		loggerUtil.warnExt(getCorrelationID(), classname, componentCategory, message, error);
	}
	
	public void trace(String classname, BFLLoggerComponent componentCategory, String message){
		loggerUtil.traceExt(getCorrelationID(), classname, componentCategory, message);
	}
	
	public String getCorrelationID() {
		return customHeader!=null?customHeader.getCmptcorrid():"";
	}
}