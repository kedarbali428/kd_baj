package com.bajaj.bfsd.common;

public enum BFLLoggerComponent {
	CONTROLLER("CTRLR"),
	MAPPER("MAPPER"),
	SERVICE("SRV"),
	DAO("DAO"),
	EXCEPTION_HANDLER("EXC_HNDLR"),
	UTILITY("UTILITY"),
	PROCESSOR("PROCESSOR"),
	REPOSITORY("REPOSITORY"),
	WORKFLOW_CONTROLLER("WF-CTRLR"),
	WORKFLOW_DELEGATE("WF-DLG"),
	WORKFLOW_LISTENER("WF-LSNR");
	
	private String value;
	private BFLLoggerComponent(String value) {
        this.value = value;
	}
	public String getValue() {
        return this.value;
	}
}
