package com.bajaj.bfsd.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class BFLLoggerUtil {
	private String correlationID;
	private static final String NOT_AVAILABLE = "NOT_AVAILABLE";

	private static Logger getLogger(String loggerName) {
		return LoggerFactory.getLogger(loggerName);
	}

	public void debug(String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.debug(logString(this.correlationID, classname, componentCategory.getValue(), message));
	}

	/**
	 * @deprecated
	 */
	@Deprecated
	public static void debug(String id, String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.debug(logString(id, classname, componentCategory.getValue(), message));
	}

	void debugExt(String id, String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.debug(logString(id, classname, componentCategory.getValue(), message));
	}

	public void error(String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_EXC.getValue())
				.error(logString(this.correlationID, classname, componentCategory.getValue(), message));
	}

	/**
	 * @deprecated
	 */
	@Deprecated
	public static void error(String id, String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_EXC.getValue())
				.error(logString(id, classname, componentCategory.getValue(), message));
	}

	void errorExt(String id, String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_EXC.getValue())
				.error(logString(id, classname, componentCategory.getValue(), message));
	}

	public void error(String classname, BFLLoggerComponent componentCategory, String message, Throwable error) {
		getLogger(BFLLoggerConstants.SERVICE_EXC.getValue())
				.error(logString(this.correlationID, classname, componentCategory.getValue(), message), error);
	}

	/**
	 * @deprecated
	 */
	@Deprecated
	public static void error(String id, String classname, BFLLoggerComponent componentCategory, String message,
			Throwable error) {
		getLogger(BFLLoggerConstants.SERVICE_EXC.getValue())
				.error(logString(id, classname, componentCategory.getValue(), message), error);
	}

	void errorExt(String id, String classname, BFLLoggerComponent componentCategory, String message, Throwable error) {
		getLogger(BFLLoggerConstants.SERVICE_EXC.getValue())
				.error(logString(id, classname, componentCategory.getValue(), message), error);
	}

	public void info(String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.info(logString(this.correlationID, classname, componentCategory.getValue(), message));
	}

	/**
	 * @deprecated
	 */
	@Deprecated
	public static void info(String id, String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.info(logString(id, classname, componentCategory.getValue(), message));
	}

	void infoExt(String id, String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.info(logString(id, classname, componentCategory.getValue(), message));
	}

	public void warn(String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.warn(logString(this.correlationID, classname, componentCategory.getValue(), message));
	}

	/**
	 * @deprecated
	 */
	@Deprecated
	public static void warn(String id, String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.warn(logString(id, classname, componentCategory.getValue(), message));
	}

	void warnExt(String id, String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.warn(logString(id, classname, componentCategory.getValue(), message));
	}

	public void warn(String classname, BFLLoggerComponent componentCategory, String message, Throwable error) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.warn(logString(this.correlationID, classname, componentCategory.getValue(), message), error);
	}

	/**
	 * @deprecated
	 */
	@Deprecated
	public static void warn(String id, String classname, BFLLoggerComponent componentCategory, String message,
			Throwable error) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.warn(logString(id, classname, componentCategory.getValue(), message), error);
	}

	void warnExt(String id, String classname, BFLLoggerComponent componentCategory, String message, Throwable error) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.warn(logString(id, classname, componentCategory.getValue(), message), error);
	}

	public void trace(String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.trace(logString(this.correlationID, classname, componentCategory.getValue(), message));
	}

	/**
	 * @deprecated
	 */
	@Deprecated
	public static void trace(String id, String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.trace(logString(id, classname, componentCategory.getValue(), message));
	}

	void traceExt(String id, String classname, BFLLoggerComponent componentCategory, String message) {
		getLogger(BFLLoggerConstants.SERVICE_APP.getValue())
				.trace(logString(id, classname, componentCategory.getValue(), message));
	}

	private static String logString(String id, String classname, String cmptCategory, String message) {
		String busTxnID = NOT_AVAILABLE;
		String cmptCorID = NOT_AVAILABLE;

		if (null != id && !id.isEmpty() && id.split("\\|").length > 0) {
			busTxnID = validate(id.split("\\|")[0]);
			cmptCorID = id.split("\\|").length > 1 ? validate(id.split("\\|")[1]) : cmptCorID;
			
			cmptCorID = !StringUtils.isEmpty(cmptCorID) ? cmptCorID.replace(" ", "-") : cmptCorID;
		}
		return  classname + " | " + cmptCorID + " | " + message;
	}

	private static String validate(String id) {
		return id == null ? NOT_AVAILABLE : id;
	}

	public String getCorrelationID() {
		return correlationID;
	}

	public void setCorrelationID(String correlationID) {
		this.correlationID = correlationID;
	}
}
