package com.bajaj.bfsd.authentication.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.authentication.exception.ControllerExceptionHandler;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.request.validator.RequestValidator;
import com.bajaj.bfsd.authentication.service.OMAuthenticationService;
import com.bajaj.bfsd.authentication.util.DataValidator;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@SpringBootTest
public class OMAuthenticationServiceControllerTest {

	@InjectMocks
	OMAuthenticationServiceController omAuthenticationServiceController;

	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	BFLLoggerUtil logger2;

	@Mock
	OMAuthenticationService omAuthenticationService;
	
	@Mock
	Environment env;

	private RequestValidator requestValidator;
	private DataValidator dataValidator;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		
		ControllerExceptionHandler exceptionHandler = new ControllerExceptionHandler();

		mockMvc = MockMvcBuilders.standaloneSetup(omAuthenticationServiceController)
				.setControllerAdvice(exceptionHandler)
				.addPlaceholderValue("api.authentication.authenticatemobiledobandgeneratetokenV2.POST.uri",
						"/v2/login/forms/mobile")
				.build();

		requestValidator = new RequestValidator();
		dataValidator = new DataValidator();
		
		ReflectionTestUtils.setField(dataValidator, "logger", logger2);
		ReflectionTestUtils.setField(requestValidator, "dataValidator", dataValidator);
		ReflectionTestUtils.setField(omAuthenticationServiceController, "requestValidator", requestValidator);
		ReflectionTestUtils.setField(exceptionHandler, "env", env);
		ReflectionTestUtils.setField(exceptionHandler, "logger", logger2);
	}

	@Test
	public void testAuthenticateMobDobAndGenerateToken() throws Exception {
		MobileLoginRequest loginRequest = new MobileLoginRequest();
		loginRequest.setMobile("9999999999");
		loginRequest.setSource("journey");
		loginRequest.setOtp("123456");
		loginRequest.setDateOfBirth("1900-10-10");
		loginRequest.setApplicationKey(123456l);

		List<Tokens> tokens = new ArrayList<Tokens>();
		Tokens token = new Tokens();
		token.setToken("authtoken");
		token.setGuardKey("guardkey");
		token.setType("authtoken");

		tokens.add(token);

		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		tokenResponse.setDefaultRole("userrole");
		tokenResponse.setUserKey(1234l);

		JSONObject loginRequestJson = new JSONObject(loginRequest);

		Mockito.when(omAuthenticationService.authenticateMobDobAndGenerateToken(Mockito.any())).thenReturn(tokenResponse);
		
		mockMvc.perform(post("/v2/login/forms/mobile").content(loginRequestJson.toString())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isCreated());
	}
	
	@Test
	public void testAuthenticateMobDobAndGenerateToken_bindingResultError() throws Exception {
		MobileLoginRequest loginRequest = new MobileLoginRequest();
		
		JSONObject loginRequestJson = new JSONObject(loginRequest);
		mockMvc.perform(post("/v2/login/forms/mobile").content(loginRequestJson.toString())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest());
	}
	
	@Test
	public void testAuthenticateMobDobAndGenerateToken_ErrorBean_AppKey() throws Exception {
		MobileLoginRequest loginRequest = new MobileLoginRequest();
		loginRequest.setMobile("9999999999");
		loginRequest.setSource("journey");
		loginRequest.setDateOfBirth("1900-10-10");
		
		JSONObject loginRequestJson = new JSONObject(loginRequest);
		mockMvc.perform(post("/v2/login/forms/mobile").content(loginRequestJson.toString())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest());
	}
	
	@Test
	public void testAuthenticateMobDobAndGenerateToken_ErrorBean_Mobile() throws Exception {
		MobileLoginRequest loginRequest = new MobileLoginRequest();
		loginRequest.setMobile("123456");
		loginRequest.setSource("journey");
		
		JSONObject loginRequestJson = new JSONObject(loginRequest);
		mockMvc.perform(post("/v2/login/forms/mobile").content(loginRequestJson.toString())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest());
	}
	
	@Test
	public void testAuthenticateMobDobAndGenerateToken_ErrorBean_Dob() throws Exception {
		MobileLoginRequest loginRequest = new MobileLoginRequest();
		loginRequest.setMobile("9999999999");
		loginRequest.setDateOfBirth("10-10-1990");
		loginRequest.setSource("journey");
		
		JSONObject loginRequestJson = new JSONObject(loginRequest);
		mockMvc.perform(post("/v2/login/forms/mobile").content(loginRequestJson.toString())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest());
	}
	
	@Test
	public void testAuthenticateMobDobAndGenerateToken_ErrorBean_SourceJourney() throws Exception {
		MobileLoginRequest loginRequest = new MobileLoginRequest();
		loginRequest.setMobile("9999999999");
		loginRequest.setDateOfBirth("1900-10-10");
		loginRequest.setSource("journey");
		
		JSONObject loginRequestJson = new JSONObject(loginRequest);
		mockMvc.perform(post("/v2/login/forms/mobile").content(loginRequestJson.toString())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest());
	}
	
	@Test
	public void testAuthenticateMobDobAndGenerateToken_ErrorBean_SourceCustomer() throws Exception {
		MobileLoginRequest loginRequest = new MobileLoginRequest();
		loginRequest.setMobile("9999999999");
		loginRequest.setDateOfBirth("1900-10-10");
		loginRequest.setSource("customerportal");
		
		JSONObject loginRequestJson = new JSONObject(loginRequest);
		mockMvc.perform(post("/v2/login/forms/mobile").content(loginRequestJson.toString())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest());
	}
	
	@Test
	public void testAuthenticateMobDobAndGenerateToken_ErrorBean_SourceOther() throws Exception {
		MobileLoginRequest loginRequest = new MobileLoginRequest();
		loginRequest.setMobile("9999999999");
		loginRequest.setDateOfBirth("1900-10-10");
		loginRequest.setSource("other");
		
		JSONObject loginRequestJson = new JSONObject(loginRequest);
		mockMvc.perform(post("/v2/login/forms/mobile").content(loginRequestJson.toString())
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest());
	}
}
