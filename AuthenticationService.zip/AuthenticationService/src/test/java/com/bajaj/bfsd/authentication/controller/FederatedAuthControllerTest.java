package com.bajaj.bfsd.authentication.controller;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeRequest;
import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeResponse;
import com.bajaj.bfsd.authentication.bean.FederatedLoginRequest;
import com.bajaj.bfsd.authentication.bean.FederatedLoginResponse;
import com.bajaj.bfsd.authentication.bean.FederatedTokenRequest;
import com.bajaj.bfsd.authentication.bean.FederatedTokenResponse;
import com.bajaj.bfsd.authentication.bean.FederatedUserRegisterRequest;
import com.bajaj.bfsd.authentication.bean.FederatedUserRegisterResponse;
import com.bajaj.bfsd.authentication.bean.HashGeneratorRequest;
import com.bajaj.bfsd.authentication.service.FederatedAuthService;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bfl.common.exceptions.BFLHttpException;

@RunWith(SpringJUnit4ClassRunner.class)
public class FederatedAuthControllerTest {

	@InjectMocks
	private FederatedAuthController federatedAuthController;

	@Mock
	private FederatedAuthService federatedAuthService;

	@Mock
	private BFLLoggerUtilExt logger;

	@Test
	public void testClientValidation() {
		FederatedLoginRequest loginRequest = new FederatedLoginRequest();
		loginRequest.setAuthorizedClient("authorizedClient");
		loginRequest.setAuthorizedEmployeeCode("12234");
		loginRequest.setClientSecret("clientSecret");
		loginRequest.setClientId("clientId");
		loginRequest.setCustomerFlag(1);
		loginRequest.setMobile("9988776655");
		loginRequest.setPartnerCustomerId(12345);
		FederatedLoginResponse loginResponse = new FederatedLoginResponse();
		loginResponse.setAuthorizationCode("Some Auth Code");

		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		Mockito.when(federatedAuthService.clientValidation(loginRequest))
				.thenReturn(loginResponse);
		ResponseEntity<?> federatedLogin = federatedAuthController.federatedLogin(loginRequest, mockedBindingResult);
		assertNotNull(federatedLogin.getBody());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testClientValidation_BindingErrors() {
		FederatedLoginRequest loginRequest = new FederatedLoginRequest();
		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		Mockito.when(mockedBindingResult.hasErrors()).thenReturn(true);
		Mockito.when(mockedBindingResult.getFieldErrors()).thenReturn(new ArrayList<FieldError>());
		federatedAuthController.federatedLogin(loginRequest, mockedBindingResult);
	}

	@Test
	public void testValidateAuthCode() {

		FederatedAuthorizeRequest validateAuthCode = new FederatedAuthorizeRequest();
		validateAuthCode.setAuthorizationCode("Some Auth Code");
		validateAuthCode.setClientId("clientId");
		
		FederatedAuthorizeResponse response = new FederatedAuthorizeResponse();
		response.setAssistanceMode(false);
		response.setAuthorizedClient("authorizedClient");
		response.setAuthorizedEmployeeCode("12234");
		response.setCustomerFlag("true");
		response.setMobile("9988776655");
		response.setTokenCode("New Token Code");
		response.setPartnerCode("partnerCode");
		response.setPartnerCustomerId("12345");
		
		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		Mockito.when(federatedAuthService.validateAuthorization(validateAuthCode))
				.thenReturn(response);
		
		ResponseEntity<?> federatedResponse = federatedAuthController.validateAuthCode(validateAuthCode, mockedBindingResult);
		assertNotNull(federatedResponse.getBody());
	}

	@Test(expected = BFLHttpException.class)
	public void testValidateAuthCode_BindingErrors() {
		FederatedAuthorizeRequest authorizeRequest = new FederatedAuthorizeRequest();
		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		Mockito.when(mockedBindingResult.hasErrors()).thenReturn(true);
		Mockito.when(mockedBindingResult.getFieldErrors()).thenReturn(new ArrayList<FieldError>());
		federatedAuthController.validateAuthCode(authorizeRequest, mockedBindingResult);
	}

	@Test
	public void testGenerateHashValue() {
		HashGeneratorRequest request = new HashGeneratorRequest();
		request.setText("hashMe");
		
		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		ResponseEntity<?> generateHashValue = federatedAuthController.generateHashValue(request, 
				mockedBindingResult);
		assertNotNull(generateHashValue.getBody());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testGenerateHashValue_BindingErrors() {
		HashGeneratorRequest hashGenReq = new HashGeneratorRequest();
		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		Mockito.when(mockedBindingResult.hasErrors()).thenReturn(true);
		Mockito.when(mockedBindingResult.getFieldErrors()).thenReturn(new ArrayList<FieldError>());
		federatedAuthController.generateHashValue(hashGenReq, mockedBindingResult);
	}
	
	@Test
	public void testGetFederatedTokenCodes() {
		
		FederatedTokenRequest request = new FederatedTokenRequest();
		request.setCustomerUserType(true);
		request.setDateOfBirth("1998-01-01");
		request.setRefreshTokenRequired(true);
		request.setTokenCode("Old Token Code");
		
		FederatedTokenResponse response = new FederatedTokenResponse();
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("cmptcorrid", "correlation Key");
		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		Mockito.when(federatedAuthService.generateTokens(Mockito.eq(request), Mockito.any(String.class)))
				.thenReturn(response);
		ResponseEntity<?> federatedTokenCodes = federatedAuthController.getFederatedTokenCodes(request, mockedBindingResult, headers);
		assertNotNull(federatedTokenCodes.getBody());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testGetFederatedTokenCodes_BindingErrors() {
		FederatedTokenRequest tokenRequest = new FederatedTokenRequest();
		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		Mockito.when(mockedBindingResult.hasErrors()).thenReturn(true);
		Mockito.when(mockedBindingResult.getFieldErrors()).thenReturn(new ArrayList<FieldError>());
		federatedAuthController.getFederatedTokenCodes(tokenRequest, mockedBindingResult, new HttpHeaders());
	}
	
	@Test
	public void testUserRegistration() {
		FederatedUserRegisterRequest request = new FederatedUserRegisterRequest();
		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		FederatedUserRegisterResponse response = new FederatedUserRegisterResponse();
		Mockito.when(federatedAuthService.registerUser(Mockito.any(FederatedUserRegisterRequest.class), Mockito.any(HttpHeaders.class)))
			.thenReturn(response);
		ResponseEntity<?> userRegistration = federatedAuthController.userRegistration(request, mockedBindingResult, new HttpHeaders());
		assertNotNull(userRegistration);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testUserRegistration_BindingErrors() {
		FederatedUserRegisterRequest request = new FederatedUserRegisterRequest();
		BindingResult mockedBindingResult = Mockito.mock(BindingResult.class);
		Mockito.when(mockedBindingResult.hasErrors()).thenReturn(true);
		Mockito.when(mockedBindingResult.getFieldErrors()).thenReturn(new ArrayList<FieldError>());
		federatedAuthController.userRegistration(request, mockedBindingResult, new HttpHeaders());
	}

}
