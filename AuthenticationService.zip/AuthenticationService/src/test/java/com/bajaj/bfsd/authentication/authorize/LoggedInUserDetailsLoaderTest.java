package com.bajaj.bfsd.authentication.authorize;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.doReturn;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@RunWith(SpringRunner.class)
public class LoggedInUserDetailsLoaderTest {

	@InjectMocks
	private LoggedInUserDetailsLoader loggedInUserLoader;
	
	@Mock
	private TokenValidationUtil tokenValidationUtil;
	
	@Mock
	private BFLLoggerUtilExt logger;
	
	@Test
	public void testLoadUserByUsernameCustomer() {
		ValidateTokenResponse validateTokenResponseBean = new ValidateTokenResponse();
		validateTokenResponseBean.setLoginId("9999999999@1900-10-10");
		validateTokenResponseBean.setDefaultRole("customer");
		validateTokenResponseBean.setTokenStatus("VALID");
		validateTokenResponseBean.setUserId(1234l);

		ResponseEntity<?> tokenResponse = ResponseEntity.ok().body(validateTokenResponseBean);
		Mockito.when(tokenValidationUtil.isValidToken(Mockito.any(ResponseEntity.class)))
			.thenReturn(true);
		doReturn(tokenResponse).when(tokenValidationUtil)
			.getTokenValidity(Mockito.anyString());
		LoggedInUser loggedInUser = loggedInUserLoader.loadUserByUsername("customertoken");
		assertNotNull(loggedInUser);
	}
	
	@Test
	public void testLoadUserByUsernameEmployee() {
		ValidateTokenResponse validateTokenResponseBean = new ValidateTokenResponse();
		validateTokenResponseBean.setLoginId("9999999999@1900-10-10");
		validateTokenResponseBean.setDefaultRole(AuthenticationServiceConstants.EMPLOYEE);
		validateTokenResponseBean.setTokenStatus("VALID");
		validateTokenResponseBean.setUserId(1234l);

		ResponseEntity<?> tokenResponse = ResponseEntity.ok().body(validateTokenResponseBean);
		Mockito.when(tokenValidationUtil.isValidToken(Mockito.any(ResponseEntity.class)))
			.thenReturn(true);
		doReturn(tokenResponse).when(tokenValidationUtil)
			.getTokenValidity(Mockito.anyString());
		LoggedInUser loggedInUser = loggedInUserLoader.loadUserByUsername("employeetoken");
		assertNotNull(loggedInUser);
	}
	
	@Test
	public void testLoadUserByUsernameInternal() {
		ValidateTokenResponse validateTokenResponseBean = new ValidateTokenResponse();
		validateTokenResponseBean.setLoginId("9999999999@1900-10-10");
		validateTokenResponseBean.setDefaultRole("internal");
		validateTokenResponseBean.setTokenStatus("VALID");
		validateTokenResponseBean.setUserId(1234l);

		ResponseEntity<?> tokenResponse = ResponseEntity.ok().body(validateTokenResponseBean);
		Mockito.when(tokenValidationUtil.isValidToken(Mockito.any(ResponseEntity.class)))
			.thenReturn(true);
		doReturn(tokenResponse).when(tokenValidationUtil)
			.getTokenValidity(Mockito.anyString());
		LoggedInUser loggedInUser = loggedInUserLoader.loadUserByUsername("internaltoken");
		assertNotNull(loggedInUser);
	}

	@Test
	public void testLoadUserByUsernameInvalidToken() {
		Mockito.when(tokenValidationUtil.isValidToken(Mockito.any(ResponseEntity.class)))
			.thenReturn(false);
		LoggedInUser loggedInUser = loggedInUserLoader.loadUserByUsername("customertoken");
		assertNull(loggedInUser);
	}
}
