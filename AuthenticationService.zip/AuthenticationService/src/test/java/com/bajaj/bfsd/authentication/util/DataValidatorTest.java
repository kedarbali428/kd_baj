package com.bajaj.bfsd.authentication.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLHttpException;

@RunWith(SpringRunner.class)
public class DataValidatorTest {

	@InjectMocks
	private DataValidator dataValidator;
	
	@Mock
	BFLLoggerUtil logger;
	
	@Mock 
	private Environment env;

	@Test
	public void testValidateMobileValid() {
		boolean validateMobile = dataValidator.validateMobile("9999999999");
		assertTrue(validateMobile);
	}
	
	@Test
	public void testValidateMobileInValid() {
		boolean validateMobile = dataValidator.validateMobile("99999999");
		assertFalse(validateMobile);
	}

	@Test
	public void testValidateDateFieldAndReturnDateNullString() {
		Date date = dataValidator.validateDateFieldAndReturnDate("", "dd/MM/yy");
		assertNull(date);
	}
	
	@Test
	public void testValidateDateFieldAndReturnDateValidString() {
		Date date = dataValidator.validateDateFieldAndReturnDate("01/01/1988", "dd/MM/yy");
		assertNotNull(date);
	}
	
	@Test
	public void testValidateDateFieldAndReturnDateInValidFormat() {
		Date date = dataValidator.validateDateFieldAndReturnDate("09/05/1998", "");
		assertNull(date);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testGetDateFromDateStringNullFormatsArray() {
		dataValidator.validateDateFormats("01-05-1998", null, HttpStatus.BAD_REQUEST);
	}

	@Test
	public void testGetDateFromDateStringValidFormat() {
		Date date = dataValidator.validateDateFormats("01-05-1998", AuthenticationServiceConstants.APPONBOARDING_STATUS_VALID_DATEFORMATS,
				HttpStatus.BAD_REQUEST);
		assertNotNull(date);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testGetDateFromDateStringEmptyFormatsArray() {
		dataValidator.validateDateFormats("01-05-1998", new String[] {}, HttpStatus.BAD_REQUEST);
	}
}
