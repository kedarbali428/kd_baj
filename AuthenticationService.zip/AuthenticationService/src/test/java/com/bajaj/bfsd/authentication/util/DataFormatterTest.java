package com.bajaj.bfsd.authentication.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLBusinessException;


@RunWith(SpringJUnit4ClassRunner.class)
public class DataFormatterTest {

	@InjectMocks
	private DataFormatter formatter;
	
	@Mock
	private BFLLoggerUtil logger;
	
	@Mock
	private Environment env;
	
	@Test
	public void testDateStringToDate() {
		String dateFormat ="dd/MM/yyyy";
		String date ="01/02/1999";
		Date formattedDate = formatter.dateStringToDate(date, dateFormat);
		assertNotNull(formattedDate);
	}

	@Test(expected = BFLBusinessException.class)
	public void testDateStringToDate_InvalidFormat() {
		String dateFormat ="dd/MM/yyyy";
		String date ="01-02-1999";
		formatter.dateStringToDate(date, dateFormat);
	}

	@Test
	public void testDateStringToDate_NullDate() {
		String dateFormat ="dd/MM/yyyy";
		formatter.dateStringToDate(null, dateFormat);
	}

	@Test
	public void testDateToFormatedDateString() {
		String dateFormat ="dd/MM/yyyy";
		Date date = new Date();
		String formattedDate = formatter.dateToFormatedDateString(date, dateFormat);
		assertNotNull(formattedDate);
	}

	@Test
	public void testDateToFormatedDateString_NullDate() {
		String dateFormat ="dd/MM/yyyy";
		formatter.dateToFormatedDateString(null, dateFormat);
	}

	
	@Test
	public void testConvertDateStringtoSqlDate() {
		String dateFormat ="dd/MM/yyyy";
		String date ="01/02/1999";
		java.sql.Date formattedDate = formatter.convertDateStringtoSqlDate(date, dateFormat);
		assertEquals("1999-02-01", formattedDate.toString());
	}
}