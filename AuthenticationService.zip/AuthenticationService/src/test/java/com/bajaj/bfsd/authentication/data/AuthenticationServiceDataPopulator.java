package com.bajaj.bfsd.authentication.data;

import java.util.ArrayList;
import java.util.List;

import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV2;
import com.bajaj.bfsd.authentication.model.AadharLoginRequest;
import com.bajaj.bfsd.authentication.model.LoginAccount;
import com.bajaj.bfsd.authentication.model.MobileDobOtpLoginRequest;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.PartnerLoginRequest;
import com.bajaj.bfsd.authentication.model.SocialAuthenticationRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsResponse;
import com.bajaj.bfsd.authentication.model.SocialProfileResponse;
import com.bajaj.bfsd.authentication.model.SystemPartnerLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.model.UserLoginAccountResponse;

public class AuthenticationServiceDataPopulator {
	
	public static UserLoginAccountRequestV2 popUserLoginAccountRequestV2() {
		UserLoginAccountRequestV2 accountRequestV2 = new UserLoginAccountRequestV2();
		accountRequestV2.setDateOfBirth("03-06-2000");
		accountRequestV2.setLoginId("9182736450");
		accountRequestV2.setLoginType("");
		accountRequestV2.setPassword("8888");
		accountRequestV2.setSource("customer");
		accountRequestV2.setRtype("1");
		return accountRequestV2;
	}
	

	public static UserLoginAccountResponse popUserLoginAccountResponse() {
		UserLoginAccountResponse userLoginAccountResponse = new UserLoginAccountResponse();
		userLoginAccountResponse.setLoginId("9876543210");
		userLoginAccountResponse.setLoginFailCount((short)0);
		userLoginAccountResponse.setUserType((short)1);
		userLoginAccountResponse.setUserId(new Long(111));
		return userLoginAccountResponse;
	}
	
	
	public static TokenResponse popTokenResponse() {
		TokenResponse tokenResponse = new TokenResponse();
		List<Tokens> tokensList = new ArrayList<>();
		Tokens tokens = new Tokens(); 
		tokens.setToken("token");
		tokens.setGuardKey("gaurdKey");
		tokensList.add(tokens);
		tokenResponse.setUserKey(Long.valueOf("123456"));
		tokenResponse.setTokens(tokensList);
		return tokenResponse;
	}
	
	
	public static MobileDobOtpLoginRequest popMobileDobOtpLoginRequest() {
		MobileDobOtpLoginRequest loginRequest = new MobileDobOtpLoginRequest();
		loginRequest.setLoginId("9876543210");
		loginRequest.setDateOfBirth("02/02/1992");
		return loginRequest;
		
	}
	
	public static AadharLoginRequest popAdharLoginRequest() {
		AadharLoginRequest aadharLoginRequest = new AadharLoginRequest();
		aadharLoginRequest.setAadharNumber("123456789");
		aadharLoginRequest.setSource("src");
		return aadharLoginRequest;
	}
	
	public static LoginAccount popLoginAccount() {
		LoginAccount loginAccount = new LoginAccount();
		loginAccount.setLoginId("1234");
		loginAccount.setLoginType((short) 1);
		loginAccount.setUserId(new Long("1"));
		return loginAccount;
	}
	
	public static SocialProfileResponse popSocialProfileResponse() {
		SocialProfileResponse socialProfileResponse = new SocialProfileResponse();
		socialProfileResponse.setEmail("email");
		socialProfileResponse.setFirstName("name");
		socialProfileResponse.setJsonResponse("json");
		socialProfileResponse.setLastName("lastName");
		socialProfileResponse.setMiddleName("Mname");
		socialProfileResponse.setToken("token");
		return socialProfileResponse;
	}
	
	public static SocialAuthenticationRequest popSocialAuthenticationRequest() {
		SocialAuthenticationRequest authenticationRequest = new SocialAuthenticationRequest();
		authenticationRequest.setCode("code");
		authenticationRequest.setSource("source");
		authenticationRequest.setToken("token");
		authenticationRequest.setTarget("target");
		return authenticationRequest;
	}
	
	public static MobileLoginRequest popMobileLoginRequest() {
		MobileLoginRequest mobileLoginRequest = new MobileLoginRequest();
		mobileLoginRequest.setMobile("8888888888");
		mobileLoginRequest.setOtp("123456");
		mobileLoginRequest.setSource("Cust");
		return mobileLoginRequest;
	}
	
	public static PartnerLoginRequest popPartnerLoginRequest() {
		PartnerLoginRequest partnerLoginRequest= new PartnerLoginRequest();
		partnerLoginRequest.setPartnerKey("partnerKey");
		partnerLoginRequest.setSecretKey("secretKey");
		return partnerLoginRequest;
		
	}
	
	public static SystemPartnerLoginRequest popSystemPartnerLoginRequest() {
		SystemPartnerLoginRequest partnerLoginRequest= new SystemPartnerLoginRequest();
		partnerLoginRequest.setSecretKey("secretKey");
		partnerLoginRequest.setSystemPartnerKey("partnerKey");
		return partnerLoginRequest;
	}
	
	public static SocialLoginParamsResponse popSocialLoginParamsResponse() {
		SocialLoginParamsResponse loginParamsResponse= new SocialLoginParamsResponse();
		loginParamsResponse.setRedirectUrl("www.abc.com");
		return loginParamsResponse;
	}
	
}
