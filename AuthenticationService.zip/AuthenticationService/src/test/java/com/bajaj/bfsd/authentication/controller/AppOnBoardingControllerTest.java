package com.bajaj.bfsd.authentication.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginRequest;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingStatusRequest;
import com.bajaj.bfsd.authentication.bean.ApplicantKeysRequest;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UpdatePanProfileRequest;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.config.MapperFactory;
import com.bajaj.bfsd.authentication.exception.ControllerExceptionHandler;
import com.bajaj.bfsd.authentication.service.AppOnBoardingService;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.DataFormatter;
import com.bajaj.bfsd.authentication.util.DataValidator;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
public class AppOnBoardingControllerTest {

	@InjectMocks
	private AppOnBoardingController controller;
	
	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	private AppOnBoardingService appOnBoardingService;

	@Mock
	private DataValidator dataValidator;
	
	@Mock 
	private DataFormatter dataFormatter;
	
	@Mock
	private ControllerExceptionHandler excpetionHandler;

	private MockMvc mockMvc;
	
	private ObjectMapper mapper;
	
	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.standaloneSetup(controller)
				.setControllerAdvice(excpetionHandler)
				.addPlaceholderValue("api.authentication.appOnBoarding.POST.uri", "/v1/users/status")
				.addPlaceholderValue("api.authentication.appOnBoarding.login.POST.uri", "/v1/users/login")
				.addPlaceholderValue("api.authentication.appOnBoarding.usersProfile.POST.uri", "/v1/users/preregister")
				.addPlaceholderValue("api.authentication.appOnBoarding.usersProfile.PUT.uri", "/v1/users/preregister")
				.addPlaceholderValue("api.authentication.appOnBoarding.userspanprofile.POST.uri", "/v1/users/baseprofile")
				.addPlaceholderValue("api.authentication.appOnBoarding.userspanprofile.PUT.uri", "/v1/users/baseprofile")
				.build();
		mapper = MapperFactory.getInstance();
	}
	
	@Test
	public void testAppOnBoardingUserStatusSuccess() throws Exception {
		AppOnBoardingStatusRequest appOnBoardingStatus = new AppOnBoardingStatusRequest();
		appOnBoardingStatus.setDateOfBirth("01-01-1975");
		appOnBoardingStatus.setMobileNumber("9999999999");
		appOnBoardingStatus.setSource(AuthenticationServiceConstants.MOBILEAPP);
		mockMvc.perform(MockMvcRequestBuilders.post("/v1/users/status")
			.contentType(MediaType.APPLICATION_JSON)
			.content(mapper.writeValueAsString(appOnBoardingStatus)))
			.andExpect(MockMvcResultMatchers.status().isOk());
	}
	
	@Test(expected = AssertionError.class)
	public void testAppOnBoardingUserStatusValidationError() throws Exception {
		AppOnBoardingStatusRequest appOnBoardingStatus = new AppOnBoardingStatusRequest();
		appOnBoardingStatus.setSource(AuthenticationServiceConstants.MOBILEAPP);
		mockMvc.perform(MockMvcRequestBuilders.post("/v1/users/status")
			.contentType(MediaType.APPLICATION_JSON)
			.content(mapper.writeValueAsString(appOnBoardingStatus)))
			.andExpect(MockMvcResultMatchers.status().isBadRequest());
	}
	
	@Test
	public void testAppOnBoardingUserStatusEmptyDob() throws Exception {
		AppOnBoardingStatusRequest appOnBoardingStatus = new AppOnBoardingStatusRequest();
		appOnBoardingStatus.setMobileNumber("9999999999");
		appOnBoardingStatus.setSource(AuthenticationServiceConstants.MOBILEAPP);
		mockMvc.perform(MockMvcRequestBuilders.post("/v1/users/status")
			.contentType(MediaType.APPLICATION_JSON)
			.content(mapper.writeValueAsString(appOnBoardingStatus)))
			.andExpect(MockMvcResultMatchers.status().isOk());
	}


	@Test
	public void testAppOnBoardingLoginSuccess() throws Exception {
		AppOnBoardingLoginRequest request = new AppOnBoardingLoginRequest();
		request.setMobileNumber("9999999999");
		request.setSource("MOBILEAPP");
		request.setOtp("123456");
		mockMvc.perform(MockMvcRequestBuilders.post("/v1/users/login")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(request)))
				.andExpect(MockMvcResultMatchers.status().isOk());

	}
	
	@Test(expected = AssertionError.class)
	public void testAppOnBoardingLoginValidationError() throws Exception {
		AppOnBoardingLoginRequest request = new AppOnBoardingLoginRequest();
		request.setMobileNumber("999999999");
		mockMvc.perform(MockMvcRequestBuilders.post("/v1/users/login")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(request)))
				.andExpect(MockMvcResultMatchers.status().is4xxClientError());
	}

	@Test
	public void testGetProfileDetails() throws Exception {
		UserProfileDetailsRequest request = new UserProfileDetailsRequest();
		mockMvc.perform(MockMvcRequestBuilders.post("/v1/users/preregister")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(request)))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testUpdateProfileDetails() throws Exception {
		UpdateUserProfileDetailsRequest request = new UpdateUserProfileDetailsRequest();
		request.setSource("MOBAPP");
		mockMvc.perform(MockMvcRequestBuilders.put("/v1/users/preregister")
			.contentType(MediaType.APPLICATION_JSON)
			.content(mapper.writeValueAsString(request)))
			.andExpect(MockMvcResultMatchers.status().isOk());
	}
	
	@Test(expected = AssertionError.class)
	public void testUpdateProfileDetailsInvalidRequest() throws Exception {
		UpdateUserProfileDetailsRequest request = new UpdateUserProfileDetailsRequest();
		mockMvc.perform(MockMvcRequestBuilders.put("/v1/users/preregister")
			.contentType(MediaType.APPLICATION_JSON)
			.content(mapper.writeValueAsString(request)))
			.andExpect(MockMvcResultMatchers.status().is4xxClientError());
	}

	@Test
	public void testVerifyProfilePanDetails() throws Exception {
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		request.setPanNumber("AABBCCDD");
		request.setUserKeys(new ApplicantKeysRequest());
		mockMvc.perform(MockMvcRequestBuilders.post("/v1/users/baseprofile")
			.contentType(MediaType.APPLICATION_JSON)
			.content(mapper.writeValueAsString(request)))
			.andExpect(MockMvcResultMatchers.status().isOk());
	}
	
	@Test(expected = AssertionError.class)
	public void testVerifyProfilePanDetailsInvalidRequest() throws Exception {
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		mockMvc.perform(MockMvcRequestBuilders.post("/v1/users/baseprofile")
			.contentType(MediaType.APPLICATION_JSON)
			.content(mapper.writeValueAsString(request)))
			.andExpect(MockMvcResultMatchers.status().is4xxClientError());
	}
	
	@Test
	public void testUpdateProfilePanDetails() throws Exception {
		UpdatePanProfileRequest request = new UpdatePanProfileRequest();
		request.setPanNumber("AABBCCDD");
		request.setName("First Last");
		request.setPanVerifiedFlag(AuthenticationServiceConstants.YES);
		request.setPincode("12345");
		request.setUserKeys(new ApplicantKeysRequest());
		mockMvc.perform(MockMvcRequestBuilders.put("/v1/users/baseprofile")
			.contentType(MediaType.APPLICATION_JSON)
			.content(mapper.writeValueAsString(request)))
			.andExpect(MockMvcResultMatchers.status().isOk());
	}
	
	@Test(expected = AssertionError.class)
	public void testUpdateProfilePanDetailsInvalidRequest() throws Exception {
		UpdatePanProfileRequest request = new UpdatePanProfileRequest();
		mockMvc.perform(MockMvcRequestBuilders.put("/v1/users/baseprofile")
			.contentType(MediaType.APPLICATION_JSON)
			.content(mapper.writeValueAsString(request)))
			.andExpect(MockMvcResultMatchers.status().is4xxClientError());
	}

}
