package com.bajaj.bfsd.authentication.bean;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.bajaj.bfsd.authentication.LdapPropertiesConfigurer;
import com.bajaj.bfsd.authentication.authorize.AdditionalInfo;
import com.bajaj.bfsd.authentication.authorize.LoggedInUser;
import com.bajaj.bfsd.authentication.authorize.ValidateTokenResponse;
import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.Validator;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.rule.impl.GetterMustExistRule;
import com.openpojo.validation.rule.impl.SetterMustExistRule;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;

public class PojoTestUtils {

	@Test
	public void validateBeans() {
		Validator validator = ValidatorBuilder.create().with(new SetterMustExistRule(), new GetterMustExistRule())
				.with(new SetterTester(), new GetterTester()).build();
		validator.validate("com.bajaj.bfsd.authentication.bean");
		validator.validate(PojoClassFactory.getPojoClass(ValidateTokenResponse.class));
		validator.validate(PojoClassFactory.getPojoClass(LdapPropertiesConfigurer.class));
	}
	
	@Test
	public void validateAuthorizationBeans() {
		Validator validator = ValidatorBuilder.create().with(new GetterMustExistRule())
				.with(new GetterTester()).build();
		List<PojoClass>  classList = new ArrayList<>();
		classList.add(PojoClassFactory.getPojoClass(AdditionalInfo.class));
		classList.add(PojoClassFactory.getPojoClass(LoggedInUser.class));
		validator.validate(classList);
	}
	
	@Test
	public void validateEntity() {
		Validator validator = ValidatorBuilder.create().with(new SetterMustExistRule(), new GetterMustExistRule())
				.with(new SetterTester(), new GetterTester()).build();
		validator.validate("com.bajaj.bfsd.authentication.entity");
	}
	
	@Test
	public void validateModel() {
		Validator validator = ValidatorBuilder.create().with(new SetterMustExistRule(), new GetterMustExistRule())
				.with(new SetterTester(), new GetterTester()).build();
		validator.validate("com.bajaj.bfsd.authentication.model");
	}
	
}
