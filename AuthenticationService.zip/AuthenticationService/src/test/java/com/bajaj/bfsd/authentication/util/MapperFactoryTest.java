package com.bajaj.bfsd.authentication.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bajaj.bfsd.authentication.config.MapperFactory;

@RunWith(PowerMockRunner.class)
public class MapperFactoryTest {
	
	@InjectMocks
	MapperFactory mapperFactory;
	
	@Test
	public void testgetInstance() {
		mapperFactory.getInstance();
	}
	

}
