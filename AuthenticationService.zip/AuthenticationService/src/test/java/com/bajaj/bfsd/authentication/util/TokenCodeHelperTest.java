package com.bajaj.bfsd.authentication.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.doReturn;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.authentication.bean.TokensBean;
import com.bajaj.bfsd.authentication.bean.UserRequest;
import com.bajaj.bfsd.authentication.bean.UserResponse;
import com.bajaj.bfsd.authentication.model.GenerateTokenRequest;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.BFLCommonClientBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLHttpException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

@RunWith(PowerMockRunner.class)
@PrepareForTest(BFLCommonRestClient.class)
public class TokenCodeHelperTest {

	@InjectMocks
	private TokenCodeHelper tokenCodeHelper;
	
	@Mock
	private BFLLoggerUtil logger;
	
	@Mock
	private AppOnBoardingUtils appOnBoardingUtils;

	@Mock
	private RestClientUtil restClientUtil;

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(tokenCodeHelper, "getApplicantUrl", "http://localhost:8080/v2/applicants?mobile={mobile}&dateOfBirth={dateOfBirth}");
		ReflectionTestUtils.setField(tokenCodeHelper, "userAdditionalProfileUrl", "http://localhost:8080/v1/user");
		ReflectionTestUtils.setField(tokenCodeHelper, "generateTokenUrl", "http://localhost:8080/v1/tokens");
	}

	@Test
	public void testGetApplicant() {
		
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("mobile", "9988776655");
		queryParam.put("dateOfBirth", "1998-01-01");

		Object type = null;
		String requestJson = null;
		BFLCommonClientBean beans = null;
		
		JSONObject applicantKey =  new JSONObject();
		applicantKey.put("applicantKey", 1234L);
		
		ResponseEntity<String> mockedResponse = Mockito.mock(ResponseEntity.class);
 		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when((ResponseEntity<String>)BFLCommonRestClient.invokeRestEndpoint(Mockito.isA(HttpMethod.class),
				Mockito.anyString(), Mockito.eq(type), Mockito.any(), 
				Mockito.eq(queryParam), Mockito.eq(requestJson), Mockito.isA(HttpHeaders.class), Mockito.eq(beans)))
				.thenReturn(mockedResponse);
		
		Mockito.when(mockedResponse.getStatusCode()).thenReturn(HttpStatus.OK);
		Mockito.when(mockedResponse.getBody()).thenReturn(applicantKey.toString());

		Long applicantId = tokenCodeHelper.getApplicant("9988776655", "1998-01-01");
		assertNotNull(applicantId);
	}

	@Test
	public void testGetApplicant_NotFound() {
		
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("mobile", "9988776655");
		queryParam.put("dateOfBirth", "1998-01-01");

		Object type = null;
		String requestJson = null;
		BFLCommonClientBean beans = null;
		
		JSONObject applicantKey =  new JSONObject();
		applicantKey.put("applicantKey", JSONObject.NULL);
		
		ResponseEntity<String> mockedResponse = Mockito.mock(ResponseEntity.class);
 		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when((ResponseEntity<String>)BFLCommonRestClient.invokeRestEndpoint(Mockito.isA(HttpMethod.class),
				Mockito.anyString(), Mockito.eq(type), Mockito.any(), 
				Mockito.eq(queryParam), Mockito.eq(requestJson), Mockito.isA(HttpHeaders.class), Mockito.eq(beans)))
				.thenReturn(mockedResponse);
		
		Mockito.when(mockedResponse.getStatusCode()).thenReturn(HttpStatus.NOT_FOUND);
		Mockito.when(mockedResponse.getBody()).thenReturn(applicantKey.toString());

		Long applicantId = tokenCodeHelper.getApplicant("9988776655", "1998-01-01");
		assertNull(applicantId);
	}
	
	@Test
	public void testGetApplicant_UnknownError() {
		
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("mobile", "9988776655");
		queryParam.put("dateOfBirth", "1998-01-01");

		Object type = null;
		String requestJson = null;
		BFLCommonClientBean beans = null;
		
		JSONObject applicantKey =  new JSONObject();
		applicantKey.put("applicantKey", JSONObject.NULL);
		
		ResponseEntity<String> mockedResponse = Mockito.mock(ResponseEntity.class);
 		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when((ResponseEntity<String>)BFLCommonRestClient.invokeRestEndpoint(Mockito.isA(HttpMethod.class),
				Mockito.anyString(), Mockito.eq(type), Mockito.any(), 
				Mockito.eq(queryParam), Mockito.eq(requestJson), Mockito.isA(HttpHeaders.class), Mockito.eq(beans)))
				.thenReturn(mockedResponse);
		
		Mockito.when(mockedResponse.getStatusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(mockedResponse.getBody()).thenReturn(applicantKey.toString());

		Long applicantId = tokenCodeHelper.getApplicant("9988776655", "1998-01-01");
		assertNull(applicantId);
	}

	@Test
	public void testCallUserAdditionalDet() {
		MobileLoginRequest mobileRequest = new MobileLoginRequest();
		mobileRequest.setApplicationKey(12345L);
		mobileRequest.setDateOfBirth("1998-01-01");
		mobileRequest.setMobile("9988776655");
		
		Object type = null;
		BFLCommonClientBean beans = null;
		Map<String, String> queryParam = null;

		UserResponse userResponse = new UserResponse();
		
		UserRequest userRequest = new UserRequest();
		userRequest.setMobile(mobileRequest.getMobile());
		userRequest.setDateOfBirth(mobileRequest.getDateOfBirth());
		userRequest.setUserType((short)1);
		userRequest.setApplicationKey(mobileRequest.getApplicationKey());
		userRequest.setApplicantKey(12345L);

		JSONObject userRequestJson = new JSONObject(userRequest);

		
		ResponseEntity<UserResponse> mockedResponse = Mockito.mock(ResponseEntity.class);
 		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when((ResponseEntity<UserResponse>)BFLCommonRestClient.invokeRestEndpoint(Mockito.isA(HttpMethod.class),
				Mockito.anyString(), Mockito.eq(type), Mockito.any(), 
				Mockito.eq(queryParam), Mockito.eq(userRequestJson.toString()), Mockito.isA(HttpHeaders.class), Mockito.eq(beans)))
				.thenReturn(mockedResponse);
		Mockito.when(mockedResponse.getStatusCode()).thenReturn(HttpStatus.CREATED);
		Mockito.when(mockedResponse.getBody()).thenReturn(userResponse);
		

		UserResponse callUserAdditionalDet = tokenCodeHelper.callUserAdditionalDet(mobileRequest, (short)1, 12345L);
		assertNotNull(callUserAdditionalDet);
	}

	@Test(expected = BFLHttpException.class)
	public void testCallUserAdditionalDet_EmptyBody() {
		MobileLoginRequest mobileRequest = new MobileLoginRequest();
		mobileRequest.setApplicationKey(12345L);
		mobileRequest.setDateOfBirth("1998-01-01");
		mobileRequest.setMobile("9988776655");
		
		Object type = null;
		BFLCommonClientBean beans = null;
		Map<String, String> queryParam = null;

		
		UserRequest userRequest = new UserRequest();
		userRequest.setMobile(mobileRequest.getMobile());
		userRequest.setDateOfBirth(mobileRequest.getDateOfBirth());
		userRequest.setUserType((short)1);
		userRequest.setApplicationKey(mobileRequest.getApplicationKey());
		userRequest.setApplicantKey(12345L);

		JSONObject userRequestJson = new JSONObject(userRequest);
		
		ResponseEntity<UserResponse> mockedResponse = Mockito.mock(ResponseEntity.class);
 		PowerMockito.mockStatic(BFLCommonRestClient.class);
		Mockito.when((ResponseEntity<UserResponse>)BFLCommonRestClient.invokeRestEndpoint(Mockito.isA(HttpMethod.class),
				Mockito.anyString(), Mockito.eq(type), Mockito.any(), 
				Mockito.eq(queryParam), Mockito.eq(userRequestJson.toString()), Mockito.isA(HttpHeaders.class), Mockito.eq(beans)))
				.thenReturn(mockedResponse);
		Mockito.when(mockedResponse.getStatusCode()).thenReturn(HttpStatus.CREATED);
		
		tokenCodeHelper.callUserAdditionalDet(mobileRequest, (short)1, 12345L);
	}

	@Test
	public void testGetToken() throws JsonProcessingException {	
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		generateTokenReq.setLoginId("1");
		generateTokenReq.setUserId(1L);
		generateTokenReq.setUserType((short) 1);

		TokenResponse tokenResponse = new TokenResponse();
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(tokenResponse);
		responseBean.setStatus(StatusCode.SUCCESS);

		String authToken = "eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJCYWphakZpblNlcnYiLCJleHAiOjE2NDUxMDc2MTksImlhdCI6MTY0NTEwNTgxOSwic3ViIjoiYXV0aGVudGljYXRpb24iLCJsb2dpbiI6Ijk5NzU1MjQyMzMiLCJ1c2VyVHlwZSI6MX0.6EwxVBbRyGWV86u6ft_VFPC1QSeZsw4lnkhUFSXz0dU";
		String guardtoken = "D9diCjRWBi9q";
		TokensBean tokensBean = new TokensBean();
		tokensBean.setGuardToken(guardtoken);
		tokensBean.setStatus("VALID");
		tokensBean.setToken(authToken);
		ResponseBean responseBean1 = new ResponseBean();
		responseBean1.setPayload(tokensBean);
		responseBean1.setStatus(StatusCode.SUCCESS);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("guardtoken", guardtoken);
		httpHeaders.set("authtoken", authToken);

		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean1, HttpStatus.OK);

		ResponseBean responseTokenResponsebean = new ResponseBean();
		responseTokenResponsebean.setPayload(responseEntity);
		responseTokenResponsebean.setStatus(StatusCode.SUCCESS);

		ResponseEntity<ResponseBean> responseEntityTokenResponsebean = new ResponseEntity<ResponseBean>(
				responseTokenResponsebean, HttpStatus.OK);

		doReturn(responseEntityTokenResponsebean).when(restClientUtil).postCall(Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any());
		tokenCodeHelper.getToken("1", 1L, (short) 1);
	}

}
