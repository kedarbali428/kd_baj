package com.bajaj.bfsd.authentication.authorize;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@RunWith(SpringRunner.class)
public class TokenValidationUtilTests {

	@InjectMocks
	TokenValidationUtil tokenValidationUtil;

	@Mock
	RestTemplate restTemplate;
	
	@Mock
	BFLLoggerUtilExt logger;


	@Before
	public void setUp() {
		ReflectionTestUtils.setField(tokenValidationUtil, "tokenValidateUrl", "/v1/tokens/validation");
		ReflectionTestUtils.setField(tokenValidationUtil, "userAdditionalInfoUrl", "/v1/user?userId={userId}");
	}

	@Test
	public void testGetTokenValidity() {
		ValidateTokenResponse validateTokenResponseBean = new ValidateTokenResponse();
		validateTokenResponseBean.setLoginId("9999999999_1900-10-10");
		validateTokenResponseBean.setDefaultRole("pcustomer");
		validateTokenResponseBean.setTokenStatus("VALID");
		validateTokenResponseBean.setUserId(9999999999l);

		ResponseEntity<ValidateTokenResponse> tokenValidationResponse = new ResponseEntity<>(validateTokenResponseBean, HttpStatus.OK);
		Mockito.when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(ValidateTokenResponse.class)))
		.thenReturn(tokenValidationResponse);

		assertNotNull(tokenValidationUtil.getTokenValidity("authtoken"));
	}
	
	@Test
	public void testGetTokenValidityRestClientException() {
		ValidateTokenResponse validateTokenResponseBean = new ValidateTokenResponse();
		validateTokenResponseBean.setLoginId("9999999999_1900-10-10");
		validateTokenResponseBean.setDefaultRole("pcustomer");
		validateTokenResponseBean.setTokenStatus("VALID");
		validateTokenResponseBean.setUserId(9999999999l);

		Mockito.when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(ValidateTokenResponse.class)))
		.thenThrow(new RestClientException("rest Client Exception"));

		assertNull(tokenValidationUtil.getTokenValidity("authtoken"));
	}

	@Test
	public void testIsValidToken() {
		ValidateTokenResponse response = new ValidateTokenResponse();
		response.setLoginId("9999999999_1900-10-10");
		response.setDefaultRole("pcustomer");
		response.setTokenStatus("VALID");
		response.setUserId(9999999999l);

		ResponseEntity<?> tokenValidationResponse = new ResponseEntity<>(response, HttpStatus.OK);
		assertEquals(true, tokenValidationUtil.isValidToken(tokenValidationResponse));
	}

	@Test
	public void testIsValidToken_ResponseNotOK() {
		assertEquals(false, tokenValidationUtil.isValidToken(new ResponseEntity<>(null, HttpStatus.NOT_FOUND)));
	}

	@Test
	public void testIsValidToken_NoBody() {
		assertEquals(false, tokenValidationUtil.isValidToken(new ResponseEntity<>(null, HttpStatus.OK)));
	}

	@Test
	public void testIsValidToken_ExpiredToken() {
		ValidateTokenResponse response = new ValidateTokenResponse();
		response.setTokenStatus("EXPIRED");
		assertEquals(false, tokenValidationUtil.isValidToken(new ResponseEntity<>(response, HttpStatus.OK)));
	}

	@Test
	public void testGetAdditionalUserInfo() {
		ResponseEntity<AdditionalInfo> additionalInfoResponse = new ResponseEntity<>(new AdditionalInfo(), HttpStatus.OK);
		
		Mockito.when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(AdditionalInfo.class), Mockito.anyMapOf(String.class, Object.class)))
		.thenReturn(additionalInfoResponse);
		
		assertNotNull(tokenValidationUtil.getAdditionalUserInfo(999999999l));
	}
	
	@Test
	public void testgetEPAdditionalUserInfo() {
		ResponseEntity<AdditionalInfo> additionalInfoResponse = new ResponseEntity<>(new AdditionalInfo(), HttpStatus.OK);
		Mockito.when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(AdditionalInfo.class), Mockito.anyMapOf(String.class, Object.class)))
		.thenReturn(additionalInfoResponse);
		assertNotNull(tokenValidationUtil.getEPAdditionalUserInfo(999999999l,"EP"));
	}
	
	@Test
	public void testGetAdditionalUserInfo_NullPayload() {
		ResponseEntity<AdditionalInfo> additionalInfoResponse = new ResponseEntity<>(null, HttpStatus.OK);
		Mockito.when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(AdditionalInfo.class), Mockito.anyMapOf(String.class, Object.class)))
		.thenReturn(additionalInfoResponse);
		
		assertEquals(null, tokenValidationUtil.getAdditionalUserInfo(999999999l));
	}
	
	@Test
	public void testgetEPAdditionalUserInfo_NullPayload() {
		ResponseEntity<AdditionalInfo> additionalInfoResponse = new ResponseEntity<>(null, HttpStatus.OK);
		Mockito.when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(AdditionalInfo.class), Mockito.anyMapOf(String.class, Object.class)))
		.thenReturn(additionalInfoResponse);
		
		assertEquals(null, tokenValidationUtil.getEPAdditionalUserInfo(999999999l,"EP"));
	}
	
	@Test
	public void testGetAdditionalUserInfo_NotOk() {
		ResponseEntity<AdditionalInfo> additionalInfoResponse = new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(AdditionalInfo.class), Mockito.anyMapOf(String.class, Object.class)))
		.thenReturn(additionalInfoResponse);		
		assertEquals(null, tokenValidationUtil.getAdditionalUserInfo(999999999l));
	}
	
	@Test
	public void testEPGetAdditionalUserInfo_NotOk() {
		ResponseEntity<AdditionalInfo> additionalInfoResponse = new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(AdditionalInfo.class), Mockito.anyMapOf(String.class, Object.class)))
		.thenReturn(additionalInfoResponse);		
		
		assertEquals(null, tokenValidationUtil.getEPAdditionalUserInfo(999999999l,"EP"));
	}
	
	@Test
	public void testGetAdditionalUserInfo_Exception() {
		when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(AdditionalInfo.class), Mockito.anyMapOf(String.class, Object.class)))
		.thenThrow(new RestClientException("rest Client Exception"));
		
		assertEquals(null, tokenValidationUtil.getAdditionalUserInfo(999999999l));
	}
	
	@Test
	public void testEPGetAdditionalUserInfo_Exception() {
		when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(AdditionalInfo.class), Mockito.anyMapOf(String.class, Object.class)))
		.thenThrow(new RestClientException("rest Client Exception"));
		
		assertEquals(null, tokenValidationUtil.getEPAdditionalUserInfo(999999999l,"EP"));
	}
	
	@Test
	public void testGetTokenValidity_Exception() {
		when(restTemplate.exchange(Mockito.anyString(),
				Mockito.any(HttpMethod.class), Mockito.any(),
				Mockito.eq(AdditionalInfo.class), Mockito.anyMapOf(String.class, Object.class)))
		.thenThrow(new RestClientException("rest Client Exception"));

		assertNull(tokenValidationUtil.getTokenValidity("authtoken"));
	}
}
