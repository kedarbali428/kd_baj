package com.bajaj.bfsd.authentication.controller;

import java.math.BigDecimal;
import java.text.ParseException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bajaj.bfsd.authentication.bean.ApplicantUtmBean;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV3;
import com.bajaj.bfsd.authentication.entity.Applicant;
import com.bajaj.bfsd.authentication.entity.Application;
import com.bajaj.bfsd.authentication.service.EstoreAuthenticationService;
import com.bajaj.bfsd.authentication.util.EstoreAuthenticationHelper;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;

@RunWith(SpringJUnit4ClassRunner.class)
@PrepareForTest({ BFLCommonRestClient.class })
public class EstoreAuthenticationControllerTest {
	
	@InjectMocks
	EstoreAuthenticationController estoreAuthenticationController;
	
	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	EstoreAuthenticationService authService;
	
	@Mock
	EstoreAuthenticationHelper estoreAuthenticationHelper;
	
	@Mock
	private Environment env;
	
	@Test
	public void testestoreAuthenticationControllerwithonlymobile() throws ParseException
	{
		UserLoginAccountRequestV3 userLoginAccountRequestV3= new UserLoginAccountRequestV3();
		userLoginAccountRequestV3.setMobileNumber("9975524233");
		userLoginAccountRequestV3.setDateOfBirth("01/05/1989");
		HttpHeaders headers= new HttpHeaders();
		estoreAuthenticationController.estoreLogin(userLoginAccountRequestV3, headers, null, null, null, null, null, null);
	}
	
	@Test
	public void testestoreAuthenticationwithonlyotp() throws ParseException
	{
		UserLoginAccountRequestV3 userLoginAccountRequestV3= new UserLoginAccountRequestV3();
		userLoginAccountRequestV3.setMobileNumber("9975524233");
		userLoginAccountRequestV3.setDateOfBirth("01-05-1989");
		ApplicantUtmBean applicantUtmBean= new ApplicantUtmBean();
		applicantUtmBean.setApltAppSource(null);
		applicantUtmBean.setApltUtmCampaign(null);
		applicantUtmBean.setApltUtmContent(null);
		applicantUtmBean.setApltUtmMedium("Organic");
		applicantUtmBean.setApltUtmTerm(null);
		applicantUtmBean.setApplicantKey(0);
		applicantUtmBean.setEventType("Login");
		applicantUtmBean.setSourcePlatform(null);
		applicantUtmBean.getApltAppSource();
		applicantUtmBean.getApltUtmCampaign();
		applicantUtmBean.getApltUtmContent();
		applicantUtmBean.getApltUtmMedium();
		applicantUtmBean.getApltUtmSource();
		applicantUtmBean.getApltUtmTerm();
		applicantUtmBean.getApplicantKey();
		applicantUtmBean.getEventType();
		applicantUtmBean.getSourcePlatform();
		String loginId=userLoginAccountRequestV3.getMobileNumber();
		String dob=userLoginAccountRequestV3.getDateOfBirth();
		HttpHeaders headers= new HttpHeaders();
		int userCount=1;
		Mockito.when(authService.checkUserExistanceforEstore(loginId, dob)).thenReturn(userCount);
		estoreAuthenticationController.estoreLogin(userLoginAccountRequestV3, headers, null, null, null, null, null, null);
	}
	
	@Test
	public void testestoreAuthenticationControllerwithonlympin() throws ParseException
	{
		UserLoginAccountRequestV3 userLoginAccountRequestV3= new UserLoginAccountRequestV3();
		userLoginAccountRequestV3.setMobileNumber("9975524233");
		userLoginAccountRequestV3.setDateOfBirth("01/05/1989");
		Applicant applicant= new Applicant();
		applicant.setApltaadhaarcardnum(null);
		applicant.setApltcommprefchannel("dfsd");
		applicant.setApltcorecusid("23455");
		applicant.setApltcustcif("23456");
		applicant.setApltempid("3256");
		applicant.setApltfirstname("dsafsf");
		applicant.setApltgrossmthincome(new BigDecimal("43453"));
		applicant.setApltheight(new BigDecimal("44335"));
		applicant.setApltisempflag(new BigDecimal("1"));
		applicant.setSubsegmentkey(new BigDecimal("2343"));
		applicant.setSegkey(new BigDecimal("23"));
		applicant.setSalutationkey(new BigDecimal("23"));
		applicant.setReligion(new BigDecimal("234"));
		applicant.getApltaadhaarcardnum();
		applicant.getSubsegmentkey();
		applicant.getSegkey();
		applicant.getSalutationkey();
		applicant.getReligionoth();
		applicant.getPlaceofbirth();
		applicant.getMaritalstatuskey();
		Application application= new Application();
		application.setAppcoreaccnum("23455");
		application.setAppisactive(new BigDecimal("1"));
		application.setAppjourneystamp("add");
		application.setApplicationkey(2345);
		application.getProdcatkey();
		application.getBflbranchkey();
		application.getApputmsource();
		application.setApputmrefcode("sadas");
		application.getAppsource();
		application.getApprefnum();
		application.setApputmsource("sdfsd");
		application.getAppreferalcode();
		application.getAppisactive();
		application.getAppprocessidentifier();
		HttpHeaders headers= new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		estoreAuthenticationController.estoreLogin(userLoginAccountRequestV3, headers, null, null, null, null, null, null);
	}

}
