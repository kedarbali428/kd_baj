package com.bajaj.bfsd.authentication.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bfl.common.exceptions.BFLBusinessException;

@RunWith(PowerMockRunner.class)
public class AuthenticationServiceHelperTest {
	
	@InjectMocks
	AuthenticationServiceHelper authenticationServiceHelper;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	private Environment env;
	
	@Test
	public void testValidDOB() {
		assertEquals("2010-01-01", authenticationServiceHelper.checkAndValidateDate("2010-1-1", logger, env));
	}
	
	@Test
	public void testValidDOB1() {
		assertEquals("2010-01-01", authenticationServiceHelper.checkAndValidateDate("2010-01-1", logger, env));
	}
	
	@Test
	public void testValidDOB2() {
		assertEquals("2010-01-01", authenticationServiceHelper.checkAndValidateDate("2010-1-01", logger, env));
	}
	
	@Test
	public void testValidDOB3() {
		assertEquals("2010-01-01", authenticationServiceHelper.checkAndValidateDate("2010-01-01", logger, env));
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testValidDOB4() {
		assertEquals("2010-01-01", authenticationServiceHelper.checkAndValidateDate("2010-1", logger, env));
	}

}
