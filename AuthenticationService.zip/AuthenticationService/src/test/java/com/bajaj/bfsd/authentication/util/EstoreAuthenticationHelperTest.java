package com.bajaj.bfsd.authentication.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bfl.common.exceptions.BFLHttpException;

@RunWith(PowerMockRunner.class)
public class EstoreAuthenticationHelperTest {
	
	@InjectMocks
	EstoreAuthenticationHelper estoreAuthenticationHelper;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	Environment env;
	
	@Test
	public void testvalidateDate()
	{
		estoreAuthenticationHelper.validateDate("03-03-1993");
	}
	
	@Test
	public void testvalidateLoginPass()
	{
		estoreAuthenticationHelper.validateLoginPass("1111");
	}
	
	@Test(expected=BFLHttpException.class)
	public void testvalidateLoginPassException()
	{
		estoreAuthenticationHelper.validateLoginPass("11111");
	}
	
	

}
