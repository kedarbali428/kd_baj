package com.bajaj.bfsd.authentication.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;

import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.service.OMAuthenticationService;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.cache.service.AuthenticationSessionCacheService;
import com.bajaj.bfsd.common.cache.service.entity.SessionBean;

@SpringBootTest
@SpringBootConfiguration
@PropertySource(value={"classpath:appclient.properties"})
public class URLAuthenticationServiceControllerTest {

//	@InjectMocks
//	OMAuthenticationServiceController omAuthenticationServiceController;

	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	BFLLoggerUtil logger2;

	@Mock
	OMAuthenticationService omAuthenticationService;
	
	@Mock
	AuthenticationSessionCacheService authenticationSessionCacheService;
	
	@Mock
	Environment env;

	@InjectMocks
	URLAuthenticationServiceController urlAuthenticationServiceController;


	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		
	}
	
	@Test
	public void testAuthenticateURLMinutes() throws Exception {
		SessionBean sessionBean= new SessionBean();
		sessionBean.setApplicantKey("118697");
		sessionBean.setApplicationKey("1100000000001652");
		sessionBean.setDateOfBirth("1978-01-09");
		sessionBean.setMobileNumber(7474859597L);
		sessionBean.setRetryCount(3);
		sessionBean.setValidity(3L);
		sessionBean.setValidityUnit("MINUTES");
		Mockito.when(authenticationSessionCacheService.get(any())).thenReturn(null);
		assertEquals(HttpStatus.CREATED, urlAuthenticationServiceController.createSessionForAuthentication(sessionBean).getStatusCode());
	}
	
	@Test
	public void testAuthenticateURLSeconds() throws Exception {
		SessionBean sessionBean= new SessionBean();
		sessionBean.setApplicantKey("118697");
		sessionBean.setApplicationKey("1100000000001652");
		sessionBean.setDateOfBirth("1978-01-09");
		sessionBean.setMobileNumber(7474859597L);
		sessionBean.setRetryCount(3);
		sessionBean.setValidity(3L);
		sessionBean.setValidityUnit("SECONDS");
		Mockito.when(authenticationSessionCacheService.get(any())).thenReturn(null);
		assertEquals(HttpStatus.CREATED, urlAuthenticationServiceController.createSessionForAuthentication(sessionBean).getStatusCode());
	}
	
	@Test
	public void testAuthenticateURLHours() throws Exception {
		SessionBean sessionBean= new SessionBean();
		sessionBean.setApplicantKey("118697");
		sessionBean.setApplicationKey("1100000000001652");
		sessionBean.setDateOfBirth("1978-01-09");
		sessionBean.setMobileNumber(7474859597L);
		sessionBean.setRetryCount(3);
		sessionBean.setValidity(3L);
		sessionBean.setValidityUnit("HOURS");
		Mockito.when(authenticationSessionCacheService.get(any())).thenReturn(null);
		assertEquals(HttpStatus.CREATED, urlAuthenticationServiceController.createSessionForAuthentication(sessionBean).getStatusCode());
	}
	
	@Test
	public void testAuthenticateToken() throws Exception {
		SessionBean sessionBean= new SessionBean();
		sessionBean.setApplicantKey("118697");
		sessionBean.setApplicationKey("1100000000001652");
		sessionBean.setDateOfBirth("1978-01-09");
		sessionBean.setMobileNumber(7474859597L);
		sessionBean.setRetryCount(3);
		sessionBean.setValidity(3L);
		sessionBean.setValidityUnit("HOURS");
		Mockito.when(authenticationSessionCacheService.get(any())).thenReturn(sessionBean);
		
		TokenResponse tokenResp = new TokenResponse();
		List<Tokens> tokenList = new ArrayList<Tokens>();
		tokenList.add(new Tokens());
		tokenResp.setTokens(tokenList);
		
		Mockito.when(omAuthenticationService.authenticateMobDobAndGenerateToken(any())).thenReturn(tokenResp);
		assertEquals(HttpStatus.NO_CONTENT, urlAuthenticationServiceController.createSessionAuthenticationForLogin("dhghfgf").getStatusCode());
	}
}
