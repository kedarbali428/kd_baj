package com.bajaj.bfsd.authentication.util;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class PasswordEncoderUtilsTest {

	private static final Logger logger = LoggerFactory.getLogger(PasswordEncoderUtilsTest.class);

	@Test
	public void testPasswordEncoder() {
		PasswordEncoder passwordEncoder = PasswordEncoderUtils.getPasswordEncoder();

		Assert.assertNotNull("PasswordEncoder is null and not initialized", passwordEncoder);
		Assert.assertTrue("Wrong PasswordEncoder class", (passwordEncoder instanceof DelegatingPasswordEncoder));
	}

	@Test
	public void testEncode() {
		String rawPassword = UUID.randomUUID().toString();

		String encodedPassword = PasswordEncoderUtils.encode(rawPassword);

		Assert.assertNotNull("EncodedPassword is null", encodedPassword);
		Assert.assertNotSame("EncodedPassword is same as RawPassword", rawPassword, encodedPassword);
	}

	@Test
	public void testEncode_FixedRawPassword() {
		String rawPassword = "Bfdl@123";

		String encodedPassword = PasswordEncoderUtils.encode(rawPassword);

		logger.info("RawPassword: " + rawPassword + ", EncodedPassword: " + encodedPassword);
		Assert.assertNotNull("EncodedPassword is null", encodedPassword);
		Assert.assertNotSame("EncodedPassword is same as RawPassword", rawPassword, encodedPassword);
	}

	@Test
	public void testMatches() {
		String rawPassword = UUID.randomUUID().toString();

		String encodedPassword = PasswordEncoderUtils.encode(rawPassword);
		Assert.assertNotNull("EncodedPassword is null", encodedPassword);

		boolean matchFound = PasswordEncoderUtils.matches(rawPassword, encodedPassword);
		Assert.assertTrue("EncodedPassword didn't match with RawPassword", matchFound);
	}

	@Test
	public void testMatches_FixedRawPassword() {
		String rawPassword = "Bfdl@123";
		String encodedPassword = "{pbkdf2-v1}aKgJ31gVVSbzCFQVUZr+ATjFjp8qiwFr6u+VSrLQtUhGX/4EEbxOImUtbyVpk8UsL/UR/28AoTA61CvnoX51RAu1dtz0H7t7";

		boolean matchFound = PasswordEncoderUtils.matches(rawPassword, encodedPassword);
		Assert.assertTrue("EncodedPassword didn't match with RawPassword", matchFound);
	}

	@Test
	public void testMatchWorkFactor() {
		Map<String, String> passwordsMap = new HashMap<String, String>();
		int iterations = 10;
		long startTime1 = System.currentTimeMillis();
		for (int i = 0; i < iterations; i++) {
			String rawPassword = UUID.randomUUID().toString();
			String encodedPassword = PasswordEncoderUtils.encode(rawPassword);
			passwordsMap.put(rawPassword, encodedPassword);
		}
		long totalTime1 = (System.currentTimeMillis() - startTime1);
		logger.info("Iterations: " + iterations + ", Total Time-1: " + totalTime1 + ", Average Time-1 (per iteration):"
				+ (totalTime1 / iterations));

		String assertMessage = "EncodedPassword didn't match with RawPassword";
		long startTime2 = System.currentTimeMillis();
		for (Map.Entry<String, String> entry : passwordsMap.entrySet()) {
			boolean matchFound = PasswordEncoderUtils.matches(entry.getKey(), entry.getValue());
			Assert.assertTrue(assertMessage, matchFound);
		}
		long totalTime2 = (System.currentTimeMillis() - startTime2);
		logger.info("Iterations: " + iterations + ", Total Time-2: " + totalTime2 + ", Average Time-2 (per iteration):"
				+ (totalTime2 / iterations));
		
		long startTime3 = System.currentTimeMillis();
		for (Map.Entry<String, String> entry : passwordsMap.entrySet()) {
			boolean matchFound = PasswordEncoderUtils.matches(entry.getKey(), entry.getValue());
			Assert.assertTrue(assertMessage, matchFound);
		}
		long totalTime3 = (System.currentTimeMillis() - startTime3);
		logger.info("Iterations: " + iterations + ", Total Time-3: " + totalTime3 + ", Average Time-3 (per iteration):"
				+ (totalTime3 / iterations));
	}
}
