package com.bajaj.bfsd.authentication.service;

import java.math.BigDecimal;
import java.text.ParseException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV3;
import com.bajaj.bfsd.authentication.config.MapperFactory;
import com.bajaj.bfsd.authentication.dao.EstoreAuthenticationDao;
import com.bajaj.bfsd.authentication.model.Userapplicants;
import com.bajaj.bfsd.authentication.service.AuthenticationServiceImpl.AsyncClass;
import com.bajaj.bfsd.authentication.service.impl.EstoreAuthenticationServiceImpl;
import com.bajaj.bfsd.authentication.util.EstoreAuthenticationHelper;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@RunWith(PowerMockRunner.class)
@PrepareForTest({BFLCommonRestClient.class,Gson.class,EstoreAuthenticationHelper.class,MapperFactory.class})
public class EstoreAuthenticationServiceImplTest {
	
	@InjectMocks
	EstoreAuthenticationServiceImpl estoreAuthenticationServiceImpl;
	
	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	EstoreAuthenticationDao authenticationServiceDao;
	
	@Mock
	private AsyncClass asyncClass;
	
	@Mock
	private Environment env;
	
	@Mock
	HttpHeaders headers;
	
	@Mock
	ObjectMapper mapper;
	
	@Mock
	EstoreAuthenticationHelper estoreAuthenticationHelper;

	@Test
	public void testCheckUserExistance() {
		String loginId="98124675321";
		String dob="03/03/1992";
		Mockito.when(authenticationServiceDao.checkLoginIdExistanceForEstore(loginId,dob)).thenReturn(1);
		estoreAuthenticationServiceImpl.checkUserExistanceforEstore(loginId,dob);
	}
	
	@Test
	public void testMultipleCheckUserExistance() {
		String loginId="98124675321";
		String dob="03/03/1992";
		Mockito.when(authenticationServiceDao.checkLoginIdExistanceForEstore(loginId,dob)).thenReturn(2);
		estoreAuthenticationServiceImpl.checkUserExistanceforEstore(loginId,dob);
	}
	
	@Test
	public void testNoCheckUserExistance() {
		String loginId="98124675321";
		String dob="03/03/1992";
		Integer loginType=8;
		String rtype="1";
		Mockito.when(authenticationServiceDao.checkLoginIdExistanceForEstore(loginId,dob)).thenReturn(0);
		estoreAuthenticationServiceImpl.checkUserExistanceforEstore(loginId,dob);
	}
	
	@Test
	public void testLoginWithOtp() throws ParseException {
		UserLoginAccountRequestV3 accountRequestV3= new UserLoginAccountRequestV3();
		Integer loginType=8;
		String dob="03-03-1992";
		Mockito.when(authenticationServiceDao.checkLoginIdExistanceForEstore(accountRequestV3.getMobileNumber(),dob)).thenReturn(3);
		accountRequestV3.setDateOfBirth(dob);
		accountRequestV3.setMobileNumber("8600301504");
		ResponseBean responseBean = new ResponseBean();
		Object payload= "{payload :{status : failure}}";
		Userapplicants userapplicants= new Userapplicants();
		userapplicants.setApplicantkey(new BigDecimal("81812"));
		userapplicants.setUserapplicantkey(234567);
		userapplicants.setUserkey(new BigDecimal("24345"));
		userapplicants.getApplicantkey();
		userapplicants.getUserkey();
		userapplicants.getUserapplicantkey();
		responseBean.setPayload(payload);
		responseBean.setStatus(StatusCode.FAILURE);
		Mockito.when(authenticationServiceDao.checkLoginIdExistanceForEstore(accountRequestV3.getMobileNumber(), dob)).thenReturn(2);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		HttpHeaders headers= new HttpHeaders();
		Mockito.when(authenticationServiceDao.getuserApplicant(new BigDecimal("81812"))).thenReturn(userapplicants);
		PowerMockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		ResponseBean res=estoreAuthenticationServiceImpl.loginWithOtpEstore(accountRequestV3, null,headers);
		
	}
	

}
