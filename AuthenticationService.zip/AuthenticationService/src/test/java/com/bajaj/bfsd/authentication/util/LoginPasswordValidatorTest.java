package com.bajaj.bfsd.authentication.util;

import java.util.regex.Pattern;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
public class LoginPasswordValidatorTest {
	
	@InjectMocks
	LoginPasswordValidator loginPasswordValidator;
	 
	  private static Pattern patternPassword;
	  private static Pattern patternLogin;

	  private static final String PASSWORD_PATTERN =//NOSONAR
              "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
	  
	  private static final String LOGIN_PATTERN = "^(.+)@(.+)$";
	  
	  @Test
	  public void testvalidateLogin()
	  {
		  loginPasswordValidator.validateLogin("abc");
	  }
	  
	  @Test
	  public void testvalidatePassword()
	  {
		  loginPasswordValidator.validatePassword("abc");
	  }

}
