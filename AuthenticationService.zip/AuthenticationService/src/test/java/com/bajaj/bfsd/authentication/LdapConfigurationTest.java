package com.bajaj.bfsd.authentication;

import javax.naming.NamingException;
import javax.naming.NoInitialContextException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class LdapConfigurationTest {
	@InjectMocks
	private LdapConfiguration ldapConfiguration;
	
	@Mock
	LdapPropertiesConfigurer ldapPropertiesConfigurer;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test(expected = NoInitialContextException.class)
	public void testldapContextSource() throws NamingException {
		Mockito.when(ldapPropertiesConfigurer.getLdapFactClass()).thenReturn("");
		Mockito.when(ldapPropertiesConfigurer.getLdapUrl()).thenReturn("");
		Mockito.when(ldapPropertiesConfigurer.getLdapSecAuthType()).thenReturn("");
		Mockito.when(ldapPropertiesConfigurer.getLdapSecPrincipal()).thenReturn("");
		Mockito.when(ldapPropertiesConfigurer.getLdapUserPwd()).thenReturn("");
		ldapConfiguration.ldapContextSource();
	}

}
