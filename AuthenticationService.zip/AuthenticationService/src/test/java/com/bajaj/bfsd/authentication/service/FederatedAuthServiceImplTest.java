package com.bajaj.bfsd.authentication.service;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;

import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeRequest;
import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeResponse;
import com.bajaj.bfsd.authentication.bean.FederatedLoginRequest;
import com.bajaj.bfsd.authentication.bean.FederatedLoginResponse;
import com.bajaj.bfsd.authentication.bean.FederatedTokenRequest;
import com.bajaj.bfsd.authentication.bean.FederatedTokenResponse;
import com.bajaj.bfsd.authentication.bean.FederatedUserRegisterRequest;
import com.bajaj.bfsd.authentication.bean.FederatedUserRegisterResponse;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterResponse;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.RegisteredClients;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.repository.RegisteredClientsRepository;
import com.bajaj.bfsd.authentication.service.impl.FederatedAuthServiceImpl;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.AuthorizationCodeImpl;
import com.bajaj.bfsd.authentication.util.DataValidator;
import com.bajaj.bfsd.authentication.util.TokenCodeHelper;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringJUnit4ClassRunner.class)
public class FederatedAuthServiceImplTest {

	@InjectMocks
	private FederatedAuthServiceImpl federatedAuthServiceImpl;

	private Long loginAuthCodeExpiryInSeconds;
	
	private Long tokenCodeExpiryInSeconds;
	
	@Mock
	private Environment env;

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	private RegisteredClientsRepository registeredClientsRepository;

	@Mock
	private AuthorizationCodeImpl authCodeImpl;
		
	@Mock 
	private DataValidator datavalidator;

	@Mock
	private TokenCodeHelper tokenCodeHelper;

	@Mock
	private AuthenticationService authenticationService;
	
	@Before
	public void setUp() {
		ReflectionTestUtils.setField(federatedAuthServiceImpl, "loginAuthCodeExpiryInSeconds", 10L);
		ReflectionTestUtils.setField(federatedAuthServiceImpl, "tokenCodeExpiryInSeconds", 300L);
	}

	@Test
	public void testClientValidation() throws IOException {
		FederatedLoginRequest loginRequest = new FederatedLoginRequest();
		loginRequest.setAuthorizedClient("authorizedClient");
		loginRequest.setAuthorizedEmployeeCode("12234");
		loginRequest.setClientSecret("Bfdl@123");
		loginRequest.setClientId("clientId");
		loginRequest.setCustomerFlag(1);
		loginRequest.setMobile("9988776655");
		loginRequest.setPartnerCustomerId(12345);
		
		FederatedLoginResponse loginResponse = new FederatedLoginResponse();
		loginResponse.setAuthorizationCode("Authorization Code");
		
		RegisteredClients registeredClients = new RegisteredClients();
		registeredClients.setClientid("clientId");
		registeredClients.setClientsecret("{pbkdf2-v1}aKgJ31gVVSbzCFQVUZr+ATjFjp8qiwFr6u+VSrLQtUhGX/4EEbxOImUtbyVpk8UsL/UR/28AoTA61CvnoX51RAu1dtz0H7t7");
		registeredClients.setAssistancemode(0);
		registeredClients.setPartnercode("partnerCode");

		Mockito.when(registeredClientsRepository.findByClientidAndClientstatus(Mockito.anyString(), Mockito.eq(1)))
				.thenReturn(registeredClients);
		Mockito.when(authCodeImpl.createAuthCode(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyString()))
				.thenReturn("Authorization Code");
		FederatedLoginResponse clientValidation = federatedAuthServiceImpl.clientValidation(loginRequest);
		assertNotNull(clientValidation.getAuthorizationCode());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testClientValidation_AssistanceModeFailure() {
		FederatedLoginRequest loginRequest = new FederatedLoginRequest();
		loginRequest.setAuthorizedClient("authorizedClient");
		loginRequest.setAuthorizedEmployeeCode(null);
		loginRequest.setClientId("clientId");

		RegisteredClients registeredClients = new RegisteredClients();
		registeredClients.setClientid("clientId");
		registeredClients.setAssistancemode(1);

		Mockito.when(registeredClientsRepository.findByClientidAndClientstatus(Mockito.anyString(), Mockito.eq(1)))
			.thenReturn(registeredClients);
		federatedAuthServiceImpl.clientValidation(loginRequest);
	}

	@Test(expected = BFLHttpException.class)
	public void testClientValidation_CustomerFlagFailure() {
		FederatedLoginRequest loginRequest = new FederatedLoginRequest();
		loginRequest.setAuthorizedClient("authorizedClient");
		loginRequest.setAuthorizedEmployeeCode("12234");
		loginRequest.setClientId("clientId");
		loginRequest.setCustomerFlag(1);
		loginRequest.setPartnerCustomerId(null);

		RegisteredClients registeredClients = new RegisteredClients();
		registeredClients.setClientid("clientId");
		registeredClients.setAssistancemode(1);

		Mockito.when(registeredClientsRepository.findByClientidAndClientstatus(Mockito.anyString(), Mockito.eq(1)))
			.thenReturn(registeredClients);
		federatedAuthServiceImpl.clientValidation(loginRequest);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testClientValidation_PasswordDoNotMatch() {
		FederatedLoginRequest loginRequest = new FederatedLoginRequest();
		loginRequest.setAuthorizedClient("authorizedClient");
		loginRequest.setAuthorizedEmployeeCode("12234");
		loginRequest.setClientSecret("Bfdl@123");
		loginRequest.setClientId("clientId");
		loginRequest.setCustomerFlag(1);
		loginRequest.setMobile("9988776655");
		loginRequest.setPartnerCustomerId(12345);
		
		FederatedLoginResponse loginResponse = new FederatedLoginResponse();
		loginResponse.setAuthorizationCode("Authorization Code");
		
		RegisteredClients registeredClients = new RegisteredClients();
		registeredClients.setClientid("clientId");
		registeredClients.setClientsecret("{pbkdf2-v1}Duh5zGjnkISs/lG33w8LH2h0NzKNehuvZ+M5YOziMEtV5Zd7SAkrx00LBWE0vPXcOAxTHmmZ/R8+uN8WRQNtA9dMwQltkG51");
		registeredClients.setAssistancemode(0);
		registeredClients.setPartnercode("partnerCode");

		Mockito.when(registeredClientsRepository.findByClientidAndClientstatus(Mockito.anyString(), Mockito.eq(1)))
				.thenReturn(registeredClients);
		
		federatedAuthServiceImpl.clientValidation(loginRequest);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testClientValidation_NoActiveClientFound() {
		FederatedLoginRequest loginRequest = new FederatedLoginRequest();
		loginRequest.setClientId("clientId");
				
		Mockito.when(registeredClientsRepository.findByClientidAndClientstatus(Mockito.anyString(), Mockito.eq(1)))
				.thenReturn(null);
		
		federatedAuthServiceImpl.clientValidation(loginRequest);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testClientValidation_ThrowsException() {
		FederatedLoginRequest loginRequest = new FederatedLoginRequest();
		loginRequest.setClientId("clientId");
				
		Mockito.when(registeredClientsRepository.findByClientidAndClientstatus(Mockito.anyString(), Mockito.eq(1)))
				.thenThrow(NullPointerException.class);
		
		federatedAuthServiceImpl.clientValidation(loginRequest);
	}
	
	@Test
	public void testValidateAuthorization() throws IOException {
		FederatedAuthorizeRequest request = new FederatedAuthorizeRequest();
		request.setAuthorizationCode("AuthorizationCode");
		request.setClientId("clientId");
		
		FederatedAuthorizeResponse response = new FederatedAuthorizeResponse();
		response.setAssistanceMode(false);
		response.setAuthorizedClient("authorizedClient");
		response.setAuthorizedEmployeeCode("12234");
		response.setCustomerFlag("true");
		response.setMobile("9988776655");
		response.setTokenCode("New Token Code");
		response.setPartnerCode("partnerCode");
		response.setPartnerCustomerId("12345");

		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
				.thenReturn(true);
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
				.thenReturn(response);
		Mockito.when(authCodeImpl.createAuthCode(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyString()))
				.thenReturn("New Auth Token");
		
		FederatedAuthorizeResponse authorizationResponse = federatedAuthServiceImpl.validateAuthorization(request);
		
		assertNotNull(authorizationResponse);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testValidateAuthorization_InvalidRequestCode() {
		FederatedAuthorizeRequest request = new FederatedAuthorizeRequest();
		request.setAuthorizationCode("AuthorizationCode");
		request.setClientId("clientId");
		
		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
				.thenReturn(false);
		
		federatedAuthServiceImpl.validateAuthorization(request);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testValidateAuthorization_CachedCodeRetriedNull() throws IOException {
		FederatedAuthorizeRequest request = new FederatedAuthorizeRequest();
		request.setAuthorizationCode("AuthorizationCode");
		request.setClientId("clientId");
		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
			.thenReturn(true);
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
			.thenReturn(null);
		
		federatedAuthServiceImpl.validateAuthorization(request);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testValidateAuthorization_CachedCodeRetrievalException() throws IOException {
		FederatedAuthorizeRequest request = new FederatedAuthorizeRequest();
		request.setAuthorizationCode("AuthorizationCode");
		request.setClientId("clientId");
		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
			.thenReturn(true);
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
			.thenThrow(NullPointerException.class);
		
		federatedAuthServiceImpl.validateAuthorization(request);
	}

	@Test(expected = BFLHttpException.class)
	public void testGetCachedAuthCode_ThrowsException() throws IOException {
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
				.thenThrow(IOException.class);
		federatedAuthServiceImpl.getCachedAuthCode("Some Valid Auth Code");
	}
	
	@Test
	public void testGenerateTokens() throws IOException {
		FederatedTokenRequest tokenRequest = new FederatedTokenRequest();
		tokenRequest.setCustomerUserType(true);
		tokenRequest.setDateOfBirth("1997-01-02");
		tokenRequest.setTokenCode("Old Token Code");
		tokenRequest.setRefreshTokenRequired(true);
		
		FederatedAuthorizeResponse response = new FederatedAuthorizeResponse();
		response.setMobile("9977665588");
		
		Tokens token1 = new Tokens();
		token1.setType(AuthenticationServiceConstants.AUTH_TOKEN);
		
		Tokens token2 = new Tokens();
		token2.setType(AuthenticationServiceConstants.REFRESH_TOKEN);

		List<Tokens> tokenList = new ArrayList<Tokens>();
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setDefaultRole("customer");
		tokenList.add(token1);
		tokenList.add(token2);
		tokenResponse.setTokens(tokenList);
		
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
				.thenReturn(response);
		
		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
				.thenReturn(true);

		Mockito.when(tokenCodeHelper.generateTokens(Mockito.any(MobileLoginRequest.class),
				Mockito.any(HttpHeaders.class), Mockito.anyShort()))
				.thenReturn(tokenResponse);
		Mockito.when(datavalidator.validateDateFieldAndReturnDate(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(new Date());
		FederatedTokenResponse generateFederatedTokenCodes = federatedAuthServiceImpl.generateTokens(tokenRequest, "Correlation Key");
		assertNotNull(generateFederatedTokenCodes);
	}

	
	@Test(expected = BFLHttpException.class)
	public void testGenerateTokens_InvalidToken() {
		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
			.thenReturn(false);
		federatedAuthServiceImpl.generateTokens(new FederatedTokenRequest(), "cmptCorrelationId");
	}
	
	@Test(expected = BFLHttpException.class)
	public void testGenerateTokens_CachedCodeNotFound() throws IOException {
		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
				.thenReturn(true);
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
				.thenReturn(null);
		federatedAuthServiceImpl.generateTokens(new FederatedTokenRequest(), "cmptCorrelationId");

	}
	
	@Test(expected = BFLHttpException.class)
	public void testGenerateTokens_SomeException() {
		Mockito.when(tokenCodeHelper.generateTokens(Mockito.any(MobileLoginRequest.class), 
				Mockito.any(HttpHeaders.class), Mockito.anyShort()))
				.thenThrow(RestClientException.class);
		federatedAuthServiceImpl.generateTokens(new FederatedTokenRequest(), "cmptCorrelationId");
	}
	
	@Test
	public void testRegisterUser() throws IOException {
		NtpPreRegisterRequest preRegisterRequest = new NtpPreRegisterRequest();
		preRegisterRequest.setDateOfBirth("1991-02-01");
		preRegisterRequest.setMobileNumber("9977554433");
		preRegisterRequest.setCustomerReferenceID("1234");
		FederatedUserRegisterRequest request = new FederatedUserRegisterRequest();
		request.setClientId("BFDL_MarketsApp");
		request.setAuthorizationCode("Some Auth Code");
		request.setPreRegisterRequest(preRegisterRequest);
		
		FederatedAuthorizeResponse authorizeResponse = new FederatedAuthorizeResponse();
		authorizeResponse.setMobile("9977554433");
		authorizeResponse.setCustomerFlag("1");
		authorizeResponse.setPartnerCustomerId("1234");
		
		Tokens token1 = new Tokens();
		token1.setType(AuthenticationServiceConstants.AUTH_TOKEN);
		
		Tokens token2 = new Tokens();
		token2.setType(AuthenticationServiceConstants.REFRESH_TOKEN);

		List<Tokens> tokenList = new ArrayList<Tokens>();
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setDefaultRole("customer");
		tokenList.add(token1);
		tokenList.add(token2);
		tokenResponse.setTokens(tokenList);
		
		
		NtpPreRegisterResponse registerResponse = new NtpPreRegisterResponse();
		registerResponse.setDateOfBirth("1991-02-01");
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.SUCCESS);
		responseBean.setPayload(registerResponse);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
			.thenReturn(true);
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
			.thenReturn(authorizeResponse);
		Mockito.when(authCodeImpl.createAuthCode(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyString()))
			.thenReturn("New Auth Token");

		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(NtpPreRegisterRequest.class),
				Mockito.eq(null), Mockito.eq(null), Mockito.any(HttpHeaders.class)))
			.thenReturn(responseEntity);
		Mockito.when(datavalidator.validateDateFieldAndReturnDate(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(new Date());

		Mockito.when(tokenCodeHelper.generateTokens(Mockito.any(MobileLoginRequest.class),
				Mockito.any(HttpHeaders.class), Mockito.anyShort()))
				.thenReturn(tokenResponse);

		FederatedUserRegisterResponse registerUser = federatedAuthServiceImpl.registerUser(request, new HttpHeaders());
		assertNotNull(registerUser);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testRegisterUser_InvalidUser() throws IOException {
		NtpPreRegisterRequest preRegisterRequest = new NtpPreRegisterRequest();
		preRegisterRequest.setDateOfBirth("1991-02-01");
		preRegisterRequest.setMobileNumber("9973554433");
		preRegisterRequest.setCustomerReferenceID("1234");
		FederatedUserRegisterRequest request = new FederatedUserRegisterRequest();
		request.setClientId("BFDL_MarketsApp");
		request.setAuthorizationCode("Some Auth Code");
		request.setPreRegisterRequest(preRegisterRequest);
		
		FederatedAuthorizeResponse authorizeResponse = new FederatedAuthorizeResponse();
		authorizeResponse.setMobile("9977554433");
		authorizeResponse.setCustomerFlag("1");
		authorizeResponse.setPartnerCustomerId("1234");
		
			
		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
			.thenReturn(true);
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
			.thenReturn(authorizeResponse);
		Mockito.when(authCodeImpl.createAuthCode(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyString()))
			.thenReturn("New Auth Token");

		federatedAuthServiceImpl.registerUser(request, new HttpHeaders());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testRegisterUser_ExceptionInNtpPreRegister() throws IOException {
		NtpPreRegisterRequest preRegisterRequest = new NtpPreRegisterRequest();
		preRegisterRequest.setDateOfBirth("1991-02-01");
		preRegisterRequest.setMobileNumber("9977554433");
		FederatedUserRegisterRequest request = new FederatedUserRegisterRequest();
		request.setClientId("BFDL_MarketsApp");
		request.setAuthorizationCode("Some Auth Code");
		request.setPreRegisterRequest(preRegisterRequest);
		
		FederatedAuthorizeResponse authorizeResponse = new FederatedAuthorizeResponse();
		authorizeResponse.setMobile("9977554433");
		authorizeResponse.setCustomerFlag("1");
		authorizeResponse.setPartnerCustomerId("1234");
		
		NtpPreRegisterResponse registerResponse = new NtpPreRegisterResponse();
		registerResponse.setDateOfBirth("1991-02-01");

		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
			.thenReturn(true);
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
			.thenReturn(authorizeResponse);
		Mockito.when(authCodeImpl.createAuthCode(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyString()))
			.thenReturn("New Auth Token");

		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(NtpPreRegisterRequest.class),
				Mockito.eq(null), Mockito.eq(null), Mockito.any(HttpHeaders.class)))
			.thenThrow(BFLTechnicalException.class);

		federatedAuthServiceImpl.registerUser(request, new HttpHeaders());
	}

	@Test(expected = BFLHttpException.class)
	public void testRegisterUser_InvalidNtpRegisterResponse() throws IOException {
		NtpPreRegisterRequest preRegisterRequest = new NtpPreRegisterRequest();
		preRegisterRequest.setDateOfBirth("1991-02-01");
		preRegisterRequest.setMobileNumber("9977554433");
		preRegisterRequest.setCustomerReferenceID("1234");
		FederatedUserRegisterRequest request = new FederatedUserRegisterRequest();
		request.setClientId("BFDL_MarketsApp");
		request.setAuthorizationCode("Some Auth Code");
		request.setPreRegisterRequest(preRegisterRequest);
		
		FederatedAuthorizeResponse authorizeResponse = new FederatedAuthorizeResponse();
		authorizeResponse.setMobile("9977554433");
		authorizeResponse.setCustomerFlag("0");
		authorizeResponse.setPartnerCustomerId("1234");
		
		List<ErrorBean> errors = new ArrayList<>();
 		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.FAILURE);
		responseBean.setErrorBean(errors);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.CONFLICT);
		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
			.thenReturn(true);
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
			.thenReturn(authorizeResponse);
		Mockito.when(authCodeImpl.createAuthCode(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyString()))
			.thenReturn("New Auth Token");

		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(NtpPreRegisterRequest.class),
				Mockito.eq(null), Mockito.eq(null), Mockito.any(HttpHeaders.class)))
			.thenReturn(responseEntity);
		federatedAuthServiceImpl.registerUser(request, new HttpHeaders());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testRegisterUser_JsonException() throws IOException {
		NtpPreRegisterRequest preRegisterRequest = new NtpPreRegisterRequest();
		preRegisterRequest.setDateOfBirth("1991-02-01");
		preRegisterRequest.setMobileNumber("9977554433");
		preRegisterRequest.setCustomerReferenceID("1234");
		FederatedUserRegisterRequest request = new FederatedUserRegisterRequest();
		request.setClientId("BFDL_MarketsApp");
		request.setAuthorizationCode("Some Auth Code");
		request.setPreRegisterRequest(preRegisterRequest);
		
		FederatedAuthorizeResponse authorizeResponse = new FederatedAuthorizeResponse();
		authorizeResponse.setMobile("9977554433");
		authorizeResponse.setCustomerFlag("1");
		authorizeResponse.setPartnerCustomerId("1234");
		
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.SUCCESS);
		responseBean.setPayload("{\"name: \"Some Name\"}");
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(authCodeImpl.validateAuthCode(Mockito.anyString()))
			.thenReturn(true);
		Mockito.when(authCodeImpl.getCacheAuthCode(Mockito.anyString()))
			.thenReturn(authorizeResponse);
		Mockito.when(authCodeImpl.createAuthCode(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyString()))
			.thenReturn("New Auth Token");

		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(NtpPreRegisterRequest.class),
				Mockito.eq(null), Mockito.eq(null), Mockito.any(HttpHeaders.class)))
			.thenReturn(responseEntity);

		 federatedAuthServiceImpl.registerUser(request, new HttpHeaders());
	}

	@Test(expected = Test.None.class)
	public void testPopulateFederatedUserRegisterUtmHeaders() {
		federatedAuthServiceImpl.populateFederatedUserRegisterUtmHeaders(new HttpHeaders(), "clientId");
	}
	
	@Test(expected = Test.None.class)
	public void testPopulateFederatedUserRegisterUtmHeadersHeadersPresent() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("utm_source", "Organic");
		headers.set("app_source", "clientId");
		headers.set("platform", "FEDERATED");
		federatedAuthServiceImpl.populateFederatedUserRegisterUtmHeaders(headers, "clientId");
	}
}
