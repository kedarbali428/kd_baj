package com.bajaj.bfsd.authentication.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeResponse;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLHttpException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@RunWith(SpringJUnit4ClassRunner.class)
public class AuthorizationCodeImplTest {
	
	@InjectMocks
	private AuthorizationCodeImpl codeImpl;
	
	private String authCodeJwtSecret;

	private String cachePrefix;

	@Mock
	private BFLLoggerUtil logger;

	@Mock
	private RedisTemplate<String, String> redisTemplate;

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(codeImpl, "authCodeJwtSecret", "Jwtsecret");
		ReflectionTestUtils.setField(codeImpl, "cachePrefix", "PREFIX::");
	}
	
	@Test
	public void testCreateAuthCode() throws IOException {
		String createdAuthCode = codeImpl.createAuthCode("issuer", "clientId", 10, "9999999999");
		assertNotNull(createdAuthCode);
	}

	@Test(expected=Test.None.class)
	public void testCacheAuthCode() throws IOException {
		ValueOperations<String, String> valueOps = Mockito.mock(ValueOperations.class);
		Mockito.when(redisTemplate.opsForValue()).thenReturn(valueOps);
		codeImpl.cacheAuthCode("Auth Code", new FederatedAuthorizeResponse(), 10L);
	}

	@Test
	public void testGetCacheAuthCode() throws JsonParseException, JsonMappingException, IOException {
		FederatedAuthorizeResponse response = new FederatedAuthorizeResponse();
		JSONObject cachedString = new JSONObject(response);
		ValueOperations<String, String> valueOps = Mockito.mock(ValueOperations.class);
		Mockito.when(redisTemplate.opsForValue()).thenReturn(valueOps);
		Mockito.when(valueOps.get(Mockito.anyString()))
				.thenReturn(cachedString.toString());
		
		FederatedAuthorizeResponse cacheAuthCode = codeImpl.getCacheAuthCode("Valid Auth Code");
		assertNotNull(cacheAuthCode);
	}

	@Test
	public void testValidateAuthCode_Valid() {
		String token = "eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjQ3ODMyNTk1MDQsIm5vbmNlIjoiZTk"
				+ "5YjE1OGQtZWQ2Yy00ODhkLWJhM2UtN2Y1OTNmMDZlNTk2In0.cJkSk8yIYiPbPK0at5BB"
				+ "Ghz5Pr5quwTGP2DWlCMPKl11DQJl7xVMmDIhF4WwBpYvzZ3Kn8yksxVbAVPwTN1QPg";
		boolean validateAuthCode = codeImpl.validateAuthCode(token);
		assertTrue(validateAuthCode);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testValidateAuthCode_Invalid() {
		String token = "eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjQ3ODMyNTk1MDQsIm5vbmNlIjoiZTk"
				+ "5YjE1OGQtZWQ2Yy00ODhkLWJhM2UtN2Y1OTNmMDZlNTk2In0.cJkSk8yIYiPbPK0at5BB"
				+ "Ghz5Pr5quwTGP2DWlCMPKl11DQJl7xVMmDIhF4WwBpYvzZ3Kn8yksxVbA3PwTN1QPg";
		codeImpl.validateAuthCode(token);
	}

}
