package com.bajaj.bfsd.authentication.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.text.ParseException;

import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.client.RestClientException;

import com.bajaj.bfsd.authentication.bean.NtpLoginRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreProcessRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterRes;
import com.bajaj.bfsd.authentication.bean.SystemTokenRequest;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV2;
import com.bajaj.bfsd.authentication.data.AuthenticationServiceDataPopulator;
import com.bajaj.bfsd.authentication.model.AadharLoginRequest;
import com.bajaj.bfsd.authentication.model.LoginAccount;
import com.bajaj.bfsd.authentication.model.LoginSecretKeyResponse;
import com.bajaj.bfsd.authentication.model.MobileDobOtpLoginRequest;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.PartnerLoginRequest;
import com.bajaj.bfsd.authentication.model.SocialAuthenticationRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsResponse;
import com.bajaj.bfsd.authentication.model.SocialProfileResponse;
import com.bajaj.bfsd.authentication.model.SystemPartnerLoginRequest;
import com.bajaj.bfsd.authentication.model.TemporaryTokenRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.UserLoginAccountRequest;
import com.bajaj.bfsd.authentication.model.UserLoginAccountResponse;
import com.bajaj.bfsd.authentication.service.AuthenticationService;
import com.bajaj.bfsd.authentication.service.LoginAccountBuilder;
import com.bajaj.bfsd.authentication.service.OMAuthenticationService;
import com.bajaj.bfsd.authentication.util.AppOnBoardingUtils;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceHelper;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AuthenticationServiceHelper.class})
public class AuthenticationServiceControllerTest {
	@InjectMocks
	AuthenticationServiceController authenticationServiceController;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	 Environment env;
	
	@Mock
	JSONObject aadharProfile;
	
	@Mock
	CustomDefaultHeaders custmHeaders;
	
	@Mock
	LoginAccountBuilder loginAcctBuilder;


	@Mock
	private AuthenticationService authService;
	@Mock
	private OMAuthenticationService omAuthenticationService;
	
	@Mock
	private HttpHeaders headers;
	
	@Mock
	BindingResult result;
	
	@Mock
	BFLLoggerUtil loggerUtil;
	
	@Mock
	ResponseEntity<ResponseBean> responseEntity;
	
	@Mock
	private AppOnBoardingUtils appOnBoardingUtils;
	
	
	/**Postive test scenario for mobile login when rType is 1
	 * @throws ParseException 
	 * 
	 */
	@Test(expected=BFLBusinessException.class)
	public void testMobileLoginRType1() throws ParseException {
		UserLoginAccountRequestV2 loginAccountRequestV2= AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		ResponseEntity<ResponseBean> responseEntity=authenticationServiceController.mobileLogin(loginAccountRequestV2, headers, null, null, null, null, null, null);
    	assertEquals("Success", responseEntity.getBody().getPayload().toString());
	}
	
	
	/**
	 * Negative test scenario for mobile login when request is null
	 * @throws ParseException 
	 */
	@Test
	public void testMobileLoginNullRequest() throws ParseException {
		ResponseEntity<ResponseBean> responseEntity=authenticationServiceController.mobileLogin(null, headers, null, null, null, null, null, null);
    	assertNull(responseEntity.getBody());
	}
	
	/**
	 * Negative test scenario for mobile login when given password is not in correct format
	 * @throws ParseException 
	 */
	@Test(expected=BFLBusinessException.class)
	public void testMobileLoginRType1InvalidId() throws ParseException {
		UserLoginAccountRequestV2 loginAccountRequestV2= AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		loginAccountRequestV2.setLoginId("1234");
		authenticationServiceController.mobileLogin(loginAccountRequestV2, headers, null, null, null, null, null, null);
	}
	
	/**
	 * Negative test scenario for mobile login when given password is not in correct format.
	 * @throws ParseException 
	 */
	@Test
	public void testMobileLoginRType1Pass() throws ParseException {
		UserLoginAccountRequestV2 loginAccountRequestV2= AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		loginAccountRequestV2.setPassword("123");
		loginAccountRequestV2.setRtype("2");
		authenticationServiceController.mobileLogin(loginAccountRequestV2, headers, null, null, null, null, null, null);
	}
	
	
	/**Positive test sceanrio for mobile login when rtype is 2
	 * @throws ParseException 
	 * 
	 */
	@Test
	public void testMobileLoginRType2() throws ParseException {
		TokenResponse token = new TokenResponse();
		token.setUserKey(Long.valueOf("123456"));
		UserLoginAccountRequestV2 loginAccountRequestV2= AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		loginAccountRequestV2.setRtype("2");
		Mockito.when(authService.login(loginAccountRequestV2, headers, null)).thenReturn(token);
		ResponseEntity<ResponseBean> responseEntity=authenticationServiceController.mobileLogin(loginAccountRequestV2, headers, null, null, null, null, null, null);
    	assertEquals(org.springframework.http.HttpStatus.OK, responseEntity.getStatusCode());
	}
	
	@Test
	public void testValidateResetPasswordUser() {
		MobileDobOtpLoginRequest dobOtpLoginRequest= AuthenticationServiceDataPopulator.popMobileDobOtpLoginRequest();
		dobOtpLoginRequest.setrType("1");
		//method under test
		ResponseEntity<ResponseBean> responseEntity=authenticationServiceController.validateResetPasswordUser(dobOtpLoginRequest, headers);
		assertEquals("Success", responseEntity.getBody().getPayload().toString());
	}
	
	@Test
	public void testValidateResetPasswordUser2() {
		MobileDobOtpLoginRequest dobOtpLoginRequest= AuthenticationServiceDataPopulator.popMobileDobOtpLoginRequest();
		dobOtpLoginRequest.setrType("2");
		ResponseBean responseBean=new ResponseBean(StatusCode.SUCCESS);
        Mockito.when(authService.autheticateMobileDobOtp(dobOtpLoginRequest)).thenReturn(responseBean);
		//method under test
		ResponseEntity<ResponseBean> responseEntity=authenticationServiceController.validateResetPasswordUser(dobOtpLoginRequest, headers);
		assertEquals("SUCCESS", responseEntity.getBody().getPayload().toString());
	}
	
	@Test
	public void testValidateResetPasswordUser2Exception() {
		MobileDobOtpLoginRequest dobOtpLoginRequest=null;
		//method under test
		ResponseEntity<ResponseBean> responseEntity=authenticationServiceController.validateResetPasswordUser(dobOtpLoginRequest, headers);
		assertNull(responseEntity.getBody());
	}
	
	@Test
	public void testGetSecretKey() {
		LoginSecretKeyResponse loginSecretKeyResponse = new LoginSecretKeyResponse();
		loginSecretKeyResponse.setSecretKey("secret Key");
		Mockito.when(authService.getSecretKey("clientId")).thenReturn(loginSecretKeyResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.getSecretKey("clientId", headers).getStatusCode());
	}
	@Test
	public void testgetAadharOtp() {
		AadharLoginRequest aadharLoginRequest= new AadharLoginRequest();
		Mockito.when(authService.getAadharOtp(aadharLoginRequest.getAadharNumber())).thenReturn(new ResponseBean());
		assertEquals(HttpStatus.OK, authenticationServiceController.getAadharOtp(headers, aadharLoginRequest).getStatusCode());
	}
	@Test
	public void tesauthenticateAadhar() {
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		AadharLoginRequest aadharLoginRequest= AuthenticationServiceDataPopulator.popAdharLoginRequest();
		Mockito.when(authService.getAadharUserDetails(aadharLoginRequest)).thenReturn(aadharProfile);
		Mockito.when(loginAcctBuilder.getLoginAccountFromAadharRequest(Mockito.anyString(),
				Mockito.anyString())).thenReturn(loginAcct);
		Mockito.when(authService.authenticateUser(loginAcct)).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),
				loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		assertEquals(200, authenticationServiceController.authenticateAadhar(headers, aadharLoginRequest).getStatusCodeValue());
	}
	
	@Test(expected=BFLTechnicalException.class)
	public void tesauthenticateAadharEX1() {
		AadharLoginRequest aadharLoginRequest= AuthenticationServiceDataPopulator.popAdharLoginRequest();
		authenticationServiceController.authenticateAadhar(headers, aadharLoginRequest);
	}
	
	@Test
	public void tesauthenticateAadharEx2() {
		AadharLoginRequest aadharLoginRequest= AuthenticationServiceDataPopulator.popAdharLoginRequest();
		Mockito.when(authService.getAadharUserDetails(aadharLoginRequest)).thenThrow(new BFLBusinessException());
		assertEquals(HttpStatus.OK, authenticationServiceController.authenticateAadhar(headers, aadharLoginRequest).getStatusCode());
	}
	
	@Test
	public void testauthenticateAadharWithoutOTP() {
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		AadharLoginRequest aadharLoginRequest= AuthenticationServiceDataPopulator.popAdharLoginRequest();
		Mockito.when(loginAcctBuilder.getLoginAccountFromAadharRequest(Mockito.anyString(),
				Mockito.anyString())).thenReturn(loginAcct);
		Mockito.when(authService.authenticateUser(loginAcct)).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),
				loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.authenticateAadharWithoutOTP(headers, aadharLoginRequest).getStatusCode());
	}
	@Test
	public void testclientLogin() {
		TemporaryTokenRequest tokenRequest = new TemporaryTokenRequest();
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		Mockito.when(loginAcctBuilder.getLoginAccountFromManualRequest(Mockito.anyString(),
				Mockito.anyString(),Mockito.anyString())).thenReturn(loginAcct);
		Mockito.when(authService.authenticateUser(loginAcct)).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),
				loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.clientLogin(headers, tokenRequest).getStatusCode());
	}

	@Test
	public void testgetSocialToken() {
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		SocialProfileResponse profileResponse = AuthenticationServiceDataPopulator.popSocialProfileResponse();
		SocialAuthenticationRequest authenticationRequest = AuthenticationServiceDataPopulator.popSocialAuthenticationRequest();
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		Mockito.when(authService.getSocialDetails(authenticationRequest, headers)).thenReturn(profileResponse);
		Mockito.when(loginAcctBuilder.getLoginAccountFromSocialRequest(Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(loginAcct);
		Mockito.when(authService.authenticateUser(loginAcct)).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.getSocialToken(headers, authenticationRequest).getStatusCode());
	}
	
	@Test
	public void testgetSocialTokenEx() {
		SocialProfileResponse profileResponse = null;
		SocialAuthenticationRequest authenticationRequest = AuthenticationServiceDataPopulator.popSocialAuthenticationRequest();
		Mockito.when(authService.getSocialDetails(authenticationRequest, headers)).thenReturn(profileResponse);
		assertEquals(HttpStatus.NOT_FOUND, authenticationServiceController.getSocialToken(headers, authenticationRequest).getStatusCode());
	}
	@Test
	public void testauthenticateMobileDob() {
		MobileLoginRequest loginRequest=AuthenticationServiceDataPopulator.popMobileLoginRequest();
		Mockito.when(authService.authenticateMobileDob(loginRequest)).thenReturn(new ResponseBean());
		assertEquals(HttpStatus.OK, authenticationServiceController.authenticateMobileDob(loginRequest,headers).getStatusCode());
	}
	@Test
	public void testauthenticateMobileDobAndGenerateToken() {
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		MobileLoginRequest loginRequest=AuthenticationServiceDataPopulator.popMobileLoginRequest();
		Mockito.when(authService.validateOtpForMobileDobLogin(loginRequest)).thenReturn(true);
		Mockito.when(loginAcctBuilder.getLoginAccountFromMobileDOBRequest(loginRequest)).thenReturn(loginAcct);
		Mockito.when(authService.authenticateUser(loginAcct)).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.authenticateMobileDobAndGenerateToken(loginRequest,headers).getStatusCode());
	}
	
	@Test
	public void testauthenticateMobileDobAndGenerateToken2() {
		MobileLoginRequest loginRequest=AuthenticationServiceDataPopulator.popMobileLoginRequest();
		Mockito.when(authService.validateOtpForMobileDobLogin(loginRequest)).thenReturn(false);
		assertEquals(HttpStatus.OK, authenticationServiceController.authenticateMobileDobAndGenerateToken(loginRequest,headers).getStatusCode());
	}
	
	@Test
	public void testauthenticateMobileDobWihtoutOtpAndGenerateToken() {
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		MobileLoginRequest loginRequest=AuthenticationServiceDataPopulator.popMobileLoginRequest();
		Mockito.when(authService.validateOtpForMobileDobLogin(loginRequest)).thenReturn(true);
		Mockito.when(loginAcctBuilder.getLoginAccountFromMobileDOBRequest(loginRequest)).thenReturn(loginAcct);
		Mockito.when(authService.authenticateUser(loginAcct)).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		assertEquals(HttpStatus.OK, authenticationServiceController.authenticateMobileDobWihtoutOtpAndGenerateToken(loginRequest,headers).getStatusCode());
	}
	
	
	@Test
	public void testAuthenticateMobileDobWihtoutOtpAndGenerateTokenAndUserKey() {
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		MobileLoginRequest loginRequest=AuthenticationServiceDataPopulator.popMobileLoginRequest();
		Mockito.when(authService.validateOtpForMobileDobLogin(loginRequest)).thenReturn(true);
		Mockito.when(loginAcctBuilder.getLoginAccountFromMobileDOBRequest(loginRequest)).thenReturn(loginAcct);
		Mockito.when(authService.authenticateUser(loginAcct)).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.authenticateMobileDobWihtoutOtpAndGenerateTokenAndUserKey(loginRequest,headers).getStatusCode());
	}
	
	
	@Test
	public void testAuthenticateMobileDobWihtoutOtpAndGenerateTokenAndUserKey2() {
		MobileLoginRequest loginRequest=null;
		assertEquals(HttpStatus.BAD_REQUEST, authenticationServiceController.authenticateMobileDobWihtoutOtpAndGenerateTokenAndUserKey(loginRequest,headers).getStatusCode());
	}
	
	@Test
	public void testgetAuthTokenForMobileApp() {
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		SocialAuthenticationRequest authenticationRequest=AuthenticationServiceDataPopulator.popSocialAuthenticationRequest();
		SocialProfileResponse profileResponse=AuthenticationServiceDataPopulator.popSocialProfileResponse();
		Mockito.when(loginAcctBuilder.getLoginAccountFromSocialRequest(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(loginAcct);
		Mockito.when(authService.getSocialDetails(authenticationRequest, headers)).thenReturn(profileResponse);
		Mockito.when(authService.authenticateUser(Mockito.any(LoginAccount.class))).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.getAuthTokenForMobileApp(headers,authenticationRequest).getStatusCode());
	}
	
	@Test
	public void testgetAuthTokenForMobileAppNullReq() {
		SocialAuthenticationRequest authenticationRequest=null;
		assertEquals(HttpStatus.BAD_REQUEST, authenticationServiceController.getAuthTokenForMobileApp(headers,authenticationRequest).getStatusCode());
	}
	
	
	@Test
	public void testgetAuthTokenForMobileApp2() {
		SocialAuthenticationRequest authenticationRequest=AuthenticationServiceDataPopulator.popSocialAuthenticationRequest();
		SocialProfileResponse profileResponse=null;
		Mockito.when(authService.getSocialDetails(authenticationRequest, headers)).thenReturn(profileResponse);
		assertEquals(HttpStatus.NOT_FOUND, authenticationServiceController.getAuthTokenForMobileApp(headers,authenticationRequest).getStatusCode());
	}
	@Test
	public void testpartnerLogin() throws Exception{
		PartnerLoginRequest partnerLoginRequest=AuthenticationServiceDataPopulator.popPartnerLoginRequest();
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		Mockito.when(loginAcctBuilder.getLoginAccountFromManualRequest(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(loginAcct);
		Mockito.when(authService.authenticateUser(Mockito.any(LoginAccount.class))).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.partnerLogin(partnerLoginRequest ,result,headers).getStatusCode());
		
	}
	
	@Test
	public void testSysytemPartnerLogin() {
		SystemPartnerLoginRequest partnerLoginRequest=AuthenticationServiceDataPopulator.popSystemPartnerLoginRequest();
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		Mockito.when(loginAcctBuilder.getLoginAccountFromManualRequest(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(loginAcct);
		Mockito.when(authService.authenticateUser(Mockito.any(LoginAccount.class))).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.systemPartnerLogin(partnerLoginRequest ,result,headers).getStatusCode());
		
	}
	@Test
	public void testLogout() {
		assertEquals(HttpStatus.OK, authenticationServiceController.logout(headers).getStatusCode());
	}
	@Test
	public void testgetSocialRedirectUrl() {
		SocialLoginParamsRequest socialLoginParamsRequest=new SocialLoginParamsRequest();
		SocialLoginParamsResponse loginParamsResponse=AuthenticationServiceDataPopulator.popSocialLoginParamsResponse();
		Mockito.when(authService.getRedirectUrl(socialLoginParamsRequest)).thenReturn(loginParamsResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.getSocialRedirectUrl(headers,socialLoginParamsRequest).getStatusCode());
	}
	
	@Test
	public void authenticateManualLoginTest() throws Exception
	{
		UserLoginAccountRequest manualLoginRequest=new UserLoginAccountRequest();
		TokenResponse token=new TokenResponse();		
		Mockito.when(authService.authenticateManualLogin(Mockito.any(), Mockito.any(),Mockito.any() )).thenReturn(token);
		
		removeUserKey(token, false);
		assertEquals(HttpStatus.OK, authenticationServiceController.authenticateManualLogin(headers, manualLoginRequest, null, null, null, null, null, null).getStatusCode());
	}


	private void removeUserKey(TokenResponse token, boolean b) {
		
		TokenResponse tokenResponse=new TokenResponse();
		 tokenResponse.setUserKey(null);
		 tokenResponse.setDefaultRole(null);		 
		
	}
	
	@Test
	public void testGenerateSystemTokens() {
		
		SystemTokenRequest systemTokenRequest = new SystemTokenRequest();
		systemTokenRequest.setProductCode("HGI");
		LoginAccount loginAcct=AuthenticationServiceDataPopulator.popLoginAccount();
		UserLoginAccountResponse accountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		TokenResponse tokenResponse=AuthenticationServiceDataPopulator.popTokenResponse();

		Mockito.when(loginAcctBuilder.getLoginAccountFromProductCode(Mockito.anyObject())).thenReturn(loginAcct);
		Mockito.when(authService.authenticateUser(loginAcct)).thenReturn(accountResponse);
		Mockito.when(authService.getToken(loginAcct.getLoginId(), accountResponse.getUserId(),
				loginAcct.getUserType(), headers)).thenReturn(tokenResponse);
		assertEquals(HttpStatus.OK, authenticationServiceController.generateSystemTokens(headers, systemTokenRequest, result).getStatusCode());
	}
	
	@Test
	public void mobileAutoLoginLoginTest() throws Exception
	{
		ResponseBean responseBean=new ResponseBean();
		Mockito.when(authService.mobileAutoLogin(Mockito.any())).thenReturn(responseBean);
		assertEquals(HttpStatus.OK, authenticationServiceController.mobileAutoLogin(headers).getStatusCode());
	}
	
	@Test(expected = Exception.class)
	public void mobileAutoLoginLoginTest1() throws Exception
	{
		
		Mockito.when(authService.mobileAutoLogin(Mockito.any())).thenThrow(new Exception());
		authenticationServiceController.mobileAutoLogin(headers);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void mobileAutoLoginLoginTest2() throws Exception
	{
		Mockito.when(authService.mobileAutoLogin(Mockito.any())).thenThrow(new BFLTechnicalException());
		authenticationServiceController.mobileAutoLogin(headers);
	}
	
	@Test
	public void ntpPreRegisterTest() throws Exception
	{
		NtpPreRegisterRequest preRegisterRequest=new NtpPreRegisterRequest();
		Mockito.when(authService.ntpPreRegister(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		authenticationServiceController.ntpPreRegister(preRegisterRequest,headers,null,null);
	}
	
	@Test(expected = Exception.class)
	public void ntpPreRegisterTest1() throws Exception
	{
		NtpPreRegisterRequest preRegisterRequest=new NtpPreRegisterRequest();
		Mockito.when(authService.ntpPreRegister(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenThrow(new Exception());
		authenticationServiceController.ntpPreRegister(preRegisterRequest,headers,Mockito.any(),Mockito.any());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void ntpPreRegisterTest2() throws Exception
	{
		NtpPreRegisterRequest preRegisterRequest=new NtpPreRegisterRequest();
		Mockito.when(authService.ntpPreRegister(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenThrow(new BFLTechnicalException());
		authenticationServiceController.ntpPreRegister(preRegisterRequest,headers,Mockito.any(),Mockito.any());
	}
	
	@Test
	public void ntpPreRegisterForBFLWithPseudoTokenTest() throws Exception
	{
		NtpPreRegisterRequest preRegisterRequest = new NtpPreRegisterRequest();
		Mockito.when(authService.ntpPreRegister(Mockito.any(NtpPreRegisterRequest.class),
				Mockito.anyString(), Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(responseEntity);
		
		Mockito.when(responseEntity.getStatusCodeValue()).thenReturn(200);
		ResponseBean ntpPreRegisterResponse = new ResponseBean();
		ntpPreRegisterResponse.setPayload(new NtpPreRegisterRes());
		Mockito.when(responseEntity.getBody()).thenReturn(ntpPreRegisterResponse);
		TokenResponse tokenResponse = new TokenResponse();
		Mockito.when(omAuthenticationService.authenticateMobDobAndGenerateToken(Mockito.any()))
			.thenReturn(tokenResponse);

		ResponseEntity<ResponseBean> response = authenticationServiceController.ntpPreRegisterForBFLWithPseudoToken(preRegisterRequest, headers, "", "");
		assertNotNull(response);
	}
	
	@Test(expected = BFLHttpException.class)
	public void ntpPreRegisterForBFLWithPseudoTokenTestApiFailure() throws Exception
	{
		NtpPreRegisterRequest preRegisterRequest=new NtpPreRegisterRequest();
		Mockito.when(authService.ntpPreRegister(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
			.thenThrow(new BFLHttpException());
		authenticationServiceController.ntpPreRegisterForBFLWithPseudoToken(preRegisterRequest,headers, "", "");
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void ntpPreRegisterForBFLWithPseudoTokenTestSomeException() throws Exception
	{
		NtpPreRegisterRequest preRegisterRequest=new NtpPreRegisterRequest();
		Mockito.when(authService.ntpPreRegister(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
			.thenThrow(new RestClientException("rest client failure"));
		authenticationServiceController.ntpPreRegisterForBFLWithPseudoToken(preRegisterRequest,headers, "", "");
	}
	
	@Test
	public void ntpPreProcessTest() throws Exception
	{
		NtpPreProcessRequest preProcessRequest=new NtpPreProcessRequest();
		Mockito.when(authService.ntpPreProcess(Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		authenticationServiceController.ntpPreProcess(preProcessRequest,headers);
	}
	
	@Test(expected = Exception.class)
	public void ntpPreProcessTest1() throws Exception
	{
		NtpPreProcessRequest preProcessRequest=new NtpPreProcessRequest();
		Mockito.when(authService.ntpPreProcess(Mockito.any(),Mockito.any())).thenThrow(new Exception());
		authenticationServiceController.ntpPreProcess(preProcessRequest,headers);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void ntpPreProcessTest2() throws Exception
	{
		NtpPreProcessRequest preProcessRequest=new NtpPreProcessRequest();
		Mockito.when(authService.ntpPreProcess(Mockito.any(),Mockito.any())).thenThrow(new BFLTechnicalException());
		authenticationServiceController.ntpPreProcess(preProcessRequest,headers);
	}
	
	@Test
	public void ntpLoginTest() throws Exception
	{
		NtpLoginRequest ntpLoginRequest=new NtpLoginRequest();
		Mockito.when(authService.ntpLogin(Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		authenticationServiceController.ntpLogin(ntpLoginRequest,headers);
	}
	
	@Test(expected = Exception.class)
	public void ntpLoginTest1() throws Exception
	{
		NtpLoginRequest ntpLoginRequest=new NtpLoginRequest();
		Mockito.when(authService.ntpLogin(Mockito.any(),Mockito.any())).thenThrow(new Exception());
		authenticationServiceController.ntpLogin(ntpLoginRequest,headers);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void ntpLoginTest2() throws Exception
	{
		NtpLoginRequest ntpLoginRequest=new NtpLoginRequest();
		Mockito.when(authService.ntpLogin(Mockito.any(),Mockito.any())).thenThrow(new BFLTechnicalException());
		authenticationServiceController.ntpLogin(ntpLoginRequest,headers);
	}
	
	@Test
	public void ntpPreRegisterForBFLWithCustomerTokenTest() throws Exception
	{
		NtpPreRegisterRequest preRegisterRequest = new NtpPreRegisterRequest();
		Mockito.when(authService.ntpPreRegister(Mockito.any(NtpPreRegisterRequest.class),
				Mockito.anyString(), Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(responseEntity);
		
		Mockito.when(responseEntity.getStatusCodeValue()).thenReturn(200);
		NtpPreRegisterRes ntpPreRegisterRes = new NtpPreRegisterRes();
		ntpPreRegisterRes.setMobileNumber("9999999999");
		ntpPreRegisterRes.setUserKey(1L);
		ResponseBean ntpPreRegisterResponse = new ResponseBean();
		ntpPreRegisterResponse.setPayload(ntpPreRegisterRes);
		Mockito.when(responseEntity.getBody()).thenReturn(ntpPreRegisterResponse);
		TokenResponse tokenResponse = new TokenResponse();
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(),
				Mockito.eq((short)1), Mockito.any(HttpHeaders.class)))
			.thenReturn(tokenResponse);

		ResponseEntity<ResponseBean> response = authenticationServiceController.ntpPreRegisterForBFLWithCustomerToken(preRegisterRequest, headers, "", "");
		assertNotNull(response);
	}
	
	@Test(expected = BFLHttpException.class)
	public void ntpPreRegisterForBFLWithCustomerTokenTestApiFailure() throws Exception
	{
		NtpPreRegisterRequest preRegisterRequest=new NtpPreRegisterRequest();
		Mockito.when(authService.ntpPreRegister(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
			.thenThrow(new BFLHttpException());
		authenticationServiceController.ntpPreRegisterForBFLWithCustomerToken(preRegisterRequest,headers, "", "");
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void ntpPreRegisterForBFLWithCustomerTokenTestSomeException() throws Exception
	{
		NtpPreRegisterRequest preRegisterRequest=new NtpPreRegisterRequest();
		Mockito.when(authService.ntpPreRegister(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
			.thenThrow(new RestClientException("rest client failure"));
		authenticationServiceController.ntpPreRegisterForBFLWithCustomerToken(preRegisterRequest,headers, "", "");
	}

}
