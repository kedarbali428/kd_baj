package com.bajaj.bfsd.authentication.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.bajaj.bfsd.authentication.bean.AppDetVerificationDetailsBean;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginRequest;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginResponse;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingStatusResponse;
import com.bajaj.bfsd.authentication.bean.ApplicantAddressDetailsBean;
import com.bajaj.bfsd.authentication.bean.ApplicantDetailBean;
import com.bajaj.bfsd.authentication.bean.ApplicantEmailDetailsBean;
import com.bajaj.bfsd.authentication.bean.ApplicantEmplDetailsBean;
import com.bajaj.bfsd.authentication.bean.ApplicantKeysRequest;
import com.bajaj.bfsd.authentication.bean.ApplicantPanVerification;
import com.bajaj.bfsd.authentication.bean.ApplicantPhoneNumberDetailsBean;
import com.bajaj.bfsd.authentication.bean.ApplicantV2DetailsResponse;
import com.bajaj.bfsd.authentication.bean.BureauDetails;
import com.bajaj.bfsd.authentication.bean.EmailDetails;
import com.bajaj.bfsd.authentication.bean.LocationAddressBean;
import com.bajaj.bfsd.authentication.bean.MobileAppOnBoardingRequest;
import com.bajaj.bfsd.authentication.bean.MobileAppOnBoardingResponse;
import com.bajaj.bfsd.authentication.bean.NameDetails;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterResponse;
import com.bajaj.bfsd.authentication.bean.Occupation;
import com.bajaj.bfsd.authentication.bean.OccupationDetails;
import com.bajaj.bfsd.authentication.bean.PanDetailsBean;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsResponse;
import com.bajaj.bfsd.authentication.bean.PanVerificationResponse;
import com.bajaj.bfsd.authentication.bean.PersonalDetails;
import com.bajaj.bfsd.authentication.bean.PinCodeDetails;
import com.bajaj.bfsd.authentication.bean.ProspectAddressDetailsResponse;
import com.bajaj.bfsd.authentication.bean.ProspectDetailsResponse;
import com.bajaj.bfsd.authentication.bean.Reference;
import com.bajaj.bfsd.authentication.bean.UpdateMobileAppOnBoardingRequest;
import com.bajaj.bfsd.authentication.bean.UpdatePanProfileRequest;
import com.bajaj.bfsd.authentication.bean.UpdatePanProfileResponse;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UserKeysBean;
import com.bajaj.bfsd.authentication.bean.UserProfileAttribute;
import com.bajaj.bfsd.authentication.bean.UserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UserProfileDetailsResponse;
import com.bajaj.bfsd.authentication.bean.UserResponse;
import com.bajaj.bfsd.authentication.bean.UserStatusBean;
import com.bajaj.bfsd.authentication.bean.Verification;
import com.bajaj.bfsd.authentication.dao.EstoreAuthenticationDao;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.service.impl.AppOnBoardingServiceImpl;
import com.bajaj.bfsd.authentication.util.AppOnBoardingUtils;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.DataFormatter;
import com.bajaj.bfsd.authentication.util.EstoreAuthenticationHelper;
import com.bajaj.bfsd.authentication.util.TokenCodeHelper;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringRunner.class)
public class AppOnBoardingServiceImplTest {

	@InjectMocks
	private AppOnBoardingServiceImpl appOnBoardingServiceImpl;
	
	@Mock
	private BFLLoggerUtil logger;

	@Mock
	private Environment env;

	@Mock
	private EstoreAuthenticationDao authenticationDao;

	@Mock
	private AppOnBoardingUtils appOnBoardingUtils;

	@Mock
	private EstoreAuthenticationHelper estoreAuthenticationHelper;
	
	@Mock
	private AuthenticationService authenticationService;
	
	@Mock
	private DataFormatter dataFormatter;
	
	@Mock
	private TokenCodeHelper tokenCodeHelper;
	
	@Test
	public void testCheckUsersSource() {
		String requestSource="MOBILEAPP";
		String userExistenceSource="APPLICANTETP,BUREAU,PROSPECT,OTPGENERATE";
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn(userExistenceSource);
		Mockito.when(authenticationDao.checkLoginIdExistanceForEstore(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(1);
		Mockito.when(appOnBoardingUtils.getProspectDetails(Mockito.anyString(), Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(new ProspectDetailsResponse());
		Mockito.when(appOnBoardingUtils.generateOtp(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(AuthenticationServiceConstants.YES);
		HttpHeaders headers=new HttpHeaders();
		AppOnBoardingStatusResponse checkUsersSource = appOnBoardingServiceImpl.checkUsersSource("9999999999", "01-01-1989", 
				requestSource, headers);
		assertNotNull(checkUsersSource);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testCheckUsersInvalidSource() {
		HttpHeaders headers=new HttpHeaders();
		String requestSource="Invalid";
		AppOnBoardingStatusResponse checkUsersSource = appOnBoardingServiceImpl.checkUsersSource("9999999999", "01-01-1989", 
				requestSource, headers);
		assertNotNull(checkUsersSource);
	}

	@Test
	public void testCheckUsersInvalidUserStatus() {
		HttpHeaders headers=new HttpHeaders();
		String requestSource="RANDOM";
		String userExistenceSource="OTP";
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn(userExistenceSource);
		AppOnBoardingStatusResponse checkUsersSource = appOnBoardingServiceImpl.checkUsersSource("9999999999", "01-01-1989", 
				requestSource, headers);
		assertNotNull(checkUsersSource);
	}
	
	@Test
	public void testCheckUsersInvalidUserStatusFailures() {
		HttpHeaders headers=new HttpHeaders();
		String requestSource="MOBILEAPP";
		String userExistenceSource="APPLICANTETP,BUREAU,PROSPECT,OTPGENERATE";
		Mockito.when(authenticationDao.checkLoginIdExistanceForEstore(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(0);
		Mockito.when(appOnBoardingUtils.getProspectDetails(Mockito.anyString(), Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(null);
		Mockito.when(appOnBoardingUtils.generateOtp(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(AuthenticationServiceConstants.NO);
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn(userExistenceSource);
		AppOnBoardingStatusResponse checkUsersSource = appOnBoardingServiceImpl.checkUsersSource("9999999999", "01-01-1989", 
				requestSource, headers);
		assertNotNull(checkUsersSource);
	}	
	
	@Test
	public void testCheckUsersInvalidUserStatusMultiple() {
		HttpHeaders headers=new HttpHeaders();
		String requestSource="MOBILEAPP";
		String userExistenceSource="APPLICANTETP";
		Mockito.when(authenticationDao.checkLoginIdExistanceForEstore(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(2);
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn(userExistenceSource);
		AppOnBoardingStatusResponse checkUsersSource = appOnBoardingServiceImpl.checkUsersSource("9999999999", "01-01-1989", 
				requestSource, headers);
		assertNotNull(checkUsersSource);
	}	
	
	@Test(expected = BFLBusinessException.class)
	public void testCheckUsersBlank() {
		HttpHeaders headers=new HttpHeaders();
		String requestSource="";
		AppOnBoardingStatusResponse checkUsersSource = appOnBoardingServiceImpl.checkUsersSource("9999999999", "01-01-1989", 
				requestSource, headers);
		assertNotNull(checkUsersSource);
	}	
	
	private AppOnBoardingLoginRequest validateOtpAndLoginValidSource(String source) {
		UserStatusBean userStatusBean = new UserStatusBean();
		userStatusBean.setBureau(AuthenticationServiceConstants.YES);
		userStatusBean.setEtp(AuthenticationServiceConstants.YES);
		userStatusBean.setProspect(AuthenticationServiceConstants.YES);
		AppOnBoardingLoginRequest request = new AppOnBoardingLoginRequest();
		request.setDateOfBirth("01-05-1991");
		request.setMobileNumber("9999999999");
		request.setOtp("123456");
		request.setUserStatus(userStatusBean);
		request.setSource(source);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(new ArrayList<Tokens>());
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1234L);
		ntpPreRegisterResponse.setApplicantKey(1234L);
		ResponseBean responseBean = new ResponseBean(ntpPreRegisterResponse);
		ResponseEntity<ResponseBean> registerResponseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		String dateOfBirth="01-05-1989";
		Date fdateOfBirth=dataFormatter.dateStringToDate(dateOfBirth, AuthenticationServiceConstants.DOB_YYYY_MM_DD_FORMAT);
		Mockito.when(dataFormatter.dateStringToDate(dateOfBirth, AuthenticationServiceConstants.DOB_YYYY_MM_DD_FORMAT))
		.thenReturn(fdateOfBirth);
		Mockito.when(dataFormatter.dateToFormatedDateString(fdateOfBirth, AuthenticationServiceConstants.DOB_YYYY_MM_DD_FORMAT))
		.thenReturn("1989-05-01");
		MobileLoginRequest mobileLoginRequest = new MobileLoginRequest();
		mobileLoginRequest.setMobile(request.getMobileNumber());
		mobileLoginRequest.setDateOfBirth(request.getDateOfBirth());
		UserResponse userResponse = new UserResponse();
		Mockito.when(tokenCodeHelper.callUserAdditionalDet(mobileLoginRequest, AuthenticationServiceConstants.USERTYPE_CUSTOMER,
				1234L)).thenReturn(userResponse);
		Mockito.when(appOnBoardingUtils.validateOtp(Mockito.any(), Mockito.any(HttpHeaders.class)))
			.thenReturn(AuthenticationServiceConstants.SUCCESS);
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyInt(), Mockito.eq((short)1), 
				Mockito.any(HttpHeaders.class)))
			.thenReturn(tokenResponse);
		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(), Mockito.eq(null), Mockito.eq(null), 
				Mockito.any(HttpHeaders.class)))
			.thenReturn(registerResponseEntity);
		return request;
	}
	
	@Test
	public void testValidateOtpAndLoginValidCustomerPortalNextTaskPersonalDetails() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.CUSTOMER_PORTAL);
		Mockito.when(appOnBoardingUtils.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(new ApplicantDetailBean());
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("app_source", "source");
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, httpHeaders);
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test
	public void testValidateOtpAndLoginValidCustomerPortalNextTaskHome() {
		ApplicantDetailBean applicantDetailBean = new ApplicantDetailBean();
		applicantDetailBean.setFirstName("name");
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.CUSTOMER_PORTAL);
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantDetailBean);
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testValidateOtpAndLoginNoApplicantCustomerPortal() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.CUSTOMER_PORTAL);
		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(), Mockito.eq(null), Mockito.eq(null), 
				Mockito.any(HttpHeaders.class)))
			.thenReturn(null);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test
	public void testValidateOtpAndLoginValidMobileAppNextTaskCampaignHome() {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("utm_journey", "campaign");
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBILEAPP);
		ApplicantDetailBean applicantDetailBean = new ApplicantDetailBean();		
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
 		Mockito.when(appOnBoardingUtils.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantDetailBean);
		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(), Mockito.eq(null), Mockito.eq(null), 
				Mockito.any(HttpHeaders.class)))
			.thenReturn(responseEntity);
		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, httpHeaders);
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test
	public void testValidateOtpAndLoginValidMobileAppNextTaskBureauDetails() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBILEAPP);
		ApplicantDetailBean applicantDetailBean = new ApplicantDetailBean();		
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(), Mockito.eq(null), Mockito.eq(null), 
				Mockito.any(HttpHeaders.class)))
			.thenReturn(responseEntity);
		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantDetailBean);
		
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test
	public void testValidateOtpAndLoginValidMobileAppNextTaskPersonalDetails() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBILEAPP);
		ApplicantDetailBean applicantDetailBean = new ApplicantDetailBean();
		applicantDetailBean.setPanNumber("AANBBCC");
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantDetailBean);
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test
	public void testValidateOtpAndLoginValidMobileAppNextTaskHome() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBILEAPP);
		ApplicantDetailBean applicantDetailBean=new ApplicantDetailBean();
		applicantDetailBean.setFirstName("Abc");
		applicantDetailBean.setLastName("Cba");
		applicantDetailBean.setPanNumber("AABBCCDD");
		ApplicantEmailDetailsBean applicantEmailDetailsBean=new ApplicantEmailDetailsBean();
		applicantEmailDetailsBean.setEmailAddress("ABC@gmail.com");
		applicantEmailDetailsBean.setType("PERSON1");
		List<ApplicantEmailDetailsBean> emailDetails=new ArrayList<ApplicantEmailDetailsBean>();
		emailDetails.add(applicantEmailDetailsBean);
		applicantDetailBean.setEmailDetails(emailDetails);
		ApplicantAddressDetailsBean applicantAddressDetailsBean=new ApplicantAddressDetailsBean();
		applicantAddressDetailsBean.setPinCode("123456");
		List<ApplicantAddressDetailsBean> addressDetailsBeans=new ArrayList<ApplicantAddressDetailsBean>();
		addressDetailsBeans.add(applicantAddressDetailsBean);
		applicantDetailBean.setAddressDetails(addressDetailsBeans);
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		
		Mockito.when(appOnBoardingUtils.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantDetailBean);
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testValidateOtpAndLoginValidMobileAppNoApplicant() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBILEAPP);
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test
	public void testValidateOtpAndLoginValidMobAppNextTaskCampaignHome() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("utm_journey", "campaign");
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.getApplicantDetailsV2WithPanVerification(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(new ApplicantV2DetailsResponse());
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, httpHeaders);
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test
	public void testValidateOtpAndLoginValidMobAppNextTaskBureau() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		ApplicantV2DetailsResponse applicantV2Details = new ApplicantV2DetailsResponse();
		applicantV2Details.setPanDetails(new ApplicantPanVerification());
		MobileAppOnBoardingResponse onBoardingResponse = new MobileAppOnBoardingResponse();
		onBoardingResponse.setSkipFlag(false);
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(Mockito.any(MobileAppOnBoardingRequest.class),
				Mockito.any(HttpHeaders.class)))
			.thenReturn(onBoardingResponse);
		Mockito.when(appOnBoardingUtils.getApplicantDetailsV2WithPanVerification(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantV2Details);
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test
	public void testValidateOtpAndLoginValidMobAppNextTaskBureauPanNotVerified() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		ApplicantPanVerification applicantPanVerification = new ApplicantPanVerification();
		applicantPanVerification.setPanNumber("AABBCC");
		ApplicantV2DetailsResponse applicantV2Details = new ApplicantV2DetailsResponse();
		applicantV2Details.setPanDetails(applicantPanVerification);
		MobileAppOnBoardingResponse onBoardingResponse = new MobileAppOnBoardingResponse();
		onBoardingResponse.setSkipFlag(false);
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(), Mockito.eq(null), Mockito.eq(null), 
				Mockito.any(HttpHeaders.class)))
			.thenReturn(responseEntity);
		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(Mockito.any(MobileAppOnBoardingRequest.class),
				Mockito.any(HttpHeaders.class)))
			.thenReturn(onBoardingResponse);
		Mockito.when(appOnBoardingUtils.getApplicantDetailsV2WithPanVerification(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantV2Details);
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test
	public void testValidateOtpAndLoginValidMobAppNextTaskHomePanVerified() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		ApplicantPanVerification applicantPanVerification = new ApplicantPanVerification();
		applicantPanVerification.setPanNumber("AABBCC");
		applicantPanVerification.setVerificationflg(AuthenticationServiceConstants.PAN_VERIFIED_STATUS_TRUE);
		ApplicantV2DetailsResponse applicantV2Details = new ApplicantV2DetailsResponse();
		applicantV2Details.setPanDetails(applicantPanVerification);
		MobileAppOnBoardingResponse onBoardingResponse = new MobileAppOnBoardingResponse();
		onBoardingResponse.setSkipFlag(false);
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(Mockito.any(MobileAppOnBoardingRequest.class),
				Mockito.any(HttpHeaders.class)))
			.thenReturn(onBoardingResponse);
		Mockito.when(appOnBoardingUtils.getApplicantDetailsV2WithPanVerification(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantV2Details);
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test
	public void testValidateOtpAndLoginValidMobAppNextTaskHomeSkipTrue() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		MobileAppOnBoardingResponse onBoardingResponse = new MobileAppOnBoardingResponse();
		onBoardingResponse.setSkipFlag(true);
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(Mockito.any(MobileAppOnBoardingRequest.class),
				Mockito.any(HttpHeaders.class)))
			.thenReturn(onBoardingResponse);
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testValidateOtpAndLoginValidMobAppNextTaskHomeInvalidEtpUserStatusSkipFalse() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		UserStatusBean userStatus = new UserStatusBean();
		userStatus.setEtp(AuthenticationServiceConstants.MULTIPLE);
		request.setUserStatus(userStatus);
		MobileAppOnBoardingResponse onBoardingResponse = new MobileAppOnBoardingResponse();
		onBoardingResponse.setSkipFlag(false);
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(Mockito.any(MobileAppOnBoardingRequest.class),
				Mockito.any(HttpHeaders.class)))
			.thenReturn(onBoardingResponse);
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
		assertNotNull(validateOtpAndLogin);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testValidateOtpAndLoginValidMobAppNextTaskException() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		ApplicantV2DetailsResponse applicantV2Details = new ApplicantV2DetailsResponse();
		Mockito.when(appOnBoardingUtils.getApplicantDetailsV2WithPanVerification(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantV2Details);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testValidateOtpAndLoginValidMobAppNextNoApplicantDetails() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		Mockito.when(appOnBoardingUtils.getApplicantDetailsV2WithPanVerification(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(null);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test(expected = Test.None.class)
	public void testValidateOtpAndLoginValidMobAppNoEtp() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		request.getUserStatus().setEtp(AuthenticationServiceConstants.NO);
		ApplicantV2DetailsResponse applicantV2Details = new ApplicantV2DetailsResponse();
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);
		MobileAppOnBoardingResponse skipStatus = new MobileAppOnBoardingResponse();
		skipStatus.setSkipFlag(null);
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.getApplicantDetailsV2WithPanVerification(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantV2Details);
		Mockito.when(appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(Mockito.any(MobileAppOnBoardingRequest.class), Mockito.any(HttpHeaders.class)))
			.thenReturn(skipStatus);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test(expected = Test.None.class)
	public void testValidateOtpAndLoginValidSourceNoNextTask() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.ECOMM);
		request.getUserStatus().setEtp(AuthenticationServiceConstants.NO);
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);		
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testValidateOtpAndLoginSomeException() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		Mockito.when(appOnBoardingUtils.getApplicantDetailsV2WithPanVerification(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenThrow(new NullPointerException());
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test(expected = Test.None.class)
	public void testValidateOtpAndLoginNoUserStatusBean() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource(AuthenticationServiceConstants.MOBAPP);
		request.setUserStatus(new UserStatusBean());
		ApplicantV2DetailsResponse applicantV2Details = new ApplicantV2DetailsResponse();
		Tokens token = new Tokens();
		token.setToken("authCode");
		List<Tokens> tokens = new ArrayList<>();
		tokens.add(token);
		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ntpPreRegisterResponse.setUserKey(1L);
		ntpPreRegisterResponse.setApplicantKey(1L);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(ntpPreRegisterResponse);
		MobileAppOnBoardingResponse skipStatus = new MobileAppOnBoardingResponse();
		Mockito.when(appOnBoardingUtils.generateTokens(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort(),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(tokenResponse);
		Mockito.when(appOnBoardingUtils.getApplicantDetailsV2WithPanVerification(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantV2Details);
		Mockito.when(appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(Mockito.any(MobileAppOnBoardingRequest.class), Mockito.any(HttpHeaders.class)))
		.thenReturn(skipStatus);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testValidateOtpAndLoginInvalidSource() {
		AppOnBoardingLoginRequest request = validateOtpAndLoginValidSource("INVALIDSOURCE");
		request.setUserStatus(null);
		ApplicantV2DetailsResponse applicantV2Details = new ApplicantV2DetailsResponse();
		Mockito.when(appOnBoardingUtils.getApplicantDetailsV2WithPanVerification(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantV2Details);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testValidateOtpAndLoginValidCreateApplicantFailed() {
		UserStatusBean userStatusBean = new UserStatusBean();
		userStatusBean.setBureau(AuthenticationServiceConstants.YES);
		userStatusBean.setEtp(AuthenticationServiceConstants.YES);
		userStatusBean.setProspect(AuthenticationServiceConstants.YES);
		AppOnBoardingLoginRequest request = new AppOnBoardingLoginRequest();
		request.setDateOfBirth("01-05-1991");
		request.setMobileNumber("9999999999");
		request.setOtp("123456");
		request.setUserStatus(userStatusBean);
		request.setSource(AuthenticationServiceConstants.CUSTOMER_PORTAL);
		Mockito.when(appOnBoardingUtils.validateOtp(Mockito.any(), Mockito.any(HttpHeaders.class)))
			.thenReturn(AuthenticationServiceConstants.SUCCESS);
		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(), Mockito.eq(null), Mockito.eq(null), 
				Mockito.any(HttpHeaders.class)))
			.thenReturn(null);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testValidateOtpAndLoginValidOtpValidationFailed() {
		UserStatusBean userStatusBean = new UserStatusBean();
		userStatusBean.setBureau(AuthenticationServiceConstants.YES);
		userStatusBean.setEtp(AuthenticationServiceConstants.YES);
		userStatusBean.setProspect(AuthenticationServiceConstants.YES);
		AppOnBoardingLoginRequest request = new AppOnBoardingLoginRequest();
		request.setDateOfBirth("01-05-1991");
		request.setMobileNumber("9999999999");
		request.setOtp("123456");
		request.setUserStatus(userStatusBean);
		request.setSource(AuthenticationServiceConstants.CUSTOMER_PORTAL);
		Mockito.when(appOnBoardingUtils.validateOtp(Mockito.any(), Mockito.any(HttpHeaders.class)))
			.thenReturn(AuthenticationServiceConstants.FAILURE);
		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(), Mockito.eq(null), Mockito.eq(null), 
				Mockito.any(HttpHeaders.class)))
			.thenReturn(null);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testValidateOtpAndLoginValidSomeException() {

		AppOnBoardingLoginRequest request = new AppOnBoardingLoginRequest();
		request.setSource(AuthenticationServiceConstants.CUSTOMER_PORTAL);
		Mockito.when(appOnBoardingUtils.validateOtp(Mockito.any(), Mockito.any(HttpHeaders.class)))
			.thenThrow(new NullPointerException());
		Mockito.when(authenticationService.ntpPreRegister(Mockito.any(), Mockito.eq(null), Mockito.eq(null), 
				Mockito.any(HttpHeaders.class)))
			.thenReturn(null);
		appOnBoardingServiceImpl.validateOtpAndLogin(request, new HttpHeaders());
	}
	
	private ApplicantDetailBean getApplicantBean() {
		ApplicantDetailBean applicantDetailBean=new ApplicantDetailBean();
		applicantDetailBean.setFirstName("First");
		applicantDetailBean.setMiddleName("Middle");
		applicantDetailBean.setLastName("Last");
		applicantDetailBean.setPanNumber("ALYPM34569A");
		ApplicantEmailDetailsBean applicantEmailDetailsBean=new ApplicantEmailDetailsBean();
		applicantEmailDetailsBean.setEmailAddress("ABC@gmail.com");
		applicantEmailDetailsBean.setType("PERSON1");
		List<ApplicantEmailDetailsBean> emailDetails=new ArrayList<ApplicantEmailDetailsBean>();
		emailDetails.add(applicantEmailDetailsBean);
		applicantDetailBean.setEmailDetails(emailDetails);
		ApplicantAddressDetailsBean applicantAddressDetailsBean=new ApplicantAddressDetailsBean();
		applicantAddressDetailsBean.setPinCode("123456");
		applicantAddressDetailsBean.setType("OTHERS");
		List<ApplicantAddressDetailsBean> addressDetailsBeans=new ArrayList<ApplicantAddressDetailsBean>();
		addressDetailsBeans.add(applicantAddressDetailsBean);
		applicantDetailBean.setAddressDetails(addressDetailsBeans);
		ApplicantPhoneNumberDetailsBean applicantPhoneNumberDetailsBean=new ApplicantPhoneNumberDetailsBean();
		applicantPhoneNumberDetailsBean.setMobileNumber("9999999999");
		applicantPhoneNumberDetailsBean.setType("OTHERS");
		List<ApplicantPhoneNumberDetailsBean> applicantPhoneNumberDetailsBeans=new ArrayList<ApplicantPhoneNumberDetailsBean>();
		applicantPhoneNumberDetailsBeans.add(applicantPhoneNumberDetailsBean);
		applicantDetailBean.setPhoneNumberDetails(applicantPhoneNumberDetailsBeans);
		AppDetVerificationDetailsBean appDetVerificationDetailsBean=new AppDetVerificationDetailsBean(); 
		appDetVerificationDetailsBean.setFieldlabel("NAME");
		appDetVerificationDetailsBean.setVerificationsrc("Aadhar");
		AppDetVerificationDetailsBean appDetVerificationDetailsBean2=new AppDetVerificationDetailsBean(); 
		appDetVerificationDetailsBean2.setFieldlabel("PAN");
		appDetVerificationDetailsBean2.setVerificationsrc("NSDL");
		AppDetVerificationDetailsBean appDetVerificationDetailsBean3=new AppDetVerificationDetailsBean(); 
		appDetVerificationDetailsBean3.setFieldlabel("EMAIL");
		appDetVerificationDetailsBean3.setVerificationsrc("Aadhar");
		List<AppDetVerificationDetailsBean> appDetVerificationDetailsBeans=new ArrayList<AppDetVerificationDetailsBean>();
		appDetVerificationDetailsBeans.add(appDetVerificationDetailsBean);
		appDetVerificationDetailsBeans.add(appDetVerificationDetailsBean2);
		appDetVerificationDetailsBeans.add(appDetVerificationDetailsBean3);
		applicantDetailBean.setAppDetVerificationDetails(appDetVerificationDetailsBeans);
		ApplicantEmplDetailsBean applicantEmplDetailsBean=new ApplicantEmplDetailsBean();
		applicantEmplDetailsBean.setEmploymentType(1L);
	
		List<ApplicantEmplDetailsBean> applicantEmplDetailsBeans=new ArrayList<ApplicantEmplDetailsBean>();
		applicantEmplDetailsBeans.add(applicantEmplDetailsBean);
		applicantDetailBean.setEmploymentTypeDetails(applicantEmplDetailsBeans);
		return applicantDetailBean;
	}
	
	private UserProfileDetailsRequest getProfileDetails() {
		UserProfileDetailsRequest userProfileDetailsReq=new UserProfileDetailsRequest();
		userProfileDetailsReq.setCurrentTask("personalDetails");
		userProfileDetailsReq.setMobileNumber("9999999999");
		userProfileDetailsReq.setSource("mobileapp");
		ApplicantKeysRequest userKeys=new ApplicantKeysRequest();
		userKeys.setApplicantKey(123456L);
		userProfileDetailsReq.setUserKeys(userKeys);
		return userProfileDetailsReq;
		
	}
	
	@Test
	public void testgetUserProfilesDetailsDataValidDetails() {
		UserProfileDetailsRequest profileDetails = getProfileDetails();
		ApplicantDetailBean applicantBean = getApplicantBean();
		Mockito.when(appOnBoardingUtils
				.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantBean);
		UserProfileDetailsResponse userProfilesDetails = appOnBoardingServiceImpl.getUserProfilesDetailsData(profileDetails, new HttpHeaders());
		assertNotNull(userProfilesDetails);
	}
	
	@Test
	public void testgetUserProfilesDetailsAbsent()
	{
		UserProfileDetailsRequest userProfileDetailsReq=new UserProfileDetailsRequest();
		userProfileDetailsReq.setCurrentTask("personalDetails");
		userProfileDetailsReq.setMobileNumber("9999999999");
		userProfileDetailsReq.setSource("mobileapp");
		ApplicantKeysRequest userKeys=new ApplicantKeysRequest();
		userKeys.setApplicantKey(123456L);
		userProfileDetailsReq.setUserKeys(userKeys);
		HttpHeaders headers=new HttpHeaders();
		ApplicantDetailBean applicantDetailBean=new ApplicantDetailBean();
		ApplicantEmailDetailsBean applicantEmailDetailsBean=new ApplicantEmailDetailsBean();
		List<ApplicantEmailDetailsBean> emailDetails=new ArrayList<ApplicantEmailDetailsBean>();
		emailDetails.add(applicantEmailDetailsBean);
		applicantDetailBean.setEmailDetails(emailDetails);
		ApplicantAddressDetailsBean applicantAddressDetailsBean=new ApplicantAddressDetailsBean();
		applicantAddressDetailsBean.setPinCode("123456");
		applicantAddressDetailsBean.setType("CURRENT");
		List<ApplicantAddressDetailsBean> addressDetailsBeans=new ArrayList<ApplicantAddressDetailsBean>();
		addressDetailsBeans.add(applicantAddressDetailsBean);
		applicantDetailBean.setAddressDetails(addressDetailsBeans);
		ApplicantPhoneNumberDetailsBean applicantPhoneNumberDetailsBean=new ApplicantPhoneNumberDetailsBean();
		applicantPhoneNumberDetailsBean.setMobileNumber("9999999999");
		applicantPhoneNumberDetailsBean.setType("OTHERS");
		List<ApplicantPhoneNumberDetailsBean> applicantPhoneNumberDetailsBeans=new ArrayList<ApplicantPhoneNumberDetailsBean>();
		applicantPhoneNumberDetailsBeans.add(applicantPhoneNumberDetailsBean);
		applicantDetailBean.setPhoneNumberDetails(applicantPhoneNumberDetailsBeans);
		AppDetVerificationDetailsBean appDetVerificationDetailsBean=new AppDetVerificationDetailsBean(); 
		AppDetVerificationDetailsBean appDetVerificationDetailsBean2=new AppDetVerificationDetailsBean(); 
		AppDetVerificationDetailsBean appDetVerificationDetailsBean3=new AppDetVerificationDetailsBean(); 
		List<AppDetVerificationDetailsBean> appDetVerificationDetailsBeans=new ArrayList<AppDetVerificationDetailsBean>();
		appDetVerificationDetailsBeans.add(appDetVerificationDetailsBean);
		appDetVerificationDetailsBeans.add(appDetVerificationDetailsBean2);
		appDetVerificationDetailsBeans.add(appDetVerificationDetailsBean3);
		applicantDetailBean.setAppDetVerificationDetails(appDetVerificationDetailsBeans);
		ApplicantEmplDetailsBean applicantEmplDetailsBean=new ApplicantEmplDetailsBean();
		applicantEmplDetailsBean.setEmploymentType(2L);
	
		List<ApplicantEmplDetailsBean> applicantEmplDetailsBeans=new ArrayList<ApplicantEmplDetailsBean>();
		applicantEmplDetailsBeans.add(applicantEmplDetailsBean);
		applicantDetailBean.setEmploymentTypeDetails(applicantEmplDetailsBeans);
		Mockito.when(appOnBoardingUtils
				.getProspectDetails(Mockito.anyString(), Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(new ProspectDetailsResponse());
		Mockito.when(appOnBoardingUtils
				.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantDetailBean);
		
		appOnBoardingServiceImpl.getUserProfilesDetailsData(userProfileDetailsReq, headers);
	}
	
	@Test
	public void testgetUserProfilesDetailsDataOtherType()
	{
		UserProfileDetailsRequest profileDetails = getProfileDetails();
		HttpHeaders headers=new HttpHeaders();
		ApplicantDetailBean applicantDetailBean=new ApplicantDetailBean();
		applicantDetailBean.setFirstName("Abc");
		applicantDetailBean.setLastName("Abc");
		applicantDetailBean.setPanNumber("ALYPM34569A");
		ApplicantEmailDetailsBean applicantEmailDetailsBean=new ApplicantEmailDetailsBean();
		applicantEmailDetailsBean.setEmailAddress("ABC@gmail.com");
		applicantEmailDetailsBean.setType("PERSON1");
		List<ApplicantEmailDetailsBean> emailDetails=new ArrayList<ApplicantEmailDetailsBean>();
		emailDetails.add(applicantEmailDetailsBean);
		applicantDetailBean.setEmailDetails(emailDetails);
		ApplicantPhoneNumberDetailsBean applicantPhoneNumberDetailsBean=new ApplicantPhoneNumberDetailsBean();
		applicantPhoneNumberDetailsBean.setMobileNumber("9999999999");
		applicantPhoneNumberDetailsBean.setType("OTHERS");
		List<ApplicantPhoneNumberDetailsBean> applicantPhoneNumberDetailsBeans=new ArrayList<ApplicantPhoneNumberDetailsBean>();
		applicantPhoneNumberDetailsBeans.add(applicantPhoneNumberDetailsBean);
		applicantDetailBean.setPhoneNumberDetails(applicantPhoneNumberDetailsBeans);
		AppDetVerificationDetailsBean appDetVerificationDetailsBean=new AppDetVerificationDetailsBean(); 
		appDetVerificationDetailsBean.setFieldlabel("NAME");
		appDetVerificationDetailsBean.setVerificationsrc("Aadhar");
		AppDetVerificationDetailsBean appDetVerificationDetailsBean2=new AppDetVerificationDetailsBean(); 
		appDetVerificationDetailsBean2.setFieldlabel("PAN");
		appDetVerificationDetailsBean2.setVerificationsrc("Aadhar");
		AppDetVerificationDetailsBean appDetVerificationDetailsBean3=new AppDetVerificationDetailsBean(); 
		appDetVerificationDetailsBean3.setFieldlabel("EMAIL");
		appDetVerificationDetailsBean3.setVerificationsrc("Aadhar");
		List<AppDetVerificationDetailsBean> appDetVerificationDetailsBeans=new ArrayList<AppDetVerificationDetailsBean>();
		appDetVerificationDetailsBeans.add(appDetVerificationDetailsBean);
		appDetVerificationDetailsBeans.add(appDetVerificationDetailsBean2);
		appDetVerificationDetailsBeans.add(appDetVerificationDetailsBean3);
		applicantDetailBean.setAppDetVerificationDetails(appDetVerificationDetailsBeans);
		ApplicantEmplDetailsBean applicantEmplDetailsBean=new ApplicantEmplDetailsBean();
		applicantEmplDetailsBean.setEmploymentType(3L);
	
		List<ApplicantEmplDetailsBean> applicantEmplDetailsBeans=new ArrayList<ApplicantEmplDetailsBean>();
		applicantEmplDetailsBeans.add(applicantEmplDetailsBean);
		applicantDetailBean.setEmploymentTypeDetails(applicantEmplDetailsBeans);
		Mockito.when(appOnBoardingUtils
				.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
			.thenReturn(applicantDetailBean);
		appOnBoardingServiceImpl.getUserProfilesDetailsData(profileDetails, headers);
	}
	
	@Test
	public void testgetUserProfilesDetailsDataOtherTypeDet()
	{
		UserProfileDetailsRequest userProfileDetailsReq=new UserProfileDetailsRequest();
		userProfileDetailsReq.setCurrentTask("personalDetails");
		userProfileDetailsReq.setMobileNumber("9999999999");
		userProfileDetailsReq.setSource("mobileapp");
		ApplicantKeysRequest userKeys=new ApplicantKeysRequest();
		userKeys.setApplicantKey(123456L);
		userProfileDetailsReq.setUserKeys(userKeys);
		HttpHeaders headers=new HttpHeaders();
		ApplicantDetailBean applicantDetailBean=new ApplicantDetailBean();
		applicantDetailBean.setFirstName("Abc");
		applicantDetailBean.setLastName("Abc");
		applicantDetailBean.setPanNumber("ALYPM34569A");
		ApplicantEmailDetailsBean applicantEmailDetailsBean=new ApplicantEmailDetailsBean();
		applicantEmailDetailsBean.setEmailAddress("ABC@gmail.com");
		applicantEmailDetailsBean.setType("PERSON1");
		List<ApplicantEmailDetailsBean> emailDetails=new ArrayList<ApplicantEmailDetailsBean>();
		emailDetails.add(applicantEmailDetailsBean);
		applicantDetailBean.setEmailDetails(emailDetails);
		ApplicantAddressDetailsBean applicantAddressDetailsBean=new ApplicantAddressDetailsBean();
		applicantAddressDetailsBean.setPinCode("123456");
		applicantAddressDetailsBean.setType("OTHERS");
		List<ApplicantAddressDetailsBean> addressDetailsBeans=new ArrayList<ApplicantAddressDetailsBean>();
		addressDetailsBeans.add(applicantAddressDetailsBean);
		applicantDetailBean.setAddressDetails(addressDetailsBeans);
		ApplicantPhoneNumberDetailsBean applicantPhoneNumberDetailsBean=new ApplicantPhoneNumberDetailsBean();
		applicantPhoneNumberDetailsBean.setMobileNumber("9999999999");
		applicantPhoneNumberDetailsBean.setType("OTHERS");
		List<ApplicantPhoneNumberDetailsBean> applicantPhoneNumberDetailsBeans=new ArrayList<ApplicantPhoneNumberDetailsBean>();
		applicantPhoneNumberDetailsBeans.add(applicantPhoneNumberDetailsBean);
		applicantDetailBean.setPhoneNumberDetails(applicantPhoneNumberDetailsBeans);
		AppDetVerificationDetailsBean appDetVerificationDetailsBean3=new AppDetVerificationDetailsBean(); 
		appDetVerificationDetailsBean3.setFieldlabel("EMAIL");
		appDetVerificationDetailsBean3.setVerificationsrc("Aadhar");
		List<AppDetVerificationDetailsBean> appDetVerificationDetailsBeans=new ArrayList<AppDetVerificationDetailsBean>();
		appDetVerificationDetailsBeans.add(appDetVerificationDetailsBean3);
		applicantDetailBean.setAppDetVerificationDetails(appDetVerificationDetailsBeans);
		ApplicantEmplDetailsBean applicantEmplDetailsBean=new ApplicantEmplDetailsBean();
		applicantEmplDetailsBean.setEmploymentType(3L);
	
		List<ApplicantEmplDetailsBean> applicantEmplDetailsBeans=new ArrayList<ApplicantEmplDetailsBean>();
		applicantEmplDetailsBeans.add(applicantEmplDetailsBean);
		applicantDetailBean.setEmploymentTypeDetails(applicantEmplDetailsBeans);
		Mockito.when(appOnBoardingUtils
				.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class))).thenReturn(applicantDetailBean);
		appOnBoardingServiceImpl.getUserProfilesDetailsData(userProfileDetailsReq, headers);
	}
	
	@Test
	public void testgetUserProfilesDetailsDataOtherTypeNoDet()
	{
		UserProfileDetailsRequest userProfileDetailsReq=new UserProfileDetailsRequest();
		userProfileDetailsReq.setCurrentTask("personalDetails");
		userProfileDetailsReq.setMobileNumber("9999999999");
		userProfileDetailsReq.setSource("mobileapp");
		ApplicantKeysRequest userKeys=new ApplicantKeysRequest();
		userKeys.setApplicantKey(123456L);
		userProfileDetailsReq.setUserKeys(userKeys);
		HttpHeaders headers=new HttpHeaders();
		ApplicantDetailBean applicantDetailBean=new ApplicantDetailBean();
		applicantDetailBean.setFirstName("Abc");
		applicantDetailBean.setLastName("Abc");
		applicantDetailBean.setPanNumber("ALYPM34569A");
		ApplicantEmailDetailsBean applicantEmailDetailsBean=new ApplicantEmailDetailsBean();
		applicantEmailDetailsBean.setEmailAddress("ABC@gmail.com");
		applicantEmailDetailsBean.setType("PERSON1");
		List<ApplicantEmailDetailsBean> emailDetails=new ArrayList<ApplicantEmailDetailsBean>();
		emailDetails.add(applicantEmailDetailsBean);
		applicantDetailBean.setEmailDetails(emailDetails);
		ApplicantAddressDetailsBean applicantAddressDetailsBean=new ApplicantAddressDetailsBean();
		applicantAddressDetailsBean.setPinCode("123456");
		applicantAddressDetailsBean.setType("OTHERS");
		List<ApplicantAddressDetailsBean> addressDetailsBeans=new ArrayList<ApplicantAddressDetailsBean>();
		addressDetailsBeans.add(applicantAddressDetailsBean);
		applicantDetailBean.setAddressDetails(addressDetailsBeans);
		ApplicantPhoneNumberDetailsBean applicantPhoneNumberDetailsBean=new ApplicantPhoneNumberDetailsBean();
		applicantPhoneNumberDetailsBean.setMobileNumber("9999999999");
		applicantPhoneNumberDetailsBean.setType("OTHERS");
		List<ApplicantPhoneNumberDetailsBean> applicantPhoneNumberDetailsBeans=new ArrayList<ApplicantPhoneNumberDetailsBean>();
		applicantPhoneNumberDetailsBeans.add(applicantPhoneNumberDetailsBean);
		applicantDetailBean.setPhoneNumberDetails(applicantPhoneNumberDetailsBeans);
		ApplicantEmplDetailsBean applicantEmplDetailsBean=new ApplicantEmplDetailsBean();
		applicantEmplDetailsBean.setEmploymentType(3L);
	
		List<ApplicantEmplDetailsBean> applicantEmplDetailsBeans=new ArrayList<ApplicantEmplDetailsBean>();
		applicantEmplDetailsBeans.add(applicantEmplDetailsBean);
		applicantDetailBean.setEmploymentTypeDetails(applicantEmplDetailsBeans);
		Mockito.when(appOnBoardingUtils
				.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class))).thenReturn(applicantDetailBean);
		appOnBoardingServiceImpl.getUserProfilesDetailsData(userProfileDetailsReq, headers);
	}
	
	@Test
	public void testgetUserProfilesDetailsDatawithProspect()
	{
		UserProfileDetailsRequest userProfileDetailsReq=new UserProfileDetailsRequest();
		userProfileDetailsReq.setCurrentTask("personalDetails");
		userProfileDetailsReq.setMobileNumber("9999999999");
		userProfileDetailsReq.setSource("mobileapp");
		ApplicantKeysRequest userKeys=new ApplicantKeysRequest();
		userKeys.setApplicantKey(123456L);
		userProfileDetailsReq.setUserKeys(userKeys);
		HttpHeaders headers=new HttpHeaders();
		ApplicantDetailBean applicantDetailBean=null;
		ProspectDetailsResponse prospect=new ProspectDetailsResponse();
		prospect.setEmailId("abc@gmail.com");
		prospect.setFirstName("abc");
		prospect.setLastName("abc");
		prospect.setMobileNo("9999999999");
		prospect.setPan("DRWPL3456L");
		ProspectAddressDetailsResponse prospectAddressDetailsResponse=new ProspectAddressDetailsResponse();
		prospectAddressDetailsResponse.setPincode("123456");
		List<ProspectAddressDetailsResponse> addressDetailsResponses=new ArrayList<ProspectAddressDetailsResponse>();
		addressDetailsResponses.add(prospectAddressDetailsResponse);
		prospect.setProspectAddress(addressDetailsResponses);
		Mockito.when(appOnBoardingUtils
				.getApplicantDetails(Mockito.anyString(), Mockito.any(HttpHeaders.class)))
		.thenReturn(applicantDetailBean);
		Mockito.when(appOnBoardingUtils.getProspectDetails(Mockito.anyString(),
				Mockito.anyString(), Mockito.any(HttpHeaders.class))).thenReturn(prospect);
		appOnBoardingServiceImpl.getUserProfilesDetailsData(userProfileDetailsReq, headers);
	}
	
	@Test
	public void testupdateApplicantDetailsNextTaskPersonalDetails()
	{
		UpdateUserProfileDetailsRequest profileDetailsPutReq=new UpdateUserProfileDetailsRequest();
		BureauDetails bureauDetails=new BureauDetails();
		PanDetailsBean panDetailsBean=new PanDetailsBean();
		panDetailsBean.setUserInput("DERP3456L");
		bureauDetails.setPan(panDetailsBean);
		profileDetailsPutReq.setBureauDetails(bureauDetails);
		PersonalDetails personalDetails=new PersonalDetails();
		NameDetails name=new NameDetails();
		name.setUserInput("abc");
		EmailDetails email=new EmailDetails();
		email.setUserInput("abc@gmail.com");
		PinCodeDetails pinCode=new PinCodeDetails();
		pinCode.setUserInput("40220");
		OccupationDetails occupationD=new OccupationDetails();
		occupationD.setUserInput("Salaried");
		personalDetails.setEmail(email);
		personalDetails.setName(name);
		personalDetails.setOccupation(occupationD);
		personalDetails.setPinCode(pinCode);
		profileDetailsPutReq.setPersonalDetails(personalDetails);
		UserKeysBean userKeys=new UserKeysBean();
		userKeys.setApplicantKey(123456L);
		HttpHeaders headers=new HttpHeaders();
		Occupation occupation=new Occupation();
		Reference ocupationType=new Reference();
		occupation.setOcupationType(ocupationType);
		profileDetailsPutReq.setCurrentTask("personalDetails");
		profileDetailsPutReq.setSource(AuthenticationServiceConstants.MOBILEAPP);
		Mockito.when(estoreAuthenticationHelper.mapOccupationData(profileDetailsPutReq))
			.thenReturn(occupation);
		appOnBoardingServiceImpl.updateApplicantDetails(profileDetailsPutReq, headers);
	}
	
	@Test
	public void testupdateApplicantDetailsBureauNextTask() {
		UpdateUserProfileDetailsRequest profileDetailsPutReq=new UpdateUserProfileDetailsRequest();
		BureauDetails bureauDetails=new BureauDetails();
		PanDetailsBean panDetailsBean=new PanDetailsBean();
		panDetailsBean.setUserInput("DERP3456L");
		bureauDetails.setPan(panDetailsBean);
		profileDetailsPutReq.setBureauDetails(bureauDetails);
		PersonalDetails personalDetails=new PersonalDetails();
		NameDetails name=new NameDetails();
		name.setUserInput("abc");
		EmailDetails email=new EmailDetails();
		email.setUserInput("abc@gmail.com");
		PinCodeDetails pinCode=new PinCodeDetails();
		pinCode.setUserInput("40220");
		OccupationDetails occupationD=new OccupationDetails();
		occupationD.setUserInput("Salaried");
		personalDetails.setEmail(email);
		personalDetails.setName(name);
		personalDetails.setOccupation(occupationD);
		personalDetails.setPinCode(pinCode);
		profileDetailsPutReq.setPersonalDetails(personalDetails);
		HttpHeaders headers=new HttpHeaders();
		Occupation occupation=new Occupation();
		Reference ocupationType=new Reference();
		ocupationType.setValue("Salaried");
		occupation.setOcupationType(ocupationType);
		profileDetailsPutReq.setCurrentTask("bureauDetails");
		Mockito.when(estoreAuthenticationHelper.mapOccupationData(profileDetailsPutReq))
			.thenReturn(occupation);
		appOnBoardingServiceImpl.updateApplicantDetails(profileDetailsPutReq, headers);
	}
	
	@Test
	public void testupdateApplicantDetailsNextTaskHome()
	{
		UpdateUserProfileDetailsRequest profileDetailsPutReq=new UpdateUserProfileDetailsRequest();
		BureauDetails bureauDetails=new BureauDetails();
		PanDetailsBean panDetailsBean=new PanDetailsBean();
		panDetailsBean.setUserInput("DERP3456L");
		bureauDetails.setPan(panDetailsBean);
		profileDetailsPutReq.setBureauDetails(bureauDetails);
		PersonalDetails personalDetails=new PersonalDetails();
		NameDetails name=new NameDetails();
		name.setUserInput("abc");
		EmailDetails email=new EmailDetails();
		email.setUserInput("abc@gmail.com");
		PinCodeDetails pinCode=new PinCodeDetails();
		pinCode.setUserInput("40220");
		OccupationDetails occupationD=new OccupationDetails();
		occupationD.setUserInput("Salaried");
		personalDetails.setEmail(email);
		personalDetails.setName(name);
		personalDetails.setOccupation(occupationD);
		personalDetails.setPinCode(pinCode);
		profileDetailsPutReq.setPersonalDetails(personalDetails);
		UserKeysBean userKeys=new UserKeysBean();
		userKeys.setApplicantKey(123456L);
		HttpHeaders headers=new HttpHeaders();
		Occupation occupation=new Occupation();
		Reference ocupationType=new Reference();
		occupation.setOcupationType(ocupationType);
		Mockito.when(appOnBoardingUtils.getPinCodeDetails(Mockito.any(UpdateUserProfileDetailsRequest.class), Mockito.any(HttpHeaders.class)))
				.thenReturn(new LocationAddressBean());
		Mockito.when(estoreAuthenticationHelper.mapOccupationData(profileDetailsPutReq))
			.thenReturn(occupation);
		appOnBoardingServiceImpl.updateApplicantDetails(profileDetailsPutReq, headers);
	}
	
	@Test
	public void testupdateApplicantDetailsNoDetails()
	{
		UpdateUserProfileDetailsRequest profileDetailsPutReq=new UpdateUserProfileDetailsRequest();
		NameDetails name=new NameDetails();
		name.setUserInput("abc");
		EmailDetails email=new EmailDetails();
		email.setUserInput("abc@gmail.com");
		PinCodeDetails pinCode=new PinCodeDetails();
		pinCode.setUserInput("40220");
		OccupationDetails occupationD=new OccupationDetails();
		occupationD.setUserInput("Salaried");
		UserKeysBean userKeys=new UserKeysBean();
		userKeys.setApplicantKey(123456L);
		HttpHeaders headers=new HttpHeaders();
		Occupation occupation=new Occupation();
		Reference ocupationType=new Reference();
		occupation.setOcupationType(ocupationType);
		Mockito.when(estoreAuthenticationHelper.mapOccupationData(profileDetailsPutReq))
			.thenReturn(occupation);
		appOnBoardingServiceImpl.updateApplicantDetails(profileDetailsPutReq, headers);
	}
	
	@Test
	public void testVerifyApplicantPanDetails_Success() {
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		request.setPanNumber("AABBCCDD");
		request.setSkipped(false);
		request.setUserKeys(new ApplicantKeysRequest());
		PanVerificationResponse panVerificationResponse = new PanVerificationResponse();
		panVerificationResponse.setPanFName("First");
		panVerificationResponse.setPanMName("Middle");
		panVerificationResponse.setPanLName("Last");
		panVerificationResponse.setPanStatus(AuthenticationServiceConstants.PAN_VERIFIED_SUCCESSFUL_STATUS);
		MobileAppOnBoardingResponse response = new MobileAppOnBoardingResponse();
		response.setSkipFlag(false);
		Mockito.when(appOnBoardingUtils.updateApplicantMobAppOnBoardingStatus(Mockito.any(UpdateMobileAppOnBoardingRequest.class), Mockito.any(HttpHeaders.class)))
			.thenReturn(response);
		Mockito.when(appOnBoardingUtils.getApplicantNsdlPanVerificationStatus(Mockito.any(PanProfileDetailsRequest.class), Mockito.any(HttpHeaders.class)))
			.thenReturn(panVerificationResponse);
		PanProfileDetailsResponse applicantPanVerificationStatus = appOnBoardingServiceImpl.verifyApplicantPanDetails(request, new HttpHeaders());
		assertEquals(applicantPanVerificationStatus.getPanVerifiedFlag(), AuthenticationServiceConstants.YES);
	}
	
	@Test
	public void testVerifyApplicantPanDetails_VerificationFailure() {
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		request.setPanNumber("AABBCCDD");
		request.setSkipped(false);
		request.setUserKeys(new ApplicantKeysRequest());
		PanVerificationResponse panVerificationResponse = new PanVerificationResponse();
		panVerificationResponse.setPanStatus("invalid status");
		MobileAppOnBoardingResponse response = new MobileAppOnBoardingResponse();
		response.setSkipFlag(false);
		Mockito.when(appOnBoardingUtils.updateApplicantMobAppOnBoardingStatus(Mockito.any(UpdateMobileAppOnBoardingRequest.class), Mockito.any(HttpHeaders.class)))
			.thenReturn(response);
		Mockito.when(appOnBoardingUtils.getApplicantNsdlPanVerificationStatus(Mockito.any(PanProfileDetailsRequest.class), Mockito.any(HttpHeaders.class)))
			.thenReturn(panVerificationResponse);
		PanProfileDetailsResponse applicantPanVerificationStatus = appOnBoardingServiceImpl.verifyApplicantPanDetails(request, new HttpHeaders());
		assertEquals(applicantPanVerificationStatus.getPanVerifiedFlag(), AuthenticationServiceConstants.NO);
	}
	
	@Test
	public void testVerifyApplicantPanDetails_BlankStatusFailure() {
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		request.setPanNumber("AABBCCDD");
		request.setSkipped(false);
		request.setUserKeys(new ApplicantKeysRequest());
		PanVerificationResponse panVerificationResponse = new PanVerificationResponse();
		MobileAppOnBoardingResponse response = new MobileAppOnBoardingResponse();
		response.setSkipFlag(false);
		Mockito.when(appOnBoardingUtils.updateApplicantMobAppOnBoardingStatus(Mockito.any(UpdateMobileAppOnBoardingRequest.class), Mockito.any(HttpHeaders.class)))
			.thenReturn(response);
		Mockito.when(appOnBoardingUtils.getApplicantNsdlPanVerificationStatus(Mockito.any(PanProfileDetailsRequest.class), Mockito.any(HttpHeaders.class)))
			.thenReturn(panVerificationResponse);
		PanProfileDetailsResponse applicantPanVerificationStatus = appOnBoardingServiceImpl.verifyApplicantPanDetails(request, new HttpHeaders());
		assertEquals(applicantPanVerificationStatus.getPanVerifiedFlag(), AuthenticationServiceConstants.NO);
	}

	@Test
	public void testVerifyApplicantPanDetails_NsdlAPIFailure() {
		ApplicantKeysRequest key = new ApplicantKeysRequest();
		key.setApplicantKey(1234L);
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		request.setPanNumber("AABBCCDD");
		request.setSkipped(false);
		request.setUserKeys(key);
		MobileAppOnBoardingResponse response = new MobileAppOnBoardingResponse();
		response.setSkipFlag(false);
		Mockito.when(appOnBoardingUtils.updateApplicantMobAppOnBoardingStatus(Mockito.any(UpdateMobileAppOnBoardingRequest.class), Mockito.any(HttpHeaders.class)))
			.thenReturn(response);
		Mockito.when(appOnBoardingUtils.getApplicantNsdlPanVerificationStatus(Mockito.any(PanProfileDetailsRequest.class), Mockito.any(HttpHeaders.class)))
			.thenThrow(new BFLBusinessException());
		appOnBoardingServiceImpl.verifyApplicantPanDetails(request, new HttpHeaders());
	}
	
	@Test
	public void testVerifyApplicantPanDetailsSkippedTrue() {
		ApplicantKeysRequest key = new ApplicantKeysRequest();
		key.setApplicantKey(1234L);
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		request.setPanNumber("AABBCCDD");
		request.setSkipped(true);
		request.setUserKeys(key);
		MobileAppOnBoardingResponse response = new MobileAppOnBoardingResponse();
		response.setSkipFlag(true);
		Mockito.when(appOnBoardingUtils.updateApplicantMobAppOnBoardingStatus(Mockito.any(UpdateMobileAppOnBoardingRequest.class), Mockito.any(HttpHeaders.class)))
			.thenReturn(response);
		Mockito.when(appOnBoardingUtils.getApplicantNsdlPanVerificationStatus(Mockito.any(PanProfileDetailsRequest.class), Mockito.any(HttpHeaders.class)))
			.thenThrow(new BFLBusinessException());
		PanProfileDetailsResponse verifiedDetails = appOnBoardingServiceImpl.verifyApplicantPanDetails(request, new HttpHeaders());
		assertNotNull(verifiedDetails);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testVerifyApplicantPanDetailsExceptionFailure() {
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		request.setPanNumber("AABBCCDD");
		appOnBoardingServiceImpl.verifyApplicantPanDetails(request, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testVerifyApplicantPanDetailsSkipUpdationFailure() {
		ApplicantKeysRequest key = new ApplicantKeysRequest();
		key.setApplicantKey(1234L);
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		request.setPanNumber("AABBCCDD");
		request.setUserKeys(key);
		
		Mockito.when(appOnBoardingUtils.updateApplicantMobAppOnBoardingStatus(Mockito.any(UpdateMobileAppOnBoardingRequest.class), Mockito.any(HttpHeaders.class)))
		.thenThrow(new BFLTechnicalException());
		appOnBoardingServiceImpl.verifyApplicantPanDetails(request, new HttpHeaders());
	}
	
	@Test
	public void testUpdateProfilesDetails_AllDetailsUpdate() {
		ApplicantKeysRequest userKeys = new ApplicantKeysRequest();
		userKeys.setApplicantKey(1L);
		UpdatePanProfileRequest request = new UpdatePanProfileRequest();
		request.setName("First Middle Last");
		request.setPanNumber("AABBCCDD");
		request.setPanVerifiedFlag(AuthenticationServiceConstants.YES);
		request.setPincode("411001");
		request.setUserKeys(userKeys);
		UserProfileAttribute profile = new UserProfileAttribute();
		LocationAddressBean location = new LocationAddressBean();
		Mockito.when(estoreAuthenticationHelper.mapFullNameData(Mockito.any(UpdateUserProfileDetailsRequest.class)))
			.thenReturn(profile);
		Mockito.when(appOnBoardingUtils.getPinCodeDetails(Mockito.any(UpdateUserProfileDetailsRequest.class),
				Mockito.any(HttpHeaders.class)))
				.thenReturn(location);
		UpdatePanProfileResponse updatedProfilesDetails = appOnBoardingServiceImpl.updateProfilesDetails(request, new HttpHeaders());
		assertNotNull(updatedProfilesDetails);
	}
	
	@Test
	public void testUpdateProfilesDetails_OnlyNameUpdate() {
		ApplicantKeysRequest userKeys = new ApplicantKeysRequest();
		userKeys.setApplicantKey(1L);
		UpdatePanProfileRequest request = new UpdatePanProfileRequest();
		request.setName("First Middle Last");
		request.setPanVerifiedFlag(AuthenticationServiceConstants.YES);
		request.setUserKeys(userKeys);
		UserProfileAttribute profile = new UserProfileAttribute();
		Mockito.when(estoreAuthenticationHelper.mapFullNameData(Mockito.any(UpdateUserProfileDetailsRequest.class)))
			.thenReturn(profile);
		UpdatePanProfileResponse updatedProfilesDetails = appOnBoardingServiceImpl.updateProfilesDetails(request, new HttpHeaders());
		assertNotNull(updatedProfilesDetails);
	}

	@Test(expected = BFLTechnicalException.class)
	public void testUpdateProfilesDetails_NameApiFailed() {
		ApplicantKeysRequest userKeys = new ApplicantKeysRequest();
		userKeys.setApplicantKey(1L);
		UpdatePanProfileRequest request = new UpdatePanProfileRequest();
		request.setName("First Middle Last");
		request.setPanNumber("AABBCCDD");
		request.setPanVerifiedFlag(AuthenticationServiceConstants.YES);
		request.setPincode("411001");
		request.setUserKeys(userKeys);
		Mockito.when(estoreAuthenticationHelper.mapFullNameData(Mockito.any(UpdateUserProfileDetailsRequest.class)))
			.thenThrow(new NullPointerException());
		appOnBoardingServiceImpl.updateProfilesDetails(request, new HttpHeaders());
	}
	
	@Test(expected = Test.None.class)
	public void testUpdateProfilesDetails_PinCodeApiFailed() {
		ApplicantKeysRequest userKeys = new ApplicantKeysRequest();
		userKeys.setApplicantKey(1L);
		UpdatePanProfileRequest request = new UpdatePanProfileRequest();
		request.setName("First Middle Last");
		request.setPanNumber("AABBCCDD");
		request.setPanVerifiedFlag(AuthenticationServiceConstants.YES);
		request.setPincode("411001");
		request.setUserKeys(userKeys);
		UserProfileAttribute profile = new UserProfileAttribute();
		Mockito.when(estoreAuthenticationHelper.mapFullNameData(Mockito.any(UpdateUserProfileDetailsRequest.class)))
			.thenReturn(profile);
		Mockito.when(appOnBoardingUtils.getPinCodeDetails(Mockito.any(UpdateUserProfileDetailsRequest.class),
				Mockito.any(HttpHeaders.class)))
				.thenThrow(new BFLHttpException());
		appOnBoardingServiceImpl.updateProfilesDetails(request, new HttpHeaders());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testUpdateProfilesDetails_PanUpdateApiFailed() {
		ApplicantKeysRequest userKeys = new ApplicantKeysRequest();
		userKeys.setApplicantKey(1L);
		UpdatePanProfileRequest request = new UpdatePanProfileRequest();
		request.setName("First Middle Last");
		request.setPanNumber("AABBCCDD");
		request.setPanVerifiedFlag(AuthenticationServiceConstants.YES);
		request.setPincode("411001");
		request.setUserKeys(userKeys);
		Mockito.when(appOnBoardingUtils.updatePanDetails(Mockito.any(UpdateUserProfileDetailsRequest.class),
				Mockito.any(Verification.class), Mockito.any(HttpHeaders.class)))
				.thenThrow(new BFLHttpException());
		appOnBoardingServiceImpl.updateProfilesDetails(request, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testUpdateProfilesDetails_SomeException() {
		ApplicantKeysRequest userKeys = new ApplicantKeysRequest();
		userKeys.setApplicantKey(1L);
		UpdatePanProfileRequest request = new UpdatePanProfileRequest();
		request.setName("First Middle Last");
		request.setPanNumber("AABBCCDD");
		request.setPanVerifiedFlag(AuthenticationServiceConstants.YES);
		request.setPincode("411001");
		request.setUserKeys(userKeys);
		Mockito.when(appOnBoardingUtils.updatePanDetails(Mockito.any(UpdateUserProfileDetailsRequest.class),
				Mockito.any(Verification.class), Mockito.any(HttpHeaders.class)))
				.thenThrow(new NullPointerException());
		appOnBoardingServiceImpl.updateProfilesDetails(request, new HttpHeaders());
	}
	
}

