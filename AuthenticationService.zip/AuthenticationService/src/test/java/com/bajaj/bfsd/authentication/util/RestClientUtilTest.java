package com.bajaj.bfsd.authentication.util;

import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.authentication.model.GenerateTokenRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.common.BFLLoggerUtil;

@RunWith(SpringJUnit4ClassRunner.class)
public class RestClientUtilTest {
	
	@InjectMocks
	private RestClientUtil restClientUtil;
	
	@Mock
	private BFLLoggerUtil logger;
	
	@Mock
	private Environment env;
	
	@Mock 
	private RestTemplate restTemplate;

	@Test
	public void testPostCall() {
		ResponseEntity<TokenResponse> tokenResponse = new ResponseEntity<>(new TokenResponse(), HttpStatus.OK);
		Mockito.when(restTemplate.exchange(Mockito.anyString(),Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(TokenResponse.class)))
			.thenReturn(tokenResponse);
		ResponseEntity<TokenResponse> postCallResponse = restClientUtil.postCall("http://www.example.com", new GenerateTokenRequest(), new HttpHeaders(), 
				TokenResponse.class);
		assertNotNull(postCallResponse);

	}
	
	@Test(expected = RestClientException.class)
	public void testPostCall_ThrowsRestClientException() {
		Mockito.when(restTemplate.exchange(Mockito.anyString(),Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(TokenResponse.class)))
			.thenThrow(new RestClientException("exception in restCall"));
		restClientUtil.postCall("http://www.example.com", new GenerateTokenRequest(), new HttpHeaders(), 
				TokenResponse.class);
	}
	
	@Test(expected = NullPointerException.class)
	public void testPostCall_ThrowsSomeException() {
		Mockito.when(restTemplate.exchange(Mockito.anyString(),Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(TokenResponse.class)))
			.thenThrow(new NullPointerException());
		restClientUtil.postCall("http://www.example.com", new GenerateTokenRequest(), new HttpHeaders(), 
				TokenResponse.class);
	}
	
	@Test
	public void testGetCall() {
		MultiValueMap<String, String> queryParam = new LinkedMultiValueMap<>();
		queryParam.add("term", "product");
		queryParam.add("term", "product2");
		queryParam.add("mobile", "9999999999");

		Map<String, String> pathParam = new HashMap<>();
		pathParam.put("key", "123");
		ResponseEntity<TokenResponse> tokenResponse = new ResponseEntity<>(new TokenResponse(), HttpStatus.OK);
		Mockito.when(restTemplate.exchange(Mockito.anyString(),Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(TokenResponse.class)))
			.thenReturn(tokenResponse);
		ResponseEntity<TokenResponse> getCallResponse = restClientUtil.getCall("http://www.example.com/{key}",
				queryParam, pathParam, new HttpHeaders(), TokenResponse.class);
		assertNotNull(getCallResponse);
	}
	
	@Test(expected = RestClientException.class)
	public void testGetCall_ThrowsRestClientException() {
		Mockito.when(restTemplate.exchange(Mockito.anyString(),Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(TokenResponse.class)))
			.thenThrow(new RestClientException("exception in restCall"));
		restClientUtil.getCall("http://www.example.com/",
				null, null, new HttpHeaders(), TokenResponse.class);
	}

	@Test(expected = NullPointerException.class)
	public void testGetCall_ThrowsSomeException() {
		MultiValueMap<String, String> queryParam = new LinkedMultiValueMap<String, String>();
		Map<String, String> pathParam = new HashMap<>();
		Mockito.when(restTemplate.exchange(Mockito.anyString(),Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(TokenResponse.class)))
			.thenThrow(new NullPointerException());
		restClientUtil.getCall("http://www.example.com/",
				queryParam, pathParam, null, TokenResponse.class);	
	}
	
	@Test
	public void testPutCall() {
		ResponseEntity<TokenResponse> tokenResponse = new ResponseEntity<>(new TokenResponse(), HttpStatus.OK);
		Mockito.when(restTemplate.exchange(Mockito.anyString(),Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(TokenResponse.class)))
			.thenReturn(tokenResponse);
		ResponseEntity<TokenResponse> putCallResponse = restClientUtil.putCall("http://www.example.com", null, 
				new GenerateTokenRequest(), new HttpHeaders(), TokenResponse.class);
		assertNotNull(putCallResponse);
	}
	
	@Test(expected = RestClientException.class)
	public void testPutCall_ThrowsRestClientException() {
		Mockito.when(restTemplate.exchange(Mockito.anyString(),Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(TokenResponse.class)))
			.thenThrow(new RestClientException("exception in restCall"));
		restClientUtil.putCall("http://www.example.com/",
				null, new GenerateTokenRequest(), new HttpHeaders(), TokenResponse.class);
	}

	@Test(expected = Exception.class)
	public void testPutCall_ThrowsSomeException() {
		Mockito.when(restTemplate.exchange(Mockito.anyString(),Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class), Mockito.eq(TokenResponse.class)))
			.thenThrow(new NullPointerException());

		restClientUtil.putCall("http://www.example.com/",
				null, new GenerateTokenRequest(), null, TokenResponse.class);	
	}
	
}
