package com.bajaj.bfsd.authentication.service;

import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.authentication.bean.UserResponse;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.service.impl.OMAuthenticationServiceImpl;
import com.bajaj.bfsd.authentication.util.TokenCodeHelper;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.clients.BFLCommonRestClientImpl;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bfl.common.exceptions.BFLHttpException;

@SpringBootTest
@SpringBootConfiguration
@RunWith(PowerMockRunner.class)
public class OMAuthenticationServiceImplTest {

	@InjectMocks
	OMAuthenticationServiceImpl omAuthenticationService;

	@Mock
	BFLLoggerUtilExt logger;

	private BFLCommonRestClient bflCommonRestClient;
	private BFLCommonRestClientImpl bflRestClientImpl;

	@Mock
	private TokenCodeHelper tokenCodeHelper;


	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

		bflRestClientImpl = PowerMockito.mock(BFLCommonRestClientImpl.class);
		ApplicationContext staticApplicationContext = PowerMockito.mock(ApplicationContext.class);
		bflCommonRestClient = PowerMockito.mock(BFLCommonRestClient.class);
		ReflectionTestUtils.setField(bflCommonRestClient, "staticApplicationContext", staticApplicationContext);
		Mockito.when(staticApplicationContext.getBean(BFLCommonRestClientImpl.class)).thenReturn(bflRestClientImpl);
	}

	@Test
	public void testAuthenticateMobDobAndGenerateToken_ValidOTP() {
		MobileLoginRequest loginRequest = buildMobileLoginRequest();

		ResponseBean validateTokenResponseBean = new ResponseBean("SUCCESS");
		ResponseEntity<?> validateOtpResponse = new ResponseEntity<Object>(validateTokenResponseBean, HttpStatus.OK);

		ResponseEntity<?> getApplicantResponse = new ResponseEntity<Object>("{\"applicantKey\":12345}", HttpStatus.OK);

		UserResponse userResponse = new UserResponse();
		userResponse.setLoginId("9999999999_1900-10-10");
		userResponse.setUserId(9999999999l);
		userResponse.setUserType((short) 10);

		ResponseEntity<?> userAdditionalDetRepsponse = new ResponseEntity<Object>(userResponse, HttpStatus.CREATED);

		List<Tokens> tokens = new ArrayList<Tokens>();
		Tokens token = new Tokens();
		token.setToken("authtoken");
		token.setGuardKey("guardkey");
		token.setType("authtoken");

		tokens.add(token);

		TokenResponse tokenResponse = new TokenResponse();
		tokenResponse.setTokens(tokens);
		tokenResponse.setDefaultRole("userrole");
		tokenResponse.setUserKey(1234l);
		
		ResponseBean tokenServiceResponseBean = new ResponseBean(tokenResponse);
		ResponseEntity<?> tokenServiceResponse = new ResponseEntity<Object>(tokenServiceResponseBean, HttpStatus.OK);

		doReturn(validateOtpResponse).doReturn(getApplicantResponse).doReturn(userAdditionalDetRepsponse)
				.doReturn(tokenServiceResponse).when(bflRestClientImpl).invokeRestEndpoint(Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

		Mockito.when(tokenCodeHelper.getApplicant(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(1234L);
		Mockito.when(tokenCodeHelper.getToken(Mockito.anyString(), Mockito.anyLong(), Mockito.anyShort()))
				.thenReturn(new TokenResponse());
		
		Mockito.when(tokenCodeHelper.callUserAdditionalDet(Mockito.any(MobileLoginRequest.class),
				Mockito.anyShort(), Mockito.anyLong()))
				.thenReturn(userResponse);

		Assert.assertNotNull(omAuthenticationService.authenticateMobDobAndGenerateToken(loginRequest));
	}

	@Test(expected = BFLHttpException.class)
	public void testAuthenticateMobDobAndGenerateToken_ValidOTPError() {
		MobileLoginRequest loginRequest = buildMobileLoginRequest();

		ResponseBean validateTokenResponseBean = new ResponseBean(null);
		ResponseEntity<?> validateOtpResponse = new ResponseEntity<Object>(validateTokenResponseBean,
				HttpStatus.INTERNAL_SERVER_ERROR);

		doReturn(validateOtpResponse).when(bflRestClientImpl).invokeRestEndpoint(Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

		omAuthenticationService.authenticateMobDobAndGenerateToken(loginRequest);
	}

	@Test(expected = BFLHttpException.class)
	public void testAuthenticateMobDobAndGenerateToken_InvalidOTP() {
		MobileLoginRequest loginRequest = buildMobileLoginRequest();

		List<ErrorBean> errorBeans = new ArrayList<ErrorBean>();
		ErrorBean errorBean = new ErrorBean("BFSD_500", "OTP is invalid");
		errorBeans.add(errorBean);
		ResponseBean validateTokenResponseBean = new ResponseBean(errorBeans);
		ResponseEntity<?> validateOtpResponse = new ResponseEntity<Object>(validateTokenResponseBean,
				HttpStatus.INTERNAL_SERVER_ERROR);

		doReturn(validateOtpResponse).when(bflRestClientImpl).invokeRestEndpoint(Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

		omAuthenticationService.authenticateMobDobAndGenerateToken(loginRequest);
	}

	private MobileLoginRequest buildMobileLoginRequest() {
		MobileLoginRequest loginRequest = new MobileLoginRequest();
		loginRequest.setMobile("9999999999");
		loginRequest.setSource("journey");
		loginRequest.setOtp("123456");
		loginRequest.setDateOfBirth("1900-10-10");
		loginRequest.setApplicationKey(123456l);

		return loginRequest;
	}
}
