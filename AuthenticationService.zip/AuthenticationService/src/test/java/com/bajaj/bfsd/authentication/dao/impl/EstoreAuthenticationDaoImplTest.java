package com.bajaj.bfsd.authentication.dao.impl;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;

import com.bajaj.bfsd.authentication.model.Userapplicants;
import com.bajaj.bfsd.authentication.repository.UserApplicantRepository;
import com.bajaj.bfsd.authentication.util.DataFormatter;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bfl.common.exceptions.BFLHttpException;

@RunWith(SpringRunner.class)
public class EstoreAuthenticationDaoImplTest {
	
	@InjectMocks
	EstoreAuthenticationDaoImpl estoreAuthenticationDaoImpl;
	
	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	EntityManager entityManager;
	
	@Mock
	private Environment env;
	
	@Mock
	Query query;
	
	@Mock
	UserApplicantRepository userApplicantRepository;
	
	@Mock
	private DataFormatter dataFormatter;

	@Test
	public void testcheckLoginIdExistanceForEstore() {
		String loginId="9975524233";
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString()))
			.thenReturn(query);
		Mockito.when(query.getSingleResult())
			.thenReturn(1L);
		Mockito.when(dataFormatter.dateStringToDate(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(new Date());
		int loginCount = estoreAuthenticationDaoImpl.checkLoginIdExistanceForEstore(loginId, "01-01-1979");
		assertEquals(loginCount, 1);
	}
	
	@Test
	public void testcheckLoginIdExistanceForEstorewithlogintypewithNodob() {
		String loginId="9975524233";
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString()))
			.thenReturn(query);
		Mockito.when(query.getSingleResult())
		.thenReturn(1L);
		int loginCount = estoreAuthenticationDaoImpl.checkLoginIdExistanceForEstore(loginId, "");
		assertEquals(loginCount, 1);
	}
	
	
	@Test(expected=BFLHttpException.class)
	public void testcheckLoginIdExistanceForEstoreSomeException() {
		String loginId="9975524233";
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString()))
			.thenReturn(query);
		estoreAuthenticationDaoImpl.checkLoginIdExistanceForEstore(loginId, null);
	}
	
	@Test
	public void testgetUserProfile() {
		List<Timestamp> resultList = new ArrayList<>();
		resultList.add(new Timestamp(1670003432423L));
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString()))
			.thenReturn(query);
		Mockito.when(query.getResultList())
			.thenReturn(resultList);
		estoreAuthenticationDaoImpl.getUserProfile("987654321");
	}
	
	@Test(expected=BFLHttpException.class)
	public void testgetUserProfileSomeExcpetion() {
		Mockito.when(entityManager.createNativeQuery(Mockito.anyString()))
			.thenReturn(query);
		estoreAuthenticationDaoImpl.getUserProfile("987654321");
	}
	
	@Test
	public void testgetApplicantId() {
		long userId= 53446;
		Mockito.when(entityManager.createQuery(Mockito.anyString()))
			.thenReturn(query);
		Mockito.when(query.getSingleResult())
			.thenReturn(1L);
		long applicantId = estoreAuthenticationDaoImpl.getApplicantId(userId);
		assertEquals(applicantId, 1);
	}
	
	@Test(expected = Test.None.class)
	public void testgetApplicantIdSomeException() {
		long userId= 53446;
		Mockito.when(entityManager.createQuery(Mockito.anyString()))
			.thenReturn(query);
		long applicantId = estoreAuthenticationDaoImpl.getApplicantId(userId);
		assertEquals(applicantId, 0);
	}
	
	@Test
	public void testgetApplicantRecord() {
		long applicantId= 53446;
		Mockito.when(entityManager.createQuery(Mockito.anyString()))
			.thenReturn(query);
		Mockito.when(query.getSingleResult())
			.thenReturn(1L);
		int applicantRecord = estoreAuthenticationDaoImpl.getApplicantRecord(applicantId);
		assertEquals(applicantRecord, 1);
	}
	
	@Test(expected = Test.None.class)
	public void testgetApplicantRecordSomeException() {
		long applicantId= 53446;
		Mockito.when(entityManager.createQuery(Mockito.anyString()))
			.thenReturn(query);
		estoreAuthenticationDaoImpl.getApplicantRecord(applicantId);
	}
	
	@Test
	public void testgetuserApplicant() {
		Userapplicants userApplicant= new Userapplicants();
		userApplicant.setApplicantkey(new BigDecimal("123456"));
		userApplicant.setUserapplicantkey(123453);
		userApplicant.setUserkey(new BigDecimal("654321"));
		Mockito.when(userApplicantRepository.findByApplicantkey(Mockito.any(BigDecimal.class)))
			.thenReturn(userApplicant);
		estoreAuthenticationDaoImpl.getuserApplicant(new BigDecimal("123456"));
	}

	
	@Test(expected = Test.None.class)
	public void testgetuserApplicantSomeException() {
		Userapplicants userApplicant= new Userapplicants();
		userApplicant.setApplicantkey(new BigDecimal("123456"));
		userApplicant.setUserapplicantkey(123453);
		userApplicant.setUserkey(new BigDecimal("654321"));
		Mockito.when(userApplicantRepository.findByApplicantkey(Mockito.any(BigDecimal.class)))
			.thenThrow(new HibernateException("Some exception"));
		estoreAuthenticationDaoImpl.getuserApplicant(new BigDecimal("123456"));
	}
}
