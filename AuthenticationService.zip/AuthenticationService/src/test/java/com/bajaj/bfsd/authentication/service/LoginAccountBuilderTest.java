package com.bajaj.bfsd.authentication.service;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.authentication.bean.SystemTokenRequest;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.DataFormatter;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@TestPropertySource(value={"classpath:/error.properties","classpath:/authenticationApplication.properties"})
@ContextConfiguration(loader = AnnotationConfigContextLoader.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class LoginAccountBuilderTest {

	@Mock
	BFLLoggerUtil logger;
	
	@Mock
	DataFormatter dataFormatter;

	@Autowired
	private Environment env;
	
	@InjectMocks
	private LoginAccountBuilder loginAccountBuilder;
	
	@Before
	public void setUp() throws JsonParseException, JsonMappingException, IOException {
		
		ReflectionTestUtils.setField(loginAccountBuilder, "productList", env.getProperty("product.list"));
		ReflectionTestUtils.setField(loginAccountBuilder, "logger", logger);
		ReflectionTestUtils.setField(loginAccountBuilder, "dataFormatter", dataFormatter);
	}	
	
	@Test
	public void test_getLoginAccountFromProductCode() {
		
		SystemTokenRequest systemTokenRequest = new SystemTokenRequest();
		systemTokenRequest.setProductCode("HGI");
		assertNotNull(loginAccountBuilder.getLoginAccountFromProductCode(systemTokenRequest));
	}
	
	@Test(expected=Exception.class)
	public void test_getLoginAccountFromProductCodeException() {
		
		SystemTokenRequest systemTokenRequest = new SystemTokenRequest();
		systemTokenRequest.setProductCode("abc");
		loginAccountBuilder.getLoginAccountFromProductCode(systemTokenRequest);
	}
	
	@Test
	public void test_getLoginAccountFromSocialRequest() {
		assertNotNull(loginAccountBuilder.getLoginAccountFromSocialRequest("loginId", "source", "target"));
	}
	
	@Test
	public void test_getLoginAccountFromManualRequest() {
		assertNotNull(loginAccountBuilder.getLoginAccountFromManualRequest("loginId", "source", "target"));
	}

	@Test
	public void test_getLoginAccountFromAadharRequest() {
		assertNotNull(loginAccountBuilder.getLoginAccountFromAadharRequest("loginId", "source"));
	}

	@Test
	public void test_getLoginAccountFromMobileDOBRequest() {
		
		MobileLoginRequest request = new MobileLoginRequest();
		request.setSource(AuthenticationServiceConstants.MPIN_OTP_LOGIN);
		assertNotNull(loginAccountBuilder.getLoginAccountFromMobileDOBRequest(request));
	}

	@Test
	public void test_getLoginAccountFromMobileDOBRequestt() {
		
		MobileLoginRequest request = new MobileLoginRequest();
		request.setSource("abc");
		assertNotNull(loginAccountBuilder.getLoginAccountFromMobileDOBRequest(request));
	}
}
