package com.bajaj.bfsd.authentication.authorize;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestClientException;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringRunner.class)
public class AuthorizationUtilTest {

	@InjectMocks
	private AuthorizationUtil authorizationUtil;
	
	@Mock
	private Environment env;

	@Mock
	private BFLLoggerUtil logger;

	@Mock
	private LoggedInUserDetailsLoader loggedInUserDetailsLoader;
	
	@Test(expected = BFLHttpException.class)
	public void testAuthorizeApplicantBlankToken() {
		authorizationUtil.authorizeApplicant(null, 1234L);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testAuthorizeApplicantNoLoggedInUser() {
		Mockito.when(loggedInUserDetailsLoader.loadUserByUsername(Mockito.anyString()))
			.thenReturn(null);
		authorizationUtil.authorizeApplicant("token", 1234L);

	}

	@Test(expected = BFLHttpException.class)
	public void testAuthorizeApplicantInvalidRole() {
		LoggedInUser user = new LoggedInUser("1234", "authToken", "system", null);
		Mockito.when(loggedInUserDetailsLoader.loadUserByUsername(Mockito.anyString()))
			.thenReturn(user);
		authorizationUtil.authorizeApplicant("token", 1234L);

	}
	
	@Test(expected = BFLHttpException.class)
	public void testAuthorizeApplicantNoAdditionalInfo() {
		LoggedInUser user = new LoggedInUser("1234", "authToken", "customer", null);
		Mockito.when(loggedInUserDetailsLoader.loadUserByUsername(Mockito.anyString()))
			.thenReturn(user);
		authorizationUtil.authorizeApplicant("token", 1234L);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testAuthorizeApplicantApplicantKeyMismatch() {
		AdditionalInfo info = new AdditionalInfo();
		LoggedInUser user = new LoggedInUser("1234", "authToken", "customer", info);
		Mockito.when(loggedInUserDetailsLoader.loadUserByUsername(Mockito.anyString()))
			.thenReturn(user);
		authorizationUtil.authorizeApplicant("token", 1234L);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testAuthorizeApplicantSomeException() {
		Mockito.when(loggedInUserDetailsLoader.loadUserByUsername(Mockito.anyString()))
			.thenThrow(new RestClientException("client exception"));
		authorizationUtil.authorizeApplicant("token", 1234L);
	}
}
