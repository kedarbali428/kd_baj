package com.bajaj.bfsd.authentication.dao.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;

import com.bajaj.bfsd.authentication.model.ApplicantUtm;
import com.bajaj.bfsd.authentication.model.BfsdUser;
import com.bajaj.bfsd.authentication.model.Login;
import com.bajaj.bfsd.authentication.util.DataFormatter;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringRunner.class)
public class AuthenticationServiceDaoImplTest {
	
	@InjectMocks
	AuthenticationServiceDaoImpl authenticationServiceDaoImpl;
	
	@Mock
	BFLLoggerUtil logger;

	@Mock
	EntityManager entityManager;
	@Mock
	private Environment env;
	@Mock
	Query query;
	
	@Mock
	private DataFormatter dataFormatter;

	@Test
	public void testCheckLoginIdExistance() {
		Mockito.when(entityManager
				.createNativeQuery("SELECT COUNT(1) From USER_LOGIN_ACCOUNTS ac ,BFSD_USERS bu where ac.USERKEY = bu.USERKEY and ac.LOGINID =:loginId and ac.USERLOGINACCTYPE=:loginType and bu.ISACTIVE=1 and bu.USERTYPE=1")).thenReturn(query);
		Mockito.when(((Number) query.getSingleResult())).thenReturn(1);
		Mockito.when(((Number) query.getSingleResult()).intValue()).thenReturn(1);
		int res=authenticationServiceDaoImpl.checkLoginIdExistance("123","03/03/1992",6,"1");
		assertEquals(1, res);
	}
	
	@Test
	public void testCheckLoginIdExistanceLoginTypeNull() {
		Mockito.when(entityManager
				.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(((Number) query.getSingleResult())).thenReturn(1);
		Mockito.when(((Number) query.getSingleResult()).intValue()).thenReturn(1);
		int res=authenticationServiceDaoImpl.checkLoginIdExistance("123","03/03/1992",null,"1");
		assertEquals(1, res);
	}
	
	@Test
	public void testCheckLoginIdExistanceLoginTypeNullRtype() {
		Mockito.when(entityManager
				.createNativeQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(((Number) query.getSingleResult())).thenReturn(1);
		Mockito.when(((Number) query.getSingleResult()).intValue()).thenReturn(1);
		int res=authenticationServiceDaoImpl.checkLoginIdExistance("123","03/03/1992",null,"2");
		assertEquals(1, res);
	}
	
	@Test(expected=BFLTechnicalException.class)
	public void testCheckLoginIdExistanceException() {
		Mockito.when(entityManager
				.createNativeQuery("SELECT COUNT(1) From USER_LOGIN_ACCOUNTS ac ,BFSD_USERS bu where ac.USERKEY = bu.USERKEY and ac.LOGINID like :loginId and ac.USERLOGINACCTYPE=:loginType and bu.ISACTIVE=1 and bu.USERTYPE=1")).thenReturn(query);
		Mockito.when(((Number) query.getSingleResult())).thenThrow(new BFLTechnicalException());
		int res=authenticationServiceDaoImpl.checkLoginIdExistance("123","03/03/1992",8,"1");
		assertEquals(1, res);
	}
	
	@Test
	public void testValidateUser() {
		Mockito.when(entityManager.createNativeQuery(
				"SELECT COUNT(1) From USER_LOGIN_ACCOUNTS ac ,BFSD_USERS bu, USER_PROFILES up where ac.USERKEY = bu.USERKEY and bu.USERKEY = up.USERKEY and ac.LOGINID=:mobileNumber and ac.USERLOGINACCTYPE=:loginType and bu.ISACTIVE=1 and bu.USERTYPE=1 and up.DATEOFBIRTH=:dateOfBirth")).thenReturn(query);
	Mockito.when(query.getSingleResult()).thenReturn(123456);
	authenticationServiceDaoImpl.validateUser("9999999999", "02/02/1992",8);
	Mockito.verify(query).getSingleResult();
   }
	
	@Test(expected=BFLBusinessException.class)
	public void testValidateUserException() {
		Mockito.when(entityManager.createNativeQuery(
				"SELECT bu.USERKEY From USER_LOGIN_ACCOUNTS ac ,BFSD_USERS bu, USER_PROFILES up where ac.USERKEY = bu.USERKEY and bu.USERKEY = up.USERKEY and ac.LOGINID=:mobileNumber and ac.USERLOGINACCTYPE=8 and bu.ISACTIVE=1 and bu.USERTYPE=1 and up.DATEOFBIRTH=:dateOfBirth")).thenReturn(query);
	Mockito.when(query.getSingleResult()).thenThrow(new JSONException(""));
	authenticationServiceDaoImpl.validateUser("9999999999", "02/02/1992",8);
   }
	@Test
	public void testUpdateLoginActivity() {
		Login login = new Login();
		authenticationServiceDaoImpl.updateLoginActivity(login);
	}
	
	
	@Test
	public void testUpdateLoginActivity2() {
		Login login = new Login();
		login.setLoginsrcwebapp("false");
		authenticationServiceDaoImpl.updateLoginActivity(login);
	}
	
	
	@Test
	public void testUpdateFailedLogin() {
		authenticationServiceDaoImpl.updateLoginFailed(null);
	}
	
	@Test
	public void testUpdateFailedLoginValid() {
		authenticationServiceDaoImpl.updateLoginFailed(new Login());
	}
	
	@Test
	public void testupdateLogoutActivity() {
		Login login= new Login();
		BfsdUser bfsdUser = new BfsdUser();
		login.setBfsdUser(bfsdUser);
		Mockito.when(entityManager.createNativeQuery("update USER_LOGIN_ACTIVITIES set logoutdt=:logoutdt,"
					+ "lstupdatedt = :lstupdatedt where userkey = :userkey and logoutdt is null and loginsrcwebapp = :loginsrcwebapp")).thenReturn(query);
		authenticationServiceDaoImpl.updateLogoutActivity(login);
	}
	
	@Test
	public void testupdateLogoutActivitytrue() {
		Login login= new Login();
		login.setLoginsrcwebapp("true");
		BfsdUser bfsdUser = new BfsdUser();
		login.setBfsdUser(bfsdUser);
		Mockito.when(entityManager.createNativeQuery("update USER_LOGIN_ACTIVITIES set logoutdt=:logoutdt,"
					+ "lstupdatedt = :lstupdatedt where userkey = :userkey and logoutdt is null and loginsrcwebapp = :loginsrcwebapp")).thenReturn(query);
		authenticationServiceDaoImpl.updateLogoutActivity(login);
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testupdateLogoutActivityEx() {
		Login login= new Login();
		Mockito.when(entityManager.createNativeQuery("update USER_LOGIN_ACTIVITIES set logoutdt=:logoutdt,"
					+ "lstupdatedt = :lstupdatedt where userkey = :userkey and logoutdt is null and loginsrcwebapp = :loginsrcwebapp")).thenReturn(query);
		authenticationServiceDaoImpl.updateLogoutActivity(login);
	}
	
	@Test
	public void testFetchRecord() {
		List<BfsdUser> bfsdUserlist = new ArrayList<>();
		Login login= new Login();
		bfsdUserlist.add(new BfsdUser());
		Mockito.when(entityManager
					.createQuery("select bu from BfsdUser bu "
							+ "where bu.userloginid = ?1 and bu.usertype =1 and bu.isactive =1")).thenReturn(query);
		Mockito.when( entityManager
				.createQuery("select bu from BfsdUser bu "
						+ "where bu.userloginid = ?1 and bu.usertype =1 and bu.isactive =1")
				.setParameter(1, login.getUsername())).thenReturn(query);
		Mockito.when( entityManager
					.createQuery("select bu from BfsdUser bu "
							+ "where bu.userloginid = ?1 and bu.usertype =1 and bu.isactive =1")
					.setParameter(1, login.getUsername()).getResultList()).thenReturn(bfsdUserlist);
		authenticationServiceDaoImpl.fetchRecord(login);
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testFetchRecordException() {
		List<BfsdUser> bfsdUserlist = new ArrayList<>();
		Login login= new Login();
		bfsdUserlist.add(new BfsdUser());
		authenticationServiceDaoImpl.fetchRecord(login);
	}
	
	@Test
	public void testFetchRecordEmptyList() {
		List<BfsdUser> bfsdUserlist = new ArrayList<>();
		Login login= new Login();
		login.setUsername("name");
		Mockito.when(entityManager
				.createQuery("select bu from BfsdUser bu "
						+ "where bu.userloginid = ?1 and bu.usertype =1 and bu.isactive =1")).thenReturn(query);
		Mockito.when( query.setParameter(1, login.getUsername())).thenReturn(query);
		Mockito.when(query.getResultList())
			.thenReturn(bfsdUserlist);
		BfsdUser fetchRecord = authenticationServiceDaoImpl.fetchRecord(login);
		assertNull(fetchRecord);
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testGetUserProfile() {
		List<Timestamp> dobList = new ArrayList<>();
		Mockito.when(entityManager.createNativeQuery("select up.DATEOFBIRTH from BFSD_USERS bu,USER_PROFILES up where up.MOBILENO=:mobileNumber and bu.USERKEY=up.USERKEY and bu.ISACTIVE=1 and bu.USERTYPE=1")).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(dobList);
		authenticationServiceDaoImpl.getUserProfile("9876543210");
		assertEquals(0, dobList.size());
	}
	
	@Test
	public void testGetUserProfile1() {
		List<Timestamp> dobList = new ArrayList<>();
		Timestamp timestamp=new Timestamp(Long.valueOf("03031992"));
		dobList.add(timestamp);
		Mockito.when(entityManager.createNativeQuery("select up.DATEOFBIRTH from BFSD_USERS bu,USER_PROFILES up where up.MOBILENO=:mobileNumber and bu.USERKEY=up.USERKEY and bu.ISACTIVE=1 and bu.USERTYPE=1")).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(dobList);
		authenticationServiceDaoImpl.getUserProfile("9876543210");
		assertEquals(1, dobList.size());
	}
	
	@Test
	public void testsaveApplicantUtm() {
		ApplicantUtm applicantUtmObj=new ApplicantUtm();
		authenticationServiceDaoImpl.saveApplicantUtm(applicantUtmObj);
	}
	
	@Test(expected = Test.None.class)
	public void testgetApplicantRecordNoResultException() {
		authenticationServiceDaoImpl.getApplicantRecord(2347L);
	}
	
	@Test
	public void testGetApplicantRecordSuccess(){
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.anyLong()))
			.thenReturn(query);
		Mockito.when(query.getSingleResult())
			.thenReturn(1);
		authenticationServiceDaoImpl.getApplicantRecord(2347L);
	}
	
	@Test
	public void testgetApplicantId() {
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.anyLong()))
		.thenReturn(query);
		Mockito.when(query.getSingleResult())
			.thenReturn(1);
		authenticationServiceDaoImpl.getApplicantId(2435L);
	}
	
	@Test(expected = Test.None.class)
	public void testgetApplicantIdNoResultException() {
		Mockito.when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		Mockito.when(query.setParameter(Mockito.anyString(), Mockito.anyLong()))
			.thenReturn(query);
		Mockito.when(query.getSingleResult())
			.thenThrow(new NoResultException());
		authenticationServiceDaoImpl.getApplicantId(2435L);
	}
	
}
