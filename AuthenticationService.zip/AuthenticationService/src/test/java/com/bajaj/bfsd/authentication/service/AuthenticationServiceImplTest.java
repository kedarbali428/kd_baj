package com.bajaj.bfsd.authentication.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bajaj.bfsd.authentication.bean.ApplicantProfile;
import com.bajaj.bfsd.authentication.bean.ApplicantUtmBean;
import com.bajaj.bfsd.authentication.bean.MobileVerificationDet;
import com.bajaj.bfsd.authentication.bean.NameVerificationDetails;
import com.bajaj.bfsd.authentication.bean.TokensBean;
import com.bajaj.bfsd.authentication.bean.User;
import com.bajaj.bfsd.authentication.bean.UserConfigurationBean;
import com.bajaj.bfsd.authentication.bean.UserKeysBean;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV2;
import com.bajaj.bfsd.authentication.bean.UserResponse;
import com.bajaj.bfsd.authentication.config.MapperFactory;
import com.bajaj.bfsd.authentication.dao.AuthenticationServiceDao;
import com.bajaj.bfsd.authentication.data.AuthenticationServiceDataPopulator;
import com.bajaj.bfsd.authentication.model.BfsdUser;
import com.bajaj.bfsd.authentication.model.GenerateTokenRequest;
import com.bajaj.bfsd.authentication.model.Login;
import com.bajaj.bfsd.authentication.model.LoginAccount;
import com.bajaj.bfsd.authentication.model.MobileDobOtpLoginRequest;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.SocialAuthenticationRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsResponse;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.model.UserLoginAccountRequest;
import com.bajaj.bfsd.authentication.model.UserLoginAccountResponse;
import com.bajaj.bfsd.authentication.service.AuthenticationServiceImpl.AsyncClass;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceHelper;
import com.bajaj.bfsd.authentication.util.DataValidator;
import com.bajaj.bfsd.authentication.util.Ldaputility;
import com.bajaj.bfsd.authentication.util.LoginPasswordValidator;
import com.bajaj.bfsd.authentication.util.TokenCodeHelper;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLBusinessException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;

@RunWith(PowerMockRunner.class)
@PrepareForTest({BFLCommonRestClient.class,Gson.class,AuthenticationServiceHelper.class,MapperFactory.class,LoginPasswordValidator.class})
public class AuthenticationServiceImplTest {
	@InjectMocks
	private AuthenticationServiceImpl authenticationServiceImpl;
	
	@Mock
	private AuthenticationServiceDao authenticationServiceDao;
	
	@Mock
	private AuthenticationServiceHelper authenticationServiceHelper;
	
	@Mock
	TokenCodeHelper tokenCodeHelper;
	
	@Mock
	BFLLoggerUtil logger;
	@Value("${fbRedirectUrl}")
	private String facebookRedirectUrl;
	
	@Mock
	private Environment env;
	@Mock
	HttpHeaders headers;
	
	
	@Mock
	private AsyncClass asyncClass;
	@Mock
	ObjectMapper mapper;
	@Mock
	DataValidator dataValidator;
	
	@Mock
	LoginPasswordValidator loginPasswordValidator;
	
	private static final String SYSTEM = "SYSTEM";

	@Mock
	Ldaputility ldaputility;
	

	/**Positive test scenario when only one user exist with given login Id
	 * 
	 */
	@Test
	public void testCheckUserExistance() {
		String loginId="98124675321";
		String dob="03/03/1992";
		Integer loginType=8;
		String rtype="1";
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(loginId,dob,loginType,rtype)).thenReturn(1);
		authenticationServiceImpl.checkUserExistance(loginId,dob,loginType,rtype,null);
	}

	
	/**
	 * Negative test scenario when no user exist with given test scenario
	 */
	@Test(expected=BFLBusinessException.class)
	public void testCheckUserExistanceZero() {
		String loginId="98124675321";
		String dob="03/03/1992";
		Integer loginType=8;
		String rtype="1";
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(loginId,dob,loginType,rtype)).thenReturn(0);
		authenticationServiceImpl.checkUserExistance(loginId,dob,loginType,rtype,null);
	}
	/**
	 * Negative test scenario when multiple user exist with given loginId
	 */
	@Test(expected=BFLBusinessException.class)
	public void testCheckUserExistanceMultiple() {
		String loginId="98124675321";
		String dob="03/03/1992";
		Integer loginType=8;
		String rtype="1";
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(loginId,dob,loginType,rtype)).thenReturn(2);
		authenticationServiceImpl.checkUserExistance(loginId,dob,loginType,rtype,null);
	}
	
	/**Positive test scenario for successfull generation of token for login
	 * @throws JsonProcessingException
	 */
	@Test
	public void testLogin() throws JsonProcessingException {
		Integer loginType=8;
		String dob="03/03/1992";
		String loginId="9182736450";
		String rtype="1";
		String json="{\"payload\": {\"userId\": \"123456\", \"loginFailCount\": \"0\", \"failedRequest\": false, \"userType\": \"1\", \"loginId\": \"9876543210\", \"accountStatus\": \"0\"} }";
		Gson mockGson = Mockito.mock(Gson.class);
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		UserLoginAccountRequestV2 userLoginRequest = AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		UserLoginAccountResponse loginAccountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		ResponseBean responseBean = new ResponseBean(loginAccountResponse);
		responseBean.setPayload(json);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(loginId,dob,loginType,rtype)).thenReturn(1);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		Mockito.when(mockGson.fromJson(json, UserLoginAccountResponse.class)).thenReturn(loginAccountResponse);
		Mockito.when(MapperFactory.getInstance()).thenReturn(mapper);
		Mockito.when(mapper.writeValueAsString(generateTokenReq)).thenReturn("");
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		Mockito.when(AuthenticationServiceHelper.getToken(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(AuthenticationServiceDataPopulator.popTokenResponse());
		TokenResponse token=authenticationServiceImpl.login(userLoginRequest, headers,null);
		assertEquals("token", token.getTokens().get(0).getToken());
		assertEquals("gaurdKey", token.getTokens().get(0).getGuardKey());
	}
	
	/**Positive test scenario for successfull generation of token for login in case of multiple user found with same mobile nuber registered
	 * @throws JsonProcessingException
	 */
	@Test
	public void testLoginMultipleUser() throws JsonProcessingException {
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		String loginId="9182736450";
		String json="{\"payload\": {\"userId\": \"123456\", \"loginFailCount\": \"0\", \"failedRequest\": false, \"userType\": \"1\", \"loginId\": \"9876543210\", \"accountStatus\": \"0\"} }";
		Gson mockGson = Mockito.mock(Gson.class);
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		UserLoginAccountRequestV2 userLoginRequest = AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		UserLoginAccountResponse loginAccountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		ResponseBean responseBean = new ResponseBean(loginAccountResponse);
		responseBean.setPayload(json);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(loginId,dob,loginType,rtype)).thenReturn(2);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		Mockito.when(mockGson.fromJson(json, UserLoginAccountResponse.class)).thenReturn(loginAccountResponse);
		Mockito.when(MapperFactory.getInstance()).thenReturn(mapper);
		Mockito.when(mapper.writeValueAsString(generateTokenReq)).thenReturn("");
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		Mockito.when(AuthenticationServiceHelper.getToken(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(AuthenticationServiceDataPopulator.popTokenResponse());
		TokenResponse token=authenticationServiceImpl.login(userLoginRequest, headers,null);
		assertEquals("token", token.getTokens().get(0).getToken());
		assertEquals("gaurdKey", token.getTokens().get(0).getGuardKey());
	}
	
	
	/**Negative test scenario for login when userkey not found in database
	 * @throws JsonProcessingException
	 */
	@Test(expected=BFLBusinessException.class)
	public void testLoginNullUserId() throws JsonProcessingException {
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		String loginId="9182736450";
		String json="{\"userId\": \"0\", \"loginFailCount\": \"0\", \"failedRequest\": false, \"userType\": \"1\", \"loginId\": \"9876543210\", \"accountStatus\": \"0\" }";
		Gson mockGson = Mockito.mock(Gson.class);
		UserLoginAccountRequestV2 userLoginRequest = AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		userLoginRequest.setDateOfBirth("03-MAR-1992");
		UserLoginAccountResponse loginAccountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		ResponseBean responseBean = new ResponseBean(loginAccountResponse);
		responseBean.setPayload(json);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(loginId,dob,loginType,rtype)).thenReturn(2);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		loginAccountResponse.setUserId(0);
		Mockito.when(mockGson.fromJson(json, UserLoginAccountResponse.class)).thenReturn(loginAccountResponse);
		authenticationServiceImpl.login(userLoginRequest, headers,null);
	}
	
	
	/**Negative scenario for login when user attempt the failed request.
	 * @throws JsonProcessingException
	 */
	@Test(expected=BFLBusinessException.class)
	public void testLoginFailedRequest() throws JsonProcessingException {
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		String loginId="9182736450";
		String json="{\"payload\": {\"userId\": \"123456\", \"loginFailCount\": \"0\", \"failedRequest\": true, \"userType\": \"1\", \"loginId\": \"9876543210\", \"accountStatus\": \"0\"} }";
		Gson mockGson = Mockito.mock(Gson.class);
		UserLoginAccountRequestV2 userLoginRequest = AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		userLoginRequest.setDateOfBirth("03-MAR-1992");
		UserLoginAccountResponse loginAccountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		ResponseBean responseBean = new ResponseBean(loginAccountResponse);
		responseBean.setPayload(json);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(loginId,dob,loginType,rtype)).thenReturn(2);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		loginAccountResponse.setUserId(0);
		Mockito.when(mockGson.fromJson(json, UserLoginAccountResponse.class)).thenReturn(loginAccountResponse);
		authenticationServiceImpl.login(userLoginRequest, headers,null);
	}
	
	
	/**Negative scenario when user account is active 
	 * @throws JsonProcessingException
	 */
	@Test(expected=BFLBusinessException.class)
	public void testLoginFailedRequestAccountActive() throws JsonProcessingException {
		Integer loginType=8;
		String dob="03/03/1992";
		String loginId="9182736450";
		String rtype="1";
		String json="{\"payload\": {\"userId\": \"123456\", \"loginFailCount\": \"0\", \"failedRequest\": true, \"userType\": \"1\", \"loginId\": \"9876543210\", \"accountStatus\": \"1\"} }";
		Gson mockGson = Mockito.mock(Gson.class);
		UserLoginAccountRequestV2 userLoginRequest = AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		userLoginRequest.setDateOfBirth("03-MAR-1992");
		UserLoginAccountResponse loginAccountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		ResponseBean responseBean = new ResponseBean(loginAccountResponse);
		responseBean.setPayload(json);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(loginId,dob,loginType,rtype)).thenReturn(2);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		loginAccountResponse.setUserId(0);
		Mockito.when(mockGson.fromJson(json, UserLoginAccountResponse.class)).thenReturn(loginAccountResponse);
		authenticationServiceImpl.login(userLoginRequest, headers,null);
	}
	
	
	/**Negative scenario when user try to login and user not able to get identified due some technical reason.
	 * @throws JsonProcessingException
	 */
	@Test(expected=BFLBusinessException.class)
	public void testLoginBadStatus() throws JsonProcessingException {
		Integer loginType=8;
		String dob="03/03/1992";
		String loginId="9182736450";
		String rtype="1";
		UserLoginAccountRequestV2 userLoginRequest = AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		userLoginRequest.setDateOfBirth("03-MAR-1992");
		UserLoginAccountResponse loginAccountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		ResponseBean responseBean = new ResponseBean(loginAccountResponse);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.BAD_GATEWAY);
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(loginId,dob,loginType,rtype)).thenReturn(2);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		authenticationServiceImpl.login(userLoginRequest, headers,null);
	}
	
	/**Negative test scenario when user data is validated against database
	 * @throws JsonProcessingException
	 */
	@Test(expected=BFLBusinessException.class)
	public void testLoginFailure() throws JsonProcessingException {
		Integer loginType=8;
		String dob="03/03/1992";
		String loginId="9182736450";
		String rtype="1";
		UserLoginAccountRequestV2 userLoginRequest = AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		userLoginRequest.setDateOfBirth("03-MAR-1992");
		UserLoginAccountResponse loginAccountResponse=AuthenticationServiceDataPopulator.popUserLoginAccountResponse();
		ResponseBean responseBean = new ResponseBean(loginAccountResponse);
		responseBean.setStatus(StatusCode.FAILURE);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(loginId,dob,loginType,rtype)).thenReturn(2);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		authenticationServiceImpl.login(userLoginRequest, headers,null);
	}
	
	
	@Test
	public void testAutheticateMobileDobOtp() {
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		MobileDobOtpLoginRequest dobOtpLoginRequest= AuthenticationServiceDataPopulator.popMobileDobOtpLoginRequest();
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(dobOtpLoginRequest.getLoginId(),dob,loginType,rtype)).thenReturn(1);
		Mockito.when(dataValidator.validateMobile(dobOtpLoginRequest.getLoginId())).thenReturn(true);
		ResponseBean responseBean= new ResponseBean();
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		//method under test
		ResponseBean  response =authenticationServiceImpl.autheticateMobileDobOtp(dobOtpLoginRequest);
		assertEquals("SUCCESS", response.getPayload().toString());
	}
	
	@Test
	public void testAutheticateMobileDobOtpMultipleUser() {
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		MobileDobOtpLoginRequest dobOtpLoginRequest= AuthenticationServiceDataPopulator.popMobileDobOtpLoginRequest();
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(dobOtpLoginRequest.getLoginId(),dob,loginType,rtype)).thenReturn(2);
		Mockito.when(dataValidator.validateMobile(dobOtpLoginRequest.getLoginId())).thenReturn(true);
		ResponseBean responseBean= new ResponseBean();
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		//method under test
		ResponseBean  response =authenticationServiceImpl.autheticateMobileDobOtp(dobOtpLoginRequest);
		assertEquals("SUCCESS", response.getPayload().toString());
	}
	
	
	@Test
	public void testAutheticateMobileDobOtpFailure() {
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		MobileDobOtpLoginRequest dobOtpLoginRequest= AuthenticationServiceDataPopulator.popMobileDobOtpLoginRequest();
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(dobOtpLoginRequest.getLoginId(),dob,loginType,rtype)).thenReturn(1);
		Mockito.when(dataValidator.validateMobile(dobOtpLoginRequest.getLoginId())).thenReturn(true);
		ResponseBean responseBean= new ResponseBean();
		responseBean.setStatus(StatusCode.FAILURE);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		//method under test
		ResponseBean  response =authenticationServiceImpl.autheticateMobileDobOtp(dobOtpLoginRequest);
		assertNull(response.getPayload());
	}
	
	@Test
	public void testAutheticateMobileDobOtpBadRequest() {
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		MobileDobOtpLoginRequest dobOtpLoginRequest= AuthenticationServiceDataPopulator.popMobileDobOtpLoginRequest();
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(dobOtpLoginRequest.getLoginId(),dob,loginType,rtype)).thenReturn(1);
		Mockito.when(dataValidator.validateMobile(dobOtpLoginRequest.getLoginId())).thenReturn(true);
		ResponseBean responseBean= new ResponseBean();
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.BAD_REQUEST);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		//method under test
		ResponseBean  response =authenticationServiceImpl.autheticateMobileDobOtp(dobOtpLoginRequest);
		assertNull(response.getPayload());
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testAutheticateMobileDobOtpBadGateway() {
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		MobileDobOtpLoginRequest dobOtpLoginRequest= AuthenticationServiceDataPopulator.popMobileDobOtpLoginRequest();
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(dobOtpLoginRequest.getLoginId(),dob,loginType,rtype)).thenReturn(1);
		Mockito.when(dataValidator.validateMobile(dobOtpLoginRequest.getLoginId())).thenReturn(true);
		ResponseBean responseBean= new ResponseBean();
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.BAD_GATEWAY);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		//method under test
		authenticationServiceImpl.autheticateMobileDobOtp(dobOtpLoginRequest);
	}
	
	
	@Test(expected=BFLBusinessException.class)
	public void testAutheticateMobileDobOtpInvalidMobile() {
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		MobileDobOtpLoginRequest dobOtpLoginRequest= AuthenticationServiceDataPopulator.popMobileDobOtpLoginRequest();
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(dobOtpLoginRequest.getLoginId(),dob,loginType,rtype)).thenReturn(1);
		Mockito.when(dataValidator.validateMobile(dobOtpLoginRequest.getLoginId())).thenReturn(false);
		//method under test
		authenticationServiceImpl.autheticateMobileDobOtp(dobOtpLoginRequest);
	}
	
	
	@Test(expected=BFLBusinessException.class)
	public void testAutheticateMobileDobOtpNullRequest() {
		MobileDobOtpLoginRequest dobOtpLoginRequest=null;
		//method under test
		authenticationServiceImpl.autheticateMobileDobOtp(dobOtpLoginRequest);
	}
	@Test
	public void authenticateUserInADTest()throws Exception
	{
		String loginId="uytyg6677";
		String pwd="yh@7653";
		UserConfigurationBean userConfig = new UserConfigurationBean();
		userConfig.setDesignation("sw");
		userConfig.setEmailId("ytdfd@gmail.com");
		userConfig.setFirstName("siva");
		userConfig.setUserKey(1254L);
		userConfig.setLastName("nara");
		userConfig.setPassword(pwd);
		userConfig.setIsUserExist(true);
		List<User> userADList=new ArrayList<>();
		User user=new User();
		user.setDesignation("sw");
		user.setEmailId("ytdfd@gmail.com");
		user.setEmpId("8546");
		user.setIsActive(BigDecimal.ONE);
		user.setFirstname("anna");
		user.setMobileNumber("9568425841");
		user.setPassword("ashg@786");
		user.setLastname("test");
		userADList.add(user);
		userConfig.setUserADList(userADList);
		authenticationServiceImpl.authenticateUserInAD(loginId, pwd);
		
	}
	
	/*@Test
	public void authenticateManualLoginTest()throws Exception
	{
		
		short userType=2;
		String loginId ="5245";
		String pwd ="jhghgs451";
		UserLoginAccountRequest manualLoginRequest=new UserLoginAccountRequest();
		manualLoginRequest.setDateOfBirth("11-08-1985");
		manualLoginRequest.setLoginId("5245");
		manualLoginRequest.setLoginType("Manual");
		manualLoginRequest.setPassword("jhghgs451");
		manualLoginRequest.setSource("web");
		
		
		ValidateUserRequest validateUserReq = new ValidateUserRequest();
		validateUserReq.setDateOfBirth("11-05-1998");
		validateUserReq.setLoginId("85451");
		validateUserReq.setLoginType((short)3);
		validateUserReq.setPwd("jhsg45");
		validateUserReq.setUserType(userType);	
		
		
		
		authenticationServiceImpl.authenticateManualLogin(manualLoginRequest, headers);
		
	}*/
	
	@Test
	public void logoutTest() throws Exception
	{
		long userId=5245L;
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		/*PowerMockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(),Mockito.any(),
					Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any())).then*/
		
		Login userLogin = new Login();
		userLogin.setUsername("gfs");
		userLogin.setPassword("jhasg54");
		userLogin.setLongitude(BigDecimal.valueOf(5));
		userLogin.setBrowser("chrome");
		BfsdUser user = new BfsdUser();
		user.setUserkey(87844L);
		userLogin.setBfsdUser(user);
		
		authenticationServiceImpl.logout(userId, headers);
		
	}
	@Test
	public void getFacebookLoginParamsTest() throws Exception
	{
		SocialLoginParamsRequest socialLoginParamsRequest=new SocialLoginParamsRequest();
		socialLoginParamsRequest.setPlatform("test");
			DateTimeFormatter srcDtf = DateTimeFormat.forPattern("yyyyMMddHHmmssSSS");
			String strJodaTime = srcDtf.print(new DateTime());
			StringBuilder url = new StringBuilder();
			url.append("www.facebook.com");
			url.append("www.facebook.com");
			url.append("www.redirect.com");
			url.append("kjahsdh@gmail.com");
			url.append("&state=" + strJodaTime);
			SocialLoginParamsResponse socialLoginParamsResponse = new SocialLoginParamsResponse();
			socialLoginParamsResponse.setRedirectUrl("www.google.com");
			SocialLoginParamsResponse resp=authenticationServiceImpl.getFacebookLoginParams(socialLoginParamsRequest);
		
	}	
	@Test
	public void saveProfileDetailsTest()throws Exception
	{
		long userId=182736L;
		String profileJson="json";
		String target="web";
		HttpHeaders httpHeaders = new HttpHeaders();

		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("source", target);
		ResponseBean responseBean1 = new ResponseBean();
		Object payload= "{payload :{statusFlag : true}}";
		responseBean1.setPayload(payload);
		JSONObject saveRequest = new JSONObject();
		saveRequest.put("userKey", userId);
		saveRequest.put("profileJson", profileJson);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(new ResponseEntity(responseBean1, HttpStatus.OK));
		authenticationServiceImpl.saveProfileDetails(profileJson, userId, target);
	}
	@Test
	public void getRedirectUrlTest() throws Exception
	{
		
		SocialLoginParamsRequest socialLoginParamsRequest=new SocialLoginParamsRequest();
		socialLoginParamsRequest.setPlatform("facebook");
		StringBuilder rediectUrl = new StringBuilder();
		String platform ="facebook";
		DateTimeFormatter srcDtf = DateTimeFormat.forPattern("yyyyMMddHHmmssSSS");
		String strJodaTime = srcDtf.print(new DateTime());
		
		SocialLoginParamsResponse socialLoginParamsResponse = new SocialLoginParamsResponse();
		socialLoginParamsResponse.setRedirectUrl("facebook");
		authenticationServiceImpl.getRedirectUrl(socialLoginParamsRequest);
		
	}
	
	@Test(expected=BFLBusinessException.class)
	public void getRedirectUrlTestcondi() throws Exception
	{
		SocialLoginParamsRequest socialLoginParamsRequest=new SocialLoginParamsRequest();
		socialLoginParamsRequest.setPlatform("default");
		StringBuilder rediectUrl = new StringBuilder();
		DateTimeFormatter srcDtf = DateTimeFormat.forPattern("yyyyMMddHHmmssSSS");
		String platform ="default";
		String strJodaTime = srcDtf.print(new DateTime());
		SocialLoginParamsResponse socialLoginParamsResponse = new SocialLoginParamsResponse();
		authenticationServiceImpl.getRedirectUrl(socialLoginParamsRequest);
		
	}
	@Test
	public void testLoginWithOtp() throws ParseException {
		UserLoginAccountRequestV2 accountRequestV2=AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(accountRequestV2.getLoginId(),dob,loginType,rtype)).thenReturn(1);
		accountRequestV2.setDateOfBirth(dob);
		accountRequestV2.setLoginType("6");
		ResponseBean responseBean = new ResponseBean();
		Object payload= "{payload :{status : failure}}";
		responseBean.setPayload(payload);
		responseBean.setStatus(StatusCode.FAILURE);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		ResponseBean res=authenticationServiceImpl.loginWithOtp(accountRequestV2, null);
		assertEquals(StatusCode.SUCCESS, res.getStatus());
	}
	
	
	@Test
	public void testLoginWithOtp1() throws ParseException {
		UserLoginAccountRequestV2 accountRequestV2=AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(accountRequestV2.getLoginId(),dob,loginType,rtype)).thenReturn(1);
		accountRequestV2.setDateOfBirth(dob);
		accountRequestV2.setLoginType("6");
		ResponseBean responseBean = new ResponseBean();
		Object payload= "{payload :{status : failure}}";
		responseBean.setPayload(payload);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.BAD_REQUEST);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		ResponseBean res=authenticationServiceImpl.loginWithOtp(accountRequestV2, null);
		assertEquals(StatusCode.SUCCESS, res.getStatus());
	}
	
	@Test(expected=BFLBusinessException.class)
	public void testLoginWithOtp3() throws ParseException {
		UserLoginAccountRequestV2 accountRequestV2=AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		Integer loginType=8;
		String dob="03/03/1992";
		String rtype="1";
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(accountRequestV2.getLoginId(),dob,loginType,rtype)).thenReturn(1);
		accountRequestV2.setDateOfBirth(dob);
		accountRequestV2.setLoginType("6");
		ResponseBean responseBean = new ResponseBean();
		Object payload= "{payload :{status : failure}}";
		responseBean.setPayload(payload);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.ACCEPTED);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		ResponseBean res=authenticationServiceImpl.loginWithOtp(accountRequestV2, null);
		assertEquals(StatusCode.SUCCESS, res.getStatus());
	}
	
	@Test
	public void testLoginWithOtp2() throws ParseException {
		UserLoginAccountRequestV2 accountRequestV2=AuthenticationServiceDataPopulator.popUserLoginAccountRequestV2();
		Integer loginType=8;
		Long dob=new Long("03031992");
		String rtype="1";
		Mockito.when(authenticationServiceDao.getUserProfile(Mockito.anyString())).thenReturn(new Timestamp(dob));
		Mockito.when(authenticationServiceDao.checkLoginIdExistance(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(),Mockito.anyString())).thenReturn(2);
		accountRequestV2.setDateOfBirth("03/03/1992");
		accountRequestV2.setLoginType("6");
		ResponseBean responseBean = new ResponseBean();
		Object payload= "{payload :{status : success}}";
		responseBean.setPayload(payload);
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		ResponseBean res=authenticationServiceImpl.loginWithOtp(accountRequestV2, null);
		assertEquals(StatusCode.SUCCESS, res.getStatus());
	}
	
	@Test
	public void testGetSocialDetailFaceBook() {
		SocialAuthenticationRequest socialRequest=new SocialAuthenticationRequest();
		socialRequest.setTarget(AuthenticationServiceConstants.FACEBOOK);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		authenticationServiceImpl.getSocialDetails(socialRequest, headers);
	}
	
	@Test
	public void testGetSocialDetailLinkdIn() {
		SocialAuthenticationRequest socialRequest=new SocialAuthenticationRequest();
		socialRequest.setTarget(AuthenticationServiceConstants.LINKEDIN);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		authenticationServiceImpl.getSocialDetails(socialRequest, headers);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testGetSocialDetail() {
		SocialAuthenticationRequest socialRequest=new SocialAuthenticationRequest();
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		authenticationServiceImpl.getSocialDetails(socialRequest, headers);
	}
	
	@Test
	public void testAuthenticateUserSuccess() {
		LoginAccount loginAcct=new LoginAccount();
		UserLoginAccountResponse accountResponse=new UserLoginAccountResponse();
		accountResponse.setAccountStatus((short)1);
		accountResponse.setUserId(1l);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		PowerMockito.when(AuthenticationServiceHelper.authenticateUser(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(accountResponse);
		UserLoginAccountResponse result=authenticationServiceImpl.authenticateUser(loginAcct);
		assertEquals((short)1, result.getAccountStatus());
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testAuthenticateUserInvalidLoginType() {
		LoginAccount loginAcct=new LoginAccount();
		loginAcct.setLoginType(AuthenticationServiceConstants.LOGINACCTYPE_MANUAL);
		UserLoginAccountResponse accountResponse=new UserLoginAccountResponse();
		accountResponse.setAccountStatus(AuthenticationServiceConstants.ISACTIVE);
		accountResponse.setUserId(1l);
		accountResponse.setFailedRequest(true);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		PowerMockito.when(AuthenticationServiceHelper.authenticateUser(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(accountResponse);
		authenticationServiceImpl.authenticateUser(loginAcct);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testAuthenticateUserFailed() {
		LoginAccount loginAcct=new LoginAccount();
		loginAcct.setLoginType(AuthenticationServiceConstants.LOGINACCTYPE_MOBILE_DOB_OTP_MPIN);
		UserLoginAccountResponse accountResponse=new UserLoginAccountResponse();
		accountResponse.setAccountStatus((short)0);
		accountResponse.setUserId(1l);
		accountResponse.setFailedRequest(true);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		PowerMockito.when(AuthenticationServiceHelper.authenticateUser(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(accountResponse);
		authenticationServiceImpl.authenticateUser(loginAcct);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testAuthenticateUserSystem() {
		LoginAccount loginAcct=new LoginAccount();
		loginAcct.setLoginType(AuthenticationServiceConstants.LOGINACCTYPE_MANUAL);
		UserLoginAccountResponse accountResponse=new UserLoginAccountResponse();
		accountResponse.setAccountStatus(AuthenticationServiceConstants.ISACTIVE);
		accountResponse.setUserId(0l);
		accountResponse.setFailedRequest(true);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		PowerMockito.when(AuthenticationServiceHelper.authenticateUser(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(accountResponse);
		authenticationServiceImpl.authenticateUser(loginAcct);
	}
	
	@Test
	public void testValidateOtpForMobileDobLogin() {
		MobileLoginRequest mobileLoginRequest=new MobileLoginRequest();
		mobileLoginRequest.setMobile("9876543210");
		mobileLoginRequest.setOtp("123456");
		mobileLoginRequest.setDateOfBirth("1992-09-09");
		mobileLoginRequest.setSource(AuthenticationServiceConstants.MPIN_OTP_LOGIN);
		Mockito.when(dataValidator.validateMobile(Mockito.any())).thenReturn(true);
		Mockito.when(dataValidator.validateDateFieldAndReturnDate(Mockito.any(), Mockito.any())).thenReturn(new Date());
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		ResponseBean responseBean= new ResponseBean();
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		authenticationServiceImpl.validateOtpForMobileDobLogin(mobileLoginRequest);
	}
	
	@Test
	public void testValidateOtpForMobileDobLoginBadReq() {
		MobileLoginRequest mobileLoginRequest=new MobileLoginRequest();
		mobileLoginRequest.setMobile("9876543210");
		mobileLoginRequest.setOtp("123456");
		mobileLoginRequest.setDateOfBirth("1992-09-09");
		mobileLoginRequest.setSource(AuthenticationServiceConstants.MPIN_OTP_LOGIN);
		Mockito.when(dataValidator.validateMobile(Mockito.any())).thenReturn(true);
		Mockito.when(dataValidator.validateDateFieldAndReturnDate(Mockito.any(), Mockito.any())).thenReturn(new Date());
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		ResponseBean responseBean= new ResponseBean();
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.BAD_REQUEST);
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		authenticationServiceImpl.validateOtpForMobileDobLogin(mobileLoginRequest);
	}
	
	@Test
	public void testValidateOtpForMobileDobLoginInternalError() {
		MobileLoginRequest mobileLoginRequest=new MobileLoginRequest();
		mobileLoginRequest.setMobile("9876543210");
		mobileLoginRequest.setOtp("123456");
		mobileLoginRequest.setDateOfBirth("1992-09-09");
		mobileLoginRequest.setSource(AuthenticationServiceConstants.MPIN_OTP_LOGIN);
		Mockito.when(dataValidator.validateMobile(Mockito.any())).thenReturn(true);
		Mockito.when(dataValidator.validateDateFieldAndReturnDate(Mockito.any(), Mockito.any())).thenReturn(new Date());
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
		ResponseBean responseBean= new ResponseBean();
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(responseEntity);
		authenticationServiceImpl.validateOtpForMobileDobLogin(mobileLoginRequest);
	}
	
	@Test
	public void testAuthenticateManulaLogin() {
		TokenResponse tokenResponse=new TokenResponse();
		List<Tokens> tokens=new ArrayList<>();
		Tokens token=new Tokens();
		token.setToken("token");
		tokens.add(token);
		tokenResponse.setTokens(tokens);
		String response= "{\"payload\":{\"userId\":2}}";
		UserLoginAccountRequest manualLoginRequest=new UserLoginAccountRequest();
		manualLoginRequest.setLoginId("9876543210");
		manualLoginRequest.setDateOfBirth("1992-09-09");
		manualLoginRequest.setPassword("test");
		PowerMockito.mockStatic(LoginPasswordValidator.class);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		PowerMockito.when(LoginPasswordValidator.validatePassword(Mockito.any())).thenReturn(true);
		PowerMockito.when(LoginPasswordValidator.validateLogin(Mockito.any())).thenReturn(true);
		manualLoginRequest.setSource(AuthenticationServiceConstants.MPIN_OTP_LOGIN);
		ApplicantUtmBean applicantUtmBean=new ApplicantUtmBean();
		ResponseBean responseBean=new ResponseBean();
		responseBean.setPayload(response);
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		Mockito.when(AuthenticationServiceHelper.getToken(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(tokenResponse);
		TokenResponse authenticateManualLogin = authenticationServiceImpl.authenticateManualLogin(manualLoginRequest, headers, applicantUtmBean);
	    assertNotNull(authenticateManualLogin);
	}

	@Test(expected = BFLBusinessException.class)
	public void testAuthenticateManulaLoginCustomerFailed() {
		TokenResponse tokenResponse=new TokenResponse();
		List<Tokens> tokens=new ArrayList<>();
		Tokens token=new Tokens();
		token.setToken("token");
		tokens.add(token);
		tokenResponse.setTokens(tokens);
		String response= "{\"payload\":{\"userId\":0}}";
		UserLoginAccountRequest manualLoginRequest=new UserLoginAccountRequest();
		manualLoginRequest.setLoginId("9876543210");
		manualLoginRequest.setDateOfBirth("1992-09-09");
		manualLoginRequest.setPassword("test");
		PowerMockito.mockStatic(LoginPasswordValidator.class);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		PowerMockito.when(LoginPasswordValidator.validatePassword(Mockito.any())).thenReturn(true);
		PowerMockito.when(LoginPasswordValidator.validateLogin(Mockito.any())).thenReturn(true);
		manualLoginRequest.setSource(AuthenticationServiceConstants.MPIN_OTP_LOGIN);
		ApplicantUtmBean applicantUtmBean=new ApplicantUtmBean();
		ResponseBean responseBean=new ResponseBean();
		responseBean.setPayload(response);
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		Mockito.when(AuthenticationServiceHelper.getToken(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(tokenResponse);
		authenticationServiceImpl.authenticateManualLogin(manualLoginRequest, headers, applicantUtmBean);
	}
	
	
	@Test(expected = BFLBusinessException.class)
	public void testAuthenticateManulaLoginEmployeeFailed() {
		String response= "{\"payload\":{\"userId\":0}}";
		UserLoginAccountRequest manualLoginRequest=new UserLoginAccountRequest();
		manualLoginRequest.setLoginId("9876543210");
		manualLoginRequest.setDateOfBirth("1992-09-09");
		manualLoginRequest.setPassword("test");
		PowerMockito.mockStatic(LoginPasswordValidator.class);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		PowerMockito.when(LoginPasswordValidator.validatePassword(Mockito.any())).thenReturn(true);
		PowerMockito.when(LoginPasswordValidator.validateLogin(Mockito.any())).thenReturn(true);
		manualLoginRequest.setSource(AuthenticationServiceConstants.EMPLOYEE_PORTAL);
		ApplicantUtmBean applicantUtmBean=new ApplicantUtmBean();
		ResponseBean responseBean=new ResponseBean();
		responseBean.setPayload(response);
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		authenticationServiceImpl.authenticateManualLogin(manualLoginRequest, headers, applicantUtmBean);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testAuthenticateManulaLoginFailedRequest() {
		String response= "{\"payload\":{\"userId\":2,\"failedRequest\":true}}";
		UserLoginAccountRequest manualLoginRequest=new UserLoginAccountRequest();
		manualLoginRequest.setLoginId("9876543210");
		manualLoginRequest.setDateOfBirth("1992-09-09");
		manualLoginRequest.setPassword("test");
		PowerMockito.mockStatic(LoginPasswordValidator.class);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		PowerMockito.when(LoginPasswordValidator.validatePassword(Mockito.any())).thenReturn(true);
		PowerMockito.when(LoginPasswordValidator.validateLogin(Mockito.any())).thenReturn(true);
		manualLoginRequest.setSource(AuthenticationServiceConstants.EMPLOYEE_PORTAL);
		ApplicantUtmBean applicantUtmBean=new ApplicantUtmBean();
		ResponseBean responseBean=new ResponseBean();
		responseBean.setPayload(response);
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		authenticationServiceImpl.authenticateManualLogin(manualLoginRequest, headers, applicantUtmBean);
	}
	
	@Test(expected = BFLBusinessException.class)
	public void testAuthenticateManulaLoginFailedRequestActive() {
		String response= "{\"payload\":{\"userId\":2,\"failedRequest\":true,\"accountStatus\":1}}";
		UserLoginAccountRequest manualLoginRequest=new UserLoginAccountRequest();
		manualLoginRequest.setLoginId("9876543210");
		manualLoginRequest.setDateOfBirth("1992-09-09");
		manualLoginRequest.setPassword("test");
		PowerMockito.mockStatic(LoginPasswordValidator.class);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(AuthenticationServiceHelper.class);
		PowerMockito.when(LoginPasswordValidator.validatePassword(Mockito.any())).thenReturn(true);
		PowerMockito.when(LoginPasswordValidator.validateLogin(Mockito.any())).thenReturn(true);
		manualLoginRequest.setSource(AuthenticationServiceConstants.EMPLOYEE_PORTAL);
		ApplicantUtmBean applicantUtmBean=new ApplicantUtmBean();
		ResponseBean responseBean=new ResponseBean();
		responseBean.setPayload(response);
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		Mockito.when(BFLCommonRestClient.create(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		authenticationServiceImpl.authenticateManualLogin(manualLoginRequest, headers, applicantUtmBean);
	}
	@Test
	public void testMobileAutoLogin() throws Exception{
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.mockStatic(MapperFactory.class);
        String authToken="eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJCYWphakZpblNlcnYiLCJleHAiOjE2NDUxMDc2MTksImlhdCI6MTY0NTEwNTgxOSwic3ViIjoiYXV0aGVudGljYXRpb24iLCJsb2dpbiI6Ijk5NzU1MjQyMzMiLCJ1c2VyVHlwZSI6MX0.6EwxVBbRyGWV86u6ft_VFPC1QSeZsw4lnkhUFSXz0dU";
        String guardtoken="D9diCjRWBi9q";
		TokensBean tokensBean = new TokensBean();
		tokensBean.setGuardToken(guardtoken);
		tokensBean.setStatus("VALID");
		tokensBean.setToken(authToken);
		ObjectWriter owTokensBean = new ObjectMapper().writer().withDefaultPrettyPrinter();
		String jsonTokensBean = owTokensBean.writeValueAsString(tokensBean);
		ResponseBean responseBean= new ResponseBean();
		responseBean.setPayload(jsonTokensBean);
		responseBean.setStatus(StatusCode.SUCCESS);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("guardtoken", guardtoken);
		httpHeaders.set("authtoken", authToken);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
		
		UserKeysBean userKeysBean = new UserKeysBean();
		userKeysBean.setApplicantKey(85120L);
		userKeysBean.setUserApplicantKey(78688L);
		userKeysBean.setUserKey(87428L);
		ObjectWriter owUserKey = new ObjectMapper().writer().withDefaultPrettyPrinter();

		String jsonUserKeysBean = owUserKey.writeValueAsString(userKeysBean);
		ResponseBean responseUserKeysBean= new ResponseBean();
		responseUserKeysBean.setPayload(jsonUserKeysBean);
		ResponseEntity<ResponseBean> responseEntityUserKeysBean = new ResponseEntity<ResponseBean>(responseUserKeysBean,HttpStatus.OK);
		
		Mockito.when((ResponseEntity<ResponseBean>)BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(responseEntity,responseEntityUserKeysBean);	
		
		ApplicantProfile applicantProfile = new ApplicantProfile();
		applicantProfile.setApplicantKey(85120L);
		Date formattedDate = new SimpleDateFormat("yyyy-MM-dd").parse("1989-05-01"); 
		applicantProfile.setDateOfBirth(formattedDate);
		applicantProfile.setGender("Male");
		applicantProfile.setMaritalStatus("MARRIED");
		MobileVerificationDet mobileVerificationDet = new MobileVerificationDet();
		mobileVerificationDet.setNumber("9975524233");
		applicantProfile.setMobileNumber(mobileVerificationDet);
		NameVerificationDetails name = new NameVerificationDetails();
		name.setFirstName("Sagar");
		applicantProfile.setName(name);
		applicantProfile.setPinCode("411006");
		
		ResponseBean responseApplicantProfile= new ResponseBean();
		responseApplicantProfile.setPayload(applicantProfile);
		responseApplicantProfile.setStatus(StatusCode.SUCCESS);
		responseApplicantProfile.setErrorBean(null);
		Mockito.when(authenticationServiceHelper.getApplicant(any(),  any())).thenReturn(responseApplicantProfile);
		
		UserResponse userResponse = new UserResponse();
		when(tokenCodeHelper.callUserAdditionalDet(Mockito.any(MobileLoginRequest.class), Mockito.anyShort(), Mockito.anyLong())).thenReturn(userResponse);
        authenticationServiceImpl.mobileAutoLogin(httpHeaders);
        assertNotNull(authenticationServiceImpl);
	}
}
