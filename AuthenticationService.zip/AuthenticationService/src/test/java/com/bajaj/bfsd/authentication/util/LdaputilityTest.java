package com.bajaj.bfsd.authentication.util;

import static org.junit.Assert.assertFalse;

import java.math.BigDecimal;
import java.util.Iterator;

import javax.naming.CommunicationException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchResult;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.authentication.LdapConfiguration;
import com.bajaj.bfsd.authentication.LdapPropertiesConfigurer;
import com.bajaj.bfsd.authentication.bean.User;
import com.bajaj.bfsd.common.BFLLoggerUtil;

@RunWith(PowerMockRunner.class)
public class LdaputilityTest {
	@InjectMocks
	Ldaputility ldaputility;
	
	@Mock
	DirContext ldapContext;

	@Mock
	LdapConfiguration ldapConfiguration;

	@Mock
	LdapPropertiesConfigurer ldapPropertiesConfigurer;
	
	@Mock
	BFLLoggerUtil logger;
	@Mock
	NamingEnumeration<SearchResult> results ;
	private String searchBase;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(ldaputility, "searchAttribute", "a,b,c");
	}
	
	@Test
	public void testGetAdUsersCN() throws NamingException {
		results=new NamingEnumeration<SearchResult>() {
			
			@Override
			public SearchResult nextElement() {
				return null;
			}
			
			@Override
			public boolean hasMoreElements() {
				return false;
			}
			
			@Override
			public SearchResult next() throws NamingException {
				BasicAttributes attributes=new BasicAttributes();
				BasicAttribute attribute1=new BasicAttribute("jkjh,hkjh");
				attributes.put("CN",attribute1);
				return new SearchResult("name", "obj",attributes);
			}
			
			@Override
			public boolean hasMore() throws NamingException {
				return true;
			}
			
			@Override
			public void close() throws NamingException {
				
			}
		};
		Mockito.when(ldapContext.search( Mockito.eq(searchBase),Mockito.eq("(&)"), Mockito.any())).thenReturn(results);
		assertFalse(ldaputility.getADUsers(new User()));
	}
	
	
	@Test
	public void testGetAdUsersOU() throws NamingException {
		results=new NamingEnumeration<SearchResult>() {
			
			@Override
			public SearchResult nextElement() {
				return null;
			}
			
			@Override
			public boolean hasMoreElements() {
				return false;
			}
			
			@Override
			public SearchResult next() throws NamingException {
				BasicAttributes attributes=new BasicAttributes();
				BasicAttribute attribute1=new BasicAttribute("jkjh:hkjh");
				attributes.put("OU",attribute1);
				return new SearchResult("name", "obj",attributes);
			}
			
			@Override
			public boolean hasMore() throws NamingException {
				return true;
			}
			
			@Override
			public void close() throws NamingException {
				
			}
		};
		Mockito.when(ldapContext.search( Mockito.eq(searchBase),Mockito.eq("(&(name=firstname*)(sn=last*)(telephoneNumber=9876543211)(mail=email)(title=des*))"), Mockito.any())).thenThrow(new CommunicationException());
		User user=new User();
		user.setFirstname("firstname");
		user.setLastname("last");
		user.setDesignation("des");
		user.setEmailId("email");
		user.setEmpId("123");
		user.setIsActive(BigDecimal.ONE);
		user.setMobileNumber("9876543211");
		user.setPassword("pass");
		assertFalse(ldaputility.getADUsers(user));
	}

}
