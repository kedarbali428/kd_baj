package com.bajaj.bfsd.authentication.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestClientException;

import com.bajaj.bfsd.authentication.bean.Address;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginRequest;
import com.bajaj.bfsd.authentication.bean.ApplicantDetailBean;
import com.bajaj.bfsd.authentication.bean.ApplicantKeysRequest;
import com.bajaj.bfsd.authentication.bean.ApplicantV2DetailsResponse;
import com.bajaj.bfsd.authentication.bean.BureauDetails;
import com.bajaj.bfsd.authentication.bean.DocumentDetails;
import com.bajaj.bfsd.authentication.bean.Email;
import com.bajaj.bfsd.authentication.bean.EmailDetails;
import com.bajaj.bfsd.authentication.bean.LocationAddressBean;
import com.bajaj.bfsd.authentication.bean.MobileAppOnBoardingRequest;
import com.bajaj.bfsd.authentication.bean.MobileAppOnBoardingResponse;
import com.bajaj.bfsd.authentication.bean.Occupation;
import com.bajaj.bfsd.authentication.bean.PanDetailsBean;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.PanVerificationResponse;
import com.bajaj.bfsd.authentication.bean.PersonalDetails;
import com.bajaj.bfsd.authentication.bean.PinCodeDetails;
import com.bajaj.bfsd.authentication.bean.ProspectDetailsResponse;
import com.bajaj.bfsd.authentication.bean.UpdateMobileAppOnBoardingRequest;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UserProfileAttribute;
import com.bajaj.bfsd.authentication.bean.Verification;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RunWith(SpringRunner.class)
public class AppOnBoardingUtilsTest {

	@InjectMocks
	private  AppOnBoardingUtils appOnBoardingUtils;
	
	@Mock
	private BFLLoggerUtil logger;

	@Mock
	private Environment env;

	@Mock
	private RestClientUtil restClientUtil;
	
	@Mock
	private DataFormatter dataFormatter;
	
	@Mock 
	private TokenCodeHelper tokenCodeHelper;
	
	@Test
	public void testGenerateOtpSuccess() {
		ResponseBean responseBean = new ResponseBean(AuthenticationServiceConstants.SUCCESS);
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		String generateOtp = appOnBoardingUtils.generateOtp("9999999999", new HttpHeaders());
		assertEquals(generateOtp, AuthenticationServiceConstants.YES);
	}

	@Test
	public void testGenerateOtpFailure() {
		ResponseBean responseBean = new ResponseBean(AuthenticationServiceConstants.FAILURE);
		responseBean.setStatus(StatusCode.FAILURE);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.UNAUTHORIZED);
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		String generateOtp = appOnBoardingUtils.generateOtp("9999999999", new HttpHeaders());
		assertEquals(generateOtp, AuthenticationServiceConstants.NO);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testGenerateOtpSomeException() {
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenThrow(new RestClientException("rest Client failed"));
		appOnBoardingUtils.generateOtp("9999999999", new HttpHeaders());
	}
	
	@Test
	public void testGetProspectDetailsSuccess() {
		ResponseBean responseBean = new ResponseBean(new ProspectDetailsResponse());
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		ProspectDetailsResponse prospectDetails = appOnBoardingUtils.getProspectDetails("9999999999", "01-01-1990", new HttpHeaders());
		assertNotNull(prospectDetails);
	}
	
	@Test
	public void testGetProspectDetailsFailure() {
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.FAILURE);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		ProspectDetailsResponse prospectDetails = appOnBoardingUtils.getProspectDetails("9999999999", "01-01-1990", new HttpHeaders());
		assertNull(prospectDetails);
	}
	
	@Test
	public void testGetProspectDetailsSomeException() {
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenThrow(new RestClientException("rest Client failed"));
		ProspectDetailsResponse prospectDetails = appOnBoardingUtils.getProspectDetails("9999999999", "01-01-1990", new HttpHeaders());
		assertNull(prospectDetails);
	}
	
	@Test
	public void testValidateOtpSuccess() {
		ResponseBean responseBean = new ResponseBean(AuthenticationServiceConstants.SUCCESS);
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		AppOnBoardingLoginRequest request = new AppOnBoardingLoginRequest();
		request.setMobileNumber("9999999999");
		request.setDateOfBirth("01-01-1979");
		String validationResponse = appOnBoardingUtils.validateOtp(request, new HttpHeaders());
		assertEquals(validationResponse, AuthenticationServiceConstants.SUCCESS);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testValidateOtpFailure() {
		ResponseBean responseBean = new ResponseBean(AuthenticationServiceConstants.FAILURE);
		responseBean.setStatus(StatusCode.FAILURE);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.UNAUTHORIZED);
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		AppOnBoardingLoginRequest request = new AppOnBoardingLoginRequest();
		request.setMobileNumber("9999999999");
		request.setDateOfBirth("01-01-1979");
		appOnBoardingUtils.validateOtp(request, new HttpHeaders());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testValidateOtpSomeException() {
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenThrow(new RestClientException("rest Client failed"));
		AppOnBoardingLoginRequest request = new AppOnBoardingLoginRequest();
		request.setMobileNumber("9999999999");
		request.setDateOfBirth("01-01-1979");
		appOnBoardingUtils.validateOtp(request, new HttpHeaders());
	}
	
	@Test
	public void testGenerateTokensSuccess() {
		appOnBoardingUtils.generateTokens("1", 1L, (short) 1, new HttpHeaders());
	}
	
	@Test
	public void testGenerateTokensFailure() {
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.FAILURE);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		appOnBoardingUtils.generateTokens("1", 1L, (short) 1, new HttpHeaders());
	}
		
	@Test
	public void testGetApplicantDetailsSuccess() {
		ResponseBean responseBean = new ResponseBean(new ApplicantDetailBean());
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.eq(null), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		ApplicantDetailBean applicantDetails = appOnBoardingUtils.getApplicantDetails("12345", new HttpHeaders());
		assertNotNull(applicantDetails);
	}
	
	@Test
	public void testGetApplicantDetailsFailure() {
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.FAILURE);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.eq(null), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		ApplicantDetailBean applicantDetails = appOnBoardingUtils.getApplicantDetails("12345", new HttpHeaders());
		assertNull(applicantDetails);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testGetApplicantDetailsSomeException() {
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.eq(null), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenThrow(new RestClientException("rest Client failed"));
		appOnBoardingUtils.getApplicantDetails("12345", new HttpHeaders());
	}
	
	@Test
	public void testUpdateApplicantDetailsSuccess() {
		ResponseEntity<UserProfileAttribute> responseEntity = new ResponseEntity<>(new UserProfileAttribute(), HttpStatus.OK);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(UserProfileAttribute.class)))
			.thenReturn(responseEntity);
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		profileDetails.setUserKeys(userKeysBean);
		UserProfileAttribute updateApplicantDetails = appOnBoardingUtils.updateApplicantDetails(new UserProfileAttribute(), profileDetails, new HttpHeaders());
		assertNotNull(updateApplicantDetails);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testUpdateApplicantDetailsFailureNull() {
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(UserProfileAttribute.class)))
			.thenReturn(null);
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		profileDetails.setUserKeys(userKeysBean);
		appOnBoardingUtils.updateApplicantDetails(new UserProfileAttribute(), profileDetails, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testUpdateApplicantDetailsFailureHttpStatus() {
		ResponseEntity<UserProfileAttribute> responseEntity = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(UserProfileAttribute.class)))
			.thenReturn(responseEntity);
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		profileDetails.setUserKeys(userKeysBean);
		appOnBoardingUtils.updateApplicantDetails(new UserProfileAttribute(), profileDetails, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testUpdateApplicantDetailsSomeException() {
		ResponseEntity<UserProfileAttribute> responseEntity = new ResponseEntity<>(new UserProfileAttribute(), HttpStatus.BAD_REQUEST);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(UserProfileAttribute.class)))
			.thenReturn(responseEntity);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		appOnBoardingUtils.updateApplicantDetails(new UserProfileAttribute(), profileDetails, new HttpHeaders());
	}
	
	@Test
	public void testUpdateEmailDetailsSuccess() {
		ResponseEntity<Email> responseEntity = new ResponseEntity<>(new Email(), HttpStatus.OK);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Email.class)))
			.thenReturn(responseEntity);
		PersonalDetails personalDetail = new PersonalDetails();
		personalDetail.setEmail(new EmailDetails());
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		profileDetails.setPersonalDetails(personalDetail);
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		Email emailDetails = appOnBoardingUtils.updateEmailDetails(profileDetails, new HttpHeaders());
		assertNotNull(emailDetails);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testUpdateEmailDetailsFailureNull() {
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Email.class)))
			.thenReturn(null);
		PersonalDetails personalDetail = new PersonalDetails();
		personalDetail.setEmail(new EmailDetails());
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		profileDetails.setPersonalDetails(personalDetail);
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		appOnBoardingUtils.updateEmailDetails(profileDetails, new HttpHeaders());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testUpdateEmailDetailsFailureHttpStatus() {
		ResponseEntity<Email> responseEntity = new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Email.class)))
			.thenReturn(responseEntity);
		PersonalDetails personalDetail = new PersonalDetails();
		personalDetail.setEmail(new EmailDetails());
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		profileDetails.setPersonalDetails(personalDetail);
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		Email emailDetails = appOnBoardingUtils.updateEmailDetails(profileDetails, new HttpHeaders());
		assertNotNull(emailDetails);
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testUpdateEmailDetailsSomeException() {
		ResponseEntity<Email> responseEntity = new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Email.class)))
			.thenReturn(responseEntity);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		appOnBoardingUtils.updateEmailDetails(profileDetails, new HttpHeaders());
	}
	
	@Test
	public void testGetPinCodeDetailsSuccess() {
		ResponseEntity<LocationAddressBean> responseEntity = new ResponseEntity<>(new LocationAddressBean(), HttpStatus.OK);
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.eq(null), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(LocationAddressBean.class)))
			.thenReturn(responseEntity);
		PersonalDetails personalDetail = new PersonalDetails();
		personalDetail.setPinCode(new PinCodeDetails());
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		profileDetails.setPersonalDetails(personalDetail);
		LocationAddressBean pinCodeDetails = appOnBoardingUtils.getPinCodeDetails(profileDetails, new HttpHeaders());
		assertNotNull(pinCodeDetails);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testGetPinCodeDetailsFailureNull() {
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.eq(null), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(LocationAddressBean.class)))
			.thenReturn(null);
		PersonalDetails personalDetail = new PersonalDetails();
		personalDetail.setPinCode(new PinCodeDetails());
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		profileDetails.setPersonalDetails(personalDetail);
		appOnBoardingUtils.getPinCodeDetails(profileDetails, new HttpHeaders());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testGetPinCodeDetailsFailureHttpStatus() {
		ResponseEntity<LocationAddressBean> responseEntity = new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.eq(null), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(LocationAddressBean.class)))
			.thenReturn(responseEntity);
		PersonalDetails personalDetail = new PersonalDetails();
		personalDetail.setPinCode(new PinCodeDetails());
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		profileDetails.setPersonalDetails(personalDetail);
		appOnBoardingUtils.getPinCodeDetails(profileDetails, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testGetPinCodeDetailsFailureSomeException() {
		ResponseEntity<LocationAddressBean> responseEntity = new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.eq(null), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(LocationAddressBean.class)))
			.thenReturn(responseEntity);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		appOnBoardingUtils.getPinCodeDetails(profileDetails, new HttpHeaders());
	}
	
	@Test
	public void testUpdateAddressDetailsSuccess() {
		ResponseEntity<Address> responseEntity = new ResponseEntity<>(new Address(), HttpStatus.OK);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Address.class)))
			.thenReturn(responseEntity);
		LocationAddressBean addressBean = new LocationAddressBean();
		addressBean.setCityId(1L);
		addressBean.setCountryId(1L);
		addressBean.setPinId(1L);
		addressBean.setPinCode("1");
		addressBean.setStateId(1L);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		Address updateAddressDetails = appOnBoardingUtils.updateAddressDetails(profileDetails, addressBean, new HttpHeaders());
		assertNotNull(updateAddressDetails);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testUpdateAddressDetailsFailureNull() {
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Address.class)))
			.thenReturn(null);
		LocationAddressBean addressBean = new LocationAddressBean();
		addressBean.setCityId(1L);
		addressBean.setCountryId(1L);
		addressBean.setPinId(1L);
		addressBean.setPinCode("1");
		addressBean.setStateId(1L);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		appOnBoardingUtils.updateAddressDetails(profileDetails, addressBean, new HttpHeaders());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testUpdateAddressDetailsFailureHttpStatus() {
		ResponseEntity<Address> responseEntity = new ResponseEntity<>(new Address(), HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Address.class)))
			.thenReturn(responseEntity);
		LocationAddressBean addressBean = new LocationAddressBean();
		addressBean.setCityId(1L);
		addressBean.setCountryId(1L);
		addressBean.setPinId(1L);
		addressBean.setPinCode("1");
		addressBean.setStateId(1L);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		appOnBoardingUtils.updateAddressDetails(profileDetails, addressBean, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testUpdateAddressDetailsFailureSomeException() {
		ResponseEntity<Address> responseEntity = new ResponseEntity<>(new Address(), HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Address.class)))
			.thenReturn(responseEntity);
		LocationAddressBean addressBean = new LocationAddressBean();
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		appOnBoardingUtils.updateAddressDetails(profileDetails, addressBean, new HttpHeaders());
	}
	
	@Test
	public void testUpdateOccupationDetailsSuccess() {
		ResponseEntity<Occupation> responseEntity = new ResponseEntity<>(new Occupation(), HttpStatus.OK);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Occupation.class)))
			.thenReturn(responseEntity);
		Occupation occupation = new Occupation();
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		Occupation updatedOccupationDetails = appOnBoardingUtils.updateOccupationDetails(profileDetails, occupation, new HttpHeaders());
		assertNotNull(updatedOccupationDetails);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testUpdateOccupationDetailsFailureNull() {
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Occupation.class)))
			.thenReturn(null);
		Occupation occupation = new Occupation();
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		appOnBoardingUtils.updateOccupationDetails(profileDetails, occupation, new HttpHeaders());
	}

	@Test(expected = BFLHttpException.class)
	public void testUpdateOccupationDetailsFailureHttpStatus() {
		ResponseEntity<Occupation> responseEntity = new ResponseEntity<>(new Occupation(), HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Occupation.class)))
			.thenReturn(responseEntity);
		Occupation occupation = new Occupation();
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		appOnBoardingUtils.updateOccupationDetails(profileDetails, occupation, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testUpdateOccupationDetailsSomeException() {
		ResponseEntity<Occupation> responseEntity = new ResponseEntity<>(new Occupation(), HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(Occupation.class)))
			.thenReturn(responseEntity);
		Occupation occupation = new Occupation();
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		appOnBoardingUtils.updateOccupationDetails(profileDetails, occupation, new HttpHeaders());
	}
	
	@Test
	public void testUpdatePanDetailsSuccess() {
		ResponseEntity<DocumentDetails> responseEntity = new ResponseEntity<>(new DocumentDetails(), HttpStatus.OK);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(DocumentDetails.class)))
			.thenReturn(responseEntity);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		BureauDetails bureauDetails = new BureauDetails();
		bureauDetails.setPan(new PanDetailsBean());
		profileDetails.setBureauDetails(bureauDetails);
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		DocumentDetails updatedDocumentDetails = appOnBoardingUtils.updatePanDetails(profileDetails, null, new HttpHeaders());
		assertNotNull(updatedDocumentDetails);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testUpdatePanDetailsFailureNull() {
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(DocumentDetails.class)))
			.thenReturn(null);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		BureauDetails bureauDetails = new BureauDetails();
		bureauDetails.setPan(new PanDetailsBean());
		profileDetails.setBureauDetails(bureauDetails);
		appOnBoardingUtils.updatePanDetails(profileDetails, new Verification(), new HttpHeaders());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testUpdatePanDetailsFailureHttpStatus() {
		ResponseEntity<DocumentDetails> responseEntity = new ResponseEntity<>(new DocumentDetails(), HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(DocumentDetails.class)))
			.thenReturn(responseEntity);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(12345L);
		profileDetails.setUserKeys(userKeysBean);
		BureauDetails bureauDetails = new BureauDetails();
		bureauDetails.setPan(new PanDetailsBean());
		profileDetails.setBureauDetails(bureauDetails);
		appOnBoardingUtils.updatePanDetails(profileDetails, null, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testUpdatePanDetailsSomeException() {
		ResponseEntity<DocumentDetails> responseEntity = new ResponseEntity<>(new DocumentDetails(), HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.eq(null), Mockito.any(), Mockito.eq(null),
				Mockito.eq(DocumentDetails.class)))
			.thenReturn(responseEntity);
		UpdateUserProfileDetailsRequest profileDetails = new UpdateUserProfileDetailsRequest();
		appOnBoardingUtils.updatePanDetails(profileDetails, null, new HttpHeaders());
	}
	
	@Test
	public void testgetApplicantDetailsV2WithPanVerificationSuccess() {
		ResponseEntity<ApplicantV2DetailsResponse> responseEntity = new ResponseEntity<>(new ApplicantV2DetailsResponse(), HttpStatus.OK);
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ApplicantV2DetailsResponse.class)))
			.thenReturn(responseEntity);
		ApplicantV2DetailsResponse applicantDetails = appOnBoardingUtils.getApplicantDetailsV2WithPanVerification("1234", new HttpHeaders());
		assertNotNull(applicantDetails);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testgetApplicantDetailsV2WithPanVerificationFailureNull() {
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ApplicantV2DetailsResponse.class)))
			.thenReturn(null);
		appOnBoardingUtils.getApplicantDetailsV2WithPanVerification("1234", new HttpHeaders());
	}
	
	@Test(expected = BFLHttpException.class)
	public void testgetApplicantDetailsV2WithPanVerificationFailureHttpStatus() {
		ResponseEntity<ApplicantV2DetailsResponse> responseEntity = new ResponseEntity<>(new ApplicantV2DetailsResponse(), HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ApplicantV2DetailsResponse.class)))
			.thenReturn(responseEntity);
		appOnBoardingUtils.getApplicantDetailsV2WithPanVerification("1234", new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testgetApplicantDetailsV2WithPanVerificationSomeException() {
		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ApplicantV2DetailsResponse.class)))
			.thenThrow(new RestClientException("rest Client failure"));
		appOnBoardingUtils.getApplicantDetailsV2WithPanVerification("1234", new HttpHeaders());
	}
	
	@Test
	public void testGetApplicantNsdlPanVerificationStatus() {
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(1L);
		request.setUserKeys(userKeysBean);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(new PanVerificationResponse());
		responseBean.setStatus(StatusCode.SUCCESS);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.OK);

		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		PanVerificationResponse response = appOnBoardingUtils.getApplicantNsdlPanVerificationStatus(request, new HttpHeaders());
		assertNotNull(response);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testGetApplicantNsdlPanVerificationStatusFailure() {
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		ApplicantKeysRequest userKeysBean = new ApplicantKeysRequest();
		userKeysBean.setApplicantKey(1L);
		request.setUserKeys(userKeysBean);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setStatus(StatusCode.FAILURE);
		ResponseEntity<ResponseBean> responseEntity = new ResponseEntity<>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);

		Mockito.when(restClientUtil.getCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(ResponseBean.class)))
			.thenReturn(responseEntity);
		appOnBoardingUtils.getApplicantNsdlPanVerificationStatus(request, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testGetApplicantNsdlPanVerificationStatusSomeException() {
		PanProfileDetailsRequest request = new PanProfileDetailsRequest();
		appOnBoardingUtils.getApplicantNsdlPanVerificationStatus(request, new HttpHeaders());
	}

	@Test
	public void testsaveApplicantMobAppOnBoardingStatusSuccess() {
		MobileAppOnBoardingRequest request = new MobileAppOnBoardingRequest();
		request.setApplicantId(1234L);
		request.setEtpStatus(AuthenticationServiceConstants.YES);
		
		MobileAppOnBoardingResponse response = new MobileAppOnBoardingResponse();
		response.setSkipFlag(true);
		
		ResponseEntity<MobileAppOnBoardingResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(MobileAppOnBoardingResponse.class)))
			.thenReturn(responseEntity);
		MobileAppOnBoardingResponse saved = appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(request, new HttpHeaders());
		assertNotNull(saved);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testsaveApplicantMobAppOnBoardingStatusFailure() {
		MobileAppOnBoardingRequest request = new MobileAppOnBoardingRequest();
		request.setApplicantId(1234L);
		request.setEtpStatus(AuthenticationServiceConstants.YES);
		
		ResponseEntity<MobileAppOnBoardingResponse> responseEntity = new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(MobileAppOnBoardingResponse.class)))
			.thenReturn(responseEntity);
		appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(request, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testsaveApplicantMobAppOnBoardingStatusSomeException() {
		MobileAppOnBoardingRequest request = new MobileAppOnBoardingRequest();
		request.setApplicantId(1234L);
		request.setEtpStatus(AuthenticationServiceConstants.YES);
		
		Mockito.when(restClientUtil.postCall(Mockito.anyString(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(MobileAppOnBoardingResponse.class)))
			.thenThrow(new RestClientException("rest client exception"));
		appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(request, new HttpHeaders());
	}
	
	@Test
	public void testupdateApplicantMobAppOnBoardingStatusSuccess() {
		UpdateMobileAppOnBoardingRequest request = new UpdateMobileAppOnBoardingRequest();
		request.setApplicantId(1234L);
		request.setSkipFlag(false);
		
		MobileAppOnBoardingResponse response = new MobileAppOnBoardingResponse();
		response.setSkipFlag(true);
		
		ResponseEntity<MobileAppOnBoardingResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(MobileAppOnBoardingResponse.class)))
			.thenReturn(responseEntity);
		MobileAppOnBoardingResponse updated = appOnBoardingUtils.updateApplicantMobAppOnBoardingStatus(request, new HttpHeaders());
		assertNotNull(updated);
	}
	
	@Test(expected = BFLHttpException.class)
	public void testupdateApplicantMobAppOnBoardingStatusFailure() {
		UpdateMobileAppOnBoardingRequest request = new UpdateMobileAppOnBoardingRequest();
		request.setApplicantId(1234L);
		request.setSkipFlag(false);
		
		ResponseEntity<MobileAppOnBoardingResponse> responseEntity = new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(MobileAppOnBoardingResponse.class)))
			.thenReturn(responseEntity);
		appOnBoardingUtils.updateApplicantMobAppOnBoardingStatus(request, new HttpHeaders());
	}
	
	@Test(expected = BFLTechnicalException.class)
	public void testupdateApplicantMobAppOnBoardingStatusSomeException() {
		UpdateMobileAppOnBoardingRequest request = new UpdateMobileAppOnBoardingRequest();
		request.setApplicantId(1234L);
		request.setSkipFlag(false);
		
		Mockito.when(restClientUtil.putCall(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any(HttpHeaders.class),
				Mockito.eq(MobileAppOnBoardingResponse.class)))
			.thenThrow(new RestClientException("rest client exception"));
		appOnBoardingUtils.updateApplicantMobAppOnBoardingStatus(request, new HttpHeaders());
	}

}

