package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class PartnerLoginRequest implements Serializable{

	private static final long serialVersionUID = -2117631641264370414L;

	@NotEmpty(message = "AUTH_635")
	private String partnerKey;
	
	@NotEmpty(message = "AUTH_635")
	private String secretKey;
	
	public String getPartnerKey() {
		return partnerKey;
	}
	public void setPartnerKey(String partnerKey) {
		this.partnerKey = partnerKey;
	}
	public String getSecretKey() {
		return secretKey;
	}
	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

}
