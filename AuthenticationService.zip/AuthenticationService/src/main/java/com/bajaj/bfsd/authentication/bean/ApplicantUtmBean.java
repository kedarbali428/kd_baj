package com.bajaj.bfsd.authentication.bean;

import org.springframework.stereotype.Service;

@Service
public class ApplicantUtmBean {

	private long applicantKey;
	private String sourcePlatform;
	private String apltUtmCampaign;
	private String apltUtmContent;
	private String apltUtmMedium;
	private String apltUtmSource;
	private String apltUtmTerm;
	private String apltAppSource;
	private String eventType;
	private String lastUpdateBy;
	private String userAgent;

	public long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getSourcePlatform() {
		return sourcePlatform;
	}

	public void setSourcePlatform(String sourcePlatform) {
		this.sourcePlatform = sourcePlatform;
	}

	public String getApltUtmCampaign() {
		return apltUtmCampaign;
	}

	public void setApltUtmCampaign(String apltUtmCampaign) {
		this.apltUtmCampaign = apltUtmCampaign;
	}

	public String getApltUtmContent() {
		return apltUtmContent;
	}

	public void setApltUtmContent(String apltUtmContent) {
		this.apltUtmContent = apltUtmContent;
	}

	public String getApltUtmMedium() {
		return apltUtmMedium;
	}

	public void setApltUtmMedium(String apltUtmMedium) {
		this.apltUtmMedium = apltUtmMedium;
	}

	public String getApltUtmSource() {
		return apltUtmSource;
	}

	public void setApltUtmSource(String apltUtmSource) {
		this.apltUtmSource = apltUtmSource;
	}

	public String getApltUtmTerm() {
		return apltUtmTerm;
	}

	public void setApltUtmTerm(String apltUtmTerm) {
		this.apltUtmTerm = apltUtmTerm;
	}

	public String getApltAppSource() {
		return apltAppSource;
	}

	public void setApltAppSource(String apltAppSource) {
		this.apltAppSource = apltAppSource;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

}
