package com.bajaj.bfsd.authentication.util;

import java.math.BigInteger;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.DigestException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.bajaj.bfsd.authentication.bean.ApplicantCreateRequest;
import com.bajaj.bfsd.authentication.bean.ApplicantEmailBean;
import com.bajaj.bfsd.authentication.bean.ApplicantProfile;
import com.bajaj.bfsd.authentication.bean.ApplicationRequestBean;
import com.bajaj.bfsd.authentication.bean.UserKeysBean;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV4;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV5;
import com.bajaj.bfsd.authentication.config.MapperFactory;
import com.bajaj.bfsd.authentication.model.PartnerLoginRequest;
import com.bajaj.bfsd.authentication.model.SocialProfileResponse;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.UserLoginAccountResponse;
import com.bajaj.bfsd.authentication.model.ValidateOTP;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class AuthenticationServiceHelper {

	private static final String THIS_CLASS = AuthenticationServiceHelper.class.getCanonicalName();
	
	private static final String FAILURE = "FAILURE";

	private static final String SUCCESS = "SUCCESS";
	
	@Autowired
	Environment env;
	
	@Autowired
	BFLLoggerUtil logger;
	
	@Value("${api.applicant.openMarkets.getApplicant.GET.url}")
	private String getApplicantUrl;

	@Value("${api.applicant.openMarkets.createApplicant.POST.url}")
	private String createApplicantUrl;

	@Value("${api.usermanagement.getloginaccount.POST.url}")
	private String createUserUrl;
	
	@Value("${api.vas.fhcrapplication.initiateprocess.POST.url}")
	private String triggerCibilOtpUrl;
	
	@Value("${api.otp.generate.POST.url}")
	private String triggerBfdlOtpUrl;
	
	@Value("${api.vas.fhcrapplication.validateprocess.POST.url}")
	private String validateCibilOtpUrl;
	
	@Value("${api.otp.validate.POST.url}")
	private String validateBfdlOtpUrl;

	@Value("${api.applicant.linkuser.POST.url}")
	private String userApplicantUrl;

	@Value("${api.applicant.save.email.POST.url}")
	private String saveEmailForApplicantUrl;

	@Value("${api.applicant.openMarkets.emails.GET.url}")
	private String getEmailForApplicantUrl;

	@Value("${tms.token.salt}")
	private String salt;
	
	@Value("${api.usermanagement.autoregister.POST.url}")
	private String autoRegisterUrl;
	
	@Value("${api.authentication.partnerlogin.POST.url}")
	private String loginPartnerUrl;
	
	private byte[] iv = { 4, 7, 2, 9, 1, 6, 5, 8, 2, 7, 2, 6, 4, 8, 3, 9 };
	private String secretKeyAlgo = "PBKDF2WithHmacSHA1";
	private String cipherAlgo = "AES/CBC/PKCS5PADDING";
	private String algo = "AES";

	AuthenticationServiceHelper() {

	}

	public static SocialProfileResponse getSocialProfile(BFLLoggerUtil logger, String socialProfileURL, String code, String token, HttpHeaders headers, Environment env) {
		
		SocialProfileResponse socialProfile;
		ObjectMapper mapper = MapperFactory.getInstance();
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getSocialDetails - started");
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("code", code);
		queryParam.put("token", token);

		ResponseEntity<ResponseBean> socialProfileResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.GET,socialProfileURL, null,
				ResponseBean.class, queryParam, null, headers, null);

		if (socialProfileResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(socialProfileResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while calling social service - "+socialProfileURL);
				throw new BFLBusinessException("AUTH_629", env.getProperty("AUTH_629"));
			} else {

				socialProfile = mapper.convertValue(socialProfileResponse.getBody().getPayload(), SocialProfileResponse.class);

			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Invalid status received while calling social URL - "+socialProfileURL);
			throw new BFLBusinessException("AUTH_628", env.getProperty("AUTH_628"));
		}


		return socialProfile;

	}

	public static UserLoginAccountResponse authenticateUser(String userMngmtURL, String requestString, BFLLoggerUtil logger) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);

		ResponseEntity<ResponseBean> authenticateUserResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST, userMngmtURL, null,
				ResponseBean.class, null, requestString, headers, null);

		if (authenticateUserResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(authenticateUserResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateUser - User not authenticated");
				throw new BFLBusinessException("AUTH_634", "");
			} else {
				return MapperFactory.getInstance().convertValue(authenticateUserResponse.getBody().getPayload(), UserLoginAccountResponse.class);
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateUser - invalid status");
			throw new BFLBusinessException("AUTH_634","");
		}
	}

	public static TokenResponse getToken(String tokenServiceURL, String requestString, BFLLoggerUtil logger,HttpHeaders headers) {
		ResponseEntity<ResponseBean> tokenServiceResponse = BFLCommonRestClient.create(tokenServiceURL, null,
				String.class, null, requestString, headers, null);
		TokenResponse tokenResponse;

		if (tokenServiceResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(tokenServiceResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Failed to authenticate user");
				throw new BFLBusinessException("AUTH-001", "Failed to authenticate user");
			} else {

				JSONObject respJson = new JSONObject(tokenServiceResponse.getBody().getPayload().toString());
				JSONObject payloadJson = respJson.has("payload") ? respJson.getJSONObject("payload") : new JSONObject();

				Gson gson = new Gson();
				tokenResponse = gson.fromJson(payloadJson.toString(), TokenResponse.class);

				return tokenResponse;
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Get token failed for login ID - ");
			throw new BFLBusinessException("500", "Get token failed for login ID - ");
		}
	}	

	public static short getUserType(String reqSource) {
		short retVal = AuthenticationServiceConstants.USERTYPE_CUSTOMER;
		String source = reqSource == null? "": reqSource.toLowerCase().trim();
		switch(source){
		case AuthenticationServiceConstants.JOURNEY:
		case AuthenticationServiceConstants.CUSTOMER_PORTAL:
		case AuthenticationServiceConstants.MPIN_OTP_LOGIN:
			retVal = AuthenticationServiceConstants.USERTYPE_CUSTOMER;
			break;
		case AuthenticationServiceConstants.EMPLOYEE_PORTAL:
			retVal = AuthenticationServiceConstants.USERTYPE_EMPLOYEE;
			break;		
		case AuthenticationServiceConstants.B2B_PARTNER:
			retVal = AuthenticationServiceConstants.USERTYPE_B2B_PARTNER;			
			break;
		case AuthenticationServiceConstants.VENDOR:
			retVal = AuthenticationServiceConstants.USERTYPE_VENDOR_PARTNER;			
			break;
		case AuthenticationServiceConstants.SYSTEM:
			retVal = AuthenticationServiceConstants.USERTYPE_SYSTEM;
			break;
		case AuthenticationServiceConstants.SYSTEM_PARTNER:
			retVal = AuthenticationServiceConstants.USERTYPE_SYSTEM_PARTNER;
			break;
        case AuthenticationServiceConstants.PRINCIPAL:
			retVal = AuthenticationServiceConstants.USERTYPE_PRINCIPAL;
			break;
		default:
		}
		return retVal;
	}
		
	public static short getSocialLoginType(String reqTarget){
		short retVal = AuthenticationServiceConstants.LOGINACCTYPE_SOCIAL_FB;
		String target = reqTarget == null? "": reqTarget.toLowerCase().trim();
		switch(target){
		case AuthenticationServiceConstants.FACEBOOK:
			retVal = AuthenticationServiceConstants.LOGINACCTYPE_SOCIAL_FB;
			break;
		case AuthenticationServiceConstants.LINKEDIN:
			retVal = AuthenticationServiceConstants.LOGINACCTYPE_SOCIAL_LI;
			break;
		default:
		}
		
		return retVal;
	}
		
	public static String decryptPassword(String secret, String value, BFLLoggerUtil logger){
		// Decrypt cipher
		
		String cipherText = value;

		try {
			byte[] cipherData = java.util.Base64.getDecoder().decode(cipherText);
			byte[] saltData = Arrays.copyOfRange(cipherData, 8, 16);

			MessageDigest md5 = MessageDigest.getInstance("MD5");
			final byte[][] keyAndIV = generateKeyAndIV(32, 16, 1, saltData, secret.getBytes(StandardCharsets.UTF_8), md5);
			SecretKeySpec key = new SecretKeySpec(keyAndIV[0], "AES");
			IvParameterSpec iv = new IvParameterSpec(keyAndIV[1]);

			byte[] encrypted = Arrays.copyOfRange(cipherData, 16, cipherData.length);
			Cipher aesCBC = Cipher.getInstance("AES/CBC/PKCS5Padding");
			aesCBC.init(Cipher.DECRYPT_MODE, key, iv);
			byte[] decryptedData = aesCBC.doFinal(encrypted);
			
			return new String(decryptedData, StandardCharsets.UTF_8);
		}
		catch (GeneralSecurityException ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "decryptPassword - unable to decrypt password - "+ex);
		}
		
		return "";


	}
	public static byte[][] generateKeyAndIV(int keyLength, int ivLength, int iterations, byte[] salt, byte[] password, MessageDigest md) 
			throws DigestException {

	    int digestLength = md.getDigestLength();
	    int requiredLength = (keyLength + ivLength + digestLength - 1) / digestLength * digestLength;
	    byte[] generatedData = new byte[requiredLength];
	    int generatedLength = 0;

	    
        md.reset();

        // Repeat process until sufficient data has been generated
        while (generatedLength < keyLength + ivLength) {

            // Digest data (last digest if available, password data, salt if available)
            if (generatedLength > 0)
                md.update(generatedData, generatedLength - digestLength, digestLength);
            md.update(password);
            if (salt != null)
                md.update(salt, 0, 8);
            md.digest(generatedData, generatedLength, digestLength);

            // additional rounds
            for (int i = 1; i < iterations; i++) {
                md.update(generatedData, generatedLength, digestLength);
                md.digest(generatedData, generatedLength, digestLength);
            }

            generatedLength += digestLength;
        }

        // Copy key and IV into separate byte arrays
        byte[][] result = new byte[2][];
        result[0] = Arrays.copyOfRange(generatedData, 0, keyLength);
        if (ivLength > 0)
            result[1] = Arrays.copyOfRange(generatedData, keyLength, keyLength + ivLength);

		return result;

	}

	/**
	 * Validate the loginId and password for number only and for length.
	 * 
	 * @param mobileUserLoginRequest
	 */
	public static void validateLoginPass(String mpin, BFLLoggerUtilExt logger,
			Environment env) {
		if (!mpin.matches("[\\d]{4}")) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,
					AuthenticationServiceConstants.ID_PASS_VALIDATION_FAIL);
			throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_636,
					env.getProperty(AuthenticationServiceConstants.AUTH_636));
		}

	}
	
	public static void validateLoginID(String loginId, BFLLoggerUtilExt logger,
			Environment env) {
		if (!loginId.matches("^[6-9][0-9]{9}$")) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,
					AuthenticationServiceConstants.ID_PASS_VALIDATION_FAIL);
			throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_636,
					env.getProperty(AuthenticationServiceConstants.AUTH_636));
		}

	}
	
	
	

	/**
	 * Validate the date for emptiness and required format
	 * @param date
	 * @param logger
	 * @param env
	 */
	public static void validateDate(String date, BFLLoggerUtil logger, Environment env) {
		DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		// Input to be parsed should strictly follow the defined date format
		// above.
		format.setLenient(false);
		if (!StringUtils.isEmpty(date)) {
			try {
				format.parse(date);
			} catch (ParseException e) {
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,
						AuthenticationServiceConstants.DATE_VALIDATION_FAILURE);
				throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_640,
						env.getProperty(AuthenticationServiceConstants.AUTH_640));
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,
					AuthenticationServiceConstants.DATE_VALIDATION_FAILURE);
			throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_640,
					env.getProperty(AuthenticationServiceConstants.AUTH_640));
		}
	}
	
	public static String timeStampToStringDate(Timestamp dateOfBirth) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(dateOfBirth);
	}
	
	public static String checkAndValidateDate(String inputDate,BFLLoggerUtilExt logger,Environment env) {
		SimpleDateFormat sdfSource = new SimpleDateFormat(AuthenticationServiceConstants.DOB_YYYY_MM_DD_FORMAT);
		String resDate;
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Date Before conversion "+inputDate);
		try {
			Date date = sdfSource.parse(inputDate);
			 //create SimpleDateFormat object with desired date format
		      SimpleDateFormat sdfDestination = new SimpleDateFormat(AuthenticationServiceConstants.DOB_YYYY_MM_DD_FORMAT);
		      //parse the date into another format
		      resDate = sdfDestination.format(date);
		} catch (ParseException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,"Invalid Date");
			throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_643,
					env.getProperty(AuthenticationServiceConstants.AUTH_643));
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Date After conversion "+resDate);
		return resDate;
		
	}
	
	public ResponseBean createApplicant(ApplicantCreateRequest applicantCreateRequest, HttpHeaders headers)
			throws Exception {

		Gson gson = new Gson();
		
		ResponseBean responseBean = new ResponseBean();

		String applicantCreateRequestJson = gson.toJson(applicantCreateRequest);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre register - create applicant - started - " + applicantCreateRequestJson);
		
		@SuppressWarnings("unchecked")
		ResponseEntity<ResponseBean> createApplicantResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, createApplicantUrl, null, ApplicantProfile.class, null,
						applicantCreateRequestJson, headers);

		String applicantCreateResponseJson = gson.toJson(createApplicantResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre register - create applicant - ended - " + applicantCreateResponseJson);

		if (createApplicantResponse.getStatusCodeValue() == HttpStatus.CONFLICT.value()) {
			if (StatusCode.FAILURE.name().equals(createApplicantResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "ntpPreRegister - Applicant already exists.");
				String payload = (String) createApplicantResponse.getBody().getPayload();
				responseBean = gson.fromJson(payload, ResponseBean.class);
				return responseBean;
			}
		}

		responseBean.setPayload(createApplicantResponse.getBody());
		responseBean.setStatus(StatusCode.SUCCESS);
		return responseBean;
	}

	public ResponseBean createUserAndUserLoginAccount(UserLoginAccountRequestV4 userLoginAccountRequest,
			HttpHeaders headers) throws Exception {

		Gson gson = new Gson();

		String userLoginAccountRequestJson = gson.toJson(userLoginAccountRequest);

		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre register - create user - started for - " + userLoginAccountRequestJson);

		ResponseEntity<ResponseBean> userLoginAccountResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, createUserUrl, null, ResponseBean.class, null,
						userLoginAccountRequestJson, headers);

		String userLoginAccountResponseJson = gson.toJson(userLoginAccountResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre register - create user - ended for - " + userLoginAccountResponseJson);

		return userLoginAccountResponse.getBody();
	}

	public ResponseBean getApplicant(Long applicantKey, HttpHeaders headers) throws Exception {

		Gson gson = new Gson();
		ResponseBean responseBean = new ResponseBean();
		
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"In get Appliacnt - started url - " + getApplicantUrl);
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("applicantKey", String.valueOf(applicantKey));
		
		ResponseEntity<ResponseBean> applicantResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.GET, getApplicantUrl, null, ApplicantProfile.class, params, null,
						headers, null);

		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"in get Applciant - ended json - " + gson.toJson(applicantResponse));
		
		if (applicantResponse.getStatusCodeValue() == HttpStatus.NOT_FOUND.value()) {
			if (StatusCode.FAILURE.name().equals(applicantResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "ntpPreRegister - Applicant not found");
				String payload = (String) applicantResponse.getBody().getPayload();
				responseBean = gson.fromJson(payload, ResponseBean.class);
				return responseBean;
			}
		}

		responseBean.setPayload(applicantResponse.getBody());
		responseBean.setStatus(StatusCode.SUCCESS);
		return responseBean;
	}

	public ResponseBean triggerCibilOtp(ApplicationRequestBean applicationRequestBean, HttpHeaders headers)
			throws Exception {

		Gson gson = new Gson();

		String applicationRequestBeanJson = gson.toJson(applicationRequestBean);

		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre process - trigger cibil otp - started for - " + applicationRequestBeanJson);

		ResponseEntity<ResponseBean> userLoginAccountResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, triggerCibilOtpUrl, null, ResponseBean.class, null,
						applicationRequestBeanJson, headers);

		String userLoginAccountResponseJson = gson.toJson(userLoginAccountResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre process - trigger cibil otp - ended for - " + userLoginAccountResponseJson);

		return userLoginAccountResponse.getBody();

	}

	public ResponseBean triggerBfldOtp(String mobileNumber, HttpHeaders headers) throws Exception {

		Gson gson = new Gson();
		JSONObject jsonRequest = new JSONObject();
		jsonRequest.put("mobile", mobileNumber);
		jsonRequest.put("mfa", true);

		String genearteBfdlOtpJson = jsonRequest.toString();

		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre process - trigger bfdl otp - started for - " + genearteBfdlOtpJson);

		ResponseEntity<ResponseBean> genearteBfdlOtpResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, triggerBfdlOtpUrl, null, ResponseBean.class, null,
						genearteBfdlOtpJson, headers);

		String genearteBfdlOtpResponseJson = gson.toJson(genearteBfdlOtpResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre process - trigger bfdl otp - ended for - " + genearteBfdlOtpResponseJson);

		return genearteBfdlOtpResponse.getBody();

	}

	public ResponseBean validateCibilOtp(ApplicationRequestBean applicationRequestBean, HttpHeaders headers)
			throws Exception {

		Gson gson = new Gson();

		String applicationRequestBeanJson = gson.toJson(applicationRequestBean);

		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp login - validate cibil otp - started for - " + applicationRequestBeanJson);

		ResponseEntity<ResponseBean> validateCibitOtpResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, validateCibilOtpUrl, null, ResponseBean.class, null,
						applicationRequestBeanJson, headers);

		String userLoginAccountResponseJson = gson.toJson(validateCibitOtpResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp login - validate cibil otp - ended for - " + userLoginAccountResponseJson);

		return validateCibitOtpResponse.getBody();

	}

	public ResponseBean validateBfdlOtp(ValidateOTP validateOTP, HttpHeaders headers) throws Exception {

		Gson gson = new Gson();
		
		HttpHeaders httpHeaders=new HttpHeaders();
		httpHeaders.set("authtoken", headers.getFirst("authtoken"));
		httpHeaders.set("guardtoken", headers.getFirst("guardtoken"));
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		
		String applicationRequestBeanJson = gson.toJson(validateOTP);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp login - validate bfdl otp - started for - " + applicationRequestBeanJson);

		ResponseEntity<ResponseBean> validateBfdlOtpResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, validateBfdlOtpUrl, null, ResponseBean.class, null,
						applicationRequestBeanJson, httpHeaders);

		String userLoginAccountResponseJson = gson.toJson(validateBfdlOtpResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp login - validate bfdl otp - ended for - " + userLoginAccountResponseJson);

		return validateBfdlOtpResponse.getBody();

	}
	
	public ResponseBean getUserApplicantKey(UserKeysBean userApplicant,HttpHeaders headers) throws Exception {
		
		Gson gson = new Gson();

		String applicationRequestBeanJson = gson.toJson(userApplicant);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre register - get userApplciantkey - started for - " + applicationRequestBeanJson);

		ResponseEntity<ResponseBean> responseBean = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, userApplicantUrl, null, ResponseBean.class, null,
						applicationRequestBeanJson, headers);

		String responseJson = gson.toJson(responseBean);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre register - get userApplciantkey - ended for - " + responseJson);

		return responseBean.getBody();
	}

	public ResponseBean saveEmailForApplicantKey(ApplicantEmailBean applicantEmailBean,HttpHeaders headers) throws Exception {
		
		Gson gson = new Gson();

		String applicantEmailBeanJson = gson.toJson(applicantEmailBean);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre register - save email for applicant - started for - " + applicantEmailBean);

		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("applicantKey", String.valueOf(applicantEmailBean.getApplicantKey()));
		
		ResponseEntity<ResponseBean> responseBean = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, saveEmailForApplicantUrl, null, ResponseBean.class, queryParam,
						applicantEmailBeanJson, headers);

		String responseJson = gson.toJson(responseBean);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre register - save email for applicant - ended for - " + responseJson);

		return responseBean.getBody();
	}

	public ResponseBean getEmailForApplicantKey(Long applicantKey,HttpHeaders headers) throws Exception {
		
		Gson gson = new Gson();
		ResponseBean responseBean = new ResponseBean();
				
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("applicantKey", String.valueOf(applicantKey));
		
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp - get email for applicant - started for - " + applicantKey);

		ResponseEntity<ResponseBean> applicantEmailResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.GET, getEmailForApplicantUrl, null, String.class, queryParam,
						null, headers);

		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp - get email for applicant - ended for - " + gson.toJson(applicantEmailResponse));
		
		if (applicantEmailResponse.getStatusCodeValue() == HttpStatus.NOT_FOUND.value() ||
				applicantEmailResponse.getStatusCodeValue() != HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(applicantEmailResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "ntpPreRegister - Applicant Email not found");
				String payload = (String) applicantEmailResponse.getBody().getPayload();
				responseBean = gson.fromJson(payload, ResponseBean.class);
				return responseBean;
			}
		}
		
		responseBean.setPayload(applicantEmailResponse.getBody());
		responseBean.setStatus(StatusCode.SUCCESS);
		return responseBean;
	}

	/**
	 * This api calls autoRegister endpoint which creates entries in
	 * USER_LOGIN_ACCOUNTS for USERLOGINACCTYPE 8(for MPIN) and USER_PROFILES
	 * 
	 * @param mpinUserLoginAcc
	 * @param headers
	 */
	public void createMpinUserLoginAccount(UserLoginAccountRequestV5 mpinUserLoginAcc, HttpHeaders headers) {
		Gson gson = new Gson();
		String mpinUserLoginAccJson = gson.toJson(mpinUserLoginAcc);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre register - create userLoginAccount for loginAccType 8 - started for - "
						+ mpinUserLoginAccJson);
		ResponseEntity<ResponseBean> mpinUserLoginAccountResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, autoRegisterUrl, mpinUserLoginAcc, ResponseBean.class, null, null,
						headers);
		String userLoginAccountResponseJson = gson.toJson(mpinUserLoginAccountResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"ntp pre register - create userLoginAccount for loginAccType 8 - ended for - "
						+ userLoginAccountResponseJson);

	}
	
	public TokenResponse createToken(HttpHeaders headers) {
		TokenResponse tokenResponse=null;
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"inside createToken ");
		URI uri = UriComponentsBuilder.fromUriString(loginPartnerUrl).build().toUri();
		PartnerLoginRequest partnerLoginRequest=new PartnerLoginRequest();
		partnerLoginRequest.setPartnerKey("EXPERIA");
		partnerLoginRequest.setSecretKey("DUMQEFGF");

		JSONObject jsonRequest = new JSONObject(partnerLoginRequest);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(jsonRequest.toString(),headers);
		RestTemplate restClient = getRestTemplate();
		ResponseEntity<String> response = null;
		try {
		response = restClient.exchange(uri.toString(), HttpMethod.POST, requestEntity, String.class);
		}catch(Exception exception)
		{
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception Occured while Creating applicant");
			throw new BFLHttpException(HttpStatus.OK,AuthenticationServiceConstants.AUTH_644,
					env.getProperty(AuthenticationServiceConstants.AUTH_644));
		}
		JSONObject jsonApplicantResponseJsonObject=new JSONObject(response.getBody().toString());
		if(SUCCESS.equalsIgnoreCase(jsonApplicantResponseJsonObject.getString("status")))
		{
			String responseString=jsonApplicantResponseJsonObject.get("payload").toString();
			JSONObject jsonObject=new JSONObject(responseString);
			ObjectMapper objectMapper=MapperFactory.getInstance();
			try {
				tokenResponse=objectMapper.readValue(jsonObject.toString(), TokenResponse.class);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error Occured while Validating User");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR,AuthenticationServiceConstants.AUTH_645,
						env.getProperty(AuthenticationServiceConstants.AUTH_645));
			}
		}
		else if(FAILURE.equalsIgnoreCase(jsonApplicantResponseJsonObject.getString("status")))
		{
			logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error Occured while fetching tokens from Tokens API's");
			throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR,AuthenticationServiceConstants.AUTH_646,
					env.getProperty(AuthenticationServiceConstants.AUTH_646));
		}
		
		return tokenResponse;
		
	}
	
	public String doEncryptAndHash(String salt, String secret, String msg) {

		String encryptedString = encrypt(salt, secret, msg);
		String hash = getMd5(encryptedString);
		return hash;
	}
	
	public String getMd5(String input) {
		String hash = "";
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] messageDigest = md.digest(input.getBytes());
			BigInteger no = new BigInteger(1, messageDigest);
			String hashtext = no.toString(16);
			while (hashtext.length() < 32) {
				hashtext = "0" + hashtext;
			}
			hash = hashtext;
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
		return hash;
	}
	

	public String encrypt(String salt, String secret, String strToEncrypt) {
		String encryptedString = "";
		try {
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			SecretKeyFactory factory = SecretKeyFactory.getInstance(secretKeyAlgo);
			KeySpec spec = new PBEKeySpec(secret.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), algo);
			Cipher cipher = Cipher.getInstance(cipherAlgo);
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
			encryptedString = Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error while encrypting", e);
		}
		return encryptedString;
	}
	
	public RestTemplate getRestTemplate() {
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		requestFactory.setConnectTimeout(15000);
		return new RestTemplate(requestFactory);
	}
}
