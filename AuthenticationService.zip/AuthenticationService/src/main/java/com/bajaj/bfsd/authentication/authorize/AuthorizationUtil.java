package com.bajaj.bfsd.authentication.authorize;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;

@Component
public class AuthorizationUtil {

	private static final String CLASS_NAME = AuthorizationUtil.class.getCanonicalName();

	private static final List<String> CUSTOMER_ROLES = Arrays.asList("pvcustomer", "customer");

	@Autowired
	private Environment env;

	@Autowired
	private BFLLoggerUtil logger;

	@Autowired
	private LoggedInUserDetailsLoader loggedInUserDetailsLoader;

	public void authorizeApplicant(String token, Long applicantKey) {
		try {
			if(StringUtils.isBlank(token)) {
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Invalid Token: "+token);
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH-698", env.getProperty("AUTH-698"));
			}
			LoggedInUser loggedInUser = loggedInUserDetailsLoader.loadUserByUsername(token);
			if (null == loggedInUser) {
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Your session has expired");
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH_669", env.getProperty("AUTH_669"));
			}
			String role = loggedInUser.getRole();
			if (!CUSTOMER_ROLES.contains(role)) {
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
						"your role is not authorized to perform this operation");
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH_670", env.getProperty("AUTH_670"));
			}
			AdditionalInfo additionalInfo = loggedInUser.getAdditionalInfo();
			Long applicantKeyFromToken = null;
			if (null != additionalInfo) {
				applicantKeyFromToken = additionalInfo.getApplicantKey();
			}
			if (null == applicantKeyFromToken) {
				logger.warn(CLASS_NAME, BFLLoggerComponent.UTILITY, "applicant Key not found in the session: "+ additionalInfo);
			}
			if (applicantKey == null || !applicantKey.equals(applicantKeyFromToken)) {
				logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Unauthorized to access input applicant details");
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH_671", env.getProperty("AUTH_671"));
			}
		} catch (BFLHttpException ex) {
			throw ex;
		} catch (Exception ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "token validation failed due to exception: ", ex);
			throw new BFLTechnicalException("AUTH-000", env.getProperty("AUTH-000"));
		}
	}
}
