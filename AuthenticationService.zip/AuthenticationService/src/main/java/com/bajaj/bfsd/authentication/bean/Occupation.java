package com.bajaj.bfsd.authentication.bean;

import java.math.BigDecimal;

public class Occupation {

	private Reference ocupationType;

	private SalariedDetail salariedDetail;

	private BusinessOwnerDetails businessOwnerDetails;
	
	private BigDecimal profitAfterTax;
	
	private BigDecimal averageBankBlance;
	
	private String employerType;	

	public String getEmployerType() {
		return employerType;
	}

	public void setEmployerType(String employerType) {
		this.employerType = employerType;
	}

	public BigDecimal getProfitAfterTax() {
		return profitAfterTax;
	}

	public void setProfitAfterTax(BigDecimal profitAfterTax) {
		this.profitAfterTax = profitAfterTax;
	}

	public BigDecimal getAverageBankBlance() {
		return averageBankBlance;
	}

	public void setAverageBankBlance(BigDecimal averageBankBlance) {
		this.averageBankBlance = averageBankBlance;
	}

	public Reference getOcupationType() {
		return ocupationType;
	}

	public void setOcupationType(Reference ocupationType) {
		this.ocupationType = ocupationType;
	}

	public SalariedDetail getSalariedDetail() {
		return salariedDetail;
	}

	public void setSalariedDetail(SalariedDetail salariedDetail) {
		this.salariedDetail = salariedDetail;
	}

	public BusinessOwnerDetails getBusinessOwnerDetails() {
		return businessOwnerDetails;
	}

	public void setBusinessOwnerDetails(BusinessOwnerDetails businessOwnerDetails) {
		this.businessOwnerDetails = businessOwnerDetails;
	}

	@Override
	public String toString() {
		return "Occupation [ocupationType=" + ocupationType + ", salariedDetail=" + salariedDetail
				+ ", businessOwnerDetails=" + businessOwnerDetails + "]";
	}
}
