package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class NtpLoginRequest implements Serializable {

	private static final long serialVersionUID = -6973378459843607975L;

	private Long applicantKey;
	private String otp;
	private Integer appStatus;// 0
	private String appJourneyStamp;// jounrneyStamp
	
	public Long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Integer getAppStatus() {
		return appStatus;
	}
	public void setAppStatus(Integer appStatus) {
		this.appStatus = appStatus;
	}
	public String getAppJourneyStamp() {
		return appJourneyStamp;
	}
	public void setAppJourneyStamp(String appJourneyStamp) {
		this.appJourneyStamp = appJourneyStamp;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	
}