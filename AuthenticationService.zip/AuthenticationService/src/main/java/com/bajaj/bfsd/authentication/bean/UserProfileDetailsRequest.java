package com.bajaj.bfsd.authentication.bean;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class UserProfileDetailsRequest {
	
	private String mobileNumber;
	private String dateOfBirth;
	private String source;
	private String currentTask;
	@Valid
	@NotNull(message = "AUTH-400")
	private ApplicantKeysRequest userKeys;
	private UserStatusBean userStatus;
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getCurrentTask() {
		return currentTask;
	}
	
	public void setCurrentTask(String currentTask) {
		this.currentTask = currentTask;
	}
	
	public ApplicantKeysRequest getUserKeys() {
		return userKeys;
	}
	
	public void setUserKeys(ApplicantKeysRequest userKeys) {
		this.userKeys = userKeys;
	}
	
	public UserStatusBean getUserStatus() {
		return userStatus;
	}
	
	public void setUserStatus(UserStatusBean userStatus) {
		this.userStatus = userStatus;
	}
	
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
	@Override
	public String toString() {
		return "UserProfileDetailsRequest [mobileNumber=" + mobileNumber + ", dateOfBirth=" + dateOfBirth + ", source="
				+ source + ", currentTask=" + currentTask + ", userKeys=" + userKeys + ", userStatus=" + userStatus
				+ "]";
	}

}
