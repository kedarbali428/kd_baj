package com.bajaj.bfsd.authentication.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.bean.Address;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginRequest;
import com.bajaj.bfsd.authentication.bean.ApplicantDetailBean;
import com.bajaj.bfsd.authentication.bean.ApplicantV2DetailsResponse;
import com.bajaj.bfsd.authentication.bean.DocumentDetails;
import com.bajaj.bfsd.authentication.bean.Email;
import com.bajaj.bfsd.authentication.bean.LocationAddressBean;
import com.bajaj.bfsd.authentication.bean.MobileAppOnBoardingRequest;
import com.bajaj.bfsd.authentication.bean.MobileAppOnBoardingResponse;
import com.bajaj.bfsd.authentication.bean.Occupation;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.PanVerificationResponse;
import com.bajaj.bfsd.authentication.bean.ProspectDetailsResponse;
import com.bajaj.bfsd.authentication.bean.UpdateMobileAppOnBoardingRequest;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UserProfileAttribute;
import com.bajaj.bfsd.authentication.bean.Verification;
import com.bajaj.bfsd.authentication.config.MapperFactory;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.ValidateOTP;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Component
@RefreshScope
public class AppOnBoardingUtils {

	private static final String THIS_CLASS = AppOnBoardingUtils.class.getCanonicalName();

	@Autowired
	private BFLLoggerUtil logger;

	@Autowired
	private Environment env;

	@Value("${api.otp.generate.POST.url}")
	private String otpGenerateUrl;
	
	@Value("${api.offerservice.fetchProspect.POST.url}")
	private String prospectDetailsUrl;

	@Value("${api.otp.validate.POST.url}")
	private String validateBfdlOtpUrl;
	
	@Value("${api.tokenmanagement.generatetoken.POST.url}")
	private String tokenServiceUrl;
		
	@Value("${api.applicant.openMarkets.applicantUpdate.PUT.url}")
	private String applicantUpdateUrl;
	
	@Value("${api.applicant.fetch.applicantDetails.GET.url}")
	private String applicantGetDetailsUrl;
	
	@Value("${api.referencedata.locations.GET.url}")
	private String pincodeGetDetailsUrl;
	
	@Value("${api.applicant.openMarkets.updateApplicantEmail.PUT.url}")
	private String emailUpdateUrl;
	
	@Value("${api.applicant.openMarkets.address.PUT.url}")
	private String addressUpdateUrl;
	
	@Value("${api.applicant.openMarkets.employmentdetails.PUT.url}")
	private String employmentUpdateUrl;
	
	@Value("${api.applicant.openMarkets.pandetails.PUT.url}")
	private String panUpdateUrl;
	
	@Value("${api.applicant.openMarkets.applicant.GET.url}")
	private String getApplicantV2DetailsUrl;
	
	@Value("${api.nsdl.pan.details.GET.url}")
	private String panVerificationStatusUrl;
		
	@Value("${api.applicant.openMarkets.mobileapp.apponboarding.POST.url}")
	private String appOnBoardingSkipFlagCurrentStatus;
	
	@Value("${api.applicant.openMarkets.mobileapp.apponboarding.PUT.url}")
	private String appOnBoardingSkipFlagUpdateStatus;
	
	@Autowired
	private RestClientUtil restClientUtil;
	
	@Autowired
	private TokenCodeHelper tokenCodeHelper;

	public String generateOtp(String mobileNumber, HttpHeaders headers) {
		String otp=null;
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "generateOtp started with mobile Number: " + mobileNumber);
		try {
			ObjectNode jsonRequest = MapperFactory.getInstance().createObjectNode();
			jsonRequest.put("mobile", mobileNumber);
			jsonRequest.put("mfa",true);
			ResponseEntity<ResponseBean> response = restClientUtil.postCall(otpGenerateUrl, jsonRequest,
					headers, ResponseBean.class);
			if (StatusCode.SUCCESS.equals(response.getBody().getStatus())){
				otp=AuthenticationServiceConstants.YES;	
			}else if(StatusCode.FAILURE.name().equals(response.getBody().getStatus().name())){
				otp=AuthenticationServiceConstants.NO;
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "generateOtp ended with otp Status: " + otp);
		}catch(Exception ex){
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception Otp Generation Failure", ex);
			throw new BFLHttpException(HttpStatus.OK, AuthenticationServiceConstants.AUTH_709, env.getProperty(AuthenticationServiceConstants.AUTH_709));
		}
		return otp;
	}
	
	public ProspectDetailsResponse getProspectDetails(String mobileNumber, String dateOfBirth,HttpHeaders headers) {
		ProspectDetailsResponse prospect=null;
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getProspectDetails started with mobile Number: " + mobileNumber);
		try {
			ObjectMapper objectMapper=MapperFactory.getInstance();
			ObjectNode jsonRequest = objectMapper.createObjectNode();
			jsonRequest.put("mobileNumber", mobileNumber);
			jsonRequest.put("dateOfBirth",dateOfBirth);
			ResponseEntity<ResponseBean> response = restClientUtil.postCall(prospectDetailsUrl, jsonRequest,
					headers, ResponseBean.class);
			if(StatusCode.SUCCESS.equals(response.getBody().getStatus())){
				prospect = objectMapper.convertValue(response.getBody().getPayload(), ProspectDetailsResponse.class);
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getProspectDetails ended with response: " + prospect);
		}catch (Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception In Mapping ProspectDetails Response", ex);
		}
		return prospect;
	}
	
	public String validateOtp(AppOnBoardingLoginRequest otpValidationAndCustomerGenReq, HttpHeaders headers) {
		String otpValidateResponse=null;
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "validateOtp started with request: " + otpValidationAndCustomerGenReq.getMobileNumber());
		ValidateOTP validateOTP=new ValidateOTP();
		validateOTP.setMobile(otpValidationAndCustomerGenReq.getMobileNumber());
		validateOTP.setOtp(otpValidationAndCustomerGenReq.getOtp());
		try {
			ResponseEntity<ResponseBean> response = restClientUtil.postCall(validateBfdlOtpUrl, validateOTP,
					headers, ResponseBean.class);
			if(StatusCode.SUCCESS.equals(response.getBody().getStatus())){
				otpValidateResponse=response.getBody().getPayload().toString();
			}else{
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Otp Validation Failed");
			throw new BFLHttpException(HttpStatus.OK, "AUTH-708",env.getProperty(AuthenticationServiceConstants.AUTH_708));
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "validateOtp response: "+ response);
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}
		catch(Exception ex){
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception Otp Validation Failed", ex);
			throw new BFLHttpException(HttpStatus.OK, "AUTH-708",env.getProperty(AuthenticationServiceConstants.AUTH_708));
		}
		return otpValidateResponse;
	}
	
	public TokenResponse generateTokens(String loginId, long userId, short userType, HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "generateTokens started with loginId: " + loginId);
		TokenResponse tokenResponse = tokenCodeHelper.generateTokens(loginId, userId, userType, headers);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "generateTokens ended with loginId: " + loginId);
		return tokenResponse;
	}	
	
	
	public ApplicantDetailBean getApplicantDetails(String applicantKey ,HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getApplicantDetails started with applicantKey: " + applicantKey);
		headers.set("platform", "mob");
		Map<String, String> applicantParam = new HashMap<String, String>();
		applicantParam.put("applicantId", applicantKey);
		ApplicantDetailBean applicantDetailBean = null;
		try {
			ResponseEntity<ResponseBean> response = restClientUtil.getCall(applicantGetDetailsUrl, null, applicantParam,
					headers, ResponseBean.class);
			if(StatusCode.SUCCESS.equals(response.getBody().getStatus())) {
				ObjectMapper objectMapper = MapperFactory.getInstance();
				applicantDetailBean = objectMapper.convertValue(response.getBody().getPayload(), ApplicantDetailBean.class);
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getApplicantDetails ended with response: " + response);
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception In getApplicantDetails API", ex);
			throw new BFLHttpException(HttpStatus.OK, "AUTH_650", env.getProperty("AUTH_650"));
		}
		return applicantDetailBean;
		
	}

	public UserProfileAttribute updateApplicantDetails(UserProfileAttribute applicantBean, UpdateUserProfileDetailsRequest userProfileDetailsPutReq ,HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"updateApplicantDetails started with applicantBean: " + applicantBean);
		try {
			Map<String, String> applicantParams = getUpdateApplicantUriPathParam(userProfileDetailsPutReq);
			ResponseEntity<UserProfileAttribute> applicantDetailBean = restClientUtil.putCall(applicantUpdateUrl, applicantParams, applicantBean,
					headers, UserProfileAttribute.class);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"updateApplicantDetails ended with response: " + applicantDetailBean);
			if(null == applicantDetailBean || !applicantDetailBean.getStatusCode().is2xxSuccessful()){
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error while updating applicant details");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH_651", env.getProperty("AUTH_651"));
			}
			return applicantDetailBean.getBody();
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while updating applicant details", ex);
			throw new BFLTechnicalException("AUTH_651", env.getProperty("AUTH_651"));
		}
	}

	public Email updateEmailDetails(UpdateUserProfileDetailsRequest applicantBean ,HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "updateEmailDetails started with applicantBean: " + applicantBean);
		try {
			Map<String, String> applicantParams = getUpdateApplicantUriPathParam(applicantBean);
			Email email=new Email();
			email.setEmail(applicantBean.getPersonalDetails().getEmail().getUserInput());
			email.setTypeKey(70L);
			ResponseEntity<Email> applicantEmailDetails = restClientUtil.putCall(emailUpdateUrl, applicantParams, email,
					headers, Email.class);
			if(null == applicantEmailDetails || !applicantEmailDetails.getStatusCode().is2xxSuccessful()){
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error while updating applicant email Details");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH_652", env.getProperty("AUTH_652"));
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"updateEmailDetails ended with response:" + applicantEmailDetails);
			return applicantEmailDetails.getBody();
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while updating applicant email Details", ex);
			throw new BFLTechnicalException("AUTH_652", env.getProperty("AUTH_652"));
		}
	}

	public LocationAddressBean getPinCodeDetails(UpdateUserProfileDetailsRequest applicantBean, HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getPinCodeDetails started with applicantBean: " + applicantBean);
		try {
			Map<String, String> pinCodeParam = new HashMap<String, String>();
			pinCodeParam.put("pincode", applicantBean.getPersonalDetails().getPinCode().getUserInput());
			ResponseEntity<LocationAddressBean> locationAddressDetails = restClientUtil.getCall(pincodeGetDetailsUrl, null, pinCodeParam,
					headers, LocationAddressBean.class);
			if (null == locationAddressDetails || !locationAddressDetails.getStatusCode().is2xxSuccessful()){
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error while getting pinCode details");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH_653", env.getProperty("AUTH_653"));	
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"getPinCodeDetails ended with response: " + locationAddressDetails);
			return locationAddressDetails.getBody();
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while updating applicant email Details", ex);
			throw new BFLTechnicalException("AUTH_653", env.getProperty("AUTH_653"));
		}
	}

	public Address updateAddressDetails(UpdateUserProfileDetailsRequest applicantBean, LocationAddressBean locationAddressBean,
			HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "updateAddressDetails started with applicantBean: " + applicantBean);
		try {
			Address addressBean=new Address();
			addressBean.setAddressTypeKey(AuthenticationServiceConstants.ADDRESSTYPE_OTHERS_KEY);
			addressBean.setCityKey(locationAddressBean.getCityId().toString());
			addressBean.setCountryKey(locationAddressBean.getCountryId().toString());
			addressBean.setStateKey(locationAddressBean.getStateId().toString());
			addressBean.setPincode(locationAddressBean.getPinCode());
			addressBean.setPincodeKey(locationAddressBean.getPinId().toString());
			Map<String, String> addressParam = getUpdateApplicantUriPathParam(applicantBean);
			ResponseEntity<Address> addressDetails = restClientUtil.putCall(addressUpdateUrl, addressParam, addressBean,
					headers, Address.class);
	
			if(null == addressDetails || !addressDetails.getStatusCode().is2xxSuccessful()){
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error in updating address details");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH_654", env.getProperty("AUTH_654"));
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"updateAddressDetails ended with response: " + addressDetails);
			return addressDetails.getBody();
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while updating applicant address Details", ex);
			throw new BFLTechnicalException("AUTH_654", env.getProperty("AUTH_654"));
		}
	}
	
	public Occupation updateOccupationDetails(UpdateUserProfileDetailsRequest applicantBean , Occupation occupation, HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "updateOccupationDetails started with request: " + applicantBean);
		try {
			Map<String, String> occupationParam = getUpdateApplicantUriPathParam(applicantBean);
			ResponseEntity<Occupation> occupationDetails = restClientUtil.putCall(employmentUpdateUrl, occupationParam, occupation,
					headers, Occupation.class);
			if(null == occupationDetails || !occupationDetails.getStatusCode().is2xxSuccessful()){
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error in updating occupation details");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH_655", env.getProperty("AUTH_655"));	
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"updateOccupationDetails ended with response: " + occupationDetails);
			return occupationDetails.getBody();
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while updating applicant occupation Details", ex);
			throw new BFLTechnicalException("AUTH_655", env.getProperty("AUTH_655"));
		}
	}
		
	public DocumentDetails updatePanDetails(UpdateUserProfileDetailsRequest applicantBean, Verification verification, HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "updatePanDetails started with request: " + applicantBean);
		try {
			Map<String, String> panParam = getUpdateApplicantUriPathParam(applicantBean);
			DocumentDetails documentDetails=new DocumentDetails();
			documentDetails.setDocumentNameKey(1L);
			documentDetails.setDocumentNumber(applicantBean.getBureauDetails().getPan().getUserInput());
			documentDetails.setVerification(verification);
			
			ResponseEntity<DocumentDetails> panDetailsResponse = restClientUtil.putCall(panUpdateUrl, panParam, documentDetails,
					headers, DocumentDetails.class);
			if( null == panDetailsResponse || !panDetailsResponse.getStatusCode().is2xxSuccessful()){
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error In updating pan details");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH_656", env.getProperty("AUTH_656"));	
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"updatePanDetails ended with response: " + panDetailsResponse);
			return panDetailsResponse.getBody();
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while updating applicant pan details", ex);
			throw new BFLTechnicalException("AUTH_656", env.getProperty("AUTH_656"));
		}

	}
	
	public ApplicantV2DetailsResponse getApplicantDetailsV2WithPanVerification(String applicantKey, HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getApplicantDetailsV2WithPanVerification started for applicantKey: " + applicantKey);
		try {
			ApplicantV2DetailsResponse response = null;
			Map<String, String> pathParam = new HashMap<String, String>();
			pathParam.put("applicantKey", applicantKey);
			ResponseEntity<ApplicantV2DetailsResponse> applicantV2DetailsResponse = restClientUtil.getCall(getApplicantV2DetailsUrl, null, pathParam,
					headers, ApplicantV2DetailsResponse.class);
			if( null == applicantV2DetailsResponse || !applicantV2DetailsResponse.getStatusCode().is2xxSuccessful()){
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error In getting applicant v2 details");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH_657", env.getProperty("AUTH_657"));	
			}
			response = applicantV2DetailsResponse.getBody();
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"getApplicantDetailsV2WithPanVerification ended with response: " + applicantV2DetailsResponse);
			return response;
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while getting applicant pan details", ex);
			throw new BFLTechnicalException("AUTH_657", env.getProperty("AUTH_657"));
		}
	}
	
	private Map<String, String> getUpdateApplicantUriPathParam(UpdateUserProfileDetailsRequest applicantBean) {
		Map<String, String> pathParam = new HashMap<String, String>();
		pathParam.put("applicantKey", applicantBean.getUserKeys().getApplicantKey().toString());
		return pathParam;
	}

	public PanVerificationResponse getApplicantNsdlPanVerificationStatus(PanProfileDetailsRequest panDetailsRequest, HttpHeaders headers) {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"getApplicantNsdlPanVerificationStatus started with request: " + panDetailsRequest);
			Map<String, String> pathParam = new HashMap<>();
			pathParam.put("panno", panDetailsRequest.getPanNumber());
			pathParam.put("applicationId", "0"); 
			pathParam.put("applicantId", panDetailsRequest.getUserKeys().getApplicantKey().toString());
			PanVerificationResponse panDetails = null;
			ResponseEntity<ResponseBean> panVerificationResponse = restClientUtil.getCall(panVerificationStatusUrl, null, pathParam,
					headers, ResponseBean.class);
			if( null == panVerificationResponse || !panVerificationResponse.getStatusCode().is2xxSuccessful()){
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error in getting nsdl pan details");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH_667", env.getProperty("AUTH_667"));	
			}else if(panVerificationResponse.getBody().getStatus().equals(StatusCode.SUCCESS)) {
				ObjectMapper mapper = MapperFactory.getInstance();
				panDetails = mapper.convertValue(panVerificationResponse.getBody().getPayload(), PanVerificationResponse.class);
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"getApplicantNsdlPanVerificationStatus ended with response: " + panVerificationResponse);
			return panDetails;
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while getting nsdl pan details", ex);
			throw new BFLTechnicalException("AUTH_667", env.getProperty("AUTH_667"));
		}
	}
	
	public MobileAppOnBoardingResponse saveApplicantMobAppOnBoardingStatus(MobileAppOnBoardingRequest skipFlagRequest, HttpHeaders headers) {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"saveApplicantMobAppOnBoardingStatus started with request: " + skipFlagRequest);
			MobileAppOnBoardingResponse appOnBoardingSkipResponse = null;
			ResponseEntity<MobileAppOnBoardingResponse> skipFlagResponse = restClientUtil.postCall(appOnBoardingSkipFlagCurrentStatus, skipFlagRequest,
					headers, MobileAppOnBoardingResponse.class);
			if( null == skipFlagResponse || !skipFlagResponse.getStatusCode().is2xxSuccessful()){
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error while saving appOnboarding skip flag");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH_672", env.getProperty("AUTH_672"));	
			}else if(skipFlagResponse.hasBody()) {
				ObjectMapper mapper = MapperFactory.getInstance();
				appOnBoardingSkipResponse = mapper.convertValue(skipFlagResponse.getBody(), MobileAppOnBoardingResponse.class);
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"saveApplicantMobAppOnBoardingStatus ended with response: " + skipFlagResponse);
			return appOnBoardingSkipResponse;
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while saving appOnboarding skip flag details", ex);
			throw new BFLTechnicalException("AUTH_672", env.getProperty("AUTH_672"));
		}
	}
	
	public MobileAppOnBoardingResponse updateApplicantMobAppOnBoardingStatus(UpdateMobileAppOnBoardingRequest updateSkipFlagRequest, HttpHeaders headers) {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"updateApplicantMobAppOnBoardingStatus started with request: " + updateSkipFlagRequest);
			MobileAppOnBoardingResponse appOnBoardingSkipResponse = null;
			ResponseEntity<MobileAppOnBoardingResponse> skipFlagResponse = restClientUtil.putCall(appOnBoardingSkipFlagCurrentStatus, null,  updateSkipFlagRequest,
					headers, MobileAppOnBoardingResponse.class);
			if( null == skipFlagResponse || !skipFlagResponse.getStatusCode().is2xxSuccessful()){
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error while updating appOnboarding skip flag status");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH_673", env.getProperty("AUTH_673"));	
			}else if(skipFlagResponse.hasBody()) {
				ObjectMapper mapper = MapperFactory.getInstance();
				appOnBoardingSkipResponse = mapper.convertValue(skipFlagResponse.getBody(), MobileAppOnBoardingResponse.class);
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
					"updateApplicantMobAppOnBoardingStatus ended with response: " + skipFlagResponse);
			return appOnBoardingSkipResponse;
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while updating appOnboarding skip flag status", ex);
			throw new BFLTechnicalException("AUTH_673", env.getProperty("AUTH_673"));
		}
	}
}
