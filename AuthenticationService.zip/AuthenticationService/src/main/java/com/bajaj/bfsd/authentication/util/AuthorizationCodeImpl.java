package com.bajaj.bfsd.authentication.util;

import java.io.IOException;
import java.security.Key;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeResponse;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLHttpException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
@RefreshScope
public class AuthorizationCodeImpl {

	private static final String THIS_CLASS = AuthorizationCodeImpl.class.getCanonicalName();

	@Value("${federated.authcode.jwtsecret}")
	private String authCodeJwtSecret;

	@Value("${federated.code.cacheprefix}")
	private String cachePrefix;

	@Autowired
	private BFLLoggerUtil logger;

	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	public String createAuthCode(String issuer, String clientId, long expiryInSeconds, String mobile) throws IOException {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
				"generateToken - for federatedRequest entity" + clientId);
		
		byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(authCodeJwtSecret);
		Key signingKey = new SecretKeySpec(apiKeySecretBytes, SignatureAlgorithm.HS256.getJcaName());

		Map<String, Object> claim = new HashMap<>();
		claim.put("nonce", UUID.randomUUID().toString());
		claim.put("mobile", mobile);
		Instant currentInstant =Instant.now();
		
	 
		String authCode = Jwts.builder().setIssuer(issuer)
				.setSubject(clientId).setIssuedAt(Date.from(currentInstant))
				.setAudience(clientId).setClaims(claim)
				.setExpiration(Date.from(currentInstant.plusSeconds(expiryInSeconds)))
				.signWith(SignatureAlgorithm.HS512, signingKey).compact();
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "generateToken - Tokens generated" + authCode);
		return authCode;

	}

	public void cacheAuthCode(String authCode, FederatedAuthorizeResponse federatedAuthorizeResponse, long expiryInSeconds)
			throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		String valueToBeCached = mapper.writeValueAsString(federatedAuthorizeResponse);
		redisTemplate.opsForValue().set(cachePrefix + authCode, valueToBeCached, expiryInSeconds, TimeUnit.SECONDS);
	}

	public FederatedAuthorizeResponse getCacheAuthCode(String authCode)
			throws IOException {
		FederatedAuthorizeResponse federatedAuthorizeResponse = null;
		ObjectMapper mapper = new ObjectMapper();
		String cacheValue = redisTemplate.opsForValue().get(cachePrefix + authCode);
		if (null != cacheValue) {
			redisTemplate.delete(cachePrefix + authCode);
			federatedAuthorizeResponse = mapper.readValue(cacheValue, FederatedAuthorizeResponse.class);
		}
		return federatedAuthorizeResponse;
	}

	public boolean validateAuthCode(String token) {
		boolean status = false;
		try {
			if (null != token && !token.isEmpty()) {
				Jwts.parser()
				.setSigningKey(DatatypeConverter.parseBase64Binary(authCodeJwtSecret))
				.parseClaimsJws(token);
				status = true;
			}
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateAuthCode – token validation failed", e);
			throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH-401",
					"Request Processing Failed –  token validation failed");
		}
		return status;
	}

}