/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Singleton class for ObjectMapper.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	29/12/2016      Initial Version
 */
public class MapperFactory {

    /**
     * Variable to hold value for object mapper.
     */
    private static ObjectMapper objectMapper;
    private static Object lockObject = new Object();

    /**
     * Instantiates a new mapper.
     */
    private MapperFactory() {
    }

    /**
     * Gets the single instance of MapperFactory.
     *
     * @return single instance of MapperFactory
     */
    public static ObjectMapper getInstance() {
        if (objectMapper == null) {
            synchronized (lockObject) {
                if (objectMapper == null) {
                    objectMapper = new ObjectMapper();
                    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                }
            }
        }
        return objectMapper;
    }
}
