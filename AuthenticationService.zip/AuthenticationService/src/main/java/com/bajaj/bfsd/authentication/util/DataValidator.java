package com.bajaj.bfsd.authentication.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.enterprise.context.RequestScoped;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLHttpException;

@Component
public class DataValidator {

	@Autowired
	@RequestScoped
	BFLLoggerUtil logger;
	
	@Autowired 
	private Environment env;
	
	private static final String THIS_CLASS = DataValidator.class.getCanonicalName();
	
	private static Pattern patternMobile;

	private static final String MOBILENUM_PATTERN = "^[6-9][0-9]{9}$";
	
	public DataValidator(){
	}
	
	static {
		patternMobile = Pattern.compile(MOBILENUM_PATTERN);
	}

	public boolean validateMobile(final String mobile) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.PROCESSOR, "validateMobile Started");
		Matcher matcherMobile = patternMobile.matcher(mobile);

		if (matcherMobile.matches())
			return true;

		return false;
	}
	

	public Date validateDateFieldAndReturnDate(String date, String format) {
		Date retVal = null;
		if(null == date){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateDateFieldAndReturnDate - date is null.");
			return retVal;
		}
		
		try{
			SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
			dateFormatter.setLenient(false);
			retVal = dateFormatter.parse(date);
		}
		catch(ParseException ex){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateDateFieldAndReturnDate - date is not in correct format: "+date);
			return retVal;
		}			
		return retVal;
	}	
	
	public Date validateDateFormats(String date, String[] dateFormats, HttpStatus statusCode) {
		Date validatedDate = null;
		if(null != dateFormats) {
			for(String format : dateFormats) {
				validatedDate = parseDateAndReturnValidDate(date, format);
				if(null != validatedDate)
					break;
			}
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateDateForMultipleFormat : "+validatedDate);
		if(null == validatedDate) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "validateDateForMultipleFormat - date is not in any correct format: "+date);
			throw new BFLHttpException(statusCode, AuthenticationServiceConstants.AUTH_643,
					env.getProperty(AuthenticationServiceConstants.AUTH_643));
		}
		return validatedDate;
	}
	
	public Date parseDateAndReturnValidDate(String date, String format) {
		Date retVal = null;
		if(StringUtils.isBlank(date)){
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "validateDateFieldAndReturnValidDate - date is invalid.");
			return retVal;
		}
		try{
			DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(format).withResolverStyle(ResolverStyle.STRICT);
			LocalDate parsedDate = LocalDate.parse(date, dateFormatter);
			retVal = java.sql.Date.valueOf(parsedDate);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "validateDateFieldAndReturnValidDate - date "+retVal);
		}catch(DateTimeException ex){
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "validateDateFieldAndReturnValidDate - date is not in correct format: "+date);
			return retVal;
		}			
		return retVal;
	}
}