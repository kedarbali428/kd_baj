package com.bajaj.bfsd.authentication.bean;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class UpdateUserProfileDetailsRequest  {

	private String mobileNumber;
	private String dateOfBirth;
	private String currentTask;
	
	@NotBlank(message = "source cannot be blank or null")
	private String source;
	
	@Valid
	@NotNull(message = "AUTH-400")
	private ApplicantKeysRequest userKeys;
	private UserStatusBean userStatus;
	private BureauDetails bureauDetails;
	private PersonalDetails personalDetails;
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getCurrentTask() {
		return currentTask;
	}
	
	public void setCurrentTask(String currentTask) {
		this.currentTask = currentTask;
	}
	
	public ApplicantKeysRequest getUserKeys() {
		return userKeys;
	}
	
	public void setUserKeys(ApplicantKeysRequest userKeys) {
		this.userKeys = userKeys;
	}
	
	public UserStatusBean getUserStatus() {
		return userStatus;
	}
	
	public void setUserStatus(UserStatusBean userStatus) {
		this.userStatus = userStatus;
	}
	
	public BureauDetails getBureauDetails() {
		return bureauDetails;
	}
	
	public void setBureauDetails(BureauDetails bureauDetails) {
		this.bureauDetails = bureauDetails;
	}
	
	public PersonalDetails getPersonalDetails() {
		return personalDetails;
	}
	
	public void setPersonalDetails(PersonalDetails personalDetails) {
		this.personalDetails = personalDetails;
	}
	
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
	@Override
	public String toString() {
		return "UpdateUserProfileDetailsRequest [mobileNumber=" + mobileNumber + ", dateOfBirth=" + dateOfBirth
				+ ", currentTask=" + currentTask + ", source=" + source + ", userKeys=" + userKeys + ", userStatus="
				+ userStatus + ", bureauDetails=" + bureauDetails + ", personalDetails=" + personalDetails + "]";
	}

}
