package com.bajaj.bfsd.authentication.service;

import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;

public interface OMAuthenticationService {

	public TokenResponse authenticateMobDobAndGenerateToken(MobileLoginRequest mobileLoginRequest);
}
