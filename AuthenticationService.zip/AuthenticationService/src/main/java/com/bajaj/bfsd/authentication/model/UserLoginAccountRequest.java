package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

public class UserLoginAccountRequest implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7138102437042992933L;
	private String loginId;
	private String password;
	private String source;
	private String loginType;
	private String dateOfBirth;
	
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
}
