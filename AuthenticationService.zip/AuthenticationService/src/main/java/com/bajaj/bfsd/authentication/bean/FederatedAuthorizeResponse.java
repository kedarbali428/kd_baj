package com.bajaj.bfsd.authentication.bean;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FederatedAuthorizeResponse {

	private String tokenCode;
	
	private String authorizedClient;
	
	private String mobile;
	
	private String partnerCode;
	
	private String customerFlag;
	
	private String partnerCustomerId;
	
	private boolean assistanceMode;

	private String authorizedEmployeeCode;

	public String getTokenCode() {
		return tokenCode;
	}

	public void setTokenCode(String tokenCode) {
		this.tokenCode = tokenCode;
	}

	public String getAuthorizedClient() {
		return authorizedClient;
	}

	public void setAuthorizedClient(String authorizedClient) {
		this.authorizedClient = authorizedClient;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	public String getCustomerFlag() {
		return customerFlag;
	}

	public void setCustomerFlag(String customerFlag) {
		this.customerFlag = customerFlag;
	}

	public String getPartnerCustomerId() {
		return partnerCustomerId;
	}

	public void setPartnerCustomerId(String partnerCustomerId) {
		this.partnerCustomerId = partnerCustomerId;
	}

	public boolean isAssistanceMode() {
		return assistanceMode;
	}

	public void setAssistanceMode(boolean assistanceMode) {
		this.assistanceMode = assistanceMode;
	}

	public String getAuthorizedEmployeeCode() {
		return authorizedEmployeeCode;
	}

	public void setAuthorizedEmployeeCode(String authorizedEmployeeCode) {
		this.authorizedEmployeeCode = authorizedEmployeeCode;
	}

	@Override
	public String toString() {
		return "FederatedAuthorizeResponse [tokenCode=" + tokenCode + ", authorizedClient=" + authorizedClient
				+ ", mobile=" + mobile + ", partnerCode=" + partnerCode + ", customerFlag=" + customerFlag
				+ ", partnerCustomerId=" + partnerCustomerId + ", assistanceMode=" + assistanceMode
				+ ", authorizedEmployeeCode=" + authorizedEmployeeCode + "]";
	}
}