package com.bajaj.bfsd.authentication.util;

import java.io.IOException;
import java.net.URI;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.bajaj.bfsd.authentication.config.MapperFactory;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class RestClientUtil {

	private static final String THIS_CLASS = RestClientUtil.class.getCanonicalName();
  
	@Autowired
	private BFLLoggerUtil logger;
	
	@Autowired
	private Environment env;
	
	@Autowired 
	private RestTemplate restTemplate;
		
	public <T> ResponseEntity<T> postCall(String url, Object requestBody, MultiValueMap<String, String> headers, 
			Class<T> responseType) {
		ObjectMapper mapper = MapperFactory.getInstance();
		ResponseEntity<T> responseEntity = null;
		try {
			URI uri = makeUrl(url, null, null);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "postCall request url: "+uri.toString());
 			HttpEntity<Object> requestEntity = makeRequestEntity(requestBody, headers, mapper);
 			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "postCall request Entity: "+requestEntity);
			responseEntity = restTemplate.exchange(uri.toString(), HttpMethod.POST, requestEntity, responseType);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "postCall response Entity: " + responseEntity);
		}catch(IOException ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "postCall IO exception occured", ex);
			throw new BFLTechnicalException("AUTH-010", env.getProperty("AUTH-010"));
		}catch(RestClientException ex) {
			throw ex;
		}catch(Exception ex) {
			throw ex;
		}
		return responseEntity;
	}
	
	public <T> ResponseEntity<T> getCall(String url, MultiValueMap<String, String> queryParams, Map<String, String> pathVariable,
		MultiValueMap<String, String> headers, Class<T> responseType) {
		ObjectMapper mapper = MapperFactory.getInstance();
		ResponseEntity<T> responseEntity = null;
		try {
			URI uri = makeUrl(url, queryParams, pathVariable);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getCall request url: "+uri.toString());
			HttpEntity<Object> requestEntity = makeRequestEntity(null, headers, mapper);
 			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getCall request Entity: "+requestEntity);
			responseEntity = restTemplate.exchange(uri.toString(), HttpMethod.GET, requestEntity, responseType);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "getCall response Entity: " + responseEntity);
		}catch(IOException ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "getCall IO exception occured", ex);
			throw new BFLTechnicalException("AUTH-010", env.getProperty("AUTH-010"));
		}catch(RestClientException ex) {
			throw ex;
		}catch(Exception ex) {
			throw ex;
		}
		return responseEntity;
	}
	
	public <T> ResponseEntity<T> putCall(String url, Map<String, String> pathVariable, Object requestBody, MultiValueMap<String, String> headers,
			Class<T> responseType) {
		ObjectMapper mapper = MapperFactory.getInstance();
		ResponseEntity<T> responseEntity = null;
		try {
			URI uri = makeUrl(url, null, pathVariable);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "putCall request url: "+uri.toString());
			HttpEntity<Object> requestEntity = makeRequestEntity(requestBody, headers, mapper);
 			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "putCall request Entity: "+requestEntity);
			responseEntity = restTemplate.exchange(uri.toString(), HttpMethod.PUT, requestEntity, responseType);
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "putCall response Entity: " + responseEntity);
		}catch(IOException ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "putCall IO exception occured", ex);
			throw new BFLTechnicalException("AUTH-010", env.getProperty("AUTH-010"));
		}catch(RestClientException ex) {
			throw ex;
		}catch(Exception ex) {
			throw ex;
		}
		return responseEntity;
	}
	
	private HttpEntity<Object> makeRequestEntity(Object requestBody, MultiValueMap<String, String> headers, ObjectMapper mapper) 
			throws IOException {
		HttpEntity<Object> httpEntity = null;
		if(null != headers && null != requestBody) {
			httpEntity = new HttpEntity<>(mapper.writeValueAsString(requestBody), headers);	
		}else if(null != headers) {
			httpEntity = new HttpEntity<>(headers);	
		}else {
			httpEntity = new HttpEntity<>(mapper.writeValueAsString(requestBody));	
		}
		return httpEntity;
	}
	
	private URI makeUrl(String url, MultiValueMap<String, String> queryParams, Map<String, String> pathVariable) {
		UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromUriString(url);
		UriComponents uriComponents = null;
		if(null != queryParams && !queryParams.isEmpty()){
			for(String query: queryParams.keySet()) {
				uriComponentsBuilder = uriComponentsBuilder.replaceQueryParam(query, queryParams.get(query).get(0));
			}
		}
		if(null != pathVariable && !pathVariable.isEmpty()) {
			uriComponents = uriComponentsBuilder.build().expand(pathVariable);
		} else {
			uriComponents = uriComponentsBuilder.build();
		}
		if(null == uriComponents) {
			uriComponents = UriComponentsBuilder.fromUriString(url).build();
		}
		URI uri = uriComponents.toUri();
		return uri;	
	}

}
