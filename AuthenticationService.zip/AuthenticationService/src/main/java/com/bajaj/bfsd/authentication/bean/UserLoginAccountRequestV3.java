package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class UserLoginAccountRequestV3 implements Serializable {
	
	private static final long serialVersionUID = 1L;
	//Here login Id will be mobile number only
	private String mobileNumber;
	private String dateOfBirth;
	
	
	
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	
	

}
