package com.bajaj.bfsd.authentication.bean;

import java.util.List;

public class UserConfigurationBean {

	boolean statusIfExist;

	private String password;
	private String emailId;
	private String firstName;
	private String lastName;
	private String designation;
	private long userKey;
	private List<User> userADList;
	private Boolean isUserExist;

	public long getUserKey() {
		return userKey;
	}

	public void setUserKey(long userKey) {
		this.userKey = userKey;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public boolean isStatusIfExist() {
		return statusIfExist;
	}

	public void setStatusIfExist(boolean statusIfExist) {
		this.statusIfExist = statusIfExist;
	}

	public List<User> getUserADList() {
		return userADList;
	}

	public void setUserADList(List<User> userADList) {
		this.userADList = userADList;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getIsUserExist() {
		return isUserExist;
	}

	public void setIsUserExist(Boolean isUserExist) {
		this.isUserExist = isUserExist;
	}

}
