package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class NtpPreRegisterRes implements Serializable {

	private static final long serialVersionUID = 7971309369088628356L;

	private Long applicantKey;
	private Long userKey;
	private Long userApplicantKey;
	private String firstName;
	private String lastName;
	private String mobileNumber;
	private String dateOfBirth;
	private String customerReferenceID;
	private String customerType;

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getUserKey() {
		return userKey;
	}

	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}

	public Long getUserApplicantKey() {
		return userApplicantKey;
	}

	public void setUserApplicantKey(Long userApplicantKey) {
		this.userApplicantKey = userApplicantKey;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getCustomerReferenceID() {
		return customerReferenceID;
	}

	public void setCustomerReferenceID(String customerReferenceID) {
		this.customerReferenceID = customerReferenceID;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	@Override
	public String toString() {
		return "NtpPreRegisterResponse [applicantKey=" + applicantKey + ", userKey=" + userKey + ", userApplicantKey=" + userApplicantKey + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", mobileNumber=" + mobileNumber + ", dateOfBirth=" + dateOfBirth + ", customerReferenceID=" + customerReferenceID + ", customerType=" + customerType + "]";
	}

}
