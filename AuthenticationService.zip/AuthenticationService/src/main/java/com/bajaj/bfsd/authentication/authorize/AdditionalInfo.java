package com.bajaj.bfsd.authentication.authorize;

import java.util.Map;

public class AdditionalInfo  {

	private Long userKey;
	private Long applicationKey;
	private Long applicantKey;
	private Long userRoleKey;
	private Map<String, Object> resourceMap;

	public AdditionalInfo() {
	}

	public Long getUserKey() {
		return userKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public Long getUserRoleKey() {
		return userRoleKey;
	}

	public Map<String, Object> getResourceMap() {
		return resourceMap;
	}

	@Override
	public String toString() {
		return "AdditionalInfo [userKey=" + userKey + ", applicationKey=" + applicationKey + ", applicantKey="
				+ applicantKey + ", userRoleKey=" + userRoleKey + ", resourceMap=" + resourceMap + "]";
	}

}