package com.bajaj.bfsd.authentication.request.validator;

import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.CUSTOMER_PORTAL;
import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.DOB_YYYY_MM_DD_FORMAT;
import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.JOURNEY;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.util.DataValidator;
import com.bajaj.bfsd.common.domain.ErrorBean;

@Component
public class RequestValidator {
	
	@Autowired
	DataValidator dataValidator;
	
	public ErrorBean validateRequest(MobileLoginRequest mobileLoginRequest) {
		ErrorBean errorBean = null;
		String source = mobileLoginRequest.getSource();
		
		if(!dataValidator.validateMobile(mobileLoginRequest.getMobile())) {
			errorBean = new ErrorBean("AUTH-441", "Mobile number is not in correct format");
			return errorBean;
		}
		
		if(null != mobileLoginRequest.getDateOfBirth() && !mobileLoginRequest.getDateOfBirth().isEmpty()
				&& null == dataValidator.validateDateFieldAndReturnDate(mobileLoginRequest.getDateOfBirth(),
						DOB_YYYY_MM_DD_FORMAT)) {
			errorBean = new ErrorBean("AUTH-442", "DateOfBirth is not in correct format");
			return errorBean;
		}
		
		switch (source) {
		case JOURNEY:
			if(null == mobileLoginRequest.getApplicationKey() || 0l == mobileLoginRequest.getApplicationKey()) {
				errorBean = new ErrorBean("AUTH-443", "ApplicationKey must not be null");
			}
			break;

		case CUSTOMER_PORTAL:
			if(null == mobileLoginRequest.getOtp() || !mobileLoginRequest.getOtp().isEmpty()) {
				errorBean = new ErrorBean("AUTH-444", "OTP must not be null");
			}
			break;
			
		default:
			errorBean = new ErrorBean("AUTH-445", "source is not valid");
			break;
		}
		
		return errorBean;
	}
}
