package com.bajaj.bfsd.authentication.bean;

import java.util.List;

import com.bajaj.bfsd.authentication.model.Tokens;

public class AppOnBoardingLoginResponse {

	private String mobileNumber;
	private String dateOfBirth;
    private UserStatusBean userStatus;
	private String nextTaskKey;
	private UserKeysBean userKeys;
	private List<Tokens> tokens;
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public UserStatusBean getUserStatus() {
		return userStatus;
	}
	
	public void setUserStatus(UserStatusBean userStatus) {
		this.userStatus = userStatus;
	}
	
	public String getNextTaskKey() {
		return nextTaskKey;
	}
	
	public void setNextTaskKey(String nextTaskKey) {
		this.nextTaskKey = nextTaskKey;
	}
	
	public UserKeysBean getUserKeys() {
		return userKeys;
	}
	
	public void setUserKeys(UserKeysBean userKeys) {
		this.userKeys = userKeys;
	}
	
	public List<Tokens> getTokens() {
		return tokens;
	}
	
	public void setTokens(List<Tokens> tokens) {
		this.tokens = tokens;
	}

	@Override
	public String toString() {
		return "AppOnBoardingLoginResponse [mobileNumber=" + mobileNumber + ", dateOfBirth=" + dateOfBirth
				+ ", userStatus=" + userStatus + ", nextTaskKey=" + nextTaskKey + ", userKeys=" + userKeys + ", tokens="
				+ tokens + "]";
	}
	
}
