package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ApplicantCreateRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private NameVerificationDetails name;
	private MobileVerificationDet mobileNumber;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private String dateOfBirth;
	
	public NameVerificationDetails getName() {
		return name;
	}
	public void setName(NameVerificationDetails name) {
		this.name = name;
	}
	public MobileVerificationDet getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(MobileVerificationDet mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
}
