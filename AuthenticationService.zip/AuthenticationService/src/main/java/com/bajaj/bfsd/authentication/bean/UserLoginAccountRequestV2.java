package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

//
public class UserLoginAccountRequestV2 implements Serializable{

	private static final long serialVersionUID = 1L;
	//Here login Id will be mobile number only
	private String loginId;
	private String password;
	private String source;
	private String loginType;
	private String dateOfBirth;
	private String rtype; //[1,2]
	
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getRtype() {
		return rtype;
	}
	public void setRtype(String rtype) {
		this.rtype = rtype;
	}
	
	
	
}
