package com.bajaj.bfsd.authentication.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;

import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeRequest;
import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeResponse;
import com.bajaj.bfsd.authentication.bean.FederatedLoginRequest;
import com.bajaj.bfsd.authentication.bean.FederatedLoginResponse;
import com.bajaj.bfsd.authentication.bean.FederatedTokenRequest;
import com.bajaj.bfsd.authentication.bean.FederatedTokenResponse;
import com.bajaj.bfsd.authentication.bean.FederatedUserRegisterRequest;
import com.bajaj.bfsd.authentication.bean.FederatedUserRegisterResponse;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterResponse;
import com.bajaj.bfsd.authentication.constants.AuthenticateServiceConstants;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.RegisteredClients;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.repository.RegisteredClientsRepository;
import com.bajaj.bfsd.authentication.service.AuthenticationService;
import com.bajaj.bfsd.authentication.service.FederatedAuthService;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.AuthorizationCodeImpl;
import com.bajaj.bfsd.authentication.util.DataValidator;
import com.bajaj.bfsd.authentication.util.PasswordEncoderUtils;
import com.bajaj.bfsd.authentication.util.TokenCodeHelper;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLHttpException;

@Service
@RefreshScope
public class FederatedAuthServiceImpl implements FederatedAuthService {
	
	private static final String THIS_CLASS = FederatedAuthServiceImpl.class.getCanonicalName();

	@Value("${federated.loginauthcode.expiryInSeconds}")
	private Long loginAuthCodeExpiryInSeconds;
	
	@Value("${federated.tokencode.expiryInSeconds}")
	private Long tokenCodeExpiryInSeconds;
		
	@Autowired
	private Environment env;

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private RegisteredClientsRepository registeredClientsRepository;

	@Autowired
	private AuthorizationCodeImpl authCodeImpl;
	
	@Autowired 
	private DataValidator datavalidator;

	@Autowired
	private TokenCodeHelper tokenCodeHelper;
	
	@Autowired
	private AuthenticationService authenticationService;

	@Override
	public FederatedLoginResponse clientValidation(FederatedLoginRequest federatedLoginRequest) {
		FederatedLoginResponse federatedLoginResponse = null;
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside clientValidation");
		try {
			RegisteredClients registeredClients = registeredClientsRepository
					.findByClientidAndClientstatus(federatedLoginRequest.getClientId(), AuthenticateServiceConstants.ISACTIVE);
			
			if (null != registeredClients) {
				if(BooleanUtils.toBoolean(registeredClients.getAssistancemode()) &&
						StringUtils.isBlank(federatedLoginRequest.getAuthorizedEmployeeCode())) {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "EmployeeCode/UserId Not provided when in assistance mode");
					throw new BFLHttpException(HttpStatus.BAD_REQUEST, "AUTH-800", env.getProperty("AUTH-800"));
				} else if(federatedLoginRequest.getCustomerFlag() == 1 &&
						null == federatedLoginRequest.getPartnerCustomerId()  ){
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Customer Id Not provided for ETB customer");
					throw new BFLHttpException(HttpStatus.BAD_REQUEST, "AUTH-801", env.getProperty("AUTH-801"));
				} else {
					String encodedPassword = registeredClients.getClientsecret();
					if (PasswordEncoderUtils.matches(federatedLoginRequest.getClientSecret(), encodedPassword)) {
						String authCode = authCodeImpl.createAuthCode( AuthenticationServiceConstants.FEDERATED_TOKEN_LOGIN_ISSUER,
								federatedLoginRequest.getClientId(), loginAuthCodeExpiryInSeconds, federatedLoginRequest.getMobile());
						federatedLoginResponse = new FederatedLoginResponse();
						federatedLoginResponse.setAuthorizationCode(authCode);
						FederatedAuthorizeResponse federatedAuthorizeResponse = new FederatedAuthorizeResponse();
						federatedAuthorizeResponse.setAuthorizedClient(federatedLoginRequest.getAuthorizedClient());
						federatedAuthorizeResponse.setMobile(String.valueOf(federatedLoginRequest.getMobile()));
						federatedAuthorizeResponse.setCustomerFlag(String.valueOf(federatedLoginRequest.getCustomerFlag()));
						federatedAuthorizeResponse.setPartnerCode(registeredClients.getPartnercode());
						federatedAuthorizeResponse
								.setPartnerCustomerId(String.valueOf(federatedLoginRequest.getPartnerCustomerId()));
						federatedAuthorizeResponse.setAssistanceMode(BooleanUtils.toBoolean(registeredClients.getAssistancemode()));
						federatedAuthorizeResponse.setAuthorizedEmployeeCode(federatedLoginRequest.getAuthorizedEmployeeCode());
						authCodeImpl.cacheAuthCode(authCode, federatedAuthorizeResponse, loginAuthCodeExpiryInSeconds);
					} else {
						logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Invalid client_id or client_secret");
						throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH-401",
								"Authentication Failed – Invalid client_id or client_secret");
					}
				}
			}else {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "No Active Registered Client found for Client Id: "+ federatedLoginRequest.getClientId());
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH-401",
						"Authentication Failed – No Active Registered Client found for client Id");
			}
		}catch(BFLHttpException e) {
			throw e;
		}catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Request Processing Failed – Unknown system issue", e);
			throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH-000",
					env.getProperty("AUTH-000"));
		}
		return federatedLoginResponse;
	}

	@Override
	public FederatedAuthorizeResponse validateAuthorization(FederatedAuthorizeRequest federatedAuthorizeRequest) {
		FederatedAuthorizeResponse federatedAuthorizeResponse = null;
		try {
			if (validateAuthCode(federatedAuthorizeRequest.getAuthorizationCode()))  {
				federatedAuthorizeResponse = getCachedAuthCode(federatedAuthorizeRequest.getAuthorizationCode());
				if (null != federatedAuthorizeResponse) {
					String newAuthCode = authCodeImpl.createAuthCode(AuthenticationServiceConstants.FEDERATED_TOKEN_AUTHORIZE_ISSUER,
							federatedAuthorizeRequest.getClientId(), tokenCodeExpiryInSeconds, federatedAuthorizeResponse.getMobile());
					federatedAuthorizeResponse.setTokenCode(newAuthCode);
					authCodeImpl.cacheAuthCode(newAuthCode, federatedAuthorizeResponse, tokenCodeExpiryInSeconds);
				}else {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Failed to fetch authorized Code from cache" + federatedAuthorizeRequest.getAuthorizationCode());
					throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH-401",
							"Authorization code already consumed");
				}
			} else {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"Authorization code expired or invalid");
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH-401",
						"Authorization code expired or invalid");
			}
		}catch(BFLHttpException e) {
			throw e;
		}catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Request Processing Failed – Unknown system issue", e);
			throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH-000",
					env.getProperty("AUTH-000"));
		}
		return federatedAuthorizeResponse;
	}

	@Override
	public boolean validateAuthCode(String authCode) {
		return authCodeImpl.validateAuthCode(authCode) ;
	}
	
	@Override
	public FederatedAuthorizeResponse getCachedAuthCode(String authorizedCode){
		try {
			return authCodeImpl.getCacheAuthCode(authorizedCode);
		} catch (IOException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "getCachedAuthCode – Failed to get Cached Auth Code", e);
			throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH-802",
					env.getProperty("AUTH-802"));
		}
	}
	
	@Override
	public FederatedTokenResponse generateTokens(FederatedTokenRequest tokenRequest, String cmptCorrelationId) {
		try {
			if( validateAuthCode(tokenRequest.getTokenCode()) ) {
				FederatedAuthorizeResponse cachedAuthCode = getCachedAuthCode(tokenRequest.getTokenCode());
				Date validatedDate = datavalidator.validateDateFieldAndReturnDate(tokenRequest.getDateOfBirth(),
						AuthenticationServiceConstants.DOB_YYYY_MM_DD_FORMAT);
				if(null != cachedAuthCode && null != validatedDate) {
					MobileLoginRequest mobileLoginRequest = new MobileLoginRequest();
					mobileLoginRequest.setDateOfBirth(tokenRequest.getDateOfBirth());
					mobileLoginRequest.setMobile(cachedAuthCode.getMobile());
	
					HttpHeaders headers = new HttpHeaders();
					headers.setContentType(MediaType.APPLICATION_JSON);
					headers.add("cmptcorrid", cmptCorrelationId);
					if(tokenRequest.isRefreshTokenRequired()) {
						headers.add("platform", "mob");
					}
					short userType = AuthenticationServiceConstants.USERTYPE_PSEUDO_VERIFIED_CUSTOMER;
					if(tokenRequest.isCustomerUserType()) {
						userType = AuthenticationServiceConstants.USERTYPE_CUSTOMER;
					}
					TokenResponse tokenCodes = tokenCodeHelper.generateTokens(mobileLoginRequest, 
							headers, userType);
					return mapTokens(tokenCodes);
				}else {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "generateFederatedTokenCodes – Failed to get Cached Auth Code");
					throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH-802",
							env.getProperty("AUTH-802"));
				}
			}else {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "generateFederatedTokenCodes – Token Code is not valid");
				throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH-401",
						env.getProperty("AUTH-401"));
			}
		}catch(BFLHttpException ex ) {
			throw ex;
		}catch(Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "generateFederatedTokenCodes – Failed to generate Token Code", e);
			throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH-803",
					env.getProperty("AUTH-803"));

		}
	}
	
	private FederatedTokenResponse mapTokens(TokenResponse tokenResponse) {
		FederatedTokenResponse federatedTokenResponse = new FederatedTokenResponse();
		List<Tokens> tokens = tokenResponse.getTokens();
		for(Tokens token: tokens) {
			if( StringUtils.equalsIgnoreCase(token.getType(), 
					AuthenticationServiceConstants.AUTH_TOKEN) ) {
				federatedTokenResponse.setCustomerAuthToken(token.getToken());
			}else if(StringUtils.equalsIgnoreCase(token.getType(), 
					AuthenticationServiceConstants.REFRESH_TOKEN) ) {
				federatedTokenResponse.setRefreshToken(token.getToken());
				federatedTokenResponse.setGuardKey(token.getGuardKey());
			}
		}
		return federatedTokenResponse;
	}
	
	@Override
	public FederatedUserRegisterResponse registerUser(FederatedUserRegisterRequest registerRequest, HttpHeaders headers) {
		try {
			FederatedUserRegisterResponse registerResponse = null;
			FederatedAuthorizeRequest authorizeRequest = new FederatedAuthorizeRequest();
			authorizeRequest.setAuthorizationCode(registerRequest.getAuthorizationCode());
			authorizeRequest.setClientId(registerRequest.getClientId());
			FederatedAuthorizeResponse authorizedResponse = validateAuthorization(authorizeRequest);
			NtpPreRegisterRequest ntpPreRegisterRequest = registerRequest.getPreRegisterRequest();
			boolean isValidRegisterRequest = validateRegisterRequest(authorizedResponse, ntpPreRegisterRequest);
			if(isValidRegisterRequest) {
				ntpPreRegisterRequest = populateCustomerDetails(authorizedResponse, ntpPreRegisterRequest);
				ResponseEntity<ResponseBean> responseEntity = authenticationService.
						ntpPreRegister(ntpPreRegisterRequest, null, null, headers);
				NtpPreRegisterResponse ntpPreRegistrationResponse = validateNtpRegistrationResponse(responseEntity);
				FederatedTokenRequest generateSdkTokenRequest = populateTokenRequest(authorizedResponse,
						ntpPreRegistrationResponse);
				FederatedTokenResponse federatedTokenResponse = generateTokens(generateSdkTokenRequest, 
						headers.getFirst("cmptcorrid"));
				registerResponse = mapUserRegisterResponse(federatedTokenResponse, ntpPreRegistrationResponse);
			}else{
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "registerUser – Failed to register User");
				throw new BFLHttpException(HttpStatus.FORBIDDEN, "AUTH-804",
						env.getProperty("AUTH-804"));
			}
			return registerResponse;
		}catch(BFLHttpException e) {
			throw e;
		}catch(Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Some Exception occured: ", e);
			throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH-000",
					env.getProperty("AUTH-000"));
		}
	}

	private boolean validateRegisterRequest(FederatedAuthorizeResponse authorizedResponse,
			NtpPreRegisterRequest preRegisterRequest) {
		boolean isValid = false;
		if(StringUtils.isBlank(preRegisterRequest.getMobileNumber())) {
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, "AUTH-006", env.getProperty("AUTH-006"));
		}
		if(StringUtils.isBlank(preRegisterRequest.getDateOfBirth())) {
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, "AUTH-707", env.getProperty("AUTH-707"));
		}
		if( StringUtils.equals(authorizedResponse.getMobile(), preRegisterRequest.getMobileNumber()) ){
			String preRegisterRequestCustomerId = preRegisterRequest.getCustomerReferenceID();
			isValid = true;
			if( StringUtils.isNotBlank(preRegisterRequestCustomerId) ) {
				isValid = StringUtils.equals(preRegisterRequestCustomerId, 
						authorizedResponse.getPartnerCustomerId());
			}
		}
		return isValid;
	}
	
	private NtpPreRegisterResponse validateNtpRegistrationResponse(ResponseEntity<ResponseBean> ntpRegisterationResponse) {
		try {
			NtpPreRegisterResponse ntpPreRegisterResponse = null;
			if(null != ntpRegisterationResponse && ntpRegisterationResponse.hasBody()) {
				ResponseBean responseBean = ntpRegisterationResponse.getBody();
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateNtpRegistrationResponse :: response from ntpPreRegister:" + responseBean);
				if(HttpStatus.OK == ntpRegisterationResponse.getStatusCode() && 
						null != responseBean.getPayload() && 
						responseBean.getStatus().name().equalsIgnoreCase(StatusCode.SUCCESS.name())){
					ntpPreRegisterResponse = (NtpPreRegisterResponse)responseBean.getPayload();
				}else if( ( null != responseBean.getErrorBean()) && !responseBean.getErrorBean().isEmpty()){
					List<FieldError> ntpRegisterResponseErrors = getFieldErrorsFromErrorBeans(responseBean.getErrorBean());
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateNtpRegistrationResponse :: errors from ntpPreRegister:" + ntpRegisterResponseErrors);
					throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, ntpRegisterResponseErrors);
				}	
			}
			return ntpPreRegisterResponse;
		}catch(BFLHttpException ex) {
			throw ex;
		}catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Some Exception occured: ", e);
			throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH-401",
					env.getProperty("AUTH-401"));
		}
	}
	
	private List<FieldError> getFieldErrorsFromErrorBeans(List<ErrorBean> errorBeans) {
		List<FieldError> fieldErrors = new ArrayList<>();
		for(ErrorBean error: errorBeans) {
			FieldError fieldError = new FieldError(null, error.getErrorCode(), error.getErrorMessage());
			fieldErrors.add(fieldError);
		}
		return fieldErrors;
	}

		
	private NtpPreRegisterRequest populateCustomerDetails(FederatedAuthorizeResponse authorizedResponse,
			NtpPreRegisterRequest ntpPreRegistrationRequest) {
		if(authorizedResponse.getCustomerFlag().equals(AuthenticationServiceConstants.EXISTING_CUSTOMER)) {
			ntpPreRegistrationRequest.setCustomerType(AuthenticationServiceConstants.ETB);
			ntpPreRegistrationRequest.setCustomerReferenceID(authorizedResponse.getPartnerCustomerId());
		}else {
			ntpPreRegistrationRequest.setCustomerType(AuthenticationServiceConstants.NTB);
		}
		return ntpPreRegistrationRequest;
	}
	
	private FederatedTokenRequest populateTokenRequest(FederatedAuthorizeResponse authorizedResponse, NtpPreRegisterResponse ntpPreRegistrationResponse) {
		FederatedTokenRequest tokenSdkRequest = new FederatedTokenRequest();
		tokenSdkRequest.setTokenCode(authorizedResponse.getTokenCode());
		tokenSdkRequest.setDateOfBirth(ntpPreRegistrationResponse.getDateOfBirth());
		tokenSdkRequest.setCustomerUserType(true);
		tokenSdkRequest.setRefreshTokenRequired(false);
		return tokenSdkRequest;
	}

	private FederatedUserRegisterResponse mapUserRegisterResponse(FederatedTokenResponse tokenResponse,NtpPreRegisterResponse ntpPreRegistrationResponse) {
		FederatedUserRegisterResponse userRegisterResponse = new FederatedUserRegisterResponse();
		userRegisterResponse.setPreRegisterResponse(ntpPreRegistrationResponse);
		userRegisterResponse.setCustomerAuthToken(tokenResponse.getCustomerAuthToken());
		return userRegisterResponse; 
	}
	
	@Override
	public HttpHeaders populateFederatedUserRegisterUtmHeaders(HttpHeaders headers, String clientId) {
		if(StringUtils.isBlank(headers.getFirst("utm_source"))) {
			headers.set("utm_source", "Organic");
		}
		if(StringUtils.isBlank(headers.getFirst("app_source"))) {
			headers.set("app_source", clientId);
		}
		if(StringUtils.isBlank(headers.getFirst("platform"))) {
			headers.set("platform", "FEDERATED");
		}
		return headers;
	}
}

