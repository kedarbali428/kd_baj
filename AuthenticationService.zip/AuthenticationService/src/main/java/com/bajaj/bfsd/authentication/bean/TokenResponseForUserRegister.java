package com.bajaj.bfsd.authentication.bean;

import java.util.List;

import com.bajaj.bfsd.authentication.model.Tokens;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TokenResponseForUserRegister {
	
	private static final long serialVersionUID = -8796814877955712643L;

	private List<Tokens> tokens;

	// End added for PartnerPortal
	public List<Tokens> getTokens() {
		return tokens;
	}

	public void setTokens(List<Tokens> tokens) {
		this.tokens = tokens;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((tokens == null) ? 0 : tokens.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TokenResponseForUserRegister other = (TokenResponseForUserRegister) obj;
		if (tokens == null) {
			if (other.tokens != null)
				return false;
		} else if (!tokens.equals(other.tokens))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TokenResponseForUserRegister [tokens=" + tokens + "]";
	}


	
}
