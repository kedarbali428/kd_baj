package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ApplicantProfile implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private NameVerificationDetails name;
	private MobileVerificationDet mobileNumber;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date dateOfBirth;
	private String pinCode;
	private String gender;
	private String maritalStatus;
	private Long applicantKey;
	private boolean appStatusComplete;
	
	public NameVerificationDetails getName() {
		return name;
	}
	public void setName(NameVerificationDetails name) {
		this.name = name;
	}
	public MobileVerificationDet getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(MobileVerificationDet mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public Long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}
	public boolean isAppStatusComplete() {
		return appStatusComplete;
	}
	public void setAppStatusComplete(boolean appStatusComplete) {
		this.appStatusComplete = appStatusComplete;
	}
	
}
