/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * This is a Class for fetching applicant details.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	20/12/2016      Initial Version
 */
@JsonInclude(Include.NON_NULL)
public class GenerateOTP implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 2302771330094629568L;
    /**
     * Variable to hold value for policy name.
     */
    private String policyName;
    /**
     * Variable to hold value for email.
     */
    private String email;
    
    /**
     * Variable to hold value for mobile.
     */
    private String mobile;
    
    /**
     * Variable to hold value for otp.
     */
    private String otp;
    
    /**
     * Variable to hold value for generate time.
     */
    private String generateTime;
    
    /**
     * Variable to hold value for valid mins.
     */
    private String validMins;
    /**
     * Getter method for policy name.
     *
     * @return policy name
     */
    public String getPolicyName() {
        return policyName;
    }

    /**
     * Sets the value of policy name.
     *
     * @param policyName the new policy name
     */
    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    /**
     * Getter method for email.
     *
     * @return email
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * Sets the value of email.
     *
     * @param email the new email
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * Getter method for mobile.
     *
     * @return mobile
     */
    public String getMobile() {
        return mobile;
    }
    
    /**
     * Sets the value of mobile.
     *
     * @param mobile the new mobile
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
    /**
     * Getter method for otp.
     *
     * @return otp
     */
    public String getOtp() {
        return otp;
    }
    
    /**
     * Sets the value of otp.
     *
     * @param otp the new otp
     */
    public void setOtp(String otp) {
        this.otp = otp;
    }

    /**
     * Getter method for generate time.
     *
     * @return generate time
     */
    public String getGenerateTime() {
        return generateTime;
    }

    /**
     * Sets the value of generate time.
     *
     * @param generateTime the new generate time
     */
    public void setGenerateTime(String generateTime) {
        this.generateTime = generateTime;
    }

    /**
     * Getter method for valid mins.
     *
     * @return valid mins
     */
    public String getValidMins() {
        return validMins;
    }

    /**
     * Sets the value of valid mins.
     *
     * @param validMins the new valid mins
     */
    public void setValidMins(String validMins) {
        this.validMins = validMins;
    }
}
