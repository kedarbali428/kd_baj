package com.bajaj.bfsd.authentication.bean;

public class UtmParameters {
	private String utmSource;
	private String utmCampaign;
	private String utmChannel;
	private String utmMedium;
	private String utmKeyword;
	private String utmContent;
	private String utmTerm;

	public String getUtmSource() {
		return utmSource;
	}

	public void setUtmSource(String utmSource) {
		this.utmSource = utmSource;
	}

	public String getUtmCampaign() {
		return utmCampaign;
	}

	public void setUtmCampaign(String utmCampaign) {
		this.utmCampaign = utmCampaign;
	}

	public String getUtmChannel() {
		return utmChannel;
	}

	public void setUtmChannel(String utmChannel) {
		this.utmChannel = utmChannel;
	}

	public String getUtmMedium() {
		return utmMedium;
	}

	public void setUtmMedium(String utmMedium) {
		this.utmMedium = utmMedium;
	}

	public String getUtmKeyword() {
		return utmKeyword;
	}

	public void setUtmKeyword(String utmKeyword) {
		this.utmKeyword = utmKeyword;
	}

	public String getUtmContent() {
		return utmContent;
	}

	public void setUtmContent(String utmContent) {
		this.utmContent = utmContent;
	}

	public String getUtmTerm() {
		return utmTerm;
	}

	public void setUtmTerm(String utmTerm) {
		this.utmTerm = utmTerm;
	}

	@Override
	public String toString() {
		return "UtmParameters [utmSource=" + utmSource + ", utmCampaign=" + utmCampaign + ", utmChannel=" + utmChannel + ", utmMedium=" + utmMedium + ", utmKeyword=" + utmKeyword + ", utmContent="
				+ utmContent + ", utmTerm=" + utmTerm + "]";
	}

}
