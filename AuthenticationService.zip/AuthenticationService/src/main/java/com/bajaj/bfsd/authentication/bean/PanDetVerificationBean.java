package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class PanDetVerificationBean implements Serializable{

	/**
	 * 
	 */
private static final long serialVersionUID = 1L;
	
	private String preFillValue;
	private boolean toBeDisplayed;
	private boolean isEditable;
	private String verificationSource;
	
	/**
	 * @return the preFillValue
	 */
	public String getPreFillValue() {
		return preFillValue;
	}
	/**
	 * @param preFillValue the preFillValue to set
	 */
	public void setPreFillValue(String preFillValue) {
		this.preFillValue = preFillValue;
	}
	/**
	 * @return the toBeDisplayed
	 */
	public boolean isToBeDisplayed() {
		return toBeDisplayed;
	}
	/**
	 * @param toBeDisplayed the toBeDisplayed to set
	 */
	public void setToBeDisplayed(boolean toBeDisplayed) {
		this.toBeDisplayed = toBeDisplayed;
	}
	/**
	 * @return the isEditable
	 */
	public boolean isEditable() {
		return isEditable;
	}
	/**
	 * @param isEditable the isEditable to set
	 */
	public void setEditable(boolean isEditable) {
		this.isEditable = isEditable;
	}
	/**
	 * @return the verificationSource
	 */
	public String getVerificationSource() {
		return verificationSource;
	}
	/**
	 * @param verificationSource the verificationSource to set
	 */
	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}
	
	
	

}
