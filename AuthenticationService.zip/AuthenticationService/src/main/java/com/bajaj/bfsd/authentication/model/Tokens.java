package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Tokens implements Serializable {

	private static final long serialVersionUID = 8859917194655114349L;
	
	private String token;
	private String guardKey;
	private String type;
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getGuardKey() {
		return guardKey;
	}
	public void setGuardKey(String guardKey) {
		this.guardKey = guardKey;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((guardKey == null) ? 0 : guardKey.hashCode());
		result = prime * result + ((token == null) ? 0 : token.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tokens other = (Tokens) obj;
		if (guardKey == null) {
			if (other.guardKey != null)
				return false;
		} else if (!guardKey.equals(other.guardKey))
			return false;
		if (token == null) {
			if (other.token != null)
				return false;
		} else if (!token.equals(other.token))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Tokens [token=" + token + ", guardKey=" + guardKey + ", type=" + type + "]";
	}
	
}
