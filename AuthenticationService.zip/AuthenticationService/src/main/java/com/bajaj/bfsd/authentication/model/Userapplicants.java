package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;




	@Entity
	@Table(name="USER_APPLICANT")
	@NamedQuery(name="UserApplicant.findAll", query="SELECT u FROM UserApplicant u")
	public class Userapplicants implements Serializable {
		private static final long serialVersionUID = 1L;

		@Id
		private long userapplicantkey;

		private BigDecimal applicantkey;

		private BigDecimal userkey;

		public Userapplicants() {
		}

		public long getUserapplicantkey() {
			return this.userapplicantkey;
		}

		public void setUserapplicantkey(long userapplicantkey) {
			this.userapplicantkey = userapplicantkey;
		}

		public java.math.BigDecimal getApplicantkey() {
			return this.applicantkey;
		}

		public void setApplicantkey(java.math.BigDecimal applicantkey) {
			this.applicantkey = applicantkey;
		}

		public java.math.BigDecimal getUserkey() {
			return this.userkey;
		}

		public void setUserkey(java.math.BigDecimal userkey) {
			this.userkey = userkey;
		}

	}


