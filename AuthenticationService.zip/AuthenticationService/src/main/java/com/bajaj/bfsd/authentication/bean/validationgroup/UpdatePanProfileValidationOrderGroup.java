package com.bajaj.bfsd.authentication.bean.validationgroup;

/* 
 * Note: 
 * This is a marker interface used for grouping validation
 * in AppOnBoarding Update Profile request based on Pan
 * 
*/

public interface UpdatePanProfileValidationOrderGroup {

}
