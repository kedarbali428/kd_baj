package com.bajaj.bfsd.authentication.authorize;

import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.AUTH_TOKEN;
import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.EXPIRED_STATUS;
import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.INVALID_STATUS;
import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.OTHER;
import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.SOURCE;
import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.USER_ID;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@Component
public class TokenValidationUtil {

	@Value("${api.tokenmanagement.authenticate.token.POST.url}")
	private String tokenValidateUrl;

	@Value("${api.usermanagement.user.additionalprofile.GET.url}")
	private String userAdditionalInfoUrl;

	@Autowired
	@Qualifier("restTemplate")
	RestTemplate restTemplate;

	@Autowired
	BFLLoggerUtilExt logger;

	public ResponseEntity<?> getTokenValidity(String authtoken) {
		HttpHeaders headers = new HttpHeaders();
		headers.add(AUTH_TOKEN, authtoken);

		HttpEntity<Object> entity = new HttpEntity<>(null, headers);

		ResponseEntity<?> validationResponse = null;
		try {
			validationResponse = restTemplate.exchange(tokenValidateUrl, HttpMethod.POST, entity,
					ValidateTokenResponse.class);
		} catch (RestClientException e) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					" Rest call failed to: " + tokenValidateUrl, e);
		}

		return validationResponse;
	}

	public boolean isValidToken(ResponseEntity<?> tokenValidationResponse) {
		if (null == tokenValidationResponse || !HttpStatus.OK.equals(tokenValidationResponse.getStatusCode())
				|| null == tokenValidationResponse.getBody()) {
			return false;
		}

		ValidateTokenResponse tokenValidateResponse = (ValidateTokenResponse) tokenValidationResponse.getBody();

		String tokenStatus = tokenValidateResponse.getTokenStatus();
		if (tokenStatus == null || (EXPIRED_STATUS.equals(tokenStatus) || INVALID_STATUS.equals(tokenStatus))) {
			return false;
		} else {
			return true;
		}
	}

	public AdditionalInfo getAdditionalUserInfo(long userId) {
		AdditionalInfo additionalInfo = null;
		Long userID=userId;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<Object> entity = new HttpEntity<>(null, headers);
		Map<String, String> uriVariables = new HashMap<String, String>();
		uriVariables.put(USER_ID,userID.toString());
		uriVariables.put(SOURCE,OTHER );

		try {
			ResponseEntity<?> additionalUserInfoResponse = restTemplate.exchange(userAdditionalInfoUrl, HttpMethod.GET,
					entity, AdditionalInfo.class, uriVariables);
			if (HttpStatus.OK == additionalUserInfoResponse.getStatusCode()) {
				if (null != additionalUserInfoResponse.getBody()) {
					additionalInfo = (AdditionalInfo) additionalUserInfoResponse.getBody();
				} else {
					logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
							"User Additional Info not available with userId: " + userId);
				}
			} else {
				logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
						"User Additional Info call failed with not OK response: "
								+ additionalUserInfoResponse.getStatusCode());
			}
		} catch (RestClientException e) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					" Rest call failed to: " + userAdditionalInfoUrl);
		}

		return additionalInfo;
	}
	
	public AdditionalInfo getEPAdditionalUserInfo(long userId,String source) {
		AdditionalInfo additionalInfo = null;
        Long userID=userId;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<Object> entity = new HttpEntity<>(null, headers);
		Map<String, String> uriVariables = new HashMap<String, String>();
		uriVariables.put(USER_ID,userID.toString() );
		uriVariables.put(SOURCE, source);

		try {
			ResponseEntity<?> additionalUserInfoResponse = restTemplate.exchange(userAdditionalInfoUrl, HttpMethod.GET,
					entity, AdditionalInfo.class, uriVariables);
			if (HttpStatus.OK == additionalUserInfoResponse.getStatusCode()) {
				if (null != additionalUserInfoResponse.getBody()) {
					additionalInfo = (AdditionalInfo) additionalUserInfoResponse.getBody();
				} else {
					logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
							"User Additional Info not available with userId: " + userId);
				}
			} else {
				logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
						"User Additional Info call failed with not OK response: "
								+ additionalUserInfoResponse.getStatusCode());
			}
		} catch (RestClientException e) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					" Rest call failed to: " + userAdditionalInfoUrl);
		}

		return additionalInfo;
	}
	
	 
}
