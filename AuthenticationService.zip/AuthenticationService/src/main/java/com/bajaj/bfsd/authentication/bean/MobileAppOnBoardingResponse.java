package com.bajaj.bfsd.authentication.bean;

public class MobileAppOnBoardingResponse {

	private Boolean skipFlag;

	public Boolean getSkipFlag() {
		return skipFlag;
	}

	public void setSkipFlag(Boolean skipFlag) {
		this.skipFlag = skipFlag;
	}

	@Override
	public String toString() {
		return "MobileAppOnBoardingResponse [skipFlag=" + skipFlag + "]";
	}
	
}
