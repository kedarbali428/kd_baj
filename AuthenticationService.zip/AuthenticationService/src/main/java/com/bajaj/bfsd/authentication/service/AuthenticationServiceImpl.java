/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.RequestScoped;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bajaj.bfsd.authentication.bean.ApplicantCreateRequest;
import com.bajaj.bfsd.authentication.bean.ApplicantDetailsBean;
import com.bajaj.bfsd.authentication.bean.ApplicantEmailBean;
import com.bajaj.bfsd.authentication.bean.ApplicantEmailDetails;
import com.bajaj.bfsd.authentication.bean.ApplicantProfile;
import com.bajaj.bfsd.authentication.bean.ApplicantUtmBean;
import com.bajaj.bfsd.authentication.bean.ApplicationRequestBean;
import com.bajaj.bfsd.authentication.bean.MobileVerificationDet;
import com.bajaj.bfsd.authentication.bean.NameVerificationDetails;
import com.bajaj.bfsd.authentication.bean.NtpLoginRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreProcessRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterResponse;
import com.bajaj.bfsd.authentication.bean.TokensBean;
import com.bajaj.bfsd.authentication.bean.User;
import com.bajaj.bfsd.authentication.bean.UserConfigurationBean;
import com.bajaj.bfsd.authentication.bean.UserKeysBean;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV2;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV4;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV5;
import com.bajaj.bfsd.authentication.bean.UtmParameters;
import com.bajaj.bfsd.authentication.config.MapperFactory;
import com.bajaj.bfsd.authentication.constants.AuthenticationServiceUtil;
import com.bajaj.bfsd.authentication.dao.AuthenticationServiceDao;
import com.bajaj.bfsd.authentication.model.AadharLoginRequest;
import com.bajaj.bfsd.authentication.model.AadharOtpResponse;
import com.bajaj.bfsd.authentication.model.ApplicantUtm;
import com.bajaj.bfsd.authentication.model.BfsdUser;
import com.bajaj.bfsd.authentication.model.GenerateOTP;
import com.bajaj.bfsd.authentication.model.GenerateTokenRequest;
import com.bajaj.bfsd.authentication.model.Login;
import com.bajaj.bfsd.authentication.model.LoginAccount;
import com.bajaj.bfsd.authentication.model.LoginSecretKeyResponse;
import com.bajaj.bfsd.authentication.model.MobileDobOtpLoginRequest;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.SocialAuthenticationRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsResponse;
import com.bajaj.bfsd.authentication.model.SocialProfileResponse;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.model.UserLoginAccountRequest;
import com.bajaj.bfsd.authentication.model.UserLoginAccountResponse;
import com.bajaj.bfsd.authentication.model.ValidateOTP;
import com.bajaj.bfsd.authentication.model.ValidateUserRequest;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceHelper;
import com.bajaj.bfsd.authentication.util.DataValidator;
import com.bajaj.bfsd.authentication.util.Ldaputility;
import com.bajaj.bfsd.authentication.util.LoginPasswordValidator;
import com.bajaj.bfsd.authentication.util.TokenCodeHelper;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLService;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

/**
 * This is a service class for OpenAM external api call.
 *
 * @author 582602
 * 
 *         Version BugId UsrId Date Description 1.0 582602 28/11/2016 Initial
 *         Version
 */


@RefreshScope
@Service
public class AuthenticationServiceImpl extends BFLService implements AuthenticationService {
	@Autowired
	BFLLoggerUtil logger;
	
	@Autowired
	@RequestScoped
	DataValidator dataValidator;
	
	@Autowired
	FinegrainAuthServiceImpl finegrainAuthServiceImpl;
	
	@Autowired
	AuthenticationServiceHelper authenticationServiceHelper;

	@Autowired
	private TokenCodeHelper tokenCodeHelper;
	
	@Value("${fbRedirectUrl}")
	private String facebookRedirectUrl;
	@Value("${fbAppId}")
	private String facebookAppId;
	@Value("${fbSecret}")
	private String facebookKey;
	@Value("${applicationRedirectPage}")
	private String applicationRedirectPage;
	@Value("${api.usermanagement.getuicredentials.GET.url}")
	private String getSecretKeyURL;
	@Value("${api.aadhar.validateaadhar.GET.url}")
	private String getAadharOtpURL;
	@Value("${api.aadhar.validateaadhar.otpkyc.POST.url}")
	private String getAadharUserDetailsURL;
	@Value("${api.usermanagement.getuserid.GET.url}")
	private String getLoginUserUrl;

	@Value("${api.tokenmanagement.generatetoken.POST.url}")
	private String tokenServiceURL;
	
	@Value("${api.tokenmanagement.expiretoken.DELETE.url}")
	private String tokenExpireUrl;

	@Value("${api.socialauthentication.linkedindetails.GET.url}")
	private String linkedinURL;
	
	@Value("${api.socialauthentication.facebookdetails.GET.url}")
	private String facebookURL;
	
	@Value("${api.sas.sa.lidurl}")
	private String linkedinDetailsURL;
	
	@Value("${api.usermanagement.getloginaccount.POST.url}")
	private String userAccountUrl;
	
	@Value("${api.usermanagement.saveprofile.POST.url}")
	private String saveUserProfileUrl;
	@Value("${api.tokenmanagement.accesstoken.GET.url}")
	private String tokenUrl;
	
	@Value("${api.applicant.keys.GET.url}")
	private String keysUrl;
	
	@Value("${tms.token.salt}")
	private String salt;
	
	//Linkedin Redirect Url Details
	@Value("${liRedirectUrl}")
	private String linkedinRedirectUrl;
	@Value("${liAppId}")
	private String linkedInClientId;
	@Value("${liSecret}")
	private String linkedInKey;
	
	@Value("${api.otp.generate.POST.url}")
	private String otpGenerateUrl;
	@Value("${api.otp.validate.POST.url}")
	private String otpValidateUrl;
	
	@Value("${userprofile.finegrain.authcheck.load:false}")
	private boolean loadFinegrainedUserProfile;
	
	
	
	@Autowired
	Ldaputility ldaputility;
	
	@Autowired
	private AsyncClass asyncClass;
	@Autowired
	private AuthenticationServiceDao authenticationServiceDao;

	private static final String THIS_CLASS = AuthenticationServiceImpl.class.getCanonicalName();
	private static final String AUTH101 = "AUTH-101";

	private static final String MOBILE2 = "mobile";
	/**
	 * Variable to hold value for env.
	 */
	@Autowired
	private Environment env;


	@Override
	public String generateOTP(GenerateOTP generateOTP) throws IOException {

		GenerateOTP generateOTP2;
		ObjectMapper mapper = MapperFactory.getInstance();
		String otpGenUrl = env.getProperty("api.otp.generate.url");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		ResponseEntity<ResponseBean> responseEntity;

		String reqJson = mapper.writeValueAsString(generateOTP);
		responseEntity = (ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST,
				otpGenUrl, null, ResponseBean.class, null, reqJson, headers);

		generateOTP2 = mapper.convertValue(responseEntity.getBody().getPayload(), GenerateOTP.class);

		if (generateOTP2 != null) {
			return generateOTP2.getOtp();
		} else {
			return null;
		}
	}	

	@Override
	public SocialLoginParamsResponse getFacebookLoginParams(SocialLoginParamsRequest socialLoginParamsRequest){
		DateTimeFormatter srcDtf = DateTimeFormat.forPattern("yyyyMMddHHmmssSSS");
		String strJodaTime = srcDtf.print(new DateTime());
		StringBuilder url = new StringBuilder();
		url.append(facebookRedirectUrl);
		url.append("client_id=" + facebookAppId);
		url.append("&redirect_uri=" + applicationRedirectPage);
		url.append("&scope=" + "email,user_birthday");
		url.append("&state=" + strJodaTime);
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "==== Facebook Redirect URL ===" + url.toString());
		SocialLoginParamsResponse socialLoginParamsResponse = new SocialLoginParamsResponse();
		socialLoginParamsResponse.setRedirectUrl(url.toString());

		return socialLoginParamsResponse;
	}
	
	@Override
	public SocialLoginParamsResponse getRedirectUrl(SocialLoginParamsRequest socialLoginParamsRequest){

		StringBuilder rediectUrl = new StringBuilder();
		String platform = socialLoginParamsRequest.getPlatform();
		DateTimeFormatter srcDtf = DateTimeFormat.forPattern("yyyyMMddHHmmssSSS");
		String strJodaTime = srcDtf.print(new DateTime());
		try {
			switch (platform) {
			case AuthenticationServiceConstants.FACEBOOK:
				rediectUrl.append(facebookRedirectUrl).append("client_id=" + facebookAppId)
						.append("&redirect_uri=" + applicationRedirectPage).append("&scope=" + "email,user_birthday")
						.append("&state=" + strJodaTime);
				break;
			case AuthenticationServiceConstants.LINKEDIN:
					rediectUrl.append(linkedinRedirectUrl).append("response_type=code")
					.append("&client_id=" + linkedInClientId).append("&redirect_uri=" + URLEncoder.encode(applicationRedirectPage, "UTF-8"))
					.append("&scope=" + URLEncoder.encode("r_basicprofile r_emailaddress", "UTF-8")).append("&state=" + strJodaTime);
				break;
			default:
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Invalid platform for redirect URL - "+platform);
				throw new BFLBusinessException("AUTH_632",env.getProperty("AUTH_632"));
			}
		
		} catch (UnsupportedEncodingException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Unable to encode URL - "+e);
			throw new BFLBusinessException("AUTH_633",env.getProperty("AUTH_633"));
		}
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getRedirectUrl - redirect URL - " + rediectUrl.toString());
		SocialLoginParamsResponse socialLoginParamsResponse = new SocialLoginParamsResponse();
		socialLoginParamsResponse.setRedirectUrl(rediectUrl.toString());

		return socialLoginParamsResponse;
	}


	@Override
	public LoginSecretKeyResponse getSecretKey(String clientId)
			 {
		HttpHeaders headersDemog = new HttpHeaders();
		headersDemog.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		Map<String, String> params = new HashMap<>();
		params.put("clientId", clientId);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "URL for secret Key - " + getSecretKeyURL);
		ResponseEntity<ResponseBean> secretKeyResponse = BFLCommonRestClient.get(getSecretKeyURL, null, String.class,
				params, null, headersDemog, null);
		if (secretKeyResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(secretKeyResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "App Key - ");
				throw new BFLBusinessException("500",
						"Get Secret Key for clientId call failed - " + secretKeyResponse.getBody().toString());
			} else {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"Response for Get Secret Key - " + secretKeyResponse.getBody().toString());
				JSONObject respJson = new JSONObject(secretKeyResponse.getBody().getPayload().toString());
				JSONObject payloadJson = respJson.has("payload") ? respJson.getJSONObject("payload") : new JSONObject();
				String secretKey = payloadJson.has("secretKey") ? payloadJson.getString("secretKey") : null;
				LoginSecretKeyResponse loginSecretKeyResponse = new LoginSecretKeyResponse();
				loginSecretKeyResponse.setSecretKey(secretKey);
				return loginSecretKeyResponse;
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "App Key - " + secretKeyResponse.getBody().toString());
			throw new BFLBusinessException("500",
					"Get Secret Key for clientId call failed - " + secretKeyResponse.getBody().toString());
		}

	}

	@Override
	public ResponseBean getAadharOtp(String aadharNo){
		HttpHeaders headersAadhar = new HttpHeaders();
		headersAadhar.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		Map<String, String> urlParam = new HashMap<>();
		urlParam.put("aadharNo", aadharNo);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "URL for Aadhar OTP - " + getAadharOtpURL);
		ResponseEntity<ResponseBean> aadharOtpResponse = BFLCommonRestClient.get(getAadharOtpURL, null, String.class,
				urlParam, null, headersAadhar, null);
		if (aadharOtpResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(aadharOtpResponse.getBody().getStatus().name()) || 
					StatusCode.FAILURE.name().equals(new JSONObject(aadharOtpResponse.getBody().getPayload().toString()).get("status"))){
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "OTP Call failed for Aadhar No - "
						+ aadharNo + ", response- " + aadharOtpResponse.getBody().toString());
				throw new BFLBusinessException("AUTH-014",
						"GenOTP Call failed for Aadhar No - " + aadharOtpResponse.getBody().toString());
			} else {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"Generate OTP Call - " + aadharOtpResponse.getBody().toString());
				
				JSONObject respJson = new JSONObject(aadharOtpResponse.getBody().getPayload().toString());
				JSONObject payloadJson = respJson.has("payload")&&respJson.get("payload")!=null ? respJson.getJSONObject("payload") : new JSONObject();
				payloadJson.get(AuthenticationServiceConstants.TRANSACTIONID);
				payloadJson.get(AuthenticationServiceConstants.HASH_CODE);
				
				AadharOtpResponse otpResponse = new AadharOtpResponse();
				otpResponse.setOtpTxnId(payloadJson.get(AuthenticationServiceConstants.TRANSACTIONID).toString());
				otpResponse.setHashCode(payloadJson.get(AuthenticationServiceConstants.HASH_CODE).toString());
				
				return new ResponseBean(otpResponse);
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Generate OTP Call failed for Aadhar No - " + aadharNo
					+ ", response- " + aadharOtpResponse.getBody().toString());
			throw new BFLBusinessException("500",
					"Generate OTP Call failed for Aadhar No - " + aadharOtpResponse.getBody().toString());
		}
	}

	@Override
	public JSONObject getAadharUserDetails(AadharLoginRequest aadharLoginRequest){

		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,"getAadharUserDetails - start");
		
		HttpHeaders headersAadhar = new HttpHeaders();
		headersAadhar.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		JSONObject jsonRequest = new JSONObject();
		jsonRequest.put("aadhaarNumber", aadharLoginRequest.getAadharNumber());
		jsonRequest.put("otp", aadharLoginRequest.getOtp());
		jsonRequest.put("transactionId", aadharLoginRequest.getOtpTxnId());
		jsonRequest.put("hashCode", aadharLoginRequest.getHashCode());
		jsonRequest.put("applicationId", aadharLoginRequest.getApplicationId());

		
	
		ResponseEntity<ResponseBean> aadharOtpResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, getAadharUserDetailsURL, null, ResponseBean.class, null, jsonRequest.toString(),
						headersAadhar, null);
		if (aadharOtpResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(aadharOtpResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,"Error while getting aadhar details - " + aadharLoginRequest.getAadharNumber()
								+ ", response -"+ aadharOtpResponse);
				throw new BFLBusinessException("AUTH-015",env.getProperty("AUTH-015"));
			} else {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,"getAadharUserDetails - status success"  +aadharOtpResponse);
				return new JSONObject(
						AuthenticationServiceUtil.mapToJsonString(aadharOtpResponse.getBody().getPayload(), logger));
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"getAadharUserDetails - Invalid status code received while aadhar OTP verification - "
							+ aadharLoginRequest.getAadharNumber() + ", response - " + aadharOtpResponse);
			throw new BFLBusinessException("AUTH_022", env.getProperty("AUTH_022"));
		}
	}
	
	@Override
	public SocialProfileResponse getSocialDetails(SocialAuthenticationRequest socialRequest, HttpHeaders headers){
	
		String socialProfileUrl;
		String target = socialRequest.getTarget();
		String code = socialRequest.getCode();
		String token = socialRequest.getToken();
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,"getSocialDetails - started -> target is ->"+target);
		
		if(AuthenticationServiceConstants.FACEBOOK.equals(target)){
			socialProfileUrl=facebookURL;
		}else if (AuthenticationServiceConstants.LINKEDIN.equals(target)) {
			socialProfileUrl=linkedinURL;
		}
		else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Invalid target - "+target);
			throw new BFLBusinessException("AUTH_021", env.getProperty("AUTH_021"));
		}
		SocialProfileResponse socialProfile = AuthenticationServiceHelper.getSocialProfile(logger, socialProfileUrl, code, token, headers, env);
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,"getSocialDetails - completed");
		return socialProfile;
	}

	@Override
	public UserLoginAccountResponse authenticateUser(LoginAccount loginAcct) {
		UserLoginAccountResponse userLoginAccountResponse;

		ObjectMapper mapper = MapperFactory.getInstance(); 
		String requestString;

		try {
			requestString = mapper.writeValueAsString(loginAcct);
		} catch (JsonProcessingException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "retrieveUserId: JsonProcessingException Occured", e);
			throw new BFLBusinessException(AUTH101, env.getProperty(AUTH101));

		}
		userLoginAccountResponse = AuthenticationServiceHelper.authenticateUser(userAccountUrl, requestString, logger);

		if(userLoginAccountResponse.getUserId() == 0){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"authenticateManualLogin - LoginId not found - " + loginAcct.getLoginId());
			throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_627,env.getProperty(AuthenticationServiceConstants.AUTH_627));
		}

		if ((loginAcct.getLoginType() == AuthenticationServiceConstants.LOGINACCTYPE_MANUAL ||loginAcct.getLoginType() == AuthenticationServiceConstants.LOGINACCTYPE_MOBILE_DOB_OTP_MPIN)
				&& userLoginAccountResponse.isFailedRequest()) {

			if (userLoginAccountResponse.getAccountStatus() == AuthenticationServiceConstants.ISACTIVE) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"authenticateManualLogin - Account locked - " + loginAcct.getLoginId());
				throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_019, env.getProperty(AuthenticationServiceConstants.AUTH_019));
			} else {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"authenticateManualLogin - Manual login failed for - " + loginAcct.getLoginId());
				throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_018, env.getProperty(AuthenticationServiceConstants.AUTH_018));
			}

		}
		
		return userLoginAccountResponse;
	}

	@Override
	public TokenResponse getToken(String loginId, Long userId, short userType, HttpHeaders headers) {
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		TokenResponse tokenResponse = null;
		try {
			generateTokenReq.setLoginId(loginId);
			generateTokenReq.setUserId(userId);
			generateTokenReq.setUserType(userType);
			ObjectMapper mapper = MapperFactory.getInstance();

			headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
			String requestString;

			requestString = mapper.writeValueAsString(generateTokenReq);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "get token Request:"+requestString);
			tokenResponse = AuthenticationServiceHelper.getToken(tokenServiceURL, requestString, logger,headers);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "getToken - "+tokenResponse.getTokens().size());
		} catch (JsonProcessingException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "getToken: JsonProcessingException Occured", e);
            throw new BFLBusinessException(AUTH101, env.getProperty(AUTH101));
		}

		return tokenResponse;
	}
	
	@Override
	public TokenResponse authenticateManualLogin(UserLoginAccountRequest manualLoginRequest, HttpHeaders headers, ApplicantUtmBean applicantUtmBean){
		TokenResponse token = null;
		long userId;
		short userType;
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateManualLogin - "+manualLoginRequest.getLoginId());
		String loginId = manualLoginRequest.getLoginId();
		String pwd = manualLoginRequest.getPassword();
		//1) Validate userid password format. If valid then fetch userid from UserManagement Service.
		if(this.validateLoginIdPasswordFormat(loginId, pwd))
		{
			userType = AuthenticationServiceHelper.getUserType(manualLoginRequest.getSource());

		//2)Validate userId in Active Directory(If user exist and userType is employee or vendor partner then it will authenticates against AD 
		   //and after successful authentication TokenManagementService will be called)
			if (userType == AuthenticationServiceConstants.USERTYPE_EMPLOYEE && !this.authenticateUserInAD(loginId,pwd)) {
				// call AD service
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "User " + loginId + "does not exist in AD");
				throw new BFLBusinessException("AUTH_626", env.getProperty("AUTH_626"));
			}

		//3)Get login failed account and user details from /user (POST) service in UserManagement. Check the logic with Manish Shoucsh	
		ValidateUserRequest validateUserReq  = new ValidateUserRequest();
		validateUserReq.setLoginId(loginId);
		validateUserReq.setLoginType(AuthenticationServiceConstants.LOGINACCTYPE_MANUAL);
		validateUserReq.setPwd(pwd);
		validateUserReq.setUserType(userType);
		
		UserLoginAccountResponse response = this.validateManualLoginUser(validateUserReq, headers);
		userId = response.getUserId();
		
		if(userId == 0){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateManualLogin - No user found for - "+validateUserReq.getLoginId());
			throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_627,env.getProperty(AuthenticationServiceConstants.AUTH_627));
		}

		boolean failedRequest = response.isFailedRequest();
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateManualLoginUser request failed- "+failedRequest);
		
		Login login = new Login();
		login.setUsername(loginId);
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(userId);
		login.setBfsdUser(bfsdUser);
		this.setLoginSrc(login, headers);
		
		
		if(failedRequest)
		{
			//update login activity in case of failure
			login.setPassword(manualLoginRequest.getPassword());
			asyncClass.updateLoginFailed(login);	
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "failure case - "+failedRequest);
			if(response.getAccountStatus() == AuthenticationServiceConstants.ISACTIVE)
			{
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateManualLogin - Account locked - "+validateUserReq.getLoginId());
				throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_019,env.getProperty(AuthenticationServiceConstants.AUTH_019));
			}
			else
			{
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateManualLogin - Manual login failed for - "+validateUserReq.getLoginId());
				throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_018,env.getProperty(AuthenticationServiceConstants.AUTH_018));
			}
		}
		else
		{
			//update login activity in case of success
			asyncClass.updateLoginActivity(login);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "success case - "+failedRequest);
			//call  TokenManagementService to generate a token and guardKey for the user
			token = this.getToken(loginId, userId, userType, headers);
			// utm Horizontal-12
				try {
					long applicantId = authenticationServiceDao.getApplicantId(userId);
					applicantUtmBean.setApplicantKey(applicantId);
					saveApplicantUtmParam(applicantUtmBean);
				} catch (Exception e) {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Applicant UTM saving failed", e);
				}
			}
		}
		return token;
	}
	
    
	    
	    @Override
	    public Boolean authenticateUserInAD(String loginId,String pwd) {
	    	logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateUserInAD method- "+loginId);
	    	//hit Active directory service-Bhavika
	    	UserConfigurationBean userConfig = new UserConfigurationBean();
	    	userConfig.setEmailId(loginId);
	    	userConfig.setPassword(pwd);
	    	userConfig = this.getActiveDirectoryUsers(userConfig);
	    	return userConfig.getIsUserExist();
	    }
	    
		
		public Boolean validateLoginIdPasswordFormat(String loginId, String password){
	
			return LoginPasswordValidator.validatePassword(password) && LoginPasswordValidator.validateLogin(loginId);
		}

		
	public UserLoginAccountResponse validateManualLoginUser(ValidateUserRequest validateUserReq, HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,"validateManualLoginUser - start");
		JSONObject reqJsonObj = new JSONObject();

		reqJsonObj.accumulate("loginId", validateUserReq.getLoginId()).accumulate("pwd", validateUserReq.getPwd())
				.accumulate("userType", validateUserReq.getUserType())
				.accumulate("loginType", validateUserReq.getLoginType()).accumulate("dateOfBirth", validateUserReq.getDateOfBirth());

		ResponseEntity<ResponseBean> manualOtpResponse = BFLCommonRestClient.create(userAccountUrl, null, String.class,
				null, reqJsonObj.toString(), headers, null);
		if (manualOtpResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(manualOtpResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while validating login - "
						+ validateUserReq.getLoginId() + "response - " + manualOtpResponse);
				throw new BFLBusinessException("AUTH-024",env.getProperty("AUTH-024"));
			} else {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,"validateManualLoginUser - success");
				JSONObject respJson = new JSONObject(manualOtpResponse.getBody().getPayload().toString());
				JSONObject payloadJson = respJson.has("payload") ? respJson.getJSONObject("payload") : new JSONObject();
				UserLoginAccountResponse resp;

				Gson gson = new Gson();
				resp = gson.fromJson(payloadJson.toString(), UserLoginAccountResponse.class);
				if(null != resp && loadFinegrainedUserProfile && resp.getUserType()==1){//only for customer users
					finegrainAuthServiceImpl.loadUserProfile(resp.getUserId());
				}
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,"validateManualLoginUser - end");
				return resp;
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Invalid status received while validate login - "
					+ validateUserReq.getLoginId() + ", response - " + manualOtpResponse);
			throw new BFLBusinessException("AUTH_023",env.getProperty("AUTH_023"));
		}
	}
	
	
	@Component
	public class AsyncClass {
		
		@Autowired 
		AuthenticationServiceDao authenticationServiceDao;
		
		@Async
		public void updateLoginActivity(Login login)
		{			
			authenticationServiceDao.updateLoginActivity(login);
		}
		
		@Async
		public void updateLoginFailed(Login login)
		{			
			authenticationServiceDao.updateLoginFailed(login);
		}
		
		@Async
		public void updateLogoutActivity(Login login)
		{			
			authenticationServiceDao.updateLogoutActivity(login);
		}
	}		
		
		
		public UserConfigurationBean getActiveDirectoryUsers(UserConfigurationBean userConfig) {
			 
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "getActiveDirectoryUsers- "+userConfig.getFirstName());
			User user1 = new User();
			if(userConfig.getFirstName()!=null && !userConfig.getFirstName().isEmpty())
				user1.setFirstname(userConfig.getFirstName());
			if(userConfig.getLastName()!=null && !userConfig.getLastName().isEmpty())
				user1.setLastname(userConfig.getLastName());
			
			if(userConfig.getEmailId()!=null && !userConfig.getEmailId().isEmpty())
				user1.setEmailId(userConfig.getEmailId());
			
			if(userConfig.getDesignation()!=null && !userConfig.getDesignation().isEmpty())
				user1.setDesignation(userConfig.getDesignation());
			
			if(userConfig.getPassword()!=null && !userConfig.getPassword().isEmpty())
				user1.setPassword(userConfig.getPassword());
			
			//TODO: Remove the commented code for actual AD authentication
			Boolean isUserExist = ldaputility.getADUsers(user1);
			
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Is User Exists Flag: "+isUserExist);
			UserConfigurationBean userConfigBean =  new UserConfigurationBean();
			userConfigBean.setIsUserExist(isUserExist);
			
			return userConfigBean;

			
		}

		@Override
		public ResponseBean authenticateMobileDob(MobileLoginRequest mobileLoginRequest) {
			
			
			ResponseBean authenticateResponse;
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateMobileDob - started");
			
			
			String mobile = mobileLoginRequest.getMobile();
			
			//Validate mobile number
			boolean validMobile = dataValidator.validateMobile(mobile);
			
			if(!validMobile){
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateMobileDob - invalid mobile number - "+mobile);
				throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_020, env.getProperty(AuthenticationServiceConstants.AUTH_020));
			}
			
			//Call to OTP generate service
			JSONObject otpGenRequest = new JSONObject();

			otpGenRequest.put("policyName", "PL");// default policy
			otpGenRequest.put(MOBILE2, mobile);
			otpGenRequest.put("mfa", true);
			otpGenRequest.put("stage", mobileLoginRequest.getStage());
			otpGenRequest.put("productcatcode", mobileLoginRequest.getProductcatcode());
			
			ResponseEntity<ResponseBean> otpGenResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST, otpGenerateUrl, null, 
														ResponseBean.class, null, otpGenRequest.toString(), getHttpHeaders(), null);
			
			if (otpGenResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
				if (StatusCode.FAILURE.name().equals(otpGenResponse.getBody().getStatus().name())) {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,"authenticateMobileDob - Failed to generate OTP");
					return otpGenResponse.getBody();
				}
			} 
			else if(otpGenResponse.getStatusCodeValue() == HttpStatus.BAD_REQUEST.value()){
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,"authenticateMobileDob - invalid request sent to generate OTP");
				return otpGenResponse.getBody();
			}
			else {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Invalid status recevied from OTP generate service -"+otpGenResponse.getStatusCodeValue());
				throw new BFLBusinessException("AUTH-000",env.getProperty("AUTH-000"));
			}
			
			
			authenticateResponse = new ResponseBean(StatusCode.SUCCESS);
			
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateMobileDob - completed");
			return authenticateResponse;
			
		}

	@Override
	public boolean validateOtpForMobileDobLogin(MobileLoginRequest mobileLoginRequest) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateMobileDobAndGenerateToken - started");

		if (null == mobileLoginRequest || !validateInputForMobileDOBOTP(mobileLoginRequest)) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"authenticateMobileDobAndGenerateToken - Invalid input");
			throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_020,
					env.getProperty(AuthenticationServiceConstants.AUTH_020));
		}

		String mobile = mobileLoginRequest.getMobile();
		String otp = mobileLoginRequest.getOtp();

		boolean isValid = validateOTP(mobile, otp);

		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateMobileDobAndGenerateToken - completed");
		return isValid;
	}

	private boolean validateOTP(String mobile, String otp) {

		boolean retVal = false;
		JSONObject otpValidationRequest = new JSONObject();
		otpValidationRequest.put(MOBILE2, mobile);
		otpValidationRequest.put("otp", otp);
		ResponseEntity<ResponseBean> otpValidationResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, otpValidateUrl, null, ResponseBean.class, null,
						otpValidationRequest.toString(), getHttpHeaders(), null);

		int statusCode = otpValidationResponse.getStatusCodeValue();

		if (statusCode == HttpStatus.OK.value()) {
			if (StatusCode.SUCCESS.name().equalsIgnoreCase(otpValidationResponse.getBody().getStatus().name())) {
				retVal = true;
			} else if (null!=otpValidationResponse.getBody()&&!otpValidationResponse.getBody().getErrorBean().isEmpty()) {
				String erroMessage=otpValidationResponse.getBody().getErrorBean().get(0).getErrorMessage();
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,erroMessage);
		    	throw new BFLBusinessException(otpValidationResponse.getBody().getErrorBean().get(0).getErrorCode(),erroMessage);
			}else{
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"validateOTP - Failed to validate OTP" + otpValidationResponse.getBody().getStatus().name());
			}
		} else if (statusCode == HttpStatus.BAD_REQUEST.value()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateOTP - invalid request sent to validate OTP");
		} else
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateOTP - Invalid status recevied from OTP generate service -" + statusCode);
		return retVal;
	}

	private boolean validateInputForMobileDOBOTP(MobileLoginRequest mobileLoginRequest) {
		boolean retVal = false;

		if (null == mobileLoginRequest) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateInputForMobileDOBOTP - mobileLoginRequest is null");
			return retVal;
		}

		// Validate mobile number
		boolean isValid = dataValidator.validateMobile(mobileLoginRequest.getMobile());

		if (!isValid) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"validateInputForMobileDOBOTP - invalid mobile number");
			return retVal;
		}
        if(!StringUtils.equals(AuthenticationServiceConstants.MPIN_OTP_LOGIN, mobileLoginRequest.getSource())) {
		if (null != dataValidator.validateDateFieldAndReturnDate(mobileLoginRequest.getDateOfBirth(), "yyyy-MM-dd"))
			isValid = true;
		else
			isValid = false;
        }

		if (!isValid) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateInputForMobileDOBOTP - invalid DOB");
			return retVal;
		}

		return true;
	}

		

		private HttpHeaders getHttpHeaders(){
			HttpHeaders headersManual= new HttpHeaders();
	    	headersManual.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
	    	
	    	return headersManual;
		}

		@Override
		public void saveProfileDetails(String profileJson, long userId, String target) {
						
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfileDetails - started");
			
			HttpHeaders httpHeaders = getHttpHeaders();
			
			Map<String, String> queryParam = new HashMap<>();
			queryParam.put("source", target);
			
			JSONObject saveRequest = new JSONObject();
			saveRequest.put("userKey", userId);
			saveRequest.put("profileJson", profileJson);

			BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST,saveUserProfileUrl, null,
					ResponseBean.class, queryParam, saveRequest.toString(), httpHeaders, null);

			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfileDetails - completed");
			
		}

	@Override
	public void logout(long userId, HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfileDetails - started");
		BFLCommonRestClient.invokeRestEndpoint(HttpMethod.DELETE, tokenExpireUrl, null, ResponseBean.class, null, null,
				headers, null);

		Login userLogin = new Login();
		BfsdUser user = new BfsdUser();
		user.setUserkey(userId);
		userLogin.setBfsdUser(user);
		this.setLoginSrc(userLogin, headers);
		//asyncClass.updateLogoutActivity(userLogin);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "saveProfileDetails - end");

	}
	@Override
	public void checkUserExistance(String loginId, String dob, Integer loginType,String rType, ApplicantUtmBean applicantUtmBean) {
			int userCount=authenticationServiceDao.checkLoginIdExistance(loginId, dob, loginType,rType);
			if (1 < userCount) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, AuthenticationServiceConstants.MULTIPLE_USER);
				throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_637,
						env.getProperty(AuthenticationServiceConstants.AUTH_637));
			} else if (1 > userCount) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, AuthenticationServiceConstants.USER_NOT_REGISTERED);
				throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_638,
						env.getProperty(AuthenticationServiceConstants.AUTH_638));
			} else {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, AuthenticationServiceConstants.SINGLE_USER);
			}
		}
	
	@Override
	public TokenResponse login(UserLoginAccountRequestV2 userLoginRequest,HttpHeaders headers, ApplicantUtmBean applicantUtmBean) {
		TokenResponse token;
		long userId;
		short userType;
		
		String loginId=userLoginRequest.getLoginId();
		String dob = (( null != userLoginRequest.getDateOfBirth() && !userLoginRequest.getDateOfBirth().isEmpty()) ? userLoginRequest.getDateOfBirth() : null);
		Integer loginType = ( (null != userLoginRequest.getLoginType() && !userLoginRequest.getLoginType().isEmpty()) ? Integer.parseInt(userLoginRequest.getLoginType()) : null); 
		String pwd=userLoginRequest.getPassword();
		
		int userCount=authenticationServiceDao.checkLoginIdExistance(loginId, dob, loginType,userLoginRequest.getRtype());
		//changes end
		userType = AuthenticationServiceHelper.getUserType(userLoginRequest.getSource());
		
		ValidateUserRequest validateUserReq = new ValidateUserRequest();
		validateUserReq.setLoginId(loginId);
		validateUserReq.setLoginType(AuthenticationServiceConstants.LOGINACCTYPE_MOBILE_DOB_OTP_MPIN);
		validateUserReq.setPwd(pwd);
		validateUserReq.setUserType(userType);
		if(1<userCount) {
			AuthenticationServiceHelper.validateDate(userLoginRequest.getDateOfBirth(),logger, env);
			validateUserReq.setDateOfBirth(userLoginRequest.getDateOfBirth());
		}

		UserLoginAccountResponse response = this.validateManualLoginUser(validateUserReq, headers);
		userId = response.getUserId();

		if (userId == 0) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"authenticateManualLogin - No user found for - " + validateUserReq.getLoginId());
			throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_627,
					env.getProperty(AuthenticationServiceConstants.AUTH_627));
		}
		

		boolean failedRequest = response.isFailedRequest();
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
				"validateManualLoginUser request failed- " + failedRequest);

		Login login = new Login();
		login.setUsername(loginId);
		BfsdUser bfsdUser = new BfsdUser();
		bfsdUser.setUserkey(userId);
		login.setBfsdUser(bfsdUser);
		this.setLoginSrc(login, headers);

		if (failedRequest) {
			// update login activity in case of failure
			login.setPassword(pwd);
			asyncClass.updateLoginFailed(login);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "failure case - " + failedRequest);
			if (response.getAccountStatus() == AuthenticationServiceConstants.ISACTIVE) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"authenticateManualLogin - Account locked - " + validateUserReq.getLoginId());
				throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_019,
						env.getProperty(AuthenticationServiceConstants.AUTH_019));
			} else {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
						"authenticateManualLogin - Manual login failed for - " + validateUserReq.getLoginId());
				throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_018,
						env.getProperty(AuthenticationServiceConstants.AUTH_018));
			}
		} else {
			// update login activity in case of success
			asyncClass.updateLoginActivity(login);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "success case - " + failedRequest);
			if(null != response && loadFinegrainedUserProfile && response.getUserType()==1){//only for customer users
				finegrainAuthServiceImpl.loadUserProfile(response.getUserId());
			}
			token = this.getToken(loginId, userId, userType, headers);
		}
		// utm Horizontal-12
		try {
			long applicantId = authenticationServiceDao.getApplicantId(userId);
			applicantUtmBean.setApplicantKey(applicantId);
			saveApplicantUtmParam(applicantUtmBean);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Applicant UTM saving failed", e);
		}
		return token;
	}

	private void setLoginSrc(Login userLogin, HttpHeaders headers) {
		List<String> platforms = headers.get(AuthenticationServiceConstants.HEADER_PLATFORM);
		String platform = "";
		if (platforms != null && !platforms.isEmpty())
			platform = platforms.get(0) != null ? platforms.get(0) : "";
		userLogin.setLoginsrcwebapp(platform.equals(AuthenticationServiceConstants.PLATFORM_DESKTOP) ? "true" : "false");
	}

	@Override
	public ResponseBean autheticateMobileDobOtp(MobileDobOtpLoginRequest dobOtpLoginRequest) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "autheticateMobileDobOtp - started");
		MobileLoginRequest mobileLoginRequest = new MobileLoginRequest();
		final Integer pinLoginType = 8; 
		ResponseBean authenticateResponse;
		if(null!=dobOtpLoginRequest) {
			String loginId=dobOtpLoginRequest.getLoginId();
			String dob=dobOtpLoginRequest.getDateOfBirth();
			int userCount=authenticationServiceDao.checkLoginIdExistance(loginId, dob,  pinLoginType,dobOtpLoginRequest.getrType()); //change
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, MessageFormat.format("{0} user found for login id {1}", userCount,loginId));
			mobileLoginRequest.setMobile(loginId);
			mobileLoginRequest.setOtp(dobOtpLoginRequest.getOtp());
			if(1<userCount) {
				// if multiple user found for the same login id then dob is mandatory
				AuthenticationServiceHelper.validateDate(dob,logger, env);
				//if multiple user will found with same data then exception will be thrown
				authenticationServiceDao.validateUser(dobOtpLoginRequest.getLoginId(), dob, pinLoginType);
				mobileLoginRequest.setDateOfBirth(dob);
			}
			authenticateResponse=authenticateMobileDob(mobileLoginRequest);
		}else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,"Invalid or null request");
			throw new BFLBusinessException("AUTH_639", env.getProperty("AUTH_639"));
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "autheticateMobileDobOtp - Ends");
		return authenticateResponse;
	}
	
	@Override
	public ResponseBean loginWithOtp(UserLoginAccountRequestV2 userLoginRequest, ApplicantUtmBean applicantUtmBean) throws ParseException {
		String otpresponse="otpresponse";
		Timestamp dateOfBirth;
		ResponseBean responseBean;
		String dob = userLoginRequest.getDateOfBirth();
		String loginId=userLoginRequest.getLoginId();
		
		if(StringUtils.isEmpty(dob)) {
			dateOfBirth = authenticationServiceDao.getUserProfile(loginId);
			dob=AuthenticationServiceHelper.timeStampToStringDate(dateOfBirth);
		}else {
			Date date = new SimpleDateFormat("dd/MM/yyyy").parse(userLoginRequest.getDateOfBirth());
			dob = new SimpleDateFormat("yyyy-MM-dd").format(date);
		}
		loginId=loginId.concat("@").concat(dob);
		
		int userCount=authenticationServiceDao.checkLoginIdExistance(userLoginRequest.getLoginId(), dob, Integer.parseInt(userLoginRequest.getLoginType()),userLoginRequest.getRtype());
		if(1<userCount) {
			AuthenticationServiceHelper.validateDate(userLoginRequest.getDateOfBirth(),logger, env);
			//if multiple user will found with same data then exception will be thrown
			authenticationServiceDao.validateUser(loginId,dob,Integer.parseInt(userLoginRequest.getLoginType()));
		}
		HttpHeaders headersLogin = new HttpHeaders();
		headersLogin.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		JSONObject jsonRequest = new JSONObject();
		jsonRequest.put("mobile", userLoginRequest.getLoginId());
		jsonRequest.put("mfa",true);
		
		@SuppressWarnings("unchecked")
		ResponseEntity<ResponseBean> otpResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, otpGenerateUrl, null, ResponseBean.class, null,
						jsonRequest.toString(), headersLogin, null);
		
		if (otpResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(otpResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateMobileDob - Failed to generate OTP");
				responseBean = new ResponseBean(StatusCode.FAILURE);
				Map<String,Object> responseMap = new HashMap<>();
				responseMap.put("dob", dob);
				responseBean.setPayload(responseMap);
				responseBean.setErrorBean(otpResponse.getBody().getErrorBean());
				return responseBean;
			}
		} else if (otpResponse.getStatusCodeValue() == HttpStatus.BAD_REQUEST.value()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"authenticateMobileDob - invalid request sent to generate OTP");
			responseBean = new ResponseBean(StatusCode.FAILURE);
			Map<String,Object> responseMap = new HashMap<>();
			responseMap.put("dob", dob);
			responseBean.setErrorBean(otpResponse.getBody().getErrorBean());
			responseBean.setPayload(responseMap);
			return responseBean;
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"Invalid status recevied from OTP generate service -" + otpResponse.getStatusCodeValue());
			throw new BFLBusinessException("AUTH-000", env.getProperty("AUTH-000"));
		}

		responseBean = new ResponseBean(StatusCode.SUCCESS);
		Map<String,Object> responseMap = new HashMap<>();
		responseMap.put("dob", dob);
		responseMap.put(otpresponse,"Success");
		responseBean.setPayload(responseMap);
		
		return responseBean;
		
	}

	private boolean saveApplicantUtmParam(ApplicantUtmBean applicantUtmBean){
		try {
			ApplicantUtm applicantUtmRecord = new ApplicantUtm();
			int recVersion = getApplicantRecVersion(applicantUtmBean.getApplicantKey());
			ZonedDateTime currentTime1 = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
			Timestamp timestamp2 = Timestamp.from(currentTime1.toInstant());
			Timestamp currentTime = new Timestamp(System.currentTimeMillis());// need to check for time zone
			applicantUtmRecord.setApplicantkey(applicantUtmBean.getApplicantKey());
			applicantUtmRecord.setRecversion(recVersion);
			applicantUtmRecord.setUtmcampaign(applicantUtmBean.getApltUtmCampaign());
			applicantUtmRecord.setUtmcontent(applicantUtmBean.getApltUtmContent());
			applicantUtmRecord.setUtmmedium(applicantUtmBean.getApltUtmMedium());
			applicantUtmRecord.setUtmsource(applicantUtmBean.getApltUtmSource());
			applicantUtmRecord.setUtmterm(applicantUtmBean.getApltUtmTerm());
			applicantUtmRecord.setSourceplatform(applicantUtmBean.getSourcePlatform());
			applicantUtmRecord.setLstupdatedt(timestamp2);
			applicantUtmRecord.setEventtype(applicantUtmBean.getEventType());
			applicantUtmRecord.setLstupdateby(applicantUtmBean.getLastUpdateBy());
			applicantUtmRecord.setUseragent(applicantUtmBean.getUserAgent());
			authenticationServiceDao.saveApplicantUtm(applicantUtmRecord);
			return true; 
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while saving applicant level UTM parameters");
		}
		return false;
	}

	@Transactional
	private int getApplicantRecVersion(long applicantId) {
		try {
			int recVersion = authenticationServiceDao.getApplicantRecord(applicantId);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Rec Version fetched successfully");
			return recVersion;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"Error while fetching applicant record from APLT_UTM_PARAMETERS table");
		}
		return 0;
	}

	@SuppressWarnings("unchecked")
	public ResponseBean mobileAutoLogin(HttpHeaders headers) {
		try {
			ResponseBean responseBean=new ResponseBean();
			ApplicantDetailsBean applicantDetailsBean=new ApplicantDetailsBean(); 
			Gson gson = new Gson();
			//Calling Token Access Management Service to get AuthToken and GuardKey
			ResponseEntity<ResponseBean> tokenResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
					.invokeRestEndpoint(HttpMethod.GET, tokenUrl, null, ResponseBean.class, null, null, headers);
			logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "mobileAutoLogin - token response - " + gson.toJson(tokenResponse.getBody()));
			if(tokenResponse.getBody().getErrorBean()!=null) {
				throw new BFLTechnicalException("AUTH-017", env.getProperty("AUTH-017"));
			}
			String tokenBody=tokenResponse.getBody().getPayload().toString();
			TokensBean tokensBean=gson.fromJson(tokenBody, TokensBean.class);
			applicantDetailsBean.setAccessToken(tokensBean);
			String authToken= tokensBean.getToken();
			String guardKey = tokensBean.getGuardToken();
			String status = tokensBean.getStatus();
			if(StringUtils.isBlank(status) || !status.equalsIgnoreCase("VALID")){
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "mobileAutoLogin - invalid token - ");
				throw new BFLTechnicalException("AUTH-698", env.getProperty("AUTH-698"));
			}
			
			//Converting GuardKey to GaurdToken
			long curTime = Calendar.getInstance().getTimeInMillis();
			String guardTokenNew = salt + "|" + curTime + "|" + guardKey;
			String encryptedGuardToken = Base64.getEncoder().encodeToString(guardTokenNew.getBytes());
			
			//Setting new headers parameters for keys 
			HttpHeaders httpHeaders=new HttpHeaders();
			httpHeaders.set("authtoken", authToken);
			httpHeaders.set("guardtoken", encryptedGuardToken);
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			
			//Call to Keys API to get user/applicant/userApplicant keys from authToken and guardToken
			ResponseEntity<ResponseBean> keyResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
					.invokeRestEndpoint(HttpMethod.GET, keysUrl, null, ResponseBean.class, null, null, httpHeaders);
			logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "mobileAutoLogin - key response - " + gson.toJson(keyResponse.getBody()));
			if(keyResponse.getBody().getErrorBean()!=null) {
				throw new BFLTechnicalException("AUTH-697", env.getProperty("AUTH-697"));
			}
			String userKeys=keyResponse.getBody().getPayload().toString();
			UserKeysBean userKeysBean=gson.fromJson(userKeys, UserKeysBean.class);
			applicantDetailsBean.setKeys(userKeysBean);
			Long applicantKey = userKeysBean.getApplicantKey();
			
			ApplicantProfile applicantProfile = null;
			ResponseBean applicantResponseBean=authenticationServiceHelper.getApplicant(applicantKey,  httpHeaders);
			if (applicantResponseBean != null && applicantResponseBean.getPayload() != null) {
				applicantProfile = gson.fromJson(gson.toJson(applicantResponseBean.getPayload()),
						ApplicantProfile.class);
			} else if (applicantResponseBean != null && applicantResponseBean.getErrorBean() != null) {
				throw new BFLTechnicalException("AUTH-696", env.getProperty("AUTH-696"));
			}
	        String formattedDate = new SimpleDateFormat(AuthenticationServiceConstants.DOB_YYYY_MM_DD_FORMAT).format(applicantProfile.getDateOfBirth());
			
			MobileLoginRequest buildUserProfile = new MobileLoginRequest();
			buildUserProfile.setDateOfBirth(formattedDate);
			buildUserProfile.setMobile(applicantProfile.getMobileNumber().getNumber());
			tokenCodeHelper.callUserAdditionalDet(buildUserProfile, AuthenticationServiceConstants.USERTYPE_CUSTOMER, applicantKey);
			
			applicantDetailsBean.setDateOfBirth(formattedDate);
			applicantDetailsBean.setPinCode(applicantProfile.getPinCode());
			applicantDetailsBean.setGender(applicantProfile.getGender());
			applicantDetailsBean.setMaritalStatus(applicantProfile.getMaritalStatus());
			applicantDetailsBean.setFirstName(applicantProfile.getName().getFirstName());
			applicantDetailsBean.setMiddleName(applicantProfile.getName().getMiddleName());
			applicantDetailsBean.setLastName(applicantProfile.getName().getLastName());
			applicantDetailsBean.setNumber(applicantProfile.getMobileNumber().getNumber());
			
			responseBean.setPayload(applicantDetailsBean);
			responseBean.setStatus(StatusCode.SUCCESS);
			
			setAndSaveApplicantUtmParam(headers, applicantKey,AuthenticationServiceConstants.LAUNCH_EVENT);
			
			return responseBean;
		} catch (BFLTechnicalException  | BFLBusinessException | BFLHttpException e ) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "BFL  exception in mobile auto login - ");
			throw e;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,"Error while mobile auto login - ", e);
			throw new BFLTechnicalException("AUTH-700", env.getProperty("AUTH-700"));
		}
	}
	@Override
	public ResponseEntity<ResponseBean> ntpPreRegister(NtpPreRegisterRequest preRegisterRequest,String merchantCode,String hash, HttpHeaders headers) {
		
		Gson gson = new Gson();
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "In pre register - started - request : " + gson.toJson(preRegisterRequest));
		if (!StringUtils.isEmpty(merchantCode)) {
			String merchantSecret = env.getProperty(merchantCode);
			String hashValue=StringUtils.EMPTY;
			if (StringUtils.isNotBlank(merchantSecret)) {
				    hashValue = authenticationServiceHelper.doEncryptAndHash(merchantCode, merchantSecret,
						preRegisterRequest.getMobileNumber());
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "hashValue:" + hashValue);
			}
			if (StringUtils.isBlank(hashValue) || !hashValue.equals(hash)) {
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUT-401",
						"You are not Authorized to use this service");
			}

		}
		TokenResponse tokenResponse=authenticationServiceHelper.createToken(headers);
		if(null != tokenResponse && null != tokenResponse.getTokens() ) {
		Tokens tokens=tokenResponse.getTokens().get(0);
		headers.add("authtoken", tokens.getToken());
		}
		NtpPreRegisterResponse ntpPreRegisterResponse = new NtpPreRegisterResponse();
		ResponseBean responseBean;
		try {
			if(StringUtils.isBlank(preRegisterRequest.getDateOfBirth())) {
				throw new BFLTechnicalException("AUTH-707", env.getProperty("AUTH-707"));
			}
			if(StringUtils.isBlank(preRegisterRequest.getMobileNumber())) {
				throw new BFLTechnicalException("AUTH-006", env.getProperty("AUTH-006"));
			}
			String dob = null;
			String startDateString = preRegisterRequest.getDateOfBirth();
			java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy");
			java.time.format.DateTimeFormatter formatter2 = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");

			try {
				dob = LocalDate.parse(startDateString, formatter).format(formatter2);
			} catch (Exception e) {
				try {
					dob = LocalDate.parse(startDateString, formatter2).format(formatter2);
				} catch (Exception e1) {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
							"Invalid date of birth format.(Expected : dd-mm-yyyy or yyyy-mm-dd, Actual: "
									+ preRegisterRequest.getDateOfBirth() + ")", e);
					throw new BFLTechnicalException("AUTH_643", env.getProperty("AUTH_643"));
				}
			}

			ApplicantCreateRequest applicantCreateRequest = new ApplicantCreateRequest();
			applicantCreateRequest.setDateOfBirth(dob);
			MobileVerificationDet mobileVerificationDet = new MobileVerificationDet();
			mobileVerificationDet.setNumber(preRegisterRequest.getMobileNumber());
			applicantCreateRequest.setMobileNumber(mobileVerificationDet);
			
			NameVerificationDetails nameVerificationDet = new NameVerificationDetails();
			nameVerificationDet.setFirstName(preRegisterRequest.getFirstName());
			nameVerificationDet.setMiddleName(preRegisterRequest.getMiddleName());
			nameVerificationDet.setLastName(preRegisterRequest.getLastName());
			applicantCreateRequest.setName(nameVerificationDet);
			
			//Create Applicant
			ResponseBean applicantResponseBean = authenticationServiceHelper.createApplicant(applicantCreateRequest, headers);
			if (applicantResponseBean != null && applicantResponseBean.getPayload() != null) {
				ApplicantProfile applicantProfile = gson.fromJson(gson.toJson(applicantResponseBean.getPayload()),
						ApplicantProfile.class);
				ntpPreRegisterResponse.setApplicantKey(applicantProfile.getApplicantKey());
			} else if (applicantResponseBean != null && applicantResponseBean.getErrorBean() != null) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "In pre register - create applicant - failed : " + gson.toJson(applicantResponseBean));
				return new ResponseEntity<ResponseBean>(applicantResponseBean, HttpStatus.CONFLICT);
			}
			//Creating User and UserLogin Account
			UserLoginAccountRequestV4 userLoginAccountRequest = new UserLoginAccountRequestV4();
			String loginId = preRegisterRequest.getMobileNumber() + "@" + dob;
			userLoginAccountRequest.setLoginId(loginId);
			userLoginAccountRequest.setLoginType((short) 6);
			userLoginAccountRequest.setUserType((short) 1);
			ResponseBean createUserResponseBean = authenticationServiceHelper.createUserAndUserLoginAccount(userLoginAccountRequest, headers);
			if (createUserResponseBean != null && createUserResponseBean.getPayload() != null) {
				UserLoginAccountResponse userLoginAccountResponseObject = gson
					.fromJson(gson.toJson(createUserResponseBean.getPayload()), UserLoginAccountResponse.class);
				ntpPreRegisterResponse.setUserKey(userLoginAccountResponseObject.getUserId());
			} else if (createUserResponseBean != null && createUserResponseBean.getErrorBean() != null) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "In pre register - create user - failed : " + gson.toJson(createUserResponseBean));
				return new ResponseEntity<ResponseBean>(createUserResponseBean, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
			// Create userLoginAccount with loginAccountType 8 for CP login
			UserLoginAccountRequestV5 userLoginAccountMpin = new UserLoginAccountRequestV5();
			Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dob);

			userLoginAccountMpin.setDateOfBirth(date);
			userLoginAccountMpin.setFirstName(preRegisterRequest.getFirstName());
			userLoginAccountMpin.setLastName(preRegisterRequest.getLastName());
			userLoginAccountMpin.setLoginId(preRegisterRequest.getMobileNumber());
			userLoginAccountMpin.setMobile(preRegisterRequest.getMobileNumber());
			userLoginAccountMpin.setUserKey(ntpPreRegisterResponse.getUserKey());
			authenticationServiceHelper.createMpinUserLoginAccount(userLoginAccountMpin, headers);

			//User Applicant Mapping
			UserKeysBean userApplicantBean=new UserKeysBean();
			userApplicantBean.setApplicantKey(ntpPreRegisterResponse.getApplicantKey());
			userApplicantBean.setUserKey(ntpPreRegisterResponse.getUserKey());
			ResponseBean userApplicantResponseBean = authenticationServiceHelper.getUserApplicantKey(userApplicantBean, headers);
			if (userApplicantResponseBean != null && userApplicantResponseBean.getPayload() != null) {
				userApplicantBean = gson.fromJson(gson.toJson(userApplicantResponseBean.getPayload()),
						UserKeysBean.class);
				ntpPreRegisterResponse.setUserApplicantKey(userApplicantBean.getUserApplicantKey());
			} else if (userApplicantResponseBean != null && userApplicantResponseBean.getErrorBean() != null) {
				return new ResponseEntity<ResponseBean>(userApplicantResponseBean, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
			//Save Email for Applicant Key
			if(StringUtils.isNotBlank(preRegisterRequest.getEmailId())) {
				try {
					ApplicantEmailBean applicantEmailBean=new ApplicantEmailBean();
					applicantEmailBean.setApplicantKey(ntpPreRegisterResponse.getApplicantKey());
					applicantEmailBean.setEmailAddress(preRegisterRequest.getEmailId());
					applicantEmailBean.setType("70");
					applicantEmailBean.setIsVerified(BigDecimal.ZERO);
					applicantEmailBean.setIdPriority(BigDecimal.ONE);
					authenticationServiceHelper.saveEmailForApplicantKey(applicantEmailBean, headers);
				} catch (Exception e) {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while saving email - ", e);
					throw new BFLTechnicalException("AUTH-699", env.getProperty("AUTH-699")); 
				}
			}
		} catch (BFLBusinessException | BFLTechnicalException e) {
			throw e;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while pre register - ", e);
			throw new BFLTechnicalException("AUTH-701", env.getProperty("AUTH-701"));
		}
		if (StringUtils.isNotBlank(preRegisterRequest.getFirstName()))
			ntpPreRegisterResponse.setFirstName(preRegisterRequest.getFirstName());
		if (StringUtils.isNotBlank(preRegisterRequest.getLastName()))
			ntpPreRegisterResponse.setLastName(preRegisterRequest.getLastName());
		if (StringUtils.isNotBlank(preRegisterRequest.getMobileNumber()))
			ntpPreRegisterResponse.setMobileNumber(preRegisterRequest.getMobileNumber());
		if (StringUtils.isNotBlank(preRegisterRequest.getDateOfBirth()))
			ntpPreRegisterResponse.setDateOfBirth(preRegisterRequest.getDateOfBirth());
		if (StringUtils.isNotBlank(preRegisterRequest.getCustomerType()))
			ntpPreRegisterResponse.setCustomerType(preRegisterRequest.getCustomerType());
		if (StringUtils.isNotBlank(preRegisterRequest.getCustomerReferenceID()))
			ntpPreRegisterResponse.setCustomerReferenceID(preRegisterRequest.getCustomerReferenceID());
		
		responseBean = new ResponseBean(ntpPreRegisterResponse);
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "In pre register - completed - final response : " + gson.toJson(responseBean));
		return new ResponseEntity<ResponseBean>(responseBean, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ResponseBean> ntpPreProcess(NtpPreProcessRequest ntpPreProcessRequest, HttpHeaders headers) {

		//Save Utm Parameters
		try {
			setAndSaveApplicantUtmParam(headers, ntpPreProcessRequest.getApplicantKey(),null);
		} catch(Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while sabing utm paramter", e);
		}

		Long applicantKey=ntpPreProcessRequest.getApplicantKey();
		ResponseBean responseBean=null;
		Gson gson = new Gson();
		String flowType=headers.getFirst("flowtype");
		if (StringUtils.isBlank(flowType)) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Flow type is missing in request header. This will skip FHCR call.");
		}

		ApplicantProfile applicantProfile = null;
		ApplicantEmailDetails[] applicantEmailDetailsList=null;
		ApplicationRequestBean applicationRequestBean=new ApplicationRequestBean();
		BeanUtils.copyProperties(ntpPreProcessRequest, applicationRequestBean);
		String mobileNumber = StringUtils.EMPTY;
		try {
			//Get Applicant Data from Applicant Key
			ResponseBean applicantResponseBean=authenticationServiceHelper.getApplicant(applicantKey,  headers);
			if (applicantResponseBean != null && applicantResponseBean.getPayload() != null) {
				applicantProfile = gson.fromJson(gson.toJson(applicantResponseBean.getPayload()),
						ApplicantProfile.class);
			} else if (applicantResponseBean != null && applicantResponseBean.getErrorBean() != null) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "In pre process - get applicant - failed : " + gson.toJson(applicantResponseBean.getErrorBean()));
				return new ResponseEntity<ResponseBean>(applicantResponseBean, HttpStatus.INTERNAL_SERVER_ERROR);
			}

			mobileNumber = applicantProfile.getMobileNumber().getNumber();
			
			if(StringUtils.isNotBlank(flowType) && flowType.equalsIgnoreCase("FHCR")) {
				
				// Get Email Id from Applicant Key
				ResponseBean applicantEmailResponseBean = authenticationServiceHelper.getEmailForApplicantKey(applicantKey, headers);
				if (applicantEmailResponseBean.getStatus().equals(StatusCode.SUCCESS)) {
					applicantEmailDetailsList = gson.fromJson(applicantEmailResponseBean.getPayload().toString(),
							ApplicantEmailDetails[].class);
				} else if (applicantEmailResponseBean.getStatus().equals(StatusCode.FAILURE)) {
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "In pre process - get applicant email - failed : " + gson.toJson(applicantEmailResponseBean));
					//return new ResponseEntity<ResponseBean>(applicantEmailResponseBean, HttpStatus.INTERNAL_SERVER_ERROR);
				}
								
				//Create FHCR Initiate Request
				SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
				String dob = df2.format(applicantProfile.getDateOfBirth());
				applicationRequestBean.setDateOfBirth(dob);
				applicationRequestBean.setFirstName(applicantProfile.getName().getFirstName());
				applicationRequestBean.setLastName(applicantProfile.getName().getLastName());
				applicationRequestBean.setMobileNumber(mobileNumber);

				applicationRequestBean.setPanNumber(ntpPreProcessRequest.getPanNumber());
				applicationRequestBean.setPinCode(ntpPreProcessRequest.getPinCode());

				if(applicantEmailDetailsList!=null) {	
					applicationRequestBean.setEmailId(applicantEmailDetailsList[0].getEmailDetail());
				} else {
					applicationRequestBean.setEmailId("sample@bajajfinserv.in");
				}
				
				//hardcoded - since not available in request but required in FHCR request
				applicationRequestBean.setOccupationType("salaried");

				if(StringUtils.isNotBlank(headers.getFirst("utm_campaign")))
					applicationRequestBean.setAppUtmCampaign(headers.getFirst("utm_campaign"));

				if(StringUtils.isNotBlank(headers.getFirst("utm_content")))
					applicationRequestBean.setAppUtmContent(headers.getFirst("utm_content"));

				if(StringUtils.isNotBlank(headers.getFirst("utm_medium")))
					applicationRequestBean.setAppUtmMedium(headers.getFirst("utm_medium"));

				if(StringUtils.isNotBlank(headers.getFirst("utm_source")))
					applicationRequestBean.setAppUtmSource(headers.getFirst("utm_source"));

				if(StringUtils.isNotBlank(headers.getFirst("utm_term")))
					applicationRequestBean.setAppUtmTerm(headers.getFirst("utm_term"));

				if(StringUtils.isNotBlank(headers.getFirst("app_source"))) {
					applicationRequestBean.setAppSource(headers.getFirst("app_source"));
				} else {
					applicationRequestBean.setAppSource("Mobile");
				}
				
				responseBean=authenticationServiceHelper.triggerCibilOtp(applicationRequestBean, headers);
			}

			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "In pre process - flow type is bfdl - trying bfdl otp");

			responseBean=authenticationServiceHelper.triggerBfldOtp( mobileNumber, headers);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "In pre process - trigger bfdl otp success.");
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.set("flowtype", flowType);
			return new ResponseEntity<ResponseBean>(responseBean, responseHeaders, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error in pre process - trigger bdfl otp also failed.", e);
			throw new BFLTechnicalException("AUTH-702", env.getProperty("AUTH-702"));
		}
	}
	

	@Override
	public ResponseEntity<ResponseBean> ntpLogin(NtpLoginRequest ntpLoginRequest, HttpHeaders headers) {
		
		//Save Utm Parameters
		try {
			setAndSaveApplicantUtmParam(headers, ntpLoginRequest.getApplicantKey(),null);
		} catch(Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while sabing utm paramter", e);
		}
		
		Gson gson = new Gson();
		ResponseBean responseBean = new ResponseBean();
		
		Long userKey=null;
		try {
			//Get Applicant Details
			ResponseBean applicantResponseBean=authenticationServiceHelper.getApplicant(ntpLoginRequest.getApplicantKey(),  headers);
			ApplicantProfile applicantProfile=null;
			if (applicantResponseBean != null && applicantResponseBean.getPayload() != null) {
				applicantProfile = gson.fromJson(gson.toJson(applicantResponseBean.getPayload()),
						ApplicantProfile.class);
			} else if (applicantResponseBean != null && applicantResponseBean.getErrorBean() != null) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error getting applicant data in ntp login" + gson.toJson(applicantResponseBean.getErrorBean()));
				return new ResponseEntity<ResponseBean>(applicantResponseBean, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
			//Get User Key Mapping
			UserKeysBean userApplicantBean=new UserKeysBean();
			userApplicantBean.setApplicantKey(applicantProfile.getApplicantKey());
			ResponseBean userApplicantResponseBean = authenticationServiceHelper.getUserApplicantKey(userApplicantBean, headers);
			if (userApplicantResponseBean != null && userApplicantResponseBean.getPayload() != null) {
				userApplicantBean = gson.fromJson(gson.toJson(userApplicantResponseBean.getPayload()),
						UserKeysBean.class);
				userKey=userApplicantBean.getUserKey();
			} else if (userApplicantResponseBean != null && userApplicantResponseBean.getErrorBean() != null) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error getting user data in ntp login" + gson.toJson(userApplicantResponseBean.getErrorBean()));
				return new ResponseEntity<ResponseBean>(userApplicantResponseBean, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
			ValidateOTP validateOTP=new ValidateOTP();
			validateOTP.setMobile(applicantProfile.getMobileNumber().getNumber());
			validateOTP.setOtp(ntpLoginRequest.getOtp());
			ResponseBean responseBeanBfdl=authenticationServiceHelper.validateBfdlOtp(validateOTP,headers);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "In ntp login - validate bfdl otp response - " + gson.toJson(responseBeanBfdl));
			if(responseBeanBfdl.getErrorBean()==null) {
				headers.add("platform", "mob");//Added to get refresh token along with customer token
				TokenResponse tokenResponse=this.getToken(applicantProfile.getMobileNumber().getNumber(), userKey, (short) 1, headers);
				List<Tokens> tokenBeanList=tokenResponse.getTokens();
				responseBean.setPayload(tokenBeanList);
				responseBean.setStatus(StatusCode.SUCCESS);
				HttpHeaders responseHeaders = new HttpHeaders();
				return new ResponseEntity<ResponseBean>(responseBean, responseHeaders, HttpStatus.OK);
			} else {
				List<ErrorBean> errorBeans=new ArrayList<ErrorBean>();
				ErrorBean errorBean=new ErrorBean();
				errorBean.setErrorCode("AUTH_630");
				errorBean.setErrorMessage(env.getProperty("AUTH_630"));
				errorBeans.add(errorBean);
				responseBeanBfdl.setErrorBean(errorBeans);
				responseBeanBfdl.setStatus(StatusCode.FAILURE);
				responseBeanBfdl.setPayload(null);
				HttpHeaders responseHeaders = new HttpHeaders();
				return new ResponseEntity<ResponseBean>(responseBeanBfdl, responseHeaders, HttpStatus.OK); 
			}
		} catch (BFLBusinessException | BFLTechnicalException e) {
			throw e;
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while ntp login - opt validation failed - ", e);
			throw new BFLTechnicalException("AUTH-703", env.getProperty("AUTH-703"));
		}
	}
	public void setAndSaveApplicantUtmParam(HttpHeaders headers,Long applicantKey, String eventType) {
		
		ApplicantUtmBean applicantUtmBean = new ApplicantUtmBean();
		
		if(StringUtils.isNotBlank(headers.getFirst("utm_campaign")))
			applicantUtmBean.setApltUtmCampaign(headers.getFirst("utm_campaign"));
		
		if(StringUtils.isNotBlank(headers.getFirst("utm_content")))
			applicantUtmBean.setApltUtmContent(headers.getFirst("utm_content"));
		
		if(StringUtils.isNotBlank(headers.getFirst("utm_medium")))
			applicantUtmBean.setApltUtmMedium(headers.getFirst("utm_medium"));
		else
			applicantUtmBean.setApltUtmMedium("Organic");
		
		if(StringUtils.isNotBlank(headers.getFirst("utm_source")))
			applicantUtmBean.setApltUtmSource(headers.getFirst("utm_source"));
		else
			applicantUtmBean.setApltUtmSource("Organic");
		
		if(StringUtils.isNotBlank(headers.getFirst("utm_term")))
			applicantUtmBean.setApltUtmTerm(headers.getFirst("utm_term"));
		
		if(StringUtils.isNotBlank(headers.getFirst("app_source"))) 
			applicantUtmBean.setSourcePlatform(headers.getFirst("app_source"));
		else
			applicantUtmBean.setSourcePlatform(headers.getFirst("appSource"));
		
		if(StringUtils.isNotBlank(headers.getFirst("platform"))) {
			applicantUtmBean.setLastUpdateBy(headers.getFirst("platform"));
		}
		applicantUtmBean.setApplicantKey(applicantKey);
		
		if (StringUtils.isNotBlank(eventType)) {
			applicantUtmBean.setEventType(eventType);
		}
		if(StringUtils.isNotBlank(headers.getFirst("user_agent"))) {
			applicantUtmBean.setUserAgent(headers.getFirst("user_agent"));
		}
		saveApplicantUtmParam(applicantUtmBean);
		
	}

	public void setAndSaveApplicantUtmParam(HttpHeaders headers, UtmParameters utmParameters, Long applicantKey) {

		ApplicantUtmBean applicantUtmBean = new ApplicantUtmBean();
		applicantUtmBean.setApltUtmCampaign(utmParameters.getUtmCampaign());
		applicantUtmBean.setApltUtmContent(utmParameters.getUtmContent());
		applicantUtmBean.setApltUtmMedium(utmParameters.getUtmMedium());
		applicantUtmBean.setApltUtmSource(utmParameters.getUtmSource());
		applicantUtmBean.setApltUtmTerm(utmParameters.getUtmTerm());
		applicantUtmBean.setApltUtmSource(utmParameters.getUtmSource());

		if(StringUtils.isNotBlank(headers.getFirst("app_source"))) 
			applicantUtmBean.setSourcePlatform(headers.getFirst("app_source"));
		else
			applicantUtmBean.setSourcePlatform(headers.getFirst("appSource"));
		
		if(StringUtils.isNotBlank(headers.getFirst("platform")))
			applicantUtmBean.setLastUpdateBy(headers.getFirst("platform"));

		applicantUtmBean.setApplicantKey(applicantKey);

		saveApplicantUtmParam(applicantUtmBean);

	}
}