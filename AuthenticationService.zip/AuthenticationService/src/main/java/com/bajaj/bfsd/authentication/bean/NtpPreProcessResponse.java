package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class NtpPreProcessResponse implements Serializable {

	private static final long serialVersionUID = 5800041845223591987L;

	private boolean mfa;
	private String mobile;
	private String otp;
	private String generateTime;
	private String validMins;
	private int validationCount;
	private int retryCount;
	private Long expitationTime;
	private boolean validationBlocked;

	public boolean isMfa() {
		return mfa;
	}

	public void setMfa(boolean mfa) {
		this.mfa = mfa;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getGenerateTime() {
		return generateTime;
	}

	public void setGenerateTime(String generateTime) {
		this.generateTime = generateTime;
	}

	public String getValidMins() {
		return validMins;
	}

	public void setValidMins(String validMins) {
		this.validMins = validMins;
	}

	public int getValidationCount() {
		return validationCount;
	}

	public void setValidationCount(int validationCount) {
		this.validationCount = validationCount;
	}

	public int getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}

	public Long getExpitationTime() {
		return expitationTime;
	}

	public void setExpitationTime(Long expitationTime) {
		this.expitationTime = expitationTime;
	}

	public boolean isValidationBlocked() {
		return validationBlocked;
	}

	public void setValidationBlocked(boolean validationBlocked) {
		this.validationBlocked = validationBlocked;
	}

}
