package com.bajaj.bfsd.authentication.model;

public class SocialAuthorizationToken {

	private String socialAuthToken;
	
	public String getSocialAuthToken() {
		return socialAuthToken;
	}

	public void setSocialAuthToken(String socialAuthToken) {
		this.socialAuthToken = socialAuthToken;
	}


	@Override
	public String toString() {
		return "SocialAuthorizationToken [socialAuthToken=" + socialAuthToken + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((socialAuthToken == null) ? 0 : socialAuthToken.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SocialAuthorizationToken other = (SocialAuthorizationToken) obj;
		if (socialAuthToken == null) {
			if (other.socialAuthToken != null)
				return false;
		} else if (!socialAuthToken.equals(other.socialAuthToken))
			return false;
		return true;
	}

	
}
