package com.bajaj.bfsd.authentication.controller;

import java.util.List;
import java.util.UUID;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeRequest;
import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeResponse;
import com.bajaj.bfsd.authentication.bean.FederatedLoginRequest;
import com.bajaj.bfsd.authentication.bean.FederatedLoginResponse;
import com.bajaj.bfsd.authentication.bean.FederatedTokenRequest;
import com.bajaj.bfsd.authentication.bean.FederatedTokenResponse;
import com.bajaj.bfsd.authentication.bean.FederatedUserRegisterRequest;
import com.bajaj.bfsd.authentication.bean.FederatedUserRegisterResponse;
import com.bajaj.bfsd.authentication.bean.HashGeneratorRequest;
import com.bajaj.bfsd.authentication.bean.HashValueResponse;
import com.bajaj.bfsd.authentication.service.FederatedAuthService;
import com.bajaj.bfsd.authentication.util.PasswordEncoderUtils;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLHttpException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RefreshScope
public class FederatedAuthController {

	private static final String CLASS_NAME = FederatedAuthController.class.getCanonicalName();
	
	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private FederatedAuthService federatedAuthService;
	
	@ApiOperation(value = "Authenticate calling client app,validate and issue new authorization Code", notes = "Authenticate calling client app,validae and issue new authorization Code", httpMethod = "POST", response = ResponseBean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = FederatedLoginResponseBean.class),
			@ApiResponse(code = 400, message = "Validations Failed - Invalid request due to missing mandatory fields", response = ResponseBean.class),
			@ApiResponse(code = 401, message = "Authentication Failed – Invalid client_id or client_secret", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Request Processing Failed – Unknown system issue", response = ResponseBean.class) })
	@PostMapping(value = "${api.authentication.federatedlogin.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> federatedLogin(@Valid @RequestBody FederatedLoginRequest federatedLoginRequest,
			BindingResult bindingResult) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Authenticate clientValidationRequest: " + federatedLoginRequest);
		if (bindingResult.hasErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Validations Failed - Invalid request due to missing mandatory fields in Request"
							+ federatedLoginRequest);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		FederatedLoginResponse federatedLoginResponse = federatedAuthService.clientValidation(federatedLoginRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Authenticate clientValidationRequest end with Response:" + federatedLoginResponse);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(federatedLoginResponse);
		responseBean.setStatus(StatusCode.SUCCESS);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	@ApiOperation(value = "Validation authorization code,process sign request,and issue new token for relying application", notes = "Validation authorization code,process sign request,and issue new token for relying application", httpMethod = "POST", response = ResponseBean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = FederatedAuthorizeResponseBean.class),
			@ApiResponse(code = 400, message = "Validations Failed - Invalid request due to missing mandatory fields", response = ResponseBean.class),
			@ApiResponse(code = 401, message = "Authorization code expired or invalid or already consumed before", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Request Processing Failed – Unknown system issue", response = ResponseBean.class) })
	@PostMapping(value = "${api.authentication.federatedauthorize.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> validateAuthCode(@Valid @RequestBody FederatedAuthorizeRequest federatedAuthorizeRequest,
			BindingResult bindingResult) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"validateAuthCode Request: " + federatedAuthorizeRequest);
		if (bindingResult.hasErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Validations Failed - Invalid request due to missing mandatory fields for Request"
							+ federatedAuthorizeRequest);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}

		FederatedAuthorizeResponse federatedAuthorizeResponse = federatedAuthService
				.validateAuthorization(federatedAuthorizeRequest);

		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
				"validateAuthCode end with response" + federatedAuthorizeResponse);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(federatedAuthorizeResponse);
		responseBean.setStatus(StatusCode.SUCCESS);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);

	}

	@ApiOperation(value = "Hash Generator ", notes = "Hash Generator", httpMethod = "POST", response = ResponseBean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = HashValueResponseBean.class),
			@ApiResponse(code = 400, message = "Validations Failed - Invalid request due to missing mandatory fields", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Request Processing Failed – Unknown system issue", response = ResponseBean.class) })
	@PostMapping(value = "/v1/federated/hashgenerator", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> generateHashValue(@Valid @RequestBody HashGeneratorRequest hashGeneratorRequest,
			BindingResult bindingResult) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"generateHashValue started with hashGeneratorRequest: " + hashGeneratorRequest);
		if (bindingResult.hasErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Validations Failed - Invalid request due to missing mandatory fields for Request"
							+ hashGeneratorRequest);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		HashValueResponse hashValueResponse = new HashValueResponse();
		String encodeHashValue = PasswordEncoderUtils.encode(hashGeneratorRequest.getText());
		hashValueResponse.setEncodedHashValue(encodeHashValue);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"generateHashValue ended with response" + hashValueResponse);
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(hashValueResponse);
		responseBean.setStatus(StatusCode.SUCCESS);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Federated Token", notes = "Federated Token Generator", httpMethod = "POST", response = ResponseBean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = FederatedTokenResponseBean.class),
			@ApiResponse(code = 400, message = "Validations Failed - Invalid request due to missing mandatory fields", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Request Processing Failed – Unknown system issue", response = ResponseBean.class) })
	@PostMapping(value = "${api.authentication.federatedtoken.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> getFederatedTokenCodes(@Valid @RequestBody FederatedTokenRequest federatedTokenRequest, BindingResult bindingResult,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "getFederatedAuthToken: " + federatedTokenRequest);
		if (bindingResult.hasErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Validations Failed - Invalid request due to missing mandatory fields for Request"
							+ federatedTokenRequest);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		FederatedTokenResponse tokenCodes = federatedAuthService.generateTokens(federatedTokenRequest, headers.getFirst("cmptcorrid"));
		ResponseBean responseBean = new ResponseBean();
		responseBean.setPayload(tokenCodes);
		responseBean.setStatus(StatusCode.SUCCESS);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Federated User Registration", notes = "Validate authorization code, validate mobile from cache claims, register applicant & user (if not existing), and return appropriate tokens", httpMethod = "POST", response = ResponseBean.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "app_source", required = false, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "utm_source", required = false, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "utm_medium", required = false, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "utm_campaign", required = false, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "utm_term", required = false, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "utm_content", required = false, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "cmptcorrid", required = false, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "user_agent", required = false, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "platform", required = false, dataType = "string", paramType = "header")
	})
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = FederatedUserRegisterResponse.class),
			@ApiResponse(code = 400, message = "Validations Failed - Invalid request due to missing mandatory fields", response = ResponseBean.class),
			@ApiResponse(code = 401, message = "Authentication Failed – Invalid authorization code", response = ResponseBean.class),
			@ApiResponse(code = 403, message = "Forbidden – Invalid registration request", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Request Processing Failed – Unknown system issue", response = ResponseBean.class) })
	@PostMapping(value = "${api.authentication.federatedusersregister.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FederatedUserRegisterResponse> userRegistration(@Valid @RequestBody FederatedUserRegisterRequest federatedUserRegister,
			BindingResult bindingResult, @RequestHeader HttpHeaders headers) {
		if (StringUtils.isBlank(headers.getFirst("cmptcorrid"))) {
			headers.set("cmptcorrid", UUID.randomUUID().toString());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"cmptcorrid: " + headers.getFirst("cmptcorrid") + ", userRegistration: " + federatedUserRegister);
		if (bindingResult.hasErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Validations Failed - Invalid request due to missing mandatory fields for Request"
							+ federatedUserRegister);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		federatedAuthService.populateFederatedUserRegisterUtmHeaders(headers, federatedUserRegister.getClientId());
		FederatedUserRegisterResponse registerUser = federatedAuthService.registerUser(federatedUserRegister,
				headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"cmptcorrid: " + headers.getFirst("cmptcorrid") + ", userRegistration response: " + registerUser);
		return new ResponseEntity<>(registerUser, HttpStatus.OK);
	}
	
	
	//Note this Static Nested Class has been done for swagger documentation purpose only
	private static class FederatedTokenResponseBean{
		
		public FederatedTokenResponse getPayload() {
			return null;
		}
		public StatusCode getStatus() {
			return null;
		}
		public List<ErrorBean> getErrorBeans() {
			return null;
		}
	}
	
	private static class FederatedLoginResponseBean{
		
		public FederatedLoginResponse getPayload() {
			return null;
		}
		public StatusCode getStatus() {
			return null;
		}
		public List<ErrorBean> getErrorBeans() {
			return null;
		}
	}
	
	private static class FederatedAuthorizeResponseBean{
		
		public FederatedAuthorizeResponse getPayload() {
			return null;
		}
		public StatusCode getStatus() {
			return null;
		}
		public List<ErrorBean> getErrorBeans() {
			return null;
		}
	}
	
	private static class HashValueResponseBean{
		
		public HashValueResponse getPayload() {
			return null;
		}
		public StatusCode getStatus() {
			return null;
		}
		public List<ErrorBean> getErrorBeans() {
			return null;
		}
	}
	
}
