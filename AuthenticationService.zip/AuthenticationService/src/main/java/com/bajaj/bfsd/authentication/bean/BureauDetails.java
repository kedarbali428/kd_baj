package com.bajaj.bfsd.authentication.bean;

public class BureauDetails {

	private PanDetailsBean pan;
	
	public PanDetailsBean getPan() {
		return pan;
	}
	public void setPan(PanDetailsBean pan) {
		this.pan = pan;
	}
	
	

}
