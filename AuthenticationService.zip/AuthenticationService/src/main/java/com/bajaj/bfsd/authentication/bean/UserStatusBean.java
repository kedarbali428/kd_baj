package com.bajaj.bfsd.authentication.bean;

public class UserStatusBean {

	private String etp;
	private String bureau;
	private String prospect;
	
	public String getEtp() {
		return etp;
	}
	
	public void setEtp(String etp) {
		this.etp = etp;
	}
	
	public String getBureau() {
		return bureau;
	}
	
	public void setBureau(String bureau) {
		this.bureau = bureau;
	}
	
	public String getProspect() {
		return prospect;
	}
	
	public void setProspect(String prospect) {
		this.prospect = prospect;
	}
	
	@Override
	public String toString() {
		return "UserStatusBean [etp=" + etp + ", bureau=" + bureau + ", prospect=" + prospect + "]";
	}
	

}
