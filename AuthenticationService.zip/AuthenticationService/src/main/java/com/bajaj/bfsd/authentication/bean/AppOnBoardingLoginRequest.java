package com.bajaj.bfsd.authentication.bean;

import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.DOB_DD_MM_UUUU_HYPHENFORMAT;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

import com.bajaj.bfsd.authentication.bean.annotations.BoundedDateFormatsValidation;

public class AppOnBoardingLoginRequest{
	
	@NotNull(message = "AUTH_020")
	@Pattern(regexp = "^[6-9]\\d{9}$", message = "AUTH-441")
	private String mobileNumber;
	
	@BoundedDateFormatsValidation(message = "AUTH_640", formats = {DOB_DD_MM_UUUU_HYPHENFORMAT},
			optional = false, lowerBoundYear = 1900)
	private String dateOfBirth;
	
	@NotBlank(message = "AUTH_630")
	private String otp;
	
	@NotBlank(message = "AUTH-711")
	private String source;
	private UserStatusBean userStatus;
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getOtp() {
		return otp;
	}
	
	public void setOtp(String otp) {
		this.otp = otp;
	}
	
	public UserStatusBean getUserStatus() {
		return userStatus;
	}
	
	public void setUserStatus(UserStatusBean userStatus) {
		this.userStatus = userStatus;
	}
	
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
	
	@Override
	public String toString() {
		return "AppOnBoardingLoginRequest [mobileNumber=" + mobileNumber + ", dateOfBirth=" + dateOfBirth
				+ ", otp=" + otp + ", source=" + source + ", userStatus=" + userStatus + "]";
	}

}
