package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class ApplicantPhoneNumberDetailsBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@NotNull(message="Phone Number can not be null")
	private String mobileNumber;
	@NotNull(message="Phone Type can not be null")
	private String type;
	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	


}
