package com.bajaj.bfsd.authentication.bean;

public class UserResponse {

	private Long userId;
	private short userType;
	private String loginId;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public short getUserType() {
		return userType;
	}

	public void setUserType(short userType) {
		this.userType = userType;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	@Override
	public String toString() {
		return "UserResponse [userId=" + userId + ", userType=" + userType + ", loginId=" + loginId + "]";
	}

}
