package com.bajaj.bfsd.authentication.bean;

import org.hibernate.validator.constraints.Email;

public class ApplicantEmailDetails {
@Email(message = "Email should be valid")
private String emailDetail;
private String verificationflg;
private String verificationsrc;
public String getEmailDetail() {
	return emailDetail;
}
public void setEmailDetail(String emailDetail) {
	this.emailDetail = emailDetail;
}
public String getVerificationflg() {
	return verificationflg;
}
public void setVerificationflg(String verificationflg) {
	this.verificationflg = verificationflg;
}
public String getVerificationsrc() {
	return verificationsrc;
}
public void setVerificationsrc(String verificationsrc) {
	this.verificationsrc = verificationsrc;
}

}
