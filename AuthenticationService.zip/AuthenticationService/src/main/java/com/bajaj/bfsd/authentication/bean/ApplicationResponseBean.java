package com.bajaj.bfsd.authentication.bean;

public class ApplicationResponseBean {
 
	private String message;
	private long applicationId;
	private long applicantId;
	private String reportUrl;
	private String queueName;
	private String questionKey;
	private String answerKey;
	private String userInputAnswer;
	private Boolean resendEligible;
	private Boolean skipEligible;
	private Boolean resendOTP; 
	private boolean cibilVerifyFlag;
	private String challengeConfigGUID;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}
	public long getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(long applicantId) {
		this.applicantId = applicantId;
	}
	public String getReportUrl() {
		return reportUrl;
	}
	public void setReportUrl(String reportUrl) {
		this.reportUrl = reportUrl;
	}
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public String getQuestionKey() {
		return questionKey;
	}
	public void setQuestionKey(String questionKey) {
		this.questionKey = questionKey;
	}
	public String getAnswerKey() {
		return answerKey;
	}
	public void setAnswerKey(String answerKey) {
		this.answerKey = answerKey;
	}
	public String getUserInputAnswer() {
		return userInputAnswer;
	}
	public void setUserInputAnswer(String userInputAnswer) {
		this.userInputAnswer = userInputAnswer;
	}
	public Boolean getResendEligible() {
		return resendEligible;
	}
	public void setResendEligible(Boolean resendEligible) {
		this.resendEligible = resendEligible;
	}
	public Boolean getSkipEligible() {
		return skipEligible;
	}
	public void setSkipEligible(Boolean skipEligible) {
		this.skipEligible = skipEligible;
	}
	public Boolean getResendOTP() {
		return resendOTP;
	}
	public void setResendOTP(Boolean resendOTP) {
		this.resendOTP = resendOTP;
	}
	public boolean isCibilVerifyFlag() {
		return cibilVerifyFlag;
	}
	public void setCibilVerifyFlag(boolean cibilVerifyFlag) {
		this.cibilVerifyFlag = cibilVerifyFlag;
	}
	public String getChallengeConfigGUID() {
		return challengeConfigGUID;
	}
	public void setChallengeConfigGUID(String challengeConfigGUID) {
		this.challengeConfigGUID = challengeConfigGUID;
	}
	@Override
	public String toString() {
		return "ApplicationResponseBean [message=" + message + ", applicationId=" + applicationId + ", applicantId="
				+ applicantId + ", reportUrl=" + reportUrl + ", queueName=" + queueName + ", questionKey=" + questionKey
				+ ", answerKey=" + answerKey + ", userInputAnswer=" + userInputAnswer + ", resendEligible="
				+ resendEligible + ", skipEligible=" + skipEligible + ", resendOTP=" + resendOTP + ", cibilVerifyFlag="
				+ cibilVerifyFlag + ", challengeConfigGUID=" + challengeConfigGUID + "]";
	}
	
	
	
}
