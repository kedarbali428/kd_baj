package com.bajaj.bfsd.authentication.bean;

public class UpdateMobileAppOnBoardingRequest {

	private Long applicantId;
	
	private Boolean skipFlag;
	
	public Long getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}
	public Boolean isSkipFlag() {
		return skipFlag;
	}
	public void setSkipFlag(Boolean skipFlag) {
		this.skipFlag = skipFlag;
	}
	@Override
	public String toString() {
		return "UpdateMobileAppOnBoardingRequest [applicantId=" + applicantId + ", skipFlag=" + skipFlag + "]";
	}
	
}
