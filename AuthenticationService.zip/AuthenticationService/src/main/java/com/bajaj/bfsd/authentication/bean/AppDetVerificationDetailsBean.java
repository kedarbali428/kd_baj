package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class AppDetVerificationDetailsBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fieldlabel;
	private String verificationsrc;
	/**
	 * @return the fieldlabel
	 */
	public String getFieldlabel() {
		return fieldlabel;
	}
	/**
	 * @param fieldlabel the fieldlabel to set
	 */
	public void setFieldlabel(String fieldlabel) {
		this.fieldlabel = fieldlabel;
	}
	/**
	 * @return the verificationsrc
	 */
	public String getVerificationsrc() {
		return verificationsrc;
	}
	/**
	 * @param verificationsrc the verificationsrc to set
	 */
	public void setVerificationsrc(String verificationsrc) {
		this.verificationsrc = verificationsrc;
	}
	
	
	

}
