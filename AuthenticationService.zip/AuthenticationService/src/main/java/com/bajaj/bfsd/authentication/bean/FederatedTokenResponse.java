package com.bajaj.bfsd.authentication.bean;

public class FederatedTokenResponse {

	private String customerAuthToken;
	
	private String refreshToken;
	
	private String guardKey;

	public String getCustomerAuthToken() {
		return customerAuthToken;
	}

	public void setCustomerAuthToken(String customerAuthToken) {
		this.customerAuthToken = customerAuthToken;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getGuardKey() {
		return guardKey;
	}

	public void setGuardKey(String guardKey) {
		this.guardKey = guardKey;
	}

	@Override
	public String toString() {
		return "FederatedTokenResponse [customerAuthToken=" + customerAuthToken + ", refreshToken=" + refreshToken
				+ ", guardKey=" + guardKey + "]";
	}
}
