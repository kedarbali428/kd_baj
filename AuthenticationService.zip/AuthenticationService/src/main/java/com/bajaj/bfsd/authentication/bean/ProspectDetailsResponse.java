package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class ProspectDetailsResponse implements Serializable{

	/**private Date
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigDecimal customerType;
	private Date dateOfBirth;
	private String emailId;
	private String firstName;
	private String middleName;
	private String lastName;
	private BigDecimal isActive;
	private String lstUpdateBy;
	private Timestamp lstUpdatedt;
	private String generCode;
	private String genderDescription;
	private String mobileNo;
	private String pan;
	private String prospectId;
	private String prospectSrc;
	private String officialEmailId;
	private List<ProspectAddressDetailsResponse> prospectAddress;

	/**
	 * @return the dateOfBirth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}
	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the isActive
	 */
	public BigDecimal getIsActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(BigDecimal isActive) {
		this.isActive = isActive;
	}
	/**
	 * @return the lstUpdateBy
	 */
	public String getLstUpdateBy() {
		return lstUpdateBy;
	}
	/**
	 * @param lstUpdateBy the lstUpdateBy to set
	 */
	public void setLstUpdateBy(String lstUpdateBy) {
		this.lstUpdateBy = lstUpdateBy;
	}
	/**
	 * @return the lstUpdatedt
	 */
	public Timestamp getLstUpdatedt() {
		return lstUpdatedt;
	}
	/**
	 * @param lstUpdatedt the lstUpdatedt to set
	 */
	public void setLstUpdatedt(Timestamp lstUpdatedt) {
		this.lstUpdatedt = lstUpdatedt;
	}
	/**
	 * @return the generCode
	 */
	public String getGenerCode() {
		return generCode;
	}
	/**
	 * @param generCode the generCode to set
	 */
	public void setGenerCode(String generCode) {
		this.generCode = generCode;
	}
	/**
	 * @return the genderDescription
	 */
	public String getGenderDescription() {
		return genderDescription;
	}
	/**
	 * @param genderDescription the genderDescription to set
	 */
	public void setGenderDescription(String genderDescription) {
		this.genderDescription = genderDescription;
	}
	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	/**
	 * @return the pan
	 */
	public String getPan() {
		return pan;
	}
	/**
	 * @param pan the pan to set
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}
	/**
	 * @return the prospectId
	 */
	public String getProspectId() {
		return prospectId;
	}
	/**
	 * @param prospectId the prospectId to set
	 */
	public void setProspectId(String prospectId) {
		this.prospectId = prospectId;
	}
	/**
	 * @return the prospectSrc
	 */
	public String getProspectSrc() {
		return prospectSrc;
	}
	/**
	 * @param prospectSrc the prospectSrc to set
	 */
	public void setProspectSrc(String prospectSrc) {
		this.prospectSrc = prospectSrc;
	}
	/**
	 * @return the officialEmailId
	 */
	public String getOfficialEmailId() {
		return officialEmailId;
	}
	/**
	 * @param officialEmailId the officialEmailId to set
	 */
	public void setOfficialEmailId(String officialEmailId) {
		this.officialEmailId = officialEmailId;
	}
	/**
	 * @return the prospectAddress
	 */
	public List<ProspectAddressDetailsResponse> getProspectAddress() {
		return prospectAddress;
	}
	/**
	 * @param prospectAddress the prospectAddress to set
	 */
	public void setProspectAddress(List<ProspectAddressDetailsResponse> prospectAddress) {
		this.prospectAddress = prospectAddress;
	}
	/**
	 * @return the customerType
	 */
	public BigDecimal getCustomerType() {
		return customerType;
	}
	/**
	 * @param customerType the customerType to set
	 */
	public void setCustomerType(BigDecimal customerType) {
		this.customerType = customerType;
	}
	
	
	
	
	

}
