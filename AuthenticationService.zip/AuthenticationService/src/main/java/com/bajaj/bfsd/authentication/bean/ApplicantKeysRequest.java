package com.bajaj.bfsd.authentication.bean;

import javax.validation.constraints.NotNull;

public class ApplicantKeysRequest {

	@NotNull(message = "AUTH-400")
	private Long applicantKey;

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	@Override
	public String toString() {
		return "ApplicantKeysRequest [applicantKey=" + applicantKey + "]";
	}
}
