package com.bajaj.bfsd.authentication.bean;

public class PersonalDetailsBean {

	private FullNameDetVerificationBean name;
	private EmailDetVerificationBean email;
	private PinCodeDetVerificationBean pinCode;
	private OccupationBean occupation;
	
	public FullNameDetVerificationBean getName() {
		return name;
	}
	
	public void setName(FullNameDetVerificationBean name) {
		this.name = name;
	}
	
	public EmailDetVerificationBean getEmail() {
		return email;
	}
	
	public void setEmail(EmailDetVerificationBean email) {
		this.email = email;
	}
	
	public PinCodeDetVerificationBean getPinCode() {
		return pinCode;
	}

	public void setPinCode(PinCodeDetVerificationBean pinCode) {
		this.pinCode = pinCode;
	}
	
	public OccupationBean getOccupation() {
		return occupation;
	}
	
	public void setOccupation(OccupationBean occupation) {
		this.occupation = occupation;
	}

}
