package com.bajaj.bfsd.authentication.bean;

public class HashValueResponse {

	private String encodedHashValue;

	public String getEncodedHashValue() {
		return encodedHashValue;
	}

	public void setEncodedHashValue(String encodedHashValue) {
		this.encodedHashValue = encodedHashValue;
	}

	@Override
	public String toString() {
		return "HashValueResponse [encodedHashValue=" + encodedHashValue + "]";
	}

}
