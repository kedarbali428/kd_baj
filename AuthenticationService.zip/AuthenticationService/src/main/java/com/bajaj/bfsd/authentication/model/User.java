/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.model;

import javax.validation.constraints.NotNull;

/**
 * This is a Class for fetching applicant details.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	20/12/2016      Initial Version
 */
public class User {
    
    /**
     * Variable to hold value for aadhaar.
     */
    private String aadhaar;
    
    /**
     * Variable to hold value for pan.
     */
    private String pan;
    
    /**
     * Variable to hold value for passport.
     */
    private String passport;
    
    /**
     * Variable to hold value for mobile.
     */
    private String mobile;
    
    /**
     * Variable to hold value for email.
     */
    private String email;
    
    /**
     * Variable to hold value for source.
     */
    @NotNull(message = "AUTH-005")
    private String source;
    
    /**
     * Getter method for aadhaar.
     *
     * @return aadhaar
     */
    public String getAadhaar() {
        return aadhaar;
    }
    
    /**
     * Sets the value of aadhaar.
     *
     * @param aadhaar the new aadhaar
     */
    public void setAadhaar(String aadhaar) {
        this.aadhaar = aadhaar;
    }
    
    /**
     * Getter method for pan.
     *
     * @return pan
     */
    public String getPan() {
        return pan;
    }
    
    /**
     * Sets the value of pan.
     *
     * @param pan the new pan
     */
    public void setPan(String pan) {
        this.pan = pan;
    }
    
    /**
     * Getter method for passport.
     *
     * @return passport
     */
    public String getPassport() {
        return passport;
    }
    
    /**
     * Sets the value of passport.
     *
     * @param passport the new passport
     */
    public void setPassport(String passport) {
        this.passport = passport;
    }
    
    /**
     * Getter method for mobile.
     *
     * @return mobile
     */
    public String getMobile() {
        return mobile;
    }
    
    /**
     * Sets the value of mobile.
     *
     * @param mobile the new mobile
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
    /**
     * Getter method for email.
     *
     * @return email
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * Sets the value of email.
     *
     * @param email the new email
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * Getter method for source.
     *
     * @return source
     */
    public String getSource() {
        return source;
    }
    
    /**
     * Sets the value of source.
     *
     * @param source the new source
     */
    public void setSource(String source) {
        this.source = source;
    }
    
}
