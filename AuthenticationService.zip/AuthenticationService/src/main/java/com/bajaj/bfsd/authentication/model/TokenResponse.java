package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TokenResponse implements Serializable {

	private static final long serialVersionUID = -8796814877955712643L;

	private List<Tokens> tokens;
	private String defaultRole;
	private Long userKey;

	public List<Tokens> getTokens() {
		return tokens;
	}

	public void setTokens(List<Tokens> tokens) {
		this.tokens = tokens;
	}

	public String getDefaultRole() {
		return defaultRole;
	}

	public void setDefaultRole(String defaultRole) {
		this.defaultRole = defaultRole;
	}

	public Long getUserKey() {
		return userKey;
	}

	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((tokens == null) ? 0 : tokens.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TokenResponse other = (TokenResponse) obj;
		if (tokens == null) {
			if (other.tokens != null)
				return false;
		} else if (!tokens.equals(other.tokens))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TokenResponse [tokens=" + tokens + ", defaultRole=" + defaultRole + ", userKey=" + userKey + "]";
	}

}
