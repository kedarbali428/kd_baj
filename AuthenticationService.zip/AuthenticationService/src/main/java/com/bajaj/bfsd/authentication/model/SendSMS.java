/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.model;

/**
 * This is a Class for fetching applicant details.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	20/12/2016      Initial Version
 */
public class SendSMS {
    
    /**
     * Variable to hold value for msg body.
     */
    private String msgBody;
    
    /**
     * Variable to hold value for msg type.
     */
    private String msgType;
    
    /**
     * Variable to hold value for phone number.
     */
    private String phoneNumber;

    /**
     * Getter method for msg type.
     *
     * @return msg type
     */
    public String getMsgType() {
        return msgType;
    }

    /**
     * Sets the value of msg type.
     *
     * @param msgType the new msg type
     */
    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    /**
     * Getter method for msg body.
     *
     * @return msg body
     */
    public String getMsgBody() {
        return msgBody;
    }

    /**
     * Sets the value of msg body.
     *
     * @param msgBody the new msg body
     */
    public void setMsgBody(String msgBody) {
        this.msgBody = msgBody;
    }

    /**
     * Getter method for phone number.
     *
     * @return phone number
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the value of phone number.
     *
     * @param phoneNumber the new phone number
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }   

}
