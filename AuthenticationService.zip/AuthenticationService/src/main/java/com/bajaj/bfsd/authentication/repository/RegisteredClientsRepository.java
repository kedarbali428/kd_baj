package com.bajaj.bfsd.authentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.authentication.model.RegisteredClients;

@Repository
public interface RegisteredClientsRepository extends JpaRepository<RegisteredClients, String> {

	RegisteredClients findByClientidAndClientstatus(String clientId,Integer clientstatus);

}
