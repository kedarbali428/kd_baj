package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

public class AadharOtpResponse implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8449485383746569975L;
	private String otpTxnId;
	public String hashCode;

	public String getOtpTxnId() {
		return otpTxnId;
	}

	public void setOtpTxnId(String otpTxnId) {
		this.otpTxnId = otpTxnId;
	}

	public String getHashCode() {
		return hashCode;
	}

	public void setHashCode(String hashCode) {
		this.hashCode = hashCode;
	}
	
	
	
}
