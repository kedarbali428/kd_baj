package com.bajaj.bfsd.authentication.bean;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(content = Include.NON_NULL)
public class PanProfileDetailsResponse {

	private String nextTaskKey;
	private String panNumber;
	private String panVerifiedFlag;
	private String name;
	
	public String getNextTaskKey() {
		return nextTaskKey;
	}
	public void setNextTaskKey(String nextTaskKey) {
		this.nextTaskKey = nextTaskKey;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getPanVerifiedFlag() {
		return panVerifiedFlag;
	}
	public void setPanVerifiedFlag(String panVerifiedFlag) {
		this.panVerifiedFlag = panVerifiedFlag;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "PanProfileDetailsResponse [nextTaskKey=" + nextTaskKey + ", panNumber=" + StringUtils.overlay(panNumber, "XXXXXXXX", 0, 10)
				+ ", panVerifiedFlag=" + panVerifiedFlag + ", name=" + name + "]";
	}
	
	
}
