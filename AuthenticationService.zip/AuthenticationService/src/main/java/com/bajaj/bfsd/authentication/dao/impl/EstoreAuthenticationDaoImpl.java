package com.bajaj.bfsd.authentication.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.dao.EstoreAuthenticationDao;
import com.bajaj.bfsd.authentication.model.Userapplicants;
import com.bajaj.bfsd.authentication.repository.UserApplicantRepository;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.DataFormatter;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bfl.common.exceptions.BFLHttpException;

@Component
public class EstoreAuthenticationDaoImpl implements EstoreAuthenticationDao {
	
	private static final String CLASSNAME = EstoreAuthenticationDaoImpl.class.getName();
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	EntityManager entityManager;
	
	@Autowired
	private Environment env;
	
	@Autowired
	UserApplicantRepository userApplicantRepository;

	@Autowired
	private DataFormatter dataFormatter;

	@Override
	public int checkLoginIdExistanceForEstore(String mobileNumber, String dateOfBirth) {
		logger.debug(CLASSNAME, BFLLoggerComponent.DAO, 
				AuthenticationServiceConstants.CHECK_LOGINID_EXISTANCE_START);
		int count = 0;
		Query query = null;
		try {
			if (!StringUtils.isEmpty(dateOfBirth)) {
				Date dob = dataFormatter.dateStringToDate(dateOfBirth, AuthenticationServiceConstants.DOB_DD_MM_YYYY_HYPHENFORMAT);
				query = entityManager.createNativeQuery(
						"SELECT COUNT(1) from APPLICANTS a,APPLICANT_PHONE_NUMBERS ap "
						+ "where ap.APPLICANTKEY = a.APPLICANTKEY and ap.APLTPHNUMNUMBER=:mobileNumber "
						+ "and a.APLTDATEOFBIRTH = :dateOfBirth "
						+ "and a.APLTISACTIVE=1 and ap.APLTPHNUMISACTIVE=1"
					);
				query.setParameter("mobileNumber", mobileNumber);
				query.setParameter("dateOfBirth", dob);
			} else {
				query = entityManager.createNativeQuery(
					"SELECT COUNT(1) from APPLICANTS a,APPLICANT_PHONE_NUMBERS ap "
					+ "where ap.APPLICANTKEY = a.APPLICANTKEY and ap.APLTPHNUMNUMBER=:mobileNumber "
					+ "and a.APLTISACTIVE=1 and ap.APLTPHNUMISACTIVE=1"
				);
			query.setParameter("mobileNumber", mobileNumber);
			}
			count= ((Number) query.getSingleResult()).intValue();
			logger.debug(CLASSNAME, BFLLoggerComponent.DAO, 
					AuthenticationServiceConstants.CHECK_LOGINID_EXISTANCE_END);
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Exception : " + e);
			throw new BFLHttpException(HttpStatus.NOT_FOUND,AuthenticationServiceConstants.AUTH_639,
					env.getProperty(AuthenticationServiceConstants.AUTH_639));
		}
		return count;
	}
	
	
	@Override
	public Timestamp getUserProfile(String mobileNumber) {
		Query query = entityManager.createNativeQuery("SELECT a.APLTDATEOFBIRTH from APPLICANTS a,APPLICANT_PHONE_NUMBERS ap where ap.APPLICANTKEY = a.APPLICANTKEY and ap.APLTPHNUMNUMBER=:mobileNumber and  a.APLTISACTIVE=1 and ap.APLTPHNUMISACTIVE=1");
		query.setParameter("mobileNumber", mobileNumber);
		List<Timestamp> dobList=query.getResultList();
		if(!dobList.isEmpty()) {
			return dobList.get(0);
		}else {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Unable to find date of birth in user profile");
			throw new BFLHttpException(HttpStatus.NOT_FOUND,AuthenticationServiceConstants.AUTH_642,
					env.getProperty(AuthenticationServiceConstants.AUTH_642));
		}
		
	}
	
	
	@Override
	@Transactional
	public int getApplicantRecord(long applicantId) {
		try {
			Query query = entityManager.createQuery("Select Count(a.applicantkey) from ApplicantUtm a where a.applicantkey =:applicantId");
					query.setParameter("applicantId", applicantId);
			int recVersion = (int) ((Number) query.getSingleResult()).longValue();
			return recVersion;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Error while getting entries for current applicant in table : APLT_UTM_PARAMETERS", e);
		}
		return 0;
	}
	

	@Override
	@Transactional
	public long getApplicantId(long userId) {
		long applicantId = 0;
		try {
			Query query = entityManager.createQuery("select a.applicantkey from UserApplicant a where a.bfsdUser.userkey =:userId");
					query.setParameter("userId", userId);
			applicantId = (long) ((Number) query.getSingleResult()).longValue();
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Error while getting entries for current applicant in table : APLT_UTM_PARAMETERS", e);
		}
		return applicantId;
	}


	@Override
	public Userapplicants getuserApplicant(BigDecimal applicantKey) {
		Userapplicants userApplicant= new Userapplicants();
		try {
			
			userApplicant=userApplicantRepository.findByApplicantkey(applicantKey);
			
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Unable to find any user with given details. " + e);
		}
		return userApplicant;
	}

}
