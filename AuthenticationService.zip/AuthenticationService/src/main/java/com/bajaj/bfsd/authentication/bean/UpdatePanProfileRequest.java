package com.bajaj.bfsd.authentication.bean;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.group.GroupSequenceProvider;

import com.bajaj.bfsd.authentication.bean.validationgroup.UpdatePanProfileValidationOrderGroup;
import com.bajaj.bfsd.authentication.bean.validationgroup.UpdatePanProfileValidationGroupSequenceProvider;

@GroupSequenceProvider(UpdatePanProfileValidationGroupSequenceProvider.class)
public class UpdatePanProfileRequest {

	@Pattern(regexp = "^[A-Z]{3}P[A-Z]{1}[0-9]{4}[A-Z]{1}$|^$", message = "AUTH_661", groups = UpdatePanProfileValidationOrderGroup.class)
	private String panNumber;
	
	@NotNull(message = "AUTH-400")
	@Pattern(regexp = "^[A-Za-z]{2,}[A-Za-z\\s]+$", message = "AUTH_662", groups = UpdatePanProfileValidationOrderGroup.class)
	@Size(max = 40, min = 3, message = "AUTH_668")
	private String name;
	
	@Pattern(regexp = "^[0-9]{6}$|^$", message = "AUTH_663", groups = UpdatePanProfileValidationOrderGroup.class)
	private String pincode;
	
	private String panVerifiedFlag;
	
	@Valid
	@NotNull(message = "AUTH-400")
	private ApplicantKeysRequest userKeys;

	public String getPanVerifiedFlag() {
		return panVerifiedFlag;
	}
	public void setPanVerifiedFlag(String panVerifiedFlag) {
		this.panVerifiedFlag = panVerifiedFlag;
	}
	public ApplicantKeysRequest getUserKeys() {
		return userKeys;
	}
	public void setUserKeys(ApplicantKeysRequest userKeys) {
		this.userKeys = userKeys;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "UpdatePanProfileRequest [panNumber=" + StringUtils.overlay(panNumber, "XXXXXXXX", 2, 10) + ", name=" + name + ", pincode=" + pincode
				+ ", panVerifiedFlag=" + panVerifiedFlag + ", userKeys=" + userKeys + "]";
	}
	
}
