package com.bajaj.bfsd.authentication.model;

public class LoginAccount {

	long userId;
	String loginId;
	String pwd;
	short userType;
	short loginType;
	String dateOfBirth;

	public LoginAccount(){
		//
	}
	
	public LoginAccount(String loginId, String pwd, short userType, short loginType, String dateOfBirth) {
		super();
		this.loginId = loginId;
		this.pwd = pwd;
		this.userType = userType;
		this.loginType = loginType;
		this.dateOfBirth = dateOfBirth;
	}
	
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public short getUserType() {
		return userType;
	}

	public void setUserType(short userType) {
		this.userType = userType;
	}

	public short getLoginType() {
		return loginType;
	}

	public void setLoginType(short loginType) {
		this.loginType = loginType;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
}
