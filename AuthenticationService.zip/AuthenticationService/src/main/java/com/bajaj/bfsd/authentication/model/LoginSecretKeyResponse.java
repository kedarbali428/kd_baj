package com.bajaj.bfsd.authentication.model;

public class LoginSecretKeyResponse {
	String secretKey;
	long systemTime;

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public long getSystemTime() {
		return systemTime;
	}

	public void setSystemTime(long systemTime) {
		this.systemTime = systemTime;
	}
	
}
