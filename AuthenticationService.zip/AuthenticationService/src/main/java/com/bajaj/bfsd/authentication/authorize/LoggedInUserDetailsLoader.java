package com.bajaj.bfsd.authentication.authorize;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@Component
public class LoggedInUserDetailsLoader {

	@Autowired
	private TokenValidationUtil tokenValidationUtil;
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	public LoggedInUser loadUserByUsername(String authtoken) {
		ResponseEntity<?> tokenValidationResponse = tokenValidationUtil.getTokenValidity(authtoken);
		if (tokenValidationUtil.isValidToken(tokenValidationResponse)) {
			ValidateTokenResponse validateTokenResponse = (ValidateTokenResponse) tokenValidationResponse.getBody();
			String userId = String.valueOf(validateTokenResponse.getUserId());
			String role = validateTokenResponse.getDefaultRole();
			AdditionalInfo additionalInfo = null;
			if ("pcustomer".equalsIgnoreCase(role) || "pvcustomer".equalsIgnoreCase(role)
					|| "customer".equalsIgnoreCase(role))
				additionalInfo = tokenValidationUtil.getAdditionalUserInfo(validateTokenResponse.getUserId());
			if(AuthenticationServiceConstants.SYSTEM.equalsIgnoreCase(role)||AuthenticationServiceConstants.EMPLOYEE.equalsIgnoreCase(role)
					||AuthenticationServiceConstants.VENDORPARTNER.equalsIgnoreCase(role)||AuthenticationServiceConstants.PRINCIPAL.equalsIgnoreCase(role))
				additionalInfo = tokenValidationUtil.getEPAdditionalUserInfo(validateTokenResponse.getUserId(),"EP");
			if ("internal".equalsIgnoreCase(role))
				additionalInfo = new AdditionalInfo();
			return new LoggedInUser(userId, authtoken, role, additionalInfo);
		}
		logger.warn(this.getClass().getCanonicalName(), BFLLoggerComponent.UTILITY, " Invalid token: " + authtoken + " with response: " + tokenValidationResponse);
		return null;
	}

}
