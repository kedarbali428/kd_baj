package com.bajaj.bfsd.authentication.bean;

public class DocumentDetails {

	private Long documentNameKey;

	private String documentNumber;

	private Long issueingAuthorityKey;

	private String documentIssuedDate;

	private String documentExpiry;

	private Verification verification;

	public Long getDocumentNameKey() {
		return documentNameKey;
	}

	public void setDocumentNameKey(Long documentNameKey) {
		this.documentNameKey = documentNameKey;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public Long getIssueingAuthorityKey() {
		return issueingAuthorityKey;
	}

	public void setIssueingAuthorityKey(Long issueingAuthorityKey) {
		this.issueingAuthorityKey = issueingAuthorityKey;
	}

	public String getDocumentIssuedDate() {
		return documentIssuedDate;
	}

	public void setDocumentIssuedDate(String documentIssuedDate) {
		this.documentIssuedDate = documentIssuedDate;
	}

	public String getDocumentExpiry() {
		return documentExpiry;
	}

	public void setDocumentExpiry(String documentExpiry) {
		this.documentExpiry = documentExpiry;
	}

	public Verification getVerification() {
		return verification;
	}

	public void setVerification(Verification verification) {
		this.verification = verification;
	}

	@Override
	public String toString() {
		return "ApplicationDocumentsBean [documentNameKey=" + documentNameKey + ", documentNumber=" + documentNumber
				+ ", issueingAuthorityKey=" + issueingAuthorityKey + ", documentIssuedDate=" + documentIssuedDate + ", documentExpiry="
				+ documentExpiry + ", verification=" + verification + "]";
	}

}
