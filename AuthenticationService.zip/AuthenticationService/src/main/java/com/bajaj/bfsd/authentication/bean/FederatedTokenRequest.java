package com.bajaj.bfsd.authentication.bean;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

public class FederatedTokenRequest {

	@NotBlank(message = "tokenCode cannot be null or empty")
	private String tokenCode;
	
	@NotBlank(message = "dateOfBirth cannot be null or empty")
	@Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "dateOfBirth must follow pattern yyyy-MM-dd")
	private String dateOfBirth;
	
	@NotNull(message = "customerUserType cannot be null")
	private boolean customerUserType;

	@NotNull(message = "refreshTokenRequired cannot be null")
	private boolean refreshTokenRequired;
	
	public String getTokenCode() {
		return tokenCode;
	}

	public void setTokenCode(String tokenCode) {
		this.tokenCode = tokenCode;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public boolean isCustomerUserType() {
		return customerUserType;
	}

	public void setCustomerUserType(boolean customerUserType) {
		this.customerUserType = customerUserType;
	}

	public boolean isRefreshTokenRequired() {
		return refreshTokenRequired;
	}

	public void setRefreshTokenRequired(boolean refreshTokenRequired) {
		this.refreshTokenRequired = refreshTokenRequired;
	}

	@Override
	public String toString() {
		return "FederatedTokenRequest [tokenCode=" + tokenCode + ", dateOfBirth=" + dateOfBirth + ", customerUserType="
				+ customerUserType + ", refreshTokenRequired=" + refreshTokenRequired + "]";
	}

	
	
}
