package com.bajaj.bfsd.authentication.authorize;

public class LoggedInUser {
		
	private String userId;
	private String authToken;
	private String role;
	private AdditionalInfo additionalInfo;
	
	public LoggedInUser(String loginId, String authToken, String role, AdditionalInfo additionalInfo) {
		this.userId = loginId;
		this.authToken = authToken;
		this.role = role;
		this.additionalInfo = additionalInfo;
	}

	public String getUserId() {
		return userId;
	}

	public String getAuthToken() {
		return authToken;
	}

	public String getRole() {
		return role;
	}

	public AdditionalInfo getAdditionalInfo() {
		return additionalInfo;
	}

	@Override
	public String toString() {
		return "LoggedInUser [userId=" + userId + ", authToken=" + authToken + ", role=" + role + ", additionalInfo="
				+ additionalInfo + "]";
	}
	
}