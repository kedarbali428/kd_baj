package com.bajaj.bfsd.authentication.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;

import com.bajaj.bfsd.authentication.model.Userapplicants;

public interface EstoreAuthenticationDao {

	public int checkLoginIdExistanceForEstore(String mobileNumber, String dateOfBirth);

	public Timestamp getUserProfile(String loginId);
	
	public int getApplicantRecord(long applicantId);
	
	public long getApplicantId(long userId);
	
	public Userapplicants getuserApplicant(BigDecimal applicantKey);

}
