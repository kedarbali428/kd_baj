package com.bajaj.bfsd.authentication.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the APPLICATIONS database table.
 * 
 */
@Entity
@Table(name="APPLICATIONS")
//@NamedQuery(name="Application.findAll", query="SELECT a FROM Application a")
public class Application implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long applicationkey;

	private Timestamp appbookingdt;

	private String appcoreaccnum;

	private Timestamp appdate;

	private BigDecimal appisactive;

	private String appjourneystamp;

	private BigDecimal appjourneytype;

	private String applstupdateby;

	private Timestamp applstupdatedt;

	private String appprocessidentifier;

	private String appreferalcode;

	private String apprefnum;

	private String appsource;

	private BigDecimal appstatus;

	private String apputmrefcode;

	private String apputmsource;

	private BigDecimal bflbranchkey;

	private BigDecimal prodcatkey;

	//bi-directional many-to-one association to Application
	@ManyToOne
	@JoinColumn(name="PARENTAPPLICATIONKEY")
	private Application application;

	//bi-directional many-to-one association to Application
	@OneToMany(mappedBy="application")
	private List<Application> applications;

	//bi-directional many-to-one association to ApplicationApplicant
	@OneToMany(mappedBy="application")
	private List<ApplicationApplicant> applicationApplicants;

	public Application() {
	}

	public long getApplicationkey() {
		return this.applicationkey;
	}

	public void setApplicationkey(long applicationkey) {
		this.applicationkey = applicationkey;
	}

	public Timestamp getAppbookingdt() {
		return this.appbookingdt;
	}

	public void setAppbookingdt(Timestamp appbookingdt) {
		this.appbookingdt = appbookingdt;
	}

	public String getAppcoreaccnum() {
		return this.appcoreaccnum;
	}

	public void setAppcoreaccnum(String appcoreaccnum) {
		this.appcoreaccnum = appcoreaccnum;
	}

	public Timestamp getAppdate() {
		return this.appdate;
	}

	public void setAppdate(Timestamp appdate) {
		this.appdate = appdate;
	}

	public BigDecimal getAppisactive() {
		return this.appisactive;
	}

	public void setAppisactive(BigDecimal appisactive) {
		this.appisactive = appisactive;
	}

	public String getAppjourneystamp() {
		return this.appjourneystamp;
	}

	public void setAppjourneystamp(String appjourneystamp) {
		this.appjourneystamp = appjourneystamp;
	}

	public BigDecimal getAppjourneytype() {
		return this.appjourneytype;
	}

	public void setAppjourneytype(BigDecimal appjourneytype) {
		this.appjourneytype = appjourneytype;
	}

	public String getApplstupdateby() {
		return this.applstupdateby;
	}

	public void setApplstupdateby(String applstupdateby) {
		this.applstupdateby = applstupdateby;
	}

	public Timestamp getApplstupdatedt() {
		return this.applstupdatedt;
	}

	public void setApplstupdatedt(Timestamp applstupdatedt) {
		this.applstupdatedt = applstupdatedt;
	}

	public String getAppprocessidentifier() {
		return this.appprocessidentifier;
	}

	public void setAppprocessidentifier(String appprocessidentifier) {
		this.appprocessidentifier = appprocessidentifier;
	}

	public String getAppreferalcode() {
		return this.appreferalcode;
	}

	public void setAppreferalcode(String appreferalcode) {
		this.appreferalcode = appreferalcode;
	}

	public String getApprefnum() {
		return this.apprefnum;
	}

	public void setApprefnum(String apprefnum) {
		this.apprefnum = apprefnum;
	}

	public String getAppsource() {
		return this.appsource;
	}

	public void setAppsource(String appsource) {
		this.appsource = appsource;
	}

	public BigDecimal getAppstatus() {
		return this.appstatus;
	}

	public void setAppstatus(BigDecimal appstatus) {
		this.appstatus = appstatus;
	}

	public String getApputmrefcode() {
		return this.apputmrefcode;
	}

	public void setApputmrefcode(String apputmrefcode) {
		this.apputmrefcode = apputmrefcode;
	}

	public String getApputmsource() {
		return this.apputmsource;
	}

	public void setApputmsource(String apputmsource) {
		this.apputmsource = apputmsource;
	}

	public BigDecimal getBflbranchkey() {
		return this.bflbranchkey;
	}

	public void setBflbranchkey(BigDecimal bflbranchkey) {
		this.bflbranchkey = bflbranchkey;
	}

	public BigDecimal getProdcatkey() {
		return this.prodcatkey;
	}

	public void setProdcatkey(BigDecimal prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public List<Application> getApplications() {
		return this.applications;
	}

	public void setApplications(List<Application> applications) {
		this.applications = applications;
	}

	public Application addApplication(Application application) {
		getApplications().add(application);
		application.setApplication(this);

		return application;
	}

	public Application removeApplication(Application application) {
		getApplications().remove(application);
		application.setApplication(null);

		return application;
	}

	public List<ApplicationApplicant> getApplicationApplicants() {
		return this.applicationApplicants;
	}

	public void setApplicationApplicants(List<ApplicationApplicant> applicationApplicants) {
		this.applicationApplicants = applicationApplicants;
	}

	public ApplicationApplicant addApplicationApplicant(ApplicationApplicant applicationApplicant) {
		getApplicationApplicants().add(applicationApplicant);
		applicationApplicant.setApplication(this);

		return applicationApplicant;
	}

	public ApplicationApplicant removeApplicationApplicant(ApplicationApplicant applicationApplicant) {
		getApplicationApplicants().remove(applicationApplicant);
		applicationApplicant.setApplication(null);

		return applicationApplicant;
	}

}