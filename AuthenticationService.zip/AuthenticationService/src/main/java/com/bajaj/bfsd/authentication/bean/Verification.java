package com.bajaj.bfsd.authentication.bean;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(content = Include.NON_NULL)
public class Verification {

	private Boolean isVerified;
	private String verificationSource;
	private String verifiedFor;
	private Date verificationDate;
	private Long verificationReference;
	private Long verifyingProductCategoryKey;

	public Long getVerificationReference() {
		return verificationReference;
	}
	public void setVerificationReference(Long verificationReference) {
		this.verificationReference = verificationReference;
	}
	public Boolean getIsVerified() {
		return isVerified;
	}
	public void setIsVerified(Boolean isVerified) {
		this.isVerified = isVerified;
	}
	public String getVerificationSource() {
		return verificationSource;
	}
	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}
	public String getVerifiedFor() {
		return verifiedFor;
	}
	public void setVerifiedFor(String verifiedFor) {
		this.verifiedFor = verifiedFor;
	}
	public Date getVerificationDate() {
		return verificationDate;
	}
	public void setVerificationDate(Date verificationDate) {
		this.verificationDate = verificationDate;
	}
	public Long getVerifyingProductCategoryKey() {
		return verifyingProductCategoryKey;
	}
	public void setVerifyingProductCategoryKey(Long verifyingProductCategoryKey) {
		this.verifyingProductCategoryKey = verifyingProductCategoryKey;
	}
	@Override
	public String toString() {
		return "Verification [isVerified=" + isVerified + ", verificationSource=" + verificationSource
				+ ", verifiedFor=" + verifiedFor + ", verificationDate=" + verificationDate + ", verificationReference="
				+ verificationReference + ", verifyingProductCategoryKey=" + verifyingProductCategoryKey + "]";
	}
}
