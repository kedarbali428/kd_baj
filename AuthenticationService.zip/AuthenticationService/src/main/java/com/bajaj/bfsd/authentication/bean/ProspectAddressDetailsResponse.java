package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class ProspectAddressDetailsResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    private String addressline1;
    
    private String addressline2;

	private String addressline3;
	
	private String pincode;

	private String pinlocalityname;
	
	private String addrtypcodes;
	
	private String citycode;

	private String cityname;
	
	private String statecode;

	private String statedescription;
	
	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal oglflag;

	/**
	 * @return the addressline1
	 */
	public String getAddressline1() {
		return addressline1;
	}

	/**
	 * @param addressline1 the addressline1 to set
	 */
	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	/**
	 * @return the addressline2
	 */
	public String getAddressline2() {
		return addressline2;
	}

	/**
	 * @param addressline2 the addressline2 to set
	 */
	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}

	/**
	 * @return the addressline3
	 */
	public String getAddressline3() {
		return addressline3;
	}

	/**
	 * @param addressline3 the addressline3 to set
	 */
	public void setAddressline3(String addressline3) {
		this.addressline3 = addressline3;
	}

	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}

	/**
	 * @param pincode the pincode to set
	 */
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	/**
	 * @return the pinlocalityname
	 */
	public String getPinlocalityname() {
		return pinlocalityname;
	}

	/**
	 * @param pinlocalityname the pinlocalityname to set
	 */
	public void setPinlocalityname(String pinlocalityname) {
		this.pinlocalityname = pinlocalityname;
	}

	/**
	 * @return the addrtypcodes
	 */
	public String getAddrtypcodes() {
		return addrtypcodes;
	}

	/**
	 * @param addrtypcodes the addrtypcodes to set
	 */
	public void setAddrtypcodes(String addrtypcodes) {
		this.addrtypcodes = addrtypcodes;
	}

	/**
	 * @return the citycode
	 */
	public String getCitycode() {
		return citycode;
	}

	/**
	 * @param citycode the citycode to set
	 */
	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

	/**
	 * @return the cityname
	 */
	public String getCityname() {
		return cityname;
	}

	/**
	 * @param cityname the cityname to set
	 */
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	/**
	 * @return the statecode
	 */
	public String getStatecode() {
		return statecode;
	}

	/**
	 * @param statecode the statecode to set
	 */
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}

	/**
	 * @return the statedescription
	 */
	public String getStatedescription() {
		return statedescription;
	}

	/**
	 * @param statedescription the statedescription to set
	 */
	public void setStatedescription(String statedescription) {
		this.statedescription = statedescription;
	}

	/**
	 * @return the lstupdateby
	 */
	public String getLstupdateby() {
		return lstupdateby;
	}

	/**
	 * @param lstupdateby the lstupdateby to set
	 */
	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	/**
	 * @return the lstupdatedt
	 */
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	/**
	 * @param lstupdatedt the lstupdatedt to set
	 */
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	/**
	 * @return the oglflag
	 */
	public BigDecimal getOglflag() {
		return oglflag;
	}

	/**
	 * @param oglflag the oglflag to set
	 */
	public void setOglflag(BigDecimal oglflag) {
		this.oglflag = oglflag;
	}

	
	

}
