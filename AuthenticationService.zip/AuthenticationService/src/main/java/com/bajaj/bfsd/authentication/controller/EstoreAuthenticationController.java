package com.bajaj.bfsd.authentication.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV3;
import com.bajaj.bfsd.authentication.bean.UtmParameters;
import com.bajaj.bfsd.authentication.service.EstoreAuthenticationService;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.EstoreAuthenticationHelper;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLBusinessException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
public class EstoreAuthenticationController extends BFLController{

	private static final String THIS_CLASS = EstoreAuthenticationController.class.getCanonicalName();

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	EstoreAuthenticationService authService;
	
	@Autowired
	EstoreAuthenticationHelper estoreAuthenticationHelper;
	
	@Autowired
	private Environment env;

	// HORIZONTAL-153 changes end
	// Estore Login Start
	/**
	 * Authenticate estore login id and password
	 * 
	 * @param headers            HttpHeaders
	 * @param EstoreLoginRequest estoreLoginRequest
	 * @return ResponseEntity ResponseEntity
	 * @throws ParseException
	 * @throws BFLBusinessException, BFLTechnicalException, IOException
	 */
	@ApiOperation(value = "Authenticate loginId and password", notes = "Authenticate loginId and password", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@RequestMapping(value = "${api.authentication.estorelogin.V3.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> estoreLogin(@RequestBody UserLoginAccountRequestV3 userLoginRequest,
			@RequestHeader HttpHeaders headers, @RequestHeader(required = false) String app_source,
			@RequestHeader(required = false) String utm_source, @RequestHeader(required = false) String utm_medium,
			@RequestHeader(required = false) String utm_campaign, @RequestHeader(required = false) String utm_term,
			@RequestHeader(required = false) String utm_content) throws ParseException {
		ResponseBean responseBean = new ResponseBean();
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.LOGIN_START);
		UtmParameters applicantUtmBean = new UtmParameters();
		
		try {
			setUtmToApplicantUtmBean(applicantUtmBean, app_source, utm_content, utm_source, utm_medium, utm_campaign,
					utm_term);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while creating applicant UTM parameter bean");
		}
		if (null != userLoginRequest) {
			estoreAuthenticationHelper.validateLoginIDV3(userLoginRequest.getMobileNumber());
			if(StringUtils.isEmpty(userLoginRequest.getDateOfBirth()))
			{
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, AuthenticationServiceConstants.MULTIPLE_USER);
				List<ErrorBean> errorBeanList= new ArrayList<ErrorBean>();
				ErrorBean errorBean= new ErrorBean();
				errorBean.setErrorCode(AuthenticationServiceConstants.AUTH_637);
				errorBean.setErrorMessage(env.getProperty(AuthenticationServiceConstants.AUTH_637));
				errorBeanList.add(errorBean);
				responseBean.setErrorBean(errorBeanList);
				responseBean.setStatus(StatusCode.FAILURE);
				return ResponseEntity.status(217).body(responseBean);
			}
				String loginId = userLoginRequest.getMobileNumber();
				String dob = null;
					estoreAuthenticationHelper.validateDate(userLoginRequest.getDateOfBirth());
					dob = userLoginRequest.getDateOfBirth();
				int userCount=authService.checkUserExistanceforEstore(loginId, dob);
			   if (1 > userCount) {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, AuthenticationServiceConstants.USER_NOT_REGISTERED);
					List<ErrorBean> errorBeanList= new ArrayList<ErrorBean>();
					ErrorBean errorBean= new ErrorBean();
					errorBean.setErrorCode(AuthenticationServiceConstants.AUTH_638);
					errorBean.setErrorMessage(env.getProperty(AuthenticationServiceConstants.AUTH_638));
					errorBeanList.add(errorBean);
					responseBean.setErrorBean(errorBeanList);
					responseBean.setStatus(StatusCode.FAILURE);
					return ResponseEntity.status(484).body(responseBean);
				} 
			  
					// rtype 2 with sendOTP
					responseBean = sendOtp(userLoginRequest, applicantUtmBean,headers);
			   
			}

	        logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.LOGIN_START);
		
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
		
	}


	// rtype 2 with sendOTP
	private ResponseBean sendOtp(UserLoginAccountRequestV3 userLoginRequest, UtmParameters applicantUtmBean,HttpHeaders headers)
			throws ParseException {
		ResponseBean responseBean;
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				AuthenticationServiceConstants.USER_LOGIN_START);
		responseBean = authService.loginWithOtpEstore(userLoginRequest, applicantUtmBean,headers);
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				AuthenticationServiceConstants.USER_LOGIN_END);
		return responseBean;
	}

	

	private void setUtmToApplicantUtmBean(UtmParameters applicantUtmBean, String app_source, String utm_content,
			String utm_source, String utm_medium, String utm_campaign, String utm_term) {
		applicantUtmBean.setUtmContent(utm_content);
		applicantUtmBean.setUtmSource(utm_source);
		applicantUtmBean.setUtmMedium(utm_medium);
		applicantUtmBean.setUtmCampaign(utm_campaign);
		applicantUtmBean.setUtmTerm(utm_term);
		
	}

	

}
