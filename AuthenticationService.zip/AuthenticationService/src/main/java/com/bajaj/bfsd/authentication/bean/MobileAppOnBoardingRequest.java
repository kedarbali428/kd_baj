package com.bajaj.bfsd.authentication.bean;

public class MobileAppOnBoardingRequest {

	private Long applicantId;
	
	private String etpStatus;
	
	public Long getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}
	public String getEtpStatus() {
		return etpStatus;
	}
	public void setEtpStatus(String etpStatus) {
		this.etpStatus = etpStatus;
	}
	@Override
	public String toString() {
		return "MobileAppOnBoardingRequest [applicantId=" + applicantId + ", etpStatus=" + etpStatus + "]";
	}
	
}
