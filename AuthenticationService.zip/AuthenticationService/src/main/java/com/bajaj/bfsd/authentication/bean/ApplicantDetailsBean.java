package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class ApplicantDetailsBean implements Serializable {

	private static final long serialVersionUID = -8321743287029484646L;

	private TokensBean accessToken;
	private UserKeysBean keys;
	private String firstName;
	private String middleName;
	private String lastName;
	private String number;
	private String dateOfBirth;
	private String pinCode;
	private String gender;
	private String maritalStatus;

	public TokensBean getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(TokensBean accessToken) {
		this.accessToken = accessToken;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public UserKeysBean getKeys() {
		return keys;
	}

	public void setKeys(UserKeysBean keys) {
		this.keys = keys;
	}

}
