package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class ApplicantEmplDetailsBean implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long employmentType;

	/**
	 * @return the employmentType
	 */
	public Long getEmploymentType() {
		return employmentType;
	}

	/**
	 * @param employmentType the employmentType to set
	 */
	public void setEmploymentType(Long employmentType) {
		this.employmentType = employmentType;
	}
	
}
