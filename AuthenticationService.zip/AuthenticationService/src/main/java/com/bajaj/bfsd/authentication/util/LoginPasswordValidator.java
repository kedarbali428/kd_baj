package com.bajaj.bfsd.authentication.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;

@Component
public class LoginPasswordValidator extends BFLComponent{

	  private static Pattern patternPassword;
	  private static Pattern patternLogin;

	  private static final String PASSWORD_PATTERN =//NOSONAR
              "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
	  
	  private static final String LOGIN_PATTERN = "^(.+)@(.+)$";


	  private LoginPasswordValidator(){
		  patternPassword = Pattern.compile(PASSWORD_PATTERN);
		  patternLogin = Pattern.compile(LOGIN_PATTERN);
	  }

	  /**
	   * Validate password with regular expression
	   * @param password password for validation
	   * @return true valid password, false invalid password
	   */
	  public static boolean validateLogin(final String login){

		  boolean valid = false;
		
		  Matcher matcherLogin = patternLogin.matcher(login);
		  
		  if(matcherLogin.matches())
			  valid = true;
		  
		  return valid;

	  }
	  
	  /**
	   * Validate password with regular expression
	   * @param password password for validation
	   * @return true valid password, false invalid password
	   */
	  public static boolean validatePassword(final String password){

		  boolean valid = true;
		  Matcher matcherPassword = patternPassword.matcher(password);		
		  
		  if(matcherPassword.matches())
			  valid = true;
		  
		  return valid;

	  }
}