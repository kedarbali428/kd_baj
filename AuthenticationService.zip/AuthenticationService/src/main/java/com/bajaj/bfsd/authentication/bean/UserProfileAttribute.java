package com.bajaj.bfsd.authentication.bean;

public class UserProfileAttribute {
	private Name name;
	private Long maritalStatusKey;
	private Long genderKey;
	private String fatherName;
	private String motherName;

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public Long getMaritalStatusKey() {
		return maritalStatusKey;
	}

	public void setMaritalStatusKey(Long maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}

	public Long getGenderKey() {
		return genderKey;
	}

	public void setGenderKey(Long genderKey) {
		this.genderKey = genderKey;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	@Override
	public String toString() {
		return "UserProfileAttribute [name=" + name + ", maritalStatusKey=" + maritalStatusKey + ", genderKey="
				+ genderKey + ", fatherName=" + fatherName + ", motherName=" + motherName + "]";
	}

}
