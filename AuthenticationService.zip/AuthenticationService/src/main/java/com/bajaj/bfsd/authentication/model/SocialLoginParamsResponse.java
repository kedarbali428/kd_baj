package com.bajaj.bfsd.authentication.model;

public class SocialLoginParamsResponse {
	String redirectUrl;
	
	public String getRedirectUrl() {
		return redirectUrl;
	}
	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}
}
