/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.PropertySource;
/**
 * This class is Main class for Openam services for authentication.
 * 
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                                          07/11/2016      Initial Version
 *
 */
import org.springframework.context.annotation.PropertySources;

import com.bajaj.bfsd.common.business.baseclasses.BFLAsyncBusinessApplication;

/**
 * This is a main class for Authentication Service.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	07/11/2016      Initial Version
 */
@PropertySources(value = {@PropertySource("classpath:error.properties")})
@EntityScan("com")
public class AuthenticationServiceApplication extends BFLAsyncBusinessApplication {

    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
        
        
        SpringApplication.run(AuthenticationServiceApplication.class, args);
        
    }

}