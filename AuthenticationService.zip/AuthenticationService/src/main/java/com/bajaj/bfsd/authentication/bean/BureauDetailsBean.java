package com.bajaj.bfsd.authentication.bean;

public class BureauDetailsBean {

	private PanDetVerificationBean pan;
	
	public PanDetVerificationBean getPan() {
		return pan;
	}
	
	public void setPan(PanDetVerificationBean pan) {
		this.pan = pan;
	}

	@Override
	public String toString() {
		return "BureauDetailsBean [pan=" + pan + "]";
	}

}
