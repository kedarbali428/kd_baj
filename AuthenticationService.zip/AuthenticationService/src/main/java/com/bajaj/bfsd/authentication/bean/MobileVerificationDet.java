package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class MobileVerificationDet implements Serializable {
	private static final long serialVersionUID = 1L;
	String countryCode;
	@NotNull(message="Country Code can not be null")
	private String number;
	private String type;
	private boolean isVerified;
	private VerificationDet verification;
	
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean isVerified() {
		return isVerified;
	}
	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}
	public VerificationDet getVerification() {
		return verification;
	}
	public void setVerification(VerificationDet verification) {
		this.verification = verification;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
}
