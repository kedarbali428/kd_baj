package com.bajaj.bfsd.authentication.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.util.MapperFactory;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.cache.service.UserProfileCacheService;
import com.bajaj.bfsd.common.cache.service.entity.UserProfileEntity;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class FinegrainAuthServiceImpl {
	
	@Autowired 
	Environment env;
	
	@Autowired
	BFLLoggerUtil logger;
	
	@Autowired
	UserProfileCacheService userProfileCacheService;
	
	@Value("${api.usermanagement.baseprofile.GET.url}")
	private String userProfileBaseUrl;
	
	private static final String THIS_CLASS = FinegrainAuthServiceImpl.class.getCanonicalName();

	public void loadUserProfile(long userId) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside loadUserProfile method");
		try{
			UserProfileEntity  userProfileEntity=  getBaseUserProfile(userId);
			if(null!=userProfileEntity)
			{
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "before Saving into cache userProfileEntity");
				userProfileCacheService.save(userId, userProfileEntity);
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "after Saving into cache userProfileEntity");
			}
		}catch(Exception e){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exception from loadUserProfile method"+e);
		}
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exit from loadUserProfile method");
	}
	
	private UserProfileEntity getBaseUserProfile(Long userId) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "get getBaseUserProfile from rest call with db");
		UserProfileEntity baseUserProfileEntity=null;
		String responsePayload;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		JSONObject reqJsonObj = new JSONObject();
		reqJsonObj.put("userKey", userId);
		Map<String, String> params = new HashMap<>();
		params.put("userKey", String.valueOf(userId));
		ResponseEntity<?> response = BFLCommonRestClient.invokeRestEndpoint(HttpMethod.GET,userProfileBaseUrl, null, String.class, params,null , headers);
		if(null != response && HttpStatus.OK.equals(response.getStatusCode())) {
			Object responseObject = response.getBody();
			JSONObject responseJson = getJsonObject(responseObject);
			responsePayload = responseJson.get("payload").toString();	
			baseUserProfileEntity = mapFromJson(responsePayload,UserProfileEntity.class);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "response from getBaseUserProfile"+response);

		}else{
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "invalid response from getBaseUserProfile");
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "returning baseUserProfileEntity");
		return baseUserProfileEntity;
	}
	
	public void fetchUserProfile(long userId) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside fetchUserProfile method");
		try{
			UserProfileEntity userProfileEntity = userProfileCacheService.get(userId);
			if(null != userProfileEntity){
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Applicant Key from userProfile is---"+userProfileEntity.getApplicantId());
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Mobile Number  from userProfile is---"+userProfileEntity.getMobileNumber());
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "date Of Birth from userProfile is---"+userProfileEntity.getDateOfBirth());
			}else{
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "UserProfileEntity not found against userId is---"+userId);
			}
		}catch(Exception e){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exception from fetchUserProfile method"+e);
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exit from fetchUserProfile method");
	}
	
	@SuppressWarnings("rawtypes")
	private JSONObject getJsonObject(Object object) {
		JSONObject jsonObject = new JSONObject();
		try {

			JSONParser parser = new JSONParser();
			if (object instanceof JSONObject) {
				jsonObject = (JSONObject) object;
			}else {
				Object obj = parser.parse(object.toString());
				jsonObject = (JSONObject) obj;
			}

		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error occured while parsing :", e);
		}
		return jsonObject;
	}
	
	public <T> T mapFromJson(String jsonString, Class<T> clazz) {
		ObjectMapper mapper = MapperFactory.getInstance();
		try {
			return mapper.readValue(jsonString, clazz);
		} catch (IOException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exception occured in JSON to object conversion.", e);
			throw new BFLTechnicalException("JSNMAPEXC_001", env.getProperty("JSNMAPEXC_001"));
		}
	}
}