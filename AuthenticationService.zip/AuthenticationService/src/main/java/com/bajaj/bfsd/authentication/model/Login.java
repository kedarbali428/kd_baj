/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

// TODO: Auto-generated Javadoc
/**
 * This is a Class for fetching applicant details.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	16/12/2016      Initial Version
 */
public class Login implements Serializable{
    
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8488668456016518416L;

    /**
     * Variable to hold value for username.
     */
    @NotNull(message = "AUTH-003")
    private String username;
    
    /**
     * Variable to hold value for password.
     */
    @NotNull(message = "AUTH-004")
    private String password;
    
    /** The deviceid. */
    private String deviceid;
    
    /** The ip address. */
    private String ipAddress;
    
    /** The browser. */
    private String browser;
    
    /** The latitude. */
    private BigDecimal latitude;
    
    /** The longitude. */
    private BigDecimal longitude;
    
    private String loginsrcwebapp;
    
    private BfsdUser bfsdUser;


	public BfsdUser getBfsdUser() {
		return bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

	public String getLoginsrcwebapp() {
		return loginsrcwebapp;
	}

	public void setLoginsrcwebapp(String loginsrcwebapp) {
		this.loginsrcwebapp = loginsrcwebapp;
	}

	/**
     * Gets the deviceid.
     *
     * @return the deviceid
     */
    public String getDeviceid() {
		return deviceid;
	}

	/**
	 * Sets the deviceid.
	 *
	 * @param deviceid the new deviceid
	 */
	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	/**
	 * Gets the ip address.
	 *
	 * @return the ip address
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * Sets the ip address.
	 *
	 * @param ipAddress the new ip address
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * Gets the browser.
	 *
	 * @return the browser
	 */
	public String getBrowser() {
		return browser;
	}

	/**
	 * Sets the browser.
	 *
	 * @param browser the new browser
	 */
	public void setBrowser(String browser) {
		this.browser = browser;
	}

	/**
	 * Gets the latitude.
	 *
	 * @return the latitude
	 */
	public BigDecimal getLatitude() {
		return latitude;
	}

	/**
	 * Sets the latitude.
	 *
	 * @param latitude the new latitude
	 */
	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	/**
	 * Gets the longitude.
	 *
	 * @return the longitude
	 */
	public BigDecimal getLongitude() {
		return longitude;
	}

	/**
	 * Sets the longitude.
	 *
	 * @param longitude the new longitude
	 */
	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	/**
     * Getter method for username.
     *
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the value of username.
     *
     * @param username the new username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Getter method for password.
     *
     * @return password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the value of password.
     *
     * @param password the new password
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
