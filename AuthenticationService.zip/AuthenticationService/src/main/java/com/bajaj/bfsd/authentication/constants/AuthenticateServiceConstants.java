/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.constants;

import java.math.BigDecimal;

/**
 * This class is Constant class for Authentication service.
 * 
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602          07/11/2016      Initial Version
 *
 */
public enum AuthenticateServiceConstants {

    /**
     * Variable to hold value for attribute ntid.
     */
    ATTRIBUTE_NTID("NTID"),

    /**
     * Variable to hold value for attribute authid.
     */
    ATTRIBUTE_AUTHID("authId"),

    /**
     * Variable to hold value for attribute callbacks.
     */
    ATTRIBUTE_CALLBACKS("callbacks"),

    /**
     * Variable to hold value for attribute output.
     */
    ATTRIBUTE_OUTPUT("output"),

    /**
     * Variable to hold value for attribute redirect url.
     */
    ATTRIBUTE_REDIRECT_URL("redirectUrl"),

    /**
     * Variable to hold value for attribute name.
     */
    ATTRIBUTE_NAME("name"),

    /**
     * Variable to hold value for attribute value.
     */
    ATTRIBUTE_VALUE("value"),

    /**
     * Variable to hold value for attribute content type.
     */
    ATTRIBUTE_CONTENT_TYPE("Content-Type"),

    /**
     * Variable to hold value for attribute cookie.
     */
    ATTRIBUTE_COOKIE("Cookie"),
    
    /**
     * Variable to hold value for attribute body.
     */
    ATTRIBUTE_BODY("body"),

    /**
     * Variable to hold value for attribute username header.
     */
    ATTRIBUTE_USERNAME_HEADER("X-OpenAM-Username"),
    
    /**
     * Variable to hold value for attribute password header.
     */
    ATTRIBUTE_PASSWORD_HEADER("X-OpenAM-Password"),
    
    /**
     * Variable to hold value for attribute password header.
     */
    ATTRIBUTE_TOKEN_HEADER("iPlanetDirectoryPro"),
    
    /**
     * Variable to hold value for attribute am app id.
     */
    ATTRIBUTE_AM_APP_ID("amapplicantid"),
    /**
     * Variable to hold value for attribute set cookie.
     */
    ATTRIBUTE_SET_COOKIE("Set-Cookie"),

    /**
     * Variable to hold value for char equal.
     */
    CHAR_EQUAL("="),

    /**
     * Variable to hold value for char semi colon.
     */
    CHAR_SEMI_COLON(";"),

    /**
     * Variable to hold value for char ampersand.
     */
    CHAR_AMPERSAND("&"),

    /**
     * Variable to hold value for char ques mark.
     */
    CHAR_QUES_MARK("?"),
    
    /**
     * Variable to hold value for passport.
     */
    PASSPORT("PASSPORT"),
    
    /**
     * Variable to hold value for mobile.
     */
    MOBILE("MOBILE"),
    
    /**
     * Variable to hold value for email.
     */
    EMAIL("EMAIL"),
    
    /**
     * Variable to hold value for aadhaar.
     */
    AADHAAR("AADHAAR"),
    
    /**
     * Variable to hold value for pan.
     */
    PAN("PAN"),
    
    DOMAIN("DOMAIN"),
    
    /**
     * Variable to hold value for aadhaar.
     */
    PLATFORM("PLATFORM"),
    
    /**
     * Variable to hold value for aadhaar.
     */
    DEVICE_ID("DEVICE_ID"),
    
    /**
     * Variable to hold value for aadhaar.
     */
    BROWSER_ID("BROWSER_ID"),
    
    /**
     * Variable to hold value for aadhaar.
     */
    BROWSER("PLATFORM"),
    
    /**
     * Variable to hold value for msg type transactional.
     */
    MSG_TYPE_TRANSACTIONAL("Transactional"); 
    
    /**
     * Variable to hold value for value.
     */
    private String value;
    

	public static final BigDecimal LOGINSRCWEB = new BigDecimal(1);
	public static final BigDecimal LOGINSRCMOBILE = new BigDecimal(2);
	
	public static final String MINUTES = "MINUTES";
	public static final String SECONDS = "SECONDS";
	public static final String HOURS = "HOURS";
    
	public static final int ISACTIVE = 1;
    /**
     * Instantiates a new authenticate service constants.
     *
     * @param value the value
     */
    private AuthenticateServiceConstants(String value) {
            this.value = value;
    }
    
    /**
     * Getter method for enum value.
     *
     * @return value
     */
    public String getValue() {
            return this.value;
    }
    
    
}
