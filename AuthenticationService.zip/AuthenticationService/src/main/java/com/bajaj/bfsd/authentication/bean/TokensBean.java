package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class TokensBean implements Serializable {

	private static final long serialVersionUID = 5109335674343100117L;

	private String token;
	private String guardToken;
	private String status;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getGuardToken() {
		return guardToken;
	}

	public void setGuardToken(String guardToken) {
		this.guardToken = guardToken;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((guardToken == null) ? 0 : guardToken.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((token == null) ? 0 : token.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null)
			return false;
		if (getClass() != o.getClass())
			return false;
		TokensBean other = (TokensBean) o;
		if (guardToken == null) {
			if (other.guardToken != null)
				return false;
		} else if (!guardToken.equals(other.guardToken))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (token == null) {
			if (other.token != null)
				return false;
		} else if (!token.equals(other.token))
			return false;
		return true;
	}

}
