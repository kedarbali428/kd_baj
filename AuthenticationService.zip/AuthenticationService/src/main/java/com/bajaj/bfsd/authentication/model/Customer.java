/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

/**
 * This is a bean class for Customer.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	16/12/2016      Initial Version
 */
public class Customer implements Serializable{
       
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 7687445562523841058L;

    /**
     * Variable to hold value for applicant id.
     */
    private Long applicantId;
    
    /**
     * Variable to hold value for mobile no.
     */
    private Long mobileNo;
    
    /**
     * Variable to hold value for email.
     */
    private String email;
    
    /**
     * Variable to hold value for token.
     */
    private SsoToken token;
    
    /**
     * Getter method for applicant id.
     *
     * @return applicant id
     */
    public Long getApplicantId() {
        return applicantId;
    }
    
    /**
     * Sets the value of applicant id.
     *
     * @param applicantId the new applicant id
     */
    public void setApplicantId(Long applicantId) {
        this.applicantId = applicantId;
    }
    
    /**
     * Getter method for mobile no.
     *
     * @return mobile no
     */
    public Long getMobileNo() {
        return mobileNo;
    }
    
    /**
     * Sets the value of mobile no.
     *
     * @param mobileNo the new mobile no
     */
    public void setMobileNo(Long mobileNo) {
        this.mobileNo = mobileNo;
    }
    
    /**
     * Getter method for email.
     *
     * @return email
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * Sets the value of email.
     *
     * @param email the new email
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * Getter method for token.
     *
     * @return token
     */
    public SsoToken getToken() {
        return token;
    }
    
    /**
     * Sets the value of token.
     *
     * @param token the new token
     */
    public void setToken(SsoToken token) {
        this.token = token;
    }
    
}
