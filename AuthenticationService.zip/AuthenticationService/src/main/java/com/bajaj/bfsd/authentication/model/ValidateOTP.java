package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class ValidateOTP implements Serializable {

	@NotNull(message = "OTP-002")
	private String mobile;
	@NotNull(message = "OTP-004")
	private String otp;
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	
}
