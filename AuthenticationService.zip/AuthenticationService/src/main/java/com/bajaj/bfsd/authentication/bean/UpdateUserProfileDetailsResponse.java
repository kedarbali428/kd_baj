package com.bajaj.bfsd.authentication.bean;

public class UpdateUserProfileDetailsResponse {

	private String nextTaskKey;
	
	public String getNextTaskKey() {
		return nextTaskKey;
	}
	
	public void setNextTaskKey(String nextTaskKey) {
		this.nextTaskKey = nextTaskKey;
	}

	@Override
	public String toString() {
		return "UpdateUserProfileDetailsResponse [nextTaskKey=" + nextTaskKey + "]";
	}

}
