package com.bajaj.bfsd.authentication.bean;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

public class SystemTokenRequest {

	@NotBlank(message = "AUTH_025")
	@Pattern(regexp = "^[A-Z]*$",message = "AUTH_025")
	private String productCode;

	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	@Override
	public String toString() {
		return "SystemTokenRequest [productCode=" + productCode + "]";
	}
}
