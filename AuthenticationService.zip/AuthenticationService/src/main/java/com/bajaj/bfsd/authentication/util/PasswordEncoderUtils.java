package com.bajaj.bfsd.authentication.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.Pbkdf2PasswordEncoder;
import org.springframework.security.crypto.password.Pbkdf2PasswordEncoder.SecretKeyFactoryAlgorithm;

public class PasswordEncoderUtils {
	private static final int HASH_SIZE = 512;
	private static final int HASH_ITERATIONS = 60006;

	private static PasswordEncoderUtils instance = new PasswordEncoderUtils();
	
	private static Map<String, String> matchPwdMap = new HashMap<>();

	private PasswordEncoder passwordEncoder = null;

	protected static PasswordEncoderUtils getInstance() {
		return instance;
	}

	private PasswordEncoderUtils() {
		init();
	}

	/**
	 * Initializes passwordEncoder.
	 */
	protected void init() {

		/**
		 * This is version v1 of Pbkdf2PasswordEncoder configuration. Any changes to
		 * below configuration in LIVE should be avoided. New config should be added
		 * with "pbkdf2-v2" while retaining existing instance to allow old passwords
		 * decoding/matching which were encoded with "pbkdf2-v1".
		 */
		Pbkdf2PasswordEncoder pbkdf2PasswordEncoderV1 = new Pbkdf2PasswordEncoder(getSecret(), HASH_ITERATIONS,
				HASH_SIZE);
		pbkdf2PasswordEncoderV1.setAlgorithm(SecretKeyFactoryAlgorithm.PBKDF2WithHmacSHA512);
		pbkdf2PasswordEncoderV1.setEncodeHashAsBase64(true);

		/**
		 * Use this for Password Encoding. Any changes should increment version and
		 * retain old instance into encoders map. "bcrypt" is added to support migration
		 * scenarios from legacy applications.
		 */
		String idForEncode = "pbkdf2-v1";
		Map<String, PasswordEncoder> encoders = new HashMap<String, PasswordEncoder>();
		encoders.put(idForEncode, pbkdf2PasswordEncoderV1);
		encoders.put("bcrypt", new BCryptPasswordEncoder());

		passwordEncoder = new DelegatingPasswordEncoder(idForEncode, encoders);
	}

	/**
	 * 
	 * @return
	 */
	protected CharSequence getSecret() {
		String secret = "{HASH:" + HASH_SIZE + "}{ITERATIONS:" + HASH_ITERATIONS + "}{ALGO:"
				+ SecretKeyFactoryAlgorithm.PBKDF2WithHmacSHA512.name() + "}";

		return secret;
	}

	/**
	 * 
	 * @return
	 */
	public static PasswordEncoder getPasswordEncoder() {
		return getInstance().passwordEncoder;
	}

	/**
	 * 
	 * @param rawPassword
	 * @return
	 */
	public static String encode(String rawPassword) {
		return getPasswordEncoder().encode(rawPassword);
	}

	/**
	 * 
	 * @param rawPassword
	 * @param encodedPassword
	 * @return
	 */
	public static boolean matches(String rawPassword, String encodedPassword) {
		String matchPwd = matchPwdMap.get(encodedPassword);
		if (null != matchPwd) {
			return matchPwd.equals(rawPassword);
		}
		
		if (getPasswordEncoder().matches(rawPassword, encodedPassword)) {
			matchPwdMap.put(encodedPassword, rawPassword);
			return true;
		}

		return false;
	}
	
}
