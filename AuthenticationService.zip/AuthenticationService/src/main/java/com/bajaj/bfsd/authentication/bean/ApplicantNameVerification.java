package com.bajaj.bfsd.authentication.bean;

public class ApplicantNameVerification {
	
	private String firstName;
	private String middleName;
	private String lastName;
	private String verificationflg;
	private String verificationsrc;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getVerificationflg() {
		return verificationflg;
	}

	public void setVerificationflg(String verificationflg) {
		this.verificationflg = verificationflg;
	}

	public String getVerificationsrc() {
		return verificationsrc;
	}

	public void setVerificationsrc(String verificationsrc) {
		this.verificationsrc = verificationsrc;
	}
}
