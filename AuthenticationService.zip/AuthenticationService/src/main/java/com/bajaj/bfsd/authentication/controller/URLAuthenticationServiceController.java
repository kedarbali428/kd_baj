package com.bajaj.bfsd.authentication.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.authentication.constants.AuthenticateServiceConstants;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.request.validator.RequestValidator;
import com.bajaj.bfsd.authentication.service.OMAuthenticationService;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.cache.service.AuthenticationSessionCacheService;
import com.bajaj.bfsd.common.cache.service.entity.AuthSessionResponseBean;
import com.bajaj.bfsd.common.cache.service.entity.SessionBean;
import com.bajaj.bfsd.common.domain.ErrorBean;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class URLAuthenticationServiceController extends BFLController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	OMAuthenticationService omAuthenticationService;
	
	@Autowired
	AuthenticationSessionCacheService authenticationSessionCacheService;
	
	@Autowired
	RequestValidator requestValidator;
	

	@ApiOperation(value = "Create session and store in cache", notes = "Create session and store in cache", httpMethod = "POST", response = AuthSessionResponseBean.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Returns session response bean", response = AuthSessionResponseBean.class),
			@ApiResponse(code = 401, message = "Returns Unauthorized for invalid session", response = ErrorBean.class) })
	@RequestMapping(value = "${api.authentication.authenticationsession.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> createSessionForAuthentication(
			@RequestBody SessionBean sessionBean) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
				"Inside createSessionForAuthentication - start with request: " + sessionBean);
		Long ttl = calculateTtl(sessionBean);
		AuthSessionResponseBean responseBean = saveSessionToCache(sessionBean, ttl);
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					"Inside createSessionForAuthentication - end with response: " + sessionBean);
			return new ResponseEntity<AuthSessionResponseBean>(responseBean, HttpStatus.CREATED);
		
	}
	
	@ApiOperation(value = "Authenticate session", notes = "Authenticate session based on session key", httpMethod = "POST", response = AuthSessionResponseBean.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 204, message = "Authentication Success", response = String.class),
			@ApiResponse(code = 401, message = "Returns Unauthorized for invalid session", response = ErrorBean.class) })
	@RequestMapping(value = "${api.authentication.authenticationloginsession.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> createSessionAuthenticationForLogin(
			@PathVariable("session-id") String sessionKey) {
		HttpHeaders headers = new HttpHeaders();
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
				"Inside createSessionForAuthentication - start with request: " + sessionKey);
		if(null !=authenticationSessionCacheService.get(sessionKey)) {
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					"Inside createSessionForAuthentication - end with response: " + sessionKey);
			SessionBean sessionBean = (SessionBean)authenticationSessionCacheService.get(sessionKey);
			if(validateRetryCount(sessionKey, sessionBean)) {
				MobileLoginRequest mobileLoginRequest = new MobileLoginRequest();
				mobileLoginRequest.setApplicationKey(Long.valueOf(sessionBean.getApplicationKey()));
				mobileLoginRequest.setDateOfBirth(sessionBean.getDateOfBirth());
				mobileLoginRequest.setMobile(String.valueOf(sessionBean.getMobileNumber()));
				TokenResponse tokenResponse = omAuthenticationService
						.authenticateMobDobAndGenerateToken(mobileLoginRequest);
				removeUserKey(tokenResponse, true);
				if(!CollectionUtils.isEmpty(tokenResponse.getTokens())) {
					Tokens authToken = tokenResponse.getTokens().get(0);
					headers.set("authToken", authToken.getToken());
					headers.set("gaurdKey", authToken.getGuardKey());
					headers.set("type", authToken.getType());
					headers.set(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN, "*");
					headers.set(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, "authToken");
					
				}
				return ResponseEntity.noContent().headers(headers).build();
			}else {
				logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
						"Inside createSessionForAuthentication - end with response: " + sessionKey);
				return new ResponseEntity<String>("Authentication Failed", HttpStatus.UNAUTHORIZED);
			}
			
			//return new ResponseEntity<String>("Authentication Success", HttpStatus.NO_CONTENT);
			//return new ResponseEntity<HttpHeaders>(headers, HttpStatus.CREATED);
			
		}else {
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					"Inside createSessionForAuthentication - end with response: " + sessionKey);
			return new ResponseEntity<String>("Authentication Failed", HttpStatus.UNAUTHORIZED);
		}
	}

	private boolean validateRetryCount(String sessionKey, SessionBean sessionBean) {
		Integer count = sessionBean.getRetryCount();
		Boolean activeCount = false;
		if(count > 0) {
			sessionBean.setRetryCount(count - 1);
			Long ttl = calculateTtl(sessionBean);
			authenticationSessionCacheService.update(sessionKey, sessionBean, ttl);
			activeCount = true;
		}else {
			authenticationSessionCacheService.delete(sessionKey);
			activeCount = false;
		}
		return activeCount;
	}

	/**
	 * @param sessionBean
	 * @param ttl
	 */
	public AuthSessionResponseBean saveSessionToCache(SessionBean sessionBean, Long ttl) {
		AuthSessionResponseBean responseBean = null;
		UUID uuid = UUID.randomUUID();
		if(null !=authenticationSessionCacheService.get(uuid.toString())) {
			saveSessionToCache(sessionBean, ttl);
		}else {
			responseBean = new AuthSessionResponseBean();
			authenticationSessionCacheService.save(uuid.toString(), sessionBean, ttl);
			responseBean.setApplicantKey(sessionBean.getApplicantKey());
			responseBean.setApplicationKey(sessionBean.getApplicationKey());
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
			LocalDateTime now = LocalDateTime.now();  
			responseBean.setCreationTime(dtf.format(now));
			responseBean.setDateOfBirth(sessionBean.getDateOfBirth());
			responseBean.setMobileNumber(sessionBean.getMobileNumber());
			responseBean.setRetryCount(sessionBean.getRetryCount());
			responseBean.setSessionKey(uuid.toString());
			responseBean.setValidity(sessionBean.getValidity());
			responseBean.setValidityUnit(sessionBean.getValidityUnit());
		}
		return responseBean;
	}
	
	private Long calculateTtl(SessionBean sessionBean) {
		Long ttl=0L;
		if(sessionBean.getValidityUnit().equals(AuthenticateServiceConstants.MINUTES)) {
			ttl = sessionBean.getValidity();
		}else if(sessionBean.getValidityUnit().equals(AuthenticateServiceConstants.SECONDS)) {
			TimeUnit time = TimeUnit.MINUTES; 
	        ttl =  time.convert(sessionBean.getValidity(),TimeUnit.SECONDS); 
		}else if(sessionBean.getValidityUnit().equals(AuthenticateServiceConstants.HOURS)) {
			TimeUnit time = TimeUnit.MINUTES; 
	        ttl =  time.convert(sessionBean.getValidity(),TimeUnit.HOURS); 
		}
		return ttl;
	}
	
	private void removeUserKey(TokenResponse tokenResponse, boolean userKeyFlag) {
		if(userKeyFlag){
			tokenResponse.setUserKey(null);
			tokenResponse.setDefaultRole(null);
		}		
	}	

}
