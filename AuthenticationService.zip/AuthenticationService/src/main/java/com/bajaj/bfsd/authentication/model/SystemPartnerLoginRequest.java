package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotEmpty;

public class SystemPartnerLoginRequest implements Serializable{
	
	private static final long serialVersionUID = 2771412150949480598L;

	@NotEmpty(message = "AUTH_635")
	private String systemPartnerKey;
	
	@NotEmpty(message = "AUTH_635")
	private String secretKey;

	public String getSystemPartnerKey() {
		return systemPartnerKey;
	}

	public void setSystemPartnerKey(String systemPartnerKey) {
		this.systemPartnerKey = systemPartnerKey;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}
	
	

}
