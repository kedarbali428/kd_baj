package com.bajaj.bfsd.authentication.config;

import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

	@Value("${httpclient.connectTimeoutMilliseconds:15000}")
	private int connectTimeout;

	@Value("${httpclient.readTimeoutMilliseconds:60000}")
	private int readTimeout;

	@Value("${httpclient.maxConnectionsPerRoute:250}")
	private int maxConnectionsPerRoute;

	@Value("${httpclient.maxConnections:2048}")
	private int maxConnections;

	@Bean(name = "httpClientConnectionManager")
	public HttpClientConnectionManager httpClientConnectionManager() {
		PoolingHttpClientConnectionManager poolingConnectionManager = new PoolingHttpClientConnectionManager();
		poolingConnectionManager.setDefaultMaxPerRoute(maxConnectionsPerRoute);
		poolingConnectionManager.setMaxTotal(maxConnections);
		return poolingConnectionManager;
	}

	@Bean(name = { "restTemplate" })
	public RestTemplate restTemplate(
			@Qualifier("httpClientConnectionManager") HttpClientConnectionManager httpClientConnectionManager) {
		CloseableHttpClient httpClient = HttpClients.custom().useSystemProperties()
				.setConnectionManager(httpClientConnectionManager).disableCookieManagement().build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		requestFactory.setConnectionRequestTimeout(connectTimeout);
		requestFactory.setConnectTimeout(connectTimeout);
		requestFactory.setReadTimeout(readTimeout);
		return new RestTemplate(requestFactory);
	}
	
	@Bean("authenticationHttpConnectionPool")
	public HttpConnectionPoolMXBean httpConnectionPool(
			@Autowired PoolingHttpClientConnectionManager httpClientConnectionManager) {
		return new HttpConnectionPoolMXBean(httpClientConnectionManager);
	}

	@ManagedResource
	public static class HttpConnectionPoolMXBean {

		private PoolingHttpClientConnectionManager poolingConnectionManager;

		public HttpConnectionPoolMXBean(PoolingHttpClientConnectionManager poolingConnectionManager) {
			this.poolingConnectionManager = poolingConnectionManager;
		}

		@ManagedAttribute
		public int getActiveHttpConnections() {
			return this.poolingConnectionManager.getTotalStats().getLeased();
		}

		@ManagedAttribute
		public int getThreadsAwaitingHttpConnections() {
			return this.poolingConnectionManager.getTotalStats().getPending();
		}

		@ManagedAttribute
		public int getIdleHttpConnections() {
			return this.poolingConnectionManager.getTotalStats().getAvailable();
		}

		@ManagedAttribute
		public int getTotalHttpConnectionsPerRoute() {
			return this.poolingConnectionManager.getDefaultMaxPerRoute();
		}

		@ManagedAttribute
		public int getTotalHttpConnections() {
			return this.poolingConnectionManager.getMaxTotal();
		}

		@ManagedOperation
		public void setTotalHttpConnectionsPerRoute(int maxPerRoute) {
			this.poolingConnectionManager.setDefaultMaxPerRoute(maxPerRoute);
		}

		@ManagedOperation
		public void setTotalHttpConnections(int maxTotal) {
			this.poolingConnectionManager.setMaxTotal(maxTotal);
		}
	}

}
