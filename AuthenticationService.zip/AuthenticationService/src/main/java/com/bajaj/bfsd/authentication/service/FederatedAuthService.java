package com.bajaj.bfsd.authentication.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeRequest;
import com.bajaj.bfsd.authentication.bean.FederatedAuthorizeResponse;
import com.bajaj.bfsd.authentication.bean.FederatedLoginRequest;
import com.bajaj.bfsd.authentication.bean.FederatedLoginResponse;
import com.bajaj.bfsd.authentication.bean.FederatedTokenRequest;
import com.bajaj.bfsd.authentication.bean.FederatedTokenResponse;
import com.bajaj.bfsd.authentication.bean.FederatedUserRegisterRequest;
import com.bajaj.bfsd.authentication.bean.FederatedUserRegisterResponse;

public interface FederatedAuthService {

	public FederatedLoginResponse clientValidation(FederatedLoginRequest mfFederatedRequest);

	public FederatedAuthorizeResponse validateAuthorization(FederatedAuthorizeRequest validaAuthCodeRequest);
	
	public FederatedTokenResponse generateTokens(FederatedTokenRequest tokenRequest, String correlationId);

	public boolean validateAuthCode(String authCode);
	
	public FederatedAuthorizeResponse getCachedAuthCode(String authorizedCode);

	public FederatedUserRegisterResponse registerUser(FederatedUserRegisterRequest registerRequest, HttpHeaders headers);

	public HttpHeaders populateFederatedUserRegisterUtmHeaders(HttpHeaders headers, String clientId);

}
