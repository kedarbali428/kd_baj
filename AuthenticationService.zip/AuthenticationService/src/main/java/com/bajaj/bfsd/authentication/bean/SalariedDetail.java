package com.bajaj.bfsd.authentication.bean;

public class SalariedDetail {
	
	private Reference employerName;
	
	private String employerNameOther;
	
	private Reference designation;
	
	private String experience;
	
	private String netSalary;
	
	private Long employerType;

	private Integer workExperienceInMonths;
	
	private Reference principalIndustry;
	
	public SalariedDetail(){
		super();
	}

	public Reference getEmployerName() {
		return employerName;
	}

	public void setEmployerName(Reference employerName) {
		this.employerName = employerName;
	}

	public Reference getDesignation() {
		return designation;
	}

	public void setDesignation(Reference designation) {
		this.designation = designation;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(String netSalary) {
		this.netSalary = netSalary;
	}

	public Long getEmployerType() {
		return employerType;
	}

	public void setEmployerType(Long employerType) {
		this.employerType = employerType;
	}

	public String getEmployerNameOther() {
		return employerNameOther;
	}

	public void setEmployerNameOther(String employerNameOther) {
		this.employerNameOther = employerNameOther;
	}

	public Integer getWorkExperienceInMonths() {
		return workExperienceInMonths;
	}

	public void setWorkExperienceInMonths(Integer workExperienceInMonths) {
		this.workExperienceInMonths = workExperienceInMonths;
	}

	public Reference getPrincipalIndustry() {
		return principalIndustry;
	}

	public void setPrincipalIndustry(Reference principalIndustry) {
		this.principalIndustry = principalIndustry;
	}
	
	@Override
	public String toString() {
		return "SalariedDetail [employerName=" + employerName + ", employerNameOther=" + employerNameOther
				+ ", designation=" + designation + ", experience=" + experience + ", netSalary=" + netSalary
				+ ", employerType=" + employerType + ", principalIndustry=" + principalIndustry
				+ ", workExperienceInMonths=" + workExperienceInMonths + "]";
	}
}
