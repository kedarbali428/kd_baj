package com.bajaj.bfsd.authentication.bean;

public class BuildUserProfileRequest {
	
	private Long applicantKey;
	private Long applicationKey;
	private String dateOfBirth;
	private String mobile;
	private short userType;
	
	public Long getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}
	public Long getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public short getUserType() {
		return userType;
	}
	public void setUserType(short userType) {
		this.userType = userType;
	}
	
	
	

}
