package com.bajaj.bfsd.authentication.service.impl;

import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.USERTYPE_PSEUDO_CUSTOMER;
import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.USERTYPE_PSEUDO_VERIFIED_CUSTOMER;
import static com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants.USERTYPE_CUSTOMER;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.bean.UserResponse;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.service.OMAuthenticationService;
import com.bajaj.bfsd.authentication.util.TokenCodeHelper;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLHttpException;

@Component
public class OMAuthenticationServiceImpl implements OMAuthenticationService {

	@Autowired
	BFLLoggerUtilExt logger;

	@Value("${api.otp.validate.POST.url}")
	private String otpValidateUrl;

	@Autowired
	private TokenCodeHelper tokenCodeHelper;
	
	private static final String CLASS_NAME = OMAuthenticationServiceImpl.class.getCanonicalName(); 

	@Override
	public TokenResponse authenticateMobDobAndGenerateToken(MobileLoginRequest mobileLoginRequest) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside authenticateMobDobAndGenerateToken - start");

		boolean otpValidated = false;
		if (null != mobileLoginRequest.getOtp() && !mobileLoginRequest.getOtp().isEmpty()) {
			otpValidated = validateOTP(mobileLoginRequest.getMobile(), mobileLoginRequest.getOtp());
			if (!otpValidated) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Not able to validate OTP. Please check validate otp endpoint");
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH-401", "Not Able to validate OTP");
			}
		}

		Long applicantKey = null;
		if (null != mobileLoginRequest.getDateOfBirth() && !mobileLoginRequest.getDateOfBirth().isEmpty()) {
			applicantKey = tokenCodeHelper.getApplicant(mobileLoginRequest.getMobile(), mobileLoginRequest.getDateOfBirth());
		}

		short userType = USERTYPE_PSEUDO_CUSTOMER;

		if (otpValidated  && null != applicantKey) {
			userType = USERTYPE_CUSTOMER;
		} else
		if (otpValidated) {
			userType = USERTYPE_PSEUDO_VERIFIED_CUSTOMER;
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "OTP not validated or request for PSEUDO tokens");
		}

		UserResponse userResponse = tokenCodeHelper.callUserAdditionalDet(mobileLoginRequest, userType, applicantKey);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside authenticateMobDobAndGenerateToken - end");
		return tokenCodeHelper.getToken(userResponse.getLoginId(), userResponse.getUserId(), userResponse.getUserType());
	}

	private boolean validateOTP(String mobile, String otp) {

		boolean retVal = false;
		JSONObject otpValidationRequest = new JSONObject();
		otpValidationRequest.put("mobile", mobile);
		otpValidationRequest.put("otp", otp);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "OTP validate API call. URL: " + otpValidateUrl + " with request: " + otpValidationRequest);
		
		ResponseEntity<ResponseBean> otpValidationResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, otpValidateUrl, null, ResponseBean.class, null,
						otpValidationRequest.toString(), headers, null);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "OTP validate API response: " + otpValidationResponse);
		
		int statusCode = otpValidationResponse.getStatusCodeValue();

		if (statusCode == HttpStatus.OK.value()) {
			if (null != otpValidationResponse.getBody().getPayload() && 
					StatusCode.SUCCESS.name().equalsIgnoreCase(otpValidationResponse.getBody().getPayload().toString())) {
				retVal = true;
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"validateOTP - Failed to validate OTP" + otpValidationResponse.getBody().getStatus().name());
			}
		} else if (null != otpValidationResponse.getBody() && null != otpValidationResponse.getBody().getErrorBean()
				&& !otpValidationResponse.getBody().getErrorBean().isEmpty() && "OTP is invalid"
						.equalsIgnoreCase(otpValidationResponse.getBody().getErrorBean().get(0).getErrorMessage())) {
			String erroMessage = otpValidationResponse.getBody().getErrorBean().get(0).getErrorMessage();
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, erroMessage);
			throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH_630", erroMessage);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"validateOTP - Invalid status recevied from OTP generate service -" + statusCode);
		}
		return retVal;
	}

}
