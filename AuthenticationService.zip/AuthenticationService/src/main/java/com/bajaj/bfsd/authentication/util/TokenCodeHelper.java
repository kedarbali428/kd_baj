package com.bajaj.bfsd.authentication.util;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.bean.UserRequest;
import com.bajaj.bfsd.authentication.bean.UserResponse;
import com.bajaj.bfsd.authentication.model.GenerateTokenRequest;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
@RefreshScope
public class TokenCodeHelper {
	
	private static final String CLASS_NAME = TokenCodeHelper.class.getCanonicalName();
	
	@Autowired
	private BFLLoggerUtil logger;

	@Value("${api.applicant.openMarkets.getApplicantWithMoDob.GET.url}")
	private String getApplicantUrl;

	@Value("${api.usermanagement.user.additionalprofile.POST.url}")
	private String userAdditionalProfileUrl;
	
	@Value("${api.tokenmanagement.generatetoken.POST.url}")
	private String generateTokenUrl;

	@Autowired
	private RestClientUtil restClientUtil;
	
	@Autowired
	private Environment env;

	public TokenResponse generateTokens(MobileLoginRequest mobileLoginRequest, HttpHeaders headers, short userType) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "authenticateMobDobAndGenerateToken - start");
		Long applicantKey = null;
		if (null != mobileLoginRequest.getDateOfBirth() && !mobileLoginRequest.getDateOfBirth().isEmpty()) {
			applicantKey = getApplicant(mobileLoginRequest.getMobile(), mobileLoginRequest.getDateOfBirth());
		}
		UserResponse userResponse = callUserAdditionalDet(mobileLoginRequest, userType, applicantKey);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "authenticateMobDobAndGenerateToken - end");
		return generateTokens(userResponse.getLoginId().toString(), userResponse.getUserId(), userResponse.getUserType(), headers);
	}

	public Long getApplicant(String mobile, String dateOfBirth) {
		Long applicantKey = null;

		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("mobile", mobile);
		queryParam.put("dateOfBirth", dateOfBirth);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Applicant Get API call. URL: " + getApplicantUrl + " with request: " + queryParam);
		
		ResponseEntity<String> getApplicantResponse = (ResponseEntity<String>) BFLCommonRestClient.invokeRestEndpoint(
				HttpMethod.GET, getApplicantUrl, null, String.class, queryParam, null, headers, null);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Applicant Get API response: " + getApplicantResponse);
		
		if (HttpStatus.OK == getApplicantResponse.getStatusCode() && null != getApplicantResponse.getBody()) {
			JSONObject payload = new JSONObject(getApplicantResponse.getBody());
			applicantKey = payload.getLong("applicantKey");

		} else if (HttpStatus.NOT_FOUND == getApplicantResponse.getStatusCode()
				&& null != getApplicantResponse.getBody()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Applicant not available with given mobile: " + mobile + "and dateOfBirth: " + dateOfBirth);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Get Applicant call returned not valid response. Please check: "
							+ getApplicantResponse.getStatusCodeValue());
		}

		return applicantKey;
	}

	public UserResponse callUserAdditionalDet(MobileLoginRequest mobileLoginRequest, short userType,
			Long applicantKey) {
		UserResponse userResponse = null;

		UserRequest userRequest = new UserRequest();
		userRequest.setMobile(mobileLoginRequest.getMobile());
		userRequest.setDateOfBirth(mobileLoginRequest.getDateOfBirth());
		userRequest.setUserType(userType);
		userRequest.setApplicationKey(mobileLoginRequest.getApplicationKey());
		userRequest.setApplicantKey(applicantKey);

		JSONObject userRequestJson = new JSONObject(userRequest);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "User Profile Creation API call. URL: " + userAdditionalProfileUrl + " with request: " + userRequestJson);

		ResponseEntity<UserResponse> userAdditionalDetRepsponse = (ResponseEntity<UserResponse>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, userAdditionalProfileUrl, null, UserResponse.class, null,
						userRequestJson.toString(), headers, null);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "User Profile Creation API response: " + userAdditionalDetRepsponse);
		
		if (HttpStatus.CREATED == userAdditionalDetRepsponse.getStatusCode()
				&& null != userAdditionalDetRepsponse.getBody()) {
			userResponse = userAdditionalDetRepsponse.getBody();
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Not a valid response from User Additional Profile endpoint call"
							+ userAdditionalDetRepsponse.getStatusCodeValue());
			throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR, "AUTH-500", "User Fetch call failure");
		}

		return userResponse;
	}
	
	public TokenResponse getToken(String loginId, Long userId, short userType) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "getToken started with loginId: " + loginId);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		TokenResponse tokenResponse = generateTokens(loginId , userId , userType , headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "getToken ended with loginId: " + loginId);
		return tokenResponse;
	}

	TokenResponse generateTokens(String loginId, long userId, short userType,HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "callGenerateTokens started with loginId: " + loginId);
		GenerateTokenRequest generateTokenReq = new GenerateTokenRequest();
		generateTokenReq.setLoginId(loginId);
		generateTokenReq.setUserId(userId);
		generateTokenReq.setUserType(userType);
		TokenResponse tokenResponse = null;
		try {
			ResponseEntity<ResponseBean> response = restClientUtil.postCall(generateTokenUrl, generateTokenReq, 
					headers, ResponseBean.class);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "callGenerateTokens Response: " + response);
			if(StatusCode.SUCCESS.equals(response.getBody().getStatus())){
				ObjectMapper objectMapper = MapperFactory.getInstance();
				tokenResponse = objectMapper.convertValue(response.getBody().getPayload(), TokenResponse.class);
			}else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Generate token failed for user Id - " + userId);
				throw new BFLBusinessException("AUTH-501", "Generate token failed for user Id - "+ userId);
			}
		}catch(BFLHttpException | BFLBusinessException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Some exception ocurred in callGenerateTokens token ", ex);
			throw new BFLHttpException(HttpStatus.OK, "AUTH_649", env.getProperty("AUTH_649"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "callGenerateTokens ended with response: " + tokenResponse);
		return tokenResponse;
	}

}
