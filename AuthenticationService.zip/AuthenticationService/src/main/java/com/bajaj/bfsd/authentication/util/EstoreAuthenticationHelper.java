package com.bajaj.bfsd.authentication.util;

import java.net.URI;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.bajaj.bfsd.authentication.bean.Name;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterResponse;
import com.bajaj.bfsd.authentication.bean.Occupation;
import com.bajaj.bfsd.authentication.bean.Reference;
import com.bajaj.bfsd.authentication.bean.SalariedDetail;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV3;
import com.bajaj.bfsd.authentication.bean.UserProfileAttribute;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UtmParameters;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class EstoreAuthenticationHelper {
	
	private static final String THIS_CLASS = AuthenticationServiceHelper.class.getCanonicalName();
	
	private static final String FAILURE = "FAILURE";

	private static final String SUCCESS = "SUCCESS";
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	Environment env;
	
	@Value("${api.authentication.ntp.preregister.POST.url}")
	private String createEstoreApplicantUrl;
	
	
	public void validateLoginIDV3(String loginId) {
		if (!loginId.matches("^[6-9][0-9]{9}$")) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,
					AuthenticationServiceConstants.ID_PASS_VALIDATION_FAIL);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST,AuthenticationServiceConstants.AUTH_636,
					env.getProperty(AuthenticationServiceConstants.AUTH_636));
		}

	}
	
	/**
	 * Validate the date for emptiness and required format
	 * @param date
	 * @param logger
	 * @param env
	 */
	public void validateDate(String date) {
		DateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		// Input to be parsed should strictly follow the defined date format
		// above.
		format.setLenient(false);
		if (StringUtils.isNotBlank(date)) {
			try {
				format.parse(date);
			} catch (ParseException e) {
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,
						AuthenticationServiceConstants.DATE_VALIDATION_FAILURE);
				throw new BFLHttpException(HttpStatus.BAD_REQUEST,AuthenticationServiceConstants.AUTH_640,
						env.getProperty(AuthenticationServiceConstants.AUTH_640));
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,
					AuthenticationServiceConstants.DATE_VALIDATION_FAILURE);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST,AuthenticationServiceConstants.AUTH_640,
					env.getProperty(AuthenticationServiceConstants.AUTH_640));
		}
	}
	
	/**
	 * Validate the loginId and password for number only and for length.
	 * 
	 * @param mobileUserLoginRequest
	 */
	public void validateLoginPass(String mpin) {
		if (!mpin.matches("[\\d]{4}")) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,
					AuthenticationServiceConstants.ID_PASS_VALIDATION_FAIL);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST,AuthenticationServiceConstants.AUTH_636,
					env.getProperty(AuthenticationServiceConstants.AUTH_636));
		}

	}
	
	public static TokenResponse getToken(String tokenServiceURL, String requestString, BFLLoggerUtil logger,HttpHeaders headers) {
		ResponseEntity<ResponseBean> tokenServiceResponse = BFLCommonRestClient.create(tokenServiceURL, null,
				String.class, null, requestString, headers, null);
		TokenResponse tokenResponse;

		if (tokenServiceResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(tokenServiceResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Failed to authenticate user");
				throw new BFLBusinessException("AUTH-001", "Failed to authenticate user");
			} else {

				JSONObject respJson = new JSONObject(tokenServiceResponse.getBody().getPayload().toString());
				JSONObject payloadJson = respJson.has("payload") ? respJson.getJSONObject("payload") : new JSONObject();

				Gson gson = new Gson();
				tokenResponse = gson.fromJson(payloadJson.toString(), TokenResponse.class);

				return tokenResponse;
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Get token failed for login ID - ");
			throw new BFLBusinessException("500", "Get token failed for login ID - ");
		}
	}	
	
	public static String timeStampToStringDate(Timestamp dateOfBirth) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(dateOfBirth);
	}
	
	public NtpPreRegisterResponse createApplicant(UserLoginAccountRequestV3 bean, UtmParameters utmParameters,HttpHeaders headers) {
		NtpPreRegisterResponse createApplicantResponse=null;
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY,
				"inside createApplicant start with mobile Number:" + bean.getMobileNumber());
		URI uri = UriComponentsBuilder.fromUriString(createEstoreApplicantUrl).build().toUri();
		NtpPreRegisterRequest ntpPreRegisterRequest=new NtpPreRegisterRequest();
		ntpPreRegisterRequest.setMobileNumber(bean.getMobileNumber());
		ntpPreRegisterRequest.setDateOfBirth(bean.getDateOfBirth());
		JSONObject jsonRequest = new JSONObject(ntpPreRegisterRequest);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(jsonRequest.toString(), headers);
		RestTemplate restClient = getRestTemplate();
		ResponseEntity<String> response = null;
		try {
		response = restClient.exchange(uri.toString(), HttpMethod.POST, requestEntity, String.class);
		JSONObject jsonApplicantResponseJsonObject=new JSONObject(response.getBody().toString());
		if(SUCCESS.equalsIgnoreCase(jsonApplicantResponseJsonObject.getString("status")))
		{
			String responseString=jsonApplicantResponseJsonObject.get("payload").toString();
			JSONObject jsonObject=new JSONObject(responseString);
			ObjectMapper objectMapper=MapperFactory.getInstance();
			createApplicantResponse=objectMapper.readValue(jsonObject.toString(), NtpPreRegisterResponse.class);}
		else if(FAILURE.equalsIgnoreCase(jsonApplicantResponseJsonObject.getString("status")))
		{
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error Occured from Creating Applicant API's");
			throw new BFLHttpException(HttpStatus.OK,AuthenticationServiceConstants.AUTH_712,
					env.getProperty(AuthenticationServiceConstants.AUTH_712));
		}
		}catch(Exception exception)
		{
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception Occured while Creating applicant");
			throw new BFLHttpException(HttpStatus.OK,AuthenticationServiceConstants.AUTH_647,
					env.getProperty(AuthenticationServiceConstants.AUTH_647));
		}
		
		return createApplicantResponse;
		
	}
	
	public RestTemplate getRestTemplate() {
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		requestFactory.setConnectTimeout(15000);
		return new RestTemplate(requestFactory);
	}

	public UserProfileAttribute mapFullNameData(UpdateUserProfileDetailsRequest userProfileDetailsPutReq)
	{
		UserProfileAttribute userProfileAttribute=new UserProfileAttribute();
		Name name=new Name();
		String fullName=StringUtils.normalizeSpace(userProfileDetailsPutReq.getPersonalDetails().getName().getUserInput());
		String[] splittedData=fullName.split(" ");
		if(splittedData.length>2)
		{
			name.setFirstName(splittedData[0]);
			name.setMiddleName(splittedData[1]);
			name.setLastName(splittedData[2]);
		}
		else if(splittedData.length==2)
		{
			name.setFirstName(splittedData[0]);
			name.setLastName(splittedData[1]);
		}
		else
		{
			name.setFirstName(splittedData[0]);
		}
		userProfileAttribute.setName(name);
		return userProfileAttribute;
		
	}
	
	public Occupation mapOccupationData(UpdateUserProfileDetailsRequest userProfileDetailsPutReq)
	{
		Occupation occupation=new Occupation();
		Reference reference=new Reference();
		SalariedDetail salariedDetail=new SalariedDetail();
		if(!(StringUtils.isEmpty(userProfileDetailsPutReq.getPersonalDetails().getOccupation().getUserInput())))
		{
			if("SALR".equalsIgnoreCase(userProfileDetailsPutReq.getPersonalDetails().getOccupation().getUserInput()))
				{
				reference.setCode("SALR");
				reference.setKey(1L);
				reference.setValue("Salaried");
				}
			else if("SEMP".equalsIgnoreCase(userProfileDetailsPutReq.getPersonalDetails().getOccupation().getUserInput()))
				{
				reference.setCode("SEMP");
				reference.setKey(2L);
				reference.setValue("Self Employed");
				}
			else if("CAICWA".equalsIgnoreCase(userProfileDetailsPutReq.getPersonalDetails().getOccupation().getUserInput()))
			{
			reference.setCode("CAICWA");
			reference.setKey(7L);
			reference.setValue("CAI/ICWA");
			}
			else if("DOCSAL".equalsIgnoreCase(userProfileDetailsPutReq.getPersonalDetails().getOccupation().getUserInput()))
			{
			reference.setCode("DOCSAL");
			reference.setKey(6L);
			reference.setValue("Salaried Doctor");
			}
			else if("DOCSEMP".equalsIgnoreCase(userProfileDetailsPutReq.getPersonalDetails().getOccupation().getUserInput()))
			{
			reference.setCode("DOCSEMP");
			reference.setKey(9L);
			reference.setValue("Self-employed Doctor");
			}
			else if("OTHER".equalsIgnoreCase(userProfileDetailsPutReq.getPersonalDetails().getOccupation().getUserInput()))
			{
			reference.setCode("OTHER");
			reference.setKey(8L);
			reference.setValue("OTHER");
			}
		}
		occupation.setOcupationType(reference);
		occupation.setSalariedDetail(salariedDetail);
		return occupation;
	}

}
