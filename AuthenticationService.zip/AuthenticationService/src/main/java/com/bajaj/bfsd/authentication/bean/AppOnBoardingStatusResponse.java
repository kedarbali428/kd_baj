package com.bajaj.bfsd.authentication.bean;

public class AppOnBoardingStatusResponse {
	
	private UserStatusBean userStatus;
	private String otpSent;
	private String nextTaskKey;
	
	public UserStatusBean getUserStatus() {
		return userStatus;
	}
	
	public void setUserStatus(UserStatusBean userStatus) {
		this.userStatus = userStatus;
	}
	
	public String getOtpSent() {
		return otpSent;
	}
	
	public void setOtpSent(String otpSent) {
		this.otpSent = otpSent;
	}
	
	public String getNextTaskKey() {
		return nextTaskKey;
	}
	
	public void setNextTaskKey(String nextTaskKey) {
		this.nextTaskKey = nextTaskKey;
	}

	@Override
	public String toString() {
		return "AppOnBoardingStatusResponse [userStatus=" + userStatus + ", otpSent=" + otpSent + ", nextTaskKey="
				+ nextTaskKey + "]";
	}

}
