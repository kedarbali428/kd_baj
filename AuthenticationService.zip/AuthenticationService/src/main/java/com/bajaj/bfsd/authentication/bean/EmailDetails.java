package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class EmailDetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String preFillValue;
	private String userInput;
	/**
	 * @return the preFillValue
	 */
	public String getPreFillValue() {
		return preFillValue;
	}
	/**
	 * @param preFillValue the preFillValue to set
	 */
	public void setPreFillValue(String preFillValue) {
		this.preFillValue = preFillValue;
	}
	/**
	 * @return the userInput
	 */
	public String getUserInput() {
		return userInput;
	}
	/**
	 * @param userInput the userInput to set
	 */
	public void setUserInput(String userInput) {
		this.userInput = userInput;
	}
	
	

}

