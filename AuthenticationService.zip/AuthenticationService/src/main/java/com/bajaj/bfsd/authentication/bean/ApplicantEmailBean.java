package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;
/**
 * Description of the class
 * This class is the bean class for the email of applicant in Applicant Service
 *
 * @author Cognizant - Date - 16/11/2016
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                                       16/11/2016
 *
 */
public class ApplicantEmailBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4876004822761907742L;
	private Long key;
	@NotNull(message="Email Address can not be null")
	private String emailAddress;
	@NotNull(message="Email isVerified can not be null")
	private BigDecimal isVerified;
	private BigDecimal idPriority;
	@NotNull(message="Email Type can not be null")
	private String type;
	private Long applicantKey;

	/**
	 * @return the key
	 */
	public Long getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(Long key) {
		this.key = key;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the isVerified
	 */
	public BigDecimal getIsVerified() {
		return isVerified;
	}

	/**
	 * @param isVerified the isVerified to set
	 */
	public void setIsVerified(BigDecimal isVerified) {
		this.isVerified = isVerified;
	}

	/**
	 * @return the idPriority
	 */
	public BigDecimal getIdPriority() {
		return idPriority;
	}

	/**
	 * @param idPriority the idPriority to set
	 */
	public void setIdPriority(BigDecimal idPriority) {
		this.idPriority = idPriority;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the applicantKey
	 */
	public Long getApplicantKey() {
		return applicantKey;
	}

	/**
	 * @param applicantKey the applicantKey to set
	 */
	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	@Override
	public String toString() {
		return "ApplicantEmailBean [key=" + key + ", emailAddress=" + emailAddress + ", isVerified=" + isVerified
				+ ", idPriority=" + idPriority + ", type=" + type + ", applicantKey=" + applicantKey + "]";
	}

}
