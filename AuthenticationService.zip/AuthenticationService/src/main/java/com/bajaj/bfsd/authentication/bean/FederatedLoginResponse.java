package com.bajaj.bfsd.authentication.bean;

public class FederatedLoginResponse {

	private String authorizationCode;

	public String getAuthorizationCode() {
		return authorizationCode;
	}

	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}

	@Override
	public String toString() {
		return "FederatedLoginResponse [authorizationCode=" + authorizationCode + "]";
	}

}
