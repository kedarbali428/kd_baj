package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class UserKeysBeanWithTokens implements Serializable {

	private static final long serialVersionUID = 5214151939252231697L;

	private UserKeysBean userKeysBean;

	private TokenResponseForUserRegister tokenResponse;

	private UserDetails userDetails;

	public UserKeysBean getUserKeysBean() {
		return userKeysBean;
	}

	public void setUserKeysBean(UserKeysBean userKeysBean) {
		this.userKeysBean = userKeysBean;
	}

	public TokenResponseForUserRegister getTokenResponse() {
		return tokenResponse;
	}

	public void setTokenResponse(TokenResponseForUserRegister tokenResponse) {
		this.tokenResponse = tokenResponse;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

}
