package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the USER_LOGIN_ACTIVITY_LOG database table.
 * 
 */
@Entity
@Table(name="USER_LOGIN_ACTIVITY_LOG")
//@NamedQuery(name="UserLoginActivityLog.findAll", query="SELECT u FROM UserLoginActivityLog u")
public class UserLoginActivityLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long userlogactlogkey;

	private String browser;

	private String deviceid;

	private String ipaddress;

	private BigDecimal latitude;

	private Timestamp logindt;

	private BigDecimal loginsrcwebapp;

	private Timestamp logoutdt;

	private Timestamp logsessionfrcenddt;

	private BigDecimal logsessionfrcendflg;

	private String logsessionfrcendreason;

	private BigDecimal longitude;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="USERKEY")
	private BfsdUser bfsdUser;

	public UserLoginActivityLog() {
	}

	public long getUserlogactlogkey() {
		return this.userlogactlogkey;
	}

	public void setUserlogactlogkey(long userlogactlogkey) {
		this.userlogactlogkey = userlogactlogkey;
	}

	public String getBrowser() {
		return this.browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getDeviceid() {
		return this.deviceid;
	}

	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	public String getIpaddress() {
		return this.ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public BigDecimal getLatitude() {
		return this.latitude;
	}

	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	public Timestamp getLogindt() {
		return this.logindt;
	}

	public void setLogindt(Timestamp logindt) {
		this.logindt = logindt;
	}

	public BigDecimal getLoginsrcwebapp() {
		return this.loginsrcwebapp;
	}

	public void setLoginsrcwebapp(BigDecimal loginsrcwebapp) {
		this.loginsrcwebapp = loginsrcwebapp;
	}

	public Timestamp getLogoutdt() {
		return this.logoutdt;
	}

	public void setLogoutdt(Timestamp logoutdt) {
		this.logoutdt = logoutdt;
	}

	public Timestamp getLogsessionfrcenddt() {
		return this.logsessionfrcenddt;
	}

	public void setLogsessionfrcenddt(Timestamp logsessionfrcenddt) {
		this.logsessionfrcenddt = logsessionfrcenddt;
	}

	public BigDecimal getLogsessionfrcendflg() {
		return this.logsessionfrcendflg;
	}

	public void setLogsessionfrcendflg(BigDecimal logsessionfrcendflg) {
		this.logsessionfrcendflg = logsessionfrcendflg;
	}

	public String getLogsessionfrcendreason() {
		return this.logsessionfrcendreason;
	}

	public void setLogsessionfrcendreason(String logsessionfrcendreason) {
		this.logsessionfrcendreason = logsessionfrcendreason;
	}

	public BigDecimal getLongitude() {
		return this.longitude;
	}

	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

}