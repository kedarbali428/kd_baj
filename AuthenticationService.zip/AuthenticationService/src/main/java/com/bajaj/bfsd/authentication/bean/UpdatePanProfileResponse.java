package com.bajaj.bfsd.authentication.bean;

public class UpdatePanProfileResponse {

	private String nextTaskKey;

	public String getNextTaskKey() {
		return nextTaskKey;
	}

	public void setNextTaskKey(String nextTaskKey) {
		this.nextTaskKey = nextTaskKey;
	}

	@Override
	public String toString() {
		return "UpdatePanProfileResponse [nextTaskKey=" + nextTaskKey + "]";
	}
	
}