package com.bajaj.bfsd.authentication.bean.validationgroup;

/* 
 * Note: 
 * This class provide sequence for bean validation
 * in AppOnBoarding Update Profile request based on Pan
 * 
*/

import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;

import com.bajaj.bfsd.authentication.bean.UpdatePanProfileRequest;

public class UpdatePanProfileValidationGroupSequenceProvider implements DefaultGroupSequenceProvider<UpdatePanProfileRequest> {

	  @Override
	  public List<Class<?>> getValidationGroups(UpdatePanProfileRequest car) {
	    List<Class<?>> defaultGroupSequence = new ArrayList<>();
	    defaultGroupSequence.add(UpdatePanProfileRequest.class);
	    defaultGroupSequence.add(UpdatePanProfileValidationOrderGroup.class);
	    return defaultGroupSequence;
	  }
}



