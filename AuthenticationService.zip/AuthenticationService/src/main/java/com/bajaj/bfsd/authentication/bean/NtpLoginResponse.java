package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;
import java.util.List;

import com.bajaj.bfsd.authentication.model.Tokens;

public class NtpLoginResponse implements Serializable {

	private static final long serialVersionUID = 4412459278414090970L;

	List<Tokens> tokens;

	public List<Tokens> getTokens() {
		return tokens;
	}

	public void setTokens(List<Tokens> tokens) {
		this.tokens = tokens;
	}

}
