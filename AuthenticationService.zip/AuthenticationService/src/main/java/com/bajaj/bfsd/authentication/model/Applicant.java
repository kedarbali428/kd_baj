/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

/**
 * This is a bean class for Applicant.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	16/12/2016      Initial Version
 */
public class Applicant implements Serializable{
       
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 7687445562523841058L;

    /**
     * Variable to hold value for applicant id.
     */
    private Long applicantId;
        
    /**
     * Variable to hold value for token.
     */
    private String token;
    
    /**
     * Getter method for applicant id.
     *
     * @return applicant id
     */
    public Long getApplicantId() {
        return applicantId;
    }
    
    /**
     * Sets the value of applicant id.
     *
     * @param applicantId the new applicant id
     */
    public void setApplicantId(Long applicantId) {
        this.applicantId = applicantId;
    }
    
    
    /**
     * Getter method for token.
     *
     * @return token
     */
    public String getToken() {
        return token;
    }
    
    /**
     * Sets the value of token.
     *
     * @param token the new token
     */
    public void setToken(String token) {
        this.token = token;
    }
    
}
