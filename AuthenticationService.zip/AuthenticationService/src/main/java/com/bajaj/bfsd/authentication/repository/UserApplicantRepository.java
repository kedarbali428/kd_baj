package com.bajaj.bfsd.authentication.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bajaj.bfsd.authentication.model.Userapplicants;


public interface UserApplicantRepository extends JpaRepository<Userapplicants, Long> {
	
	Userapplicants findByApplicantkey(BigDecimal applicantKey);

}
