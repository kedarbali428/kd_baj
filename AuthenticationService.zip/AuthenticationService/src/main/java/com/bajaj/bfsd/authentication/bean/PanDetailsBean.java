package com.bajaj.bfsd.authentication.bean;

public class PanDetailsBean {

	private String preFillValue;
	private String userInput;
	
	public String getPreFillValue() {
		return preFillValue;
	}
	
	public void setPreFillValue(String preFillValue) {
		this.preFillValue = preFillValue;
	}
	public String getUserInput() {
		return userInput;
	}
		
	public void setUserInput(String userInput) {
		this.userInput = userInput;
	}
	
	

}
