package com.bajaj.bfsd.authentication.bean;

import org.hibernate.validator.constraints.NotBlank;

public class HashGeneratorRequest {

	@NotBlank(message = "text cannot be null or blank")
	private String text;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "HashGeneratorRequest [text=" + (null != text) + "]";
	}

}
