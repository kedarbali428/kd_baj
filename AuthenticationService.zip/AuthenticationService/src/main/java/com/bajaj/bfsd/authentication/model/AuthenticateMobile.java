package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class AuthenticateMobile implements Serializable{

	
	private static final long serialVersionUID = 1L;
	
	@NotNull(message = "OTP-002")
	private String mobile;

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	

}
