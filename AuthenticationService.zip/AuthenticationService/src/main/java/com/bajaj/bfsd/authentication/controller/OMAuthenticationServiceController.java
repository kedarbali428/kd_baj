package com.bajaj.bfsd.authentication.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.request.validator.RequestValidator;
import com.bajaj.bfsd.authentication.service.OMAuthenticationService;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bfl.common.exceptions.BFLHttpException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class OMAuthenticationServiceController extends BFLController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	OMAuthenticationService omAuthenticationService;
	
	@Autowired
	RequestValidator requestValidator;

	@ApiOperation(value = "Authenticate Mobile and Generate Pseudo Token", notes = "Authenticate Mobile and Generate Pseudo Token", httpMethod = "POST", response = ResponseBean.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Returns Pseudo Token", response = TokenResponse.class),
			@ApiResponse(code = 400, message = "Returns field errors", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Returns Unauthorized for invalid OTP", response = ErrorBean.class) })
	@RequestMapping(value = "${api.authentication.authenticatemobiledobandgeneratetokenV2.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> authenticateMobDobAndGenerateToken(
			@Valid @RequestBody MobileLoginRequest mobileLoginRequest, BindingResult bindingResult) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
				"Inside authenticateMobDobAndGenerateToken - start with request: " + mobileLoginRequest);

		if (bindingResult.hasErrors()) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					"Not a valid request. Please check the request: " + mobileLoginRequest);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		} 
		
		ErrorBean errorBean = requestValidator.validateRequest(mobileLoginRequest);
		
		if (null != errorBean) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					"Not a valid request. Please check the request: " + mobileLoginRequest);
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, errorBean.getErrorCode(), errorBean.getErrorMessage());
		} else {
			TokenResponse tokenResponse = omAuthenticationService
					.authenticateMobDobAndGenerateToken(mobileLoginRequest);
			
			removeUserKey(tokenResponse, true);
			
			ResponseBean response = new ResponseBean(tokenResponse);

			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER,
					"Inside authenticateMobDobAndGenerateToken - end with response: " + tokenResponse);
			return new ResponseEntity<ResponseBean>(response, HttpStatus.CREATED);
		}
	}
	
	private void removeUserKey(TokenResponse tokenResponse, boolean userKeyFlag) {
		if(userKeyFlag){
			tokenResponse.setUserKey(null);
			tokenResponse.setDefaultRole(null);
		}		
	}	
}
