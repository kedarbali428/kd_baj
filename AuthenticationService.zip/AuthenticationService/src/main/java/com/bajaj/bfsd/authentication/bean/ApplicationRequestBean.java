package com.bajaj.bfsd.authentication.bean;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

public class ApplicationRequestBean {

	private String applicationId;
	private String applicantId;
	private String firstName;
	private String lastName;
	private String panNumber;
	private String dateOfBirth;
	private String mobileNumber;
	private String pinCode;
	private BigDecimal netMonthlySalary;
	private String occupationType;
	private String turnOver;
	private String turnOverRange;
	private String emailId;
	private Boolean isTermSelected;
	@NotNull(message = "AppSource can not be null")
	private String appSource;
	@NotNull(message = "AppStatus can not be null")
	private Integer appStatus;
	@NotNull(message = "AppJourneyStamp can not be null")
	private String appJourneyStamp;
	private String appUtmRefCode;
	private String appUtmSource;
	private String appUtmMedium;
	private String appUtmCampaign;
	private String appUtmTerm;
	private String appUtmContent;
	private String queueName;
	private String questionKey;
	private String answerKey;
	private String userInputAnswer;
	private Boolean resendEligible;
	private Boolean skipEligible;
	private Boolean resendOTP;
	private String challengeConfigGUID;
	private String cibilTypeFlag;

	
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public BigDecimal getNetMonthlySalary() {
		return netMonthlySalary;
	}
	public void setNetMonthlySalary(BigDecimal netMonthlySalary) {
		this.netMonthlySalary = netMonthlySalary;
	}
	public String getOccupationType() {
		return occupationType;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public String getTurnOver() {
		return turnOver;
	}
	public void setTurnOver(String turnOver) {
		this.turnOver = turnOver;
	}
	public String getTurnOverRange() {
		return turnOverRange;
	}
	public void setTurnOverRange(String turnOverRange) {
		this.turnOverRange = turnOverRange;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public Boolean getIsTermSelected() {
		return isTermSelected;
	}
	public void setIsTermSelected(Boolean isTermSelected) {
		this.isTermSelected = isTermSelected;
	}
	public String getAppSource() {
		return appSource;
	}
	public void setAppSource(String appSource) {
		this.appSource = appSource;
	}
	public Integer getAppStatus() {
		return appStatus;
	}
	public void setAppStatus(Integer appStatus) {
		this.appStatus = appStatus;
	}
	public String getAppJourneyStamp() {
		return appJourneyStamp;
	}
	public void setAppJourneyStamp(String appJourneyStamp) {
		this.appJourneyStamp = appJourneyStamp;
	}
	public String getAppUtmRefCode() {
		return appUtmRefCode;
	}
	public void setAppUtmRefCode(String appUtmRefCode) {
		this.appUtmRefCode = appUtmRefCode;
	}
	public String getAppUtmSource() {
		return appUtmSource;
	}
	public void setAppUtmSource(String appUtmSource) {
		this.appUtmSource = appUtmSource;
	}
	public String getAppUtmMedium() {
		return appUtmMedium;
	}
	public void setAppUtmMedium(String appUtmMedium) {
		this.appUtmMedium = appUtmMedium;
	}
	public String getAppUtmCampaign() {
		return appUtmCampaign;
	}
	public void setAppUtmCampaign(String appUtmCampaign) {
		this.appUtmCampaign = appUtmCampaign;
	}
	public String getAppUtmTerm() {
		return appUtmTerm;
	}
	public void setAppUtmTerm(String appUtmTerm) {
		this.appUtmTerm = appUtmTerm;
	}
	public String getAppUtmContent() {
		return appUtmContent;
	}
	public void setAppUtmContent(String appUtmContent) {
		this.appUtmContent = appUtmContent;
	}
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public String getQuestionKey() {
		return questionKey;
	}
	public void setQuestionKey(String questionKey) {
		this.questionKey = questionKey;
	}
	public String getAnswerKey() {
		return answerKey;
	}
	public void setAnswerKey(String answerKey) {
		this.answerKey = answerKey;
	}
	public String getUserInputAnswer() {
		return userInputAnswer;
	}
	public void setUserInputAnswer(String userInputAnswer) {
		this.userInputAnswer = userInputAnswer;
	}
	public Boolean getResendEligible() {
		return resendEligible;
	}
	public void setResendEligible(Boolean resendEligible) {
		this.resendEligible = resendEligible;
	}
	public Boolean getSkipEligible() {
		return skipEligible;
	}
	public void setSkipEligible(Boolean skipEligible) {
		this.skipEligible = skipEligible;
	}
	public Boolean getResendOTP() {
		return resendOTP;
	}
	public void setResendOTP(Boolean resendOTP) {
		this.resendOTP = resendOTP;
	}
	public String getChallengeConfigGUID() {
		return challengeConfigGUID;
	}
	public void setChallengeConfigGUID(String challengeConfigGUID) {
		this.challengeConfigGUID = challengeConfigGUID;
	}	

	public String getCibilTypeFlag() {
		return cibilTypeFlag;
	}
	public void setCibilTypeFlag(String cibilTypeFlag) {
		this.cibilTypeFlag = cibilTypeFlag;
	}
	@Override
	public String toString() {
		return "ApplicationRequestBean [applicationId=" + applicationId + ", applicantId=" + applicantId
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", panNumber=" + panNumber + ", dateOfBirth="
				+ dateOfBirth + ", mobileNumber=" + mobileNumber + ", pinCode=" + pinCode + ", netMonthlySalary="
				+ netMonthlySalary + ", occupationType=" + occupationType + ", turnOver=" + turnOver
				+ ", turnOverRange=" + turnOverRange + ", emailId=" + emailId + ", isTermSelected=" + isTermSelected
				+ ", appSource=" + appSource + ", appStatus=" + appStatus + ", appJourneyStamp=" + appJourneyStamp
				+ ", appUtmRefCode=" + appUtmRefCode + ", appUtmSource=" + appUtmSource + ", appUtmMedium="
				+ appUtmMedium + ", appUtmCampaign=" + appUtmCampaign + ", appUtmTerm=" + appUtmTerm
				+ ", appUtmContent=" + appUtmContent + ", queueName=" + queueName + ", questionKey=" + questionKey
				+ ", answerKey=" + answerKey + ", userInputAnswer=" + userInputAnswer + ", resendEligible="
				+ resendEligible + ", skipEligible=" + skipEligible + ", resendOTP=" + resendOTP
				+ ", challengeConfigGUID=" + challengeConfigGUID + ", cibilTypeFlag=" + cibilTypeFlag + "]";
	}

	
	
}
	