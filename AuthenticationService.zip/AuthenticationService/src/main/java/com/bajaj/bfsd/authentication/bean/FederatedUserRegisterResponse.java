package com.bajaj.bfsd.authentication.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value = Include.NON_NULL)
public class FederatedUserRegisterResponse {

	private String customerAuthToken;
		
	private NtpPreRegisterResponse preRegisterResponse;

	public String getCustomerAuthToken() {
		return customerAuthToken;
	}

	public void setCustomerAuthToken(String customerAuthToken) {
		this.customerAuthToken = customerAuthToken;
	}

	public NtpPreRegisterResponse getPreRegisterResponse() {
		return preRegisterResponse;
	}

	public void setPreRegisterResponse(NtpPreRegisterResponse preRegisterResponse) {
		this.preRegisterResponse = preRegisterResponse;
	}

	@Override
	public String toString() {
		return "FederatedUserRegisterResponse [customerAuthToken=" + customerAuthToken +
				", preRegisterResponse=" + preRegisterResponse + "]";
	}

	
}
