package com.bajaj.bfsd.authentication.bean;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class Email {

	@NotNull(message = "typeKey can not be null")
	private Long typeKey;

	@NotBlank(message = "email can not be null")
	private String email;

	private Verification verification;

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the verification
	 */
	public Verification getVerification() {
		return verification;
	}

	/**
	 * @param verification
	 *            the verification to set
	 */
	public void setVerification(Verification verification) {
		this.verification = verification;
	}

	/**
	 * @return the typeKey
	 */
	public Long getTypeKey() {
		return typeKey;
	}

	/**
	 * @param typeKey
	 *            the typeKey to set
	 */
	public void setTypeKey(Long typeKey) {
		this.typeKey = typeKey;
	}

}
