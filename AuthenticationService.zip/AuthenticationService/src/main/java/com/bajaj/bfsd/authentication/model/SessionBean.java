package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

public class SessionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	Integer mobileNumber;
	String dateOfBirth;
	String applicationKey;
	Integer retryCount;
	String applicantKey;
	Integer validity;
	Integer validityUnit;
	/**
	 * @return the mobileNumber
	 */
	public Integer getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(Integer mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	/**
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @return the applicationKey
	 */
	public String getApplicationKey() {
		return applicationKey;
	}
	/**
	 * @param applicationKey the applicationKey to set
	 */
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}
	/**
	 * @return the retryCount
	 */
	public Integer getRetryCount() {
		return retryCount;
	}
	/**
	 * @param retryCount the retryCount to set
	 */
	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}
	/**
	 * @return the applicantKey
	 */
	public String getApplicantKey() {
		return applicantKey;
	}
	/**
	 * @param applicantKey the applicantKey to set
	 */
	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}
	/**
	 * @return the validity
	 */
	public Integer getValidity() {
		return validity;
	}
	/**
	 * @param validity the validity to set
	 */
	public void setValidity(Integer validity) {
		this.validity = validity;
	}
	/**
	 * @return the validityUnit
	 */
	public Integer getValidityUnit() {
		return validityUnit;
	}
	/**
	 * @param validityUnit the validityUnit to set
	 */
	public void setValidityUnit(Integer validityUnit) {
		this.validityUnit = validityUnit;
	}

	

	
}
