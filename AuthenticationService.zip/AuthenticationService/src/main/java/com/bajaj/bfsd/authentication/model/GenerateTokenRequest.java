package com.bajaj.bfsd.authentication.model;

public class GenerateTokenRequest{
	
	private long userId;
	private String loginId;
	private short userType;
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public short getUserType() {
		return userType;
	}
	public void setUserType(short userType) {
		this.userType = userType;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((loginId == null) ? 0 : loginId.hashCode());
		result = prime * result + (int) (userId ^ (userId >>> 32));
		result = prime * result + userType;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GenerateTokenRequest other = (GenerateTokenRequest) obj;
		if (loginId == null) {
			if (other.loginId != null)
				return false;
		} else if (!loginId.equals(other.loginId))
			return false;
		if (userId != other.userId)
			return false;
		if (userType != other.userType)
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "GenerateTokenRequest [userId=" + userId + ", loginId=" + loginId + ", userType=" + userType + "]";
	}

	


}
