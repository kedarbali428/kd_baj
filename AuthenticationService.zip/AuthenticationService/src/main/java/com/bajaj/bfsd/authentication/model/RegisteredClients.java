package com.bajaj.bfsd.authentication.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "REGISTERED_CLIENTS")
public class RegisteredClients {

	@Id
	@Column(name = "CLIENTID")
	private String clientid;
	
	@Column(name = "CLIENTAPPLICATION")
	private String clientapplication;
	
	@Column(name = "APPLNAME")
	private String applname;
	
	@Column(name = "CLIENTSECRET")
	private String clientsecret;
	
	@Column(name = "CONFIDENTIAL")
	private Integer confidential;
	
	@Column(name = "ERRORURL")
	private String errorurl;
	
	@Column(name = "PARTNERCODE")
	private String partnercode;
	
	@Column(name = "ASSISTANCEMODE")
	private Integer assistancemode;
	
	@Column(name = "REDIRECTURL")
	private String redirecturl;
	
	@Column(name = "REGISTEREDAT")
	private Timestamp registeredat;
	
	@Column(name = "TOKENVALIDITYSECONDS", nullable = false)
	private Integer tokenvalidityseconds;
	
	@Column(name = "VERSIONID")
	private Integer versionid;
	
	@Column(name = "CLIENTSTATUS")
	private Integer clientstatus;
	
	@Column(name = "CREATEBY")
	private String createby;
	
	@Column(name = "CREATEDT")
	private Timestamp createdt;
	
	@Column(name = "LSTUPDATEBY")
	private String lstupdateby;
	
	@Column(name = "LSTUPDATEDT")
	private Timestamp lstupdatedt;
	
	public String getClientid() {
		return clientid;
	}
	public void setClientid(String clientid) {
		this.clientid = clientid;
	}
	public String getClientapplication() {
		return clientapplication;
	}
	public void setClientapplication(String clientapplication) {
		this.clientapplication = clientapplication;
	}
	public String getApplname() {
		return applname;
	}
	public void setApplname(String applname) {
		this.applname = applname;
	}
	public String getClientsecret() {
		return clientsecret;
	}
	public void setClientsecret(String clientsecret) {
		this.clientsecret = clientsecret;
	}
	public Integer getConfidential() {
		return confidential;
	}
	public void setConfidential(Integer confidential) {
		this.confidential = confidential;
	}
	public String getErrorurl() {
		return errorurl;
	}
	public void setErrorurl(String errorurl) {
		this.errorurl = errorurl;
	}
	public String getPartnercode() {
		return partnercode;
	}
	public void setPartnercode(String partnercode) {
		this.partnercode = partnercode;
	}
	public Integer getAssistancemode() {
		return assistancemode;
	}
	public void setAssistancemode(Integer assistancemode) {
		this.assistancemode = assistancemode;
	}
	public String getRedirecturl() {
		return redirecturl;
	}
	public void setRedirecturl(String redirecturl) {
		this.redirecturl = redirecturl;
	}
	public Timestamp getRegisteredat() {
		return registeredat;
	}
	public void setRegisteredat(Timestamp registeredat) {
		this.registeredat = registeredat;
	}
	public Integer getTokenvalidityseconds() {
		return tokenvalidityseconds;
	}
	public void setTokenvalidityseconds(Integer tokenvalidityseconds) {
		this.tokenvalidityseconds = tokenvalidityseconds;
	}
	public Integer getVersionid() {
		return versionid;
	}
	public void setVersionid(Integer versionid) {
		this.versionid = versionid;
	}
	public Integer getClientstatus() {
		return clientstatus;
	}
	public void setClientstatus(Integer clientstatus) {
		this.clientstatus = clientstatus;
	}
	public String getCreateby() {
		return createby;
	}
	public void setCreateby(String createby) {
		this.createby = createby;
	}
	public Timestamp getCreatedt() {
		return createdt;
	}
	public void setCreatedt(Timestamp createdt) {
		this.createdt = createdt;
	}
	public String getLstupdateby() {
		return lstupdateby;
	}
	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}
	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}
	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}
	@Override
	public String toString() {
		return "RegisteredClients [clientid=" + clientid + ", clientapplication=" + clientapplication + ", applname="
				+ applname + ", clientsecret=" +(null != clientsecret)+ ", confidential=" + confidential + ", errorurl="
				+ errorurl + ", partnercode=" + partnercode + ", assistancemode=" + assistancemode + ", redirecturl="
				+ redirecturl + ", registeredat=" + registeredat + ", tokenvalidityseconds=" + tokenvalidityseconds
				+ ", versionid=" + versionid + ", clientstatus=" + clientstatus + ", createby=" + createby
				+ ", createdt=" + createdt + ", lstupdateby=" + lstupdateby + ", lstupdatedt=" + lstupdatedt + "]";
	}
	
	
}

