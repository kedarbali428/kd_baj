package com.bajaj.bfsd.authentication.service;

import javax.enterprise.context.RequestScoped;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.bean.SystemTokenRequest;
import com.bajaj.bfsd.authentication.model.LoginAccount;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceHelper;
import com.bajaj.bfsd.authentication.util.DataFormatter;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLBusinessException;

@Component
public class LoginAccountBuilder {
	
	@Autowired
	@RequestScoped
	BFLLoggerUtil logger;
	
	@Autowired
	@RequestScoped
	DataFormatter dataFormatter;

	@Autowired
	private Environment env;
	
	@Value("${product.list}")
	private String productList;
	
	private static final String AUTH_025 = "AUTH_025";
	
	public LoginAccount getLoginAccountFromMobileDOBRequest(MobileLoginRequest request) {
        short loginAccType;
		String loginId = request.getMobile();
		String dob = request.getDateOfBirth();
		//Task Id:	BFDLREVSEC-178: Here condition has been added to reuse the existing code for forgot mpin from customer portal
		if(!StringUtils.equals(AuthenticationServiceConstants.MPIN_OTP_LOGIN, request.getSource())) {
			loginId = loginId + "@" + dob;
			loginAccType=AuthenticationServiceConstants.LOGINACCTYPE_MOBILEDOB;
		}else {
			loginAccType=AuthenticationServiceConstants.LOGINACCTYPE_FORGOT_PASSWORD;
		}
		return new LoginAccount(loginId, "",
				AuthenticationServiceHelper.getUserType(request.getSource()),loginAccType, dob);
	}

	public LoginAccount getLoginAccountFromSocialRequest(String loginId, String source, String target) {

		return new LoginAccount(loginId, "", AuthenticationServiceHelper.getUserType(source),
				AuthenticationServiceHelper.getSocialLoginType(target), "");
	}
	
	public LoginAccount getLoginAccountFromManualRequest(String loginId, String pwd, String source) {

		return new LoginAccount(loginId, pwd, AuthenticationServiceHelper.getUserType(source),
				AuthenticationServiceConstants.LOGINACCTYPE_MANUAL, "");
	}
	
	public LoginAccount getLoginAccountFromAadharRequest(String loginId, String source) {
		return new LoginAccount(loginId, "", AuthenticationServiceHelper.getUserType(source),
				AuthenticationServiceConstants.LOGINACCTYPE_AADHAR, "");
	}
	
	public LoginAccount getLoginAccountFromProductCode(SystemTokenRequest systemTokenRequest) {

		LoginAccount loginAccount = null;
		for (String product : productList.split(AuthenticationServiceConstants.COMMA)) {
			String productDetails[] = product.split(AuthenticationServiceConstants.SEMI_COLON);			
			if(systemTokenRequest.getProductCode().equals(productDetails[0])) {
				loginAccount = new LoginAccount(productDetails[1], productDetails[2], 
						AuthenticationServiceHelper.getUserType(AuthenticationServiceConstants.SYSTEM),
						AuthenticationServiceConstants.LOGINACCTYPE_MANUAL, "");
				break;
			}
		}
		if (null == loginAccount)
			throw new BFLBusinessException(AUTH_025, env.getProperty(AUTH_025));
		
		return loginAccount;
	}
	
}
