package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

import org.springframework.stereotype.Component;


@Component
public class Token implements Serializable {

	private static final long serialVersionUID = 5214151939252231697L;
	
	
	String jwtToken;
	String guardToken;

	@Override
	public String toString() {
		return "Token [jwtToken=" + jwtToken + ", guardToken=" + guardToken + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((guardToken == null) ? 0 : guardToken.hashCode());
		result = prime * result + ((jwtToken == null) ? 0 : jwtToken.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Token other = (Token) obj;
		if (guardToken == null) {
			if (other.guardToken != null)
				return false;
		} else if (!guardToken.equals(other.guardToken))
			return false;
		if (jwtToken == null) {
			if (other.jwtToken != null)
				return false;
		} else if (!jwtToken.equals(other.jwtToken))
			return false;
		return true;
	}
	public String getJwtToken() {
		return jwtToken;
	}
	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
	public String getGuardToken() {
		return guardToken;
	}
	public void setGuardToken(String guardToken) {
		this.guardToken = guardToken;
	}
	

	

}
