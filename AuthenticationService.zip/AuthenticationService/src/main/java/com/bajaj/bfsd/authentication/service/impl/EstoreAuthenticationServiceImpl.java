package com.bajaj.bfsd.authentication.service.impl;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.bean.NtpPreRegisterResponse;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV3;
import com.bajaj.bfsd.authentication.bean.UtmParameters;
import com.bajaj.bfsd.authentication.dao.EstoreAuthenticationDao;
import com.bajaj.bfsd.authentication.service.AuthenticationServiceImpl;
import com.bajaj.bfsd.authentication.service.EstoreAuthenticationService;
import com.bajaj.bfsd.authentication.util.EstoreAuthenticationHelper;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLHttpException;

@Component
public class EstoreAuthenticationServiceImpl implements EstoreAuthenticationService {
	
	private static final String THIS_CLASS = AuthenticationServiceImpl.class.getCanonicalName();

	@Autowired
	BFLLoggerUtil logger;
	
	@Autowired
	EstoreAuthenticationDao authenticationServiceDao;
	
	@Autowired
	private Environment env;
	
	@Value("${api.otp.generate.POST.url}")
	private String otpGenerateUrl;
	
	@Autowired
	EstoreAuthenticationHelper estoreAuthenticationHelper;

	
	@Override
	public ResponseBean loginWithOtpEstore(UserLoginAccountRequestV3 userLoginRequest,
			UtmParameters applicantUtmBean,HttpHeaders headers) throws ParseException {
		String otpresponse="otpResponse";
		return genrateOtp(userLoginRequest, otpresponse,applicantUtmBean,headers);
	}

	private ResponseBean genrateOtp(UserLoginAccountRequestV3 userLoginRequest, String otpresponse,UtmParameters applicantUtmBean,HttpHeaders headers) {
		
		NtpPreRegisterResponse ntpPreRegisterResponse=estoreAuthenticationHelper.createApplicant(userLoginRequest, applicantUtmBean, headers);
		ResponseBean responseBean;
		JSONObject jsonRequest = new JSONObject();
		jsonRequest.put("mobile", userLoginRequest.getMobileNumber());
		jsonRequest.put("mfa",true);
		
		@SuppressWarnings("unchecked")
		ResponseEntity<ResponseBean> otpResponse = (ResponseEntity<ResponseBean>) BFLCommonRestClient
				.invokeRestEndpoint(HttpMethod.POST, otpGenerateUrl, null, ResponseBean.class, null,
						jsonRequest.toString(), headers, null);
		
		//Validate the response for genearate otp
		validateGenerateOtpResponse(userLoginRequest.getMobileNumber(), otpResponse);

		responseBean = new ResponseBean(StatusCode.SUCCESS);
		Map<String,Object> responseMap = new HashMap<>();
		if(!org.springframework.util.StringUtils.isEmpty(ntpPreRegisterResponse))
		{
		responseMap.put("dateOfBirth", userLoginRequest.getDateOfBirth());
		responseMap.put(otpresponse,"Success");
		responseMap.put("applicantKey", ntpPreRegisterResponse.getApplicantKey());
		responseMap.put("userKey", ntpPreRegisterResponse.getUserKey());
		responseMap.put("userApplicantKey", ntpPreRegisterResponse.getUserApplicantKey());
		responseBean.setPayload(responseMap);
		}
		else {
		
			responseMap.put("dateOfBirth", userLoginRequest.getDateOfBirth());
			responseMap.put(otpresponse,"Success");
			responseMap.put("applicantKey", null);
			responseMap.put("userKey", null);
			responseMap.put("userApplicantKey", null);
			responseBean.setPayload(responseMap);
		}
		
		return responseBean;
	}

	public ResponseBean validateGenerateOtpResponse(String mobileNumber, ResponseEntity<ResponseBean> otpResponse) {
		ResponseBean responseBean= new ResponseBean();
		if (otpResponse.getStatusCodeValue() == HttpStatus.OK.value()) {
			if (StatusCode.FAILURE.name().equals(otpResponse.getBody().getStatus().name())) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateMobileDob - Failed to generate OTP");
				responseBean = new ResponseBean(StatusCode.FAILURE);
				Map<String,Object> responseMap = new HashMap<>();
				responseMap.put("mobileNumber", mobileNumber);
				responseBean.setPayload(responseMap);
				responseBean.setErrorBean(otpResponse.getBody().getErrorBean());
				return responseBean;
			}
		} else if (otpResponse.getStatusCodeValue() == HttpStatus.BAD_REQUEST.value()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"authenticateMobileDob - invalid request sent to generate OTP");
			responseBean = new ResponseBean(StatusCode.FAILURE);
			Map<String,Object> responseMap = new HashMap<>();
			responseMap.put("mobileNumber", mobileNumber);
			responseBean.setErrorBean(otpResponse.getBody().getErrorBean());
			responseBean.setPayload(responseMap);
			return responseBean;
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"Invalid status recevied from OTP generate service -" + otpResponse.getStatusCodeValue());
			throw new BFLHttpException(HttpStatus.INTERNAL_SERVER_ERROR,"AUTH-000", env.getProperty("AUTH-000"));
		}
		return responseBean;
	}

	@Override
	public int checkUserExistanceforEstore(String loginId, String dob) {
		int userCount=authenticationServiceDao.checkLoginIdExistanceForEstore(loginId, dob);
		return userCount;
		
		
	}
	
}
