package com.bajaj.bfsd.authentication.bean;

import java.math.BigDecimal;

public class BusinessOwnerDetails {

	private String businessName;

	private Reference businessType;

	private Reference natureOfBusiness;

	private Reference industryType;

	private Reference anualTurnover;

	private String netMonthlyIncome;

	private String businessVintage;

	private String proprieterName;

	private String businessPan;

	private String gstNumber;

	private Reference subindumastkey;

	private BigDecimal profitAfterTax;

	private BigDecimal averageBankBalance;

	private Reference companyType;

	private Integer presentBusinessVintage;
	
	private String cif;

	private String officetype;

	public Reference getCompanyType() {
		return companyType;
	}

	public void setCompanyType(Reference companyType) {
		this.companyType = companyType;
	}

	public BigDecimal getProfitAfterTax() {
		return profitAfterTax;
	}

	public void setProfitAfterTax(BigDecimal profitAfterTax) {
		this.profitAfterTax = profitAfterTax;
	}

	public BigDecimal getAverageBankBalance() {
		return averageBankBalance;
	}

	public void setAverageBankBalance(BigDecimal averageBankBalance) {
		this.averageBankBalance = averageBankBalance;
	}

	public Reference getSubindumastkey() {
		return subindumastkey;
	}

	public void setSubindumastkey(Reference subindumastkey) {
		this.subindumastkey = subindumastkey;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public Reference getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Reference businessType) {
		this.businessType = businessType;
	}

	public Reference getNatureOfBusiness() {
		return natureOfBusiness;
	}

	public void setNatureOfBusiness(Reference natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}

	public Reference getIndustryType() {
		return industryType;
	}

	public void setIndustryType(Reference industryType) {
		this.industryType = industryType;
	}

	public Reference getAnualTurnover() {
		return anualTurnover;
	}

	public void setAnualTurnover(Reference anualTurnover) {
		this.anualTurnover = anualTurnover;
	}

	public String getNetMonthlyIncome() {
		return netMonthlyIncome;
	}

	public void setNetMonthlyIncome(String netMonthlyIncome) {
		this.netMonthlyIncome = netMonthlyIncome;
	}

	public String getBusinessVintage() {
		return businessVintage;
	}

	public void setBusinessVintage(String businessVintage) {
		this.businessVintage = businessVintage;
	}

	public String getProprieterName() {
		return proprieterName;
	}

	public void setProprieterName(String proprieterName) {
		this.proprieterName = proprieterName;
	}

	public String getBusinessPan() {
		return businessPan;
	}

	public void setBusinessPan(String businessPan) {
		this.businessPan = businessPan;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public Integer getPresentBusinessVintage() {
		return presentBusinessVintage;
	}

	public void setPresentBusinessVintage(Integer presentBusinessVintage) {
		this.presentBusinessVintage = presentBusinessVintage;
	}

	public String getOfficetype() {
		return officetype;
	}

	public void setOfficetype(String officetype) {
		this.officetype = officetype;
	}
	
	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	@Override
	public String toString() {
		return "BusinessOwnerDetails [businessName=" + businessName + ", businessType=" + businessType
				+ ", natureOfBusiness=" + natureOfBusiness + ", industryType=" + industryType + ", anualTurnover="
				+ anualTurnover + ", netMonthlyIncome=" + netMonthlyIncome + ", businessVintage=" + businessVintage
				+ ", proprieterName=" + proprieterName + ", businessPan=" + businessPan + ", gstNumber=" + gstNumber
				+ ", subindumastkey=" + subindumastkey + ", profitAfterTax=" + profitAfterTax + ", averageBankBalance="
				+ averageBankBalance + ", companyType=" + companyType + ", presentBusinessVintage="
				+ presentBusinessVintage + ", cif=" + cif + ", officetype=" + officetype + "]";
	}

}
