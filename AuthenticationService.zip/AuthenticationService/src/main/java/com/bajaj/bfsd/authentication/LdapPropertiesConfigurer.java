package com.bajaj.bfsd.authentication;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;

@RefreshScope
@Component
public class LdapPropertiesConfigurer extends BFLComponent {
	
	@Value("${ldap.url}")
	private String ldapUrl;

	@Value("${ldap.context.factoryClass}")
	private String ldapFactClass;

	@Value("${ldap.security.principle}")
	private String ldapSecPrincipal;
	
	@Value("${ldap.security.authentication.type}")
	private String ldapSecAuthType;

	@Value("${ldap.context.password}")
	private String ldapUserPwd;

	/**
	 * @return the ldapUrl
	 */
	public String getLdapUrl() {
		return ldapUrl;
	}

	/**
	 * @param ldapUrl the ldapUrl to set
	 */
	public void setLdapUrl(String ldapUrl) {
		this.ldapUrl = ldapUrl;
	}

	/**
	 * @return the ldapFactClass
	 */
	public String getLdapFactClass() {
		return ldapFactClass;
	}

	/**
	 * @param ldapFactClass the ldapFactClass to set
	 */
	public void setLdapFactClass(String ldapFactClass) {
		this.ldapFactClass = ldapFactClass;
	}

	/**
	 * @return the ldapSecPrincipal
	 */
	public String getLdapSecPrincipal() {
		return ldapSecPrincipal;
	}

	/**
	 * @param ldapSecPrincipal the ldapSecPrincipal to set
	 */
	public void setLdapSecPrincipal(String ldapSecPrincipal) {
		this.ldapSecPrincipal = ldapSecPrincipal;
	}

	/**
	 * @return the ldapSecAuthType
	 */
	public String getLdapSecAuthType() {
		return ldapSecAuthType;
	}

	/**
	 * @param ldapSecAuthType the ldapSecAuthType to set
	 */
	public void setLdapSecAuthType(String ldapSecAuthType) {
		this.ldapSecAuthType = ldapSecAuthType;
	}

	/**
	 * @return the ldapUserPwd
	 */
	public String getLdapUserPwd() {
		return ldapUserPwd;
	}

	/**
	 * @param ldapUserPwd the ldapUserPwd to set
	 */
	public void setLdapUserPwd(String ldapUserPwd) {
		this.ldapUserPwd = ldapUserPwd;
	}
	
}
