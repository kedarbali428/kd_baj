package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

public class AadharLoginRequest implements Serializable{
	
	private static final long serialVersionUID = -4254102002264709631L;
	
	private String aadharNumber;
	private String otp;
	private String otpTxnId;
	private String source;
	private long applicationId;
	private String hashCode;
	
	
	public String getHashCode() {
		return hashCode;
	}
	public void setHashCode(String hashCode) {
		this.hashCode = hashCode;
	}
	
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getOtpTxnId() {
		return otpTxnId;
	}
	public void setOtpTxnId(String otpTxnId) {
		this.otpTxnId = otpTxnId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}
}
