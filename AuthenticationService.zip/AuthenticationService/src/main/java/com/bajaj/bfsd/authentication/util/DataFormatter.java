package com.bajaj.bfsd.authentication.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLBusinessException;

@Component
public class DataFormatter {

	@Autowired
	private BFLLoggerUtil logger;
	
	@Autowired
	private Environment env;
	
	private static final String THIS_CLASS = DataFormatter.class.getCanonicalName();
	
	public Date dateStringToDate(String date, String format) {
		Date retVal = null;
		try{
			if(StringUtils.isNotBlank(date)) {
				SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
				dateFormatter.setLenient(false);
				retVal = dateFormatter.parse(date);
			}
		}catch(ParseException ex){
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "dateStringToDate - date is not in correct format: "+date);
			throw new BFLBusinessException("AUTH_643", env.getProperty("AUTH_643"));
		}
		return retVal;
	}
	
	public String dateToFormatedDateString(Date date, String format) {
		String retVal = null;		
		try{
			if(null != date) {
				SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
				dateFormatter.setLenient(false);
				retVal = dateFormatter.format(date);
			}
		}catch(Exception ex){
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "dateToFormatedDateString - date could not be formated: "+date);
			throw new BFLBusinessException("AUTH_640", env.getProperty("AUTH_640"));
		}			
		return retVal;
	}	
	
	public java.sql.Date convertDateStringtoSqlDate(String date, String format){
		java.sql.Date sqlDate = null;
		Date formattedDate = dateStringToDate(date, format);
		if(null != formattedDate )
			sqlDate = new java.sql.Date(formattedDate.getTime());
		return sqlDate;
	}
	
	public String getFormattedDate(Date date, String format){
		String formattedDate = "";
		if(null != date) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			sdf.setLenient(false);
			formattedDate = sdf.format(date);
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "formatted date: " + formattedDate);
		return formattedDate;
	}
	
}
