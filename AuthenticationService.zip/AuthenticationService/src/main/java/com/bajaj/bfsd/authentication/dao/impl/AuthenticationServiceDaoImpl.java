package com.bajaj.bfsd.authentication.dao.impl;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.authentication.constants.AuthenticateServiceConstants;
import com.bajaj.bfsd.authentication.dao.AuthenticationServiceDao;
import com.bajaj.bfsd.authentication.model.ApplicantUtm;
import com.bajaj.bfsd.authentication.model.BfsdUser;
import com.bajaj.bfsd.authentication.model.Login;
import com.bajaj.bfsd.authentication.model.UserFailedLog;
import com.bajaj.bfsd.authentication.model.UserLoginActivity;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.DataFormatter;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.baseclasses.BFLRepository;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RefreshScope
@Repository
public class AuthenticationServiceDaoImpl extends BFLRepository implements AuthenticationServiceDao {

	private static final String CLASSNAME = AuthenticationServiceDaoImpl.class.getName();
	
	@Autowired
	@RequestScoped
	BFLLoggerUtil logger;

	@Autowired
	EntityManager entityManager;
	@Autowired
	private Environment env;
	
	@Autowired 
	private DataFormatter dataFormatter;
	
	private static final String AUTH_605 = "AUTH-605";

	@SuppressWarnings("unchecked")
	public BfsdUser fetchRecord(Login login) {
		List<BfsdUser> bfsdUserlist = Collections.emptyList();
		BfsdUser bfsdUser = null;
		try {
			bfsdUserlist = (List<BfsdUser>) entityManager
					.createQuery("select bu from BfsdUser bu "
							+ "where bu.userloginid = ?1 and bu.usertype =1 and bu.isactive =1")
					.setParameter(1, login.getUsername()).getResultList();
			if (!bfsdUserlist.isEmpty()) {
				bfsdUser = bfsdUserlist.get(0);
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "fetchRecord - exception while fetching record - " + e);
			throw new BFLBusinessException("AUTH_631", env.getProperty("AUTH_631"));
		}
		return bfsdUser;
	}

	// Update history table for Each attempts
	@Transactional
	@Override
	public void updateLoginActivity(Login login) {
		try {
			Calendar calendar = Calendar.getInstance();
			Timestamp currentTimestamp = new java.sql.Timestamp(calendar.getTime().getTime());
			if (login != null) {
				UserLoginActivity loginActivity = new UserLoginActivity();
				loginActivity.setBfsdUser(login.getBfsdUser());
				if ("false".equalsIgnoreCase(login.getLoginsrcwebapp())) {
					loginActivity.setLoginsrcwebapp(AuthenticateServiceConstants.LOGINSRCMOBILE);
				} else {
					loginActivity.setLoginsrcwebapp(AuthenticateServiceConstants.LOGINSRCWEB);
				}
				loginActivity.setDeviceid(login.getDeviceid());
				loginActivity.setIpaddress(login.getIpAddress());
				loginActivity.setBrowser(login.getBrowser());
				loginActivity.setLatitude(login.getLatitude());
				loginActivity.setLongitude(login.getLongitude());
				loginActivity.setLogindt(currentTimestamp);
				loginActivity.setLoginid(login.getUsername());
				loginActivity.setLstupdateby("1");
				loginActivity.setLstupdatedt(currentTimestamp);
				entityManager.persist(loginActivity);
				logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER,
						"IP Address updateLoginActivity--> " + login.getIpAddress());
				logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER,
						"IP Address updateLoginActivitySeter--> " + loginActivity.getIpaddress());
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO,
					"updateLoginActivity - exception while updating record - " + e);
			throw new BFLBusinessException(AUTH_605, env.getProperty(AUTH_605));
		}

	}

	@Transactional
	@Override
	public void updateLoginFailed(Login login) {
		try {
			Calendar calendar = Calendar.getInstance();
			Timestamp currentTimestamp = new java.sql.Timestamp(calendar.getTime().getTime());
			if (login != null) {
				UserFailedLog failedLog = new UserFailedLog();

				failedLog.setDeviceid(login.getDeviceid());
				failedLog.setIpaddress(login.getIpAddress());
				failedLog.setBrowser(login.getBrowser());
				failedLog.setLatitude(login.getLatitude());
				failedLog.setLongitude(login.getLongitude());
				failedLog.setAttemptdt(currentTimestamp);
				failedLog.setLoginid(login.getUsername());
				failedLog.setLoginpwd(login.getPassword());

				entityManager.persist(failedLog);
				logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER,
						"IP Address updateLoginFailed--> " + login.getIpAddress());
				logger.info(CLASSNAME, BFLLoggerComponent.CONTROLLER,
						"IP Address updateLoginFailed--> " + failedLog.getIpaddress());
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO,
					"updateLoginFailed - exception while updating record - " + e);
			throw new BFLBusinessException(AUTH_605, env.getProperty(AUTH_605));
		}

	}

	@Override
	@Transactional
	public void updateLogoutActivity(Login login) {
		try {

			Timestamp currentTimestamp = new java.sql.Timestamp(System.currentTimeMillis());
			Query query = entityManager.createNativeQuery("update USER_LOGIN_ACTIVITIES set logoutdt=:logoutdt," 
					+ "lstupdatedt = :lstupdatedt where userkey = :userkey and logoutdt is null and loginsrcwebapp = :loginsrcwebapp");
			
			query.setParameter("userkey", login.getBfsdUser().getUserkey());
			query.setParameter("logoutdt", currentTimestamp);
			query.setParameter("lstupdatedt", currentTimestamp);
			if ("true".equalsIgnoreCase(login.getLoginsrcwebapp())) {
				query.setParameter("loginsrcwebapp", AuthenticateServiceConstants.LOGINSRCWEB);
			} else {
				query.setParameter("loginsrcwebapp", AuthenticateServiceConstants.LOGINSRCMOBILE);
			}
			
			int count = query.executeUpdate();
			logger.debug(CLASSNAME, BFLLoggerComponent.DAO,
					"updateLogoutActivity - logout activity updatedcount - " + count);
		
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO,
					"updateLogoutActivity - exception while updating record - " + e);
			throw new BFLBusinessException(AUTH_605, env.getProperty(AUTH_605));
		}

	}

	@Override
	public int checkLoginIdExistance(String loginId, String dob, Integer loginType,String rType ) {
		logger.debug(CLASSNAME, BFLLoggerComponent.DAO, AuthenticationServiceConstants.CHECK_LOGINID_EXISTANCE_START);
		int count = 0;
		String concatedloginId=null;
		try {
			Query query;
			if(!StringUtils.isEmpty(dob)&& loginType!=null && loginType==6 ) {
				concatedloginId = loginId.concat("@").concat(dob);
			}else { 
				concatedloginId=loginId;
			}
			if(loginType != null) {
				query = entityManager.createNativeQuery("SELECT COUNT(1) From USER_LOGIN_ACCOUNTS ac ,BFSD_USERS bu where ac.USERKEY = bu.USERKEY and ac.LOGINID =:loginId and ac.USERLOGINACCTYPE=:loginType and bu.ISACTIVE=1 and bu.USERTYPE=1");
				query.setParameter("loginId", concatedloginId);
				query.setParameter("loginType", loginType);
				count = ((Number) query.getSingleResult()).intValue();
			}else {
				if(StringUtils.equals("1", rType)&&!StringUtils.isEmpty(dob)) {
					count=validateUser(loginId, dob, 8);
				}else {
				query = entityManager.createNativeQuery("SELECT COUNT(LOGINID) From USER_LOGIN_ACCOUNTS ac ,BFSD_USERS bu where ac.USERKEY = bu.USERKEY and ac.LOGINID =:loginId and ac.USERLOGINACCTYPE=8 and bu.ISACTIVE=1 and bu.USERTYPE=1");
				query.setParameter("loginId", loginId);
				count = ((Number) query.getSingleResult()).intValue();	
				}
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.DAO, AuthenticationServiceConstants.CHECK_LOGINID_EXISTANCE_END);
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Exception : " + e);
			throw new BFLTechnicalException(AuthenticationServiceConstants.AUTH_639,
					env.getProperty(AuthenticationServiceConstants.AUTH_639));
		}
		return count;
	}
	@Override
	public int validateUser(String mobileNumber, String dateOfBirth, Integer loginType) {
		try {
			java.sql.Date dob = dataFormatter.convertDateStringtoSqlDate(dateOfBirth, AuthenticationServiceConstants.DOB_DD_MM_YYYY_ARABICFORMAT);
			Query query = entityManager.createNativeQuery(
					"SELECT COUNT(1) From USER_LOGIN_ACCOUNTS ac ,BFSD_USERS bu, USER_PROFILES up "
					+ "where ac.USERKEY = bu.USERKEY and bu.USERKEY = up.USERKEY and ac.LOGINID=:mobileNumber "
					+ "and ac.USERLOGINACCTYPE=:loginType and bu.ISACTIVE=1 and bu.USERTYPE=1 "
					+ "and up.DATEOFBIRTH=:dateOfBirth");
			
			query.setParameter("mobileNumber", mobileNumber);
			query.setParameter("dateOfBirth", dob);
			query.setParameter("loginType", loginType);
			return((Number) query.getSingleResult()).intValue();
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Unable to find any user with given details. " + e);
			throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_641,
					env.getProperty(AuthenticationServiceConstants.AUTH_641));
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public Timestamp getUserProfile(String mobileNumber) {
		Query query = entityManager.createNativeQuery("select up.DATEOFBIRTH from BFSD_USERS bu,USER_PROFILES up where up.MOBILENO=:mobileNumber and bu.USERKEY=up.USERKEY and bu.ISACTIVE=1 and bu.USERTYPE=1");
		query.setParameter("mobileNumber", mobileNumber);
		List<Timestamp> dobList=query.getResultList();
		if(!dobList.isEmpty()) {
			return dobList.get(0);
		}else {
			logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Unable to find date of birth in user profile");
			throw new BFLBusinessException(AuthenticationServiceConstants.AUTH_642,
					env.getProperty(AuthenticationServiceConstants.AUTH_642));
		}
		
	}

		@Override
		@Transactional
		public boolean saveApplicantUtm(ApplicantUtm applicantUtmObj) {
			try {
				entityManager.persist(applicantUtmObj);
				logger.debug(CLASSNAME, BFLLoggerComponent.DAO, "Applicant level UTM Saving Completed in :");// + executionTime);
				return true;
			} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Error while saving UTM parametres in table APLT_UTM_PARAMETERS", e);
				return false;
			}
		}

		@Override
		@Transactional
		public int getApplicantRecord(long applicantId) {
			try {
				Query query = entityManager.createQuery("Select Count(a.applicantkey) from ApplicantUtm a where a.applicantkey =:applicantId")
						.setParameter("applicantId", applicantId);
				int recVersion = (int) ((Number) query.getSingleResult()).longValue();
				return recVersion;
			} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Error while getting entries for current applicant in table : APLT_UTM_PARAMETERS", e);
			}
			return 0;
		}

		@Override
		@Transactional
		public long getApplicantId(long userId) {
			long applicantId = 0;
			try {
				Query query = entityManager.createQuery("select a.applicantkey from UserApplicant a where a.bfsdUser.userkey =:userId")
						.setParameter("userId", userId);
				applicantId = (long) ((Number) query.getSingleResult()).longValue();
			} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.DAO, "Error while getting entries for current applicant in table : APLT_UTM_PARAMETERS", e);
			}
			return applicantId;
		}
}
