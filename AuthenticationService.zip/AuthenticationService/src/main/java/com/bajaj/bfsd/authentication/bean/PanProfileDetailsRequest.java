package com.bajaj.bfsd.authentication.bean;

import javax.validation.Valid;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;

public class PanProfileDetailsRequest {

	private String panNumber;
	
	@Valid
	@NotNull(message = "AUTH-400")
	private ApplicantKeysRequest userKeys;

	@NotNull(message = "AUTH-400")
	private Boolean skipped;
	
	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public ApplicantKeysRequest getUserKeys() {
		return userKeys;
	}

	public void setUserKeys(ApplicantKeysRequest userKeys) {
		this.userKeys = userKeys;
	}
	
	public Boolean getSkipped() {
		return skipped;
	}

	public void setSkipped(Boolean skipped) {
		this.skipped = skipped;
	}
	
	/*
	 * Note: This method is for validation of pan Number
	 * based on skipped flag
	 */
	@AssertTrue(message = "AUTH_660")
	private boolean ispanNumber() {
		boolean status = false;
		if(null == skipped || skipped)
			status = true;
		else
			status = (null!= panNumber) && panNumber.matches("^[A-Z]{3}P[A-Z]{1}[0-9]{4}[A-Z]{1}$");
		return status;
	}
	
	@Override
	public String toString() {
		return "PanProfileDetailsRequest [panNumber=" + StringUtils.overlay(panNumber, "XXXXXXXX", 2, 10) + ", userKeys=" + userKeys + ", skipped="
				+ skipped + "]";
	}
	
}
