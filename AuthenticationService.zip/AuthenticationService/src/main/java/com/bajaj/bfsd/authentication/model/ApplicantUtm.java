package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the APP_CONTACT_AUTH_REQUEST database table.
 * 
 */
@Entity
@Table(name = "APLT_UTM_PARAMETERS")
//@NamedQuery(name = "ApltUtmParameters.findAll", query = "SELECT u FROM ApltUtmParameters a")
public class ApplicantUtm implements Serializable {

	private static final long serialVersionUID = -3215945733068103933L;

//	@SequenceGenerator(name = "APLT_UTM_KEY_GENERATOR", sequenceName = "ORGSYSUSER.ISEQ$$_119844", allocationSize = 1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "APLT_UTM_KEY_GENERATOR")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "APLTUTMPARAMLKEY")
	private long apltUtmParamlKey;

//	bi-directional many-to-one association to Applicants table
//	@ManyToOne
//	@JoinColumn(name = "APPLICANTKEY")
//	private Applicant applicant;

	@Column(name = "APPLICANTKEY")
	private long applicantkey;

	public ApplicantUtm() {
	}

	@Column(name = "UTMSOURCE")
	private String utmsource;

	@Column(name = "UTMMEDIUM")
	private String utmmedium;

	@Column(name = "UTMCAMPAIGN")
	private String utmcampaign;

	@Column(name = "UTMTERM")
	private String utmterm;

	@Column(name = "UTMCONTENT")
	private String utmcontent;

	@Column(name = "RECVERSION")
	private double recversion;

	@Column(name = "SOURCEPLATFORM")
	private String sourceplatform;

	@Column(name = "PRODUCT")
	private String product;

	@Column(name = "ISACTIVE")
	private int isactive;

	@Column(name = "LSTUPDATEBY")
	private String lstupdateby;

	@Column(name = "LSTUPDATEDT")
	private Timestamp lstupdatedt;

	@Column(name = "EVENTTYPE")
	private String eventtype;

	@Column(name = "USERAGENT")
	private String useragent;

	public long getApltUtmParamlKey() {
		return apltUtmParamlKey;
	}

	public void setApltUtmParamlKey(long apltUtmParamlKey) {
		this.apltUtmParamlKey = apltUtmParamlKey;
	}

	public long getApplicantkey() {
		return applicantkey;
	}

	public void setApplicantkey(long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public String getUtmsource() {
		return utmsource;
	}

	public void setUtmsource(String utmsource) {
		this.utmsource = utmsource;
	}

	public String getUtmmedium() {
		return utmmedium;
	}

	public void setUtmmedium(String utmmedium) {
		this.utmmedium = utmmedium;
	}

	public String getUtmcampaign() {
		return utmcampaign;
	}

	public void setUtmcampaign(String utmcampaign) {
		this.utmcampaign = utmcampaign;
	}

	public String getUtmterm() {
		return utmterm;
	}

	public void setUtmterm(String utmterm) {
		this.utmterm = utmterm;
	}

	public String getUtmcontent() {
		return utmcontent;
	}

	public void setUtmcontent(String utmcontent) {
		this.utmcontent = utmcontent;
	}

	public double getRecversion() {
		return recversion;
	}

	public void setRecversion(double recversion) {
		this.recversion = recversion;
	}

	public String getSourceplatform() {
		return sourceplatform;
	}

	public void setSourceplatform(String sourceplatform) {
		this.sourceplatform = sourceplatform;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getIsactive() {
		return isactive;
	}

	public void setIsactive(int isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getEventtype() {
		return eventtype;
	}

	public void setEventtype(String eventtype) {
		this.eventtype = eventtype;
	}

	public String getUseragent() {
		return useragent;
	}

	public void setUseragent(String useragent) {
		this.useragent = useragent;
	}

}
