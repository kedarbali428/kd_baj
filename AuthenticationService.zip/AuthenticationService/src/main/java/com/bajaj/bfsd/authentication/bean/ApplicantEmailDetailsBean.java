package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class ApplicantEmailDetailsBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4876004822761907742L;
	@NotNull(message="Email Address can not be null")
	private String emailAddress;
	@NotNull(message="Email Type can not be null")
	private String type;
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	

}
