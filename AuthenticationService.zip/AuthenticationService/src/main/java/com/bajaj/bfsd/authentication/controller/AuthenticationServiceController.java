/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.authentication.bean.ApplicantUtmBean;
import com.bajaj.bfsd.authentication.bean.NtpLoginRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreProcessRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterRes;
import com.bajaj.bfsd.authentication.bean.SystemTokenRequest;
import com.bajaj.bfsd.authentication.bean.TokenResponseForUserRegister;
import com.bajaj.bfsd.authentication.bean.UserDetails;
import com.bajaj.bfsd.authentication.bean.UserKeysBean;
import com.bajaj.bfsd.authentication.bean.UserKeysBeanWithTokens;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV2;
import com.bajaj.bfsd.authentication.model.AadharLoginRequest;
import com.bajaj.bfsd.authentication.model.LoginAccount;
import com.bajaj.bfsd.authentication.model.LoginSecretKeyResponse;
import com.bajaj.bfsd.authentication.model.MobileDobOtpLoginRequest;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.PartnerLoginRequest;
import com.bajaj.bfsd.authentication.model.SocialAuthenticationRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsResponse;
import com.bajaj.bfsd.authentication.model.SocialProfileResponse;
import com.bajaj.bfsd.authentication.model.SystemPartnerLoginRequest;
import com.bajaj.bfsd.authentication.model.TemporaryTokenRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.UserLoginAccountRequest;
import com.bajaj.bfsd.authentication.model.UserLoginAccountResponse;
import com.bajaj.bfsd.authentication.service.AuthenticationService;
import com.bajaj.bfsd.authentication.service.LoginAccountBuilder;
import com.bajaj.bfsd.authentication.service.OMAuthenticationService;
import com.bajaj.bfsd.authentication.util.AppOnBoardingUtils;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceHelper;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.Gson;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * This class is controller class for custom services for authentication.
 * 
 * @author 582602
 * 
 *         Version BugId UsrId Date Description 1.0 582602 07/11/2016 Initial
 *         Version
 *
 */
@RefreshScope
@RestController
public class AuthenticationServiceController extends BFLController {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private Environment env;
	
	@Autowired
	@RequestScoped
	CustomDefaultHeaders custmHeaders;
	
	@Autowired
	BFLLoggerUtil loggerUtil;

	@Autowired
	@RequestScoped
	LoginAccountBuilder loginAcctBuilder;
	private static final String THIS_CLASS = AuthenticationServiceController.class.getCanonicalName();
		
	/**
	 * Variable to hold value for auth service.
	 */
	@Autowired
	private AuthenticationService authService;
	
	@Autowired
	OMAuthenticationService omAuthenticationService;
	
	@Autowired
	AppOnBoardingUtils appOnBoardingUtils;
	
	/**
	 * Gets the auth token for passed state and code for facebook APIs
	 * 
	 * @param headers
	 *            HttpHeaders
	 * @param socialProfileRequest
	 *            FacebookProfileRequest
	 * @return ResponseEntity ResponseEntity
	 */
	@ApiOperation(value = "Get Social Redirect URL", notes = "Get Social Redirect URL", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@RequestMapping(value = "${api.authentication.getsocialredirecturl.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getSocialRedirectUrl(@RequestHeader HttpHeaders headers,
			@RequestBody SocialLoginParamsRequest socialLoginParamsRequest){
		SocialLoginParamsResponse socialLoginParamsResponse;
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Inside Controller for Social Redirect URL for target = "
						+ socialLoginParamsRequest.getPlatform());
		
			socialLoginParamsResponse = authService.getRedirectUrl(socialLoginParamsRequest);
			ResponseBean responseBean = new ResponseBean(socialLoginParamsResponse);
	
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	/**
	 * Gets the secret key for the clientId passed
	 * 
	 * @param headers
	 *            HttpHeaders
	 * @param socialProfileRequest
	 *            FacebookProfileRequest
	 * @return ResponseEntity ResponseEntity
	 */
	@ApiOperation(value = "Get secret key for clientId", notes = "Get secret key for clientId", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@RequestMapping(value = "${api.authentication.getsecretkey.GET.uri}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getSecretKey(@PathVariable(value = "clientId") String clientId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"Inside Controller for getting secret key for client = " + clientId);
		LoginSecretKeyResponse loginSecretKeyResponse = authService.getSecretKey(clientId);
		loginSecretKeyResponse.setSystemTime(System.currentTimeMillis());
		ResponseBean responseBean = new ResponseBean(loginSecretKeyResponse);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	/**
	 * Gets the secret key for the clientId passed
	 * 
	 * @param headers
	 *            HttpHeaders
	 * @param socialProfileRequest
	 *            FacebookProfileRequest
	 * @return ResponseEntity ResponseEntity
	 */
	@ApiOperation(value = "Get OTP for the aadhar no", notes = "Get OTP for the aadhar no", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@RequestMapping(value = "${api.authentication.getaadharotp.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getAadharOtp(@RequestHeader HttpHeaders headers,
			@RequestBody AadharLoginRequest aadharLoginRequest){
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"Inside Controller for generating otp for aadhar no = " + aadharLoginRequest.getAadharNumber());
		ResponseBean responseBean = authService.getAadharOtp(aadharLoginRequest.getAadharNumber());
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	/**
	 * Gets the secret key for the clientId passed
	 * 
	 * @param headers
	 *            HttpHeaders
	 * @param socialProfileRequest
	 *            FacebookProfileRequest
	 * @return ResponseEntity ResponseEntity
	 */
	@ApiOperation(value = "Get aadhar user details", notes = "Get aadhar user details", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@RequestMapping(value = "${api.authentication.authenticateaadhar.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> authenticateAadhar(@RequestHeader HttpHeaders headers,
			@RequestBody AadharLoginRequest aadharLoginRequest) {
		try {
			JSONObject aadharProfile = authService.getAadharUserDetails(aadharLoginRequest);
			String loginId = aadharProfile.getString("aadhaarNumber");
			logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "authenticateUsingAadhar for aadhar ref no = " + loginId);
			LoginAccount loginAcct = loginAcctBuilder.getLoginAccountFromAadharRequest(loginId, aadharLoginRequest.getSource());			
			TokenResponse tokens = validateUserAndGenerateToken(loginAcct, headers, false);
			authService.saveProfileDetails(aadharProfile.toString(), loginAcct.getUserId(), AuthenticationServiceConstants.LOGINACCTYPE_AADHAR_STR);
					
			return new ResponseEntity<>(new ResponseBean(tokens), HttpStatus.OK);
		} catch (BFLBusinessException businessException) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Business Exception occured while Fetching Aadhar OTP",
					businessException);
			List<ErrorBean> errorBeans = new ArrayList<>();
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode("INVALID_OTP");
			errorBean.setErrorMessage("Invalid Otp");
			errorBeans.add(errorBean);
			return new ResponseEntity<>(new ResponseBean(errorBeans), HttpStatus.OK);
		} catch (Exception exception) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Exception occured while Fetching Aadhar OTP", exception);
			throw new BFLTechnicalException("Exception occured while Fetching Aadhar OTP", exception);
		}
	}	

	@ApiOperation(value = "Authenticat user with Aadhar number and generate token", notes = "Authenticat user with Aadhar number and generate token. "
			+ "OTP validation for aadhar will be skipped assuming this call is internal", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@RequestMapping(value = "${api.authentication.authenticateaadharnootp.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> authenticateAadharWithoutOTP(@RequestHeader HttpHeaders headers,
			@RequestBody AadharLoginRequest aadharLoginRequest){
		String loginId = aadharLoginRequest.getAadharNumber();
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "authenticateUsingAadharWithoutOTP - for aadhar no = " + loginId);
		LoginAccount loginAcct = loginAcctBuilder.getLoginAccountFromAadharRequest(loginId, aadharLoginRequest.getSource());			
		TokenResponse tokens = validateUserAndGenerateToken(loginAcct, headers,false);
				
		return new ResponseEntity<>(new ResponseBean(tokens), HttpStatus.OK);
	}	
	// Changes for IAM start ---

	/**
	 * Gets the secret key for the clientId passed
	 * 
	 * @param headers
	 *            HttpHeaders
	 * @param socialProfileRequest
	 *            FacebookProfileRequest
	 * @return ResponseEntity ResponseEntity
	 * @throws JsonProcessingException
	 */
	@ApiOperation(value = "Authenticate client", notes = "After successful authentication system token will be provided", httpMethod = "POST")
	@RequestMapping(value = "${api.authentication.clientlogin.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> clientLogin(@RequestHeader HttpHeaders headers, @RequestBody TemporaryTokenRequest tokenRequest)
	{
		String loginId = tokenRequest.getClientId();
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"clientLogin - started for - "+ loginId);
		LoginAccount loginAcct = loginAcctBuilder.getLoginAccountFromManualRequest(loginId, tokenRequest.getSecretKey(), AuthenticationServiceConstants.SYSTEM);
		TokenResponse tokens = validateUserAndGenerateToken(loginAcct, headers, false);
		ResponseBean responseBean = new ResponseBean(tokens);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"clientLogin - completed for - "+ loginId);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	@ApiOperation(value = "Authenticate user based on social profile from web", notes = "Returns token after successful authentication", httpMethod = "POST")
	@ApiImplicitParams({
		    @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
		    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
		  })
	@RequestMapping(value = "${api.authentication.getsocialtoken.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getSocialToken(@RequestHeader HttpHeaders headers, @RequestBody SocialAuthenticationRequest request) {
		
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getSocial token - started");
		
		SocialProfileResponse socialProfileResponse = authService.getSocialDetails(request, headers);
		ResponseBean responseBean=null;
		HttpStatus httpStatus = HttpStatus.OK;
		
		if (null != socialProfileResponse) {			
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getSocialToken - Social profile received - call user service");
			LoginAccount loginAcct = loginAcctBuilder.getLoginAccountFromSocialRequest(socialProfileResponse.getEmail(), request.getSource(), request.getTarget());			
			TokenResponse tokens = validateUserAndGenerateToken(loginAcct, headers,false);
			authService.saveProfileDetails(socialProfileResponse.getJsonResponse(), loginAcct.getUserId(), request.getTarget());
			responseBean = new ResponseBean(tokens);
		}else {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getSocialToken - Social NOT profile received");
			httpStatus = HttpStatus.NOT_FOUND;
		}
		
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getSocial token - completed");
		return new ResponseEntity<>(responseBean, httpStatus);		
	}	
	

	/**
	 * Authenticate manual login id and password
	 * 
	 * @param headers
	 *            HttpHeaders
	 * @param ManualLoginRequest manualLoginRequest
	 * @return ResponseEntity ResponseEntity
	 * @throws BFLBusinessException, BFLTechnicalException, IOException
	 */
	@ApiOperation(value = "Authenticate loginId and password", notes = "Authenticate loginId and password", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@RequestMapping(value = "${api.authentication.authenticatemanuallogin.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> authenticateManualLogin(@RequestHeader HttpHeaders headers,
			@RequestBody UserLoginAccountRequest manualLoginRequest, @RequestParam(required = false) String app_source,
			@RequestParam(required = false) String utm_source, @RequestParam(required = false) String utm_medium,
			@RequestParam(required = false) String utm_campaign, @RequestParam(required = false) String utm_term,
			@RequestParam(required = false) String utm_content) {
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"Inside Controller for validating format for loginId" + manualLoginRequest.getLoginId());
		ApplicantUtmBean applicantUtmBean = new ApplicantUtmBean();
		try {
			setUtmToApplicantUtmBean(applicantUtmBean, app_source, utm_content, utm_source, utm_medium, utm_campaign,
					utm_term);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while creating applicant UTM parameter bean");
		}

		
		TokenResponse token = authService.authenticateManualLogin(manualLoginRequest, headers,applicantUtmBean);
		
		removeUserKey(token,false);
		return new ResponseEntity<>(new ResponseBean(token), HttpStatus.OK);
	}
	
	// Changes for IAM end
	
	@ApiOperation(value = "Authenticate mobile number and date of birth", notes = "Authenticate mobile number and date of birth", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@RequestMapping(value = "${api.authentication.authenticatemobiledob.POST.uri}",
					method = RequestMethod.POST, produces= MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> authenticateMobileDob(@RequestBody MobileLoginRequest mobileLoginRequest,
														     @RequestHeader HttpHeaders headers){
		
		
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "authenticateMobileDob - started for - "+mobileLoginRequest.getMobile());
		
		ResponseBean responseBean = authService.authenticateMobileDob(mobileLoginRequest);
		
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "authenticateMobileDob - completed for - "+mobileLoginRequest.getMobile());

		return new ResponseEntity<>(responseBean, HttpStatus.OK);

	}
	
	@ApiOperation(value = "Authenticate mobile number and date of birth based on OTP", 
					notes = "Authenticate mobile number and date of birth after validating the OTP provided", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@RequestMapping(value = "${api.authentication.authenticatemobiledobandgeneratetoken.POST.uri}", 
					method = RequestMethod.POST, produces= MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> authenticateMobileDobAndGenerateToken(@RequestBody MobileLoginRequest request,
														     @RequestHeader HttpHeaders headers){		
		
		ResponseBean responseBean;
		TokenResponse tokens;
		HttpStatus httpStatus;

		String mobile = request.getMobile();
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"authenticateMobileDobAndGenerateToken - started for - " + mobile);
		List<ErrorBean> errorBeans = new ArrayList<>();
		ErrorBean errorBean = new ErrorBean();
		try {
			boolean isOtpValid = authService.validateOtpForMobileDobLogin(request);
		
		if (isOtpValid) {
			LoginAccount loginAcct = loginAcctBuilder.getLoginAccountFromMobileDOBRequest(request);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"authenticateMobileDobAndGenerateToken - OTP validated - call user service");
			tokens = validateUserAndGenerateToken(loginAcct, headers, false);
			responseBean = new ResponseBean(tokens);
		} else {
			errorBean.setErrorCode("AUTH_630");
			errorBean.setErrorMessage(env.getProperty("AUTH_630"));
			errorBeans.add(errorBean);
			responseBean = new ResponseBean(errorBeans);
		}
		}catch (BFLBusinessException e){
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Exception occurred : "+e);
			errorBean.setErrorCode(e.getCode());
			errorBean.setErrorMessage(e.getMessage());
			errorBeans.add(errorBean);
			responseBean = new ResponseBean(errorBeans);
		}
		httpStatus = HttpStatus.OK;

		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "authenticateMobileDobAndGenerateToken - completed");
		return new ResponseEntity<>(responseBean, httpStatus);
	}
	
	@ApiOperation(value = "Authenticate mobile number and date of birth based on OTP", 
				notes = "Authenticate mobile number and date of birth after validating the OTP provided", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@RequestMapping(value = "${api.authentication.authenticatemobiledobwithoutotpandgeneratetoken.POST.uri}", method = RequestMethod.POST, produces= MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> authenticateMobileDobWihtoutOtpAndGenerateToken(@RequestBody MobileLoginRequest request,
		     @RequestHeader HttpHeaders headers){
		//dob has been changed to maintain DD and MM format.
		request.setDateOfBirth(AuthenticationServiceHelper.checkAndValidateDate(request.getDateOfBirth(), logger, env));
	return getTokenForMobileDobWihtoutOtp(request, headers, false);
	}
	
	@RequestMapping(value = "${api.authentication.authenticateMobileDobWihtoutOtpAndGenerateTokenAndUserKey.POST.uri}", method = RequestMethod.POST, produces= MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> authenticateMobileDobWihtoutOtpAndGenerateTokenAndUserKey(@RequestBody MobileLoginRequest request,
			     @RequestHeader HttpHeaders headers){		
	
		return getTokenForMobileDobWihtoutOtp(request, headers, true);
	}
	
	private ResponseEntity<ResponseBean> getTokenForMobileDobWihtoutOtp(MobileLoginRequest request,
	HttpHeaders headers, boolean userKeyFlag){	
		
		ResponseBean responseBean;
		TokenResponse tokens;
		HttpStatus httpStatus;
		if(null == request)
		{
			tokens = new TokenResponse();
			httpStatus = HttpStatus.BAD_REQUEST;
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "authenticateMobileDobAndGenerateToken - Invalid input");			
		}
		else{
			String mobile = request.getMobile();
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "authenticateMobileDobAndGenerateToken - started for - "+mobile);
					
			LoginAccount loginAcct = loginAcctBuilder.getLoginAccountFromMobileDOBRequest(request);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "authenticateMobileDobAndGenerateToken - OTP validated - call user service");
			tokens = validateUserAndGenerateToken(loginAcct, headers, userKeyFlag);
			httpStatus = HttpStatus.OK;			
		}		
		responseBean = new ResponseBean(tokens);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "authenticateMobileDobAndGenerateToken - completed");
		return new ResponseEntity<>(responseBean, httpStatus);
	}
	
	@ApiOperation(value = "Allowes user to login into mobile app using social credentials", notes = "Allowes user to login into mobile app using social credentials, "
			+ "on successful login it return the authentication token", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@RequestMapping(value = "${api.authentication.getauthtokenformobileapp.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getAuthTokenForMobileApp(@RequestHeader HttpHeaders headers,
			@RequestBody SocialAuthenticationRequest request) {
		
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getAuthTokenForMobileApp - started");
		
		ResponseBean responseBean;
		TokenResponse tokens;
		HttpStatus httpStatus;
		
		if(null == request || !validateRequest(request)){
			tokens = new TokenResponse();
			httpStatus = HttpStatus.BAD_REQUEST;			
		}
		else
		{
			SocialProfileResponse socialProfileResponse = authService.getSocialDetails(request, headers);
			
			if (null != socialProfileResponse) {
				LoginAccount loginAcct = loginAcctBuilder.getLoginAccountFromSocialRequest(socialProfileResponse.getEmail(), request.getSource(), request.getTarget());
				logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getAuthTokenForMobileApp - Social profile received - call user service");
				tokens = validateUserAndGenerateToken(loginAcct, headers, false);
				authService.saveProfileDetails(socialProfileResponse.getJsonResponse(), loginAcct.getUserId(), request.getTarget());
				httpStatus = HttpStatus.OK;	
			}else {
				tokens = new TokenResponse();
				httpStatus = HttpStatus.NOT_FOUND;			
			}
		}
		
		responseBean = new ResponseBean(tokens);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getAuthTokenForMobileApp - completed");
		return new ResponseEntity<>(responseBean, httpStatus);		
	}
	
	@ApiOperation(value = "Authenticate partner", notes = "After successful authentication system token will be provided", httpMethod = "POST")
	@RequestMapping(value = "${api.authentication.partnerlogin.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> partnerLogin(@Valid @RequestBody PartnerLoginRequest partnerRequest, BindingResult result, 
			@RequestHeader HttpHeaders headers)
	{
		validateInput(result);
		String loginId = partnerRequest.getPartnerKey();
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"partnerLogin - started for - "+ loginId);
		LoginAccount loginAcct = loginAcctBuilder.getLoginAccountFromManualRequest(loginId, partnerRequest.getSecretKey(), AuthenticationServiceConstants.B2B_PARTNER);
		TokenResponse tokens = validateUserAndGenerateToken(loginAcct, headers, false);
		//Make guard key null for partner login
		tokens.getTokens().get(0).setGuardKey(null);
		ResponseBean responseBean = new ResponseBean(tokens);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"partnerLogin - completed for - "+ loginId);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	@ApiOperation(value = "Logout session", notes = "After successful logout system token will be expired", httpMethod = "DELETE")
	@RequestMapping(value = "${api.authentication.logout.DELETE.uri}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> logout(@RequestHeader HttpHeaders headers)
	{
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"logout - started ");
		authService.logout(custmHeaders.getUserKey(),headers);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"logout - completed");
		return new ResponseEntity<>(new ResponseBean(StatusCode.SUCCESS), HttpStatus.OK);
	}
	
	//Chatbot-209 chanages start
	@ApiOperation(value = "Authenticate system partner", notes = "After successful system partner authentication system token will be provided", httpMethod = "POST")
	@RequestMapping(value = "${api.authentication.systempartnerlogin.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> systemPartnerLogin(@Valid @RequestBody SystemPartnerLoginRequest partnerRequest, BindingResult result, 
			@RequestHeader HttpHeaders headers)
	{
		validateInput(result);
		String loginId = partnerRequest.getSystemPartnerKey();
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"systemPartnerLogin - started for - "+ loginId);
		LoginAccount loginAcct = loginAcctBuilder.getLoginAccountFromManualRequest(loginId, partnerRequest.getSecretKey(), AuthenticationServiceConstants.SYSTEM_PARTNER);
		TokenResponse tokens = validateUserAndGenerateToken(loginAcct, headers, false);
		//Make guard key null for partner login
		tokens.getTokens().get(0).setGuardKey(null);
		ResponseBean responseBean = new ResponseBean(tokens);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"systemPartnerLogin - completed for - "+ loginId);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	// Chatbot-209 changes end
	// Mobile Login Start
		/**
		 * Authenticate manual login id and password
		 * 
		 * @param headers
		 *            HttpHeaders
		 * @param ManualLoginRequest
		 *            manualLoginRequest
		 * @return ResponseEntity ResponseEntity
		 * @throws ParseException 
		 * @throws BFLBusinessException,
		 *             BFLTechnicalException, IOException
		 */
		@ApiOperation(value = "Authenticate loginId and password", notes = "Authenticate loginId and password", httpMethod = "POST")
		@ApiImplicitParams({
				@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
				@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
		@RequestMapping(value = "${api.authentication.authenticatemanuallogin.V2.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
		@CrossOrigin
		public ResponseEntity<ResponseBean> mobileLogin(@RequestBody UserLoginAccountRequestV2 userLoginRequest,
				@RequestHeader HttpHeaders headers, @RequestParam(required = false) String app_source, @RequestParam(required = false) String utm_source,
				@RequestParam(required = false) String utm_medium, @RequestParam(required = false) String utm_campaign,
				@RequestParam(required = false) String utm_term, @RequestParam(required = false) String utm_content) throws ParseException {
			TokenResponse token;
			ResponseBean responseBean = null;
			logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.LOGIN_START);
			ApplicantUtmBean applicantUtmBean = new ApplicantUtmBean();
			try {
				setUtmToApplicantUtmBean(applicantUtmBean, app_source, utm_content, utm_source, utm_medium, utm_campaign, utm_term);
			} catch (Exception e) {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error while creating applicant UTM parameter bean");
			}
			if (null != userLoginRequest ) {
				//validate  login id for case of rtype 1 and 2
				AuthenticationServiceHelper.validateLoginID(userLoginRequest.getLoginId(), logger, env);
				if (StringUtils.equals("1", userLoginRequest.getRtype())) {
					String loginId = userLoginRequest.getLoginId();
					Integer loginType = (null != userLoginRequest.getLoginType() && !userLoginRequest.getLoginType().isEmpty()) ? Integer.parseInt(userLoginRequest.getLoginType()) : null;
					String dob = null;
					if(!StringUtils.isEmpty(userLoginRequest.getDateOfBirth())) {
						AuthenticationServiceHelper.validateDate(userLoginRequest.getDateOfBirth(),loggerUtil, env);
						dob=userLoginRequest.getDateOfBirth();
					}
					authService.checkUserExistance(loginId, dob, loginType,userLoginRequest.getRtype(),applicantUtmBean);
					responseBean = new ResponseBean("Success");
					logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.USER_VALIDATED);
				} else {
					if(StringUtils.equals("2", userLoginRequest.getRtype())&& StringUtils.equals("8", userLoginRequest.getLoginType())) {
						//validate pass only for rtype 2 with MPIN
						AuthenticationServiceHelper.validateLoginPass(userLoginRequest.getPassword(), logger, env);
						logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,AuthenticationServiceConstants.USER_LOGIN_START);
						token=authService.login(userLoginRequest, headers,applicantUtmBean);
						removeUserKey(token, false);
						responseBean = new ResponseBean(token);
						logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.USER_LOGIN_END);
						
					}else if(StringUtils.equals("2", userLoginRequest.getRtype()) && StringUtils.equals("6", userLoginRequest.getLoginType())) {
						//rtype 2 with sendOTP
						logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,AuthenticationServiceConstants.USER_LOGIN_START);
						responseBean=authService.loginWithOtp(userLoginRequest,applicantUtmBean);
						logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.USER_LOGIN_END);
					}
				}
			
				logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.LOGIN_START);
			}
			return new ResponseEntity<>(responseBean, HttpStatus.OK);
		}
		
		private void setUtmToApplicantUtmBean(ApplicantUtmBean applicantUtmBean, String app_source, String utm_content, String utm_source,
				String utm_medium, String utm_campaign, String utm_term) {
			applicantUtmBean.setApltUtmContent(utm_content);
			applicantUtmBean.setSourcePlatform(app_source);
			applicantUtmBean.setApltUtmSource(utm_source);
			if (!StringUtils.isEmpty(utm_medium))
				applicantUtmBean.setApltUtmMedium(utm_medium);
			else
				applicantUtmBean.setApltUtmMedium("Organic");
			applicantUtmBean.setApltUtmCampaign(utm_campaign);
			applicantUtmBean.setApltUtmTerm(utm_term);
			applicantUtmBean.setEventType("Login");
		}

		// Mobile login Ends
	    //Forgot - Reset Mpin Start
		@ApiOperation(value = "Authenticate mobile number,Mpin and DOB in case of multiple user with same login id", notes = "Authenticate mobile number,Mpin and DOB in case of multiple user with same login id", httpMethod = "POST")
		@ApiImplicitParams({
				@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
				@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
		@RequestMapping(value = "${api.authentication.authenticatemobiledobotp.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
		@CrossOrigin
		public ResponseEntity<ResponseBean> validateResetPasswordUser(@RequestBody MobileDobOtpLoginRequest mobileDobOtpLoginRequest,@RequestHeader HttpHeaders headers){
			ResponseBean responseBean = null;
			final Integer pinLoginType = 8;
			logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.NOBILE_DOB_OTP_START);
			if (null != mobileDobOtpLoginRequest) {
				//validate  login id for case of rtype 1 and 2
				AuthenticationServiceHelper.validateLoginID(mobileDobOtpLoginRequest.getLoginId(), logger, env);
				if (StringUtils.equals("1", mobileDobOtpLoginRequest.getrType())) {
					authService.checkUserExistance(mobileDobOtpLoginRequest.getLoginId(), mobileDobOtpLoginRequest.getDateOfBirth(), pinLoginType,mobileDobOtpLoginRequest.getrType(),null);
					responseBean = new ResponseBean("Success");
					logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.USER_VALIDATED);
				} else {
					responseBean=authService.autheticateMobileDobOtp(mobileDobOtpLoginRequest);
					logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.NOBILE_DOB_OTP_AFTER_CALL);
			      }
			}
			//after this UI will call OTP validation endpoint - api.authentication.authenticatemobiledobandgeneratetoken.POST.uri
			logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, AuthenticationServiceConstants.NOBILE_DOB_OTP_END);
			return new ResponseEntity<>(responseBean, HttpStatus.OK);
		}
		
		//Reset Mpin Ends

	//Jira-HORIZONTAL-146
	@CrossOrigin
	@ApiOperation(value = "Mobile Login a customer", notes = "Check if customer is already logged in.", httpMethod="GET")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "refreshtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header") })
	@RequestMapping(value = "${api.authentication.user.login.mobile.GET.uri}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> mobileAutoLogin(@RequestHeader HttpHeaders headers) {
		
		ResponseBean responseBean=new ResponseBean();
		try {
			responseBean=authService.mobileAutoLogin(headers);
		} catch (BFLTechnicalException | BFLBusinessException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "BFL  exception in mobile auto login - ");
			throw e;			
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Failed mobile auto login - ");
			throw new BFLBusinessException("AUTH-700", env.getProperty("AUTH-700"));
		}
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	private TokenResponse validateUserAndGenerateToken(LoginAccount loginAcct, HttpHeaders headers,
			boolean userKeyFlag) {
		UserLoginAccountResponse authenitcateUserResponse = authService.authenticateUser(loginAcct);
		loginAcct.setUserId(authenitcateUserResponse.getUserId());
		TokenResponse tokenResponse = authService.getToken(loginAcct.getLoginId(),authenitcateUserResponse.getUserId(), loginAcct.getUserType(), headers);
		
		removeUserKey(tokenResponse,userKeyFlag);
		
		return tokenResponse;
	}	
	
	private void removeUserKey(TokenResponse tokenResponse, boolean userKeyFlag) {
		if(!userKeyFlag){
			tokenResponse.setUserKey(null);
			tokenResponse.setDefaultRole(null);
		}		
	}	
	
	private boolean validateRequest(SocialAuthenticationRequest request) {
		boolean retVal = false;
		if(null != request){
			String source = request.getSource();
			String code = request.getCode();
			String token = request.getToken();
			String target = request.getTarget();
			if(null == source || source.trim().length()==0)
				return retVal;
			
			if(null == target || target.trim().length()==0)
				return retVal;
			
			if((null == code || code.trim().length()==0) && (null == token || token.trim().length()==0))
				return retVal;
			
			retVal = true;
		}
		return retVal;
	}

	private void validateInput(BindingResult result){
		if (result.hasErrors()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "validateInput - Invalid request input - "+result);
            throw new BFLBusinessException(result.getFieldErrors());
        }
	}
	
	@ApiOperation(value = "NTP Pre Register", httpMethod = "POST")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "flowtype", required = true, dataType = "string", paramType = "header") })
	@CrossOrigin
	@RequestMapping(value = "${api.authentication.ntp.preregister.POST.uri}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> ntpPreRegister(@Valid @RequestBody NtpPreRegisterRequest preRegisterRequest,
			@RequestHeader HttpHeaders headers,
			@RequestHeader(required=false)String merchantCode,
			@RequestHeader(required=false)String hash) {
		ResponseEntity<ResponseBean> responseEntity = null;
		try {
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"ntp pre register - started for - " + preRegisterRequest.toString());
			responseEntity = authService.ntpPreRegister(preRegisterRequest, merchantCode, hash, headers);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"ntp pre register - ender for - " + responseEntity.toString());
		} catch (BFLBusinessException | BFLTechnicalException e) {
			throw e;
		} catch (Exception e) {
			throw new BFLTechnicalException("AUTH-701", env.getProperty("AUTH-701"));
		}
		return responseEntity;
	}
	
	@ApiOperation(value = "NTP Pre Process", httpMethod = "POST")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "flowtype", required = true, dataType = "string", paramType = "header") })
	@CrossOrigin
	@RequestMapping(value = "${api.authentication.ntp.preprocess.POST.uri}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> ntpPreProcess(@RequestBody NtpPreProcessRequest preProcessRequest,
			@RequestHeader HttpHeaders headers) {
		ResponseEntity<ResponseBean> responseEntity = null;
		try {
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"ntp pre register - started for - " + preProcessRequest.toString());
			responseEntity = authService.ntpPreProcess(preProcessRequest, headers);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"ntp pre process - ender for - " + responseEntity.toString());
		} catch (BFLBusinessException | BFLTechnicalException e) {
			throw e;
		} catch (Exception e) {
			throw new BFLTechnicalException("AUTH-702", env.getProperty("AUTH-702"));
		}
		return responseEntity;
	}
	
	@ApiOperation(value = "NTP Login", httpMethod = "POST")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
		@ApiImplicitParam(name = "flowtype", required = true, dataType = "string", paramType = "header") })
	@CrossOrigin
	@RequestMapping(value = "${api.authentication.ntp.login.POST.uri}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> ntpLogin(@RequestBody NtpLoginRequest preLoginRequest,
			@RequestHeader HttpHeaders headers) {

		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"ntp login  - started for - " + preLoginRequest);
		ResponseEntity<ResponseBean> responseEntity = null;
		try {
			responseEntity = authService.ntpLogin(preLoginRequest, headers);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"ntp pre process - ender for - " + responseEntity.toString());
		} catch (BFLBusinessException | BFLTechnicalException e) {
			throw e;
		} catch (Exception e) {
			throw new BFLTechnicalException("AUTH-703", env.getProperty("AUTH-703"));
		}
		return responseEntity;
	}
	
	@ApiOperation(value = "To Generate System Tokens According to Product", notes = "To Generate System "
			+ "Tokens According to Product", httpMethod = "POST")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Tokens Generated Successfully.", response = TokenResponse.class),
			@ApiResponse(code = 400, message = "Invalid Input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some Technical Error Occurred", response = ErrorBean.class) })
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "${api.authentication.clientlogin.v2.POST.uri}", 
		consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> generateSystemTokens(@RequestHeader HttpHeaders headers, 
			@Valid @RequestBody SystemTokenRequest systemTokenRequest, BindingResult result) {
		
		// Bean Validation Check
		if (result.hasFieldErrors())
			throw new BFLBusinessException(result.getFieldErrors());
		
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"generateSystemTokens - started for - "+ systemTokenRequest);
		LoginAccount loginAcct = loginAcctBuilder.getLoginAccountFromProductCode(systemTokenRequest);
		TokenResponse tokens = validateUserAndGenerateToken(loginAcct, headers, false);
		ResponseBean responseBean = new ResponseBean(tokens);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,"generateSystemTokens - completed for - "+ systemTokenRequest);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

	@ApiOperation(value = "NTP Pre Register for BFL with Pseudo Token", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "flowtype", required = true, dataType = "string", paramType = "header") })
	@CrossOrigin
	@RequestMapping(value = "${api.authentication.ntp.preregister.bfl.POST.uri}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBean> ntpPreRegisterForBFLWithPseudoToken(
			@Valid @RequestBody NtpPreRegisterRequest preRegisterRequest, @RequestHeader HttpHeaders headers,
			@RequestHeader(required=false)String merchantCode,
			@RequestHeader(required=false)String hash) {
		ResponseEntity<ResponseBean> responseEntity = null;
		try {
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"ntp pre register - started for - " + preRegisterRequest.toString());
			responseEntity = authService.ntpPreRegister(preRegisterRequest,merchantCode,hash, headers);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"ntp pre register - ender for - " + responseEntity.toString());
			// Create Pseudo Token - Start
			if(responseEntity.getStatusCodeValue()==200) {
				NtpPreRegisterRes response = new NtpPreRegisterRes();
				MobileLoginRequest mobileLoginRequest = new MobileLoginRequest();
				Gson gson = new Gson();
				response = gson.fromJson(gson.toJson(responseEntity.getBody().getPayload()), NtpPreRegisterRes.class);
				// Added applicant key in appliaction to get psuedo token and is only for BFL
				mobileLoginRequest.setApplicationKey(0L);
				mobileLoginRequest.setDateOfBirth(preRegisterRequest.getDateOfBirth());
				mobileLoginRequest.setMobile(preRegisterRequest.getMobileNumber());
				
				mobileLoginRequest.setSource("BFL");

				UserKeysBean userKeysBean = new UserKeysBean();
				userKeysBean.setApplicantKey(response.getApplicantKey());
				userKeysBean.setUserApplicantKey(response.getUserApplicantKey());
				userKeysBean.setUserKey(response.getUserKey());

				UserDetails userDetails = new UserDetails();
				userDetails.setFirstName(response.getFirstName());
				userDetails.setLastName(response.getLastName());
				userDetails.setMobileNumber(response.getMobileNumber());
				userDetails.setDateOfBirth(response.getDateOfBirth());
				userDetails.setCustomerType(response.getCustomerType());
				userDetails.setCustomerReferenceID(response.getCustomerReferenceID());
				
				TokenResponse tokenResponse = omAuthenticationService
						.authenticateMobDobAndGenerateToken(mobileLoginRequest);
				TokenResponseForUserRegister tokenResponseForUserRegister=new TokenResponseForUserRegister();
				tokenResponseForUserRegister.setTokens(tokenResponse.getTokens());
				removeUserKey(tokenResponse, true);
				UserKeysBeanWithTokens userKeysBeanWithTokens = new UserKeysBeanWithTokens();
				userKeysBeanWithTokens.setUserKeysBean(userKeysBean);
				userKeysBeanWithTokens.setTokenResponse(tokenResponseForUserRegister);
				userKeysBeanWithTokens.setUserDetails(userDetails);
				ResponseBean responseBean = new ResponseBean(userKeysBeanWithTokens);
				// Create Pseudo Token - End
				return new ResponseEntity<>(responseBean, HttpStatus.OK);
			}	
		} catch (BFLBusinessException | BFLTechnicalException | BFLHttpException e) {
			throw e;
		} catch (Exception e) {
			throw new BFLTechnicalException("AUTH-701", env.getProperty("AUTH-701"));
		}
		return responseEntity;
	}
	
	@ApiOperation(value = "NTP Pre Register for BFL with Customer Token", httpMethod = "POST")
	@CrossOrigin
	@RequestMapping(value = "${api.authentication.ntp.preregister.bflcustomertoken.POST.uri}", method = RequestMethod.POST)
	public ResponseEntity<ResponseBean> ntpPreRegisterForBFLWithCustomerToken(
			@Valid @RequestBody NtpPreRegisterRequest preRegisterRequest, @RequestHeader HttpHeaders headers,@RequestHeader(required=true)String merchantCode,
			@RequestHeader(required=true)String hash) {
		ResponseEntity<ResponseBean> responseEntity = null;
		try {
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"ntp ntpPreRegisterForBFLWithCustomerToken - started for - " + preRegisterRequest.toString());
			responseEntity = authService.ntpPreRegister(preRegisterRequest,merchantCode,hash, headers);
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"ntp ntpPreRegisterForBFLWithCustomerToken - ender for - " + responseEntity.toString());
			// Create Customer Token - Start
			if(responseEntity.getStatusCodeValue()==200) {
				NtpPreRegisterRes response = new NtpPreRegisterRes();
				MobileLoginRequest mobileLoginRequest = new MobileLoginRequest();
				Gson gson = new Gson();
				response = gson.fromJson(gson.toJson(responseEntity.getBody().getPayload()), NtpPreRegisterRes.class);
				// Added applicant key in appliaction to get customer token and is only for BFL
				mobileLoginRequest.setApplicationKey(0L);
				mobileLoginRequest.setDateOfBirth(preRegisterRequest.getDateOfBirth());
				mobileLoginRequest.setMobile(preRegisterRequest.getMobileNumber());
				
				mobileLoginRequest.setSource("BFL");

				UserKeysBean userKeysBean = new UserKeysBean();
				userKeysBean.setApplicantKey(response.getApplicantKey());
				userKeysBean.setUserApplicantKey(response.getUserApplicantKey());
				userKeysBean.setUserKey(response.getUserKey());

				UserDetails userDetails = new UserDetails();
				userDetails.setFirstName(response.getFirstName());
				userDetails.setLastName(response.getLastName());
				userDetails.setMobileNumber(response.getMobileNumber());
				userDetails.setDateOfBirth(response.getDateOfBirth());
				userDetails.setCustomerType(response.getCustomerType());
				userDetails.setCustomerReferenceID(response.getCustomerReferenceID());
				
				headers.add("platform", "mob");
				TokenResponse tokenResponse=appOnBoardingUtils.generateTokens(response.getMobileNumber(), response.getUserKey(), (short) 1,
				headers);
				TokenResponseForUserRegister tokenResponseForUserRegister=new TokenResponseForUserRegister();
				tokenResponseForUserRegister.setTokens(tokenResponse.getTokens());
				UserKeysBeanWithTokens userKeysBeanWithTokens = new UserKeysBeanWithTokens();
				userKeysBeanWithTokens.setUserKeysBean(userKeysBean);
				userKeysBeanWithTokens.setTokenResponse(tokenResponseForUserRegister);
				userKeysBeanWithTokens.setUserDetails(userDetails);
				ResponseBean responseBean = new ResponseBean(userKeysBeanWithTokens);
				// Create Customer Token - End
				return new ResponseEntity<>(responseBean, HttpStatus.OK);
			}	
		} catch (BFLBusinessException | BFLTechnicalException | BFLHttpException e) {
			throw e;
		} catch (Exception e) {
			throw new BFLTechnicalException("AUTH-701", env.getProperty("AUTH-701"));
		}
		return responseEntity;
	}
}
