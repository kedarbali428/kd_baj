package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;
import java.util.List;

import com.bajaj.bfsd.common.domain.ErrorBean;

public class EstoreResponseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private transient Object payload;
	private List<ErrorBean> errorBean;
	
	public EstoreResponseBean() { 
		//Empty constructor
	}

	public EstoreResponseBean(Object payload) {
		super();
		this.payload = payload;
	}

	public EstoreResponseBean(List<ErrorBean> errorBean) {
		super();
		this.errorBean = errorBean;
	}
	
	public EstoreResponseBean(Object payload, List<ErrorBean> errorBean) {
		super();
		this.payload = payload;
		this.errorBean = errorBean;
	}

	public List<ErrorBean> getErrorBean() {
		return errorBean;
	}

	public void setErrorBean(List<ErrorBean> errorBean) {
		this.errorBean = errorBean;
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "EstoreResponseBean [payload=" + payload + ", errorBean=" + errorBean + "]";
	}


	
	
}
