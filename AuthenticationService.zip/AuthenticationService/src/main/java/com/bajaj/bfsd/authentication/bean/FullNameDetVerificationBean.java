package com.bajaj.bfsd.authentication.bean;

public class FullNameDetVerificationBean {

	private String preFillValue;
	private boolean toBeDisplayed;
	private boolean isEditable;
	private String verificationSource;
	
	public String getPreFillValue() {
		return preFillValue;
	}
	
	public void setPreFillValue(String preFillValue) {
		this.preFillValue = preFillValue;
	}
	
	public boolean isToBeDisplayed() {
		return toBeDisplayed;
	}
	
	public void setToBeDisplayed(boolean toBeDisplayed) {
		this.toBeDisplayed = toBeDisplayed;
	}
	
	public boolean isEditable() {
		return isEditable;
	}
	
	public void setEditable(boolean isEditable) {
		this.isEditable = isEditable;
	}
	
	public String getVerificationSource() {
		return verificationSource;
	}
	
	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}
	
}
