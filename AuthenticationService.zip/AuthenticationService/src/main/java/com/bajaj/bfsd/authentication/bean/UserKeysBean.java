package com.bajaj.bfsd.authentication.bean;

public class UserKeysBean {

	private Long applicantKey;
	private Long userApplicantKey;
	private Long userKey;

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getUserApplicantKey() {
		return userApplicantKey;
	}

	public void setUserApplicantKey(Long userApplicantKey) {
		this.userApplicantKey = userApplicantKey;
	}

	public Long getUserKey() {
		return userKey;
	}

	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}

	@Override
	public String toString() {
		return "UserKeysBean [applicantKey=" + applicantKey + ", userApplicantKey=" + userApplicantKey + ", userKey="
				+ userKey + "]";
	}

}
