package com.bajaj.bfsd.authentication.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginRequest;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginResponse;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingStatusResponse;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsResponse;
import com.bajaj.bfsd.authentication.bean.UpdatePanProfileRequest;
import com.bajaj.bfsd.authentication.bean.UpdatePanProfileResponse;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsResponse;
import com.bajaj.bfsd.authentication.bean.UserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UserProfileDetailsResponse;

public interface AppOnBoardingService {
	
	AppOnBoardingStatusResponse checkUsersSource(String mobileNumber, String dateOfBirth, String source, HttpHeaders headers);

	AppOnBoardingLoginResponse validateOtpAndLogin(AppOnBoardingLoginRequest otpValidationAndCustomerGenReq, HttpHeaders headers);

	UserProfileDetailsResponse getUserProfilesDetailsData(UserProfileDetailsRequest userProfileDetailsReq, HttpHeaders headers);
	
	UpdateUserProfileDetailsResponse updateApplicantDetails(UpdateUserProfileDetailsRequest profileDetailsPutReq, HttpHeaders headers);

	PanProfileDetailsResponse verifyApplicantPanDetails(PanProfileDetailsRequest panProfileRequest, HttpHeaders headers);

	UpdatePanProfileResponse updateProfilesDetails(UpdatePanProfileRequest updateRequest, HttpHeaders httpHeaders);
	
}
