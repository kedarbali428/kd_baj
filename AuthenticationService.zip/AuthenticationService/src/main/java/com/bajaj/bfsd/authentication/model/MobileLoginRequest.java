package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class MobileLoginRequest implements Serializable {

	private static final long serialVersionUID = -6600697696390594561L;

	@NotNull(message = "mobile can not be null")
	@NotBlank(message = "mobile can not be empty")
	private String mobile;

	private String otp;

	private String dateOfBirth;

	@NotNull(message = "source can not be null")
	@NotBlank(message = "source can not be empty")
	private String source;

	private String stage;

	private String productcatcode;

	private Long applicationKey;

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getProductcatcode() {
		return productcatcode;
	}

	public void setProductcatcode(String productcatcode) {
		this.productcatcode = productcatcode;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	@Override
	public String toString() {
		return "MobileLoginRequest [mobile=" + mobile + ", otp=" + otp + ", dateOfBirth=" + dateOfBirth + ", source="
				+ source + ", stage=" + stage + ", productcatcode=" + productcatcode + ", applicationKey="
				+ applicationKey + "]";
	}

}
