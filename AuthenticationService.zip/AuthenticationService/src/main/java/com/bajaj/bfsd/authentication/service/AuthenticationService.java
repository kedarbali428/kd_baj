/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.service;

import java.io.IOException;
import java.text.ParseException;

import org.json.JSONObject;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.bajaj.bfsd.authentication.bean.ApplicantUtmBean;
import com.bajaj.bfsd.authentication.bean.NtpLoginRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreProcessRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterRequest;
import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV2;
import com.bajaj.bfsd.authentication.model.AadharLoginRequest;
import com.bajaj.bfsd.authentication.model.GenerateOTP;
import com.bajaj.bfsd.authentication.model.LoginAccount;
import com.bajaj.bfsd.authentication.model.LoginSecretKeyResponse;
import com.bajaj.bfsd.authentication.model.MobileDobOtpLoginRequest;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.SocialAuthenticationRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsRequest;
import com.bajaj.bfsd.authentication.model.SocialLoginParamsResponse;
import com.bajaj.bfsd.authentication.model.SocialProfileResponse;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.UserLoginAccountRequest;
import com.bajaj.bfsd.authentication.model.UserLoginAccountResponse;
import com.bajaj.bfsd.common.domain.ResponseBean;


/**
 * This is an Interface for OpenAM external api call.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	28/11/2016      Initial Version
 */
public interface AuthenticationService {

	public String generateOTP(GenerateOTP generateOTP) throws IOException;

	public SocialLoginParamsResponse getFacebookLoginParams(SocialLoginParamsRequest socialLoginParamsRequest);

	public LoginSecretKeyResponse getSecretKey(String clientId);

	public ResponseBean getAadharOtp(String aadharNo);
	
	public JSONObject getAadharUserDetails(AadharLoginRequest aadharLoginRequest);

	public TokenResponse getToken(String loginId, Long userId, short userType, HttpHeaders headers);

	public SocialProfileResponse getSocialDetails(SocialAuthenticationRequest socialRequest, HttpHeaders headers);

	public UserLoginAccountResponse authenticateUser(LoginAccount loginAcct);

	public Boolean authenticateUserInAD(String loginId,String pwd);

	public TokenResponse authenticateManualLogin(UserLoginAccountRequest manualLoginRequest, HttpHeaders headers, ApplicantUtmBean applicantUtmBean);

	public SocialLoginParamsResponse getRedirectUrl(SocialLoginParamsRequest socialLoginParamsRequest);

	public ResponseBean authenticateMobileDob(MobileLoginRequest mobileLoginRequest);

	public boolean validateOtpForMobileDobLogin(MobileLoginRequest mobileLoginRequest);
	
	public void saveProfileDetails(String profileJson, long userId, String target);
	
	public void logout(long userId,HttpHeaders headers);
	
	public void checkUserExistance(String loginId, String dob, Integer loginType,String rType, ApplicantUtmBean applicantUtmBean);
	
	public TokenResponse login(UserLoginAccountRequestV2 userLoginRequest,HttpHeaders headers, ApplicantUtmBean applicantUtmBean);
	/**generate otp for reset mpin.
	 * @param dobOtpLoginRequest
	 * @return
	 */
	public ResponseBean autheticateMobileDobOtp(MobileDobOtpLoginRequest dobOtpLoginRequest);
	public ResponseBean loginWithOtp(UserLoginAccountRequestV2 userLoginRequest, ApplicantUtmBean applicantUtmBean) throws ParseException;

	public ResponseBean mobileAutoLogin(HttpHeaders headers);

	public ResponseEntity<ResponseBean> ntpPreRegister(NtpPreRegisterRequest preRegisterRequest,String merchantCode,String hash, HttpHeaders headers);

	public ResponseEntity<ResponseBean> ntpPreProcess(NtpPreProcessRequest preProcessRequest, HttpHeaders headers);

	public ResponseEntity<ResponseBean> ntpLogin(NtpLoginRequest preLoginRequest, HttpHeaders headers);
}
