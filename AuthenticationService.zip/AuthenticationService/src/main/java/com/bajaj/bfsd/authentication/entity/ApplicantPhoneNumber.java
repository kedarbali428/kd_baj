package com.bajaj.bfsd.authentication.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the APPLICANT_PHONE_NUMBERS database table.
 * 
 */
@Entity
@Table(name="APPLICANT_PHONE_NUMBERS")
//@NamedQuery(name="ApplicantPhoneNumber.findAll", query="SELECT a FROM ApplicantPhoneNumber a")
public class ApplicantPhoneNumber implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long apltphnumkey;

	private String apltphnumareacode;

	private String apltphnumcountrycode;

	@Temporal(TemporalType.DATE)
	private Date apltphnumenddt;

	private BigDecimal apltphnumisactive;

	private BigDecimal apltphnumisdndactive;

	private BigDecimal apltphnumispreferred;

	private BigDecimal apltphnumisverified;

	private String apltphnumlstupdateby;

	private Timestamp apltphnumlstupdatedt;

	private String apltphnumnumber;

	@Temporal(TemporalType.DATE)
	private Date apltphnumstartdt;

	private Timestamp apltphnumverifydt;

	private BigDecimal phonetypekey;

	//bi-directional many-to-one association to Applicant
	@ManyToOne
	@JoinColumn(name="APPLICANTKEY")
	private Applicant applicant;

	public ApplicantPhoneNumber() {
	}

	public long getApltphnumkey() {
		return this.apltphnumkey;
	}

	public void setApltphnumkey(long apltphnumkey) {
		this.apltphnumkey = apltphnumkey;
	}

	public String getApltphnumareacode() {
		return this.apltphnumareacode;
	}

	public void setApltphnumareacode(String apltphnumareacode) {
		this.apltphnumareacode = apltphnumareacode;
	}

	public String getApltphnumcountrycode() {
		return this.apltphnumcountrycode;
	}

	public void setApltphnumcountrycode(String apltphnumcountrycode) {
		this.apltphnumcountrycode = apltphnumcountrycode;
	}

	public Date getApltphnumenddt() {
		return this.apltphnumenddt;
	}

	public void setApltphnumenddt(Date apltphnumenddt) {
		this.apltphnumenddt = apltphnumenddt;
	}

	public BigDecimal getApltphnumisactive() {
		return this.apltphnumisactive;
	}

	public void setApltphnumisactive(BigDecimal apltphnumisactive) {
		this.apltphnumisactive = apltphnumisactive;
	}

	public BigDecimal getApltphnumisdndactive() {
		return this.apltphnumisdndactive;
	}

	public void setApltphnumisdndactive(BigDecimal apltphnumisdndactive) {
		this.apltphnumisdndactive = apltphnumisdndactive;
	}

	public BigDecimal getApltphnumispreferred() {
		return this.apltphnumispreferred;
	}

	public void setApltphnumispreferred(BigDecimal apltphnumispreferred) {
		this.apltphnumispreferred = apltphnumispreferred;
	}

	public BigDecimal getApltphnumisverified() {
		return this.apltphnumisverified;
	}

	public void setApltphnumisverified(BigDecimal apltphnumisverified) {
		this.apltphnumisverified = apltphnumisverified;
	}

	public String getApltphnumlstupdateby() {
		return this.apltphnumlstupdateby;
	}

	public void setApltphnumlstupdateby(String apltphnumlstupdateby) {
		this.apltphnumlstupdateby = apltphnumlstupdateby;
	}

	public Timestamp getApltphnumlstupdatedt() {
		return this.apltphnumlstupdatedt;
	}

	public void setApltphnumlstupdatedt(Timestamp apltphnumlstupdatedt) {
		this.apltphnumlstupdatedt = apltphnumlstupdatedt;
	}

	public String getApltphnumnumber() {
		return this.apltphnumnumber;
	}

	public void setApltphnumnumber(String apltphnumnumber) {
		this.apltphnumnumber = apltphnumnumber;
	}

	public Date getApltphnumstartdt() {
		return this.apltphnumstartdt;
	}

	public void setApltphnumstartdt(Date apltphnumstartdt) {
		this.apltphnumstartdt = apltphnumstartdt;
	}

	public Timestamp getApltphnumverifydt() {
		return this.apltphnumverifydt;
	}

	public void setApltphnumverifydt(Timestamp apltphnumverifydt) {
		this.apltphnumverifydt = apltphnumverifydt;
	}

	public BigDecimal getPhonetypekey() {
		return this.phonetypekey;
	}

	public void setPhonetypekey(BigDecimal phonetypekey) {
		this.phonetypekey = phonetypekey;
	}

	public Applicant getApplicant() {
		return this.applicant;
	}

	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}

}