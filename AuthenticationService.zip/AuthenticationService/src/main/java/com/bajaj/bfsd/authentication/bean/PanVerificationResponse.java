package com.bajaj.bfsd.authentication.bean;

public class PanVerificationResponse {

	private String panNo;
	private String panFName;
	private String panMName;
	private String panLName;
	private String panDate;
	private String panStatus;
	
	public String getPanNo() {
		return panNo;
	}
	
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	
	public String getPanFName() {
		return panFName;
	}
	
	public void setPanFName(String panFName) {
		this.panFName = panFName;
	}
	
	public String getPanMName() {
		return panMName;
	}
	
	public void setPanMName(String panMName) {
		this.panMName = panMName;
	}
	
	public String getPanLName() {
		return panLName;
	}
	
	public void setPanLName(String panLName) {
		this.panLName = panLName;
	}
	
	public String getPanDate() {
		return panDate;
	}
	
	public void setPanDate(String panDate) {
		this.panDate = panDate;
	}
	
	public String getPanStatus() {
		return panStatus;
	}
	
	public void setPanStatus(String panStatus) {
		this.panStatus = panStatus;
	}

	@Override
	public String toString() {
		return "PanResponse [panNo=" + panNo + ", panFName=" + panFName + ", panMName=" + panMName + ", panLName="
				+ panLName + ", panDate=" + panDate + ", panStatus=" + panStatus + "]";
	}
	
}
