package com.bajaj.bfsd.authentication.bean;

import java.math.BigDecimal;
import java.util.Date;

public class ApplicantV2DetailsResponse {
	
	private long applicantKey;
	private Date apltDateOfBirth;
	private BigDecimal apltGrossMthIncome;
	private Integer apltIsActive;
	private BigDecimal apltNetMthIncome;
	private String apltPAN;
	private String apltStatus;
	private Integer genderKey;
	private Integer langKey;
	private Integer maritalStatusKey;
	private Integer nationalityKey;
	private Integer salutationKey;
	private ApplicantNameVerification nameDetails;
	private ApplicantPanVerification panDetails;
	private Long residenceTypeKey;
	private Long occupationType;
	private Long profKey;	

	public ApplicantV2DetailsResponse() {
		super();
	}

	public long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Date getApltDateOfBirth() {
		return apltDateOfBirth;
	}

	public void setApltDateOfBirth(Date apltDateOfBirth) {
		this.apltDateOfBirth = apltDateOfBirth;
	}

	public BigDecimal getApltGrossMthIncome() {
		return apltGrossMthIncome;
	}

	public void setApltGrossMthIncome(BigDecimal apltGrossMthIncome) {
		this.apltGrossMthIncome = apltGrossMthIncome;
	}

	public Integer getApltIsActive() {
		return apltIsActive;
	}

	public void setApltIsActive(Integer apltIsActive) {
		this.apltIsActive = apltIsActive;
	}

	public BigDecimal getApltNetMthIncome() {
		return apltNetMthIncome;
	}

	public void setApltNetMthIncome(BigDecimal apltNetMthIncome) {
		this.apltNetMthIncome = apltNetMthIncome;
	}

	public String getApltPAN() {
		return apltPAN;
	}

	public void setApltPAN(String apltPAN) {
		this.apltPAN = apltPAN;
	}

	public String getApltStatus() {
		return apltStatus;
	}

	public void setApltStatus(String apltStatus) {
		this.apltStatus = apltStatus;
	}

	public Integer getGenderKey() {
		return genderKey;
	}

	public void setGenderKey(Integer genderKey) {
		this.genderKey = genderKey;
	}

	public Integer getLangKey() {
		return langKey;
	}

	public void setLangKey(Integer langKey) {
		this.langKey = langKey;
	}

	public Integer getMaritalStatusKey() {
		return maritalStatusKey;
	}

	public void setMaritalStatusKey(Integer maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}

	public Integer getNationalityKey() {
		return nationalityKey;
	}

	public void setNationalityKey(Integer nationalityKey) {
		this.nationalityKey = nationalityKey;
	}

	public ApplicantNameVerification getNameDetails() {
		return nameDetails;
	}

	public void setNameDetails(ApplicantNameVerification nameDetails) {
		this.nameDetails = nameDetails;
	}

	public ApplicantPanVerification getPanDetails() {
		return panDetails;
	}

	public void setPanDetails(ApplicantPanVerification panDetails) {
		this.panDetails = panDetails;
	}

	public Integer getSalutationKey() {
		return salutationKey;
	}

	public void setSalutationKey(Integer salutationKey) {
		this.salutationKey = salutationKey;
	}

	public Long getResidenceTypeKey() {
		return residenceTypeKey;
	}

	public void setResidenceTypeKey(Long residenceTypeKey) {
		this.residenceTypeKey = residenceTypeKey;
	}

	public Long getOccupationType() {
		return occupationType;
	}

	public void setOccupationType(Long occupationType) {
		this.occupationType = occupationType;
	}

	public Long getProfKey() {
		return profKey;
	}

	public void setProfKey(Long profKey) {
		this.profKey = profKey;
	}


}
