package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ApplicantDetailBean implements  Serializable{


		private static final long serialVersionUID = 6124130279249023332L;
		private Long applicantKey;
		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
		private Date dateOfBirth;
		private String firstName;
		private String lastName;
		private String middleName;
		private String panNumber;
		private String genederCode;
		private String maritalStatusCode;
		private String maritalStatusDesc;
		private String nationalityCode;
		private String genderDesc;
		private List<ApplicantAddressDetailsBean> addressDetails;
		
		private List<ApplicantEmailDetailsBean> emailDetails;
	
		private List<ApplicantPhoneNumberDetailsBean> phoneNumberDetails;
		
		private List<AppDetVerificationDetailsBean> appDetVerificationDetails;
		
		private List<ApplicantEmplDetailsBean> employmentTypeDetails;

		/**
		 * @return the applicantKey
		 */
		public Long getApplicantKey() {
			return applicantKey;
		}

		/**
		 * @param applicantKey the applicantKey to set
		 */
		public void setApplicantKey(Long applicantKey) {
			this.applicantKey = applicantKey;
		}

		/**
		 * @return the dateOfBirth
		 */
		public Date getDateOfBirth() {
			return dateOfBirth;
		}

		/**
		 * @param dateOfBirth the dateOfBirth to set
		 */
		public void setDateOfBirth(Date dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}

		/**
		 * @return the firstName
		 */
		public String getFirstName() {
			return firstName;
		}

		/**
		 * @param firstName the firstName to set
		 */
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		/**
		 * @return the lastName
		 */
		public String getLastName() {
			return lastName;
		}

		/**
		 * @param lastName the lastName to set
		 */
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		/**
		 * @return the middleName
		 */
		public String getMiddleName() {
			return middleName;
		}

		/**
		 * @param middleName the middleName to set
		 */
		public void setMiddleName(String middleName) {
			this.middleName = middleName;
		}

		/**
		 * @return the panNumber
		 */
		public String getPanNumber() {
			return panNumber;
		}

		/**
		 * @param panNumber the panNumber to set
		 */
		public void setPanNumber(String panNumber) {
			this.panNumber = panNumber;
		}

		/**
		 * @return the genederCode
		 */
		public String getGenederCode() {
			return genederCode;
		}

		/**
		 * @param genederCode the genederCode to set
		 */
		public void setGenederCode(String genederCode) {
			this.genederCode = genederCode;
		}

		/**
		 * @return the maritalStatusCode
		 */
		public String getMaritalStatusCode() {
			return maritalStatusCode;
		}

		/**
		 * @param maritalStatusCode the maritalStatusCode to set
		 */
		public void setMaritalStatusCode(String maritalStatusCode) {
			this.maritalStatusCode = maritalStatusCode;
		}

		/**
		 * @return the maritalStatusDesc
		 */
		public String getMaritalStatusDesc() {
			return maritalStatusDesc;
		}

		/**
		 * @param maritalStatusDesc the maritalStatusDesc to set
		 */
		public void setMaritalStatusDesc(String maritalStatusDesc) {
			this.maritalStatusDesc = maritalStatusDesc;
		}

		/**
		 * @return the nationalityCode
		 */
		public String getNationalityCode() {
			return nationalityCode;
		}

		/**
		 * @param nationalityCode the nationalityCode to set
		 */
		public void setNationalityCode(String nationalityCode) {
			this.nationalityCode = nationalityCode;
		}

		/**
		 * @return the genderDesc
		 */
		public String getGenderDesc() {
			return genderDesc;
		}

		/**
		 * @param genderDesc the genderDesc to set
		 */
		public void setGenderDesc(String genderDesc) {
			this.genderDesc = genderDesc;
		}

		/**
		 * @return the addressDetails
		 */
		public List<ApplicantAddressDetailsBean> getAddressDetails() {
			return addressDetails;
		}

		/**
		 * @param addressDetails the addressDetails to set
		 */
		public void setAddressDetails(List<ApplicantAddressDetailsBean> addressDetails) {
			this.addressDetails = addressDetails;
		}

		/**
		 * @return the emailDetails
		 */
		public List<ApplicantEmailDetailsBean> getEmailDetails() {
			return emailDetails;
		}

		/**
		 * @param emailDetails the emailDetails to set
		 */
		public void setEmailDetails(List<ApplicantEmailDetailsBean> emailDetails) {
			this.emailDetails = emailDetails;
		}

		/**
		 * @return the phoneNumberDetails
		 */
		public List<ApplicantPhoneNumberDetailsBean> getPhoneNumberDetails() {
			return phoneNumberDetails;
		}

		/**
		 * @param phoneNumberDetails the phoneNumberDetails to set
		 */
		public void setPhoneNumberDetails(List<ApplicantPhoneNumberDetailsBean> phoneNumberDetails) {
			this.phoneNumberDetails = phoneNumberDetails;
		}

		/**
		 * @return the appDetVerificationDetails
		 */
		public List<AppDetVerificationDetailsBean> getAppDetVerificationDetails() {
			return appDetVerificationDetails;
		}

		/**
		 * @param appDetVerificationDetails the appDetVerificationDetails to set
		 */
		public void setAppDetVerificationDetails(List<AppDetVerificationDetailsBean> appDetVerificationDetails) {
			this.appDetVerificationDetails = appDetVerificationDetails;
		}

		/**
		 * @return the employmentTypeDetails
		 */
		public List<ApplicantEmplDetailsBean> getEmploymentTypeDetails() {
			return employmentTypeDetails;
		}

		/**
		 * @param employmentTypeDetails the employmentTypeDetails to set
		 */
		public void setEmploymentTypeDetails(List<ApplicantEmplDetailsBean> employmentTypeDetails) {
			this.employmentTypeDetails = employmentTypeDetails;
		}

		
		
		

	}
	


