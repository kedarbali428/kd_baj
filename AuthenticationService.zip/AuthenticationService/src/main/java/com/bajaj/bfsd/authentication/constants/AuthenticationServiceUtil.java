/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.constants;

import com.bajaj.bfsd.authentication.config.MapperFactory;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AuthenticationServiceUtil {
    

    public static final String THIS_CLASS = AuthenticationServiceUtil.class.getSimpleName();
   
    private AuthenticationServiceUtil() {} 
        
	public static String mapToJsonString(Object payload, BFLLoggerUtil logger) {

		ObjectMapper mapper = MapperFactory.getInstance();
		try {
			return mapper.writeValueAsString(payload);
		} catch (JsonProcessingException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "mapToJsonString - invalid json to parse" + e);
			throw new BFLTechnicalException("AUTH-009", e);
		}
	}
}
