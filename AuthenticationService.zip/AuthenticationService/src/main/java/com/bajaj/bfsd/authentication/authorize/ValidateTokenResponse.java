package com.bajaj.bfsd.authentication.authorize;

public class ValidateTokenResponse  {
	
	private String tokenStatus;
	private Long userId;
	private String defaultRole;
	private String loginId;

	public String getTokenStatus() {
		return tokenStatus;
	}

	public Long getUserId() {
		return userId;
	}

	public String getDefaultRole() {
		return defaultRole;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setTokenStatus(String tokenStatus) {
		this.tokenStatus = tokenStatus;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public void setDefaultRole(String defaultRole) {
		this.defaultRole = defaultRole;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	@Override
	public String toString() {
		return "ValidateTokenResponse [tokenStatus=" + tokenStatus + ", userId=" + userId + ", defaultRole="
				+ defaultRole + ", loginId=" + loginId + "]";
	}

}
