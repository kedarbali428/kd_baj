package com.bajaj.bfsd.authentication.service.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bajaj.bfsd.authentication.bean.AppDetVerificationDetailsBean;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginRequest;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginResponse;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingStatusResponse;
import com.bajaj.bfsd.authentication.bean.ApplicantAddressDetailsBean;
import com.bajaj.bfsd.authentication.bean.ApplicantDetailBean;
import com.bajaj.bfsd.authentication.bean.ApplicantEmailDetailsBean;
import com.bajaj.bfsd.authentication.bean.ApplicantEmplDetailsBean;
import com.bajaj.bfsd.authentication.bean.ApplicantKeysRequest;
import com.bajaj.bfsd.authentication.bean.ApplicantV2DetailsResponse;
import com.bajaj.bfsd.authentication.bean.BureauDetails;
import com.bajaj.bfsd.authentication.bean.BureauDetailsBean;
import com.bajaj.bfsd.authentication.bean.EmailDetVerificationBean;
import com.bajaj.bfsd.authentication.bean.FullNameDetVerificationBean;
import com.bajaj.bfsd.authentication.bean.LocationAddressBean;
import com.bajaj.bfsd.authentication.bean.MobileAppOnBoardingRequest;
import com.bajaj.bfsd.authentication.bean.MobileAppOnBoardingResponse;
import com.bajaj.bfsd.authentication.bean.NameDetails;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterRequest;
import com.bajaj.bfsd.authentication.bean.NtpPreRegisterResponse;
import com.bajaj.bfsd.authentication.bean.Occupation;
import com.bajaj.bfsd.authentication.bean.OccupationBean;
import com.bajaj.bfsd.authentication.bean.PanDetVerificationBean;
import com.bajaj.bfsd.authentication.bean.PanDetailsBean;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsResponse;
import com.bajaj.bfsd.authentication.bean.PanVerificationResponse;
import com.bajaj.bfsd.authentication.bean.PersonalDetails;
import com.bajaj.bfsd.authentication.bean.PersonalDetailsBean;
import com.bajaj.bfsd.authentication.bean.PinCodeDetVerificationBean;
import com.bajaj.bfsd.authentication.bean.PinCodeDetails;
import com.bajaj.bfsd.authentication.bean.ProspectAddressDetailsResponse;
import com.bajaj.bfsd.authentication.bean.ProspectDetailsResponse;
import com.bajaj.bfsd.authentication.bean.UpdateMobileAppOnBoardingRequest;
import com.bajaj.bfsd.authentication.bean.UpdatePanProfileRequest;
import com.bajaj.bfsd.authentication.bean.UpdatePanProfileResponse;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsResponse;
import com.bajaj.bfsd.authentication.bean.UserKeysBean;
import com.bajaj.bfsd.authentication.bean.UserProfileAttribute;
import com.bajaj.bfsd.authentication.bean.UserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UserProfileDetailsResponse;
import com.bajaj.bfsd.authentication.bean.UserStatusBean;
import com.bajaj.bfsd.authentication.bean.Verification;
import com.bajaj.bfsd.authentication.dao.EstoreAuthenticationDao;
import com.bajaj.bfsd.authentication.model.MobileLoginRequest;
import com.bajaj.bfsd.authentication.model.TokenResponse;
import com.bajaj.bfsd.authentication.model.Tokens;
import com.bajaj.bfsd.authentication.service.AppOnBoardingService;
import com.bajaj.bfsd.authentication.service.AuthenticationService;
import com.bajaj.bfsd.authentication.util.AppOnBoardingUtils;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.DataFormatter;
import com.bajaj.bfsd.authentication.util.EstoreAuthenticationHelper;
import com.bajaj.bfsd.authentication.util.MapperFactory;
import com.bajaj.bfsd.authentication.util.TokenCodeHelper;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@RefreshScope
public class AppOnBoardingServiceImpl implements AppOnBoardingService {

	private static final String THIS_CLASS = AppOnBoardingServiceImpl.class.getCanonicalName();

	@Autowired
	private BFLLoggerUtil logger;

	@Autowired
	private Environment env;

	@Autowired
	private EstoreAuthenticationDao authenticationDao;

	@Autowired
	private AppOnBoardingUtils appOnBoardingUtils;

	@Autowired
	private EstoreAuthenticationHelper estoreAuthenticationHelper;

	@Autowired
	private AuthenticationService authenticationService;

	@Autowired
	private TokenCodeHelper tokenCodeHelper;
	
	@Autowired 
	private DataFormatter dataFormatter;
	
	@Override
	public AppOnBoardingStatusResponse checkUsersSource(String mobileNumber, String dateOfBirth, String source,
			HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "checkUsersSource started with mobileNumber: "+mobileNumber+" and dateOfBirth: "+dateOfBirth);
		AppOnBoardingStatusResponse appOnBoardingResponse = new AppOnBoardingStatusResponse();
		String userExistenceSource = env.getProperty(source.toUpperCase());
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "User existence to be checked on source: " + userExistenceSource);
		if (StringUtils.isNotBlank(userExistenceSource)) {
			String[] userExistenceStatusToCheck = userExistenceSource.split(",");
			checkUserStatusInSource(mobileNumber, dateOfBirth, headers, userExistenceStatusToCheck,
				appOnBoardingResponse);
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "unknown source: "+source);
			throw new BFLBusinessException("AUTH-445", env.getProperty("AUTH-445"));
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "checkUsersSource ended");
		return appOnBoardingResponse;
	}

	public AppOnBoardingStatusResponse checkUserStatusInSource(String mobileNumber, String dateOfBirth, HttpHeaders headers,
		 String[] userExistenceStatusToCheck, AppOnBoardingStatusResponse appOnBoardingResponse) {
		String etp;
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "checkUserStatusInSource started for : " + userExistenceStatusToCheck );
		UserStatusBean userStatusBean = new UserStatusBean();
		for (String userExistence : userExistenceStatusToCheck) {
			switch (userExistence) {
				case AuthenticationServiceConstants.APPLICANTETP:
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "checkUserExistenceInSource for ApplicantETP source");
					etp = checkApplicantETPStatus(mobileNumber, dateOfBirth);
					userStatusBean.setEtp(etp);
					break;
				case AuthenticationServiceConstants.BUREAU:
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "checkUserExistenceInSource for Bureau source");
					break;
				case AuthenticationServiceConstants.PROSPECT:
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "checkUserExistenceInSource for Prospect source");
					ProspectDetailsResponse prospect = appOnBoardingUtils.getProspectDetails(mobileNumber, dateOfBirth, headers);
					if (null != prospect) {
						userStatusBean.setProspect(AuthenticationServiceConstants.YES);
					} else {
						userStatusBean.setProspect(AuthenticationServiceConstants.NO);
					}
					break;
				case AuthenticationServiceConstants.OTPGENERATE:
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "checkUserExistenceInSource generate OTP");
					String otp = appOnBoardingUtils.generateOtp(mobileNumber, headers);
					appOnBoardingResponse.setOtpSent(otp);
					if (otp.equals(AuthenticationServiceConstants.YES)) {
						appOnBoardingResponse.setNextTaskKey(AuthenticationServiceConstants.OTP_VALIDATION);
					}
					break;
				default:
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
							"No user existence check required for: "+userExistence);
					break;
			}
		}
		appOnBoardingResponse.setUserStatus(userStatusBean);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "checkUserStatusInSource ended for : " + userExistenceStatusToCheck );
		return appOnBoardingResponse;
	}

	public String checkApplicantETPStatus(String mobileNumber, String dateOfBirth) {
		String etpStatus = null;
		int userCount = authenticationDao.checkLoginIdExistanceForEstore(mobileNumber, dateOfBirth);
		if (userCount >= 1) {
			etpStatus = AuthenticationServiceConstants.YES;
		} else {
			etpStatus = AuthenticationServiceConstants.NO;
		}
		return etpStatus;
	}
	
	@Override
	public AppOnBoardingLoginResponse validateOtpAndLogin(AppOnBoardingLoginRequest loginRequest,
			HttpHeaders headers) {
		try {
			checkValidSource(loginRequest.getSource());
			AppOnBoardingLoginResponse loginResponse = validateOtpAndCreateApplicant(loginRequest, headers);
			rulesToSetNextTaskKey(loginRequest, headers, loginResponse);
			loginResponse.setMobileNumber(loginRequest.getMobileNumber());
			loginResponse.setDateOfBirth(loginRequest.getDateOfBirth());
			return loginResponse;
		}catch(BFLHttpException | BFLBusinessException | BFLTechnicalException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "validateOtpAndLogin some Exception occured", ex);
			throw new BFLTechnicalException("AUTH-000", env.getProperty("AUTH-000"));
		}
	}
	
	private void checkValidSource(String requestSource) {
		boolean sourcePresent = Arrays.stream(AuthenticationServiceConstants.VALIDSOURCES).anyMatch(source -> source.equalsIgnoreCase(requestSource));
		if(!sourcePresent) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "unknown source: "+requestSource);
			throw new BFLBusinessException("AUTH-445", env.getProperty("AUTH-445"));
		}
	}

	public AppOnBoardingLoginResponse validateOtpAndCreateApplicant(AppOnBoardingLoginRequest loginRequest,
			HttpHeaders headers) {
		AppOnBoardingLoginResponse loginResponse = new AppOnBoardingLoginResponse();
		String otpValidateResponse = appOnBoardingUtils.validateOtp(loginRequest, headers);
		if (AuthenticationServiceConstants.SUCCESS.equalsIgnoreCase(otpValidateResponse)) {
			NtpPreRegisterRequest ntpPreRegisterRequest = new NtpPreRegisterRequest();
			ntpPreRegisterRequest.setMobileNumber(loginRequest.getMobileNumber());
			ntpPreRegisterRequest.setDateOfBirth(loginRequest.getDateOfBirth());
			NtpPreRegisterResponse preRegisterResponse = createApplicant(ntpPreRegisterRequest, headers);
			if(null != preRegisterResponse) {
				Date dateOfBirth = dataFormatter.dateStringToDate(preRegisterResponse.getDateOfBirth(), AuthenticationServiceConstants.DOB_DD_MM_YYYY_HYPHENFORMAT);
				String formattedDateofBirth = dataFormatter.dateToFormatedDateString(dateOfBirth, AuthenticationServiceConstants.DOB_YYYY_MM_DD_FORMAT);
				MobileLoginRequest mobileLoginRequest = new MobileLoginRequest();
				mobileLoginRequest.setMobile(preRegisterResponse.getMobileNumber());
				mobileLoginRequest.setDateOfBirth(formattedDateofBirth);
				tokenCodeHelper.callUserAdditionalDet(mobileLoginRequest, AuthenticationServiceConstants.USERTYPE_CUSTOMER,
						preRegisterResponse.getApplicantKey());	
				List<Tokens> generatedTokens = generateTokens(loginRequest.getMobileNumber(), headers, preRegisterResponse.getUserKey());
				UserKeysBean userKeysBean = new UserKeysBean();
				userKeysBean.setApplicantKey(preRegisterResponse.getApplicantKey());
				userKeysBean.setUserKey(preRegisterResponse.getUserKey());
				userKeysBean.setUserApplicantKey(preRegisterResponse.getUserApplicantKey());
				loginResponse.setUserKeys(userKeysBean);
				loginResponse.setTokens(generatedTokens);
				UserStatusBean userStatusResponseBean = getUserStatusResponseBean(loginRequest.getUserStatus());
				loginResponse.setUserStatus(userStatusResponseBean);
			}else {
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "applicant not exist for given details: "+ loginRequest);
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "AUTH-696", 
						env.getProperty("AUTH-696"));
			}
		}else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "otp Validation Failed");
			throw new BFLHttpException(HttpStatus.UNAUTHORIZED, AuthenticationServiceConstants.AUTH_630, 
					env.getProperty(AuthenticationServiceConstants.AUTH_630));
		}
		return loginResponse;
	}

	private NtpPreRegisterResponse createApplicant(NtpPreRegisterRequest ntpPreRegisterRequest, HttpHeaders headers) {
		try {
			NtpPreRegisterResponse preRegisterResponse = null;
			HttpHeaders createApplicantheaders = prepareHeaders(headers);
			ResponseEntity<ResponseBean> createApplicantResponse = authenticationService
					.ntpPreRegister(ntpPreRegisterRequest, null, null, createApplicantheaders);
			ObjectMapper mapper = MapperFactory.getInstance();
			String responseBody = mapper.writeValueAsString(createApplicantResponse.getBody().getPayload());
			preRegisterResponse = mapper.readValue(responseBody, NtpPreRegisterResponse.class);
			return preRegisterResponse;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Some Exception occured while applicant registration ", ex);
			throw new BFLTechnicalException("AUTH-701", env.getProperty("AUTH-701"));
		}
	}
	
	private HttpHeaders prepareHeaders(HttpHeaders requestHeaders) {
		HttpHeaders createApplicantHeaders = new HttpHeaders();
		createApplicantHeaders.setContentType(MediaType.APPLICATION_JSON);
		Set<Entry<String, List<String>>> entrySet = requestHeaders.entrySet();
		entrySet.stream()
			.filter(header -> header.getKey().matches("^utm_.*"))
			.forEach(header -> createApplicantHeaders.set(header.getKey(), header.getValue().get(0)));
		
		addHeaderIfPresent(createApplicantHeaders, requestHeaders, "platform");
		addHeaderIfPresent(createApplicantHeaders, requestHeaders, "user_agent");
		addHeaderIfPresent(createApplicantHeaders, requestHeaders, "app_source");
		return createApplicantHeaders;
	}

	private HttpHeaders addHeaderIfPresent(HttpHeaders newHeaders, HttpHeaders oldHeaders, String string) {
		String value = oldHeaders.getFirst(string);
		if(null != value ) {
			newHeaders.set(string, value);
		}
		return newHeaders;
	}

	public List<Tokens> generateTokens(String mobileNumber, HttpHeaders headers, Long userKey) {
		headers.add("platform", "mob");
		TokenResponse tokenResponse = appOnBoardingUtils.generateTokens(mobileNumber, userKey, (short) 1, headers);
		return tokenResponse.getTokens();
	}
	
	public void rulesToSetNextTaskKey(AppOnBoardingLoginRequest loginRequest,
			HttpHeaders requestheaders, AppOnBoardingLoginResponse loginResponse) {
		try {
			String applicantKey = loginResponse.getUserKeys().getApplicantKey().toString();
			String requestSource = loginRequest.getSource().toLowerCase();
			HttpHeaders headers = prepareHeaders(requestheaders);
			headers.set(AuthenticationServiceConstants.AUTH_TOKEN, loginResponse.getTokens().get(0).getToken());
			switch(requestSource) {
				case AuthenticationServiceConstants.CUSTOMER_PORTAL:
					Map<String, Object> applicantDetails = getApplicantStatusDetails(loginRequest.getUserStatus(),
							applicantKey, headers, requestSource);
					ApplicantDetailBean applicant = (ApplicantDetailBean)applicantDetails.get("applicant");
					if(null != applicant) {
						String setNextTaskForCustomerPortalSource = getNextTaskForCustomerPortalSource(applicant);
						loginResponse.setNextTaskKey(setNextTaskForCustomerPortalSource);
					}else {
						logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "applicant does not exist: " + loginRequest);
						throw new BFLBusinessException("AUTH_641", env.getProperty("AUTH_641"));
					}
					break;
				case AuthenticationServiceConstants.MOBILEAPP:
					String setNextTaskForMobileAppSource = getNextTaskForMobileAppSource(loginRequest.getUserStatus(), 
							headers, applicantKey, requestSource);
					loginResponse.setNextTaskKey(setNextTaskForMobileAppSource);
					break;
				case AuthenticationServiceConstants.MOBAPP:
					String setNextTaskForMobAppSource = getNextTaskForMobAppSource(loginRequest.getUserStatus(),
							headers, applicantKey, requestSource);
					loginResponse.setNextTaskKey(setNextTaskForMobAppSource);
					break;
				default:
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "No next task to set for source : "+requestSource);
					break;
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, String.format("next Task set for source %s is : %s ", requestSource, loginResponse.getNextTaskKey()));
		}catch(BFLBusinessException | BFLTechnicalException | BFLHttpException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "rulesToSetNextTaskKey: Some Exception occured", ex);
			throw new BFLTechnicalException(AuthenticationServiceConstants.AUTH_648, 
					env.getProperty(AuthenticationServiceConstants.AUTH_648));
		}
	}

	private String getNextTaskForCustomerPortalSource(ApplicantDetailBean applicantDetailBean) {
		String nextTaskKey = null;
		if (StringUtils.isBlank(applicantDetailBean.getFirstName())) {
			nextTaskKey = AuthenticationServiceConstants.PERSONAL_DETAILS;
		}else {
			nextTaskKey = AuthenticationServiceConstants.HOME;
		}
		return nextTaskKey;
	}
	
	private String getNextTaskForMobileAppSource(UserStatusBean userStatus, HttpHeaders headers, String applicantKey,
			String requestSource) {
		String nextTaskKey = null;
		if(AuthenticationServiceConstants.CAMPAIGN.equalsIgnoreCase(headers.getFirst(AuthenticationServiceConstants.UTMJOURNEY_HEADERKEY))){
			nextTaskKey = AuthenticationServiceConstants.HOME;	
		}else {
			Map<String, Object> applicantDetails = getApplicantStatusDetails(userStatus, applicantKey, headers, requestSource);
			ApplicantDetailBean applicant = (ApplicantDetailBean)applicantDetails.get("applicant");
			if(null != applicant) {
				if(StringUtils.isBlank(applicant.getPanNumber())){
					nextTaskKey = AuthenticationServiceConstants.BUREAU_DETAILS;	
				}else if (StringUtils.isBlank(applicant.getFirstName()) || StringUtils.isBlank(applicant.getLastName())
					|| (null == applicant.getAddressDetails() || applicant.getAddressDetails().isEmpty())
					|| (null == applicant.getEmailDetails() || applicant.getEmailDetails().isEmpty())) {
					nextTaskKey = AuthenticationServiceConstants.PERSONAL_DETAILS;
				}else {
					nextTaskKey = AuthenticationServiceConstants.HOME;
				}
			} else { 
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "applicant does not exist: " + applicantKey);
				throw new BFLBusinessException("AUTH_641", env.getProperty("AUTH_641"));
			}
		}
		return nextTaskKey;
	}
	
	private String getNextTaskForMobAppSource(UserStatusBean userStatus, HttpHeaders headers, 
			String applicantKey, String requestSource) {
		try {
			String nextTaskKey = null;
			String utmJourney = headers.getFirst(AuthenticationServiceConstants.UTMJOURNEY_HEADERKEY);
			if(AuthenticationServiceConstants.CAMPAIGN.equalsIgnoreCase(utmJourney)) {
				nextTaskKey = AuthenticationServiceConstants.HOME;
			} else {
				nextTaskKey = computeNextTaskForMobAppOnSkipFlagBasis(userStatus, headers, applicantKey, requestSource);
			} 
			if (null == nextTaskKey){
				logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "getNextTaskForMobAppSource: invalid etp status");
				throw new BFLTechnicalException("AUTH_674", env.getProperty("AUTH_674"));
			}
			return nextTaskKey;
		} catch(BFLTechnicalException | BFLHttpException ex) {
			throw ex;
		} catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "setNextTaskForMobAppSource: Some Exception occured", ex);
			throw new BFLTechnicalException(AuthenticationServiceConstants.AUTH_627, env.getProperty(AuthenticationServiceConstants.AUTH_627));
		}
	}
	
	public Map<String, Object> getApplicantStatusDetails(UserStatusBean userStatus, String applicantKey, 
			HttpHeaders headers, String source) {
		Map<String, Object> applicantDetailsBean = new HashMap<>();
		String etp = null;
		if(null != userStatus)
			etp = userStatus.getEtp();
		if( AuthenticationServiceConstants.YES.equalsIgnoreCase(etp)
				&& AuthenticationServiceConstants.MOBAPP.equalsIgnoreCase(source)) {
			ApplicantV2DetailsResponse applicantV2Details = appOnBoardingUtils
					.getApplicantDetailsV2WithPanVerification(applicantKey, headers);
			if(null != applicantV2Details) {
				applicantDetailsBean.put("applicant", applicantV2Details);
			} 	
		} else if(!AuthenticationServiceConstants.MOBAPP.equalsIgnoreCase(source)) {
			ApplicantDetailBean applicantDetails = appOnBoardingUtils.getApplicantDetails(applicantKey,  headers);
			if(null != applicantDetails) {
				applicantDetailsBean.put("applicant", applicantDetails);
			}
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "getApplicantStatusDetails: invalid etp status");
			throw new BFLTechnicalException("AUTH_674", env.getProperty("AUTH_674"));
		}
		return applicantDetailsBean;
	}
	
	private UserStatusBean getUserStatusResponseBean(UserStatusBean userStatusRequestBean) {
		UserStatusBean userStatusResponseBean = new UserStatusBean();
		if(null != userStatusRequestBean) {
			userStatusResponseBean.setEtp(AuthenticationServiceConstants.YES);
			userStatusResponseBean.setProspect(userStatusRequestBean.getProspect());
			userStatusResponseBean.setBureau(userStatusRequestBean.getBureau());
		} else {
			//In future criteria for bureau and prospect need to be added
			userStatusResponseBean.setEtp(AuthenticationServiceConstants.YES);
		}
		return userStatusResponseBean;
	}
	
	private String computeNextTaskForMobAppOnSkipFlagBasis(UserStatusBean userStatus, 
			HttpHeaders headers, String applicantKey, String requestSource) {
		String computedNextTask = null;
		String etp = userStatus.getEtp();
		MobileAppOnBoardingRequest skipFlagRequest = new MobileAppOnBoardingRequest();
		skipFlagRequest.setApplicantId(Long.valueOf(applicantKey));
		skipFlagRequest.setEtpStatus(etp);
		MobileAppOnBoardingResponse skipFlagResponse = 
				appOnBoardingUtils.saveApplicantMobAppOnBoardingStatus(skipFlagRequest, headers);
		if( (null != skipFlagResponse.getSkipFlag()) && skipFlagResponse.getSkipFlag()) {
			computedNextTask = AuthenticationServiceConstants.HOME;	
		} else if(AuthenticationServiceConstants.YES.equalsIgnoreCase(etp)) {
			Map<String, Object> applicantDetails = getApplicantStatusDetails(userStatus, applicantKey,
					headers, requestSource);
			ApplicantV2DetailsResponse applicantV2Details = (ApplicantV2DetailsResponse)applicantDetails.get("applicant");
			String panNumber = applicantV2Details.getPanDetails().getPanNumber();
			if(StringUtils.isBlank(panNumber)) {
				computedNextTask = AuthenticationServiceConstants.BUREAU_DETAILS;	
			} else {
				String panVerifiedStatus = applicantV2Details.getPanDetails().getVerificationflg();
				if(AuthenticationServiceConstants.PAN_VERIFIED_STATUS_TRUE.equals(panVerifiedStatus)) {
					computedNextTask = AuthenticationServiceConstants.HOME;	
				}else {
					computedNextTask = AuthenticationServiceConstants.BUREAU_DETAILS;	
				}
			}
		} else if(AuthenticationServiceConstants.NO.equalsIgnoreCase(etp) || StringUtils.isBlank(etp) ) {
			computedNextTask = AuthenticationServiceConstants.BUREAU_DETAILS;
		}
		return computedNextTask;
	}

	@Override
	public UserProfileDetailsResponse getUserProfilesDetailsData(UserProfileDetailsRequest userProfileDetailsReq, HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
				"inside getUserProfilesDetailsData start with Request:" + userProfileDetailsReq);
		UserProfileDetailsResponse userProfileDetailsRes = new UserProfileDetailsResponse();
		BureauDetailsBean bureausDetails = new BureauDetailsBean();
		PersonalDetailsBean personalDetails = new PersonalDetailsBean();
		PanDetVerificationBean panNumber = new PanDetVerificationBean();
		EmailDetVerificationBean emailId = new EmailDetVerificationBean();
		PinCodeDetVerificationBean pinCode = new PinCodeDetVerificationBean();
		FullNameDetVerificationBean fullNameDetVerificationBean = new FullNameDetVerificationBean();
		OccupationBean occupationBean = new OccupationBean();
		ApplicantDetailBean applicantDetailBean = appOnBoardingUtils
				.getApplicantDetails(userProfileDetailsReq.getUserKeys().getApplicantKey().toString(), headers);
		applicantDataRules(userProfileDetailsRes, panNumber, emailId, pinCode, fullNameDetVerificationBean,
				occupationBean, applicantDetailBean);
		prospectDataRules(userProfileDetailsReq, headers, panNumber, emailId, pinCode, fullNameDetVerificationBean);

		bureausDetails.setPan(panNumber);
		personalDetails.setName(fullNameDetVerificationBean);
		personalDetails.setEmail(emailId);
		personalDetails.setPinCode(pinCode);
		personalDetails.setOccupation(occupationBean);
        if(panNumber.isToBeDisplayed() && panNumber.isEditable() && 
        		!(AuthenticationServiceConstants.PERSONAL_DETAILS.equalsIgnoreCase(userProfileDetailsReq.getCurrentTask())))
        {
        	userProfileDetailsRes.setCurrentTask(AuthenticationServiceConstants.BUREAU_DETAILS);
        	userProfileDetailsRes.setSkipAllowed(true);
        } else if (fullNameDetVerificationBean.isEditable() || 
        		emailId.isEditable() || 
        		pinCode.isEditable() ||
        		occupationBean.isEditable()) {
        	userProfileDetailsRes.setCurrentTask(AuthenticationServiceConstants.PERSONAL_DETAILS);
        	userProfileDetailsRes.setSkipAllowed(false);
        }else {
        	userProfileDetailsRes.setCurrentTask(AuthenticationServiceConstants.HOME);
        	userProfileDetailsRes.setSkipAllowed(false);
        }
         
		userProfileDetailsRes.setBureauDetails(bureausDetails);
		userProfileDetailsRes.setPersonalDetails(personalDetails);
		return userProfileDetailsRes;
	}

	public void prospectDataRules(UserProfileDetailsRequest userProfileDetailsReq, HttpHeaders headers,
			PanDetVerificationBean panNumber, EmailDetVerificationBean emailId, PinCodeDetVerificationBean pinCode,
			FullNameDetVerificationBean fullNameDetVerificationBean) {
		if (StringUtils.isBlank(fullNameDetVerificationBean.getPreFillValue())
				|| StringUtils.isBlank(panNumber.getPreFillValue()) || StringUtils.isBlank(emailId.getPreFillValue())
				|| StringUtils.isBlank(pinCode.getPreFillValue())) {
			ProspectDetailsResponse prospect = appOnBoardingUtils.getProspectDetails(
					userProfileDetailsReq.getMobileNumber(), userProfileDetailsReq.getDateOfBirth(), headers);
			if (null != prospect) {
				if (StringUtils.isBlank(fullNameDetVerificationBean.getPreFillValue())
						&& StringUtils.isNotBlank(prospect.getFirstName())
						|| StringUtils.isNotBlank(prospect.getLastName())) {
					StringBuilder name = new StringBuilder().append(prospect.getFirstName());
					if(StringUtils.isNotBlank(prospect.getMiddleName())){
						name=name.append(" ").append(prospect.getMiddleName());
							}
					if(StringUtils.isNotBlank(prospect.getLastName())) {
						name=name.append(" ").append(prospect.getLastName());
					}
					fullNameDetVerificationBean.setPreFillValue(name.toString());
					fullNameDetVerificationBean.setEditable(true);
					fullNameDetVerificationBean.setToBeDisplayed(true);
				} 
				if (StringUtils.isBlank(panNumber.getPreFillValue())
						&& StringUtils.isNotBlank(prospect.getPan())) {
					panNumber.setPreFillValue(prospect.getPan());
					panNumber.setEditable(true);
					panNumber.setToBeDisplayed(true);
				} 
				if (StringUtils.isBlank(emailId.getPreFillValue())
						&& StringUtils.isNotBlank(prospect.getEmailId())) {
					emailId.setPreFillValue(prospect.getEmailId());
					emailId.setEditable(true);
					emailId.setToBeDisplayed(true);
				} 
				if (StringUtils.isBlank(pinCode.getPreFillValue())
						&& !prospect.getProspectAddress().isEmpty()) {
					ProspectAddressDetailsResponse applicantAddressDetailsBean = prospect.getProspectAddress().get(0);
					pinCode.setPreFillValue(applicantAddressDetailsBean.getPincode());
					pinCode.setEditable(true);
					pinCode.setToBeDisplayed(true);
				}

			}
		}
	}

	public void applicantDataRules(UserProfileDetailsResponse userProfileDetailsRes, PanDetVerificationBean panNumber,
			EmailDetVerificationBean emailId, PinCodeDetVerificationBean pinCode,
			FullNameDetVerificationBean fullNameDetVerificationBean, OccupationBean occupationBean,
			ApplicantDetailBean applicantDetailBean) {
		if (null != applicantDetailBean) {

			panCheck(userProfileDetailsRes, panNumber, applicantDetailBean);
			nameCheck(fullNameDetVerificationBean, applicantDetailBean);
			emailCheck(emailId, applicantDetailBean);
			pinCodeCheck(pinCode, applicantDetailBean);
			occupationCheck(occupationBean, applicantDetailBean);
			verificationRuleSet(panNumber, emailId, fullNameDetVerificationBean, applicantDetailBean,occupationBean,pinCode);

		}
	}

	public void verificationRuleSet(PanDetVerificationBean panNumber, EmailDetVerificationBean emailId,
			FullNameDetVerificationBean fullNameDetVerificationBean, ApplicantDetailBean applicantDetailBean,OccupationBean occupationBean,PinCodeDetVerificationBean pinCode) {
		if (null != applicantDetailBean.getAppDetVerificationDetails()
				&& !(applicantDetailBean.getAppDetVerificationDetails().isEmpty())) {
			for (AppDetVerificationDetailsBean appDetVerificationDetailsBean : applicantDetailBean
					.getAppDetVerificationDetails()) {
				nameVerifiedCheck(fullNameDetVerificationBean, appDetVerificationDetailsBean);
				panVerifiedCheck(panNumber, appDetVerificationDetailsBean);
				emailVerifiedCheck(emailId, appDetVerificationDetailsBean);
			}
		}
			
	}

	public void emailVerifiedCheck(EmailDetVerificationBean emailId,
			AppDetVerificationDetailsBean appDetVerificationDetailsBean) {
		if ("EMAIL".equalsIgnoreCase(appDetVerificationDetailsBean.getFieldlabel())) {
			emailId.setEditable(false);
			emailId.setToBeDisplayed(false);
			emailId.setVerificationSource(appDetVerificationDetailsBean.getVerificationsrc());
		}else if(null == emailId.getVerificationSource()){
			emailId.setEditable(true);
			emailId.setToBeDisplayed(true);
		}
	}

	public void panVerifiedCheck(PanDetVerificationBean panNumber,
			AppDetVerificationDetailsBean appDetVerificationDetailsBean) {
		if ("PAN".equalsIgnoreCase(appDetVerificationDetailsBean.getFieldlabel())) {
			panNumber.setEditable(false);
			panNumber.setToBeDisplayed(false);
			panNumber.setVerificationSource(appDetVerificationDetailsBean.getVerificationsrc());
		
		} else if(null==panNumber.getVerificationSource()){
			panNumber.setEditable(true);
			panNumber.setToBeDisplayed(true);
		}
	}

	public void nameVerifiedCheck(FullNameDetVerificationBean fullNameDetVerificationBean,
			AppDetVerificationDetailsBean appDetVerificationDetailsBean) {
		if ("NAME".equalsIgnoreCase(appDetVerificationDetailsBean.getFieldlabel())) {
			fullNameDetVerificationBean.setEditable(false);
			fullNameDetVerificationBean.setToBeDisplayed(false);
			fullNameDetVerificationBean.setVerificationSource(appDetVerificationDetailsBean.getVerificationsrc());
		} else if(null==fullNameDetVerificationBean.getVerificationSource()){
				fullNameDetVerificationBean.setEditable(true);
				fullNameDetVerificationBean.setToBeDisplayed(true);
		}
	}

	public void occupationCheck(OccupationBean occupationBean, ApplicantDetailBean applicantDetailBean) {
		if (null != applicantDetailBean.getEmploymentTypeDetails()
				&& !applicantDetailBean.getEmploymentTypeDetails().isEmpty()) {
			ApplicantEmplDetailsBean applicantEmplDetailsBean = applicantDetailBean.getEmploymentTypeDetails().get(0);
			if(null != applicantEmplDetailsBean.getEmploymentType()) {
			if (applicantEmplDetailsBean.getEmploymentType() == 1) {
				occupationBean.setPreFillValue("Salaried");
			} else if (applicantEmplDetailsBean.getEmploymentType() == 2) {
				occupationBean.setPreFillValue("Business Owner");
			} else if (applicantEmplDetailsBean.getEmploymentType() == 7) {
				occupationBean.setPreFillValue("Chartered Accountant");
			} else if (applicantEmplDetailsBean.getEmploymentType() == 6) {
					occupationBean.setPreFillValue("Doctor");
			} else {
				occupationBean.setPreFillValue("Others");
			}
		    occupationBean.setEditable(false);
		    occupationBean.setToBeDisplayed(false);
			}
		} else {
			occupationBean.setEditable(true);
		    occupationBean.setToBeDisplayed(false);
		}
	}

	public void pinCodeCheck(PinCodeDetVerificationBean pinCode, ApplicantDetailBean applicantDetailBean) {
		if (null != applicantDetailBean.getAddressDetails() && !applicantDetailBean.getAddressDetails().isEmpty()) {
			for (ApplicantAddressDetailsBean applicantAddressDetailsBean : applicantDetailBean.getAddressDetails()) {
				if ("CURRENT".equals(applicantAddressDetailsBean.getType())) {
					pinCode.setPreFillValue(applicantAddressDetailsBean.getPinCode());
					pinCode.setEditable(false);
					pinCode.setToBeDisplayed(true);
					break;
				}else if ("OTHERS".equals(applicantAddressDetailsBean.getType())) {
					pinCode.setPreFillValue(applicantAddressDetailsBean.getPinCode());
					pinCode.setEditable(false);
					pinCode.setToBeDisplayed(true);
					break;
				}
			}
		}
		
		if(StringUtils.isBlank(pinCode.getPreFillValue())){
			pinCode.setEditable(true);
			pinCode.setToBeDisplayed(true);
		}
		
	}

	public void emailCheck(EmailDetVerificationBean emailId, ApplicantDetailBean applicantDetailBean) {
		if (null != applicantDetailBean.getEmailDetails() && !applicantDetailBean.getEmailDetails().isEmpty()) {

			for (ApplicantEmailDetailsBean applicantEmailDetailsBean : applicantDetailBean.getEmailDetails()) {
				if ("PERSON1".equals(applicantEmailDetailsBean.getType())) {
					emailId.setPreFillValue(applicantEmailDetailsBean.getEmailAddress());
					emailId.setEditable(false);
					emailId.setToBeDisplayed(true);
				}
			}
		}
		
		if(StringUtils.isBlank(emailId.getPreFillValue())){
			emailId.setEditable(true);
			emailId.setToBeDisplayed(true);
		}
	}

	public void nameCheck(FullNameDetVerificationBean fullNameDetVerificationBean,
			ApplicantDetailBean applicantDetailBean) {
		if (StringUtils.isNotBlank(applicantDetailBean.getFirstName())
				|| StringUtils.isNotBlank(applicantDetailBean.getLastName())) {
			StringBuilder name = (new StringBuilder()).append(applicantDetailBean.getFirstName());
			if(StringUtils.isNotBlank(applicantDetailBean.getMiddleName())){
				name=name.append(" ").append(applicantDetailBean.getMiddleName());
					}
			if(StringUtils.isNotBlank(applicantDetailBean.getLastName())) {
				name=name.append(" ").append(applicantDetailBean.getLastName());
			}
			fullNameDetVerificationBean.setPreFillValue(name.toString());
			fullNameDetVerificationBean.setToBeDisplayed(true);
		}else {
			fullNameDetVerificationBean.setEditable(true);
			fullNameDetVerificationBean.setToBeDisplayed(true);
		}
	}

	public void panCheck(UserProfileDetailsResponse userProfileDetailsRes, PanDetVerificationBean panNumber,
			ApplicantDetailBean applicantDetailBean) {
		if (StringUtils.isNotBlank(applicantDetailBean.getPanNumber())) {
			panNumber.setPreFillValue(applicantDetailBean.getPanNumber());
			panNumber.setEditable(false);
			panNumber.setToBeDisplayed(true);
			userProfileDetailsRes.setSkipAllowed(true);
		}else {
			panNumber.setEditable(true);
			panNumber.setToBeDisplayed(true);
			userProfileDetailsRes.setSkipAllowed(true);
		}
	}

	@Override
	public UpdateUserProfileDetailsResponse updateApplicantDetails(UpdateUserProfileDetailsRequest profileDetailsPutReq, HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
				"inside updateApplicantDetails start with request:" + profileDetailsPutReq);
		UpdateUserProfileDetailsResponse userProfileDetailsPutRes = new UpdateUserProfileDetailsResponse();
		if(null != profileDetailsPutReq.getBureauDetails()){
			if( null != profileDetailsPutReq.getBureauDetails().getPan()){
				appOnBoardingUtils.updatePanDetails(profileDetailsPutReq, null, headers);
			}
		}
		if (null != profileDetailsPutReq.getPersonalDetails()) {
			updateName(profileDetailsPutReq, headers);
			updateEmail(profileDetailsPutReq, headers);
			updatePincode(profileDetailsPutReq, headers);
			updateOccupation(profileDetailsPutReq, headers);
		}
		nextTaskKeyRule(profileDetailsPutReq, userProfileDetailsPutRes,headers);
		return userProfileDetailsPutRes;
	}

	public void nextTaskKeyRule(UpdateUserProfileDetailsRequest profileDetailsPutReq,
			UpdateUserProfileDetailsResponse userProfileDetailsPutRes,HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "inside next task key after completing all update operations with request:"+profileDetailsPutReq);
		if (AuthenticationServiceConstants.BUREAU_DETAILS.equalsIgnoreCase(profileDetailsPutReq.getCurrentTask())) {
			userProfileDetailsPutRes.setNextTaskKey(AuthenticationServiceConstants.PERSONAL_DETAILS);
		} else if (AuthenticationServiceConstants.PERSONAL_DETAILS.equalsIgnoreCase(profileDetailsPutReq.getCurrentTask())
				&& AuthenticationServiceConstants.MOBILEAPP.equalsIgnoreCase(profileDetailsPutReq.getSource())) {
			userProfileDetailsPutRes.setNextTaskKey(AuthenticationServiceConstants.PHOME);
		} else {
			userProfileDetailsPutRes.setNextTaskKey(AuthenticationServiceConstants.HOME);
		}
	}

	public void updateOccupation(UpdateUserProfileDetailsRequest profileDetailsPutReq, HttpHeaders headers) {
		if ( null != profileDetailsPutReq.getPersonalDetails().getOccupation()
				&& StringUtils.isNotBlank(profileDetailsPutReq.getPersonalDetails().getOccupation().getUserInput())) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"inside updateOccupation start with request:" + profileDetailsPutReq);
			Occupation occupation = estoreAuthenticationHelper.mapOccupationData(profileDetailsPutReq);
			if (StringUtils.isNotBlank(occupation.getOcupationType().getValue())) {
				appOnBoardingUtils.updateOccupationDetails(profileDetailsPutReq, occupation, headers);
			}
		}
	}

	public void updatePincode(UpdateUserProfileDetailsRequest profileDetailsPutReq, HttpHeaders headers) {
		if ( null != profileDetailsPutReq.getPersonalDetails().getPinCode()
				&& StringUtils.isNotBlank(profileDetailsPutReq.getPersonalDetails().getPinCode().getUserInput())) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"inside updatePinCode start with request:" + profileDetailsPutReq);
			LocationAddressBean locationAddressBean = appOnBoardingUtils.getPinCodeDetails(profileDetailsPutReq,
					headers);
			if (null != locationAddressBean) {
				appOnBoardingUtils.updateAddressDetails(profileDetailsPutReq, locationAddressBean, headers);
			}
		}
	}

	public void updateEmail(UpdateUserProfileDetailsRequest profileDetailsPutReq, HttpHeaders headers) {
		if (null != profileDetailsPutReq.getPersonalDetails().getEmail()
				&& StringUtils.isNotBlank(profileDetailsPutReq.getPersonalDetails().getEmail().getUserInput())) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"inside updateEmail start with request:" + profileDetailsPutReq);
			appOnBoardingUtils.updateEmailDetails(profileDetailsPutReq, headers);
		}
	}

	public void updateName(UpdateUserProfileDetailsRequest profileDetailsPutReq, HttpHeaders headers) {
		if (null != (profileDetailsPutReq.getPersonalDetails().getName())
				&& StringUtils.isNotBlank(profileDetailsPutReq.getPersonalDetails().getName().getUserInput())) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"inside updateFullName start with request:" + profileDetailsPutReq);
			UserProfileAttribute userProfileAttribute = estoreAuthenticationHelper
					.mapFullNameData(profileDetailsPutReq);
			appOnBoardingUtils.updateApplicantDetails(userProfileAttribute, profileDetailsPutReq, headers);
		}
	}

	@Override
	public PanProfileDetailsResponse verifyApplicantPanDetails(PanProfileDetailsRequest panProfileRequest, HttpHeaders headers) {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"verifyApplicantPanDetails started with request:" + panProfileRequest);
			Boolean skipStatus = updateAppOnBoardingSkipFlagStatus(panProfileRequest, headers);
			PanProfileDetailsResponse panProfileResponse = null;
			if((null != skipStatus) && !skipStatus) { 
				String panNumber = panProfileRequest.getPanNumber();
				PanVerificationResponse panVerificationResponse = callPanVerificationApi(panProfileRequest, headers);
				if((null != panVerificationResponse) && checkPanStatus(panVerificationResponse.getPanStatus())) {
					List<String> nameParts = Arrays.asList(panVerificationResponse.getPanFName(), 
							panVerificationResponse.getPanMName(), panVerificationResponse.getPanLName());
					panProfileResponse = preparePanVerificationResponse(panNumber, prepareApplicantsPanName(nameParts),
							AuthenticationServiceConstants.YES, AuthenticationServiceConstants.BASIC_DETAILS);
				} else {
					panProfileResponse = preparePanVerificationResponse(panNumber, StringUtils.EMPTY,
							AuthenticationServiceConstants.NO, AuthenticationServiceConstants.PERSONAL_DETAILS);
				}	
			} else {
				panProfileResponse = preparePanVerificationResponse(null, null, null, AuthenticationServiceConstants.HOME);
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"verifyApplicantPanDetails ended with response:" + panProfileResponse);
			return panProfileResponse;
		} catch(BFLHttpException | BFLBusinessException | BFLTechnicalException ex) {
			throw ex;
		} catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "updateProfilesPanDetails: Some Exception occured", ex);
			throw new BFLTechnicalException("AUTH-000", env.getProperty("AUTH-000"));
		}
	}
	
	private Boolean updateAppOnBoardingSkipFlagStatus(PanProfileDetailsRequest panProfileRequest, HttpHeaders headers) {
		UpdateMobileAppOnBoardingRequest updateSkipFlagRequest = new UpdateMobileAppOnBoardingRequest();
		updateSkipFlagRequest.setApplicantId(panProfileRequest.getUserKeys().getApplicantKey());
		updateSkipFlagRequest.setSkipFlag(panProfileRequest.getSkipped());
		MobileAppOnBoardingResponse updateResponse = appOnBoardingUtils
				.updateApplicantMobAppOnBoardingStatus(updateSkipFlagRequest, headers);
		updateResponse.getSkipFlag();
		return updateResponse.getSkipFlag();
	}

	private PanVerificationResponse callPanVerificationApi(PanProfileDetailsRequest panProfileRequest, HttpHeaders headers) {
		PanVerificationResponse panVerificationResponse = null;
		try {
			panVerificationResponse = appOnBoardingUtils
					.getApplicantNsdlPanVerificationStatus(panProfileRequest, headers);
		} catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "panVerification: nsdl pan Verification api failed", ex);
		}
		return panVerificationResponse;
	}
	
	private boolean checkPanStatus(String panVerificationStatus) {
		boolean status = false;
		if(StringUtils.isNotBlank(panVerificationStatus)) {
			String panResponse = panVerificationStatus.toUpperCase();
			if(panResponse.contains(AuthenticationServiceConstants.PAN_VERIFIED_SUCCESSFUL_STATUS)) {
				status = true;
			}
		}
		return status;
	}

	private String prepareApplicantsPanName(List<String> names) {
		String name = names.stream()
			.filter( part -> StringUtils.isNotBlank(part))
			.collect(Collectors.joining(" "));
		return name;
	}
	
	private PanProfileDetailsResponse preparePanVerificationResponse(String panNumber, String name, 
			String panVerificationStatus, String nextTaskKey) {
		PanProfileDetailsResponse panProfileResponse = new PanProfileDetailsResponse();
		panProfileResponse.setName(name);
		panProfileResponse.setPanNumber(panNumber);
		panProfileResponse.setPanVerifiedFlag(panVerificationStatus);
		panProfileResponse.setNextTaskKey(nextTaskKey);
		return panProfileResponse;
	}
	
	@Override
	public UpdatePanProfileResponse updateProfilesDetails(UpdatePanProfileRequest profileUpdateRequest, HttpHeaders headers) {
		try {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"updateProfilesDetails started with request: " + profileUpdateRequest);
			ApplicantKeysRequest userKeys = profileUpdateRequest.getUserKeys();
			headers.set("userKey", userKeys.getApplicantKey().toString());
			UpdateUserProfileDetailsRequest nameDetails = prepareNameUpdateRequest(profileUpdateRequest.getName(), userKeys);
			updateName(nameDetails, headers);
			String pincode = profileUpdateRequest.getPincode();
			if(StringUtils.isNotBlank(pincode)){
				callApplicantPinCodeUpdationApi(headers, userKeys, pincode);
			}
			String panNumber = profileUpdateRequest.getPanNumber();
			if(StringUtils.isNotBlank(panNumber)){
				UpdateUserProfileDetailsRequest panUpdateRequest = preparePanUpdateRequest(panNumber, userKeys);
				Verification panVerificationDetails = null;
				String panVerifiedFlag = profileUpdateRequest.getPanVerifiedFlag();
				if(AuthenticationServiceConstants.YES.equalsIgnoreCase(panVerifiedFlag)) {
					panVerificationDetails = getPanVerificationDetails(panVerifiedFlag);
				}
				appOnBoardingUtils.updatePanDetails(panUpdateRequest, panVerificationDetails, headers);
			}
			UpdatePanProfileResponse updateProfileResponse = new UpdatePanProfileResponse();
			updateProfileResponse.setNextTaskKey(AuthenticationServiceConstants.PHOME);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
					"updateProfilesDetails ended with response: " + updateProfileResponse);
			return updateProfileResponse;
		}catch(BFLBusinessException | BFLHttpException ex) {
			throw ex;
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "updateProfilesDetails: Some Exception occured", ex);
			throw new BFLTechnicalException("AUTH_659", env.getProperty("AUTH_659"));
		}
	}
	
	private void callApplicantPinCodeUpdationApi(HttpHeaders headers, ApplicantKeysRequest userKeys, String pincode) {
		try {
			UpdateUserProfileDetailsRequest pinCodeUpdateRequest = preparePinCodeUpdateRequest(pincode, userKeys);
			updatePincode(pinCodeUpdateRequest, headers);
		}catch(Exception ex) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "updateProfilesDetails: pincode updation failed for applicant: "
					+ userKeys.getApplicantKey(), ex);
		}
	}
	
	private UpdateUserProfileDetailsRequest prepareNameUpdateRequest(String name, ApplicantKeysRequest userKeys) {
		UpdateUserProfileDetailsRequest updateName = new UpdateUserProfileDetailsRequest();
		NameDetails nameDetails = new NameDetails();
		nameDetails.setUserInput(name);
		PersonalDetails personalDetails = new PersonalDetails();
		personalDetails.setName(nameDetails);
		updateName.setPersonalDetails(personalDetails);
		updateName.setUserKeys(userKeys);
		return updateName;
	}
	
	private UpdateUserProfileDetailsRequest preparePanUpdateRequest(String panNumber, ApplicantKeysRequest userKeys) {
		UpdateUserProfileDetailsRequest updatePan = new UpdateUserProfileDetailsRequest();
		PanDetailsBean panDetails = new PanDetailsBean();
		panDetails.setUserInput(panNumber);
		BureauDetails bureauDetails = new BureauDetails();
		bureauDetails.setPan(panDetails);
		updatePan.setBureauDetails(bureauDetails);
		updatePan.setUserKeys(userKeys);
		return updatePan;
	}
	
	private Verification getPanVerificationDetails(String panVerificationStatus) {
		Verification panVerification = new Verification();
		panVerification.setIsVerified(true);
		panVerification.setVerifiedFor(AuthenticationServiceConstants.APP_ON_BOARDING_VERIFICATION);
		panVerification.setVerificationSource(AuthenticationServiceConstants.MOBAPP.toUpperCase());
		panVerification.setVerifyingProductCategoryKey(AuthenticationServiceConstants.PRODUCT_CATEGORY_CODE_PAN_VERIFICATION);
		return panVerification;
	}
	
	private UpdateUserProfileDetailsRequest preparePinCodeUpdateRequest(String pinCodeNumber, ApplicantKeysRequest userKeys) {
		UpdateUserProfileDetailsRequest updatePinCode = new UpdateUserProfileDetailsRequest();
		PinCodeDetails pinCodeDetails = new PinCodeDetails();
		pinCodeDetails.setUserInput(pinCodeNumber);
		PersonalDetails personalDetails = new PersonalDetails();
		personalDetails.setPinCode(pinCodeDetails);
		updatePinCode.setPersonalDetails(personalDetails);
		updatePinCode.setUserKeys(userKeys);
		return updatePinCode;
	}
	
}