package com.bajaj.bfsd.authentication.bean.annotations;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;

import org.apache.commons.lang3.StringUtils;

@Retention(RUNTIME)
@Target(FIELD)
@Constraint(validatedBy = BoundedDateFormatsValidation.BoundedDateFormatsValidationImpl.class)
public @interface BoundedDateFormatsValidation {

    String message() default "";
    String[] formats() default {};
    int lowerBoundYear() default 1900;
    int upperBoundYear() default 0;
    boolean optional() default false;
    Class<?>[] groups() default {};

    public abstract Class<? extends Payload>[] payload() default {};

    class BoundedDateFormatsValidationImpl implements ConstraintValidator<BoundedDateFormatsValidation, String>{

    	private String[] formats = null;
    	private boolean optional;
    	private int lowerBoundYear = 0;
    	private int upperBoundYear = 0;
    	
    	@Override
    	public void initialize(BoundedDateFormatsValidation constraintAnnotation) {
    		formats = constraintAnnotation.formats();
    		optional = constraintAnnotation.optional(); 
    		lowerBoundYear = constraintAnnotation.lowerBoundYear() >=0 ? constraintAnnotation.lowerBoundYear(): 1900;
    		upperBoundYear = BoundedDateFormatsValidationImpl.boundCheck(constraintAnnotation.upperBoundYear(),
    				constraintAnnotation.lowerBoundYear());
    	}

    	@Override
    	public boolean isValid(String date, ConstraintValidatorContext context) {
    		boolean status = false;
    		for(String format : formats) {
    			try {
    				DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format)
    						.withResolverStyle(ResolverStyle.STRICT);
    				if(optional && StringUtils.isBlank(date)) {
    	    			status = true;
    					break;
    				}
    				LocalDate parsedDate = LocalDate.parse(date, dtf);
    				status = checkDate(parsedDate, date, dtf);
    				if(status)
    					break;
    			}catch(Exception ex) {
    				status = false;
    			}
    		}
    		return status;
    	}
    	
    	private static int boundCheck(int upperBound, int lowerBound) {
    		return (upperBound != 0 && upperBound >= lowerBound) ?
   				 	upperBound : LocalDate.now().getYear();
    	}
    	
    	private boolean checkDate(LocalDate inputDate, String date, DateTimeFormatter dtf) {
    		boolean status = false;
    		LocalDate lowerLimitDate = LocalDate.of(lowerBoundYear-1, 12, 31);
    		LocalDate upperLimitDate = LocalDate.now().withYear(upperBoundYear);
    		if(inputDate.isAfter(lowerLimitDate) && inputDate.isBefore(upperLimitDate)){
    				status = true;
    		}
    		return status;
    	}
    	
    }
}
