package com.bajaj.bfsd.authentication.service;

import java.text.ParseException;

import org.springframework.http.HttpHeaders;

import com.bajaj.bfsd.authentication.bean.UserLoginAccountRequestV3;
import com.bajaj.bfsd.authentication.bean.UtmParameters;
import com.bajaj.bfsd.common.domain.ResponseBean;

public interface EstoreAuthenticationService {
	
	
	public ResponseBean loginWithOtpEstore(UserLoginAccountRequestV3 userLoginRequest, UtmParameters applicantUtmBean,HttpHeaders headers) throws ParseException;
	
	public int checkUserExistanceforEstore(String loginId, String dob);

}
