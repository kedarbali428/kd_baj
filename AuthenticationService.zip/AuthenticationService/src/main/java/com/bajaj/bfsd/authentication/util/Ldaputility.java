package com.bajaj.bfsd.authentication.util;

import java.util.Properties;

import javax.naming.AuthenticationException;
import javax.naming.CommunicationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.LdapConfiguration;
import com.bajaj.bfsd.authentication.LdapPropertiesConfigurer;
import com.bajaj.bfsd.authentication.bean.User;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;

@RefreshScope
@Component
public class Ldaputility extends BFLComponent{

	private static final String THIS_CLASS = Ldaputility.class.getSimpleName();
	
	@Autowired
	DirContext ldapContext;

	@Autowired
	LdapConfiguration ldapConfiguration;

	@Value("${ldap.domain}")
	public String searchBase;

	@Value("${ldap.search.attribute}")
	public String searchAttribute;
	
	@Value("${adEnabled}")
	private boolean isAdEnabled;
	
	@Autowired
	LdapPropertiesConfigurer ldapPropertiesConfigurer;
	
	@Autowired
	BFLLoggerUtil logger;

	public Boolean getADUsers(User user) {
		boolean isUserExist = false;
		NamingEnumeration results = null;
		String cn = null;
		String ou = null;
		try {
			String filter = computeFilter(user);
			String[] searchAttrArray = searchAttribute.split(",");
			SearchControls constraints = new SearchControls();
			constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
			constraints.setReturningAttributes(searchAttrArray);
			results = ldapContext.search(searchBase, filter, constraints);

			while (results != null && results.hasMore()) {
				SearchResult sr = (SearchResult) results.next();
				Attributes attributes1 = sr.getAttributes();
				Attribute attr1 = attributes1.get("CN");
				if(null != attr1){
					cn =  sr.toString().substring(sr.toString().indexOf("CN="), sr.toString().indexOf(','));
				}
				attr1 = attributes1.get("OU");
				ou = sr.toString().substring(sr.toString().indexOf("OU="), sr.toString().indexOf(':'));
				if(null != attr1){
					ou = sr.toString().substring(sr.toString().indexOf("OU="), sr.toString().indexOf(':'));
				}
				
				Properties properties = new Properties();
				properties.put(Context.INITIAL_CONTEXT_FACTORY, ldapPropertiesConfigurer.getLdapFactClass());
				properties.put(Context.PROVIDER_URL,ldapPropertiesConfigurer.getLdapUrl());
				properties.put(Context.SECURITY_AUTHENTICATION, ldapPropertiesConfigurer.getLdapSecAuthType());
				properties.put(Context.SECURITY_PRINCIPAL, cn +","+ou+","+searchBase);
				properties.put(Context.SECURITY_CREDENTIALS, user.getPassword());
				properties.put(Context.REFERRAL, "ignore");
				if(isAdEnabled)
					isUserExist = directoryContext(properties);
				else
					isUserExist = true;
			}
		} catch (CommunicationException connectionLostEx) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "CommunicationException - "+connectionLostEx);
			try {
				ldapContext = ldapConfiguration.ldapContextSource();
				return getADUsers(user);
			} catch (NamingException e) {
				logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "NamingException - "+e);
			}
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception - "+e);
		}finally{
			if(results!=null)
				try {
					results.close();
				} catch (NamingException e) {
					logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "NamingException - "+e);
				}
		}

		return isUserExist;
	}
	
	private boolean directoryContext(Properties properties){
		
		boolean isUserExist=false;
		DirContext context=null;
		try{
			context = new InitialDirContext(properties);
			if(null != context){//NOSONAR
				isUserExist = true;
			}	
		}catch(AuthenticationException e){
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "AuthenticationException - "+e);
			isUserExist = false;
		}catch(Exception e){
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception - "+e);
			isUserExist = false;
		}finally{
			if(context!=null)
				try {
					context.close();
				} catch (NamingException e) {
					logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "NamingException- "+e);
				}
		}
		
		return isUserExist;
	}

	private static String computeFilter(User user) {
		StringBuilder strBfr = new StringBuilder("(&");
		if (user.getFirstname() != null) {
			strBfr.append("(name=").append(user.getFirstname()).append("*)");
		}
		if (user.getLastname() != null) {
			strBfr.append("(sn=").append(user.getLastname()).append("*)");
		}
		if (user.getMobileNumber() != null) {
			strBfr.append("(telephoneNumber=").append(user.getMobileNumber()).append(")");
		}
		if (user.getEmailId() != null) {
			strBfr.append("(mail=").append(user.getEmailId()).append(")");
		}
		if (user.getDesignation() != null) {
			strBfr.append("(title=").append(user.getDesignation()).append("*)");
		}
		
		strBfr.append(")");

		return strBfr.toString();
	}
}
