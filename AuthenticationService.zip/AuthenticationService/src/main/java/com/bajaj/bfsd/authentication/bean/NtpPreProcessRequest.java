package com.bajaj.bfsd.authentication.bean;

import java.io.Serializable;

public class NtpPreProcessRequest implements Serializable {

	private static final long serialVersionUID = 1218816745573100143L;

	private Long applicantKey;
	private String panNumber;
	private String pinCode;
	private Integer appStatus;
	private String appJourneyStamp;
		  
	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public Integer getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(Integer appStatus) {
		this.appStatus = appStatus;
	}

	public String getAppJourneyStamp() {
		return appJourneyStamp;
	}

	public void setAppJourneyStamp(String appJourneyStamp) {
		this.appJourneyStamp = appJourneyStamp;
	}
	
	

}
