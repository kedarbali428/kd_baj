package com.bajaj.bfsd.authentication.controller;

import java.util.Date;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.authentication.authorize.AuthorizationUtil;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginRequest;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingLoginResponse;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingStatusRequest;
import com.bajaj.bfsd.authentication.bean.AppOnBoardingStatusResponse;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.PanProfileDetailsResponse;
import com.bajaj.bfsd.authentication.bean.UpdatePanProfileRequest;
import com.bajaj.bfsd.authentication.bean.UpdatePanProfileResponse;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UpdateUserProfileDetailsResponse;
import com.bajaj.bfsd.authentication.bean.UserProfileDetailsRequest;
import com.bajaj.bfsd.authentication.bean.UserProfileDetailsResponse;
import com.bajaj.bfsd.authentication.service.AppOnBoardingService;
import com.bajaj.bfsd.authentication.util.AuthenticationServiceConstants;
import com.bajaj.bfsd.authentication.util.DataFormatter;
import com.bajaj.bfsd.authentication.util.DataValidator;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLHttpException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RefreshScope
public class AppOnBoardingController extends BFLController{

	private static final String THIS_CLASS = AppOnBoardingController.class.getCanonicalName();

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private AppOnBoardingService appOnBoardingService;

	@Autowired
	private DataValidator dataValidator;
	
	@Autowired 
	private DataFormatter dataFormatter;
	
	@Autowired
	private AuthorizationUtil authorizationUtil;

	@ApiOperation(value = "AppOnBoarding get user status based on source", notes = "AppOnBoarding get user status based on mobile, dob and source", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header" ),
			@ApiImplicitParam(name = "app_source", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_source", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_medium", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_campaign", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_term", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_content", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "platform", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "user_agent", required = false, dataType = "string", paramType = "header")
	})
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ResponseBean.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = ResponseBean.class) })
	@RequestMapping(value = "${api.authentication.appOnBoarding.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> appOnBoardingUserStatus(@Valid @RequestBody AppOnBoardingStatusRequest appOnBoardingRequest,
			BindingResult bindingResult, @RequestHeader HttpHeaders headers,
			@RequestHeader(name = "user_agent", required = false) @Length(max = 4000) String userAgent){
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "appOnBoarding User Status started for request Body: "+ appOnBoardingRequest);
		if(bindingResult.hasErrors()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "appOnBoardingUserStatus request body validation failed");
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		String formatedDate = null;
		if (StringUtils.isNotBlank(appOnBoardingRequest.getDateOfBirth())) {
			Date validatedDate = dataValidator.validateDateFormats(appOnBoardingRequest.getDateOfBirth(),
					AuthenticationServiceConstants.APPONBOARDING_STATUS_VALID_DATEFORMATS, HttpStatus.BAD_REQUEST);
			 formatedDate = dataFormatter.getFormattedDate(validatedDate, AuthenticationServiceConstants.DOB_DD_MM_YYYY_HYPHENFORMAT);
		}
		AppOnBoardingStatusResponse userStatusResponse = appOnBoardingService.checkUsersSource(appOnBoardingRequest.getMobileNumber(), 
				formatedDate, appOnBoardingRequest.getSource(), headers);
		ResponseBean responseBean = new ResponseBean(userStatusResponse);
		responseBean.setStatus(StatusCode.SUCCESS);
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "appOnBoarding User Status ended");
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	@ApiOperation(value = "AppOnBoarding login with mobileNumber, dateOfBirth and otp", notes = "AppOnBoarding mobile login with mobileNumber and dateOfBirth after otp validation", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), 
			@ApiImplicitParam(name = "app_source", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_source", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_medium", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_campaign", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_term", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_content", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "utm_journey", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "platform", required = false, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "user_agent", required = false, dataType = "string", paramType = "header")
	})
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ResponseBean.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = ResponseBean.class) })
	@RequestMapping(value = "${api.authentication.appOnBoarding.login.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> appOnBoardingLogin(@Valid @RequestBody AppOnBoardingLoginRequest otpValidationAndCustomerGenReq, 
			BindingResult bindingResult, @RequestHeader HttpHeaders headers,
			@RequestHeader(name = "user_agent", required = false) @Length(max = 4000) String userAgent){
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "appOnBoardingLogin started with request: "+otpValidationAndCustomerGenReq);
		if(bindingResult.hasErrors()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "appOnBoardingLogin request body validation failed");
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		AppOnBoardingLoginResponse validateOtpAndLogin = appOnBoardingService.validateOtpAndLogin(otpValidationAndCustomerGenReq,
				headers);
		ResponseBean responseBean = new ResponseBean(validateOtpAndLogin);
		responseBean.setStatus(StatusCode.SUCCESS);
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "appOnBoardingLogin ended with response: "+validateOtpAndLogin);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	@ApiOperation(value = "AppOnBoarding UserProfiles module with mobileNumber and dateOfBirth", notes = "AppOnBoarding UserProfiles module with mobileNumber and dateOfBirth", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ResponseBean.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = ResponseBean.class) })
	@RequestMapping(value = "${api.authentication.appOnBoarding.usersProfile.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> getProfileDetails(@Valid @RequestBody UserProfileDetailsRequest userProfileDetailsReq, BindingResult bindingResult, @RequestHeader HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getProfileDetails started with request: "+ userProfileDetailsReq);
		if(bindingResult.hasErrors()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getProfileDetails request body validation failed");
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		authorizationUtil.authorizeApplicant(headers.getFirst("authtoken"), userProfileDetailsReq.getUserKeys().getApplicantKey());
		UserProfileDetailsResponse userProfilesDetailsResponse = appOnBoardingService.getUserProfilesDetailsData(userProfileDetailsReq, headers);
		ResponseBean responseBean = new ResponseBean(userProfilesDetailsResponse);
		responseBean.setStatus(StatusCode.SUCCESS);
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getProfileDetails ended with response: "+ responseBean);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	@ApiOperation(value = "AppOnBoarding UserProfiles Update module with mobileNumber, dateOfBirth and flags", notes = "AppOnBoarding UserProfiles Update module with mobileNumber, dateOfBirth and flags", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ResponseBean.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = ResponseBean.class) })
	@RequestMapping(value = "${api.authentication.appOnBoarding.usersProfile.PUT.uri}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> updateProfileDetails(@Valid @RequestBody UpdateUserProfileDetailsRequest userProfileDetailsReq, BindingResult bindingResult, @RequestHeader HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "updateProfileDetails started with request: "+ userProfileDetailsReq);
		if(bindingResult.hasErrors()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "updateProfileDetails request body validation failed");
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		authorizationUtil.authorizeApplicant(headers.getFirst("authtoken"), userProfileDetailsReq.getUserKeys().getApplicantKey());
		UpdateUserProfileDetailsResponse updatedApplicantDetails = appOnBoardingService.updateApplicantDetails(userProfileDetailsReq, headers);
		ResponseBean responseBean = new ResponseBean(updatedApplicantDetails);
		responseBean.setStatus(StatusCode.SUCCESS);
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "updateProfileDetails ended with response: "+ responseBean);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	@ApiOperation(value = "AppOnBoarding UserProfiles module for pan number verification", notes = "AppOnBoarding UserProfiles module for pan number verification", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ResponseBean.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = ResponseBean.class) 
	})
	@RequestMapping(value = "${api.authentication.appOnBoarding.userspanprofile.POST.uri}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> verifyProfilePanDetails(@Valid @RequestBody PanProfileDetailsRequest panProfileRequest, BindingResult bindingResult,
			@RequestHeader HttpHeaders headers){
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "verifyProfilePanDetails started");
		if(bindingResult.hasErrors()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "verifyProfilePanDetails request body validation failed");
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		authorizationUtil.authorizeApplicant(headers.getFirst("authtoken"), panProfileRequest.getUserKeys().getApplicantKey());
		PanProfileDetailsResponse verifiedProfilesPanDetail = appOnBoardingService.verifyApplicantPanDetails(panProfileRequest, headers);
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "verifyProfilePanDetails ended");
		ResponseBean responseBean = new ResponseBean(verifiedProfilesPanDetail);
		responseBean.setStatus(StatusCode.SUCCESS);
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}
	
	@ApiOperation(value = "AppOnBoarding UserProfiles module for pan number, pincode update", notes = "AppOnBoarding UserProfiles module for pan number, pincode update", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "guardtoken", required = true, dataType = "string", paramType = "header"),
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), 
			@ApiImplicitParam(name = "cmptcorrid", required = false, dataType = "string", paramType = "header")
	})
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = ResponseBean.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ResponseBean.class),
			@ApiResponse(code = 401, message = "Unauthorized", response = ResponseBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = ResponseBean.class) })
	@RequestMapping(value = "${api.authentication.appOnBoarding.userspanprofile.PUT.uri}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ResponseBean> updateProfilePanDetails(@Valid @RequestBody UpdatePanProfileRequest updatePanProfileRequest, BindingResult bindingResult,
			@RequestHeader HttpHeaders headers){
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "updateProfilePanDetails started");
		if(bindingResult.hasErrors()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "updateProfilePanDetails request body validation failed");
			throw new BFLHttpException(HttpStatus.BAD_REQUEST, bindingResult.getFieldErrors());
		}
		authorizationUtil.authorizeApplicant(headers.getFirst("authtoken"), updatePanProfileRequest.getUserKeys().getApplicantKey());
		UpdatePanProfileResponse updateProfilesPanDetails = appOnBoardingService.updateProfilesDetails(updatePanProfileRequest, headers);
		ResponseBean responseBean = new ResponseBean(updateProfilesPanDetails);
		responseBean.setStatus(StatusCode.SUCCESS);
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "updateProfilePanDetails ended");
		return new ResponseEntity<>(responseBean, HttpStatus.OK);
	}

}