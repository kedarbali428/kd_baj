package com.bajaj.bfsd.authentication.model;

public class SocialLoginParamsRequest {
	String platform;

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	
	
}
