package com.bajaj.bfsd.authentication.dao;

import java.sql.Timestamp;

import com.bajaj.bfsd.authentication.model.ApplicantUtm;
import com.bajaj.bfsd.authentication.model.Login;

public interface AuthenticationServiceDao {
	public void updateLoginActivity(Login login);
	public void updateLoginFailed(Login login);
	public void updateLogoutActivity(Login login);
	public int checkLoginIdExistance(String loginId, String dob, Integer loginType,String rType);
	public int validateUser(String mobileNumber, String dateOfBirth, Integer loginType);
	public Timestamp getUserProfile(String loginId);
	public boolean saveApplicantUtm(ApplicantUtm ApplicantUtmObj);

	public int getApplicantRecord(long applicantId);
	
	public long getApplicantId(long userId);
}
