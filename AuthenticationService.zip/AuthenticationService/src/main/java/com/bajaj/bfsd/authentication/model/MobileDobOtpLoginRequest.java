package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

public class MobileDobOtpLoginRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String loginId;
	private String otp;
	private String dateOfBirth;
	private String rType;
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getrType() {
		return rType;
	}
	public void setrType(String rType) {
		this.rType = rType;
	}
	
	
	
	

}
