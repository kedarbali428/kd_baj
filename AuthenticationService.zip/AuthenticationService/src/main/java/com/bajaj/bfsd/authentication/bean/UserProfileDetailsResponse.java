package com.bajaj.bfsd.authentication.bean;

public class UserProfileDetailsResponse{

	private boolean isSkipAllowed;
	private String currentTask;
	private BureauDetailsBean bureauDetails;
	private PersonalDetailsBean personalDetails;

	public String getCurrentTask() {
		return currentTask;
	}
	
	public void setCurrentTask(String currentTask) {
		this.currentTask = currentTask;
	}
	
	public BureauDetailsBean getBureauDetails() {
		return bureauDetails;
	}
	
	public void setBureauDetails(BureauDetailsBean bureauDetails) {
		this.bureauDetails = bureauDetails;
	}
	
	public PersonalDetailsBean getPersonalDetails() {
		return personalDetails;
	}
	
	public void setPersonalDetails(PersonalDetailsBean personalDetails) {
		this.personalDetails = personalDetails;
	}
	
	public boolean isSkipAllowed() {
		return isSkipAllowed;
	}
	
	public void setSkipAllowed(boolean isSkipAllowed) {
		this.isSkipAllowed = isSkipAllowed;
	}

	@Override
	public String toString() {
		return "UserProfileDetailsResponse [isSkipAllowed=" + isSkipAllowed + ", currentTask=" + currentTask
				+ ", bureauDetails=" + bureauDetails + ", personalDetails=" + personalDetails + "]";
	}
}
