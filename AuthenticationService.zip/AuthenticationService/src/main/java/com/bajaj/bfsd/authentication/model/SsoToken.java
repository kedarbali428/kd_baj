/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;

/**
 * This class is Base Response class for Openam services for authentication.
 * 
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602          07/11/2016      Initial Version
 *
 */
public class SsoToken implements Serializable{

    /**
     * Constant for serialVersionUID.
     */
    private static final long serialVersionUID = -4750477359972838224L;

    /**
     * Variable to hold value for token id.
     */
    private String tokenId;
    
    /**
     * Variable to hold value for success url.
     */
    private String successUrl;
    
    /**
     * Variable to hold value for auth type.
     */
    private String authType; 
    
    /**
     * Getter method for token id.
     *
     * @return token id
     */
    public String getTokenId() {
        return tokenId;
    }
    
    /**
     * Sets the value of token id.
     *
     * @param token the new token id
     */
    public void setTokenId(String token) {
        this.tokenId = token;
    }

    /**
     * Getter method for success url.
     *
     * @return success url
     */
    public String getSuccessUrl() {
        return successUrl;
    }

    /**
     * Sets the value of success url.
     *
     * @param successUrl the new success url
     */
    public void setSuccessUrl(String successUrl) {
        this.successUrl = successUrl;
    }

    /**
     * Getter method for auth type.
     *
     * @return auth type
     */
    public String getAuthType() {
        return authType;
    }

    /**
     * Sets the value of auth type.
     *
     * @param authType the new auth type
     */
    public void setAuthType(String authType) {
        this.authType = authType;
    }

   
}
