package com.bajaj.bfsd.authentication.bean;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class FederatedUserRegisterRequest {

	@NotBlank(message = "clientId cannot be null or blank")
	private String clientId;
	
	@NotBlank(message = "authorizationCode cannot be null or blank")
	private String authorizationCode;
	
	@NotNull(message = "preRegisterRequest cannot be null")
	private NtpPreRegisterRequest preRegisterRequest;
	
	public String getClientId() {
		return clientId;
	}
	
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	public String getAuthorizationCode() {
		return authorizationCode;
	}
	
	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}
	
	public NtpPreRegisterRequest getPreRegisterRequest() {
		return preRegisterRequest;
	}
	
	public void setPreRegisterRequest(NtpPreRegisterRequest preRegisterRequest) {
		this.preRegisterRequest = preRegisterRequest;
	}
	
	@Override
	public String toString() {
		return "FederatedUserRegister [clientId=" + clientId + ", authorizationCode=" + authorizationCode
				+ ", preRegisterRequest=" + preRegisterRequest + "]";
	}
	
}
