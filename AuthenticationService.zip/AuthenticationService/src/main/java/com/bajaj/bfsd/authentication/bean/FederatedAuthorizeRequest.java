package com.bajaj.bfsd.authentication.bean;

import javax.validation.constraints.NotNull;

public class FederatedAuthorizeRequest {

	@NotNull(message = "authorizationCode can not be null or empty")
	private String authorizationCode;
	
	@NotNull(message = "clientId can not be null or empty")
	private String clientId;

	public String getAuthorizationCode() {
		return authorizationCode;
	}

	public void setAuthorizationCode(String authrizationCode) {
		this.authorizationCode = authrizationCode;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	@Override
	public String toString() {
		return "FederatedAuthorizeRequest [authorizationCode=" + authorizationCode + ", clientId=" + clientId + "]";
	}

}
