package com.bajaj.bfsd.authentication.util;

public class AuthenticationServiceConstants {
	
	public static final String JOURNEY ="journey";
	public static final String CUSTOMER_PORTAL = "customerportal";
	public static final String MOBILEAPP = "mobileapp";
	public static final String MOBAPP = "mobapp";
	public static final String ECOMM = "ecomm";
	public static final String WEBSITE	= "website";
	public static final String WHATSAPP = "whatsapp";
	public static final String EMPLOYEE_PORTAL = "employeeportal";
	public static final String B2B_PARTNER = "b2bpartner";
	public static final String VENDOR = "vendor";
	public static final String SYSTEM = "system";
	public static final String SYSTEM_PARTNER = "systempartner";
  	public static final String PRINCIPAL = "principal";
	public static final String MPIN_OTP_LOGIN="mpinotplogin";
	
	public static final String FACEBOOK = "facebook";
	public static final String LINKEDIN = "linkedin";
	
	public static final String LOGINACCTYPE_SOCIAL_STR = "social";
	public static final String LOGINACCTYPE_AADHAR_STR = "aadhar";
	public static final String LOGINACCTYPE_MOBILEDOB_STR = "mobile";
	public static final String LOGINACCTYPE_MANUAL_STR = "manual";
	
	public static final short USERTYPE_CUSTOMER = 1;
	public static final short USERTYPE_EMPLOYEE = 2;
	public static final short USERTYPE_VENDOR_PARTNER = 3;
	public static final short USERTYPE_B2B_PARTNER = 4;
	public static final short USERTYPE_SYSTEM = 0;
	public static final short USERTYPE_SYSTEM_PARTNER=5;
  	public static final short USERTYPE_PRINCIPAL=6;
	public static final short USERTYPE_PSEUDO_CUSTOMER = 10;
	public static final short USERTYPE_PSEUDO_VERIFIED_CUSTOMER = 11;
	
	public static final short LOGINACCTYPE_SOCIAL_FB = 1;
	public static final short LOGINACCTYPE_SOCIAL_LI = 2;
	public static final short LOGINACCTYPE_SOCIAL_GL = 3;
	public static final short LOGINACCTYPE_SOCIAL_TW = 4;
	public static final short LOGINACCTYPE_MANUAL = 5;
	public static final short LOGINACCTYPE_MOBILEDOB = 6;
	public static final short LOGINACCTYPE_AADHAR = 7;
	public static final short LOGINACCTYPE_MOBILE_DOB_OTP_MPIN = 8;
	public static final short LOGINACCTYPE_FORGOT_PASSWORD = 9;
	
	public static final short ISACTIVE = 1;
	public static final String AUTH_627 = "AUTH_627";
	public static final String AUTH_020 = "AUTH_020";
	public static final String AUTH_019 = "AUTH-019";
	public static final String AUTH_018 = "AUTH-018";
	public static final String AUTH_630 = "AUTH_630";
	public static final String AUTH_636 = "AUTH_636";
	public static final String AUTH_637 = "AUTH_637";
	public static final String AUTH_638 = "AUTH_638";
	public static final String AUTH_639 = "AUTH_639";
	public static final String AUTH_640 = "AUTH_640";
	public static final String AUTH_641 ="AUTH_641";
	public static final String AUTH_642 ="AUTH_642";
	public static final String AUTH_643 ="AUTH_643";
	public static final String AUTH_644 ="AUTH_644";
	public static final String AUTH_645 ="AUTH_645";
	public static final String AUTH_646 ="AUTH_646";
	public static final String AUTH_647 ="AUTH_647";
	public static final String AUTH_648 ="AUTH_648";
	public static final String AUTH_708 ="AUTH-708";
	public static final String AUTH_709 ="AUTH-709";
	public static final String AUTH_710 ="AUTH-710";
	public static final String AUTH_711 ="AUTH-711";
	public static final String AUTH_712 ="AUTH-712";
	public static final String PLATFORM_DESKTOP = "desk";
	public static final String HEADER_PLATFORM = "platform";
	public static final String TRANSACTIONID="transactionId";
	public static final String HASH_CODE="hashCode";
	
	
	public static final String ID_PASS_VALIDATION_FAIL="Either login id or password is not acceptable";
	public static final String CHECK_LOGINID_EXISTANCE_START="Check login Id existance start";
	public static final String CHECK_LOGINID_EXISTANCE_END="Check login Id existance END";
	public static final String USER_NOT_REGISTERED="User is not registered";
	public static final String MULTIPLE_USER="More than one user exist with same login Id";
	public static final String SINGLE_USER="Successfully found the registered user";
	public static final String LOGIN_START="Started login User";
	public static final String LOGIN_END="User Login Ends";
	public static final String USER_VALIDATED="User validated successfully";
	public static final String USER_LOGIN_START="User login starts after validation";
	public static final String USER_LOGIN_END="User login ends after validation";
	public static final String DATE_VALIDATION_FAILURE="Date is empty or invalid";
	public static final String NOBILE_DOB_OTP_START="Started Mobile dob otp";
	public static final String NOBILE_DOB_OTP_AFTER_CALL=" After mobile dob otp service call";
	public static final String NOBILE_DOB_OTP_END="End Mobile dob otp";
	public static final String DOB_YYYY_MM_DD_FORMAT="yyyy-MM-dd";
	
	public static final String COMMA=",";
	public static final String SEMI_COLON=";";
	
	public static final String FEDERATED_TOKEN_LOGIN_ISSUER = "/v1/federated/login";
	public static final String FEDERATED_TOKEN_AUTHORIZE_ISSUER = "/v1/federated/authorize";
	
	public static final String LAUNCH_EVENT="launch";
	
	public static final String AUTH_TOKEN = "authtoken";
	public static final String REFRESH_TOKEN = "refreshtoken";
	
	public static final String ETB = "ETB";
	public static final String NTB = "NTB";
	public static final String EXISTING_CUSTOMER = "1";
	
	public static final String YES = "YES";
	public static final String NO = "NO";
	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";

	public static final String DOB_DD_MM_YYYY_HYPHENFORMAT = "dd-MM-yyyy";
	public static final String DOB_DD_MM_YYYY_ARABICFORMAT = "dd/MM/yyyy";
	
	public static final String DOB_DD_MM_UUUU_ARABICFORMAT = "dd/MM/uuuu";
	public static final String DOB_DD_MM_UUUU_HYPHENFORMAT = "dd-MM-uuuu";
	public static final String[] APPONBOARDING_STATUS_VALID_DATEFORMATS = {
			DOB_DD_MM_UUUU_ARABICFORMAT, DOB_DD_MM_UUUU_HYPHENFORMAT
			};
	public static final String[] VALIDSOURCES = {
			CUSTOMER_PORTAL, MOBILEAPP, MOBAPP, ECOMM, WEBSITE, WHATSAPP
			};
	
	public static final String APPLICANTETP = "APPLICANTETP";
	public static final String BUREAU = "BUREAU";
	public static final String PROSPECT = "PROSPECT";
	public static final String OTPGENERATE = "OTPGENERATE";
	public static final String MULTIPLE = "MULTIPLE";
	public static final String CAMPAIGN = "campaign";
	public static final String PHOME = "PHOME";
	public static final String BUREAU_DETAILS = "bureauDetails";
	public static final String PERSONAL_DETAILS = "personalDetails";
	public static final String HOME = "home";
	public static final String OTP_VALIDATION = "otpValidation";
	public static final String ADDRESSTYPE_OTHERS_KEY = "52";
	public static final String PAN_VERIFIED_STATUS_TRUE = "1";
	public static final String UTMJOURNEY_HEADERKEY = "utm_journey";
	public static final String BASIC_DETAILS = "basicDetails";
	public static final String PAN_VERIFIED_SUCCESSFUL_STATUS = "EXISTING AND VALID";
	public static final String ADDRESS_TYPE_OTHERS = "OTHERS";
	public static final String APP_ON_BOARDING_VERIFICATION = "APPONBOARDING";
	public static final long PRODUCT_CATEGORY_CODE_PAN_VERIFICATION = 5L;

	public static final String USER_ID = "userId";
	public static final String SOURCE = "source";
	public static final String OTHER = "other";
	public static final String EXPIRED_STATUS = "EXPIRED";
	public static final String INVALID_STATUS = "INVALID";
	public static final String EMPLOYEE = "employee";
	public static final String VENDORPARTNER = "venderpartner";

	private AuthenticationServiceConstants(){
		
	}
}
