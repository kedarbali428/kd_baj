package com.bajaj.bfsd.authentication.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the USER_LOGIN_ACTIVITIES database table.
 * 
 */
@Entity
@Table(name="LOGIN_FAILED_LOG")
//@NamedQuery(name="UserFailedLog.findAll", query="SELECT u FROM UserFailedLog u")
public class UserFailedLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long loginfaillogkey; 
	

	private String loginid;
	private String loginpwd;
	private Timestamp attemptdt;
	
	private long reasoncode;
	private long srcwebapp;
	

	private String browser;

	private String deviceid;

	private String ipaddress;

	private BigDecimal latitude;

	private BigDecimal longitude;

	public long getLoginfaillogkey() {
		return loginfaillogkey;
	}

	public void setLoginfaillogkey(long loginfaillogkey) {
		this.loginfaillogkey = loginfaillogkey;
	}

	public String getLoginid() {
		return loginid;
	}

	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}

	public String getLoginpwd() {
		return loginpwd;
	}

	public void setLoginpwd(String loginpwd) {
		this.loginpwd = loginpwd;
	}

	public Timestamp getAttemptdt() {
		return attemptdt;
	}

	public void setAttemptdt(Timestamp attemptdt) {
		this.attemptdt = attemptdt;
	}

	public long getReasoncode() {
		return reasoncode;
	}

	public void setReasoncode(long reasoncode) {
		this.reasoncode = reasoncode;
	}

	public long getSrcwebapp() {
		return srcwebapp;
	}

	public void setSrcwebapp(long srcwebapp) {
		this.srcwebapp = srcwebapp;
	}

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getDeviceid() {
		return deviceid;
	}

	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	public String getIpaddress() {
		return ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public BigDecimal getLatitude() {
		return latitude;
	}

	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	public BigDecimal getLongitude() {
		return longitude;
	}

	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	


}