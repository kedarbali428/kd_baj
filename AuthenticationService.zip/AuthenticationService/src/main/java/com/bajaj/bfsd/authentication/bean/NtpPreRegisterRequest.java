package com.bajaj.bfsd.authentication.bean;

import javax.validation.constraints.NotNull;

public class NtpPreRegisterRequest  {
	
	private String firstName;

	private String middleName;

	private String lastName;

	@NotNull(message = "Mobile Number is mandatory")
	private String mobileNumber;

	@NotNull(message = "Date of birth is mandatory")
	private String dateOfBirth;

	private String emailId;

	private String source;
	private String customerReferenceID;
	private String customerType;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getCustomerReferenceID() {
		return customerReferenceID;
	}

	public void setCustomerReferenceID(String customerReferenceID) {
		this.customerReferenceID = customerReferenceID;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}


	@Override
	public String toString() {
		return "NtpPreRegisterRequest [firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName + ", mobileNumber=" + mobileNumber + ", dateOfBirth=" + dateOfBirth
				+ ", emailId=" + emailId + ", source=" + source + ", customerReferenceID=" + customerReferenceID + ", customerType=" + customerType + "]";
	}

}
