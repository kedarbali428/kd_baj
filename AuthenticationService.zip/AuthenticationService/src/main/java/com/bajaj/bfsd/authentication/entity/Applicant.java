package com.bajaj.bfsd.authentication.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the APPLICANTS database table.
 * 
 */
@Entity
@Table(name="APPLICANTS")
//@NamedQuery(name="Applicant.findAll", query="SELECT a FROM Applicant a")
public class Applicant implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long applicantkey;

	private String apltaadhaarcardnum;

	private String apltcommprefchannel;

	private String apltcorecusid;

	private String apltcustcif;

	@Temporal(TemporalType.DATE)
	private Date apltdateofbirth;

	private String apltempid;

	private String apltfirstname;

	private BigDecimal apltgrossmthincome;

	private BigDecimal apltheight;

	@Temporal(TemporalType.DATE)
	private Date apltinactivedt;

	private BigDecimal apltisactive;

	private BigDecimal apltisempflag;

	private String apltlastname;

	private String apltlstupdateby;

	private Timestamp apltlstupdatedt;

	private String apltmiddlename;

	private BigDecimal apltnetmthincome;

	private String apltpan;

	@Temporal(TemporalType.DATE)
	private Date apltpassportexpdt;

	private String apltpassportnum;

	private String apltprospectid;

	private String apltstatus;

	private Timestamp apltstatuschgdate;

	private BigDecimal aplttotalobligation;

	private String apltucic;

	private BigDecimal apltweight;

	private BigDecimal caste;

	private String casteoth;

	private BigDecimal custcategorycdkey;

	private BigDecimal custsubcategory;

	private BigDecimal genderkey;

	private BigDecimal langkey;

	private BigDecimal maritalstatuskey;

	private BigDecimal nationalitykey;

	private String placeofbirth;

	private BigDecimal religion;

	private String religionoth;

	private BigDecimal salutationkey;

	private BigDecimal segkey;

	private BigDecimal subsegmentkey;

	//bi-directional many-to-one association to ApplicationApplicant
	@OneToMany(mappedBy="applicant")
	private List<ApplicationApplicant> applicationApplicants;

	//bi-directional many-to-one association to ApplicantPhoneNumber
	@OneToMany(mappedBy="applicant")
	private List<ApplicantPhoneNumber> applicantPhoneNumbers;

	public Applicant() {
	}

	public long getApplicantkey() {
		return this.applicantkey;
	}

	public void setApplicantkey(long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public String getApltaadhaarcardnum() {
		return this.apltaadhaarcardnum;
	}

	public void setApltaadhaarcardnum(String apltaadhaarcardnum) {
		this.apltaadhaarcardnum = apltaadhaarcardnum;
	}

	public String getApltcommprefchannel() {
		return this.apltcommprefchannel;
	}

	public void setApltcommprefchannel(String apltcommprefchannel) {
		this.apltcommprefchannel = apltcommprefchannel;
	}

	public String getApltcorecusid() {
		return this.apltcorecusid;
	}

	public void setApltcorecusid(String apltcorecusid) {
		this.apltcorecusid = apltcorecusid;
	}

	public String getApltcustcif() {
		return this.apltcustcif;
	}

	public void setApltcustcif(String apltcustcif) {
		this.apltcustcif = apltcustcif;
	}

	public Date getApltdateofbirth() {
		return this.apltdateofbirth;
	}

	public void setApltdateofbirth(Date apltdateofbirth) {
		this.apltdateofbirth = apltdateofbirth;
	}

	public String getApltempid() {
		return this.apltempid;
	}

	public void setApltempid(String apltempid) {
		this.apltempid = apltempid;
	}

	public String getApltfirstname() {
		return this.apltfirstname;
	}

	public void setApltfirstname(String apltfirstname) {
		this.apltfirstname = apltfirstname;
	}

	public BigDecimal getApltgrossmthincome() {
		return this.apltgrossmthincome;
	}

	public void setApltgrossmthincome(BigDecimal apltgrossmthincome) {
		this.apltgrossmthincome = apltgrossmthincome;
	}

	public BigDecimal getApltheight() {
		return this.apltheight;
	}

	public void setApltheight(BigDecimal apltheight) {
		this.apltheight = apltheight;
	}

	public Date getApltinactivedt() {
		return this.apltinactivedt;
	}

	public void setApltinactivedt(Date apltinactivedt) {
		this.apltinactivedt = apltinactivedt;
	}

	public BigDecimal getApltisactive() {
		return this.apltisactive;
	}

	public void setApltisactive(BigDecimal apltisactive) {
		this.apltisactive = apltisactive;
	}

	public BigDecimal getApltisempflag() {
		return this.apltisempflag;
	}

	public void setApltisempflag(BigDecimal apltisempflag) {
		this.apltisempflag = apltisempflag;
	}

	public String getApltlastname() {
		return this.apltlastname;
	}

	public void setApltlastname(String apltlastname) {
		this.apltlastname = apltlastname;
	}

	public String getApltlstupdateby() {
		return this.apltlstupdateby;
	}

	public void setApltlstupdateby(String apltlstupdateby) {
		this.apltlstupdateby = apltlstupdateby;
	}

	public Timestamp getApltlstupdatedt() {
		return this.apltlstupdatedt;
	}

	public void setApltlstupdatedt(Timestamp apltlstupdatedt) {
		this.apltlstupdatedt = apltlstupdatedt;
	}

	public String getApltmiddlename() {
		return this.apltmiddlename;
	}

	public void setApltmiddlename(String apltmiddlename) {
		this.apltmiddlename = apltmiddlename;
	}

	public BigDecimal getApltnetmthincome() {
		return this.apltnetmthincome;
	}

	public void setApltnetmthincome(BigDecimal apltnetmthincome) {
		this.apltnetmthincome = apltnetmthincome;
	}

	public String getApltpan() {
		return this.apltpan;
	}

	public void setApltpan(String apltpan) {
		this.apltpan = apltpan;
	}

	public Date getApltpassportexpdt() {
		return this.apltpassportexpdt;
	}

	public void setApltpassportexpdt(Date apltpassportexpdt) {
		this.apltpassportexpdt = apltpassportexpdt;
	}

	public String getApltpassportnum() {
		return this.apltpassportnum;
	}

	public void setApltpassportnum(String apltpassportnum) {
		this.apltpassportnum = apltpassportnum;
	}

	public String getApltprospectid() {
		return this.apltprospectid;
	}

	public void setApltprospectid(String apltprospectid) {
		this.apltprospectid = apltprospectid;
	}

	public String getApltstatus() {
		return this.apltstatus;
	}

	public void setApltstatus(String apltstatus) {
		this.apltstatus = apltstatus;
	}

	public Timestamp getApltstatuschgdate() {
		return this.apltstatuschgdate;
	}

	public void setApltstatuschgdate(Timestamp apltstatuschgdate) {
		this.apltstatuschgdate = apltstatuschgdate;
	}

	public BigDecimal getAplttotalobligation() {
		return this.aplttotalobligation;
	}

	public void setAplttotalobligation(BigDecimal aplttotalobligation) {
		this.aplttotalobligation = aplttotalobligation;
	}

	public String getApltucic() {
		return this.apltucic;
	}

	public void setApltucic(String apltucic) {
		this.apltucic = apltucic;
	}

	public BigDecimal getApltweight() {
		return this.apltweight;
	}

	public void setApltweight(BigDecimal apltweight) {
		this.apltweight = apltweight;
	}

	public BigDecimal getCaste() {
		return this.caste;
	}

	public void setCaste(BigDecimal caste) {
		this.caste = caste;
	}

	public String getCasteoth() {
		return this.casteoth;
	}

	public void setCasteoth(String casteoth) {
		this.casteoth = casteoth;
	}

	public BigDecimal getCustcategorycdkey() {
		return this.custcategorycdkey;
	}

	public void setCustcategorycdkey(BigDecimal custcategorycdkey) {
		this.custcategorycdkey = custcategorycdkey;
	}

	public BigDecimal getCustsubcategory() {
		return this.custsubcategory;
	}

	public void setCustsubcategory(BigDecimal custsubcategory) {
		this.custsubcategory = custsubcategory;
	}

	public BigDecimal getGenderkey() {
		return this.genderkey;
	}

	public void setGenderkey(BigDecimal genderkey) {
		this.genderkey = genderkey;
	}

	public BigDecimal getLangkey() {
		return this.langkey;
	}

	public void setLangkey(BigDecimal langkey) {
		this.langkey = langkey;
	}

	public BigDecimal getMaritalstatuskey() {
		return this.maritalstatuskey;
	}

	public void setMaritalstatuskey(BigDecimal maritalstatuskey) {
		this.maritalstatuskey = maritalstatuskey;
	}

	public BigDecimal getNationalitykey() {
		return this.nationalitykey;
	}

	public void setNationalitykey(BigDecimal nationalitykey) {
		this.nationalitykey = nationalitykey;
	}

	public String getPlaceofbirth() {
		return this.placeofbirth;
	}

	public void setPlaceofbirth(String placeofbirth) {
		this.placeofbirth = placeofbirth;
	}

	public BigDecimal getReligion() {
		return this.religion;
	}

	public void setReligion(BigDecimal religion) {
		this.religion = religion;
	}

	public String getReligionoth() {
		return this.religionoth;
	}

	public void setReligionoth(String religionoth) {
		this.religionoth = religionoth;
	}

	public BigDecimal getSalutationkey() {
		return this.salutationkey;
	}

	public void setSalutationkey(BigDecimal salutationkey) {
		this.salutationkey = salutationkey;
	}

	public BigDecimal getSegkey() {
		return this.segkey;
	}

	public void setSegkey(BigDecimal segkey) {
		this.segkey = segkey;
	}

	public BigDecimal getSubsegmentkey() {
		return this.subsegmentkey;
	}

	public void setSubsegmentkey(BigDecimal subsegmentkey) {
		this.subsegmentkey = subsegmentkey;
	}

	public List<ApplicationApplicant> getApplicationApplicants() {
		return this.applicationApplicants;
	}

	public void setApplicationApplicants(List<ApplicationApplicant> applicationApplicants) {
		this.applicationApplicants = applicationApplicants;
	}

	public ApplicationApplicant addApplicationApplicant(ApplicationApplicant applicationApplicant) {
		getApplicationApplicants().add(applicationApplicant);
		applicationApplicant.setApplicant(this);

		return applicationApplicant;
	}

	public ApplicationApplicant removeApplicationApplicant(ApplicationApplicant applicationApplicant) {
		getApplicationApplicants().remove(applicationApplicant);
		applicationApplicant.setApplicant(null);

		return applicationApplicant;
	}

	public List<ApplicantPhoneNumber> getApplicantPhoneNumbers() {
		return this.applicantPhoneNumbers;
	}

	public void setApplicantPhoneNumbers(List<ApplicantPhoneNumber> applicantPhoneNumbers) {
		this.applicantPhoneNumbers = applicantPhoneNumbers;
	}

	public ApplicantPhoneNumber addApplicantPhoneNumber(ApplicantPhoneNumber applicantPhoneNumber) {
		getApplicantPhoneNumbers().add(applicantPhoneNumber);
		applicantPhoneNumber.setApplicant(this);

		return applicantPhoneNumber;
	}

	public ApplicantPhoneNumber removeApplicantPhoneNumber(ApplicantPhoneNumber applicantPhoneNumber) {
		getApplicantPhoneNumbers().remove(applicantPhoneNumber);
		applicantPhoneNumber.setApplicant(null);

		return applicantPhoneNumber;
	}

}