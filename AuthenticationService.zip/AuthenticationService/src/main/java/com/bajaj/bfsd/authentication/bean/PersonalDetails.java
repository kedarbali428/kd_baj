package com.bajaj.bfsd.authentication.bean;

public class PersonalDetails {
	
	private NameDetails name;
	private EmailDetails email;
	private PinCodeDetails pinCode;
	private OccupationDetails occupation;
	
	public NameDetails getName() {
		return name;
	}
	
	public void setName(NameDetails name) {
		this.name = name;
	}
	
	public EmailDetails getEmail() {
		return email;
	}
	
	public void setEmail(EmailDetails email) {
		this.email = email;
	}
	
	public PinCodeDetails getPinCode() {
		return pinCode;
	}
	
	public void setPinCode(PinCodeDetails pinCode) {
		this.pinCode = pinCode;
	}
	
	public OccupationDetails getOccupation() {
		return occupation;
	}
	
	public void setOccupation(OccupationDetails occupation) {
		this.occupation = occupation;
	}
	
}
