package com.bajaj.bfsd.authentication.bean;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;


public class FederatedLoginRequest  {

	@NotBlank(message = "clientId can not be null or empty")
	private String clientId;

	@NotBlank(message = "clientSecret can not be null or empty")
	private String clientSecret;

	@NotBlank(message = "authorizedClient can not be null or empty")
	private String authorizedClient;

	@NotBlank(message = "mobile can not be null or empty")
	@Pattern(regexp = "^[6-9]\\d{9}$", message = "Not Valid mobile number")
	private String mobile;

	@NotNull(message = "customer flag cannot be null")
	@Digits(fraction = 0, integer = 1, message = "customer flag can be 0|1")
	private Integer customerFlag;

	private Integer partnerCustomerId;
	
	private String authorizedEmployeeCode;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getAuthorizedClient() {
		return authorizedClient;
	}

	public void setAuthorizedClient(String authorizedClient) {
		this.authorizedClient = authorizedClient;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getCustomerFlag() {
		return customerFlag;
	}

	public void setCustomerFlag(Integer customerFlag) {
		this.customerFlag = customerFlag;
	}

	public Integer getPartnerCustomerId() {
		return partnerCustomerId;
	}

	public void setPartnerCustomerId(Integer partnerCustomerId) {
		this.partnerCustomerId = partnerCustomerId;
	}

	public String getAuthorizedEmployeeCode() {
		return authorizedEmployeeCode;
	}

	public void setAuthorizedEmployeeCode(String authorizedEmployeeCode) {
		this.authorizedEmployeeCode = authorizedEmployeeCode;
	}

	@Override
	public String toString() {
		return "FederatedLoginRequest [clientId=" + clientId + ", clientSecret=" + (null != clientSecret) + ", authorizedClient="
				+ authorizedClient + ", mobile=" + mobile + ", customerFlag=" + customerFlag + ", partnerCustomerId="
				+ partnerCustomerId + ", authorizedEmployeeCode=" + authorizedEmployeeCode + "]";
	}

}
