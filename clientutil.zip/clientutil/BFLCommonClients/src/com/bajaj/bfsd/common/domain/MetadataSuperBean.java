package com.bajaj.bfsd.common.domain;

import java.io.Serializable;

/**
 * Bean for handling no sql data
 * @author 595327
 *
 */
public class MetadataSuperBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String applicationId;
	private String applicantId;
	private String source;
	private boolean captureRawResponse;
	private boolean syncRequired;
	private String sourcetype; //BRE type

	
	public MetadataSuperBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MetadataSuperBean(String source) {
		this.source = source;
	}

	/**
	 * @return the applicationId
	 */
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * @return the applicantId
	 */
	public String getApplicantId() {
		return applicantId;
	}

	/**
	 * @param applicantId the applicantId to set
	 */
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return the captureRawResponse
	 */
	public boolean isCaptureRawResponse() {
		return captureRawResponse;
	}

	/**
	 * @param captureRawResponse the captureRawResponse to set
	 */
	public void setCaptureRawResponse(boolean captureRawResponse) {
		this.captureRawResponse = captureRawResponse;
	}

	public String getSourcetype() {
		return sourcetype;
	}

	public void setSourcetype(String sourcetype) {
		this.sourcetype = sourcetype;
	}

	public boolean isSyncRequired() {
		return syncRequired;
	}

	public void setSyncRequired(boolean syncRequired) {
		this.syncRequired = syncRequired;
	}
	
}
