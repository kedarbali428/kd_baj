package com.bajaj.bfsd.common.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

//@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value=Include.NON_EMPTY)
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class DynamoDbBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String appnId;

	private String applicantId;

	private String source;

	@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
	@JsonInclude(value=Include.NON_EMPTY)
	//@JsonIgnore
	private transient Object resPayload;
	
	private String resPayloadStr;

	private String reqTimeStamp;

	private String resTimeStamp;

	private String rawResUrl;
	
	private String sourcetype;
	
	private String reqPayload;

	public DynamoDbBean() {
		super();
	}

	public String getAppnId() {
		return appnId;
	}

	public void setAppnId(String appnId) {
		this.appnId = appnId;
	}

	public String getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Object getResPayload() {
		return resPayload;
	}

	public void setResPayload(Object resPayload) {
		this.resPayload = resPayload;
	}

	public String getReqTimeStamp() {
		return reqTimeStamp;
	}

	public void setReqTimeStamp(String reqTimeStamp) {
		this.reqTimeStamp = reqTimeStamp;
	}

	public String getResTimeStamp() {
		return resTimeStamp;
	}

	public void setResTimeStamp(String resTimeStamp) {
		this.resTimeStamp = resTimeStamp;
	}

	public String getRawResUrl() {
		return rawResUrl;
	}

	public void setRawResUrl(String rawResUrl) {
		this.rawResUrl = rawResUrl;
	}
	
	public String getResPayloadStr() {
		return resPayloadStr;
	}

	public void setResPayloadStr(String resPayloadStr) {
		this.resPayloadStr = resPayloadStr;
	}
	
	public String getSourcetype() {
		return sourcetype;
	}

	public void setSourcetype(String sourcetype) {
		this.sourcetype = sourcetype;
	}

	public String getReqPayload() {
		return reqPayload;
	}

	public void setReqPayload(String reqPayload) {
		this.reqPayload = reqPayload;
	}

	@Override
	public String toString() {
		String returnValue = "{\"appnId\":" + appnId + ", \"applicantId\":" + applicantId + ", \"source\":\"" + source
				+ "\", \"resPayload\":" + resPayload +", \"reqPayload\":" + reqPayload + ", \"reqTimeStamp\":\""+reqTimeStamp+"\",\"resTimeStamp\":\""
				+resTimeStamp+"\",\"rawResUrl\":\""+rawResUrl+"\",\"sourcetype\":\"" + sourcetype + "\"}";
		
		return returnValue.replaceAll("\"\"", "null");
	}


	
	

}
