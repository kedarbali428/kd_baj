package com.bajaj.bfsd.common.clients;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Future;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.domain.BFLCommonClientBean;
import com.bajaj.bfsd.common.domain.DynamoDbBean;
import com.bajaj.bfsd.common.domain.ErrorBean;
import com.bajaj.bfsd.common.domain.MetadataBean;
import com.bajaj.bfsd.common.domain.MetadataDetailsBean;
import com.bajaj.bfsd.common.domain.MetadataSuperBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.common.util.BFLCommonClientUtility;
import com.bajaj.bfsd.common.util.BFLCommonClientsUtil;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

/**
 * BFL common REST client for handling rest calls.
 * 
 * @author 595327
 *
 */
@RefreshScope
@Component
@Scope("prototype")
public class BFLCommonRestClientImpl {

	@Value("${api.nosql.audit.POST.url}")
	private String noSQLDataURL;

	@Value("${api.rawresponse.upload.url}")
	private String rawResponseUpload;
	
	/*@Value("${spring.application.name}")
	private String appName;*/
	
	@Autowired
	BFLLoggerUtilExt logger;

	private static final String Class_Name = BFLCommonRestClientImpl.class.getName(); // NOSONAR
	private static final String CORE_001 = "CORE-001"; // NOSONAR
	private static final String CORE_002 = "CORE-002"; // NOSONAR
	private static final String CORE_003 = "CORE-003"; // NOSONAR
	private static final String CORE_004 = "CORE-004"; // NOSONAR
	public static final String REQ_CORELATION_ID = "cmptcorrid";

	protected final Properties properties = BFLCommonClientUtility.getProperties("commonClient.properties");

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	CustomDefaultHeaders customHdrs;

	@Value("${proxy.address}")
	private String proxyAddress;

	@Value("${proxy.port}")
	private String port;
	
	@Autowired
	BFLCommonAsyncRestClient bflCommonAsyncRestClient;

	/**
	 * 
	 * @return RestTemplate
	 */
	private RestTemplate getTemplate(BFLCommonClientBean... bflCommonClientBean) {
		SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
		if (null != bflCommonClientBean && bflCommonClientBean.length > 0
				&& null != bflCommonClientBean[0].getClientProxyBean()) {
			// Enable Proxy setting
			Proxy proxy = new Proxy(Proxy.Type.HTTP,
					new InetSocketAddress(bflCommonClientBean[0].getClientProxyBean().getProxyAddress(),
							Integer.parseInt(bflCommonClientBean[0].getClientProxyBean().getPort())));
			clientHttpRequestFactory.setProxy(proxy);
			restTemplate.setRequestFactory(clientHttpRequestFactory);
		} else {
			restTemplate.setRequestFactory(clientHttpRequestFactory);
		}
		return restTemplate;
	}

	/**
	 * method for handling HTTP GET operations
	 * 
	 * @param uriForGet
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<ResponseBean>
	 */
	public ResponseEntity<ResponseBean> get(String uriForGet, Object reuqestObject, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCall(uriForGet, HttpMethod.GET, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);
	}

	/**
	 * method for handling HTTP DELETE operations
	 * 
	 * @param uriForDelete
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<ResponseBean>
	 */
	public ResponseEntity<ResponseBean> delete(String uriForDelete, Object reuqestObject, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCall(uriForDelete, HttpMethod.DELETE, reuqestObject, responseType, params, requestJson,
				headers, bflCommonClientBean);
	}

	/**
	 * method for handling HTTP POST operations
	 * 
	 * @param uriForCreate
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<ResponseBean>
	 */
	public ResponseEntity<ResponseBean> create(String uriForCreate, Object reuqestObject, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCall(uriForCreate, HttpMethod.POST, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);
	}
	
	public ResponseEntity<ResponseBean> postForEntity(String url,MultiValueMap<String, String> map, Class<?> responseType,
			Map<String, String> params, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return postEntity(url, map, responseType, params, headers, 
				bflCommonClientBean);
	}
	
	private ResponseEntity<ResponseBean> postEntity(String url, MultiValueMap<String, String> map,
			Class<?> responseType, Map<String, String> params, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		HttpHeaders appendedHeaders = headers;
		// check to append headers only for internal BFL calls; headers will not
		// be appended for external services' calls
		if (null == bflCommonClientBean || bflCommonClientBean.length == 0) {
			appendedHeaders = appendCustomeHeaderValues(headers, customHdrs);
		}

		Timestamp requestTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		List<ErrorBean> errorBeans = new ArrayList<>();
		ResponseBean bean = new ResponseBean();
		ResponseEntity<?> responseEntity;
		
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(map,
				appendedHeaders);

		RestTemplate restTemplateInstance = getTemplate(bflCommonClientBean);

		try {
			if (params != null) {
				responseEntity = restTemplateInstance.postForEntity(url, entity, responseType,params);
			} else {
				responseEntity = restTemplateInstance.postForEntity(url, entity, responseType);
			}
			if (null != responseEntity) {
				bean.setPayload(responseEntity.getBody());
				bean.setStatus(StatusCode.SUCCESS);
			}

			// invoke method to persist records to NoSQL DB
			if (null != bflCommonClientBean && bflCommonClientBean.length > 0 && null != responseEntity) {
				persitNoSQLEntries(requestTimeStamp, null, appendedHeaders, responseEntity, bflCommonClientBean);
			}

			return new ResponseEntity<>(bean, responseEntity != null ? responseEntity.getHeaders() : new HttpHeaders(),
					responseEntity != null ? responseEntity.getStatusCode() : HttpStatus.INTERNAL_SERVER_ERROR);

		} catch (HttpClientErrorException ce) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient postForEntity : HttpClientErrorException during call ", ce);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_001);
			errorBean.setErrorMessage(ce.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setPayload(ce.getResponseBodyAsString());
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, ce.getStatusCode());
		} catch (HttpStatusCodeException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient postForEntity : HttpStatusCodeException during  call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_002);
			errorBean.setErrorMessage(e.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setPayload(e.getResponseBodyAsString());
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, e.getStatusCode());
		} catch (RestClientException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient postForEntity : RestClientException during call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_003);
			errorBean.setErrorMessage(e.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient postForEntity : Exception during call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_004);
			errorBean.setErrorMessage(e.getMessage());
			errorBeans.add(errorBean);
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<ResponseBean> excuteRestCall(String url, HttpMethod httpMethod, Object reuqestObject,
			Class<?> responseType, Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		HttpHeaders appendedHeaders = headers;
		// check to append headers only for internal BFL calls; headers will not
		// be appended for external services' calls
		if (null == bflCommonClientBean || bflCommonClientBean.length == 0) {
			appendedHeaders = appendCustomeHeaderValues(headers, customHdrs);
		}

		Timestamp requestTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		List<ErrorBean> errorBeans = new ArrayList<>();
		ResponseBean bean = new ResponseBean();
		HttpEntity<Object> entity;
		ResponseEntity<?> responseEntity;
		if (null != reuqestObject) {
			entity = new HttpEntity<>(reuqestObject, appendedHeaders);
		} else {
			entity = new HttpEntity<>(requestJson, appendedHeaders);
		}

		RestTemplate restTemplateInstance = getTemplate(bflCommonClientBean);

		try {
			if (params != null) {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType);
			}
			HttpHeaders responseHeaders = new HttpHeaders();
			if (null != responseEntity) {
				bean.setPayload(responseEntity.getBody());
				bean.setStatus(StatusCode.SUCCESS);
				if (null != responseEntity.getHeaders()) {
					responseEntity.getHeaders().forEach((key,value)-> {
						if (!"Content-Length".equalsIgnoreCase(key)) {
							responseHeaders.put(key, value);
						}
					});
				}
			}

			// invoke method to persist records to NoSQL DB
			if (null != bflCommonClientBean && bflCommonClientBean.length > 0 && null != responseEntity) {
				persitNoSQLEntries(requestTimeStamp, requestJson, appendedHeaders, responseEntity, bflCommonClientBean);
			}

			return new ResponseEntity<>(bean, responseHeaders,
					responseEntity != null ? responseEntity.getStatusCode() : HttpStatus.INTERNAL_SERVER_ERROR);

		} catch (HttpClientErrorException ce) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCall : HttpClientErrorException during "
							+ httpMethod.name() + " call ",
					ce);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_001);
			errorBean.setErrorMessage(ce.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setPayload(ce.getResponseBodyAsString());
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, ce.getStatusCode());
		} catch (HttpStatusCodeException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCall : HttpStatusCodeException during "
							+ httpMethod.name() + " call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_002);
			errorBean.setErrorMessage(e.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setPayload(e.getResponseBodyAsString());
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, e.getStatusCode());
		} catch (RestClientException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCall : RestClientException during "
							+ httpMethod.name() + " call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_003);
			errorBean.setErrorMessage(e.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCall : Exception during " + httpMethod.name()
							+ " call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_004);
			errorBean.setErrorMessage(e.getMessage());
			errorBeans.add(errorBean);
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<ResponseBean> excuteRestCallTest(String url, HttpMethod httpMethod, Object reuqestObject,
			Class<?> responseType, Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		HttpHeaders appendedHeaders = headers;
		// check to append headers only for internal BFL calls; headers will not
		// be appended for external services' calls
		if (null == bflCommonClientBean || bflCommonClientBean.length == 0) {
			appendedHeaders = appendCustomeHeaderValues(headers, customHdrs);
		}
		Timestamp requestTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		List<ErrorBean> errorBeans = new ArrayList<>();
		ResponseBean bean = new ResponseBean();
		HttpEntity<Object> entity;
		ResponseEntity<?> responseEntity;
		if (null != reuqestObject) {
			entity = new HttpEntity<>(reuqestObject, appendedHeaders);
		} else {
			entity = new HttpEntity<>(requestJson, appendedHeaders);
		}

		RestTemplate restTemplateInstance = getTemplate();
		List l = null;
		try {
			l = ProxySelector.getDefault().select(new URI(url));
		} catch (URISyntaxException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCallTest : URISyntaxException during "
							+ httpMethod.name() + " call ",
					e);
		}
		if (l != null) {
			for (Iterator iter = l.iterator(); iter.hasNext();) {
				java.net.Proxy proxy = (java.net.Proxy) iter.next();

				InetSocketAddress addr = (InetSocketAddress) proxy.address();

				if (addr == null) {
					BFLLoggerUtil.info(null, Class_Name, BFLLoggerComponent.UTILITY, "No Proxy");
				} else {
					System.setProperty("http.proxyHost", addr.getHostName());
					System.setProperty("http.proxyPort", Integer.toString(addr.getPort()));
					SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
					Proxy clientProxy = new Proxy(Proxy.Type.HTTP,
							new InetSocketAddress(addr.getHostName(), addr.getPort()));
					clientHttpRequestFactory.setProxy(clientProxy);
					restTemplateInstance.setRequestFactory(clientHttpRequestFactory);
				}
			}
		}

		try {
			if (params != null) {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType);
			}
			if (null != responseEntity) {
				bean.setPayload(responseEntity.getBody());
				bean.setStatus(StatusCode.SUCCESS);
			}

			// invoke method to persist records to NoSQL DB
			if (null != bflCommonClientBean && bflCommonClientBean.length > 0 && null != responseEntity) {
				persitNoSQLEntries(requestTimeStamp, requestJson, headers, responseEntity, bflCommonClientBean);
			}

			return new ResponseEntity<>(bean, responseEntity != null ? responseEntity.getHeaders() : new HttpHeaders(),
					responseEntity != null ? responseEntity.getStatusCode() : HttpStatus.INTERNAL_SERVER_ERROR);

		} catch (HttpClientErrorException ce) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCallTest : HttpClientErrorException during "
							+ httpMethod.name() + " call ",
					ce);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_001);
			errorBean.setErrorMessage(ce.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setPayload(ce.getResponseBodyAsString());
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, ce.getStatusCode());
		} catch (HttpStatusCodeException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCallTest : HttpStatusCodeException during "
							+ httpMethod.name() + " call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_002);
			errorBean.setErrorMessage(e.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setPayload(e.getResponseBodyAsString());
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, e.getStatusCode());
		} catch (RestClientException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCallTest : RestClientException during "
							+ httpMethod.name() + " call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_003);
			errorBean.setErrorMessage(e.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCallTest : Exception during " + httpMethod.name()
							+ " call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_004);
			errorBean.setErrorMessage(e.getMessage());
			errorBeans.add(errorBean);
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * method for handling HTTP PUT operations
	 * 
	 * @param uriForUpdate
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<ResponseBean>
	 */
	public ResponseEntity<ResponseBean> update(String uriForUpdate, Object reuqestObject, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCall(uriForUpdate, HttpMethod.PUT, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);

	}

	/**
	 * Generic method for handling all HTTP operations
	 * 
	 * @param httpMethod
	 * @param uriForGet
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<ResponseBean>
	 */
	public ResponseEntity<ResponseBean> execute(HttpMethod httpMethod, String uriForGet, Object reuqestObject,
			Class<?> responseType, Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCall(uriForGet, httpMethod, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);

	}

	public ResponseEntity<?> invokeRestEndpointWithCustomHeders(HttpMethod httpMethod, String uri, Object reuqestObject, // NOSONAR
			Class<?> responseType, Map<String, String> params, String requestJson, HttpHeaders headers, // NOSONAR
			CustomDefaultHeaders customHeaders, BFLCommonClientBean... bflCommonClientBean) {// NOSONAR
		List<ErrorBean> errorBeans = new ArrayList<>();
		HttpHeaders appendedHeaders = headers;
		ResponseBean bean = new ResponseBean();
		// check to append headers only for internal BFL calls; headers will not
		// be appended for external services' calls
		if (null == bflCommonClientBean || bflCommonClientBean.length == 0) {
			appendedHeaders = appendCustomeHeaderValues(headers, customHdrs);
		}
		Timestamp requestTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		ResponseEntity<?> responseEntity;
		HttpEntity<Object> entity;
		if (null != reuqestObject) {
			entity = new HttpEntity<>(reuqestObject, appendedHeaders);
		} else {
			entity = new HttpEntity<>(requestJson, appendedHeaders);
		}
		RestTemplate restTemplateInstance = getTemplate(bflCommonClientBean);
		try {
			if (params != null) {
				responseEntity = restTemplateInstance.exchange(uri, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplateInstance.exchange(uri, httpMethod, entity, responseType);
			}

			// invoke method to persist records to NoSQL DB check for cross
			// cutting actions listed in bflCommonClient bean
			if (null != bflCommonClientBean && bflCommonClientBean.length > 0 && null != responseEntity) {
				persitNoSQLEntries(requestTimeStamp, requestJson, appendedHeaders, responseEntity, bflCommonClientBean);
			}
			return responseEntity;

		} catch (HttpClientErrorException ce) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient invokeRestEndpointWithCustomHeders : Exception during invokeRestEndpoint call ",
					ce);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_001);
			errorBean.setErrorMessage(ce.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setPayload(ce.getResponseBodyAsString());
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, ce.getStatusCode());
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient invokeRestEndpointWithCustomHeders : Exception during invokeRestEndpoint call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_004);
			errorBean.setErrorMessage(e.getMessage());
			errorBeans.add(errorBean);
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Generic method for handling all HTTP operations
	 * 
	 * @param httpMethod
	 * @param uri
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> invokeRestEndpoint(HttpMethod httpMethod, String uri, Object reuqestObject, //NOSONAR
			Class<?> responseType, Map<String, String> params, String requestJson, HttpHeaders headers, //NOSONAR
			BFLCommonClientBean... bflCommonClientBean) { //NOSONAR
		HttpHeaders appendedHeaders = headers;
		List<ErrorBean> errorBeans = new ArrayList<>();
		ResponseBean bean = new ResponseBean();
		// check to append headers only for internal BFL calls; headers will not
		// be appended for external services' calls
		if (null == bflCommonClientBean || bflCommonClientBean.length == 0) {
			appendedHeaders = appendCustomeHeaderValues(headers, customHdrs);
		}

		Timestamp requestTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		ResponseEntity<?> responseEntity;
		HttpEntity<Object> entity;
		if (null != reuqestObject) {
			entity = new HttpEntity<>(reuqestObject, appendedHeaders);
		} else {
			entity = new HttpEntity<>(requestJson, appendedHeaders);
		}
		RestTemplate restTemplateInstance = getTemplate(bflCommonClientBean);

		try {
			if (params != null) {
				responseEntity = restTemplateInstance.exchange(uri, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplateInstance.exchange(uri, httpMethod, entity, responseType);
			}

			// invoke method to persist records to NoSQL DB check for cross
			// cutting actions listed in bflCommonClient bean
			if (null != bflCommonClientBean && bflCommonClientBean.length > 0 && null != responseEntity) {
				persitNoSQLEntries(requestTimeStamp, requestJson, appendedHeaders, responseEntity, bflCommonClientBean);
			}
			return responseEntity;

		} catch (HttpClientErrorException ce) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient invokeRestEndpoint : Exception during invokeRestEndpoint call ",
					ce);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_001);
			errorBean.setErrorMessage(ce.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setPayload(ce.getResponseBodyAsString());
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, ce.getStatusCode());
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient invokeRestEndpoint : Exception during invokeRestEndpoint call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_004);
			errorBean.setErrorMessage(e.getMessage());
			errorBeans.add(errorBean);
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private HttpHeaders appendCustomeHeaderValues(HttpHeaders headers, CustomDefaultHeaders customHeader) {
		HttpHeaders updatedHeaders;
		if (null == headers) {
			updatedHeaders = new HttpHeaders();
		} else {
			updatedHeaders = headers;
		}
		if (null != customHeader) {
			updatedHeaders.add(CustomDefaultHeaders.AUTH_TOKEN, customHeader.getAuthtoken());
			updatedHeaders.add(CustomDefaultHeaders.CMPTCORR_ID, customHeader.getCmptcorrid());
			updatedHeaders.add(CustomDefaultHeaders.GUARD_TOKEN, customHeader.getGuardtoken());
			updatedHeaders.add(CustomDefaultHeaders.SOURCE, customHeader.getSource());
			updatedHeaders.add(CustomDefaultHeaders.PLATFORM, customHeader.getPlatform());
			updatedHeaders.add(CustomDefaultHeaders.USERKEY, String.valueOf(customHeader.getUserKey()));
			updatedHeaders.add(CustomDefaultHeaders.DEFAULTROLE, customHeader.getDefaultRole());
			updatedHeaders.add(CustomDefaultHeaders.LOGINID, customHeader.getLoginid());
			updatedHeaders.add(CustomDefaultHeaders.APPLICANTID, String.valueOf(customHeader.getApplntId()));
			//updatedHeaders.add(HttpHeaders.REFERER, appName);
		}
		return updatedHeaders;
	}

	/**
	 * Generic method to persist records to NoSQL Database
	 * @param requestJson 
	 * 
	 * @param httpMethod
	 * @param params
	 * @param requestJson
	 * @param responseEntity
	 * @param bflCommonClientBean
	 */
	private void persitNoSQLEntries(Timestamp requestTimeStamp, String requestJson, HttpHeaders headers, ResponseEntity<?> responseEntity,
			BFLCommonClientBean... bflCommonClientBean) {

		Timestamp currentTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		MetadataDetailsBean metadataDetailsBean;
		Timestamp responseTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		MetadataSuperBean metadataBean;
		// check for cross cutting actions listed in bflCommonClient bean
		if (null != bflCommonClientBean && bflCommonClientBean.length > 0 && null != responseEntity
				&& null != bflCommonClientBean[0].getMetadataSuperBean()) {
			// check for metadatabean availability, if yes persit entries to
			// NoSQL database
			metadataBean = bflCommonClientBean[0].getMetadataSuperBean();
			DynamoDbBean bean = new DynamoDbBean();
			bean.setSource(metadataBean.getSource());
			if(null != metadataBean.getSourcetype()) {
				bean.setSourcetype(metadataBean.getSourcetype());
			}
			bean.setApplicantId(metadataBean.getApplicantId());
			if(null != requestJson) {
				bean.setReqPayload(requestJson);
			}
			bean.setAppnId(metadataBean.getApplicationId());
			bean.setResPayload(responseEntity.getBody());
			bean.setResPayloadStr(responseEntity.getBody() != null ? responseEntity.getBody().toString() : null);
			bean.setReqTimeStamp(requestTimeStamp != null ? requestTimeStamp.toString() : currentTimeStamp.toString());
			bean.setResTimeStamp(responseTimeStamp.toString());

			if (metadataBean.isCaptureRawResponse() && null != bean.getResPayload()) {
				MultipartFile file = BFLCommonClientsUtil.createRawResponseFile(
						BFLCommonClientsUtil.getStringRepresentationForObject(responseEntity.getBody()));
				try {
					metadataDetailsBean = new MetadataDetailsBean(metadataBean.getSource());
					metadataDetailsBean.setApplicationId(metadataBean.getApplicationId());
					metadataDetailsBean.setMultipartFile(file);
					String presignedURL = BFLCommonClientsUtil.invokeUploadRawResponse(metadataDetailsBean,
							headers.getFirst(BFLCommonClientsUtil.REQ_CORELATION_ID));
					bean.setRawResUrl(presignedURL);
				} catch (Exception e) {
					BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
							"BFLCommonClient BFLCommonRestClient : Exception during persitNoSQLEntries call ", e);
				}
			}
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			// persist no sql record securely
			excuteRestCallSecurely(noSQLDataURL, HttpMethod.POST, bean, String.class, null, null, httpHeaders, bflCommonClientBean[0].getMetadataSuperBean().isSyncRequired());
		}
	}

	/**
	 * method to persist unstructured data
	 * 
	 * @param metadataBean
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public ResponseEntity<ResponseBean> persistUnstructureData(MetadataBean metadataBean, String correlationId) {
		// check if cust headers are available, if not set
		Timestamp currentTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		MetadataDetailsBean metadataDetailsBean = BFLCommonClientsUtil.mapMetaDataBean(metadataBean);

		String presignedURL;
		ResponseEntity<ResponseBean> responseEntity;
		if (null != metadataDetailsBean) {
			DynamoDbBean bean = new DynamoDbBean();
			bean.setSource(metadataDetailsBean.getSource());
			if(null != metadataDetailsBean.getSourcetype()) {
				bean.setSourcetype(metadataDetailsBean.getSourcetype());
			}
			bean.setApplicantId(metadataDetailsBean.getApplicantId());
			bean.setAppnId(metadataDetailsBean.getApplicationId());
			bean.setResPayload(metadataDetailsBean.getResponsePayload());
			if(null != metadataDetailsBean.getRequestPayload()) {
				bean.setReqPayload(metadataDetailsBean.getRequestPayload().toString());
			}
			/*IF(NULL ! = metadataDetailsBean.getResponsePayload()) {
				
			} ELSE {
				bean.setResPayloadStr(metadataDetailsBean.getResponsePayload() != null ? metadataDetailsBean.getResponsePayload().toString() : null);
			}*/
		
			bean.setReqTimeStamp(metadataDetailsBean.getRequestTimestamp() != null
					? metadataDetailsBean.getRequestTimestamp().toString() : currentTimeStamp.toString());
			bean.setResTimeStamp(metadataDetailsBean.getResponseTimestamp() != null
					? metadataDetailsBean.getResponseTimestamp().toString() : currentTimeStamp.toString());

			// Get presigned url from s3 upload activity
			MultipartFile file = null;
			if (null != metadataDetailsBean.getRawResponse()) {
				file = BFLCommonClientsUtil.createRawResponseFile(metadataDetailsBean.getRawResponse());
			}
			if (null != file) {
				try {
					metadataDetailsBean.setMultipartFile(file);
					presignedURL = BFLCommonClientsUtil.invokeUploadRawResponse(metadataDetailsBean, correlationId);
					bean.setRawResUrl(presignedURL);
				} catch (Exception e) {
					BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
							"BFLCommonClient BFLCommonRestClient : Exception during persistUnstructureData call ", e);
				}
			}

			// persit no sql record
			HttpHeaders headers = new HttpHeaders();
			headers.set("Content-Type", "application/json");
			// persit no sql record securely

			responseEntity = excuteRestCallSecurely(noSQLDataURL, HttpMethod.POST, bean, String.class, null, null,
					headers, true);
			return responseEntity;

		}
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

	}

	/**
	 * @Deprecated (other version of same method present, do not use this
	 *             method)
	 */
	@Deprecated
	@Async
	public Future<String> uploadMultiformDocuments(MultipartFile[] multipartFiles, Map<String, String> map,
			String serviceUrl, String corelationId) {
		StringBuilder sb = new StringBuilder();
		BufferedReader reader = null;
		InputStreamReader inputStreamReader = null;
		CloseableHttpClient client = null;
		try { // NOSONAR
			client = HttpClients.createDefault();
			MultipartEntityBuilder builder = MultipartEntityBuilder.create();

			if (multipartFiles != null) {
				for (int i = 0; i < multipartFiles.length; i++) {
					MultipartFile file = multipartFiles[i];
					ContentBody contentBody = new InputStreamBody(file.getInputStream(),
							ContentType.create(file.getContentType()), file.getOriginalFilename());
					builder.addPart("file", contentBody);
				}
			}
			for (Map.Entry<String, String> entry : map.entrySet()) {
				builder.addTextBody(entry.getKey(), entry.getValue());
			}
			// org.apache.http.HttpEntity use explicitly,in exiting code using
			// the spring HttpEntity-Need to unify
			org.apache.http.HttpEntity httpentity = builder.build();
			HttpPost uploadFile = new HttpPost(serviceUrl);
			uploadFile.addHeader(REQ_CORELATION_ID, corelationId);
			uploadFile.setEntity(httpentity);

			CloseableHttpResponse response = client.execute(uploadFile);

			org.apache.http.HttpEntity responseEntity = response.getEntity();
			inputStreamReader = new InputStreamReader(responseEntity.getContent());
			reader = new BufferedReader(inputStreamReader);
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient : IOException during uploadMultiformDocuments (deprecated) service call ",
					e);
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient : Exception during uploadMultiformDocuments (deprecated) service call ",
					e);
		} finally {
			try {
				IOUtils.closeQuietly(inputStreamReader);
				IOUtils.closeQuietly(reader);
				if (null != client) {
					client.close();
				}
			} catch (IOException e) {
				BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
						"BFLCommonClient BFLCommonRestClient : Error while closing closable http client: ", e);
			}

		}
		return new AsyncResult(sb.toString());
	}

	@Async
	public Future<String> uploadMultiformDocuments(MultipartFile[] multipartFiles, Map<String, String> map,
			String serviceUrl, String corelationId, HttpHeaders headers, BFLCommonClientBean... bflCommonClientBean) {
		return new AsyncResult( performUploadMultiformDocuments(multipartFiles, map, serviceUrl, corelationId, headers,
				bflCommonClientBean));
	}

	public String performUploadMultiformDocuments(MultipartFile[] multipartFiles, Map<String, String> map,
			String serviceUrl, String corelationId, HttpHeaders headers, BFLCommonClientBean... bflCommonClientBean) {

		if (null == bflCommonClientBean || bflCommonClientBean.length == 0) {
			headers = appendCustomeHeaderValues(headers, customHdrs);// NOSONAR
		}

		StringBuilder sb = new StringBuilder();
		BufferedReader reader = null;
		InputStreamReader inputStreamReader = null;
		CloseableHttpClient client = null;
		try { // NOSONAR
			client = HttpClients.createDefault();
			MultipartEntityBuilder builder = MultipartEntityBuilder.create();

			if (multipartFiles != null) {
				for (int i = 0; i < multipartFiles.length; i++) {
					MultipartFile file = multipartFiles[i];
					ContentBody contentBody = new InputStreamBody(file.getInputStream(),
							ContentType.create(file.getContentType()), file.getOriginalFilename());
					builder.addPart("file", contentBody);
				}
			}
			for (Map.Entry<String, String> entry : map.entrySet()) {
				builder.addTextBody(entry.getKey(), entry.getValue());
			}
			// org.apache.http.HttpEntity use explicitly,in exiting code using
			// the spring HttpEntity-Need to unify
			org.apache.http.HttpEntity httpentity = builder.build();
			HttpEntityEnclosingRequestBase uploadFile;
			if(null != bflCommonClientBean && bflCommonClientBean.length > 0 && null != bflCommonClientBean[0].getHttpMethod()){
				uploadFile = getHttpEntityRequest(bflCommonClientBean[0].getHttpMethod(),serviceUrl);
			}else{
				uploadFile = new HttpPost(serviceUrl);
			}
			uploadFile.addHeader(CustomDefaultHeaders.CMPTCORR_ID, customHdrs.getCmptcorrid());
			uploadFile.addHeader(CustomDefaultHeaders.AUTH_TOKEN, customHdrs.getAuthtoken());
			uploadFile.addHeader(CustomDefaultHeaders.GUARD_TOKEN, customHdrs.getGuardtoken());
			uploadFile.addHeader(CustomDefaultHeaders.PLATFORM, customHdrs.getPlatform());
			uploadFile.addHeader(CustomDefaultHeaders.SOURCE, customHdrs.getSource());
			uploadFile.addHeader(CustomDefaultHeaders.APPLICANTID, String.valueOf(customHdrs.getApplntId()));

			uploadFile.setEntity(httpentity);

			CloseableHttpResponse response = client.execute(uploadFile);

			org.apache.http.HttpEntity responseEntity = response.getEntity();
			inputStreamReader = new InputStreamReader(responseEntity.getContent());
			reader = new BufferedReader(inputStreamReader);
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient uploadMultiformDocuments : IOException during uploadMultiformDocuments (deprecated) service call ",
					e);
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient uploadMultiformDocuments : Exception during uploadMultiformDocuments (deprecated) service call ",
					e);
		} finally {
			try {
				IOUtils.closeQuietly(inputStreamReader);
				IOUtils.closeQuietly(reader);
				if (null != client) {
					client.close();
				}
			} catch (IOException e) {
				BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
						"BFLCommonClient uploadMultiformDocuments : Error occurred while closing closable HTTP client ",
						e);
			}

		}
		return sb.toString();
	}
	
	private HttpEntityEnclosingRequestBase getHttpEntityRequest(HttpMethod httpMethod, String serviceUrl){
		if(HttpMethod.POST.equals(httpMethod)){
			return new HttpPost(serviceUrl);
		}else if(HttpMethod.PUT.equals(httpMethod)){
			return new HttpPut(serviceUrl);
		}else {
			return new HttpPost(serviceUrl);
		}
	}

	private ResponseEntity<ResponseBean> excuteRestCallSecurely(String url, HttpMethod httpMethod, Object reuqestObject,
			Class<?> responseType, Map<String, String> params, String requestJson, HttpHeaders headers, boolean dynamoSyncFlag,
			BFLCommonClientBean... bflCommonClientBean) {
		HttpHeaders appendedHeaders = headers;
		// check to append headers only for internal BFL calls; headers will not
		// be appended for external services' calls
		if (null == bflCommonClientBean || bflCommonClientBean.length == 0) {
			appendedHeaders = appendCustomeHeaderValues(appendedHeaders, customHdrs);
		}

		Timestamp requestTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		List<ErrorBean> errorBeans = new ArrayList<>();
		ResponseBean bean = new ResponseBean();
		HttpEntity<Object> entity;
		ResponseEntity<?> responseEntity;
		if (null != reuqestObject) {
			entity = new HttpEntity<>(reuqestObject, appendedHeaders);
		} else {
			entity = new HttpEntity<>(requestJson, appendedHeaders);
		}

		HttpClient httpClient = HttpClients.custom().setSSLContext(getSSLContext()).build();

		ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

		RestTemplate restTemplateInstance = new RestTemplate(requestFactory);
		try {
			//method for DynamoDB Call - Async and Sync Call
			responseEntity = callDynamoEndpoint(url, httpMethod, responseType, params, entity, restTemplateInstance, dynamoSyncFlag);
			
			if (null != responseEntity) {
				bean.setPayload(responseEntity.getBody());
				bean.setStatus(StatusCode.SUCCESS);
			}

			// invoke method to persist records to NoSQL DB
			if (null != bflCommonClientBean && bflCommonClientBean.length > 0 && null != bflCommonClientBean[0].getMetadataSuperBean() &&null != responseEntity) {
				persitNoSQLEntries(requestTimeStamp, requestJson, appendedHeaders, responseEntity, bflCommonClientBean);
			}

			return new ResponseEntity<>(bean, responseEntity != null ? responseEntity.getHeaders() : new HttpHeaders(),
					responseEntity != null ? responseEntity.getStatusCode() : HttpStatus.INTERNAL_SERVER_ERROR);

		} catch (HttpClientErrorException ce) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCallSecurely : HttpClientErrorException during "
							+ httpMethod.name() + " call ",
					ce);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_001);
			errorBean.setErrorMessage(ce.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setPayload(ce.getResponseBodyAsString());
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, ce.getStatusCode());
		} catch (HttpStatusCodeException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCallSecurely : HttpStatusCodeException during "
							+ httpMethod.name() + " call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_002);
			errorBean.setErrorMessage(e.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setPayload(e.getResponseBodyAsString());
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, e.getStatusCode());
		} catch (RestClientException e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCallSecurely : RestClientException during "
							+ httpMethod.name() + " call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_003);
			errorBean.setErrorMessage(e.getMostSpecificCause().toString());
			errorBeans.add(errorBean);
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonRestClient excuteRestCallSecurely : Exception during " + httpMethod.name()
							+ " call ",
					e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_004);
			errorBean.setErrorMessage(e.getMessage());
			errorBeans.add(errorBean);
			bean.setStatus(StatusCode.FAILURE);
			bean.setErrorBean(errorBeans);
			return new ResponseEntity<>(bean, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * @param url
	 * @param httpMethod
	 * @param responseType
	 * @param params
	 * @param entity
	 * @param restTemplateInstance
	 * @param dynamoAsyncFlag 
	 * @return
	 */
	private ResponseEntity<?> callDynamoEndpoint(String url, HttpMethod httpMethod, Class<?> responseType,
			Map<String, String> params, HttpEntity<Object> entity, RestTemplate restTemplateInstance, boolean dynamoSyncFlag) {
		ResponseEntity<?> responseEntity = null;
		if (!dynamoSyncFlag) {
			bflCommonAsyncRestClient.callDyanmoAsync(restTemplateInstance, url, httpMethod, entity, responseType, params);
		} else {
			if (params != null) {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplateInstance.exchange(url, httpMethod, entity, responseType);
			}
		}
		return responseEntity;
	}

	/**
	 * Creates the SSL context for Signzy REST calls
	 * 
	 * @return SSLContext SSLContext
	 */
	private SSLContext getSSLContext() {
		SSLContext sslContext = null;
		try {
			sslContext = SSLContext.getInstance("TLS");
			// set up a TrustManager that trusts everything
			sslContext.init(null, new TrustManager[] { new X509TrustManager() {
				@Override
				public X509Certificate[] getAcceptedIssuers() {
					return null; // NOSONAR
				}

				@Override
				public void checkClientTrusted(X509Certificate[] certs, String authType) {
					// This method will remain empty
				}

				@Override
				public void checkServerTrusted(X509Certificate[] certs, String authType) {
					// This method will remain empty
				}
			} }, new SecureRandom());
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.DAO, "==== Error in getting the SSL context ===",
					e);
		}
		return sslContext;
	}

	public String excuteUploadRawResponse(MetadataDetailsBean metadataBean, String correlationId) {
		String coRelationId = null != correlationId ? correlationId : "PASS_CORELATION_ID";
		CloseableHttpClient client = null;
		MultipartFile multipartFiles = metadataBean.getMultipartFile();
		StringBuilder sb = new StringBuilder();
		BufferedReader reader = null;
		InputStreamReader inputStreamReader = null;

		try { // NOSONAR
			client = HttpClients.createDefault();
			MultipartEntityBuilder builder = MultipartEntityBuilder.create();

			if (null != multipartFiles) {
				MultipartFile file = multipartFiles;
				ContentBody contentBody = new InputStreamBody(file.getInputStream(),
						ContentType.create(file.getContentType()), file.getOriginalFilename());
				builder.addPart("file", contentBody);
			}

			builder.addTextBody("uuid", UUID.randomUUID().toString());
			builder.addTextBody("performOcr", "N");
			builder.addTextBody("assetType", metadataBean.getSource());
			builder.addTextBody("applicationId", metadataBean.getApplicationId());

			org.apache.http.HttpEntity httpentity = builder.build();
			HttpPost uploadFile = new HttpPost(rawResponseUpload);
			uploadFile.addHeader(REQ_CORELATION_ID, coRelationId);
			uploadFile.addHeader(CustomDefaultHeaders.CMPTCORR_ID, customHdrs.getCmptcorrid());
			uploadFile.addHeader(CustomDefaultHeaders.AUTH_TOKEN, customHdrs.getAuthtoken());
			uploadFile.addHeader(CustomDefaultHeaders.GUARD_TOKEN, customHdrs.getGuardtoken());
			uploadFile.addHeader(CustomDefaultHeaders.PLATFORM, customHdrs.getPlatform());
			uploadFile.addHeader(CustomDefaultHeaders.SOURCE, customHdrs.getSource());
			uploadFile.setEntity(httpentity);

			CloseableHttpResponse response = client.execute(uploadFile);

			org.apache.http.HttpEntity responseEntity = response.getEntity();
			inputStreamReader = new InputStreamReader(responseEntity.getContent());
			reader = new BufferedReader(inputStreamReader);
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
			return sb != null ? sb.toString() : null;
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonClientsUtil : Exception during invokeUploadRawResponse call ", e);
			throw new BFLTechnicalException("CORE-USDS-001",
					"Error occurred while handling unstructrured data operations!");
		} finally {
			if (null != client) {
				try {
					client.close();
				} catch (IOException e) {
					BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
							"BFLCommonClient BFLCommonClientsUtil : Exception during invokeUploadRawResponse call ", e);
				}
			}
		}
	}
	
	/**
	 * Below method will call internal BRE using Jersey Client.Used for Internal BRE Calls. 
	 * @param breUrl
	 * @param httpMethod
	 * @param responseType
	 * @param requestJson
	 * @param headers
	 * @param bflCommonClientBean
	 * @return
	 */
	public ResponseEntity<?> executeJerseyRestCall(String breUrl, HttpMethod httpMethod, 
			Class<?> responseType, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		
		ResponseBean responseBean = new ResponseBean();
		ResponseEntity<?> responseEntity = null; 
		String breResponseStr = null;
		List<ErrorBean> errorBeans = new ArrayList();
		HttpHeaders appendedHeaders = headers;
		HttpHeaders responseHeaders = new HttpHeaders();
		
		try {
			Client client = JersyClientInstance.getRestClient();
			WebResource webResource = client.resource(breUrl);
			Builder builder = webResource.getRequestBuilder();
			
			Set<String> headerKeysSet = headers.keySet();
			if(null != headerKeysSet && !headerKeysSet.isEmpty()) {
				for (String string : headerKeysSet) {
					builder.header(string, headers.get(string).get(0));
				}
			}
			
			ClientResponse clientResponse = builder.post(ClientResponse.class, requestJson);
			
			if (clientResponse.getStatus() == 200 || clientResponse.getStatus() == 201) {
				breResponseStr= clientResponse.getEntity(String.class);
				responseBean.setPayload(breResponseStr);
				responseBean.setStatus(StatusCode.SUCCESS);
				logger.info(Class_Name, BFLLoggerComponent.SERVICE, "Response when OK status is obtained : " + breResponseStr);
				
				responseEntity = new ResponseEntity(breResponseStr,
						null != clientResponse ? HttpStatus.valueOf(clientResponse.getStatus()):HttpStatus.INTERNAL_SERVER_ERROR);			
				
				//Copy Jersey API response Headers to Spring Framework Response Entity
				MultivaluedMap<String , String> multivaluedMapJerseyRespHeaders = clientResponse.getHeaders();
				if(null != multivaluedMapJerseyRespHeaders &&  !multivaluedMapJerseyRespHeaders.isEmpty()) {
					for(Map.Entry<String,List<String>> entry : multivaluedMapJerseyRespHeaders.entrySet()) {
						responseHeaders.add(entry.getKey(), entry.getValue().get(0));
					}
				}
				
				// check to append headers only for internal BFL calls; headers will not
				// be appended for external services' calls
				//if (null == bflCommonClientBean || bflCommonClientBean.length == 0) {
				appendedHeaders = appendCustomeHeaderValues(headers, customHdrs);
				//}
				
				responseEntity = new ResponseEntity(breResponseStr, responseHeaders,
						null != clientResponse ? HttpStatus.valueOf(clientResponse.getStatus()):HttpStatus.INTERNAL_SERVER_ERROR);	
				
				
				// invoke method to persist records to NoSQL DB
				if (null != bflCommonClientBean && bflCommonClientBean.length > 0 && null != responseEntity) {
					Timestamp requestTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
					this.persitNoSQLEntries(requestTimeStamp, requestJson, appendedHeaders, responseEntity, bflCommonClientBean);
				}
			}else{
				logger.info(Class_Name, BFLLoggerComponent.SERVICE, "Error response code: " + clientResponse.getStatus());
			}
			/*return new ResponseEntity(responseBean, respoonseHeaders,
					responseEntity != null ? responseEntity.getStatusCode() : HttpStatus.INTERNAL_SERVER_ERROR);*/
			return responseEntity;
			
		}catch(UniformInterfaceException unEx) {
			logger.error(Class_Name, BFLLoggerComponent.UTILITY,
					"In executeJerseyRestCall : UniformInterfaceException during "
							+ httpMethod.name() + " call ",	unEx);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_001);
			errorBean.setErrorMessage(unEx.getMessage());
			errorBeans.add(errorBean);
			responseBean.setPayload(unEx.getResponse().getEntity(String.class));
			responseBean.setStatus(StatusCode.FAILURE);
			responseBean.setErrorBean(errorBeans);
			return new ResponseEntity(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		}catch(ClientHandlerException cliEx) {
			logger.error(Class_Name, BFLLoggerComponent.UTILITY,
					"In executeJerseyRestCall : ClientHandlerException during "
							+ httpMethod.name() + " call ",	cliEx);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_002);
			errorBean.setErrorMessage(cliEx.getMessage());
			errorBeans.add(errorBean);
			responseBean.setStatus(StatusCode.FAILURE);
			responseBean.setErrorBean(errorBeans);
			return new ResponseEntity(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			BFLLoggerUtil.error(null, Class_Name, BFLLoggerComponent.UTILITY,
					"In executeJerseyRestCall : Exception during " + httpMethod.name()
							+ " call ",	e);
			ErrorBean errorBean = new ErrorBean();
			errorBean.setErrorCode(CORE_003);
			errorBean.setErrorMessage(e.getMessage());
			errorBeans.add(errorBean);
			responseBean.setStatus(StatusCode.FAILURE);
			responseBean.setErrorBean(errorBeans);
			return new ResponseEntity(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}