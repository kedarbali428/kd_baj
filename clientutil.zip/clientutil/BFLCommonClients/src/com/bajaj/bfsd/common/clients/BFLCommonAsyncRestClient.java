package com.bajaj.bfsd.common.clients;

import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * @author gouravgoyal
 * 
 */
@EnableAsync
@Component
public class BFLCommonAsyncRestClient {

	@Async
	public void callDyanmoAsync(RestTemplate restTemplate, String url, HttpMethod httpMethod, HttpEntity<Object> entity, Class<?> responseType,
			Map<String, String> params) {
		if (params != null) {
			restTemplate.exchange(url, httpMethod, entity, responseType, params);
		} else {
			restTemplate.exchange(url, httpMethod, entity, responseType);
		}
	}
}
