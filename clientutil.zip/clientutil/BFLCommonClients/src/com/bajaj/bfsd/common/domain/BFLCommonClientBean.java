package com.bajaj.bfsd.common.domain;

import java.io.Serializable;

import org.springframework.http.HttpMethod;

/**
 * Bean for handling error scenarios
 * 
 * @author 595327
 *
 */
public class BFLCommonClientBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private MetadataSuperBean metadataSuperBean;
	
	private ClientProxyBean clientProxyBean;
	
	private HttpMethod httpMethod;
	
	/**
	 * @return the metadataSuperBean
	 */
	public MetadataSuperBean getMetadataSuperBean() {
		return metadataSuperBean;
	}

	/**
	 * @param metadataSuperBean the metadataSuperBean to set
	 */
	public void setMetadataSuperBean(MetadataSuperBean metadataSuperBean) {
		this.metadataSuperBean = metadataSuperBean;
	}

	/**
	 * @return the clientProxyBean
	 */
	public ClientProxyBean getClientProxyBean() {
		return clientProxyBean;
	}

	/**
	 * @param clientProxyBean the clientProxyBean to set
	 */
	public void setClientProxyBean(ClientProxyBean clientProxyBean) {
		this.clientProxyBean = clientProxyBean;
	}

	/**
	 * @return the httpMethod
	 */
	public HttpMethod getHttpMethod() {
		return httpMethod;
	}

	/**
	 * @param httpMethod the httpMethod to set
	 */
	public void setHttpMethod(HttpMethod httpMethod) {
		this.httpMethod = httpMethod;
	}
}
