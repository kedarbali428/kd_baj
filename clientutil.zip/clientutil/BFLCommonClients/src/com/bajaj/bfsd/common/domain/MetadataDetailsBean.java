package com.bajaj.bfsd.common.domain;

import java.io.Serializable;

import org.springframework.web.multipart.MultipartFile;




/**
 * Bean for handling no sql data
 * @author 595327
 *
 */
public class MetadataDetailsBean extends MetadataBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String rawResponseUrl;
	private transient MultipartFile multipartFile;
	
	public MetadataDetailsBean(String source) {
		super(source);
	}
	

	/**
	 * @return the rawResponseUrl
	 */
	public String getRawResponseUrl() {
		return rawResponseUrl;
	}

	/**
	 * @param rawResponseUrl the rawResponseUrl to set
	 */
	public void setRawResponseUrl(String rawResponseUrl) {
		this.rawResponseUrl = rawResponseUrl;
	}

	/**
	 * @return the multipartFile
	 */
	public MultipartFile getMultipartFile() {
		return multipartFile;
	}

	/**
	 * @param multipartFile the multipartFile to set
	 */
	public void setMultipartFile(MultipartFile multipartFile) {
		this.multipartFile = multipartFile;
	}
	
	
}
