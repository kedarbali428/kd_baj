package com.bajaj.bfsd.common.domain;

import java.io.Serializable;

public class ClientProxyBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	String proxyAddress;
	
	String port;

	/**
	 * @return the proxyAddress
	 */
	public String getProxyAddress() {
		return proxyAddress;
	}

	/**
	 * @param proxyAddress the proxyAddress to set
	 */
	public void setProxyAddress(String proxyAddress) {
		this.proxyAddress = proxyAddress;
	}

	/**
	 * @return the port
	 */
	public String getPort() {
		return port;
	}

	/**
	 * @param port the port to set
	 */
	public void setPort(String port) {
		this.port = port;
	}
	
	

}
