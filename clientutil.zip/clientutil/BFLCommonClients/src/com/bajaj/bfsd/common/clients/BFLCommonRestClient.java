package com.bajaj.bfsd.common.clients;

import java.sql.Timestamp;
import java.util.Map;
import java.util.concurrent.Future;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;

import com.bajaj.bfsd.common.domain.BFLCommonClientBean;
import com.bajaj.bfsd.common.domain.MetadataBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.sun.jersey.api.client.ClientResponse;

/**
 * BFL common REST client for handling rest calls.
 * 
 * @author 595327
 *
 */
@RefreshScope
@Component
public class BFLCommonRestClient {

	@Autowired
	ApplicationContext applicationContext;

	static ApplicationContext staticApplicationContext;
	
	@PostConstruct
	public void setClientInitParam() {
		staticApplicationContext = applicationContext; //NOSONAR
	}
	
	private static BFLCommonRestClientImpl getBFLCommonRestClientImpl() {
		return staticApplicationContext
				.getBean(BFLCommonRestClientImpl.class);
	}

	/**
	 * method for handling HTTP GET operations
	 * 
	 * @param uriForGet
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<ResponseBean>
	 */
	public static ResponseEntity<ResponseBean> get(String uriForGet, Object reuqestObject, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCall(uriForGet, HttpMethod.GET, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);
	}

	/**
	 * method for handling HTTP DELETE operations
	 * 
	 * @param uriForDelete
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<ResponseBean>
	 */
	public static ResponseEntity<ResponseBean> delete(String uriForDelete, Object reuqestObject, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCall(uriForDelete, HttpMethod.DELETE, reuqestObject, responseType, params, requestJson,
				headers, bflCommonClientBean);
	}

	/**
	 * method for handling HTTP POST operations
	 * 
	 * @param uriForCreate
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<ResponseBean>
	 */
	public static ResponseEntity<ResponseBean> create(String uriForCreate, Object reuqestObject, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCall(uriForCreate, HttpMethod.POST, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);
	}

	private static ResponseEntity<ResponseBean> excuteRestCall(String url, HttpMethod httpMethod, Object reuqestObject,
			Class<?> responseType, Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {

		BFLCommonRestClientImpl impl = getBFLCommonRestClientImpl();
		return impl.excuteRestCall(url, httpMethod, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);
	}
	
	public static ResponseEntity<ResponseBean> createTest(String uriForCreate, Object reuqestObject, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCallTest(uriForCreate, HttpMethod.POST, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);
	}

	private static ResponseEntity<ResponseBean> excuteRestCallTest(String url, HttpMethod httpMethod, Object reuqestObject,
			Class<?> responseType, Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {

		BFLCommonRestClientImpl impl = getBFLCommonRestClientImpl();
		return impl.excuteRestCallTest(url, httpMethod, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);
	}

	/**
	 * method for handling HTTP PUT operations
	 * 
	 * @param uriForUpdate
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<ResponseBean>
	 */
	public static ResponseEntity<ResponseBean> update(String uriForUpdate, Object reuqestObject, Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCall(uriForUpdate, HttpMethod.PUT, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);

	}
	
	/**
	 * 
	 * @param url
	 * @param map
	 * @param responseType
	 * @param params
	 * @param headers
	 * @param bflCommonClientBean
	 * @return
	 */
	public ResponseEntity<ResponseBean> postForEntity(String url,MultiValueMap<String, String> map, Class<?> responseType,
			Map<String, String> params, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return postEntity(url, map, responseType, params, headers, 
				bflCommonClientBean);
	}
	
	/**
	 * 
	 * @param url
	 * @param map
	 * @param responseType
	 * @param params
	 * @param headers
	 * @param bflCommonClientBean
	 * @return
	 */
	private static ResponseEntity<ResponseBean> postEntity(String url,MultiValueMap<String, String> map, Class<?> responseType,
			Map<String, String> params, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {

		BFLCommonRestClientImpl impl = getBFLCommonRestClientImpl();
		return impl.postForEntity(url, map, responseType, params, headers, bflCommonClientBean);
	}

	/**
	 * Generic method for handling all HTTP operations
	 * 
	 * @param httpMethod
	 * @param uriForGet
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<ResponseBean>
	 */
	public static ResponseEntity<ResponseBean> execute(HttpMethod httpMethod, String uriForGet, Object reuqestObject,
			Class<?> responseType, Map<String, String> params, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {
		return excuteRestCall(uriForGet, httpMethod, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);

	}

	/**
	 * Generic method for handling all HTTP operations
	 * 
	 * @param httpMethod
	 * @param uri
	 * @param reuqestObject
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @return ResponseEntity<?>
	 */
	public static ResponseEntity<?> invokeRestEndpoint(HttpMethod httpMethod, String uri, Object reuqestObject,//NOSONAR
			Class<?> responseType, Map<String, String> params, String requestJson, HttpHeaders headers,//NOSONAR
			BFLCommonClientBean... bflCommonClientBean) { // NOSONAR

		BFLCommonRestClientImpl impl = getBFLCommonRestClientImpl();
		return impl.invokeRestEndpoint(httpMethod, uri, reuqestObject, responseType, params, requestJson, headers,
				bflCommonClientBean);
	}

	/**
	 * method to persist unstructured data
	 * 
	 * @param metadataBean
	 * @return
	 */
	public static ResponseEntity<ResponseBean> persistUnstructureData(MetadataBean metadataBean, String correlationId) {
		BFLCommonRestClientImpl impl = getBFLCommonRestClientImpl();
		return impl.persistUnstructureData(metadataBean, correlationId);
	}

	@Async
	public static Future<String> uploadMultiformDocuments(MultipartFile[] multipartFiles, Map<String, String> map,
			String serviceUrl, String corelationId, HttpHeaders headers, BFLCommonClientBean... bflCommonClientBean) {

		BFLCommonRestClientImpl impl = getBFLCommonRestClientImpl();
		return impl.uploadMultiformDocuments(multipartFiles, map, serviceUrl, corelationId, headers,
				bflCommonClientBean);
	}
	
	
	public static String uploadMultiformDocumentsInSync(MultipartFile[] multipartFiles, Map<String, String> map,
			String serviceUrl, String corelationId, HttpHeaders headers, BFLCommonClientBean... bflCommonClientBean) {
		BFLCommonRestClientImpl impl = getBFLCommonRestClientImpl();
		return impl.performUploadMultiformDocuments(multipartFiles, map, serviceUrl, corelationId, headers,
				bflCommonClientBean);
	}
	
	public static ResponseEntity<?> executeJerseyRestCall(String breUrl, HttpMethod httpMethod, 
			Class<?> responseType, String requestJson, HttpHeaders headers,
			BFLCommonClientBean... bflCommonClientBean) {

		BFLCommonRestClientImpl impl = getBFLCommonRestClientImpl();
		return impl.executeJerseyRestCall(breUrl, httpMethod, responseType, requestJson, headers, bflCommonClientBean);
	}
	
}