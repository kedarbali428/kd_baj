package com.bajaj.bfsd.common.constants;

public enum HttpVerb {

	POST, PUT, GET, DELETE;
	
}
