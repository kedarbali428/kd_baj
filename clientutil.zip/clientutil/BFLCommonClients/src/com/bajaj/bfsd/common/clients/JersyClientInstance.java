package com.bajaj.bfsd.common.clients;

import javax.annotation.Resource;

import com.sun.jersey.api.client.Client;

@Resource
public class JersyClientInstance {
	private static Client restClient = getJersyClientInstance();

	private JersyClientInstance(){
		//private constructor to prevent instantiation
	}

	private static Client getJersyClientInstance() {
		if (null == restClient) {
			restClient = Client.create();
		}
		return restClient;
	}

	public static Client getRestClient() {
		return restClient;
	}
}
