package com.bajaj.bfsd.common.clients;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Scanner;

import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;

public class ErrorHandler extends DefaultResponseErrorHandler {

	private Scanner scanner;

	@Override
	public void handleError(ClientHttpResponse response) throws IOException {
		// conversion logic for decoding conversion
		ByteArrayInputStream arrayInputStream = (ByteArrayInputStream) response.getBody();
		scanner = new Scanner(arrayInputStream);
		scanner.useDelimiter("\\Z");
		if (scanner.hasNext())
			scanner.next();
	}
}