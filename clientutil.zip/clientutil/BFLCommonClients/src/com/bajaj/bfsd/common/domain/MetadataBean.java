package com.bajaj.bfsd.common.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Map;

/**
 * Bean for handling no sql data
 * @author 595327
 *
 */
public class MetadataBean extends MetadataSuperBean implements Serializable {
	
	/**
	 * default serial version UID
	 */
	private static final long serialVersionUID = 1L;
	private transient Object requestPayload;
	private transient Object responsePayload;
	private Timestamp requestTimestamp;
	private Timestamp responseTimestamp;
	private Map<String,String> params;
	private String rawResponse;
	
	
	public MetadataBean(String source) {
		super(source);
	}
	
	/**
	 * @return the responsePayload
	 */
	public Object getResponsePayload() {
		return responsePayload;
	}

	/**
	 * @param responsePayload the responsePayload to set
	 */
	public void setResponsePayload(Object responsePayload) {
		this.responsePayload = responsePayload;
	}

	/**
	 * @return the requestTimestamp
	 */
	public Timestamp getRequestTimestamp() {
		return requestTimestamp;
	}

	/**
	 * @param requestTimestamp the requestTimestamp to set
	 */
	public void setRequestTimestamp(Timestamp requestTimestamp) {
		this.requestTimestamp = requestTimestamp;
	}

	/**
	 * @return the responseTimestamp
	 */
	public Timestamp getResponseTimestamp() {
		return responseTimestamp;
	}

	/**
	 * @param responseTimestamp the responseTimestamp to set
	 */
	public void setResponseTimestamp(Timestamp responseTimestamp) {
		this.responseTimestamp = responseTimestamp;
	}
	
	/**
	 * @return the params
	 */
	public Map<String, String> getParams() {
		return params;
	}

	/**
	 * @param params the params to set
	 */
	public void setParams(Map<String, String> params) {
		this.params = params;
	}

	/**
	 * @return the requestPayload
	 */
	public Object getRequestPayload() {
		return requestPayload;
	}

	/**
	 * @param requestPayload the requestPayload to set
	 */
	public void setRequestPayload(Object requestPayload) {
		this.requestPayload = requestPayload;
	}

	/**
	 * @return the rawResponse
	 */
	public String getRawResponse() {
		return rawResponse;
	}

	/**
	 * @param rawResponse the rawResponse to set
	 */
	public void setRawResponse(String rawResponse) {
		this.rawResponse = rawResponse;
	}
}
