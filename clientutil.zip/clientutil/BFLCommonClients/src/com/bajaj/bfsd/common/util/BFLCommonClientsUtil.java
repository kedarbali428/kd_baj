package com.bajaj.bfsd.common.util;

import java.io.IOException;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.clients.BFLCommonRestClientImpl;
import com.bajaj.bfsd.common.domain.MetadataBean;
import com.bajaj.bfsd.common.domain.MetadataDetailsBean;

@RefreshScope
@Component
public class BFLCommonClientsUtil {
	
	private static final String class_Name = BFLCommonClientsUtil.class.getName(); //NOSONAR
	
	protected static final Properties properties = BFLCommonClientUtility.getProperties("commonClient.properties");

	public static final String REQ_CORELATION_ID = "cmptcorrid";
	
	
	static String staticRAWResponseUpload;
	
	@Autowired
	Environment env;
	
	@Autowired
	ApplicationContext applicationContext;
	
	static ApplicationContext staticApplicationContext;
	
	@PostConstruct
	public void setClientInitParam() {
		staticApplicationContext = applicationContext; //NOSONAR
	}
	
	private static BFLCommonRestClientImpl getBFLCommonRestClientImpl() {
		return (BFLCommonRestClientImpl) staticApplicationContext
				.getBean(BFLCommonRestClientImpl.class);
	}
	
	/**
	 * returns json representation of object
	 * 
	 * @param object
	 * @return
	 */
	public static String getStringRepresentationForObject(Object object) {
		ObjectMapper mapperObj = new ObjectMapper();
		try {
			return mapperObj.writeValueAsString(object);
		} catch (IOException e) {
			BFLLoggerUtil.error(null,class_Name, BFLLoggerComponent.UTILITY,
					"BFLCommonClient BFLCommonClientsUtil : Exception during getStringRepresentationForObject call ", e);
		}
		return null;
	}

	public static MultipartFile createRawResponseFile(String rawResponse) {
		String name = "file.txt";
		String originalFileName = "file.txt";
		String contentType = "text/plain";
		byte[] mutipartContent = rawResponse.getBytes();
		MultipartFile multipartFile = new MockMultipartFile(name, originalFileName, contentType, mutipartContent);
		return multipartFile;
	}

	

	/**
	 * Mapper method
	 * 
	 * @param metadataBean
	 * @return
	 * @throws Exception
	 */
	public static MetadataDetailsBean mapMetaDataBean(MetadataBean metadataBean) {

		MetadataDetailsBean metadataDetailsBean = new MetadataDetailsBean(metadataBean.getSource());
		metadataDetailsBean.setApplicantId(metadataBean.getApplicantId());
		metadataDetailsBean.setApplicationId(metadataBean.getApplicationId());
		metadataDetailsBean.setParams(metadataBean.getParams());
		metadataDetailsBean.setRawResponse(metadataBean.getRawResponse());
		metadataDetailsBean.setRequestPayload(metadataBean.getRequestPayload());
		metadataDetailsBean.setRequestTimestamp(metadataBean.getRequestTimestamp());
		metadataDetailsBean.setResponsePayload(metadataBean.getResponsePayload());
		metadataDetailsBean.setResponseTimestamp(metadataBean.getResponseTimestamp());
		metadataDetailsBean.setSourcetype(metadataBean.getSourcetype());
		
		return metadataDetailsBean;

	}
	
	public static String invokeUploadRawResponse(MetadataDetailsBean metadataBean, String correlationId) {

		return getBFLCommonRestClientImpl().excuteUploadRawResponse(metadataBean,correlationId);  
	}
}
