package com.bajaj.bfsd.common.domain;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SuppressWarnings("rawtypes")
public class ResponseWrapper extends ResponseEntity{

	public ResponseWrapper(HttpStatus status) {
		super(status);
	}
}
