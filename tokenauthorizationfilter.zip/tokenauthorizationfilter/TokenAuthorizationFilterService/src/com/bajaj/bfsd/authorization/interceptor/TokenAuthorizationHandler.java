package com.bajaj.bfsd.authorization.interceptor;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;

@Component
public class TokenAuthorizationHandler implements HandlerInterceptor {
	private static final String CLASS_NAME = TokenAuthorizationHandler.class.getName();
	@Autowired
	private AuthorizationProcessor authenticationProcessor;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CustomDefaultHeaders customDefaultHeaders;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "TokenAuthorizationHandler-preHandle started");
		if (handler instanceof HandlerMethod) {
			HandlerMethod method = (HandlerMethod) handler;

			RequestMapping mapping = method.getMethodAnnotation(RequestMapping.class);
			String uriPath = Arrays.toString(mapping.value());
			String uri = uriPath.substring(uriPath.indexOf('{') + 1, uriPath.indexOf('}'));
			authenticationProcessor.isUserAuthorized(uri, customDefaultHeaders.getUserKey(), request.getMethod());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "TokenAuthorizationHandler-preHandle done");
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub

	}

}
