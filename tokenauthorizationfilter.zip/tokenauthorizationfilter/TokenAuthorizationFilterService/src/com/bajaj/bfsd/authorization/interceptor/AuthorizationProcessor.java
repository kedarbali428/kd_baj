package com.bajaj.bfsd.authorization.interceptor;

import java.util.Objects;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicy;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicyMap;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLHttpException;

@Component
public class AuthorizationProcessor {

	private static final String CLASSNAME = AuthorizationProcessor.class.getName();

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	BFLAuthorizationPolicyMap authMap;

	@Autowired
	CustomDefaultHeaders customHdrs;

	@Autowired
	Environment env;

	@Value("${api.rolemanagement.checkRoleInUsersAssignedRolesHierarchy.POST.url}")
	private String validateUserRolesUrl;

	public boolean isUserAuthorized(String uri, long userId, String method) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "isUserAuthorized - entering");

		boolean authorizationRequired = false;

		if (StringUtils.isEmpty(uri)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "URI is null.");
			return false;
		}
		uri = env.getProperty(uri);
		BFLAuthorizationPolicy policy = authMap.getPolicy(uri + method);
		if (Objects.isNull(policy)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Policy is null.");
			return false;
		}

		authorizationRequired = policy.isAuthorizationRequired();

		if (authorizationRequired) {
			authorizationRequired = policy.hasRole(customHdrs.getDefaultRole());

			if (!authorizationRequired) {
				authorizationRequired = checkInHierarchyIfUserHasPermittedRole(userId, policy);
			}
		} else {
			authorizationRequired = !authorizationRequired;
		}

		if (!authorizationRequired) {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
					"In AuthorizationProcessor:performAuthenticationAuthorizationCheck - User"
							+ (customHdrs == null ? " not available."
									: (customHdrs.getUserKey() + " is not allowed to access the requestURI - " + uri)));
			throw new BFLHttpException(HttpStatus.FORBIDDEN, "BFSD-403",
					"You are not authorized to use this service.!!");
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "isUserAuthorized - exit");
		return authorizationRequired;
	}

	@SuppressWarnings("unchecked")
	private boolean checkInHierarchyIfUserHasPermittedRole(long userId, BFLAuthorizationPolicy policy) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "checkInHierarchyIfUserHasPermittedRole - entering");

		HttpHeaders headersManual = new HttpHeaders();
		headersManual.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		JSONObject reqJsonObj = new JSONObject();
		reqJsonObj.put("userId", userId);
		reqJsonObj.put("commaSeparatedRolesToVerify", policy.getRolesStr());
		reqJsonObj.put("defaultRoleName", customHdrs.getDefaultRole());

		ResponseEntity<?> response = BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST, validateUserRolesUrl, null,
				ResponseBean.class, null, reqJsonObj.toString(), headersManual, null);

		if (null == response || !HttpStatus.OK.equals(response.getStatusCode())) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"checkInHierarchyIfUserHasPermittedRole - Role management service invocation returned error - "
							+ (response == null ? "Rolemanagement Service response is null"
									: response.getStatusCode().toString()));
			return false;
		}

		ResponseBean resBean = (ResponseBean) response.getBody();

		if (resBean == null || !StatusCode.SUCCESS.equals(resBean.getStatus())) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"checkInHierarchyIfUserHasPermittedRole - Role management service invocation retuned error - "
							+ (resBean != null ? resBean.getStatus()
									: "Rolemanagement Service response payload is null"));
			return false;
		}

		Object payLoad = resBean.getPayload();
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "checkInHierarchyIfUserHasPermittedRole - exit");
		return (null != payLoad && (boolean) payLoad);

	}
}