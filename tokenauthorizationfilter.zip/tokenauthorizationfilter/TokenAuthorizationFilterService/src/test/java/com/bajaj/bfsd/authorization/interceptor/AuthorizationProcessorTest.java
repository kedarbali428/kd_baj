package com.bajaj.bfsd.authorization.interceptor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicy;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicyMap;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLHttpException;

@RunWith(PowerMockRunner.class)
@PrepareForTest({BFLCommonRestClient.class})
public class AuthorizationProcessorTest {

	@InjectMocks
	AuthorizationProcessor authorizationProcessor;
	
	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	BFLAuthorizationPolicyMap authMap;

	@Mock
	CustomDefaultHeaders customHdrs;

	@Mock
	Environment env;
	
	@Before
	public void setUp() {
		authorizationProcessor = new AuthorizationProcessor();
		ReflectionTestUtils.setField(authorizationProcessor, "logger", logger);
		ReflectionTestUtils.setField(authorizationProcessor, "env", env);
		ReflectionTestUtils.setField(authorizationProcessor, "authMap", authMap);
		ReflectionTestUtils.setField(authorizationProcessor, "customHdrs", customHdrs);
	}
	
	@Test
	public void testisUserAuthorizedWithUriNull() {
		String uri = "https://www.example.com";
		authorizationProcessor.isUserAuthorized(uri, 1234L, "GET");
	}
	
	@Test
	public void testisUserAuthorizedWithPolicyNull() {
		String uri = "https://www.example.com";
		BFLAuthorizationPolicy policy = null;
		Mockito.when(authMap.getPolicy(uri)).thenReturn(policy);
		authorizationProcessor.isUserAuthorized(uri, 1234L, "GET");
	}
	
	@Test
	public void testisUserAuthorizedWithNoAuthorization() {
		String uri = "https://www.example.com";
		BFLAuthorizationPolicy policy = new BFLAuthorizationPolicy();
		policy.setIsAuthorizationRequired("N");
		Mockito.when(authMap.getPolicy(Mockito.any())).thenReturn(policy);
		authorizationProcessor.isUserAuthorized(uri, 1234L, "GET");
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = BFLHttpException.class)
	public void testisUserAuthorizedWithBFLHttpException() {
		String uri = "https://www.example.com";
		BFLAuthorizationPolicy policy = new BFLAuthorizationPolicy();
		policy.setIsAuthorizationRequired("Y");
		policy.setIsAuthenticationRequired("Y");
		policy.setRequestMethod("GET");
		policy.setRoles("ADMIN");
		Mockito.when(authMap.getPolicy(Mockito.any())).thenReturn(policy);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(
				(ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(null);
		authorizationProcessor.isUserAuthorized(uri, 1234L, "GET");
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testisUserAuthorizedWithAuthorization() {
		String uri = "https://www.example.com";
		BFLAuthorizationPolicy policy = new BFLAuthorizationPolicy();
		policy.setIsAuthorizationRequired("Y");
		policy.setIsAuthenticationRequired("Y");
		policy.setRequestMethod("GET");
		policy.setRoles("ADMIN");
		Mockito.when(authMap.getPolicy(Mockito.any())).thenReturn(policy);
		boolean payload =true;
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		PowerMockito.when(
				(ResponseEntity<ResponseBean>) BFLCommonRestClient.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
						Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity<>(new ResponseBean(payload), HttpStatus.OK));
		authorizationProcessor.isUserAuthorized(uri, 1234L, "GET");
	}
}
