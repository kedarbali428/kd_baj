package com.bajaj.markets.credit.business.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.beans.AppDocumentTrackingBean;
import com.bajaj.markets.credit.business.beans.ApplicationBFLDocsRequestBean;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationDocumentResponseBean;
import com.bajaj.markets.credit.business.beans.BFLDocument;
import com.bajaj.markets.credit.business.beans.CreditDocumentTypeBean;
import com.bajaj.markets.credit.business.beans.DocumentBean;
import com.bajaj.markets.credit.business.beans.DocumentPushResponseBean;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.InitiateDocumentPushRequest;
import com.bajaj.markets.credit.business.beans.PrincipalBean;
import com.bajaj.markets.credit.business.beans.ResponseBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessApplicationDocumentPushService;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class CreditBusinessApplicationDocumentPushServiceImpl implements CreditBusinessApplicationDocumentPushService {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CustomDefaultHeaders customHeaders;

	@Autowired
	PublisherService publisherService;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	public static final String CLASS_NAME = CreditBusinessApplicationDocumentPushServiceImpl.class.getCanonicalName();

	private ObjectMapper mapper = new ObjectMapper();

	@Value("${api.omcreditapplicationservice.transaction.get.url}")
	private String transactionGetURL;

	@Value("${api.omcreditapplicationservice.transaction.put.url}")
	private String transactionPutURL;
	
	@Value("${api.omcreditapplicationservice.master.get.url}")
	private String masterGetURL;

	@Value("${api.omcreditapplicationservice.product.get.url}")
	private String productGetURL;

	@Value("${api.omreferencedatareferencedataservice.principal.get.url}")
	private String principalURL;

	@Value("${api.documents.list.POST.url}")
	private String documentServiceUrl;

	@Value("${documentpush.queue}")
	private String queueName;

	private Long PRINCIPLE_KEY_PAYSENSE=15L;
	private Integer PAYSENSE_PERFIOS_XML_TYPE=12;
	
	@Override
	public DocumentPushResponseBean fetchDocumentPushDetails(Long applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start - fetchDocumentPushResponse for applicationId: " + applicationId);

		DocumentPushResponseBean documentPushResponseBean = new DocumentPushResponseBean();
		documentPushResponseBean.setApplicationKey(applicationId);
		ApplicationDetail applicationDetail = getProductDetails(applicationId, headers);
		Long principalKey = applicationDetail.getPrincipalKey();
		if (null == principalKey) {
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "PrincipalKey cannot be null");

		}
		documentPushResponseBean.setPrincipleKey(principalKey);
		documentPushResponseBean.setProductL2(applicationDetail.getL2ProductCode());
		documentPushResponseBean.setProductL3(applicationDetail.getL3ProductCode());
		documentPushResponseBean.setProductL4(applicationDetail.getL4ProductCode());
		documentPushResponseBean.setProductL2Desc(applicationDetail.getL2ProductDesc());
		documentPushResponseBean.setProductL3Desc(applicationDetail.getL3ProductDesc());
		documentPushResponseBean.setProductL4Desc(applicationDetail.getL4ProductDesc());

		PrincipalBean principalBean = fetchPartnerName(headers, principalKey);
		documentPushResponseBean.setPartnername(principalBean.getPrincipleName());
		
		List<BFLDocument> docList = fetchingDocument(PRINCIPLE_KEY_PAYSENSE.equals(principalKey) ? 
				Long.parseLong(applicationDetail.getParentApplicationKey()) : 
			applicationId, headers);
		List<AppDocumentTrackingBean> transactionResponse = getTransactionResponse(applicationId, headers);
		List<DocumentBean> documentBeanList = new ArrayList<>();

		List<CreditDocumentTypeBean> masterResponseList = getMasterResponse(principalKey, headers);
		if (masterResponseList.isEmpty()) {
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					"No document configured for this principal.");
		}
		for (CreditDocumentTypeBean masterResponse : masterResponseList) {
			BFLDocument document = docList.stream()
					.filter(x -> x.getDocCategoryCode().equals(masterResponse.getDoccatcode())
							&& x.getType().equals(masterResponse.getDoctypecode()) 
							&& x.getContentType().contains(masterResponse.getDocformat().trim()))
					.findFirst().orElse(null);

			int count=0;
			if(!(principalKey.equals(PRINCIPLE_KEY_PAYSENSE) && masterResponse.getCreditdoctype().equals(PAYSENSE_PERFIOS_XML_TYPE))) {
			for (DocumentBean existingBean:documentBeanList) {
				if(existingBean.getDocType().equals(masterResponse.getDoctypecode()) && existingBean.getDocAvalibale()) {
					count++;
					break;
				}
				if(existingBean.getDocType().equals(masterResponse.getDoctypecode()) && !existingBean.getDocAvalibale() && null!=document) {
					existingBean.setDocAvalibale(true);
					existingBean.setDocId(document.getDocId());
					existingBean.setPartnerDocName(masterResponse.getPartnerdocname());
					existingBean.setCreditdoctype(masterResponse.getCreditdoctype());
					count++;
					break;
				}
				
				if(existingBean.getDocType().equals(masterResponse.getDoctypecode()) && !existingBean.getDocAvalibale() && null==document) {
					count++;
					break;
				}
			}}
			if(0==count) {
				DocumentBean documentBean = populateDocumentBean(transactionResponse, masterResponse, document,masterResponseList);
				documentBeanList.add(documentBean);
			}

		}
		documentPushResponseBean.setDocumentbean(documentBeanList);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End - fetchDocumentPushResponse for applicationId: " + applicationId);

		return documentPushResponseBean;
	}

	private PrincipalBean fetchPartnerName(HttpHeaders headers, Long principalKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start - fetchPartnerName for principalKey: " + principalKey);
		List<PrincipalBean> principalBeanList = getPrincipalDetails(headers);
		PrincipalBean principalBean = new PrincipalBean();
		if (null != principalBeanList && null != principalKey) {
			principalBean = principalBeanList.stream().filter(x -> x.getPrinciplekey().equals(principalKey)).findFirst()
					.get();
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End - fetchPartnerName for principalKey: " + principalKey);
		return principalBean;
	}

	private DocumentBean populateDocumentBean(List<AppDocumentTrackingBean> transactionResponse,
			CreditDocumentTypeBean masterResponse, BFLDocument document, List<CreditDocumentTypeBean> masterResponseList) {
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start - populateDocumentBean ");
		DocumentBean documentBean = new DocumentBean();
		if (null != document) {

			documentBean.setDocId(document.getDocId());
			documentBean.setDocAvalibale(true);
		} else if(masterResponse.getCreditdoctype().equals(PAYSENSE_PERFIOS_XML_TYPE)){
			documentBean.setDocAvalibale(true);
		}else {
			documentBean.setDocAvalibale(false);
		}
		documentBean.setBfsdDocName(masterResponse.getBfsddocname());
		documentBean.setDocType(masterResponse.getDoctypecode());
		documentBean.setDocCategoryCode(masterResponse.getDoccatcode());
		AppDocumentTrackingBean transactionBean = null;

		if (null != transactionResponse) {
			List<CreditDocumentTypeBean> masterList = masterResponseList.stream()
					.filter(x -> x.getDoccatcode().equals(masterResponse.getDoccatcode())).collect(Collectors.toList());
			for (CreditDocumentTypeBean master : masterList) {
				transactionBean = transactionResponse.stream()
						.filter(x -> x.getCreditdoctype().equals(master.getCreditdoctype())).findFirst().orElse(null);
				if(null!=transactionBean)
					break;
			}

		}
		documentBean.setCreditdoctype(masterResponse.getCreditdoctype());
		if (null != transactionBean) {
			documentBean.setDocSentDate(transactionBean.getDocsentdate());
			documentBean.setDocumentPushStatus(transactionBean.getDocsentstatus());
		}

		documentBean.setPartnerDocName(masterResponse.getPartnerdocname());
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End - populateDocumentBean ");
		return documentBean;
	}

	private List<BFLDocument> fetchingDocument(Long applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start - fetchingDocument ");
		ApplicationBFLDocsRequestBean documentServiceRequestBean = new ApplicationBFLDocsRequestBean();
		documentServiceRequestBean.setApplicationId(applicationId);
		documentServiceRequestBean.setOmProductFlag(true);
		documentServiceRequestBean.setDocListType("ALL");
		ApplicationDocumentResponseBean documentServiceResponse = getDocumentServiceResponse(documentServiceRequestBean,
				headers);
		List<BFLDocument> docList = new ArrayList<>();
		if (null != documentServiceResponse) {

			docList.addAll(documentServiceResponse.getPrimaryApplicantDocs().getDocList());
			docList.addAll(documentServiceResponse.getPrimaryApplicantDocs().getPhysicalCollectionDocList());
			docList.addAll(documentServiceResponse.getPrimaryApplicantDocs().getCombinedEsignDocList());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End - fetchingDocument ");
		return docList;
	}

	@SuppressWarnings("unchecked")
	private ApplicationDetail getProductDetails(Long applicationId, HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start - getProductDetails for applicationId: " + applicationId);

		Map<String, String> params = new HashMap<String, String>();
		params.put("applicationid", applicationId.toString());
		Gson gson = new Gson();
		ApplicationDetail applicationDetail = new ApplicationDetail();
		ResponseEntity<String> response = (ResponseEntity<String>) creditBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, productGetURL, String.class, params, null, headers);
		if (null != response.getBody()) {
			applicationDetail = gson.fromJson(response.getBody(), ApplicationDetail.class);
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End - getProductDetails");

		return applicationDetail;
	}

	@SuppressWarnings("unchecked")
	private ApplicationDocumentResponseBean getDocumentServiceResponse(
			ApplicationBFLDocsRequestBean documentServiceRequestBean, HttpHeaders headers) {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside getDocumentServiceResponse with request: " + documentServiceRequestBean);
		ApplicationDocumentResponseBean docResponseJson = null;
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		String docReq;
		try {
			docReq = mapper.writeValueAsString(documentServiceRequestBean);
		} catch (JsonProcessingException e) {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Request cant be mapped " + e);
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_050", "Request cant be mapped"));

		}
		ResponseEntity<ResponseBean> docResponse = (ResponseEntity<ResponseBean>) creditBusinessHelper
				.invokeRestEndpoint(HttpMethod.POST, documentServiceUrl, ResponseBean.class, null, docReq, headers);
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Response from document service" + docResponse);
		if (null != docResponse && HttpStatus.OK.equals(docResponse.getStatusCode())) {

			docResponseJson = mapper.convertValue(docResponse.getBody().getPayload(),
					ApplicationDocumentResponseBean.class);
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Exiting getDocumentServiceResponse with response:  " + docResponseJson);
		return docResponseJson;
	}

	@SuppressWarnings("unchecked")
	private List<CreditDocumentTypeBean> getMasterResponse(Long principleKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start - getMasterResponse for principleKey: " + principleKey);

		Map<String, String> params = new HashMap<String, String>();
		params.put("principalkey", principleKey.toString());
		Gson gson = new Gson();
		List<CreditDocumentTypeBean> applicationDocumentPushMasterResponseBeanList = new ArrayList<>();
		ResponseEntity<String> response = (ResponseEntity<String>) creditBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, masterGetURL, String.class, params, null, headers);
		if (null != response.getBody()) {

			CreditDocumentTypeBean[] applicationDocumentPushMasterResponseBeans = gson.fromJson(response.getBody(),
					CreditDocumentTypeBean[].class);
			applicationDocumentPushMasterResponseBeanList = Arrays.asList(applicationDocumentPushMasterResponseBeans);
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End - getMasterResponse");

		return applicationDocumentPushMasterResponseBeanList;
	}

	@SuppressWarnings("unchecked")
	private List<AppDocumentTrackingBean> getTransactionResponse(Long applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start - getTransactionResponse for applicationId: " + applicationId);

		Map<String, String> params = new HashMap<String, String>();
		params.put("applicationid", applicationId.toString());
		Gson gson = new Gson();
		List<AppDocumentTrackingBean> appDocumentTrackingBeanList = new ArrayList<>();
		ResponseEntity<String> response = (ResponseEntity<String>) creditBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, transactionGetURL, String.class, params, null, headers);
		if (null != response.getBody()) {
			AppDocumentTrackingBean[] appDocumentTrackingBeans = gson.fromJson(response.getBody(),
					AppDocumentTrackingBean[].class);
			appDocumentTrackingBeanList = Arrays.asList(appDocumentTrackingBeans);
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End - getTransactionResponse");

		return appDocumentTrackingBeanList;
	}

	@SuppressWarnings("unchecked")
	private List<PrincipalBean> getPrincipalDetails(HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start - getPrinicipalDetails");

		Gson gson = new Gson();
		List<PrincipalBean> principalBeanList = new ArrayList<>();
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End - getPrinicipalDetails");
		ResponseEntity<String> response = (ResponseEntity<String>) creditBusinessHelper
				.invokeRestEndpoint(HttpMethod.GET, principalURL, String.class, null, null, headers);
		if (null != response.getBody()) {
			PrincipalBean[] principalBeans = gson.fromJson(response.getBody(), PrincipalBean[].class);
			principalBeanList = Arrays.asList(principalBeans);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End - getPrinicipalDetails");
		return principalBeanList;
	}

	@Override
	public List<AppDocumentTrackingBean> initiateDocumentPush(InitiateDocumentPushRequest initiateDocumentPushRequest,
			String source, HttpHeaders headers, Long applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start - initiateDocumentPush with request "
				+ initiateDocumentPushRequest + " applicationId " + applicationId);
		Boolean updateStatusflag = false;
		List<AppDocumentTrackingBean> appDocumentTrackingRequestList = new ArrayList<>();
		List<AppDocumentTrackingBean> transactionList = new ArrayList<>();
		if (source.equals("EP")) {
			appDocumentTrackingRequestList = initiateDocumentPushRequest.getAppDocumentTrackingBeanList();

		} else if (source.equalsIgnoreCase("JOURNEY")){
			DocumentPushResponseBean documentPushResponseBean = fetchDocumentPushDetails(applicationId, headers);
			List<DocumentBean> documentBeanList = documentPushResponseBean.getDocumentbean();
			for (DocumentBean documentBean : documentBeanList) {
				AppDocumentTrackingBean appDocumentTrackingBean = new AppDocumentTrackingBean();
				appDocumentTrackingBean.setCreditdoctype(documentBean.getCreditdoctype());
				appDocumentTrackingBean.setDocsentstatus("INITIATED");
				appDocumentTrackingBean.setDocsource(source);
				appDocumentTrackingBean.setDocsentby(customHeaders.getUserKey());
				appDocumentTrackingBean.setDocsentdate(new Timestamp(Calendar.getInstance().getTime().getTime()));
				if(documentBean.getDocAvalibale() || documentBean.getCreditdoctype().equals(PAYSENSE_PERFIOS_XML_TYPE)) {
					appDocumentTrackingRequestList.add(appDocumentTrackingBean);
				}
			}
		}
		
			transactionList = insertTransactionDetails(appDocumentTrackingRequestList, applicationId, headers,
					updateStatusflag);
		
		
		triggerEvent(initiateDocumentPushRequest, applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End - initiateDocumentPush");
		return transactionList;
	}

	private void triggerEvent(InitiateDocumentPushRequest initiateDocumentPushRequest, Long applicationId) {
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Raising event for applicationId: " + applicationId);
			EventMessage eventMessage = createEventMessage(applicationId, initiateDocumentPushRequest.getPrincipleKey(),
					initiateDocumentPushRequest.getPrincipleName());
			publisherService.publishToQueue(queueName, eventMessage);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Raised event");
		} catch (Exception e) {
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception while raising event");
		}
	}

	private EventMessage createEventMessage(Long applicationId, Long principleKey, String principleName) {
		Map<String, String> headersMap = new HashMap<>();
		headersMap.put("authtoken", customHeaders.getAuthtoken());
		headersMap.put("cmptcorrid", customHeaders.getCmptcorrid());
		headersMap.put("guardtoken", customHeaders.getGuardtoken());

		Map<String, String> payload = new HashMap<>();
		payload.put("applicationId", applicationId.toString());
		payload.put("principleKey", principleKey.toString());
		payload.put("principleName", principleName);
		EventMessage eventMessage = new EventMessage();
		eventMessage.setEventType("DOCUMENT_PUSH_INITIATED");
		eventMessage.setEventName("PRINCIPAL_DOCUMENT_PUSH");
		eventMessage.setPayload(payload);
		eventMessage.setHeaders(headersMap);
		return eventMessage;
	}

	@SuppressWarnings("unchecked")
	private List<AppDocumentTrackingBean> insertTransactionDetails(
			List<AppDocumentTrackingBean> appDocumentTrackingBeanList, Long applicationId, HttpHeaders headers,
			Boolean updateStatusflag) {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside insertTransactionDetails with request: " + appDocumentTrackingBeanList);
		List<AppDocumentTrackingBean> responseJson = null;
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		String transReq;
		Map<String, String> params = new HashMap<String, String>();
		params.put("applicationid", applicationId.toString());
		params.put("updatestatusflag", updateStatusflag.toString());
		try {
			transReq = mapper.writeValueAsString(appDocumentTrackingBeanList);
		} catch (JsonProcessingException e) {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Request cant be mapped " + e);
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_050", "Request cant be mapped"));

		}
		try {
			
			ResponseEntity<String> response = (ResponseEntity<String>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.PUT, transactionPutURL, String.class, params, transReq, headers);
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Response from document service" + response);
			Gson gson = new Gson();
			if (null != response && HttpStatus.OK.equals(response.getStatusCode())) {

				AppDocumentTrackingBean[] appDocumentTrackingBeans = gson.fromJson(response.getBody(),
						AppDocumentTrackingBean[].class);
				responseJson = Arrays.asList(appDocumentTrackingBeans);
			}
			
		}
		catch(Exception e) {
			CreditBusinessException exc=(CreditBusinessException)e;
			String message;
			if(null!=exc.getPayload()) {
				message=exc.getPayload().toString();
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, exc.getPayload().toString());
			}else {
				message="Technical exception occured.";
			}
			ErrorBean errorBean=new ErrorBean("OMCB-1001", message.toString());
			throw new CreditBusinessException(HttpStatus.NOT_FOUND,errorBean);
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Exiting insertTransactionDetails with response:  " + responseJson);
		return responseJson;
	}
	
	

}
