package com.bajaj.markets.credit.business.helper;

import java.util.HashMap;
import java.util.Map;

public enum OMProductToBauProduct {

	SALR("SOL"), SEMP("DBOL"), HLF("BHFLHLF"), HLBT("BHFLHLBT"), LAP("BHFLLAP"), LAPBT("BHFLLAPBT");

	private final String value;

	private OMProductToBauProduct(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

	private static final Map<String, String> lookup = new HashMap<>();

	static {
		for (OMProductToBauProduct d : OMProductToBauProduct.values()) {
			lookup.put(d.name(), d.getValue());
		}
	}

	public static String getBauProd(String omProdKey) {
		return lookup.get(omProdKey);
	}


}
