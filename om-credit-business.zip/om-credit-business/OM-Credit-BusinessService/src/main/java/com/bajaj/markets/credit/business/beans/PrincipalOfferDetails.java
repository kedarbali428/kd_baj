package com.bajaj.markets.credit.business.beans;

import java.util.Date;
import java.util.List;

public class PrincipalOfferDetails {

	private String accountNumber; 
	private String accountOpeningDate; 
	private String cardNumber; 
	private String cardLimit; 
	private String cardFees; 
	private List<CorporateOffer> corporateOffer; 
	private List<Promo> promo; 
	private String productCode; 
	private String productType; 
	private List<ProductOffer> productOffer; 
	private Date offerLoadDateTime; 
	private Object additionalOfferDetails; 
	private List<ProductUsageType> productUsageType;
	private String offerType;
	private Date offerStartDate;
	private Date offerExpiryDate;
	private String productHolder;
	private String sourcingType;
	private String productRiskBands;
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountOpeningDate() {
		return accountOpeningDate;
	}
	public void setAccountOpeningDate(String accountOpeningDate) {
		this.accountOpeningDate = accountOpeningDate;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardLimit() {
		return cardLimit;
	}
	public void setCardLimit(String cardLimit) {
		this.cardLimit = cardLimit;
	}
	public String getCardFees() {
		return cardFees;
	}
	public void setCardFees(String cardFees) {
		this.cardFees = cardFees;
	}
	public List<CorporateOffer> getCorporateOffer() {
		return corporateOffer;
	}
	public void setCorporateOffer(List<CorporateOffer> corporateOffer) {
		this.corporateOffer = corporateOffer;
	}
	public List<Promo> getPromo() {
		return promo;
	}
	public void setPromo(List<Promo> promo) {
		this.promo = promo;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public List<ProductOffer> getProductOffer() {
		return productOffer;
	}
	public void setProductOffer(List<ProductOffer> productOffer) {
		this.productOffer = productOffer;
	}
	public Object getAdditionalOfferDetails() {
		return additionalOfferDetails;
	}
	public void setAdditionalOfferDetails(Object additionalOfferDetails) {
		this.additionalOfferDetails = additionalOfferDetails;
	}
	public List<ProductUsageType> getProductUsageType() {
		return productUsageType;
	}
	public void setProductUsageType(List<ProductUsageType> productUsageType) {
		this.productUsageType = productUsageType;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public Date getOfferLoadDateTime() {
		return offerLoadDateTime;
	}
	public void setOfferLoadDateTime(Date offerLoadDateTime) {
		this.offerLoadDateTime = offerLoadDateTime;
	}
	public Date getOfferStartDate() {
		return offerStartDate;
	}
	public void setOfferStartDate(Date offerStartDate) {
		this.offerStartDate = offerStartDate;
	}
	public Date getOfferExpiryDate() {
		return offerExpiryDate;
	}
	public void setOfferExpiryDate(Date offerExpiryDate) {
		this.offerExpiryDate = offerExpiryDate;
	}
	public String getProductHolder() {
		return productHolder;
	}
	public void setProductHolder(String productHolder) {
		this.productHolder = productHolder;
	}
	public String getSourcingType() {
		return sourcingType;
	}
	public void setSourcingType(String sourcingType) {
		this.sourcingType = sourcingType;
	}
	public String getProductRiskBands() {
		return productRiskBands;
	}
	public void setProductRiskBands(String productRiskBands) {
		this.productRiskBands = productRiskBands;
	}
	@Override
	public String toString() {
		return "PrincipalOfferDetails [accountNumber=" + accountNumber + ", accountOpeningDate=" + accountOpeningDate
				+ ", cardNumber=" + cardNumber + ", cardLimit=" + cardLimit + ", cardFees=" + cardFees
				+ ", corporateOffer=" + corporateOffer + ", promo=" + promo + ", productCode=" + productCode
				+ ", productType=" + productType + ", productOffer=" + productOffer + ", offerLoadDateTime="
				+ offerLoadDateTime + ", additionalOfferDetails=" + additionalOfferDetails + ", productUsageType="
				+ productUsageType + ", offerType=" + offerType + ", offerStartDate=" + offerStartDate
				+ ", offerExpiryDate=" + offerExpiryDate + ", productHolder=" + productHolder + ", sourcingType="
				+ sourcingType + ", productRiskBands=" + productRiskBands + "]";
	}
}