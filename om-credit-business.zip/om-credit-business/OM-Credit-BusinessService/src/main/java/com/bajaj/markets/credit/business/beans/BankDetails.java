package com.bajaj.markets.credit.business.beans;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.bajaj.markets.credit.business.beans.validator.ValidAccountType;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Back;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Next;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class BankDetails {
	
	@NotBlank(groups = Next.class, message = "account number can not be null")
	@Size(groups = Next.class, max = 18, min = 8, message = "account number is not valid")
	@Digits(groups = Next.class, integer = 18, fraction = 0, message = "account number is not valid")
	private String accountNumber;
	
	@NotBlank(groups = Next.class, message = "ifscCode can not be null")
	private String ifscCode;
	
	private BankMaster bank;
	
	private String bankAccountHolderName;
	
	@ValidAccountType(groups = Next.class)
	private String bankAccountTypeKey;
	
	private Boolean bankDetailsEditable;
	
	private Boolean accountNumberEdited;
	
	private String mandateAddedBy;
	
	private String mandateReference;
	
	@NotBlank(groups = Back.class, message = "action is not valid")
	private String action;
	
	@JsonIgnore
	private String repaymentMode;

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public void setBank(BankMaster bank) {
		this.bank = bank;
	}

	public void setBankAccountHolderName(String bankAccountHolderName) {
		this.bankAccountHolderName = bankAccountHolderName;
	}

	public void setBankAccountType(String bankAccountType) {
		this.bankAccountTypeKey = bankAccountType;
	}

	public void setBankDetailsEditable(Boolean bankDetailsEditable) {
		this.bankDetailsEditable = bankDetailsEditable;
	}

	public void setAccountNumberEdited(Boolean accountNumberEdited) {
		this.accountNumberEdited = accountNumberEdited;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public BankMaster getBank() {
		return bank;
	}

	public String getBankAccountHolderName() {
		return bankAccountHolderName;
	}

	public String getBankAccountType() {
		return bankAccountTypeKey;
	}

	public String getMandateAddedBy() {
		return mandateAddedBy;
	}

	public void setMandateAddedBy(String mandateAddedBy) {
		this.mandateAddedBy = mandateAddedBy;
	}

	public String getMandateReference() {
		return mandateReference;
	}

	public void setMandateReference(String mandateReference) {
		this.mandateReference = mandateReference;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	
	public String getRepaymentMode() {
		return repaymentMode;
	}

	public void setRepaymentMode(String repaymentMode) {
		this.repaymentMode = repaymentMode;
	}
	
	public Boolean getBankDetailsEditable() {
		return bankDetailsEditable;
	}

	public Boolean getAccountNumberEdited() {
		return accountNumberEdited;
	}

	@Override
	public String toString() {
		return "BankDetails [accountNumber=" + accountNumber + ", ifscCode=" + ifscCode + ", bank=" + bank
				+ ", bankAccountHolderName=" + bankAccountHolderName + ", bankAccountTypeKey=" + bankAccountTypeKey
				+ ", bankDetailsEditable=" + bankDetailsEditable + ", accountNumberEdited=" + accountNumberEdited
				+ ", mandateAddedBy=" + mandateAddedBy + ", mandateReference=" + mandateReference + ", action=" + action
				+ ", repaymentMode=" + repaymentMode + "]";
	}

}
