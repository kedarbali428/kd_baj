package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.util.List;

public class CibilResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long cibilReferenceNumber;
	private String provider;
	private Long applicantKey;
	private Long applicationKey;
	private boolean authenticationRequired;
	private String state;
	private String cibilReport;
	private List<CibilTypeAndScore> cibilTypeAndScore;
	
	public void setCibilReferenceNumber(long cibilReferenceNumber) {
		this.cibilReferenceNumber = cibilReferenceNumber;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public void setAuthenticationRequired(boolean authenticationRequired) {
		this.authenticationRequired = authenticationRequired;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setCibilReport(String cibilReport) {
		this.cibilReport = cibilReport;
	}

	public long getCibilReferenceNumber() {
		return cibilReferenceNumber;
	}

	public String getState() {
		return state;
	}

	public List<CibilTypeAndScore> getCibilTypeAndScore() {
		return cibilTypeAndScore;
	}

	public void setCibilTypeAndScore(List<CibilTypeAndScore> cibilTypeAndScore) {
		this.cibilTypeAndScore = cibilTypeAndScore;
	}

	@Override
	public String toString() {
		return "[cibilReferenceNumber:" + cibilReferenceNumber + ", provider:" + provider + ", applicantKey:" + applicantKey + ", applicationKey:"
				+ applicationKey + ", authenticationRequired:" + authenticationRequired + ", state:" + state + ", cibilReport:" + cibilReport + "]";
	}

}
