package com.bajaj.markets.credit.business.beans;

public class EmployerTypeBean {

	private Long employertypekey;

	private String employertypecode;

	public Long getEmployertypekey() {
		return employertypekey;
	}

	public void setEmployertypekey(Long employertypekey) {
		this.employertypekey = employertypekey;
	}

	public String getEmployertypecode() {
		return employertypecode;
	}

	public void setEmployertypecode(String employertypecode) {
		this.employertypecode = employertypecode;
	}

}
