package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class OccupationReference implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long occupationKey;

	private String occupationCode;

	private String occupationValue;

	private Integer isactive;

	public Long getOccupationKey() {
		return occupationKey;
	}

	public void setOccupationKey(Long occupationKey) {
		this.occupationKey = occupationKey;
	}

	public String getOccupationCode() {
		return occupationCode;
	}

	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}

	public String getOccupationValue() {
		return occupationValue;
	}

	public void setOccupationValue(String occupationValue) {
		this.occupationValue = occupationValue;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

}
