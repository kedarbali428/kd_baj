package com.bajaj.markets.credit.business.config;

import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

	@Value("${omcreditbusinessservice.httpclient.maxConnectionsPerRoute}")
	private int maxConnectionsPerRoute;

	@Value("${omcreditbusinessservice.httpclient.maxConnections}")
	private int maxConnections;

	@Bean
	public HttpClientConnectionManager httpClientConnectionManager() {
		PoolingHttpClientConnectionManager poolingConnectionManager = new PoolingHttpClientConnectionManager();
		poolingConnectionManager.setDefaultMaxPerRoute(maxConnectionsPerRoute);
		poolingConnectionManager.setMaxTotal(maxConnections);
		return poolingConnectionManager;
	}

	@Bean
	@Primary
	public RestTemplate restTemplate(@Autowired HttpClientConnectionManager httpClientConnectionManager) {
		CloseableHttpClient httpClient = HttpClients.custom().useSystemProperties().setConnectionManager(httpClientConnectionManager)
				.disableCookieManagement().build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		return new RestTemplate(requestFactory);
	}

	@Bean
	public HttpConnectionPoolMXBean httpConnectionPool(
			@Autowired PoolingHttpClientConnectionManager httpClientConnectionManager) {
		return new HttpConnectionPoolMXBean(httpClientConnectionManager);
	}

	@ManagedResource
	public static class HttpConnectionPoolMXBean {

		private PoolingHttpClientConnectionManager poolingConnectionManager;

		public HttpConnectionPoolMXBean(PoolingHttpClientConnectionManager poolingConnectionManager) {
			this.poolingConnectionManager = poolingConnectionManager;
		}

		@ManagedAttribute
		public int getActiveHttpConnections() {
			return this.poolingConnectionManager.getTotalStats().getLeased();
		}

		@ManagedAttribute
		public int getThreadsAwaitingHttpConnections() {
			return this.poolingConnectionManager.getTotalStats().getPending();
		}

		@ManagedAttribute
		public int getIdleHttpConnections() {
			return this.poolingConnectionManager.getTotalStats().getAvailable();
		}

		@ManagedAttribute
		public int getTotalHttpConnectionsPerRoute() {
			return this.poolingConnectionManager.getDefaultMaxPerRoute();
		}

		@ManagedAttribute
		public int getTotalHttpConnections() {
			return this.poolingConnectionManager.getMaxTotal();
		}

		@ManagedOperation
		public void setTotalHttpConnectionsPerRoute(int maxPerRoute) {
			this.poolingConnectionManager.setDefaultMaxPerRoute(maxPerRoute);
		}

		@ManagedOperation
		public void setTotalHttpConnections(int maxTotal) {
			this.poolingConnectionManager.setMaxTotal(maxTotal);
		}
	}
}
