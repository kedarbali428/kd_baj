package com.bajaj.markets.credit.business.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.PanValidationRequest;
import com.bajaj.markets.credit.business.beans.PanValidationResponse;
import com.bajaj.markets.credit.business.beans.PanVerificationStatusEnum;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessPanVerificationService;

@Component
public class CreditBusinessPanVerificationServiceImpl implements CreditBusinessPanVerificationService {
	
	private static final String ERROR_CODE_OMCB_1153 = "OMCB-1153";
	private static final String ERROR_CODE_OMCB_1152 = "OMCB-1152";
	private static final String ERROR_CODE_OMCB_1151 = "OMCB-1151";
	private static final String USERATTRIBUTEKEY = "userattributekey";
	private static final String APPLICATIONID = "applicationid";
	private static final String DOCUMENT_NUMBER = "documentNumber";
	private static final String DOCUMENT_NAME_KEY = "documentNameKey";
	private static final String IS_VERIFIED = "isVerified";
	private static final String VERIFICATION = "verification";
	private static final String L2_PRODUCT_KEY = "l2ProductKey";
	private static final String L2_PRODUCT_CODE = "l2ProductCode";
	private static final String PAN_NUMBER = "panNumber";
	private static final String APPLICANT_KEY = "applicantKey";
	private static final String APPLICATION_KEY = "applicationKey";
	private static final String NAME_RECIEVED = "nameRecieved";

	private static final String CLASS_NAME = CreditBusinessPanVerificationServiceImpl.class.getCanonicalName();
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private CreditBusinessApiCallsHelper apiCallHelper;
	
	@Autowired
	private CreditBusinessHelper businessHelper;
	
	@Value("${api.omverificationverificationdomainservice.verifypan.post.url}")
	private String panVerificationUrl;
	
	@Value("${api.omcreditapplicationservice.updatedocumentdetails.put.url}")
	private String panDocumentUrl;

	@Override
	public PanValidationResponse validateAndUpdatePan(Long applicationId, PanValidationRequest panValidationRequest) {
		try {
			PanValidationResponse panValidationResponse = new PanValidationResponse();
			panValidationResponse.setVerificationStatus(PanVerificationStatusEnum.NOT_VERIFIED);
			Map<String, String> params = new HashMap<>();
			params.put(APPLICATIONID, applicationId.toString());
			ApplicationDetail applicationDetail = apiCallHelper.getApplicationDetails(applicationId.toString(), new HttpHeaders());
			UserProfileBean userProfile = apiCallHelper.getUserProfile(params, "1", false);
			if (null != userProfile) {
				// update pan nubmer to application attribute
				this.updatePan(panValidationRequest, userProfile);
				// verify pan with NSDL (Pan verificaiton domain service API)
				JSONObject panVerificationResponse = this.callPanVerificationApi(panValidationRequest, applicationDetail, userProfile);
				if (isPanVerified(panVerificationResponse)) {
					String nameAsperPan = businessHelper
							.removeNullFromGivenString(null != panVerificationResponse.get(NAME_RECIEVED)
									? panVerificationResponse.get(NAME_RECIEVED).toString(): null);
					panValidationResponse.setNameAsPerPan(nameAsperPan);
					panValidationResponse.setVerificationStatus(PanVerificationStatusEnum.VERIFIED);
				} else {
					logger.warn(CLASS_NAME, BFLLoggerComponent.SERVICE, "Pan not verified for: " + applicationId);
				}
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Profile details not available for: " + applicationId);
				throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(ERROR_CODE_OMCB_1151, env.getProperty(ERROR_CODE_OMCB_1151)));
			}
			return panValidationResponse;
		} catch (CreditBusinessException businessException) {
			throw businessException;
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while validating PAN for: " + applicationId + " and pan: " + panValidationRequest.getPanNumber());
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(ERROR_CODE_OMCB_1152, env.getProperty(ERROR_CODE_OMCB_1152)));
		}
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject callPanVerificationApi(PanValidationRequest panValidationRequest, ApplicationDetail applicationDetails, UserProfileBean userProfile) {
		JSONObject panVerificationRequest = new JSONObject();
		panVerificationRequest.put(APPLICATION_KEY, applicationDetails.getApplicationKey());
		panVerificationRequest.put(APPLICANT_KEY, applicationDetails.getApplicantKey());
		panVerificationRequest.put(PAN_NUMBER, panValidationRequest.getPanNumber());
		panVerificationRequest.put(L2_PRODUCT_CODE, applicationDetails.getL2ProductCode());
		panVerificationRequest.put(L2_PRODUCT_KEY, applicationDetails.getL2ProductKey());
		
		ResponseEntity<?> panVerificationResponseEntity = businessHelper.invokeRestEndpoint(HttpMethod.POST, panVerificationUrl,
				String.class, null, panVerificationRequest.toString(), new HttpHeaders());
		
		if (null != panVerificationResponseEntity.getBody() && HttpStatus.CREATED.equals(panVerificationResponseEntity.getStatusCode())) {
			return CreditBusinessHelper.getJSONObject(panVerificationResponseEntity.getBody());
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Pan verification did not return success response for: " + applicationDetails.getApplicationKey());
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(ERROR_CODE_OMCB_1153, env.getProperty(ERROR_CODE_OMCB_1153)));
		}
	}
	
	private boolean isPanVerified(JSONObject panVerificationResponse) {
		boolean isPanVerified = Boolean.FALSE;
		if (null != panVerificationResponse && null != panVerificationResponse.get(VERIFICATION)) {
			JSONObject verification = CreditBusinessHelper.getJSONObject(panVerificationResponse.get(VERIFICATION));
			if (null != verification && null != verification.get(IS_VERIFIED)) {
				isPanVerified = Boolean.valueOf(verification.get(IS_VERIFIED).toString()); 
			}
		}
		return isPanVerified;
	}
	
	@SuppressWarnings("unchecked")
	private void updatePan(PanValidationRequest panValidationRequest, UserProfileBean userProfile) {
		JSONObject documentUpdateRequest = new JSONObject();
		documentUpdateRequest.put(DOCUMENT_NAME_KEY, 1);
		documentUpdateRequest.put(DOCUMENT_NUMBER, panValidationRequest.getPanNumber());

		Map<String, String> params = new HashMap<>();
		params.put(APPLICATIONID, userProfile.getApplicationKey());
		params.put(USERATTRIBUTEKEY, userProfile.getApplicationUserAttributeKey());
		
		ResponseEntity<?> panVerificationResponseEntity = businessHelper.invokeRestEndpoint(HttpMethod.PUT, panDocumentUrl,
				String.class, params, documentUpdateRequest.toString(), new HttpHeaders());
		
		if (null != panVerificationResponseEntity && HttpStatus.OK.equals(panVerificationResponseEntity.getStatusCode())) {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Pan document updated successfully with application attribute: " 
					+ userProfile.getApplicationUserAttributeKey());
		}
	}
}
