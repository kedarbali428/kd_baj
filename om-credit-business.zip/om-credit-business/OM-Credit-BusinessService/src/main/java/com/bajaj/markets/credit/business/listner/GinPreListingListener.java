package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_JSON;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CITY_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.FULLNAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.GIN_ASYCNH_ANALYTICS_FLOW_FLAG;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2_PRODUCT_CODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OCCUPATIONTYPECODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PINCODEBEAN;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PINCODEKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.USERPROFILEOUTPUT;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.EmployerMasterBean;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.EtbVariantEnum;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.referencedataclientlib.bean.CacheServiceException;
import com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Component
public class GinPreListingListener {

	static final String APPSCORE_TASKID = "ginAppScore";
	static final String UPDATEAPPSCORE_TASKID = "ginUpdateAppScoreResp";
	static final String DEROG_TASKID = "ginDerog";
	static final String OBLIGATIONGET_TASKID = "ginObligationGet";
	static final String OBLIGATIONSAVE_TASKID = "ginObligationSave";

	@Autowired
	MasterDataRedisClientHelper redisHelper;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessGinHelper ginHelper;

	@Autowired
	private Executor customExecutor;

	@Autowired
	private WorkflowHelper workflowHelper;

	@Value("${etb.gin.analyticsflow.asychflag}")
	private boolean ginAnalyticsFlowAsychflag;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallHelper;

	private static final String CLASS_NAME = GinPreListingListener.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void personalPanVerifyPre(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start personalPanPre");
		JSONObject userProfile = CreditBusinessHelper.getJSONObject(execution.getVariable(USERPROFILEOUTPUT));
		String pan = userProfile.get(CreditBusinessConstants.PAN_NUMBER) != null ? userProfile.get(CreditBusinessConstants.PAN_NUMBER).toString() : null;
		JSONObject panUpdatePayload = new JSONObject();
		panUpdatePayload.put("panNumber", pan);
		panUpdatePayload.put("applicationKey", execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		panUpdatePayload.put("applicantKey", execution.getVariable(CreditBusinessConstants.APPLICANTID));
		panUpdatePayload.put("fullName", execution.getVariable(FULLNAME));
		panUpdatePayload.put("l2ProductKey", execution.getVariable(CreditBusinessConstants.L2_PRODUCT_KEY));
		panUpdatePayload.put("l2ProductCode", execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE));
		execution.setVariable(PAYLOAD, panUpdatePayload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End personalPanPre");
	}

	@SuppressWarnings("unchecked")
	public void preAppScore(DelegateExecution execution) throws JsonMappingException, JsonProcessingException {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAppScore");
		JSONObject appScoreRequest = new JSONObject();
		LocationResponseBean pincode = (LocationResponseBean) execution.getVariable(PINCODEBEAN);

		JSONObject cibilJson = CreditBusinessHelper.getJSONObject(execution.getVariable(CIBIL_JSON));
		JSONObject userProfile = CreditBusinessHelper.getJSONObject(execution.getVariable(USERPROFILEOUTPUT));

		String resiTypeCode = "";
		String maritialStatusCode = null;
		
		if (userProfile.get("residenceTypeKey") != null) {
			Long residenceTypeKey = Double.valueOf(userProfile.get("residenceTypeKey").toString()).longValue();
			resiTypeCode = redisHelper.findResitypeByKey(residenceTypeKey).getResidenceCode();
		}

		if (userProfile.get("maritalStatusKey") != null) {
			Long maritalStatusKey = Double.valueOf(userProfile.get("maritalStatusKey").toString()).longValue();
			maritialStatusCode = redisHelper.findMaritailStatusByKey(maritalStatusKey).getMaritalStatusValue();
		}
		appScoreRequest.put(CreditBusinessConstants.RESIDENCE_STATUS, resiTypeCode);
		appScoreRequest.put(CreditBusinessConstants.MARITALSTATUS, maritialStatusCode);
		appScoreRequest.put(CreditBusinessConstants.CITY, pincode.getCityName());
		appScoreRequest.put(CreditBusinessConstants.APPLICANT_ID, "1234");
		appScoreRequest.put(CreditBusinessConstants.APPLICATIONID, execution.getVariable(APPLICATION_ID));
		appScoreRequest.put(CreditBusinessConstants.CIBIL_RESPONSE, cibilJson);
		appScoreRequest.put(CreditBusinessConstants.L2_PRODUCT_CODE, execution.getVariable(L2_PRODUCT_CODE));
		appScoreRequest.put(CreditBusinessConstants.OCCUPATION_TYPE, execution.getVariable(OCCUPATIONTYPECODE));

		execution.setVariable(APPSCORE_TASKID.concat("_" + PAYLOAD), appScoreRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preAppScore");
	}

	public void postAppScore(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postAppScore");
		JSONObject appScoreResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(APPSCORE_TASKID.concat("_" + OUTPUT)));
		execution.setVariable(CreditBusinessConstants.APPSCORE, null);
		execution.setVariable(CreditBusinessConstants.LRSCORE, null);
		execution.setVariable(CreditBusinessConstants.MLSCORE, null);
		execution.setVariable(CreditBusinessConstants.LRSCOREV2, null);
		execution.setVariable(CreditBusinessConstants.APPSCORE_UPDATE, Boolean.FALSE);
		if (null != appScoreResponse) {
			String appscore = null != appScoreResponse.get(CreditBusinessConstants.FINALSCORE)
					? String.valueOf(((Double) appScoreResponse.get(CreditBusinessConstants.FINALSCORE)).intValue())
					: null;
			if (!StringUtils.isEmpty(appscore) || null != appScoreResponse.get("hmlScoreDetails")) {
				execution.setVariable(CreditBusinessConstants.APPSCORE, appscore);
				execution.setVariable(CreditBusinessConstants.LRSCORE,
						null != appScoreResponse.get(CreditBusinessConstants.LRSCORE)
								? String.valueOf(((Double) appScoreResponse.get(CreditBusinessConstants.LRSCORE)).intValue())
								: null);
				execution.setVariable(CreditBusinessConstants.MLSCORE,
						null != appScoreResponse.get(CreditBusinessConstants.MLSCORE)
								? String.valueOf(((Double) appScoreResponse.get(CreditBusinessConstants.MLSCORE)).intValue())
								: null);
				execution.setVariable(CreditBusinessConstants.LRSCOREV2,
						null != appScoreResponse.get(CreditBusinessConstants.LRSCOREV2)
								? String.valueOf(((Double) appScoreResponse.get(CreditBusinessConstants.LRSCOREV2)).intValue())
								: null);
				execution.setVariable(CreditBusinessConstants.APPSCORE_UPDATE, Boolean.TRUE);
			}

		}
		execution.setVariable(UPDATEAPPSCORE_TASKID.concat("_" + PAYLOAD), appScoreResponse);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postAppScore");
	}

	@SuppressWarnings("unchecked")
	public void preDerog(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDerog");
		LocationResponseBean pincode = (LocationResponseBean) execution.getVariable(PINCODEBEAN);

		JSONObject derogRequest = new JSONObject();
		JSONObject cibilJson = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.CIBIL_JSON));
		String l2ProductCode = execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE).toString();
		derogRequest.put(CreditBusinessConstants.APP_SCORE, execution.getVariable(CreditBusinessConstants.APPSCORE));
		derogRequest.put(CreditBusinessConstants.APPLICANT_ID, null);
		derogRequest.put(CreditBusinessConstants.APPLICATIONID, execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		derogRequest.put(CreditBusinessConstants.BRANCHNAME, pincode.getCityName());
		derogRequest.put(CreditBusinessConstants.CIBILRESPONSEJSON, cibilJson);
		derogRequest.put(CreditBusinessConstants.CUSTOMERID, null);
		derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, execution.getVariable(CreditBusinessConstants.OCCUPATION_TYPE));
		derogRequest.put(CreditBusinessConstants.SOURCE, CreditBusinessConstants.COMMERCIAL_CIBIL);
		execution.setVariable(DEROG_TASKID.concat("_" + PAYLOAD), derogRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preDerog");
	}

	public void postDerog(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postDerog");
		execution.setVariable(CreditBusinessConstants.DEROG_JSON, execution.getVariable(DEROG_TASKID.concat("_" + OUTPUT)));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postDerog");
	}

	@SuppressWarnings("unchecked")
	public void preGetObligation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preGetObligation");
		LocationResponseBean pincode = (LocationResponseBean) execution.getVariable(PINCODEBEAN);

		JSONObject payload = new JSONObject();
		payload.put("appScore", execution.getVariable("appscore"));
		payload.put("applicationId", execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		payload.put("branchName", pincode.getCityName());
		payload.put("cibilResponseJSON", CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.CIBIL_JSON)));
		payload.put("productType", execution.getVariable(CreditBusinessConstants.L2_PRODUCT_DESC));
		payload.put("applicantId", execution.getVariable(CreditBusinessConstants.APPLICANTID));
		payload.put("customerId", execution.getVariable(CreditBusinessConstants.APPLICANTID));
		execution.setVariable(OBLIGATIONGET_TASKID.concat("_" + PAYLOAD), payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preGetObligation");
	}

	public void postGetObligation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetObligation");
		execution.setVariable(CreditBusinessConstants.OBLIGATION_AMT, execution.getVariable(OBLIGATIONGET_TASKID.concat("_" + OUTPUT)));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetObligation");
	}

	@SuppressWarnings("unchecked")
	public void preSaveObligation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preSaveObligation");
		JSONObject payload = new JSONObject();
		payload.put("applicationKey", execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		JSONObject obligationJSON = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OBLIGATION_AMT));
		if (null != obligationJSON) {
			payload.put("obligationAmount", null != obligationJSON.get("emiSum") ? obligationJSON.get("emiSum").toString() : "0.0");
		} else {
			payload.put("obligationAmount", "0.0");
		}
		payload.put("obligationSource", "ANALYTICS_API");
		execution.setVariable(OBLIGATIONSAVE_TASKID.concat("_" + PAYLOAD), payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preSaveObligation");
	}

	public void postGetAddress(DelegateExecution execution) {
		JSONObject addrObject = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
		execution.setVariable(PINCODEKEY, addrObject.get(PINCODEKEY));
	}

	public void fetchPincodeBean(DelegateExecution execution) {
		Long pincodeKey = Long.parseLong(execution.getVariable(CreditBusinessConstants.PINCODEKEY).toString());
		LocationResponseBean locationResponseBean = redisHelper.getPinCodeByKey(pincodeKey);
		execution.setVariable(PINCODEBEAN, locationResponseBean);
	}

	public void fetchEmployerBean(DelegateExecution execution) throws JsonMappingException, CacheServiceException, JsonProcessingException {
		Long employerKey = Long.parseLong(execution.getVariable(CreditBusinessConstants.EMPLOYERID).toString());
		EmployerMasterBean employerMaster = redisHelper.getEmployerByKey(employerKey);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start fetchEmployerBean");
		execution.setVariable(CreditBusinessConstants.KID_PRESENT, false);
		execution.setVariable(CreditBusinessConstants.EMPLOYER_KID, null);
		execution.setVariable(CreditBusinessConstants.EMPLOYER_NAME, null);
		if (employerMaster != null) {
			execution.setVariable(CreditBusinessConstants.EMPRMASTCATEGORY, employerMaster.getEmprMastCategory());
			execution.setVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY, employerMaster.getEmprMastSubcategory());
			execution.setVariable(CreditBusinessConstants.EMPLOYER_NAME, employerMaster.getEmprMasterName());

			if (employerMaster.getEmployerKid() != null) {
				execution.setVariable(CreditBusinessConstants.KID_PRESENT, true);
				execution.setVariable(CreditBusinessConstants.EMPLOYER_KID, employerMaster.getEmployerKid());
			}

		}
	}

	public void checkGinOffer(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start checkGinOffer");
		execution.setVariable(CreditBusinessConstants.IS_GIN_OFFER, false);
		execution.setVariable(CreditBusinessConstants.IS_NONGIN_ETB_OFFER, false);
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject profession = CreditBusinessHelper.getJSONObject(request.get("profession"));
		Long occupationKey = profession!=null?Double.valueOf(profession.get("key").toString()).longValue():null;
		String l2ProductCode = request.get("productCode").toString();
		if (null!=occupationKey && 1 == occupationKey && CreditBusinessConstants.PRODUCT_CODE_OMPL.equalsIgnoreCase(l2ProductCode)) {
			Long appId = Double.valueOf(execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString()).longValue();

			EtbVariantEnum etbVariant = ginHelper.checkEtbVariantFromAppOfferDet(appId.toString(), occupationKey, l2ProductCode);
			Boolean isEtb = ginHelper.checkIsEtbCustomer(appId.toString());
			if ((null != etbVariant && etbVariant.equals(EtbVariantEnum.NONGIN) && null != isEtb
					&& isEtb.booleanValue()) || (null == etbVariant && null != isEtb && isEtb.booleanValue())) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,"NON-GIN flow is TRUE processing NON GIN ETB journey");
				execution.setVariable(CreditBusinessConstants.CIBIL_TYPE,CreditBusinessConstants.CIBIL_TYPE_COMMERCIAL);
				execution.setVariable(CreditBusinessConstants.IS_NONGIN_ETB_OFFER, true);
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end checkGinOffer");
	}

	public void startAnalyticsFlow(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start startAnalyticsFlow");
		Map<String, Object> vars = execution.getVariables();
		CompletableFuture.supplyAsync(() -> workflowHelper.startActivitiProcess("ginAnalyticsFlowBpmn", vars), customExecutor);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end startAnalyticsFlow");
	}

	public void checkAnalyticsFlow(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start checkAnalyticsFlow");
		execution.setVariable(GIN_ASYCNH_ANALYTICS_FLOW_FLAG, ginAnalyticsFlowAsychflag);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end checkAnalyticsFlow");
	}
	
	public void ginAddressUpdate(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start ginAddressUpdate");
		JSONObject addrObject = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
		
		JSONObject addressObject = new JSONObject();
		JSONObject verification = new JSONObject();
		addressObject.put("addressLine1", addrObject.get("addressLine1"));
		addressObject.put("addressLine2", addrObject.get("addressLine2"));
		addressObject.put("addressSource", "JOURNEY");
		addressObject.put("addressTypeKey", AddressTypeEnum.CURRENT.getValue());
		addressObject.put("cityKey", addrObject.get("cityKey"));
		addressObject.put("countryKey",  addrObject.get("countryKey"));
		addressObject.put("pincodeKey",  addrObject.get("pincodeKey"));
		addressObject.put("stateKey",addrObject.get("stateKey"));
		verification.put(CreditBusinessConstants.IS_VERIFIED, false);
		verification.put(CreditBusinessConstants.VERIFICATION_DATE, "");
		verification.put(CreditBusinessConstants.VERIFICATION_SOURCE, "");
		verification.put(CreditBusinessConstants.VERIFIEDFOR, "");
		addressObject.put("verification", verification);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, addressObject);
		execution.setVariable(CITY_KEY,addrObject.get("cityKey"));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End ginAddressUpdate");

	}
	
	public void getGinPersonalEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start getGinPersonalEmail");
		Email emailDetails = null;
		String applicationId= execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString();
		try {
			emailDetails = apiCallHelper.getEmail(applicationId, execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString(), EmailTypeEnum.PERON1.getValue().toString());
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception while fetching email for appId = " + applicationId, e);
		}
		if (null != emailDetails) {
			execution.setVariable(CreditBusinessConstants.PERSONALEMAILID, emailDetails.getEmail());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end getGinPersonalEmail");
	
	}
}
