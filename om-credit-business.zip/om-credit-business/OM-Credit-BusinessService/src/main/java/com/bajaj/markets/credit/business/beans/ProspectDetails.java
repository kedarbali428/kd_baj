package com.bajaj.markets.credit.business.beans;

import java.util.List;
public class ProspectDetails {
	
	private PersonalDetails personalDetails;
	
	private List<OfferDetail> offerDetails;
	
	private List<AddressDetails> addressDetails;
	
	private List<BankDetailsBean> bankDetails;
	
	private List<MandateDetailsBean> mandateDetails;
	
	public PersonalDetails getPersonalDetails() {
		return personalDetails;
	}

	public void setPersonalDetails(PersonalDetails personalDetails) {
		this.personalDetails = personalDetails;
	}
	
	public List<AddressDetails> getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(List<AddressDetails> addressDetails) {
		this.addressDetails = addressDetails;
	}

	public List<BankDetailsBean> getBankDetails() {
		return bankDetails;
	}

	public void setBankDetails(List<BankDetailsBean> bankDetails) {
		this.bankDetails = bankDetails;
	}

	public List<OfferDetail> getOfferDetails() {
		return offerDetails;
	}

	public void setOfferDetails(List<OfferDetail> offerDetails) {
		this.offerDetails = offerDetails;
	}

	public List<MandateDetailsBean> getMandateDetails() {
		return mandateDetails;
	}

	public void setMandateDetails(List<MandateDetailsBean> mandateDetails) {
		this.mandateDetails = mandateDetails;
	}

	@Override
	public String toString() {
		return "ProspectDetails [personalDetails=" + personalDetails + ", offerDetails=" + offerDetails
				+ ", addressDetails=" + addressDetails + "]";
	}

}
