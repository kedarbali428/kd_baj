package com.bajaj.markets.credit.business.beans;

public class AppEsignInfoBean {
	
	private Long appEsignInfokey;

	private String status;
	
	private Long appDocKey;

	private String suspendReason;
	
	private Integer isactive;

	public Long getAppEsignInfokey() {
		return appEsignInfokey;
	}

	public void setAppEsignInfokey(Long appEsignInfokey) {
		this.appEsignInfokey = appEsignInfokey;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getAppDocKey() {
		return appDocKey;
	}

	public void setAppDocKey(Long appDocKey) {
		this.appDocKey = appDocKey;
	}

	public String getSuspendReason() {
		return suspendReason;
	}

	public void setSuspendReason(String suspendReason) {
		this.suspendReason = suspendReason;
	}


	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	@Override
	public String toString() {
		return "AppEsignInfoBean [appEsignInfokey=" + appEsignInfokey + ", status=" + status + ", appDocKey="
				+ appDocKey + ", suspendReason=" + suspendReason + ", isactive=" + isactive + "]";
	}
	
}
