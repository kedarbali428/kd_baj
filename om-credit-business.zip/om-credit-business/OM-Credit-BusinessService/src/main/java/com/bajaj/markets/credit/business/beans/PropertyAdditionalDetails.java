package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class PropertyAdditionalDetails implements Serializable{

	private PropertyPageDetails propertyDetails;

	private String hlProductIntent;

	private Pincode pincode;

	private String l3ProductCode;

	private String l4ProductCode;
	
	private String action;

	public String getHlProductIntent() {
		return hlProductIntent;
	}

	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public Pincode getPincode() {
		return pincode;
	}

	public void setPincode(Pincode pincode) {
		this.pincode = pincode;
	}

	public PropertyPageDetails getPropertyDetails() {
		return propertyDetails;
	}

	public void setPropertyDetails(PropertyPageDetails propertyDetails) {
		this.propertyDetails = propertyDetails;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public String getL4ProductCode() {
		return l4ProductCode;
	}

	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

}
