package com.bajaj.markets.credit.business.beans;

/**
 * Application Stage Details resource
 * 
 * @author 736919
 * 
 */
public class ApplicationStageDetails {

	private Integer percentageCompletion;

	private String stageDesc;
	private String subStageDesc;
	private String stageInTime;

	public Integer getPercentageCompletion() {
		return percentageCompletion;
	}

	public void setPercentageCompletion(Integer percentageCompletion) {
		this.percentageCompletion = percentageCompletion;
	}

	public String getStageDesc() {
		return stageDesc;
	}

	public void setStageDesc(String stageDesc) {
		this.stageDesc = stageDesc;
	}

	public String getSubStageDesc() {
		return subStageDesc;
	}

	public void setSubStageDesc(String subStageDesc) {
		this.subStageDesc = subStageDesc;
	}

	public String getStageInTime() {
		return stageInTime;
	}

	public void setStageInTime(String stageInTime) {
		this.stageInTime = stageInTime;
	}

	@Override
	public String toString() {
		return "ApplicationStageDetails [percentageCompletion=" + percentageCompletion + ", stageDesc=" + stageDesc
				+ ", subStageDesc=" + subStageDesc + ", stageInTime=" + stageInTime + "]";
	}

}
