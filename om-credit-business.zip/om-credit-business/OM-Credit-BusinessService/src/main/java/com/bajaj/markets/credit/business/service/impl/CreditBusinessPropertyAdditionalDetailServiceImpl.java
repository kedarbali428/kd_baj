package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PERSONAL_EMAIL_TYPE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.TYPE_KEY;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AdditionalPageInfo;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.Pincode;
import com.bajaj.markets.credit.business.beans.PropertyAdditionalDetails;
import com.bajaj.markets.credit.business.beans.PropertyPageDetails;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MapperFactory;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinsessPropertyAdditionalDetailService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CreditBusinessPropertyAdditionalDetailServiceImpl implements CreditBusinsessPropertyAdditionalDetailService {

	@Autowired
	CreditBusinessApiCallsHelper apiHelper;
	
	@Autowired
	private Executor customExecutor;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String getChildApplicationsUrl;
	
	@Value("${api.omcreditapplicationservice.getemail.get.url}")
	String emailGetURL;
	
	@Autowired
	WorkflowHelper workflowHelper;
	
	private static final String CLASS_NAME = CreditBusinessPropertyAdditionalDetailServiceImpl.class.getCanonicalName();


	@Override
	public PropertyAdditionalDetails getPropertyAdditionalDetails(String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start getPropertyAdditionalDetails for applicationid : " + applicationId);
		PropertyAdditionalDetails propertyAdditionalDetails = new PropertyAdditionalDetails();
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationkey", applicationId);
		params.put("isInProcessing", "true");
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ResponseEntity<?> childApplicationListRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				getChildApplicationsUrl, List.class, params, null, new HttpHeaders());
		if (childApplicationListRes.getBody() != null) {
			List<ApplicationDetail> childApplicationList = mapper.convertValue(childApplicationListRes.getBody(),
					new TypeReference<List<ApplicationDetail>>() {
					});
			ApplicationDetail childApp = childApplicationList.get(0);
			String childAppId = childApp.getApplicationKey();
			propertyAdditionalDetails.setL3ProductCode(childApp.getL3ProductCode());
			propertyAdditionalDetails.setL4ProductCode(childApp.getL4ProductCode());
			CompletableFuture<Void> getPropertyDetailsObject = CompletableFuture
					.supplyAsync(() -> apiHelper.getPropertyDetails(childAppId), customExecutor)
					.exceptionally(ex -> new PropertyPageDetails()).thenAccept(propertyDetailsObject -> {
						PropertyPageDetails propertyDetails = getPropertyAdditionalDetails(propertyDetailsObject);
						propertyAdditionalDetails.setPropertyDetails(propertyDetails);
					});
			CompletableFuture<Void> getHlProductInttentObject = CompletableFuture
					.supplyAsync(() -> apiHelper.getHlProductIntent(childAppId), customExecutor)
					.thenAccept(getHlProductIntents -> {
						propertyAdditionalDetails.setHlProductIntent(getHlProductIntents.getHlProductIntent());
					});

			CompletableFuture<Void> getPropertyAddressDetailsObject = CompletableFuture
					.supplyAsync(() -> apiHelper.getPropertyAddressDetails(childAppId), customExecutor)
					.exceptionally(ex -> new Pincode()).thenAccept(getAddressDetails -> {
						Pincode propertyPincode = new Pincode();
						propertyPincode.setPincode(getAddressDetails.getPincode());
						propertyPincode.setCountry(getAddressDetails.getCountry());
						propertyPincode.setState(getAddressDetails.getState());
						propertyPincode.setCity(getAddressDetails.getCity());
						propertyPincode.setAddressLine1(getAddressDetails.getAddressLine1());
						propertyPincode.setAddressLine2(getAddressDetails.getAddressLine2());
						propertyAdditionalDetails.setPincode(propertyPincode);
					});

			CompletableFuture
					.allOf(getPropertyDetailsObject, getHlProductInttentObject, getPropertyAddressDetailsObject).join();
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Inside getPropertyAdditionalDetails method Child App not found,applicationId: " + applicationId);
			throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("OMCB_23", "Child App not found"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End getPropertyAdditionalDetails for applicationid : " + applicationId);
		return propertyAdditionalDetails;

	}


	@Override
	public ApplicationResponse postPropertyDetails(String applicationId,
			@Valid PropertyAdditionalDetails propertyAdditionalDetailsRequest, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start postPropertyDetails for applicationid : " + applicationId + " Request : " + propertyAdditionalDetailsRequest);
		
		Map<String, Object> vars = new HashMap<String, Object>();
		vars.put(CreditBusinessConstants.REQUEST, propertyAdditionalDetailsRequest);
		vars.put("action", propertyAdditionalDetailsRequest.getAction() != null ? propertyAdditionalDetailsRequest.getAction().toLowerCase() : "next");
		try {
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End postPropertyDetails");
			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			ApplicationResponse applicationResponse = new ApplicationResponse();
			applicationResponse.setNextTask(task);
			applicationResponse.setPayload(propertyAdditionalDetailsRequest);
			return applicationResponse;
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception completing workflow task", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while calling the service", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-101", "Exception while completing activiti task"));
		}
	}

		private PropertyPageDetails getPropertyAdditionalDetails(PropertyPageDetails propertyDetailsObject) {
		PropertyPageDetails propertyDetails = new PropertyPageDetails();
		propertyDetails.setAppPropertyDetKey(propertyDetailsObject.getAppPropertyDetKey());
		propertyDetails.setIsPropertyIdentified(propertyDetailsObject.getIsPropertyIdentified());
		propertyDetails.setPropertySizeBHK(propertyDetailsObject.getPropertySizeBHK());
		propertyDetails.setPropertySizeInSqrFeet(propertyDetailsObject.getPropertySizeInSqrFeet());
		propertyDetails.setCreated(propertyDetailsObject.isCreated());
		propertyDetails.setBuilderName(propertyDetailsObject.getBuilderName());
		propertyDetails.setProjectName(propertyDetailsObject.getProjectName());
		propertyDetails.setPropertyCost(propertyDetailsObject.getPropertyCost());
		propertyDetails.setPropertyStatus(propertyDetailsObject.getPropertyStatus());
		propertyDetails.setPropertyType(propertyDetailsObject.getPropertyType());
		propertyDetails.setPropertyUsage(propertyDetailsObject.getPropertyUsage());
		propertyDetails.setSearchAssistRequired(propertyDetailsObject.getSearchAssistRequired());
		propertyDetails.setUserBudget(propertyDetailsObject.getUserBudget());
		propertyDetails.setPropertyMarketValue(propertyDetailsObject.getPropertyMarketValue());
		propertyDetails.setUnitSelected("SqrFeet");
		return propertyDetails;
	}


	@Override
	public AdditionalPageInfo getAdditionalPageInformation(String applicationId, HttpHeaders headers) {
		AdditionalPageInfo additionalPageInfo = new AdditionalPageInfo();
		HashMap<String, String> applicationParams = new HashMap<>();
		applicationParams.put("applicationkey", applicationId);
		applicationParams.put("isInProcessing", "true");
		ObjectMapper mapper = MapperFactory.INSTANCE.getInstance();
		ResponseEntity<?> childApplicationListRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getChildApplicationsUrl, List.class, applicationParams, null, new HttpHeaders());
		if (childApplicationListRes.getBody() != null) {
			List<ApplicationDetail> childApplicationList = mapper.convertValue(childApplicationListRes.getBody(), new TypeReference<List<ApplicationDetail>>() {
			});
			ApplicationDetail childApp = childApplicationList.get(0);
			String childAppId = childApp.getApplicationKey();
			additionalPageInfo.setL3code(childApp.getL3ProductCode());
			// 1. Get User Profile Bean
			Map<String, String> userProfileParams = new HashMap<String, String>();
			userProfileParams.put("applicationid", childAppId);
			UserProfileBean userProfile = apiHelper.getUserProfile(userProfileParams, CreditBusinessConstants.CHILD_APPLICANT_TYPE, true);
			if (null != userProfile) {
				// 2. Get Email Details
				Map<String, String> emailParams = new HashMap<String, String>();
				emailParams.put(APPLICATION_ID, childAppId);
				String applicationUserAttributeKey = userProfile.getApplicationUserAttributeKey();
				emailParams.put("userattributekey", applicationUserAttributeKey);
				emailParams.put(TYPE_KEY, PERSONAL_EMAIL_TYPE_KEY);
				Email email = getEmailDetails(emailParams, headers);
				additionalPageInfo = prepareAdditionalPageInfo(userProfile, email, childApp.getL3ProductCode());
			} 
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside getAdditionalPageInformation method Child App not found, applicationId: " + applicationId);
			throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("OMCB_23", "Child App not found"));
		}
		return additionalPageInfo;
	}

	private Email getEmailDetails(Map<String, String> params, HttpHeaders headers) {
		ResponseEntity<Email> apiResponse = null;
		try {
			apiResponse = (ResponseEntity<Email>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, emailGetURL, Email.class, params, null, headers);
			return apiResponse != null ? apiResponse.getBody() : null;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Application email detail not found for application attribute id");
		}
		return null;
	}

	private AdditionalPageInfo prepareAdditionalPageInfo(UserProfileBean userProfile, Email email, String l3ProductCode) {
		AdditionalPageInfo additionalPageInfo = new AdditionalPageInfo();
		additionalPageInfo.setCoAppMobile(userProfile.getMobile());
		additionalPageInfo.setCoAppPAN(userProfile.getPanNumber());
		additionalPageInfo.setL3code(l3ProductCode);
		additionalPageInfo.setCoAppDob(userProfile.getDateOfBirth());
		
		if (null != userProfile.getName()) {
			additionalPageInfo.setCoAppName(userProfile.getName().getFirstName() + " " + userProfile.getName().getLastName());
		}

		if (!org.springframework.util.StringUtils.isEmpty(userProfile.getGenderKey())) {
			additionalPageInfo.setCoAppGender(userProfile.getGenderKey());
		}

		if (!org.springframework.util.StringUtils.isEmpty(userProfile.getMaritalStatusKey())) {
			additionalPageInfo.setCoAppMaritalStatus(userProfile.getMaritalStatusKey());
		}

		if (null != email)
			additionalPageInfo.setCoAppEmail(email.getEmail());
		return additionalPageInfo;
	}
	
	@Override
	public ApplicationResponse postAdditionalDetails(String applicationId,
			@Valid AdditionalPageInfo additionalPageInfo, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start postAdditionalDetails for applicationid : " + applicationId + " Request : " + additionalPageInfo);
		Map<String, Object> vars = new HashMap<String, Object>();
		vars.put(CreditBusinessConstants.REQUEST, additionalPageInfo);
		vars.put("action", additionalPageInfo.getAction() != null ? additionalPageInfo.getAction().toLowerCase() : "next");
		try {
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End postAdditionalDetails");
			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			ApplicationResponse applicationResponse = new ApplicationResponse();
			applicationResponse.setNextTask(task);
			applicationResponse.setPayload(additionalPageInfo);
			return applicationResponse;
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception completing workflow task", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while calling the service", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-101", "Exception while completing activiti task"));
		}
	}
}
