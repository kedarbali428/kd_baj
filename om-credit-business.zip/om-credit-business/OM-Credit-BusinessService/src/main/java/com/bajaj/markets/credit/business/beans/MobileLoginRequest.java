package com.bajaj.markets.credit.business.beans;

public class MobileLoginRequest {
	
	private String mobile;
	private String otp;
	private String dateOfBirth;
	private String source;
	private Long applicationKey;

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

}
