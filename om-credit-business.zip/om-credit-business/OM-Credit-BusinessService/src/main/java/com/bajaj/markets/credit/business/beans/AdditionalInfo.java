package com.bajaj.markets.credit.business.beans;

public class AdditionalInfo {

	private String panNumber;
	private String name;
	private String middleName;
	private String maritalStatus;
	private String dateOfBirth;
	private String lastName;
	private String gender;
	private String personalEmail;
	private String currentAddressLine1;
	private String currentAddressLine2;
	private String currentAddressLine3;
	private String currentState;
	private String currentCity;
	private String zipCode;
	private String permanentAddressLine1;
	private String permanentAddressLine2;
	private String permanentAddressLine3;
	private String permanentState;
	private String permanentCity;
	private String permanentzipCode;
	private String officeAddressLine1;
	private String officeAddressLine2;
	private String officeAddressLine3;
	private String officeState;
	private String officeCity;
	private String officePinCode;
	private String employmentType;
	private String nameOfCompanyBusiness;
	private String designation;
	private String fathersName;
	private String mothersName;
	
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPersonalEmail() {
		return personalEmail;
	}
	public void setPersonalEmail(String personalEmail) {
		this.personalEmail = personalEmail;
	}
	public String getCurrentAddressLine1() {
		return currentAddressLine1;
	}
	public void setCurrentAddressLine1(String currentAddressLine1) {
		this.currentAddressLine1 = currentAddressLine1;
	}
	public String getCurrentAddressLine2() {
		return currentAddressLine2;
	}
	public void setCurrentAddressLine2(String currentAddressLine2) {
		this.currentAddressLine2 = currentAddressLine2;
	}
	public String getCurrentAddressLine3() {
		return currentAddressLine3;
	}
	public void setCurrentAddressLine3(String currentAddressLine3) {
		this.currentAddressLine3 = currentAddressLine3;
	}
	public String getPermanentAddressLine1() {
		return permanentAddressLine1;
	}
	public void setPermanentAddressLine1(String permanentAddressLine1) {
		this.permanentAddressLine1 = permanentAddressLine1;
	}
	public String getPermanentAddressLine2() {
		return permanentAddressLine2;
	}
	public void setPermanentAddressLine2(String permanentAddressLine2) {
		this.permanentAddressLine2 = permanentAddressLine2;
	}
	public String getPermanentAddressLine3() {
		return permanentAddressLine3;
	}
	public void setPermanentAddressLine3(String permanentAddressLine3) {
		this.permanentAddressLine3 = permanentAddressLine3;
	}
	public String getOfficeAddressLine1() {
		return officeAddressLine1;
	}
	public void setOfficeAddressLine1(String officeAddressLine1) {
		this.officeAddressLine1 = officeAddressLine1;
	}
	public String getOfficeAddressLine2() {
		return officeAddressLine2;
	}
	public void setOfficeAddressLine2(String officeAddressLine2) {
		this.officeAddressLine2 = officeAddressLine2;
	}
	public String getOfficeAddressLine3() {
		return officeAddressLine3;
	}
	public void setOfficeAddressLine3(String officeAddressLine3) {
		this.officeAddressLine3 = officeAddressLine3;
	}
	public String getCurrentState() {
		return currentState;
	}
	public void setCurrentState(String currentState) {
		this.currentState = currentState;
	}
	public String getCurrentCity() {
		return currentCity;
	}
	public void setCurrentCity(String currentCity) {
		this.currentCity = currentCity;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getPermanentState() {
		return permanentState;
	}
	public void setPermanentState(String permanentState) {
		this.permanentState = permanentState;
	}
	public String getPermanentCity() {
		return permanentCity;
	}
	public void setPermanentCity(String permanentCity) {
		this.permanentCity = permanentCity;
	}
	public String getPermanentzipCode() {
		return permanentzipCode;
	}
	public void setPermanentzipCode(String permanentzipCode) {
		this.permanentzipCode = permanentzipCode;
	}
	public String getOfficeState() {
		return officeState;
	}
	public void setOfficeState(String officeState) {
		this.officeState = officeState;
	}
	public String getOfficeCity() {
		return officeCity;
	}
	public void setOfficeCity(String officeCity) {
		this.officeCity = officeCity;
	}
	public String getOfficePinCode() {
		return officePinCode;
	}
	public void setOfficePinCode(String officePinCode) {
		this.officePinCode = officePinCode;
	}
	public String getEmploymentType() {
		return employmentType;
	}
	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}
	public String getNameOfCompanyBusiness() {
		return nameOfCompanyBusiness;
	}
	public void setNameOfCompanyBusiness(String nameOfCompanyBusiness) {
		this.nameOfCompanyBusiness = nameOfCompanyBusiness;
	}	
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getFathersName() {
		return fathersName;
	}
	public void setFathersName(String fathersName) {
		this.fathersName = fathersName;
	}
	public String getMothersName() {
		return mothersName;
	}
	public void setMothersName(String mothersName) {
		this.mothersName = mothersName;
	}
	@Override
	public String toString() {
		return "AdditionalInfo [panNumber=" + panNumber + ", name=" + name + ", maritalStatus=" + maritalStatus
				+ ", dateOfBirth=" + dateOfBirth + ", lastName=" + lastName + ", gender=" + gender + ", personalEmail="
				+ personalEmail + ", currentAddressLine1=" + currentAddressLine1 + ", currentAddressLine2="
				+ currentAddressLine2 + ", currentAddressLine3=" + currentAddressLine3 + ", currentState="
				+ currentState + ", currentCity=" + currentCity + ", zipCode=" + zipCode + ", permanentAddressLine1="
				+ permanentAddressLine1 + ", permanentAddressLine2=" + permanentAddressLine2
				+ ", permanentAddressLine3=" + permanentAddressLine3 + ", permanentState=" + permanentState
				+ ", permanentCity=" + permanentCity + ", permanentzipCode=" + permanentzipCode
				+ ", officeAddressLine1=" + officeAddressLine1 + ", officeAddressLine2=" + officeAddressLine2
				+ ", officeAddressLine3=" + officeAddressLine3 + ", officeState=" + officeState + ", officeCity="
				+ officeCity + ", officePinCode=" + officePinCode + ", employmentType=" + employmentType
				+ ", nameOfCompanyBusiness=" + nameOfCompanyBusiness + ", designation=" + designation + ", fathersName="
				+ fathersName + ", mothersName=" + mothersName + "]";
	}
}