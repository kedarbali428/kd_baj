package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

public class CibilRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String otp;
	private boolean resendOtp;

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public boolean getResendOtp() {
		return resendOtp;
	}

	public void setResendOtp(boolean resendOtp) {
		this.resendOtp = resendOtp;
	}

	@Override
	public String toString() {
		return "CibilRequest [otp=" + otp + ", resendOtp=" + resendOtp + "]";
	}

}
