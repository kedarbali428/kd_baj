package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class SessionInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2892313994131445241L;
	private Long userKey;
	private Long applicationKey;
	private String role;

	public Long getUserKey() {
		return userKey;
	}

	public void setUserKey(Long userKey) {
		this.userKey = userKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "SessionInfo [userKey=" + userKey + ", applicationKey=" + applicationKey + ", role=" + role + "]";
	}

}
