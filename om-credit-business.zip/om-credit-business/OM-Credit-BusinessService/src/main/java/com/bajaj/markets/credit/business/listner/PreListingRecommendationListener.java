package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;

import java.util.HashMap;
import java.util.Map;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DATE_OF_BIRTH;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.publisher.service.PublisherService;

@Component
public class PreListingRecommendationListener {
	public static final String CLASS_NAME = PreListingRecommendationListener.class.getCanonicalName();
	public static final String CREDIT_PRELISTING_RECOMMENDATION_EVENT = "CREDIT_PRELISTING_RECOMMENDATION";
	public static final String PRELISTING_RECOMMENDATION_EVENT_TYPE = "PRELISTING_RECOMMENDATION";

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private PublisherService publisherService;

	@Autowired
	CustomDefaultHeaders customHeaders;

	@Value("${aws.sqs.prelisting.recommendations.fanout.queuename}")
	private String preListingFanoutQueue;

	@SuppressWarnings("unchecked")
	public void publishPreListingRecommendationEvent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"start - publishPreListingRecommendationEvent for applicationId: "
						+ execution.getVariable(APPLICATION_ID));
		JSONObject preListingFanoutEvent = new JSONObject();
		preListingFanoutEvent.put("applicationId", String.valueOf(execution.getVariable(APPLICATION_ID)));
		preListingFanoutEvent.put("userAttributeKey",
				String.valueOf(execution.getVariable(APPLICATION_USER_ATTRIBUTE_KEY)));
		preListingFanoutEvent.put("mobile", execution.getVariable(MOBILE));
		preListingFanoutEvent.put("dateOfBirth", execution.getVariable(DATE_OF_BIRTH));
		preListingFanoutEvent.put("sourceContext", "updateProfileApp");
		Map<String, String> headers = new HashMap<>();
		headers.put(CreditBusinessConstants.AUTH_TOKEN, customHeaders.getAuthtoken());
		headers.put(CreditBusinessConstants.CMPT_CORR_ID, customHeaders.getCmptcorrid());

		Map<String, String> messageFilterAttributes = new HashMap<String, String>();

		EventMessage eventMessage = new EventMessage();
		eventMessage.setEventName(CREDIT_PRELISTING_RECOMMENDATION_EVENT);
		eventMessage.setEventType(PRELISTING_RECOMMENDATION_EVENT_TYPE);
		eventMessage.setPayload(preListingFanoutEvent);
		eventMessage.setHeaders(headers);
		eventMessage.setMessageFilterAttributes(messageFilterAttributes);
		try {
			publisherService.publishToQueue(preListingFanoutQueue, eventMessage);
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
					"PreListingRecommendation event publish failed for message: " + eventMessage, exception);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"end - PreListingRecommendation event publish for applicationId: "
						+ execution.getVariable(APPLICATION_ID));
	}

}
