package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.USERATTRIBUTETYPE;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.OfferResponse;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessOfferDetailsService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CreditBusinessOfferDetailsServiceImpl implements CreditBusinessOfferDetailsService {

	@Value("${api.omcreditapplicationservice.application.offers.GET.url}")
	private String offerdetailsUrl;

	@Autowired
	private CreditBusinessHelper creditBusinessHelper;

	@Autowired
	private BFLLoggerUtilExt logger;

	@Value("${api.omcreditapplicationservice.application.userprofiles.customername.GET.url}")
	private String customerNameUrl;

	@Value("#{${offer.riskoffertype.map}}")
	private Map<String, Integer> offerPriorityMap;

	@Value("#{${offer.displayPriority.map}}")
	private Map<String, Integer> offerDisplayPriority;

	private ObjectMapper mapper = new ObjectMapper();

	private static final String CLASS_NAME = CreditBusinessOfferDetailsServiceImpl.class.getCanonicalName();

	@Override
	public List<OfferResponse> getOfferAmount(String applicationId, String productCode) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start - getOfferAmount: " + applicationId);
		List<AppOfferDetBean> offerDetails = null;
		List<OfferResponse> response = new ArrayList<>();
		try {
			if (productCode.equalsIgnoreCase(CreditBusinessConstants.PRODUCT_CODE_OMPL)) {
				offerDetails = getOffers(applicationId);
				if (!CollectionUtils.isEmpty(offerDetails)) {

					ArrayList<AppOfferDetBean> offerList = getEligibleOfferListSortedByBusinessPriority(applicationId,
							offerDetails);

					Map<String, Integer> displayPriority = getDisplayPriority(offerList);

					response = offerList.stream().map(appOfferDet -> {
						return populateOfferDetailsResponse(appOfferDet, applicationId, displayPriority);
					}).sorted(Comparator.comparing(OfferResponse::getDisplayPriority,
							Comparator.nullsLast(Comparator.naturalOrder()))).collect(Collectors.toList());
				}
			}
		} catch (CreditBusinessException creditBusinessException) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"offer details not found, applicationId: " + applicationId);
			throw new CreditBusinessException(HttpStatus.NOT_FOUND,
					new ErrorBean("OMCB_4003", "offer details not found"));
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception Occrred while fetching offer amount for application id: " + applicationId, exception);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("OMCB_4002", "Error while fetching offer Details"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End - getOfferAmount for applicationId " + applicationId + " ,respone:" + response);
		return response;
	}

	private List<AppOfferDetBean> getOffers(String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start- getOffers for applicationId: " + applicationId);
		List<AppOfferDetBean> offerDetails = null;
		Map<String, String> param = new HashMap<>();
		param.put("applicationid", applicationId);
		param.put("productCode", null);
		ResponseEntity<?> offerApiResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, offerdetailsUrl,
				List.class, param, null, new HttpHeaders());
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		if (null != offerApiResponse && null != offerApiResponse.getBody()) {
			offerDetails = mapper.convertValue(offerApiResponse.getBody(), new TypeReference<List<AppOfferDetBean>>() {
			});
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End- getOffers for applicationId: " + applicationId + " ,offerresponse: " + offerDetails);
		return offerDetails;
	}

	private ArrayList<AppOfferDetBean> getEligibleOfferListSortedByBusinessPriority(String applicationId,
			List<AppOfferDetBean> offerDetails) {
		ArrayList<AppOfferDetBean> offerList = new ArrayList<AppOfferDetBean>();

		Map<String, List<AppOfferDetBean>> offersGroupedByProduct = offerDetails.stream()
				.filter(o -> null != o.getOfferAmt() && o.getOfferAmt().compareTo(BigDecimal.ZERO) != 0)
				.collect(Collectors.groupingBy(AppOfferDetBean::getProductCode, Collectors.toList()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"OffersGroupedByProduct for " + applicationId + " : " + offersGroupedByProduct);

		offersGroupedByProduct.forEach((k, v) -> {
			Optional<AppOfferDetBean> offerSortedByPriority = v.stream().sorted(Comparator
					.comparing(AppOfferDetBean::getOfferPriority, Comparator.nullsLast(Comparator.naturalOrder())))
					.findFirst();
			if (offerSortedByPriority.isPresent() && null == offerSortedByPriority.get().getOfferPriority()
					&& v.size() > 0) {
				offerSortedByPriority = v.stream().sorted(Comparator.comparing(AppOfferDetBean::getAppOfferDetKey))
						.findFirst();
			}
			if (offerSortedByPriority.isPresent()) {
				offerList.add(offerSortedByPriority.get());
			}
		});
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"eligible offer list sorted by business priority for " + applicationId + " : " + offerList);
		return offerList;
	}

	private Map<String, Integer> getDisplayPriority(List<AppOfferDetBean> list) {
		Map<String, Integer> map = null;
		if (!CollectionUtils.isEmpty(list)) {
			List<String> riskOfferTypesToOrder = list.stream().map(AppOfferDetBean::getProductCode)
					.filter(a ->!StringUtils.isBlank(a) && offerDisplayPriority.containsKey(a)).sorted((left, right) -> {
						Integer leftIndex = offerDisplayPriority.get(left);
						Integer rightIndex = offerDisplayPriority.get(right);
						if (leftIndex == null) {
							return -1;
						}
						if (rightIndex == null) {
							return 1;
						}
						return Integer.compare(leftIndex, rightIndex);
					}).collect(Collectors.toList());
			map = IntStream.range(0, riskOfferTypesToOrder.size()).boxed()
					.collect(Collectors.toMap(riskOfferTypesToOrder::get, i -> i + 1));
		}
		return map;
	}

	public String prepareName(Name customerName) {
		StringBuilder fullname = new StringBuilder();
		if (!StringUtils.isBlank(customerName.getFirstName())) {
			fullname.append(customerName.getFirstName());
			if (!StringUtils.isBlank(customerName.getLastName())) {
				fullname.append(" ").append(customerName.getLastName());
			}
			return fullname.toString();
		} else {
			return null;
		}
	}

	private OfferResponse populateOfferDetailsResponse(AppOfferDetBean offer, String applicationId,
			Map<String, Integer> displayPriority) {
		OfferResponse offerResponse = new OfferResponse();
		BigDecimal offerAmount = offer.getOfferAmt();
		offerResponse.setOfferAmount(offerAmount);
		offerResponse.setOfferTenure(CreditBusinessConstants.OFFER_TENURE);
		if (CreditBusinessConstants.AXIS_PRODUCT_CODE.equals(offer.getProductCode())) {
			offerResponse.setOfferTenure(offer.getOfferTenure());
		}
		if (null == offer.getOfferRoi()) {
			offerResponse.setOfferRoi(new BigDecimal(CreditBusinessConstants.OFFER_ROI));
		} else {
			offerResponse.setOfferRoi(offer.getOfferRoi());
		}
		offerResponse.setIsEmiAmount(offer.getIsEmiAmount());
		offerResponse.setL3ProductCode(offer.getProductCode());
		offerResponse.setRiskOfferType(offer.getRiskOfferType());
		offerResponse.setDisplayPriority(
				!CollectionUtils.isEmpty(displayPriority) ? displayPriority.get(offer.getProductCode()) : null);
		Name customerName = getCustomerName(applicationId);
		offerResponse.setName(prepareName(customerName));
		return offerResponse;
	}

	private Name getCustomerName(String applicationId) {
		Name customerName = null;
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationId);
		params.put("userattributetype", USERATTRIBUTETYPE);

		ResponseEntity<?> customerNameResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				customerNameUrl, Name.class, params, null, new HttpHeaders());
		if (null != customerNameResponse && HttpStatus.OK.equals(customerNameResponse.getStatusCode())
				&& null != customerNameResponse.getBody()) {
			customerName = mapper.convertValue(customerNameResponse.getBody(), Name.class);
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Customer name not found, applicationId: " + applicationId);
			throw new CreditBusinessException(HttpStatus.NOT_FOUND,
					new ErrorBean("OMCB_4001", "Customer name not found"));
		}
		return customerName;
	}

}
