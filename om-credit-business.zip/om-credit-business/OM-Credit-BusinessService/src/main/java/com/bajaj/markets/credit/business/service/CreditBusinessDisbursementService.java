package com.bajaj.markets.credit.business.service;

import com.bajaj.markets.credit.business.beans.DisbursementEventResponseBean;

public interface CreditBusinessDisbursementService {

	public DisbursementEventResponseBean processDisbursement(String applicationId);
}
