package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class NextTask implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8788427449502219329L;
	
	private String processID;
	private String nextTaskKey;
	
	public String getProcessID() {
		return processID;
	}
	public void setProcessID(String processID) {
		this.processID = processID;
	}
	public String getNextTaskKey() {
		return nextTaskKey;
	}
	public void setNextTaskKey(String nextTaskKey) {
		this.nextTaskKey = nextTaskKey;
	}
	@Override
	public String toString() {
		return "NextTask [processID=" + processID + ", nextTaskKey=" + nextTaskKey + "]";
	}
	
	

}
