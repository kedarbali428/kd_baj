package com.bajaj.markets.credit.business.controller;

import static org.springframework.http.HttpStatus.UNPROCESSABLE_ENTITY;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.constraints.Digits;
import javax.validation.groups.Default;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.BankDetails;
import com.bajaj.markets.credit.business.beans.EmailDetails;
import com.bajaj.markets.credit.business.beans.EmailPageActions;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EmailOTPValidate;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EmailTOKENValidate;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessEmailVerificationService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessEmailVerificationController {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	Validator validator;
	
	@Autowired
	CreditBusinessEmailVerificationService creditBusinessEmailVerificationService;
	
	public static final String CLASS_NAME = CreditBusinessEmailVerificationController.class.getCanonicalName();
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(	value = "Validate, Already Verified, Resend Email OTP and Back scenarios on bases of that get next task to be shown in journey",
					notes = "Validate Email OTP and Get next task", httpMethod = "POST",
					response = ApplicationResponse.class)
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Email Validated Successfully", response = ApplicationResponse.class),
			@ApiResponse(code = 400, message = "bad request parameter", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "invalid input parameter", response = ErrorBean.class) })
	@PostMapping(value = "/v1/credit/applications/{applicationid}/emailverification", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationResponse> validateEmail(@RequestHeader HttpHeaders headers, @RequestBody EmailDetails emailDetails,
			@PathVariable(name = "applicationid") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric and should not exceeds size") Long applicationId) {
		if(null != emailDetails.getAction()) {
			
			Set<ConstraintViolation<EmailDetails>> validationErrors = validator.validate(emailDetails, 
					EmailPageActions.VALIDATE.toString().equals(emailDetails.getAction().toString()) ?
							EmailOTPValidate.class : 
								EmailPageActions.VALIDATEEMAILTOKEN.toString().equals(emailDetails.getAction().toString()) ?
										EmailTOKENValidate.class : Default.class);
			
			if(!CollectionUtils.isEmpty(validationErrors)) {
				logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "request failed with validation");
				
				throw new CreditBusinessException(UNPROCESSABLE_ENTITY, 
						new ErrorBean("OMCB_104", validationErrors.stream().findFirst().get().getMessage()));
			} else {
				
				ResponseEntity<ApplicationResponse> response = new ResponseEntity<ApplicationResponse>(
						creditBusinessEmailVerificationService.validateEmail(applicationId, emailDetails, headers), HttpStatus.CREATED);
				
				return response;
			}
		} else {
			
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "action is not valid as specified in enum");
			throw new CreditBusinessException(UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_104", "not a valid action"));
		}
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(	value = "Get Email and Email Type to be verified", notes = "Get Email and Email Type to be verified", httpMethod = "GET",
					response = EmailDetails.class)
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Email details to be verified fetched successfully", response = BankDetails.class),
			@ApiResponse(code = 400, message = "bad request parameter", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "unauthorized", response = ErrorBean.class) })
	@GetMapping(value = "/v1/credit/applications/{applicationid}/emailverification", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<EmailDetails> getEmailDetailsToVerified(@RequestHeader HttpHeaders headers,
			@PathVariable(name = "applicationid") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric and should not exceeds size") Long applicationId,
			@RequestParam(required = false) String task) {
		ResponseEntity<EmailDetails> response = new ResponseEntity<EmailDetails>(
				creditBusinessEmailVerificationService.getEmailVerificationDetails(applicationId, headers, task), HttpStatus.OK);
		return response;
	}
}
