package com.bajaj.markets.credit.business.beans;

public class EmicResponse {

	private String encryptedResponse;
	private String name;
	private String mobile;
	private String dateOfBirth;

	public String getEncryptedResponse() {
		return encryptedResponse;
	}

	public void setEncryptedResponse(String encryptedResponse) {
		this.encryptedResponse = encryptedResponse;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {
		return "EmicResponse [encryptedResponse=" + encryptedResponse + ", name=" + name + ", mobile=" + mobile
				+ ", dateOfBirth=" + dateOfBirth + "]";
	}

}
