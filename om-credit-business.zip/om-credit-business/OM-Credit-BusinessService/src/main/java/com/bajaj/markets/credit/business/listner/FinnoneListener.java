package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.BMR_CUSTOMER_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CREDIT_OFFER_CHECK;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OCCUPATIONTYPECODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OFFER_CHECK;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SKIP_API_EXCEPTION;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EventMessageHelper;
import com.bajaj.markets.credit.publisher.service.PublisherService;

@Component
public class FinnoneListener {

	public static final String FINNONE_EVENT_MESSAGE_FILTER = "FINNONE";

	@Autowired
	BFLLoggerUtilExt logger;

	@Value("${aws.publisher.topic.arn}")
	private String topicArn;

	@Autowired
	PublisherService publisherService;

	@Autowired
	EventMessageHelper eventHelper;

	public static final String CLASS_NAME = FinnoneListener.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void publishEvent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start - finnone event publish");
		if (execution.getVariable(BMR_CUSTOMER_ID) != null) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "CustomerID found from BMR, hence calling FinOne Event");
			JSONObject payload = new JSONObject();
			payload.put("applicationId", execution.getVariable(APPLICATION_ID));
			payload.put("customerId", execution.getVariable(BMR_CUSTOMER_ID));
			payload.put("principalKey", "3");
			payload.put("userAttributeKey", execution.getVariable(APPLICATION_USER_ATTRIBUTE_KEY));
			payload.put("mobile", execution.getVariable(MOBILE));
			payload.put("occupationType", execution.getVariable(OCCUPATIONTYPECODE));
			payload.put("email", execution.getVariable(CreditBusinessConstants.PERSONALEMAILID));

			Map<String, String> messageFilterAttributes = new HashMap<String, String>();
			messageFilterAttributes.put("applicationEvent", FINNONE_EVENT_MESSAGE_FILTER);

			EventMessage eventMessage = eventHelper.createEventMessageForBMR2(CREDIT_OFFER_CHECK, OFFER_CHECK, null, payload, messageFilterAttributes);
			try {
				publisherService.publish(topicArn, eventMessage);
			} catch (Exception exception) {
				logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "finnone event pulish failed for: " + eventMessage, exception);
			}
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "CustomerID not found from BMR. Hence, skipping FinOne Event");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end - finnone event publish");
	}

	public void preFetchBMRCustomerInfo(DelegateExecution execution) {
		execution.setVariable(SKIP_API_EXCEPTION, true);
	}

	public void postFetchBMRCustomerInfo(DelegateExecution execution) {
		Object apiException = execution.getVariable(API_EXCEPTION_ARISE);

		execution.setVariable(BMR_CUSTOMER_ID, null);

		if (null == apiException || !(boolean) apiException) {
			JSONObject response = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
			if (null != response && null != response.get("principleCustRefId")) {
				execution.setVariable(BMR_CUSTOMER_ID, response.get("principleCustRefId"));
			}
		}

		// remove exception skip flags from execution once task gets completed
		List<String> variablesToRemoveFromExecution = new ArrayList<String>();
		variablesToRemoveFromExecution.add(SKIP_API_EXCEPTION);
		variablesToRemoveFromExecution.add(API_EXCEPTION_ARISE);

		execution.removeVariables(variablesToRemoveFromExecution);
	}
}
