package com.bajaj.markets.credit.business.datasource;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class DataSourceRegistry {
	
	private List<DataSource> dataSourceList;
	
	public  DataSourceRegistry(){
		dataSourceList = new ArrayList<>();
	}
	
	public void registerDataSource(DataSource dataSource){
		dataSourceList.add(dataSource);
	}
	
	public List<DataSource> getDataSouces(){
		return dataSourceList;
	}
}