package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class BtBankResponse implements Serializable{

	private Integer bankMasterKey;
	private String sourceName;
	private String bankAccountCatCode;
	
	public Integer getBankMasterKey() {
		return bankMasterKey;
	}
	public void setBankMasterKey(Integer bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}
	public String getSourceName() {
		return sourceName;
	}
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	public String getBankAccountCatCode() {
		return bankAccountCatCode;
	}
	public void setBankAccountCatCode(String bankAccountCatCode) {
		this.bankAccountCatCode = bankAccountCatCode;
	}
}
