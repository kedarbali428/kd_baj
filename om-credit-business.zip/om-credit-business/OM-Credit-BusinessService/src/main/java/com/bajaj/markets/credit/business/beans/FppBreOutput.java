package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class FppBreOutput {
	private String applicationId;
	private Long l3ProductKey;
	private String l3ProductCode;
	private List<OpenArcFppOutput> openArcFppOutput;

	public String getApplicationId() {
		return applicationId;
	}

	public Long getL3ProductKey() {
		return l3ProductKey;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public List<OpenArcFppOutput> getOpenArcFppOutput() {
		return openArcFppOutput;
	}
}