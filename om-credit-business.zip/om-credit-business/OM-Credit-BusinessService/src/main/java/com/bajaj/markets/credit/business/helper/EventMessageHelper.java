package com.bajaj.markets.credit.business.helper;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.BMR2;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.BMR2_QUEUE_FILTER_ATTRB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CREDIT_OFFER_CHECK;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OFFER_CHECK;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.bean.EventSchema;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.BMR2Request;
import com.bajaj.markets.credit.business.beans.BflRequest;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.ProfileDetails;
import com.bajaj.markets.credit.business.beans.ProfileDetailsReqResp;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.publisher.service.PublisherService;

@Component
public class EventMessageHelper {

	@Autowired
	PublisherService publisherService;

	@Autowired
	CustomDefaultHeaders customHeaders;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;

	@Value("${aws.publisher.topic.arn}")
	private String topicArn;

	private static final String CLASS_NAME = EventMessageHelper.class.getCanonicalName();

	public void publishBMR1Event(ApplicationDetail application, ProfileDetails profileDetails, String source) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"publishBMR1Event: Call started for BMR 1 for application :" + application.getApplicantKey() + " :" + profileDetails);
		try {
			BflRequest bflRequest = new BflRequest();
			bflRequest.setApplicationId(application.getApplicationKey());
			bflRequest.setPan(profileDetails.getPan());
			bflRequest.setOccupationType(profileDetails.getOccupation());
			bflRequest.setEmail(profileDetails.getPersonalEmailId());
			bflRequest.setL2ProductCode(application.getL2ProductCode());
			bflRequest.setPrincipleKey(3l);
			bflRequest.setHlProductIntent(null != application.getHlProductIntent() ? application.getHlProductIntent() : null);

			Map<String, String> queryParam = new HashMap<>();
			queryParam.put("applicationid", application.getApplicationKey());
			UserProfileBean userProfile = apiCallsHelper.getUserProfile(queryParam, "1", true);
			if (userProfile != null) {
				bflRequest.setMob(userProfile.getMobile());
				bflRequest.setDob(userProfile.getDateOfBirth());
				bflRequest.setUserAttributeKey(userProfile.getApplicationUserAttributeKey());
				Name name = userProfile.getName();
				if (null != name) {
					bflRequest.setFirstName(name.getFirstName());
					bflRequest.setLastName(name.getLastName());
					bflRequest.setMiddleName(name.getMiddleName());
				}

				queryParam.put("userattributekey", userProfile.getApplicationUserAttributeKey());
				queryParam.put("typeKey", AddressTypeEnum.CURRENT.getValue());
				try {
					Address address = apiCallsHelper.getAddress(new HttpHeaders(), queryParam);
					if (null != address) {
						bflRequest.setPinCode(address.getPincode());
					}
				}catch(Exception e) {
					logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Address not found");
				}
			}

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "BflRequest sent to BMR " + bflRequest);
			EventMessage eventMessage = null;
			eventMessage = createEventMessage(application.getL2ProductCode(), bflRequest, PrincipalTypeEnum.BFL);
			publisherService.publish(topicArn, eventMessage);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Completed publishBMR1Event :: Message published for OMPL - " + eventMessage);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Some techical error occured while PUBLISHING EVENT MESSAGE ", e);
		}
	}

	public void publishBMR2Event(ApplicationDetail application, ProfileDetails profileDetails, String source) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"publishBMR2Event: Call started for BMR2 for application :" + application.getApplicantKey() + " :" + profileDetails);
		try {
			if (application.getL2ProductCode().equals(CreditBusinessConstants.PRODUCT_CODE_OMPL)) {
				BMR2Request request = new BMR2Request();
				request.setApplicationId(application.getApplicationKey());
				request.setOccupationType(profileDetails.getOccupation());
				if (application.getL2ProductCode().equals(CreditBusinessConstants.PRODUCT_CODE_OMPL)) {
					request.setPrincipalKey("3");
				}
				request.setL2ProductCode(application.getL2ProductCode());

				Map<String, String> queryParam = new HashMap<>();
				queryParam.put("applicationid", application.getApplicationKey());
				UserProfileBean userProfile = apiCallsHelper.getUserProfile(queryParam, "1", true);
				if (userProfile != null) {
					queryParam.put("userattributekey", userProfile.getApplicationUserAttributeKey());
					queryParam.put("typeKey", AddressTypeEnum.CURRENT.getValue());
					Address address = apiCallsHelper.getAddress(new HttpHeaders(), queryParam);
					if (null != address) {
						request.setAddressTypeKey(address.getAddressTypeKey());
					}
				}

				Map<String, String> messageFilterAttributes = new HashMap<String, String>();
				messageFilterAttributes.put(BMR2_QUEUE_FILTER_ATTRB, BMR2);
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "BMR2Request sent to BMR2" + request);
				EventMessage eventMessage = createEventMessageForBMR2(CREDIT_OFFER_CHECK, OFFER_CHECK, null, request, messageFilterAttributes);
				publisherService.publish(topicArn, eventMessage);
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Completed publishBMR2Event :: Message published for OMPL for BMR2- " + eventMessage);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "not publishing BMR2 event for application");
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Some techical error occured while PUBLISHING EVENT MESSAGE for BMR2", e);
		}
	}

	public EventMessage createEventMessage(String productcode, Object payload, PrincipalTypeEnum principalEnum) {
		Map<String, String> headers = new HashMap<>();
		Map<String, String> messageFilterAttributes = new HashMap<String, String>();
		
		headers.put(CreditBusinessConstants.AUTH_TOKEN, customHeaders.getAuthtoken());
		headers.put(CreditBusinessConstants.CMPT_CORR_ID, customHeaders.getCmptcorrid());
		
		messageFilterAttributes.put("productCode", productcode);
		messageFilterAttributes.put("principalName", principalEnum.getValue());
		
		EventMessage eventMessage = new EventMessage();
		eventMessage.setEventName(CreditBusinessConstants.CREDIT_OFFER_CHECK);
		eventMessage.setEventType(CreditBusinessConstants.OFFER_CHECK);
		eventMessage.setPayload(payload);
		eventMessage.setHeaders(headers);
		eventMessage.setMessageFilterAttributes(messageFilterAttributes);
		return eventMessage;
	}

	public EventMessage createEventMessageForBMR2(String eventName, String eventType, EventSchema eventSchema, Object payload,
			Map<String, String> messageFilterAttributes) {
		EventMessage eventMessage = new EventMessage();
		Map<String, String> headers = new HashMap<>();
		headers.put(CreditBusinessConstants.AUTH_TOKEN, customHeaders.getAuthtoken());
		headers.put(CreditBusinessConstants.CMPT_CORR_ID, customHeaders.getCmptcorrid());
		eventMessage.setHeaders(headers);
		eventMessage.setEventName(eventName);
		eventMessage.setEventType(eventType);
		eventMessage.setEventSchema(eventSchema);
		eventMessage.setPayload(payload);
		eventMessage.setMessageFilterAttributes(messageFilterAttributes);

		return eventMessage;
	}
	
	public void publishBMR1EventV2(ApplicationDetail application, ProfileDetailsReqResp profileDetailsReqResp) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"publishBMR1EventV2 : Call started for BMR 1 for application :" + application.getApplicantKey() + " :"
						+ profileDetailsReqResp);
		try {
			BflRequest bflRequest = new BflRequest();
			bflRequest.setApplicationId(application.getApplicationKey());
			bflRequest.setPan(profileDetailsReqResp.getProfileDetails().getPanNumber());
			bflRequest.setOccupationType(profileDetailsReqResp.getProfession().getOccupation().getCode());
			bflRequest.setEmail(profileDetailsReqResp.getProfileDetails().getPersonalEmailId());
			bflRequest.setL2ProductCode(application.getL2ProductCode());
			bflRequest.setPrincipleKey(3l);
			bflRequest.setHlProductIntent(
					null != application.getHlProductIntent() ? application.getHlProductIntent() : null);

			Map<String, String> queryParam = new HashMap<>();
			queryParam.put("applicationid", application.getApplicationKey());
			UserProfileBean userProfile = apiCallsHelper.getUserProfile(queryParam, "1", true);
			if (userProfile != null) {
				bflRequest.setMob(userProfile.getMobile());
				bflRequest.setDob(userProfile.getDateOfBirth());
				bflRequest.setUserAttributeKey(userProfile.getApplicationUserAttributeKey());
				Name name = userProfile.getName();
				if (null != name) {
					bflRequest.setFirstName(name.getFirstName());
					bflRequest.setLastName(name.getLastName());
					bflRequest.setMiddleName(name.getMiddleName());
				}

				queryParam.put("userattributekey", userProfile.getApplicationUserAttributeKey());
				queryParam.put("typeKey", AddressTypeEnum.CURRENT.getValue());
				try {
					Address address = apiCallsHelper.getAddress(new HttpHeaders(), queryParam);
					if (null != address) {
						bflRequest.setPinCode(address.getPincode());
					}
				} catch (Exception e) {
					logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Address not found");
				}
			}

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "BflRequest sent to BMR " + bflRequest);
			EventMessage eventMessage = null;
			eventMessage = createEventMessage(application.getL2ProductCode(), bflRequest, PrincipalTypeEnum.BFL);
			publisherService.publish(topicArn, eventMessage);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Completed publishBMR1EventV2  :: Message published for OMPL - " + eventMessage);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Some techical error occured while PUBLISHING EVENT MESSAGE "+ application.getApplicantKey(), e);
		}
	}
   
}
