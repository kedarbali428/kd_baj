package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class LoanDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Double amount;
	private Double tenor;
	private Double roi;
	private Double emi;
	private String emidate;
	private String emiCycleDate;
	private Double roiWithoutBundle;

	public Double getRoiWithoutBundle() {
		return roiWithoutBundle;
	}

	public void setRoiWithoutBundle(Double roiWithoutBundle) {
		this.roiWithoutBundle = roiWithoutBundle;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Double getTenor() {
		return tenor;
	}

	public void setTenor(Double tenor) {
		this.tenor = tenor;
	}

	public Double getRoi() {
		return roi;
	}

	public void setRoi(Double roi) {
		this.roi = roi;
	}

	public Double getEmi() {
		return emi;
	}

	public void setEmi(Double emi) {
		this.emi = emi;
	}

	public String getEmidate() {
		return emidate;
	}

	public void setEmidate(String emidate) {
		this.emidate = emidate;
	}

	public String getEmiCycleDate() {
		return emiCycleDate;
	}

	public void setEmiCycleDate(String emiCycleDate) {
		this.emiCycleDate = emiCycleDate;
	}
	
	@Override
	public String toString() {
		return "LoanDetails [amount=" + amount + ", tenor=" + tenor + ", roi=" + roi + ", emi=" + emi + ", emidate="
				+ emidate + ", emiCycleDate=" + emiCycleDate + ", roiWithoutBundle=" + roiWithoutBundle + "]";
	}

}
