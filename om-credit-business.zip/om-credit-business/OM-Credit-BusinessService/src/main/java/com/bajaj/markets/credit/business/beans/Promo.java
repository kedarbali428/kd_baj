package com.bajaj.markets.credit.business.beans;

public class Promo {

	private String promoCode; 
	private String promoDescription;
	
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public String getPromoDescription() {
		return promoDescription;
	}
	public void setPromoDescription(String promoDescription) {
		this.promoDescription = promoDescription;
	}
	@Override
	public String toString() {
		return "Promo [promoCode=" + promoCode + ", promoDescription=" + promoDescription + "]";
	}
}