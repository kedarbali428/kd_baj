package com.bajaj.markets.credit.business;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.session.data.redis.config.ConfigureRedisAction;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;
import org.springframework.session.web.context.AbstractHttpSessionApplicationInitializer;
import org.springframework.session.web.http.HeaderHttpSessionIdResolver;
import org.springframework.session.web.http.HttpSessionIdResolver;

import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;

@Configuration
@ConditionalOnProperty(value = "spring.session.enabled", havingValue = "true", matchIfMissing = false)
@EnableRedisHttpSession(redisNamespace = "omcredit",maxInactiveIntervalInSeconds = 300)
public class SessionConfig extends AbstractHttpSessionApplicationInitializer {

	@Bean
	public HttpSessionIdResolver httpSessionIdResolver() {
		return new HeaderHttpSessionIdResolver(CreditBusinessConstants.HEADER_X_SESSION_TOKEN); // <3> // custom header
	}

//	@Bean
//	public ServletListenerRegistrationBean<SessionListenerWithMetrics> sessionListenerWithMetrics() {
//		ServletListenerRegistrationBean<SessionListenerWithMetrics> listenerRegBean = new ServletListenerRegistrationBean<>();
//
//		listenerRegBean.setListener(new SessionListenerWithMetrics());
//		return listenerRegBean;
//	}

	@Bean
	public HttpSessionEventPublisher httpSessionEventPublisher() {
		return new HttpSessionEventPublisher();
	}

	@Bean
	public ConfigureRedisAction configureRedisAction() {
		return ConfigureRedisAction.NO_OP; // enable commands at redis level phase 2 }
	}
}