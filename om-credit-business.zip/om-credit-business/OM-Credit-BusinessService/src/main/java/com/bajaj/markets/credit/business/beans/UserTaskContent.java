package com.bajaj.markets.credit.business.beans;

public class UserTaskContent {

	private String name;

    private FormFieldContent content;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public FormFieldContent getContent() {
		return content;
	}

	public void setContent(FormFieldContent content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "UserTaskContent [name=" + name + ", content=" + content + "]";
	}
    
}
