package com.bajaj.markets.credit.business.helper;

import org.springframework.http.HttpStatus;

import com.bajaj.markets.credit.business.beans.ErrorBean;

public class CreditBusinessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5490199492309807549L;

	private HttpStatus code;
	private ErrorBean errorBean;
	private Object payload;

	public CreditBusinessException() {
		super("Businsess Exception raised without status and error message");
	}

	public CreditBusinessException(HttpStatus code, ErrorBean errorBean) {
		super(null != errorBean ? errorBean.getErrorMessage() : "Businsess Exception raised without error message");
		this.code = code;
		this.errorBean = errorBean;
	}

	public CreditBusinessException(HttpStatus code, ErrorBean errorBean, Object payload) {
		super(null != errorBean ? errorBean.getErrorMessage() : "Businsess Exception raised without error message");
		this.code = code;
		this.errorBean = errorBean;
		this.payload = payload;
	}

	public CreditBusinessException(HttpStatus code, Object payload) {
		super("Businsess Exception raised without error message");
		this.code = code;
		this.payload = payload;
	}

	public CreditBusinessException(Throwable cause) {
		super(cause);
	}
	public CreditBusinessException(HttpStatus code, ErrorBean errorBean, Object payload, Throwable cause) {
		super(cause);
		this.code = code;
		this.errorBean = errorBean;
		this.payload = payload;
	}

	public HttpStatus getCode() {
		return code;
	}

	public ErrorBean getErrorBean() {
		return errorBean;
	}

	public Object getPayload() {
		return payload;
	}

	@Override
	public String toString() {
		return "CreditBusinessException [code=" + code + ", errorBean=" + errorBean + ", payload=" + payload
				+ "]";
	}

}
