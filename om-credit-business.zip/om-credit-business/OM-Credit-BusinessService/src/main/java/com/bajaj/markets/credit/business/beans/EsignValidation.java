package com.bajaj.markets.credit.business.beans;

public class EsignValidation {
	private String otp;
	private String mobile;
	private String name;
	private String dateOfBirth;
	private Location location;
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "EsignValidation [otp=" + otp + ", mobile=" + mobile + ", name=" + name + ", dateOfBirth=" + dateOfBirth
				+ ", location=" + location + "]";
	}
	
	

}
