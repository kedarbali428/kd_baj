package com.bajaj.markets.credit.business.listner;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.ApplicantUpdateDetails;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.service.impl.CreditBusinessUnderWriterServiceImpl;
@Component
public class UnderWriterListener {
	private static final String CLASS_NAME = UnderWriterListener.class.getCanonicalName();
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	CreditBusinessUnderWriterServiceImpl creditBusinessUnderWriterServiceImpl;
	@Autowired
	private Executor customExecutor;
	
    public void executeUnderWriterChecks(DelegateExecution execution) {
        Object applicationKeyObj = execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY);
        Object applicantObj = execution.getVariable(CreditBusinessConstants.APPLICANTID);
        logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                "start executeUnderWriterChecks for Application ID :" + applicationKeyObj);
        if (null != applicationKeyObj && null != applicantObj) {
            String applicationId = applicationKeyObj.toString();
            String applicantKey = applicantObj.toString();
            CompletableFuture.runAsync(
                    () -> creditBusinessUnderWriterServiceImpl.excuteUnderWriterCheckData(applicationId, applicantKey),
                    customExecutor).whenComplete((a, ex) -> {
                        logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                                "executeUnderWriterChecks Completed for Application ID :" + applicationKeyObj);
                        if (null != ex) {
                            logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
                                    "Exception occured in executeUnderWriterChecks", ex);
                        }
                    });
        } else {
            logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
                    "Error while getting ApplicationKey and Applicant Key From Execution ,it is either Null or Empty :-\");");

        }
        logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End executeUnderWriterChecks");
    }
}
