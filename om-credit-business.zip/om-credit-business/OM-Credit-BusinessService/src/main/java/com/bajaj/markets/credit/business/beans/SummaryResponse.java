package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.util.List;

public class SummaryResponse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Double totalAmount;
	private Double netDisbursementAmount;
	private Double totalFeeAmount;
	private String l2productCode;
	private String l3productCode;
	private String l4productCode;
	private LoanDetails loanDetails;
	private List<Fees> feeList;
	private String childApplicationId;
	private Double bundleCost;
	private boolean bundleSelected;
	private String hlProductIntent;

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Double getNetDisbursementAmount() {
		return netDisbursementAmount;
	}

	public void setNetDisbursementAmount(Double netDisbursementAmount) {
		this.netDisbursementAmount = netDisbursementAmount;
	}

	public Double getTotalFeeAmount() {
		return totalFeeAmount;
	}

	public void setTotalFeeAmount(Double totalFeeAmount) {
		this.totalFeeAmount = totalFeeAmount;
	}

	public String getL3productCode() {
		return l3productCode;
	}

	public void setL3productCode(String l3productCode) {
		this.l3productCode = l3productCode;
	}

	public String getL4productCode() {
		return l4productCode;
	}

	public void setL4productCode(String l4productCode) {
		this.l4productCode = l4productCode;
	}

	public LoanDetails getLoanDetails() {
		return loanDetails;
	}

	public void setLoanDetails(LoanDetails loanDetails) {
		this.loanDetails = loanDetails;
	}

	public List<Fees> getFeeList() {
		return feeList;
	}

	public void setFeeList(List<Fees> feeList) {
		this.feeList = feeList;
	}

	public String getChildApplicationId() {
		return childApplicationId;
	}

	public void setChildApplicationId(String childApplicationId) {
		this.childApplicationId = childApplicationId;
	}

	public Double getBundleCost() {
		return bundleCost;
	}

	public void setBundleCost(Double bundleCost) {
		this.bundleCost = bundleCost;
	}

	public boolean isBundleSelected() {
		return bundleSelected;
	}

	public void setBundleSelected(boolean bundleSelected) {
		this.bundleSelected = bundleSelected;
	}
	
	public String getHlProductIntent() {
		return hlProductIntent;
	}

	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public String getL2productCode() {
		return l2productCode;
	}

	public void setL2productCode(String l2productCode) {
		this.l2productCode = l2productCode;
	}

	@Override
	public String toString() {
		return "SummaryResponse [totalAmount=" + totalAmount + ", netDisbursementAmount=" + netDisbursementAmount + ", totalFeeAmount=" + totalFeeAmount
				+ ", l2productCode=" + l2productCode + ", l3productCode=" + l3productCode + ", l4productCode=" + l4productCode + ", loanDetails=" + loanDetails
				+ ", feeList=" + feeList + ", childApplicationId=" + childApplicationId + ", bundleCost=" + bundleCost + ", bundleSelected=" + bundleSelected
				+ "]";
	}
}
