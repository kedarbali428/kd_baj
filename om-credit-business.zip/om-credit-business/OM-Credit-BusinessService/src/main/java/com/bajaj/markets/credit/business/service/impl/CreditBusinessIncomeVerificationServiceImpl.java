package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PARENT_APPLICATION_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PROCESS_ID;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessIncomeVerificationService;

@Component
public class CreditBusinessIncomeVerificationServiceImpl implements CreditBusinessIncomeVerificationService {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	WorkflowHelper workflowHelper;

	/**
	 * This method will complete income verification as well as salary
	 * identification user tasks. Does salary verification with channel partner.
	 * 
	 * @param Long        applicationId
	 * @param HttpHeaders headers
	 * @return ApplicationResponse applicationResponse
	 */
	@Override
	public ApplicationResponse completeIncomeVerification(Long applicationId, HttpHeaders headers) {

		ApplicationResponse incomeVerificationResponse = new ApplicationResponse();
		Map<String, Object> vars = new HashMap<String, Object>();
		vars.put(APPLICATION_ID, applicationId);
		vars.put(PARENT_APPLICATION_KEY, applicationId);
		
		// in case of email verification skip, action to set as activiti check in BFL journey
		vars.put("action", "");

		try {
			String nextTaskKey = workflowHelper.completeTask(headers.get(PROCESS_ID).get(0), vars);

			NextTask nextTask = new NextTask();
			Map<String, Object> incomeVerificationResponsePayload = new HashMap<String, Object>();
			nextTask.setNextTaskKey(nextTaskKey);
			Object segmentRerunFlag =(Boolean) workflowHelper.getFromExecutionMap(CreditBusinessConstants.IS_SEGMENT_RERUN, headers.get(PROCESS_ID).get(0));
			if (null != segmentRerunFlag) {
				incomeVerificationResponsePayload.put("segmentRerun", Boolean.valueOf(segmentRerunFlag.toString()));
			}
			
			incomeVerificationResponse.setPayload(incomeVerificationResponsePayload);
			incomeVerificationResponse.setNextTask(nextTask);

			return incomeVerificationResponse;

		} catch (CreditBusinessException e) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
					"Exception completing workflow task" + e);
			throw e;
		} catch (Exception e) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
					"Exception occured while calling the service" + e);
			throw new CreditBusinessException(e.getCause());
		}
	}

}
