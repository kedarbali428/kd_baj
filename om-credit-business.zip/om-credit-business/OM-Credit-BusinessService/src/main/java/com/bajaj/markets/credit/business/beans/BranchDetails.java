package com.bajaj.markets.credit.business.beans;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BranchDetails {

	private Long branchKey;
	@JsonProperty("bflbranchname")
	private String branchName;

	public Long getBranchKey() {
		return branchKey;
	}

	public void setBranchKey(Long branchKey) {
		this.branchKey = branchKey;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	@Override
	public String toString() {
		return "BranchDetails [branchKey=" + branchKey + ", branchName=" + branchName + "]";
	}

}
