package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.JOURNEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OCCUPATIONTYPECODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.USERPROFILEOUTPUT;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ProfileDetails;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EventMessageHelper;

@Component
public class BmrListener {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	EventMessageHelper eventHelper;

	private static final String CLASS_NAME = BmrListener.class.getCanonicalName();

	public void bmrMessageEvents(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start bmrMessageEvents");
		ApplicationDetail appDetails = (ApplicationDetail) execution.getVariable(CreditBusinessConstants.APPLICATION_DETAILS);
		JSONObject userProfile = CreditBusinessHelper.getJSONObject(execution.getVariable(USERPROFILEOUTPUT));
		String pan = userProfile.get(CreditBusinessConstants.PAN_NUMBER) != null ? userProfile.get(CreditBusinessConstants.PAN_NUMBER).toString() : null;
		
		ProfileDetails profileDetails = new ProfileDetails();
		profileDetails.setPan(pan);
		profileDetails.setPersonalEmailId(null!=execution.getVariable(CreditBusinessConstants.PERSONALEMAILID)?execution.getVariable(CreditBusinessConstants.PERSONALEMAILID).toString():null);
		profileDetails.setOccupation(execution.getVariable(OCCUPATIONTYPECODE).toString());

		eventHelper.publishBMR1Event(appDetails, profileDetails, JOURNEY);
		eventHelper.publishBMR2Event(appDetails, profileDetails, JOURNEY);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End bmrMessageEvents");
	}

}
