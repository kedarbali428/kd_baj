package com.bajaj.markets.credit.business.beans;

public class ProductOffer {

	private String offerCode; 
	private String offerDescription;
	
	public String getOfferCode() {
		return offerCode;
	}
	public void setOfferCode(String offerCode) {
		this.offerCode = offerCode;
	}
	public String getOfferDescription() {
		return offerDescription;
	}
	public void setOfferDescription(String offerDescription) {
		this.offerDescription = offerDescription;
	}
	@Override
	public String toString() {
		return "ProductOffer [offerCode=" + offerCode + ", offerDescription=" + offerDescription + "]";
	}
}