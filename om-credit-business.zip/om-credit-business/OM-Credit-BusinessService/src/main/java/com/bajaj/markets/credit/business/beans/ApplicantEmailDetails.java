package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

public class ApplicantEmailDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long apltEmailIdKey;

	private String apltEmailAddress;

	@Temporal(TemporalType.DATE)
	private Date apltEmailEndDt;

	private BigDecimal apltEmailIdIsVerified;

	private BigDecimal apltEmailIdPriority;

	private BigDecimal apltEmailIsActive;

	private String apltEmailLstUpdateBy;

	private Timestamp apltEmailLstUpdateDt;

	@Temporal(TemporalType.DATE)
	private Date apltEmailStartDt;

	private BigDecimal emailBounceFlag;

	@Temporal(TemporalType.DATE)
	private Date emailBounceDt;

	private Timestamp apltEmailVerificationDt;

	private String apltEmailVerificationSrc;

	private Long applicantKey;
	
	private Long emailTypeKey;

	public ApplicantEmailDetails() {
	}

	public Long getApltEmailIdKey() {
		return apltEmailIdKey;
	}

	public void setApltEmailIdKey(Long apltEmailIdKey) {
		this.apltEmailIdKey = apltEmailIdKey;
	}

	public String getApltEmailAddress() {
		return apltEmailAddress;
	}

	public void setApltEmailAddress(String apltEmailAddress) {
		this.apltEmailAddress = apltEmailAddress;
	}

	public Date getApltEmailEndDt() {
		return apltEmailEndDt;
	}

	public void setApltEmailEndDt(Date apltEmailEndDt) {
		this.apltEmailEndDt = apltEmailEndDt;
	}

	public BigDecimal getApltEmailIdIsVerified() {
		return apltEmailIdIsVerified;
	}

	public void setApltEmailIdIsVerified(BigDecimal apltEmailIdIsVerified) {
		this.apltEmailIdIsVerified = apltEmailIdIsVerified;
	}

	public BigDecimal getApltEmailIdPriority() {
		return apltEmailIdPriority;
	}

	public void setApltEmailIdPriority(BigDecimal apltEmailIdPriority) {
		this.apltEmailIdPriority = apltEmailIdPriority;
	}

	public BigDecimal getApltEmailIsActive() {
		return apltEmailIsActive;
	}

	public void setApltEmailIsActive(BigDecimal apltEmailIsActive) {
		this.apltEmailIsActive = apltEmailIsActive;
	}

	public String getApltEmailLstUpdateBy() {
		return apltEmailLstUpdateBy;
	}

	public void setApltEmailLstUpdateBy(String apltEmailLstUpdateBy) {
		this.apltEmailLstUpdateBy = apltEmailLstUpdateBy;
	}

	public Timestamp getApltEmailLstUpdateDt() {
		return apltEmailLstUpdateDt;
	}

	public void setApltEmailLstUpdateDt(Timestamp apltEmailLstUpdateDt) {
		this.apltEmailLstUpdateDt = apltEmailLstUpdateDt;
	}

	public Date getApltEmailStartDt() {
		return apltEmailStartDt;
	}

	public void setApltEmailStartDt(Date apltEmailStartDt) {
		this.apltEmailStartDt = apltEmailStartDt;
	}

	public BigDecimal getEmailBounceFlag() {
		return emailBounceFlag;
	}

	public void setEmailBounceFlag(BigDecimal emailBounceFlag) {
		this.emailBounceFlag = emailBounceFlag;
	}

	public Date getEmailBounceDt() {
		return emailBounceDt;
	}

	public void setEmailBounceDt(Date emailBounceDt) {
		this.emailBounceDt = emailBounceDt;
	}

	public Timestamp getApltEmailVerificationDt() {
		return apltEmailVerificationDt;
	}

	public void setApltEmailVerificationDt(Timestamp apltEmailVerificationDt) {
		this.apltEmailVerificationDt = apltEmailVerificationDt;
	}

	public String getApltEmailVerificationSrc() {
		return apltEmailVerificationSrc;
	}

	public void setApltEmailVerificationSrc(String apltEmailVerificationSrc) {
		this.apltEmailVerificationSrc = apltEmailVerificationSrc;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getEmailTypeKey() {
		return emailTypeKey;
	}

	public void setEmailTypeKey(Long emailTypeKey) {
		this.emailTypeKey = emailTypeKey;
	}

}