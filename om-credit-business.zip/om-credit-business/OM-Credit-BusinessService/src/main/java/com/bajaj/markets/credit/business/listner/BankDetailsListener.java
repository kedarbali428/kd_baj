package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICANTID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CHILDAPPLICATIONID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DATE_OF_BIRTH;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DOB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.JOURNEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2PRODUCTKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L3_PRODUCT_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PRINCIPALKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SPACE_DELIMETER;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.BankDetails;
import com.bajaj.markets.credit.business.beans.BankDetailsReponse;
import com.bajaj.markets.credit.business.beans.EmandateResponse;
import com.bajaj.markets.credit.business.beans.MandateBreRequest;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessBankDetailsService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class BankDetailsListener {

	@Autowired
	BFLLoggerUtilExt logger;
	
	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	
	@Autowired
	private CreditBusinessBankDetailsService creditBusinessBankDetailsService;
	
	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;
	
	public static final String CLASS_NAME = BankDetailsListener.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void preSaveBankDetails(DelegateExecution execution) {
		JSONObject branchDetails = (JSONObject) execution.getVariable("branchDetail");
		JSONObject bankDetailsJson = (JSONObject) execution.getVariable("bankDetail");
		
		Gson gson = new Gson();
		BankDetails bankDetails = gson.fromJson(bankDetailsJson.toString(), BankDetails.class);
		
		execution.setVariable("bankAccountNumber", bankDetails.getAccountNumber());
		execution.setVariable("ifscCode", bankDetails.getIfscCode());
		
		JSONObject bankDetailSaveRequest = new JSONObject();
		
		bankDetailSaveRequest.put("accoutNumber", bankDetails.getAccountNumber());
		bankDetailSaveRequest.put("bankAccountTypeKey", bankDetails.getBankAccountType());
		bankDetailSaveRequest.put("beneficiaryType", "CUSTOMER");
		bankDetailSaveRequest.put("branchKey", ((Double) branchDetails.get("branchKey")).longValue());
		bankDetailSaveRequest.put("bankMasterKey", ((Double) branchDetails.get("bankMasterKey")).longValue());
		bankDetailSaveRequest.put("holderName", bankDetails.getBankAccountHolderName());
		bankDetailSaveRequest.put("source", JOURNEY);
		bankDetailSaveRequest.put("userAttributeKey", execution.getVariable(APPLICATION_USER_ATTRIBUTE_KEY));
		if(null != bankDetails.getMandateReference() && !StringUtils.isEmpty(bankDetails.getMandateReference())) {
			bankDetailSaveRequest.put("finalMandateKey", bankDetails.getMandateReference());
			bankDetailSaveRequest.put("mandateAddedBy", bankDetails.getMandateAddedBy());
		}
		bankDetailSaveRequest.put("paymentMode", bankDetails.getRepaymentMode());
        bankDetailSaveRequest.put("invokeFromJourney", true);
		
		execution.setVariable(PAYLOAD, bankDetailSaveRequest);
	}
	
	public void postSaveBankDetails(DelegateExecution execution) {
		JSONObject bankDetailsResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
		execution.setVariable("bankDetailsKey", ((Double) bankDetailsResponse.get("bankDetailsKey")).longValue());
	}
	
	public void fetchPrimaryUserProfile(DelegateExecution execution) {
		ArrayList<?> userProfiles = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);

		if (null != userProfiles) {
			for (Object object : userProfiles) {
				JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
				if (null != userProfile && userProfile.get(APPLICATION_USER_ATTRIBUTE_TYPE).equals("1")) {
					execution.setVariable(APPLICATION_USER_ATTRIBUTE_KEY,
							userProfile.get(APPLICATION_USER_ATTRIBUTE_KEY));
					execution.setVariable(MOBILE, userProfile.get(MOBILE));
					execution.setVariable(DOB, userProfile.get(DATE_OF_BIRTH));
					JSONObject nameObject = CreditBusinessHelper.getJSONObject(userProfile.get(NAME));
					StringBuffer fullName = new StringBuffer(null != nameObject.get("firstName") ? nameObject.get("firstName").toString() + SPACE_DELIMETER : "");
					fullName.append(null != nameObject.get("middleName") ? nameObject.get("middleName").toString() + SPACE_DELIMETER : "")
						.append(null != nameObject.get("lastName") ? nameObject.get("lastName").toString() : "");
					execution.setVariable("fullName", fullName);
					break;
				}
			}
		}
	}
	
	public void preGetBankDetails(DelegateExecution execution) {
		execution.setVariable("preferredForRepayment", true);
	}
	
	public void postGetBankDetails(DelegateExecution execution) {
		ArrayList<?> bankDetails = (ArrayList<?>) execution.getVariable(OUTPUT);
		execution.setVariable("bankDetails", bankDetails);
	}
	
	public void postMandateGet(DelegateExecution execution, boolean isParentApplication) {
		Object mandateAvailable = execution.getVariable("mandateAvailable");
		if(null == mandateAvailable || (null != mandateAvailable && (boolean) mandateAvailable)) {
			ArrayList<?> mandateDetails =(ArrayList<?>) execution.getVariable(OUTPUT);
			if(!isParentApplication) {
				execution.setVariable("mandateDetailsForChild", mandateDetails);
			} else {
				execution.setVariable("mandateDetailsForParent", mandateDetails);
			}
		}
		execution.removeVariable("mandateAvailable");
	}

	@SuppressWarnings("unchecked")
	public void preMandateCreation(DelegateExecution execution) {
		JSONObject branchDetails = (JSONObject) execution.getVariable("branchDetail");
		JSONObject bankDetailsJson = (JSONObject) execution.getVariable("bankDetail");
	
		JSONObject mandateCreateRequest = new JSONObject();
		mandateCreateRequest.put("applicationKey", execution.getVariable(APPLICATION_ID));
		mandateCreateRequest.put("applicantKey", execution.getVariable(APPLICANTID));
		mandateCreateRequest.put("accountNumber", bankDetailsJson.get("accountNumber"));
		mandateCreateRequest.put("accountType", bankDetailsJson.get("bankAccountTypeKey"));
		mandateCreateRequest.put("bankName", branchDetails.get("bankName"));
		mandateCreateRequest.put("ifscCode", bankDetailsJson.get("ifscCode"));
		mandateCreateRequest.put("micrCode", branchDetails.get("branchMicrCode"));
		mandateCreateRequest.put("mobileNumber", execution.getVariable(MOBILE));
		mandateCreateRequest.put("name", execution.getVariable("fullName"));
		mandateCreateRequest.put("productMasterKey", "69");
		mandateCreateRequest.put("productCategoryCode", execution.getVariable(L2PRODUCTKEY));
		mandateCreateRequest.put("principal", execution.getVariable(PRINCIPALKEY));
		mandateCreateRequest.put("productCode", execution.getVariable(L3_PRODUCT_KEY));
		mandateCreateRequest.put("isRecurring", true);
		mandateCreateRequest.put("status", "CREATED");
		
		execution.setVariable(PAYLOAD, mandateCreateRequest);
	}
	
	public void prepareBreRequest(DelegateExecution execution) {
		try {
			
			List<BankDetailsReponse> bankDetailsResponses = mapper.convertValue(execution.getVariable("bankDetails"),
					new TypeReference<List<BankDetailsReponse>>() {
					});
			
			List<EmandateResponse> emandateResponses = new ArrayList<EmandateResponse>();;
			
			Object emandateDetailsForChildObject = execution.getVariable("mandateDetailsForChild");
			Object emandateDetailsForParentObject = execution.getVariable("mandateDetailsForParent");
			List<EmandateResponse> emandateResponseForChild = null;
			List<EmandateResponse> emandateResponseForParent = null;

			if(null != emandateDetailsForChildObject) {
				emandateResponseForChild = mapper.convertValue(emandateDetailsForChildObject, 
						new TypeReference<List<EmandateResponse>>() {});
				
				emandateResponses.addAll(emandateResponseForChild);
			}
			if(null != emandateDetailsForParentObject) {
				emandateResponseForParent = mapper.convertValue(emandateDetailsForParentObject, 
						new TypeReference<List<EmandateResponse>>() {});
				
				emandateResponses.addAll(emandateResponseForParent);
			}
			
			HttpHeaders headers = new HttpHeaders();
			CreditBusinessHelper.updateHttpHeaders(headers, customDefaultHeaders);
			
			Map<String, String> params = new HashMap<String, String>();
			params.put(APPLICATION_ID, execution.getVariable(CHILDAPPLICATIONID).toString());
			
			MandateBreRequest mandateBreRequest = creditBusinessBankDetailsService.
					createBreRequest(bankDetailsResponses, emandateResponses, params, headers);
			
			mandateBreRequest.setMandateBRECallType(2l);
			
			Gson gson = new Gson();
			String mandateBreRequestJson = gson.toJson(mandateBreRequest);
			
			execution.setVariable(PAYLOAD, mandateBreRequestJson);
			
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Exception occurred while creating BRE request: " + e);
			throw e;
		}
	}
	
	public void postBreCall(DelegateExecution execution) {
		JSONObject mandateBreResposne = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
		
		execution.setVariable("mandateRequired", true);
		
		Object mandateRequired = mandateBreResposne.get("mandateRequiredFlag");
		if(null != mandateRequired) {
			execution.setVariable("mandateRequired", mandateRequired);
			execution.setVariable("preferredMandate", mandateBreResposne);	
		}
	}
	
	@SuppressWarnings("unchecked")
	public void preMandateUpdate(DelegateExecution execution) {
		JSONObject preferredMandateObject = (JSONObject) execution.getVariable("preferredMandate");
		JSONObject preferredMandate = CreditBusinessHelper.getJSONObject(preferredMandateObject.get("mandateDetails"));
		
		JSONObject mandateUpdateRequest = new JSONObject();
		mandateUpdateRequest.put("applicationKey", execution.getVariable(APPLICATION_ID));
		mandateUpdateRequest.put("applicantKey", execution.getVariable(APPLICANTID));
		mandateUpdateRequest.put("accountNumber", preferredMandate.get("accountNo"));
		mandateUpdateRequest.put("accountType", null); // not getting account type from mandate bre
		mandateUpdateRequest.put("bankName", preferredMandate.get("bankName"));
		mandateUpdateRequest.put("ifscCode", preferredMandate.get("ifscCode"));
		mandateUpdateRequest.put("micrCode", preferredMandate.get("micrCode"));
		mandateUpdateRequest.put("mobileNumber", execution.getVariable(MOBILE));
		mandateUpdateRequest.put("name", execution.getVariable("fullName"));
		mandateUpdateRequest.put("productMasterKey", "69");
		mandateUpdateRequest.put("productCategoryCode", execution.getVariable(L2PRODUCTKEY));
		mandateUpdateRequest.put("principal", execution.getVariable(PRINCIPALKEY));
		mandateUpdateRequest.put("productCode", execution.getVariable(L3_PRODUCT_KEY));
		mandateUpdateRequest.put("isRecurring", true);
		mandateUpdateRequest.put("chanelMandateRefId", preferredMandate.get("channelMandateReferenceId"));
		mandateUpdateRequest.put("limit", null != preferredMandate.get("maxLimit") ? 
				((Double) preferredMandate.get("maxLimit")).longValue() : null);
		mandateUpdateRequest.put("balanceLimit", null != preferredMandate.get("balanceLimit") ?
				((Double) preferredMandate.get("balanceLimit")).longValue() : null);
		mandateUpdateRequest.put("umrn", preferredMandate.get("mandateRegistrationNumber"));
		mandateUpdateRequest.put("mandateUpdateSource", CreditBusinessConstants.JOURNEY);

		execution.setVariable("mandateReference", preferredMandate.get("mandatereference"));
		
		execution.setVariable(PAYLOAD, mandateUpdateRequest);
	}
	
}
