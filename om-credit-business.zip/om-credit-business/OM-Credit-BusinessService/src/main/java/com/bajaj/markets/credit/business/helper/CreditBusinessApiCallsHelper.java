package com.bajaj.markets.credit.business.helper;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponentsBuilder;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationStageDetails;
import com.bajaj.markets.credit.business.beans.BankMaster;
import com.bajaj.markets.credit.business.beans.BranchDetails;
import com.bajaj.markets.credit.business.beans.CibilResponse;
import com.bajaj.markets.credit.business.beans.CityResponseBean;
import com.bajaj.markets.credit.business.beans.CustDerivedIndustryMaster;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.EmployerTypeBean;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.IndustryMaster;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OccupationReference;
import com.bajaj.markets.credit.business.beans.Pincode;
import com.bajaj.markets.credit.business.beans.PricingDetail;
import com.bajaj.markets.credit.business.beans.PrincipalBean;
import com.bajaj.markets.credit.business.beans.ProductList;
import com.bajaj.markets.credit.business.beans.PropertyPageDetails;
import com.bajaj.markets.credit.business.beans.Qualification;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.beans.ResponseBean;
import com.bajaj.markets.credit.business.beans.Specilizations;
import com.bajaj.markets.credit.business.beans.TokenResponse;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

/**
 * Helper class to call commonly used API across business service
 * 
 * @author 764504
 */
@Component
@Scope("prototype")
public class CreditBusinessApiCallsHelper {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private Environment env;

	@Autowired
	@Lazy
	CreditBusinessHelper creditBusinessHelper;

	@Value("${api.omcreditapplicationservice.getprofessionreferencedata.get.url}")
	private String getOccupationsReferences;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getOccupationUrl;

	@Value("${api.omreferencedatareferencedataservice.location.residence.get.url}")
	private String getResitypes;

	@Value("${api.omcreditapplicationservice.getaddress.get.url}")
	private String getAddressURL;

	@Value("${api.omreferencedatareferencedataservice.location.pincodekey.get.url}")
	private String getAddressOnPincodeKeyUrl;

	@Value("${api.omreferencedatareferencedataservice.getemployer.get.url}")
	private String getEmployer;

	@Value("${api.omreferencedatareferencedataservice.lookup.code.get.url}")
	private String getLookupUrl;

	@Value("${api.omverificationverificationdomainservice.verifypan.get.url}")
	private String getPanVerification;

	@Value("${api.omcreditapplicationservice.bmrdetails.GET.url}")
	private String getBmrDetails;
	
	@Value("${api.omcreditapplicationservice.bmr2response.mongodetail.GET.url}")
	private String getBmr2ResponseFromMongo;

	@Value("${api.omreferencedatareferencedataservice.location.industry.get.url}")
	private String getIndustryType;

	@Value("${api.omcreditapplicationservice.userprofiles.get.url}")
	private String getUserProfilesUrl;

	@Value("${api.omcreditapplicationservice.propertydetails.get.url}")
	private String getPropertyDetailsUrl;

	@Value("${api.omcreditapplicationservice.getapplicationproduct.get.url}")
	private String getApplicationProduct;

	@Autowired
	CustomDefaultHeaders customHeaders;

	@Value("${api.omverificationverificationdomainservice.creditvidya.GET.url}")
	private String getCreditVidyaStatus;

	@Value("${api.omverificationverificationdomainservice.verification.income.estimation.GET.url}")
	private String getIncomeEstimationURL;

	@Value("${api.omverificationverificationdomainservice.verification.income.estimation.details.GET.url}")
	private String getIncomeEstimationJsonURL;

	@Value("${api.omreferencedataservice.bank.bankmasterkey.GET.url}")
	private String getBankMasterUrl;

	@Value("${api.applicationservice.productlist.get.url}")
	private String getProductListUrl;

	@Value("${api.omreferencedata.industrytype.industrymasterkey.param.url}")
	private String industryTypeURL;
	
	@Value("${api.omcreditapplicationservice.creditapplication.get.url}")
	private String getCreditApplication;

	@Value("${api.omcreditapplicationservice.principalcustinfo.offers.url}")
	private String principalCustInfo;

	@Value("${api.omcreditapplicationservice.getemail.get.url}")
	private String getEmailUrl;
	
	@Value("${api.omcreditapplicationservice.application.offers.GET.url}")
	private String getOffersUrl;
	
	@Value("${api.omcreditapplicationservice.verification.PUT.url}")
	private String updateVerificationDetailUrl;
	
	@Value("${api.omreferencedatareferencedataservice.location.pincode.get.url}")
	private String getPincodeMasterByPincodeUrl;
	
		@Value("${api.omcibilverificationservice.cibil.details.get.url}")
	private String getCibilDocumentUrl;
	
	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String getChildApplicationsUrl;
	
	@Value("${api.omcreditapplicationservice.address.GET.url}")
	private String getAddressURLV2;
	
	@Value("${api.omcreditapplicationservice.getdocument.get.url}")
	private String documentDetailUrl;

	@Value("${api.referencedata.specilization.GET.url}")
	private String specialisationUrl;

	@Value("${api.referencedata.qaulify.GET.url}")
	private String qualificationUrl;
	
	@Value("${api.omcreditapplicationservice.loan.pricing.get.url}")
	private String getLoanPricingUrl;
	
	@Value("${api.omcreditapplicationservice.creditapplication.parameters.url}")
	private String getAppParamDetails;

	private static final String CLASSNAME = CreditBusinessApiCallsHelper.class.getName();

	/**
	 * Method to call Occupation from master data for applicationId and userAttributeKey
	 * 
	 * @param Map param, containig 
	 * @return OccupationReference instace from master data
	 */
	public OccupationReference getOccupationValue(Map<String, String> params) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getOccupation");
		Occupation occupation = null;
		try {
			occupation = callApi(getOccupationUrl, HttpMethod.GET, params, null, Occupation.class);
		} catch (CreditBusinessException businessException) {
			if (HttpStatus.NOT_FOUND.equals(businessException.getCode())) {
				return null;
			}
			throw businessException;
		}
		if (occupation != null && occupation.getOcupationType() != null && occupation.getOcupationType().getKey() != null) {
			Reference occType = occupation.getOcupationType();
			OccupationReference[] occupationReferenceArr = callApi(getOccupationsReferences, HttpMethod.GET, null, null, OccupationReference[].class);
			for (OccupationReference occRef : occupationReferenceArr) {
				if (occType.getKey().equals(occRef.getOccupationKey())) {
					return occRef;
				}
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End getOccupation no occupation found");
		return null;
	}

	/**
	 * @deprecated Instead use getUserProfile() method 
	 * 
	 * @param Map params contains application key 
	 * @return String userAttributKey
	 */
	@Deprecated
	public String getUserAttributeKey(Map<String, String> params) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getUserAttributeKey");
		UserProfileBean userProfile = getUserProfile(params);
		if (userProfile != null) {
			logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "End getUserAttributeKey ");
			return userProfile.getApplicationUserAttributeKey();
		}
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "End getUserAttributeKey :: userProfile not found");
		return null;
	}

	/**
	 * @param Map params contains application key
	 * @return Object UserProfile
	 */
	public UserProfileBean getUserProfile(Map<String, String> params) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getUserProfile");
		UserProfileBean[] userProfileList = callApi(getUserProfilesUrl, HttpMethod.GET, params, null, UserProfileBean[].class);
		for (UserProfileBean userProfile : userProfileList) {
			if (userProfile.getApplicationUserAttributeType().equals("1")) {
				logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "End getUserProfile ");
				return userProfile;
			}
		}
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "End getUserAttributeKey :: userAttributeKey is null");
		return null;
	}

	/**
	 * @param Map params contains application key
	 * @return Object UserProfile
	 */
	public UserProfileBean getUserProfile(Map<String, String> params, String applicantType, Boolean allApplicantRequired) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getUserProfile");
		String url = getUserProfilesUrl;
		if (allApplicantRequired) {
			url = UriComponentsBuilder.fromUriString(url).queryParam("allApplicantRquired", allApplicantRequired).build().toUriString();
		}
		UserProfileBean[] userProfileList = callApi(url, HttpMethod.GET, params, null, UserProfileBean[].class);
		for (UserProfileBean userProfile : userProfileList) {
			if (userProfile.getApplicationUserAttributeType().equals(applicantType)) {
				logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "End getUserProfile ");
				return userProfile;
			}
		}
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "End getUserAttributeKey :: userAttributeKey is null");
		return null;
	}

	public OccupationReference getOccupationMasterFromOccupationId(Long occupationId) {
		if (occupationId != null) {
			OccupationReference[] occupationReferenceArr = callApi(getOccupationsReferences, HttpMethod.GET, null, null, OccupationReference[].class);
			for (OccupationReference occRef : occupationReferenceArr) {
				if (occupationId.equals(occRef.getOccupationKey())) {
					return occRef;
				}
			}
		}
		return null;
	}

	/**
	 * Method to call all Resitypes from master data
	 * 
	 * @return ResidenceMaster[]  from master data
	 */
	public ResidenceMaster[] getAllResitypes() {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getAllResitypes");
		ResidenceMaster[] resiTypes = callApi(getResitypes, HttpMethod.GET, null, null, ResidenceMaster[].class);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End getAllResitypes ");
		return resiTypes;
	}

	/**
	 * Method to get  lookup by its code
	 * 
	 * @return JSONObject   
	 */
	public JSONObject getLookupByCode(String lookupCode) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getLookup");
		Map<String, String> params = new HashMap<>();
		params.put("lkpcode", lookupCode);
		JSONObject lookups = callApi(getLookupUrl, HttpMethod.GET, params, null, JSONObject.class);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End getLookup ");
		return lookups;
	}

	/**
	 * Method to call all Address of given type for application
	 * 
	 * @return Address 
	 */
	public Address getAddress(HttpHeaders headers, Map<String, String> params) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching address for params : " + params);
		Address currentAddress = callApi(getAddressURL, HttpMethod.GET, params, null, Address.class);
		if (null != currentAddress && !StringUtils.isEmpty(currentAddress.getPincodeKey())) {
			setPinCode(currentAddress, params);
		}
		return currentAddress;
	}

	private void setPinCode(Address address, Map<String, String> params) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching pincode for params : " + params);
		if (address != null && params != null) {
			params.put("pincodeKey", address.getPincodeKey());
			LocationResponseBean locationAddressBean = callApi(getAddressOnPincodeKeyUrl, HttpMethod.GET, params, null, LocationResponseBean.class);
			if (null != locationAddressBean) {
				address.setPincode(locationAddressBean.getPincode());
				address.setCityName(locationAddressBean.getCityName());
			}
			address.setPinCodeBean(locationAddressBean);
		}
	}

	/**
	 * Method to call all PinCode master data  of given pincodekey
	 * 
	 * @return LocationResponseBean 
	 */
	public LocationResponseBean getPinCodeMaster(String pincodeKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching PinCode master for PinCode: " + pincodeKey);
		if (pincodeKey != null) {
			Map<String, String> params = new HashMap<>();
			params.put("pincodeKey", pincodeKey);
			return callApi(getAddressOnPincodeKeyUrl, HttpMethod.GET, params, null, LocationResponseBean.class);
		}
		return null;
	}

	/**
	 * Method to call all EmployerMaster master data  of given employerId
	 * 
	 * @return JSONObject 
	 */
	@SuppressWarnings("unchecked")
	public JSONObject getEmployerMaster(Long employerId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching getEmployerMaster for employerId : " + employerId);
		JSONObject employerMaster = null;
		if (null!=employerId) {
			Map<String, String> params = new HashMap<>();
			params.put("employerid", employerId.toString());
			try {
				ResponseEntity<JSONObject> empMasterResponse = (ResponseEntity<JSONObject>) creditBusinessHelper
						.invokeRestEndpoint(HttpMethod.GET, getEmployer, JSONObject.class, params, null,
								new HttpHeaders());
				employerMaster = null != empMasterResponse ? empMasterResponse.getBody() : null;
			} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.PROCESSOR,
						"setEmployerNameAndSalary: No record found for employerId" + employerId.toString());
			}
		}
		return employerMaster;
	}

	/**
	 * Method to call all PanVerification from verification schema for given applicationId
	 * 
	 * @return JSONObject 
	 */
	public JSONObject getPanVerification(Long applicationKey, Long applicantKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching getPanVerification for application : " + applicationKey);
		JSONObject employerMaster = null;
		if (applicationKey != null && applicantKey != null) {
			Map<String, String> params = new HashMap<>();
			params.put("applicationid", applicationKey.toString());
			params.put("applicantid", applicantKey.toString());
			employerMaster = callApi(getPanVerification, HttpMethod.GET, params, null, JSONObject.class);
		}
		return employerMaster;
	}

	/**
	 * Method to call all BMR response for given applicationId
	 * 
	 * @return JSONObject 
	 */
	public String getBmrDetails(String applicationKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching getBmrDetails for application : " + applicationKey);
		String bmrDetails = null;
		if (applicationKey != null) {
			Map<String, String> params = new HashMap<String, String>();
			params.put("applicationid", applicationKey);
			bmrDetails = callApi(getBmrDetails, HttpMethod.GET, params, null, String.class);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "completed getBmrDetails for application : " + applicationKey);
		return bmrDetails;
	}
	
	public String getBmr2ResponseFromMongo(String applicationKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"fetching getBmr2Response from Mongo for application : " + applicationKey);
		String bmr2Response = null;
		if (applicationKey != null) {
			Map<String, String> params = new HashMap<>();
			params.put("applicationid", applicationKey);
			bmr2Response = callApi(getBmr2ResponseFromMongo, HttpMethod.GET, params, null, String.class);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"completed getBmr2Response for application : " + applicationKey);
		return bmr2Response;
	}
	

	@SuppressWarnings("unchecked")
	public <T> T callApi(String url, HttpMethod methodType, Map<String, String> queryParam, String requestJson, Class<T> responseType) {
		ResponseEntity<T> apiResponse = (ResponseEntity<T>) creditBusinessHelper.invokeRestEndpoint(methodType, url, responseType, queryParam, requestJson,
				new HttpHeaders());
		return apiResponse != null ? apiResponse.getBody() : null;
	}

	public String getIndustryType(Long industryTypeKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching getBmrDetails for industryTypeKey : " + industryTypeKey);
		ObjectMapper mapper = new ObjectMapper();
		String industryType = null;
		ResponseEntity<?> getIndustryMasterRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getIndustryType, Object.class, null, null,
				new HttpHeaders());
		List<CustDerivedIndustryMaster> custDerivedIndustryMasterList = mapper.convertValue(getIndustryMasterRes.getBody(),
				new TypeReference<List<CustDerivedIndustryMaster>>() {
				});
		for (CustDerivedIndustryMaster custDerivedIndustryMaster : custDerivedIndustryMasterList) {
			if (custDerivedIndustryMaster.getCustIndMastKey().equals(industryTypeKey)) {
				industryType = custDerivedIndustryMaster.getCustIndMastDesc();
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "completed getBmrDetails for industryTypeKey : " + industryTypeKey);
		return industryType;
	}

	public PropertyPageDetails getPropertyDetails(String childAppId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getPropertyDetails for applicationid : " + childAppId);
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", childAppId);
		ResponseEntity<?> propertyDetailsResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getPropertyDetailsUrl, PropertyPageDetails.class,
				params, null, new HttpHeaders());
		PropertyPageDetails propertyDetails = (PropertyPageDetails) propertyDetailsResponse.getBody();
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End getPropertyDetails for applicationid : " + childAppId);
		return propertyDetails;
	}

	public ApplicationDetail getHlProductIntent(String childAppId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getHlProductIntent for applicationid : " + childAppId);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", childAppId);
		ResponseEntity<?> getApplicationProductResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getApplicationProduct,
				ApplicationDetail.class, params, null, new HttpHeaders());
		ApplicationDetail applicationDetail = (ApplicationDetail) getApplicationProductResponse.getBody();
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End getHlProductIntent for applicationid : " + childAppId);
		return applicationDetail;
	}

	public Pincode getPropertyAddressDetails(String childAppId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getPropertyAddressDetails for applicationid : " + childAppId);
		Address address = null;
		LocationResponseBean addressBean = null;
		String appAttributeKey = null;
		Pincode pinCode = null;
		ObjectMapper mapper = new ObjectMapper();
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", childAppId);
		ResponseEntity<?> userProfileResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getUserProfilesUrl, List.class, params, null,
				new HttpHeaders());
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<UserProfileBean> userProfileList = mapper.convertValue(userProfileResponse.getBody(), new TypeReference<List<UserProfileBean>>() {
		});
		for (UserProfileBean userProfile : userProfileList) {
			if (userProfile.getApplicationUserAttributeType().equals("1")) {
				appAttributeKey = userProfile.getApplicationUserAttributeKey();
			}
		}
		params.put("typeKey", "95");
		params.put("applicationid", childAppId);
		params.put("userattributekey", appAttributeKey);
		ResponseEntity<?> addressResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getAddressURL, Address.class, params, null,
				new HttpHeaders());
		address = (Address) addressResponse.getBody();
		pinCode = new Pincode();
		pinCode.setAddressLine1(address.getAddressLine1());
		pinCode.setAddressLine2(address.getAddressLine2());
		// Call datareference service
		if (null != address && !StringUtils.isEmpty(address.getPincodeKey())) {
			params.put("pincodeKey", address.getPincodeKey());

			ResponseEntity<?> getPinDetails = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getAddressOnPincodeKeyUrl, LocationResponseBean.class,
					params, null, new HttpHeaders());
			addressBean = (LocationResponseBean) getPinDetails.getBody();
			pinCode.setPincode(addressBean.getPincode());
			pinCode.setCity(getReference(addressBean.getCityKey(), addressBean.getCityCode(), addressBean.getCityName()));
			pinCode.setCountry(getReference(addressBean.getCountryKey(), addressBean.getCountryCode(), addressBean.getCountryName()));
			pinCode.setState(getReference(addressBean.getStateKey(), addressBean.getStateCode(), addressBean.getStateName()));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End getPropertyAddressDetails for applicationid : " + childAppId);
		return pinCode;
	}

	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;
	}

	public String getSOLIndustryType(Integer industryMasterKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching getSOLIndustryType for industryMasterKey : " + industryMasterKey);
		ObjectMapper mapper = new ObjectMapper();
		String industryType = null;
		Map<String, String> params = new HashMap<>();
		params.put("industryMasterKey",industryMasterKey.toString());
		ResponseEntity<?> getIndustryMasterResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,industryTypeURL, Object.class, params,
				null, new HttpHeaders());
		if(getIndustryMasterResponse!=null && getIndustryMasterResponse.getBody()!=null) {
			List<IndustryMaster> industryMasterList = mapper.convertValue(getIndustryMasterResponse.getBody(),
					new TypeReference<List<IndustryMaster>>() {
					});
			industryType = industryMasterList.get(0).getIndustryMasterDesc();
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "completed getSOLIndustryType for industryMasterKey : " + industryMasterKey);
		return industryType;
	}
	
	/**
	 * Method to call all CreditVidya from VerificationDomain for given applicationId & applicantId
	 * 
	 * @return JSONObject 
	 */
	public JSONObject getCreditVidyaStatus(String applicationKey, Long applicantKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"fetching creditVidyaStatus for application : " + applicationKey + " and applicantKey " + applicantKey);
		JSONObject getCreditVidyaStatusOutput = null;
		if (applicationKey != null) {
			Map<String, String> params = new HashMap<>();
			params.put("applicationKey", applicationKey);
			params.put("applicantKey", applicantKey != null ? applicantKey.toString() : null);
			getCreditVidyaStatusOutput = callApi(getCreditVidyaStatus, HttpMethod.GET, params, null, JSONObject.class);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "completed creditVidyaStatus for application : " + applicationKey);
		return getCreditVidyaStatusOutput;
	}

	public JSONObject getIncomeEstimation(String applicationKey,String applicantkey) {
		JSONObject incomeEstimationResponse = null;
		try {
			Map<String, String> params = new HashMap<>();
			params.put("applicationid", applicationKey);
			params.put("applicantkey", applicantkey);

			ResponseEntity<?> incomeEstimationResponseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getIncomeEstimationURL, List.class,
					params, null, new HttpHeaders());

			if (null != incomeEstimationResponseEntity.getBody()) {
				List<Object> incomeEstimationResponseList = (ArrayList<Object>) incomeEstimationResponseEntity.getBody();
				incomeEstimationResponse = CreditBusinessHelper.getJSONObject(incomeEstimationResponseList.get(0));
			}

		} catch (CreditBusinessException businessException) {
			if (HttpStatus.NOT_FOUND.equals(businessException.getCode())) {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "income estimation not present for application: " + applicationKey);
			} else {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Call failed while fetching income estimation details for application: " + applicationKey);
				throw new CreditBusinessException(businessException.getCode(), new ErrorBean("CBS-551", "Service Call failure!"));
			}
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occurred while calling income estimation for application: " + applicationKey);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-500", "Some technical exception occurred!"));
		}

		return incomeEstimationResponse;
	}

	/**
	 * Method to call all Bank master data  of given bankMasterId
	 * 
	 * @return JSONObject 
	 */
	public BankMaster[] getBankDetails(Long bankMasterKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching getBankDetails for bankMasterKey : " + bankMasterKey);
		BankMaster[] bankMaster = null;
		if (bankMasterKey != null) {
			Map<String, String> params = new HashMap<>();
			params.put("bankMasterKey", bankMasterKey.toString());
			bankMaster = callApi(getBankMasterUrl, HttpMethod.GET, params, null, BankMaster[].class);
		}
		return bankMaster;
	}

	public ProductList getProductListForApplication(String applicationId) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getProductListForApplication ");
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("applicationid", applicationId);
		ProductList apiResponse = callApi(getProductListUrl, HttpMethod.GET, queryParam, null, ProductList.class);
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "Response = " + apiResponse);
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "End getProductListForApplication ");
		return apiResponse;
	}

	public String fetchIncomeEstimatedChannelJson(String incomeImputationKey) {
		String channelJson = null;
		try {
			Map<String, String> params = new HashMap<>();
			params.put("estimatedincomeRef", incomeImputationKey);

			ResponseEntity<?> channelReponseBody = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getIncomeEstimationJsonURL, Object.class, params,
					null, new HttpHeaders());

			if (null != channelReponseBody.getBody()) {
				JSONObject channelResponse = CreditBusinessHelper.getJSONObject(channelReponseBody.getBody());
				channelJson = null != channelResponse.get("channelResponse") ? channelResponse.get("channelResponse").toString() : null;
			}
		} catch (CreditBusinessException businessException) {
			if (HttpStatus.NOT_FOUND.equals(businessException.getCode())) {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "income estimation channel json not present for: " + incomeImputationKey);
			} else {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
						"Call failed while fetching income estimation json" + " for incomeImputationKey: " + incomeImputationKey);
				throw new CreditBusinessException(businessException.getCode(), new ErrorBean("CBS-551", "Service Call failure!"));
			}
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Exception occurred while calling income estimation json" + " for incomeImputationKey: " + incomeImputationKey);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-500", "Some technical exception occurred!"));
		}
		return channelJson;
	}

	@SuppressWarnings("unchecked")
	public ApplicationDetail getApplicationDetails(String applicationid, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start  getApplicationDetails: " + applicationid);
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("applicationid", applicationid);
		ResponseEntity<ApplicationDetail> responseEntity = (ResponseEntity<ApplicationDetail>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				getCreditApplication, ApplicationDetail.class, queryParam, null, headers);
		if (responseEntity != null && HttpStatus.OK.equals(responseEntity.getStatusCode()) && responseEntity.getBody() != null) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Response from getApplicationDetails: " + responseEntity);
			return responseEntity.getBody();
		}
		logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Error while fetching Application Details for applicationId == " + applicationid);
		throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("OMCB_022", "Error while fetching Application Details"));
	}

	/**
	 * Method to get principalCustInfo
	 * 
	 * @return JSONObject 
	 */
	public JSONObject getPrincipalCustInfo(String applicationKey, String principalKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"fetching getPrincipalCustInfo for application : " + applicationKey + " and principalKey " + principalKey);
		JSONObject output = null;
		if (applicationKey != null) {
			Map<String, String> params = new HashMap<>();
			params.put("applicationid", applicationKey);
			params.put("principalkey", principalKey);
			output = callApi(principalCustInfo, HttpMethod.GET, params, null, JSONObject.class);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "completed getPrincipalCustInfo for application : " + applicationKey);
		return output;
	}

	/**
	 * Method to get Email details
	 * 
	 * @return Email.class
	 */
	public Email getEmail(String applicationKey, String userattributekey, String emailTypeKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"fetching Emails for application : " + applicationKey + ", userattributekey = " + userattributekey + " and emailType " + emailTypeKey);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationKey);
		params.put("userattributekey", userattributekey);
		params.put("typeKey", emailTypeKey);
		Email email = callApi(getEmailUrl, HttpMethod.GET, params, null, Email.class);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Completed fetching Emails for application : " + applicationKey + ", userattributekey = "
				+ userattributekey + " and emailType " + emailTypeKey);
		return email;
	}

	public List<AppOfferDetBean> fetchOffers(String applicationId, String productCode, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start - fetchOffers for: " + applicationId);
		List<AppOfferDetBean> offerList = null;
		try {
			Map<String, String> params = new HashMap<>();

			params.put("applicationid", applicationId);
			params.put("productCode", productCode);

			ResponseEntity<?> offerResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getOffersUrl, List.class, params, null, headers);

			if (null != offerResponse) {
				ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				offerList = mapper.convertValue(offerResponse.getBody(), new TypeReference<List<AppOfferDetBean>>() {
				});
			}

		} catch (CreditBusinessException businessException) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Offer Fetch API call failure: " + applicationId);
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Offer Fetch Failed for: " + applicationId, exception);
		}

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End - fetchOffers for: " + applicationId);
		return offerList;
	}
	
	@SuppressWarnings("unchecked")
	public void saveVerificationDetails(String applicationKey, String verificationAttribute, String verificationSource){
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside saveVerificationDetails, applicationId: " + applicationKey);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("applicationKey", applicationKey);
		jsonObject.put("verificationAttribute", verificationAttribute);
		jsonObject.put("verificationSource", verificationSource);
		jsonObject.put("isVerified", 1);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		try {
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateVerificationDetailUrl,Object.class, null, jsonObject.toJSONString(), headers);
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "End saveVerificationDetails method details saved successfully for applicationId: " + applicationKey);
		} catch (Exception e) {
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside saveVerificationDetails Error occurred while saving details for applicationId: " + applicationKey);
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside saveVerificationDetails Error occurred while saving details for applicationId: " + applicationKey, e);
		}
	}
	
	/**
	 * Method to call PinCode master data of given pincode
	 * 
	 * @return LocationAddressBean
	 */
	public LocationAddressBean getPinCodeMasterByPinCode(String pincode) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching PinCode master for PinCode: " + pincode);
		Map<String, String> params = new HashMap<>();
		params.put("pincode", pincode);
		return callApi(getPincodeMasterByPincodeUrl, HttpMethod.GET, params, null, LocationAddressBean.class);
	}

	public String getCommercialFormatCibil(String cibilReferenceKey, String cibilType, String format) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"fetching Commercial format cibil for cibilReferenceKey " + cibilReferenceKey);
		Map<String, String> params = new HashMap<>();
		params.put("cibilreference", cibilReferenceKey);
		params.put("cibiltype", cibilType);
		params.put("format", format);
		return callApi(getCibilDocumentUrl, HttpMethod.GET, params, null, String.class);
	} 
	
	/**
	 * Method to call all all Address' (V2) 
	 * 
	 * @return Address List 
	 */
	public List<Address> getAddressV2(HttpHeaders headers, Map<String, String> params) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "into getAddressV2() fetching address for params : " + params);
		List<Address> addressList = null;
		List<?> response = callApi(getAddressURLV2, HttpMethod.GET, params, null, List.class);
		if (!CollectionUtils.isEmpty(response)) {
			ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			addressList = mapper.convertValue(response, new TypeReference<List<Address>>() {
			});
			addressList.forEach(address -> {
				if (address.getPincodeKey() != null) {
					setPinCode(address, params);
				}
			});
		}
		return addressList;
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public String getInternalToken(String applicationId) {
		String correlationId = "undefined|" + applicationId;
		BFLLoggerUtil.debug(correlationId, CLASSNAME, BFLLoggerComponent.UTILITY, "getInternalToken - start ");
		JSONObject jObj = new JSONObject();
		jObj.put("userType", "99");

		String reqestjson = jObj.toString();

		ResponseEntity<ResponseBean> responseEntity = (ResponseEntity<ResponseBean>) creditBusinessHelper
				.invokeRestEndpoint(HttpMethod.POST, env.getProperty("api.tokenmanagement.generatetoken.POST.url"),
						ResponseBean.class, null, reqestjson, new HttpHeaders());
		BFLLoggerUtil.debug(correlationId, CLASSNAME, BFLLoggerComponent.UTILITY,
				"tokenResponse " + responseEntity.getBody().getPayload() + "Status:" + responseEntity.getStatusCode());

		if (null != responseEntity && HttpStatus.OK.equals(responseEntity.getStatusCode())
				&& null != responseEntity.getBody()) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			TokenResponse tokenResponse = mapper.convertValue(responseEntity.getBody().getPayload(),
					TokenResponse.class);
			BFLLoggerUtil.debug(correlationId, CLASSNAME, BFLLoggerComponent.UTILITY, "getInternalToken - end ");
			return tokenResponse.getTokens().get(0).getToken();
		} else {
			BFLLoggerUtil.error(correlationId, CLASSNAME, BFLLoggerComponent.UTILITY,
					"not a valid internal token response: " + responseEntity);
			throw new CreditBusinessException(HttpStatus.EXPECTATION_FAILED,
					new ErrorBean("OMCB_070", "Error occured while generating internal tokens "));
		}

	}
	
	public List<EmployerTypeBean> getEmployeeTypes() {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start - getEmployeeTypes" );
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ResponseEntity<?> employerTypeResponseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				env.getProperty("api.omreferencedatareferencedataservice.employertype.get.url"), Object.class, null,
				null, new HttpHeaders());
		return mapper.convertValue(employerTypeResponseEntity.getBody(),
				new TypeReference<List<EmployerTypeBean>>() {
				});
	}
	
	public CityResponseBean getCityDetails(String cityKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start - getCityDetails");
		Map<String, String> params = new HashMap<>();
		params.put("citykey", cityKey);
		ResponseEntity<?> cityResponseBeanResp = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				env.getProperty("api.omreferencedata.city.GET.url"), String.class, params, null, new HttpHeaders());
		try {
			return (new ObjectMapper()).readValue(cityResponseBeanResp.getBody().toString(),
					new TypeReference<CityResponseBean>() {
					});
		} catch (Exception e) {
			return new CityResponseBean();
		}
	}
	
	public BranchDetails getBranchDetails(String cityKey,String branchKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start - getBranchDetails" );
		Map<String, String> params = new HashMap<>();
		params.put("citykey", cityKey);
		params.put("branchKey", branchKey);
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ResponseEntity<?> branchResponseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				env.getProperty("api.omreferencedata.bflbranches.GET.url"), Object.class, params,
				null, new HttpHeaders());
		return mapper.convertValue(branchResponseEntity.getBody(),
				new TypeReference<BranchDetails>() {
				});
	}
	
	public ApplicationStageDetails getStageDetails(String applicationKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"fetching getStageDetails for application : " + applicationKey);
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", applicationKey);
		ApplicationStageDetails applicationStageDetails = callApi(
				env.getProperty("api.omcreditapplicationservice.updatestage.put.url"), HttpMethod.GET, params, null,
				ApplicationStageDetails.class);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"completed getStageDetails for application : " + applicationKey);
		return applicationStageDetails;
	}
	
	@SuppressWarnings("unchecked")
	public List<PrincipalBean> getPrincipalDetails() {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start - getPrinicipalDetails");

		Gson gson = new Gson();
		List<PrincipalBean> principalBeanList = new ArrayList<>();
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End - getPrinicipalDetails");
		ResponseEntity<String> response = (ResponseEntity<String>) creditBusinessHelper.invokeRestEndpoint(
				HttpMethod.GET, env.getProperty("api.omreferencedatareferencedataservice.principal.get.url"),
				String.class, null, null, new HttpHeaders());
		PrincipalBean[] principalBeans = gson.fromJson(response.getBody(), PrincipalBean[].class);
		principalBeanList = Arrays.asList(principalBeans);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End - getPrinicipalDetails");
		return principalBeanList;
	}
	
	public List<ApplicationDetail> getChildApplications(String applicationId, String isInProcessing) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Start - getChildApplications for applicationkey " + applicationId);
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationkey", applicationId);
		params.put("isInProcessing", isInProcessing);
		ResponseEntity<?> childApplicationListRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				env.getProperty("api.omcreditapplicationservice.childapplications.get.url"), List.class, params, null,
				new HttpHeaders());
		return mapper.convertValue(childApplicationListRes.getBody(), new TypeReference<List<ApplicationDetail>>() {
		});
	}
	
	public CibilResponse[] getCibilReference(String applicationId, String cibiltype, String applicantKey, String cibilReferenceKey) {

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Start - getCibilReference for applicationkey " + applicationId);
		Map<String, String> params = new HashMap<>();
		params.put(CIBIL_TYPE, cibiltype);
		params.put("applicationkey", applicationId);
		params.put("applicantkey", applicantKey);
		params.put("cibilreferencekey", !StringUtils.isEmpty(cibilReferenceKey) ? cibilReferenceKey : null);

		ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				env.getProperty("api.omcibilverificationservice.cibil.get.url"), String.class, params, null,
				new HttpHeaders());

		CibilResponse[] cibilResponses = new Gson().fromJson((String) responseEntity.getBody(), CibilResponse[].class);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"End - getCibilReference for applicationkey " + applicationId);
		return cibilResponses;
	}

	public Specilizations getSpecialisationDetails(String spclMasterKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.PROCESSOR,
				"getSpecialisationDetails Start for spclMasterKey: " + spclMasterKey);
		Specilizations specilization = null;
		try {
			UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(specialisationUrl)
					.queryParam("spclMasterKey", spclMasterKey);

			ResponseEntity<?> excuteRestCall = creditBusinessHelper.invokeRestEndPointWithOptionalParams(HttpMethod.GET, uriBuilder,
					String.class, null, null, null);

			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				Specilizations[] specilizations = new Gson().fromJson(excuteRestCall.getBody().toString(), Specilizations[].class);
				specilization = specilizations[0];
				logger.debug(CLASSNAME, BFLLoggerComponent.PROCESSOR,
						"getQualificationDetails Start for specilizations: " + specilizations);
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Error in fetching getSpecialisationDetails for spclMasterKey: " + spclMasterKey, e);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.PROCESSOR, "getSpecialisationDetails end ");
		return specilization;
	}

	public Qualification getQualificationDetails(String qlfyMasterkey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.PROCESSOR,
				"getQualificationDetails Start for qlfyMasterkey: " + qlfyMasterkey);
		Qualification qualification = null;
		try {
			UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(qualificationUrl)
					.queryParam("qlfyMasterkey", qlfyMasterkey);

			ResponseEntity<?> excuteRestCall = creditBusinessHelper.invokeRestEndPointWithOptionalParams(HttpMethod.GET, uriBuilder,
					String.class, null, null, null);

			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				Qualification[] qualificationResponse = new Gson().fromJson(excuteRestCall.getBody().toString(), Qualification[].class);
				if(qualificationResponse.length > 0)
					qualification = qualificationResponse[0];
				logger.debug(CLASSNAME, BFLLoggerComponent.PROCESSOR,
						"getQualificationDetails Start for qualificationMaster: " + qualificationResponse);
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Error in fetching getQualificationDetails for qlfyMasterkey: " + qlfyMasterkey, e);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.PROCESSOR, "getQualificationDetails end ");
		return qualification;
	}

	
	/**
	 * This method returns the reference (key,code,value) as per requested ReferenceOf Enum defined 
	 * along with queryParams and filter bases input Reference.
	 * 
	 * If no filtering required filterReference shall be passed null.
	 * 
	 * Either of queryParams or filterReference should be present for actual reference fetch. 
	 * 
	 * @param referenceOf
	 * @param queryParams
	 * @param filterReference
	 * @return Reference
	 */
	public Reference getReference(ReferenceOf referenceOf, MultiValueMap<String, String> queryParams, Reference filterReference) {
		if(null != referenceOf && (null != queryParams || null != filterReference)) {
			String url = env.getProperty(referenceOf.getUrl());
			if (null != url && !url.isBlank() && null != queryParams && !queryParams.isEmpty()) {
				url = UriComponentsBuilder.fromUriString(url).queryParams(queryParams).build().toUriString();
			}
			ArrayList<?> referenceResponseList = (ArrayList<?>) callApi(url, HttpMethod.GET, null, null, Object.class);
			return this.buildReference(filterReference, referenceOf, referenceResponseList);
		}
		return filterReference;
	}
	
	private Reference buildReference(Reference filterReference, ReferenceOf referenceOf, ArrayList<?> referenceResponseList) {
		Reference reference = null;
		if(null != referenceResponseList) {
			for (Object responseObject : referenceResponseList) {
				JSONObject responseJson = CreditBusinessHelper.getJSONObject(responseObject);
				if (null != responseJson) {
					Object key= responseJson.get(referenceOf.getKeyLabel());
					Object code = responseJson.get(referenceOf.getCodeLabel());
					Object value = responseJson.get(referenceOf.getValueLabel());
					if(null == filterReference || matchFilterCriteria(filterReference, key, code, value)) {
						reference = new Reference();
						reference.setKey(null != key ? Double.valueOf(key.toString()).longValue() : null);
						reference.setCode(null != code ? code.toString() : null);
						reference.setValue(null != value ? value.toString() : null);
						break;
					}
				}
			}
		}
		return reference;
	}
	
	private boolean matchFilterCriteria(Reference filterReference, Object key, Object code, Object value) {
		if(null != filterReference.getKey() && null != key && filterReference.getKey().longValue() == Double.valueOf(key.toString()).longValue()) {
			return true;
		}
		if(null != filterReference.getCode() && null != code && filterReference.getCode().equals(code.toString())) {
			return true;
		}
		if(null != filterReference.getValue() && null != value && filterReference.getValue().equals(value.toString())) {
			return true;
		}
		return false;
	}
	
	
	/**
	 * This method returns the reference (key,code,value) as per requested ReferenceOf Enum defined 
	 * along with queryParams, pathParameters and filter bases input Reference.
	 * 
	 * If no filtering required filterReference shall be passed null.
	 * 
	 * Either of queryParams or filterReference should be present for actual reference fetch,
	 * else method returns first reference data of the responded list. 
	 * 
	 * @param referenceOf
	 * @param pathParameters
	 * @param queryParams
	 * @param filterReference
	 * @return Reference
	 * 
	 * @throws CreditBusinessException
	 * 
	 **/
	public Reference getReferenceV2(ReferenceOf referenceOf, Map<String, String> pathParameters, 
			MultiValueMap<String, String> queryParams, Reference filterReference) {
		if(null != referenceOf && (null != queryParams || null != filterReference)) {
			String url = env.getProperty(referenceOf.getUrl());
			if (null != url && !url.isBlank()) {
				if(null != pathParameters && !pathParameters.isEmpty()) {
					url = UriComponentsBuilder.fromUriString(url).queryParams(queryParams).build(pathParameters).toString();
				} else {
					url = UriComponentsBuilder.fromUriString(url).queryParams(queryParams).build().toString();
				}
			} else {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "url not defined for property key: " + referenceOf.getUrl());
				throw new CreditBusinessException(HttpStatus.NOT_IMPLEMENTED, new ErrorBean("OMCB-501", "Reference data url not defined"));
			}
			ArrayList<?> referenceResponseList = (ArrayList<?>) callApi(url, HttpMethod.GET, null, null, Object.class);
			return this.buildReference(filterReference, referenceOf, referenceResponseList);
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Invalid request data: referenceOf " + referenceOf + ", queryParams: " + queryParams + ", filterReference: " + filterReference);
			return filterReference;
		}
	}
	
	/**
	 * This method returns application loan pricing
	 * if Approved EP pricing is present then it will be returned
	 * Otherwise journey pricing will be returned
	 * @param applicationId
	 * @return
	 */
	public PricingDetail getAppLoanPricing(String applicationId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Start - getAppLoanPricing for applicationkey " + applicationId);
		try {
			Map<String, String> params = new HashMap<>();
			params.put("applicationKey", applicationId);
			ResponseEntity<List<?>> pricingResponse = (ResponseEntity<List<?>>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, getLoanPricingUrl, List.class, params, null, new HttpHeaders());

			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Optional<?> epPricing = pricingResponse.getBody().stream().filter(i -> {
				Map<String, Object> j = (Map<String, Object>) i;
				return (j.get("pricingStatus") != null && j.get("source") != null
						&& CreditBusinessConstants.EP.equalsIgnoreCase(j.get("source").toString())
						&& CreditBusinessConstants.APPROVED.equalsIgnoreCase(j.get("pricingStatus").toString()));
			}).findFirst();

			if (epPricing.isPresent()) {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End - getAppLoanPricing with EP pricing");
				PricingDetail pricing = mapper.convertValue(epPricing.get(), PricingDetail.class);
				return pricing;
			} else {
				Optional<?> journeyPricing = pricingResponse.getBody().stream().filter(i -> {
					Map<String, Object> j = (Map<String, Object>) i;
					return (j.get("pricingStatus") != null && j.get("source") != null
							&& CreditBusinessConstants.JOURNEY.equalsIgnoreCase(j.get("source").toString())
							&& CreditBusinessConstants.APPROVED.equalsIgnoreCase(j.get("pricingStatus").toString()));
				}).findFirst();
				if (journeyPricing.isPresent()) {
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End - getAppLoanPricing with Journey pricing");
					PricingDetail pricing = mapper.convertValue(journeyPricing.get(), PricingDetail.class);
					return pricing;
				}
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Error occurred in getAppLoanPricing for : " + applicationId, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-106", "Error occurred in getAppLoanPricing"));
		}
	}
	
	public JSONObject getApplicationParameterDetails(String applicationId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"fetching getApplicationParameterDetails for applicationId : " + applicationId);
		JSONObject applicationParameters = new JSONObject();
		Map<String, String> params = new HashMap<>();
		if (applicationId != null) {
			params.put("applicationid", applicationId);
			applicationParameters = callApi(getAppParamDetails, HttpMethod.GET, params, null, JSONObject.class);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "completed getApplicationParameterDetails for application : " + applicationId);
		return applicationParameters;		
	}
	
	@SuppressWarnings("unchecked")
	public DocumentDetails getDocumentDetail(Map<String, String> params, Long documentKey) {
		String documentDetailUrlWithDocumentKey = documentDetailUrl;
		if(null != documentKey) {
			documentDetailUrlWithDocumentKey = UriComponentsBuilder.fromHttpUrl(documentDetailUrlWithDocumentKey)
					.queryParam("documentnamekey", documentKey).build().toString();
		}
		ResponseEntity<DocumentDetails> documentResponseEntity = (ResponseEntity<DocumentDetails>) creditBusinessHelper.
				invokeRestEndpoint(HttpMethod.GET, documentDetailUrlWithDocumentKey, DocumentDetails.class, params, null, new HttpHeaders());
		
		return null != documentResponseEntity ? documentResponseEntity.getBody() : null;
	}
}
