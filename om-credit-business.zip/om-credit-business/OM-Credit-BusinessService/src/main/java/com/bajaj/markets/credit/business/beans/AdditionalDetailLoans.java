package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class AdditionalDetailLoans implements Serializable {

	private static final long serialVersionUID = 2703536940790674814L;

	private String applicationid;
	private String l3ProductCode;
	private String l4ProductCode;
	private String riskOfferType;
	private List<Address> addressDetails;
	private List<Nominee> nomineeDetails;
	private Boolean permanentAddressRequired;
	private Boolean isSelfEmployed;
	private String motherName;
	private String fatherName;
	private String action;
	private Long principalKey;
	private boolean bundleSelected;
	private Integer currentWorkExperience;
	private Integer presentBusinessVintage;
	private LoanPurpose loanPurpose;
	private Reference qualification;
	private BigDecimal averageBankBalance;
	private String workEmailId;
	private Boolean workEmailRequired;
	private Boolean genericEmailAllowed;
	private List<RelatedPersonnelBean> relatedPersonnelDetails;
	private Long employerType;
	private Long subEmployerType;

	private Boolean isGinFlow;
	private Boolean designationRequired;
	private Reference designation;
	private String personalEmailId;
	private Boolean personalEmailRequired;
	private Boolean isNonGinFlow;
	private Boolean isNtbFlow;
	private Boolean employerRequired;
	private Reference employerName;
	private Address partnerAddressDetails;
	private Reference shopStatus;
	private Reference corporateLinkageType;
	private Reference natureOfBusiness;
	private String experience;
	private Reference residenceType;
	private Reference gender;
	private boolean isGenderRequired;
	private Boolean permanentAddressShowOnResiType;
	
	public Boolean getPermanentAddressShowOnResiType() {
		return permanentAddressShowOnResiType;
	}

	public void setPermanentAddressShowOnResiType(Boolean permanentAddressShowOnResiType) {
		this.permanentAddressShowOnResiType = permanentAddressShowOnResiType;
	}

	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public String getL4ProductCode() {
		return l4ProductCode;
	}

	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public List<Address> getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(List<Address> addressDetails) {
		this.addressDetails = addressDetails;
	}

	public List<Nominee> getNomineeDetails() {
		return nomineeDetails;
	}

	public void setNomineeDetails(List<Nominee> nomineeDetails) {
		this.nomineeDetails = nomineeDetails;
	}

	public Boolean getPermanentAddressRequired() {
		return permanentAddressRequired;
	}

	public void setPermanentAddressRequired(Boolean permanentAddressRequired) {
		this.permanentAddressRequired = permanentAddressRequired;
	}

	public Boolean getIsSelfEmployed() {
		return isSelfEmployed;
	}

	public void setIsSelfEmployed(Boolean isSelfEmployed) {
		this.isSelfEmployed = isSelfEmployed;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public boolean isBundleSelected() {
		return bundleSelected;
	}

	public void setBundleSelected(boolean bundleSelected) {
		this.bundleSelected = bundleSelected;
	}

	public Integer getCurrentWorkExperience() {
		return currentWorkExperience;
	}

	public void setCurrentWorkExperience(Integer currentWorkExperience) {
		this.currentWorkExperience = currentWorkExperience;
	}

	public Integer getPresentBusinessVintage() {
		return presentBusinessVintage;
	}

	public void setPresentBusinessVintage(Integer presentBusinessVintage) {
		this.presentBusinessVintage = presentBusinessVintage;
	}

	public LoanPurpose getLoanPurpose() {
		return loanPurpose;
	}

	public void setLoanPurpose(LoanPurpose loanPurpose) {
		this.loanPurpose = loanPurpose;
	}

	public Reference getQualification() {
		return qualification;
	}

	public void setQualification(Reference qualification) {
		this.qualification = qualification;
	}

	public BigDecimal getAverageBankBalance() {
		return averageBankBalance;
	}

	public void setAverageBankBalance(BigDecimal averageBankBalance) {
		this.averageBankBalance = averageBankBalance;
	}

	public String getWorkEmailId() {
		return workEmailId;
	}

	public void setWorkEmailId(String workEmailId) {
		this.workEmailId = workEmailId;
	}

	public Boolean getWorkEmailRequired() {
		return workEmailRequired;
	}

	public void setWorkEmailRequired(Boolean workEmailRequired) {
		this.workEmailRequired = workEmailRequired;
	}

	public Boolean getGenericEmailAllowed() {
		return genericEmailAllowed;
	}

	public void setGenericEmailAllowed(Boolean genericEmailAllowed) {
		this.genericEmailAllowed = genericEmailAllowed;
	}

	public List<RelatedPersonnelBean> getRelatedPersonnelDetails() {
		return relatedPersonnelDetails;
	}

	public void setRelatedPersonnelDetails(List<RelatedPersonnelBean> relatedPersonnelDetails) {
		this.relatedPersonnelDetails = relatedPersonnelDetails;
	}

	public Boolean getIsGinFlow() {
		return isGinFlow;
	}

	public void setIsGinFlow(Boolean isGinFlow) {
		this.isGinFlow = isGinFlow;
	}

	public Boolean getDesignationRequired() {
		return designationRequired;
	}

	public void setDesignationRequired(Boolean designationRequired) {
		this.designationRequired = designationRequired;
	}

	public Reference getDesignation() {
		return designation;
	}

	public void setDesignation(Reference designation) {
		this.designation = designation;
	}

	public String getPersonalEmailId() {
		return personalEmailId;
	}

	public void setPersonalEmailId(String personalEmailId) {
		this.personalEmailId = personalEmailId;
	}

	public Boolean getPersonalEmailRequired() {
		return personalEmailRequired;
	}

	public void setPersonalEmailRequired(Boolean personalEmailRequired) {
		this.personalEmailRequired = personalEmailRequired;
	}

	public Boolean getIsNonGinFlow() {
		return isNonGinFlow;
	}

	public void setIsNonGinFlow(Boolean isNonGinFlow) {
		this.isNonGinFlow = isNonGinFlow;
	}

	public Boolean getIsNtbFlow() {
		return isNtbFlow;
	}

	public void setIsNtbFlow(Boolean isNtbFlow) {
		this.isNtbFlow = isNtbFlow;
	}

	public Boolean getEmployerRequired() {
		return employerRequired;
	}

	public void setEmployerRequired(Boolean employerRequired) {
		this.employerRequired = employerRequired;
	}

	public Reference getEmployerName() {
		return employerName;
	}

	public void setEmployerName(Reference employerName) {
		this.employerName = employerName;
	}

	public Address getPartnerAddressDetails() {
		return partnerAddressDetails;
	}

	public void setPartnerAddressDetails(Address partnerAddressDetails) {
		this.partnerAddressDetails = partnerAddressDetails;
	}
	
	public Long getEmployerType() {
		return employerType;
	}

	public void setEmployerType(Long employerType) {
		this.employerType = employerType;
	}

	public Long getSubEmployerType() {
		return subEmployerType;
	}

	public void setSubEmployerType(Long subEmployerType) {
		this.subEmployerType = subEmployerType;
	}

	public Reference getShopStatus() {
		return shopStatus;
	}

	public void setShopStatus(Reference shopStatus) {
		this.shopStatus = shopStatus;
	}

	public Reference getCorporateLinkageType() {
		return corporateLinkageType;
	}

	public void setCorporateLinkageType(Reference corporateLinkageType) {
		this.corporateLinkageType = corporateLinkageType;
	}

	public Reference getNatureOfBusiness() {
		return natureOfBusiness;
	}

	public void setNatureOfBusiness(Reference natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}	

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}
	
	public Reference getGender() {
		return gender;
	}
	
	public Reference getResidenceType() {
		return residenceType;
	}
	
	public void setGender(Reference gender) {
		this.gender=gender;
	}
	
	public void setResidenceType(Reference residenceType) {
		this.residenceType=residenceType;
	}
	
	public boolean getIsGenderRequired() {
		return isGenderRequired;
	}
	
	public void setIsGenderRequired(boolean isGenderRequired) {
		this.isGenderRequired = isGenderRequired;
	}

	@Override
	public String toString() {
		return "AdditionalDetailLoans [applicationid=" + applicationid + ", l3ProductCode=" + l3ProductCode
				+ ", l4ProductCode=" + l4ProductCode + ", riskOfferType=" + riskOfferType + ", addressDetails="
				+ addressDetails + ", nomineeDetails=" + nomineeDetails + ", permanentAddressRequired="
				+ permanentAddressRequired + ", isSelfEmployed=" + isSelfEmployed + ", motherName=" + motherName
				+ ", fatherName=" + fatherName + ", action=" + action + ", principalKey=" + principalKey
				+ ", bundleSelected=" + bundleSelected + ", currentWorkExperience=" + currentWorkExperience
				+ ", presentBusinessVintage=" + presentBusinessVintage + ", loanPurpose=" + loanPurpose
				+ ", qualification=" + qualification + ", averageBankBalance=" + averageBankBalance + ", workEmailId="
				+ workEmailId + ", workEmailRequired=" + workEmailRequired + ", genericEmailAllowed="
				+ genericEmailAllowed + ", relatedPersonnelDetails=" + relatedPersonnelDetails + ", employerType="
				+ employerType + ", subEmployerType=" + subEmployerType + ", isGinFlow=" + isGinFlow
				+ ", designationRequired=" + designationRequired + ", designation=" + designation + ", personalEmailId="
				+ personalEmailId + ", personalEmailRequired=" + personalEmailRequired + ", isNonGinFlow="
				+ isNonGinFlow + ", isNtbFlow=" + isNtbFlow + ", employerRequired=" + employerRequired
				+ ", employerName=" + employerName + ", partnerAddressDetails=" + partnerAddressDetails
				+ ", shopStatus=" + shopStatus + ", corporateLinkageType=" + corporateLinkageType
				+ ", natureOfBusiness=" + natureOfBusiness + ", experience=" + experience + ", residenceType="
				+ residenceType + ", gender=" + gender + ", isGenderRequired=" + isGenderRequired
				+ ", permanentAddressShowOnResiType=" + permanentAddressShowOnResiType + "]";
	}
	
	

}