package com.bajaj.markets.credit.business.beans;

public class LookupCodeValuesResponseBean implements Comparable<LookupCodeValuesResponseBean> {
	
	private Integer key;
	private String code;
	private String value;
		
	public Integer getKey() {
		return key;
	}

	public void setKey(Integer key) {
		this.key = key;
	}

	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "EducationValuesResponseBean [key=" + key + ", code=" + code + ", value=" + value + "]";
	}

	@Override
	public int compareTo(LookupCodeValuesResponseBean o) {
		return this.getKey().compareTo(o.getKey());
	}

}
