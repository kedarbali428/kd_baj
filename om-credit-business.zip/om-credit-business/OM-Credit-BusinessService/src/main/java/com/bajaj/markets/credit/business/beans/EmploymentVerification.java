package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class EmploymentVerification implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String branch;
	private String occupationType;
	private Long emplrScore;
	private Double nameConfidence;
	private Boolean settledFlag;
	private Boolean recentFlag;
	private Boolean uniqueFlag;
	private Boolean nameExactFlag;
	private String officialEmailDomain;
	private String creditVidyaStatus;
	private String karzaApproach;
	private String karzaId;
	private Long status;
	private String companyCatogery;
	private String companyType;
	private String karzaType;

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}

	public void setEmplrScore(Long emplrScore) {
		this.emplrScore = emplrScore;
	}

	public void setNameConfidence(Double nameConfidence) {
		this.nameConfidence = nameConfidence;
	}

	public void setSettledFlag(Boolean settledFlag) {
		this.settledFlag = settledFlag;
	}

	public void setRecentFlag(Boolean recentFlag) {
		this.recentFlag = recentFlag;
	}

	public void setUniqueFlag(Boolean uniqueFlag) {
		this.uniqueFlag = uniqueFlag;
	}

	public void setNameExactFlag(Boolean nameExactFlag) {
		this.nameExactFlag = nameExactFlag;
	}

	public void setOfficialEmailDomain(String officialEmailDomain) {
		this.officialEmailDomain = officialEmailDomain;
	}

	public void setCreditVidyaStatus(String creditVidyaStatus) {
		this.creditVidyaStatus = creditVidyaStatus;
	}

	public void setKarzaApproach(String karzaApproach) {
		this.karzaApproach = karzaApproach;
	}

	public void setKarzaId(String karzaId) {
		this.karzaId = karzaId;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public void setCompanyCatogery(String companyCatogery) {
		this.companyCatogery = companyCatogery;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public String getKarzaType() {
		return karzaType;
	}

	public void setKarzaType(String karzaType) {
		this.karzaType = karzaType;
	}

	@Override
	public String toString() {
		return "EmploymentVerification [branch=" + branch + ", occupationType=" + occupationType + ", emplrScore=" + emplrScore + ", nameConfidence="
				+ nameConfidence + ", settledFlag=" + settledFlag + ", recentFlag=" + recentFlag + ", uniqueFlag=" + uniqueFlag + ", nameExactFlag="
				+ nameExactFlag + ", officialEmailDomain=" + officialEmailDomain + ", creditVidyaStatus=" + creditVidyaStatus + ", karzaApproach="
				+ karzaApproach + ", karzaId=" + karzaId + ", status=" + status + ", companyCatogery=" + companyCatogery + ", companyType=" + companyType
				+ ", karzaType=" + karzaType + "]";
	}

}
