package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class SaveUserTaskRequest {

	private List<UserTaskContent> userTaskContent;

	public List<UserTaskContent> getUserTaskContent() {
		return userTaskContent;
	}

	public void setUserTaskContent(List<UserTaskContent> userTaskContent) {
		this.userTaskContent = userTaskContent;
	}

	@Override
	public String toString() {
		return "SaveUserTaskRequest [userTaskContent=" + userTaskContent + "]";
	}
	
}
