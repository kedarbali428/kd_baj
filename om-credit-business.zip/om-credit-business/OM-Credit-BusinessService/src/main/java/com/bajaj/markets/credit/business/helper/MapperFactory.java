package com.bajaj.markets.credit.business.helper;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public enum MapperFactory {
	INSTANCE;

	private final ObjectMapper mapper = new ObjectMapper();

	private MapperFactory() {
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	public ObjectMapper getInstance() {
		return mapper;
	}

}
