package com.bajaj.markets.credit.business.sduiprocessor;

import org.springframework.http.HttpHeaders;

public interface TaskProcessor {

	String getUserTaskRequest(String applicationId, HttpHeaders headers);
	
}
