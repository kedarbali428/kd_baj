package com.bajaj.markets.credit.business.beans;

public class UserProfileBean {

	private String applicationKey;

	private String applicationUserAttributeKey;

	private String applicationUserAttributeType;

	private String mobile;

	private String dateOfBirth;

	private Name name;

	private Long maritalStatusKey;

	private Long genderKey;

	private Long residenceTypeKey;

	private String qualification;

	private String panNumber;

	private String motherName;

	private String fatherName;
	
	private String applicantKey;
	
	private Long coapplicantObligation;
	
	private Boolean workEmailRequired;
	
	private String nameToBePrintedOnCard;

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getApplicationUserAttributeKey() {
		return applicationUserAttributeKey;
	}

	public void setApplicationUserAttributeKey(String applicationUserAttributeKey) {
		this.applicationUserAttributeKey = applicationUserAttributeKey;
	}

	public String getApplicationUserAttributeType() {
		return applicationUserAttributeType;
	}

	public void setApplicationUserAttributeType(String applicationUserAttributeType) {
		this.applicationUserAttributeType = applicationUserAttributeType;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public Long getMaritalStatusKey() {
		return maritalStatusKey;
	}

	public void setMaritalStatusKey(Long maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}

	public Long getGenderKey() {
		return genderKey;
	}

	public void setGenderKey(Long genderKey) {
		this.genderKey = genderKey;
	}

	public Long getResidenceTypeKey() {
		return residenceTypeKey;
	}

	public void setResidenceTypeKey(Long residenceTypeKey) {
		this.residenceTypeKey = residenceTypeKey;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	


	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}
	
	public Long getCoapplicantObligation() {
		return coapplicantObligation;
	}

	public void setCoapplicantObligation(Long coapplicantObligation) {
		this.coapplicantObligation = coapplicantObligation;
	}

	public Boolean getWorkEmailRequired() {
		return workEmailRequired;
	}

	public void setWorkEmailRequired(Boolean workEmailRequired) {
		this.workEmailRequired = workEmailRequired;
	}
	
	public String getNameToBePrintedOnCard() {
		return nameToBePrintedOnCard;
	}

	public void setNameToBePrintedOnCard(String nameToBePrintedOnCard) {
		this.nameToBePrintedOnCard = nameToBePrintedOnCard;
	}
	
	@Override
	public String toString() {
		return "UserProfileBean [applicationKey=" + applicationKey + ", applicationUserAttributeKey=" + applicationUserAttributeKey
				+ ", applicationUserAttributeType=" + applicationUserAttributeType + ", mobile=" + mobile + ", dateOfBirth=" + dateOfBirth + ", name=" + name
				+ ", maritalStatusKey=" + maritalStatusKey + ", genderKey=" + genderKey + ", residenceTypeKey=" + residenceTypeKey + ", qualification="
				+ qualification + ", panNumber=" + panNumber + ", motherName=" + motherName + ", fatherName=" + fatherName + ", applicantKey=" + applicantKey
				+ ", coapplicantObligation=" + coapplicantObligation + ", workEmailRequired=" + workEmailRequired + "]";
	}
	
}
