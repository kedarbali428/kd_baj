package  com.bajaj.markets.credit.business.beans;
import java.util.List;

public class EligibilityResponse {

	private String isCustomerEligible;
	private String custType; 
	private String custName; 
	private String customerId; 
	private String customerSerialKey; 
	private String appRefId; 
	private String token; 
	private String serviceability; 
	private Object additionalInfo; 
	private List<PrincipalOfferDetails> offerDetails;
	
	public String getIsCustomerEligible() {
		return isCustomerEligible;
	}
	public void setIsCustomerEligible(String isCustomerEligible) {
		this.isCustomerEligible = isCustomerEligible;
	}
	public String getCustType() {
		return custType;
	}
	public void setCustType(String custType) {
		this.custType = custType;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerSerialKey() {
		return customerSerialKey;
	}
	public void setCustomerSerialKey(String customerSerialKey) {
		this.customerSerialKey = customerSerialKey;
	}
	public String getAppRefId() {
		return appRefId;
	}
	public void setAppRefId(String appRefId) {
		this.appRefId = appRefId;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getServiceability() {
		return serviceability;
	}
	public void setServiceability(String serviceability) {
		this.serviceability = serviceability;
	}
	public Object getAdditionalInfo() {
		return additionalInfo;
	}
	public void setAdditionalInfo(Object additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	public List<PrincipalOfferDetails> getOfferDetails() {
		return offerDetails;
	}
	public void setOfferDetails(List<PrincipalOfferDetails> offerDetails) {
		this.offerDetails = offerDetails;
	}
	@Override
	public String toString() {
		return "EligibilityResponse [isCustomerEligible=" + isCustomerEligible + ", custType=" + custType
				+ ", custName=" + custName + ", customerId=" + customerId + ", customerSerialKey=" + customerSerialKey
				+ ", appRefId=" + appRefId + ", token=" + token + ", serviceability=" + serviceability
				+ ", additionalInfo=" + additionalInfo + ", offerDetails=" + offerDetails + "]";
	}
}