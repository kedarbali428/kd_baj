package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class LoanPurpose implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6262278095362168132L;

	private Long key;
	
	private String code;
	
	private String purposeValue;

	public Long getKey() {
		return key;
	}

	public void setKey(Long key) {
		this.key = key;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getPurposeValue() {
		return purposeValue;
	}

	public void setPurposeValue(String purposeValue) {
		this.purposeValue = purposeValue;
	}

	@Override
	public String toString() {
		return "LoanPurpose [key=" + key + ", code=" + code + ", purposeValue=" + purposeValue + "]";
	}
	
}
