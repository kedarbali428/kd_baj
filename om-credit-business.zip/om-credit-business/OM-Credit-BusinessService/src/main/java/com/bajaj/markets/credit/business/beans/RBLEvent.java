package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class RBLEvent implements Serializable{
	private static final long serialVersionUID = -8624030785544622606L;
	private String applicationId;
	private String mob;
	private String dob;
	private Reference profession;
	private String utmSource;
	private String productCode;
	private String principalName;
	
	public String getUtmSource() {
		return utmSource;
	}

	public void setUtmSource(String utmSource) {
		this.utmSource = utmSource;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public Reference getProfession() {
		return profession;
	}

	public void setProfession(Reference profession) {
		this.profession = profession;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	@Override
	public String toString() {
		return "RBLEvent [applicationId=" + applicationId + ", mob=" + mob + ", dob=" + dob + ", profession="
				+ profession + ", utmSource=" + utmSource + ", productCode=" + productCode + ", principalName="
				+ principalName + "]";
	}

}