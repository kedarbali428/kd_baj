package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class PinCodeDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long pinKey;
	private Long pinCode;
	private String city;
	private String cityKey;
	private String state;
	private String stateKey;
	private String shortName;
	private String countryCode;
	private String country;
	private Boolean negetiveAreaFlag;
	private Boolean oglFlag;

	public Long getPinKey() {
		return pinKey;
	}

	public void setPinKey(Long pinKey) {
		this.pinKey = pinKey;
	}

	public Long getPinCode() {
		return pinCode;
	}

	public void setPinCode(Long pinCode) {
		this.pinCode = pinCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCityKey() {
		return cityKey;
	}

	public void setCityKey(String cityKey) {
		this.cityKey = cityKey;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStateKey() {
		return stateKey;
	}

	public void setStateKey(String stateKey) {
		this.stateKey = stateKey;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Boolean getNegetiveAreaFlag() {
		return negetiveAreaFlag;
	}

	public void setNegetiveAreaFlag(Boolean negetiveAreaFlag) {
		this.negetiveAreaFlag = negetiveAreaFlag;
	}

	public Boolean getOglFlag() {
		return oglFlag;
	}

	public void setOglFlag(Boolean oglFlag) {
		this.oglFlag = oglFlag;
	}

	@Override
	public String toString() {
		return "PinCodeDetails [" + (pinKey != null ? "pinKey=" + pinKey + ", " : "") + (pinCode != null ? "pinCode=" + pinCode + ", " : "")
				+ (city != null ? "city=" + city + ", " : "") + (cityKey != null ? "cityKey=" + cityKey + ", " : "")
				+ (state != null ? "state=" + state + ", " : "") + (stateKey != null ? "stateKey=" + stateKey + ", " : "")
				+ (shortName != null ? "shortName=" + shortName + ", " : "") + (countryCode != null ? "countryCode=" + countryCode + ", " : "")
				+ (country != null ? "country=" + country + ", " : "") + (negetiveAreaFlag != null ? "negetiveAreaFlag=" + negetiveAreaFlag + ", " : "")
				+ (oglFlag != null ? "oglFlag=" + oglFlag : "") + "]";
	}

}
