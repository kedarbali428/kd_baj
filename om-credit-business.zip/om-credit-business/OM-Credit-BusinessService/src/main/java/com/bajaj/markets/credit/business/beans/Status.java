package com.bajaj.markets.credit.business.beans;

public enum Status {
	CREATED,INITIAITED,COMPLETED,FAILED,EXPIRED,NOT_INITIAITED,DEFAULT,SUSPENDED

}
