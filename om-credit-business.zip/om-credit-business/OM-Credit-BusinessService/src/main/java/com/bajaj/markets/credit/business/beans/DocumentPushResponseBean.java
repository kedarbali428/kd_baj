package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class DocumentPushResponseBean {

	private String partnername ;
	private String productL4;
	private String productL2;
	private String productL3;
	
	private String productL4Desc;
	private String productL2Desc;
	private String productL3Desc;
	
	private Long applicationKey;
	private Long principleKey;
	
	private List<DocumentBean> documentbean;

	public String getPartnername() {
		return partnername;
	}

	public void setPartnername(String partnername) {
		this.partnername = partnername;
	}

	public String getProductL4() {
		return productL4;
	}

	public void setProductL4(String productL1) {
		this.productL4 = productL1;
	}

	public String getProductL2() {
		return productL2;
	}

	public void setProductL2(String productL2) {
		this.productL2 = productL2;
	}

	public String getProductL3() {
		return productL3;
	}

	public void setProductL3(String productL3) {
		this.productL3 = productL3;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public List<DocumentBean> getDocumentbean() {
		return documentbean;
	}

	public void setDocumentbean(List<DocumentBean> documentbean) {
		this.documentbean = documentbean;
	}

	public Long getPrincipleKey() {
		return principleKey;
	}

	public void setPrincipleKey(Long principleKey) {
		this.principleKey = principleKey;
	}

	public String getProductL4Desc() {
		return productL4Desc;
	}

	public void setProductL4Desc(String productL4Desc) {
		this.productL4Desc = productL4Desc;
	}

	public String getProductL2Desc() {
		return productL2Desc;
	}

	public void setProductL2Desc(String productL2Desc) {
		this.productL2Desc = productL2Desc;
	}

	public String getProductL3Desc() {
		return productL3Desc;
	}

	public void setProductL3Desc(String productL3Desc) {
		this.productL3Desc = productL3Desc;
	}
	
	
	
	
}
