package com.bajaj.markets.credit.business.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.Application;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.service.CreditBusinessSduiService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessSduiController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessSduiService creditBusinessSduiService;

	@Autowired
	CustomDefaultHeaders customHeader;

	private static final String CLASS_NAME = CreditBussinessApplicationController.class.getCanonicalName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "API to fetch userTask", notes = "API to fetch userTask", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched landing page application details", response = Object.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found for given applicationId", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@CrossOrigin
	@GetMapping(path = "/v2/applications/{applicationkey}/userTask/{taskName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getUserTask(
			@PathVariable(value = "applicationkey", required = true) String applicationkey,
			@PathVariable(value = "taskName", required = true) String taskName,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Start getUserTask with applicationid : " + applicationkey);

		Object userTask = creditBusinessSduiService.getUserTask(applicationkey, taskName,headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"End getUserTask with applicationid : " + applicationkey);

		return new ResponseEntity<>(userTask, HttpStatus.OK);
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "API to save application data", notes = "API to save application data", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched landing page application details", response = Application.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found for given applicationId", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@CrossOrigin
	@PostMapping(path = "/v2/applications/{applicationkey}/userTask/{taskName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveUserTaskContent(
			@PathVariable(value = "applicationkey", required = true) String applicationkey,
			@PathVariable(value = "taskName", required = true) String taskName,
			@RequestBody Object userTaskContent,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Start saveUserTaskContent for applicationid : " + applicationkey + "request :" + userTaskContent);

		ApplicationResponse userTask = creditBusinessSduiService.saveUserTaskContent(applicationkey, taskName, userTaskContent, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"End saveUserTaskContent with applicationid : " + applicationkey);

		return new ResponseEntity<>(userTask, HttpStatus.OK);
	}
}
