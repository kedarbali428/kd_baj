package com.bajaj.markets.credit.business.helper;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.EmployerMasterBean;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.MaritalStatus;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.referencedataclientlib.bean.CacheServiceException;
import com.bajaj.markets.referencedataclientlib.bean.GenderMaster;
import com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean;
import com.bajaj.markets.referencedataclientlib.bean.LookupCodeValuesResponseBean;
import com.bajaj.markets.referencedataclientlib.bean.RefreshCacheDataBean;
import com.bajaj.markets.referencedataclientlib.helper.MasterData;
import com.bajaj.markets.referencedataclientlib.helper.MasterDataEnumConstants;
import com.bajaj.markets.referencedataclientlib.service.CacheService;
import com.bajaj.markets.referencedataclientlib.service.CommonCacheService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class MasterDataRedisClientHelper {

	@Autowired
	private CacheService cacheService;

	@Autowired
	private CommonCacheService commonCacheService;

	@Autowired
	private BFLLoggerUtilExt logger;

	ObjectMapper mapper = new ObjectMapper();

	private static final String CLASS_NAME = MasterDataRedisClientHelper.class.getCanonicalName();

	public String getGenderByTypeKey(Long genderTypeKey) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, " Inside getGenderByTypeKey() method .  TypeKey = " + genderTypeKey);
		return cacheService.findByKey(MasterData.GENDER, genderTypeKey, com.bajaj.markets.referencedataclientlib.bean.GenderMaster.class).getGenderValue();
	}

	public LookupCodeValuesResponseBean getLookupValueByLookupCodeAndKey(String lookupCode, Long lookupKey) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY,
				" Inside getLookupValueByLookupCodeAndKey for Lookup Type Code :: " + lookupCode + " :: and Key :: " + lookupKey);
		return cacheService.findByKey(MasterData.LOOKUPCODE, lookupKey, LookupCodeValuesResponseBean.class, lookupCode);
	}

	public LookupCodeValuesResponseBean getLookupValueByLookupCodeAndSortTxt(String lookupCode, String sortTxt) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				" Inside getLookupValuesBasedOnLookupCodeAndId for Lookup Type Code :: " + lookupCode + " :: and Lookup Key :: " + sortTxt);
		return cacheService.findByCode(MasterData.LOOKUPCODE, sortTxt, LookupCodeValuesResponseBean.class, lookupCode);
	}

	public Long getAddressTypeKeyForCode(String addressTypeCode) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Inside getAddressTypeKeyForCode for Address Type Code :: " + addressTypeCode);
		return cacheService.findByCode(MasterData.ADDRESS, addressTypeCode, com.bajaj.markets.referencedataclientlib.bean.AddressTypeMaster.class)
				.getAddressKey();
	}

	public Object getGetLookupByValueAndSource(String value, String lookUpSource) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, " Inside getGetLookupByCode() method ");
		return cacheService.findByCode(MasterData.LOOKUPCODE, value, Object.class, lookUpSource);
	}

	public Long getOccupationKeyForCode(String occupationCode) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Inside getOccupationKeyForCode for Occupation Code :: " + occupationCode);
		return cacheService.findByCode(MasterData.OCCUPATION, occupationCode, com.bajaj.markets.referencedataclientlib.bean.OccupationMaster.class)
				.getOccupationKey();
	}

	public com.bajaj.markets.referencedataclientlib.bean.OccupationMaster getOccupationByKey(Long occupationKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Inside getOccupationByKey for Occupation Key :: " + occupationKey);
		return cacheService.findByKey(MasterData.OCCUPATION, occupationKey, com.bajaj.markets.referencedataclientlib.bean.OccupationMaster.class);
	}
	
	public String getOccupationDesciptionForKey(Long occupationKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				" Inside getOccupationCodeForKey for Occupation Key :: " + occupationKey);
		return cacheService.findByKey(MasterData.OCCUPATION, occupationKey,
				com.bajaj.markets.referencedataclientlib.bean.OccupationMaster.class).getOccupationValue();
	}

	public com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean getPinCodeByKey(Long pincodeKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Inside getPinCodeByKey for PincodeKey :: " + pincodeKey);
		Map<String, Object> params = new HashMap<>();
		params.put("pincodeKey", pincodeKey);
		LocationResponseBean locationResponseBean = null;
		try {
			RefreshCacheDataBean refreshCacheDataBean = commonCacheService.findByKeyOrCode(MasterDataEnumConstants.MasterName.PINCODE, pincodeKey.toString(),
					params);
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			locationResponseBean = mapper.readValue(CreditBusinessHelper.objectToJson(refreshCacheDataBean.getReferenceDataObject()),
					LocationResponseBean.class);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Exception occured while fetching pinCode master data for pincode Key " + pincodeKey, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("OMCB_021", "Some techical exception occurred while"));
		}
		return locationResponseBean;
	}

	public EmployerMasterBean getEmployerByKey(Long employerId) throws CacheServiceException, JsonMappingException, JsonProcessingException {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, " Inside getEmployerByKey = employerId " + employerId);
		EmployerMasterBean employerMaster = null;
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("employerid", employerId);
			RefreshCacheDataBean refreshCacheDataBean = commonCacheService
					.findByKeyOrCode(MasterDataEnumConstants.MasterName.EMPLOYER, employerId.toString(), params);
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			employerMaster = mapper.readValue(
					CreditBusinessHelper.objectToJson(refreshCacheDataBean.getReferenceDataObject()),
					EmployerMasterBean.class);
		}catch(Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "getEmployerByKey : Record not found for employerID"+employerId);
		}
		
		return employerMaster;
	}

	public <T> T findAllCommonMasters(MasterDataEnumConstants.MasterName masterData, Map<String, Object> params, Class<T> responseType)
			throws CacheServiceException, JsonMappingException, JsonProcessingException {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, " Inside findAllCommonMasters = " + masterData);
		Object response = commonCacheService.findAll(masterData);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return mapper.readValue(CreditBusinessHelper.objectToJson(response), responseType);
	}

	public ResidenceMaster findResitypeByKey(Long residenceTypeKey) throws JsonMappingException, JsonProcessingException {
		ResidenceMaster[] resiTypeMaster = findAllCommonMasters(MasterDataEnumConstants.MasterName.RESIDENCE, null, ResidenceMaster[].class);
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "Inside findResitypeByKey = " + residenceTypeKey);
		if (resiTypeMaster != null && resiTypeMaster.length > 0) {
			for (ResidenceMaster residance : resiTypeMaster) {
				if (residenceTypeKey.equals(residance.getResidenceKey())) {
					return residance;
				}
			}
		}
		return null;
	}

	public MaritalStatus findMaritailStatusByKey(Long maritialStatusKey) throws JsonMappingException, JsonProcessingException {
		MaritalStatus[] maritialStatusArr = findAllCommonMasters(MasterDataEnumConstants.MasterName.MARITIALSTATUS, null, MaritalStatus[].class);
		if (maritialStatusArr != null && maritialStatusArr.length > 0) {
			for (MaritalStatus maritialStatus : maritialStatusArr) {
				if (maritialStatusKey.equals(maritialStatus.getMaritalStatusKey())) {
					return maritialStatus;
				}
			}
		}
		return null;
	}

	public Reference getGenderReferenceByTypeKey(Long genderTypeKey) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, " Inside getGenderReferenceByTypeKey() method.  TypeKey = " + genderTypeKey);
		Reference genderRef = null;
		GenderMaster genderMaster = cacheService.findByKey(MasterData.GENDER, genderTypeKey, com.bajaj.markets.referencedataclientlib.bean.GenderMaster.class);
		if (genderMaster != null) {
			genderRef = new Reference();
			genderRef.setKey(genderMaster.getGenderKey());
			genderRef.setCode(genderMaster.getGenderCode());
			genderRef.setValue(genderMaster.getGenderValue());
		}
		return genderRef;
	}
}
