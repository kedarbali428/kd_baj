package com.bajaj.markets.credit.business.beans;

public class Gender {

	private Long genderKey;
	
	private String genderCode;
	
	private String genderValue;

	public Long getGenderKey() {
		return genderKey;
	}

	public void setGenderKey(Long genderKey) {
		this.genderKey = genderKey;
	}

	public String getGenderCode() {
		return genderCode;
	}

	public void setGenderCode(String genderCode) {
		this.genderCode = genderCode;
	}

	public String getGenderValue() {
		return genderValue;
	}

	public void setGenderValue(String genderValue) {
		this.genderValue = genderValue;
	}

	@Override
	public String toString() {
		return "Gender [genderKey=" + genderKey + ", genderCode=" + genderCode + ", genderValue=" + genderValue + "]";
	}	
	
}
