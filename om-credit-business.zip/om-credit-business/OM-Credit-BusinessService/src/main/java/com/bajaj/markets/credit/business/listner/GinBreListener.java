package com.bajaj.markets.credit.business.listner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ObligationDetail;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.RejectionSystemSourceEnum;
import com.google.gson.Gson;

@Component
public class GinBreListener {

	private static final String SEND_NOTIFICATION = "sendNotification";
	private static final String OPEN_ARC_CARD_LIST_INPUT = "openArcCardListingInput";
	private static final String REJECTION_SYSTEM = "rejectionSystem";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	CreditBusinessGinHelper creditBusinessGinHelper;

	@Autowired
	MasterDataRedisClientHelper redisHelper;

	@Autowired
	BreListener breListener;

	private static final String CLASS_NAME = GinBreListener.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void preListing(DelegateExecution execution) throws Exception {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preListing");
		String cibilJson = CreditBusinessHelper.objectToJson(execution.getVariable(CreditBusinessConstants.CIBIL_JSON));
		JSONObject mcp2Request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		JSONObject breRequest = new JSONObject();
		JSONObject openArcCardListingInput = new JSONObject();
		openArcCardListingInput.put("applicationId", execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		openArcCardListingInput.put("eligibilityType", "AIP");
		openArcCardListingInput.put("cibilJson", cibilJson);
		openArcCardListingInput.put("cibilType", execution.getVariable("cibilType"));
		openArcCardListingInput.put("cibilScore", execution.getVariable("cibilScore"));
		openArcCardListingInput.put("product", execution.getVariable(CreditBusinessConstants.L2_PRODUCT_DESC));
		openArcCardListingInput.put("occupationType", execution.getVariable(CreditBusinessConstants.OCCUPATIONTYPECODE));

		creditBusinessGinHelper.prepareBreRequestForGinFlow(openArcCardListingInput, mcp2Request, null, null, null);

		if (null != execution.getVariable(CreditBusinessConstants.DEROG_JSON)) {
			Gson gson = new Gson();
			String derogJson = gson.toJson(execution.getVariable(CreditBusinessConstants.DEROG_JSON));
			openArcCardListingInput.put(CreditBusinessConstants.DEROG_JSON, derogJson);
		}

		JSONObject obligationJSON = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OBLIGATION_AMT));
		if (null != obligationJSON) {
			openArcCardListingInput.put("obligationAmount", null != obligationJSON.get("emiSum") ? obligationJSON.get("emiSum").toString() : null);
			List<Map<String, Object>> obligationDetailsList = (List<Map<String, Object>>) obligationJSON.get("emiList");
			List<ObligationDetail> obligationList = null;
			if (!obligationDetailsList.isEmpty()) {
				obligationList = new ArrayList<>();
				for (Map<String, Object> obligation : obligationDetailsList) {
					ObligationDetail details = new ObligationDetail();
					details.setAccountType(obligation.get("accountType") != null ? obligation.get("accountType").toString() : null);
					details.setCurrentBalance((obligation.get("currentBalance") != null && !obligation.get("currentBalance").toString().equals(""))
							? Integer.parseInt(obligation.get("currentBalance").toString())
							: 0);
					details.setEmiAmount((obligation.get("emiAmount") != null && !obligation.get("emiAmount").equals(""))
							? Integer.parseInt(obligation.get("emiAmount").toString())
							: 0);
					if (obligation.get("mob") != null) {
						double m = Double.parseDouble(obligation.get("mob").toString());
						Integer mob = (int) m;
						details.setMob(mob);
					}
					obligationList.add(details);
				}
			}
			openArcCardListingInput.put("obligationDetailList", obligationList);
		}

		breRequest.put(OPEN_ARC_CARD_LIST_INPUT, openArcCardListingInput);
		breRequest.put("additionalParameterDetail", mcp2Request.get("additionalParameterDetail"));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, breRequest);
		execution.setVariable(REJECTION_SYSTEM, RejectionSystemSourceEnum.LISTBREAPI.getValue());
		execution.setVariable(SEND_NOTIFICATION, true);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preListing ");
	}

	public void postListing(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postListing");
		breListener.postListing(execution);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postListing");
	}

	public void postGetBreRequest(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preMcpRequest");
		JSONObject mcp = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT, mcp);
		JSONObject prodCategory = CreditBusinessHelper.getJSONObject(mcp.get("prodCategory"));
		execution.setVariable(CreditBusinessConstants.PRODUCTDESC, prodCategory.get("prodCatDesc"));
		execution.setVariable(CreditBusinessConstants.PRODUCTCODE, prodCategory.get("prodCatCode"));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preMcpRequest");
	}
}
