package com.bajaj.markets.credit.business.datasource;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AdditionalInfo;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.AddressDetails;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.BusinessOwnerDetails;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.EligibilityResponse;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.Gender;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.MaritalStatus;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OfferApiRequest;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.beans.OfferSource;
import com.bajaj.markets.credit.business.beans.PrincipalCustomer;
import com.bajaj.markets.credit.business.beans.PrincipalOfferDetails;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.SalariedDetail;
import com.bajaj.markets.credit.business.beans.UpdatePrincipalParam;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class RBLExtDataSource implements DataSource {

	@Value("${api.cardsprincipalintgrservice.axis.offers.GET.url}")
	private String principalOffersUrl;

	@Value("${api.referencedataservice.offersource.url}")
	private String offerSourceUrl;
	
	@Value("${api.omreferencedatareferencedataservice.getmaritalstatus.get.url}")
	private String getmaritalStatusURL;
	
	@Value("${api.omreferencedatareferencedataservice.getgender.get.url}")
	private String getgenderURL;
	
	@Value("${api.omreferencedatareferencedataservice.location.pincode.get.url}")
	private String pinCodeUrl;
	
	@Value("${CC.RBLExtDataSource.precedence}")
	private String precedence;
	
	@Autowired
	private CreditBusinessHelper creditBusinessHelper;

	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private BFLLoggerUtil loggerUtil;
	
	@Value("${api.omcreditcardsprincipalintegrationservice.principal.update.param.PUT.url}")
	private String updatePrincipalUrl;

	private static final String CLASS_NAME = RBLExtDataSource.class.getName();

	@Override
	public void registerDataSource(DataSourceRegistry dataSourceRegistry) {
		dataSourceRegistry.registerDataSource(this);
		loggerUtil.info(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"registerDataSource - RBLExtDataSource registration done");
	}

	@Override
	public OfferDetailsBean initDataSource(ApplicantDataBean applicantDataBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		OfferDetailsBean offerDetailsBean = new OfferDetailsBean();
		try {			
			offerDetailsBean.setPrecedence(Integer.parseInt(precedence));
			offerDetailsBean.setDataSourceName(this.getClass().getSimpleName());
			EligibilityResponse eligibilityResponse = getRBLEligibility(applicantDataBean);
			if (!CollectionUtils.isEmpty(eligibilityResponse.getOfferDetails())) {
				updateRBLConsentUtmParam(applicantDataBean);
			}
			OfferSource offerSource = getRBLOfferDetails(applicantDataBean);
	
			populatePrincipalCustomerDetails(eligibilityResponse, applicantDataBean, offerDetailsBean);
			populateUserProfileDetails(eligibilityResponse, applicantDataBean, offerDetailsBean);
			populateDocumentDetails(eligibilityResponse, offerDetailsBean);
			populateEmailDetails(eligibilityResponse, offerDetailsBean);
			populateAddressDetails(eligibilityResponse, applicantDataBean, offerDetailsBean);
			populateOfferDetails(eligibilityResponse, offerSource, applicantDataBean, offerDetailsBean);
			populateOccupationDetails(eligibilityResponse, applicantDataBean, offerDetailsBean);

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - Population process failed", e);
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
		return offerDetailsBean;
	}

	private void populateOfferDetails(EligibilityResponse eligibilityResponse, OfferSource OfferSource,
			ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		List<AppOfferDetBean> offers = new ArrayList<>();
		Long offerSourceKey = null != OfferSource && null != OfferSource.getOffersrckey()
				? Long.valueOf(OfferSource.getOffersrckey())
				: null;
		if (!CollectionUtils.isEmpty(eligibilityResponse.getOfferDetails())) {
			for (PrincipalOfferDetails principalOfferDetails : eligibilityResponse.getOfferDetails()) {
				AppOfferDetBean bean = new AppOfferDetBean();
				bean.setApplicationKey(null != applicantDataBean.getOfferApiRequest().getApplicationKey() ? Long.parseLong(applicantDataBean.getOfferApiRequest().getApplicationKey()) : null);
				bean.setProductCode(principalOfferDetails.getProductCode());
				bean.setOfferSrcKey(offerSourceKey);
				bean.setIsOfferAvailable(true);
				bean.setRiskClassification(principalOfferDetails.getProductRiskBands());
				bean.setOfferGenerationSource(principalOfferDetails.getSourcingType());
				bean.setIsCardHolder(principalOfferDetails.getProductHolder());
				bean.setOfferExpiryDt(principalOfferDetails.getOfferExpiryDate());
				if (!StringUtils.isBlank(principalOfferDetails.getCardLimit())
						&& StringUtils.isNumeric(principalOfferDetails.getCardLimit())) {
					bean.setOfferAmt(new BigDecimal(principalOfferDetails.getCardLimit()));
				}
				offers.add(bean);
			}
		}
		offerDetailsBean.setOffers(offers);
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - Ended");
	}

	private void populatePrincipalCustomerDetails(EligibilityResponse eligibilityResponse,
			ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populatePrincipalCustomerDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		List<PrincipalCustomer> principalCustomerDetails = new ArrayList<>();
		if(null != eligibilityResponse) {
			PrincipalCustomer principalCustomerDetail = new PrincipalCustomer();
			principalCustomerDetail.setApplicationKey(null != applicantDataBean.getOfferApiRequest().getApplicationKey() ? Long.parseLong(applicantDataBean.getOfferApiRequest().getApplicationKey()) : null);
			principalCustomerDetail.setPrincipleCustRefId(eligibilityResponse.getAppRefId());
			principalCustomerDetail.setPrincipleCustRefSrc(CreditBusinessConstants.CUST_REF_SRC);
			principalCustomerDetail.setPrincipleCustType(eligibilityResponse.getCustType());
			principalCustomerDetail.setIsEtb(false);
			principalCustomerDetail.setPrincipalKey(Long.parseLong(CreditBusinessConstants.RBL_PRINCIPAL_KEY));
			if (null != principalCustomerDetail.getPrincipleCustType()
					&& (CreditBusinessConstants.ETB.equalsIgnoreCase(principalCustomerDetail.getPrincipleCustType())
							|| CreditBusinessConstants.LEAD.equalsIgnoreCase(principalCustomerDetail.getPrincipleCustType()))) {
				principalCustomerDetail.setIsEtb(true);
			}
			principalCustomerDetail.setAdditionalDetails(eligibilityResponse.getAdditionalInfo());
			principalCustomerDetail.setAppattrbkey(Long.valueOf(applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey()));
			principalCustomerDetails.add(principalCustomerDetail);
		}
		offerDetailsBean.setPrincipalCustomerDetails(principalCustomerDetails);
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populatePrincipalCustomerDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
	}
	
	private void populateUserProfileDetails(EligibilityResponse eligibilityResponse,
			ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateUserProfileDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		List<UserProfileBean> userProfileBeans = new ArrayList<>();
		if(null != eligibilityResponse && null != eligibilityResponse.getAdditionalInfo()) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			AdditionalInfo additionalInfo = mapper.convertValue(eligibilityResponse.getAdditionalInfo(), AdditionalInfo.class);
			UserProfileBean userProfileBean = new UserProfileBean();
			userProfileBean.setApplicationKey(applicantDataBean.getOfferApiRequest().getApplicationKey());
			userProfileBean.setApplicationUserAttributeKey(applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey());
			userProfileBean.setDateOfBirth(additionalInfo.getDateOfBirth());
			userProfileBean.setGenderKey(getGenderKey(additionalInfo.getGender()));
			userProfileBean.setMaritalStatusKey(getMaritalStatusKey(additionalInfo.getMaritalStatus()));
			Name name = new Name();
			name.setFirstName(additionalInfo.getName());
			name.setMiddleName(null != additionalInfo.getMiddleName() ? additionalInfo.getMiddleName() : "");
			name.setLastName(null != additionalInfo.getLastName() ? additionalInfo.getLastName() : "");
			userProfileBean.setName(name);
			userProfileBean.setPanNumber(additionalInfo.getPanNumber());
			userProfileBean.setMotherName(additionalInfo.getMothersName());
			userProfileBean.setFatherName(additionalInfo.getFathersName());
			userProfileBeans.add(userProfileBean);
		}
		offerDetailsBean.setUserProfileBeans(userProfileBeans);
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateUserProfileDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
	}
	
	private void populateDocumentDetails(EligibilityResponse eligibilityResponse, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateDocumentDetails method - started");
		List<DocumentDetails> documents = new ArrayList<>();
		if(null != eligibilityResponse && null != eligibilityResponse.getAdditionalInfo()) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			AdditionalInfo additionalInfo = mapper.convertValue(eligibilityResponse.getAdditionalInfo(), AdditionalInfo.class);
			if(!StringUtils.isEmpty(additionalInfo.getPanNumber())) {
				DocumentDetails documentDetail = new DocumentDetails();
				documentDetail.setDocumentNameKey(1L);
				documentDetail.setDocumentNumber(additionalInfo.getPanNumber());
				documents.add(documentDetail);
			}
		}
		offerDetailsBean.setDocuments(documents);
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateDocumentDetails method - ended");
	}
	
	private void populateEmailDetails(EligibilityResponse eligibilityResponse, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateEmailDetails method - started");
		List<Email> emails = new ArrayList<>();
		if(null != eligibilityResponse && null != eligibilityResponse.getAdditionalInfo()) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			AdditionalInfo additionalInfo = mapper.convertValue(eligibilityResponse.getAdditionalInfo(), AdditionalInfo.class);
			if (!StringUtils.isEmpty(additionalInfo.getPersonalEmail())) {
				Email email = new Email();
				email.setEmail(additionalInfo.getPersonalEmail());
				email.setTypeKey(CreditBusinessConstants.PERSONAL_EMAIL_TYPE);
				emails.add(email);
			}
		}
		offerDetailsBean.setEmails(emails);
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateEmailDetails method - ended");
	}
	
	private void populateAddressDetails(EligibilityResponse eligibilityResponse, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateAddressDetails method - started");
		List<Address> addresses = new ArrayList<>();
		if(null != eligibilityResponse && null != eligibilityResponse.getAdditionalInfo()) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			AdditionalInfo additionalInfo = mapper.convertValue(eligibilityResponse.getAdditionalInfo(), AdditionalInfo.class);
			List<AddressDetails> addressDetailsList = new ArrayList<>();
			
			AddressDetails currentAddress = new AddressDetails();
			currentAddress.setAddressType(AddressTypeEnum.CURRENT.getValue());
			String currAddL1 = null != additionalInfo.getCurrentAddressLine1() ? additionalInfo.getCurrentAddressLine1() : "";
			currentAddress.setAddressLine1(currAddL1);
			String currAddL2 = null != additionalInfo.getCurrentAddressLine2() ? additionalInfo.getCurrentAddressLine2() : "";
			String currAddL3 = null != additionalInfo.getCurrentAddressLine3() ? additionalInfo.getCurrentAddressLine3() : "";
			currentAddress.setAddressLine2(currAddL2+" "+currAddL3);
			currentAddress.setPinCode(additionalInfo.getZipCode());
			currentAddress.setCity(additionalInfo.getCurrentCity());
			currentAddress.setState(additionalInfo.getCurrentState());
			
			AddressDetails permanentAddress = new AddressDetails();
			permanentAddress.setAddressType(AddressTypeEnum.PERMANENT.getValue());
			String permAddL1 = null != additionalInfo.getPermanentAddressLine1() ? additionalInfo.getPermanentAddressLine1() : "";
			permanentAddress.setAddressLine1(permAddL1);
			String permAddL2 = null != additionalInfo.getPermanentAddressLine2() ? additionalInfo.getPermanentAddressLine2() : "";
			String permAddL3 = null != additionalInfo.getPermanentAddressLine3() ? additionalInfo.getPermanentAddressLine3() : "";
			permanentAddress.setAddressLine2(permAddL2+" "+permAddL3);
			permanentAddress.setPinCode(additionalInfo.getPermanentzipCode());
			permanentAddress.setCity(additionalInfo.getPermanentCity());
			permanentAddress.setState(additionalInfo.getPermanentState());
			
			AddressDetails officeAddress = new AddressDetails();
			officeAddress.setAddressType(AddressTypeEnum.OFFICE.getValue());
			String offcAddL1 = null != additionalInfo.getOfficeAddressLine1() ? additionalInfo.getOfficeAddressLine1() : "";
			officeAddress.setAddressLine1(offcAddL1);
			String offcAddL2 = null != additionalInfo.getOfficeAddressLine2() ? additionalInfo.getOfficeAddressLine2() : "";
			String offcAddL3 = null != additionalInfo.getOfficeAddressLine3() ? additionalInfo.getOfficeAddressLine3() : "";
			officeAddress.setAddressLine2(offcAddL2+" "+offcAddL3);
			officeAddress.setPinCode(additionalInfo.getOfficePinCode());
			officeAddress.setCity(additionalInfo.getOfficeCity());
			officeAddress.setState(additionalInfo.getOfficeState());
			
			addressDetailsList.add(currentAddress);
			addressDetailsList.add(permanentAddress);
			addressDetailsList.add(officeAddress);
			
			for(AddressDetails addressDetail : addressDetailsList) {
				Address address = new Address();
				address.setAddressTypeKey(addressDetail.getAddressType());
				address.setAddressLine1(addressDetail.getAddressLine1());
				address.setAddressLine2(addressDetail.getAddressLine2());
				address.setPincode(addressDetail.getPinCode());
				address.setAddressSource(CreditBusinessConstants.OFFER_API);
				if (!StringUtils.isEmpty(addressDetail.getPinCode())) {
					LocationAddressBean locationAddressBean = getLocationAddressBean(addressDetail, applicantDataBean.getHeaders());
					if(null != locationAddressBean) {
						address.setCityKey(null != locationAddressBean.getCityId() ? String.valueOf(locationAddressBean.getCityId()) : null);
						address.setPincodeKey(null != locationAddressBean.getPinId() ? String.valueOf(locationAddressBean.getPinId()) : null);
						address.setCountryKey(null != locationAddressBean.getCountryId() ? String.valueOf(locationAddressBean.getCountryId()) : null);
						address.setStateKey(null != locationAddressBean.getStateId() ? String.valueOf(locationAddressBean.getStateId()) : null);
					}
					addresses.add(address);
				}
			}
		}
		offerDetailsBean.setAddresses(addresses);
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateAddressDetails method - ended");
	}
	
	private void populateOccupationDetails(EligibilityResponse eligibilityResponse, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateOccupationDetails method - started");
		List<Occupation> occupations = new ArrayList<>();
		if(null != eligibilityResponse && null != eligibilityResponse.getAdditionalInfo()) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			AdditionalInfo additionalInfo = mapper.convertValue(eligibilityResponse.getAdditionalInfo(), AdditionalInfo.class);
			
			String employment = additionalInfo.getEmploymentType();
			if(!StringUtils.isEmpty(employment) && employment.equalsIgnoreCase("Self-Employed Professional")) {
				Occupation occupation = new Occupation();
				BusinessOwnerDetails businessOwnerDetails = new BusinessOwnerDetails();
				businessOwnerDetails.setBusinessName(additionalInfo.getNameOfCompanyBusiness());
				occupation.setBusinessOwnerDetails(businessOwnerDetails);
				occupation.setOcupationType(getReference(2l, "SEMP", "Self Employed"));
				occupations.add(occupation);
			} else if (!StringUtils.isEmpty(employment) && employment.equalsIgnoreCase("Salaried")) {
				Occupation occupation = new Occupation();
				SalariedDetail salariedDetail = new SalariedDetail();
				salariedDetail.setEmployerNameOther(additionalInfo.getNameOfCompanyBusiness());
				occupation.setSalariedDetail(salariedDetail);
				occupation.setOcupationType(getReference(1l, "SALR", "Salaried"));
				occupations.add(occupation);
			}
		}
		offerDetailsBean.setOccupations(occupations);
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - populateOccupationDetails method - ended");
	}

	public EligibilityResponse getRBLEligibility(ApplicantDataBean applicantDataBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getRBLEligibility method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			HttpHeaders headers = applicantDataBean.getHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(CreditBusinessConstants.APPLICATION_ID,
					applicantDataBean.getOfferApiRequest().getApplicationKey());
			headers.add(CreditBusinessConstants.MOBILE_NUMBER, applicantDataBean.getOfferApiRequest().getMobileNo());

			HashMap<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.PRINCIPAL, CreditBusinessConstants.RBL_PRINCIPAL_VALUE);

			ResponseEntity<?> response = (ResponseEntity<?>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					principalOffersUrl, Object.class, paramMap, null, headers);
			if (null != response && null != response.getBody() && HttpStatus.OK.equals(response.getStatusCode())) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getRBLEligibility method response is "+response);
				ObjectMapper mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				EligibilityResponse offers = mapper.convertValue(response.getBody(), EligibilityResponse.class);
				logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getRBLEligibility method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
				return offers;
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getRBLEligibility method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - offer data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getRBLEligibility method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - failed", e);
			return null;
		}
	}

	private OfferSource getRBLOfferDetails(ApplicantDataBean applicantDataBean) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getRBLOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		HttpHeaders headers = applicantDataBean.getHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HashMap<String, String> paramMap = new HashMap<>();
		paramMap.put("srccode", CreditBusinessConstants.CUST_REF_SRC);
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			ResponseEntity<?> response = (ResponseEntity<?>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					offerSourceUrl, Object.class, paramMap, null, headers);
			if (null != response && (HttpStatus.OK.equals(response.getStatusCode()) && null != response.getBody())) {
				List<OfferSource> offerSourceList = mapper.convertValue(response.getBody(),
						new TypeReference<List<OfferSource>>() {
						});
				OfferSource offerSource = !CollectionUtils.isEmpty(offerSourceList) ? offerSourceList.get(0) : null;
				logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getRBLOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
				return offerSource;
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getRBLOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - applicant data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getRBLOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - failed", e);
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	private Long getGenderKey(final String gender) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getGenderKey method - started");
		try {
			ResponseEntity<List<Gender>> responseEntity = (ResponseEntity<List<Gender>>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, getgenderURL, List.class, null, null, new HttpHeaders());
			List<Gender> genderList;
			Long genderKey = null;
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				genderList = mapper.convertValue(responseEntity.getBody(), new TypeReference<List<Gender>>() {
				});
		
				for (Gender genderObj : genderList) {
					if (genderObj.getGenderValue().equalsIgnoreCase(gender)) {
						genderKey = genderObj.getGenderKey();
						break;
					}
				}
				logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getGenderKey method - ended");
				return genderKey;
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getGenderKey method - gender data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getGenderKey method - failed", e);
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	private Long getMaritalStatusKey(final String maritalStatus) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getMaritalStatusKey method - started");
		try { 
			ResponseEntity<List<MaritalStatus>> responseEntity = (ResponseEntity<List<MaritalStatus>>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, getmaritalStatusURL, List.class, null, null, new HttpHeaders());
			List<MaritalStatus> maritalStatusList;
			Long maritalStatusKey = null;
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				maritalStatusList = mapper.convertValue(responseEntity.getBody(),
						new TypeReference<List<MaritalStatus>>() {
						});
				for (MaritalStatus marStatus : maritalStatusList) {
					if ((marStatus.getMaritalStatusValue()).equalsIgnoreCase(maritalStatus)) {
						maritalStatusKey = marStatus.getMaritalStatusKey();
						break;
					}
				}
				logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getMaritalStatusKey method - ended");
				return maritalStatusKey;
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getMaritalStatusKey method - marital status data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getMaritalStatusKey method - failed", e);
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	private LocationAddressBean getLocationAddressBean(AddressDetails addressDetail, HttpHeaders headers) {
		logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getLocationAddressBean method - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("pincode", addressDetail.getPinCode());
			ResponseEntity<LocationAddressBean> responseEntity = (ResponseEntity<LocationAddressBean>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, pinCodeUrl, LocationAddressBean.class, paramMap,
							null, headers);
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				logger.info(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getLocationAddressBean method - ended");
				return responseEntity.getBody();
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getLocationAddressBean method - location address data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside RBLExtDataSource - getLocationAddressBean method - failed", e);
			return null;
		}
	}
	
	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;
	}

	private void updateRBLConsentUtmParam(ApplicantDataBean applicantDataBean) {
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"updateRBLUtmParam start with " + applicantDataBean.toString());
			OfferApiRequest offerApiRequest = applicantDataBean.getOfferApiRequest();
			HttpHeaders headers = applicantDataBean.getHeaders();
			Gson gson = new Gson();
			UpdatePrincipalParam updatePrincipalParam = new UpdatePrincipalParam();
			updatePrincipalParam.setApplicationId(offerApiRequest.getApplicationKey());
			updatePrincipalParam.setMobileNumber(offerApiRequest.getMobileNo());
			List<String> utmSrcList = headers.get("utm_source");
			String utmSrc = null;
			if (!CollectionUtils.isEmpty(utmSrcList)) {
				utmSrc = utmSrcList.get(0);
			}
			updatePrincipalParam.setUtmSrc(utmSrc);
			String updateParamReqjson = gson.toJson(updatePrincipalParam);
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("principalkey", "2");
			ResponseEntity<Object> responseEntity = (ResponseEntity<Object>) creditBusinessHelper.invokeRestEndpoint(
					HttpMethod.PUT, updatePrincipalUrl, String.class, paramMap, updateParamReqjson, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "updateRBLUtmParam Ends with " + responseEntity);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Exception while updateRBLConsentUtmParam : ", e);
		}
	}

}