package com.bajaj.markets.credit.business.controller;

import static com.bajaj.bfsd.security.beans.CustomDefaultHeaders.CMPTCORR_ID;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.business.beans.ResponseBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;

@ControllerAdvice
public class CreditBusinessControllerAdvice extends ResponseEntityExceptionHandler {
	
	private static final String CLASS_NAME = CreditBusinessControllerAdvice.class.getCanonicalName();
	
	@SuppressWarnings("deprecation")
	@ExceptionHandler(value = { CreditBusinessException.class })
	protected ResponseEntity<Object> handleConflict(RuntimeException ex, WebRequest request) {
		CreditBusinessException creditBusinessException = (CreditBusinessException) ex;
		//To log internal server exception from controller advice
		if(creditBusinessException.getCode().is5xxServerError()) {
			String requestDescription = request.getDescription(false);
			BFLLoggerUtil.error(request.getHeader(CMPTCORR_ID), CLASS_NAME, BFLLoggerComponent.EXCEPTION_HANDLER, "Exception Occurred for request: " + requestDescription, creditBusinessException);
		}
		if (null != creditBusinessException.getErrorBean() && null != creditBusinessException.getPayload()) {
			return handleExceptionInternal(ex,
					new ResponseBean(creditBusinessException.getPayload(), creditBusinessException.getErrorBean()),
					new HttpHeaders(), creditBusinessException.getCode(), request);
		} else if (null != creditBusinessException.getErrorBean()) {
			return handleExceptionInternal(ex, creditBusinessException.getErrorBean(), new HttpHeaders(),
					creditBusinessException.getCode(), request);
		} else if (null != creditBusinessException.getPayload()) {
			return handleExceptionInternal(ex, creditBusinessException.getPayload(), new HttpHeaders(),
					creditBusinessException.getCode(), request);
		}else{
			return handleExceptionInternal(ex, creditBusinessException.getMessage(), new HttpHeaders(),
					creditBusinessException.getCode(), request);
		}
	}
}
