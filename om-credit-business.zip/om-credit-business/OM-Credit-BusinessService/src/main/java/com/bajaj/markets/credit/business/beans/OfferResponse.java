package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;

public class OfferResponse {

	private BigDecimal offerAmount;

	private String name;

	private BigDecimal offerRoi;

	private BigDecimal isEmiAmount;

	private Integer offerTenure;

	private String l3ProductCode;

	private String riskOfferType;

	private Integer displayPriority;

	public BigDecimal getOfferAmount() {
		return offerAmount;
	}

	public void setOfferAmount(BigDecimal offerAmount) {
		this.offerAmount = offerAmount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getOfferRoi() {
		return offerRoi;
	}

	public void setOfferRoi(BigDecimal offerRoi) {
		this.offerRoi = offerRoi;
	}

	public BigDecimal getIsEmiAmount() {
		return isEmiAmount;
	}

	public void setIsEmiAmount(BigDecimal isEmiAmount) {
		this.isEmiAmount = isEmiAmount;
	}

	public Integer getOfferTenure() {
		return offerTenure;
	}

	public void setOfferTenure(Integer offerTenure) {
		this.offerTenure = offerTenure;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public Integer getDisplayPriority() {
		return displayPriority;
	}

	public void setDisplayPriority(Integer displayPriority) {
		this.displayPriority = displayPriority;
	}

	@Override
	public String toString() {
		return "OfferResponse [offerAmount=" + offerAmount + ", name=" + name + ", offerRoi=" + offerRoi
				+ ", isEmiAmount=" + isEmiAmount + ", offerTenure=" + offerTenure + ", l3ProductCode=" + l3ProductCode
				+ ", riskOfferType=" + riskOfferType + ", displayPriority=" + displayPriority + "]";
	}

}
