package com.bajaj.markets.credit.business.beans;

public class BankDetailsReponse {

	private Long bankDetailsKey;
	private String accoutNumber;
	private String userAttributeKey;
	private String branchKey;
	private String bankMasterKey;
	private String impsStatus;
	private String impsKey;
	private String source;
	private String bankAccountTypeKey;
	private String impsNameMatch;
	private String finalMandateKey;
	private String systemSelectedMandateKey;
	private String bankAccountCatagory;
	private String beneficiaryType;
	private Boolean preferedBank;
	private String beneficiaryNames;
	private String holderName;
	private String accountVerificationStatus;
	private String mandateAddedBy;
	
	public String getBankMasterKey() {
		return bankMasterKey;
	}

	public void setBankMasterKey(String bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}

	public Long getBankDetailsKey() {
		return bankDetailsKey;
	}

	public void setBankDetailsKey(Long bankDetailsKey) {
		this.bankDetailsKey = bankDetailsKey;
	}

	public String getAccoutNumber() {
		return accoutNumber;
	}

	public void setAccoutNumber(String accoutNumber) {
		this.accoutNumber = accoutNumber;
	}

	public String getUserAttributeKey() {
		return userAttributeKey;
	}

	public void setUserAttributeKey(String userAttributeKey) {
		this.userAttributeKey = userAttributeKey;
	}

	public String getBranchKey() {
		return branchKey;
	}

	public void setBranchKey(String branchKey) {
		this.branchKey = branchKey;
	}

	public String getImpsStatus() {
		return impsStatus;
	}

	public void setImpsStatus(String impsStatus) {
		this.impsStatus = impsStatus;
	}

	public String getImpsKey() {
		return impsKey;
	}

	public void setImpsKey(String impsKey) {
		this.impsKey = impsKey;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getBankAccountTypeKey() {
		return bankAccountTypeKey;
	}

	public void setBankAccountTypeKey(String bankAccountTypeKey) {
		this.bankAccountTypeKey = bankAccountTypeKey;
	}

	public String getImpsNameMatch() {
		return impsNameMatch;
	}

	public void setImpsNameMatch(String impsNameMatch) {
		this.impsNameMatch = impsNameMatch;
	}

	public String getFinalMandateKey() {
		return finalMandateKey;
	}

	public void setFinalMandateKey(String finalMandateKey) {
		this.finalMandateKey = finalMandateKey;
	}

	public String getSystemSelectedMandateKey() {
		return systemSelectedMandateKey;
	}

	public void setSystemSelectedMandateKey(String systemSelectedMandateKey) {
		this.systemSelectedMandateKey = systemSelectedMandateKey;
	}

	public String getBankAccountCatagory() {
		return bankAccountCatagory;
	}

	public void setBankAccountCatagory(String bankAccountCatagory) {
		this.bankAccountCatagory = bankAccountCatagory;
	}

	public String getBeneficiaryType() {
		return beneficiaryType;
	}

	public void setBeneficiaryType(String beneficiaryType) {
		this.beneficiaryType = beneficiaryType;
	}

	public Boolean getPreferedBank() {
		return preferedBank;
	}

	public void setPreferedBank(Boolean preferedBank) {
		this.preferedBank = preferedBank;
	}

	public String getBeneficiaryNames() {
		return beneficiaryNames;
	}

	public void setBeneficiaryNames(String beneficiaryNames) {
		this.beneficiaryNames = beneficiaryNames;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getAccountVerificationStatus() {
		return accountVerificationStatus;
	}

	public void setAccountVerificationStatus(String accountVerificationStatus) {
		this.accountVerificationStatus = accountVerificationStatus;
	}

	public String getMandateAddedBy() {
		return mandateAddedBy;
	}

	public void setMandateAddedBy(String mandateAddedBy) {
		this.mandateAddedBy = mandateAddedBy;
	}

	@Override
	public String toString() {
		return "BankDetailsReponse [bankDetailsKey=" + bankDetailsKey + ", accoutNumber=" + accoutNumber
				+ ", userAttributeKey=" + userAttributeKey + ", branchKey=" + branchKey + ", bankMasterKey="
				+ bankMasterKey + ", impsStatus=" + impsStatus + ", impsKey=" + impsKey + ", source=" + source
				+ ", bankAccountTypeKey=" + bankAccountTypeKey + ", impsNameMatch=" + impsNameMatch
				+ ", finalMandateKey=" + finalMandateKey + ", systemSelectedMandateKey=" + systemSelectedMandateKey
				+ ", bankAccountCatagory=" + bankAccountCatagory + ", beneficiaryType=" + beneficiaryType
				+ ", preferedBank=" + preferedBank + ", beneficiaryNames=" + beneficiaryNames + ", holderName="
				+ holderName + ", accountVerificationStatus=" + accountVerificationStatus + ", mandateAddedBy="
				+ mandateAddedBy + "]";
	}

}