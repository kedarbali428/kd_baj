package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;

public class Verification implements Serializable, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Boolean isVerified;
	private String verificationSource;
	private String verifiedFor;
	
	@JsonAdapter(LocalDateAdapter.class)
	private Timestamp verificationDate;
	
	private Long verificationReference;
	private Long verifyingProductCategoryKey ;

	public Boolean getIsVerified() {
		return isVerified;
	}
	public void setIsVerified(Boolean isVerified) {
		this.isVerified = isVerified;
	}
	public String getVerificationSource() {
		return verificationSource;
	}
	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}
	public String getVerifiedFor() {
		return verifiedFor;
	}
	public void setVerifiedFor(String verifiedFor) {
		this.verifiedFor = verifiedFor;
	}
	public Timestamp getVerificationDate() {
		return verificationDate;
	}
	public void setVerificationDate(Timestamp verificationDate) {
		this.verificationDate = verificationDate;
	}
	public Long getVerificationReference() {
		return verificationReference;
	}
	public void setVerificationReference(Long verificationReference) {
		this.verificationReference = verificationReference;
	}
	
	public Long getVerifyingProductCategoryKey() {
		return verifyingProductCategoryKey;
	}
	public void setVerifyingProductCategoryKey(Long verifyingProductCategoryKey) {
		this.verifyingProductCategoryKey = verifyingProductCategoryKey;
	}
	
	@Override
	public String toString() {
		return "Verification [isVerified=" + isVerified + ", verificationSource=" + verificationSource
				+ ", verifiedFor=" + verifiedFor + ", verificationDate=" + verificationDate + ", verificationReference="
				+ verificationReference + ", verifyingProductCategoryKey=" + verifyingProductCategoryKey + "]";
	}

	class LocalDateAdapter implements JsonSerializer<Timestamp> {

		@Override
		public JsonElement serialize(Timestamp src, java.lang.reflect.Type typeOfSrc,
				JsonSerializationContext context) {
			return new JsonPrimitive(src.toLocalDateTime().toLocalDate().format(DateTimeFormatter.ISO_LOCAL_DATE)); // "yyyy-mm-dd"
		}
	}

	@Override
	public Verification clone() {
		Verification verificationObj = new Verification();
		verificationObj.setIsVerified(isVerified);
		verificationObj.setVerificationDate(verificationDate);
		verificationObj.setVerificationReference(verificationReference);
		verificationObj.setVerificationSource(verificationSource);
		verificationObj.setVerifyingProductCategoryKey(verifyingProductCategoryKey);
		return verificationObj;
	}
}
