package com.bajaj.markets.credit.business.helper;

import org.springframework.http.HttpStatus;

public class DialerIntegrationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2143198713968316665L;

	private HttpStatus code;
	private Object payload;

	public DialerIntegrationException(HttpStatus code, Object payload) {
		super();
		this.code = code;
		this.payload = payload;
	}

	public DialerIntegrationException() {
	}

	public HttpStatus getCode() {
		return code;
	}

	public void setCode(HttpStatus code) {
		this.code = code;
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}

}
