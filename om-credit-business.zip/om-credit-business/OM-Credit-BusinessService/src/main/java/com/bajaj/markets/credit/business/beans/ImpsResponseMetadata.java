package com.bajaj.markets.credit.business.beans;


/**
 * This is bean class for BankService
 * 
 * @author 604135
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          604135          01/02/2016      Initial Version
 *
 */
public class ImpsResponseMetadata
{
	private String tranRefNo;
	private String tranSatus;
	private String bankRefNo;
	private String beneficiaryName;
	private String transStatusCode;
	private String beneAccNo;
	private String applicationBankDetKey;
	private String impsKey;
	
	/**
	 * @return the transStatusCode
	 */
	public String getTransStatusCode() {
		return transStatusCode;
	}
	/**
	 * @param transStatusCode the transStatusCode to set
	 */
	public void setTransStatusCode(String transStatusCode) {
		this.transStatusCode = transStatusCode;
	}
	public String getTranRefNo() {
		return tranRefNo;
	}
	public void setTranRefNo(String tranRefNo) {
		this.tranRefNo = tranRefNo;
	}
	
	public void setTranSatus(String tranSatus) {
		this.tranSatus = tranSatus;
	}
	public String getTranSatus() {
		return tranSatus;
	}
	public void setBankRefNo(String bankRefNo) {
		this.bankRefNo = bankRefNo;
	}
	public String getBankRefNo() {
		return bankRefNo;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}	
	
	public String getBeneAccNo() {
		return beneAccNo;
	}
	public void setBeneAccNo(String beneAccNo) {
		this.beneAccNo = beneAccNo;
	}
	
	public String getApplicationBankDetKey() {
		return applicationBankDetKey;
	}
	public void setApplicationBankDetKey(String applicationBankDetKey) {
		this.applicationBankDetKey = applicationBankDetKey;
	}
	
	public String getImpsKey() {
		return impsKey;
	}
	public void setImpsKey(String impsKey) {
		this.impsKey = impsKey;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ImpsResponseMetadata [tranRefNo=" + tranRefNo + ", tranSatus=" + tranSatus + ", bankRefNo=" + bankRefNo
				+ ", beneficiaryName=" + beneficiaryName + ", transStatusCode=" + transStatusCode + "]";
	}
	
}
