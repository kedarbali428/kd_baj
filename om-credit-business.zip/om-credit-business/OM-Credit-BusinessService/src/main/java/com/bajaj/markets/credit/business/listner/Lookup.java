package com.bajaj.markets.credit.business.listner;

import java.util.ArrayList;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Lookup {

	private static final String LOOKUP_VALUES_RESPONSE_LIST = "lookupValuesResponseList";

	@Autowired
	BFLLoggerUtilExt logger;

	final ObjectMapper mapper = new ObjectMapper();

	private static final String CLASS_NAME = Lookup.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void setQualification(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start setQualification");
		JSONObject output = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (output != null) {
			execution.setVariable(CreditBusinessConstants.QUALIFICATION_LOOKUP_LIST, (ArrayList<Map<String, Object>>) output.get(LOOKUP_VALUES_RESPONSE_LIST));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End setQualification");
	}

	@SuppressWarnings("unchecked")
	public void setAnnualturnover(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start setAnnualturnover");
		JSONObject output = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (output != null) {
			execution.setVariable(CreditBusinessConstants.ANNUALTURNOVER_LOOKUP_LIST, (ArrayList<Map<String, Object>>) output.get(LOOKUP_VALUES_RESPONSE_LIST));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End setAnnualturnover");
	}

}
