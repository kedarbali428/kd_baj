package com.bajaj.markets.credit.business.service.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationInfo;
import com.bajaj.markets.credit.business.beans.GstInfo;
import com.bajaj.markets.credit.business.beans.GstRequest;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessGSTService;
import com.bajaj.markets.credit.business.service.CreditBusinessService;

@Component
public class CreditBusinessGSTServiceImpl implements CreditBusinessGSTService {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessService creditBusinessService;

	private static final String CLASS_NAME = CreditBusinessGSTServiceImpl.class.getCanonicalName();

	@Override
	public GstInfo getGstInfo(String applicationid, GstRequest gst, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside getGstInfo method"+applicationid);

		GstInfo gstInfo = new GstInfo();
		try {
			ApplicationInfo applicationInfo = creditBusinessService.getApplicationInfo(applicationid, headers);
			String GpanNum = gst.getGstPinNo().substring(2, 12);
			if (GpanNum.equals(applicationInfo.getPanNumber())) {
				// method to validate GST
				gstInfo.setValidated(isValidGSTNo(gst.getGstPinNo()));
			}
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while validating GstPin  ", e);
			throw e;
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "exit  getGstInfo method"+applicationid);

		
		return gstInfo;
	}

	private boolean isValidGSTNo(String gSTNO) {
		// Regex to check valid
		String regex = "^[0-9]{2}[A-Z]{5}[0-9]{4}" + "[A-Z]{1}[1-9A-Z]{1}" + "Z[0-9A-Z]{1}$";
		// compile to ReGex
		Pattern p = Pattern.compile(regex);
		// If string is empty
		// retrun false
		if (gSTNO == null) {
			return false;
		}
		// find matching
		Matcher m = p.matcher(gSTNO);
		// return if the string
		// matched the ReGex
		return m.matches();
	}

}
