package com.bajaj.markets.credit.business.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.AppDocumentTrackingBean;
import com.bajaj.markets.credit.business.beans.DocumentPushResponseBean;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.InitiateDocumentPushRequest;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessApplicationDocumentPushService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessApplicationDocumentPushController {
	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessApplicationDocumentPushService creditBusinessApplicationDocumentPushService;

	private static final String CLASS_NAME = CreditBusinessApplicationDocumentPushController.class.getCanonicalName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.PRINCIPAL, Role.VENDORPARTNER,Role.CUSTOMER })
	@ApiOperation(value = "Fetch document details", notes = "Fetch document details", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = DocumentPushResponseBean.class) })
	@GetMapping(path = "/v1/credit/applications/{applicationid}/document/push", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<DocumentPushResponseBean> fetchDocumentPushDetails(
			@PathVariable("applicationid") Long applicationId, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start fetchDocumentPushResponse :" + applicationId);
		DocumentPushResponseBean responseBean = creditBusinessApplicationDocumentPushService
				.fetchDocumentPushDetails(applicationId, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End fetchDocumentPushResponse :" + applicationId);
		return new ResponseEntity<DocumentPushResponseBean>(responseBean, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER,Role.EMPLOYEE, Role.PRINCIPAL, Role.VENDORPARTNER,Role.CUSTOMER })
	@ApiOperation(value = "Save/update record in app_document_tracking", notes = "Save/update record in app_document_tracking", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "", response = AppDocumentTrackingBean[].class) })
	@PutMapping(path = "/v1/credit/applications/{applicationid}/document/push/{source}/initiate", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> initiateDocumentPush(
			@Valid @RequestBody InitiateDocumentPushRequest initiateDocumentPushRequest,
			@PathVariable("applicationid") Long applicationId, @PathVariable("source") String source,
			@RequestHeader HttpHeaders headers, BindingResult result) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start initiateDocumentPush :" + applicationId);
		if (result.hasFieldErrors()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Inside initiateDocumentPush method controller - resource validation failed");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_20", result.getFieldErrors().get(0).getDefaultMessage()));
		} else {
			List<AppDocumentTrackingBean> response = creditBusinessApplicationDocumentPushService
					.initiateDocumentPush(initiateDocumentPushRequest, source, headers, applicationId);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End initiateDocumentPush :" + applicationId);
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
	}

}
