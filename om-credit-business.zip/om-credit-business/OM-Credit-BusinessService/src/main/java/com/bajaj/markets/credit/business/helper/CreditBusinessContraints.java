package com.bajaj.markets.credit.business.helper;

public class CreditBusinessContraints {
	
	public interface Salaried {}
	public interface Business {}
	public interface DoctorSalaried {}
	public interface DoctorSelfEmployed {}
	public interface CaIcwaSelfEmployed {}
	public interface Other {}
	public interface FppSelected {}
	public interface FppNotSelected {}
	public interface Rejected {}
	public interface NotRejected {}
	public interface Back {}
	
}
