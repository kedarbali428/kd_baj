package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.GstInfo;
import com.bajaj.markets.credit.business.beans.GstRequest;

public interface CreditBusinessGSTService {

	public GstInfo getGstInfo(String applicationid, GstRequest gst, HttpHeaders headers);
		
	
}
