package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Business;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Salaried;

public class Pincode implements Serializable{

	private static final long serialVersionUID = 2703536940790674842L;
	
	@NotBlank(groups = {Salaried.class,Business.class},message = "pincode cannot be null or empty")
	private String pincode;
	
	@NotNull(groups = {Salaried.class,Business.class},message = "city cannot be null or empty")
	private Reference city;
	
	@NotNull(groups = {Salaried.class,Business.class},message = "country cannot be null or empty")
	private Reference country;
	
	@NotNull(groups = {Salaried.class,Business.class},message = "state cannot be null or empty")
	private Reference state;
	
	@NotNull(groups = {Salaried.class,Business.class},message = "oglFlag cannot be null or empty")
	private Boolean oglFlag;
	
	@NotNull(groups = {Salaried.class,Business.class},message = "negativeAreaFlag cannot be null or empty")
	private Boolean negativeAreaFlag;
	
	private String tier;
	
	private String addressLine1;
	
	private String addressLine2;
	
	private String programType;
	
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public Reference getCity() {
		return city;
	}
	public void setCity(Reference city) {
		this.city = city;
	}
	public Reference getCountry() {
		return country;
	}
	public void setCountry(Reference country) {
		this.country = country;
	}
	public Reference getState() {
		return state;
	}
	public void setState(Reference state) {
		this.state = state;
	}
	public Boolean getOglFlag() {
		return oglFlag;
	}
	public void setOglFlag(Boolean oglFlag) {
		this.oglFlag = oglFlag;
	}
	public Boolean getNegativeAreaFlag() {
		return negativeAreaFlag;
	}
	public void setNegativeAreaFlag(Boolean negativeAreaFlag) {
		this.negativeAreaFlag = negativeAreaFlag;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}	
	public String getProgramType() {
		return programType;
	}
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	@Override
	public String toString() {
		return "Pincode [pincode=" + pincode + ", city=" + city + ", country=" + country + ", state=" + state
				+ ", oglFlag=" + oglFlag + ", negativeAreaFlag=" + negativeAreaFlag + ", tier=" + tier
				+ ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2 + ", programType=" + programType + "]";
	}
}
