package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Business;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Salaried;



public class ProcessCard implements Serializable{
	
	private static final long serialVersionUID = 2703536940790674418L;

	@NotBlank(groups = Salaried.class, message = "consent can not be null or empty")
	private String consent;
	
	private String applicationid; 
	
	@NotBlank(groups = Business.class, message = "action can not be null or empty")
	private String action;

	public String getConsent() {
		return consent;
	}

	public void setConsent(String consent) {
		this.consent = consent;
	}

	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "ProcessCard [consent=" + consent + ", applicationid=" + applicationid + "]";
	}
}
