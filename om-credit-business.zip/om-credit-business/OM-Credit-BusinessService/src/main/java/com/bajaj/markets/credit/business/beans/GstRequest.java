package com.bajaj.markets.credit.business.beans;

public class GstRequest {

	private Long applicantId;
	private String gstPinNo;
	public Long getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}
	public String getGstPinNo() {
		return gstPinNo;
	}
	public void setGstPinNo(String gstPinNo) {
		this.gstPinNo = gstPinNo;
	}



}
