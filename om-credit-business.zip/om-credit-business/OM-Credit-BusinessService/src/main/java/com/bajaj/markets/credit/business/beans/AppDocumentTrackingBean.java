package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.validation.constraints.NotNull;

public class AppDocumentTrackingBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer creditdoctype;

	private String docsentstatus;

	private Timestamp docsentdate;

	private Long docsentby;

	private String docerrorcode;

	private String docerrordesc;

	private Timestamp docerrordt;

	private String partnerrefid;

	private String docsource;

	public Integer getCreditdoctype() {
		return creditdoctype;
	}

	public void setCreditdoctype(Integer creditdoctype) {
		this.creditdoctype = creditdoctype;
	}

	public String getDocsentstatus() {
		return docsentstatus;
	}

	public void setDocsentstatus(String docsentstatus) {
		this.docsentstatus = docsentstatus;
	}

	public Timestamp getDocsentdate() {
		return docsentdate;
	}

	public void setDocsentdate(Timestamp docsentdate) {
		this.docsentdate = docsentdate;
	}

	public Long getDocsentby() {
		return docsentby;
	}

	public void setDocsentby(Long docsentby) {
		this.docsentby = docsentby;
	}

	public String getDocerrorcode() {
		return docerrorcode;
	}

	public void setDocerrorcode(String docerrorcode) {
		this.docerrorcode = docerrorcode;
	}

	public String getDocerrordesc() {
		return docerrordesc;
	}

	public void setDocerrordesc(String docerrordesc) {
		this.docerrordesc = docerrordesc;
	}

	public Timestamp getDocerrordt() {
		return docerrordt;
	}

	public void setDocerrordt(Timestamp docerrordt) {
		this.docerrordt = docerrordt;
	}

	public String getPartnerrefid() {
		return partnerrefid;
	}

	public void setPartnerrefid(String partnerrefid) {
		this.partnerrefid = partnerrefid;
	}

	public String getDocsource() {
		return docsource;
	}

	public void setDocsource(String docsource) {
		this.docsource = docsource;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "AppDocumentTrackingBean [creditdoctype=" + creditdoctype + ", docsentstatus=" + docsentstatus
				+ ", docsentdate=" + docsentdate + ", docsentby=" + docsentby + ", docerrorcode=" + docerrorcode
				+ ", docerrordesc=" + docerrordesc + ", docerrordt=" + docerrordt + ", partnerrefid=" + partnerrefid
				+ ", docsource=" + docsource + "]";
	}

}
