package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApplicationBFLDocsResponseBean {
	
	private List<BFLDocument>  docList;
	private List<BFLDocument>  combinedEsignDocList;
	private List <BFLDocument>  physicalCollectionDocList;
	private Map<String, byte[]> fileDataMap = new HashMap<>();
	
	private String feeCode;
	private BigDecimal fee;
	
	public List<BFLDocument> getDocList() {
		return docList;
	}
	public void setDocList(List<BFLDocument> docList) {
		this.docList = docList;
	}
	public List<BFLDocument> getCombinedEsignDocList() {
		return combinedEsignDocList;
	}
	public void setCombinedEsignDocList(List<BFLDocument> combinedEsignDocList) {
		this.combinedEsignDocList = combinedEsignDocList;
	}
	public List<BFLDocument> getPhysicalCollectionDocList() {
		return physicalCollectionDocList;
	}
	public void setPhysicalCollectionDocList(List<BFLDocument> physicalCollectionDocList) {
		this.physicalCollectionDocList = physicalCollectionDocList;
	}
	public String getFeeCode() {
		return feeCode;
	}
	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}
	public BigDecimal getFee() {
		return fee;
	}
	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}

	public Map<String, byte[]> getFileDataMap() {
		return fileDataMap;
	}
	public void setFileDataMap(Map<String, byte[]> fileDataMap) {
		this.fileDataMap = fileDataMap;
	}
}
