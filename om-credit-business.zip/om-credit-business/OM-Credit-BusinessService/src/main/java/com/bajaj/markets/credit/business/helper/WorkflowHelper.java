package com.bajaj.markets.credit.business.helper;

import java.util.List;
import java.util.Map;

import org.activiti.engine.ActivitiException;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.persistence.entity.ExecutionEntityImpl;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.NextTask;


/**
 * Helper class to interact with Activiti APIs
 * 
 * @author 764504
 *
 */

@Component
public class WorkflowHelper {

	private static final String OMCB_101 = "OMCB_101";
	private static final String OMCB_102 = "OMCB_102";
	private static final String OMCB_103 = "OMCB_103";
	private static final String OMCB_104 = "OMCB_104";
	private static final String OMCB_105 = "OMCB_105";
	private static final String OMCB_106 = "OMCB_106";
	private static final String OMCB_107 = "OMCB_107";

	@Autowired
	RuntimeService runtimeService;

	@Autowired
	TaskService taskService;

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private Environment env;
	
	private static final String CLASS_NAME = WorkflowHelper.class.getCanonicalName();

	/**
	 * This method will start activiti process with name passed to it
	 *  
	 * @param String processName
	 * @param Map<String, Object> activiti variables 
	 * @return NextTask nextTask
	 */
	public NextTask startActivitiProcess(String processName, Map<String, Object> payload) {
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Started startActivitiProcess() method");
			if (processName == null)
				throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(OMCB_107, env.getProperty(OMCB_107)));
			NextTask nextTask = new NextTask();
			Object productCode = payload.get(CreditBusinessConstants.PRODUCTCODE);
			if (null == productCode || !org.apache.commons.lang3.StringUtils
					.equals(CreditBusinessConstants.PRODUCT_CODE_EMIC, String.valueOf(productCode))) {
				ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(processName, payload);
				nextTask.setProcessID(processInstance.getProcessInstanceId());

				// Checking if child process is completed/have another child inside it
				String pIdToComplete = getActiveProcessId(processInstance.getProcessInstanceId());
				List<Task> tasks = taskService.createTaskQuery().processInstanceId(pIdToComplete).list();
				if (null != tasks && !tasks.isEmpty()) {
					nextTask.setNextTaskKey(tasks.get(0).getTaskDefinitionKey());
				}
			} else if (org.apache.commons.lang3.StringUtils
					.equals(CreditBusinessConstants.PRODUCT_CODE_EMIC, String.valueOf(productCode))) {
				nextTask.setNextTaskKey(CreditBusinessConstants.REDIRECT_TO_EMIC);
			}
			return nextTask;
		} catch(CreditBusinessException businessException) {
			throw businessException;
		} catch (ActivitiException e) {
			Throwable throwable = this.handleActivitiException(e);
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while starting activiti process", throwable);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(OMCB_101, env.getProperty(OMCB_101)));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Technical exception occurred while starting activiti process", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(OMCB_104, env.getProperty(OMCB_104)));
		}
	}

	/**
	 * This method will complete workflow task
	 *  
	 * @param Object activiti variables
	 * @param String processId 
	 * @return String nextTaskKey - null in case the activiti process donesn't have any other task remaining or nextTaskId if it exists 
	 */
	public String completeTask(String processId, Map<String, Object> variables) {
		String nextTaskKey = null;
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Started completeTask() method");
			if (StringUtils.isEmpty(processId))
				throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(OMCB_103, env.getProperty(OMCB_103)));

			List<Task> tasks = getActiveUserTask(processId);
			if (null != tasks && !tasks.isEmpty()) {
				// Completing active task
				taskService.complete(tasks.get(0).getId(), variables);

				// Checking if child process is completed/have another child inside it
				List<Task> nextTasks = getActiveUserTask(processId);
				if (null != nextTasks && !nextTasks.isEmpty()) {
					nextTaskKey = nextTasks.get(0).getTaskDefinitionKey();
				}
			}
			return nextTaskKey;
		} catch(CreditBusinessException businessException) {
			throw businessException;
		} catch (ActivitiException e) {
			Throwable throwable = this.handleActivitiException(e);
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while completing activiti task", throwable);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(OMCB_105, env.getProperty(OMCB_105)));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while completing activiti task", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(OMCB_106, env.getProperty(OMCB_106)));
		}
	}

	private Throwable handleActivitiException(ActivitiException e) {
		Throwable throwable = e.getCause();
		while(null != throwable) {
			if(throwable instanceof CreditBusinessException) {
				throw (CreditBusinessException) throwable;
			}
			throwable = throwable.getCause();
		}
		return e.getCause();
	}

	/**
	 * This method will complete workflow task
	 *  
	 * @param Object activiti variables
	 * @param String parentProcessId 
	 * @return String process Id of Active child process (if no child process is active then returns parentProcessId. )
	 */
	public String getActiveProcessId(String parentProcessId) {
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Started getActiveProcessId() method");
			String pId = null;
			List<Execution> exeList = runtimeService.createExecutionQuery().onlySubProcessExecutions().rootProcessInstanceId(parentProcessId).list();
			if (exeList != null && !exeList.isEmpty()) {
				for (Execution childExe : exeList) {
					pId = childExe.getProcessInstanceId();
				}
			}
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Completed getActiveProcessId() method");
			if (null == pId) {
				return parentProcessId;
			} else {
				return pId;
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while finding active child task", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(OMCB_102, env.getProperty(OMCB_102)));
		}
	}

	public Object getFromExecutionMap(String key, String processId) {
		Map<String, Object> map = runtimeService.getVariables(getActiveProcessId(processId));
		return map.get(key);
	}

	/**
	 * This method will active user task
	 * 
	 * @param String parentProcessId 
	 * @return List<Task>  Active user tasks
	 */
	private List<Task> getActiveUserTask(String parentProcessId) {
		List<Task> nextTaskList = null;
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Started getActiveUserTask() method with parentProcessId "+ parentProcessId);
		List<Execution> exeList = runtimeService.createExecutionQuery().onlySubProcessExecutions().rootProcessInstanceId(parentProcessId).list();
		if (exeList != null && !exeList.isEmpty()) {
			for (Execution childExe : exeList) {
				ExecutionEntityImpl childExeImpl = (ExecutionEntityImpl) childExe;
				logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "ChildExecution for ActivitiId = "+ childExeImpl.getProcessDefinitionKey()+ ", ChildExecution process id  = "+ childExe.getProcessInstanceId());
				nextTaskList = getTasks(childExe.getProcessInstanceId());
				if (!CollectionUtils.isEmpty(nextTaskList)) {
					break;
				}
			}
		} else {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Child Executions not found parent processId "+parentProcessId);
			nextTaskList = getTasks(parentProcessId);
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Completed getActiveUserTask() method");
		return nextTaskList;
	}

	private List<Task> getTasks(String pid) {
		List<Task> nextTasks = taskService.createTaskQuery().processInstanceId(pid).list();
		if (null != nextTasks && !nextTasks.isEmpty()) {
			return nextTasks;
		}
		return null;
	}

	public Map<String, Object> getAllVariablesFromProcessId(String processId) {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Into getFromExecutionMap for processId " + processId);
		return runtimeService.getVariables(getActiveProcessId(processId));
	}

}
