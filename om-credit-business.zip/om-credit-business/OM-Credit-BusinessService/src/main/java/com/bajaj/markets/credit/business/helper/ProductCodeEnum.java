package com.bajaj.markets.credit.business.helper;

/**
 * Enum to map string representation of Product Codes
 * 
 * @author 764504
 *
 */
public enum ProductCodeEnum {

	CREDIT_CARD("CC"), LOANS("OMPL"), SECUREDLOANS("OMSL");

	private final String value;

	private ProductCodeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

}
