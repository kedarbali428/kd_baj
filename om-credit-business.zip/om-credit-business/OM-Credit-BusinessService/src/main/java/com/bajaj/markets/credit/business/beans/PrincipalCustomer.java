package com.bajaj.markets.credit.business.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PrincipalCustomer {

	private Long principleCustKey;
	
	private Long applicationKey;
	
	private Long principalKey;
	
	private String principleCustRefId;
	
	private String principleCustRefSrc;
	
	private Boolean isEtb;
	
	private String principleCustSegment;
	
	private String principleCustType;
	
	private Object additionalDetails;
	
	private Long appattrbkey;

	public Long getPrincipleCustKey() {
		return principleCustKey;
	}

	public void setPrincipleCustKey(Long principleCustKey) {
		this.principleCustKey = principleCustKey;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public String getPrincipleCustRefId() {
		return principleCustRefId;
	}

	public void setPrincipleCustRefId(String principleCustRefId) {
		this.principleCustRefId = principleCustRefId;
	}

	public String getPrincipleCustRefSrc() {
		return principleCustRefSrc;
	}

	public void setPrincipleCustRefSrc(String principleCustRefSrc) {
		this.principleCustRefSrc = principleCustRefSrc;
	}

	public Boolean getIsEtb() {
		return isEtb;
	}

	public void setIsEtb(Boolean isEtb) {
		this.isEtb = isEtb;
	}

	public String getPrincipleCustSegment() {
		return principleCustSegment;
	}

	public void setPrincipleCustSegment(String principleCustSegment) {
		this.principleCustSegment = principleCustSegment;
	}

	public String getPrincipleCustType() {
		return principleCustType;
	}

	public void setPrincipleCustType(String principleCustType) {
		this.principleCustType = principleCustType;
	}

	public Object getAdditionalDetails() {
		return additionalDetails;
	}

	public void setAdditionalDetails(Object additionalDetails) {
		this.additionalDetails = additionalDetails;
	}
	
	public Long getAppattrbkey() {
		return appattrbkey;
	}

	public void setAppattrbkey(Long appattrbkey) {
		this.appattrbkey = appattrbkey;
	}

	@Override
	public String toString() {
		return "PrincipalCustomerInfo [principleCustKey=" + principleCustKey + ", applicationKey="
				+ applicationKey + ", principalKey=" + principalKey
				+ ", principleCustRefId=" + principleCustRefId
				+ ", principleCustRefSrc=" + principleCustRefSrc + ", isEtb=" + isEtb 
				+ ", principleCustSegment=" + principleCustSegment + ", principleCustType=" 
				+ principleCustType + ", additionalDetails=" + additionalDetails + "]";
	}

}