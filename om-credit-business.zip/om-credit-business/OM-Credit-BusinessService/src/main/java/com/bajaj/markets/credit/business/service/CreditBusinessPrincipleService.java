package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.ApplicationParameter;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ProcessCard;
import com.bajaj.markets.credit.business.beans.ProcessStatus;

public interface CreditBusinessPrincipleService {

	public ApplicationResponse processCard(ProcessCard processCard, HttpHeaders headers);
	
	public ApplicationResponse processStatus(ProcessStatus processStatus, HttpHeaders headers);
	
	public ApplicationParameter fetchApprovedDetails(String applicationId, String l3ProductCode);
}
