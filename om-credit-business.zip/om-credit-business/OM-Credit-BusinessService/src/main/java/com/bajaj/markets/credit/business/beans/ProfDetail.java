package com.bajaj.markets.credit.business.beans;

public class ProfDetail {
	
		private String applicationKey;
		
		private String applicationUserAttributeKey;
		
		private String applicationUserAttributeType;
		
		private Name name;

		private Long maritalStatusKey;

		private Long genderKey;

		public String getApplicationKey() {
			return applicationKey;
		}

		public void setApplicationKey(String applicationKey) {
			this.applicationKey = applicationKey;
		}

		public String getApplicationUserAttributeKey() {
			return applicationUserAttributeKey;
		}

		public void setApplicationUserAttributeKey(String applicationUserAttributeKey) {
			this.applicationUserAttributeKey = applicationUserAttributeKey;
		}

		public String getApplicationUserAttributeType() {
			return applicationUserAttributeType;
		}

		public void setApplicationUserAttributeType(String applicationUserAttributeType) {
			this.applicationUserAttributeType = applicationUserAttributeType;
		}

		public Name getName() {
			return name;
		}

		public void setName(Name name) {
			this.name = name;
		}

		public Long getMaritalStatusKey() {
			return maritalStatusKey;
		}

		public void setMaritalStatusKey(Long maritalStatusKey) {
			this.maritalStatusKey = maritalStatusKey;
		}

		public Long getGenderKey() {
			return genderKey;
		}

		public void setGenderKey(Long genderKey) {
			this.genderKey = genderKey;
		}

		@Override
		public String toString() {
			return "ProfDetail [applicationKey=" + applicationKey + ", applicationUserAttributeKey="
					+ applicationUserAttributeKey + ", applicationUserAttributeType=" + applicationUserAttributeType
					+ ", name=" + name + ", maritalStatusKey=" + maritalStatusKey + ", genderKey=" + genderKey + "]";
		}

}
