package com.bajaj.markets.credit.business.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.EmicRequest;
import com.bajaj.markets.credit.business.beans.EmicResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessEmicService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class CreditBusinessEmicServiceImpl implements CreditBusinessEmicService {

	@Autowired
	private CreditBusinessHelper creditBusinessHelper;

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;

	@Value("${api.omcreditapplicationservice.userprofiles.get.url}")
	private String getUserProfiles;

	@Value("${api.omcreditcardsprincipalintegrationservice.leadinfo.put.url}")
	private String encryptRequestUrl;

	private static final String CLASS_NAME = CreditBusinessEmicServiceImpl.class.getCanonicalName();

	@Override
	public EmicResponse encryptEmicRequest(String applicationId,String responseFormat) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "encryptEmicRequest start from : " + applicationId);
		EmicResponse emicResponse = new EmicResponse();
		try {
			ObjectMapper mapper = new ObjectMapper();
			Map<String, String> params = new HashMap<>();
			HttpHeaders headers = new HttpHeaders();
			headers.set(CreditBusinessConstants.AUTH_TOKEN, customDefaultHeaders.getAuthtoken());
			UserProfileBean userProfile = userProfile(applicationId, mapper, params, headers);
			EmicRequest emicRequest = new EmicRequest();
			emicRequest.setMobileNumber(userProfile.getMobile());
			emicRequest.setDateOfBirth(userProfile.getDateOfBirth());
			Name name = userProfile.getName();
			if (null != name) {
			emicRequest.setName(
					creditBusinessHelper.formFullName(name.getFirstName(), name.getMiddleName(), name.getLastName()));
			}
			if (StringUtils.equalsIgnoreCase("encrypted", responseFormat)) {
			Gson gson = new Gson();
				JSONObject jsonRequest = new JSONObject();
				jsonRequest.put("dateOfBirth", emicRequest.getDateOfBirth());
				jsonRequest.put("mobileNumber", emicRequest.getMobileNumber());
				jsonRequest.put("name", emicRequest.getName());
				params.put("principalkey", "20");
				ResponseEntity<?> encryptDataResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT,
						encryptRequestUrl, String.class, params, jsonRequest.toString(), headers);
				emicResponse = gson.fromJson(encryptDataResponse.getBody().toString(), EmicResponse.class);
			} else {
				emicResponse.setDateOfBirth(emicRequest.getDateOfBirth());
				emicResponse.setMobile(emicRequest.getMobileNumber());
				emicResponse.setName(emicRequest.getName());
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"encryptEmicRequest end with : " + emicResponse.toString());
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while encryption : ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("OMBSEMIC-0001", "Encryption Failed."));
		}
		return emicResponse;
	}

	private UserProfileBean userProfile(String applicationId, ObjectMapper mapper, Map<String, String> params,
			HttpHeaders headers) {
		params.put(CreditBusinessConstants.APPLICATION_ID, applicationId);
		ResponseEntity<?> userProfileResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				getUserProfiles, List.class, params, null, headers);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<UserProfileBean> userProfileList = mapper.convertValue(userProfileResponse.getBody(),
				new TypeReference<List<UserProfileBean>>() {
				});
		UserProfileBean userProfile = new UserProfileBean();
		for (UserProfileBean userProfileBean : userProfileList) {
			if (userProfileBean.getApplicationUserAttributeType().equals("1")) {
				userProfile = userProfileBean;
				break;
			}
		}
		return userProfile;
	}

}
