package com.bajaj.markets.credit.business.beans;

public class OfferDetails {
	private Boolean isOfferAvailable;
	private String riskOfferType;
	private String offerType;
	private Integer offerAmount;
	
	//Adding Additional parameter as part of JIRAID Len-535 
	private String offerSource;
	private String offerExpirayDate;
	private String offerAcceptedStatus;
	private String offerID;
	private String riskClassification;
	private String offerProgramCode;
	 
	public void setIsOfferAvailable(Boolean isOfferAvailable) {
		this.isOfferAvailable = isOfferAvailable;
	}
	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public void setOfferAmount(Integer offerAmount) {
		this.offerAmount = offerAmount;
	}
	public void setOfferSource(String offerSource) {
		this.offerSource = offerSource;
	}
	public void setOfferExpirayDate(String offerExpirayDate) {
		this.offerExpirayDate = offerExpirayDate;
	}
	public void setOfferAcceptedStatus(String offerAcceptedStatus) {
		this.offerAcceptedStatus = offerAcceptedStatus;
	}
	public void setOfferID(String offerID) {
		this.offerID = offerID;
	}
	public void setRiskClassification(String riskClassification) {
		this.riskClassification = riskClassification;
	}
	public void setOfferProgramCode(String offerProgramCode) {
		this.offerProgramCode = offerProgramCode;
	}
	
	 

}
