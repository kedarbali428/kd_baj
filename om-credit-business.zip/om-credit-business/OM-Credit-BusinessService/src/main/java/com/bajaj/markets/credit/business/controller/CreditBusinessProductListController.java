package com.bajaj.markets.credit.business.controller;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PRODUCT_CODE_OMPL;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REJECTED_STATUS;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ChildApplication;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.ProductList;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.NotRejected;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Rejected;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessProductListService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Controller to perform operations on Product List resource
 * 
 * @author 764504
 *
 */
@RestController
public class CreditBusinessProductListController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessProductListService service;

	@Autowired
	private Validator validator;

	private static final String CLASSNAME = CreditBusinessProductListController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "API to fetch card's list", notes = "API to fetch card's list", httpMethod = "GET")
	@ApiImplicitParams({ @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully fetched card's list for product listing", response = ProductList.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found for given application", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/credit/applications/{applicationid}/product", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ProductList> productList(@PathVariable("applicationid") String applicationId,
			@RequestParam(name = "amount", required = false) Double loanAmount, @RequestParam(name = "tenure", required = false) Double tenure,
			@RequestParam(name = "isSmallTicket", required = false) Integer isSmallTicket) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start productList :" + applicationId);
		ResponseEntity<ProductList> response = null;
		response = service.getProductList(applicationId, loanAmount, tenure, isSmallTicket);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "End productList");
		return response;
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "Product application created successsfully", notes = "Product application created successsfully", httpMethod = "POST")
	@ApiImplicitParams({ @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Successfully created Product application", response = ApplicationResponse.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(path = "/v1/credit/applications/{applicationid}/product", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationResponse> createProductApplication(@PathVariable("applicationid") String applicationId,
			@Valid @RequestBody ChildApplication request, BindingResult result, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start createProductApplication :" + applicationId + " Request : " + request);
		Class clz = getValidationClass(request);
		Set<ConstraintViolation<ChildApplication>> validationErrors = validator.validate(request, clz);
		if (!CollectionUtils.isEmpty(validationErrors)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside createProductApplication method  - resource validation failed");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_20", validationErrors.stream().findFirst().get().getMessage()));
		} else {
			request.setParentApplicationKey(applicationId);
			ApplicationResponse applicationResponse = service.createProductApplication(request, headers);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "End createProductApplication");
			return new ResponseEntity<>(applicationResponse, HttpStatus.CREATED);
		}
	}

	private Class getValidationClass(ChildApplication req) {
		if (req.getL2ProductCode() == null) {
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_20", "l2ProductCode can not be null or empty"));
		}

		if (PRODUCT_CODE_OMPL.equalsIgnoreCase(req.getL2ProductCode()) && null != req.getAction() && REJECTED_STATUS.equalsIgnoreCase(req.getAction())) {
			return Rejected.class;
		}
		return NotRejected.class;
	}
}
