package com.bajaj.markets.credit.business.beans;

import java.util.List;

import org.json.simple.JSONObject;

public class OpenArcRejectionInput {
	private String applicationId;
	private String product; // from path variable
	private Float subStagePercentage;
	private String occupationType;
	private String rejectionType; // from path variable
	private Float age;
	private String gender;

	private String designation;

	//Adding Additional parameter as part of JIRAID Len-535
	private String city;

	private String panNumber;
	private Boolean additionalCibilFlag;
	//private String constitution;

	private List<PanDetails> panDetails;
	private String resiType;

	//Adding Additional parameter as part of JIRAID Len-535
	private Integer cibilScore;
	private Integer appScoreML;
	private Integer appScoreLR;
	private Integer appScore;
	private String cibilJson;
	private String derogJson;
	private Integer obligationAmount;
	List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails;

	private String educationQualification;
	private Float workExperience;

	//Adding Additional parameter as part of JIRAID Len-535
	private String annualTurnOver;
	private Integer businessVintage;
	private String natureOfBusiness;

	private String companyType;
	private String companyCategory;
	private String industryType;
	private String subIndustryType;
	private List<PrincipleProductDetails> principleProductDetails; // only for mcp2
	private Boolean existingCustomerFlag;
	private Double profitAfterTax;
	private Double averageBankBalance;
	private String employerType;
	private String employerCat;
	private String businessPAN;
	private String officeType;

	//Adding fields for Secured Loan
	private String btBankName;
	private String hlProductIntent;

	//Added for OMDT-1272
	private String officialEmailId;
	private Boolean propertyIdentifiedFlag;
	private Integer yearOfGraduation;
	private Integer yearOfPostGraduation;
	private List<DeactivateOffer> deactivateOfferList;
	private JSONObject pincodeDetail;

	private String registrationNumber;
	private String yrOfAttainingCertificate;

	private String degree;
	private Integer specializationCode;
	private String customerProfileSegment;
	private String microSegment;
	private String journeyStamp;
	
	
	
	public String getCustomerProfileSegment() {
		return customerProfileSegment;
	}

	public void setCustomerProfileSegment(String customerProfileSegment) {
		this.customerProfileSegment = customerProfileSegment;
	}

	public String getMicroSegment() {
		return microSegment;
	}

	public void setMicroSegment(String microSegment) {
		this.microSegment = microSegment;
	}

	public String getJourneyStamp() {
		return journeyStamp;
	}

	public void setJourneyStamp(String journeyStamp) {
		this.journeyStamp = journeyStamp;
	}

	public String getRejectionType() {
		return rejectionType;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public void setSubStagePercentage(Float subStagePercentage) {
		this.subStagePercentage = subStagePercentage;
	}

	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}

	public void setRejectionType(String rejectionType) {
		this.rejectionType = rejectionType;
	}

	public void setAge(Float age) {
		this.age = age;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public void setAdditionalCibilFlag(Boolean additionalCibilFlag) {
		this.additionalCibilFlag = additionalCibilFlag;
	}

	public void setPanDetails(List<PanDetails> panDetails) {
		this.panDetails = panDetails;
	}

	public void setResiType(String resiType) {
		this.resiType = resiType;
	}

	public void setCibilScore(Integer cibilScore) {
		this.cibilScore = cibilScore;
	}

	public void setAppScoreML(Integer appScoreML) {
		this.appScoreML = appScoreML;
	}

	public void setAppScoreLR(Integer appScoreLR) {
		this.appScoreLR = appScoreLR;
	}

	public void setAppScore(Integer appScore) {
		this.appScore = appScore;
	}

	public void setCibilJson(String cibilJson) {
		this.cibilJson = cibilJson;
	}

	public void setDerogJson(String derogJson) {
		this.derogJson = derogJson;
	}

	public void setObligationAmount(Integer obligationAmount) {
		this.obligationAmount = obligationAmount;
	}

	public void setEstimatedNetMonthlySalaryDetails(List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails) {
		this.estimatedNetMonthlySalaryDetails = estimatedNetMonthlySalaryDetails;
	}

	public void setEducationQualification(String educationQualification) {
		this.educationQualification = educationQualification;
	}

	public void setWorkExperience(Float workExperience) {
		this.workExperience = workExperience;
	}

	public void setAnnualTurnOver(String annualTurnOver) {
		this.annualTurnOver = annualTurnOver;
	}

	public void setBusinessVintage(Integer businessVintage) {
		this.businessVintage = businessVintage;
	}

	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public void setCompanyCategory(String companyCategory) {
		this.companyCategory = companyCategory;
	}

	public void setIndustryType(String industryType) {
		this.industryType = industryType;
	}

	public void setSubIndustryType(String subIndustryType) {
		this.subIndustryType = subIndustryType;
	}

	public void setPrincipleProductDetails(List<PrincipleProductDetails> principleProductDetails) {
		this.principleProductDetails = principleProductDetails;
	}

	public void setExistingCustomerFlag(Boolean existingCustomerFlag) {
		this.existingCustomerFlag = existingCustomerFlag;
	}

	public void setProfitAfterTax(Double profitAfterTax) {
		this.profitAfterTax = profitAfterTax;
	}

	public void setAverageBankBalance(Double averageBankBalance) {
		this.averageBankBalance = averageBankBalance;
	}

	public void setEmployerType(String employerType) {
		this.employerType = employerType;
	}

	public void setEmployerCat(String employerCat) {
		this.employerCat = employerCat;
	}

	public void setBusinessPAN(String businessPAN) {
		this.businessPAN = businessPAN;
	}

	public void setOfficeType(String officeType) {
		this.officeType = officeType;
	}

	public void setBtBankName(String btBankName) {
		this.btBankName = btBankName;
	}

	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public void setOfficialEmailId(String officialEmailId) {
		this.officialEmailId = officialEmailId;
	}

	public void setPropertyIdentifiedFlag(Boolean propertyIdentifiedFlag) {
		this.propertyIdentifiedFlag = propertyIdentifiedFlag;
	}

	public void setYearOfGraduation(Integer yearOfGraduation) {
		this.yearOfGraduation = yearOfGraduation;
	}

	public void setYearOfPostGraduation(Integer yearOfPostGraduation) {
		this.yearOfPostGraduation = yearOfPostGraduation;
	}

	public void setDeactivateOfferList(List<DeactivateOffer> deactivateOfferList) {
		this.deactivateOfferList = deactivateOfferList;
	}

	public void setPincodeDetail(JSONObject pincodeDetail) {
		this.pincodeDetail = pincodeDetail;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public void setYrOfAttainingCertificate(String yrOfAttainingCertificate) {
		this.yrOfAttainingCertificate = yrOfAttainingCertificate;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public void setSpecializationCode(Integer specializationCode) {
		this.specializationCode = specializationCode;
	}

	@Override
	public String toString() {
		return "OpenArcRejectionInput [applicationId=" + applicationId + ", product=" + product + ", subStagePercentage=" + subStagePercentage
				+ ", occupationType=" + occupationType + ", rejectionType=" + rejectionType + ", age=" + age + ", gender=" + gender + ", designation="
				+ designation + ", city=" + city + ", panNumber=" + panNumber + ", additionalCibilFlag=" + additionalCibilFlag + ", panDetails=" + panDetails
				+ ", resiType=" + resiType + ", cibilScore=" + cibilScore + ", appScoreML=" + appScoreML + ", appScoreLR=" + appScoreLR + ", appScore="
				+ appScore + ", cibilJson=" + cibilJson + ", derogJson=" + derogJson + ", obligationAmount=" + obligationAmount
				+ ", estimatedNetMonthlySalaryDetails=" + estimatedNetMonthlySalaryDetails + ", educationQualification=" + educationQualification
				+ ", workExperience=" + workExperience + ", annualTurnOver=" + annualTurnOver + ", businessVintage=" + businessVintage + ", natureOfBusiness="
				+ natureOfBusiness + ", companyType=" + companyType + ", companyCategory=" + companyCategory + ", industryType=" + industryType
				+ ", subIndustryType=" + subIndustryType + ", principleProductDetails=" + principleProductDetails + ", existingCustomerFlag="
				+ existingCustomerFlag + ", profitAfterTax=" + profitAfterTax + ", averageBankBalance=" + averageBankBalance + ", employerType=" + employerType
				+ ", employerCat=" + employerCat + ", businessPAN=" + businessPAN + ", officeType=" + officeType + ", btBankName=" + btBankName
				+ ", hlProductIntent=" + hlProductIntent + ", officialEmailId=" + officialEmailId + ", propertyIdentifiedFlag=" + propertyIdentifiedFlag
				+ ", yearOfGraduation=" + yearOfGraduation + ", yearOfPostGraduation=" + yearOfPostGraduation + ", deactivateOfferList=" + deactivateOfferList
				+ ", pincodeDetail=" + pincodeDetail + ", registrationNumber=" + registrationNumber + ", yrOfAttainingCertificate=" + yrOfAttainingCertificate
				+ ", degree=" + degree + ", specializationCode=" + specializationCode + "]";
	}

}