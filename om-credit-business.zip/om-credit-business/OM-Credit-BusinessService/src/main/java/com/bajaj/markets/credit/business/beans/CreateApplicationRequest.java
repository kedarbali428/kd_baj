package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class CreateApplicationRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2791466815044255565L;

	private String applicationKey;
	private String mobile;
	private String dateOfBirth;
	private Integer l2ProductKey;
	private String hlProductIntent;
	private Name name;
	private String appProcessIdentifier;

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Integer getL2ProductKey() {
		return l2ProductKey;
	}

	public void setL2ProductKey(Integer l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}

	public String getHlProductIntent() {
		return hlProductIntent;
	}

	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public String getAppProcessIdentifier() {
		return appProcessIdentifier;
	}

	public void setAppProcessIdentifier(String appProcessIdentifier) {
		this.appProcessIdentifier = appProcessIdentifier;
	}

}
