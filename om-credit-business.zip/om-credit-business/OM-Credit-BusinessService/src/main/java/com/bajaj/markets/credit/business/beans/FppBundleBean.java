package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.json.simple.JSONObject;

import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.FppSelected;

public class FppBundleBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3934410960515479795L;
	private String applicationId;
	private Long l3ProductKey;
	private String l3ProductCode;
	private boolean isGenderRequired;
	private Reference gender;

	@Valid
	@NotNull(groups = FppSelected.class, message = "FPP Product Bundle can not be null")
	private OpenArcFppOutput openArcFppOutput;

	private List<FppQuestionAnswer> questionAnswerList;

	private FppAtributes fppAttributeAtributes;

	private JSONObject pricingMap;

	private List<Nominee> nomineeDetails;

	public OpenArcFppOutput getOpenArcFppOutput() {
		return openArcFppOutput;
	}

	public void setOpenArcFppOutput(OpenArcFppOutput openArcFppOutput) {
		this.openArcFppOutput = openArcFppOutput;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public Long getL3ProductKey() {
		return l3ProductKey;
	}

	public void setL3ProductKey(Long l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public List<FppQuestionAnswer> getQuestionAnswerList() {
		return questionAnswerList;
	}

	public FppAtributes getFppAttributeAtributes() {
		return fppAttributeAtributes;
	}

	public void setQuestionAnswerList(List<FppQuestionAnswer> questionAnswerList) {
		this.questionAnswerList = questionAnswerList;
	}

	public void setFppAttributeAtributes(FppAtributes fppAttributeAtributes) {
		this.fppAttributeAtributes = fppAttributeAtributes;
	}

	public JSONObject getPricingMap() {
		return pricingMap;
	}

	public void setPricingMap(JSONObject pricingMap) {
		this.pricingMap = pricingMap;
	}

	public boolean getIsGenderRequired() {
		return isGenderRequired;
	}

	public void setIsGenderRequired(boolean isGenderRequired) {
		this.isGenderRequired = isGenderRequired;
	}

	public Reference getGender() {
		return gender;
	}

	public void setGender(Reference gender) {
		this.gender = gender;
	}
	
	public List<Nominee> getNomineeDetails() {
		return nomineeDetails;
	}

	public void setNomineeDetails(List<Nominee> nomineeDetails) {
		this.nomineeDetails = nomineeDetails;
	}


	@Override
	public String toString() {
		return "FppBundleBean [applicationId=" + applicationId + ", l3ProductKey=" + l3ProductKey + ", l3ProductCode="
				+ l3ProductCode + ", isGenderRequired=" + isGenderRequired + ", gender=" + gender
				+ ", openArcFppOutput=" + openArcFppOutput + ", questionAnswerList=" + questionAnswerList
				+ ", fppAttributeAtributes=" + fppAttributeAtributes + ", pricingMap=" + pricingMap
				+ ", nomineeDetails=" + nomineeDetails + "]";
	}
}