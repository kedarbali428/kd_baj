package com.bajaj.markets.credit.business.beans.validator;

import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Business;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.CaIcwaSelfEmployed;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.DoctorSalaried;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.DoctorSelfEmployed;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Other;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Salaried;

public enum OccupationValidatorClass {
	
	SALR(Salaried.class),
	SEMP(Business.class),
	DOCSAL(DoctorSalaried.class),
	DOCSEMP(DoctorSelfEmployed.class),
	CAICWA(CaIcwaSelfEmployed.class),
	OTHER(Other.class);
	
	private final Class<?> valiatorClass;
	
	private OccupationValidatorClass(Class<?> validatorClass) {
		this.valiatorClass = validatorClass;
	}
	
	public Class<?> getOccupationValidatorClass() {
		return this.valiatorClass;
	}
	
}
