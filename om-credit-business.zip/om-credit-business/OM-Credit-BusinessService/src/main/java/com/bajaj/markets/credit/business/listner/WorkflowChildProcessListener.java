package com.bajaj.markets.credit.business.listner;

import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Component;

@Component
public class WorkflowChildProcessListener {

	@SuppressWarnings("unchecked")
	public void pre(DelegateExecution execution) {
		Object object = execution.getVariable("var");
		execution.setVariables((Map<String, ? extends Object>) object);
		execution.removeVariable("var");
	}
	
	public void post(DelegateExecution execution) {
		Object object = execution.getVariables();
		execution.setVariable("var", object);
	}

}
