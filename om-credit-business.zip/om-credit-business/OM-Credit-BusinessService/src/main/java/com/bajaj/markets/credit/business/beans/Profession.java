package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Business;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Salaried;



public class Profession implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3075948821086859466L;
	
	@NotNull
	private Reference ocupationType;
	@NotBlank(groups = Salaried.class, message = "SalariedDetail cannot be null or empty")
	private SalariedDetail salariedDetail;
	@NotBlank(groups = Business.class, message = "BusinessOwnerDetails cannot be null or empty")
	private BusinessOwnerDetails businessOwnerDetails;
	
	public Reference getOccupation() {
		return ocupationType;
	}
	public void setOccupation(Reference occupation) {
		this.ocupationType = occupation;
	}
	public SalariedDetail getSalariedDetail() {
		return salariedDetail;
	}
	public void setSalariedDetail(SalariedDetail salariedDetail) {
		this.salariedDetail = salariedDetail;
	}
	public BusinessOwnerDetails getBusinessOwnerDetails() {
		return businessOwnerDetails;
	}
	public void setBusinessOwnerDetails(BusinessOwnerDetails businessOwnerDetails) {
		this.businessOwnerDetails = businessOwnerDetails;
	}
	
	@Override
	public String toString() {
		return "Profession [occupation=" + ocupationType + ", salariedDetail=" + salariedDetail
				+ ", businessOwnerDetails=" + businessOwnerDetails + "]";
	}
	
}
