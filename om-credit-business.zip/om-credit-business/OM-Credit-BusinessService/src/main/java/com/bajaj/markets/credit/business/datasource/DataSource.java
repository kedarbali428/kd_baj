package com.bajaj.markets.credit.business.datasource;

import org.springframework.stereotype.Component;

import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;

@Component
public interface DataSource {	
	
	public void registerDataSource(DataSourceRegistry dataSourceRegistry);
	
	public OfferDetailsBean initDataSource(ApplicantDataBean applicantDataBean);
}