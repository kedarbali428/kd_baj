package com.bajaj.markets.credit.business.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value = Include.NON_NULL)
public class CibilResponseWrapper {

	private Object payload;

	private NextTask nextTask;

	public CibilResponseWrapper() {
		super();
	}

	public CibilResponseWrapper(Object payload, NextTask nextTask) {
		super();
		this.payload = payload;
		this.nextTask = nextTask;
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object cibilResponse) {
		this.payload = cibilResponse;
	}

	public NextTask getNextTask() {
		return nextTask;
	}

	public void setNextTask(NextTask nextTask) {
		this.nextTask = nextTask;
	}

	@Override
	public String toString() {
		return "CibilResponseWrapper [payload=" + payload + ", nextTask=" + nextTask + "]";
	}

}
