package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Salaried;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.DoctorSalaried;

public class SalariedDetail implements Serializable {

	private static final long serialVersionUID = 2703536940790674844L;

	@NotNull(groups = Salaried.class, message = "employerName cannot be null or empty")
	private Reference employerName;

	private String employerNameOther;

	private Reference designation;

	@NotBlank(groups = Salaried.class, message = "experience cannot be null or empty")
	private String experience;

	private String netSalary;

	private Long employerType;
	
	private Long subEmployerType;
	
	private Reference principalIndustry;

	private Integer workExperienceInMonths;
	
	private BigDecimal averageBankBalance;
	
	@NotNull(groups = {DoctorSalaried.class}, message = "qualification cannot be null")
	private Reference qualification;
	
	private Reference specialization;
	
	private String otherSpecialization;
	
	@NotNull(groups = {DoctorSalaried.class}, message = "yearOfGraduation cannot be null")
	private Integer yearOfGraduation;
	
	private Integer yearOfPostGraduation;
	
	private Reference regCouncil;
	
	private String doctorRegistrationNumber;
	
	private Reference hospital;
	
	private String hospitalNameOther;
	
	private Reference empSectorService;

	@NotBlank(groups = {DoctorSalaried.class}, message = "practiceType can not be null")
	private String practiceType;

	public Reference getEmployerName() {
		return employerName;
	}

	public void setEmployerName(Reference employerName) {
		this.employerName = employerName;
	}

	public Reference getDesignation() {
		return designation;
	}

	public void setDesignation(Reference designation) {
		this.designation = designation;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(String netSalary) {
		this.netSalary = netSalary;
	}

	public Long getEmployerType() {
		return employerType;
	}

	public void setEmployerType(Long employerType) {
		this.employerType = employerType;
	}

	public Long getSubEmployerType() {
		return subEmployerType;
	}

	public void setSubEmployerType(Long subEmployerType) {
		this.subEmployerType = subEmployerType;
	}

	public String getEmployerNameOther() {
		return employerNameOther;
	}

	public void setEmployerNameOther(String employerNameOther) {
		this.employerNameOther = employerNameOther;
	}

	public Reference getPrincipalIndustry() {
		return principalIndustry;
	}

	public void setPrincipalIndustry(Reference principalIndustry) {
		this.principalIndustry = principalIndustry;
	}

	public Integer getWorkExperienceInMonths() {
		return workExperienceInMonths;
	}

	public void setWorkExperienceInMonths(Integer workExperienceInMonths) {
		this.workExperienceInMonths = workExperienceInMonths;
	}

	public BigDecimal getAverageBankBalance() {
		return averageBankBalance;
	}

	public void setAverageBankBalance(BigDecimal averageBankBalance) {
		this.averageBankBalance = averageBankBalance;
	}

	public Reference getQualification() {
		return qualification;
	}

	public void setQualification(Reference qualification) {
		this.qualification = qualification;
	}

	public Reference getSpecialization() {
		return specialization;
	}

	public void setSpecialization(Reference specialization) {
		this.specialization = specialization;
	}

	public String getOtherSpecialization() {
		return otherSpecialization;
	}

	public void setOtherSpecialization(String otherSpecialization) {
		this.otherSpecialization = otherSpecialization;
	}

	public Integer getYearOfGraduation() {
		return yearOfGraduation;
	}

	public void setYearOfGraduation(Integer yearOfGraduation) {
		this.yearOfGraduation = yearOfGraduation;
	}

	public Integer getYearOfPostGraduation() {
		return yearOfPostGraduation;
	}

	public void setYearOfPostGraduation(Integer yearOfPostGraduation) {
		this.yearOfPostGraduation = yearOfPostGraduation;
	}

	public Reference getRegCouncil() {
		return regCouncil;
	}

	public void setRegCouncil(Reference regCouncil) {
		this.regCouncil = regCouncil;
	}

	public String getDoctorRegistrationNumber() {
		return doctorRegistrationNumber;
	}

	public void setDoctorRegistrationNumber(String doctorRegistrationNumber) {
		this.doctorRegistrationNumber = doctorRegistrationNumber;
	}

	public Reference getHospital() {
		return hospital;
	}

	public void setHospital(Reference hospital) {
		this.hospital = hospital;
	}

	public String getHospitalNameOther() {
		return hospitalNameOther;
	}

	public void setHospitalNameOther(String hospitalNameOther) {
		this.hospitalNameOther = hospitalNameOther;
	}
	
	public String getPracticeType() {
		return practiceType;
	}

	public void setPracticeType(String practiceType) {
		this.practiceType = practiceType;
	}

	public Reference getEmpSectorService() {
		return empSectorService;
	}

	public void setEmpSectorService(Reference empSectorService) {
		this.empSectorService = empSectorService;
	}

	@Override
	public String toString() {
		return "SalariedDetail [employerName=" + employerName + ", employerNameOther=" + employerNameOther
				+ ", designation=" + designation + ", experience=" + experience + ", netSalary=" + netSalary
				+ ", employerType=" + employerType + ", subEmployerType=" + subEmployerType + ", principalIndustry="
				+ principalIndustry + ", workExperienceInMonths=" + workExperienceInMonths + ", averageBankBalance="
				+ averageBankBalance + ", qualification=" + qualification + ", specialization=" + specialization
				+ ", otherSpecialization=" + otherSpecialization + ", yearOfGraduation=" + yearOfGraduation
				+ ", yearOfPostGraduation=" + yearOfPostGraduation + ", regCouncil=" + regCouncil
				+ ", doctorRegistrationNumber=" + doctorRegistrationNumber + ", hospital=" + hospital
				+ ", hospitalNameOther=" + hospitalNameOther + ", empSectorService=" + empSectorService
				+ ", practiceType=" + practiceType + "]";
	}

	

}
