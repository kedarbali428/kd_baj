package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class AdditionalPageInfo implements Serializable{
	private String coAppName;
	private String coAppDob;
	private String coAppEmail;
	private String coAppPAN;
	private Long coAppGender;
	private Long coAppMaritalStatus;
	private String coAppMobile;
	private String action;
	private String l3code;

	public String getCoAppName() {
		return coAppName;
	}

	public void setCoAppName(String coAppName) {
		this.coAppName = coAppName;
	}

	public String getCoAppDob() {
		return coAppDob;
	}

	public void setCoAppDob(String coAppDob) {
		this.coAppDob = coAppDob;
	}

	public String getCoAppEmail() {
		return coAppEmail;
	}

	public void setCoAppEmail(String coAppEmail) {
		this.coAppEmail = coAppEmail;
	}

	public String getCoAppPAN() {
		return coAppPAN;
	}

	public void setCoAppPAN(String coAppPAN) {
		this.coAppPAN = coAppPAN;
	}

	public Long getCoAppGender() {
		return coAppGender;
	}

	public void setCoAppGender(Long coAppGender) {
		this.coAppGender = coAppGender;
	}

	public Long getCoAppMaritalStatus() {
		return coAppMaritalStatus;
	}

	public void setCoAppMaritalStatus(Long coAppMaritalStatus) {
		this.coAppMaritalStatus = coAppMaritalStatus;
	}

	public String getCoAppMobile() {
		return coAppMobile;
	}

	public void setCoAppMobile(String coAppMobile) {
		this.coAppMobile = coAppMobile;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getL3code() {
		return l3code;
	}

	public void setL3code(String l3code) {
		this.l3code = l3code;
	}

	@Override
	public String toString() {
		return "AdditionalPageInfo [coAppName=" + coAppName + ", coAppDob=" + coAppDob + ", coAppEmail=" + coAppEmail + ", coAppPAN=" + coAppPAN + ", coAppGender=" + coAppGender
				+ ", coAppMaritalStatus=" + coAppMaritalStatus + ", coAppMobile=" + coAppMobile + ", action=" + action + ", l3code=" + l3code + "]";
	}

}
