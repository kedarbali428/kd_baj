package com.bajaj.markets.credit.business.controller;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.Profession;
import com.bajaj.markets.credit.business.beans.ProfileDetailsReqResp;
import com.bajaj.markets.credit.business.beans.validator.OccupationValidatorClass;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Back;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessProfileDetailService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessProfileDetailsController {
	
	@Autowired
	private Validator validator;		
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessProfileDetailService creditBusinessProfileDetailService;
	
	private static final String CLASS_NAME = CreditBusinessProfessionController.class.getCanonicalName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "To get professional details.", notes = "To get professional details for to and fro on application.", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Profile details fetched successfully.", response = ProfileDetailsReqResp.class),
			@ApiResponse(code = 400, message = "Bad request", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@GetMapping(path = "/v2/credit/applications/{applicationId}/profile", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ProfileDetailsReqResp> getProfileDetails(
			@PathVariable(value = "applicationId") String applicationId, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Started getProfileDetails in controller with Request : " + applicationId);
		
		ProfileDetailsReqResp profileDetailsResponse = creditBusinessProfileDetailService
				.getProfileDetails(applicationId);
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"End getProfileDetails in controller with Response : " + profileDetailsResponse);
		return new ResponseEntity<>(profileDetailsResponse, HttpStatus.OK);
	}
	

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "Submit the profile details to the running process", notes = "Submit the profile details to the running process", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Profile details saved successfully", response = ApplicationResponse.class),
			@ApiResponse(code = 200, message = "Profile details fetched successfully.", response = ProfileDetailsReqResp.class),
			@ApiResponse(code = 400, message = "Bad request", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Unprocessable Entity", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@PostMapping(path = "/v2/credit/applications/{applicationId}/profile", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApplicationResponse> saveProfileDetails(
			@PathVariable(value = "applicationId") String applicationId,//digits, fraction , 20max
			@RequestBody ProfileDetailsReqResp profileDetails,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Started saveProfileDetails in controller with Request : " + profileDetails);
		if (null != profileDetails.getProfession() || !StringUtils.isEmpty(profileDetails.getAction())) {

			Set<ConstraintViolation<ProfileDetailsReqResp>> validationErrors = validator.validate(profileDetails,
					!StringUtils.isEmpty(profileDetails.getAction())
							&& profileDetails.getAction().equalsIgnoreCase("back") ? Back.class
									: this.getValidatorClass(profileDetails.getProfession()));

			if (!CollectionUtils.isEmpty(validationErrors)) {
				logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
						"Inside saveProfileDetails method : invalid parameters passed");
				String message = "";
				if (validationErrors.stream().findFirst().isPresent()) {
					message = validationErrors.stream().findFirst().get().getMessage();
				}
				throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_11", message));
			} else {
				ApplicationResponse applicationResponse = creditBusinessProfileDetailService
						.saveProfileDetails(profileDetails, applicationId, headers);

				logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
						"End saveProfileDetails in controller with Response : ");
				return new ResponseEntity<>(applicationResponse, HttpStatus.CREATED);
			}
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Inside saveProfileDetails method : invalid parameters passed");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_11", "profile detail is null or empty"));
		}
	}

	private Class<?> getValidatorClass(Profession profession) {
		if (null != profession && null != profession.getOccupation()
				&& !StringUtils.isEmpty(profession.getOccupation().getCode())) {
			try {
				return OccupationValidatorClass.valueOf(profession.getOccupation().getCode())
						.getOccupationValidatorClass();
			} catch (IllegalArgumentException | NullPointerException exception) {
				logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Occupation Type" + profession);
				throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
						new ErrorBean("OMCB_1001", "Invalid Occupation Type"));
			}
		} else {
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_1002", "Occupation Type can not be null"));
		}
	}
}
