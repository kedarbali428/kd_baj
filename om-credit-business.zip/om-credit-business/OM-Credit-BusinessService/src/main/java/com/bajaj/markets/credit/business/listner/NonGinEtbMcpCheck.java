package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE_FROM_MCP;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AdditionalParameterDetail;
import com.bajaj.markets.credit.business.beans.EstimatedNetMonthlySalaryDetails;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.MCPRequest;
import com.bajaj.markets.credit.business.beans.OpenArcRejectionInput;
import com.bajaj.markets.credit.business.beans.PanDetails;
import com.bajaj.markets.credit.business.beans.PrincipleProductDetails;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.RejectionSystemSourceEnum;
import com.bajaj.markets.referencedataclientlib.bean.OccupationMaster;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.Gson;

@Component
public class NonGinEtbMcpCheck {
	private static final String OCCUPATION_TYPE = "occupationType";
	private static final String OCCUPATION_TYPE_CODE = "occupationTypeCode";
	private static final String PINCODE = "pincode";
	private static final String PINCODE_VALUE = "pincodeValue";
	private static final String IS_ELIGIBLE = "isEligible";
	private static final String OPEN_ARC_REJECTION_OUTPUT = "openArcRejectionOutput";
	private static final String PRINCIPLE_PRODUCT_DETAILS = "principleProductDetails";
	private static final String OCUPATION_TYPE = "ocupationType";
	private static final String REJECTION_SYSTEM = "rejectionSystem";
	private static final String SALARY_SOURCE = "salarySource";
	private static final String SALARY_AMOUNT = "salaryAmount";
	private static final String UPDATE_MCP = "updateMCP";
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	MasterDataRedisClientHelper masterDataRedisHelper;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;

	private static final String CLASS_NAME = NonGinEtbMcpCheck.class.getCanonicalName();

	public void mcpFirst(DelegateExecution execution) throws JsonProcessingException {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start mcpFirst");
		execution.setVariable(REJECTION_SYSTEM, RejectionSystemSourceEnum.REJBRE1.getValue());

		JSONObject mcpRequestFromGet = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		preparePayload(execution, "1", mcpRequestFromGet);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End mcpFirst");
	}

	public void mcpSecond(DelegateExecution execution) throws JsonProcessingException {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start mcpSecond");
		execution.setVariable(REJECTION_SYSTEM, RejectionSystemSourceEnum.REJBRE2.getValue());
		JSONObject mcpRequestFromGet = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		preparePayload(execution, "2", mcpRequestFromGet);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End mcpSecond");
	}

	private void preparePayload(DelegateExecution execution, String rejectionType, JSONObject mcpRequestFromGet)
			throws JsonProcessingException {
		MCPRequest mcpRequest = new MCPRequest();
		OpenArcRejectionInput openArcRejectionInput = new OpenArcRejectionInput();
		String applicationId = execution.getVariable(CreditBusinessConstants.APPLICATION_ID) != null
				? execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString()
				: null;

		openArcRejectionInput.setApplicationId(applicationId);
		openArcRejectionInput.setRejectionType(rejectionType);
		openArcRejectionInput.setProduct(execution.getVariable(CreditBusinessConstants.PRODUCTDESC).toString());
		JSONObject ocupationType = null;
		JSONObject salariedDetail = null;
		JSONObject businessOwnerDetails = null;
		JSONObject occupationFromMcpRequest = CreditBusinessHelper.getJSONObject(mcpRequestFromGet.get("occupation"));
		JSONObject occupation = setOccupationValue(execution, occupationFromMcpRequest);
		if (null != occupation) {
			ocupationType = CreditBusinessHelper.getJSONObject(occupation.get(OCUPATION_TYPE));
			salariedDetail = CreditBusinessHelper.getJSONObject(occupation.get("salariedDetail"));
			businessOwnerDetails = CreditBusinessHelper.getJSONObject(occupation.get("businessOwnerDetails"));
		}
		if (null != salariedDetail) {
			setSalariedData(execution, openArcRejectionInput, salariedDetail);
		}

		if (null != businessOwnerDetails) {
			setBusinessOwnerData(execution, openArcRejectionInput, businessOwnerDetails);
		}

		openArcRejectionInput
				.setOccupationType(null != ocupationType && null != ocupationType.get(CreditBusinessConstants.VALUE)
						? ocupationType.get(CreditBusinessConstants.VALUE).toString()
						: null);
		if (null != mcpRequestFromGet) {
			openArcRejectionInput.setSubStagePercentage(mcpRequestFromGet.get("subStagePercentage") != null
					? Float.valueOf(mcpRequestFromGet.get("subStagePercentage").toString())
					: null);
			setAdditionalParameters(mcpRequestFromGet, mcpRequest);
			setUserProfileData(execution, mcpRequestFromGet, openArcRejectionInput);
			setPrincipleProductDetailsData(execution, rejectionType, mcpRequestFromGet, openArcRejectionInput);
			List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails = setSalaryDetails(
					mcpRequestFromGet);
			openArcRejectionInput.setEstimatedNetMonthlySalaryDetails(estimatedNetMonthlySalaryDetails);
			setCity(mcpRequestFromGet, openArcRejectionInput);
			if (null != mcpRequestFromGet.get("officialEmailId")) {
				openArcRejectionInput.setOfficialEmailId(mcpRequestFromGet.get("officialEmailId").toString());
			} else {
				openArcRejectionInput.setOfficialEmailId(null);
			}
		}

		List<PanDetails> panDetailsList = getNsdlPanResponse(execution);
		openArcRejectionInput.setPanDetails(panDetailsList);
		execution.setVariable("mcp", rejectionType);

		mcpRequest.setOpenArcRejectionInput(openArcRejectionInput);
		JSONObject mcpRequestjson = CreditBusinessHelper.getJSONObject(mcpRequest);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, mcpRequestjson);
	}

	private void setCity(JSONObject mcpRequestFromGet, OpenArcRejectionInput openArcRejectionInput) {
		if (mcpRequestFromGet.get("addressList") != null) {
			Gson gson = new Gson();
			String addressJson = gson.toJson(mcpRequestFromGet.get("addressList"));
			JSONArray addressDetails = gson.fromJson(addressJson, JSONArray.class);
			if (!CollectionUtils.isEmpty(addressDetails)) {
				for (int i = 0; i < addressDetails.size(); i++) {
					JSONObject address = CreditBusinessHelper.getJSONObject(addressDetails.get(i));
					if ("50".equals(address.get("addressTypeKey").toString()) && null!=address.get("pincodeKey")) {
						LocationResponseBean pinCodeMaster = apiCallsHelper
								.getPinCodeMaster(address.get("pincodeKey").toString());
						openArcRejectionInput.setCity(pinCodeMaster.getCityName());
					}
				}
			}
		}
	}

	private List<EstimatedNetMonthlySalaryDetails> setSalaryDetails(JSONObject mcpRequestFromGet) {
		List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails = null;
		if (mcpRequestFromGet.get("estimatedNetMonthlySalaryDetails") != null) {
			List<Map<String, Object>> salaryDetails = (List<Map<String, Object>>) mcpRequestFromGet
					.get("estimatedNetMonthlySalaryDetails");
			if (!salaryDetails.isEmpty()) {
				estimatedNetMonthlySalaryDetails = new ArrayList<>();
				for (Map<String, Object> salary : salaryDetails) {
					EstimatedNetMonthlySalaryDetails details = new EstimatedNetMonthlySalaryDetails();
					details.setSalarySource(
							salary.get(SALARY_SOURCE) != null ? salary.get(SALARY_SOURCE).toString() : null);
					details.setSalaryAmount(
							salary.get(SALARY_AMOUNT) != null ? new BigDecimal(salary.get(SALARY_AMOUNT).toString())
									: null);
					estimatedNetMonthlySalaryDetails.add(details);
				}
			}
		}
		return estimatedNetMonthlySalaryDetails;
	}

	private void setPrincipleProductDetailsData(DelegateExecution execution, String rejectionType,
			JSONObject mcpRequestFromGet, OpenArcRejectionInput openArcRejectionInput) {
		if (null != mcpRequestFromGet.get("mcpAddressDetails")) {
			Gson g = new Gson();
			String json = g.toJson(mcpRequestFromGet.get("mcpAddressDetails"));
			JSONArray mcpAddressDetails = g.fromJson(json, JSONArray.class);
			if (null != mcpAddressDetails && !mcpAddressDetails.isEmpty()) {
				JSONObject mcpAddressDtl = CreditBusinessHelper.getJSONObject(mcpAddressDetails.get(0));
				if (null != mcpAddressDtl) {
					String principleProductDetailsJson = g.toJson(mcpAddressDtl.get(PRINCIPLE_PRODUCT_DETAILS));
					JSONArray principleProductDetails = g.fromJson(principleProductDetailsJson, JSONArray.class);
					if ("1".equals(rejectionType)) {
						JSONArray principleProductDetailsUpdated = addPincodeInMCPRequest(execution,
								principleProductDetails);
						principleProductDetails = principleProductDetailsUpdated;
					}
					openArcRejectionInput.setPrincipleProductDetails(
							(java.util.List<PrincipleProductDetails>) principleProductDetails);
				}
			}
		}
	}

	private void setAdditionalParameters(JSONObject mcpRequestFromGet, MCPRequest mcpRequest) {
		JSONObject additionalParameterDetail = CreditBusinessHelper
				.getJSONObject(mcpRequestFromGet.get("additionalParameterDetail"));
		if (null != additionalParameterDetail) {
			AdditionalParameterDetail parameterDetail = new AdditionalParameterDetail();
			parameterDetail.setUtmCampaign(additionalParameterDetail.get("utmCampaign") != null
					? additionalParameterDetail.get("utmCampaign").toString()
					: null);
			parameterDetail.setUtmChannel(additionalParameterDetail.get("utmChannel") != null
					? additionalParameterDetail.get("utmChannel").toString()
					: null);
			parameterDetail.setUtmContent(additionalParameterDetail.get("utmContent") != null
					? additionalParameterDetail.get("utmContent").toString()
					: null);
			parameterDetail.setUtmMedium(additionalParameterDetail.get("utmMedium") != null
					? additionalParameterDetail.get("utmMedium").toString()
					: null);
			parameterDetail.setUtmSource(additionalParameterDetail.get("utmSource") != null
					? additionalParameterDetail.get("utmSource").toString()
					: null);
			parameterDetail.setUtmTerm(additionalParameterDetail.get("utmTerm") != null
					? additionalParameterDetail.get("utmTerm").toString()
					: null);
			mcpRequest.setAdditionalParameterDetail(parameterDetail);
		}
	}

	public List<PanDetails> getNsdlPanResponse(DelegateExecution execution) {
		List<PanDetails> panDetailsList = null;
		if (execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE) != null) {
			JSONObject nsdlPanResponse = CreditBusinessHelper
					.getJSONObject(execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE));
			panDetailsList = new ArrayList<>();
			PanDetails panDetails = new PanDetails();
			panDetails.setNameMatch(
					nsdlPanResponse.get("nameMatch") != null ? nsdlPanResponse.get("nameMatch").toString() : null);
			panDetails.setMatchScore(null);
			panDetails.setPanType(null);
			panDetails.setPanStatus(
					nsdlPanResponse.get("panStatus") != null ? nsdlPanResponse.get("panStatus").toString() : null);
			panDetailsList.add(panDetails);
		}
		return panDetailsList;
	}

	@SuppressWarnings("unchecked")
	private void setUserProfileData(DelegateExecution execution, JSONObject mcpRequestFromGet,
			OpenArcRejectionInput openArcRejectionInput) throws JsonProcessingException {
		JSONObject userProfile = CreditBusinessHelper
				.getJSONObject(mcpRequestFromGet.get(CreditBusinessConstants.USERPROFILE));
		if (userProfile != null) {
			if (userProfile.get("residenceTypeKey") != null) {
				Double resiTypeKey = Double.valueOf(userProfile.get("residenceTypeKey").toString());
				ResidenceMaster resiType = masterDataRedisHelper.findResitypeByKey(resiTypeKey.longValue());
				openArcRejectionInput.setResiType(resiType.getResidenceValue());
			}
			openArcRejectionInput
					.setAge(null != userProfile.get(CreditBusinessConstants.DATE_OF_BIRTH)
							? (float) CreditBusinessHelper
									.calculateAge(userProfile.get(CreditBusinessConstants.DATE_OF_BIRTH).toString())
							: null);
			openArcRejectionInput.setPanNumber(null != userProfile.get(CreditBusinessConstants.PAN_NUMBER)
					? userProfile.get(CreditBusinessConstants.PAN_NUMBER).toString()
					: null);

			if (userProfile.get("qualification") != null) {
				String qualificationValue = userProfile.get("qualification").toString();
				ArrayList<Map<String, Object>> qualificationList = (ArrayList<Map<String, Object>>) execution
						.getVariable(CreditBusinessConstants.QUALIFICATION_LOOKUP_LIST);
				if (qualificationList != null && !CollectionUtils.isEmpty(qualificationList)) {
					Optional<Map<String, Object>> qualificationOptional = qualificationList.stream().filter(
							q -> qualificationValue.equalsIgnoreCase(q.get(CreditBusinessConstants.VALUE).toString()))
							.findFirst();
					if (!qualificationOptional.isEmpty()) {
						openArcRejectionInput.setEducationQualification(
								qualificationOptional.get().get(CreditBusinessConstants.CODE) != null
										? qualificationOptional.get().get(CreditBusinessConstants.CODE).toString()
										: null);
					}
				}
			}
			if (userProfile.get("genderKey") != null) {
				Double generKey = Double.valueOf(userProfile.get("genderKey").toString());
				String gender = masterDataRedisHelper.getGenderByTypeKey(generKey.longValue());
				openArcRejectionInput.setGender(gender);
			}
		}

	}

	private void setSalariedData(DelegateExecution execution, OpenArcRejectionInput openArcRejectionInput,
			JSONObject salariedDetail) {
		JSONObject designation = CreditBusinessHelper.getJSONObject(salariedDetail.get("designation"));
		openArcRejectionInput
				.setDesignation(null != designation && null != designation.get(CreditBusinessConstants.VALUE)
						? designation.get(CreditBusinessConstants.VALUE).toString()
						: null);
		String exp = null != salariedDetail.get("experience") ? salariedDetail.get("experience").toString() : null;
		openArcRejectionInput
				.setWorkExperience(exp != null && !"null".equalsIgnoreCase(exp) ? Float.valueOf(exp) : null);
		openArcRejectionInput.setEmployerType(execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY) != null
				? execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY).toString()
				: null);
		openArcRejectionInput
				.setCompanyCategory(execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY) != null
						? execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY).toString()
						: null);
	}

	@SuppressWarnings("unchecked")
	private void setBusinessOwnerData(DelegateExecution execution, OpenArcRejectionInput openArcRejectionInput,
			JSONObject businessOwnerDetails) {
		openArcRejectionInput.setBusinessPAN(
				businessOwnerDetails.get("businessPan") != null ? businessOwnerDetails.get("businessPan").toString()
						: null);
		openArcRejectionInput.setOfficeType(
				businessOwnerDetails.get("officeType") != null ? businessOwnerDetails.get("officeType").toString()
						: null);
		openArcRejectionInput.setProfitAfterTax(businessOwnerDetails.get("profitAfterTax") != null
				? Double.valueOf(businessOwnerDetails.get("profitAfterTax").toString())
				: null);
		openArcRejectionInput.setAverageBankBalance(businessOwnerDetails.get("averageBankBalance") != null
				? Double.valueOf(businessOwnerDetails.get("averageBankBalance").toString())
				: null);
		JSONObject anualTurnover = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("anualTurnover"));
		if (null != anualTurnover && null != anualTurnover.get(CreditBusinessConstants.VALUE)) {
			String annualTurnOverValue = anualTurnover.get(CreditBusinessConstants.VALUE).toString();
			ArrayList<Map<String, Object>> annualTurnoverList = (ArrayList<Map<String, Object>>) execution
					.getVariable(CreditBusinessConstants.ANNUALTURNOVER_LOOKUP_LIST);
			if (annualTurnOverValue != null && !CollectionUtils.isEmpty(annualTurnoverList)) {
				Optional<Map<String, Object>> annulturnOverOptional = annualTurnoverList.stream()
						.filter(turnover -> annualTurnOverValue
								.equalsIgnoreCase(turnover.get(CreditBusinessConstants.VALUE).toString()))
						.findFirst();
				if (!annulturnOverOptional.isEmpty()) {
					openArcRejectionInput
							.setAnnualTurnOver(annulturnOverOptional.get().get(CreditBusinessConstants.CODE) != null
									? annulturnOverOptional.get().get(CreditBusinessConstants.CODE).toString()
									: null);
				}
			}
		}

		if (businessOwnerDetails.get("businessVintage") != null) {
			openArcRejectionInput
					.setBusinessVintage(Integer.valueOf(businessOwnerDetails.get("businessVintage").toString()));
		}

		JSONObject natureOfBusiness = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("natureOfBusiness"));
		openArcRejectionInput.setNatureOfBusiness(
				null != natureOfBusiness && null != natureOfBusiness.get(CreditBusinessConstants.KEY)
						? natureOfBusiness.get(CreditBusinessConstants.KEY).toString()
						: null);

		openArcRejectionInput.setCompanyType(
				null != businessOwnerDetails.get("businessType") ? businessOwnerDetails.get("businessType").toString()
						: null);

		JSONObject industryType = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("industryType"));
		if (null != industryType && null != industryType.get(CreditBusinessConstants.KEY)) {
			Long industryTypeKey = Double.valueOf(industryType.get(CreditBusinessConstants.KEY).toString()).longValue();
			String industryTypeValue = apiCallsHelper.getIndustryType(industryTypeKey);
			openArcRejectionInput.setIndustryType(industryTypeValue);
		}
		openArcRejectionInput.setSubIndustryType(null);// Need to ask
	}

	public void mcpSecondPost(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start mcpSecondPost");
		JSONObject mcpOutput = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		boolean cibilRequired = false;
		boolean karzaRequired = false;
		execution.setVariable(CreditBusinessConstants.CIBIL_REQUIRED, cibilRequired);
		execution.setVariable(CreditBusinessConstants.CV_REQUIRED, Boolean.FALSE);
		if (mcpOutput != null && mcpOutput.get(OPEN_ARC_REJECTION_OUTPUT) != null) {
			JSONObject rejectionOutput = CreditBusinessHelper.getJSONObject(mcpOutput.get(OPEN_ARC_REJECTION_OUTPUT));
			if (rejectionOutput.get("cibilRequired") != null && (Boolean) rejectionOutput.get("cibilRequired")) {
				cibilRequired = true;
				execution.setVariable(CreditBusinessConstants.CIBIL_REQUIRED, cibilRequired);
			}
			if (null != rejectionOutput.get(CIBIL_TYPE_FROM_MCP)) {
				execution.setVariable(CIBIL_TYPE, rejectionOutput.get(CIBIL_TYPE_FROM_MCP).toString());
				logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, rejectionOutput.get(CIBIL_TYPE_FROM_MCP).toString());
			}
			if (null != rejectionOutput.get(CreditBusinessConstants.CV_REQUIRED)
					&& (Boolean) rejectionOutput.get(CreditBusinessConstants.CV_REQUIRED)) {
				execution.setVariable(CreditBusinessConstants.CV_REQUIRED, Boolean.TRUE);
			}
			if (null != rejectionOutput.get(CreditBusinessConstants.KARZA_REQUIRED) && (Boolean) rejectionOutput.get(CreditBusinessConstants.KARZA_REQUIRED)) {
				karzaRequired = true;
			}		
		}
		execution.setVariable(CreditBusinessConstants.KARZA_REQUIRED, karzaRequired);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "karzaRequired flag from MCP2 is " + karzaRequired);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"CibilRequired flag from MCP2 is " + cibilRequired);
		this.post(execution);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End mcpSecondPost");
	}

	@SuppressWarnings("unchecked")
	public void post(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start MCP post");
		execution.setVariable(UPDATE_MCP,
				CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT)));
		Boolean eligiblePrincipleFound = false;
		execution.setVariable(CreditBusinessConstants.CALL_LENDINGKART_DEDUPE, false);
		if (execution.getVariable(CreditBusinessConstants.OUTPUT) != null) {
			JSONObject mcpOutput = CreditBusinessHelper
					.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
			if (mcpOutput != null && mcpOutput.get(OPEN_ARC_REJECTION_OUTPUT) != null) {
				JSONObject rejectionOutput = CreditBusinessHelper
						.getJSONObject(mcpOutput.get(OPEN_ARC_REJECTION_OUTPUT));
				if (rejectionOutput != null && rejectionOutput.get(PRINCIPLE_PRODUCT_DETAILS) != null) {
					List<Map<String, Object>> principleProdDetailList = (List<Map<String, Object>>) rejectionOutput
							.get(PRINCIPLE_PRODUCT_DETAILS);
					if (!CollectionUtils.isEmpty(principleProdDetailList)) {
						for (Map<String, Object> product : principleProdDetailList) {
							if ((boolean) product.get(IS_ELIGIBLE) && !eligiblePrincipleFound.booleanValue()) {
								eligiblePrincipleFound = (boolean) product.get(IS_ELIGIBLE);
							}

							if ("LKBOL".equalsIgnoreCase(product.get("principleProductCode").toString())) {
								if ((boolean) product.get(IS_ELIGIBLE)) {
									execution.setVariable(CreditBusinessConstants.CALL_LENDINGKART_DEDUPE, true);
								}
							}
						}
					}
				}
			}
		}
		execution.setVariable(CreditBusinessConstants.IS_REJECTED, !eligiblePrincipleFound);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start MCP post");
	}

	@SuppressWarnings("unchecked")
	public void updateMcp(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start updateMcp");
		JSONObject updateMCP = CreditBusinessHelper.getJSONObject(execution.getVariable(UPDATE_MCP));
		updateMCP.put(REJECTION_SYSTEM, execution.getVariable(REJECTION_SYSTEM));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, updateMCP);
		execution.setVariable(REJECTION_SYSTEM, null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start updateMcp");
	}

	public void prepareMcpRequest(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preMcpRequest");
		execution.setVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT,
				CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT)));
		JSONObject mcp = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		JSONObject prodCategory = CreditBusinessHelper.getJSONObject(mcp.get("prodCategory"));
		execution.setVariable(CreditBusinessConstants.PRODUCTDESC, prodCategory.get("prodCatDesc"));
		execution.setVariable(CreditBusinessConstants.PRODUCTCODE, prodCategory.get("prodCatCode"));
		execution.setVariable(CreditBusinessConstants.CV_REQUIRED,
				null != mcp.get(CreditBusinessConstants.CV_REQUIRED)
						? (Boolean) mcp.get(CreditBusinessConstants.CV_REQUIRED)
						: Boolean.FALSE);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preMcpRequest");
	}

	@SuppressWarnings("unchecked")
	public JSONObject setOccupationValue(DelegateExecution execution, JSONObject occupationFromMcpRequest) {
		if (!execution.hasVariable(OCCUPATION_TYPE)) {
			execution.setVariable(OCCUPATION_TYPE, null);
		}
		if (!execution.hasVariable(OCCUPATION_TYPE_CODE)) {
			execution.setVariable(OCCUPATION_TYPE_CODE, null);
		}

		if (occupationFromMcpRequest != null && occupationFromMcpRequest.get(OCUPATION_TYPE) != null) {
			Map<String, Object> occupationType = (Map<String, Object>) occupationFromMcpRequest.get(OCUPATION_TYPE);
				if (occupationType.get("key") != null) {
					Double occupationKey = Double.valueOf(occupationType.get("key").toString());
					OccupationMaster occupationMaster =  masterDataRedisHelper.getOccupationByKey(occupationKey.longValue());
					if (occupationMaster != null) {
						occupationType.put(CreditBusinessConstants.VALUE, occupationMaster.getOccupationValue());
						execution.setVariable(OCCUPATION_TYPE, occupationMaster.getOccupationValue());
						execution.setVariable(OCCUPATION_TYPE_CODE, occupationMaster.getOccupationCode());
						occupationFromMcpRequest.put(OCUPATION_TYPE, occupationType);
					}
				}
		}
		return occupationFromMcpRequest;
	}

	public void preGetPincodeForMcp(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preGetPincodeForMcp");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject residencePincode = CreditBusinessHelper.getJSONObject(request.get("residencePincode"));
		execution.setVariable(CreditBusinessConstants.PINCODEKEY,
				null != residencePincode && null != residencePincode.get(PINCODE)
						? residencePincode.get(PINCODE).toString()
						: null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preGetPincodeForMcp");
	}

	public void postGetPincodeForMcp(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetPincodeForMcp");
		execution.setVariable(PINCODE_VALUE, null);
		JSONObject pincodeDetails = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (null != pincodeDetails) {
			String pincodeValue = null != pincodeDetails.get(PINCODE) ? pincodeDetails.get(PINCODE).toString() : null;
			execution.setVariable(PINCODE_VALUE, pincodeValue);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetPincodeForMcp");
	}

	@SuppressWarnings("unchecked")
	private JSONArray addPincodeInMCPRequest(DelegateExecution execution, JSONArray principleProductDetails) {
		JSONArray principleProductDetailsUpdated = new JSONArray();
		String pincodeValue = null != execution.getVariable(PINCODE_VALUE)
				? execution.getVariable(PINCODE_VALUE).toString()
				: null;
		for (int i = 0; i < principleProductDetails.size(); i++) {
			JSONObject principleProductDetailJsonObject = CreditBusinessHelper
					.getJSONObject(principleProductDetails.get(i));
			JSONObject pincodeJsonObject = CreditBusinessHelper
					.getJSONObject(principleProductDetailJsonObject.get(PINCODE));
			pincodeJsonObject.put(PINCODE, pincodeValue);
			principleProductDetailJsonObject.put(PINCODE, pincodeJsonObject);
			principleProductDetailsUpdated.add(principleProductDetailJsonObject);
		}
		return principleProductDetailsUpdated;
	}

	public void setMcpBreReRun(DelegateExecution execution) {
		execution.setVariable("mcpBreReRan", true);
	}
	
}
