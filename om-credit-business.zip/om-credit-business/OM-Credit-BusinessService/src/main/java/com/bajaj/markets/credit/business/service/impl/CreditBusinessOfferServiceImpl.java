package com.bajaj.markets.credit.business.service.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.utils.DateUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.AddressDetails;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.BFDLProspectDetails;
import com.bajaj.markets.credit.business.beans.BusinessOwnerDetails;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Gender;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.LookupCodeResponse;
import com.bajaj.markets.credit.business.beans.LookupCodeValuesResponseBean;
import com.bajaj.markets.credit.business.beans.MaritalStatus;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.NatureOfBusinessMaster;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OfferApiRequest;
import com.bajaj.markets.credit.business.beans.OfferDetail;
import com.bajaj.markets.credit.business.beans.PersonalDetails;
import com.bajaj.markets.credit.business.beans.ProspectDetails;
import com.bajaj.markets.credit.business.beans.ProspectOfferDetails;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResponseBean;
import com.bajaj.markets.credit.business.beans.SalariedDetail;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.OMProductToBauProduct;
import com.bajaj.markets.credit.business.helper.OfferType;
import com.bajaj.markets.credit.business.helper.RiskOfferTypeToL3Prod;
import com.bajaj.markets.credit.business.service.CreditBusinessOfferService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Service
public class CreditBusinessOfferServiceImpl implements CreditBusinessOfferService {

	@Value("${api.offers.offerDetailsForPlatform.POST.url}")
	private String offersUrl;

	@Value("${api.omcreditapplicationservice.updateemail.put.url}")
	private String updateEmailUrl;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String updateOccupationUrl;

	@Value("${api.omcreditapplicationservice.updateaddress.put.url}")
	private String updateAddressUrl;

	@Value("${api.omcreditapplicationservice.updateuserprofiles.put.url}")
	private String updateUserProfilesUrl;

	@Value("${api.omcreditapplicationservice.offer.put.url}")
	private String updateOfferUrl;

	@Value("${api.omreferencedatareferencedataservice.getmaritalstatus.get.url}")
	private String getmaritalStatusURL;

	@Value("${api.omreferencedatareferencedataservice.getgender.get.url}")
	private String getgenderURL;

	@Value("${api.omreferencedatareferencedataservice.location.pincode.get.url}")
	private String pinCodeUrl;

	@Value("${api.omreferencedatareferencedataservice.lookup.code.get.url}")
	private String lookUpCodeUrl;

	@Value("${api.omcreditapplicationservice.salary.put.url}")
	private String updateSalaryUrl;

	@Value("${api.omreferencedatareferencedataservice.natureofbusiness.get.url}")
	private String natureOfBusinessUrl;
	
	@Value("${api.emicnsb.creditcardoffer.GET.url}")
	private String creditCardOfferUrl;
	
	@Value("${api.referencedata.offersource.GET.url}")
	private String getOfferSourceUrl;
	
	@Value("${api.omcreditapplicationservice.updatedocumentdetails.put.url}")
	private String updateDocumentUrl;
	
	@Value("${RBL_OFFER_PRODUCTS}")
	private String rblOfferProducts;

	@Autowired
	private CreditBusinessHelper creditBusinessHelper;

	@Autowired
	private BFLLoggerUtilExt logger;

	private ObjectMapper mapper = new ObjectMapper();

	private static final String CLASS_NAME = CreditBusinessOfferServiceImpl.class.getCanonicalName();
	private static final String OFFER_API = "OFFERAPI";

	@Override
	public ProspectDetails getProspectOffer(OfferApiRequest offerApiRequest, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "GetProspect Offer Start : " + offerApiRequest.toString());
		Gson gson = new Gson();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			ProspectDetails prospectDetails = null;
			offerApiRequest.setDob(dateToddmmmyy(offerApiRequest.getDob()));
			offerApiRequest.setProductCode(OMProductToBauProduct.getBauProd(offerApiRequest.getProductCode()));
			String reqJson = gson.toJson(offerApiRequest);
			ResponseEntity<Object> offerApiResponse = (ResponseEntity<Object>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.POST, offersUrl, Object.class, null, reqJson, new HttpHeaders());
			if (null != offerApiResponse && null != offerApiResponse.getBody()) {
				ResponseBean responseBean = mapper.convertValue(offerApiResponse.getBody(), ResponseBean.class);
				ProspectOfferDetails prospectOfferDetails = mapper.convertValue(responseBean.getPayload(),
						ProspectOfferDetails.class);
				if (null != prospectOfferDetails
						&& !CollectionUtils.isEmpty(prospectOfferDetails.getProspectDetails())) {
					prospectDetails = prospectOfferDetails.getProspectDetails().get(0);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Response from offer API :  " + prospectDetails.toString());
					Map<String, String> param = new HashMap<>();
					param.put("applicationid", offerApiRequest.getApplicationKey());
					param.put("userattributekey", offerApiRequest.getApplicationUserAttributeKey());
					updateApplicationAttribute(prospectDetails.getPersonalDetails(), param, headers);
					updateDocumentDetails(prospectDetails.getPersonalDetails(), param, headers);
					updateEmail(prospectDetails.getPersonalDetails(), param, headers);
					updateOffersAndOccupationAndAddress(prospectDetails, offerApiRequest, param, headers);
				}

			}
			return prospectDetails;
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Failed to update offer" + e);
		}
		return null;

	}

	private void updateApplicationAttribute(PersonalDetails personalDetails, Map<String, String> param,
			HttpHeaders headers) {

		if (null != personalDetails) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Update Application Attribute for Offer Start : " + personalDetails.toString());
			try {

				UserProfileBean userProfile = new UserProfileBean();
				Name name = new Name();
				name.setFirstName(personalDetails.getFirstName());
				name.setMiddleName(personalDetails.getMiddleName());
				name.setLastName(personalDetails.getLastName());
				userProfile.setName(name);
				String productCheck = param.get("productcode");
				if(null!=productCheck) {
					userProfile.setDateOfBirth(personalDetails.getDob());
				} else {
					userProfile.setDateOfBirth(dateToYYYYMMDD(personalDetails.getDob()));
				}
				userProfile.setPanNumber(personalDetails.getPan());
				userProfile.setMobile(personalDetails.getMobileNo());
				if (!StringUtils.isEmpty(personalDetails.getMaritalStatus())) {
				ResponseEntity<List<MaritalStatus>> getmaritalStatusResponse = (ResponseEntity<List<MaritalStatus>>) creditBusinessHelper
						.invokeRestEndpoint(HttpMethod.GET, getmaritalStatusURL, List.class, null, null, headers);
					List<MaritalStatus> maritalStatusList;
					maritalStatusList = mapper.convertValue(getmaritalStatusResponse.getBody(),
							new TypeReference<List<MaritalStatus>>() {
							});
					for (MaritalStatus marStatus : maritalStatusList) {
						if ((marStatus.getMaritalStatusValue()).equalsIgnoreCase(personalDetails.getMaritalStatus())) {
							userProfile.setMaritalStatusKey(marStatus.getMaritalStatusKey());
							break;
						}
					}
				}

				// For Gender key code value
				if (!StringUtils.isEmpty(personalDetails.getGender())) {
					ResponseEntity<List<Gender>> getgenderResponse = (ResponseEntity<List<Gender>>) creditBusinessHelper
							.invokeRestEndpoint(HttpMethod.GET, getgenderURL, List.class, null, null, headers);
					List<Gender> genderList;
					genderList = mapper.convertValue(getgenderResponse.getBody(), new TypeReference<List<Gender>>() {
					});

					for (Gender gender : genderList) {
						if (gender.getGenderValue().equalsIgnoreCase(personalDetails.getGender())) {
							userProfile.setGenderKey(gender.getGenderKey());
							break;
						}
					}
				}
				String userProfileReq = mapper.writeValueAsString(userProfile);
				creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateUserProfilesUrl, Object.class, param,
						userProfileReq, headers);

				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Application Attribute for Offer End. ");
			} catch (Exception e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Offer User Profile failed." + e);
			}

		}
	}

	private void updateEmail(PersonalDetails personalDetails, Map<String, String> param, HttpHeaders headers) {
		try {
			if (null != personalDetails) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Update email for Offer Start : " + personalDetails.toString());
				if (!StringUtils.isEmpty(personalDetails.getPersonalEmailId())) {
					JSONObject updateEmailRequest = new JSONObject();
					updateEmailRequest.put("email", personalDetails.getPersonalEmailId());
					updateEmailRequest.put("typeKey", "70");
					creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateEmailUrl, Object.class, param,
							updateEmailRequest.toString(), headers);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Updated personal email for Offer Start : " + personalDetails.toString());
				}
				if (!StringUtils.isEmpty(personalDetails.getOfficeEmailID())) {
					JSONObject updateEmailRequest = new JSONObject();
					updateEmailRequest.put("email", personalDetails.getOfficeEmailID());
					updateEmailRequest.put("typeKey", "67");
					creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateEmailUrl, Object.class, param,
							updateEmailRequest.toString(), headers);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Update office email for Offer Start : " + personalDetails.toString());

				}
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Email for Offer End.");
			}

		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Offer Email Failed" + e);
		}

	}

	private void updateOffersAndOccupationAndAddress(ProspectDetails prospectDetails, OfferApiRequest offerApiRequest,
			Map<String, String> param,
			HttpHeaders headers) {
		// update Offer starts.
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Offer details for Offer Start");
			if (!CollectionUtils.isEmpty(prospectDetails.getOfferDetails())) {
				for (OfferDetail offer : prospectDetails.getOfferDetails()) {
					AppOfferDetBean appOfferDetBean = new AppOfferDetBean();
					appOfferDetBean.setIsOfferAvailable(true);
					appOfferDetBean.setOfferAmt(offer.getOfferAmount());
					appOfferDetBean.setOfferAppliedDt(StringUtils.isEmpty(offer.getOfferCreatedDate()) ? null
							: DateUtils.parseDate(offer.getOfferCreatedDate()));
					appOfferDetBean
							.setOfferType(!StringUtils.isEmpty(offer.getOfferType())
									? OfferType.getOfferType(offer.getOfferType())
									: 2);
					appOfferDetBean.setRiskOfferType(offer.getRiskOffertype());
					appOfferDetBean.setIsBaseRate(offer.getOfferBaseRate());
					appOfferDetBean.setGenerationRule(offer.getGenerationRule());
					appOfferDetBean.setOfferExpiryDt(StringUtils.isEmpty(offer.getExpiryDate()) ? null
							: DateUtils.parseDate(offer.getExpiryDate()));
					appOfferDetBean.setIsBaseRate(offer.getLnISBaseRate());
					appOfferDetBean.setTlBaseRate(offer.getLnTLBaseRate());
					appOfferDetBean.setOfferId(offer.getOfferId());
					appOfferDetBean.setOfferRoi(offer.getOfferROI());
					appOfferDetBean.setOfferSrcKey(1l);
					appOfferDetBean.setApplicationKey(Long.valueOf(offerApiRequest.getApplicationKey()));
					appOfferDetBean
							.setOfferTenure(null != offer.getOfferTenure() ? offer.getOfferTenure().intValue() : null);
					if (!StringUtils.isEmpty(offer.getRiskOffertype())) {
						appOfferDetBean
								.setProductCode(RiskOfferTypeToL3Prod.getL3ProductCode(offer.getRiskOffertype()));
					}
					appOfferDetBean.setRiskOfferType(offer.getRiskOffertype());
					appOfferDetBean.setRiskSegment(offer.getRiskSegment());
					if (null != prospectDetails.getPersonalDetails()) {
						appOfferDetBean
								.setProspectId(String.valueOf(prospectDetails.getPersonalDetails().getProspectKey()));
					}
					param.put("principalkey", "3");
					String offerReqJson = mapper.writeValueAsString(appOfferDetBean);
					creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateOfferUrl, Object.class, param,
							offerReqJson, headers);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update offer details end.");
					if (null != offer.getNetMonthlySalary()) {
						try {
							logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Salary  for Offer Start");
							JSONObject updateSalaryRequest = new JSONObject();
							updateSalaryRequest.put("salary", offer.getNetMonthlySalary());
							updateSalaryRequest.put("salarySource", OFFER_API);
							creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateSalaryUrl, Object.class,
									param, updateSalaryRequest.toString(), headers);
							logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
									"Update Salary for offer details end.");
						} catch (Exception e) {
							logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Offer salary failed" + e);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Offer Failed" + e);
		}

		// Update occupation starts
		if (null != prospectDetails.getPersonalDetails()) {
			PersonalDetails personalDetails = prospectDetails.getPersonalDetails();
			try {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Occupation for offer details start.");
				Occupation occupation = new Occupation();
				if (StringUtils.equals(offerApiRequest.getProductCode(), "DBOL")) {
					BusinessOwnerDetails businessOwnerDetails = new BusinessOwnerDetails();
					if (!StringUtils.isEmpty(personalDetails.getAnnualTurnover())) {
						param.put("lkpcode", "ANNUALTURNOVER");
						ResponseEntity<?> getlLookUpCodeRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
								lookUpCodeUrl, Object.class, param, null, new HttpHeaders());
						LookupCodeResponse lookUpCode = mapper.convertValue(getlLookUpCodeRes.getBody(),
								LookupCodeResponse.class);
						List<LookupCodeValuesResponseBean> annualTurnOverList = lookUpCode.getLookupValuesResponseList()
								.stream().filter(o -> o.getValue().contains(personalDetails.getAnnualTurnover()))
								.collect(Collectors.toList());
						if (!CollectionUtils.isEmpty(annualTurnOverList)) {
							businessOwnerDetails
									.setAnualTurnover(getReference(annualTurnOverList.get(0).getKey().longValue(),
											annualTurnOverList.get(0).getCode(), annualTurnOverList.get(0).getValue()));
						}
					}
					if (!StringUtils.isEmpty(personalDetails.getBusinessVintage())) {
						businessOwnerDetails.setBusinessVintage(personalDetails.getBusinessVintage());
					
				}
					businessOwnerDetails.setBusinessPan(personalDetails.getBusinessEntityPAN());
					businessOwnerDetails.setBusinessName(personalDetails.getBusinessName());
					// For nature of business key code value
					if (!StringUtils.isEmpty(personalDetails.getNatureOfBusiness())) {
					ResponseEntity<List<NatureOfBusinessMaster>> getgenderResponse = (ResponseEntity<List<NatureOfBusinessMaster>>) creditBusinessHelper
							.invokeRestEndpoint(HttpMethod.GET, natureOfBusinessUrl, List.class, null, null, headers);
					List<NatureOfBusinessMaster> natureOfBusinessList;
					natureOfBusinessList = mapper.convertValue(getgenderResponse.getBody(),
							new TypeReference<List<NatureOfBusinessMaster>>() {
							});
					if (!CollectionUtils.isEmpty(natureOfBusinessList)) {
						List<NatureOfBusinessMaster> nobList = natureOfBusinessList.stream().filter(
								nob -> nob.getNatureOfBusinessValue().equals(personalDetails.getNatureOfBusiness()))
								.collect(Collectors.toList());
						businessOwnerDetails.setNatureOfBusiness(getReference(nobList.get(0).getNatureOfBusinessKey(),
								nobList.get(0).getNatureOfBusinessCode(), nobList.get(0).getNatureOfBusinessValue()));
					}
					}
					occupation.setOcupationType(getReference(2l, "SEMP", "Self Employed"));
					occupation.setBusinessOwnerDetails(businessOwnerDetails);
				} else {
					SalariedDetail salariedDetail = new SalariedDetail();
					salariedDetail.setDesignation(getReference(null, null, personalDetails.getDesignation()));
					occupation.setSalariedDetail(salariedDetail);
					occupation.setOcupationType(getReference(1l, "SALR", "Salaried"));
				}
				String updateOccupationReq = mapper.writeValueAsString(occupation);
				creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateOccupationUrl, Object.class, param,
						updateOccupationReq, headers);
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Occupation for offer details end.");
			} catch (Exception e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Offer occupation Failed" + e);
			}

			// Start save address details.
			try {
				if (!CollectionUtils.isEmpty(prospectDetails.getAddressDetails())) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Address for offer details Start.");
					for (AddressDetails addressDetail : prospectDetails.getAddressDetails()) {
						Address address = new Address();
						address.setAddressLine1(addressDetail.getAddressLine1());
						address.setAddressLine2(addressDetail.getAddressLine2());
						address.setAddressTypeKey("50");
						address.setResiType(personalDetails.getResidenceType());
						address.setPincode(addressDetail.getPinCode());
						address.setAddressSource(OFFER_API);
						if (!StringUtils.isEmpty(addressDetail.getPinCode())) {
							param.put("pincode", addressDetail.getPinCode());
							ResponseEntity<LocationAddressBean> locationAddressResp = (ResponseEntity<LocationAddressBean>) creditBusinessHelper
									.invokeRestEndpoint(HttpMethod.GET, pinCodeUrl, LocationAddressBean.class, param,
											null, headers);
							if (null != locationAddressResp.getBody()) {
								LocationAddressBean locationAddressBean = locationAddressResp.getBody();
								address.setCityKey(String.valueOf(locationAddressBean.getCityId()));
								address.setPincodeKey(String.valueOf(locationAddressBean.getPinId()));
								address.setCountryKey(String.valueOf(locationAddressBean.getCountryId()));
								address.setStateKey(String.valueOf(locationAddressBean.getStateId()));
								String updateAddressReq = mapper.writeValueAsString(address);
								creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateAddressUrl, Object.class,
										param, updateAddressReq, headers);
							}
						}
						logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Address for offer details end.");
					}
				}
			} catch (Exception e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Offer address update failed.");
			}
		}
	}

	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;
	}

	public String dateToddmmmyy(String inputDate) {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");
		Date date = null;
		try {
			date = format1.parse(inputDate);
		} catch (ParseException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "date parsing fails");
		}
		return format2.format(date);
	}

	public String dateToYYYYMMDD(String inputDate) {
		SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MMM-yy");
		Date date = null;
		try {
			date = format1.parse(inputDate);
		} catch (ParseException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "date parsing fails to yyyymmdd");
		}
		return format2.format(date);
	}

	@Override
	public BFDLProspectDetails getCardsProspectOffer(OfferApiRequest offerApiRequest, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Get CardsProspect offer start with: "+offerApiRequest);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		
		try {
			BFDLProspectDetails prospectDetails = null;
			Map<String, String> params = new HashMap<String, String>();
			params.put("mobilenumber", offerApiRequest.getMobileNo());
			params.put("productcode", "CC");
			params.put("apputmSource", "");
			params.put("consent", "false");
			params.put("applicationid", offerApiRequest.getApplicationKey());
			params.put("userattributekey", offerApiRequest.getApplicationUserAttributeKey());
			
			ResponseEntity<Object> offerApiResponse = (ResponseEntity<Object>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, creditCardOfferUrl, Object.class, params, null, headers);
			
			if(null!=offerApiResponse && 200==(offerApiResponse.getStatusCode().value()) && null!=offerApiResponse.getBody()) {
				ResponseBean responseBean = mapper.convertValue(offerApiResponse.getBody(), ResponseBean.class);
				prospectDetails = mapper.convertValue(responseBean.getPayload(), BFDLProspectDetails.class);
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, 
						"Response from Offer API: "+prospectDetails);
				if(null!=prospectDetails && !StringUtils.isEmpty(prospectDetails.getCardLimit())) {
					PersonalDetails personalDetails = getPersonalDetailsForCards(prospectDetails, offerApiRequest.getDob());
					updateCardsOffer(offerApiRequest, prospectDetails, params, headers);
					updateApplicationAttribute(personalDetails, params, headers);
					updateDocumentDetails(personalDetails, params, headers);
					updateEmail(personalDetails, params, headers);
					updateAddressDetailsForCards(prospectDetails, params, headers);
					updateOccupationDetailsForCards(prospectDetails, params, headers);
				}
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Get Cards Prospect offer end with: "+prospectDetails);
			return prospectDetails;
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Failed to update card offer" + e);
		}
		return null;
	}
	
	private void updateCardsOffer(OfferApiRequest offerApiRequest, BFDLProspectDetails prospectDetails, Map<String, String> params, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update offer details for cards start.");
		try {
			List<String> rblProducts = new ArrayList<>();
			rblProducts = Arrays.asList(rblOfferProducts.split(","));
			
			params.put("srccode", "INTOFFTBL");
			params.put("srckey", "");
			ResponseEntity<Object> offerSourceResponse = (ResponseEntity<Object>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, getOfferSourceUrl, List.class, params, null, headers);
			
			List<Object> offerSource = mapper.convertValue(offerSourceResponse.getBody(), new TypeReference<List<Object>>() {});
			
			String offerSour = offerSource.get(0).toString();
			org.activiti.engine.impl.util.json.JSONObject json = new org.activiti.engine.impl.util.json.JSONObject(offerSour);
			String offersrckey = json.get("offersrckey").toString();
			
			for (String l3prodCode : rblProducts) {
				AppOfferDetBean appOfferDetBean = new AppOfferDetBean();
				appOfferDetBean.setApplicationKey(Long.valueOf(offerApiRequest.getApplicationKey()));
				appOfferDetBean.setProductCode(l3prodCode);
				appOfferDetBean.setIsOfferAvailable(true);
				appOfferDetBean.setOfferAmt(new BigDecimal(prospectDetails.getCardLimit()));
				appOfferDetBean.setOfferSrcKey(Long.valueOf(offersrckey));
				appOfferDetBean.setIsCardHolder(prospectDetails.getIsCreditCardHolder());
				
				String offerReqJson = mapper.writeValueAsString(appOfferDetBean);
				
				creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateOfferUrl, Object.class, 
						params, offerReqJson, headers);
			}
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Card Offer Failed" + e);
		}
	}
	
	private PersonalDetails getPersonalDetailsForCards(BFDLProspectDetails prospectDetails, String dob) {
		PersonalDetails personalDetails = new PersonalDetails();
		
		personalDetails.setFirstName(prospectDetails.getName());
		personalDetails.setMiddleName(prospectDetails.getMiddleName());
		personalDetails.setLastName(prospectDetails.getLastName());
		personalDetails.setDob(dob);
		personalDetails.setPan(prospectDetails.getPan());
		personalDetails.setMobileNo(prospectDetails.getMobileNumber());
		personalDetails.setMaritalStatus(prospectDetails.getMaritalStatus());
		personalDetails.setGender(prospectDetails.getGender());
		personalDetails.setPersonalEmailId(prospectDetails.getEmail());
		
		return personalDetails;
	}
	
	private void updateAddressDetailsForCards(BFDLProspectDetails prospectDetails, Map<String, String> params, HttpHeaders headers) {
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Address for cards offer details Start.");
			List<AddressDetails> addressDetailsList = new ArrayList<>();
			
			AddressDetails currentAddress = new AddressDetails();
			currentAddress.setAddressType("50");
			currentAddress.setAddressLine1(prospectDetails.getCurrentAddressLine1());
			currentAddress.setAddressLine2(prospectDetails.getCurrentAddressLine2()+" "+prospectDetails.getCurrentAddressLine3());
			currentAddress.setPinCode(prospectDetails.getZipcode());
			currentAddress.setCity(prospectDetails.getCurrentCity());
			currentAddress.setState(prospectDetails.getCurrentState());
			
			AddressDetails permanentAddress = new AddressDetails();
			permanentAddress.setAddressType("48");
			permanentAddress.setAddressLine1(prospectDetails.getPermanentAddressLine1());
			permanentAddress.setAddressLine2(prospectDetails.getPermanentAddressLine2()+" "+prospectDetails.getPermanentAddressLine3());
			permanentAddress.setPinCode(prospectDetails.getPermanentZipcode());
			permanentAddress.setCity(prospectDetails.getPermanentCity());
			permanentAddress.setState(prospectDetails.getPermanentState());
			
			AddressDetails officeAddress = new AddressDetails();
			officeAddress.setAddressType("46");
			officeAddress.setAddressLine1(prospectDetails.getOfficeAddressLine1());
			officeAddress.setAddressLine2(prospectDetails.getOfficeAddressLine2()+" "+prospectDetails.getOfficeAddressLine3());
			officeAddress.setPinCode(prospectDetails.getOfficePincode());
			officeAddress.setCity(prospectDetails.getOfficeCity());
			officeAddress.setState(prospectDetails.getOfficeState());
			
			addressDetailsList.add(currentAddress);
			addressDetailsList.add(permanentAddress);
			addressDetailsList.add(officeAddress);
		
			for(AddressDetails addressDetail : addressDetailsList) {
				Address address = new Address();
				address.setAddressTypeKey(addressDetail.getAddressType());
				address.setAddressLine1(addressDetail.getAddressLine1());
				address.setAddressLine2(addressDetail.getAddressLine2());
				address.setPincode(addressDetail.getPinCode());
				address.setAddressSource(OFFER_API);
				if (!StringUtils.isEmpty(addressDetail.getPinCode())) {
					params.put("pincode", addressDetail.getPinCode());
					ResponseEntity<LocationAddressBean> locationAddressResp = (ResponseEntity<LocationAddressBean>) creditBusinessHelper
							.invokeRestEndpoint(HttpMethod.GET, pinCodeUrl, LocationAddressBean.class, params, null, headers);
					if (null != locationAddressResp.getBody()) {
						LocationAddressBean locationAddressBean = locationAddressResp.getBody();
						address.setCityKey(String.valueOf(locationAddressBean.getCityId()));
						address.setPincodeKey(String.valueOf(locationAddressBean.getPinId()));
						address.setCountryKey(String.valueOf(locationAddressBean.getCountryId()));
						address.setStateKey(String.valueOf(locationAddressBean.getStateId()));
						String updateAddressReq = mapper.writeValueAsString(address);
						creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateAddressUrl, Object.class,
								params, updateAddressReq, headers);
					}
				}
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Address for cards offer details end.");
			}
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Card Offer address update failed.");
		}
	}
	
	private void updateOccupationDetailsForCards(BFDLProspectDetails prospectDetails, Map<String, String> params, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Occupation for cards offer details start.");
		Occupation occupation = new Occupation();
		try {
			String employment = prospectDetails.getEmploymentType();
			
			if(!StringUtils.isEmpty(employment) && employment.equalsIgnoreCase("Self-Employed Professional")) {
				BusinessOwnerDetails businessOwnerDetails = new BusinessOwnerDetails();
				businessOwnerDetails.setBusinessName(prospectDetails.getNameOfCompanyBusiness());
				occupation.setBusinessOwnerDetails(businessOwnerDetails);
				occupation.setOcupationType(getReference(2l, "SEMP", "Self Employed"));
			} else if(!StringUtils.isEmpty(employment) && employment.equalsIgnoreCase("Salaried")) {
				SalariedDetail salariedDetail = new SalariedDetail();
				salariedDetail.setEmployerNameOther(prospectDetails.getNameOfCompanyBusiness());
				occupation.setSalariedDetail(salariedDetail);
				occupation.setOcupationType(getReference(1l, "SALR", "Salaried"));
			}
			String updateOccupationReq = mapper.writeValueAsString(occupation);
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateOccupationUrl, Object.class, params,
					updateOccupationReq, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Occupation for cards offer details end.");
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Cards Offer occupation Failed" + e);
		}
	}
	
	private void updateDocumentDetails(PersonalDetails personalDetails, Map<String, String> param,
			HttpHeaders headers) {
		if(null!=personalDetails) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, 
					"Update Document detail for Offer start.");
			try {
				if(!StringUtils.isEmpty(personalDetails.getPan())) {
					DocumentDetails documentDetail = new DocumentDetails();
					documentDetail.setDocumentNameKey(1L);
					documentDetail.setDocumentNumber(personalDetails.getPan());
					
					String updateDocumentReq = mapper.writeValueAsString(documentDetail);
					creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateDocumentUrl, Object.class, param, 
							updateDocumentReq, headers);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, 
							"Update Document detail for Offer end successfully.");
				} else {
					throw new CreditBusinessException(HttpStatus.NOT_FOUND, null);
				}
			} catch (Exception e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Update Document detail failed: "+e);
			}
		}
	}
	
	
}
