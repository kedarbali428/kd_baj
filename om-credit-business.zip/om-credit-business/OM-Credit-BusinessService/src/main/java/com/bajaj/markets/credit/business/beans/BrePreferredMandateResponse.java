package com.bajaj.markets.credit.business.beans;

public class BrePreferredMandateResponse {

	private Boolean bankDetailsEditableFlag;
	private Boolean mandateRequiredFlag;
	private Boolean accountNumberEditFlag;
	private MandateDetailsBRE mandateDetails;

	public void setBankDetailsEditableFlag(Boolean bankDetailsEditableFlag) {
		this.bankDetailsEditableFlag = bankDetailsEditableFlag;
	}

	public void setMandateRequiredFlag(Boolean mandateRequiredFlag) {
		this.mandateRequiredFlag = mandateRequiredFlag;
	}

	public void setAccountNumberEditFlag(Boolean accountNumberEditFlag) {
		this.accountNumberEditFlag = accountNumberEditFlag;
	}

	public MandateDetailsBRE getMandateDetails() {
		return mandateDetails;
	}

	public void setMandateDetails(MandateDetailsBRE mandateDetails) {
		this.mandateDetails = mandateDetails;
	}

}
