package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class ResidenceMaster implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long residenceKey;
	
	private String residenceCode;
	
	private String residenceValue;
	
	private Integer isactive;

	public Long getResidenceKey() {
		return residenceKey;
	}

	public void setResidenceKey(Long residenceKey) {
		this.residenceKey = residenceKey;
	}

	public String getResidenceCode() {
		return residenceCode;
	}

	public void setResidenceCode(String residenceCode) {
		this.residenceCode = residenceCode;
	}

	public String getResidenceValue() {
		return residenceValue;
	}

	public void setResidenceValue(String residenceValue) {
		this.residenceValue = residenceValue;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

	@Override
	public String toString() {
		return "ResidenceMaster [residenceKey=" + residenceKey + ", residenceCode=" + residenceCode
				+ ", residenceValue=" + residenceValue + ", isactive=" + isactive + "]";
	}

}
