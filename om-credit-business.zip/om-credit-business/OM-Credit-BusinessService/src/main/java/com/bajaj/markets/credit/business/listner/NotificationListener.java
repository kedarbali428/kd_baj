package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATIONKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2_PRODUCT_CODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.FIRST_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.LAST_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MIDDLE_NAME;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.bean.EventSchema;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.CurrencyConversionHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.bajaj.markets.referencedataclientlib.bean.LookupCodeValuesResponseBean;

@Component
public class NotificationListener {
	
	private static final String SEND_LISTING_NOTIFICATION_ATTRB = "sendListingNotification";
	private static final String CREDIT_NOTIFICATION_EVENT = "creditNotificationEvent";
	private static final String SEND_LISTING_NOTIFICATION = "SEND_LISTING_NOTIFICATION";
	private static final String CREDIT_NOTIFICATION = "CREDIT_NOTIFICATION";
	private static final String LOANAGAINSTPROPERTYBALTRANSFER = "LAPBT";
	private static final String HOMELOANBALANCETRANSFER = "HLBT";
	private static final String LOANAGAINSTPROPERTY = "LAP";
	private static final String HOMELOANFRESH = "HLF";
	
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Value("${bfsd.web.customer.portal.url}")
	private String custPortalLinkUrl;
	
	@Autowired
	MasterDataRedisClientHelper masterDataRedisClientHelper;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;
	
	@Autowired
	private PublisherService publisherService;
	
	@Value("${aws.publisher.application.topic.arn}")
	private String applicationTopicArn;
	
	private static final String CLASS_NAME = NotificationListener.class.getCanonicalName();
	
	public void preFetchPersonalEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preFetchPersonalEmail");
		execution.setVariable(CreditBusinessConstants.TYPE_KEY, EmailTypeEnum.PERON1.getValue().toString());
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preFetchPersonalEmail");
	}
	
	public void postFetchPersonalEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postFetchPersonalEmail");
		JSONObject getEmailResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.EMAIL, null != getEmailResponse.get(CreditBusinessConstants.EMAIL) ? getEmailResponse.get(CreditBusinessConstants.EMAIL).toString() : null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postFetchPersonalEmail");
	}
	
	@SuppressWarnings("unchecked")
	public void prePartnerInProgress(DelegateExecution execution,String notificationTypeCode,String principalName) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start prePartnerInProgress");
		Map<String, Object> notificationJson = new HashMap<String, Object>();
		notificationJson.put(CreditBusinessConstants.NOTIFICATION_TYPE_CODE, notificationTypeCode);
		Map<String, Object> templatedata = new HashMap<String, Object>();
		templatedata.put(CreditBusinessConstants.PHONE_NUMBER, null != execution.getVariable(CreditBusinessConstants.MOBILE) ? execution.getVariable(CreditBusinessConstants.MOBILE).toString() : null);
		templatedata.put(CreditBusinessConstants.RECIPIENT_EMAIL, null != execution.getVariable(CreditBusinessConstants.EMAIL) ? execution.getVariable(CreditBusinessConstants.EMAIL).toString() : null);
		LookupCodeValuesResponseBean lookupCodeValuesResponseBean = masterDataRedisClientHelper.getLookupValueByLookupCodeAndSortTxt("HLPRODUCTINTENT", execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT).toString());
		if (null != lookupCodeValuesResponseBean) {
			templatedata.put("productName", lookupCodeValuesResponseBean.getValue());
		}
		templatedata.put("parentapplicationid", execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		templatedata.put("principalName", principalName);
		templatedata.put(CreditBusinessConstants.NAME, null != execution.getVariable(CreditBusinessConstants.NAME) ? execution.getVariable(CreditBusinessConstants.NAME).toString() : null);
		templatedata.put("applink", env.getProperty("mobile.app.url"));
		notificationJson.put(CreditBusinessConstants.TEMPLATE_DATA_MAP, templatedata);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, notificationJson);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end prePartnerInProgress");
	}
	
	@SuppressWarnings("unchecked")
	public void productSummaryNotification(DelegateExecution execution,String notificationTypeCode) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start productSummaryNotification");
		JSONObject pricing = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.PAYLOAD));
		Map<String, Object> notificationJson = new HashMap<String, Object>();
		notificationJson.put(CreditBusinessConstants.NOTIFICATION_TYPE_CODE, notificationTypeCode);
		Map<String, Object> templatedata = new HashMap<String, Object>();
		templatedata.put(CreditBusinessConstants.PHONE_NUMBER, null != execution.getVariable(CreditBusinessConstants.MOBILE) ? execution.getVariable(CreditBusinessConstants.MOBILE).toString() : null);
		templatedata.put(CreditBusinessConstants.RECIPIENT_EMAIL, null != execution.getVariable(CreditBusinessConstants.EMAIL) ? execution.getVariable(CreditBusinessConstants.EMAIL).toString() : null);
		templatedata.put(CreditBusinessConstants.NAME, null != execution.getVariable(CreditBusinessConstants.NAME) ? execution.getVariable(CreditBusinessConstants.NAME).toString() : null);
		LookupCodeValuesResponseBean lookupCodeValuesResponseBean = masterDataRedisClientHelper.getLookupValueByLookupCodeAndSortTxt("HLPRODUCTINTENT", execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT).toString());
		if (null != lookupCodeValuesResponseBean) {
			templatedata.put("productName", lookupCodeValuesResponseBean.getValue());
		}
		templatedata = setnotificationRequest(templatedata,pricing);
		String link = null;
		switch (execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT).toString()) {
		case HOMELOANFRESH:
			link = env.getProperty("hlf.journey.url");
			break;
		case HOMELOANBALANCETRANSFER:
			link = env.getProperty("hlbt.journey.url");
			break;
		case LOANAGAINSTPROPERTY:
			link = env.getProperty("lap.journey.url");
			break;
		case LOANAGAINSTPROPERTYBALTRANSFER:
			link = env.getProperty("lapbt.journey.url");
			break;
		}
		templatedata.put("applink", link);
		templatedata.put("applicationKey", execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		notificationJson.put(CreditBusinessConstants.TEMPLATE_DATA_MAP, templatedata);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, notificationJson);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end productSummaryNotification");
	}
	
	private Map<String, Object> setnotificationRequest(Map<String, Object> templateDataMap, JSONObject pricing) {
		templateDataMap.put("loanType", pricing.get("l3ProductDesc"));
		templateDataMap.put("loanAmount",CurrencyConversionHelper.numberToCurrencyConversion(pricing.get("finalLoanAmount")));
		templateDataMap.put("netDisbursement", CurrencyConversionHelper.numberToCurrencyConversion(pricing.get("netDisbursementAmount")));
		templateDataMap.put("roi", pricing.get("finalRoi"));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside sendPricingNotification , droplineTenure: " + pricing.get("droplineTenure"));
		Long tenure = null != pricing.get("droplineTenure") ? ((Double)pricing.get("droplineTenure")).longValue() : null;
		templateDataMap.put("tenor", tenure);
		templateDataMap.put("emi",CurrencyConversionHelper.numberToCurrencyConversion(pricing.get("emiAmount")));
		templateDataMap.put("emiCycleDate", (String.format("%.0f", pricing.get("dueDay"))));
		String formattedDate =creditBusinessHelper.dateFormatter(pricing.get("firstDueDate").toString(), "yyyy-MM-dd", "dd-MMM-yyyy");
		templateDataMap.put("firstEmiDate", null!= formattedDate ? formattedDate.toUpperCase() : null);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> feesList = (List<Map<String, Object>>) pricing.get("fees");
		Double totalFee = 0d;
		for (Map<String, Object> f : feesList) {
			if(f.get("feeCode").toString().equals("PROCFEE")) {
				templateDataMap.put("processingFee",CurrencyConversionHelper.numberToCurrencyConversion(f.get("feesInAmount")));
			}
			else if(f.get("feeCode").toString().equals("CONV")) {
				templateDataMap.put("convenienceFee", CurrencyConversionHelper.numberToCurrencyConversion(f.get("feesInAmount")));
			}
			else if(f.get("feeCode").toString().equals("STAMPFEE")) {
				templateDataMap.put("stampFee", CurrencyConversionHelper.numberToCurrencyConversion(f.get("feesInAmount")));
			}
			totalFee = Double.sum(totalFee, BigDecimal.valueOf((Double) (f.get("feesInAmount"))).doubleValue());
		}
		templateDataMap.put("totalFeeAndCharges", CurrencyConversionHelper.numberToCurrencyConversion(totalFee));
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "exit sendPricingNotification");
		return templateDataMap;

	}
	
	@SuppressWarnings("unchecked")
	public void publishListingNotificationEvent(DelegateExecution execution) {
		JSONObject eventPayload = new JSONObject();
		eventPayload.put(L2_PRODUCT_CODE, execution.getVariable(L2_PRODUCT_CODE));
		eventPayload.put(APPLICATIONKEY, execution.getVariable(APPLICATION_ID));
		
		EventMessage eventMessage = new EventMessage();
		Map<String, String> eventHeaders = new HashMap<>();
		eventHeaders.put(CustomDefaultHeaders.AUTH_TOKEN, customDefaultHeaders.getAuthtoken());
		eventHeaders.put(CustomDefaultHeaders.CMPTCORR_ID, customDefaultHeaders.getCmptcorrid());
		
		Map<String, String> messageFilterAttributes = new HashMap<>();
		messageFilterAttributes.put(CREDIT_NOTIFICATION_EVENT, SEND_LISTING_NOTIFICATION_ATTRB);
		
		eventMessage.setHeaders(eventHeaders);
		eventMessage.setEventName(CREDIT_NOTIFICATION);
		eventMessage.setEventType(SEND_LISTING_NOTIFICATION);
		eventMessage.setEventSchema(new EventSchema());
		eventMessage.setPayload(eventPayload);
		eventMessage.setMessageFilterAttributes(messageFilterAttributes);
		try {
			publisherService.publish(applicationTopicArn, eventMessage);
		} catch(Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Exception occurred while publishing listing notification event for: " + eventMessage, exception);
		}
	}
	
	public void preUnsecuredPartnerInprogress(DelegateExecution execution, String notificationTypeCode, String principalName) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preUnSecuredPartnerInProgress notification for: "+principalName);
		Map<String, Object> notificationJson = new HashMap<String, Object>();
		notificationJson.put(CreditBusinessConstants.NOTIFICATION_TYPE_CODE, notificationTypeCode);
		Map<String, Object> templatedata = new HashMap<String, Object>();
		templatedata.put("link", env.getProperty("loan.journey.url"));
		JSONObject name = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.NAME));
		StringBuilder fullName = new StringBuilder();
		if (null != name.get(FIRST_NAME)) {
			fullName.append(name.get(FIRST_NAME).toString());
			if (null != name.get(MIDDLE_NAME)) {
				fullName.append(" ").append(name.get(MIDDLE_NAME).toString());
			}
			if (null != name.get(LAST_NAME)) {
				fullName.append(" ").append(name.get(LAST_NAME).toString());
			}
		}
		templatedata.put(CreditBusinessConstants.NAME, fullName.toString());
		templatedata.put("principal", principalName);
		templatedata.put(CreditBusinessConstants.PHONE_NUMBER, null != execution.getVariable(CreditBusinessConstants.MOBILE) ? execution.getVariable(CreditBusinessConstants.MOBILE).toString() : null);
		templatedata.put(CreditBusinessConstants.RECIPIENT_EMAIL, null != execution.getVariable(CreditBusinessConstants.EMAIL) ? execution.getVariable(CreditBusinessConstants.EMAIL).toString() : null);
		templatedata.put("applicationid", execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		templatedata.put("isBol", false);
		templatedata.put("isSBFC", false);
		templatedata.put("isMuthoot", true);
		notificationJson.put(CreditBusinessConstants.TEMPLATE_DATA_MAP, templatedata);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, notificationJson);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preUnSecuredPartnerInProgress notification for: "+principalName);
	}
	
	@SuppressWarnings("unchecked")
	public void publishListingNotificationEvent(String applicationId, JSONObject mcpRequest) {
		JSONObject eventPayload = new JSONObject();
		String l2ProductCode = null;
		if (null != mcpRequest.get("prodCategory")) {
			Map<String, Object> productCategory = (Map<String, Object>) mcpRequest.get("prodCategory");
			l2ProductCode = productCategory.get("prodCatCode") != null ? productCategory.get("prodCatCode").toString() : null;
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "prodCategory not exist in mcpRequest response for: " + applicationId);
		}
		eventPayload.put(L2_PRODUCT_CODE, l2ProductCode);
		eventPayload.put(APPLICATIONKEY, applicationId);
		
		EventMessage eventMessage = new EventMessage();
		Map<String, String> eventHeaders = new HashMap<>();
		eventHeaders.put(CustomDefaultHeaders.AUTH_TOKEN, customDefaultHeaders.getAuthtoken());
		eventHeaders.put(CustomDefaultHeaders.CMPTCORR_ID, customDefaultHeaders.getCmptcorrid());
		
		Map<String, String> messageFilterAttributes = new HashMap<>();
		messageFilterAttributes.put(CREDIT_NOTIFICATION_EVENT, SEND_LISTING_NOTIFICATION_ATTRB);
		
		eventMessage.setHeaders(eventHeaders);
		eventMessage.setEventName(CREDIT_NOTIFICATION);
		eventMessage.setEventType(SEND_LISTING_NOTIFICATION);
		eventMessage.setEventSchema(new EventSchema());
		eventMessage.setPayload(eventPayload);
		eventMessage.setMessageFilterAttributes(messageFilterAttributes);
		try {
			publisherService.publish(applicationTopicArn, eventMessage);
		} catch(Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Exception occurred while publishing listing notification event for: " + eventMessage, exception);
		}
	}
}
