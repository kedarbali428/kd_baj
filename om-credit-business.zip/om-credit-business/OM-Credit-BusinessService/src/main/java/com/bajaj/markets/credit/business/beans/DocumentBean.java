package com.bajaj.markets.credit.business.beans;

import java.sql.Timestamp;

public class DocumentBean {

	private String DocType;
	private String partnerDocName;
	private String bfsdDocName;
	private Boolean docAvalibale;
	private Timestamp docSentDate;
	private String docId;
	private String docCategoryCode;

	private Integer creditdoctype;

	private String documentPushStatus;

	public String getDocType() {
		return DocType;
	}

	public void setDocType(String docType) {
		DocType = docType;
	}

	public String getPartnerDocName() {
		return partnerDocName;
	}

	public void setPartnerDocName(String partnerDocName) {
		this.partnerDocName = partnerDocName;
	}

	public String getBfsdDocName() {
		return bfsdDocName;
	}

	public void setBfsdDocName(String bfsdDocName) {
		this.bfsdDocName = bfsdDocName;
	}

	public Boolean getDocAvalibale() {
		return docAvalibale;
	}

	public void setDocAvalibale(Boolean docAvalibale) {
		this.docAvalibale = docAvalibale;
	}

	public Timestamp getDocSentDate() {
		return docSentDate;
	}

	public void setDocSentDate(Timestamp docSentDate) {
		this.docSentDate = docSentDate;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getDocCategoryCode() {
		return docCategoryCode;
	}

	public void setDocCategoryCode(String docCategoryCode) {
		this.docCategoryCode = docCategoryCode;
	}

	public Integer getCreditdoctype() {
		return creditdoctype;
	}

	public void setCreditdoctype(Integer creditdoctype) {
		this.creditdoctype = creditdoctype;
	}

	public String getDocumentPushStatus() {
		return documentPushStatus;
	}

	public void setDocumentPushStatus(String documentPushStatus) {
		this.documentPushStatus = documentPushStatus;
	}

}
