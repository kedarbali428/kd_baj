package com.bajaj.markets.credit.business.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.BundleProduct;
import com.bajaj.markets.credit.business.beans.BundleProductRider;
import com.bajaj.markets.credit.business.beans.BundleReject;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.FppAtributes;
import com.bajaj.markets.credit.business.beans.FppBreOutput;
import com.bajaj.markets.credit.business.beans.FppBundleBean;
import com.bajaj.markets.credit.business.beans.FppDetails;
import com.bajaj.markets.credit.business.beans.FppQuestionAnswer;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.Nominee;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OccupationReference;
import com.bajaj.markets.credit.business.beans.OpenArcFppOutput;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.RelationshipEnum;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessProductBundleService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Service used to perform loan product bundle related operations
 * 
 * @author 764504
 *
 */

@Service
public class CreditBusinessProductBundleServiceImpl implements CreditBusinessProductBundleService {
	
	private static final String IS_GENDER_REQUIRED = "isGenderRequired";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private CreditBusinessApiCallsHelper apiCallsHelper;

	@Autowired
	private WorkflowHelper workflowHelper;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getOccupationUrl;

	@Value("${api.omcreditapplicationservice.bundle.fpp.PUT.url}")
	private String putFppDataUrl;

	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String getChildApplicationUrl;

	@Value("${api.omcreditapplicationservice.bundle.GET.url}")
	private String getBundleKey;

	@Value("${api.omvasapplicationservice.questionresponse.GET.url}")
	private String getVasQuestionAns;

	@Value("${api.omvasapplicationservice.additionalattribute.GET.url}")
	private String getVasAttribues;
	
	@Value("#{${genderRequired.l3ProductCodes}}")
	private Map<String, String> genderRequiredl3ProductCodes;
	
	@Value("${api.omvasapplicationservice.nominee.GET.url}")
	private String getNominee;
	
	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	private MasterDataRedisClientHelper masterDataRedisHelper;

	private static final String CLASSNAME = CreditBusinessProductBundleServiceImpl.class.getName();

	/**
	 *Method used to fetch product bundle for given application
	 */
	@Override
	public FppBundleBean fetchFppBundle(String parentApplicationId, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start  - fetchFppBundle method applicationId :" + parentApplicationId);
		FppBundleBean reponse = null;

		try {
			Map<String, String> params = new HashMap<String, String>();
			params.put("applicationid", parentApplicationId);
			UserProfileBean userProfile = apiCallsHelper.getUserProfile(params);
			if (userProfile != null) {
				String request = prepareRequest(parentApplicationId, userProfile);
				reponse = prepareResponse(parentApplicationId, request, userProfile);
			}
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "BusinessException while fetching FPP bundle data for application " + parentApplicationId);
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "BusinessException while fetching FPP bundle ", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception while fetching FPP bundle data for application " + parentApplicationId);
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception while fetching FPP bundle ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-101", "Exception while fetching FPP bundle"));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End  - fetchFppBundle method  :");
		return reponse;
	}
	
	@SuppressWarnings("unchecked")
	private String prepareRequest(String parentApplicationId, UserProfileBean userProfile) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "start  - prepareRequest(), for parent application  " + parentApplicationId);
		JSONObject request = new JSONObject();
		request.put("source", CreditBusinessConstants.JOURNEY);
		if (userProfile != null && userProfile.getApplicationUserAttributeKey() != null) {
			Map<String, String> params = new HashMap<String, String>();
			params.put("applicationid", parentApplicationId);
			params.put("userattributekey", userProfile.getApplicationUserAttributeKey());
			Occupation occupation = apiCallsHelper.callApi(getOccupationUrl, HttpMethod.GET, params, null, Occupation.class);
			if (occupation != null && occupation.getOcupationType() != null) {
				OccupationReference occRef = apiCallsHelper.getOccupationMasterFromOccupationId(occupation.getOcupationType().getKey());
				if (occRef != null) {
					request.put("occupationType", occRef.getOccupationValue());
					if (occupation.getSalariedDetail() != null && occupation.getSalariedDetail().getEmployerName() != null
							&& occupation.getSalariedDetail().getEmployerName().getKey() != null) {
						JSONObject empMaster = apiCallsHelper.getEmployerMaster(occupation.getSalariedDetail().getEmployerName().getKey());
						if (empMaster != null) {
							request.put("companyCategory", empMaster.get("emprMastCategory"));
						}
					}
				}
			}
		}

		if (request.get("occupationType") == null) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Invalid request no occupationType found for application " + parentApplicationId);
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("CBS-101", "Invalid request no occupationType found for application " + parentApplicationId));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "end  - prepareRequest(), for parent application  " + parentApplicationId);
		return request.toJSONString();
	}

	@SuppressWarnings("unchecked")
	private FppBundleBean prepareResponse(String parentApplicationId, String request, UserProfileBean userProfile) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start  - prepareResponse method request :" + request);
		Map<String, String> params = new HashMap<String, String>();
		params.put("applicationkey", parentApplicationId);
		params.put("isInProcessing", Boolean.TRUE.toString());
		List<Map<String, Object>> childApps = apiCallsHelper.callApi(getChildApplicationUrl, HttpMethod.GET, params, null, List.class);
		if (!CollectionUtils.isEmpty(childApps)) {
			FppBundleBean fppResponse = new FppBundleBean();
			fppResponse.setApplicationId(parentApplicationId);

			Map<String, Object> childApplication = childApps.get(0);
			String childApplicationKey = childApplication.get(CreditBusinessConstants.APPLICATIONKEY) != null
					? childApplication.get(CreditBusinessConstants.APPLICATIONKEY).toString()
					: null;

			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Fetching FPP data for child app  :" + childApplicationKey);
			params = new HashMap<String, String>();
			params.put("applicationid", childApplicationKey);
			FppBreOutput output = apiCallsHelper.callApi(putFppDataUrl, HttpMethod.PUT, params, request,
					FppBreOutput.class);

			fppResponse.setIsGenderRequired(false);
			if (null != output && "true".equalsIgnoreCase(genderRequiredl3ProductCodes.get(output.getL3ProductCode()))) {
				fppResponse.setIsGenderRequired(true);
			}
			if (userProfile.getGenderKey() != null) {
				Reference gender = masterDataRedisHelper.getGenderReferenceByTypeKey(userProfile.getGenderKey());
				fppResponse.setGender(gender);
			}
			
		if (output != null && !CollectionUtils.isEmpty(output.getOpenArcFppOutput())) {
				JSONObject pricingMap = new JSONObject();
				OpenArcFppOutput openArcFppOutput = output.getOpenArcFppOutput().get(0);
				fppResponse.setL3ProductCode(output.getL3ProductCode());
				fppResponse.setL3ProductKey(output.getL3ProductKey());
				fppResponse.setOpenArcFppOutput(openArcFppOutput);

				if (!CollectionUtils.isEmpty(openArcFppOutput.getProducts())) {
					for (BundleProduct product : openArcFppOutput.getProducts()) {
						if (product.getProductCode().startsWith("BFDL_FPP_")) {
							pricingMap.put("PRODUCT_VHEALTH", product.getPv());
						} else if (product.getProductCode().startsWith("GCPP")) {
							pricingMap.put("PRODUCT_" + product.getProductCode(), product.getSumAssured());
						} else {
							pricingMap.put("PRODUCT_" + product.getProductCode(), product.getCostWithGst());
						}
						if (!CollectionUtils.isEmpty(product.getRiders())) {
							for (BundleProductRider rider : product.getRiders()) {
								pricingMap.put("RIDER_" + rider.getRiderCode(), rider.getSumAssured());
							}
						}
					}
				}
				fppResponse.setPricingMap(pricingMap);
				
				setBundleData(parentApplicationId, childApplicationKey, fppResponse);
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End  - getFppData method response :" + fppResponse);
				return fppResponse;
			}
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Invalid FPP response received from Application Service for child appliction " + childApplicationKey);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-101", "Invalid FPP response received from Application Service"));
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "No active child found for appliction " + parentApplicationId);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-101", "No active child found for appliction " + parentApplicationId));
		}
	}

	private void setBundleData(String parentApplicationId, String childApplicationKey, FppBundleBean fppResponse) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Started setBundleData for ApplicationKey " + parentApplicationId);
		Map<String, String> params = new HashMap<String, String>();
		params = new HashMap<String, String>();
		params.put("applicationid", childApplicationKey);
		JSONObject bundleKeyResp = null;
		JSONObject[] bundleKeyRespArr = apiCallsHelper.callApi(getBundleKey, HttpMethod.GET, params, null,
				JSONObject[].class);
		if (!ArrayUtils.isEmpty(bundleKeyRespArr)) {
			for (JSONObject bundle : bundleKeyRespArr) {
				if (bundle.get("source") != null
						&& CreditBusinessConstants.JOURNEY.equalsIgnoreCase(bundle.get("source").toString())) {
					bundleKeyResp = bundle;
					break;
				}
			}
			if (bundleKeyResp != null && bundleKeyResp.get("bundleSelected") != null
					&& (boolean) bundleKeyResp.get("bundleSelected")
					&& bundleKeyResp.get("bundleApplicationKey") != null) {
				Long bundleApplicationKey = Long.parseLong(bundleKeyResp.get("bundleApplicationKey").toString());

				// Get answers of questions stamped in VAS domain
				getQuestionAnsData(fppResponse, bundleApplicationKey);

				// Get attribuetes values such as height, weight etc. from VAS domain
				params = new HashMap<String, String>();
				params.put("applicationKey", bundleApplicationKey.toString());
				FppAtributes attributeResp = apiCallsHelper.callApi(getVasAttribues, HttpMethod.GET, params, null,
						FppAtributes.class);
				fppResponse.setFppAttributeAtributes(attributeResp);
			}
		}
		if (CreditBusinessConstants.BFLSOLFLDG.equals(fppResponse.getL3ProductCode())) {
			setNomineeData(bundleKeyResp, fppResponse, parentApplicationId);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"End setBundleData for ApplicationKey " + parentApplicationId);
	}

	@SuppressWarnings("unchecked")
	private Map<String, String> getQuestionAnsData(FppBundleBean fppResponse, Long bundleApplicationKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "start  - getQuestionAnsData, fetching question ans fro vas application  " + bundleApplicationKey);
		Map<String, String> params = new HashMap<String, String>();
		params.put("applicationKey", bundleApplicationKey.toString());
		JSONObject questionAnsResp = apiCallsHelper.callApi(getVasQuestionAns, HttpMethod.GET, params, null, JSONObject.class);
		if (questionAnsResp != null && questionAnsResp.get("questionAnswerList") != null) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			List<FppQuestionAnswer> questionAnsList = mapper.convertValue(questionAnsResp.get("questionAnswerList"), List.class);
			fppResponse.setQuestionAnswerList(questionAnsList);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "end  - getQuestionAnsData ");
		return params;
	}

	private void setNomineeData(JSONObject bundleResp, FppBundleBean response, String parentApplicationId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Started setBundleAndNomineeData for ApplicationKey " + parentApplicationId);
		if (bundleResp != null && bundleResp.get("bundleSelected") != null
				&& (boolean) bundleResp.get("bundleSelected")) {
			List<JSONObject> nomineeData = null;
			try {
				nomineeData = getNomineeDataFromVas(bundleResp.get("bundleApplicationKey"), parentApplicationId);
				List<Nominee> nomineeList = mapNominee(nomineeData, parentApplicationId);
				response.setNomineeDetails(nomineeList);
			} catch (CreditBusinessException e) {
				if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
							"Resource Not Found exception for Nominee details for : " + parentApplicationId, e);
				} else {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
							"Exception while fetching Nominee details for " + parentApplicationId, e);
					throw e;
				}
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"End setBundleAndNomineeData for ApplicationKey " + parentApplicationId);
	}

	private List<JSONObject> getNomineeDataFromVas(Object vasApplicationId, String parentApplicationId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Started getNomineeDataFromVas for ApplicationKey " + parentApplicationId);
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", vasApplicationId.toString());
		HttpHeaders headers = new HttpHeaders();
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Calling VAS Application Service");
		ResponseEntity<?> nomineeResp = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getNominee, List.class,
				params, null, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Response received from Vas Domain " + nomineeResp);
		if (nomineeResp != null && HttpStatus.OK.equals(nomineeResp.getStatusCode()) && nomineeResp.getBody() != null) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "getNomineeData finished " + parentApplicationId);
			return mapper.convertValue(nomineeResp.getBody(), new TypeReference<List<JSONObject>>() {
			});
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "getNomineeData finished " + parentApplicationId);
		return null;
	}

	private List<Nominee> mapNominee(List<JSONObject> nomineeData, String parentApplicationId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Started mapNominee for ApplicationKey " + parentApplicationId);
		List<Nominee> nomineeList = null;
		if (!CollectionUtils.isEmpty(nomineeData)) {
			nomineeList = new ArrayList<Nominee>();
			for (JSONObject n : nomineeData) {
				Nominee nominee = new Nominee();
				nominee.setDateOfBirth(n.get("dateOfBirth") != null ? n.get("dateOfBirth").toString() : null);
				nominee.setName(n.get("name") != null ? n.get("name").toString() : null);
				if (n.get("relationship") != null) {
					RelationshipEnum relation = RelationshipEnum.getByValue(n.get("relationship").toString());
					if (relation != null) {
						Reference ref = new Reference();
						ref.setCode(relation.getCode());
						ref.setValue(relation.getValue());
						ref.setKey(Long.valueOf(relation.getKey().toString()));
						nominee.setRelationship(ref);
					}
				}
				nomineeList.add(nominee);
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"End mapNominee for ApplicationKey " + parentApplicationId);
		return nomineeList;
	}

	/**
	 *Method used to save product bundle for given application
	 */
	@Override
	public FppDetails saveFppBundle(FppDetails fppDetails, Long applicationId, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start  - saveFppBundle method request :" + fppDetails);
		try {
			Map<String, Object> vars = new HashMap<String, Object>();
			vars.put(CreditBusinessConstants.REQUEST, fppDetails);
			vars.put("action", fppDetails.getAction() != null ? fppDetails.getAction().toLowerCase() : "next");
			vars.put(CreditBusinessConstants.APPLICATION_ID, applicationId);
			vars.put(CreditBusinessConstants.FPPSELECTED, fppDetails.getIsFppSelected());
			boolean isGenderRequired = Boolean.FALSE;
			if("next".equals(vars.get("action")) && fppDetails.getIsFppSelected()) {
				isGenderRequired = fppDetails.getBundleData().getIsGenderRequired();
			}
			vars.put(IS_GENDER_REQUIRED, isGenderRequired);
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			if (!StringUtils.isEmpty(nextTaskKey)) {
				NextTask task = new NextTask();
				task.setNextTaskKey(nextTaskKey);
				fppDetails.setNextTask(task);
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End saveFppBundle for applicationid : " + applicationId + " Response : " + fppDetails);
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "BusinessException while completing activiti task ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-101", "BusinessException while completing activiti task"));
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception while completing activiti task", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-101", "Exception while completing activiti task"));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End  - saveFppBundle method  :");
		return fppDetails;
	}
	
	/**
	 *Method used to move backword/forward workflow from FPP rejection task screen 
	 *
	 */
	@Override
	public ApplicationResponse rejectBundle(BundleReject request, Long applicationId, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start  - rejectBundle method request :" + request);
		ApplicationResponse response = new ApplicationResponse();
		try {
			Map<String, Object> vars = new HashMap<String, Object>();
			vars.put(CreditBusinessConstants.REQUEST, request);
			vars.put("action", request.getAction() != null ? request.getAction().toLowerCase() : "next");
			vars.put(CreditBusinessConstants.APPLICATION_ID, applicationId);
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			NextTask task = new NextTask();
			if (!StringUtils.isEmpty(nextTaskKey)) {
				task.setNextTaskKey(nextTaskKey);
			}
			response.setNextTask(task);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End rejectBundle for applicationid : " + applicationId + " Response : " + response);
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "BusinessException while processing bundle rejection", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-101", "BusinessException while processing bundle rejection"));
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception while processing bundle rejection", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-101", "Exception while processing bundle rejection"));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End  - rejectBundle method  :");
		return response;
	}

}