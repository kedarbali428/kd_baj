package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;
import java.util.Date;
public class PersonalDetails {
	private String firstName;
	private String middleName;
	private String lastName;
	private String dob;
	private String mobileNo;
	private String pinCode;
	private String companyName;
	private Long employerId;
	private String officeEmailID;
	private String designation;
	private String pan;
	private String maritalStatus;
	private Long maritalStatusKey;
	private String residenceType;
	private Long residenceTypeKey;
	private String personalEmailId;
	private String profession;
	private String occupationType;
	private String latestDegree;
	private String specialization;
	private BigDecimal ugYearOfGraduation;
	private BigDecimal pgYearOfGraduation;
	private String yearOfCertification;
	private String mrn;
	private String medicalCouncil;
	private String clinicOwnershipStatus;
	private String annualTurnover;
	private String constitutionType;
	private String businessVintage;
	private String natureOfBusiness;
	private String industry;
	private String gender;
	private Long genderKey;
	private String subIndustry;
	private String businessName;
	private String businessEntityPAN;
	private String officePin;
	private String officeCity;
	private String officeState;
	private String officeOwnership;
	private String hospitalName;
	private String othHospitalName;
	private String customerId;
	private Long prospectKey;
	private BigDecimal dncstatus;
	private Long emicardnum;
	private Date dateofincorporation;
	private BigDecimal customertype;
	private String prospectid;
	private String pennantcustid;
	private BigDecimal bfsdapltkey;
	private String prospectsrc;
	private BigDecimal copattainyear;
	private Long cibilscore;
	private String caregnumber;
	private Long hospitalKey;
	private Long rcmastKey;
	private Long spclmastkey;
	private Long qlfymastkey;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPincode() {
		return pinCode;
	}
	public void setPincode(String pincode) {
		this.pinCode = pincode;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Long getEmployerId() {
		return employerId;
	}
	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}
	public String getOfficeEmailID() {
		return officeEmailID;
	}
	public void setOfficeEmailID(String officeEmailID) {
		this.officeEmailID = officeEmailID;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public Long getMaritalStatusKey() {
		return maritalStatusKey;
	}
	public void setMaritalStatusKey(Long maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}
	public String getResidenceType() {
		return residenceType;
	}
	public void setResidenceType(String residenceType) {
		this.residenceType = residenceType;
	}
	public String getPersonalEmailId() {
		return personalEmailId;
	}
	public void setPersonalEmailId(String personalEmailId) {
		this.personalEmailId = personalEmailId;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	public String getOccupationType() {
		return occupationType;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public String getLatestDegree() {
		return latestDegree;
	}
	public void setLatestDegree(String latestDegree) {
		this.latestDegree = latestDegree;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public BigDecimal getUgYearOfGraduation() {
		return ugYearOfGraduation;
	}
	public void setUgYearOfGraduation(BigDecimal ugYearOfGraduation) {
		this.ugYearOfGraduation = ugYearOfGraduation;
	}
	public BigDecimal getPgYearOfGraduation() {
		return pgYearOfGraduation;
	}
	public void setPgYearOfGraduation(BigDecimal pgYearOfGraduation) {
		this.pgYearOfGraduation = pgYearOfGraduation;
	}
	public String getYearOfCertification() {
		return yearOfCertification;
	}
	public void setYearOfCertification(String yearOfCertification) {
		this.yearOfCertification = yearOfCertification;
	}
	public String getMrn() {
		return mrn;
	}
	public void setMrn(String mrn) {
		this.mrn = mrn;
	}
	public String getMedicalCouncil() {
		return medicalCouncil;
	}
	public void setMedicalCouncil(String medicalCouncil) {
		this.medicalCouncil = medicalCouncil;
	}
	public String getClinicOwnershipStatus() {
		return clinicOwnershipStatus;
	}
	public void setClinicOwnershipStatus(String clinicOwnershipStatus) {
		this.clinicOwnershipStatus = clinicOwnershipStatus;
	}
	public String getAnnualTurnover() {
		return annualTurnover;
	}
	public void setAnnualTurnover(String annualTurnover) {
		this.annualTurnover = annualTurnover;
	}
	public String getConstitutionType() {
		return constitutionType;
	}
	public void setConstitutionType(String constitutionType) {
		this.constitutionType = constitutionType;
	}
	public String getBusinessVintage() {
		return businessVintage;
	}
	public void setBusinessVintage(String businessVintage) {
		this.businessVintage = businessVintage;
	}
	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}
	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Long getGenderKey() {
		return genderKey;
	}
	public void setGenderKey(Long genderKey) {
		this.genderKey = genderKey;
	}
	public String getSubIndustry() {
		return subIndustry;
	}
	public void setSubIndustry(String subIndustry) {
		this.subIndustry = subIndustry;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getBusinessEntityPAN() {
		return businessEntityPAN;
	}
	public void setBusinessEntityPAN(String businessEntityPAN) {
		this.businessEntityPAN = businessEntityPAN;
	}
	public String getOfficePin() {
		return officePin;
	}
	public void setOfficePin(String officePin) {
		this.officePin = officePin;
	}
	public String getOfficeCity() {
		return officeCity;
	}
	public void setOfficeCity(String officeCity) {
		this.officeCity = officeCity;
	}
	public String getOfficeState() {
		return officeState;
	}
	public void setOfficeState(String officeState) {
		this.officeState = officeState;
	}
	public String getOfficeOwnership() {
		return officeOwnership;
	}
	public void setOfficeOwnership(String officeOwnership) {
		this.officeOwnership = officeOwnership;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getOthHospitalName() {
		return othHospitalName;
	}
	public void setOthHospitalName(String othHospitalName) {
		this.othHospitalName = othHospitalName;
	}
	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public Long getProspectKey() {
		return prospectKey;
	}
	public void setProspectKey(Long prospectKey) {
		this.prospectKey = prospectKey;
	}
	public Long getResidenceTypeKey() {
		return residenceTypeKey;
	}
	public void setResidenceTypeKey(Long residenceTypeKey) {
		this.residenceTypeKey = residenceTypeKey;
	}
	
	public BigDecimal getDncstatus() {
		return dncstatus;
}
	public void setDncstatus(BigDecimal dncstatus) {
		this.dncstatus = dncstatus;
	}
	public Long getEmicardnum() {
		return emicardnum;
	}
	public void setEmicardnum(Long emicardnum) {
		this.emicardnum = emicardnum;
	}
	public Date getDateofincorporation() {
		return dateofincorporation;
	}
	public void setDateofincorporation(Date dateofincorporation) {
		this.dateofincorporation = dateofincorporation;
	}
	public BigDecimal getCustomertype() {
		return customertype;
	}
	public void setCustomertype(BigDecimal customertype) {
		this.customertype = customertype;
	}
	public String getProspectid() {
		return prospectid;
	}
	public void setProspectid(String prospectid) {
		this.prospectid = prospectid;
	}
	public String getPennantcustid() {
		return pennantcustid;
	}
	public void setPennantcustid(String pennantcustid) {
		this.pennantcustid = pennantcustid;
	}
	public BigDecimal getBfsdapltkey() {
		return bfsdapltkey;
	}
	public void setBfsdapltkey(BigDecimal bfsdapltkey) {
		this.bfsdapltkey = bfsdapltkey;
	}
	public String getProspectsrc() {
		return prospectsrc;
	}
	public void setProspectsrc(String prospectsrc) {
		this.prospectsrc = prospectsrc;
	}
	public BigDecimal getCopattainyear() {
		return copattainyear;
	}
	public void setCopattainyear(BigDecimal copattainyear) {
		this.copattainyear = copattainyear;
	}
	public Long getCibilscore() {
		return cibilscore;
	}
	public void setCibilscore(Long cibilscore) {
		this.cibilscore = cibilscore;
	}
	public String getCaregnumber() {
		return caregnumber;
	}
	public void setCaregnumber(String caregnumber) {
		this.caregnumber = caregnumber;
	}
	public Long getHospitalKey() {
		return hospitalKey;
	}
	public void setHospitalKey(Long hospitalKey) {
		this.hospitalKey = hospitalKey;
	}
	public Long getRcmastKey() {
		return rcmastKey;
	}
	public void setRcmastKey(Long rcmastKey) {
		this.rcmastKey = rcmastKey;
	}
	public Long getSpclmastkey() {
		return spclmastkey;
	}
	public void setSpclmastkey(Long spclmastkey) {
		this.spclmastkey = spclmastkey;
	}
	public Long getQlfymastkey() {
		return qlfymastkey;
	}
	public void setQlfymastkey(Long qlfymastkey) {
		this.qlfymastkey = qlfymastkey;
	}
	
}
