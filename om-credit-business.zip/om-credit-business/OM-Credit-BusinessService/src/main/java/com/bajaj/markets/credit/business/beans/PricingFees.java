package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


public class PricingFees implements Serializable,Cloneable{

	private static final long serialVersionUID = 1L;
	


	private Long feesKey;
	
    private Long appLoanPricingKey;
    
    private BigDecimal feesInPercent;
    
    private BigDecimal feesInAmount;
    
    private String feeCode;

	public Long getFeesKey() {
		return feesKey;
	}

	public void setFeesKey(Long feesKey) {
		this.feesKey = feesKey;
	}

	public Long getAppLoanPricingKey() {
		return appLoanPricingKey;
	}

	public void setAppLoanPricingKey(Long appLoanPricingKey) {
		this.appLoanPricingKey = appLoanPricingKey;
	}

	public BigDecimal getFeesInPercent() {
		return feesInPercent;
	}

	public void setFeesInPercent(BigDecimal feesInPercent) {
		this.feesInPercent = feesInPercent;
	}

	public BigDecimal getFeesInAmount() {
		return feesInAmount;
	}

	public void setFeesInAmount(BigDecimal feesInAmount) {
		this.feesInAmount = feesInAmount;
	}

	public String getFeeCode() {
		return feeCode;
	}

	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}
    
}