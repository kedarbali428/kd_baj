package com.bajaj.markets.credit.business.sduiprocessor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TaskProcessorFactory {

	@Autowired
	private BasicDetailsProcessor basicDetailsProcessor;

	public TaskProcessor getUserTask(String taskName) {
		switch (taskName) {
		case "basicDetails":
			return basicDetailsProcessor;
		default:
			return basicDetailsProcessor;
		}
		
	}
	
}
