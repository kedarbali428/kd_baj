package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;

import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EmailOTPValidate;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EmailTOKENValidate;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(content = Include.NON_NULL)
public class EmailDetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 238393812075879177L;

	private EmailPageActions action;
	
	@NotEmpty(groups = EmailOTPValidate.class, message = "otp can not be null")
	@Digits(groups = EmailOTPValidate.class, integer = 6, fraction = 0, message = "otp should be numaric and should not be exceed the size")
	private String otp;
	
	@NotEmpty(groups = EmailTOKENValidate.class, message = "emailToken can not be null")
	private String emailToken;
	
	private String email;
	private Long emailTypeKey;
	private Boolean verified;
	
	private Boolean emailVerificationVisible;
	
	public String getOtp() {
		return otp;
	}

	public EmailPageActions getAction() {
		return action;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setVerified(Boolean verified) {
		this.verified = verified;
	}

	public String getEmail() {
		return email;
	}

	public Boolean isVerified() {
		return verified;
	}

	public Long getEmailTypeKey() {
		return emailTypeKey;
	}

	public void setEmailTypeKey(Long emailTypeKey) {
		this.emailTypeKey = emailTypeKey;
	}
	
	public String getEmailToken() {
		return emailToken;
	}

	public Boolean getEmailVerificationVisible() {
		return emailVerificationVisible;
	}

	public void setEmailVerificationVisible(Boolean emailVerificationVisible) {
		this.emailVerificationVisible = emailVerificationVisible;
	}
	
	public Boolean getVerified() {
		return verified;
	}

	@Override
	public String toString() {
		return "EmailDetails [action=" + action + ", otp=" + otp + ", emailToken=" + emailToken + ", email=" + email
				+ ", emailTypeKey=" + emailTypeKey + ", verified=" + verified + ", emailVerificationVisible="
				+ emailVerificationVisible + "]";
	}
	
}
