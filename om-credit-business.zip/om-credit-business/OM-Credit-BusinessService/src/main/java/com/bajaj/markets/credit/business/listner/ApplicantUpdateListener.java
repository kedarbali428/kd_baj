package com.bajaj.markets.credit.business.listner;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.ApplicantUpdateDetails;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;

@Component
public class ApplicantUpdateListener {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	ApplicantUpdateDetails applicantUpdateDetails;
	
	@Autowired
	private Executor customExecutor;

	private static final String CLASS_NAME = ApplicantUpdateDetails.class.getCanonicalName();

	public void updateApplicantData(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "start updateApplicantData for Application ID :" + execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		CompletableFuture.runAsync(() -> applicantUpdateDetails.updateApplicantData(execution),customExecutor)
		.whenComplete((a,ex) -> {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "updateApplicantData Completed for Application ID :" + execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
			if(null != ex) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured in updateApplicantData",ex);
			}
		});
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End updateApplicantData");
	}
	
	public void updateApplicantAddress(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "start updateApplicantAddress");
		CompletableFuture.runAsync(() -> applicantUpdateDetails.updateApplicantAddress(execution),customExecutor)
		.whenComplete((a,ex) -> {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "updateApplicantAddress Completed");
			if(null != ex) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured in updateApplicantAddress",ex);
			}
		});
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End updateApplicantAddress");
	}

}
