package com.bajaj.markets.credit.business.service;

import java.util.List;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.Application;
import com.bajaj.markets.credit.business.beans.ApplicationInfo;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ImpsRequestMetadata;
import com.bajaj.markets.credit.business.beans.ProfileDetail;
import com.bajaj.markets.credit.business.beans.ProfileDetails;
import com.bajaj.markets.credit.business.beans.ProfileDetailsWrapper;

public interface CreditBusinessService {

	public ProfileDetailsWrapper updateProfile(ProfileDetails profileDetails, String applicationid,
			HttpHeaders headers,String action);

	ApplicationResponse createCreditApplication(Application application, HttpHeaders headers);

	ProfileDetail getProfile(String applicationId, String source);

	Application getApplication(String applicationid, HttpHeaders headers);

	ApplicationInfo getApplicationInfo(String applicationId, HttpHeaders headers);

	public List<ImpsRequestMetadata> getImpsDetails(String applicationId, Integer bankAcctcatKey, HttpHeaders headers);

	public void updateProfileDetails(String applicationid, HttpHeaders headers);

}
