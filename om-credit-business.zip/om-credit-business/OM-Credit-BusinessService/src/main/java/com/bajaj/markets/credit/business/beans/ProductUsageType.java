package com.bajaj.markets.credit.business.beans;

public class ProductUsageType {

	private String usageTypeCode; 
	private String usageTypeDescription;
	
	public String getUsageTypeCode() {
		return usageTypeCode;
	}
	public void setUsageTypeCode(String usageTypeCode) {
		this.usageTypeCode = usageTypeCode;
	}
	public String getUsageTypeDescription() {
		return usageTypeDescription;
	}
	public void setUsageTypeDescription(String usageTypeDescription) {
		this.usageTypeDescription = usageTypeDescription;
	}
	@Override
	public String toString() {
		return "ProductUsageType [usageTypeCode=" + usageTypeCode + ", usageTypeDescription=" + usageTypeDescription
				+ "]";
	}
}