package com.bajaj.markets.credit.business.listner;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
public class Occupation {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String OCCUPATION_TYPE = "ocupationType";
	private static final String OCCUPATION_TYPE_KEY = "occupationTypeKey";
	private static final String PROFESSION = "profession";
	private static final String KEY = "key";

	private static final String CLASS_NAME = UpdateProfile.class.getCanonicalName();
	
	public void preOccupationTypeKey(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preOccupationTypeKey");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject profession = CreditBusinessHelper.getJSONObject(request.get(PROFESSION));
		JSONObject occupationType = CreditBusinessHelper.getJSONObject(profession.get(OCCUPATION_TYPE));
		if(null != occupationType && null != occupationType.get(KEY)) {
			execution.setVariable(OCCUPATION_TYPE_KEY, ((Double)occupationType.get(KEY)).longValue());
		} else {
			execution.setVariable(OCCUPATION_TYPE_KEY, null);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preOccupationTypeKey");
	}
}