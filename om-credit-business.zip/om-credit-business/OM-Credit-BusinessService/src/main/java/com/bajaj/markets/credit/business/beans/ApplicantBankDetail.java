package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class ApplicantBankDetail implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long applicantBankDetKey;
	private String apltBnkDetAccNum;
	private Timestamp apltBnkDetAccVerficationDt;
	private String apltBnkDetAccVerficationSrc;
	private BigDecimal apltBnkDetAccVerficationSts;
	private Date apltBnkDetEndDt;
	private String apltBnkDetHolderName;
	private String apltBnkDetLstUpdateBy;
	private Timestamp apltBnkDetLstUpdateDt;
	private Date apltBnkDetStartDt;
	private BigDecimal apltBnkInfoSalaryAccFlag;
	private BigDecimal apltBnkIsActive;
	private BigDecimal mandateReqdFlg;
	private Timestamp mandateReqFlgChngDt;
	private Long accTypKey;
	private Long applicantKey;
	private Long branchKey;

	public ApplicantBankDetail() {
	}

	public Long getApplicantBankDetKey() {
		return applicantBankDetKey;
	}

	public void setApplicantBankDetKey(Long applicantBankDetKey) {
		this.applicantBankDetKey = applicantBankDetKey;
	}

	public String getApltBnkDetAccNum() {
		return apltBnkDetAccNum;
	}

	public void setApltBnkDetAccNum(String apltBnkDetAccNum) {
		this.apltBnkDetAccNum = apltBnkDetAccNum;
	}

	public Timestamp getApltBnkDetAccVerficationDt() {
		return apltBnkDetAccVerficationDt;
	}

	public void setApltBnkDetAccVerficationDt(Timestamp apltBnkDetAccVerficationDt) {
		this.apltBnkDetAccVerficationDt = apltBnkDetAccVerficationDt;
	}

	public String getApltBnkDetAccVerficationSrc() {
		return apltBnkDetAccVerficationSrc;
	}

	public void setApltBnkDetAccVerficationSrc(String apltBnkDetAccVerficationSrc) {
		this.apltBnkDetAccVerficationSrc = apltBnkDetAccVerficationSrc;
	}

	public BigDecimal getApltBnkDetAccVerficationSts() {
		return apltBnkDetAccVerficationSts;
	}

	public void setApltBnkDetAccVerficationSts(BigDecimal apltBnkDetAccVerficationSts) {
		this.apltBnkDetAccVerficationSts = apltBnkDetAccVerficationSts;
	}

	public Date getApltBnkDetEndDt() {
		return apltBnkDetEndDt;
	}

	public void setApltBnkDetEndDt(Date apltBnkDetEndDt) {
		this.apltBnkDetEndDt = apltBnkDetEndDt;
	}

	public String getApltBnkDetHolderName() {
		return apltBnkDetHolderName;
	}

	public void setApltBnkDetHolderName(String apltBnkDetHolderName) {
		this.apltBnkDetHolderName = apltBnkDetHolderName;
	}

	public String getApltBnkDetLstUpdateBy() {
		return apltBnkDetLstUpdateBy;
	}

	public void setApltBnkDetLstUpdateBy(String apltBnkDetLstUpdateBy) {
		this.apltBnkDetLstUpdateBy = apltBnkDetLstUpdateBy;
	}

	public Timestamp getApltBnkDetLstUpdateDt() {
		return apltBnkDetLstUpdateDt;
	}

	public void setApltBnkDetLstUpdateDt(Timestamp apltBnkDetLstUpdateDt) {
		this.apltBnkDetLstUpdateDt = apltBnkDetLstUpdateDt;
	}

	public Date getApltBnkDetStartDt() {
		return apltBnkDetStartDt;
	}

	public void setApltBnkDetStartDt(Date apltBnkDetStartDt) {
		this.apltBnkDetStartDt = apltBnkDetStartDt;
	}

	public BigDecimal getApltBnkInfoSalaryAccFlag() {
		return apltBnkInfoSalaryAccFlag;
	}

	public void setApltBnkInfoSalaryAccFlag(BigDecimal apltBnkInfoSalaryAccFlag) {
		this.apltBnkInfoSalaryAccFlag = apltBnkInfoSalaryAccFlag;
	}

	public BigDecimal getApltBnkIsActive() {
		return apltBnkIsActive;
	}

	public void setApltBnkIsActive(BigDecimal apltBnkIsActive) {
		this.apltBnkIsActive = apltBnkIsActive;
	}

	public BigDecimal getMandateReqdFlg() {
		return mandateReqdFlg;
	}

	public void setMandateReqdFlg(BigDecimal mandateReqdFlg) {
		this.mandateReqdFlg = mandateReqdFlg;
	}

	public Timestamp getMandateReqFlgChngDt() {
		return mandateReqFlgChngDt;
	}

	public void setMandateReqFlgChngDt(Timestamp mandateReqFlgChngDt) {
		this.mandateReqFlgChngDt = mandateReqFlgChngDt;
	}

	public Long getAccTypKey() {
		return accTypKey;
	}

	public void setAccTypKey(Long accTypKey) {
		this.accTypKey = accTypKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getBranchKey() {
		return branchKey;
	}

	public void setBranchKey(Long branchKey) {
		this.branchKey = branchKey;
	}

}