package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Back;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Business;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.CaIcwaSelfEmployed;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.DoctorSalaried;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.DoctorSelfEmployed;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Salaried;

public class CreditParameters implements Serializable {

	private static final long serialVersionUID = 2703536940790674841L;

	@Valid
	@NotNull(groups = { Salaried.class, Business.class, DoctorSalaried.class, DoctorSelfEmployed.class,
			CaIcwaSelfEmployed.class }, message = "residencePincode cannot be null or empty")
	private Pincode residencePincode;

	@NotNull(groups = { Salaried.class, Business.class, DoctorSalaried.class, DoctorSelfEmployed.class,
			CaIcwaSelfEmployed.class }, message = "residenceType cannot be null or empty")
	private Reference residenceType;

	@Valid
	@NotNull(groups = { Salaried.class, Business.class, DoctorSalaried.class, DoctorSelfEmployed.class,
			CaIcwaSelfEmployed.class }, message = "Occupation cannot be null or empty")
	private Occupation profession;

	private String applicationid;

	@NotBlank(groups = Back.class, message = "action cannot be null or empty")
	private String action;

	private String hlProductIntent;

	private PropertyDetails propertyDetails;

	private Pincode propertyPincode;

	private BankMaster btBankDetails;

	private Boolean coapplicantEarning = false;

	private String coapplicantObligation;

	private String coapplicantIncome;

	private String l2ProductCode;

	private Boolean isEtb;

	private boolean isFreeTextForEmployer;

	@NotEmpty(groups = { Salaried.class, Business.class }, message = "Full name can not be null or empty")
	private String name;
	
	private String dateOfBirth;

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Pincode getResidencePincode() {
		return residencePincode;
	}

	public void setResidencePincode(Pincode residencePincode) {
		this.residencePincode = residencePincode;
	}

	public Reference getResidenceType() {
		return residenceType;
	}

	public void setResidenceType(Reference residenceType) {
		this.residenceType = residenceType;
	}

	public Occupation getProfession() {
		return profession;
	}

	public void setProfession(Occupation profession) {
		this.profession = profession;
	}

	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getHlProductIntent() {
		return hlProductIntent;
	}

	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public PropertyDetails getPropertyDetails() {
		return propertyDetails;
	}

	public void setPropertyDetails(PropertyDetails propertyDetails) {
		this.propertyDetails = propertyDetails;
	}

	public Pincode getPropertyPincode() {
		return propertyPincode;
	}

	public void setPropertyPincode(Pincode propertyPincode) {
		this.propertyPincode = propertyPincode;
	}

	public BankMaster getBtBankDetails() {
		return btBankDetails;
	}

	public void setBtBankDetails(BankMaster btBankDetails) {
		this.btBankDetails = btBankDetails;
	}

	public Boolean getCoapplicantEarning() {
		return coapplicantEarning;
	}

	public void setCoapplicantEarning(Boolean coapplicantEarning) {
		this.coapplicantEarning = coapplicantEarning;
	}

	public String getCoapplicantObligation() {
		return coapplicantObligation;
	}

	public void setCoapplicantObligation(String coapplicantObligation) {
		this.coapplicantObligation = coapplicantObligation;
	}

	public String getCoapplicantIncome() {
		return coapplicantIncome;
	}

	public void setCoapplicantIncome(String coapplicantIncome) {
		this.coapplicantIncome = coapplicantIncome;
	}

	public String getL2ProductCode() {
		return l2ProductCode;
	}

	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}

	public Boolean getIsEtb() {
		return isEtb;
	}

	public void setIsEtb(Boolean isEtb) {
		this.isEtb = isEtb;
	}

	public boolean isFreeTextForEmployer() {
		return isFreeTextForEmployer;
	}

	public void setFreeTextForEmployer(boolean isFreeTextForEmployer) {
		this.isFreeTextForEmployer = isFreeTextForEmployer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "CreditParameters [residencePincode=" + residencePincode + ", residenceType=" + residenceType
				+ ", profession=" + profession + ", applicationid=" + applicationid + ", action=" + action
				+ ", hlProductIntent=" + hlProductIntent + ", propertyDetails=" + propertyDetails + ", propertyPincode="
				+ propertyPincode + ", btBankDetails=" + btBankDetails + ", coapplicantEarning=" + coapplicantEarning
				+ ", coapplicantObligation=" + coapplicantObligation + ", coapplicantIncome=" + coapplicantIncome
				+ ", l2ProductCode=" + l2ProductCode + ", isEtb=" + isEtb + ", isFreeTextForEmployer="
				+ isFreeTextForEmployer + ", name=" + name + ", DateOfBirth=" + dateOfBirth + "]";
	}
}
