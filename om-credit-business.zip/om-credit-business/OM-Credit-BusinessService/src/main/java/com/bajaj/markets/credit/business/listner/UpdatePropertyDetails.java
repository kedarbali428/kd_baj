package com.bajaj.markets.credit.business.listner;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;

@Component
public class UpdatePropertyDetails {

	private static final String CO_APP_EMAIL = "coAppEmail";

	private static final String CO_APP_DOB = "coAppDob";

	private static final String CO_APP_MOBILE = "coAppMobile";

	private static final String CO_APP_PAN = "coAppPAN";

	private static final String CO_APP_MARITAL_STATUS = "coAppMaritalStatus";

	private static final String CO_APP_GENDER = "coAppGender";

	private static final String CO_APP_NAME = "coAppName";

	private static final String SOURCE_NAME = "sourceName";

	private static final String BANK_MASTER_KEY = "bankMasterKey";

	private static final String BTBANK = "BTBANK";

	private static final String BANK_ACCOUNT_CATEGORY = "bankAccountCatCode";

	private static final String KEY = "key";

	private static final String VERIFICATION2 = "verification";

	private static final String STATE_KEY = "stateKey";

	private static final String PINCODE_KEY = "pincodeKey";

	private static final String PINCODE2 = "pincode";

	private static final String COUNTRY_KEY = "countryKey";

	private static final String CITY_KEY = "cityKey";

	private static final String ADDRESS_TYPE_KEY = "addressTypeKey";

	private static final String ADDRESS_SOURCE = "addressSource";

	private static final String ADDRESS_LINE2 = "addressLine2";

	private static final String ADDRESS_LINE1 = "addressLine1";

	private static final String STATE2 = "state";

	private static final String COUNTRY2 = "country";

	private static final String CITY2 = "city";

	private static final String PROPERTY_PINCODE = "propertyPincode";

	
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	@Autowired
	MasterDataRedisClientHelper masterDataRedisClientHelper;
	
	private static final String CLASS_NAME = UpdatePropertyDetails.class.getCanonicalName();
	
	@SuppressWarnings("unchecked")
	public void propertyUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start propertyUpdate");
		JSONObject professionalDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject propertyDetails = CreditBusinessHelper.getJSONObject(professionalDetails.get(CreditBusinessConstants.PROPERTYDETAILS));
		JSONObject propertyDetailsJsonObject = new JSONObject();
		propertyDetailsJsonObject.put("isPropertyIdentified", propertyDetails.get("isPropertyIdentified"));
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTYSIZE, null);
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTYSIZE_SQFT, null);
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTY_REFERENCE, null);
		if(null != professionalDetails.get("coapplicantEarning")) {
			Boolean showCoAppEarning = (Boolean) professionalDetails.get("coapplicantEarning");
			execution.setVariable(CreditBusinessConstants.SHOW_COAPPLICANT_EARNING,showCoAppEarning);
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, propertyDetailsJsonObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End propertyUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void updatePropertyaddress(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start addressUpdate");
		JSONObject address = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject pinCode = CreditBusinessHelper.getJSONObject(address.get(PROPERTY_PINCODE));
		JSONObject city = CreditBusinessHelper.getJSONObject(pinCode.get(CITY2));
		JSONObject country = CreditBusinessHelper.getJSONObject(pinCode.get(COUNTRY2));
		JSONObject state = CreditBusinessHelper.getJSONObject(pinCode.get(STATE2));
		JSONObject addressObject = new JSONObject();
		JSONObject verification = new JSONObject();
		addressObject.put(ADDRESS_LINE1, "");
		addressObject.put(ADDRESS_LINE2, "");
		addressObject.put(ADDRESS_SOURCE, "JOURNEY");
		addressObject.put(ADDRESS_TYPE_KEY, masterDataRedisClientHelper.getAddressTypeKeyForCode(CreditBusinessConstants.ADDRESS_TYPE_PROPERTY));
		addressObject.put(CITY_KEY, (String.format("%.0f", city.get(KEY))));
		addressObject.put(COUNTRY_KEY, (String.format("%.0f", country.get(KEY))));
		addressObject.put(PINCODE2, pinCode.get(PINCODE2));
		addressObject.put(PINCODE_KEY, pinCode.get(PINCODE2));
		addressObject.put(STATE_KEY, (String.format("%.0f", state.get(KEY))));
		verification.put(CreditBusinessConstants.IS_VERIFIED, false);
		verification.put(CreditBusinessConstants.VERIFICATION_DATE, "");
		verification.put(CreditBusinessConstants.VERIFICATION_SOURCE, "");
		verification.put(CreditBusinessConstants.VERIFIEDFOR, "");
		addressObject.put(VERIFICATION2, verification);
		if(null != address.get("coapplicantEarning")) {
			Boolean showCoAppEarning = (Boolean) address.get("coapplicantEarning");
			execution.setVariable(CreditBusinessConstants.SHOW_COAPPLICANT_EARNING,showCoAppEarning);
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, addressObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End addressUpdate");

	}
	
	@SuppressWarnings("unchecked")
	public void updateBTBankDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start updateBTBankDetails");
		JSONObject propertyDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject btBankDetails = CreditBusinessHelper.getJSONObject(propertyDetails.get("btBankDetails"));
		JSONObject bankDetailObject = new JSONObject();
		bankDetailObject.put(BANK_ACCOUNT_CATEGORY, BTBANK);
		bankDetailObject.put(BANK_MASTER_KEY,Integer.parseInt((String.format("%.0f", btBankDetails.get(BANK_MASTER_KEY)))));
		bankDetailObject.put(SOURCE_NAME, CreditBusinessConstants.JOURNEY);
		if(null != propertyDetails.get("coapplicantEarning")) {
			Boolean showCoAppEarning = (Boolean) propertyDetails.get("coapplicantEarning");
			execution.setVariable(CreditBusinessConstants.SHOW_COAPPLICANT_EARNING,showCoAppEarning);
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, bankDetailObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End updateBTBankDetails");
	}
	
	@SuppressWarnings("unchecked")
	public void preAdditionalPropertyDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAdditionalPropertyDetails");
		execution.setVariable(CreditBusinessConstants.PROPERTY_PINCODE_DISPLAY, false);
		JSONObject additionalPropertyDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject propertyDetails  = CreditBusinessHelper.getJSONObject(additionalPropertyDetails.get("propertyDetails"));
		JSONObject pincodeDetails = CreditBusinessHelper.getJSONObject(additionalPropertyDetails.get("pincode"));
		if(null!=pincodeDetails) {
			if(null != pincodeDetails.get("pincode") || null != pincodeDetails.get("addressLine1")) {
				execution.setVariable(CreditBusinessConstants.PROPERTY_PINCODE_DISPLAY, true);
			}
			else {
				execution.setVariable(CreditBusinessConstants.PROPERTY_PINCODE_DISPLAY, false);
			}
		}
		JSONObject propertyDetailsJsonObject = new JSONObject();
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTYSIZE, propertyDetails.get(CreditBusinessConstants.PROPERTYSIZE));
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTYSIZE_SQFT, propertyDetails.get(CreditBusinessConstants.PROPERTYSIZE_SQFT));
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTY_REFERENCE, propertyDetails.get(CreditBusinessConstants.PROPERTY_REFERENCE));
		propertyDetailsJsonObject.put(CreditBusinessConstants.BUILDER_NAME, propertyDetails.get(CreditBusinessConstants.BUILDER_NAME));
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROJECT_NAME, propertyDetails.get(CreditBusinessConstants.PROJECT_NAME));
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTY_COST, propertyDetails.get(CreditBusinessConstants.PROPERTY_COST));
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTY_STATUS, propertyDetails.get(CreditBusinessConstants.PROPERTY_STATUS));
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTY_TYPE, propertyDetails.get(CreditBusinessConstants.PROPERTY_TYPE));
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTY_USAGE, propertyDetails.get(CreditBusinessConstants.PROPERTY_USAGE));
		propertyDetailsJsonObject.put(CreditBusinessConstants.SEARCH_ASSIST_REQUIRED, propertyDetails.get(CreditBusinessConstants.SEARCH_ASSIST_REQUIRED));
		propertyDetailsJsonObject.put(CreditBusinessConstants.CUSTOMER_BUDGET, propertyDetails.get(CreditBusinessConstants.CUSTOMER_BUDGET));
		propertyDetailsJsonObject.put(CreditBusinessConstants.PROPERTY_MARKET_VALUE, propertyDetails.get(CreditBusinessConstants.PROPERTY_MARKET_VALUE));
		execution.setVariable(CreditBusinessConstants.TYPE_KEY, masterDataRedisClientHelper.getAddressTypeKeyForCode(CreditBusinessConstants.ADDRESS_TYPE_PROPERTY));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, propertyDetailsJsonObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preAdditionalPropertyDetails");
	}
	
	@SuppressWarnings("unchecked")
	public void updateAdditionalPropertyaddress(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start addressUpdate");
		JSONObject additionalPropertyDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject pinCode = CreditBusinessHelper.getJSONObject(additionalPropertyDetails.get(PINCODE2));
		JSONObject addressObject = new JSONObject();
		JSONObject verification = new JSONObject();
		addressObject.put(ADDRESS_LINE1, pinCode.get("addressLine1"));
		addressObject.put(ADDRESS_LINE2, pinCode.get("addressLine2"));
		addressObject.put(ADDRESS_SOURCE, "JOURNEY");
		addressObject.put(ADDRESS_TYPE_KEY, masterDataRedisClientHelper.getAddressTypeKeyForCode(CreditBusinessConstants.ADDRESS_TYPE_PROPERTY));
		if(null != pinCode.get(PINCODE2)) {
			JSONObject city = CreditBusinessHelper.getJSONObject(pinCode.get(CITY2));
			JSONObject country = CreditBusinessHelper.getJSONObject(pinCode.get(COUNTRY2));
			JSONObject state = CreditBusinessHelper.getJSONObject(pinCode.get(STATE2));
			addressObject.put(CITY_KEY, (String.format("%.0f", city.get(KEY))));
			addressObject.put(COUNTRY_KEY, (String.format("%.0f", country.get(KEY))));
			addressObject.put(PINCODE2, null != pinCode.get(PINCODE2) ? pinCode.get(PINCODE2) : null);
			addressObject.put(PINCODE_KEY, null != pinCode.get(PINCODE2) ? pinCode.get(PINCODE2) : null);
			addressObject.put(STATE_KEY, (String.format("%.0f", state.get(KEY))));
		}
		else {
			JSONObject addrObject = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
			addressObject.put(CITY_KEY, addrObject.get(CITY_KEY));
			addressObject.put(COUNTRY_KEY, addrObject.get(COUNTRY_KEY));
			addressObject.put(PINCODE2, null != addrObject.get(PINCODE2) ? addrObject.get(PINCODE2) : null);
			addressObject.put(PINCODE_KEY, null != addrObject.get(PINCODE_KEY) ? addrObject.get(PINCODE_KEY) : null);
			addressObject.put(STATE_KEY, addrObject.get(STATE_KEY));
		}
		verification.put(CreditBusinessConstants.IS_VERIFIED, false);
		verification.put(CreditBusinessConstants.VERIFICATION_DATE, "");
		verification.put(CreditBusinessConstants.VERIFICATION_SOURCE, "");
		verification.put(CreditBusinessConstants.VERIFIEDFOR, "");
		addressObject.put(VERIFICATION2, verification);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, addressObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End addressUpdate");

	}
	
	@SuppressWarnings("unchecked")
	public void preAdditionalDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAdditionalDetails");
		JSONObject additionalDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject additionalDetailObj = new JSONObject();
		String fullName = null != additionalDetails.get(CO_APP_NAME) ? (String) additionalDetails.get(CO_APP_NAME) : null;
		int idx = fullName.lastIndexOf(' ');
		if (idx == -1)
			throw new IllegalArgumentException("Only a single name: " + fullName);
		JSONObject nameObj = new JSONObject();
		nameObj.put(CreditBusinessConstants.FIRST_NAME, fullName.substring(0, fullName.indexOf(' ')));
		nameObj.put(CreditBusinessConstants.MIDDLE_NAME, fullName.substring(fullName.indexOf(' '), idx).trim());
		nameObj.put(CreditBusinessConstants.LAST_NAME, fullName.substring(idx + 1));
		additionalDetailObj.put(CreditBusinessConstants.NAME, nameObj);
		additionalDetailObj.put(CreditBusinessConstants.GENDER,(String.format("%.0f", additionalDetails.get(CO_APP_GENDER))));
		additionalDetailObj.put(CreditBusinessConstants.MARITALSTATUS, (String.format("%.0f", additionalDetails.get(CO_APP_MARITAL_STATUS))));
		additionalDetailObj.put(CreditBusinessConstants.PAN, null != additionalDetails.get(CO_APP_PAN) ? additionalDetails.get(CO_APP_PAN) : null);
		additionalDetailObj.put(CreditBusinessConstants.DATE_OF_BIRTH, null != additionalDetails.get(CO_APP_DOB) ? additionalDetails.get(CO_APP_DOB) : null);
		additionalDetailObj.put(CreditBusinessConstants.EMAIL, null != additionalDetails.get(CO_APP_EMAIL) ? additionalDetails.get(CO_APP_EMAIL) : null);
		JSONObject mobileObj = new JSONObject();
		mobileObj.put("number", null != additionalDetails.get(CO_APP_MOBILE) ? additionalDetails.get(CO_APP_MOBILE) : null);
		additionalDetailObj.put(CreditBusinessConstants.MOBILE_NUMBER, mobileObj);
		additionalDetailObj.put(CreditBusinessConstants.APPLICANTKEY, execution.getVariable(CreditBusinessConstants.APPLICANTID));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, additionalDetailObj);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preAdditionalDetails");
	}
}
