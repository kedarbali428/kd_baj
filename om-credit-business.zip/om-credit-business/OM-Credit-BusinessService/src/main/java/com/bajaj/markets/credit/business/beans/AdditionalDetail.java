package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class AdditionalDetail implements Serializable {

	private static final long serialVersionUID = 2703536940790674814L;

	private String applicationid;
	private String l3ProductCode;
	private List<Address> addressDetails;
	private String motherName;
	private String fatherName;
	private Reference qualification;
	private Boolean deliveryAddressFlag;
	private Boolean cppFlag;
	private String action;
	private Long principalKey;
	private List<PrincipalFeature> principalFeatures;
	private Reference occupationType;
	private Reference industryType;
	private Address partnerAddressDetails;
	private String customerType;
	private Address otherAddressDetails;
	private String workEmailId;
	private String alternateMobileNumber;
	private Reference empSectorService;
	private Reference businessNature;
	private Reference applicantIdProof;
	private Reference addressProof;
	private Double annualItr;
	private boolean hasSalaryAccount;
	private String appointmentDateTimeFrom;
	private String appointmentDateTimeTo;
	private String appointmentAddressTypeCode;
	
	@Size(max = 22, message = "Name to printed on card must be maximum of 22 characters")
	@Pattern(regexp = "^[A-Za-z]{1,}[\\.]{0,1}[\\s]{0,1}[A-Za-z]{1,}[\\.]{0,1}[\\s]{0,1}[A-Za-z]{0,}[\\.]{0,1}$", message = "Name to printed on card must be alphabets and of maximum 22 characters")
	private String nameToBePrintedOnCard;
	private String customerFullName;
	private RelationReference relationReference;
	
	public boolean isHasSalaryAccount() {
		return hasSalaryAccount;
	}

	public void setHasSalaryAccount(boolean hasSalaryAccount) {
		this.hasSalaryAccount = hasSalaryAccount;
	}

	public String getAppointmentDateTimeFrom() {
		return appointmentDateTimeFrom;
	}

	public void setAppointmentDateTimeFrom(String appointmentDateTimeFrom) {
		this.appointmentDateTimeFrom = appointmentDateTimeFrom;
	}

	public String getAppointmentDateTimeTo() {
		return appointmentDateTimeTo;
	}

	public void setAppointmentDateTimeTo(String appointmentDateTimeTo) {
		this.appointmentDateTimeTo = appointmentDateTimeTo;
	}

	public String getAppointmentAddressTypeCode() {
		return appointmentAddressTypeCode;
	}

	public void setAppointmentAddressTypeCode(String appointmentAddressTypeCode) {
		this.appointmentAddressTypeCode = appointmentAddressTypeCode;
	}

	public Reference getApplicantIdProof() {
		return applicantIdProof;
	}

	public void setApplicantIdProof(Reference applicantIdProof) {
		this.applicantIdProof = applicantIdProof;
	}

	public Reference getAddressProof() {
		return addressProof;
	}

	public void setAddressProof(Reference addressProof) {
		this.addressProof = addressProof;
	}

	private String principalCode;
	
	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public List<Address> getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(List<Address> addressDetails) {
		this.addressDetails = addressDetails;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public Reference getQualification() {
		return qualification;
	}

	public void setQualification(Reference qualification) {
		this.qualification = qualification;
	}

	public Boolean getDeliveryAddressFlag() {
		return deliveryAddressFlag;
	}

	public void setDeliveryAddressFlag(Boolean deliveryAddressFlag) {
		this.deliveryAddressFlag = deliveryAddressFlag;
	}

	public Boolean getCppFlag() {
		return cppFlag;
	}

	public void setCppFlag(Boolean cppFlag) {
		this.cppFlag = cppFlag;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public List<PrincipalFeature> getPrincipalFeatures() {
		return principalFeatures;
	}

	public void setPrincipalFeatures(List<PrincipalFeature> principalFeatures) {
		this.principalFeatures = principalFeatures;
	}
	
	public Reference getOccupationType() {
		return occupationType;
	}

	public void setOccupationType(Reference occupationType) {
		this.occupationType = occupationType;
	}

	public Reference getIndustryType() {
		return industryType;
	}

	public void setIndustryType(Reference industryType) {
		this.industryType = industryType;
	}

	public Address getPartnerAddressDetails() {
		return partnerAddressDetails;
	}

	public void setPartnerAddressDetails(Address partnerAddressDetails) {
		this.partnerAddressDetails = partnerAddressDetails;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public Address getOtherAddressDetails() {
		return otherAddressDetails;
	}

	public void setOtherAddressDetails(Address otherAddressDetails) {
		this.otherAddressDetails = otherAddressDetails;
	}
	public String getWorkEmailId() {
		return workEmailId;
	}

	public void setWorkEmailId(String workEmailId) {
		this.workEmailId = workEmailId;
	}
	
	public String getAlternateMobileNumber() {
		return alternateMobileNumber;
	}

	public void setAlternateMobileNumber(String alternateMobileNumber) {
		this.alternateMobileNumber = alternateMobileNumber;
	}
	
	public Double getAnnualItr() {
		return annualItr;
	}

	public void setAnnualItr(Double annualItr) {
		this.annualItr = annualItr;
	}

	public String getNameToBePrintedOnCard() {
		return nameToBePrintedOnCard;
	}

	public void setNameToBePrintedOnCard(String nameToBePrintedOnCard) {
		this.nameToBePrintedOnCard = nameToBePrintedOnCard;
	}
	
	public RelationReference getRelationReference() {
		return relationReference;
	}
	
	public void setRelationReference(RelationReference relationReference) {
		this.relationReference = relationReference;
	}
	
	public String getCustomerFullName() {
		return customerFullName;
	}
	
	public void setCustomerFullName(String customerFullName) {
		this.customerFullName = customerFullName;
	}

	public Reference getEmpSectorService() {
		return empSectorService;
	}

	public void setEmpSectorService(Reference empSectorService) {
		this.empSectorService = empSectorService;
	}

	public Reference getBusinessNature() {
		return businessNature;
	}

	public void setBusinessNature(Reference businessNature) {
		this.businessNature = businessNature;
	}

	public String getPrincipalCode() {
		return principalCode;
	}

	public void setPrincipalCode(String principalCode) {
		this.principalCode = principalCode;
	}

	@Override
	public String toString() {
		return "AdditionalDetail [applicationid=" + applicationid + ", l3ProductCode=" + l3ProductCode
				+ ", addressDetails=" + addressDetails + ", motherName=" + motherName + ", fatherName=" + fatherName
				+ ", qualification=" + qualification + ", deliveryAddressFlag=" + deliveryAddressFlag + ", cppFlag="
				+ cppFlag + ", action=" + action + ", principalKey=" + principalKey + ", principalFeatures="
				+ principalFeatures + ", occupationType=" + occupationType + ", industryType=" + industryType
				+ ", partnerAddressDetails=" + partnerAddressDetails + ", customerType=" + customerType
				+ ", otherAddressDetails=" + otherAddressDetails + ", workEmailId=" + workEmailId
				+ ", alternateMobileNumber=" + alternateMobileNumber  + ", empSectorService="
				+ empSectorService + ", businessNature=" + businessNature + ", annualItr=" + annualItr
				+ ", nameToBePrintedOnCard=" + nameToBePrintedOnCard + ", customerFullName=" + customerFullName
				+ ", relationReference=" + relationReference + ", principalCode=" + principalCode + "]";
	}
}