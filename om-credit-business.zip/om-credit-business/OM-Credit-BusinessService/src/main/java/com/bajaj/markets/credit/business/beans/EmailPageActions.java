package com.bajaj.markets.credit.business.beans;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.fasterxml.jackson.annotation.JsonCreator;

public enum EmailPageActions {
	
	VALIDATEEMAILTOKEN("validatetoken"),
	VALIDATE("validate"),
	VERIFIED("verified"),
	RESENDOTP("resend"),
	BACK("back");
	
	private String value;
	
	EmailPageActions(String value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
	    return value;
	}
	
	@SuppressWarnings("deprecation")
	@JsonCreator
	public static EmailPageActions fromValue(String value) {
		for (EmailPageActions action : EmailPageActions.values()) {
			if(value.equals(action.toString())) {
				return action;
			}
		}
		BFLLoggerUtil.debug(null, EmailPageActions.class.getCanonicalName(), BFLLoggerComponent.CONTROLLER, "requested action is not available with emailpageactions enum");
		return null;
	}
	
}
