package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REJECTED_STATUS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SUB_STAGE_PERCENTAGE;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ChildApplication;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.Fees;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.ObligationDetail;
import com.bajaj.markets.credit.business.beans.OccupationReference;
import com.bajaj.markets.credit.business.beans.PricingDetail;
import com.bajaj.markets.credit.business.beans.PricingFees;
import com.bajaj.markets.credit.business.beans.PrincipalBean;
import com.bajaj.markets.credit.business.beans.Product;
import com.bajaj.markets.credit.business.beans.ProductList;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EtbVariantEnum;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.OMProductToBauProduct;
import com.bajaj.markets.credit.business.helper.ProductCodeEnum;
import com.bajaj.markets.credit.business.helper.RejectionSystemSourceEnum;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.listner.NotificationListener;
import com.bajaj.markets.credit.business.service.CreditBusinessProductListService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

/**
 * Service to perform operations on Product List resource
 * 
 * @author 764504
 *
 */
@Service
public class CreditBusinessProductListServiceImpl implements CreditBusinessProductListService {

	private static final long LISTING_PERCENTAGE = 50L;
	private static final String OM_PERSONAL_LOAN_DESC = "OM Personal loan";
	private static final String LOANAGAINSTPROPERTYBALTRANSFER = "LAPBT";
	private static final String HOMELOANBALANCETRANSFER = "HLBT";
	private static final String LOANAGAINSTPROPERTY = "LAP";
	private static final String HOMELOANFRESH = "HLF";
	private static final String APPLICATIONID = "applicationid";
	

	@Autowired
	private CreditBusinessHelper creditBusinessHelper;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	WorkflowHelper workflowHelper;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	@Autowired
	private NotificationListener notificationListener;

	private static final String OPEN_ARC_CARD_LIST_INPUT = "openArcCardListingInput";

	@Value("${api.applicationservice.productlist.showonlyeligible.get.url}")
	private String getProductListUrl;

	@Value("${api.omcreditapplicationservice.creditapplication.get.url}")
	private String getApplicationUrl;

	@Value("${api.omcreditapplicationservice.userprofiles.get.url}")
	private String getUserProfilesUrl;

	@Value("${api.omcreditapplicationservice.mcpdetails.get.url}")
	private String getBreRequestUrl;

	@Value("${api.omcreditproductrecommendationservice.l2recommendation.post.url}")
	private String listingBrePostUrl;

	@Value("${api.omcibilverificationservice.cibil.get.url}")
	private String getCibilReferenceKeyUrl;

	@Value("${api.omcibilverificationservice.cibil.details.get.url}")
	private String getCibilDocumentUrl;

	@Value("${api.omcreditapplicationservice.update.recommendation.put.url}")
	private String putBreResponse;

	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String getChildApplicationsUrl;

	@Value("${api.omcreditcardsprincipalintegrationservice.derog.url}")
	private String derogUrl;

	@Value("${api.omreferencedatareferencedataservice.location.pincodekey.get.url}")
	private String getAddressOnPincodeKeyUrl;

	@Value("${api.omcreditcardsprincipalintegrationservice.obligation.PUT.url}")
	private String obligationUrl;
	
	@Value("${api.omcreditapplicationservice.updatestage.put.url}")
	private String updateStageUrl;

	@Value("${api.omcreditapplicationservice.creditapplication.PUT.url}")
	private String putApplicationUrl;

	@Autowired
	private CreditBusinessGinHelper ginFlowHelper;

	@Autowired
	private MasterDataRedisClientHelper redisHelper;
	
	@Autowired
	private CreditBusinessApiCallsHelper creditBusinessApiCallsHelper;

	private static final String CLASSNAME = CreditBusinessProductListServiceImpl.class.getName();

	/**
	 * @implNote
	 * Method used to fetch product listing. For credit cards it calls ApplicationService's API and for Loans it calls BRE  to fetch it. 
	 *  
	 * @param Long applicationId 
	 * @return ProductList
	 */
	@Override
	public ResponseEntity<ProductList> getProductList(String applicationId, Double loanAmount, Double tenure, Integer isSmallTicket) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "getProductList started");
		ResponseEntity<ProductList> orchestrationResponse = null;
		if (!StringUtils.isNumeric(applicationId)) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Field validation exception.");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_020", "ApplicationId should be numeric."));
		}
		try {
			Map<String, String> queryParam = new HashMap<>();
			queryParam.put(APPLICATIONID, applicationId);
			ApplicationDetail appDetails = callApi(getApplicationUrl, HttpMethod.GET, queryParam, null, ApplicationDetail.class);
			
			if(null != loanAmount && null != tenure) {	
				Map<String,Object> applicationParam = new HashMap<>();
				Map<String,Object> applicationParameter = new HashMap<>();
				applicationParameter.put("applicationParameters",applicationParam);
				applicationParam.put("requestedCreditAmount",loanAmount.intValue());
				applicationParam.put("requestedTenureMonths",tenure.intValue());
				ObjectMapper mapper = new ObjectMapper();
				String applicationParamRequest = mapper.writeValueAsString(applicationParameter);
				creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, putApplicationUrl, Object.class, queryParam, applicationParamRequest,new HttpHeaders());
			}
			
			if (appDetails != null) {
				Map<String, String> params = new HashMap<>();
				params.put(APPLICATIONID, applicationId);
				UserProfileBean userProfile = apiCallsHelper.getUserProfile(params);
				Name username = userProfile.getName();
				if (ProductCodeEnum.CREDIT_CARD.getValue().equalsIgnoreCase(appDetails.getL2ProductCode())) {
					orchestrationResponse = getProductListForApplication(applicationId);
				} else if (ProductCodeEnum.LOANS.getValue().equalsIgnoreCase(appDetails.getL2ProductCode())
						|| ProductCodeEnum.SECUREDLOANS.getValue().equalsIgnoreCase(appDetails.getL2ProductCode())) {
					orchestrationResponse = getProductListForLoan(applicationId, loanAmount, tenure, isSmallTicket, userProfile);
				}
				ProductList productList = orchestrationResponse != null ? orchestrationResponse.getBody() : null;
				productList.setName(username);
				updateRejectionFlag(orchestrationResponse, applicationId);
			}
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured while fetching card list ", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Some techical error occured while fetching card list ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("OMCB_021", "Some techical error occured while fetching card list"));
		}
		return orchestrationResponse;
	}

	private void updateRejectionFlag(ResponseEntity<ProductList> orchestrationResponse, String applicationId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside updateForRejectionFlag, applicationId : " + applicationId);
		if (null != orchestrationResponse && null != orchestrationResponse.getBody()
				&& !CollectionUtils.isEmpty(orchestrationResponse.getBody().getProductList())) {

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HashMap<String, String> params = new HashMap<>();
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			params.put("applicationkey", applicationId);
			params.put("isInProcessing", "false");
			ResponseEntity<?> childApplicationListRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getChildApplicationsUrl, List.class, params,
					null, headers);
			List<ApplicationDetail> childApplicationList = mapper.convertValue(childApplicationListRes.getBody(), new TypeReference<List<ApplicationDetail>>() {
			});
			Map<String, Integer> childMap = new HashMap<>();
			childApplicationList.forEach(child -> {
				childMap.put(child.getL3ProductCode(), child.getApplicationStatus());
			});
			orchestrationResponse.getBody().getProductList().forEach(product -> {
				if (childMap.containsKey(product.getProductCode())) {
					product.setChildStatus(childMap.get(product.getProductCode()));
				} else {
					product.setChildStatus(0);
				}
			});
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End updateForRejectionFlag, applicationId : " + applicationId);
	}

	@SuppressWarnings("unchecked")
	public ApplicationResponse createProductApplication(ChildApplication childApplication, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start createProductApplication ChildApplication resource :" + childApplication);

		Map<String, Object> vars = new HashMap<>();
		vars.put(CreditBusinessConstants.REQUEST, childApplication);
		vars.put("action", childApplication.getAction() != null ? childApplication.getAction().toLowerCase() : "next");
		vars.put(CreditBusinessConstants.FPPSELECTED, childApplication.getIsFppSelected());
		try {
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			Boolean pennantFlag = (Boolean) workflowHelper.getFromExecutionMap("pennantSuccess", headers.get(CreditBusinessConstants.PROCESS_ID).get(0));
			JSONObject payload = (JSONObject) workflowHelper.getFromExecutionMap("ChildApplicationResponse",
					headers.get(CreditBusinessConstants.PROCESS_ID).get(0));
			if (payload != null) {
			payload.put(CreditBusinessConstants.PENNENT_SUCCESS, pennantFlag);
			}

			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End createProductApplication");
			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			ApplicationResponse applicationResponse = new ApplicationResponse();
			applicationResponse.setNextTask(task);
			applicationResponse.setPayload(payload);
			return applicationResponse;
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "CreditBusinessException occured while completing activiti task", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured while completing activiti task", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("OMCB_20", "Some technical exception occured while completing activiti task"));
		}
	}

	@SuppressWarnings({ "unchecked"})
	private ResponseEntity<ProductList> getProductListForApplication(String applicationId) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getProductListForCards ");
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put(APPLICATIONID, applicationId);
		queryParam.put("showonlyeligible", "true");
		ResponseEntity<ProductList> apiResponse = (ResponseEntity<ProductList>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getProductListUrl,
				ProductList.class, queryParam, null, new HttpHeaders());
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "Response = " + apiResponse);
		
		List<PrincipalBean> principalDetails = creditBusinessApiCallsHelper.getPrincipalDetails();

		Map<Long, String> principalMap = principalDetails.stream()
				.collect(Collectors.toMap(PrincipalBean::getPrinciplekey, PrincipalBean::getPrincipleCode));

		apiResponse.getBody().getProductList()
				.forEach(product -> product.setPrincipalCode(principalMap.get(product.getPrincipalKey())));
		
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "End getProductListForCards ");
		return new ResponseEntity<>(apiResponse.getBody(), apiResponse.getStatusCode());
	}

	/**
	 * @implNote Method used to call listing BRE for Loans and  update app_product_listing using AppliacationService's API
	 * If loanAmount and tenure is not passed then it checks record is present in app_product_listing for same  application + l3 + l4 
	 * and picks requiredLoanAmount & tenure from it otherwise it passes null to BRE. 
	 * 
	 * @param applicationId
	 * @param loanAmount
	 * @param tenure
	 * @param isSmallTicket
	 * @param userAttributeKey
	 * @return ProductList
	 */
	@SuppressWarnings("unchecked")
	private ResponseEntity<ProductList> getProductListForLoan(String applicationId, Double loanAmount, Double tenure, Integer isSmallTicket,
			UserProfileBean userProfile) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getProductListForLoan for applicationId: "+applicationId);
		HashMap<String, String> params = new HashMap<>();
		params.put(APPLICATIONID, applicationId);
		String occupationDesc = null;
		JSONObject breRequest = new JSONObject();
		JSONObject openArcCardListingInput = new JSONObject();
		ProductList prodList = null;
		try {
			openArcCardListingInput.put("applicationId", applicationId);
			openArcCardListingInput.put("eligibilityType", "AIP");

			String userAttributeKey = userProfile.getApplicationUserAttributeKey();
			if (!StringUtils.isEmpty(userAttributeKey)) {
				params.put("userattributekey", userAttributeKey);
				JSONObject mcpRequest = callApi(getBreRequestUrl, HttpMethod.GET, params, null, JSONObject.class);
				occupationDesc = getOccupationDesc(params);
				openArcCardListingInput.put("occupationType", occupationDesc);

				setDataFromMcpRequest(params, openArcCardListingInput, mcpRequest,  loanAmount, tenure, isSmallTicket);

				setCibilData(openArcCardListingInput, params, userProfile.getApplicantKey());

				if (mcpRequest.get("addressList") != null) {
					List<Map<String, Object>> addressList = (List<Map<String, Object>>) mcpRequest.get("addressList");
					if (!CollectionUtils.isEmpty(addressList)) {
						Map<String, Object> address = addressList.get(0);
						if (address.get("pincodeKey") != null) {
							com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean locationAddressBean = redisHelper
									.getPinCodeByKey(Long.parseLong(address.get("pincodeKey").toString()));
							Object derogResponse = getDerog(openArcCardListingInput.get("cibilJson"), applicationId, mcpRequest,
									locationAddressBean.getCityName(), occupationDesc);
							openArcCardListingInput.put(CreditBusinessConstants.DEROG_JSON, CreditBusinessHelper.objectToJson(derogResponse));
								populateObligation(openArcCardListingInput, applicationId, mcpRequest,
										locationAddressBean.getCityName(), occupationDesc);
								
						}
				    }
				}
				
				breRequest.put(OPEN_ARC_CARD_LIST_INPUT, openArcCardListingInput);

				String productDesc = openArcCardListingInput.get("product") != null ? openArcCardListingInput.get("product").toString() : null;
				String jsonApplicationRequest = CreditBusinessHelper.objectToJson(breRequest);
				JSONObject breOutput = callLisitingBre(jsonApplicationRequest, productDesc);
				if (breOutput != null && breOutput.get("openArcCardListingOutput") != null) {
					JSONObject listingOutput = CreditBusinessHelper.getJSONObject(breOutput.get("openArcCardListingOutput"));
					listingOutput.put("openArcCardListing", null);
					breOutput.put("openArcCardListingOutput", listingOutput);
					breOutput.put("rejectionSystem", RejectionSystemSourceEnum.LISTBREAPI.getValue());
					breOutput.put("sendNotification", false);
					JSONObject[] breUpdateOutput = updateBreResponse(breOutput, applicationId);
					
					//check for stage percentage if 30% send out notification event and update stage percentage to 50%
					this.triggerNotificationEventAndUpdateStage(applicationId, mcpRequest);
					//Mapping output of update call
					prodList = mapBreOutput(listingOutput, breUpdateOutput, loanAmount, tenure, productDesc);
					setPricingDataForHonouredEpPricing(applicationId, prodList);
				}
				logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "End getProductListForLoan ");
				return new ResponseEntity<ProductList>(prodList, HttpStatus.OK);
			} else {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured while Getting user attribute");
				throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "User Attribute not present"));
			}
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Error occurred while getting card list for loans ", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Error occurred while getting card list from BRE", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-106", "Error occurred while getting card list from BRE"));
		}
	}

	@SuppressWarnings("unchecked")
	private void populateObligation(JSONObject openArcCardListingInput, String applicationId, JSONObject mcpRequest,
			String cityName, String occupationDesc) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Start populateObligation for applicationId: " + applicationId);
		Object obligationResponse = null;

		JSONObject obligationRequest = new JSONObject();
		if (mcpRequest.get("appScoreDetails") != null) {
			JSONObject appScore = CreditBusinessHelper.getJSONObject(mcpRequest.get("appScoreDetails"));
			obligationRequest.put(CreditBusinessConstants.APP_SCORE,
					appScore.get("finalScore") != null ? Float.valueOf(appScore.get("finalScore").toString()) : null);
		}
		obligationRequest.put(CreditBusinessConstants.APPLICANT_ID, null);
		obligationRequest.put(CreditBusinessConstants.APPLICATIONID, applicationId);
		obligationRequest.put(CreditBusinessConstants.BRANCHNAME, cityName);
		Object cibilJson = openArcCardListingInput.get("cibilJson");
		obligationRequest.put(CreditBusinessConstants.CIBILRESPONSEJSON, CreditBusinessHelper.getJSONObject(cibilJson));
		obligationRequest.put(CreditBusinessConstants.CUSTOMERID, null);
		if(null != mcpRequest.get(CreditBusinessConstants.HLPRODUCTINTENT)) {
			obligationRequest.put(CreditBusinessConstants.PRODUCTTYPE, "OM Secured Loan");
		}else {
		obligationRequest.put(CreditBusinessConstants.PRODUCTTYPE, "OM Personal Loan");
		}
		obligationResponse = callApi(obligationUrl, HttpMethod.PUT, null,
				CreditBusinessHelper.objectToJson(obligationRequest), Object.class);
		JSONObject obligationJSON = CreditBusinessHelper.getJSONObject(obligationResponse);
		if (null != mcpRequest.get(CreditBusinessConstants.HLPRODUCTINTENT)) {
			List<Map<String, Object>> obligationDetailsList = (List<Map<String, Object>>) obligationJSON.get("emiList");
			List<ObligationDetail> obligationList = null;
			if (!obligationDetailsList.isEmpty()) {
				obligationList = new ArrayList<>();
				for (Map<String, Object> obligation : obligationDetailsList) {
					ObligationDetail details = new ObligationDetail();
					details.setAccountType(
							obligation.get("accountType") != null ? obligation.get("accountType").toString() : null);
					details.setCurrentBalance((obligation.get("currentBalance") != null
							&& !obligation.get("currentBalance").toString().equals(""))
									? Integer.parseInt(obligation.get("currentBalance").toString())
									: 0);
					details.setEmiAmount(
							(obligation.get("emiAmount") != null && !obligation.get("emiAmount").equals(""))
									? Integer.parseInt(obligation.get("emiAmount").toString())
									: 0);
					if (obligation.get("mob") != null) {
						double m = Double.parseDouble(obligation.get("mob").toString());
						Integer mob = (int) m;
						details.setMob(mob);
					}
					details.setReportingShortName(obligation.get("reportingShortName") != null
							? obligation.get("reportingShortName").toString()
							: null);
					details.setHighCreditSanctionAmt((obligation.get("highCreditSanctionAmt") != null
							&& !obligation.get("highCreditSanctionAmt").toString().equals(""))
									? Integer.parseInt(obligation.get("highCreditSanctionAmt").toString())
									: 0);
					obligationList.add(details);
				}
			}
			openArcCardListingInput.put("obligationDetailList", obligationList);
		} else {
			openArcCardListingInput.put("obligationJson", obligationJSON.get("obligationJson"));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"End populateObligation for applicationId: " + applicationId);
	}

	private JSONObject[] updateBreResponse(JSONObject breOutput, String applicationId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start updateBreResponse");
		JSONObject[] output = null;
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put(APPLICATIONID, applicationId);
		String requestString = breOutput != null ? CreditBusinessHelper.objectToJson(breOutput) : null;
		if (!StringUtils.isEmpty(requestString)) {
			output = callApi(putBreResponse, HttpMethod.PUT, queryParam, requestString, JSONObject[].class);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Update Response :: " + output);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End updateBreResponse");
		return output;
	}

	private JSONObject callLisitingBre(String requestString, String productDesc) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start callLisitingBre");
		Map<String, String> queryParam = new HashMap<>();
		queryParam.put("productcode", productDesc);
		JSONObject breOutput = null;
		breOutput = callApi(listingBrePostUrl, HttpMethod.POST, queryParam, requestString, JSONObject.class);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End callLisitingBre BRE Response :: " + breOutput);
		return breOutput;
	}

	private String getOccupationDesc(Map<String, String> params) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start getOccupationDesc");
		OccupationReference occRef = apiCallsHelper.getOccupationValue(params);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End getOccupationDesc");
		if (occRef != null)
			return occRef.getOccupationValue();

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End getOccupationDesc no occupation found");
		return null;
	}

	private void setDataFromMcpRequest(Map<String, String> params, JSONObject openArcCardListingInput, JSONObject mcpRequest, Double reqLoanAmount,
			Double reqTenure, Integer isSmallTicket) throws Exception {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start  setDataFromMcpRequest " + openArcCardListingInput);
		if (mcpRequest != null && mcpRequest.get("prodCategory") != null) {
			JSONObject productCategory = CreditBusinessHelper.getJSONObject(mcpRequest.get("prodCategory"));
			JSONObject occupation = CreditBusinessHelper.getJSONObject(mcpRequest.get("occupation"));
			JSONObject occupationType = CreditBusinessHelper.getJSONObject(occupation.get("ocupationType"));
			Double occTypeKey = Double.parseDouble(occupationType.get("key").toString());
			EtbVariantEnum etbVariant = ginFlowHelper.checkEtbVariantFromAppOfferDet(openArcCardListingInput.get("applicationId").toString(),
					occTypeKey.longValue(), productCategory.get("prodCatCode").toString());
			if (etbVariant != null && etbVariant.equals(EtbVariantEnum.GIN)) {
				ginFlowHelper.prepareBreRequestForGinFlow(openArcCardListingInput, mcpRequest, reqLoanAmount, reqTenure, isSmallTicket);
			} else {
			creditBusinessHelper.populateBreRequestFromMcpDetails(openArcCardListingInput, mcpRequest, false, reqLoanAmount, reqTenure, isSmallTicket);
			}
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Error occurred while fething request for BRE");
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-102", "Error occurred while fething request for BRE"));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End setDataFromMcpRequest");
	}

	@SuppressWarnings("unchecked")
	private void setCibilData(JSONObject openArcCardListingInput, Map<String, String> params, String applicantKey) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start setCibilData");
		String cibilType = null;
		openArcCardListingInput.put("cibilJson", null);
		openArcCardListingInput.put("cibilType", null);
		openArcCardListingInput.put("cibilScore", null);
		params.put("cibiltype", "");
		params.put("applicationkey", params.get("applicationid"));
		params.put("applicantkey", applicantKey);
		
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("applicationid", params.get("applicationid"));
		queryParams.put("userattributekey", params.get("userattributekey"));
		DocumentDetails documentDetails = apiCallsHelper.getDocumentDetail(queryParams, 2l);
		
		params.put("cibilreferencekey", null != documentDetails && null != documentDetails.getDocumentNumber() && 
				documentDetails.getDocumentNumber().matches("\\d+") ? documentDetails.getDocumentNumber() : null);
		
		JSONObject[] referenceKeyRespArr = callApi(getCibilReferenceKeyUrl, HttpMethod.GET, params, null, JSONObject[].class);
		if (referenceKeyRespArr != null && referenceKeyRespArr.length > 0) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "CIBIL refernce key found now fetching CIBIL document");
			for (JSONObject referenceKeyResp : referenceKeyRespArr) {
				if (null != referenceKeyResp && null != referenceKeyResp.get("state") && referenceKeyResp.get("state").toString().equals("COMPLETED")) {
					if (referenceKeyResp.get("cibilTypeAndScore") != null) {
						List<Map<String, Object>> typeScoreList = (List<Map<String, Object>>) referenceKeyResp.get("cibilTypeAndScore");
						if (!CollectionUtils.isEmpty(typeScoreList) && typeScoreList.get(0).get("cibilType") != null) {
							cibilType = typeScoreList.get(0).get("cibilType").toString();
							openArcCardListingInput.put("cibilType", cibilType);
							openArcCardListingInput.put("cibilScore", typeScoreList.get(0).get("scoreV3"));
						}
					}

					if (referenceKeyResp.get("cibilReferenceNumber") != null) {
						Integer cibilReferenceKey = Double.valueOf(referenceKeyResp.get("cibilReferenceNumber").toString()).intValue();
						Map<String, String> qMap = new HashMap<>();
						qMap.put("cibilreference", String.valueOf(cibilReferenceKey));
						qMap.put("cibiltype", cibilType);
						qMap.put("format", "COMMERCIALCIBIL");
						String cibilDocumentResponse = callApi(getCibilDocumentUrl, HttpMethod.GET, qMap, null, String.class);
						logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "CIBIL document fetched");
						openArcCardListingInput.put("cibilJson", cibilDocumentResponse);
					}
					break;
				} else {
					Gson gson = new Gson();
					JSONObject cibilInactiveJson = new JSONObject();
					cibilInactiveJson.put("applicantKey", referenceKeyResp.get("applicantKey"));
					cibilInactiveJson.put("authenticationRequired", referenceKeyResp.get("authenticationRequired"));
					cibilInactiveJson.put("provider", referenceKeyResp.get("provider"));
					cibilInactiveJson.put("applicationKey", referenceKeyResp.get("applicationKey"));
					cibilInactiveJson.put("state", referenceKeyResp.get("state"));
					cibilInactiveJson.put("cibilReferenceNumber", referenceKeyResp.get("cibilReferenceNumber"));
					String cibilResponse = gson.toJson(cibilInactiveJson);
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "CIBIL document fetched");
					openArcCardListingInput.put("cibilJson", cibilResponse);						 
				}
			}

		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End setCibilData");
	}

	@SuppressWarnings("unchecked")
	private Object getDerog(Object cibilJson, String applicationId, JSONObject mcpRequest, String city, String occupationType) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start setDerog");
		Object derogResponse = null;
		Map<String, String> params = new HashMap<>();
		if (null != mcpRequest.get(CreditBusinessConstants.HLPRODUCTINTENT)) {
			params.put("l2ProductCode", CreditBusinessConstants.PRODUCT_CODE_OMSL);
		} else {
		params.put("l2ProductCode", CreditBusinessConstants.PRODUCT_CODE_OMPL);
		}

		JSONObject derogRequest = new JSONObject();
		if (mcpRequest.get("appScoreDetails") != null) {
			JSONObject appScore = CreditBusinessHelper.getJSONObject(mcpRequest.get("appScoreDetails"));
			derogRequest.put(CreditBusinessConstants.APP_SCORE,
					appScore.get("finalScore") != null ? Float.valueOf(appScore.get("finalScore").toString()) : null);
		}

		derogRequest.put(CreditBusinessConstants.APPLICANT_ID, null);
		derogRequest.put(CreditBusinessConstants.APPLICATIONID, applicationId);
		derogRequest.put(CreditBusinessConstants.BRANCHNAME, city);
		derogRequest.put(CreditBusinessConstants.CIBILRESPONSEJSON, CreditBusinessHelper.getJSONObject(cibilJson));
		derogRequest.put(CreditBusinessConstants.CUSTOMERID, null);
		if (null != mcpRequest.get(CreditBusinessConstants.HLPRODUCTINTENT)) {
			switch (mcpRequest.get(CreditBusinessConstants.HLPRODUCTINTENT).toString()) {
			case HOMELOANFRESH:
				derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, OMProductToBauProduct.getBauProd(HOMELOANFRESH));
				break;
			case LOANAGAINSTPROPERTY:
				derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, OMProductToBauProduct.getBauProd(LOANAGAINSTPROPERTY));
				break;
			case HOMELOANBALANCETRANSFER:
				derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, OMProductToBauProduct.getBauProd(HOMELOANBALANCETRANSFER));
				break;
			case LOANAGAINSTPROPERTYBALTRANSFER:
				derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, OMProductToBauProduct.getBauProd(LOANAGAINSTPROPERTYBALTRANSFER));
				break;
			}
			derogRequest.put(CreditBusinessConstants.SOURCE, CreditBusinessConstants.CONSUMER_CIBIL);
		} else {
			derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, occupationType);
			derogRequest.put(CreditBusinessConstants.SOURCE, CreditBusinessConstants.COMMERCIAL_CIBIL);
		}
		derogResponse = callApi(derogUrl, HttpMethod.PUT, params, CreditBusinessHelper.objectToJson(derogRequest), Object.class);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End setDerog");
		return derogResponse;
	}

	@SuppressWarnings("unchecked")
	private ProductList mapBreOutput(JSONObject breoutput, JSONObject[] updateOutput, Double requiredLoanAmt, Double requiredTenure, String l2ProductDesc) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "start mapBreOutput");
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ProductList productList = new ProductList();
		boolean isEligibleProductFound = false;
		if (breoutput != null && breoutput.get("openMarketsLoanListing") != null) {
			JSONObject listingOutputFromBre = CreditBusinessHelper.getJSONObject(breoutput.get("openMarketsLoanListing"));
			productList.setMaxEligibility((Double) listingOutputFromBre.get("maxEligibility"));
			productList.setMaxTenor((Double) listingOutputFromBre.get("maxTenor"));
			productList.setRequiredLoanAmout((Double) listingOutputFromBre.get("requiredLoanAmount"));
			productList.setRequiredTenor((Double) listingOutputFromBre.get("requiredTenor"));
			productList.setMinLoanAmountRequired((Double) listingOutputFromBre.get("minLoanAmountRequired"));
			productList.setMinTenorRequired((Double) listingOutputFromBre.get("minTenorRequired"));

			List<JSONObject> principleProductList = mapper.convertValue(listingOutputFromBre.get("principalProductDetails"),
					new TypeReference<List<JSONObject>>() {
					});

			List<Product> list = new ArrayList<>();
			for (Object priciple : updateOutput) {
				JSONObject principalProductDetails = CreditBusinessHelper.getJSONObject(priciple);
				String l3ProductCode = principalProductDetails.get("l3productCode") != null ? principalProductDetails.get("l3productCode").toString() : null;
				String l4ProductCode = principalProductDetails.get("l4ProductCode") != null ? principalProductDetails.get("l4ProductCode").toString() : null;
				String riskOfferTypefromService = principalProductDetails.get("riskoffertype") != null ? principalProductDetails.get("riskoffertype").toString() : "";
				
				JSONObject breProduct = getMatchingRecordFromBreOutput(principleProductList, l3ProductCode, l4ProductCode, riskOfferTypefromService);

				Product loanProduct = new Product();
				loanProduct.setDescription((String) principalProductDetails.get("description"));
				loanProduct.setProductCode((String) principalProductDetails.get("productCode"));
				loanProduct.setL3productCode(l3ProductCode);
				loanProduct.setL4ProductCode(l4ProductCode);
				loanProduct.setRiskOfferType(
						principalProductDetails.get("riskoffertype") != null ? principalProductDetails.get("riskoffertype").toString() : null);
				loanProduct
						.setbScore(principalProductDetails.get("bScore") != null ? BigDecimal.valueOf((Double) (principalProductDetails.get("bScore"))) : null);
				loanProduct.setEmi(principalProductDetails.get("emi") != null ? new BigDecimal(principalProductDetails.get("emi").toString()) : null);
				loanProduct.setRoi(principalProductDetails.get("roi") != null ? new BigDecimal(principalProductDetails.get("roi").toString()) : null);
				loanProduct.setFeature(principalProductDetails.get("feature") != null ? principalProductDetails.get("feature").toString() : null);
				loanProduct.setPromotionalOffer(
						principalProductDetails.get("promotionalOffer") != null ? principalProductDetails.get("promotionalOffer").toString() : null);
				loanProduct.setRewardPoint(principalProductDetails.get("rewardPoint") != null ? principalProductDetails.get("rewardPoint").toString() : null);
				Double productListingKey = (Double) principalProductDetails.get("productListingKey");
				loanProduct.setProductListingKey(null != productListingKey ? productListingKey.longValue() : null);
				loanProduct.setPriorityOrder(principalProductDetails.get("priorityOrder") != null
						? Double.valueOf(principalProductDetails.get("priorityOrder").toString()).intValue()
						: null);
				loanProduct.setIsSelected(principalProductDetails.get("principalSelectedByCustomer") != null
						? principalProductDetails.get("principalSelectedByCustomer").toString()
						: null);
				loanProduct.setApprovalChances(
						principalProductDetails.get("approvalChances") != null ? principalProductDetails.get("approvalChances").toString() : null);
				loanProduct.setCardTag(principalProductDetails.get("cardTag") != null ? principalProductDetails.get("cardTag").toString() : null);
				loanProduct.setCtaName(principalProductDetails.get("ctaName") != null ? principalProductDetails.get("ctaName").toString() : null);
				loanProduct.setEligibilityAmount(
						principalProductDetails.get("eligibilityAmount") != null ? new BigDecimal(principalProductDetails.get("eligibilityAmount").toString())
								: null);	
				loanProduct.setRequiredLoanAmount(breProduct.get("requiredLoanAmount") != null ? BigDecimal.valueOf((Double)(breProduct.get("requiredLoanAmount"))): null);
				loanProduct.setTenor(breProduct.get("tenor") != null ? BigDecimal.valueOf((Double)(breProduct.get("tenor"))): null);
				Double netDisbursementAmount = (Double) breProduct.get("netDisbursementAmount");
				loanProduct.setNetDisbursementAmount(null != netDisbursementAmount ? netDisbursementAmount.longValue(): null);
				if (principalProductDetails.get("isEligible") != null) {
					loanProduct.setIsEligible(BigDecimal.valueOf((Double) principalProductDetails.get("isEligible")));
					if (BigDecimal.ONE.intValue() == loanProduct.getIsEligible().intValue()) {
						isEligibleProductFound = true;
					}
				}
				loanProduct.setToBeDisplayedOnListingPage(
						principalProductDetails.get("toBeDisplayedOnListingPage") != null ? principalProductDetails.get("toBeDisplayedOnListingPage").toString()
								: null);

				if (breProduct != null && breProduct.get("usp") != null) {
					loanProduct.setUsp(mapper.convertValue(breProduct.get("usp"), new TypeReference<List<String>>() {
					}));
				}

				if (principalProductDetails.get("productSize") != null && "STS".equalsIgnoreCase((String) principalProductDetails.get("productSize"))) {
					loanProduct.setIsSmallTicket(BigDecimal.ONE);
				} else {
					loanProduct.setIsSmallTicket(BigDecimal.ZERO);
				}

				List<Fees> fees = null;
				Double totalFee = 0d;
				if (principalProductDetails.get("feesList") != null) {
					List<Map<String, Object>> feesList = (List<Map<String, Object>>) principalProductDetails.get("feesList");
					fees = new ArrayList<>();
					for (Map<String, Object> f : feesList) {
						Fees fee = new Fees();
						fee.setFeeCode((String) f.get("feeCode"));
						fee.setFeesInAmount(BigDecimal.valueOf((Double) (f.get("feesInAmount"))));
						fee.setFeesInPercent(BigDecimal.valueOf((Double) (f.get("feesInPercent"))));
						totalFee = Double.sum(totalFee, fee.getFeesInAmount().doubleValue());
						fees.add(fee);
					}
				}
				loanProduct.setFees(fees);
				loanProduct.setTotalFee(totalFee);

				if (principalProductDetails.get("loanTypeName") != null) {
					String loanTypeName = (String) principalProductDetails.get("loanTypeName");
					loanProduct.setLoanType(loanTypeName);
				}

				if (principalProductDetails.get("preApproved") != null) {
					if ("yes".equalsIgnoreCase((String) principalProductDetails.get("preApproved"))) {
						loanProduct.setLoanTag("PRE APPROVED");
					}
				}
				
				loanProduct.setHonouredPricingSource((String) principalProductDetails.get("honouredPricingSource"));
				if (CreditBusinessConstants.EP.equalsIgnoreCase(loanProduct.getHonouredPricingSource())) {
					productList.setIsEpPricingHonoured(true);
				}
				if (CreditBusinessConstants.YES.equalsIgnoreCase(loanProduct.getIsSelected())
						&& Boolean.parseBoolean(loanProduct.getToBeDisplayedOnListingPage())) {
					productList.setIsCardSelected(true);
				}				
				list.add(loanProduct);
			}

			if (l2ProductDesc != null && OM_PERSONAL_LOAN_DESC.equalsIgnoreCase(l2ProductDesc) && !isEligibleProductFound) {
				productList.setStatus(REJECTED_STATUS);
			}

			productList.setProductList(list);
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "start mapBreOutput");
		return productList;
	}

	/**
	 * Method returns matching record from BRE principleProduct list
	 * 
	 * @param principleProductList
	 * @param l3ProductCode
	 * @param l4ProductCode
	 * @return
	 */
	private JSONObject getMatchingRecordFromBreOutput(List<JSONObject> principleProductList, String l3ProductCode, String l4ProductCode, String riskOfferTypefromService) {
		for (JSONObject breProduct : principleProductList) {
			if (breProduct.get("principleProductCode") != null && breProduct.get("principleProductCode").toString().equals(l3ProductCode)
					&& breProduct.get("loanTypeRecommendation") != null && breProduct.get("loanTypeRecommendation").toString().equals(l4ProductCode)) {

				String riskOfferTypefromBRE = breProduct.get("riskOfferType") != null? breProduct.get("riskOfferType").toString(): "";
				if (riskOfferTypefromService.equalsIgnoreCase(riskOfferTypefromBRE)) {
					return breProduct;
				}
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	private <T> T callApi(String url, HttpMethod methodType, Map<String, String> queryParam, String requestJson, Class<T> responseType) {
		ResponseEntity<T> apiResponse = (ResponseEntity<T>) creditBusinessHelper.invokeRestEndpoint(methodType, url, responseType, queryParam, requestJson,
				new HttpHeaders());
		return apiResponse != null ? apiResponse.getBody() : null;
	}
	
	private void setPricingDataForHonouredEpPricing(String applicationId, ProductList prodList) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Start setPricingDataForHonouredEpPricing for applicationId: " + applicationId);
		List<Product> productListUpdate = new ArrayList<>();
		List<Product> productList = prodList.getProductList();
		try {
			for (Product loanProduct : productList) {
				if (CreditBusinessConstants.EP.equalsIgnoreCase(loanProduct.getHonouredPricingSource())
						&& CreditBusinessConstants.YES.equalsIgnoreCase(loanProduct.getIsSelected())
						&& Boolean.parseBoolean(loanProduct.getToBeDisplayedOnListingPage())) {
					List<ApplicationDetail> applicationDetailList = apiCallsHelper.getChildApplications(applicationId,
							"true");
					if (!CollectionUtils.isEmpty(applicationDetailList)) {
						ApplicationDetail applicationDetail = applicationDetailList.get(0);
						String childAppId = applicationDetail.getApplicationKey();
						PricingDetail epPricing = apiCallsHelper.getAppLoanPricing(childAppId);
						loanProduct.setEmi(epPricing.getEmiAmount());
						loanProduct.setRoi(new BigDecimal(epPricing.getFinalRoi()));

						List<Fees> fees = new ArrayList<>();
						Double totalFee = 0d;
						for (PricingFees pricingfee : epPricing.getFees()) {
							Fees fee = new Fees();
							fee.setFeeCode(pricingfee.getFeeCode());
							fee.setFeesInAmount(pricingfee.getFeesInAmount());
							fee.setFeesInPercent(pricingfee.getFeesInPercent());
							totalFee = Double.sum(totalFee, fee.getFeesInAmount().doubleValue());
							fees.add(fee);
						}
						loanProduct.setFees(fees);
						loanProduct.setTotalFee(totalFee);
					}
				}
				productListUpdate.add(loanProduct);
			}
			prodList.setProductList(productListUpdate);
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Error occurred in setPricingDataForHonouredEpPricing for : " + applicationId, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-106", "Error occurred while getting card list from BRE"));
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"End setPricingDataForHonouredEpPricing for applicationId: " + applicationId);
	}

	
	@SuppressWarnings("unchecked")
	private void triggerNotificationEventAndUpdateStage(String applicationId, JSONObject mcpRequest) {
		Object substagePercentageObject = mcpRequest.get(SUB_STAGE_PERCENTAGE);
		if(null != substagePercentageObject && LISTING_PERCENTAGE > Double.valueOf(substagePercentageObject.toString()).longValue()) {
			//send iisting notification
			notificationListener.publishListingNotificationEvent(applicationId, mcpRequest);
			
			//update stage
			Map<String, String> params = new HashMap<>();
			params.put(APPLICATION_ID, applicationId);
			JSONObject stageUpdate = new JSONObject();
			stageUpdate.put("percentageCompletion", LISTING_PERCENTAGE);
			this.callApi(updateStageUrl, HttpMethod.PUT, params, stageUpdate.toString(), String.class);
		}
	}
	
}
