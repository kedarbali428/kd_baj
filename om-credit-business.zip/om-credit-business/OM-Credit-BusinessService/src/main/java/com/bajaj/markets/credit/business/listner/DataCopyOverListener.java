package com.bajaj.markets.credit.business.listner;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.ApplicationDataCopyOverEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;

@Component
public class DataCopyOverListener {

	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = DataCopyOverListener.class.getCanonicalName();

	public void preAdditionalDetailsChildToParent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preAdditionalDetailsChildToParent");
		List<String> sourceList = new ArrayList<>();		
		sourceList.add(ApplicationDataCopyOverEnum.ADDRESS_CURRENT.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.ADDRESS_OFFICE.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.ADDRESS_PERM.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.LOANPURPOSE.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.CURRENT_EXPERIENCE.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.CURRENT_BUSINESS_EXPERIENCE.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.ADDITIONAL_DETAILS.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.INDUSTRY_TYPE.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.AVERAGE_BANK_BALANCE.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.EMAIL_OFFICIAL.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.OCCUPATION.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.APPDETVERIFICATION_EMAIL.getDesc());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preAdditionalDetailsChildToParent");
	}
	
	public void preBankDetailsChildToParent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preBankDetailsChildToParent");
		List<String> sourceList = new ArrayList<>();
		sourceList.add(ApplicationDataCopyOverEnum.BANK_JOURNEY.getDesc());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBankDetailsChildToParent");
	}
	
	public void preBankDetailsParentToChild(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preBankDetailsChildToParent");
		List<String> sourceList = new ArrayList<>();
		sourceList.add(ApplicationDataCopyOverEnum.BANK_PERFIOS.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.BANK_BMR.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.SALARY.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.INCOME_VERIFICATION_DATA.getDesc());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBankDetailsChildToParent");
	}
	
	public void defaultChildToParent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start defaultChildToParent");
		List<String> sourceList = new ArrayList<>();
		sourceList.add(ApplicationDataCopyOverEnum.DEFAULT.getDesc());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End defaultChildToParent");
	}
	
	public void ginAdditionalDetailChildToParent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start ginAdditionalDetailChildToParent");
		List<String> sourceList = new ArrayList<>();
		sourceList.add(ApplicationDataCopyOverEnum.EMAIL_OFFICIAL.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.OCCUPATION.getDesc());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End ginAdditionalDetailChildToParent");
	}
	
	public void nonGinAdditionalDetailsChildToParent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start nonGinAdditionalDetailsChildToParent");
		List<String> sourceList = new ArrayList<>();
		sourceList.add(ApplicationDataCopyOverEnum.ADDRESS.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.EMAIL.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.OCCUPATION.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.APPDETVERIFICATION_EMAIL.getDesc());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End nonGinAdditionalDetailsChildToParent");
	}
	
	public void addressCopyOverChildToParent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start addressCopyOverChildToParent");
		List<String> sourceList = new ArrayList<>();
		sourceList.add(ApplicationDataCopyOverEnum.ADDRESS.getDesc());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End addressCopyOverChildToParent");
	}
	
	
	public void prePersonalEmailParentToChild(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start prePersonalEmailParentToChild");
		List<String> sourceList = new ArrayList<>();
		sourceList.add(ApplicationDataCopyOverEnum.EMAIL_PERSONAL.getDesc());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End prePersonalEmailParentToChild");
	}

	public void preCommonAdditionalDetailLoanChildToParent(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCommonAdditionalDetailLoanChildToParent");
		Boolean currentAddressUpdateFlag = (Boolean)execution.getVariable("currentAddressUpdateFlag");
		Boolean workAddressUpdateFlag = (Boolean)execution.getVariable("workAddressUpdateFlag");
		Boolean permanentAddressUpdateFlag = (Boolean)execution.getVariable("permanentAddressUpdateFlag");
		Boolean userProfileUpdateFlag = (Boolean)execution.getVariable("userProfileUpdateFlag");
		Boolean workEmailUpdateFlag = (Boolean)execution.getVariable("workEmailUpdateFlag");
		Boolean customerReferenceUpdateFlag = (Boolean)execution.getVariable("customerReferenceUpdateFlag");
		Boolean loanPurposeUpdateFlag = (Boolean)execution.getVariable("loanPurposeUpdateFlag");
		Boolean personalEmailUpdateFlag = (Boolean)execution.getVariable("personalEmailUpdateFlag");
		Boolean experienceUpdateFlag = (Boolean)execution.getVariable("experienceUpdateFlag");
		Boolean designationUpdateFlag = (Boolean)execution.getVariable("designationUpdateFlag");
		
		List<String> sourceList = new ArrayList<>();
		
		if(currentAddressUpdateFlag){
			sourceList.add(ApplicationDataCopyOverEnum.ADDRESS_CURRENT.getDesc());
		}
		if(workAddressUpdateFlag){
			sourceList.add(ApplicationDataCopyOverEnum.ADDRESS_OFFICE.getDesc());
		}
		if(permanentAddressUpdateFlag){
			sourceList.add(ApplicationDataCopyOverEnum.ADDRESS_PERM.getDesc());
		}
		if(userProfileUpdateFlag){
			sourceList.add(ApplicationDataCopyOverEnum.ADDITIONAL_DETAILS.getDesc());
		}
		if(workEmailUpdateFlag){
			sourceList.add(ApplicationDataCopyOverEnum.EMAIL_OFFICIAL.getDesc());
		}
		if(customerReferenceUpdateFlag){
			sourceList.add(ApplicationDataCopyOverEnum.GUARANTOR_DETAIL.getDesc());
		}
		if(loanPurposeUpdateFlag){
			sourceList.add(ApplicationDataCopyOverEnum.LOANPURPOSE.getDesc());
		}
		if(personalEmailUpdateFlag){
			sourceList.add(ApplicationDataCopyOverEnum.EMAIL_PERSONAL.getDesc());
		}
		if(experienceUpdateFlag){
			sourceList.add(ApplicationDataCopyOverEnum.DECLARED_EXPERIENCE.getDesc());
		}
		if(designationUpdateFlag){
			sourceList.add(ApplicationDataCopyOverEnum.DESIGNATION.getDesc());		}

		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCommonAdditionalDetailLoanChildToParent");
	}
	
	public void preAdditionalDetailsChildToParentAxisLoans(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preAdditionalDetailsChildToParentAxisLoans");
		List<String> sourceList = new ArrayList<>();
		sourceList.add(ApplicationDataCopyOverEnum.ADDRESS_CURRENT.getDesc());
		sourceList.add(ApplicationDataCopyOverEnum.ADDRESS_OFFICE.getDesc());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preAdditionalDetailsChildToParentAxisLoans");
	}
}
