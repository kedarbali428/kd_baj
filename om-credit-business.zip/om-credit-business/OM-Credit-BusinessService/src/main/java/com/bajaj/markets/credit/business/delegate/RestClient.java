package com.bajaj.markets.credit.business.delegate;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST_HEADERS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SKIP_API_EXCEPTION;

import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.ActivitiException;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
@Scope("prototype")
public class RestClient implements JavaDelegate {

	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = RestClient.class.getCanonicalName();
	private Expression requestURL;
	private Expression requestType;
	private Expression requestParams;

	@Autowired
	Environment env;

	@Override
	public void execute(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "************* Start execute *************");
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "Execution started for task = " + execution.getCurrentActivityId());
		Object requestURLLocal = null;
		Object requestTypeLocal = null;
		Object requestParamsLocal = null;
		HashMap<String, String> requestHeadersLocal = null;
		String requestEntity = null;
		String requestUrl = null;
		HttpMethod method = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		if (null != requestURL && requestURL.getValue(execution) != null) {
			requestURLLocal = requestURL.getValue(execution);
			if (env.getProperty(requestURLLocal.toString()) != null)
				requestUrl = env.getProperty(requestURLLocal.toString()).trim();
		}
		if (null != requestType && requestType.getValue(execution) != null) {
			requestTypeLocal = requestType.getValue(execution);
			method = HttpMethod.resolve(requestTypeLocal.toString());
		}

		if (null != requestParams && null != requestParams.getValue(execution)) {
			requestParamsLocal = requestParams.getValue(execution);
		}
		
		Object requestHeaders = execution.getVariable(REQUEST_HEADERS);
		if (null != requestHeaders) {
			requestHeadersLocal = (HashMap<String, String>) requestHeaders;
			headers = CreditBusinessHelper.updateHttpHeaders(requestHeadersLocal, headers);
			execution.removeVariable(REQUEST_HEADERS);
		}
		
		ResponseEntity<?> responseEntity = null;
		try {
			if (!HttpMethod.GET.equals(method)) {
				requestEntity = CreditBusinessHelper.objectToJson(execution.getVariable(CreditBusinessConstants.PAYLOAD));
			}

			Map<String, String> map = creditBusinessHelper.setrequestParams(requestParamsLocal);
			responseEntity = creditBusinessHelper.invokeRestEndpoint(method, requestUrl, Object.class, map, requestEntity, headers);
		} catch (CreditBusinessException e) {
			if (null != execution.getVariable(SKIP_API_EXCEPTION) && (Boolean) execution.getVariable(SKIP_API_EXCEPTION)) {
				execution.setVariable(API_EXCEPTION_ARISE, true);
			} 
			else if (null != e.getPayload()) {
				String error = (String) e.getPayload();
				if(error.contains("CPI_SL101")) {
					execution.setVariable(CreditBusinessConstants.OUTPUT, error);
					logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "Pennant failed with " + e.getMessage());
				}
				else if(error.contains("CPI_1016")) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "HML Call failed with " + e.getMessage());
				}
				else if (error.contains("PAYSENSELIB-001") || error.contains("PAYSENSELIB-002")) { //PAYSENSE ELIGIBILITY CHECK FAILURE
					execution.setVariable(OUTPUT, null);
				}
				else if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
					if (error.contains("OMEDS-1018")) { //MANDATE NOT FOUND
						execution.setVariable("mandateAvailable", false);
						execution.setVariable(OUTPUT, null);
					} else if (error.contains("RFFD_3002")) { //BRANCH NOT FOUND
						execution.setVariable(OUTPUT, null);
					} else if (error.contains("OMCA_151")) { //UTM NOT FOUND
						execution.setVariable(OUTPUT, null);
					} else {
						throw new ActivitiException(null != e.getErrorBean() ? e.getErrorBean().getErrorMessage() : "Unhandled API Exception", e);
					}
				}else if (e.getCode().equals(HttpStatus.NOT_ACCEPTABLE)) {
					if (error.contains("OMVER_126") || error.contains("OMVER_125")) {
						execution.setVariable(CreditBusinessConstants.OUTPUT, error);
						logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "Email Validation failed with " + error);
					} else {
						throw new ActivitiException(null != e.getErrorBean() ? e.getErrorBean().getErrorMessage() : "Unhandled API Exception", e);
					}
				}
				else {
					throw new ActivitiException(null != e.getErrorBean() ? e.getErrorBean().getErrorMessage() : "Unhandled API Exception", e);
				}
			}else {
				throw new ActivitiException(null != e.getErrorBean() ? e.getErrorBean().getErrorMessage() : "Unhandled API Exception", e);
			}
		}

		if (null != responseEntity) {
			if(null != responseEntity.getBody()) {
				execution.setVariable(CreditBusinessConstants.IS_API_RESPONSE_NULL, Boolean.FALSE);
				execution.setVariable(CreditBusinessConstants.OUTPUT, responseEntity.getBody());
			} else {
				execution.setVariable(CreditBusinessConstants.IS_API_RESPONSE_NULL, Boolean.TRUE);
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "************* End execute *************");
	}
}
