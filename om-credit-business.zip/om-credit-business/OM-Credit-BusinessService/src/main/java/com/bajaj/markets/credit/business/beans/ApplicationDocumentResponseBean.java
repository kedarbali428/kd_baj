package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class ApplicationDocumentResponseBean {
	
	private ApplicationBFLDocsResponseBean primaryApplicantDocs;
	private List<ApplicationBFLDocsResponseBean> coApplicantDocs;
	/**
	 * @return the primaryApplicantDocs
	 */
	public ApplicationBFLDocsResponseBean getPrimaryApplicantDocs() {
		return primaryApplicantDocs;
	}
	/**
	 * @param primaryApplicantDocs the primaryApplicantDocs to set
	 */
	public void setPrimaryApplicantDocs(ApplicationBFLDocsResponseBean primaryApplicantDocs) {
		this.primaryApplicantDocs = primaryApplicantDocs;
	}
	/**
	 * @return the coApplicantDocs
	 */
	public List<ApplicationBFLDocsResponseBean> getCoApplicantDocs() {
		return coApplicantDocs;
	}
	/**
	 * @param coApplicantDocs the coApplicantDocs to set
	 */
	public void setCoApplicantDocs(List<ApplicationBFLDocsResponseBean> coApplicantDocs) {
		this.coApplicantDocs = coApplicantDocs;
	}

}
