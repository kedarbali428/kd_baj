package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICANTID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CHILDAPPLICATIONID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DOB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L3_PRODUCT_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAN_NUMBER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PARENT_APPLICATION_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PRINCIPALKEY;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@Component
public class KycListener {

	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASS_NAME = KycListener.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void preCkycSearchOrDownload(DelegateExecution execution) {
		JSONObject kycRequest = new JSONObject();
		
		kycRequest.put("applicationKey", execution.getVariable(CHILDAPPLICATIONID));
		kycRequest.put("parentApplicationKey", execution.getVariable(PARENT_APPLICATION_KEY));
		kycRequest.put("applicantKey", execution.getVariable(APPLICANTID));
		kycRequest.put("principalKey", execution.getVariable(PRINCIPALKEY));
		kycRequest.put("productKey", execution.getVariable(L3_PRODUCT_KEY));
		kycRequest.put("mobileNumber", execution.getVariable(MOBILE));
		kycRequest.put("dob", execution.getVariable(DOB));
		kycRequest.put("panNumber", execution.getVariable(PAN_NUMBER));
		
		logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "CKYC request: " + kycRequest);
		execution.setVariable(PAYLOAD, kycRequest);
	}
	
}