package com.bajaj.markets.credit.business.service;

import javax.validation.Valid;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.PricingConsentCaptureRequest;
import com.bajaj.markets.credit.business.beans.PricingConsentRequest;
import com.bajaj.markets.credit.business.beans.PricingConsentResponse;

public interface CreditBusinessPricingConsentService  {

	PricingConsentResponse pricingConsent(String applicationKey, @Valid PricingConsentRequest pricingConsentRequest,
			HttpHeaders headers);

	PricingConsentResponse pricingconsentCapture(String applicationKey, String consentRef,
			@Valid PricingConsentCaptureRequest pricingConsentCaptureRequest, HttpHeaders headers);




}
