package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;

public class EstimatedNetMonthlySalaryDetails {
	private String salarySource;
	private BigDecimal salaryAmount;

	 

	public void setSalarySource(String salarySource) {
		this.salarySource = salarySource;
	}


	public void setSalaryAmount(BigDecimal salaryAmount) {
		this.salaryAmount = salaryAmount;
	}

	@Override
	public String toString() {
		return "EstimatedNetMonthlySalaryDetails [salarySource=" + salarySource + ", salaryAmount=" + salaryAmount
				+ "]";
	}

}
