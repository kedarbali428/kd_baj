package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class PrincipleProductDetails {
	private String principleProductCode;
	private List<OfferDetails> offerDetails;
	private List<String> rejectCodeList;
	private Pincode pincode;
	private Pincode officepincode;
	private String employerType;
	private String employerCat;
	private String employerSubCat;
	private Boolean existingCustomerType;

	// Adding Additional parameter as part of JIRAID Len-535
	private String dedupeJson;
	private List<String> deviationCodes;
	private Boolean bflApplicableLocationFlag;
	private String childApplicationStatus;
	
	//Adding fields for secured Loan
	private Pincode propertyPincode;
	private Boolean isBTBankServicebaleFlag;

	public Pincode getOfficepincode() {
		return officepincode;
	}

	public void setOfficepincode(Pincode officepincode) {
		this.officepincode = officepincode;
	}

	public void setPrincipleProductCode(String principleProductCode) {
		this.principleProductCode = principleProductCode;
	}

	public void setOfferDetails(List<OfferDetails> offerDetails) {
		this.offerDetails = offerDetails;
	}

	public void setRejectCodeList(List<String> rejectCodeList) {
		this.rejectCodeList = rejectCodeList;
	}

	public void setPincode(Pincode pincode) {
		this.pincode = pincode;
	}

	public void setEmployerType(String employerType) {
		this.employerType = employerType;
	}

	public void setEmployerCat(String employerCat) {
		this.employerCat = employerCat;
	}

	public void setExistingCustomerType(Boolean existingCustomerType) {
		this.existingCustomerType = existingCustomerType;
	}

	public void setDedupeJson(String dedupeJson) {
		this.dedupeJson = dedupeJson;
	}

	public void setDeviationCodes(List<String> deviationCodes) {
		this.deviationCodes = deviationCodes;
	}

	public void setBflApplicableLocationFlag(Boolean bflApplicableLocationFlag) {
		this.bflApplicableLocationFlag = bflApplicableLocationFlag;
	}

	public void setChildApplicationStatus(String childApplicationStatus) {
		this.childApplicationStatus = childApplicationStatus;
	}
	
	public void setPropertyPincode(Pincode propertyPincode) {
		this.propertyPincode = propertyPincode;
	}

	public void setIsBTBankServicebaleFlag(Boolean isBTBankServicebaleFlag) {
		this.isBTBankServicebaleFlag = isBTBankServicebaleFlag;
	}

}
