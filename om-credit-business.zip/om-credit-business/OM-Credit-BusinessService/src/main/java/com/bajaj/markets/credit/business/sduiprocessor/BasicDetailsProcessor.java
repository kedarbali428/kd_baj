package com.bajaj.markets.credit.business.sduiprocessor;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NTB_PLCS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PLCS_HTS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PLCS_MTS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PLTB;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ApplicantNameDetails;
import com.bajaj.markets.credit.business.beans.ApplicantProfileDetails;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.beans.SalariedDetail;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.beans.UserTaskRequest;
import com.bajaj.markets.credit.business.beans.VerifiedNamePanBean;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessProfessionService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
@SuppressWarnings("unchecked")
public class BasicDetailsProcessor implements TaskProcessor {

	private static final String FALSE = "false";

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	CreditBusinessProfessionService creditBusinessProfessionService;

	@Value("${api.omcreditapplicationservice.userprofiles.get.url}")
	private String getUserProfiles;

	@Value("${api.omreferencedatareferencedataservice.location.residence.get.url}")
	private String getResidenceUrl;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getOccupationUrl;

	@Value("${api.omreferencedatareferencedataservice.getemployer.get.url}")
	private String employerMasterUrl;
	
	@Value("${api.applicant.openMarkets.applicant.GET.url}")
	private String getApplicantUrl;
	
	@Value("${api.omofferservice.offer.GET.url}")
	private String newOffersUrl;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;

	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = BasicDetailsProcessor.class.getCanonicalName();

	@Override
	public String getUserTaskRequest(String applicationId, HttpHeaders headers) {
		UserTaskRequest userRequest = new UserTaskRequest();
		Map<String, String> properties = new HashMap<>();
		properties.put("nameEditable", "true");
		properties.put("panEditable", "true");
		Map<String, Object> content = new HashMap<>();
		Map<String, String> params = new HashMap<>();
		params.put(CreditBusinessConstants.APPLICATION_ID, applicationId);
		ResponseEntity<?> userProfileResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getUserProfiles,
				List.class, params, null, headers);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<UserProfileBean> userProfileList = mapper.convertValue(userProfileResponse.getBody(),
				new TypeReference<List<UserProfileBean>>() {
				});
		if (!CollectionUtils.isEmpty(userProfileList)) {
			for (UserProfileBean userProfile : userProfileList) {
				if ("1".equals(userProfile.getApplicationUserAttributeType())) {
					setNameAndPan(headers, properties, content, userProfile);
					setPincode(applicationId, headers, content, userProfile);
					setResidenceType(content, params, mapper, userProfile);
					setEmployerNameAndSalary(headers, content, params, mapper, userProfile);
				}
			}
		}
		properties.put("formUrl", "/v2/applications/{applicationkey}/userTask/{taskName}");
		setFreeTextForEmployer(applicationId, headers, properties);
		userRequest.setContent(content);
		userRequest.setProperties(properties);
		Gson gson = new Gson();
		return gson.toJson(userRequest);
	}

	private VerifiedNamePanBean getNameAndPanFromUserProfile(UserProfileBean userProfile) {
		VerifiedNamePanBean verifiedBean = new VerifiedNamePanBean();
		StringBuilder fullname = new StringBuilder();
		Name name = userProfile.getName();
		if (!StringUtils.isBlank(name.getFirstName())) {
			fullname.append(name.getFirstName());
			if (!StringUtils.isBlank(name.getMiddleName())) {
				fullname.append(" ").append(name.getMiddleName());
			}
			if (!StringUtils.isBlank(name.getLastName())) {
				fullname.append(" ").append(name.getLastName());
			}
		}
		verifiedBean.setProspectName(fullname.toString());
		verifiedBean.setProspectPan(userProfile.getPanNumber());
		return verifiedBean;
	}

	private void setFreeTextForEmployer(String applicationId, HttpHeaders headers, Map<String, String> properties) {
		List<AppOfferDetBean> offerList = apiCallsHelper.fetchOffers(applicationId, null, headers);
		String plcsRiskOfferType = null;
		if (!CollectionUtils.isEmpty(offerList)) {
			for (AppOfferDetBean appOfferDetBean : offerList) {
				if (null != appOfferDetBean.getOfferSrcKey() && appOfferDetBean.getOfferSrcKey() == 1l) {
					plcsRiskOfferType = appOfferDetBean.getRiskOfferType();
					break;
				}
			}
		}
		if (null != plcsRiskOfferType && isPlcsOffer(plcsRiskOfferType)) {
			properties.put("isFreeText", "true");
		} else {
			properties.put("isFreeText", FALSE);
		}
	}

	private void setEmployerNameAndSalary(HttpHeaders headers, Map<String, Object> content, Map<String, String> params,
			ObjectMapper mapper, UserProfileBean userProfile) {
		params.put("userattributekey", userProfile.getApplicationUserAttributeKey());
		ResponseEntity<?> getOccupationResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				getOccupationUrl, Object.class, params, null, new HttpHeaders());
		Occupation occupation = mapper.convertValue(getOccupationResponse.getBody(), Occupation.class);
		SalariedDetail salariedDetail = occupation.getSalariedDetail();
		if (null != salariedDetail) {
			if (null != salariedDetail.getEmployerName()
					&& null != salariedDetail.getEmployerName().getKey()) {
				Map<String, String> param = new HashMap<>();
				param.put("employerid", salariedDetail.getEmployerName().getKey().toString());
				JSONObject employerMaster = null;
				try {
					ResponseEntity<?> getIndustryMasterRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
							employerMasterUrl, Object.class, param, null, headers);
					employerMaster = mapper.convertValue(getIndustryMasterRes.getBody(), JSONObject.class);
				}catch(Exception e) {
					logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "setEmployerNameAndSalary: No record found for employerId"+salariedDetail.getEmployerName().getKey().toString());
				}
				if (null != employerMaster) {
					String employerName = null != employerMaster.get("emprMasterName")
							? employerMaster.get("emprMasterName").toString()
							: null;
					JSONObject employerNameJson = new JSONObject();
					employerNameJson.put("text", employerName);
					employerNameJson.put("code", salariedDetail.getEmployerName().getKey().toString());
					content.put("employerName", employerNameJson);
				}
			} else {
				JSONObject employerNameJson = new JSONObject();
				employerNameJson.put("text", salariedDetail.getEmployerNameOther());
				employerNameJson.put("code", "");
				content.put("employerName", employerNameJson);
			}
			JSONObject salaryJson = new JSONObject();
			salaryJson.put("text", salariedDetail.getNetSalary());
			content.put("salary", salaryJson);
		}
	}

	private void setResidenceType(Map<String, Object> content, Map<String, String> params, ObjectMapper mapper,
			UserProfileBean userProfile) {
		ResponseEntity<?> getResidenceTypeResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				getResidenceUrl, List.class, params, null, new HttpHeaders());
		List<ResidenceMaster> residenceMastList = mapper.convertValue(getResidenceTypeResponse.getBody(),
				new TypeReference<List<ResidenceMaster>>() {
				});
		residenceMastList.forEach(residenceMast -> {
			if (null != userProfile.getResidenceTypeKey()
					&& userProfile.getResidenceTypeKey().equals(residenceMast.getResidenceKey())) {
				JSONObject residenceJson = new JSONObject();
				residenceJson.put("text", residenceMast.getResidenceValue());
				residenceJson.put("code", residenceMast.getResidenceCode());
				content.put("resiStatus", residenceJson);
			}
		});
	}

	private void setPincode(String applicationId, HttpHeaders headers, Map<String, Object> content,
			UserProfileBean userProfile) {
		JSONObject pinCodeText = new JSONObject();
		LocationResponseBean pincodeBean = getCurrentAddressDetails(applicationId,
				userProfile.getApplicationUserAttributeKey(), headers);
		if (null != pincodeBean) {
			pinCodeText.put("text", pincodeBean.getPincode());
			pinCodeText.put("code", pincodeBean.getPincodeKey());
		}
		content.put("pincode", pinCodeText);
	}

	private void setNameAndPan(HttpHeaders headers, Map<String, String> properties, Map<String, Object> content,
			UserProfileBean userProfile) {
		VerifiedNamePanBean namePanBean = getApplicantProfileDetails(userProfile,headers);
		String name="";
		String pan="";
		if(null!=namePanBean) {
			name = namePanBean.getProspectName();
			pan = namePanBean.getProspectPan();
			if(namePanBean.isNameVerified()) {
				name=namePanBean.getApplicantName();
				properties.put("nameEditable", "true");
			}
			if(namePanBean.isPanVerified()) {
				pan=namePanBean.getApplicantPan();
				properties.put("panEditable", "true");
			}
		}
		JSONObject nameText = new JSONObject();
		nameText.put("text", name);
		content.put("Name", nameText);
		JSONObject panText = new JSONObject();
		panText.put("text", pan);
		content.put("pan", panText);
	}

	private LocationResponseBean getCurrentAddressDetails(String applicationId, String appAttributeKey,
			HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Started getCurrentAddressDetails");
		try {
			Map<String, String> params = new HashMap<>();
			params.put("applicationid", applicationId);
			params.put("userattributekey", appAttributeKey);
			params.put("typeKey", AddressTypeEnum.CURRENT.getValue());
			params.put("returnSingleCurrentAddressFlag", Boolean.TRUE.toString());
			params.put("removeExactMatchCurrentAddress", Boolean.FALSE.toString());
			List<Address> addressList = apiCallsHelper.getAddressV2(headers, params);
			if (!CollectionUtils.isEmpty(addressList)) {
				for (Address addrs : addressList) {
					if (addrs.getPinCodeBean() != null) {
						return addrs.getPinCodeBean();
					}
				}
			}
		}catch(Exception e) {
			return null;
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Completed getCurrentAddressDetails");
		return null;
	}

	private boolean isPlcsOffer(String plcsRiskOfferType) {
		return PLTB.equals(plcsRiskOfferType) || PLCS_HTS.equals(plcsRiskOfferType)
				|| PLCS_MTS.equals(plcsRiskOfferType) || NTB_PLCS.equals(plcsRiskOfferType)
				|| "SAL_PLTB".equals(plcsRiskOfferType) || "SAL_HTS".equals(plcsRiskOfferType)
				|| "SAL_MTS".equals(plcsRiskOfferType);
	}
	
	private VerifiedNamePanBean getApplicantProfileDetails(UserProfileBean userProfile,HttpHeaders headers) {
		try {
			VerifiedNamePanBean verifiedBean = new VerifiedNamePanBean();
			logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getApplicantProfileDetails method for application "+userProfile.getApplicationKey()+" - started");
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.APPLICANTKEY, userProfile.getApplicantKey());
			if(null!=userProfile.getApplicantKey()) {
				ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
						getApplicantUrl, Object.class, paramMap, null, headers);
				if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
					ObjectMapper mapper = new ObjectMapper();
					mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
					ApplicantProfileDetails applicantProfileDetails = mapper.convertValue(responseEntity.getBody(), ApplicantProfileDetails.class);
					getVerifiedApplicantName(verifiedBean, applicantProfileDetails);
					getVerifiedApplicantPan(verifiedBean, applicantProfileDetails);
					logger.info(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside ApplicantDataSource - getApplicantProfileDetails method for application "+userProfile.getApplicationKey()+" - ended");
				}
			}
			if(verifiedBean.isNameVerified() && verifiedBean.isPanVerified()) {
				return verifiedBean;
			}else {
				return getNameAndPanFromUserProfile(userProfile);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "inside ApplicantDataSource - getApplicantProfileDetails method for application "+userProfile.getApplicationKey()+" - failed", e);
			return null;
		}
	}

	private void getVerifiedApplicantPan(VerifiedNamePanBean verifiedBean,
			ApplicantProfileDetails applicantProfileDetails) {
		if (null != applicantProfileDetails.getPanDetails()
				&& !StringUtils.isEmpty(applicantProfileDetails.getPanDetails().getVerificationflg())
				&& ("1".equals(applicantProfileDetails.getPanDetails().getVerificationflg())
						|| "Y".equals(applicantProfileDetails.getPanDetails().getVerificationflg()))) {
			verifiedBean.setPanVerified(Boolean.TRUE);
			verifiedBean.setApplicantPan(applicantProfileDetails.getPanDetails().getPanNumber());
		}
	}

	private void getVerifiedApplicantName(VerifiedNamePanBean verifiedBean,
			ApplicantProfileDetails applicantProfileDetails) {
		if (null != applicantProfileDetails.getNameDetails()
				&& !StringUtils.isEmpty(applicantProfileDetails.getNameDetails().getVerificationflg())
				&& ("1".equals(applicantProfileDetails.getNameDetails().getVerificationflg())
						|| "Y".equals(applicantProfileDetails.getNameDetails().getVerificationflg()))) {
			verifiedBean.setNameVerified(Boolean.TRUE);
			StringBuilder fullname = new StringBuilder();
			ApplicantNameDetails name = applicantProfileDetails.getNameDetails();
			if (!StringUtils.isBlank(name.getFirstName())) {
				fullname.append(name.getFirstName());
				if (!StringUtils.isBlank(name.getMiddleName())) {
					fullname.append(" ").append(name.getMiddleName());
				}
				if (!StringUtils.isBlank(name.getLastName())) {
					fullname.append(" ").append(name.getLastName());
				}
			}
			verifiedBean.setApplicantName(fullname.toString());
		}
	}
	
}
