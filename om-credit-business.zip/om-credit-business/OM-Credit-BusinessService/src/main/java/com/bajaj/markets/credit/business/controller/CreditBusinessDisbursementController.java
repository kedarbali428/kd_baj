package com.bajaj.markets.credit.business.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.DisbursementEventRequestBean;
import com.bajaj.markets.credit.business.beans.DisbursementEventResponseBean;
import com.bajaj.markets.credit.business.service.CreditBusinessDisbursementService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
/**
 * @author pranoti.pandole
 *
 */
@RestController
public class CreditBusinessDisbursementController {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessDisbursementService creditBusinessDisbursementService;
	
	
	private static final String CLASS_NAME = CreditBusinessDisbursementController.class.getCanonicalName();

	@Secured(value = {Role.EMPLOYEE,Role.PRINCIPAL,Role.VENDORPARTNER,Role.CUSTOMER})
	@ApiOperation(value = "Initiate Disbursement", notes = "Process Disbursement", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Case Disbursed Successfuly.", response = DisbursementEventResponseBean.class)})
	@PostMapping(path = "/v1/credit/applications/{applicationid}/disbursement/initiate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<DisbursementEventResponseBean> processDisbursement(@PathVariable("applicationid") String applicationId, @RequestBody DisbursementEventRequestBean disbursementEventRequestBean,@RequestHeader HttpHeaders headers){
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start processDisbursement :" + applicationId);
		DisbursementEventResponseBean responsetBean =creditBusinessDisbursementService.processDisbursement(applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End processDisbursement :" + applicationId);
		return new ResponseEntity<DisbursementEventResponseBean>(responsetBean, HttpStatus.OK);
	}
	
	
}
