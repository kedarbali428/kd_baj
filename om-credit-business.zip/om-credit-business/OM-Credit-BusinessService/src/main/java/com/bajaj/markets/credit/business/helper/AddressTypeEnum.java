package com.bajaj.markets.credit.business.helper;

/**
 * Enum of address type with its key value
 * 
 * @author 764504
 *
 */
public enum AddressTypeEnum {

	CURRENT("50"), OFFICE("46"), PERMANENT("48"), OTHERS("52"), DELIVERY("56");

	private final String value;

	private AddressTypeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

}
