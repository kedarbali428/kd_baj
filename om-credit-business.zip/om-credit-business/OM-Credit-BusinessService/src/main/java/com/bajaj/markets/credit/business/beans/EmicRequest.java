package com.bajaj.markets.credit.business.beans;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.google.gson.annotations.SerializedName;

public class EmicRequest {
	@Pattern(regexp = "^[6789]{1}\\d{9}$", message = "Mobile number should be of 10 digit and starts with 6 or 7 or 8 or 9.")
	@SerializedName("mobileno")
	private String mobileNumber;

	@NotBlank(message = "Date of Birth is mandatory")
	@SerializedName("DOB")
	private String dateOfBirth;

	private String name;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "EmicRequest [mobileNumber=" + mobileNumber + ", dateOfBirth=" + dateOfBirth + ", name=" + name + "]";
	}

}
