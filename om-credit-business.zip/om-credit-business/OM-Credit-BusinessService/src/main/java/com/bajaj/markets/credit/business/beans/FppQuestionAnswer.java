package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

public class FppQuestionAnswer implements Serializable {
	 
	/**
	 * 
	 */
	private static final long serialVersionUID = -2873902146187689281L;

	private Integer questionKey;

	@NotBlank(message = "QuestionCode can not be null or blank")
	private String questionCode;

	private String questionString;

	private Boolean visibleToUiFlag;

	private Integer appQuestionResponseKey;

	@NotBlank(message = "UserResponse can not be null or blank")
	private String userResponse;

	public Integer getQuestionKey() {
		return questionKey;
	}

	public void setQuestionKey(Integer questionKey) {
		this.questionKey = questionKey;
	}

	public String getUserResponse() {
		return userResponse;
	}

	public void setUserResponse(String userResponse) {
		this.userResponse = userResponse;
	}

	public String getQuestionString() {
		return questionString;
	}

	public void setQuestionString(String questionString) {
		this.questionString = questionString;
	}

	public Boolean getVisibleToUiFlag() {
		return visibleToUiFlag;
	}

	public void setVisibleToUiFlag(Boolean visibleToUiFlag) {
		this.visibleToUiFlag = visibleToUiFlag;
	}

	public String getQuestionCode() {
		return questionCode;
	}

	public void setQuestionCode(String questionCode) {
		this.questionCode = questionCode;
	}

	public Integer getAppQuestionResponseKey() {
		return appQuestionResponseKey;
	}

	public void setAppQuestionResponseKey(Integer appQuestionResponseKey) {
		this.appQuestionResponseKey = appQuestionResponseKey;
	}

}