package com.bajaj.markets.credit.business.service;

import java.util.List;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.Reference;

public interface CreditMasterDataService {

	List<Reference> getServiceableMasterData(String principalCode, String serviceableCode, String status,
			HttpHeaders headers);

}
