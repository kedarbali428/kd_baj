package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICANTID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DATE_OF_BIRTH;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DOB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
public class Applicant {

	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASS_NAME = Applicant.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void preCreateApplicant(DelegateExecution execution) {
		JSONObject profileDet = CreditBusinessHelper.getJSONObject(execution.getVariable(NAME));
		JSONObject applicantRequest = new JSONObject();

		applicantRequest.put("firstName", profileDet.get("firstName"));
		applicantRequest.put("middleName", profileDet.get("middleName"));
		applicantRequest.put("lastName", profileDet.get("lastName"));
		applicantRequest.put(DATE_OF_BIRTH, execution.getVariable(DOB));
		applicantRequest.put("mobileNumber", execution.getVariable(MOBILE));
		
		execution.setVariable(PAYLOAD, applicantRequest);
	}

	public void postCreateApplicant(DelegateExecution execution) {
		JSONObject applicantResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
		
		Object payload = applicantResponse.get("payload");
		if(null != payload) {
			JSONObject payloadJson = CreditBusinessHelper.getJSONObject(payload);
			execution.setVariable(APPLICANTID, String.format("%.0f", payloadJson.get("applicantKey")));
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Applicant creation response did not return expected response");
		}
	}
	
}
