package com.bajaj.markets.credit.business.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.BusinessOwnerDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.LookupCodeResponse;
import com.bajaj.markets.credit.business.beans.LookupCodeValuesResponseBean;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.Profession;
import com.bajaj.markets.credit.business.beans.ProfileDetailsReqResp;
import com.bajaj.markets.credit.business.beans.ProfileDetailsV2;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResidencePincode;
import com.bajaj.markets.credit.business.beans.SalariedDetail;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.EventMessageHelper;
import com.bajaj.markets.credit.business.helper.PrincipalTypeEnum;
import com.bajaj.markets.credit.business.helper.ReferenceOf;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessProfileDetailService;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CreditBusinessProfileDetailServiceImpl implements CreditBusinessProfileDetailService {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;

	@Autowired
	WorkflowHelper workflowHelper;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getOccupationUrl;

	@Value("${api.omreferencedatareferencedataservice.getemployer.get.url}")
	private String employerMasterUrl;

	@Value("${api.omreferencedatareferencedataservice.lookup.code.get.url}")
	private String lookUpCodeUrl;
	
	@Value("${api.omcreditapplicationservice.creditapplication.parameters.url}")
	private String appParametersUrl;

	@Autowired
	private EventMessageHelper eventMessageHelper;
	
	@Autowired
	private PublisherService publisherService;
	
	@Value("${aws.publisher.topic.arn}")
	private String topicArn;
	
	private static final String CLASS_NAME = CreditBusinessAdditionalDetailServiceImpl.class.getName();
	final String APPLICATIONID = "applicationid";
	final String APPLICATIONPARAMETERS = "applicationParameters";
	final String REQUESTEDCREDITAMOUNT = "requestedCreditAmount";

	@Override
	public ProfileDetailsReqResp getProfileDetails(String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Started getProfileDetails for : " + applicationId);
		ProfileDetailsReqResp ProfileDetailsResponse = new ProfileDetailsReqResp();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HashMap<String, String> params = new HashMap<>();
			params.put("applicationid", applicationId);
			UserProfileBean userProfile = apiCallsHelper.getUserProfile(params);
			String appAttributeKey = userProfile.getApplicationUserAttributeKey();

			ProfileDetailsV2 profileDetailsV2 = setProfileDetails(applicationId, appAttributeKey, userProfile);
			ProfileDetailsResponse.setProfileDetails(profileDetailsV2);
			Profession profession = setProfessionDetails(appAttributeKey, applicationId);
			ProfileDetailsResponse.setProfession(profession);
			ResidencePincode residencePincode = getCurrentAddressDetails(applicationId, appAttributeKey, headers);
			ProfileDetailsResponse.setResidencePincode(residencePincode);
			setRequiredLoanAmount(ProfileDetailsResponse,applicationId);
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "CreditBusinessException for : " + applicationId, e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occured in getProfileDetails for : " + applicationId, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-001", "Failed to get profile details"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End getProfileDetails with : " + ProfileDetailsResponse);
		return ProfileDetailsResponse;
	}

	private ProfileDetailsV2 setProfileDetails(String applicationId, String appAttributeKey,
			UserProfileBean userProfile) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Started setProfileDetails for : " + applicationId);
		ProfileDetailsV2 profileDetailsV2 = new ProfileDetailsV2();
		try {
			profileDetailsV2.setPanNumber(userProfile.getPanNumber());

			if(null != userProfile.getName()) {
				if(null != userProfile.getName().getFirstName() && null != userProfile.getName().getMiddleName() && null != userProfile.getName().getLastName()) {
					profileDetailsV2.setName(userProfile.getName().getFirstName() + " " + userProfile.getName().getMiddleName() + " " + userProfile.getName().getLastName());
				} else if(null != userProfile.getName().getFirstName() && null != userProfile.getName().getLastName()) {
					profileDetailsV2.setName(userProfile.getName().getFirstName() + " " + userProfile.getName().getLastName());
				}
			}

			if (null != userProfile.getResidenceTypeKey()) {
				Reference filterReference = getReference(userProfile.getResidenceTypeKey(), null, null);
				Reference residence = apiCallsHelper.getReference(ReferenceOf.RESIDENCE, null, filterReference);
				profileDetailsV2.setResidenceType(residence);
			}

			if (null != userProfile.getMaritalStatusKey()) {
				Reference filterReference = getReference(userProfile.getMaritalStatusKey(), null, null);
				Reference maritalStatus = apiCallsHelper.getReference(ReferenceOf.MARITAL_STATUS, null,
						filterReference);
				if (CreditBusinessConstants.MARITAL_STATUS_M.equals(maritalStatus.getCode())
						|| CreditBusinessConstants.MARITAL_STATUS_S.equals(maritalStatus.getCode())) {
					profileDetailsV2.setMaritalStatus(maritalStatus);
				} else {
					maritalStatus.setKey(CreditBusinessConstants.MARITAL_STATUS_M_KEY);
					maritalStatus.setCode(CreditBusinessConstants.MARITAL_STATUS_M);
					maritalStatus.setValue(CreditBusinessConstants.MARRIED);
					profileDetailsV2.setMaritalStatus(maritalStatus);
				}
			}

			if (null != userProfile.getGenderKey()) {
				Reference filterReference = getReference(userProfile.getGenderKey(), null, null);
				Reference gender = apiCallsHelper.getReference(ReferenceOf.GENDER, null, filterReference);
				if (CreditBusinessConstants.GENDER_M.equals(gender.getCode())
						|| CreditBusinessConstants.GENDER_F.equals(gender.getCode())) {
					profileDetailsV2.setGender(gender);
				} else {
					Reference genderDet = new Reference();
					genderDet.setKey(CreditBusinessConstants.GENDER_KEY);
					genderDet.setCode(CreditBusinessConstants.GENDER_M);
					genderDet.setValue(CreditBusinessConstants.MALE);
					profileDetailsV2.setGender(genderDet);
				}
			}
			try {
				Email persEmail = apiCallsHelper.getEmail(applicationId, appAttributeKey,
						EmailTypeEnum.PERON1.getValue().toString());
				profileDetailsV2.setPersonalEmailId(null != persEmail ? persEmail.getEmail() : null);
			} catch (Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Exception Occurred in application service for personal email for " + applicationId + e);
			}
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "CreditBusinessException for : " + applicationId, e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occured in setProfileDetails for : " + applicationId, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-001", "Failed to set profile details"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End setProfileDetails with : " + profileDetailsV2);
		return profileDetailsV2;
	}

	private Profession setProfessionDetails(String appAttributeKey, String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Started setProfessionDetails for : " + applicationId);
		Profession profession = new Profession();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			if (null != appAttributeKey) {
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				HashMap<String, String> params = new HashMap<>();
				params.put("applicationid", applicationId);
				params.put("userattributekey", appAttributeKey);

				ResponseEntity<?> getOccupationResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
						getOccupationUrl, Object.class, params, null, new HttpHeaders());

				Occupation occupation = mapper.convertValue(getOccupationResponse.getBody(), Occupation.class);
				SalariedDetail salariedDetail = occupation.getSalariedDetail();
				BusinessOwnerDetails businessOwnerDetails = occupation.getBusinessOwnerDetails();
				Reference occupationType = occupation.getOcupationType();
				profession.setOccupation(occupationType);

				if (null != salariedDetail) {
					profession
							.setSalariedDetail(this.prepareResponseFromSalariedDetails(salariedDetail, applicationId));
				}

				if (null != businessOwnerDetails) {
					profession.setBusinessOwnerDetails(
							this.prepareResponseFromBusinessOwnerDetails(businessOwnerDetails, applicationId));
				}
			}
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "CreditBusinessException for : " + applicationId, e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occured in setProfessionDetails for : " + applicationId, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-001", "Failed to set ProfessionDetails details"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End setProfessionDetails with : " + profession);
		return profession;
	}

	private SalariedDetail prepareResponseFromSalariedDetails(SalariedDetail salariedDetail, String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Started prepareResponseFromSalariedDetails for : " + applicationId);
		if (null != salariedDetail.getEmployerName() && null != salariedDetail.getEmployerName().getKey()) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				Map<String, String> param = new HashMap<>();
				param.put("employerid", salariedDetail.getEmployerName().getKey().toString());

				ResponseEntity<?> getIndustryMasterRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
						employerMasterUrl, Object.class, param, null, headers);

				JSONObject employerMaster = mapper.convertValue(getIndustryMasterRes.getBody(), JSONObject.class);
				if (null != employerMaster) {
					String employerName = null != employerMaster.get("emprMasterName")
							? employerMaster.get("emprMasterName").toString()
							: null;
					salariedDetail.getEmployerName().setValue(employerName);
				}
			} catch (Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"prepareResponseFromSalariedDetails: No record found for employerId"
								+ salariedDetail.getEmployerName().getKey().toString());
			}

		}

		if (null != salariedDetail.getQualification() && null != salariedDetail.getQualification().getKey()) {
			Reference filterRef = getReference(salariedDetail.getQualification().getKey(), null, null);
			salariedDetail.setQualification(apiCallsHelper.getReference(ReferenceOf.QUALIFICATION, null, filterRef));
		}

		if (null != salariedDetail.getSpecialization() && null != salariedDetail.getSpecialization().getKey()) {
			MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
			queryParams.add("spclMasterKey", salariedDetail.getSpecialization().getKey().toString());
			Reference filterReference = getReference(salariedDetail.getSpecialization().getKey(), null, null);
			Reference specilization = apiCallsHelper.getReference(ReferenceOf.SPECIALIZATION, queryParams,
					filterReference);
			salariedDetail.setSpecialization(specilization);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End prepareResponseFromSalariedDetails with : " + salariedDetail);
		return salariedDetail;
	}

	private BusinessOwnerDetails prepareResponseFromBusinessOwnerDetails(BusinessOwnerDetails businessOwnerDetails,
			String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Started prepareResponseFromBusinessOwnerDetails for : " + applicationId);
		try {
			if (null != businessOwnerDetails.getIndustryType()
					&& null != businessOwnerDetails.getIndustryType().getKey()) {
				Reference filterReference = getReference(businessOwnerDetails.getIndustryType().getKey(), null, null);
				Reference industry = apiCallsHelper.getReferenceV2(ReferenceOf.INDUSTRY, null, null, filterReference);
				businessOwnerDetails.setIndustryType(industry);
			}

			if (null != businessOwnerDetails.getAnualTurnover()
					&& null != businessOwnerDetails.getAnualTurnover().getValue()) {
				HashMap<String, String> params = new HashMap<>();
				params.put("lkpcode", "ANNUALTURNOVER");
				ResponseEntity<?> getlLookUpCodeRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
						lookUpCodeUrl, Object.class, params, null, new HttpHeaders());
				ObjectMapper mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				LookupCodeResponse lookUpCode = mapper.convertValue(getlLookUpCodeRes.getBody(),
						LookupCodeResponse.class);
				List<LookupCodeValuesResponseBean> annualTurnOverList = lookUpCode.getLookupValuesResponseList()
						.stream().filter(o -> o.getValue().contains(businessOwnerDetails.getAnualTurnover().getValue()))
						.collect(Collectors.toList());
				if (!CollectionUtils.isEmpty(annualTurnOverList)) {
					businessOwnerDetails.setAnualTurnover(getReference(annualTurnOverList.get(0).getKey().longValue(),
							annualTurnOverList.get(0).getCode(), annualTurnOverList.get(0).getValue()));
				}
			}

			if (null != businessOwnerDetails.getQualification()
					&& null != businessOwnerDetails.getQualification().getKey()) {
				Reference filterRef = getReference(businessOwnerDetails.getQualification().getKey(), null, null);
				Reference qualification = apiCallsHelper.getReferenceV2(ReferenceOf.QUALIFICATION, null, null,
						filterRef);
				businessOwnerDetails.setQualification(qualification);
			}

			if (null != businessOwnerDetails.getSpecialization()
					&& null != businessOwnerDetails.getSpecialization().getKey()) {
				MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
				queryParams.add("spclMasterKey", businessOwnerDetails.getSpecialization().getKey().toString());
				Reference filterReference = getReference(businessOwnerDetails.getSpecialization().getKey(), null, null);
				Reference specilization = apiCallsHelper.getReferenceV2(ReferenceOf.SPECIALIZATION, null, queryParams,
						filterReference);
				businessOwnerDetails.setSpecialization(specilization);
			}
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "CreditBusinessException for : " + applicationId, e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occured in prepareResponseFromBusinessOwnerDetails for : " + applicationId, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-001", "Failed to prepareResponse for BusinessOwnerDetails"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"End prepareResponseFromBusinessOwnerDetails with : " + businessOwnerDetails);
		return businessOwnerDetails;
	}

	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;
	}

	private ResidencePincode getCurrentAddressDetails(String applicationId, String appAttributeKey,
			HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Started getCurrentAddressDetails for : " + applicationId);
		ResidencePincode residencePincode = null;
		Map<String, String> params = new HashMap<String, String>();
		params.put("applicationid", applicationId);
		params.put("userattributekey", appAttributeKey);
		params.put("typeKey", AddressTypeEnum.CURRENT.getValue());
		params.put("returnSingleCurrentAddressFlag", Boolean.TRUE.toString());
		params.put("removeExactMatchCurrentAddress", Boolean.FALSE.toString());
		try {
			List<Address> addressList = apiCallsHelper.getAddressV2(headers, params);
			for (Address addrs : addressList) {
				if (addrs.getPinCodeBean() != null) {
					LocationResponseBean pinCodeBean = addrs.getPinCodeBean();
					residencePincode = new ResidencePincode();
					residencePincode.setPincode(pinCodeBean.getPincode());
					residencePincode.setCity(getReference(pinCodeBean.getCityKey(), pinCodeBean.getCityCode(),
							pinCodeBean.getCityName()));
					residencePincode.setCountry(getReference(pinCodeBean.getCountryKey(), pinCodeBean.getCountryCode(),
							pinCodeBean.getCountryName()));
					residencePincode.setNegativeAreaFlag(pinCodeBean.getPinNegativeAreaFlg() != 0);
					residencePincode.setOglFlag(pinCodeBean.getPinOglFlg() != 0);
					residencePincode.setState(getReference(pinCodeBean.getStateKey(), pinCodeBean.getStateCode(),
							pinCodeBean.getStateName()));
					break;
				}
			}
		} catch (CreditBusinessException e) {
			if (HttpStatus.NOT_FOUND.equals(e.getCode())) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Resource Not Found exception while fetching V2 address with params = " + params);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Exception while fetching V2 address with params = " + params, e);
				throw e;
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Completed getCurrentAddressDetails");
		return residencePincode;
	}
	
	@SuppressWarnings("unchecked")
	private void setRequiredLoanAmount(ProfileDetailsReqResp profileDetailsResponse, String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Started setProfileDetails for : " + applicationId);
		try {
			HashMap<String, String> params = new HashMap<>();
			params.put(APPLICATIONID, applicationId);
			ResponseEntity<?> appParametersRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					appParametersUrl, Object.class, params, null, new HttpHeaders());
			if (null != appParametersRes && null != appParametersRes.getBody()) {
				Map<Object, Object> applicationParametersRes = (Map<Object, Object>) appParametersRes.getBody();
				if (null != applicationParametersRes.get(APPLICATIONPARAMETERS)) {			
					Map<Object, Object> applicationParameters = (Map<Object, Object>) applicationParametersRes
							.get(APPLICATIONPARAMETERS);
					if (null != applicationParameters.get(REQUESTEDCREDITAMOUNT)) {
						String reqLoanAmt = (String) applicationParameters.get(REQUESTEDCREDITAMOUNT);
						profileDetailsResponse
								.setRequiredLoanAmount(null != reqLoanAmt ? Integer.parseInt(reqLoanAmt) : null);
					}
				}
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occured while calling the service for appId : " + applicationId, e);
			  throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new
			  ErrorBean("CBS-101", "Exception while set RequiredLoanAmount"));			 
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End setProfileDetails");
	}

	@Override
	public ApplicationResponse saveProfileDetails(ProfileDetailsReqResp profileDetails, String applicationId,
			HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start saveProfileDetails for applicationid : " + applicationId);
		try {
			ApplicationDetail application = apiCallsHelper.getApplicationDetails(applicationId, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "application : " + application);
			
			if ((StringUtils.isEmpty(profileDetails.getAction()) || !"back".equals(profileDetails.getAction())) && CreditBusinessConstants.PRODUCT_CODE_OMPL.equalsIgnoreCase(application.getL2ProductCode())) {
				unsecuredEarlySalaryDedupeEvents(profileDetails, application);
				eventMessageHelper.publishBMR1EventV2(application, profileDetails);
			}
			String nextTaskKey = null;
			if (null != headers && null != headers.get(CreditBusinessConstants.PROCESS_ID)) {
				Map<String, Object> vars = new HashMap<>(); 
				vars.put(CreditBusinessConstants.REQUEST, profileDetails);
				vars.put(CreditBusinessConstants.APPLICATIONID, applicationId);
				nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"ProcessId dosen't exist with headers for appId : " + applicationId);
				throw new CreditBusinessException(HttpStatus.BAD_REQUEST,
						new ErrorBean("CBS-1010", "Invalid Request! processId must present"));
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"End updateProfile for applicationid : " + applicationId);
			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			ApplicationResponse applicationResponse = new ApplicationResponse();
			applicationResponse.setNextTask(task);
			return applicationResponse;
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception completing workflow task for appId : " + applicationId, e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception occured while calling the service for appId : " + applicationId, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-101", "Exception while completing activiti task"));
		}
	}
		
		@SuppressWarnings("unchecked")
		private void unsecuredEarlySalaryDedupeEvents(ProfileDetailsReqResp profileDetails, ApplicationDetail application) {
			if (CreditBusinessConstants.PRODUCT_CODE_OMPL.equalsIgnoreCase(application.getL2ProductCode())) {
				Map<String, String> params = new HashMap<>();
				params.put("applicationid", application.getApplicationKey());
				UserProfileBean userProfileBean= apiCallsHelper.getUserProfile(params);
				if (null != userProfileBean && null != userProfileBean.getMobile()) {
					JSONObject earlySalaryUnsecuredDedupeRequest = new JSONObject();
					earlySalaryUnsecuredDedupeRequest.put("applicationId", application.getApplicationKey());
					earlySalaryUnsecuredDedupeRequest.put("mob", userProfileBean.getMobile());
					earlySalaryUnsecuredDedupeRequest.put("productCode", CreditBusinessConstants.PRODUCT_CODE_OMPL);
					earlySalaryUnsecuredDedupeRequest.put("principalName", PrincipalTypeEnum.EARLYSALARY.getValue());
					earlySalaryUnsecuredDedupeRequest.put("pan", profileDetails.getProfileDetails().getPanNumber());
					earlySalaryUnsecuredDedupeRequest.put("userAttributeKey", userProfileBean.getApplicationUserAttributeKey());
					
					triggerDedupeEvent(CreditBusinessConstants.PRODUCT_CODE_OMPL, PrincipalTypeEnum.EARLYSALARY, earlySalaryUnsecuredDedupeRequest);
				} else {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "UserProfile data is not proper for publishing EarlySalary dedupe event, application : "+application.getApplicationKey());
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "UserProfile data is not proper for publishing EarlySalary dedupe event, application : "+application.getApplicationKey());
				}
			}
		}
		
		private void triggerDedupeEvent(String productCode, PrincipalTypeEnum principalTypeEnum, Object dedupeRequest){
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Input triggerDedupeEvent method for productCode: "+ productCode+ " , principalTypeEnum : "+ principalTypeEnum + " , dedupeRequest: "+ dedupeRequest);
			try {
				EventMessage eventMessage = eventMessageHelper.createEventMessage(productCode, dedupeRequest, principalTypeEnum);
				publisherService.publish(topicArn, eventMessage);
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "triggerDedupeEvent method successful");
			} catch (Exception e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception in triggerDedupeEvent.");
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception in triggerDedupeEvent",e);
			}
		}
}
