package com.bajaj.markets.credit.business.helper;

public class CreditBusinessConstants {

	public static final String HEADER_X_SESSION_TOKEN = "X-Session-Token";
	private CreditBusinessConstants() {
		// NOSONAR
	}

	public static final String GET = "GET";
	public static final String POST = "POST";
	public static final String SHOW_OTP_SCREEN = "showOtpScreen";
	public static final String CB_500 = "CB-500";
	public static final String OFFICE_PINCODEREQUIRED ="officePincodeRequired";
	public static final String CB_501 = "CB-501";
	public static final String CB_502 = "CB-502";
	public static final String CB_503 = "CB-503";
	public static final String CB_504 = "CB-504";
	public static final String CB_401 = "CBS-401";
	public static final String CB_406 = "CBS-406";
	public static final String OUTPUT = "output";
	public static final String IS_API_RESPONSE_NULL = "isAPIResponseNull";
	public static final String UPDATE_PROFILE = "updateProfile";
	public static final String APPLICATION_ID = "applicationid";
	public static final String NAME = "name";
	public static final String FULL_NAME = "fullname";
	public static final String FIRST_NAME = "firstName";
	public static final String LAST_NAME = "lastName";
	public static final String MIDDLE_NAME = "middleName";
	public static final String KEY = "key";
	public static final String SALUTATIONKEY = "salutationKey";
	public static final String APPLICATIONKEY = "applicationKey";
	public static final String MARITALSTATUSKEY = "maritalStatusKey";
	public static final String MARITALSTATUS = "maritalStatus";
	public static final String IS_VERIFIED = "isVerified";
	public static final String VERIFIED = "verified";
	public static final String VERIFICATION_DATE = "verificationDate";
	public static final String RESIDENCETYPEKEY = "residenceTypeKey";
	public static final String RESITYPE = "residenceType";
	public static final String VERIFICATION = "verification";
	public static final String VERIFIEDBY = "verifiedBy";
	public static final String VERIFIEDFOR = "verifiedFor";
	public static final String VERIFICATION_SOURCE = "verificationSource";
	public static final String GENDERKEY = "genderKey";
	public static final String GENDER = "gender";
	public static final String PAYLOAD = "payload";
	public static final String MOBILE = "mobile";
	public static final String DATE_OF_BIRTH = "dateOfBirth";
	public static final String REQUEST = "request";
	public static final String EMPLOYER_ID ="employerId";
	public static final String NEXT_TASK_KEY = "nextTaskKey";
	public static final String BASIC_DETAILS = "basicdetails";
	public static final String PROFESSION_DETAILS = "professionDetailsUT";
	public static final String APPLICANTID = "applicantid";
	public static final String APPLICATION_USER_ATTRIBUTE_KEY = "applicationUserAttributeKey";
	public static final String CHILD_APPLICATION_USER_ATTRIBUTE_KEY = "childApplicationUserAttributeKey";
	public static final String APPLICATION_USER_ATTRIBUTE_TYPE = "applicationUserAttributeType";
	public static final String DOB = "dob";
	public static final String PAN = "pan";
	public static final String DOCUMENT_EXPIRY = "documentExpiry";
	public static final String DOCUMENT_ISSUED_DATE = "documentIssuedDate";
	public static final String DOCUMENT_NAME_KEY = "documentNameKey";
	public static final String DOCUMENT_NUMBER = "documentNumber";
	public static final String ISSUEING_AUTHORITY_KEY = "issueingAuthorityKey";
	public static final String AGE = "age";
	public static final String COMPANY_CATEGORY = "companyCategory";
	public static final String COMPANY_TYPE = "companyType";
	public static final String EDUCATION_QUALIFICATION = "educationQualification";
	public static final String INDUSTRY_TYPE = "industryType";
	public static final String OCCUPATION_TYPE = "occupationType";
	public static final String REJECTION_TYPE = "rejectionType";
	public static final String SUB_INDUSTRY_TYPE = "subIndustryType";
	public static final String SUB_STAGE_PERCENTAGE = "subStagePercentage";
	public static final String WORKEXPERIENCE = "workExperience";
	public static final String PROCESS_ID = "processId";
	public static final String VALUE = "value";
	public static final String CC = "CC";
	public static final String CREDIT_CARD_PARENT_JOURNEY = "creditCardParentJourney";
	public static final String PERSONALEMAILID = "personalEmailId";
	public static final String CREDIT_JOURNEY = "creditJourney";
	public static final String WORKEMAILID = "workEmailId";
	public static final String IS_SALARIED = "isSalaried";
	public static final String USERPROFILEOUTPUT = "userProfileOutput";
	public static final String USERPROFILE = "userProfile";
	public static final String RESI_TYPE_LIST = "resiTypeList";
	public static final String OCCUPATION_LIST = "occupationList";
	
	public static final String CODE = "code";
	public static final String CIBIL_JSON = "CIBIL_JSON";
	public static final String PRODUCTCODE = "productcode";
	public static final String PRODUCTDESC = "productdesc";
	public static final String CIBIL_REF_KEY = "cibilReferenceKey";
	public static final String CIBIL_TYPE = "cibiltype";
	public static final String CIBIL_TYPE_CONSUMER = "CONSUMERCIBIL";
	public static final String PAN_NUMBER = "panNumber";
	public static final String TYPE_KEY = "typeKey";
	public static final String OFFICIAL_EMAIL_TYPE_KEY = "67";
	public static final String EMAIL = "email";
	public static final String POSTAL_CODE = "postalCode";
	public static final String CIBIL_REQUIRED = "cibilRequired";
	public static final String MCP_REQUEST_OUTPUT = "mcpRequestOutput";
	public static final String PRODUCT_LISTING_KEY = "productListingKey";
	public static final String L2_PRODUCT_CODE = "l2ProductCode";
	public static final String L3_PRODUCT_CODE = "l3ProductCode";
	public static final String L4_PRODUCT_CODE = "l4ProductCode";
	public static final String PRODUCT_CODE_EMIC = "EMIC";
	public static final String BFL = "bfl";
	public static final String AXIS = "axis";
	public static final String PRODUCT_CODE_CC = "CC";
	public static final String PRODUCT_CODE_OMPL = "OMPL";
	public static final String OFFER_CHECK = "OFFER_CHECK";
	public static final String CREDIT_OFFER_CHECK = "CREDIT_OFFER_CHECK";
	public static final String OMPL_LEAD_BOOST_EVENT_NAME = "OMPL_LEAD_BOOST";
	public static final String OMPL_LEAD_BOOST_EVENT_TYPE = "OMPL_LEAD_BOOST_INIT";
	public static final String REDIRECT_TO_EMIC = "redirectToEmic";
	public static final String OTP = "otp";
	public static final String CONSENT = "consent";
	public static final String IS_CASE_CREATED = "isCaseCreated";
	public static final String CONSENT_ACTION = "consentAction";
	public static final String RESEND = "resend";
	public static final String BACK = "back";
	public static final String ISOTPVALID= "isOTPValid";
	public static final String OTP_VALIDATION = "otpValidation";
	public static final String CARD_STATUS = "cardStatus";
	public static final String PARENT_APPLICATION_KEY = "parentApplicationKey";
	public static final String L2_PRODUCT_KEY = "l2ProductKey";
	public static final String STATUS = "status";
	public static final String QUALIFICATION_LOOKUP_LIST = "qualificationLookup";
	public static final String ANNUALTURNOVER_LOOKUP_LIST = "annualturnoverLookup";
	public static final String PRINCIPAL_FEATURES = "principalFeatures";
	public static final String PERCENTAGECOMPLETION = "percentageCompletion";
	public static final String STAGEPERCENTAGE = "stagePercentage";
	public static final String APPLICATION_RESUME = "applicationResume";
	public static final String APPLICATION_STATUS = "applicationStatus";
	public static final String ISINPROCESSING = "isInProcessing";
	public static final String L3_PRODUCT_KEY = "l3ProductKey";
	public static final String L4_PRODUCT_KEY = "l4ProductKey";
	public static final String PRINCIPALKEY = "principalKey";
	public static final String CHILDAPPLICATIONID = "childApplicationId";
	public static final String JOURNEY = "journey";
	public static final String EP = "EP";
	public static final String APPLICANT_TYPE_ONE = "1";
	public static final String APPLICANT_TYPE_TWO = "2";
	public static final String RESUME = "resume";
	public static final String IS_REJECTED = "isRejected";
	public static final String CARD_LIMIT = "cardLimit";
	public static final String CUST_NAME = "custName";
	public static final String CARD_STATUS_API= "cardStatusApi";
	public static final String APPLICANTKEY = "applicantKey";
	public static final String EMAILID = "emailId";
	public static final String EMPLOYER_KID = "employerKid";
	public static final String EMPLOYER_NAME = "employerName";
	public static final String FORCED_VERIFICATION = "forcedVerification";
	public static final String KID_PRESENT = "kidPresent";
	public static final String EMPLOYERID = "employerId";
	public static final String EMAILTYPE_LIST = "emailTypeList";
	public static final String EMAILCODE = "emailCode";
	public static final String KARZA_VERIFICATION_RESPONSE = "karzaVerificationResponse";
	public static final String FPPAPPLICABLE = "fppApplicable";
	public static final String CHILDPRESENT = "childpresent";
	public static final String GENDER_LIST = "genderList";
	public static final String VAS_APPLICATION_KEY = "vasApplicationKey";
	public static final String APPROVED = "Approved";
	public static final String APPROVAL_PENDING = "APPROVAL_PENDING";
	public static final String VAS_COST_OUTPUT = "vasCostOutput";
	public static final String FPPSELECTED = "fppSelected";
	public static final String BUNDLE_REJECTED = "bundleRejected";
	public static final String OCCUPATION_TYPE_KEY = "occupationTypeKey";
	public static final String APPLICATION_KEY = "applicationkey";
	public static final String CITYKEY = "citykey";
	public static final String PINCODE_KEY = "pincodekey";
	

	public static final String RESIDENCE_STATUS = "residenceStatus";
	public static final String RESIDENCE_VALUE = "residenceValue";
	public static final String MARITALSTATUSVALUE = "maritalStatusValue";
	public static final String APPLICANT_ID = "applicantId";
	public static final String APPLICATIONID = "applicationId";
	public static final String CIBIL_RESPONSE = "cibilResponse";
	public static final String CITY = "city";
	public static final String CITY_KEY = "cityKey";
	public static final String OCCUPATIONTYPECODE = "occupationTypeCode";
	public static final String UW="underWriterSegmentBREActivity";
	public static final String APPSCORE = "appscore";
	public static final String LRSCORE = "lrScore";
	public static final String MLSCORE = "mlScore";
	public static final String LRSCOREV2 = "lrScoreV2";
	public static final String APPSCORE_UPDATE = "appscoreUpdate";
	public static final String FINALSCORE = "finalScore";
	public static final String ADDRESSLIST = "addressList";
	public static final String PINCODEKEY = "pincodeKey";
	public static final String CITYNAME = "cityName";
	public static final String MARITALSTATUSLIST = "maritalStatusList";
	public static final String BRANCHNAME = "branchName";
	public static final String CIBILRESPONSEJSON = "cibilResponseJSON";
	public static final String CUSTOMERID = "customerId";
	public static final String PRODUCTTYPE = "productType";
	public static final String SOURCE = "source";
	public static final String CONSUMER_CIBIL = "consumer cibil";
	public static final String COMMERCIAL_CIBIL = "commercial cibil";
	public static final String DEROG_JSON = "derogJson";
	public static final String MOBILE_NUMBER = "mobileNumber";
	public static final String FULLNAME = "fullName";
	public static final String COMPANY_NAME = "companyName";
	public static final String L2PRODUCTKEY = "l2productkey";
	public static final String SALARY = "salary";
	public static final String NETSALARY = "netSalary";
	public static final String CREDITVIDYARESPONSE = "creditVidyaResponse";
	public static final String CVVALIDATIONSTATUS = "cvValidationstatus";
	public static final String VALIDATIONSTATUS = "validationstatus";
	public static final String APP_SCORE = "appScore";
	public static final String OPEN_ARC_CARD_LISTING_OUTPUT = "openArcCardListingOutput";
	public static final String OPEN_MARKET_LOAN_LISTING = "openMarketsLoanListing";
	public static final String AUTH_TOKEN = "authtoken";
	public static final String SPACE_DELIMETER = " ";
	public static final String ACTIVITI_SKIP_EXPRESSION = "_ACTIVITI_SKIP_EXPRESSION_ENABLED";
	public static final String EMPRMASTCATEGORY = "emprMastCategory";
	public static final String EMPRMASTSUBCATEGORY = "emprMastSubcategory";
	public static final String NSDLPANRESPONSE = "nsdlPanResponse";
	public static final String NSDLNAMEMATCHFLAG = "nsdlNameMatchFlag";
	public static final String OBLIGATION_AMT= "obligationOutput";
	public static final String CIBIL_TYPE_COMMERCIAL = "COMMERCIALCIBIL";
	public static final String VERIFICATION_SOURCE_BFSD = "BFSD";
	public static final String VERIFICATION_SOURCE_EP = "EP";
	public static final String EMAIL_TYPE_OFFICIAL = "OFFICIAL";
	public static final String PRINCIPALFEATUREFLAG = "principalFeatureFlag";
	public static final String INDUSTRYTYPEFLAG = "industryTypeFlag";
	public static final String SALARIEDDETAIL = "salariedDetail";
	public static final String PRINCIPALINDUSTRY = "principalIndustry";
	public static final String BUSINESS = "SEMP";
	public static final String SALARIED = "SALR";
	public static final String DOCTOR = "DOC";
	public static final String CA_CS_ICWA = "CAICWA";
	public static final String CREDITVIDYA_RISKCATEGORY="creditVidyaRiskCategory";
	public static final String VALIDATION_STATUS ="validationstatus";
	public static final String ADDITIONAL_CIBILFLAG = "additionalCibilFlag";
	public static final String CIBIL_SCORE = "cibilScore";
	
	public static final String LOOKUP_SOURCE_QUALIFICATION = "QUALIFICATION";
	public static final String NEGATIVEAREAFLAG = "negativeAreaFlag";
	public static final String PROPERTYDETAILS = "propertyDetails";
	public static final String HLPRODUCTINTENT = "hlProductIntent";
	public static final String ADDRESS_TYPE_PROPERTY = "PROPERTY";
	
	public static final String BTBANKMASTERKEY = "btBankMasterKey";
	public static final String BTBANKNAME = "btBankName";
	public static final String PRODUCT_CODE_OMSL = "OMSL";
	
	public static final String PARENT_STATUS = "parentStatus";
	
	public static final String NOTIFICATION_TYPE_CODE = "notificationTypeCode";
	public static final String PHONE_NUMBER = "phoneNumber";
	public static final String RECIPIENT_EMAIL= "recipientEmailId";
	public static final String TEMPLATE_DATA_MAP = "templateDataMap";
	

	public static final String REJECTION_SYSTEM = "rejectionSystem";
	public static final String PENNENT_SUCCESS = "pennantSuccess";
	public static final String SALARIED_OTHR_EMPLOYER = "salariedOtherEmployer";
	public static final String CV_REQUIRED = "cvRequired";
	
	public static final String BUNDLEPRESENT = "bundlepresent";
	public static final String CHILDSTATUS = "childStatus";
	public static final String PARENTSTATUS = "parentStatus";
	public static final String STATUSVALUE = "statusValue";
	public static final String REJECTED_STATUS = "Rejected";
	public static final String REDIRECTTOLISTING = "redirectToListing";
	public static final String COMMUNICATION = "communication";
	
	public static final Long PERSONAL_EMAIL_TYPE = 70l;
	public static final Long OFFICIAL_EMAIL_TYPE = 67l;
	public static final String LKPCODE_ANNUALTURNOVER = "ANNUALTURNOVER";
	public static final String LKPCODE_BUSINESSVINTAGE = "BUSINESSVINTAGE";
	public static final String LKPCODE = "lkpcode";
	public static final String OFFER_API = "OFFERAPI";
	public static final String ADDR_TYPE_KEY = "50";
	public static final String ETB = "ETB";
	public static final String LEAD = "LEAD";
	public static final String RBL_PRINCIPAL_KEY = "2";
	public static final String PRINCIPAL_KEY = "principalkey";
	public static final String RBL_PRINCIPAL_VALUE = "rbl";
	public static final String PRINCIPAL = "principal";
	public static final String CUST_REF_SRC = "PRTOFFAPI";
	public static final int UNSECURED_LOAN = 10002;
	public static final int CARD = 10001;
	public static final String CURRENT_ADDRESS = "Current Address";
	public static final String PERMANENT_ADDRESS = "Permanent Address";
	public static final String OFFICE_ADDRESS = "Office Address";
	public static final String OTHER_ADDRESS = "OTHER Address";
	public static final String CURRENT_ADDR = "CURRENT";
	public static final String PERMANENT_ADDR = "PERM";
	public static final String OFFICE_ADDR = "OFFICE";
	public static final String OTHER_ADDR = "OTHERS";
	public static final String APPLICANT_UPDATE = "APPLICANT_UPDATE";
	public static final String APPLICANT_UPDATE_EVENT_TYPE = "UPDATE";
	public static final String CMPT_CORR_ID = "cmptcorrid";
	public static final String KIBANA_OFFER_SRC = "BFDL_LOANS";
	public static final String KIBANA_OFFER_TARGET = "OFFER_DATA";
	public static final String SUCCESS = "SUCCESS";
	public static final int SECURED_LOAN = 10003;
	public static final String CUSTOMER_TYPE= "customerType";
	public static final String PRINCIPLECUSTTYPE= "principleCustType";
	public static final String ISDEMOGCOMPLETED= "isDemogCompleted";
	
	public static final String REQUEST_HEADERS = "requestHeaders"; //do not use this variable for any other purpose and do not set in execution unless required to set headers.
	
	public static final String LEAD_BOOST_QUEUE_FILTER_ATTRB = "applicationEvent";
	public static final String LEAD_BOOST_EVENT_FILTER = "LEAD_BOOST";
	
	public static final String PROPERTYSIZE = "propertySizeBHK";
	public static final String PROPERTYSIZE_SQFT = "propertySizeInSqrFeet";
	public static final String PROPERTY_REFERENCE = "propertyRefference";
	public static final String BUILDER_NAME = "builderName";
	public static final String PROJECT_NAME = "projectName";
	public static final String PROPERTY_COST = "propertyCost";
	public static final String PROPERTY_STATUS = "propertyStatus";
	public static final String PROPERTY_TYPE = "propertyType";
	public static final String PROPERTY_USAGE = "propertyUsage";
	public static final String SEARCH_ASSIST_REQUIRED = "searchAssistRequired";
	public static final String CUSTOMER_BUDGET = "userBudget";
	public static final String PROPERTY_MARKET_VALUE = "propertyMarketValue";
	public static final String PROPERTY_PINCODE_DISPLAY = "propertyPincode";
	
	public static final String CALL_PROPERTY_ADDRESS = "isPropertyAddress";
	public static final String SHOW_COAPPLICANT_EARNING = "showCoAppEarning";
	public static final String CO_APPLICATION_USER_ATTRIBUTE_KEY = "coapplicationUserAttributeKey";

	public static final String USERKEY = "userKey";
	public static final String DELIVERY_ADDRESS = "DELIVERY";
	public static final String LISTING_BRE_ELIGILITY_TYPE_IV = "IV";
	public static final String STATUS_COMPLETED = "COMPLETED";
	public static final String INDMASTKEY = "indMastKey";
	
	public static final String USERATTRIBUTETYPE = "1";
	public static final String BITLY_NEXT = "bitlynext";
	public static final String ESIGN_TASKKEY = "esign";
	public static final String ESIGN_THANK_YOU_TASKKEY = "esignthankyou";
	public static final String IS_OFFICIALEMAIL_PRESENT = "isOfficialEmailPresent";
	
	public static final String NTB_PLCS = "NTB_PLCS";
	public static final String PLCS_MTS = "PLCS_MTS";
	public static final String PLCS_HTS = "PLCS_HTS";
	public static final String PLTB = "PLTB";
	public static final String PL="PL";
	
	public static final String SOURCE_JOURNEY = "JOURNEY";
	public static final String DOC_SENT_STATUS_SUCCESS = "Success";
	
	
	public static final String OFFER_AVAILABLE = "offerAvailable";
	
	public static final String SKIP_API_EXCEPTION = "skipAPIException";
	public static final String API_EXCEPTION_ARISE = "APIExceptionArise";
	public static final String NSDLPANRESPONSE_VERIFY = "nsdlPanResponse_verify";
	
	public static final String CIBIL_TYPE_FROM_MCP = "cibilType";
	public static final String APPLICANT = "APPLICANT";
	public static final String RESIDENCE_TYPE_KEY="residenceTypeKey";
	
	public static final String CIBIL_STATE_INACTIVE = "INACTIVE";
	public static final String AXIS_LOAN_KEY = "26";	
	
	public static final String BMR_CUSTOMER_ID = "bmrCustomerId";
	
	public static final String IS_ESIGN_REQUIRED = "isEsignRequired";
	
	public static final String UW_REQUIRED = "uwRequired";
	
	public interface Salaried {
	}

	public interface Business {
	}

	public interface Back {
	}
	
	public interface Resume {
		
	}
	
	public interface FreshApplication {
		
	}

	public interface Next {
	}
	public interface EmailOTPValidate {
	}

	public interface OfferCase {
	}
	
	public interface CAICWA {}

	public static final String KARZA_CHILD_REJECTED = "karzaChildRejected";
	public static final String CHILD_APPLICANT_TYPE = "2";
	public static final String PERSONAL_EMAIL_TYPE_KEY="70";
	public static final String PINCODEBEAN = "pinCodeBean";
	public static final String L2_PRODUCT_DESC = "l2ProductDesc";
	
	public static final String CUSTOMER_ID = "customerId";
	public static final String HOLD_REASON = "holdReason";
	public static final String IN_ACTIVEDATE = "inactiveDate";
	public static final String ACTIVEDATE = "activeDate";
	public interface EmailTOKENValidate {
	}
	
	public interface Other {
		
	}
	
	public static final String CALL_LENDINGKART_DEDUPE = "callLendingkartDedupe";
	public static final String LEAD_PUSH_DUPLICATE_RECORD = "DUPLICATE_RECORD";
	public static final String IS_DUPLICATE_RECORD = "isDuplicateRecord";
	public static final String KARZA_TYPE="karzaType";
	public static final String WORK_EMAIL_REQUIRED = "workEmailRequired";
	public static final String EMPLOYER_NAME_OTHER = "employerNameOther";
	public static final String CHILD_USERPROFILEOUTPUT = "childUserProfileOutput";
	public static final String IS_GENERIC_EMAIL_DOMAIN = "isGenericEmailDomain";
	
	public static final String FIRST_CIBIL_RECORD = "firstCibilRecord";
	public static final String CONSUMER_ADDRESS = "consumerAddress";
	public static final String CIBIL_ADDRESS_SOURCE = "CIBIL";
	public static final String CIBIL_ADDRESSLINE1 = "addressLine1";
	public static final String CIBIL_RESIDENCE_ADDRESS_CATEGORY_CODE = "02";
	public static final String CIBIL_OFFCIE_ADDRESS_CATEGORY_CODE = "03";
	public static final String CIBIL_ADDRESS_CATEGORY = "addressCategory";
	public static final String CIBIL_DATE_REPORTED = "dateReported";
	public static final String CURRENT_ADDRESS_OBJECT = "currentAddress";
	public static final String APP_SALARY_DETAILS_LIST = "salaryDetails";
	public static final String IS_MEDHAS_DECISION_APPROVED = "isMedhasDecisionApproved";
	public static final String IS_MEDHAS_OFFER_PRESENT = "isMedhasOfferPresent";
	public static final String MEDHAS_OFFER = "medhasOffer";
	public static final String IS_IV_REQUIRED_FOR_CV = "isCVIncomeVerificationRequired";
	public static final String LOAN_PRICING = "loanPricing";
	public static final String VALID_FPP_BUNDLE = "validFppBundle";
	public static final String RISKOFFERTYPE = "riskoffertype";
	public static final String IS_GIN_OFFER = "isGinOffer";
	public static final String IS_NONGIN_ETB_OFFER = "isNonGinEtbOffer";
	public static final String GIN_ASYCNH_ANALYTICS_FLOW_FLAG = "ginAsycnhAnalyticsFlowFlag";
	public static final String IS_ETB_CUSTOMER = "isEtbCustomer";
	public static final String EMAIL_COMMUNICATION_SEND_REQUIRED = "emailCommunicationSendRequired";
	public static final String ETB_TYPE = "etbType";
	public static final String PERSONAL_EMAIL_REQUIRED = "personalEmailRequired";
	public static final String DESIGNATION_REQUIRED = "designationRequired";
	public static final String ALLOW_CURRENT_ADDRESS_UPDATE = "allowCurrentAddressUpdate";
	public static final String EMPLOYER_REQUIRED = "employerRequired";
	public static final String BMR2 = "BMR2";
	public static final String BMR2_QUEUE_FILTER_ATTRB = "applicationEvent";
	public static final String APPLICATION_DETAILS = "applicationDetails";
	public static final String ADD_SRC_OFFERAPI = "offerapi";
	public static final String ADD_SRC_APPLICANT = "applicant";
	public static final String TAKE_BACK_TO_LISTING_PAGE = "takeBackToListingPage";
	
	public static final String ADDRESS_SPECIAL_CHAR_SKIP = "[|<>?^=;(){}\\[\\]!*@\\\\_:~,#$%&+??/`]";
	public static final String ALTERNATE_MOBILE_NUMBER_FLAG = "alternateMobileNumberFlag";
	public static final Long AMEX_PRINCIPALKEY = 27l;
	public static final String OFFICIAL_EMAIL_FLAG = "officialemailFlag";
	public static final String OFFER_ROI = "13";
	public static final String AXIS_PRODUCT_CODE="AXISSOL";
	public static final Integer OFFER_TENURE = 60;
	public static final String IS_EP_PRICING_APPROVED = "isEpPricingApproved";
	public static final String YES = "YES";
	public static final String SALARIED_DOCTOR = "Salaried Doctor";
	public static final String SELF_EMPLOYED_DOCTOR = "Self Employed Doctor";
	public static final String IS_PROL_APPLICANT = "isProlApplicant";
	public static final String DEMOG = "demog";
	public static final String ESTIMATED_INCOME ="estimatedIncome";
	public static final String CIBIL_RESPONSJSON="cibilResponseJSON";
	public static final String ANALYTICS_SALARY_NOT_FOUND = "analyticsSalaryNotFound";
	public static final String OCCUPATION_UPDATE_FLAG = "ocupationUpdateFlag";
	public static final String SHOPSTATUS = "shopStatus";
	public static final String CORPORATELINKAGE = "corporateLinkageType";
	public static final Long ICICI_CARDS_PRINCIPALKEY = 21l;
	public static final String KARZA_REQUIRED = "karzaRequired";
	public static final Long MARITAL_STATUS_M_KEY = 27l;
	public static final String MARITAL_STATUS_M = "M";
	public static final String MARRIED = "MARRIED";
	public static final String MARITAL_STATUS_S = "S";
	
	public static final Long GENDER_KEY = 27l;
	public static final String GENDER_M = "M";
	public static final String MALE = "Male";
	public static final String GENDER_F = "F";
	
	public static final Long RESIDENCE_KEY = 1l;
	public static final String RESIDENCE_OWN = "OWN";
	public static final String RESIDENCE_OWN_VALUE = "Own";
	public static final String RESIDENCE_RENTAL = "RENTAL";
	public static final String RESIDENCE_RENTALFAMILY = "RENTALFAMILY";
	public static final String RESIDENCE_OTHERS = "OTHERS";
	public static final String ANALYTICS_REPAYMENT_FLOW_FLAG = "analyticsRepaymentFlowFlag";
	public static final String ANALYTICS_REPAYMENT_SOURCE = "Analytics";
	public static final String PENNANT_REPAYMENT_SOURCE = "Pennant";
	public static final String IS_DUMMY_EMAIL = "isDummyEmail";
	public static final String DUMMYEMAIL_REGEX = ".*(?i)dummy.*@bajajfinserv.in";
	public static final String CIBIL_SOURCE_CONSTANT="CIBIL";
	public static final String PERFIOS_SOURCE_CONSTANT="PERFIOS";
	public static final String FORMAT="format";
	public static final String CIBIL_REFERENCE="cibilreference";
	public static final String CIBIL_REFERENCE_KEY="cibilreferencekey";	
	public static final String APPLICANT_KEY="applicantkey";
	public static final String REJECTED = "REJECTED";
	public static final String ESIGN_STATUS_SUSPENDED = "SUSPENDED";
	public static final String RAISE_EXCEPTION = "RAISE_EXCEPTION";
	public static final String CUSTOMER_DECLARED_INCOME = "customerDeclaredIncome";
	public static final String PERFIOS_SALARY = "perfiosSalary";
	public static final String PERFIOS = "perfios";
	public static final String FINAL_INCOME = "finalIncome";
	public static final String SALARY_SOURCE = "salarySource";
	public static final String IMPUTEDINCOME = "IMPUTEDINCOME";
	public static final String SUB_STAGE_CODE = "subStageCode";
	public static final String EMPR_CLASSIFICATION = "empClassification";
	public static final String CUSTOMER_SEGMENT = "customerSegment";
	public static final String CUSTOMER_PROFILESEGMENT = "customerProfileSegment";
	public static final String MICRO_SEGMENT = "microSegment";
	public static final String USERATTRIBUTEKEY = "userattributekey";
	public static final String BFLSOLFLDG = "BFLSOLFLDG";
	public static final String SALARYSOURCE_EPCREDIT = "EPCREDIT";
	public static final String EPCREDIT_SALARY = "epCreditSalary";
	public static final String SALARY_DETAILS = "salariesDetails";
	public static final String IS_SEGMENT_RERUN = "segmentReRunFlag";
}
