package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class ObligationDetail implements Serializable{

	private String accountType;
	
	private Integer currentBalance;
	
	private Integer emiAmount;
	
	private Integer mob;
	
	private Integer highCreditSanctionAmt;
	
	private String reportingShortName;

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Integer getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(Integer currentBalance) {
		this.currentBalance = currentBalance;
	}

	public Integer getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(Integer emiAmount) {
		this.emiAmount = emiAmount;
	}

	public Integer getMob() {
		return mob;
	}

	public void setMob(Integer mob) {
		this.mob = mob;
	}

	public Integer getHighCreditSanctionAmt() {
		return highCreditSanctionAmt;
	}

	public void setHighCreditSanctionAmt(Integer highCreditSanctionAmt) {
		this.highCreditSanctionAmt = highCreditSanctionAmt;
	}

	public String getReportingShortName() {
		return reportingShortName;
	}

	public void setReportingShortName(String reportingShortName) {
		this.reportingShortName = reportingShortName;
	}
	
	
}
