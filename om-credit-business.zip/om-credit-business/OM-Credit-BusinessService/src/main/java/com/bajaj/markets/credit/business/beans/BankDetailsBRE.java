package com.bajaj.markets.credit.business.beans;

public class BankDetailsBRE {

	private String accountNo;
	private String bankBranchName;
	private String bankName;
	private String cName;
	private String ifscCode;
	private String micrCode;
	private String sourceName;
	private String mandateAddedby;
	private String mandatereference;

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	public void setMandateAddedby(String mandateAddedby) {
		this.mandateAddedby = mandateAddedby;
	}

	public void setMandatereference(String mandatereference) {
		this.mandatereference = mandatereference;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public String getBankBranchName() {
		return bankBranchName;
	}

	public String getBankName() {
		return bankName;
	}

	public String getcName() {
		return cName;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public String getSourceName() {
		return sourceName;
	}

	public String getMandateAddedby() {
		return mandateAddedby;
	}

	public String getMandatereference() {
		return mandatereference;
	}

	@Override
	public String toString() {
		return "BankDetailsBRE [accountNo=" + accountNo + ", bankBranchName=" + bankBranchName + ", bankName="
				+ bankName + ", cName=" + cName + ", ifscCode=" + ifscCode + ", micrCode=" + micrCode + ", sourceName="
				+ sourceName + ", mandateAddedby=" + mandateAddedby + ", mandatereference=" + mandatereference + "]";
	}

}
