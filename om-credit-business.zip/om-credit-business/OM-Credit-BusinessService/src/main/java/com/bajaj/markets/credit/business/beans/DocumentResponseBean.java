package com.bajaj.markets.credit.business.beans;

public class DocumentResponseBean {

	private BFLDocument document;

	private AppDocumentTrackingBean transactionResponse;

	private CreditDocumentTypeBean masterResponse;

	public BFLDocument getDocument() {
		return document;
	}

	public void setDocument(BFLDocument document) {
		this.document = document;
	}

	public AppDocumentTrackingBean getTransactionResponse() {
		return transactionResponse;
	}

	public void setTransactionResponse(AppDocumentTrackingBean transactionResponse) {
		this.transactionResponse = transactionResponse;
	}

	public CreditDocumentTypeBean getMasterResponse() {
		return masterResponse;
	}

	public void setMasterResponse(CreditDocumentTypeBean masterResponse) {
		this.masterResponse = masterResponse;
	}
}
