package com.bajaj.markets.credit.business.beans;

public class Specilizations {
	
	private Long spclmastkey;
	
	private String spclmastcode;
	
	private String spcldesc;
	
	public Long getSpclmastkey() {
		return spclmastkey;
	}

	public void setSpclmastkey(Long spclmastkey) {
		this.spclmastkey = spclmastkey;
	}

	public String getSpclmastcode() {
		return spclmastcode;
	}

	public void setSpclmastcode(String spclmastcode) {
		this.spclmastcode = spclmastcode;
	}

	public String getSpcldesc() {
		return spcldesc;
	}

	public void setSpcldesc(String spcldesc) {
		this.spcldesc = spcldesc;
	}
	
	@Override
	public String toString() {
		return "Specilization [spclmastkey=" + spclmastkey + ", spclmastcode=" + spclmastcode + ", spcldesc=" + spcldesc
				+ "]";
	}	
	
}