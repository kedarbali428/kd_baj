package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class MandateBreRequest {

	private Long applicationId;
	private Long mandateBRECallType;
	private List<MandateDetailsBRE> mandateDetails;
	private List<BankDetailsBRE> bankDetails;
	private String source;

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public void setMandateDetails(List<MandateDetailsBRE> mandateDetails) {
		this.mandateDetails = mandateDetails;
	}

	public void setBankDetails(List<BankDetailsBRE> bankDetails) {
		this.bankDetails = bankDetails;
	}

	public void setMandateBRECallType(Long mandateBRECallType) {
		this.mandateBRECallType = mandateBRECallType;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Override
	public String toString() {
		return "MandateBreRequest [applicationId=" + applicationId + ", mandateBRECallType=" + mandateBRECallType
				+ ", mandateDetails=" + mandateDetails + ", bankDetails=" + bankDetails + ", source=" + source + "]";
	}

}
