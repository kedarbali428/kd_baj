/**
 * 
 */
package com.bajaj.markets.credit.business.helper;

/**
 * Interface to store constants used in Activiti
 * 
 * @author 764504
 *
 */
public interface WorkflowConstants {
	public static final String PAYLOAD = "PAYLOAD";
}
