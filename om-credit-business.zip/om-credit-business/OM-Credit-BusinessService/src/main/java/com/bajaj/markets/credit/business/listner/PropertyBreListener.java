package com.bajaj.markets.credit.business.listner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ObligationDetail;
import com.bajaj.markets.credit.business.beans.PanDetails;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.google.gson.Gson;

@Component
public class PropertyBreListener {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	private McpCheck mcpCheck;

	private static final String CLASS_NAME = PropertyBreListener.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void prePropertyListing(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preListing");
		JSONObject mcpRequest = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		JSONObject breRequest = new JSONObject();
		JSONObject propertyInput = new JSONObject();
		propertyInput.put("applicationId", execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		propertyInput.put("cibilScore", execution.getVariable("cibilScore"));
		propertyInput.put("occupationType", execution.getVariable("occupationType"));
		propertyInput.put("product", execution.getVariable(CreditBusinessConstants.PRODUCTDESC));
		
		creditBusinessHelper.populatePropertyBreRequestFromMcpDetails(propertyInput, mcpRequest);

		breRequest.put("propertyInput", propertyInput);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, breRequest);
	}
	
	@SuppressWarnings("unchecked")
	public void postPropertyListing(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start MCP post");
		JSONObject jsonObject = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		Boolean eligiblePrincipleFound = false;
		if (execution.getVariable(CreditBusinessConstants.OUTPUT) != null) {
			JSONObject propertyOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
			if (propertyOutput != null && propertyOutput.get("propertyOutput") != null) {
				JSONObject rejectionOutput = CreditBusinessHelper.getJSONObject(propertyOutput.get("propertyOutput"));
				if (rejectionOutput != null && rejectionOutput.get("principleProductDetails") != null) {
					List<Map<String, Object>> principleProdDetailList = (List<Map<String, Object>>) rejectionOutput.get("principleProductDetails");
					if (!CollectionUtils.isEmpty(principleProdDetailList)) {
						eligiblePrincipleFound = principleProdDetailList.stream().anyMatch(details -> (boolean) details.get("isEligible"));
					}
				}
			}
		}
		execution.setVariable(CreditBusinessConstants.IS_REJECTED, !eligiblePrincipleFound);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start MCP post");
	}
}

	
