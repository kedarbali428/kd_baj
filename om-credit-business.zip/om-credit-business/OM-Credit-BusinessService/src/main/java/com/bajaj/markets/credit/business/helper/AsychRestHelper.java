package com.bajaj.markets.credit.business.helper;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * Class used for making Aynch rest calls 
 * 
 * @author 764504
 *
 */
@Component
@RefreshScope
public class AsychRestHelper {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private BFLLoggerUtilExt logger;

	ObjectMapper mapper = new ObjectMapper();

	private static final String CLASS_NAME = AsychRestHelper.class.getCanonicalName();

	/**
	 * Method used for making Asynchronous call to rest API
	 * 
	 * @param httpMethod
	 * @param url
	 * @param responseType
	 * @param params
	 * @param requestJson
	 * @param headers
	 * @param customDefaultHeaders
	 */
	@Async
	public void invokeAsynchRestEndpoint(HttpMethod httpMethod, String url, Class<?> responseType, Map<String, String> params, String requestJson,
			HttpHeaders headers, CustomDefaultHeaders customDefaultHeaders) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start invokeAsynchRestEndpoint");
		CreditBusinessHelper.updateHttpHeaders(headers, customDefaultHeaders);
		ResponseEntity<?> responseEntity = null;
		try {
			HttpEntity<Object> entity = new HttpEntity<>(requestJson, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "RequestEndpoint : " + url);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request JSON : " + requestJson);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Params : " + params);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request Type : " + httpMethod);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Headers : " + headers);
			if (null != params) {
				responseEntity = restTemplate.exchange(url, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplate.exchange(url, httpMethod, entity, responseType);
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Response from endpoint : " + responseEntity);
			if (null != responseEntity.getBody())
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Body == " + mapper.writeValueAsString(responseEntity.getBody()));
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "End excuteRestCall");
		} catch (RestClientException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Async Call failed " + url + ", Error : " + e.getMessage());
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, " RestClientException during Asych call : " + url + ",  with request :" + requestJson, e);
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Async Call failed " + url + ", Error : " + e.getMessage());
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, " Exception during Asych call : " + url + ",  with request :" + requestJson, e);
		}
	}
}