package com.bajaj.markets.credit.business.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.PrincipalBean;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.service.CreditMasterDataService;
import com.google.gson.Gson;

@Service
public class CreditMasterDataServiceImpl implements CreditMasterDataService {

	@Autowired
	private CreditBusinessHelper creditBusinessHelper;

	@Autowired
	private BFLLoggerUtilExt logger;

	@Value("${api.omcreditapplicationservice.referenceattributes.GET.url}")
	private String serviceableMasterUrl;

	@Value("${api.omreferencedatareferencedataservice.principal.get.url}")
	private String principalMasterDataUrl;

	private static final String CLASSNAME = CreditMasterDataServiceImpl.class.getCanonicalName();

	@Override
	public List<Reference> getServiceableMasterData(String principalCode, String serviceableCode, String status,
			HttpHeaders headers) {
		List<Reference> serviceableCodes = null;
		try {
			Map<String, String> params = new HashMap<>();
			Gson gson = new Gson();
			Long principalKey = getPrincipalDetails(principalCode, headers, gson);
			if (null != principalKey) {
				params.put("principalKey", String.valueOf(principalKey));
				params.put("referenceAttributeCode", serviceableCode);
				params.put("status", status);
				ResponseEntity<?> serviceableMasterRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
						serviceableMasterUrl, String.class, params, null, headers);

				if (null != serviceableMasterRes && null != serviceableMasterRes.getBody()
						&& HttpStatus.OK.equals(serviceableMasterRes.getStatusCode())) {
					Reference[] references = gson.fromJson(serviceableMasterRes.getBody().toString(),
							Reference[].class);
					serviceableCodes = Arrays.asList(references);
					logger.info(CLASSNAME, BFLLoggerComponent.UTILITY,
							"inside CreditMasterDataServiceImpl -  getServiceableMasterData method"
									+ serviceableMasterRes + " - ended");
				}
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception: ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("OCBS-001", "Technical Exception Occurred."));
		}

		return serviceableCodes;
	}

	private Long getPrincipalDetails(String principalCode, HttpHeaders headers, Gson gson) {
		ResponseEntity<?> principalMasterDataRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				principalMasterDataUrl, String.class, null, null, headers);
		Long principalKey = null;
		if (null != principalMasterDataRes && null != principalMasterDataRes.getBody()
				&& HttpStatus.OK.equals(principalMasterDataRes.getStatusCode())) {
			List<PrincipalBean> principalBeanList = new ArrayList<>();
			if (null != principalMasterDataRes.getBody()) {
				PrincipalBean[] principalBeans = gson.fromJson(principalMasterDataRes.getBody().toString(),
						PrincipalBean[].class);
				principalBeanList = Arrays.asList(principalBeans);
			}
			logger.info(CLASSNAME, BFLLoggerComponent.UTILITY,
					"inside CreditMasterDataServiceImpl - getPrincipalDetails method for application "
							+ principalBeanList + " - ended");
			for (PrincipalBean principalDetails : principalBeanList) {

				if (StringUtils.equals(principalCode, String.valueOf(principalDetails.getPrincipleCode()))) {
					principalKey = principalDetails.getPrinciplekey();
				}
			}
		}
		return principalKey;
	}

}
