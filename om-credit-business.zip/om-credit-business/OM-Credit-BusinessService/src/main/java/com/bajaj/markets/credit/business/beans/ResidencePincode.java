package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class ResidencePincode implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7038092810668710702L;
	
	private Reference city;
	private Reference state;
	private Reference country;
	@NotNull
	private String pincode;
	private Boolean negativeAreaFlag;
	private Boolean oglFlag;
	
	public Reference getCity() {
		return city;
	}
	public void setCity(Reference city) {
		this.city = city;
	}
	public Reference getState() {
		return state;
	}
	public void setState(Reference state) {
		this.state = state;
	}
	public Reference getCountry() {
		return country;
	}
	public void setCountry(Reference country) {
		this.country = country;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public Boolean getNegativeAreaFlag() {
		return negativeAreaFlag;
	}
	public void setNegativeAreaFlag(Boolean negativeAreaFlag) {
		this.negativeAreaFlag = negativeAreaFlag;
	}
	public Boolean getOglFlag() {
		return oglFlag;
	}
	public void setOglFlag(Boolean oglFlag) {
		this.oglFlag = oglFlag;
	}
	
	@Override
	public String toString() {
		return "ResidencePincode [city=" + city + ", state=" + state + ", country=" + country + ", pincode=" + pincode
				+ ", negativeAreaFlag=" + negativeAreaFlag + ", oglFlag=" + oglFlag + "]";
	}
	
}
