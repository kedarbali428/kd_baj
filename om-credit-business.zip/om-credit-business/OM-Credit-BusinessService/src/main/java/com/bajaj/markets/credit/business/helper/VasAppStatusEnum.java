package com.bajaj.markets.credit.business.helper;

public enum VasAppStatusEnum {

	REJECTED("Rejected");

	private final String value;

	private VasAppStatusEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

}
