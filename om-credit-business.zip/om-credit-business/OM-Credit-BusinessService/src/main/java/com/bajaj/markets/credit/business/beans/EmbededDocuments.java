package com.bajaj.markets.credit.business.beans;

public class EmbededDocuments {
	
	private String listofFiles;

	public String getListofFiles() {
		return listofFiles;
	}

	public void setListofFiles(String listofFiles) {
		this.listofFiles = listofFiles;
	}

	@Override
	public String toString() {
		return "EmbededDocuments [listofFiles=" + listofFiles + "]";
	}
	

}
