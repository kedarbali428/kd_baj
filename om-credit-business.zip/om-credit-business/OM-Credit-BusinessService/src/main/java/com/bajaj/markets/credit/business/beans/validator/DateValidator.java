package com.bajaj.markets.credit.business.beans.validator;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;

@Component
public class DateValidator implements ConstraintValidator<DateConstraint, String> {

	private String format;

	@Override
	public void initialize(DateConstraint dateConstraintAnnotation) {
		this.format = dateConstraintAnnotation.format();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (value == null) {
			return false;
		}
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			dateFormat.setLenient(false);
			dateFormat.parse(value);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void validateAppointmentDateTime(String principalCode, String appointmentDateTimeFrom,
			String appointmentDateTimeTo) {
		if (StringUtils.equalsIgnoreCase("ICICI BANK", principalCode)) {
			validateIciciCardAppointmentDateTime(appointmentDateTimeFrom, appointmentDateTimeTo);
		}

	}

	private void validateIciciCardAppointmentDateTime(String appointmentDateTimeFrom, String appointmentDateTimeTo) {
		try {
			Timestamp appointmentTimestampFrom = Timestamp.valueOf(appointmentDateTimeFrom);
			Timestamp appointmentTimestampTo = Timestamp.valueOf(appointmentDateTimeTo);
			long diff = appointmentTimestampTo.getTime() - appointmentTimestampFrom.getTime();
			long min = TimeUnit.MILLISECONDS.toMinutes(diff);
			if (60 != min) {
				throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OCBSICB-10001", "Invalid appointment data time."));
			}
		} catch (Exception e) {
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OCBSICB-10001", "Invalid appointment data time."));
		}
	}

}
