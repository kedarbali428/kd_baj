package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICANTID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_JSON;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_REF_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_STATE_INACTIVE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE_COMMERCIAL;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE_CONSUMER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DATE_OF_BIRTH;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DOB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMAIL;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2_PRODUCT_CODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAN_NUMBER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PINCODEKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PRODUCT_CODE_OMPL;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SKIP_API_EXCEPTION;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.TYPE_KEY;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean;

@Component
public class CibilListener {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallHelper;
	
	@Autowired
	PublisherService publisherService;
	
	@Autowired
	CustomDefaultHeaders customHeaders;
	
	@Value("${default.cibil.refresh.days:20}")
	private Integer defaultCibilRefreshDays;
	
	@Value("${aws.fhcr.report.topic.arn}")
	private String topicArn;
	
	@Autowired
	MasterDataRedisClientHelper masterDataRedisClientHelper;

	public void postFetchCibil(DelegateExecution execution) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "Start postFetchCibil");
		ArrayList<?> fetchCibilResponses = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		execution.setVariable("cibilType", null);
		execution.setVariable("cibilScore", null);
		execution.setVariable("cibilState", "");
		execution.setVariable("cibilReferenceKey", null);

		if (null != fetchCibilResponses && !fetchCibilResponses.isEmpty()) {
			JSONObject fetchCibilResponse = null;
			for (Object activeCibilResponse : fetchCibilResponses) {
				fetchCibilResponse = CreditBusinessHelper.getJSONObject(activeCibilResponse);
				if (null != fetchCibilResponse.get("state")
						&& "COMPLETED".equalsIgnoreCase((String) fetchCibilResponse.get("state")))
					break;
				else {
					Double cibilReferenceKey = (Double) fetchCibilResponse.get("cibilReferenceNumber");
					execution.setVariable("cibilState", fetchCibilResponse.get("state"));
					execution.setVariable("cibilReferenceKey", cibilReferenceKey.longValue());
					fetchCibilResponse = null;
				}
			}

			if (fetchCibilResponse != null) {
				Double cibilReferenceKey = (Double) fetchCibilResponse.get("cibilReferenceNumber");
				execution.setVariable("cibilState", fetchCibilResponse.get("state"));
				execution.setVariable("cibilReferenceKey", cibilReferenceKey.longValue());
				if (fetchCibilResponse.get("cibilTypeAndScore") != null) {
					List<Map<String, Object>> typeScoreList = (List<Map<String, Object>>) fetchCibilResponse
							.get("cibilTypeAndScore");
					if (!CollectionUtils.isEmpty(typeScoreList)) {
						execution.setVariable("cibilType", typeScoreList.get(0).get("cibilType"));
						execution.setVariable("cibilScore", typeScoreList.get(0).get("scoreV3"));
						execution.setVariable("additionalCibilFlag", null!=typeScoreList.get(0).get("addlCibilFlg")? ((Double)typeScoreList.get(0).get("addlCibilFlg")).intValue():0);
					}
				}
			}
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "End postFetchCibil");
	}
	
	public void preFetchCibil(DelegateExecution execution) {
		Long applicantKey = ((Double) execution.getVariable(CreditBusinessConstants.APPLICANTKEY)).longValue();
		execution.setVariable(CreditBusinessConstants.APPLICANTKEY, applicantKey);
	}

	@SuppressWarnings("unchecked")
	public void preAuthenticateCibil(DelegateExecution execution) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAuthenticateCibil");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(REQUEST));
		JSONObject cibilAuthenticateRequest = new JSONObject();

		cibilAuthenticateRequest.put("response", request.get("otp"));
		cibilAuthenticateRequest.put("questionType", "OTP");
		cibilAuthenticateRequest.put("resendOtp", request.get("resendOtp"));

		execution.setVariable(CreditBusinessConstants.PAYLOAD, cibilAuthenticateRequest);
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "End preAuthenticateCibil");
	}

	public void postAuthenticateCibil(DelegateExecution execution) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "Start postAuthenticateCibil");
		JSONObject authenticateCibilResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
		execution.setVariable("authenticationRequired", true);

		if (null != authenticateCibilResponse && !authenticateCibilResponse.containsKey("errorCode")) {
			execution.setVariable("authenticationRequired", authenticateCibilResponse.get("authenticationRequired"));
			execution.setVariable(CIBIL_REF_KEY, Double.valueOf(authenticateCibilResponse.get("cibilReferenceNumber").toString()).longValue());
			execution.setVariable("cibilState", authenticateCibilResponse.get("state"));
		} else {
			execution.setVariable("cibilAuthenticateErrorRes", authenticateCibilResponse);
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "End postAuthenticateCibil");
	}

	@SuppressWarnings("unchecked")
	public void preCibil(DelegateExecution execution, boolean performCommercialCibil) {
		JSONObject cibilRequest = new JSONObject();
		
		if(!performCommercialCibil) {
			JSONObject userData = new JSONObject();
	
			JSONObject name = CreditBusinessHelper.getJSONObject(execution.getVariable(NAME));
			userData.put("firstName", name.get("firstName"));
			userData.put("lastName", null != name.get("lastName") ? name.get("lastName") : name.get("middleName"));
			userData.put("number", execution.getVariable(MOBILE));
			userData.put(DATE_OF_BIRTH, execution.getVariable(DOB));
			userData.put("identifierName", "TaxId");
			userData.put("identifier", execution.getVariable(PAN_NUMBER));
			userData.put(EMAIL, execution.getVariable(EMAIL));
			userData.put("postalCode", execution.getVariable("postalCode"));
	
			cibilRequest.put("userData", userData);
			
			String cibilType = execution.getVariable(CIBIL_TYPE).toString();
			if ("CONSUMERCIBIL".equalsIgnoreCase(cibilType)) {
				cibilRequest.put("provider", "TRANSUNION");
			} else if ("COMMERCIALCIBIL".equalsIgnoreCase(cibilType)) {
				cibilRequest.put("provider", "TRANSUNION");
			} else {
				cibilRequest.put("provider", "");
			}
	
			cibilRequest.put("cibilType", cibilType);
			cibilRequest.put("applicationKey", execution.getVariable(APPLICATION_ID));
			cibilRequest.put("applicantKey", execution.getVariable(APPLICANTID));
			
			if(PRODUCT_CODE_OMPL.equalsIgnoreCase(execution.getVariable(L2_PRODUCT_CODE).toString()) 
					&& CIBIL_TYPE_CONSUMER.equalsIgnoreCase(cibilType)) {
				execution.setVariable(SKIP_API_EXCEPTION, true);
				cibilRequest.put("cibilRefreshDays", defaultCibilRefreshDays);
			} else {
				execution.setVariable(SKIP_API_EXCEPTION, false);
			}
			
		} else {
			cibilRequest = (JSONObject) execution.getVariable(PAYLOAD);
			cibilRequest.put("cibilType", "COMMERCIALCIBIL");
			cibilRequest.put("provider", "TRANSUNION");
			
			execution.setVariable(CIBIL_TYPE, CIBIL_TYPE_COMMERCIAL);			
			execution.setVariable(SKIP_API_EXCEPTION, false);
		}
		
		execution.setVariable(PAYLOAD, cibilRequest);
	}

	public void postCibil(DelegateExecution execution) {
		JSONObject cibilResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		
		boolean skipAPIException = (boolean) execution.getVariable(SKIP_API_EXCEPTION);
		Object exceptionArisedObj = execution.getVariable(API_EXCEPTION_ARISE);
		
		if(skipAPIException && (
				(null != exceptionArisedObj && (boolean) exceptionArisedObj) || (cibilResponse.containsKey("errorCode"))
					|| (cibilResponse.containsKey("state") && CIBIL_STATE_INACTIVE.equalsIgnoreCase(cibilResponse.get("state").toString()))
				)) {
			execution.setVariable("authenticationRequired", true);
		} else {
			execution.setVariable("authenticationRequired", false);
			if (cibilResponse != null) {
				execution.setVariable(CIBIL_REF_KEY, Double.valueOf(cibilResponse.get("cibilReferenceNumber").toString()).longValue());
				execution.setVariable("cibilState", cibilResponse.get("state"));
				execution.setVariable("authenticationRequired", cibilResponse.get("authenticationRequired"));
			}
		}
		execution.setVariable("cibilResponseFromPostAPI", cibilResponse);
		
		// remove exception skip flags from execution once task gets completed
		List<String> variablesToRemoveFromExecution = new ArrayList<String>();
		variablesToRemoveFromExecution.add(SKIP_API_EXCEPTION);
		variablesToRemoveFromExecution.add(API_EXCEPTION_ARISE);
				
		execution.removeVariables(variablesToRemoveFromExecution);
	}

	public void fetchCibilDocumentPost(DelegateExecution execution) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start fetchCibilDocumentPost");
		
		Object isAPIResponseNull = execution.getVariable(CreditBusinessConstants.IS_API_RESPONSE_NULL);
		String cibilJson = null;
		
		if(null != isAPIResponseNull && (boolean) isAPIResponseNull) {
			Object cibilResponseFromPostAPI = execution.getVariable("cibilResponseFromPostAPI");
			cibilJson = null !=  cibilResponseFromPostAPI ? 
					CreditBusinessHelper.getJSONObject(cibilResponseFromPostAPI).toString() : null;
		} else {
			Object output = execution.getVariable(CreditBusinessConstants.OUTPUT);
			cibilJson = output != null
					? CreditBusinessHelper.getJSONObject(output).toString()
					: null;
		}
		
		execution.setVariable(CIBIL_JSON, cibilJson != null ? (String) cibilJson : null);
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End fetchCibilDocumentPost");
	}

	public void fetchBasicUserProfileForCibilPost(DelegateExecution execution) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "Start fetchUserProfileForCibil");

		ArrayList<?> userProfiles = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);

		if (null != userProfiles) {
			for (Object object : userProfiles) {
				JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
				if (null != userProfile && userProfile.get(APPLICATION_USER_ATTRIBUTE_TYPE).equals("1")) {
					execution.setVariable(APPLICATION_USER_ATTRIBUTE_KEY, userProfile.get(APPLICATION_USER_ATTRIBUTE_KEY));
					execution.setVariable(MOBILE, userProfile.get(MOBILE));
					execution.setVariable(DOB, userProfile.get(DATE_OF_BIRTH));
					execution.setVariable(NAME, userProfile.get(NAME));

					// for next personal email fetch call
					execution.setVariable(TYPE_KEY, 70);
				}
			}
		}

		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End fetchUserProfileForCibil with user attribute key: " + execution.getVariable(APPLICATION_USER_ATTRIBUTE_KEY));
	}

	public void fetchPersonalEmailForCibilPost(DelegateExecution execution) {
		JSONObject emailObject = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(EMAIL, emailObject.get(EMAIL));

		// for next address fetch call
		execution.setVariable(TYPE_KEY, 50);
	}
	
	public void fetchAddressForCibilPost(DelegateExecution execution) {
		JSONObject addrObject = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(PINCODEKEY, addrObject.get("pincodeKey"));
	}

	public void fetchPanDocumentForCibilPost(DelegateExecution execution) {
		JSONObject panDocument = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(PAN_NUMBER, panDocument.get("documentNumber"));
	}
	
	public void preFetchCibilForCibilType(DelegateExecution execution) {
		if (null == execution.getVariable(CIBIL_TYPE))
			execution.setVariable(CIBIL_TYPE, "");
	}

	
	public void getPersonalEmail(DelegateExecution execution) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "start getPersonalEmail");
		Email emailDetails = null;
		String applicationId= execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString();
		try {
			emailDetails = apiCallHelper.getEmail(applicationId, execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString(), EmailTypeEnum.PERON1.getValue().toString());
		} catch (CreditBusinessException e) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
					"Exception while fetching email for appId = " + applicationId, e);
		}
		if (null != emailDetails) {
			execution.setVariable(CreditBusinessConstants.EMAIL, emailDetails.getEmail());
		}
		// for next address fetch call
				execution.setVariable(TYPE_KEY, 50);
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "end getPersonalEmail");
	
	}
	
	@SuppressWarnings("unchecked")
	public void preUpdateCibilRefKey(DelegateExecution execution) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "Start preUpdateCibilRefKey");
		Long cibilReferenceKey = (Long) execution.getVariable(CIBIL_REF_KEY);
		JSONObject documentUpdate = new JSONObject();
		documentUpdate.put(CreditBusinessConstants.DOCUMENT_NAME_KEY, 2);
		documentUpdate.put(CreditBusinessConstants.DOCUMENT_NUMBER, cibilReferenceKey.toString());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, documentUpdate);
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "End preUpdateCibilRefKey");
	}
	
	@SuppressWarnings("unchecked")
	public void triggerFhcrEvent(DelegateExecution execution) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "Start triggerFhcrEvent");
		Long cibilReferenceKey = (Long) execution.getVariable(CIBIL_REF_KEY);
		String cibilState = (String) execution.getVariable("cibilState");
		String cibiltype = (String) execution.getVariable(CIBIL_TYPE);
		
		if(null != cibilReferenceKey && "COMPLETED".equalsIgnoreCase(cibilState) && "CONSUMERCIBIL".equalsIgnoreCase(cibiltype)){
			Map<String, String> headers = new HashMap<>();
			headers.put(CreditBusinessConstants.AUTH_TOKEN, customHeaders.getAuthtoken());
			headers.put("cmptcorrid", customHeaders.getCmptcorrid());
			headers.put("userKey", String.valueOf(customHeaders.getUserKey()));
			JSONObject payload = new JSONObject();
			payload.put("cibilReferenceKey", cibilReferenceKey);
			payload.put("cibilType", "CONSUMERCIBIL");
			EventMessage eventMessage = new EventMessage();
			eventMessage.setEventName("FHCR_REPORT_GENERATION");
			eventMessage.setEventType("CREATE");
			eventMessage.setPayload(payload);
			eventMessage.setHeaders(headers);
			publisherService.publish(topicArn, eventMessage);
			
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "FHCR Event triggered successfully");
		}else{
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "Condition not met for triggerring FHCR event");
		}
		
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "End triggerFhcrEvent");
	}
	
	public void getPincodeFromPincodekey(DelegateExecution execution) {
		Object pincodekeyObj = execution.getVariable(PINCODEKEY);
		if(null != pincodekeyObj) {
			LocationResponseBean locationResponseBean = masterDataRedisClientHelper.getPinCodeByKey(Double.valueOf(pincodekeyObj.toString()).longValue());
			execution.setVariable("postalCode", locationResponseBean.getPincode());
		} else {
			execution.setVariable("postalCode", null);
		}
	}
	
	public void setAppAttributeTaggedCibilReferenceKeyToExecution(DelegateExecution execution) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("applicationid", execution.getVariable(APPLICATION_ID).toString());
		params.put("userattributekey", apiCallHelper.getUserProfile(params, "1", false).getApplicationUserAttributeKey());
		DocumentDetails documentDetails = apiCallHelper.getDocumentDetail(params, 2l);
		
		execution.setVariable(CIBIL_REF_KEY, null != documentDetails && null != documentDetails.getDocumentNumber() 
				&& documentDetails.getDocumentNumber().matches("\\d+") ? documentDetails.getDocumentNumber() : null);
	}
}