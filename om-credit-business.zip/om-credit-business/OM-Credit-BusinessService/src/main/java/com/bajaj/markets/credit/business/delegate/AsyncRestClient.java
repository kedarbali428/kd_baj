package com.bajaj.markets.credit.business.delegate;

import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.helper.AsychRestHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
@Scope("prototype")
public class AsyncRestClient implements JavaDelegate {

	RestTemplate restTemplate;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	AsychRestHelper asynchRestHelper;

	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;

	@Autowired
	Environment env;

	private static final String CLASS_NAME = AsyncRestClient.class.getCanonicalName();
	private Expression requestURL;
	private Expression requestType;
	private Expression requestParams;

	@Override
	public void execute(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "************* Start Asynch Call  *************");
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "Execution started for task = " + execution.getCurrentActivityId());
		Object requestURLLocal = null;
		Object requestTypeLocal = null;
		Object requestParamsLocal = null;
		String requestEntity = null;
		String requestUrl = null;
		HttpMethod method = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		if (null != requestURL && requestURL.getValue(execution) != null) {
			requestURLLocal = requestURL.getValue(execution);
			if (env.getProperty(requestURLLocal.toString()) != null)
				requestUrl = env.getProperty(requestURLLocal.toString()).trim();
		}
		if (null != requestType && requestType.getValue(execution) != null) {
			requestTypeLocal = requestType.getValue(execution);
			method = HttpMethod.resolve(requestTypeLocal.toString());
		}

		if (null != requestParams && null != requestParams.getValue(execution)) {
			requestParamsLocal = requestParams.getValue(execution);
		}

		try {

			if (!HttpMethod.GET.equals(method)) {
				requestEntity = CreditBusinessHelper.objectToJson(execution.getVariable(CreditBusinessConstants.PAYLOAD));
			}

			Map<String, String> map = creditBusinessHelper.setrequestParams(requestParamsLocal);
			asynchRestHelper.invokeAsynchRestEndpoint(method, requestUrl, Object.class, map, requestEntity, headers,
					new CustomDefaultHeaders(customDefaultHeaders));
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Exception occured  " + e.getMessage());
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, " Exception occured for Asych call : ", e);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "************* End Asych Call  *************");
	}
}