package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICANTID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CHILDAPPLICATIONID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CHILD_APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMAIL_COMMUNICATION_SEND_REQUIRED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMAIL_TYPE_OFFICIAL;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2PRODUCTKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SKIP_API_EXCEPTION;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.TYPE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.VERIFICATION_SOURCE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.VERIFICATION_SOURCE_BFSD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.VERIFICATION_SOURCE_EP;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.EmailPageActions;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
public class EmailVerificationListener {
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Value("${om.email.verification.sources}")
	private String configuredVerificationSources;
	
	
	private final static String CLASS_NAME = EmailVerificationListener.class.getCanonicalName();

	public void isEmailVerificationRequired(DelegateExecution execution) {
		JSONObject productListObject = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));

		execution.setVariable("emailVerificationRequired", false);
		if (null != productListObject) {
			ArrayList<?> productList = (ArrayList<?>) productListObject.get("productList");
			Object emailVerificationRequiredFlag = CreditBusinessHelper.getJSONObject(productList.get(0))
					.get("emailverificationrequiredflag");
			if (null != emailVerificationRequiredFlag) {
				if(1 == ((Double) emailVerificationRequiredFlag).intValue()) {
					execution.setVariable("emailVerificationRequired", true);
				}
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "product listing not having emailverificationrequiredflag");
			}
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "product listing object null");
		}
	}
	
	public void getUserProfile(DelegateExecution execution) {
		ArrayList<?> userProfiles = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);

		if (null != userProfiles) {
			for (Object object : userProfiles) {
				JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
				if (null != userProfile && userProfile.get(APPLICATION_USER_ATTRIBUTE_TYPE).equals("1")) {
					execution.setVariable(CHILD_APPLICATION_USER_ATTRIBUTE_KEY,
							userProfile.get(APPLICATION_USER_ATTRIBUTE_KEY));
					
					// for next office email fetch call
					execution.setVariable(TYPE_KEY, 67);
				}
			}
		}
	}
	
	public void postGetEmail(DelegateExecution execution) {
		JSONObject emailResponseJson = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		
		execution.setVariable("emailVerified", false);
		execution.setVariable("isVerificationIdPresent", false);
		execution.setVariable("verificationIdKey", null);
		
		if(null != emailResponseJson && !emailResponseJson.isEmpty()) {
			Object verificationsObjs = emailResponseJson.get("verifications");
			
			if(null != verificationsObjs) {
				ArrayList<?> verifications = (ArrayList<?>) verificationsObjs;
				
				for (Object verificationObj : verifications) {
					JSONObject verification = CreditBusinessHelper.getJSONObject(verificationObj);
					
					Object verificationSource = verification.get(VERIFICATION_SOURCE);
					Object emailVerified = verification.get("isVerified");
					Object verificationReference = verification.get("verificationReference");
					
					if(null != verificationSource && ( configuredVerificationSources.contains(verificationSource.toString())) ) {
						if(null != emailVerified && Boolean.valueOf(emailVerified.toString())) {
							execution.setVariable("emailVerified", true);
							break;
						} else {
							if (null != verificationReference) {
								execution.setVariable("isVerificationIdPresent", true);
								execution.setVariable("verificationReference", ((Double) verificationReference).longValue());
							}
						}						
					} else {
						logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "verification source: " + verification);
					}
				}
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "verifications not available with email response");
			}
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "email reponse is null");
		}
	}
	
	public void setEmailType(DelegateExecution execution) {
		execution.setVariable("emailType", EMAIL_TYPE_OFFICIAL);
	}
	
	@SuppressWarnings("unchecked")
	public void preSendOtp(DelegateExecution execution) {
		JSONObject emailVerificationRequest = new JSONObject();
		
		emailVerificationRequest.put("applicantId", execution.getVariable(APPLICANTID));
		emailVerificationRequest.put("parentApplicationKey", execution.getVariable(APPLICATION_ID));
		emailVerificationRequest.put("applicationId", execution.getVariable(CHILDAPPLICATIONID));
		emailVerificationRequest.put("emailType", execution.getVariable("emailType"));
		emailVerificationRequest.put("productCatkey", execution.getVariable(L2PRODUCTKEY));
		emailVerificationRequest.put("productMastserkey", "69");
		
		execution.setVariable(PAYLOAD, emailVerificationRequest);
		
		execution.removeVariable("emailPageResponsePayload");
		
	}
	
	@SuppressWarnings("unchecked")
	public void postEmailVerification(DelegateExecution execution) {
		JSONObject emailVerificationResponseJson = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		
		if(null != emailVerificationResponseJson && emailVerificationResponseJson.containsKey("errorCode")) {
			execution.setVariable("emailVerified", false);
			execution.setVariable("emailPageResponsePayload", emailVerificationResponseJson);
		} else {
			Object verifiedFlag = emailVerificationResponseJson.get("verifiedFlag");
			JSONObject emailDetailsRequest = CreditBusinessHelper.getJSONObject(execution.getVariable("EX_emailDetail"));
			
			boolean emailVerified = false;
			if(null != verifiedFlag) {
				emailVerified = Boolean.valueOf(verifiedFlag.toString());
			}
			execution.setVariable("emailVerified", emailVerified);
			
			if(null != emailDetailsRequest) {
				emailDetailsRequest.put("verified", emailVerified);
			}
			execution.setVariable("emailPageResponsePayload", emailDetailsRequest);
		}
		
	}
	
	@SuppressWarnings("unchecked")
	public void preEmailVerification(DelegateExecution execution) {
		JSONObject emailVerificationRequest = new JSONObject();
		JSONObject emailDetail = CreditBusinessHelper.getJSONObject(execution.getVariable("EX_emailDetail"));
		
		String action = emailDetail.get("action").toString(); // should not be null hence did not put null check
		
		if (!EmailPageActions.VALIDATEEMAILTOKEN.name().equalsIgnoreCase(action)) {
			emailVerificationRequest.put("otp", emailDetail.get("otp"));
			emailVerificationRequest.put("verificationMethod", "OTP");
		} else {
			emailVerificationRequest.put("token", emailDetail.get("emailToken"));
			emailVerificationRequest.put("verificationMethod", "TOKEN");
		}
		
		emailVerificationRequest.put("applicationId", execution.getVariable(CHILDAPPLICATIONID));
		emailVerificationRequest.put("emailType", execution.getVariable("emailType"));
		
		execution.removeVariable("emailPageResponsePayload");
		execution.setVariable(PAYLOAD, emailVerificationRequest);
	}
	
	// sets dummy action on take event of email already verified flow
	public void setDummyAction(DelegateExecution execution, String action) {
		execution.setVariable("action", action);
	}
	
	public void setEmailCommInitiationAndValidationOutsideEVFlow(DelegateExecution execution,
			boolean emailCommunicationInitiationFlow, boolean validationNotAtEVStage) {
		execution.setVariable("emailCommunicationInitiationFlow", emailCommunicationInitiationFlow);
		execution.setVariable("validationNotAtEVStage", validationNotAtEVStage);
	}
	
	public void preGetEmailInitiationResponse(DelegateExecution execution) {
		execution.setVariable(SKIP_API_EXCEPTION, true);
	}
	
	public void postGetEmailInitiationResponse(DelegateExecution execution) {
		Object apiException = execution.getVariable(API_EXCEPTION_ARISE);
		
		execution.setVariable(EMAIL_COMMUNICATION_SEND_REQUIRED, true);
		if (null == apiException || !(boolean) apiException) {
			JSONObject emailVerificationResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
			if (null != emailVerificationResponse) {
				Object emailSentFlagObj = emailVerificationResponse.get("emailSentFlag");
				if(null != emailSentFlagObj && ((boolean) emailSentFlagObj)) {
					execution.setVariable(EMAIL_COMMUNICATION_SEND_REQUIRED, false);
				}
			}		
		}
		
		// remove exception skip flags from execution once task gets completed
		List<String> variablesToRemoveFromExecution = new ArrayList<String>();
		variablesToRemoveFromExecution.add(SKIP_API_EXCEPTION);
		variablesToRemoveFromExecution.add(API_EXCEPTION_ARISE);

		execution.removeVariables(variablesToRemoveFromExecution);
	}
	
}
