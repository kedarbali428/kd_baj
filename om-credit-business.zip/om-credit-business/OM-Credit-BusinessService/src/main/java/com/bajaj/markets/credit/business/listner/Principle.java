package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATIONKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CONSENT_ACTION;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.BUSINESS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.FULLNAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAN_NUMBER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PERSONALEMAILID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SALARIED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SKIP_API_EXCEPTION;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.STAGEPERCENTAGE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SUCCESS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.beans.AdditionalDetailLoans;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.ApplicationStatus;
import com.bajaj.markets.credit.business.beans.PrincipalFeature;
import com.bajaj.markets.credit.business.beans.RejectionBean;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.google.gson.Gson;

@Component
public class Principle {

	private static final String BUSINESS_NATURE = "businessNature";
	private static final String EMP_SECTOR_SERVICE = "empSectorService";
	private static final String COPYOVER_SOURCE_ADDRESS_PERM = "ADDRESS_PERM";
	private static final String COPYOVER_SOURCE_ALTERNATE_MOBILE_NO = "ALTERNATE_MOBILE_NO";
	private static final String COPYOVER_SOURCE_ADDRESS_DELIVERY = "ADDRESS_DELIVERY";
	private static final String COPYOVER_SOURCE_ADDITIONAL_DETAILS = "ADDITIONAL_DETAILS";
	private static final String COPYOVER_SOURCE_OCCUPATION = "OCCUPATION";

	private static final String RELATION_CODE_MASTER_KEY = "relationCodeMasterKey";

	private static final String SALUTATION_KEY = "salutationKey";

	private static final String RELATION_OBJ = "relation";

	private static final String SALUTATION_OBJ = "salutation";

	private static final String RELATION_REFERENCE = "relationReference";

	private static final String OTP_GENERATE_MFA = "mfa";
	private static final String OTP_GENERATE_POLICY_PL = "PL";
	private static final String OTP_GENERATE_POLICY_NAME = "policyName";
	private static final String VERIFICATION_ATTRB_MOBILE = "MOBILE";
	private static final String MOBILE_VERIFIED_FLAG = "mobileVerifiedFlag";
	private static final String KEY_VERIFICATIONS = "verifications";
	private static final String VERIFICATION_SOURCE_BFSD_OTP = "BFSD_OTP";
	private static final String IS_VERIFIED = "isVerified";
	private static final String VERIFICATION_SOURCE = "verificationSource";
	private static final String VERIFICATION_ATTRIBUTE = "verificationAttribute";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	PublisherService publisherService;
	
	@Autowired
	CustomDefaultHeaders customHeaders;
	
	@Value("${aws.publisher.principal.topic.arn}")
	private String topicArn;

	@Value("${api.omcreditcardprincipleintegration.custdemog.GET.url}")
	private String getPrincipalCustDemogUrl;

	private static final String CLASS_NAME = Principle.class.getCanonicalName();
	
	@SuppressWarnings("unchecked")
	public void preAxisProcessApi(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAxisProcessApi");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		execution.setVariable(CreditBusinessConstants.APPLICATION_ID, request.get(CreditBusinessConstants.APPLICATION_ID));
		JSONObject processApiRequest = new JSONObject();
		processApiRequest.put(CreditBusinessConstants.OTP, null != request.get(CreditBusinessConstants.CONSENT) ? request.get(CreditBusinessConstants.CONSENT).toString() : null);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, processApiRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preAxisProcessApi");
	}
	
	public void postAxisProcessApi(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postAxisProcessApi");
		JSONObject processApiResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		Boolean isCaseCreated = null != processApiResponse.get(CreditBusinessConstants.IS_CASE_CREATED) ? (Boolean)processApiResponse.get(CreditBusinessConstants.IS_CASE_CREATED) : null;
		execution.setVariable(CreditBusinessConstants.IS_CASE_CREATED, isCaseCreated);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postAxisProcessApi");
	}
	
	public void postFetchParentStatus(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postFetchParentStatus");
		JSONObject statusResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.PARENTSTATUS, "");
		execution.setVariable(CreditBusinessConstants.REDIRECTTOLISTING, Boolean.FALSE);
		if(null != statusResponse){
			String parentStatus = null != statusResponse.get(CreditBusinessConstants.STATUSVALUE) ? statusResponse.get(CreditBusinessConstants.STATUSVALUE).toString() : null;
			execution.setVariable(CreditBusinessConstants.PARENTSTATUS,parentStatus);
			if(!CreditBusinessConstants.REJECTED_STATUS.equalsIgnoreCase(parentStatus)){
				execution.setVariable(CreditBusinessConstants.REDIRECTTOLISTING, Boolean.TRUE);
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postFetchParentStatus");
	}
	
	@SuppressWarnings({ "unchecked"})
	public void prePrincipalFeatureUpdate(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start prePrincipalFeatureUpdate");
		JSONObject principleFeatureDetails = new JSONObject();
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		List<PrincipalFeature> principalFeatures = (List<PrincipalFeature>) additionalDetail.get(CreditBusinessConstants.PRINCIPAL_FEATURES);
		execution.setVariable(CreditBusinessConstants.PRINCIPALFEATUREFLAG, Boolean.FALSE);
		execution.setVariable(CreditBusinessConstants.OCCUPATION_UPDATE_FLAG, Boolean.FALSE);
		if(!CollectionUtils.isEmpty(principalFeatures)){
			principleFeatureDetails.put(CreditBusinessConstants.PRINCIPAL_FEATURES, principalFeatures);
			execution.setVariable(CreditBusinessConstants.PAYLOAD, principleFeatureDetails);
			execution.setVariable(CreditBusinessConstants.PRINCIPALFEATUREFLAG, Boolean.TRUE);
		}
		JSONObject empSectorServiceJson = CreditBusinessHelper.getJSONObject(additionalDetail.get(EMP_SECTOR_SERVICE));
		JSONObject businessNatureJson = CreditBusinessHelper.getJSONObject(additionalDetail.get(BUSINESS_NATURE));
		if(null != additionalDetail.get(CreditBusinessConstants.INDUSTRY_TYPE)
				|| (null != empSectorServiceJson && null != empSectorServiceJson.get(CreditBusinessConstants.KEY))
				|| (null != businessNatureJson && null != businessNatureJson.get(CreditBusinessConstants.KEY))){
			execution.setVariable(CreditBusinessConstants.OCCUPATION_UPDATE_FLAG, Boolean.TRUE);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End prePrincipalFeatureUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void preUpdateAdditionalOccupationData(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preIndustryTypeUpdate");
		JSONObject professJsonObject = new JSONObject();
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject occupationType = CreditBusinessHelper.getJSONObject(additionalDetail.get(CreditBusinessConstants.OCCUPATION_TYPE));
		
		professJsonObject.put("ocupationType", occupationType);
		
		switch (occupationType.get(CODE).toString()) {
			case SALARIED:
				JSONObject industryType = CreditBusinessHelper.getJSONObject(additionalDetail.get(CreditBusinessConstants.INDUSTRY_TYPE));
				JSONObject empSectorService = CreditBusinessHelper.getJSONObject(additionalDetail.get(EMP_SECTOR_SERVICE));
				JSONObject salariedDetail = new JSONObject();
				salariedDetail.put(CreditBusinessConstants.PRINCIPALINDUSTRY, industryType);
				salariedDetail.put(EMP_SECTOR_SERVICE, empSectorService);
				
				professJsonObject.put(CreditBusinessConstants.SALARIEDDETAIL, salariedDetail);
				break;
				
			case BUSINESS:
				JSONObject businessNature = CreditBusinessHelper.getJSONObject(additionalDetail.get(BUSINESS_NATURE));
				JSONObject businessOwnerDetails = new JSONObject();
				businessOwnerDetails.put(BUSINESS_NATURE, businessNature);
				
				professJsonObject.put("businessOwnerDetails", businessOwnerDetails);
				break;
			default:
				logger.info(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preUpdateAdditionalOccupationData() "
						+ "- Occupation update not defined for: " + occupationType);
				break;
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, professJsonObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preIndustryTypeUpdate");
	}
	
	public void postLeadPush(DelegateExecution execution) {
		execution.setVariable(CreditBusinessConstants.IS_DUPLICATE_RECORD, false);
		JSONObject leadPushResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		boolean isCaseCreated = null != leadPushResponse.get(CreditBusinessConstants.IS_CASE_CREATED) ? Boolean.valueOf(leadPushResponse.get(CreditBusinessConstants.IS_CASE_CREATED).toString()) : false;
		execution.setVariable(CreditBusinessConstants.IS_CASE_CREATED, isCaseCreated);
		String failureReason = null != leadPushResponse.get("failureReason") ? leadPushResponse.get("failureReason").toString() : null;
		if(!isCaseCreated && null !=failureReason && failureReason.equals(CreditBusinessConstants.LEAD_PUSH_DUPLICATE_RECORD)) {
			execution.setVariable(CreditBusinessConstants.IS_DUPLICATE_RECORD, true);
		}
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Is Case Created/Updated? " + isCaseCreated);
	}
	
	public void postNegativeAreaCheck(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postNegativeAreaCheck");
		execution.setVariable(CreditBusinessConstants.NEGATIVEAREAFLAG, Boolean.FALSE);
		Object neagativeAreaResponse = execution.getVariable(CreditBusinessConstants.OUTPUT);
		if(null != neagativeAreaResponse && neagativeAreaResponse instanceof Boolean && (Boolean)neagativeAreaResponse){
			execution.setVariable(CreditBusinessConstants.NEGATIVEAREAFLAG, Boolean.TRUE);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postNegativeAreaCheck");
	}
	
	public void preLeadPushStageUpdate(DelegateExecution execution, Long leadPushStagePercentage) {
		execution.setVariable(STAGEPERCENTAGE, 0l);
		execution.setVariable("leadPushStagePercentage", leadPushStagePercentage);
	}
	
	public void preChildToParentCopyOver(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preChildToParentCopyOver");
		List<String> sourceList = new ArrayList<>();
		sourceList.add("ADDRESS_CURRENT");
		sourceList.add("ADDRESS_OFFICE");
		Object officialemailFlag = execution.getVariable("officialemailFlag");
		if(null != officialemailFlag && (Boolean)officialemailFlag){
			sourceList.add("EMAIL_OFFICIAL");
		}
		Boolean updateProfileFlag = (Boolean)execution.getVariable("updateProfileFlag");
		Boolean deliveryAddressUpdateFlag = (Boolean)execution.getVariable("deliveryAddressUpdateFlag");
		Object occupationUpdateFlag = execution.getVariable(CreditBusinessConstants.OCCUPATION_UPDATE_FLAG);
		Object alternateMobileNumberFlag = execution.getVariable("alternateMobileNumberFlag");
		Boolean otherAddressUpdateFlag = (Boolean)execution.getVariable("otherAddressUpdateFlag");
		Object annualItrFlag = execution.getVariable("annualItrFlag");
		String principalKey = (String)execution.getVariable("principalKey");
		if(updateProfileFlag){
			sourceList.add(COPYOVER_SOURCE_ADDITIONAL_DETAILS);
		}
		if(deliveryAddressUpdateFlag){
			sourceList.add(COPYOVER_SOURCE_ADDRESS_DELIVERY);
		}
		if(null != occupationUpdateFlag && (Boolean) occupationUpdateFlag){
			sourceList.add(COPYOVER_SOURCE_OCCUPATION);
		}
		if(null != alternateMobileNumberFlag && (Boolean)alternateMobileNumberFlag){
			sourceList.add(COPYOVER_SOURCE_ALTERNATE_MOBILE_NO);
		}
		if(otherAddressUpdateFlag && (principalKey.equals("27") || "17".equalsIgnoreCase(principalKey))){
			sourceList.add(COPYOVER_SOURCE_ADDRESS_PERM);
		}
		if(null != annualItrFlag && (Boolean)annualItrFlag){
			sourceList.add(COPYOVER_SOURCE_OCCUPATION);
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, sourceList);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preChildToParentCopyOver");
	}
	
	 public void preLeadPush(DelegateExecution execution) {
		  execution.setVariable(PAYLOAD, null);
		  }
	 
	public void postBflModelBLeadPush(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Into postBflModelBLeadPush() started ");
		JSONObject leadPushResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		boolean isCaseCreated = null != leadPushResponse.get(CreditBusinessConstants.IS_CASE_CREATED)
				? Boolean.valueOf(leadPushResponse.get(CreditBusinessConstants.IS_CASE_CREATED).toString())
				: false;
		execution.setVariable(CreditBusinessConstants.IS_CASE_CREATED, isCaseCreated);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Into postBflModelBLeadPush() Is Case Created/Updated? " + isCaseCreated);
	}
	
	@SuppressWarnings("unchecked")
	public void preBflModelBLeadPush(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Into preBflModelBLeadPush() started ");
		JSONObject payload = new JSONObject();
		payload.put("cibilScore", execution.getVariable("cibilScore"));
		execution.setVariable(PAYLOAD, payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "preBflModelBLeadPush() completed");
	}
	
	public void postFetchPrincipalCustInfo(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postFetchPrincipalCustInfo");
		JSONObject custInfo = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.CUSTOMER_TYPE, "");
		if(null != custInfo && null != custInfo.get(CreditBusinessConstants.PRINCIPLECUSTTYPE) && ("ETB".equalsIgnoreCase(custInfo.get(CreditBusinessConstants.PRINCIPLECUSTTYPE).toString()) || "LEAD".equalsIgnoreCase(custInfo.get(CreditBusinessConstants.PRINCIPLECUSTTYPE).toString()))){
			execution.setVariable(CreditBusinessConstants.CUSTOMER_TYPE, "ETB");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postFetchPrincipalCustInfo");
	}
	
	public void postDemogConsentTask(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postDemogConsentTask");
		execution.setVariable(CreditBusinessConstants.REDIRECTTOLISTING, Boolean.FALSE);
		execution.setVariable("additionalDetailsBack", "");
		if(null != execution.getVariable(CreditBusinessConstants.CONSENT_ACTION) && CreditBusinessConstants.BACK.equalsIgnoreCase(execution.getVariable(CreditBusinessConstants.CONSENT_ACTION).toString())){
			execution.setVariable(CreditBusinessConstants.REDIRECTTOLISTING, Boolean.TRUE);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postDemogConsentTask");
	}
	
	public void postGetPrincipalTransaction(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetPrincipalTransaction");
		JSONObject principalTransactionInfo = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.ISDEMOGCOMPLETED, Boolean.FALSE);
		if(null != principalTransactionInfo && null != principalTransactionInfo.get(CreditBusinessConstants.ISDEMOGCOMPLETED) && principalTransactionInfo.get(CreditBusinessConstants.ISDEMOGCOMPLETED) instanceof Boolean){
			execution.setVariable(CreditBusinessConstants.ISDEMOGCOMPLETED, (Boolean)principalTransactionInfo.get(CreditBusinessConstants.ISDEMOGCOMPLETED));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetPrincipalTransaction");
	}
	
	public void postDemogApi(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postDemogApi");
		JSONObject demogApiResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		Boolean isCaseCreated = null != demogApiResponse.get(CreditBusinessConstants.ISOTPVALID) ? (Boolean)demogApiResponse.get(CreditBusinessConstants.ISOTPVALID) : null;
		execution.setVariable(CreditBusinessConstants.IS_CASE_CREATED, isCaseCreated);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postDemogApi");
	}
	
	@SuppressWarnings("unchecked")
	public void prePartnerDedupe(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "prePartnerDedupe() started");
		
		//Added this check to handle extra pre listener call in case of multiinstance of the service task
		Object partnerDedupeRequired = execution.getVariable("partnerDedupeRequired");
		
		if(null == partnerDedupeRequired || !(boolean) partnerDedupeRequired) {
			Map<String, Boolean> partnerDedupeRequiredMap = (Map<String, Boolean>) execution.getVariable("partnerDedupeRequiredMap");
			
			for (Map.Entry<String, Boolean> entry : partnerDedupeRequiredMap.entrySet()) {
				if(entry.getValue()) {
					execution.setVariable("principalToDedupe", Long.valueOf(entry.getKey()));
					preparePartnerDedupePayload(execution, entry.getKey());
					
					partnerDedupeRequiredMap.put(entry.getKey(), false);
					execution.setVariable("partnerDedupeRequiredMap", partnerDedupeRequiredMap);
					break;
				}
			}
			
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "prePatnerDedupe() payload preparation skipped. Creating multiple instance of parnterDedupe task");
			execution.removeVariable("partnerDedupeRequired");
		}
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "prePartnerDedupe() completed");
	}
	
	private void preparePartnerDedupePayload(DelegateExecution execution, String principalKey) {
		JSONObject payload= new JSONObject();
		switch (principalKey) {
		case "11":
			payload.put("appattrbkey", execution.getVariable(APPLICATION_USER_ATTRIBUTE_KEY));
			payload.put("email", execution.getVariable(PERSONALEMAILID));
			payload.put("mobile", execution.getVariable(MOBILE));
			break;
		
		case "24":
			payload.put("appattrbkey", execution.getVariable(APPLICATION_USER_ATTRIBUTE_KEY));
			payload.put("panNumber", execution.getVariable(PAN_NUMBER));
			break;
			
		case "15":
			payload.put("appattrbkey", execution.getVariable(APPLICATION_USER_ATTRIBUTE_KEY));
			payload.put("panNumber", execution.getVariable(PAN_NUMBER));
			payload.put("mobile", execution.getVariable(MOBILE));
			break;
			
		default:
			break;
		}
		execution.setVariable(PAYLOAD, payload);
	}

	public void postFetchDateOfBirth(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start fetchDemogDetails");
		execution.setVariable("demogMatchFlag", Boolean.TRUE);
		JSONObject response = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		boolean dateOfBirthMatched = false;
		boolean nameMatched = false;
		boolean panMatched = false;
		if (null != response) {
			dateOfBirthMatched = (boolean) response.get("dateOfBirthMatched");
			nameMatched = (boolean) response.get("nameMatched");
			panMatched = (boolean) response.get("panMatched");
		}
		if (!dateOfBirthMatched || !nameMatched || !panMatched) {
			execution.setVariable("demogMatchFlag", Boolean.FALSE);
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End fetchDemogDetails");
	}

	public void preUpdateStatusDobRejection(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preUpdateStatusDobRejection");
		ApplicationStatus applicationStatus = new ApplicationStatus();
		RejectionBean rejectionBean = new RejectionBean();
		List<String> list = new ArrayList<>();
		list.add("CCRMM");
		rejectionBean.setProdKey(((Double) execution.getVariable("l3ProductKey")).longValue());
		rejectionBean.setRejectionCode(list);
		rejectionBean.setRejectionSystem("RADDDET");
		applicationStatus.setRejectionBean(rejectionBean);
		applicationStatus.setStatusKey(3);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, applicationStatus);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preUpdateStatusDobRejection");
	}
	
	public void postDemogConsentTaskLoans(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postDemogConsentTaskLoans");
		execution.setVariable("takeBackToListingPage", Boolean.FALSE);
		execution.setVariable("action", "");
		if(null != execution.getVariable(CreditBusinessConstants.CONSENT_ACTION) && CreditBusinessConstants.BACK.equalsIgnoreCase(execution.getVariable(CreditBusinessConstants.CONSENT_ACTION).toString())){
			execution.setVariable("takeBackToListingPage", Boolean.TRUE);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postDemogConsentTaskLoans");
	}
	
	public void postDisbursalApi(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postDisbursalApi");
		JSONObject disbursalApiResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		Boolean isCaseCreated = null != disbursalApiResponse.get("isOtpValid") ? (Boolean)disbursalApiResponse.get("isOtpValid") : null;
		execution.setVariable(CreditBusinessConstants.IS_CASE_CREATED, isCaseCreated);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postDisbursalApi");
	}
	
	@SuppressWarnings("unchecked")
	public void preDisbursalApi(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDisbursalApi");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject disbursalApiRequest = new JSONObject();
		disbursalApiRequest.put(CreditBusinessConstants.OTP, null != request.get(CreditBusinessConstants.CONSENT) ? request.get(CreditBusinessConstants.CONSENT).toString() : null);
		disbursalApiRequest.put(CreditBusinessConstants.APPLICATIONID, execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, disbursalApiRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preDisbursalApi");
	}
	
	public void setCommonAdditionalDetailLoanFlags(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start setCommonAdditionalDetailLoanFlags");
		execution.setVariable("currentAddressUpdateFlag", Boolean.FALSE);
		execution.setVariable("workAddressUpdateFlag", Boolean.FALSE);
		execution.setVariable("permanentAddressUpdateFlag", Boolean.FALSE);
		execution.setVariable("userProfileUpdateFlag", Boolean.FALSE);
		execution.setVariable("workEmailUpdateFlag", Boolean.FALSE);
		execution.setVariable("customerReferenceUpdateFlag", Boolean.FALSE);
		execution.setVariable("loanPurposeUpdateFlag", Boolean.FALSE);
		execution.setVariable("personalEmailUpdateFlag", Boolean.FALSE);
		execution.setVariable("occupationDetailUpdateFlag", Boolean.FALSE);
		execution.setVariable("experienceUpdateFlag", Boolean.FALSE);
		execution.setVariable("designationUpdateFlag", Boolean.FALSE);
		
		String additionalDetailString = CreditBusinessHelper.objectToJson(execution.getVariable(CreditBusinessConstants.REQUEST));
		Gson g = new Gson();
		if (additionalDetailString != null) {
			AdditionalDetailLoans additionalDetails = g.fromJson(additionalDetailString, AdditionalDetailLoans.class);
			if (additionalDetails != null && !CollectionUtils.isEmpty(additionalDetails.getAddressDetails())) {
				for (Address address : additionalDetails.getAddressDetails()) {
					if (AddressTypeEnum.CURRENT.getValue().equalsIgnoreCase(address.getAddressTypeKey())) {
						execution.setVariable("currentAddressUpdateFlag", Boolean.TRUE);
						continue;
					}
					if (AddressTypeEnum.OFFICE.getValue().equalsIgnoreCase(address.getAddressTypeKey())) {
						execution.setVariable("workAddressUpdateFlag", Boolean.TRUE);
						continue;
					}
					if (AddressTypeEnum.PERMANENT.getValue().equalsIgnoreCase(address.getAddressTypeKey())) {
						execution.setVariable("permanentAddressUpdateFlag", Boolean.TRUE);
						continue;
					}
				}
			}
			if(null != additionalDetails && (!StringUtils.isEmpty(additionalDetails.getMotherName()) || !StringUtils.isEmpty(additionalDetails.getFatherName()) || null != additionalDetails.getQualification() 
					|| (null!= additionalDetails.getGender() && null != additionalDetails.getGender().getKey()) 
					|| (null!= additionalDetails.getResidenceType() && null != additionalDetails.getResidenceType().getKey()))){
				execution.setVariable("userProfileUpdateFlag", Boolean.TRUE);
			}
			
			if(null != additionalDetails && !StringUtils.isEmpty(additionalDetails.getWorkEmailId())){
				execution.setVariable("workEmailUpdateFlag", Boolean.TRUE);
			}
			
			if (null != additionalDetails && !CollectionUtils.isEmpty(additionalDetails.getRelatedPersonnelDetails())){
				execution.setVariable("customerReferenceUpdateFlag", Boolean.TRUE);
			}
			
			if (null != additionalDetails && null != additionalDetails.getLoanPurpose()){
				execution.setVariable("loanPurposeUpdateFlag", Boolean.TRUE);
			}
			
			if (null != additionalDetails && null != additionalDetails.getPersonalEmailId()){
				execution.setVariable("personalEmailUpdateFlag", Boolean.TRUE);
			}
			
			if (null != additionalDetails && (null != additionalDetails.getShopStatus() || null!= additionalDetails.getCorporateLinkageType() || null != additionalDetails.getCurrentWorkExperience() || null != additionalDetails.getDesignation() || !StringUtils.isEmpty(additionalDetails.getExperience()))){
				execution.setVariable("occupationDetailUpdateFlag", Boolean.TRUE);
			}
			
			if (null != additionalDetails && !StringUtils.isEmpty(additionalDetails.getExperience())){
				execution.setVariable("experienceUpdateFlag", Boolean.TRUE);
			}
			
			if (null != additionalDetails && null != additionalDetails.getDesignation() ){
				execution.setVariable("designationUpdateFlag", Boolean.TRUE);
			}
			
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End setCommonAdditionalDetailLoanFlags");
	}
	
	public void preUpdateCustomerReference(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preUpdateCustomerReference");
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(REQUEST));
		execution.setVariable(PAYLOAD, additionalDetail.get("relatedPersonnelDetails"));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preUpdateCustomerReference");
	}
	
	@SuppressWarnings("unchecked")
	public void preAnnualItrUpdate(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAnnualItrUpdate");
		execution.setVariable("annualItrFlag", Boolean.FALSE);
		JSONObject professJsonObject = new JSONObject();
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject occupationType = CreditBusinessHelper.getJSONObject(additionalDetail.get(CreditBusinessConstants.OCCUPATION_TYPE));
		Object annualItr = additionalDetail.get("annualItr");
		if(null != annualItr && annualItr instanceof Double){
			execution.setVariable("annualItrFlag", Boolean.TRUE);
			JSONObject businessOwnerDetails = new JSONObject();
			businessOwnerDetails.put("profitAfterTax", new BigDecimal((Double)annualItr));
			professJsonObject.put("businessOwnerDetails", businessOwnerDetails);
			professJsonObject.put("ocupationType", occupationType);
			execution.setVariable(CreditBusinessConstants.PAYLOAD, professJsonObject);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preAnnualItrUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void triggerHdfcCardLeadPushEvent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start triggerHdfcCardLeadPushEvent");
		String mobile = (String)execution.getVariable(CreditBusinessConstants.MOBILE);
		String l3ProductKey = String.valueOf(((Double)execution.getVariable(CreditBusinessConstants.L3_PRODUCT_KEY)).intValue());
		String applicationId = (String)execution.getVariable(CreditBusinessConstants.APPLICATION_ID);
		String childApplicationId = (String)execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID);
		String principalKey = (String)execution.getVariable(CreditBusinessConstants.PRINCIPALKEY);
		JSONObject leadPushRequest = new JSONObject();
		leadPushRequest.put("mobileNumber", mobile);
		leadPushRequest.put(CreditBusinessConstants.L3_PRODUCT_KEY, l3ProductKey);
		leadPushRequest.put(CreditBusinessConstants.APPLICATIONKEY, applicationId);
		leadPushRequest.put(CreditBusinessConstants.PRINCIPALKEY, principalKey);
        Map<String, String> additionalInfo=new HashMap<>();
        additionalInfo.put(CreditBusinessConstants.L2_PRODUCT_CODE,CreditBusinessConstants.PRODUCT_CODE_CC);
        additionalInfo.put(CreditBusinessConstants.CHILDAPPLICATIONID,childApplicationId);
        leadPushRequest.put("additionalInfo", additionalInfo);
        Map<String, String> header = new HashMap<>();
        header.put(CustomDefaultHeaders.AUTH_TOKEN, customHeaders.getAuthtoken());
        header.put(CustomDefaultHeaders.CMPTCORR_ID, customHeaders.getCmptcorrid());
        header.put(CreditBusinessConstants.APPLICATION_ID, applicationId);
        header.put("mobilenumber", mobile);
        Map<String, String> messageFilterAttributes = new HashMap<>();
        messageFilterAttributes.put("isPrincipalDelayRequired", "NO");
        EventMessage eventMessage = new EventMessage();
        eventMessage.setEventName("PRINCIPAL_LEAD_PUSH");
        eventMessage.setHeaders(header);
        eventMessage.setPayload(leadPushRequest);
        eventMessage.setMessageFilterAttributes(messageFilterAttributes);
        publisherService.publish(topicArn, eventMessage);

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End triggerHdfcCardLeadPushEvent");
	}
	
	@SuppressWarnings("unchecked")
	public void preUpdateRelationshipDetail(DelegateExecution execution) {
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(REQUEST));
		JSONObject payload = new JSONObject();
		if(null != additionalDetail && null != additionalDetail.get(RELATION_REFERENCE)) {
			JSONObject relationReference = CreditBusinessHelper.getJSONObject(additionalDetail.get(RELATION_REFERENCE));
			if(null != relationReference && null != relationReference.get(SALUTATION_OBJ) 
					&& null != relationReference.get(RELATION_OBJ)) {
				payload.put(NAME, relationReference.get(FULLNAME).toString());
				JSONObject salutation = CreditBusinessHelper.getJSONObject(relationReference.get(SALUTATION_OBJ));
				payload.put(SALUTATION_KEY, null != salutation.get(KEY) 
						? Double.valueOf(salutation.get(KEY).toString()).longValue()
						: null);
				JSONObject relation = CreditBusinessHelper.getJSONObject(relationReference.get(RELATION_OBJ));
				payload.put(RELATION_CODE_MASTER_KEY, null != relation.get(KEY) 
						? Double.valueOf(relation.get(KEY).toString()).longValue()
						: null);
			}
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Request from execution found null! ");
		}
		execution.setVariable(PAYLOAD, payload);
	}
	
	@SuppressWarnings("unchecked")
	public void preGenerateOtp(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preGenerateOtp");
		String mobile = (String)execution.getVariable(CreditBusinessConstants.MOBILE);
		JSONObject otpGenerationRequest = new JSONObject();
		otpGenerationRequest.put(CreditBusinessConstants.MOBILE, mobile);
		otpGenerationRequest.put(OTP_GENERATE_POLICY_NAME, OTP_GENERATE_POLICY_PL);
		otpGenerationRequest.put(OTP_GENERATE_MFA, true);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, otpGenerationRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preGenerateOtp");
	}
	
	@SuppressWarnings("unchecked")
	public void preOtpValidate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preOtpValidate");
		String mobile = (String)execution.getVariable(CreditBusinessConstants.MOBILE);
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject otpValidationRequest = new JSONObject();
		otpValidationRequest.put(CreditBusinessConstants.MOBILE, mobile);
		otpValidationRequest.put(CreditBusinessConstants.OTP, null != request.get(CreditBusinessConstants.CONSENT) ? request.get(CreditBusinessConstants.CONSENT).toString() : null);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, otpValidationRequest);
		execution.setVariable(SKIP_API_EXCEPTION, true);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preOtpValidate");
	}
	
	public void postOtpValidate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postOtpValidate");
		execution.setVariable(CreditBusinessConstants.IS_CASE_CREATED, Boolean.FALSE);
		Object apiException = execution.getVariable(API_EXCEPTION_ARISE);
		if (null != apiException && (boolean) apiException) {
			execution.setVariable(CreditBusinessConstants.IS_CASE_CREATED, Boolean.FALSE);
		}else{
			JSONObject otpValidationResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
			if (null != otpValidationResponse && null != otpValidationResponse.get(CreditBusinessConstants.PAYLOAD) ) {
				String otpValidationJsonResponse = otpValidationResponse.get(CreditBusinessConstants.PAYLOAD)
						.toString();
				if (SUCCESS.equalsIgnoreCase(otpValidationJsonResponse)) {
					execution.setVariable(CreditBusinessConstants.IS_CASE_CREATED, Boolean.TRUE);
				}
			}
		}
		
		// remove exception skip flags from execution once task gets completed
		List<String> variablesToRemoveFromExecution = new ArrayList<String>();
		variablesToRemoveFromExecution.add(SKIP_API_EXCEPTION);
		variablesToRemoveFromExecution.add(API_EXCEPTION_ARISE);

		execution.removeVariables(variablesToRemoveFromExecution);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postOtpValidate");
	}
	
	public void postFetchUserProfileCheckVerification(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postFetchUserProfileCheckVerification");
		execution.setVariable(MOBILE_VERIFIED_FLAG, Boolean.FALSE);
		JSONObject userProfileResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.MOBILE, null != userProfileResponse ? (String)userProfileResponse.get(CreditBusinessConstants.MOBILE): null);
		if(null != userProfileResponse && null != userProfileResponse.get(KEY_VERIFICATIONS)){
			ArrayList<?> verificationList = (ArrayList<?>)userProfileResponse.get(KEY_VERIFICATIONS);
			execution.setVariable(MOBILE_VERIFIED_FLAG, filterVerificationsForMobile(verificationList));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postFetchUserProfileCheckVerification");
	}
	
	private Boolean filterVerificationsForMobile(ArrayList<?> verificationList){
		Boolean mobileVerifiedFlag = false;
		for(Object verification : verificationList){
			JSONObject verificationObject = CreditBusinessHelper.getJSONObject(verification);
			if(null != verificationObject && null != verificationObject.get(VERIFICATION_ATTRIBUTE) && VERIFICATION_ATTRB_MOBILE.equalsIgnoreCase((String)verificationObject.get(VERIFICATION_ATTRIBUTE))){
				if(null != verificationObject.get(VERIFICATION_SOURCE) && VERIFICATION_SOURCE_BFSD_OTP.equalsIgnoreCase((String)verificationObject.get(VERIFICATION_SOURCE))){
					mobileVerifiedFlag =  null != verificationObject.get(IS_VERIFIED) ? (Boolean)verificationObject.get(IS_VERIFIED): Boolean.FALSE;
					return mobileVerifiedFlag;
				}
			}
		}
		return mobileVerifiedFlag;
	}
	
	@SuppressWarnings("unchecked")
	public void updateMobileVerificationDetail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start updateMobileVerificationDetail");
		String applicationId = (String)execution.getVariable(CreditBusinessConstants.APPLICATION_ID);
		JSONObject verificationObject = new JSONObject();
		verificationObject.put(APPLICATIONKEY, applicationId);
		verificationObject.put(VERIFICATION_ATTRIBUTE, VERIFICATION_ATTRB_MOBILE);
		verificationObject.put(VERIFICATION_SOURCE, VERIFICATION_SOURCE_BFSD_OTP);
		verificationObject.put(IS_VERIFIED, 1);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, verificationObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End updateMobileVerificationDetail");
	}
	
	public void setDefaultConsentAction(DelegateExecution execution) {
		execution.setVariable(CONSENT_ACTION, "");
	}
}
