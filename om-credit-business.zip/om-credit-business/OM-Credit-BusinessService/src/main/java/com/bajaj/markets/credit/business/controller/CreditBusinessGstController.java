package com.bajaj.markets.credit.business.controller;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.Application;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.GstInfo;
import com.bajaj.markets.credit.business.beans.GstRequest;
import com.bajaj.markets.credit.business.service.CreditBusinessGSTService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class CreditBusinessGstController {

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessGSTService creditBusinessGstService;

	private static final String CLASS_NAME = CreditBusinessGstController.class.getCanonicalName();

	/**
	 * fetch getGstInfo
	 * 
	 * @param applicationid
	 * @param headers
	 * @return
	 */
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE })
	@ApiOperation(value = "API to fetch GST  details to expose to  UI ", notes = "API to fetch GST  details to expose to UI ", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully GST validated details", response = Application.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found for given applicationId", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@CrossOrigin
	@PostMapping(path = "/v1/credit/applications/{applicationid}/gstInfo", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GstInfo> getGstInfo(@RequestBody GstRequest gst,
			@PathVariable(value = "applicationid", required = true) @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationid,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Start getgstInfo with applicationid : " + applicationid);

		GstInfo gstinfo = creditBusinessGstService.getGstInfo(applicationid, gst, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End getgstInfo with applicationid : " + applicationid);

		return new ResponseEntity<>(gstinfo, HttpStatus.OK);

	}
}
