package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -190345607611775304L;
	
	private Object payload;//NOSONAR
	private NextTask nextTask;

	public Object getPayload() {
		return payload;
	}
	public void setPayload(Object payload) {
		this.payload = payload;
	}
	public NextTask getNextTask() {
		return nextTask;
	}
	public void setNextTask(NextTask nextTask) {
		this.nextTask = nextTask;
	}

	@Override
	public String toString() {
		return "ApplicationResponse [payload=" + payload + ", nextTask=" + nextTask + "]";
	}

}
