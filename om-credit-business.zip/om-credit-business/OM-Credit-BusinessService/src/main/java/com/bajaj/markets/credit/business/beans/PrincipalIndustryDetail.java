package com.bajaj.markets.credit.business.beans;

public class PrincipalIndustryDetail {
	
	private Long principalIndustryMasterKey;
	
	private String industryCode;
	
	private String industryName;

	public Long getPrincipalIndustryMasterKey() {
		return principalIndustryMasterKey;
	}

	public void setPrincipalIndustryMasterKey(Long principalIndustryMasterKey) {
		this.principalIndustryMasterKey = principalIndustryMasterKey;
	}

	public String getIndustryCode() {
		return industryCode;
	}

	public void setIndustryCode(String industryCode) {
		this.industryCode = industryCode;
	}

	public String getIndustryName() {
		return industryName;
	}

	public void setIndustryName(String industryName) {
		this.industryName = industryName;
	}

	@Override
	public String toString() {
		return "PrincipalIndustryDetail [principalIndustryMasterKey=" + principalIndustryMasterKey + ", industryCode="
				+ industryCode + ", industryName=" + industryName + "]";
	}

}
