package com.bajaj.markets.credit.business.helper;

public enum ReferenceOf {
	
	QUALIFICATION("api.omreferencedata.qualification.master.url", "qlfymastkey", "qlfyprefcode", "qlfydesc"),
	SPECIALIZATION("api.omreferencedata.specialization.master.url", "spclmastkey", "spclmastcode", "spcldesc"),
	HOSPITAL("api.omreferencedata.hospital.master.url", "hospitalkey", "hospitalcode", "name"),
	REGISTRATION_COUNSIL("api.omreferencedata.counsil.master.url", "rcmastkey", "rccode", "rcname"),
	PRINCIPLE_DOCUMENTS("api.omreferencedatareferencedataservice.principal.document.url", "principleDocTypeKey", "docIdCatCode", "documentTypeDescription"),
	SALUTATION("api.referencedata.salutations.GET.url", "salutationkey", "salutationcode", "salutationdec"),
	RELATION("api.referencedata.relation.GET.url", "relationcodemastkey", "rcmcode", "rcmcode"),
	RESIDENCE("api.omreferencedatareferencedataservice.location.residence.get.url", "residenceKey", "residenceCode", "residenceValue"),
	MARITAL_STATUS("api.omreferencedatareferencedataservice.getmaritalstatus.get.url", "maritalStatusKey", "maritalStatusCode", "maritalStatusValue"),
	GENDER("api.omreferencedatareferencedataservice.getgender.get.url", "genderKey", "genderCode", "genderValue"),
	INDUSTRY("api.omreferencedatareferencedataservice.location.industry.get.url", "custIndMastKey", "categoryCd", "custIndMastDesc"),
	TURNOVER("api.omreferencedatareferencedataservice.lookup.code.get.url","key","code", "value");
	
	private String url;
	private String keyLabel;
	private String codeLabel;
	private String valueLabel;
	
	private ReferenceOf(String url, String keyLabel, String codeLabel, String valueLabel) {
		this.url = url;
		this.keyLabel = keyLabel;
		this.codeLabel = codeLabel;
		this.valueLabel = valueLabel;
	}

	public String getUrl() {
		return this.url;
	}

	public String getKeyLabel() {
		return this.keyLabel;
	}

	public String getCodeLabel() {
		return this.codeLabel;
	}

	public String getValueLabel() {
		return this.valueLabel;
	}
	
}