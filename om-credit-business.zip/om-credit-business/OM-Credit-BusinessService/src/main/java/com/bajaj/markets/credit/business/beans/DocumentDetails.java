package com.bajaj.markets.credit.business.beans;
import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


public class DocumentDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Digits(fraction = 0, integer = 20, message = "documentNameKey cannot be in fraction & should not exceed size")
	@NotNull(message = "documentNameKey cannot be null or empty")
	private Long documentNameKey;

	@NotEmpty(message = "documentNumber cannot be null or empty")
	private String documentNumber;

	private Long issueingAuthorityKey;

	private String documentIssuedDate;

	private String documentExpiry;

	private Verification verification;

	public Long getDocumentNameKey() {
		return documentNameKey;
	}

	public void setDocumentNameKey(Long documentNameKey) {
		this.documentNameKey = documentNameKey;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public Long getIssueingAuthorityKey() {
		return issueingAuthorityKey;
	}

	public void setIssueingAuthorityKey(Long issueingAuthorityKey) {
		this.issueingAuthorityKey = issueingAuthorityKey;
	}

	public String getDocumentIssuedDate() {
		return documentIssuedDate;
	}

	public void setDocumentIssuedDate(String documentIssuedDate) {
		this.documentIssuedDate = documentIssuedDate;
	}

	public String getDocumentExpiry() {
		return documentExpiry;
	}

	public void setDocumentExpiry(String documentExpiry) {
		this.documentExpiry = documentExpiry;
	}

	public Verification getVerification() {
		return verification;
	}

	public void setVerification(Verification verification) {
		this.verification = verification;
	}

	@Override
	public String toString() {
		return "ApplicationDocumentsBean [documentNameKey=" + documentNameKey + ", documentNumber=" + documentNumber
				+ ", issueingAuthorityKey=" + issueingAuthorityKey + ", documentIssuedDate=" + documentIssuedDate + ", documentExpiry="
				+ documentExpiry + ", verification=" + verification + "]";
	}

}
