package com.bajaj.markets.credit.business.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.BankDetail;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.EmandatesRequest;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.PrincipalCustomer;
import com.bajaj.markets.credit.business.beans.SalarySource;
import com.bajaj.markets.credit.business.beans.SalarySourceDetails;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ApplictionClient {
	@Autowired
	private CreditBusinessHelper creditBusinessHelper;
	
	@Value("${api.omcreditapplicationservice.updateuserprofiles.put.url}")
	private String updateUserProfilesUrl;
	
	@Value("${api.omcreditapplicationservice.updateemail.put.url}")
	private String updateEmailUrl;
	
	@Value("${api.omcreditapplicationservice.updateaddress.put.url}")
	private String updateAddressUrl;
	
	@Value("${api.omcreditapplicationservice.application.userprofiles.occupation.PUT.url}")
	private String updateOccupationUrl;
	
	@Value("${api.omcreditapplicationservice.offer.put.url}")
	private String updateOfferUrl;
	
	@Value("${api.omcreditapplicationservice.salary.put.url}")
	private String updateSalaryUrl;
	
	@Value("${api.omcreditapplicationservice.savebankdetails.POST.url}")
	private String updateBankUrl;
	
	@Value("${api.omcreditapplicationservice.updatedocumentdetails.put.url}")
	private String updateDocumentUrl;
	
	@Value("${api.creditappservice.principalcustinfo.offers.PUT.url}")
	private String pricipalCustInfoOffersUrl;
	
	@Value("${api.ompaymentsemandatedomainservice.updatemandatebyumrn.PUT.url}")
	private String updateMandateUrl;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASSNAME = ApplictionClient.class.getName();
	
	public boolean saveApplicantProfile(UserProfileBean userProfileBean, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveApplicantProfile method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			Map<String, String> param = new HashMap<>();
			param.put("applicationid", applicantDataBean.getOfferApiRequest().getApplicationKey());
			param.put("userattributekey", applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey());
			ObjectMapper mapper = new ObjectMapper();
			String userProfileReq = mapper.writeValueAsString(userProfileBean);
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateUserProfilesUrl, Object.class, param,
					userProfileReq, applicantDataBean.getHeaders());
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveApplicantProfile method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - address call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveApplicantProfile method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return true;
	}
	
	public boolean saveEmail(Email email, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveEmail method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			Map<String, String> param = new HashMap<>();
			param.put("applicationid", applicantDataBean.getOfferApiRequest().getApplicationKey());
			param.put("userattributekey", applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey());
			ObjectMapper mapper = new ObjectMapper();
			String emailReq = mapper.writeValueAsString(email);
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateEmailUrl, Object.class, param,
					emailReq, applicantDataBean.getHeaders());
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveEmail method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - email call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveEmail method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return true;
	}
	
	public boolean saveAddress(Address address, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveAddress method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {			
			Map<String, String> param = new HashMap<>();
			param.put("applicationid", applicantDataBean.getOfferApiRequest().getApplicationKey());
			param.put("userattributekey", applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey());
			ObjectMapper mapper = new ObjectMapper();
			String addressReq = mapper.writeValueAsString(address);
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateAddressUrl, Object.class,
					param, addressReq, applicantDataBean.getHeaders());
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveAddress method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - addess call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveAddress method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return true;
	}
	
	public boolean saveBank(BankDetail bank, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveBank method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			Map<String, String> param = new HashMap<>();
			param.put("applicationKey", applicantDataBean.getOfferApiRequest().getApplicationKey());
			ObjectMapper mapper = new ObjectMapper();
			String bankReq = mapper.writeValueAsString(bank);
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, updateBankUrl, Object.class,
					param, bankReq, applicantDataBean.getHeaders());
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveBank method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - bank call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveBank method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return true;
	}
	
	public boolean saveOccupation(Occupation occupation, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveOccupation method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			Map<String, String> param = new HashMap<>();
			param.put("applicationid", applicantDataBean.getOfferApiRequest().getApplicationKey());
			param.put("userattributekey", applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey());
			ObjectMapper mapper = new ObjectMapper();
			String occupationReq = mapper.writeValueAsString(occupation);
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateOccupationUrl, Object.class, param,
					occupationReq, applicantDataBean.getHeaders());
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveOccupation method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - bank call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveOccupation method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return true;
	}
	
	public boolean saveOffer(AppOfferDetBean appOfferDetBean, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveOffer method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			Map<String, String> param = new HashMap<>();
			param.put("applicationid", applicantDataBean.getOfferApiRequest().getApplicationKey());
			param.put("userattributekey", applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey());
			ObjectMapper mapper = new ObjectMapper();
			appOfferDetBean.setAppattrbkey(Long.parseLong(applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey()));
			appOfferDetBean.setPrincipalKey(3L);
			String offerReq = mapper.writeValueAsString(appOfferDetBean);
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateOfferUrl, Object.class, param,
					offerReq, applicantDataBean.getHeaders());
			if(null != appOfferDetBean.getNetMonthlySalary()) {
				SalarySourceDetails salarySourceDetails = new SalarySourceDetails();
				List<SalarySource> salarySources = new ArrayList<>();
				SalarySource salarySource = new SalarySource();
				salarySource.setSalary(appOfferDetBean.getNetMonthlySalary().intValue());
				salarySource.setSalarySource(CreditBusinessConstants.OFFER_API);
				salarySources.add(salarySource);
				salarySourceDetails.setSalarySources(salarySources);
				String updateSalaryRequest = mapper.writeValueAsString(salarySourceDetails);
			
				creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateSalaryUrl, Object.class,
						param, updateSalaryRequest.toString(), applicantDataBean.getHeaders());
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveOffer method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - offer call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveOffer method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return true;
	}
	
	public boolean saveDocument(DocumentDetails documentDetails, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveDocument method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			Map<String, String> param = new HashMap<>();
			param.put("applicationid", applicantDataBean.getOfferApiRequest().getApplicationKey());
			param.put("userattributekey", applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey());
			ObjectMapper mapper = new ObjectMapper();
			String documentReq = mapper.writeValueAsString(documentDetails);
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateDocumentUrl, Object.class, param,
					documentReq, applicantDataBean.getHeaders());
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveDocument method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - document call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveDocument method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return true;
	}
	
	public boolean savePrincipalCustomerInfo(PrincipalCustomer principalCustomer, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY,
				"inside ApplictionClient - savePrincipalCustomerInfo method for application "
						+ applicantDataBean.getOfferApiRequest().getApplicationKey() + " - started");
		try {
			HashMap<String, String> paramMap = new HashMap<>();
			paramMap.put("applicationid", applicantDataBean.getOfferApiRequest().getApplicationKey());
			paramMap.put(CreditBusinessConstants.PRINCIPAL_KEY, CreditBusinessConstants.RBL_PRINCIPAL_KEY);
			ObjectMapper mapper = new ObjectMapper();
			String requestJson;
			requestJson = mapper.writeValueAsString(principalCustomer);
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, pricipalCustInfoOffersUrl, String.class, paramMap,
					requestJson, applicantDataBean.getHeaders());

		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"inside ApplictionClient - savePrincipalCustomerInfo method for application "
							+ applicantDataBean.getOfferApiRequest().getApplicationKey() + " - savePrincipalCustomerInfo call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY,
				"inside ApplictionClient - savePrincipalCustomerInfo method for application "
						+ applicantDataBean.getOfferApiRequest().getApplicationKey() + " - end");
		return true;
	}
	
	public boolean saveMandate(EmandatesRequest mandate, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveMandate method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			HashMap<String, String> paramMap = new HashMap<>();
			paramMap.put("umrn", mandate.getUmrn());
			ObjectMapper mapper = new ObjectMapper();
			String mandateReq = mapper.writeValueAsString(mandate);
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateMandateUrl, Object.class,
					paramMap, mandateReq, applicantDataBean.getHeaders());
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveMandate method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - mandate call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplictionClient - saveMandate method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return true;
	}
}