package com.bajaj.markets.credit.business.beans;

public class SalarySource {

	private String salarySource;

	private Integer salary;

	public String getSalarySource() {
		return salarySource;
	}

	public void setSalarySource(String salarySource) {
		this.salarySource = salarySource;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "salarySource : [ salarySource=" + salarySource + ",salary" + salary + "]";
	}

}
