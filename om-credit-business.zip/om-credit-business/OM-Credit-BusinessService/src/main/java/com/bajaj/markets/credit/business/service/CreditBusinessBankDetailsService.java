package com.bajaj.markets.credit.business.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.BankDetails;
import com.bajaj.markets.credit.business.beans.BankDetailsReponse;
import com.bajaj.markets.credit.business.beans.EmandateResponse;
import com.bajaj.markets.credit.business.beans.MandateBreRequest;

public interface CreditBusinessBankDetailsService {

	public ApplicationResponse saveBankDetails(Long applicationId, BankDetails bankDetails, HttpHeaders headers);
	
	public BankDetails getBankDetail(Long applicationid, HttpHeaders headers);
	
	public MandateBreRequest createBreRequest(List<BankDetailsReponse> bankDetailsResponses,
			List<EmandateResponse> emandateResponses, Map<String, String> params, HttpHeaders headers);
	
}
