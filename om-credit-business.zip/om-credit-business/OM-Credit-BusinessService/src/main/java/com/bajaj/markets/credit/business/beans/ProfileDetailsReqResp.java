package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class ProfileDetailsReqResp implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4924006261157388077L;
	
	private ProfileDetailsV2 profileDetails;
    private ResidencePincode residencePincode;
    private Profession profession;
    private Integer requiredLoanAmount;
    private String action;
   
	public ProfileDetailsV2 getProfileDetails() {
		return profileDetails;
	}

	public void setProfileDetails(ProfileDetailsV2 profileDetails) {
		this.profileDetails = profileDetails;
	}

	public ResidencePincode getResidencePincode() {
		return residencePincode;
	}

	public void setResidencePincode(ResidencePincode residencePincode) {
		this.residencePincode = residencePincode;
	}

	public Profession getProfession() {
		return profession;
	}

	public void setProfession(Profession profession) {
		this.profession = profession;
	}

	public Integer getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	public void setRequiredLoanAmount(Integer requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "ProfileDetailsResponse [profileDetails=" + profileDetails + ", residenceAddress=" + residencePincode
				+ ", profession=" + profession + ", requiredLoanAmount=" + requiredLoanAmount + "]";
	}
	
}
