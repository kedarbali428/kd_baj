package com.bajaj.markets.credit.business.beans;

import java.sql.Timestamp;

public class ApplicationPhoneNumberDetails {

	private Long appPhoneNumberKey;
	private Long appAttributeKey;
	private Long phoneTypeKey;
	private String countryCode;
	private String areaCode;
	private String phoneNumber;
	private Integer isVerified;
	private Timestamp startDate;
	private Timestamp endDate;
	public Long getAppPhoneNumberKey() {
		return appPhoneNumberKey;
	}
	public void setAppPhoneNumberKey(Long appPhoneNumberKey) {
		this.appPhoneNumberKey = appPhoneNumberKey;
	}
	public Long getAppAttributeKey() {
		return appAttributeKey;
	}
	public void setAppAttributeKey(Long appAttributeKey) {
		this.appAttributeKey = appAttributeKey;
	}
	public Long getPhoneTypeKey() {
		return phoneTypeKey;
	}
	public void setPhoneTypeKey(Long phoneTypeKey) {
		this.phoneTypeKey = phoneTypeKey;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Integer getIsVerified() {
		return isVerified;
	}
	public void setIsVerified(Integer isVerified) {
		this.isVerified = isVerified;
	}
	public Timestamp getStartDate() {
		return startDate;
	}
	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}
	public Timestamp getEndDate() {
		return endDate;
	}
	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}
	@Override
	public String toString() {
		return "ApplicationPhoneNumberDetails [appPhoneNumberKey=" + appPhoneNumberKey + ", appAttributeKey="
				+ appAttributeKey + ", phoneTypeKey=" + phoneTypeKey + ", countryCode=" + countryCode + ", areaCode="
				+ areaCode + ", phoneNumber=" + phoneNumber + ", isVerified=" + isVerified + ", startDate=" + startDate
				+ ", endDate=" + endDate + "]";
	}
}
