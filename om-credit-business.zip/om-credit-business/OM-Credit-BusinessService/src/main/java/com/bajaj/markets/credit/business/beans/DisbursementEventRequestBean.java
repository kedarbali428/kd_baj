/**
 * 
 */
package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

/**
 * @author pranoti.pandole
 *
 */
public class DisbursementEventRequestBean  implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String applicationId;
	private String applicantId;
	private String productCode;
	private String productCategory;
	private String disbursmentKey;
	private String eventType;
	private String principalName;
	
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public void setDisbursmentKey(String disbursmentKey) {
		this.disbursmentKey = disbursmentKey;
	}
	
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getProductCode() {
		return productCode;
	}
	public String getPrincipalName() {
		return principalName;
	}
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}
	
	

}
