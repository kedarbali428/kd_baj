package com.bajaj.markets.credit.business.helper;

import java.util.HashMap;
import java.util.Map;

import com.bajaj.markets.credit.business.beans.Reference;

public enum BAUProductToOccupation {
	
	// Loans
	SOL(Occupation.SALR_OCCUPATION),
	DBOL(Occupation.SEMP_OCCUPATION),
	
	// Cards
	SAL(Occupation.SALR_OCCUPATION),
	SEMP(Occupation.SEMP_OCCUPATION);
	
	private final Reference occupation;

	BAUProductToOccupation(Reference occupation) {
		this.occupation = occupation;
	}
	
	public Reference getOccupation() {
		return this.occupation;
	}

	public static final Map<String, Reference> occupationFromBAUProductCode = new HashMap<String, Reference>();
	
	static {
		for (BAUProductToOccupation bauProductToOccupation : BAUProductToOccupation.values()) {
			occupationFromBAUProductCode.put(bauProductToOccupation.name(), bauProductToOccupation.getOccupation());
		}
	}

	public static Reference getOccupation(String bauProdCode) {
		return occupationFromBAUProductCode.get(bauProdCode);
	}
}

class Occupation {
	
	public static final Reference SALR_OCCUPATION = new Reference(1l, "SALR", "Salaried");
	public static final Reference SEMP_OCCUPATION = new Reference(2l, "SEMP", "Self Employed");
	
}