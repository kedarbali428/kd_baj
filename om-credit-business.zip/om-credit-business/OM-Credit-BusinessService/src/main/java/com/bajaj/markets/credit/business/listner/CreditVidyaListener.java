package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APP_SALARY_DETAILS_LIST;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_JSON;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CURRENT_ADDRESS_OBJECT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DOB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMAIL;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.GENDERKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.IS_IV_REQUIRED_FOR_CV;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.IS_MEDHAS_DECISION_APPROVED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.IS_MEDHAS_OFFER_PRESENT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L3_PRODUCT_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.LOAN_PRICING;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MEDHAS_OFFER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NSDLPANRESPONSE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OCCUPATION_LIST;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PARENT_APPLICATION_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST_HEADERS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SKIP_API_EXCEPTION;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CREDITVIDYA_RISKCATEGORY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.VALIDATION_STATUS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.ApplicationStatusEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.OccupationTypeEnum;
import com.bajaj.markets.credit.business.helper.RejectionSystemSourceEnum;

@Component
public class CreditVidyaListener {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	Application application;
	
	private static final String MEDHAS_JAR_REJECT_CODE = "CVJARREJECT";
	
	private static final String CLASS_NAME = CreditVidyaListener.class.getCanonicalName();

	public void postGetPersonalEmail(DelegateExecution execution) {
		JSONObject emailObject = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
		execution.setVariable(EMAIL, emailObject.get(EMAIL));
	}

	public void postGetAddress(DelegateExecution execution) {
		execution.setVariable(CURRENT_ADDRESS_OBJECT, execution.getVariable(OUTPUT));
	}

	public void postGetNSDLPanDetails(DelegateExecution execution) {
		execution.setVariable(NSDLPANRESPONSE, execution.getVariable(OUTPUT));
	}
	
	public void preGetCreditVidyaRiskCategory(DelegateExecution execution) {
		
		execution.setVariable(CreditBusinessConstants.SKIP_API_EXCEPTION, true);
		
	}
	public void postGetCreditVidyaRiskCategory(DelegateExecution execution) {
		Object apiException = execution.getVariable(CreditBusinessConstants.API_EXCEPTION_ARISE);
		if (null == apiException || !(boolean) apiException) {
			JSONObject creditVidyaResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
			execution.setVariable(CREDITVIDYA_RISKCATEGORY, creditVidyaResponse.get(VALIDATION_STATUS));
		} else {
			execution.setVariable(CREDITVIDYA_RISKCATEGORY, null);
		}
		// remove exception skip flags from execution once task gets completed
		List<String> variablesToRemoveFromExecution = new ArrayList<String>();
		variablesToRemoveFromExecution.add(CreditBusinessConstants.SKIP_API_EXCEPTION);
		variablesToRemoveFromExecution.add(CreditBusinessConstants.API_EXCEPTION_ARISE);
		execution.removeVariables(variablesToRemoveFromExecution);
	}

	public void postGetOccupationMaster(DelegateExecution execution) {
		ArrayList<?> occupationsFromMaster = (ArrayList<?>) execution.getVariable(OUTPUT);
		execution.setVariable(OCCUPATION_LIST, occupationsFromMaster);
	}

	public void postGetOccupation(DelegateExecution execution) {
		JSONObject occupationObject = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));

		JSONObject occupationType = CreditBusinessHelper.getJSONObject(occupationObject.get("ocupationType"));
		Object occupationKey = occupationType.get("key");
		Object occupationTypeValue = null;
		String occupationCode = "";

		ArrayList<?> occupationList = (ArrayList<?>) execution.getVariable(OCCUPATION_LIST);

		for (Object object : occupationList) {
			JSONObject occupationTypeFromMaster = CreditBusinessHelper.getJSONObject(object);
			if (occupationKey.equals(occupationTypeFromMaster.get("occupationKey"))) {
				occupationTypeValue = occupationTypeFromMaster.get("occupationValue");
				occupationCode = occupationTypeFromMaster.get("occupationCode").toString();
				break;
			}
		}
		if (null != occupationCode && OccupationTypeEnum.BUSINESS.getValue().equalsIgnoreCase(occupationCode)) {
			JSONObject businessOwnerDetails = CreditBusinessHelper.getJSONObject(occupationObject.get("businessOwnerDetails"));
			execution.setVariable("profitAfterTax", null != businessOwnerDetails.get("profitAfterTax") 
					?  ((Double) businessOwnerDetails.get("profitAfterTax")).longValue() : null);
		}
		execution.setVariable("occupationCode", occupationCode);
		execution.setVariable("occupationValue", occupationTypeValue);
	}

	public void postGetSalaryDetails(DelegateExecution execution) {
		ArrayList<?> salaryDetails = (ArrayList<?>) execution.getVariable(OUTPUT);
		execution.setVariable(APP_SALARY_DETAILS_LIST, salaryDetails);
	}

	@SuppressWarnings("unchecked")
	public void prepareMedhasDecisionJarRequest(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start - prepareMedhasDecisionJarRequest");
		JSONObject nsdlPanVerificationResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(NSDLPANRESPONSE));
		JSONObject loanPricing = CreditBusinessHelper.getJSONObject(execution.getVariable(LOAN_PRICING));
		JSONObject payload = new JSONObject();
		JSONObject applicationData = new JSONObject();
		applicationData.put("currentAddress", execution.getVariable(CURRENT_ADDRESS_OBJECT));
		applicationData.put("dateOfBirth", execution.getVariable(DOB));
		applicationData.put("genderKey", execution.getVariable(GENDERKEY));
		applicationData.put("name", buildFullName(execution.getVariable(NAME)));
		if(null != nsdlPanVerificationResponse) {
			applicationData.put("panName", nsdlPanVerificationResponse.get("fullName"));
			applicationData.put("panNumber", nsdlPanVerificationResponse.get("panNumber"));
		}
		applicationData.put("personalEmailId", execution.getVariable(EMAIL));
		applicationData.put("salaries", execution.getVariable(APP_SALARY_DETAILS_LIST));
		applicationData.put("occupationType", execution.getVariable("occupationValue"));
		if(null != loanPricing) {
			applicationData.put("loanAmount",
					null != loanPricing.get("finalLoanAmount") ? BigDecimal.valueOf((Double) loanPricing.get("finalLoanAmount")) : null);
			applicationData.put("tenure", null != loanPricing.get("droplineTenure") ? ((Double) loanPricing.get("droplineTenure")).longValue() : null);
		}
		applicationData.put("profitAfterTax", execution.getVariable("profitAfterTax"));
		
		payload.put("applicationData", applicationData);
		payload.put("applicationKey", execution.getVariable(PARENT_APPLICATION_KEY));
		payload.put("cibilString", execution.getVariable(CIBIL_JSON));
		payload.put("perfiosString", execution.getVariable("perfiosJson"));
		
		execution.setVariable(PAYLOAD, payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End - prepareMedhasDecisionJarRequest");
	}

	private String buildFullName(Object nameObject) {
		StringBuilder fullName = new StringBuilder();
		if (null != nameObject) {
			JSONObject name = CreditBusinessHelper.getJSONObject(nameObject);
			Object firstName = name.get("firstName");
			Object middleName = name.get("middleName");
			Object lastName = name.get("lastName");
			if (null != firstName) {
				fullName.append(firstName);
			}
			if (null != middleName) {
				fullName.append(" ").append(middleName);
			}
			if (null != lastName) {
				fullName.append(" ").append(lastName);
			}
		}		
		return fullName.toString();
	}

	public void postMedhasDecision(DelegateExecution execution) {
		JSONObject medhasResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
		execution.setVariable(IS_MEDHAS_DECISION_APPROVED, (boolean) medhasResponse.get("medhasDecisionApproved"));
		execution.setVariable(IS_MEDHAS_OFFER_PRESENT, (boolean) medhasResponse.get("medhasOfferPresent"));
		execution.setVariable(MEDHAS_OFFER, medhasResponse.get("availableMedhasOffer"));
		execution.setVariable(IS_IV_REQUIRED_FOR_CV, (boolean) medhasResponse.get("incomeVerificationRequired"));
	}
	
	public void flowFromIncomeVerification(DelegateExecution execution, boolean isFlowFromIncomeVerification) {
		execution.setVariable("flowFromIncomeVerification", isFlowFromIncomeVerification);
	}
	
	@SuppressWarnings("unchecked")
	public void preRegisterUser(DelegateExecution execution) {
		JSONObject payload = new JSONObject();
		payload.put("mobileNumber", execution.getVariable(MOBILE));
		
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("applicationid", execution.getVariable(PARENT_APPLICATION_KEY).toString());
		
		execution.setVariable(REQUEST_HEADERS, headers);
		execution.setVariable(PAYLOAD, payload);
	}
	
	@SuppressWarnings("unchecked")
	public void preChildRejectionBre(DelegateExecution execution) {
		ApplicationStatusEnum appStatusRejected = ApplicationStatusEnum.REJECTED;
		
		List<String> rejectCodeList = new ArrayList<String>();
		rejectCodeList.add(MEDHAS_JAR_REJECT_CODE);
		JSONObject payload = new JSONObject();
		JSONObject rejectionBean = new JSONObject();
		rejectionBean.put("prodKey", execution.getVariable(L3_PRODUCT_KEY));
		rejectionBean.put("rejectionCode", rejectCodeList);
		rejectionBean.put("rejectionSystem", RejectionSystemSourceEnum.PRINCIPALREJECT.getValue());
		
		payload.put("rejectionBean", rejectionBean);
		payload.put("statusValue", appStatusRejected.getCode());
		payload.put("statusKey", appStatusRejected.getKey());
		
		execution.setVariable(PAYLOAD, payload);
	}
	
	public void postFetchLoanPricing(DelegateExecution execution) {
		execution.setVariable(LOAN_PRICING, application.getJourneyPricing(execution));
	}
	
	public void preUpdatePricingDetails(DelegateExecution execution) {
		JSONObject medhasOffer = CreditBusinessHelper.getJSONObject(execution.getVariable(MEDHAS_OFFER));
		JSONObject pricingDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(LOAN_PRICING));
		
		execution.setVariable(PAYLOAD, calculateFeesAndUpdatePricing(medhasOffer, pricingDetails));
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject calculateFeesAndUpdatePricing(JSONObject medhasOffer, JSONObject pricingDetails) {
		Object medhasFeesPercentObj = medhasOffer.get("processingFeePercent");
		Object feesListObj = pricingDetails.get("fees");
		if(null!= medhasOffer && null != medhasFeesPercentObj && null != pricingDetails && null != feesListObj) {
			List<Map<String, Object>> feesList = (ArrayList<Map<String, Object>>) pricingDetails.get("fees");
			List<Map<String, Object>> updatedFessList = new ArrayList<Map<String,Object>>();
			for (Map<String, Object> fee : feesList) {
				if (null != fee.get("feeCode") && "PROCFEE".equalsIgnoreCase(fee.get("feeCode").toString())) {
					BigDecimal feesAmount = calculateFeeFromMedhasOffer(medhasOffer, pricingDetails.get("finalLoanAmount"));
					fee.put("feesInAmount", null != feesAmount ? feesAmount : fee.get("feesInAmount"));
					fee.put("feesInPercent", medhasOffer.get("processingFeePercent"));
				}
				updatedFessList.add(fee);
			}
			pricingDetails.put("fees", updatedFessList);
		}
		return pricingDetails;
	}
	
	private BigDecimal calculateFeeFromMedhasOffer(JSONObject medhasOffer, Object loanAmount) {
		BigDecimal feesAmount = null;
		Object minProcessingFee = medhasOffer.get("minProcessingFee");
		if(null != loanAmount && null != medhasOffer.get("processingFeePercent")) {
			Long processingFeePercent = ((Double) medhasOffer.get("processingFeePercent")).longValue();
			feesAmount = BigDecimal.valueOf((((Double) loanAmount).longValue() * processingFeePercent) / 100);
		}
		if(null != minProcessingFee && null != feesAmount) {
			long minProcessFee = ((Double) minProcessingFee).longValue();
			feesAmount = feesAmount.longValue() > minProcessFee ? BigDecimal.valueOf(minProcessFee) : feesAmount;  
		}
		return feesAmount;
	}
	
	public void preGetIncomeImputation(DelegateExecution execution) {
		execution.setVariable(SKIP_API_EXCEPTION, true);
	}
	
	public void postGetIncomeImputation(DelegateExecution execution) {
		Object apiException = execution.getVariable(API_EXCEPTION_ARISE);
		
		if (null != apiException && (boolean) apiException) {
			execution.setVariable("status", "");
		} else {
			ArrayList<?> incomeEstimationList = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
			JSONObject incomeEstimation = CreditBusinessHelper.getJSONObject(incomeEstimationList.get(0));
			execution.setVariable("incomeputationkey", incomeEstimation.get("incomemputationKey"));
			execution.setVariable("status", incomeEstimation.get("status"));
		}
		
		// remove exception skip flags from execution once task gets completed
		List<String> variablesToRemoveFromExecution = new ArrayList<String>();
		variablesToRemoveFromExecution.add(SKIP_API_EXCEPTION);
		variablesToRemoveFromExecution.add(API_EXCEPTION_ARISE);
		
		execution.removeVariables(variablesToRemoveFromExecution);
	}
	
	public void postFetchChannelJson(DelegateExecution execution) {
		JSONObject channelResponseJson = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable("perfiosJson", channelResponseJson.get("channelResponse"));
	}
	
	public void preCVApprovalStatus(DelegateExecution execution) {
		JSONObject payload = new JSONObject();
		payload.put("statusValue", ApplicationStatusEnum.APPROVAL.getCode());
		payload.put("statusKey", ApplicationStatusEnum.APPROVAL.getKey());
		execution.setVariable(PAYLOAD, payload);
		
	}
	
	public void postFetchCibilReportJson(DelegateExecution execution) {
		Object cibilResponseObject = execution.getVariable(OUTPUT);
		execution.setVariable(CIBIL_JSON, CreditBusinessHelper.objectToJson(cibilResponseObject));
	}
}
