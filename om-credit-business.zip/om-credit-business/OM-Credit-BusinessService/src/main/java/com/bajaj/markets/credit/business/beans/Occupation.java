package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Business;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Other;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Salaried;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.CaIcwaSelfEmployed;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.DoctorSalaried;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.DoctorSelfEmployed;

public class Occupation implements Serializable {

	private static final long serialVersionUID = 2703536940790674843L;

	@NotNull(groups = { Salaried.class, Business.class, Other.class, DoctorSalaried.class, DoctorSelfEmployed.class,
			CaIcwaSelfEmployed.class }, message = "ocupationType cannot be null or empty")
	private Reference ocupationType;

	@Valid
	@NotNull(groups = { Salaried.class, Other.class, DoctorSalaried.class }, message = "salariedDetail cannot be null or empty")
	private SalariedDetail salariedDetail;

	@Valid
	@NotNull(groups = { Business.class, DoctorSelfEmployed.class, CaIcwaSelfEmployed.class }, message = "businessOwnerDetails cannot be null or empty")
	private BusinessOwnerDetails businessOwnerDetails;

	private ProfessionDetail profession;

	public Reference getOcupationType() {
		return ocupationType;
	}

	public void setOcupationType(Reference ocupationType) {
		this.ocupationType = ocupationType;
	}

	public SalariedDetail getSalariedDetail() {
		return salariedDetail;
	}

	public void setSalariedDetail(SalariedDetail salariedDetail) {
		this.salariedDetail = salariedDetail;
	}

	public BusinessOwnerDetails getBusinessOwnerDetails() {
		return businessOwnerDetails;
	}

	public void setBusinessOwnerDetails(BusinessOwnerDetails businessOwnerDetails) {
		this.businessOwnerDetails = businessOwnerDetails;
	}

	public ProfessionDetail getProfession() {
		return profession;
	}

	public void setProfession(ProfessionDetail profession) {
		this.profession = profession;
	}

	@Override
	public String toString() {
		return "Occupation [ocupationType=" + ocupationType + ", salariedDetail=" + salariedDetail + ", businessOwnerDetails=" + businessOwnerDetails
				+ ", profession=" + profession + "]";
	}
}
