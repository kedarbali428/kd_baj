package com.bajaj.markets.credit.business.beans;

public class Name {


	private String firstName;

	private String middleName;

	private String lastName;

	private Long salutationKey;

	private Verification verification;
	
	public Name(){
		
	}

	public Name(String firstName, String middleName, String lastName, Long salutationKey,
			Verification verification) {
		super();
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.salutationKey = salutationKey;
		this.verification = verification;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Long getSalutationKey() {
		return salutationKey;
	}
	public void setSalutationKey(Long salutationKey) {
		this.salutationKey = salutationKey;
	}
	public Verification getVerification() {
		return verification;
	}
	public void setVerification(Verification verification) {
		this.verification = verification;
	}
	@Override
	public String toString() {
		return "Name [firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName
				+ ", salutationKey=" + salutationKey + ", verification=" + verification + "]";
	}
}
