package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PLTB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PLCS_HTS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PLCS_MTS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NTB_PLCS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.activiti.engine.RuntimeService;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.BankMaster;
import com.bajaj.markets.credit.business.beans.BtBankResponse;
import com.bajaj.markets.credit.business.beans.BusinessOwnerDetails;
import com.bajaj.markets.credit.business.beans.CreditParameters;
import com.bajaj.markets.credit.business.beans.CustDerivedIndustryMaster;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.LookupCodeResponse;
import com.bajaj.markets.credit.business.beans.LookupCodeValuesResponseBean;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.Pincode;
import com.bajaj.markets.credit.business.beans.PropertyDetails;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.beans.SalariedDetail;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.ReferenceOf;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessProfessionService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class CreditBusinessProfessionServiceImpl implements CreditBusinessProfessionService {

	private static final String LOANAGAINSTPROPERTYBALTRANSFER = "LAPBT";

	private static final String HOMELOANBALANCETRANSFER = "HLBT";

	private static final String LOANAGAINSTPROPERTY = "LAP";

	private static final String HOMELOANFRESH = "HLF";

	@Autowired
	RuntimeService runtimeService;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	MasterDataRedisClientHelper masterDataRedisClientHelper;

	@Value("${api.omcreditapplicationservice.userprofiles.allapplicants.get.url}")
	private String getUserProfilesUrl;
	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getOccupationUrl;
	@Value("${api.omcreditapplicationservice.getaddress.get.url}")
	private String getAddressURL;
	@Value("${api.omreferencedatareferencedataservice.location.pincodekey.get.url}")
	private String getAddressOnPincodeKeyUrl;
	@Value("${api.omreferencedatareferencedataservice.location.residence.get.url}")
	private String getResidenceUrl;
	@Value("${api.omreferencedatareferencedataservice.location.business.get.url}")
	private String getBussinessMaster;
	@Value("${api.omreferencedatareferencedataservice.location.industry.get.url}")
	private String getIndustryMaster;

	@Value("${api.omreferencedatareferencedataservice.getemployer.get.url}")
	private String employerMasterUrl;

	@Value("${api.omreferencedatareferencedataservice.lookup.code.get.url}")
	private String lookUpCodeUrl;
	
	@Value("${api.omcreditapplicationservice.propertydetails.get.url}")
	private String getPropertyDetailsUrl;
	
	@Value("${api.omcreditapplicationservice.getapplicationproduct.get.url}")
	private String getApplicationProduct;
	
	@Value("${api.omcreditapplicationservice.btbankdetails.get.url}")
	private String getBTBankDetailsUrl;
	
	@Value("${api.omreferencedataservice.bank.bankmasterkey.GET.url}")
	private String bankMasterGetBankMasterKeyURL;
	
	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	WorkflowHelper workflowHelper;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	@Autowired 
	private CreditBusinessGinHelper ginHelper;

	private static final String CLASS_NAME = CreditBusinessProfessionServiceImpl.class.getCanonicalName();

	public ApplicationResponse saveProfessionalDet(CreditParameters creditParameters, String applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start saveProfessionalDet for applicationid : " + applicationId);
		creditParameters.setApplicationid(applicationId);
		Map<String, Object> vars = Collections.<String, Object>singletonMap(CreditBusinessConstants.REQUEST, creditParameters);
		try {
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End updateProfile for applicationid : " + applicationId);
			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			ApplicationResponse applicationResponse = new ApplicationResponse();
			applicationResponse.setNextTask(task);
			return applicationResponse;
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception completing workflow task" ,e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while calling the service",e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-101", "Exception while completing activiti task"));
		}
	}

	@Override
	public CreditParameters getProfessionalDet(String applicationId) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		CreditParameters creditParameters = new CreditParameters();
		Occupation occupation = null;
		String appAttributeKey = null;
		HashMap<String, String> params = new HashMap<>();
		try {
			Boolean isEtb = false;
			ApplicationDetail application = apiCallsHelper.getApplicationDetails(applicationId, headers);
			params.put("applicationid", applicationId);
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			creditParameters.setL2ProductCode(application.getL2ProductCode());
			if (CreditBusinessConstants.PRODUCT_CODE_OMPL.equalsIgnoreCase(application.getL2ProductCode())) {
				isEtb = ginHelper.checkIsEtbCustomer(applicationId);
				String plcsRiskOfferType = null;
				//LEN-1712
				List<AppOfferDetBean> offerList = apiCallsHelper.fetchOffers(applicationId, null, headers);
				if (!CollectionUtils.isEmpty(offerList)) {
					for (AppOfferDetBean appOfferDetBean : offerList) {
						if (null!=appOfferDetBean.getOfferSrcKey() && appOfferDetBean.getOfferSrcKey() == 1l) {
							plcsRiskOfferType = appOfferDetBean.getRiskOfferType();
							break;
						}
					}
				}
				if (null != isEtb && isEtb.booleanValue() && null != plcsRiskOfferType
						&& isPlcsOffer(plcsRiskOfferType)) {
					creditParameters.setFreeTextForEmployer(true);
				}
			}
			creditParameters.setIsEtb(isEtb);
			ResponseEntity<?> userProfileResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getUserProfilesUrl, List.class, params, null,
					headers);

			List<UserProfileBean> userProfileList = mapper.convertValue(userProfileResponse.getBody(), new TypeReference<List<UserProfileBean>>() {
			});
			for (UserProfileBean userProfile : userProfileList) {
				if(null != userProfile.getName()) {
					if(null != userProfile.getName().getFirstName() && null != userProfile.getName().getMiddleName() && null != userProfile.getName().getLastName()) {
						creditParameters.setName(userProfile.getName().getFirstName() + " " + userProfile.getName().getMiddleName() + " " + userProfile.getName().getLastName());
					} else if(null != userProfile.getName().getFirstName() && null != userProfile.getName().getLastName()) {
						creditParameters.setName(userProfile.getName().getFirstName() + " " + userProfile.getName().getLastName());
					}
				}
				if (userProfile.getApplicationUserAttributeType().equals("1")) {
					appAttributeKey = userProfile.getApplicationUserAttributeKey();

					// call reference data for residencetype details.
					ResponseEntity<?> getOccupationResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getResidenceUrl, List.class, params, null,
							new HttpHeaders());
					List<ResidenceMaster> residenceMastList = mapper.convertValue(getOccupationResponse.getBody(), new TypeReference<List<ResidenceMaster>>() {
					});
					residenceMastList.forEach(residenceMast -> {
						if (null != userProfile.getResidenceTypeKey() && userProfile.getResidenceTypeKey().equals(residenceMast.getResidenceKey())) {
							if (CreditBusinessConstants.RESIDENCE_OWN.equals(residenceMast.getResidenceCode())
									|| CreditBusinessConstants.RESIDENCE_RENTAL.equals(residenceMast.getResidenceCode())
									|| CreditBusinessConstants.RESIDENCE_RENTALFAMILY
											.equals(residenceMast.getResidenceCode())
									|| CreditBusinessConstants.RESIDENCE_OTHERS
											.equals(residenceMast.getResidenceCode())) {
								creditParameters.setResidenceType(getReference(residenceMast.getResidenceKey(),
										residenceMast.getResidenceCode(), residenceMast.getResidenceValue()));
							} else {
								creditParameters.setResidenceType(getReference(CreditBusinessConstants.RESIDENCE_KEY,
										CreditBusinessConstants.RESIDENCE_OWN, CreditBusinessConstants.RESIDENCE_OWN_VALUE));
							}
						}
					});
					
					creditParameters.setDateOfBirth(userProfile.getDateOfBirth());
				}
				if(userProfile.getApplicationUserAttributeType().equals("2")) {
					String coappAttributeKey = userProfile.getApplicationUserAttributeKey();
					params.put("userattributekey", coappAttributeKey);
					ResponseEntity<?> getOccupationResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getOccupationUrl, Object.class, params, null,
							new HttpHeaders());
					occupation = mapper.convertValue(getOccupationResponse.getBody(), Occupation.class);
					SalariedDetail salariedDetail = occupation.getSalariedDetail();
					if(null != salariedDetail && null != salariedDetail.getNetSalary()) {
						creditParameters.setCoapplicantIncome(salariedDetail.getNetSalary());
						creditParameters.setCoapplicantEarning(true);
					}
					
					if(null != userProfile.getCoapplicantObligation()) {
						creditParameters.setCoapplicantObligation(null != userProfile.getCoapplicantObligation() ? userProfile.getCoapplicantObligation().toString() : null);
					}
				}
			}
			if (!StringUtils.isEmpty(appAttributeKey)) {
				params.put("userattributekey", appAttributeKey);
				ResponseEntity<?> getOccupationResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getOccupationUrl, Object.class, params, null,
						new HttpHeaders());
				occupation = mapper.convertValue(getOccupationResponse.getBody(), Occupation.class);
				SalariedDetail salariedDetail = occupation.getSalariedDetail();
				BusinessOwnerDetails businessOwnerDetails = occupation.getBusinessOwnerDetails();
				
				if (null != salariedDetail) {
					occupation.setSalariedDetail(
							this.prepareResponseFromSalariedDetails(salariedDetail, headers, mapper));
				} 
				
				if (null != businessOwnerDetails) {
					occupation.setBusinessOwnerDetails(
							this.prepareResponseFromBusinessOwnerDetails(businessOwnerDetails, headers, mapper, params));
						}
				creditParameters.setProfession(occupation);

				Pincode pinCode = getCurrentAddressDetails(applicationId, appAttributeKey, headers);
				creditParameters.setResidencePincode(pinCode);
			}
			
			//get PropertyAddress for secured loan
			//get HLProduct Intent
			params.put("applicationid",applicationId);
			ResponseEntity<?> getApplicationProductResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					getApplicationProduct, String.class, params, null, headers);
			Gson gson = new Gson();
			JSONObject payload = gson.fromJson((String) getApplicationProductResponse.getBody(), JSONObject.class);
			if(null != payload.get("hlProductIntent")) {
				creditParameters.setHlProductIntent(payload.get("hlProductIntent").toString());
				SecuredProfessionalDetails(applicationId,headers, creditParameters,appAttributeKey);
			}
		} catch (CreditBusinessException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured : " + e);
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found, but still returning Occupation");
				creditParameters.setProfession(occupation);
				params.put("applicationid",applicationId);
				ResponseEntity<?> getApplicationProductResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
						getApplicationProduct, String.class, params, null, headers);
				Gson gson = new Gson();
				JSONObject payload = gson.fromJson((String) getApplicationProductResponse.getBody(), JSONObject.class);
				if(null != payload.get("hlProductIntent")) {
					creditParameters.setHlProductIntent(payload.get("hlProductIntent").toString());
				}
				return creditParameters;
			}
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while Get Credit Parameters" + e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "Exception occured while Get Credit Parameters"));
		}

		return creditParameters;
	}
	
	private SalariedDetail prepareResponseFromSalariedDetails(SalariedDetail salariedDetail, HttpHeaders headers, ObjectMapper mapper) {
		if(null != salariedDetail.getEmployerName() && null != salariedDetail.getEmployerName().getKey()) {
			JSONObject employerMaster = null;
			try {
				Map<String, String> param = new HashMap<>();
				param.put("employerid", salariedDetail.getEmployerName().getKey().toString());
				ResponseEntity<?> getIndustryMasterRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
						employerMasterUrl, Object.class, param, null, headers);
				employerMaster = mapper.convertValue(getIndustryMasterRes.getBody(), JSONObject.class);
			}catch(Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "prepareResponseFromSalariedDetails: No record found for employerId"+salariedDetail.getEmployerName().getKey().toString());
			}
			if (null != employerMaster) {
				String employerName = null != employerMaster.get("emprMasterName") ? employerMaster.get("emprMasterName").toString() : null;
				salariedDetail.getEmployerName().setValue(employerName);
			}
		}
		
		if (null != salariedDetail.getQualification() && null != salariedDetail.getQualification().getKey()) {
			salariedDetail.setQualification(apiCallsHelper.getReference(ReferenceOf.QUALIFICATION, null, 
					getReference(salariedDetail.getQualification().getKey(), null, null)));
		}
		
		if (null != salariedDetail.getSpecialization() && null != salariedDetail.getSpecialization().getKey()) {
			MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
			queryParams.add("spclMasterKey", salariedDetail.getSpecialization().getKey().toString());
			Reference filterReference = getReference(salariedDetail.getSpecialization().getKey(), null, null);
			salariedDetail.setSpecialization(apiCallsHelper.getReference(ReferenceOf.SPECIALIZATION, queryParams, filterReference));
		}
		return salariedDetail;
	}
	
	private BusinessOwnerDetails prepareResponseFromBusinessOwnerDetails(BusinessOwnerDetails businessOwnerDetails, HttpHeaders headers,
			ObjectMapper mapper, Map<String, String> params) {
		if (null != businessOwnerDetails.getIndustryType()) {
			ResponseEntity<?> getIndustryMasterRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getIndustryMaster, Object.class, params,
					null, headers);
			List<CustDerivedIndustryMaster> custDerivedIndustryMaster = mapper.convertValue(getIndustryMasterRes.getBody(),
					new TypeReference<List<CustDerivedIndustryMaster>>() {
					});
			custDerivedIndustryMaster.forEach(indMast -> {
				if (null != businessOwnerDetails.getIndustryType() && null != businessOwnerDetails.getIndustryType().getKey()
						&& businessOwnerDetails.getIndustryType().getKey().equals(indMast.getCustIndMastKey())) {
					businessOwnerDetails
							.setIndustryType(getReference(indMast.getCustIndMastKey(), indMast.getCategoryCd(), indMast.getCustIndMastDesc()));
				}
			});
		}
		
		if (null != businessOwnerDetails.getAnualTurnover()	&& null != businessOwnerDetails.getAnualTurnover().getValue()) {
			params.put("lkpcode", "ANNUALTURNOVER");
			ResponseEntity<?> getlLookUpCodeRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, lookUpCodeUrl, Object.class, params, null,
					new HttpHeaders());
			LookupCodeResponse lookUpCode = mapper.convertValue(getlLookUpCodeRes.getBody(), LookupCodeResponse.class);
			List<LookupCodeValuesResponseBean> annualTurnOverList = lookUpCode.getLookupValuesResponseList().stream()
					.filter(o -> o.getValue().contains(businessOwnerDetails.getAnualTurnover().getValue())).collect(Collectors.toList());
			if (!CollectionUtils.isEmpty(annualTurnOverList)) {
				businessOwnerDetails.setAnualTurnover(getReference(annualTurnOverList.get(0).getKey().longValue(), annualTurnOverList.get(0).getCode(),
						annualTurnOverList.get(0).getValue()));
			}
		}
		
		if (null != businessOwnerDetails.getQualification() && null != businessOwnerDetails.getQualification().getKey()) {
			businessOwnerDetails.setQualification(apiCallsHelper.getReference(ReferenceOf.QUALIFICATION, null, 
					getReference(businessOwnerDetails.getQualification().getKey(), null, null)));
		}
		
		if (null != businessOwnerDetails.getSpecialization() && null != businessOwnerDetails.getSpecialization().getKey()) {
			MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
			queryParams.add("spclMasterKey", businessOwnerDetails.getSpecialization().getKey().toString());
			Reference filterReference = getReference(businessOwnerDetails.getSpecialization().getKey(), null, null);
			businessOwnerDetails.setSpecialization(apiCallsHelper.getReference(ReferenceOf.SPECIALIZATION, queryParams, filterReference));
		}
		
		return businessOwnerDetails;
	}

	private boolean isPlcsOffer(String plcsRiskOfferType) {
		return PLTB.equals(plcsRiskOfferType) || PLCS_HTS.equals(plcsRiskOfferType)
				|| PLCS_MTS.equals(plcsRiskOfferType) || NTB_PLCS.equals(plcsRiskOfferType) || PL.equals(plcsRiskOfferType);
	}

	private void SecuredProfessionalDetails(String applicationId,HttpHeaders headers, CreditParameters creditParameters, String appAttributeKey) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		switch(creditParameters.getHlProductIntent()) {
		case HOMELOANFRESH:
			creditParameters.setPropertyDetails(getPropertyDetails(applicationId, headers, mapper));
			break;
		case LOANAGAINSTPROPERTY :
			creditParameters.setPropertyPincode(getPropertyAddressDetails(applicationId, headers,appAttributeKey, mapper));
			break;
		case HOMELOANBALANCETRANSFER :
			creditParameters.setBtBankDetails(getBtBankDetails(applicationId, headers, appAttributeKey, mapper));
			break;
		case LOANAGAINSTPROPERTYBALTRANSFER :
			creditParameters.setPropertyPincode(getPropertyAddressDetails(applicationId, headers,appAttributeKey, mapper));
			creditParameters.setBtBankDetails(getBtBankDetails(applicationId, headers, appAttributeKey, mapper));
			break;
		}
	}

	private BankMaster getBtBankDetails(String applicationId, HttpHeaders headers, String appAttributeKey, ObjectMapper mapper) {
		BtBankResponse btBankResponse;
		Map<String, String> params;
		params = new HashMap<>();
		params.put("applicationKey", applicationId);
		params.put("userattributekey", appAttributeKey);
		ResponseEntity<?> getBtBankDetails = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getBTBankDetailsUrl, Object.class, params,
				null, headers);
		btBankResponse = mapper.convertValue(getBtBankDetails.getBody(), BtBankResponse.class);
		BankMaster bankMaster = null;
		if(null != btBankResponse && btBankResponse.getBankMasterKey() !=0) {
		    params = new HashMap<>();
			params.put("bankMasterKey", btBankResponse.getBankMasterKey().toString());
			ResponseEntity<?> branchDetailsResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					bankMasterGetBankMasterKeyURL, Object.class, params, null, headers);
			ArrayList<?> bankMasterDetails = (ArrayList<?>) branchDetailsResponse.getBody();
			JSONObject bankMasterDetail = CreditBusinessHelper.getJSONObject(bankMasterDetails.get(0));
			bankMaster = new BankMaster();
			bankMaster.setBankMasterKey(btBankResponse.getBankMasterKey().longValue());
			bankMaster.setBankCode(null != bankMasterDetail.get("bankCode") ? bankMasterDetail.get("bankCode").toString() : null);
			bankMaster.setBankName(null != bankMasterDetail.get("bankName") ? bankMasterDetail.get("bankName").toString() : null);
		}
		return bankMaster;
	}

	private PropertyDetails getPropertyDetails(String applicationId, HttpHeaders headers, ObjectMapper mapper) {
		Map<String, String> params = new HashMap<>();
		PropertyDetails propertyDetails = null;
		params.put("applicationKey", applicationId);
		ResponseEntity<?> propertyDetailsResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getPropertyDetailsUrl, Object.class, params, null,
				headers);
		if(null != propertyDetailsResponse && propertyDetailsResponse.getStatusCode().equals(HttpStatus.OK)) {
			propertyDetails  = mapper.convertValue(propertyDetailsResponse.getBody(), PropertyDetails.class);
		}
		return propertyDetails;
	}

	private Pincode getPropertyAddressDetails(String applicationId, HttpHeaders headers, String appAttributeKey, ObjectMapper mapper) {
		Pincode pinCode = null;
		Address address = null;
		LocationResponseBean addressBean = null;
		Map<String, String> params = new HashMap<>();
		params.put("typeKey", "95");
		params.put("applicationid",applicationId);
		params.put("userattributekey", appAttributeKey);
		ResponseEntity<?> getAddressResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getAddressURL, Object.class, params, null,
				headers);
		address = mapper.convertValue(getAddressResponse.getBody(), Address.class);
		// Call datareference service
		if (null != address && !StringUtils.isEmpty(address.getPincodeKey())) {
			params.put("pincodeKey", address.getPincodeKey());
			
			ResponseEntity<?> getPinDetails = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getAddressOnPincodeKeyUrl, Object.class, params,
					null, headers);
			addressBean = mapper.convertValue(getPinDetails.getBody(), LocationResponseBean.class);
			pinCode = new Pincode();
			pinCode.setPincode(addressBean.getPincode());
			pinCode.setCity(getReference(addressBean.getCityKey(), addressBean.getCityCode(), addressBean.getCityName()));
			pinCode.setCountry(getReference(addressBean.getCountryKey(), addressBean.getCountryCode(), addressBean.getCountryName()));
			pinCode.setState(getReference(addressBean.getStateKey(), addressBean.getStateCode(), addressBean.getStateName()));
		}
		return pinCode;
	}

	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;

	}
	
	
	
	private Pincode getCurrentAddressDetails(String applicationId, String appAttributeKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Started getCurrentAddressDetails");
		Pincode pinCode = null;
		Map<String, String> params = new HashMap<String, String>();
		params.put("applicationid", applicationId);
		params.put("userattributekey", appAttributeKey);
		params.put("typeKey", AddressTypeEnum.CURRENT.getValue());
		params.put("returnSingleCurrentAddressFlag",Boolean.TRUE.toString());
		params.put("removeExactMatchCurrentAddress",Boolean.FALSE.toString());
		try {
			List<Address> addressList = apiCallsHelper.getAddressV2(headers, params);
			for(Address addrs : addressList) {
				if(addrs.getPinCodeBean() != null) {
					LocationResponseBean pinCodeBean = addrs.getPinCodeBean();
					pinCode = new Pincode();
					pinCode.setPincode(pinCodeBean.getPincode());
					pinCode.setCity(getReference(pinCodeBean.getCityKey(), pinCodeBean.getCityCode(), pinCodeBean.getCityName()));
					pinCode.setCountry(getReference(pinCodeBean.getCountryKey(), pinCodeBean.getCountryCode(), pinCodeBean.getCountryName()));
					pinCode.setNegativeAreaFlag(pinCodeBean.getPinNegativeAreaFlg() != 0);
					pinCode.setOglFlag(pinCodeBean.getPinOglFlg() != 0);
					pinCode.setState(getReference(pinCodeBean.getStateKey(), pinCodeBean.getStateCode(), pinCodeBean.getStateName()));
					break;
				}
			}
		} catch (CreditBusinessException e) {
			if (HttpStatus.NOT_FOUND.equals(e.getCode())) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found exception while fetching V2 address with params = " + params);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while fetching V2 address with params = " + params, e);
				throw e;
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Completed getCurrentAddressDetails");
		return pinCode;
	}
}
 