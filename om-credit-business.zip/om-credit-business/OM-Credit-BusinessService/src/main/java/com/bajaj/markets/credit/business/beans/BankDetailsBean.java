package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;
import java.util.Date;

public class BankDetailsBean {
	
	private long prospectbankdetkey;

	private String accnum;

	private Date ecsexpirydt;

	private BigDecimal openecsavailablelimit;

	private BigDecimal openecslimit;

	private Long prospectkey;
	
	private Long bankmastkey;
	
	private Long branchkey;
	
	private Long acctypkey;
	
	private String subrepaymode;
	
	private String bankCode;
	
	private String branchCode;
	
	private String bankName;
	
	private String branchName;
	
	private String ifscCode;
	
	public long getProspectbankdetkey() {
		return prospectbankdetkey;
	}

	public void setProspectbankdetkey(long prospectbankdetkey) {
		this.prospectbankdetkey = prospectbankdetkey;
	}

	public String getAccnum() {
		return accnum;
	}

	public void setAccnum(String accnum) {
		this.accnum = accnum;
	}

	public Date getEcsexpirydt() {
		return ecsexpirydt;
	}

	public void setEcsexpirydt(Date ecsexpirydt) {
		this.ecsexpirydt = ecsexpirydt;
	}

	public BigDecimal getOpenecsavailablelimit() {
		return openecsavailablelimit;
	}

	public void setOpenecsavailablelimit(BigDecimal openecsavailablelimit) {
		this.openecsavailablelimit = openecsavailablelimit;
	}

	public BigDecimal getOpenecslimit() {
		return openecslimit;
	}

	public void setOpenecslimit(BigDecimal openecslimit) {
		this.openecslimit = openecslimit;
	}

	public Long getProspectkey() {
		return prospectkey;
	}

	public void setProspectkey(Long prospectkey) {
		this.prospectkey = prospectkey;
	}

	public Long getBankmastkey() {
		return bankmastkey;
	}

	public void setBankmastkey(Long bankmastkey) {
		this.bankmastkey = bankmastkey;
	}

	public Long getBranchkey() {
		return branchkey;
	}

	public void setBranchkey(Long branchkey) {
		this.branchkey = branchkey;
	}

	public Long getAcctypkey() {
		return acctypkey;
	}

	public void setAcctypkey(Long acctypkey) {
		this.acctypkey = acctypkey;
	}

	public String getSubrepaymode() {
		return subrepaymode;
	}

	public void setSubrepaymode(String subrepaymode) {
		this.subrepaymode = subrepaymode;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
}