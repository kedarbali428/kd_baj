package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

public class FppAtributes implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2536835470678873545L;

	@NotNull(message = "Height can not be null")
	@Digits(fraction = 2, integer = 20, message = "Height can not be other than digits")
	private Float height;

	@NotNull(message = "Weight can not be null")
	@Digits(fraction = 2, integer = 20, message = "Weight can not be other than digits")
	private Float weight;

	public Float getHeight() {
		return height;
	}

	public Float getWeight() {
		return weight;
	}

	public void setHeight(Float height) {
		this.height = height;
	}

	public void setWeight(Float weight) {
		this.weight = weight;
	}

}
