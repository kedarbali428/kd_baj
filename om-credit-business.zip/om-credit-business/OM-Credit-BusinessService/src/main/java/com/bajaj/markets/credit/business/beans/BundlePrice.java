package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;

public class BundlePrice {

	private BigDecimal bundleFinalPrice;
	
	private BigDecimal bundleFloorPrice;
	
	private BigDecimal bundleMaxPrice;
	
	private BigDecimal bundleCostReference;

	public BigDecimal getBundleFinalPrice() {
		return bundleFinalPrice;
	}

	public void setBundleFinalPrice(BigDecimal bundleFinalPrice) {
		this.bundleFinalPrice = bundleFinalPrice;
	}

	public BigDecimal getBundleFloorPrice() {
		return bundleFloorPrice;
	}

	public void setBundleFloorPrice(BigDecimal bundleFloorPrice) {
		this.bundleFloorPrice = bundleFloorPrice;
	}

	public BigDecimal getBundleMaxPrice() {
		return bundleMaxPrice;
	}

	public void setBundleMaxPrice(BigDecimal bundleMaxPrice) {
		this.bundleMaxPrice = bundleMaxPrice;
	}

	public BigDecimal getBundleCostReference() {
		return bundleCostReference;
	}

	public void setBundleCostReference(BigDecimal bundleCostReference) {
		this.bundleCostReference = bundleCostReference;
	}

	
}
