package com.bajaj.markets.credit.business.beans;

import javax.validation.constraints.Size;

public class ApplicantPANDetails {
@Size(min = 10, max = 10, message 
		      = "PAN can not be less than 10 or greater than 10")
private String panNumber;
private String verificationflg;
private String verificationsrc;
public String getPanNumber() {
	return panNumber;
}
public void setPanNumber(String panNumber) {
	this.panNumber = panNumber;
}
public String getVerificationflg() {
	return verificationflg;
}
public void setVerificationflg(String verificationflg) {
	this.verificationflg = verificationflg;
}
public String getVerificationsrc() {
	return verificationsrc;
}
public void setVerificationsrc(String verificationsrc) {
	this.verificationsrc = verificationsrc;
}
}
