package com.bajaj.markets.credit.business.beans.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class AccountTypeValidator implements ConstraintValidator<ValidAccountType, String> {
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if(null == value) {
			context.disableDefaultConstraintViolation();
			context.buildConstraintViolationWithTemplate("Account Type can not be null").addConstraintViolation();
			return false;
		}
		
		for(AccountType accountType: AccountType.values()) {
			if(value.equals(accountType.toString())) {
				return true;
			}
		}
		return false;
	}
	
	public enum AccountType{
		CURRENT("21"),
		SAVINGS("22");

		private String value;
		
		AccountType(String value) {
			this.value = value;
		}
		
		@Override
		public String toString() {
			return value;
		}
	}

}