package com.bajaj.markets.credit.business.beans;

public class ProfessionDetail {
	private Reference profession;

	public Reference getProfession() {
		return profession;
	}

	public void setProfession(Reference profession) {
		this.profession = profession;
	}
}
