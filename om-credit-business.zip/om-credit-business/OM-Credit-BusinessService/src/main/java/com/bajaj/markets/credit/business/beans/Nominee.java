package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.business.beans.validator.DateConstraint;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.FppSelected;

public class Nominee implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@DateConstraint(groups = FppSelected.class, format = "yyyy-MM-dd", message = "date of birth not valid")
	private String dateOfBirth;
	@NotNull
	private String name;
	private String relationcodemastkey;
	@NotNull
	private Reference relationship;

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public String getName() {
		return name;
	}

	public String getRelationcodemastkey() {
		return relationcodemastkey;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setRelationcodemastkey(String relationcodemastkey) {
		this.relationcodemastkey = relationcodemastkey;
	}

	public Reference getRelationship() {
		return relationship;
	}

	public void setRelationship(Reference relationship) {
		this.relationship = relationship;
	}

	@Override
	public String toString() {
		return "Nominee [dateOfBirth=" + dateOfBirth + ", name=" + name + ", relationcodemastkey=" + relationcodemastkey
				+ ", relationship=" + relationship + "]";
	}

}
