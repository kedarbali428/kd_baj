package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class AdditionalDetailPricing implements Serializable {

	private static final long serialVersionUID = 2703536940790674814L;

	private String l3ProductCode;
	private String l4ProductCode;
	private Double amount;
	private Double netDisbursementAmount;
	private Double roi;
	private Double emi;
	private Double totalFeeAmount;

	public Double getTotalFeeAmount() {
		return totalFeeAmount;
	}

	public void setTotalFeeAmount(Double totalFeeAmount) {
		this.totalFeeAmount = totalFeeAmount;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public String getL4ProductCode() {
		return l4ProductCode;
	}

	public Double getAmount() {
		return amount;
	}

	public Double getNetDisbursementAmount() {
		return netDisbursementAmount;
	}

	public Double getRoi() {
		return roi;
	}

	public Double getEmi() {
		return emi;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public void setNetDisbursementAmount(Double netDisbursementAmount) {
		this.netDisbursementAmount = netDisbursementAmount;
	}

	public void setRoi(Double roi) {
		this.roi = roi;
	}

	public void setEmi(Double emi) {
		this.emi = emi;
	}

	@Override
	public String toString() {
		return "AdditionalDetailPricing [l3ProductCode=" + l3ProductCode + ", l4ProductCode=" + l4ProductCode
				+ ", amount=" + amount + ", netDisbursementAmount=" + netDisbursementAmount + ", roi=" + roi + ", emi="
				+ emi + ", totalFeeAmount=" + totalFeeAmount + "]";
	}

}