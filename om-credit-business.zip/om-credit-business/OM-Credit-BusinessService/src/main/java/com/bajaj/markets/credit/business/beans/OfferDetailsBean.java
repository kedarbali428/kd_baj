package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class OfferDetailsBean {
	
	private Integer precedence;
	
	private String dataSourceName;

	private List<AppOfferDetBean> offers;
	
	private List<UserProfileBean> userProfileBeans;
	
	private List<DocumentDetails> documents;
	
	private List<Email> emails;
	
	private List<Address> addresses;
	
	private List<Occupation> occupations;
	
	private List<BankDetail> banks;
	
	private List<PrincipalCustomer> principalCustomerDetails;
	
	private List<EmandatesRequest> mandates;

	public Integer getPrecedence() {
		return precedence;
	}
	
	public void setPrecedence(Integer precedence) {
		this.precedence=precedence;
	}
	
	public String getDataSourceName() {
		return dataSourceName;
	}

	public void setDataSourceName(String dataSourceName) {
		this.dataSourceName = dataSourceName;
	}

	public List<AppOfferDetBean> getOffers() {
		return offers;
	}

	public void setOffers(List<AppOfferDetBean> offers) {
		this.offers = offers;
	}

	public List<UserProfileBean> getUserProfileBeans() {
		return userProfileBeans;
	}

	public void setUserProfileBeans(List<UserProfileBean> userProfileBeans) {
		this.userProfileBeans = userProfileBeans;
	}

	public List<DocumentDetails> getDocuments() {
		return documents;
	}

	public void setDocuments(List<DocumentDetails> documents) {
		this.documents = documents;
	}

	public List<Email> getEmails() {
		return emails;
	}

	public void setEmails(List<Email> emails) {
		this.emails = emails;
	}

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	public List<Occupation> getOccupations() {
		return occupations;
	}

	public void setOccupations(List<Occupation> occupations) {
		this.occupations = occupations;
	}

	public List<BankDetail> getBanks() {
		return banks;
	}

	public void setBanks(List<BankDetail> banks) {
		this.banks = banks;
	}

	public List<PrincipalCustomer> getPrincipalCustomerDetails() {
		return principalCustomerDetails;
	}

	public void setPrincipalCustomerDetails(List<PrincipalCustomer> principalCustomerDetails) {
		this.principalCustomerDetails = principalCustomerDetails;
	}

	public List<EmandatesRequest> getMandates() {
		return mandates;
	}

	public void setMandates(List<EmandatesRequest> mandates) {
		this.mandates = mandates;
	}
}