package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class EsignResponse {
	
	private Status  status ;
	private DocumentInfo  documentInfo;
	private boolean isCreated;
	private boolean isEsigned;
	private boolean isDocumentGenerated;
	private boolean isOTPRequired;
	private Long esignReferenceNumber;
	private String l3productCode;
	private List<EmbededDocuments> embededDocuments ;
	private boolean personalEmailRequired;

	
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public DocumentInfo getDocumentInfo() {
		return documentInfo;
	}
	public void setDocumentInfo(DocumentInfo documentInfo) {
		this.documentInfo = documentInfo;
	}
	public boolean getIsCreated() {
		return isCreated;
	}
	public void setIsCreated(boolean isCreated) {
		this.isCreated = isCreated;
	}
	public boolean getIsEsigned() {
		return isEsigned;
	}
	public void setIsEsigned(boolean isEsigned) {
		this.isEsigned = isEsigned;
	}
	public boolean getIsDocumentGenerated() {
		return isDocumentGenerated;
	}
	public void setIsDocumentGenerated(boolean isDocumentGenerated) {
		this.isDocumentGenerated = isDocumentGenerated;
	}
	
	public Long getEsignReferenceNumber() {
		return esignReferenceNumber;
	}
	public void setEsignReferenceNumber(Long esignReferenceNumber) {
		this.esignReferenceNumber = esignReferenceNumber;
	}
	public List<EmbededDocuments> getEmbededDocuments() {
		return embededDocuments;
	}
	public void setEmbededDocuments(List<EmbededDocuments> embededDocuments) {
		this.embededDocuments = embededDocuments;
	}
	public boolean getIsOTPRequired() {
		return isOTPRequired;
	}
	public void setIsOTPRequired(boolean isOTPRequired) {
		this.isOTPRequired = isOTPRequired;
	}
	public String getL3productCode() {
		return l3productCode;
	}
	public void setL3productCode(String l3productCode) {
		this.l3productCode = l3productCode;
	}
	public boolean isPersonalEmailRequired() {
		return personalEmailRequired;
	}
	public void setPersonalEmailRequired(boolean personalEmailRequired) {
		this.personalEmailRequired = personalEmailRequired;
	}
	@Override
	public String toString() {
		return "EsignResponse [status=" + status + ", documentInfo=" + documentInfo + ", isCreated=" + isCreated
				+ ", isEsigned=" + isEsigned + ", isDocumentGenerated=" + isDocumentGenerated + ", isOTPRequired="
				+ isOTPRequired + ", esignReferenceNumber=" + esignReferenceNumber + ", l3productCode=" + l3productCode
				+ ", embededDocuments=" + embededDocuments + ", personalEmailRequired=" + personalEmailRequired + "]";
	}
}
