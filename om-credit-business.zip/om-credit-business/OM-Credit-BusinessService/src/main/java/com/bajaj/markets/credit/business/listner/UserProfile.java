package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DATE_OF_BIRTH;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DOB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.FIRST_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.LAST_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MIDDLE_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.WORK_EMAIL_REQUIRED;

import java.util.ArrayList;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
public class UserProfile {

	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	private static final String CLASS_NAME = UserProfile.class.getCanonicalName();

	public void pre(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start getUserProfile");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (request != null &&  request.get(CreditBusinessConstants.APPLICATION_ID) != null) {
			execution.setVariable(CreditBusinessConstants.APPLICATION_ID, request.get(CreditBusinessConstants.APPLICATION_ID));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End getUserProfile");
	}

	public void post(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postUserProfile");
		execution.setVariable(WORK_EMAIL_REQUIRED, false);
		ArrayList<?> s = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		if (null != s) {
			for (Object object : s) {
				JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
				if (null != userProfile && userProfile.get(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE).equals("1")) {
					execution.setVariable(CreditBusinessConstants.USERPROFILEOUTPUT, userProfile);
					execution.setVariable(CreditBusinessConstants.MOBILE, userProfile.get(CreditBusinessConstants.MOBILE));
					execution.setVariable(CreditBusinessConstants.DOB, userProfile.get(CreditBusinessConstants.DATE_OF_BIRTH));
					execution.setVariable(CreditBusinessConstants.GENDERKEY, userProfile.get(CreditBusinessConstants.GENDERKEY));
					execution.setVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY,
							userProfile.get(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY));
					execution.setVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE,
							userProfile.get(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE));
					execution.setVariable(CreditBusinessConstants.NAME, userProfile.get(CreditBusinessConstants.NAME));
					if (userProfile.get(WORK_EMAIL_REQUIRED) != null && (boolean) userProfile.get(WORK_EMAIL_REQUIRED)) {
						execution.setVariable(WORK_EMAIL_REQUIRED, true);
					}
					
					JSONObject nameObj = creditBusinessHelper.getJSONObject(userProfile.get(CreditBusinessConstants.NAME));
					execution.setVariable(CreditBusinessConstants.NAME, nameObj);
					 
					if (nameObj != null) {
						String fName = nameObj.get(FIRST_NAME) != null ? nameObj.get(FIRST_NAME).toString() : "";
						String mName = nameObj.get(MIDDLE_NAME) != null ? nameObj.get(MIDDLE_NAME).toString() : "";
						String lName = nameObj.get(LAST_NAME) != null ? nameObj.get(LAST_NAME).toString() : "";
						execution.setVariable(CreditBusinessConstants.FULLNAME, fName + " " + mName + " " + lName);
					}
					execution.setVariable("isPrimaryAplt", true);
				} else {
					execution.setVariable("isPrimaryAplt", false);
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postUserProfile");
	}

	public void fetchPrimaryUserAttributeProfile(DelegateExecution execution) {
		ArrayList<?> userProfiles = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);

		if (null != userProfiles) {
			for (Object object : userProfiles) {
				JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
				if (null != userProfile && userProfile.get(APPLICATION_USER_ATTRIBUTE_TYPE).equals("1")) {
					execution.setVariable(APPLICATION_USER_ATTRIBUTE_KEY, userProfile.get(APPLICATION_USER_ATTRIBUTE_KEY));
					execution.setVariable(MOBILE, userProfile.get(MOBILE));
					execution.setVariable(DOB, userProfile.get(DATE_OF_BIRTH));
					break;
				}
			}
		}
	}

	public void fetchParentAppUserAttribute(DelegateExecution execution) {
		ArrayList<?> userProfiles = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);

		if (null != userProfiles) {
			for (Object object : userProfiles) {
				JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
				if (null != userProfile && userProfile.get(APPLICATION_USER_ATTRIBUTE_TYPE).equals("1")) {
					execution.setVariable("parentAppUserAttributeKey",userProfile.get(APPLICATION_USER_ATTRIBUTE_KEY));
					break;
				}
			}
		}
	}
	
}
