package com.bajaj.markets.credit.business.beans;

public class MandateDetailsBRE {
	private String mandateExpiryDate;
	private String mandateRegistrationNumber;
	private Long maxLimit;
	private Long balanceLimit;
	private String accountNo;
	private String bankBranchName;
	private String bankName;
	private String cName;
	private String ifscCode;
	private String micrCode;
	private String mandateCreatedsourceName;
	private String mandatereference;
	private String channelType;
	private String channelMandateReferenceId;
	private String sourceName;

	public void setMandateExpiryDate(String mandateExpiryDate) {
		this.mandateExpiryDate = mandateExpiryDate;
	}

	public void setMandateRegistrationNumber(String mandateRegistrationNumber) {
		this.mandateRegistrationNumber = mandateRegistrationNumber;
	}

	public void setMaxLimit(Long maxLimit) {
		this.maxLimit = maxLimit;
	}

	public void setBalanceLimit(Long balanceLimit) {
		this.balanceLimit = balanceLimit;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public void setMandateCreatedsourceName(String mandateCreatedsourceName) {
		this.mandateCreatedsourceName = mandateCreatedsourceName;
	}

	public void setMandatereference(String mandatereference) {
		this.mandatereference = mandatereference;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public void setChannelMandateReferenceId(String channelMandateReferenceId) {
		this.channelMandateReferenceId = channelMandateReferenceId;
	}

	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	@Override
	public String toString() {
		return "MandateDetailsBRE [mandateExpiryDate=" + mandateExpiryDate + ", mandateRegistrationNumber="
				+ mandateRegistrationNumber + ", maxLimit=" + maxLimit + ", balanceLimit=" + balanceLimit
				+ ", accountNo=" + accountNo + ", bankBranchName=" + bankBranchName + ", bankName=" + bankName
				+ ", cName=" + cName + ", ifscCode=" + ifscCode + ", micrCode=" + micrCode
				+ ", mandateCreatedsourceName=" + mandateCreatedsourceName + ", mandatereference=" + mandatereference
				+ ", channelType=" + channelType + ", channelMandateReferenceId=" + channelMandateReferenceId
				+ ", sourceName=" + sourceName + "]";
	}

}