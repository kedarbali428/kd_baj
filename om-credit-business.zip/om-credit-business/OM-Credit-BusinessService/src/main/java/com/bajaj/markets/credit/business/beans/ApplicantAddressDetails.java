package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;


public class ApplicantAddressDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private Long apltAddrKey;

	private Integer apltAddrIsActive;

	private String apltAddrLstUpdateBy;

	private Timestamp apltAddrLstUpdateDt;

	private String apltAddrSrc;

	@Temporal(TemporalType.DATE)
	private Date apltAddReffStartDt;

	private Long addrTypKey;

	private Long applicantKey;

	private Long pincodeKey;

	private String apltAddrAddressLine1;

	private String apltAddrAddressLine2;

	private String apltAddrFlatNum;

	private String apltAddrHouseNum;

	private String apltAddrStreet;

	private String countryKey;

	private String stateKey;

	private String cityKey;

	private Long localityKey;

	private Integer locOGLFlg;

	private Integer locNegativeAreaFlg;

	private BigDecimal occupancyType;

	public ApplicantAddressDetails() {
	}

	public Long getApltAddrKey() {
		return apltAddrKey;
	}

	public void setApltAddrKey(Long apltAddrKey) {
		this.apltAddrKey = apltAddrKey;
	}

	public Integer getApltAddrIsActive() {
		return apltAddrIsActive;
	}

	public void setApltAddrIsActive(Integer apltAddrIsActive) {
		this.apltAddrIsActive = apltAddrIsActive;
	}

	public String getApltAddrLstUpdateBy() {
		return apltAddrLstUpdateBy;
	}

	public void setApltAddrLstUpdateBy(String apltAddrLstUpdateBy) {
		this.apltAddrLstUpdateBy = apltAddrLstUpdateBy;
	}

	public Timestamp getApltAddrLstUpdateDt() {
		return apltAddrLstUpdateDt;
	}

	public void setApltAddrLstUpdateDt(Timestamp apltAddrLstUpdateDt) {
		this.apltAddrLstUpdateDt = apltAddrLstUpdateDt;
	}

	public String getApltAddrSrc() {
		return apltAddrSrc;
	}

	public void setApltAddrSrc(String apltAddrSrc) {
		this.apltAddrSrc = apltAddrSrc;
	}

	public Date getApltAddReffStartDt() {
		return apltAddReffStartDt;
	}

	public void setApltAddReffStartDt(Date apltAddReffStartDt) {
		this.apltAddReffStartDt = apltAddReffStartDt;
	}

	public Long getAddrTypKey() {
		return addrTypKey;
	}

	public void setAddrTypKey(Long addrTypKey) {
		this.addrTypKey = addrTypKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(Long pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public String getApltAddrAddressLine1() {
		return apltAddrAddressLine1;
	}

	public void setApltAddrAddressLine1(String apltAddrAddressLine1) {
		this.apltAddrAddressLine1 = apltAddrAddressLine1;
	}

	public String getApltAddrAddressLine2() {
		return apltAddrAddressLine2;
	}

	public void setApltAddrAddressLine2(String apltAddrAddressLine2) {
		this.apltAddrAddressLine2 = apltAddrAddressLine2;
	}

	public String getApltAddrFlatNum() {
		return apltAddrFlatNum;
	}

	public void setApltAddrFlatNum(String apltAddrFlatNum) {
		this.apltAddrFlatNum = apltAddrFlatNum;
	}

	public String getApltAddrHouseNum() {
		return apltAddrHouseNum;
	}

	public void setApltAddrHouseNum(String apltAddrHouseNum) {
		this.apltAddrHouseNum = apltAddrHouseNum;
	}

	public String getApltAddrStreet() {
		return apltAddrStreet;
	}

	public void setApltAddrStreet(String apltAddrStreet) {
		this.apltAddrStreet = apltAddrStreet;
	}

	public String getCountryKey() {
		return countryKey;
	}

	public void setCountryKey(String countryKey) {
		this.countryKey = countryKey;
	}

	public String getStateKey() {
		return stateKey;
	}

	public void setStateKey(String stateKey) {
		this.stateKey = stateKey;
	}

	public String getCityKey() {
		return cityKey;
	}

	public void setCityKey(String cityKey) {
		this.cityKey = cityKey;
	}

	public Long getLocalityKey() {
		return localityKey;
	}

	public void setLocalityKey(Long localityKey) {
		this.localityKey = localityKey;
	}

	public Integer getLocOGLFlg() {
		return locOGLFlg;
	}

	public void setLocOGLFlg(Integer locOGLFlg) {
		this.locOGLFlg = locOGLFlg;
	}

	public Integer getLocNegativeAreaFlg() {
		return locNegativeAreaFlg;
	}

	public void setLocNegativeAreaFlg(Integer locNegativeAreaFlg) {
		this.locNegativeAreaFlg = locNegativeAreaFlg;
	}

	public BigDecimal getOccupancyType() {
		return occupancyType;
	}

	public void setOccupancyType(BigDecimal occupancyType) {
		this.occupancyType = occupancyType;
	}
	
}