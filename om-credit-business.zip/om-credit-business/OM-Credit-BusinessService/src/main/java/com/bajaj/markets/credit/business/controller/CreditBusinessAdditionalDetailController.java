package com.bajaj.markets.credit.business.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.AdditionalDetail;
import com.bajaj.markets.credit.business.beans.AdditionalDetailLoans;
import com.bajaj.markets.credit.business.beans.AdditionalDetailPricing;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.validator.DateValidator;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessAdditionalDetailService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessAdditionalDetailController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessAdditionalDetailService creditBusinessAdditionalDetailService;

	@Autowired
	private DateValidator dateValidator;

	private static final String CLASS_NAME = CreditBusinessAdditionalDetailController.class.getCanonicalName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "Additional detail saved successsfully & process card api triggered", notes = "Additional detail saved successsfully & process card api triggered", httpMethod = "POST")
	@ApiImplicitParams({ @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Additional detail saved successsfully.", response = ApplicationResponse.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(path = "/v1/credit/applications/{applicationid}/card/additionaldetail", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationResponse> saveAdditionalDetail(@PathVariable("applicationid") String applicationId,
			@Valid @RequestBody AdditionalDetail additionalDetail, BindingResult result, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start saveAdditionalDetail :" + applicationId);
		if (!StringUtils.isNumeric(applicationId) || result.hasFieldErrors()) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Save Additional Details - Invalid request for: " + applicationId + " with error: " + result.getFieldErrors());
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_22", null != result.getFieldError() ? result.getFieldError().getDefaultMessage() : "Invalid request"));
		} else {
			dateValidator.validateAppointmentDateTime(additionalDetail.getPrincipalCode(),
					additionalDetail.getAppointmentDateTimeFrom(), additionalDetail.getAppointmentDateTimeTo());
			additionalDetail.setApplicationid(applicationId);
			ApplicationResponse applicationResponse = creditBusinessAdditionalDetailService.saveAdditionalDetail(additionalDetail, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End saveAdditionalDetail");
			return new ResponseEntity<>(applicationResponse, HttpStatus.CREATED);
		}
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "Get Additional Details for Resume flow", notes = "Get Additional Details for Resume flow", httpMethod = "GET")
	@ApiImplicitParams({ @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Additional Details fetched successfully", response = AdditionalDetail.class),
			@ApiResponse(code = 404, message = "No Resource found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/credit/applications/{applicationid}/card/additionaldetail", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<AdditionalDetail> getAdditionalDetail(@PathVariable("applicationid") String applicationId, @RequestParam String l3ProductCode,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside getAdditionalDetail with applicationId: " + applicationId + " and l3ProductCode " + l3ProductCode);
		AdditionalDetail additionalDetail = null;
		if (StringUtils.isNumeric(applicationId) && !StringUtils.isBlank(l3ProductCode)) {
			additionalDetail = creditBusinessAdditionalDetailService.getAdditionalDetail(applicationId, l3ProductCode);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Resource not found for given application Id and l3productcode.");
			throw new CreditBusinessException(HttpStatus.NOT_FOUND,
					new ErrorBean("CBS-1011", "Resource not found for given application Id and l3productcode."));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside getAdditionalDetail end with additionalDetail: " + additionalDetail);
		return new ResponseEntity<>(additionalDetail, HttpStatus.OK);
	}

	@ApiOperation(value = "Additional detail saved successsfully", notes = "Additional detail saved successsfully", httpMethod = "POST")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Additional detail saved successsfully.", response = ApplicationResponse.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(path = "/v1/credit/applications/loans/{applicationid}/additionaldetail", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationResponse> saveLoansAdditionalDetail(@PathVariable("applicationid") String applicationId,
			@Valid @RequestBody AdditionalDetailLoans additionalDetail, BindingResult result, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start saveLoansAdditionalDetail :" + applicationId);
		if (result.hasFieldErrors()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside saveAdditionalDetail method controller - resource validation failed");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_22", result.getFieldErrors().get(0).getDefaultMessage()));
		} else {
			additionalDetail.setApplicationid(applicationId);
			return creditBusinessAdditionalDetailService.saveLoansAdditionalDetail(additionalDetail, headers);
		}
	}

	@ApiOperation(value = "Additional detail fetched successsfully", notes = "Additional detail fetched successsfully", httpMethod = "GET")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Additional detail fetched successsfully.", response = AdditionalDetailLoans.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/credit/applications/loans/{applicationid}/additionaldetail", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<AdditionalDetailLoans> getLoansAdditionalDetail(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start getLoansAdditionalDetail :" + applicationId);
		AdditionalDetailLoans response = creditBusinessAdditionalDetailService.getLoansAdditionalDetail(applicationId, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End getLoansAdditionalDetail ");
		return new ResponseEntity<AdditionalDetailLoans>(response, HttpStatus.OK);
	}

	@ApiOperation(value = "Pricing Fetched successfully", notes = "Pricing Fetched successfully", httpMethod = "GET")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Pricing Fetched successfully", response = AdditionalDetailPricing.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/credit/loans/{applicationid}/summary", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<AdditionalDetailPricing> getPricing(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start getLoansAdditionalDetail :" + applicationId);
		AdditionalDetailPricing response = creditBusinessAdditionalDetailService.getPricing(applicationId, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End getLoansAdditionalDetail ");
		return new ResponseEntity<AdditionalDetailPricing>(response, HttpStatus.OK);
	}
}
