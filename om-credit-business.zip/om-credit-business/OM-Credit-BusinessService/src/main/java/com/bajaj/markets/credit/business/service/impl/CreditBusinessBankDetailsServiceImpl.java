package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.JOURNEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PROCESS_ID;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.BankDetails;
import com.bajaj.markets.credit.business.beans.BankDetailsBRE;
import com.bajaj.markets.credit.business.beans.BankDetailsReponse;
import com.bajaj.markets.credit.business.beans.BankMaster;
import com.bajaj.markets.credit.business.beans.BrePreferredBankResponse;
import com.bajaj.markets.credit.business.beans.DestinationBankInfo;
import com.bajaj.markets.credit.business.beans.EmandateResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.MandateBreRequest;
import com.bajaj.markets.credit.business.beans.MandateDetailsBRE;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessBankDetailsService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@RefreshScope
@Component
public class CreditBusinessBankDetailsServiceImpl implements CreditBusinessBankDetailsService {

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	WorkflowHelper workflowHelper;

	@Value("${api.omreferencedataservice.branch.GET.url}")
	public String branchGetURL;

	@Value("${api.omcreditapplicationservice.bankdetails.GET.url}")
	private String bankDetailsGetURL;

	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String childApplicationGetURL;

	@Value("${api.ompaymentsmanadatedomainservice.mandate.GET.url}")
	private String mandateGetURL;

	@Value("${api.omreferencedataservice.branch.branchkey.GET.url}")
	private String branchGetBranchKeyURL;
	
	@Value("${api.omcreditapplicationservice.preferred.bank.POST.url}")
	private String mandateBrePreferredBankURL;
	
	@Value("${api.omreferencedataservice.bank.bankname.GET.url}")
	private String bankMasterGetBankNameURL;
	
	@Value("${api.omreferencedataservice.bank.bankmasterkey.GET.url}")
	private String bankMasterGetBankMasterKeyURL;
	
	@Value("${om.bankaccount.repayment:false}")
	private Boolean preferredForRepayment;

	private ObjectMapper mapper = new ObjectMapper();

	public static final String CLASS_NAME = CreditBusinessBankDetailsServiceImpl.class.getCanonicalName();

	/**
	 * @param applicationId
	 * @param bankDetails
	 * @return ApplicationResponse
	 * 
	 *         This is used to add user added bank details to persist in
	 *         applications table at child application level, verify using imps,
	 *         check for mandate and accordingly provide next task to be shown to
	 *         user
	 */
	@Override
	public ApplicationResponse saveBankDetails(Long applicationId, BankDetails bankDetails, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start - saveBankDetails: " + bankDetails);

		try {
			ApplicationResponse applicationResponse = null;
			String processId = headers.get(PROCESS_ID).get(0);

			Map<String, String> params = new HashMap<String, String>();
			

			Map<String, Object> vars = new HashMap<String, Object>();
			vars.put(APPLICATION_ID, applicationId);
			vars.put("action", bankDetails.getAction());
			
			if(!StringUtils.isEmpty(bankDetails.getAction()) && "back".equals(bankDetails.getAction())) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "back action triggered");
				
				applicationResponse = new ApplicationResponse();
				NextTask nextTask = new NextTask();

				nextTask.setNextTaskKey(workflowHelper.completeTask(processId, vars));

				applicationResponse.setNextTask(nextTask);
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Action is not back starting workflow");
				JSONObject branchDetail = getBranchDetailsFromIfscCode(bankDetails.getIfscCode(), params, headers);
				if(null != branchDetail) {
					Long bankMasterKey = null != branchDetail.get("bankMasterKey") ? ((Double) branchDetail.get("bankMasterKey")).longValue() : null;
					
					if(null != bankMasterKey) {
						JSONObject bankMasterDetail = getBranchDetailsFromBankMasterKey(bankMasterKey.toString(), params, headers);
						if(null != bankMasterDetail) {
							bankDetails.setRepaymentMode(null != bankMasterDetail.get("preferredMode") ? 
									bankMasterDetail.get("preferredMode").toString() : null);
						} else {
							logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Bank Master Data Not Available for bankMasterKey: " + bankMasterKey);
						}
					} else {
						logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "bankMasterKey null for requested ifscCode: " + bankDetails.getIfscCode());
					}
					
					vars.put("branchDetail", branchDetail);
					vars.put("bankDetail", CreditBusinessHelper.getJSONObject(bankDetails));
					
					applicationResponse = new ApplicationResponse();
					NextTask nextTask = new NextTask();
					String nextTaskKey = workflowHelper.completeTask(processId, vars);
					nextTask.setNextTaskKey(nextTaskKey);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Workflow is completed, nextTaskKey received "+nextTaskKey);
	
					applicationResponse.setNextTask(nextTask);
					applicationResponse.setPayload(bankDetails);
				} else {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Not a valid IFSC code");
					throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_104", "Not a valid IfscCode"));
				}
			}

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End - saveBankDetails completed successfully: " + applicationResponse);
			return applicationResponse;
		} catch (CreditBusinessException creditBusinessException) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "CreditBusinessException: ", creditBusinessException);
			throw creditBusinessException;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception while completing the bank details save: " + e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-500", "Some Technical Exception Occurred"));
		}
	}

	/**
	 * @param applicationId
	 * @return bankDetails
	 * 
	 *              This is used to get bank details at child application level,
	 *              mandate get call and BRE call of type-1 to check whether bank
	 *              details are editable or not
	 */
	@Override
	public BankDetails getBankDetail(Long applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start - getBankDetails: " + applicationId);

		BankDetails bankDetails = null;
		try {
			Map<String, String> params = new HashMap<String, String>();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			// get child application
			getChildApplicationAndSetRequestParams(applicationId.toString(), params, headers);
			
			// get bank details
			List<BankDetailsReponse> bankDetailsResponses = getBankDetails(params, headers);

			// get mandate details
			List<EmandateResponse> emandateResponses = getMandateDetails(params, headers);

			// get bre preferred bank
			BrePreferredBankResponse preferredBankResponse = callMandateBre(params, bankDetailsResponses,
					emandateResponses, headers);

			bankDetails = new BankDetails();
			
			bankDetails.setBankDetailsEditable(preferredBankResponse.getBankDetailsEditableFlag());
			bankDetails.setAccountNumberEdited(preferredBankResponse.getAccountNumberEditFlag());

			BankDetailsBRE bankDetailFromBRE = preferredBankResponse.getBankDetails();
			if(null != bankDetailFromBRE) {
				bankDetails.setAccountNumber(bankDetailFromBRE.getAccountNo());
				bankDetails.setBankAccountHolderName(bankDetailFromBRE.getcName());
				bankDetails.setMandateAddedBy(bankDetailFromBRE.getMandateAddedby());
				bankDetails.setMandateReference(bankDetailFromBRE.getMandatereference());
//				bankDetails.setBankAccountType(preferredBankResponse.getBankDetails().getBankAccountType());
				
				String ifscCode = bankDetailFromBRE.getIfscCode();
				String bankName = bankDetailFromBRE.getBankName();
				
				if(!StringUtils.isEmpty(ifscCode)) {
					bankDetails.setIfscCode(ifscCode);
					
					JSONObject branchDetail = getBranchDetailsFromIfscCode(ifscCode, params, headers);
					if(null != branchDetail) {	
						BankMaster bankMaster = new BankMaster();
						bankMaster.setBankMasterKey(null != branchDetail.get("bankMasterKey") ? ((Double) branchDetail.get("bankMasterKey")).longValue() : null);
						bankMaster.setBankName(null != branchDetail.get("bankName") ? branchDetail.get("bankName").toString() : null);
						
						bankDetails.setBank(bankMaster);
					} else {
						logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Branch not available for ifsccode: " + bankDetails.getIfscCode());
					}
				} else if (!StringUtils.isEmpty(bankName)) {
					JSONObject bankMasterDetail = getBranchDetailsFromBankName(bankName, params, headers);
					if(null != bankMasterDetail) {	
						BankMaster bankMaster = new BankMaster();
						bankMaster.setBankMasterKey(((Double) bankMasterDetail.get("bankMasterKey")).longValue());
						bankMaster.setBankCode(bankMasterDetail.get("bankCode").toString());
						bankMaster.setBankName(bankMasterDetail.get("bankName").toString());
						
						bankDetails.setBank(bankMaster);
					} else {
						logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Bank master not available with master for bankName: " + bankName);
					}
				} else {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Neither ifscCode nor bankName available from BRE response");
				}
			}
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End - getBankDetails: " + bankDetails);
			return bankDetails;
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found. ");
				throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("CBS-102", "Resource not found."));
			}
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured : ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, 
					new ErrorBean("CBS-001", "Failed to get bank details"));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception: ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-001", "Failed to get bank details"));
		}
	}

	private List<BankDetailsReponse> getBankDetails(Map<String, String> params, HttpHeaders headers) {
		try {
			List<BankDetailsReponse> bankDetailsResponses = null;

			params.put("preferredForRepayment", preferredForRepayment.toString());

			ResponseEntity<?> bankDetailsResponseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					bankDetailsGetURL, List.class, params, null, headers);

			bankDetailsResponses = mapper.convertValue(bankDetailsResponseEntity.getBody(),
					new TypeReference<List<BankDetailsReponse>>() {
					});

			return bankDetailsResponses;
		} catch (CreditBusinessException e) {
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while Get Bank Details ", e);
			throw e;
		}
	}

	private List<EmandateResponse> getMandateDetails(Map<String, String> params, HttpHeaders headers) {
		List<EmandateResponse> emandateResponses = new ArrayList<EmandateResponse>();
		
		List<String> mandateCallList = new ArrayList<String>();
		mandateCallList.add("PARENT_APPLICATION");
		mandateCallList.add("CHILD_APPLICATION");
		
		for (String mandateCallFor : mandateCallList) {
			try {
				List<EmandateResponse> appSpecificEmandateResponses = new ArrayList<EmandateResponse>();
				ResponseEntity<?> mandateResponseEntity = null;
				
				params.put("ifscCode", null);
				params.put("bankAccountNumber", null);
				
				if("CHILD_APPLICATION".equalsIgnoreCase(mandateCallFor)) {
					mandateResponseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, mandateGetURL,
							List.class, params, null, headers);
				} else {
					Map<String, String> paramsForParentCall = new HashMap<String, String>(params);
					paramsForParentCall.put("applicationid", params.get("applicationkey"));
					
					mandateResponseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, mandateGetURL,
							List.class, paramsForParentCall, null, headers);
				}

				appSpecificEmandateResponses = mapper.convertValue(mandateResponseEntity.getBody(),
						new TypeReference<List<EmandateResponse>>() {
						});
				
				emandateResponses.addAll(appSpecificEmandateResponses);

			} catch (CreditBusinessException e) {
				if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found. ");
				} else {
					throw e;
				}
			} catch (Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while Emandate Fetch ", e);
				throw e;
			}
		}
		
		return emandateResponses;
	}

	private BrePreferredBankResponse callMandateBre(Map<String, String> params,
			List<BankDetailsReponse> bankDetailsResponses, List<EmandateResponse> emandateResponses,
			HttpHeaders headers) {
		try {
			BrePreferredBankResponse brePreferredBankResponse = null;

			MandateBreRequest mandateBreRequest = createBreRequest(bankDetailsResponses, emandateResponses, params, headers);
			mandateBreRequest.setMandateBRECallType(1l);
			
			Gson gson = new Gson();
			String mandateBreRequestJson = gson.toJson(mandateBreRequest);
			
			ResponseEntity<?> mandateResponseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST,
					mandateBrePreferredBankURL, Object.class, params, mandateBreRequestJson, headers);

			brePreferredBankResponse = mapper.convertValue(mandateResponseEntity.getBody(), BrePreferredBankResponse.class);

			return brePreferredBankResponse;
		} catch (CreditBusinessException creditBusinessException) {
			throw creditBusinessException;
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception Occrred while calling mandate bre wrapper API", exception);
			throw exception;
		}
	}

	@Override
	public MandateBreRequest createBreRequest(List<BankDetailsReponse> bankDetailsResponses,
			List<EmandateResponse> emandateResponses, Map<String, String> params, HttpHeaders headers) {
		MandateBreRequest mandateBreRequest = new MandateBreRequest();
		List<BankDetailsBRE> bankDetailsBRE = new ArrayList<BankDetailsBRE>();
		List<MandateDetailsBRE> mandateDetailsBRE = new ArrayList<MandateDetailsBRE>();

		bankDetailsResponses.stream().forEach(bankDetailResponse -> {
			BankDetailsBRE bankDetailBre = new BankDetailsBRE();
			bankDetailBre.setAccountNo(bankDetailResponse.getAccoutNumber());
			bankDetailBre.setcName(bankDetailResponse.getHolderName());
			bankDetailBre.setMandatereference(bankDetailResponse.getFinalMandateKey());
			bankDetailBre.setSourceName(bankDetailResponse.getSource());
			
			if (!StringUtils.isEmpty(bankDetailResponse.getBranchKey())) {
				JSONObject branchDetail = getBranchDetails(bankDetailResponse.getBranchKey(), params, headers);
				if(null != branchDetail) {
					bankDetailBre.setBankBranchName(null != branchDetail.get("branchName") ? branchDetail.get("branchName").toString() : null);
					bankDetailBre.setBankName(null != branchDetail.get("bankName") ? branchDetail.get("bankName").toString() : null);
					bankDetailBre.setIfscCode(null != branchDetail.get("branchIfscCode") ? branchDetail.get("branchIfscCode").toString() : null);
					bankDetailBre.setMicrCode(null != branchDetail.get("branchMicrCode") ? branchDetail.get("branchMicrCode").toString() : null);
				} else {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "branchDetail is null");
				}
			} else if (!StringUtils.isEmpty(bankDetailResponse.getBankMasterKey())) {
				JSONObject bankMasterDetail = getBranchDetailsFromBankMasterKey(bankDetailResponse.getBankMasterKey(), params, headers);
				if(null != bankMasterDetail) {
					bankDetailBre.setBankName(null != bankMasterDetail.get("bankName") ? bankMasterDetail.get("bankName").toString() : null);
				} else {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "bankMasterDetail is null");
				}
			}
			
			bankDetailsBRE.add(bankDetailBre);
		});
		
		if(null != emandateResponses && !CollectionUtils.isEmpty(emandateResponses)) {
			emandateResponses.stream().forEach(emandateResponse -> {
				MandateDetailsBRE mandateDetailBre = new MandateDetailsBRE();
				DestinationBankInfo bankInfo = emandateResponse.getDestinationBankInfo();
				if(null != bankInfo) {
					mandateDetailBre.setAccountNo(bankInfo.getAccountNumber());
					mandateDetailBre.setBankName(bankInfo.getBankName());
					mandateDetailBre.setIfscCode(bankInfo.getIfscCode());
				}
				mandateDetailBre.setBalanceLimit(null != emandateResponse.getAvailableLimit() ? emandateResponse.getAvailableLimit().longValue() : null);
				mandateDetailBre.setMaxLimit(null != emandateResponse.getLimit() ? emandateResponse.getLimit().longValue() : null);
				mandateDetailBre.setBankBranchName(null);  //TODO where to get?
				mandateDetailBre.setChannelMandateReferenceId(emandateResponse.getChanelMandateRefId());
				mandateDetailBre.setChannelType(emandateResponse.getChannel());
				mandateDetailBre.setcName(null != emandateResponse.getUserInfo() ? emandateResponse.getUserInfo().getName() : null);
				mandateDetailBre.setMandateCreatedsourceName(emandateResponse.getMandateCreationSource());
				mandateDetailBre.setMandateExpiryDate(emandateResponse.getMandateExpiryDate());
				mandateDetailBre.setMandatereference(emandateResponse.getMandateReference());
				mandateDetailBre.setMandateRegistrationNumber(emandateResponse.getUmrn());
				mandateDetailBre.setMicrCode(emandateResponse.getMicrCode());
				mandateDetailBre.setSourceName(emandateResponse.getMandateCreationSource());
				
				mandateDetailsBRE.add(mandateDetailBre);
			});
		}
		
		mandateBreRequest.setApplicationId(Long.valueOf(params.get("applicationid")));
		mandateBreRequest.setBankDetails(bankDetailsBRE);
		mandateBreRequest.setMandateDetails(mandateDetailsBRE);
		mandateBreRequest.setSource(JOURNEY);
		
		return mandateBreRequest;
	}

	private JSONObject getBranchDetails(String branchKey, Map<String, String> params, HttpHeaders headers) {
		JSONObject branchDetail = null;
		try {
			params.put("branchKey", branchKey);
			ResponseEntity<?> branchDetailsResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					branchGetBranchKeyURL, Object.class, params, null, headers);

			ArrayList<?> branchDetails = (ArrayList<?>) branchDetailsResponse.getBody();
			branchDetail = CreditBusinessHelper.getJSONObject(branchDetails.get(0));
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found. ");
				return null;
			}
			throw e;
		}
		
		return branchDetail;
	}
	
	private JSONObject getBranchDetailsFromIfscCode(String ifscCode, Map<String, String> params, HttpHeaders headers) {
		JSONObject branchDetail = null;
		try {
			params.put("ifscCode", ifscCode);

			ResponseEntity<?> branchDetailsResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					branchGetURL, Object.class, params, null, headers);
			
			ArrayList<?> branchDetails = (ArrayList<?>) branchDetailsResponse.getBody();
			
			branchDetail = CreditBusinessHelper.getJSONObject(branchDetails.get(0));
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found. ");
				return null;
			}
			throw e;
		}
		
		return branchDetail;
	}
	
	public JSONObject getBranchDetailsFromBankName(String bankName, Map<String, String> params, HttpHeaders headers) {
		JSONObject bankMasterDetail = null;
		try {
			params.put("bankName", bankName);

			ResponseEntity<?> branchDetailsResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					bankMasterGetBankNameURL, Object.class, params, null, headers);
			
			ArrayList<?> bankMasterDetails = (ArrayList<?>) branchDetailsResponse.getBody();
			
			bankMasterDetail = CreditBusinessHelper.getJSONObject(bankMasterDetails.get(0));
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found. ");
				return null;
			}
			throw e;
		}
		
		return bankMasterDetail;
	}
	
	public JSONObject getBranchDetailsFromBankMasterKey(String bankMasterKey, Map<String, String> params, HttpHeaders headers) {
		JSONObject bankMasterDetail = null;
		try {
			params.put("bankMasterKey", bankMasterKey);

			ResponseEntity<?> branchDetailsResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					bankMasterGetBankMasterKeyURL, Object.class, params, null, headers);
			
			ArrayList<?> bankMasterDetails = (ArrayList<?>) branchDetailsResponse.getBody();
			
			bankMasterDetail = CreditBusinessHelper.getJSONObject(bankMasterDetails.get(0));
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found. ");
				return null;
			}
			throw e;
		}
		
		return bankMasterDetail;
	}
	
	private void getChildApplicationAndSetRequestParams(String applicationId, Map<String, String> params, HttpHeaders headers) {
		try {
			params.put("applicationkey", applicationId.toString());
			params.put("isInProcessing", "true");
			
			ResponseEntity<?> applicationResponseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, 
					childApplicationGetURL, Object.class, params, null, headers);

			ArrayList<Object> applicationResponseList = null != applicationResponseEntity.getBody() ? 
					(ArrayList<Object>) applicationResponseEntity.getBody() : null;
					
			if(!CollectionUtils.isEmpty(applicationResponseList) && applicationResponseList.size() == 1) {
				JSONObject applicationResponse = CreditBusinessHelper.getJSONObject(applicationResponseList.get(0));
				
				params.put("principalKey", String.valueOf(((Double) applicationResponse.get("principalKey")).intValue()));
				params.put("l3ProductKey", String.valueOf(((Double) applicationResponse.get("l3ProductKey")).intValue()));
				params.put("applicantid", 
						null != applicationResponse.get("applicantKey") ? applicationResponse.get("applicantKey").toString()
								: null);
				
				params.put("applicationid", applicationResponse.get("applicationKey").toString());
				
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Either child application is null or non unique for the application: " + applicationId);
				throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("CBS-404", "No unique child application found for the application"));
			}

		} catch (CreditBusinessException creditBusinessException) {
			throw creditBusinessException;
		}
	}
	
}
