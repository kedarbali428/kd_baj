package com.bajaj.markets.credit.business.controller;

import javax.validation.constraints.Digits;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.service.CreditBusinessIncomeVerificationService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessIncomeVerificationController {

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private CreditBusinessIncomeVerificationService creditBusinessIncomeVeriService;

	private static final String THIS_CLASS = CreditBusinessIncomeVerificationController.class.getCanonicalName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "Business Orchestration for Income Verification and Salary Identification", notes = "Business Orchestration for Income Verification and Salary Identification", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Successfully completed Income Verification", response = ApplicationResponse.class),
			@ApiResponse(code = 400, message = "Invalid request"),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorize", response = ErrorBean.class) })
	@PostMapping(value = "/v1/credit/application/{applicationid}/verification/income")
	@CrossOrigin
	public ResponseEntity<?> completeIncomeVerification(
			@PathVariable(name = "applicationid") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
				"Inside completeIncomeVerification with applicationId: " + applicationId);

		ApplicationResponse incomeVerificationResponse = creditBusinessIncomeVeriService
				.completeIncomeVerification(applicationId, headers);

		logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Inside completeIncomeVerification - end");
		return new ResponseEntity<ApplicationResponse>(incomeVerificationResponse, HttpStatus.CREATED);
	}

}
