package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class TokenResponse {

	private List<Tokens> tokens;

	public List<Tokens> getTokens() {
		return tokens;
	}

	public void setTokens(List<Tokens> tokens) {
		this.tokens = tokens;
	}
}
