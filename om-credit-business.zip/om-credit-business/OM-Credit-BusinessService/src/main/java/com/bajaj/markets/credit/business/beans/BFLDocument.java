package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;

public class BFLDocument implements Comparable<BFLDocument> {

	private String name;
	private String url;
	private String urlKey;
	private String docId;
	private String type;
	private String category;
	private String typeDesc;
	private String contentType;
	private String submitStatus;
	private String legalDeskDocId;
	private String downloadable;
	private String verificationStatus;
	private int esignSequence;
	private boolean originalCopyFlag;
	private String docCategoryCode;
	private String docCategoryDesc;
	private String docName;
	private BigDecimal custDoc;
	private String documentFor;
	private String submitDate;

	public String getSubmitDate() {
		return submitDate;
	}

	public void setSubmitDate(String submitDate) {
		this.submitDate = submitDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypeDesc() {
		return typeDesc;
	}

	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getSubmitStatus() {
		return submitStatus;
	}

	public void setSubmitStatus(String submitStatus) {
		this.submitStatus = submitStatus;
	}

	public String getLegalDeskDocId() {
		return legalDeskDocId;
	}

	public void setLegalDeskDocId(String legalDeskDocId) {
		this.legalDeskDocId = legalDeskDocId;
	}

	public String getDownloadable() {
		return downloadable;
	}

	public void setDownloadable(String downloadable) {
		this.downloadable = downloadable;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	/**
	 * @return the urlKey
	 */
	public String getUrlKey() {
		return urlKey;
	}

	/**
	 * @param urlKey
	 *            the urlKey to set
	 */
	public void setUrlKey(String urlKey) {
		this.urlKey = urlKey;
	}

	/**
	 * @return the esignSequence
	 */
	public int getEsignSequence() {
		return esignSequence;
	}

	/**
	 * @param esignSequence
	 *            the esignSequence to set
	 */
	public void setEsignSequence(int esignSequence) {
		this.esignSequence = esignSequence;
	}

	/**
	 * @return the originalCopyFlag
	 */
	public boolean isOriginalCopyFlag() {
		return originalCopyFlag;
	}

	/**
	 * @param originalCopyFlag
	 *            the originalCopyFlag to set
	 */
	public void setOriginalCopyFlag(boolean originalCopyFlag) {
		this.originalCopyFlag = originalCopyFlag;
	}

	public String getDocCategoryCode() {
		return docCategoryCode;
	}

	public void setDocCategoryCode(String docCategoryCode) {
		this.docCategoryCode = docCategoryCode;
	}

	public String getDocCategoryDesc() {
		return docCategoryDesc;
	}

	public void setDocCategoryDesc(String docCategoryDesc) {
		this.docCategoryDesc = docCategoryDesc;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public BigDecimal getCustDoc() {
		return custDoc;
	}

	public void setCustDoc(BigDecimal custDoc) {
		this.custDoc = custDoc;
	}

	public String getDocumentFor() {
		return documentFor;
	}

	public void setDocumentFor(String documentFor) {
		this.documentFor = documentFor;
	}

	@Override
	public int compareTo(BFLDocument doc) {
		int getEsignSequence = doc.getEsignSequence();
		// ascending order
		return this.esignSequence - getEsignSequence;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + esignSequence;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BFLDocument other = (BFLDocument) obj;
		if (esignSequence != other.esignSequence)
			return false;
		return true;
	}
}
