package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMPLOYER_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.IS_ESIGN_REQUIRED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AppEsignInfoBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;

@Component
public class EsignDetails {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	private CreditBusinessApiCallsHelper creditBusinessApiCallsHelper;
	
	@Value("${api.omcreditapplicationservice.updateemail.put.url}")
	private String updateEmailUrl;
	
	@Value("${api.omcreditapplicationservice.loan.pricing.get.url}")
	private String appLoanPricingUrl;
	
	@Value("${api.omcreditesignservice.fetchall.esign.GET.url}")
	private String fetchAllEsignsUrl;
	
	@Value("${api.omcreditesignservice.esign.PUT.url}")
	private String updateEsignUrl;

	public static final String CLASS_NAME = EsignDetails.class.getCanonicalName();
	
	private static final int SELF_EMPLOYED_OCCUPATION_KEY = 2;
	
	private static final int SALR_OCCUPATION_KEY = 1;

	public void fetchEsignDetails(DelegateExecution execution) {
		JSONObject esignDetails = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (esignDetails != null) {
			execution.setVariable(CreditBusinessConstants.STATUS, esignDetails.get(CreditBusinessConstants.STATUS));
		}

	}

	public void preEsignDetails(DelegateExecution execution) {

		JSONObject esignDetails = new JSONObject();

		esignDetails.put("isForced", true);
		esignDetails.put("generateBitly", false);
		esignDetails.put("generateDocument", true);
		execution.setVariable(PAYLOAD, esignDetails);
	}

	public void postEsignStage(DelegateExecution execution, boolean esignJourneyNext) {
		execution.setVariable("esignJourneyNext", esignJourneyNext);
	}
	
	public void checkPersonalEmailUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "checkPersonalEmailUpdate: start");
		JSONObject esignDetails = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		execution.setVariable("emailUpdateRequired", false);
		if (null != esignDetails.get("personalEmail")) {
			execution.setVariable("emailUpdateRequired", true);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "checkPersonalEmailUpdate: end");
	}
	
	public void prePersonalEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start prePersonalEmail");
		JSONObject esignDetails = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject updateProfile = new JSONObject();
		String personalEmail = esignDetails.get("personalEmail").toString();
		updateProfile.put("email", personalEmail);
		updateProfile.put("typeKey", EmailTypeEnum.PERON1.getValue());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, updateProfile);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End prePersonalEmail");
	}
	
	public void isEsignRequired(DelegateExecution execution) {
		JSONObject occupationObject = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		JSONObject occupationType = CreditBusinessHelper.getJSONObject(occupationObject.get("ocupationType"));
		
		Object occupationKeyObj = occupationType.get("key");
		boolean esignRequired = true;
		if(null != occupationKeyObj) {
			int occupationKey = ((Double) occupationKeyObj).intValue();
			if (SELF_EMPLOYED_OCCUPATION_KEY == occupationKey) {
				esignRequired = false;
			} 
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "occupationKey is null!");
		}
		execution.setVariable(IS_ESIGN_REQUIRED, esignRequired);
	}
		
	public void isUnderWriterCheckRequired(DelegateExecution execution) {
		Long employerId = null;
		JSONObject occupationObject = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		JSONObject occupationType = CreditBusinessHelper.getJSONObject(occupationObject.get("ocupationType"));
		JSONObject salariedDetail = CreditBusinessHelper.getJSONObject(occupationObject.get("salariedDetail"));
		
		Object occupationKeyObj = occupationType.get("key");
		boolean underWriterRequired = false;
		if (null != occupationKeyObj) {
			int occupationKey = ((Double) occupationKeyObj).intValue();
			if (SALR_OCCUPATION_KEY == occupationKey) {
				underWriterRequired = true;
				JSONObject employerName = CreditBusinessHelper.getJSONObject(salariedDetail.get("employerName"));
				if (null != employerName.get("key")) {
					employerId = ((Double) employerName.get("key")).longValue();
				}
			}
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "occupationKey is null!");
		}
		execution.setVariable(CreditBusinessConstants.UW_REQUIRED, underWriterRequired);
		execution.setVariable(EMPLOYER_ID, employerId);
	}

	@Async
	public void suspendEsignForRejectedEpPricing(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start- suspendEsignForRejectedEpPricing "
				+ execution.getVariable(CreditBusinessConstants.APPLICATIONKEY));
		try {
			if (isEpPricingRejected(execution)) {
				List<AppEsignInfoBean> appEsignInfoBean = getActiveEsigns(execution);
				for (AppEsignInfoBean appEsign : appEsignInfoBean) {
					if (null != appEsign.getIsactive() && 1 == appEsign.getIsactive()) {
						updateEsignInfo(execution, appEsign);
					}
				}
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
					"Exception Occured in suspendEsignForRejectedEpPricing Async call "
							+ execution.getVariable(CreditBusinessConstants.APPLICATIONKEY),e);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End- suspendEsignForHonouredEpPricing "
				+ execution.getVariable(CreditBusinessConstants.APPLICATIONKEY));
	}

	private boolean isEpPricingRejected(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start- checkIfEpPricingRejected " + execution.getVariable(CreditBusinessConstants.APPLICATIONKEY));
		Map<String, String> params = new HashMap<>();
		params.put(CreditBusinessConstants.APPLICATIONKEY,(String) execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));

		List<?> appLoanPricingList = (List<?>) creditBusinessApiCallsHelper.callApi(appLoanPricingUrl, HttpMethod.GET, params, null,
				Object.class);

		boolean isEpPricingRejected = false;
		if (!CollectionUtils.isEmpty(appLoanPricingList)) {
			Optional<?> epPricing = appLoanPricingList.stream().filter(i -> {
				Map<String, Object> j = (Map<String, Object>) i;
				return (j.get("pricingStatus") != null && j.get("source") != null
						&& CreditBusinessConstants.EP.equalsIgnoreCase(j.get("source").toString())
						&& CreditBusinessConstants.REJECTED.equalsIgnoreCase(j.get("pricingStatus").toString()));
			}).findFirst();

			if (epPricing.isPresent()) {
				isEpPricingRejected = true;
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"End- checkIfEpPricingRejected isEpPricingRejected : " + isEpPricingRejected);
		return isEpPricingRejected;
	}

	private List<AppEsignInfoBean> getActiveEsigns(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start- getActiveEsigns " + execution.getVariable(CreditBusinessConstants.APPLICATIONKEY));
		List<AppEsignInfoBean> appEsignList = new ArrayList<>();
		Map<String, String> params = new HashMap<>();
		params.put(CreditBusinessConstants.APPLICATIONKEY,(String) execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		AppEsignInfoBean[] appEsignInfoBeanArray = creditBusinessApiCallsHelper.callApi(fetchAllEsignsUrl, HttpMethod.GET, params,
				null, AppEsignInfoBean[].class);
		if (null != appEsignInfoBeanArray) {
			appEsignList = Arrays.asList(appEsignInfoBeanArray);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End- getActiveEsigns with" + appEsignList);
		return appEsignList;
	}

	private AppEsignInfoBean updateEsignInfo(DelegateExecution execution, AppEsignInfoBean appEsign) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start- updateEsignInfo " + execution.getVariable(CreditBusinessConstants.APPLICATIONKEY));

		appEsign.setStatus(CreditBusinessConstants.ESIGN_STATUS_SUSPENDED);
		appEsign.setSuspendReason(CreditBusinessConstants.RAISE_EXCEPTION);
		Map<String, String> params = new HashMap<>();
		params.put(CreditBusinessConstants.APPLICATIONKEY, (String) execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		params.put("esignKey", appEsign.getAppEsignInfokey().toString());
		appEsign = creditBusinessApiCallsHelper.callApi(updateEsignUrl, HttpMethod.PUT, params, CreditBusinessHelper.objectToJson(appEsign),
				AppEsignInfoBean.class);

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,"End- updateEsignInfo with " + appEsign.toString());
		return appEsign;
	}
}
