package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.CibilReference;
import com.bajaj.markets.credit.business.beans.CibilRequest;
import com.bajaj.markets.credit.business.beans.CibilResponseWrapper;

public interface CreditBusinessCibilOtpService {

	public CibilReference getCibilReference(Long applicationId);

	public CibilResponseWrapper authenticateCibil(Long applicationId, Long cibilReferenceKey, CibilRequest cibilRequest, HttpHeaders headers);
}
