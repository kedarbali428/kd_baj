package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class ProspectOfferDetails {

	private List<ProspectDetails> prospectDetails;

	public List<ProspectDetails> getProspectDetails() {
		return prospectDetails;
	}

	public void setProspectDetails(List<ProspectDetails> prospectDetails) {
		this.prospectDetails = prospectDetails;
	}

	

}
