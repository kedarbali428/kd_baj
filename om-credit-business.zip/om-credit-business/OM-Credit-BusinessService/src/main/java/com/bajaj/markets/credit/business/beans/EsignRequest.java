package com.bajaj.markets.credit.business.beans;

public class EsignRequest {
	
	private boolean isForced;
	private boolean generateBitly;
	private boolean generateDocument;
	private EsignValidation esignValidation;
	public boolean getIsForced() {
		return isForced;
	}
	public void setIsForced(boolean isForced) {
		this.isForced = isForced;
	}
	public boolean isGenerateBitly() {
		return generateBitly;
	}
	public void setGenerateBitly(boolean generateBitly) {
		this.generateBitly = generateBitly;
	}
	public boolean isGenerateDocument() {
		return generateDocument;
	}
	public void setGenerateDocument(boolean generateDocument) {
		this.generateDocument = generateDocument;
	}
	public EsignValidation getEsignValidation() {
		return esignValidation;
	}
	public void setEsignValidation(EsignValidation esignValidation) {
		this.esignValidation = esignValidation;
	}
	@Override
	public String toString() {
		return "EsignRequest [isForced=" + isForced + ", generateBitly=" + generateBitly + ", generateDocument="
				+ generateDocument + ", esignValidation=" + esignValidation + "]";
	}
	
	
}
