package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.ApplicationResponse;

public interface CreditBusinessIncomeVerificationService {
	
	public ApplicationResponse completeIncomeVerification(Long applicationId, HttpHeaders headers);
	
}
