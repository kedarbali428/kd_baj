package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class RelationReference implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7392294835464817873L;
	
	private Reference salutation;
	private Reference relation;
	private String fullName;

	public Reference getSalutation() {
		return salutation;
	}

	public void setSalutation(Reference salutation) {
		this.salutation = salutation;
	}

	public Reference getRelation() {
		return relation;
	}

	public void setRelation(Reference relation) {
		this.relation = relation;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

}
