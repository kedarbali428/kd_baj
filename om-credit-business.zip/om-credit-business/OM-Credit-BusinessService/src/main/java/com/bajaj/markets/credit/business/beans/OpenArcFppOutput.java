package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.FppSelected;

public class OpenArcFppOutput implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2082688827244326645L;
	@NotBlank(groups = FppSelected.class, message = "planCode can not be null or empty")
	private String planCode;
	private String planName;
	private String planFriendlyName;
	private String planType;
	private Double withFppSaveRoi;
	private Double withFppRoi;
	private Double withoutFppRoi;
	private Double withFppSavingAmount;
	private Double floorPriceWithGST;
	private Double actualFppPriceWithGST;
	private Double oldProfit;
	private Double fppCostPrice;

	@Valid
	@NotEmpty(groups = FppSelected.class, message = "products can not be null or empty")
	private List<BundleProduct> products;

	public void setWithFppSaveRoi(Double withFppSaveRoi) {
		this.withFppSaveRoi = withFppSaveRoi;
	}

	public void setWithFppRoi(Double withFppRoi) {
		this.withFppRoi = withFppRoi;
	}

	public void setWithFppSavingAmount(Double withFppSavingAmount) {
		this.withFppSavingAmount = withFppSavingAmount;
	}

	public void setFloorPriceWithGST(Double floorPriceWithGST) {
		this.floorPriceWithGST = floorPriceWithGST;
	}

	public void setActualFppPriceWithGST(Double actualFppPriceWithGST) {
		this.actualFppPriceWithGST = actualFppPriceWithGST;
	}

	public void setOldProfit(Double oldProfit) {
		this.oldProfit = oldProfit;
	}

	public void setFppCostPrice(Double fppCostPrice) {
		this.fppCostPrice = fppCostPrice;
	}

	public void setProducts(List<BundleProduct> products) {
		this.products = products;
	}

	public Double getWithFppSaveRoi() {
		return withFppSaveRoi;
	}

	public Double getWithFppRoi() {
		return withFppRoi;
	}

	public Double getWithFppSavingAmount() {
		return withFppSavingAmount;
	}

	public Double getFloorPriceWithGST() {
		return floorPriceWithGST;
	}

	public Double getActualFppPriceWithGST() {
		return actualFppPriceWithGST;
	}

	public Double getOldProfit() {
		return oldProfit;
	}

	public Double getFppCostPrice() {
		return fppCostPrice;
	}

	public List<BundleProduct> getProducts() {
		return products;
	}

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public String getPlanName() {
		return planName;
	}

	public String getPlanFriendlyName() {
		return planFriendlyName;
	}

	public String getPlanType() {
		return planType;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public void setPlanFriendlyName(String planFriendlyName) {
		this.planFriendlyName = planFriendlyName;
	}

	public void setPlanType(String planType) {
		this.planType = planType;
	}

	public Double getWithoutFppRoi() {
		return withoutFppRoi;
	}

	public void setWithoutFppRoi(Double withoutFppRoi) {
		this.withoutFppRoi = withoutFppRoi;
	}

	@Override
	public String toString() {
		return "OpenArcFppOutput [planCode=" + planCode + ", planName=" + planName + ", planFriendlyName=" + planFriendlyName + ", planType=" + planType
				+ ", withFppSaveRoi=" + withFppSaveRoi + ", withFppRoi=" + withFppRoi + ", withoutFppRoi=" + withoutFppRoi + ", withFppSavingAmount="
				+ withFppSavingAmount + ", floorPriceWithGST=" + floorPriceWithGST + ", actualFppPriceWithGST=" + actualFppPriceWithGST + ", oldProfit="
				+ oldProfit + ", fppCostPrice=" + fppCostPrice + ", products=" + products + "]";
	}

	 

}
