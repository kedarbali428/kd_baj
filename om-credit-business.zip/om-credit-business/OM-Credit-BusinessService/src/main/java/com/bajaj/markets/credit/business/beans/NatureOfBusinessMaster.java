package com.bajaj.markets.credit.business.beans;

public class NatureOfBusinessMaster {


	private Long natureOfBusinessKey;

	private String natureOfBusinessCode;
	
	private String natureOfBusinessValue;

	private Integer isactive;

	public Long getNatureOfBusinessKey() {
		return natureOfBusinessKey;
	}

	public void setNatureOfBusinessKey(Long natureOfBusinessKey) {
		this.natureOfBusinessKey = natureOfBusinessKey;
	}

	public String getNatureOfBusinessCode() {
		return natureOfBusinessCode;
	}

	public void setNatureOfBusinessCode(String natureOfBusinessCode) {
		this.natureOfBusinessCode = natureOfBusinessCode;
	}

	public String getNatureOfBusinessValue() {
		return natureOfBusinessValue;
	}

	public void setNatureOfBusinessValue(String natureOfBusinessValue) {
		this.natureOfBusinessValue = natureOfBusinessValue;
	}

	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}

}
