package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMPLOYER_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMPLOYER_NAME_OTHER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.KARZA_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SALARIED_OTHR_EMPLOYER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.WORKEMAILID;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.EmploymentVerification;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.referencedataclientlib.bean.OccupationMaster;

@Component
public class Karza {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	@Autowired
	MasterDataRedisClientHelper masterDataRedisHelper;

	private static final String CLASS_NAME = Karza.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void preApi(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preApi");
		JSONObject karzaRequest = new JSONObject();
		karzaRequest.put(CreditBusinessConstants.APPLICANTKEY, execution.getVariable(CreditBusinessConstants.APPLICANTID));
		karzaRequest.put(CreditBusinessConstants.APPLICATIONKEY, execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		karzaRequest.put(CreditBusinessConstants.EMPLOYER_KID, execution.getVariable(CreditBusinessConstants.EMPLOYER_KID));
		karzaRequest.put(CreditBusinessConstants.EMPLOYER_NAME, execution.getVariable(CreditBusinessConstants.EMPLOYER_NAME));
		karzaRequest.put(CreditBusinessConstants.L2_PRODUCT_CODE, execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE));
		karzaRequest.put(CreditBusinessConstants.L2_PRODUCT_KEY, execution.getVariable(CreditBusinessConstants.L2_PRODUCT_KEY));
		karzaRequest.put(CreditBusinessConstants.MOBILE, execution.getVariable(CreditBusinessConstants.MOBILE));
		
		JSONObject name = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.NAME));
		if(name != null) {
			String firstName = (String)name.get("firstName");
			String middleName = null != name.get("middleName") ? (String)name.get("middleName") : null;
			String lastName = (String)name.get("lastName");
			String fullName = "";
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "firstName = "+firstName+"--- middleName = "+middleName+" --- lastName = "+lastName);
			if(null != middleName) {
				fullName = firstName + " " + middleName + " " + lastName;
			} else {
				fullName = firstName + " " + lastName;
			}
			karzaRequest.put("fulName", fullName);
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, karzaRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preApi");
	}

	private String getOccupationDesc(DelegateExecution execution) {
		Integer occupationTypeKey = (Integer) execution.getVariable(CreditBusinessConstants.OCCUPATION_TYPE_KEY);
		OccupationMaster occupationMaster =  masterDataRedisHelper.getOccupationByKey(occupationTypeKey.longValue());
		if (occupationMaster != null) {
			return occupationMaster.getOccupationValue();
			
		}
		return null;
	}

	public void postGetVerification(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetVerificaiton");
		execution.setVariable(CreditBusinessConstants.KARZA_VERIFICATION_RESPONSE, null);
		ArrayList<?> responseArr = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		if (!CollectionUtils.isEmpty(responseArr)) {
			JSONObject output = CreditBusinessHelper.getJSONObject(responseArr.get(0));
			execution.setVariable(CreditBusinessConstants.KARZA_VERIFICATION_RESPONSE, output);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetVerificaiton");
	}

	public void preEmploymentVerificationBre(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start preEmploymentVerificationBre for karzaType ==>  " + execution.getVariable(KARZA_TYPE));
		EmploymentVerification karzaInputParameter = new EmploymentVerification();
		karzaInputParameter.setKarzaType(execution.getVariable(KARZA_TYPE).toString());
		String occDesc = getOccupationDesc(execution);
		karzaInputParameter.setOccupationType(occDesc);
		karzaInputParameter.setCompanyType(execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY) != null
				? execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY).toString()
				: null);
		karzaInputParameter.setCompanyCatogery(execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY) != null
				? execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY).toString()
				: null);
		karzaInputParameter.setCreditVidyaStatus(execution.getVariable(CreditBusinessConstants.CVVALIDATIONSTATUS) != null
				? execution.getVariable(CreditBusinessConstants.CVVALIDATIONSTATUS).toString()
				: null);

		karzaInputParameter.setBranch(null);
		karzaInputParameter.setOfficialEmailDomain(null);

		JSONObject verification = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.KARZA_VERIFICATION_RESPONSE));
		if (verification != null) {
			karzaInputParameter
					.setEmplrScore(verification.get("employerScore") != null ? Double.valueOf(verification.get("employerScore").toString()).longValue() : null);
			karzaInputParameter.setKarzaApproach(verification.get("karzaApproach") != null ? verification.get("karzaApproach").toString() : null);
			karzaInputParameter.setKarzaId(verification.get("employerKid") != null ? verification.get("employerKid").toString() : null);
			karzaInputParameter
					.setNameConfidence(verification.get("nameConfidence") != null ? Double.valueOf(verification.get("nameConfidence").toString()) : null);
			karzaInputParameter.setNameExactFlag(getBooleanValueFromInt(verification.get("nameExactFlag")));
			karzaInputParameter.setRecentFlag(getBooleanValueFromInt(verification.get("recentFlag")));
			karzaInputParameter.setSettledFlag(getBooleanValueFromInt(verification.get("settledFlag")));
			karzaInputParameter.setUniqueFlag(getBooleanValueFromInt(verification.get("uniqueFlag")));
			karzaInputParameter.setStatus(verification.get("status") != null ? Double.valueOf(verification.get("status").toString()).longValue() : null);
		}

		execution.setVariable(CreditBusinessConstants.PAYLOAD, karzaInputParameter);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preEmploymentVerificationBre");
	}

	public void postEmploymentVerificationBre(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postEmploymentVerificationBre");
		execution.setVariable(CreditBusinessConstants.KARZA_CHILD_REJECTED, false);
		JSONObject output = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (output != null && output.get("karzaBreResponse") != null) {
			JSONObject karzaResponse = CreditBusinessHelper.getJSONObject(output.get("karzaBreResponse"));
			if (karzaResponse.get("karzaVerificationOutput") != null) {
				JSONObject karzaVerificationOutput = CreditBusinessHelper.getJSONObject(karzaResponse.get("karzaVerificationOutput"));
				if (karzaVerificationOutput.get("rejectCode") != null) {
					ArrayList<?> responseArr = (ArrayList<?>) karzaVerificationOutput.get("rejectCode");
					if (!responseArr.isEmpty()) {
						execution.setVariable(CreditBusinessConstants.KARZA_CHILD_REJECTED, true);
					}
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postEmploymentVerificationBre");
	}

	public void preGetCreditVidyaDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preGetCreditVidyaDetails");
		execution.setVariable("cvApplicantId", null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preGetCreditVidyaDetails");
	}

	public void postGetCreditVidyaDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetCreditVidyaDetails");
		execution.setVariable(CreditBusinessConstants.CVVALIDATIONSTATUS, null);
		JSONObject output = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (output != null) {
			execution.setVariable(CreditBusinessConstants.CVVALIDATIONSTATUS, output.get("validationstatus"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetCreditVidyaDetails");
	}

	public void setDefaultFlags(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start setDefaultFlags");
		execution.setVariable(CreditBusinessConstants.KARZA_CHILD_REJECTED, false);
		if (execution.getVariable(CreditBusinessConstants.IS_DUMMY_EMAIL) == null) {
			execution.setVariable(CreditBusinessConstants.IS_DUMMY_EMAIL,false);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End setDefaultFlags");
	}

	private Boolean getBooleanValueFromInt(Object value) {
		if (value != null) {
			if ("1".equals(value.toString())) {
				return true;
			} else if ("0".equals(value.toString())) {
				return false;
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public void preCreditVidya(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCreditVidya");
		JSONObject creditVidyaRequest = new JSONObject();
		JSONObject userProfile = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.USERPROFILEOUTPUT));
		if (null != userProfile) {
			creditVidyaRequest.put(CreditBusinessConstants.DOB,
					null != userProfile.get(CreditBusinessConstants.DATE_OF_BIRTH) ? userProfile.get(CreditBusinessConstants.DATE_OF_BIRTH).toString() : null);
			creditVidyaRequest.put(CreditBusinessConstants.MOBILE_NUMBER,
					null != userProfile.get(CreditBusinessConstants.MOBILE) ? userProfile.get(CreditBusinessConstants.MOBILE).toString() : null);
			if (null != userProfile.get(CreditBusinessConstants.NAME)) {
				JSONObject name = CreditBusinessHelper.getJSONObject(userProfile.get(CreditBusinessConstants.NAME));
				String firstName = null != name.get(CreditBusinessConstants.FIRST_NAME) ? name.get(CreditBusinessConstants.FIRST_NAME).toString() : null;
				String middleName = null != name.get(CreditBusinessConstants.MIDDLE_NAME) ? name.get(CreditBusinessConstants.MIDDLE_NAME).toString() : null;
				String lastName = null != name.get(CreditBusinessConstants.LAST_NAME) ? name.get(CreditBusinessConstants.LAST_NAME).toString() : null;
				String fullName = firstName + " " + middleName + " " + lastName;
				creditVidyaRequest.put(CreditBusinessConstants.FULLNAME, fullName);
			}
		}
		creditVidyaRequest.put(CreditBusinessConstants.APPLICANTKEY, null);
		creditVidyaRequest.put(CreditBusinessConstants.APPLICATIONKEY, execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
		creditVidyaRequest.put(CreditBusinessConstants.EMAILID, execution.getVariable(CreditBusinessConstants.WORKEMAILID));
		creditVidyaRequest.put(CreditBusinessConstants.L2PRODUCTKEY, execution.getVariable(CreditBusinessConstants.L2_PRODUCT_KEY));
		creditVidyaRequest.put(CreditBusinessConstants.SALARY, execution.getVariable(CreditBusinessConstants.NETSALARY));

		if (execution.getVariable(SALARIED_OTHR_EMPLOYER) != null && (boolean) execution.getVariable(SALARIED_OTHR_EMPLOYER)) {
			creditVidyaRequest.put(CreditBusinessConstants.COMPANY_NAME, execution.getVariable(EMPLOYER_NAME_OTHER));
		} else {
			creditVidyaRequest.put(CreditBusinessConstants.COMPANY_NAME, execution.getVariable(EMPLOYER_NAME));
		}

		Map<String, String> childParams = new HashMap<>();
		childParams.put("applicationid", execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY).toString());
		childParams.put("userattributekey", execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
		// fetch current address
		childParams.put("typeKey", AddressTypeEnum.CURRENT.getValue());
		Address currentAddress = apiCallsHelper.getAddress(null, childParams);
		if (currentAddress != null) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Setting city to CreditVidya request = "+currentAddress.getCityName());
			creditVidyaRequest.put(CreditBusinessConstants.CITY, currentAddress.getCityName());
		}

		execution.setVariable(CreditBusinessConstants.PAYLOAD, creditVidyaRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preCreditVidya");
	}

	public void postCreditVidya(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postCreditVidya");
		execution.setVariable(CreditBusinessConstants.CREDITVIDYARESPONSE,
				CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT)));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postCreditVidya");
	}

	@SuppressWarnings("unchecked")
	public void preEmailVerificationUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preEmailVerificationUpdate");
		execution.setVariable(CreditBusinessConstants.CVVALIDATIONSTATUS, null);
		JSONObject updateEmailVerificationDetail = new JSONObject();
		JSONObject creditVidyaResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.CREDITVIDYARESPONSE));
		if (null != creditVidyaResponse) {
			JSONObject verification = CreditBusinessHelper.getJSONObject(creditVidyaResponse.get(CreditBusinessConstants.VERIFICATION));
			updateEmailVerificationDetail.put(CreditBusinessConstants.EMAIL, execution.getVariable(WORKEMAILID));
			updateEmailVerificationDetail.put(CreditBusinessConstants.TYPE_KEY, EmailTypeEnum.OFFICE.getValue());
			updateEmailVerificationDetail.put(CreditBusinessConstants.VERIFICATION, verification);
			execution.setVariable(CreditBusinessConstants.CVVALIDATIONSTATUS,
					null != creditVidyaResponse.get(CreditBusinessConstants.VALIDATIONSTATUS)
							? creditVidyaResponse.get(CreditBusinessConstants.VALIDATIONSTATUS).toString()
							: null);
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, updateEmailVerificationDetail);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preEmailVerificationUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void checkDomain(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preEmailVerificationUpdate");
		execution.setVariable(CreditBusinessConstants.IS_GENERIC_EMAIL_DOMAIN, false);
		JSONObject output = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (output != null && output.get("payload") != null) {
			JSONObject payload = CreditBusinessHelper.getJSONObject(output.get("payload"));
			if(payload.get("statusFlag") != null)
			execution.setVariable(CreditBusinessConstants.IS_GENERIC_EMAIL_DOMAIN, (boolean) payload.get("statusFlag"));
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preEmailVerificationUpdate");
	}

}
