package com.bajaj.markets.credit.business.beans;

import java.util.Map;

public class ApplicationParameter {

	private Map<String, String> applicationParameters;

	public Map<String, String> getApplicationParameters() {
		return applicationParameters;
	}

	public void setApplicationParameters(Map<String, String> applicationParameters) {
		this.applicationParameters = applicationParameters;
	}

	@Override
	public String toString() {
		return "ApplicationParameter [applicationParameters=" + applicationParameters + "]";
	}


}
