package com.bajaj.markets.credit.business.beans;

public class GstInfo {

	private boolean isValidated;

	public boolean isValidated() {
		return isValidated;
	}

	public void setValidated(boolean isValidated) {
		this.isValidated = isValidated;
	}

}
