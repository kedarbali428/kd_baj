package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class PrincipalRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String applicationId;
	private String mob;
	private String userAttributeKey;
	private String productCode;
	private String principalName;
	
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	
	public String getUserAttributeKey() {
		return userAttributeKey;
	}
	public void setUserAttributeKey(String userAttributeKey) {
		this.userAttributeKey = userAttributeKey;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getPrincipalName() {
		return principalName;
	}
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}
	@Override
	public String toString() {
		return "PrincipalRequest [applicationId=" + applicationId + ", mob=" + mob + ", userAttributeKey="
				+ userAttributeKey + ", productCode=" + productCode + ", principalName=" + principalName + "]";
	}
	
}