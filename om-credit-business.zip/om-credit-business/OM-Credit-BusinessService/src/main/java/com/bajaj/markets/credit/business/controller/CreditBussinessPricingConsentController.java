package com.bajaj.markets.credit.business.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.PricingConsentCaptureRequest;
import com.bajaj.markets.credit.business.beans.PricingConsentRequest;
import com.bajaj.markets.credit.business.beans.PricingConsentResponse;
import com.bajaj.markets.credit.business.service.CreditBusinessPricingConsentService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class CreditBussinessPricingConsentController {

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private CreditBusinessPricingConsentService employeePortalPricingConsentService;

	private static final String CLASS_NAME = CreditBussinessPricingConsentController.class.getCanonicalName();

	@Secured(value = { Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL, Role.CUSTOMER})
	@ApiOperation(value = "Sending pricing consent to users after pricing is revised from EP or Journey", notes = "Sending pricing consent to users after pricing is revised from EP or Journey", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "consent initiated", response = PricingConsentResponse.class),
			@ApiResponse(code = 412, message = "precondition failed", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@CrossOrigin
	@PostMapping(path = "/v1/credit/applications/{applicationid}/pricingconsent")
	public ResponseEntity<?> pricingConsent(@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationKey,
			@Valid @RequestBody PricingConsentRequest pricingConsentRequest, BindingResult bindindResult,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside pricingConsent method controller for applicationKey :" + applicationKey);
			PricingConsentResponse pricingConsentResponse = employeePortalPricingConsentService
					.pricingConsent(applicationKey.toString(), pricingConsentRequest, headers);
			return new ResponseEntity<>(pricingConsentResponse, HttpStatus.CREATED);

		
	}

	@Secured(value = {Role.SYSTEM, Role.EMPLOYEE, Role.VENDORPARTNER, Role.PRINCIPAL,Role.CUSTOMER})
	@ApiOperation(value = "Application consentCapture", notes = "Application consentCapture", httpMethod = "PUT")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "consent initiated", response = PricingConsentResponse.class),
			@ApiResponse(code = 412, message = "precondition failed", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@CrossOrigin
	@PutMapping(path = "/v1/credit/applications/{applicationid}/pricingconsent/{consentref}")
	public ResponseEntity<?> pricingconsentCapture(@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationKey,
			@PathVariable("consentref") String consentRef,
			@Valid @RequestBody PricingConsentCaptureRequest pricingConsentCaptureRequest, BindingResult bindindResult,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside pricingconsentCapture method controller for applicationKey :" + applicationKey);
		
			PricingConsentResponse pricingConsentResponse = employeePortalPricingConsentService
					.pricingconsentCapture(applicationKey, consentRef, pricingConsentCaptureRequest, headers);
			return new ResponseEntity<>(pricingConsentResponse, HttpStatus.OK);

	
			
	}
}
