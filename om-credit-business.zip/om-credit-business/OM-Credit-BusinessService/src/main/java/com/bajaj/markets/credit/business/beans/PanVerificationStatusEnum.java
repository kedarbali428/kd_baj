package com.bajaj.markets.credit.business.beans;

public enum PanVerificationStatusEnum {
	
	VERIFIED("verified"),
	NOT_VERIFIED("not_verified"),
	UNKNOWN("unknown");

	private final String value;
	
	private PanVerificationStatusEnum(String value) {
		this.value = value;
	}
	
	public String getStatusValue() {
		return this.value;
	}
}
