package com.bajaj.markets.credit.business.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.AdditionalDetailLoans;
import com.bajaj.markets.credit.business.beans.AdditionalPageInfo;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.PropertyAdditionalDetails;
import com.bajaj.markets.credit.business.service.CreditBusinsessPropertyAdditionalDetailService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessPropertyAdditionalDetailController {
	
	private static final String CLASS_NAME = CreditBusinessPropertyAdditionalDetailController.class.getCanonicalName();

	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private CreditBusinsessPropertyAdditionalDetailService propertyAdditionalDetailService;
	

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "Property Additional detail fetched successsfully", notes = "Property Additional detail fetched successsfully", httpMethod = "GET")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Additional detail fetched successsfully.", response = PropertyAdditionalDetails.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "/v1/credit/applications/secureloans/{applicationid}/property/additionaldetail", consumes = MediaType.APPLICATION_JSON_VALUE,
				produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<PropertyAdditionalDetails> getPropertyAdditionalDetail(
			@PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start getPropertyAdditionalDetail :" + applicationId);
		PropertyAdditionalDetails response = propertyAdditionalDetailService.getPropertyAdditionalDetails(applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End getPropertyAdditionalDetail:" + applicationId);
		return new ResponseEntity<PropertyAdditionalDetails>(response, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(	value = "This API will submit property data to the running process",
					notes = "This API will submit property data to the running process", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Property Details saved successfully", response = PropertyAdditionalDetails.class),
			@ApiResponse(code = 422, message = "Invalid input parameters", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@PostMapping(	path = "/v1/credit/applications/secureloans/{applicationid}/property/additionaldetail", consumes = MediaType.APPLICATION_JSON_VALUE,
					produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApplicationResponse> propertyAdditionalDetails(@PathVariable(value = "applicationid") String applicationId,
			@Valid @RequestBody PropertyAdditionalDetails propertyAdditionalDetailsRequest, BindingResult result, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Started post property details with Request : " + propertyAdditionalDetailsRequest);
		ApplicationResponse applicationResponse = propertyAdditionalDetailService.postPropertyDetails(applicationId, propertyAdditionalDetailsRequest, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End post summary method: ");
		return new ResponseEntity<>(applicationResponse, HttpStatus.CREATED);
	}
	
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "Additional page detail fetched successsfully", notes = "Additional page detail fetched successsfully", httpMethod = "GET")
	@ApiResponses(value = { 
			@ApiResponse(code = 200, message = "Additional page detail fetched successsfully.", response = AdditionalPageInfo.class), 
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class), 
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) 
	})
	@GetMapping(path = "/v1/credit/applications/secureloans/{applicationid}/additionaldetail", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<AdditionalPageInfo> getAdditionalPageInfo(@PathVariable(value = "applicationid", required = true) String applicationId, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Get Additional page details API started for applicaiton id :" + applicationId);
		AdditionalPageInfo additionalPageInfo = propertyAdditionalDetailService.getAdditionalPageInformation(applicationId, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Get Additional page details API completed for applicaiton id : " + applicationId + " with response: " + additionalPageInfo);
		return new ResponseEntity<AdditionalPageInfo>(additionalPageInfo, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(	value = "This API will submit property data to the running process",
					notes = "This API will submit property data to the running process", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Property Details saved successfully", response = PropertyAdditionalDetails.class),
			@ApiResponse(code = 422, message = "Invalid input parameters", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@PostMapping(	path = "/v1/credit/applications/secureloans/{applicationid}/additionaldetail", consumes = MediaType.APPLICATION_JSON_VALUE,
					produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApplicationResponse> additionalDetails(@PathVariable(value = "applicationid") String applicationId,
			@Valid @RequestBody AdditionalPageInfo additionalPageInfo, BindingResult result, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Started post additional details with Request : " + additionalPageInfo);
		ApplicationResponse applicationResponse = propertyAdditionalDetailService.postAdditionalDetails(applicationId, additionalPageInfo, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End post additional details method: ");
		return new ResponseEntity<>(applicationResponse, HttpStatus.CREATED);
	}
}
