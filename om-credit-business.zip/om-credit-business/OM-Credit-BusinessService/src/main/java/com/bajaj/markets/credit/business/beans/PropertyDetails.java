package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class PropertyDetails implements Serializable{

	private Boolean isPropertyIdentified;
	
	public Boolean getIsPropertyIdentified() {
		return isPropertyIdentified;
	}

	public void setIsPropertyIdentified(Boolean isPropertyIdentified) {
		this.isPropertyIdentified = isPropertyIdentified;
	}

	@Override
	public String toString() {
		return "PropertyDetails [isPropertyIdentified=" + isPropertyIdentified + "]";
	}

}
