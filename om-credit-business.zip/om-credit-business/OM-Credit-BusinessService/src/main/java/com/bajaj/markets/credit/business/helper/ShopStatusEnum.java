package com.bajaj.markets.credit.business.helper;

public enum ShopStatusEnum {
	OWNSHOP("OWNSHOP", "Owned Shop"), RENTEDSHOP("RENTEDSHOP", "Rented Shop"), NOSHOP("NOSHOP", "No Shop/Only Online");

	private String code;
	private String value;

	private ShopStatusEnum(String code, String value) {
		this.code = code;
		this.value = value;
	}

	public String getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}

	public static String getValueOfShopStatus(String shopCode) {
		for (ShopStatusEnum map : ShopStatusEnum.values()) {
			if (map.code.equals(shopCode)) {
				return map.value;
			}
		}
		return null;
	}

}
