/**
 * 
 */
package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class Esign implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String applicationid;
	private String action;
	private String personalEmail;

	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}

	public String getApplicationid() {
		return applicationid;
	}
	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}
	public String getPersonalEmail() {
		return personalEmail;
	}
	public void setPersonalEmail(String personalEmail) {
		this.personalEmail = personalEmail;
	}
	@Override
	public String toString() {
		return "Esign [applicationid=" + applicationid + ", action=" + action + ", personalEmail=" + personalEmail
				+ "]";
	}

}
