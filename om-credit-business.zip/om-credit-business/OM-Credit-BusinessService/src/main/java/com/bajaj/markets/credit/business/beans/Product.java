package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;
import java.util.List;

public class Product {
	private String description;
	private BigDecimal annualFee;
	private String feature;
	private String rewardPoint;
	private String promotionalOffer;
	private String approvalChances;
	private String cardTag;
	private BigDecimal isEligible;
	private Integer priorityOrder;
	private String productCode;
	private BigDecimal isSmallTicket;
	private String l3productCode;
	private String l4ProductCode;
	private String riskOfferType;
	private String productvariant;
	private BigDecimal roi;
	private BigDecimal emi;
	private BigDecimal bScore;
	private String loanTag;
	private String loanType;
	private List<Fees> fees;
	private Double totalFee;
	private Long productListingKey;
	private String isSelected;
	private String ctaName;
	private String toBeDisplayedOnListingPage;
	private List<String> usp;
	private BigDecimal requiredLoanAmount;
	private BigDecimal tenor;
	private BigDecimal eligibilityAmount;
	private Integer childStatus;
	private String honouredPricingSource;
	private String principalCode; 
	private Long principalKey;
	private Long netDisbursementAmount;

	public String getHonouredPricingSource() {
		return honouredPricingSource;
	}

	public void setHonouredPricingSource(String honouredPricingSource) {
		this.honouredPricingSource = honouredPricingSource;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getAnnualFee() {
		return annualFee;
	}

	public void setAnnualFee(BigDecimal annualFee) {
		this.annualFee = annualFee;
	}

	public String getFeature() {
		return feature;
	}

	public void setFeature(String feature) {
		this.feature = feature;
	}

	public String getRewardPoint() {
		return rewardPoint;
	}

	public void setRewardPoint(String rewardPoint) {
		this.rewardPoint = rewardPoint;
	}

	public String getPromotionalOffer() {
		return promotionalOffer;
	}

	public void setPromotionalOffer(String promotionalOffer) {
		this.promotionalOffer = promotionalOffer;
	}

	public String getApprovalChances() {
		return approvalChances;
	}

	public void setApprovalChances(String approvalChances) {
		this.approvalChances = approvalChances;
	}

	public String getCardTag() {
		return cardTag;
	}

	public void setCardTag(String cardTag) {
		this.cardTag = cardTag;
	}

	public BigDecimal getIsEligible() {
		return isEligible;
	}

	public void setIsEligible(BigDecimal isEligible) {
		this.isEligible = isEligible;
	}

	public Integer getPriorityOrder() {
		return priorityOrder;
	}

	public void setPriorityOrder(Integer priorityOrder) {
		this.priorityOrder = priorityOrder;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public BigDecimal getIsSmallTicket() {
		return isSmallTicket;
	}

	public void setIsSmallTicket(BigDecimal isSmallTicket) {
		this.isSmallTicket = isSmallTicket;
	}

	public String getL3productCode() {
		return l3productCode;
	}

	public void setL3productCode(String l3productCode) {
		this.l3productCode = l3productCode;
	}

	public String getProductvariant() {
		return productvariant;
	}

	public void setProductvariant(String productvariant) {
		this.productvariant = productvariant;
	}

	public BigDecimal getRoi() {
		return roi;
	}

	public void setRoi(BigDecimal roi) {
		this.roi = roi;
	}

	public BigDecimal getEmi() {
		return emi;
	}

	public void setEmi(BigDecimal emi) {
		this.emi = emi;
	}

	public BigDecimal getbScore() {
		return bScore;
	}

	public void setbScore(BigDecimal bScrore) {
		this.bScore = bScrore;
	}

	public String getLoanTag() {
		return loanTag;
	}

	public void setLoanTag(String loanTag) {
		this.loanTag = loanTag;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public List<Fees> getFees() {
		return fees;
	}

	public void setFees(List<Fees> fees) {
		this.fees = fees;
	}

	public Double getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(Double totalFee) {
		this.totalFee = totalFee;
	}

	public Long getProductListingKey() {
		return productListingKey;
	}

	public void setProductListingKey(Long productListingKey) {
		this.productListingKey = productListingKey;
	}

	public String getL4ProductCode() {
		return l4ProductCode;
	}

	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}

	public String getIsSelected() {
		return isSelected;
	}

	public void setIsSelected(String isSelected) {
		this.isSelected = isSelected;
	}

	public String getCtaName() {
		return ctaName;
	}

	public void setCtaName(String ctaName) {
		this.ctaName = ctaName;
	}

	public String getToBeDisplayedOnListingPage() {
		return toBeDisplayedOnListingPage;
	}

	public void setToBeDisplayedOnListingPage(String toBeDisplayedOnListingPage) {
		this.toBeDisplayedOnListingPage = toBeDisplayedOnListingPage;
	}

	public List<String> getUsp() {
		return usp;
	}

	public void setUsp(List<String> usp) {
		this.usp = usp;
	}

	public BigDecimal getRequiredLoanAmount() {
		return requiredLoanAmount;
	}

	public void setRequiredLoanAmount(BigDecimal requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}

	public BigDecimal getTenor() {
		return tenor;
	}

	public void setTenor(BigDecimal tenor) {
		this.tenor = tenor;
	}

	public BigDecimal getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(BigDecimal eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	public Integer getChildStatus() {
		return childStatus;
	}

	public void setChildStatus(Integer childStatus) {
		this.childStatus = childStatus;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public String getPrincipalCode() {
		return principalCode;
	}

	public void setPrincipalCode(String principalCode) {
		this.principalCode = principalCode;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public Long getNetDisbursementAmount() {
		return netDisbursementAmount;
	}

	public void setNetDisbursementAmount(Long netDisbursementAmount) {
		this.netDisbursementAmount = netDisbursementAmount;
	}

	@Override
	public String toString() {
		return "Product [description=" + description + ", annualFee=" + annualFee + ", feature=" + feature
				+ ", rewardPoint=" + rewardPoint + ", promotionalOffer=" + promotionalOffer + ", approvalChances="
				+ approvalChances + ", cardTag=" + cardTag + ", isEligible=" + isEligible + ", priorityOrder="
				+ priorityOrder + ", productCode=" + productCode + ", isSmallTicket=" + isSmallTicket
				+ ", l3productCode=" + l3productCode + ", l4ProductCode=" + l4ProductCode + ", riskOfferType="
				+ riskOfferType + ", productvariant=" + productvariant + ", roi=" + roi + ", emi=" + emi + ", bScore="
				+ bScore + ", loanTag=" + loanTag + ", loanType=" + loanType + ", fees=" + fees + ", totalFee="
				+ totalFee + ", productListingKey=" + productListingKey + ", isSelected=" + isSelected + ", ctaName="
				+ ctaName + ", toBeDisplayedOnListingPage=" + toBeDisplayedOnListingPage + ", usp=" + usp
				+ ", requiredLoanAmount=" + requiredLoanAmount + ", tenor=" + tenor + ", eligibilityAmount="
				+ eligibilityAmount + ", childStatus=" + childStatus + ", honouredPricingSource="
				+ honouredPricingSource + ", principalCode=" + principalCode + ", principalKey=" + principalKey
				+ ", netDisbursementAmount=" + netDisbursementAmount + "]";
	}
}
