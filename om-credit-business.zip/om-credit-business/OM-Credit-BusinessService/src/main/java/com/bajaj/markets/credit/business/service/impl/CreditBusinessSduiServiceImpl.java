package com.bajaj.markets.credit.business.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.sduiprocessor.TaskProcessor;
import com.bajaj.markets.credit.business.sduiprocessor.TaskProcessorFactory;
import com.bajaj.markets.credit.business.service.CreditBusinessSduiService;

@Component
public class CreditBusinessSduiServiceImpl implements CreditBusinessSduiService {

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Value("${api.omcommonsduiservice.usertask.POST.url}")
	private String getUserTaskUrl;

	@Autowired
	private TaskProcessorFactory taskProcessorFactory;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	WorkflowHelper workflowHelper;
	
	private static final String CLASS_NAME = CreditBusinessSduiServiceImpl.class.getCanonicalName();

	@Override
	public Object getUserTask(String applicationId, String taskName, HttpHeaders headers) {
		TaskProcessor taskProcessor = taskProcessorFactory.getUserTask(taskName);
		String request = taskProcessor.getUserTaskRequest(applicationId, headers);
		Map<String, String> param = new HashMap<>();
		param.put("taskid", taskName);
		ResponseEntity<?> userTaskResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, getUserTaskUrl,
				String.class, param, request, headers);
		if (null != userTaskResponse) {
			return userTaskResponse.getBody();
		}
		return null;
	}

	@Override
	public ApplicationResponse saveUserTaskContent(String applicationId,  String taskName,Object userTaskContent, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start saveUserTaskContent for applicationid : " + applicationId);
		try {
			Map<String, Object> vars = new HashMap<>();
			vars.put(CreditBusinessConstants.REQUEST, userTaskContent);
			vars.put("applicationid", applicationId);
			vars.put("applicationId", applicationId);
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End saveUserTaskContent for applicationid : " + applicationId);
			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			ApplicationResponse applicationResponse = new ApplicationResponse();
			applicationResponse.setNextTask(task);
			return applicationResponse;
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception completing workflow task" ,e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while calling the service",e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-101", "Exception while completing activiti task"));
		}
	
		
	}

}
