package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE_FROM_MCP;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.IS_REJECTED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.TAKE_BACK_TO_LISTING_PAGE;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AdditionalParameterDetail;
import com.bajaj.markets.credit.business.beans.DeactivateOffer;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.EstimatedNetMonthlySalaryDetails;
import com.bajaj.markets.credit.business.beans.MCPRequest;
import com.bajaj.markets.credit.business.beans.OpenArcRejectionInput;
import com.bajaj.markets.credit.business.beans.PanDetails;
import com.bajaj.markets.credit.business.beans.PrincipleProductDetails;
import com.bajaj.markets.credit.business.beans.Qualification;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.beans.Specilizations;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.PrincipleDedupeRequiredEnum;
import com.bajaj.markets.credit.business.helper.RejectionSystemSourceEnum;
import com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean;
import com.bajaj.markets.referencedataclientlib.bean.LookupCodeValuesResponseBean;
import com.bajaj.markets.referencedataclientlib.bean.OccupationMaster;
import com.google.gson.Gson;

import io.jsonwebtoken.lang.Collections;

@Component
public class McpCheck {
	private static final String REJECTION_SYSTEM = "rejectionSystem";
	private static final String SALARY_SOURCE = "salarySource";
	private static final String SALARY_AMOUNT = "salaryAmount";
	private static final String UPDATE_MCP = "updateMCP";
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	MasterDataRedisClientHelper masterDataRedisHelper;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	private int dedupeCardinality;
	
	private static final String CLASS_NAME = McpCheck.class.getCanonicalName();

	public void mcpFirst(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start mcpFirst");
		execution.setVariable(REJECTION_SYSTEM, RejectionSystemSourceEnum.REJBRE1.getValue());
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject residencePincode = CreditBusinessHelper.getJSONObject(request.get("residencePincode"));
		JSONObject mcpRequestFromGet = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		ResidenceMaster residenceType = this.getResidanceType(mcpRequestFromGet);
		String resiType = (null != residenceType && null != residenceType.getResidenceValue() ? residenceType.getResidenceValue() : null);
		JSONObject occupationFromMcpRequest = CreditBusinessHelper.getJSONObject(mcpRequestFromGet.get("occupation"));
		JSONObject occupation = setOccupationValue(execution, occupationFromMcpRequest);
		preparePayload(execution, "1", mcpRequestFromGet, occupation, residencePincode, resiType);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End mcpFirst");
	}

	public void mcpSecond(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start mcpSecond");
		execution.setVariable(REJECTION_SYSTEM, RejectionSystemSourceEnum.REJBRE2.getValue());
		JSONObject mcpRequestFromGet = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		JSONObject residencePincode = null;
		ResidenceMaster residenceType = getResidanceType(mcpRequestFromGet);
		String resiType = (null != residenceType && null != residenceType.getResidenceValue() ? residenceType.getResidenceValue() : null);
		JSONObject occupationFromMcpRequest = CreditBusinessHelper.getJSONObject(mcpRequestFromGet.get("occupation"));
		JSONObject occupation = setOccupationValue(execution, occupationFromMcpRequest);
		preparePayload(execution, "2", mcpRequestFromGet, occupation, residencePincode, resiType);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End mcpSecond");
	}

	public ResidenceMaster getResidanceType(JSONObject mcpRequestFromGet){
		ResidenceMaster resi = null;
		JSONObject userProfile = CreditBusinessHelper.getJSONObject(mcpRequestFromGet.get("userProfile"));
		if (userProfile != null && userProfile.get("residenceTypeKey") != null) {
			Double resiTypeKey = (Double) userProfile.get("residenceTypeKey");
			try {
				resi = masterDataRedisHelper.findResitypeByKey(resiTypeKey.longValue());
			} catch (Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Error while fetching resiTypes from Redis ", e);
				new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("WFLSTRN-001", "Some Technical Exception Occured"));
				
			} 	
				}
		return resi;
			}

	@SuppressWarnings("unchecked")
	private void preparePayload(DelegateExecution execution, String rejectionType, JSONObject mcpRequestFromGet, JSONObject occupation,
			JSONObject residencePincode, String resiType) {
		JSONObject additionalParameterDetail = null;
		JSONObject userProfile = null;
		MCPRequest mcpRequest = new MCPRequest();
		OpenArcRejectionInput openArcRejectionInput = new OpenArcRejectionInput();

		String applicationId = execution.getVariable(CreditBusinessConstants.APPLICATION_ID) != null
				? execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString()
				: null;
		openArcRejectionInput.setApplicationId(applicationId);
		openArcRejectionInput.setProduct(execution.getVariable(CreditBusinessConstants.PRODUCTDESC).toString());
		openArcRejectionInput.setResiType(resiType);

		JSONObject ocupationType = null;
		JSONObject salariedDetail = null;
		JSONObject businessOwnerDetails = null;
		if (null != occupation) {
			ocupationType = CreditBusinessHelper.getJSONObject(occupation.get("ocupationType"));
			salariedDetail = CreditBusinessHelper.getJSONObject(occupation.get("salariedDetail"));
			businessOwnerDetails = CreditBusinessHelper.getJSONObject(occupation.get("businessOwnerDetails"));
		}

		if (null != mcpRequestFromGet) {
			openArcRejectionInput.setSubStagePercentage(
					mcpRequestFromGet.get("subStagePercentage") != null ? Float.valueOf(mcpRequestFromGet.get("subStagePercentage").toString()) : null);
			openArcRejectionInput.setRegistrationNumber(mcpRequestFromGet.get("registrationNumber") != null ? mcpRequestFromGet.get("registrationNumber").toString() : null);
			openArcRejectionInput.setYrOfAttainingCertificate(mcpRequestFromGet.get("yrOfAttainingCertificate") != null ? mcpRequestFromGet.get("yrOfAttainingCertificate").toString() : null);
			openArcRejectionInput.setYearOfGraduation(
					mcpRequestFromGet.get("yearOfGraduation") != null ? Float.valueOf(mcpRequestFromGet.get("yearOfGraduation").toString()).intValue() : null);
			openArcRejectionInput.setYearOfPostGraduation(
					mcpRequestFromGet.get("yearOfPostGraduation") != null ? Float.valueOf(mcpRequestFromGet.get("yearOfPostGraduation").toString()).intValue() : null);
			if(mcpRequestFromGet.get("appSegmentation")!=null) {
				Map<String,Object> appSegmentation=(Map<String, Object>) mcpRequestFromGet.get("appSegmentation");
				openArcRejectionInput.setCustomerProfileSegment(appSegmentation.get("customerProfileSegment") !=null ? appSegmentation.get("customerProfileSegment").toString():null);
				openArcRejectionInput.setMicroSegment(appSegmentation.get("microSegment")!=null ? appSegmentation.get("microSegment").toString():null);
				
				
			}
			openArcRejectionInput.setJourneyStamp(mcpRequestFromGet.get("journeyStamp") != null ? mcpRequestFromGet.get("journeyStamp").toString() : null);
			
			additionalParameterDetail = CreditBusinessHelper.getJSONObject(mcpRequestFromGet.get("additionalParameterDetail"));
			if (null != additionalParameterDetail) {
				AdditionalParameterDetail parameterDetail = new AdditionalParameterDetail();
				parameterDetail
						.setUtmCampaign(additionalParameterDetail.get("utmCampaign") != null ? additionalParameterDetail.get("utmCampaign").toString() : null);
				parameterDetail
						.setUtmChannel(additionalParameterDetail.get("utmChannel") != null ? additionalParameterDetail.get("utmChannel").toString() : null);
				parameterDetail
						.setUtmContent(additionalParameterDetail.get("utmContent") != null ? additionalParameterDetail.get("utmContent").toString() : null);
				parameterDetail.setUtmMedium(additionalParameterDetail.get("utmMedium") != null ? additionalParameterDetail.get("utmMedium").toString() : null);
				parameterDetail.setUtmSource(additionalParameterDetail.get("utmSource") != null ? additionalParameterDetail.get("utmSource").toString() : null);
				parameterDetail.setUtmTerm(additionalParameterDetail.get("utmTerm") != null ? additionalParameterDetail.get("utmTerm").toString() : null);
				mcpRequest.setAdditionalParameterDetail(parameterDetail);
			}
			userProfile = CreditBusinessHelper.getJSONObject(mcpRequestFromGet.get(CreditBusinessConstants.USERPROFILE));
			if (userProfile != null) {
				setUserProfileData(execution, userProfile, openArcRejectionInput);
			}
			setCity(mcpRequestFromGet, openArcRejectionInput);
			setSpecialisationDetails(mcpRequestFromGet, openArcRejectionInput);
			setQualificationDetails(mcpRequestFromGet, openArcRejectionInput);
			if (null != mcpRequestFromGet.get("mcpAddressDetails")) {
				Gson g = new Gson();
				String json = g.toJson(mcpRequestFromGet.get("mcpAddressDetails"));
				JSONArray mcpAddressDetails = g.fromJson(json, JSONArray.class);
				if (null != mcpAddressDetails && !mcpAddressDetails.isEmpty()) {
					JSONObject mcpAddressDtl = CreditBusinessHelper.getJSONObject(mcpAddressDetails.get(0));
					if (null != mcpAddressDtl) {
						String principleProductDetailsJson = g.toJson(mcpAddressDtl.get("principleProductDetails"));
						JSONArray principleProductDetails = g.fromJson(principleProductDetailsJson, JSONArray.class);
						if("1".equals(rejectionType)){
							JSONArray principleProductDetailsUpdated = addPincodeInMCPRequest(execution,principleProductDetails,rejectionType);
							principleProductDetails = principleProductDetailsUpdated;
						}else if("2".equals(rejectionType)) {
							JSONArray principleProductDetailsUpdated=addOfficePincodeInMCPRequest(execution,principleProductDetails,rejectionType);
							principleProductDetails = principleProductDetailsUpdated;
						}
						openArcRejectionInput.setPrincipleProductDetails((java.util.List<PrincipleProductDetails>) principleProductDetails);
					}
				}
			}
			
			List<EstimatedNetMonthlySalaryDetails> estimatedNetMonthlySalaryDetails = null;
			if (mcpRequestFromGet.get("estimatedNetMonthlySalaryDetails") != null) {
				List<Map<String, Object>> salaryDetails = (List<Map<String, Object>>) mcpRequestFromGet.get("estimatedNetMonthlySalaryDetails");
				if (!salaryDetails.isEmpty()) {
					estimatedNetMonthlySalaryDetails = new ArrayList<>();
					for (Map<String, Object> salary : salaryDetails) {
						EstimatedNetMonthlySalaryDetails details = new EstimatedNetMonthlySalaryDetails();
						details.setSalarySource(salary.get(SALARY_SOURCE) != null ? salary.get(SALARY_SOURCE).toString() : null);
						details.setSalaryAmount(salary.get(SALARY_AMOUNT) != null ? new BigDecimal(salary.get(SALARY_AMOUNT).toString()) : null);
						estimatedNetMonthlySalaryDetails.add(details);
					}
				}
			}
			openArcRejectionInput.setEstimatedNetMonthlySalaryDetails(estimatedNetMonthlySalaryDetails);			

			if (mcpRequestFromGet.get("pincode") != null) {
				JSONObject externalPincodeObject = CreditBusinessHelper.getJSONObject(mcpRequestFromGet.get("pincode"));				
				if (externalPincodeObject.get("pincode") != null) {
					LocationResponseBean pinCodeMaster =  masterDataRedisHelper.getPinCodeByKey(new BigDecimal(externalPincodeObject.get("pincode").toString()).longValue());
					externalPincodeObject.put("pincode", pinCodeMaster.getPincode());
					externalPincodeObject.put("city", pinCodeMaster.getCityName());
					openArcRejectionInput.setPincodeDetail(externalPincodeObject);

			List<DeactivateOffer> deactivateOfferList = null;
			if (mcpRequestFromGet.get("deactivateOfferList") != null) {
				List<Map<String, Object>> deactivatedOffers = (List<Map<String, Object>>) mcpRequestFromGet
						.get("deactivateOfferList");
				if (!deactivatedOffers.isEmpty()) {
					deactivateOfferList = new ArrayList<>();
					for (Map<String, Object> offer : deactivatedOffers) {
						DeactivateOffer deactivateOffer = new DeactivateOffer();
						deactivateOffer.setActiveDate(offer.get(CreditBusinessConstants.ACTIVEDATE) != null
								? offer.get(CreditBusinessConstants.ACTIVEDATE).toString()
								: null);
						if (null != offer.get(CreditBusinessConstants.CUSTOMER_ID)) {
						Long customerId = Double.valueOf(offer.get(CreditBusinessConstants.CUSTOMER_ID).toString())
								.longValue();
						deactivateOffer.setCustomerId(customerId);
						}

						deactivateOffer.setHoldReason(offer.get(CreditBusinessConstants.HOLD_REASON) != null
								? offer.get(CreditBusinessConstants.HOLD_REASON).toString()
								: null);
						deactivateOffer.setInactiveDate(offer.get(CreditBusinessConstants.IN_ACTIVEDATE) != null
								? offer.get(CreditBusinessConstants.IN_ACTIVEDATE).toString()
								: null);
						deactivateOffer.setStatus(offer.get(CreditBusinessConstants.STATUS) != null
								? offer.get(CreditBusinessConstants.STATUS).toString()
								: null);
						deactivateOfferList.add(deactivateOffer);
					}
				}
			}
			openArcRejectionInput.setDeactivateOfferList(deactivateOfferList);
		}
			}
		}

		openArcRejectionInput.setOccupationType(
				null != ocupationType && null != ocupationType.get(CreditBusinessConstants.VALUE) ? ocupationType.get(CreditBusinessConstants.VALUE).toString()
						: null);
		openArcRejectionInput.setRejectionType(rejectionType);

		if (null != salariedDetail) {
			setSalariedData(execution, openArcRejectionInput, salariedDetail);
		}

		if (null != businessOwnerDetails) {
			setBusinessOwnerData(execution, openArcRejectionInput, businessOwnerDetails);
		}

		/*
		 * if (null != residencePincode) { JSONObject city =
		 * CreditBusinessHelper.getJSONObject(residencePincode.get("city"));
		 * openArcRejectionInput .setCity(null != city && null !=
		 * city.get(CreditBusinessConstants.VALUE) ?
		 * city.get(CreditBusinessConstants.VALUE).toString() : null);
		 * 
		 * }
		 */ 
		//TODO

		List<PanDetails> panDetailsList = getNsdlPanResponse(execution);
		openArcRejectionInput.setPanDetails(panDetailsList);
		execution.setVariable("mcp", rejectionType);
		
		//Added BT Bank Details for Secured Loan
		openArcRejectionInput.setBtBankName(null != execution.getVariable(CreditBusinessConstants.BTBANKNAME) ? execution.getVariable(CreditBusinessConstants.BTBANKNAME).toString() : null);
				
		//Added hlProduct Intent for Secured Loan
		openArcRejectionInput.setHlProductIntent(null != execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT) ? execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT).toString() : null);
        
		//Added for OMDT-1272
				if (null != mcpRequestFromGet.get("officialEmailId")) {
					openArcRejectionInput.setOfficialEmailId(mcpRequestFromGet.get("officialEmailId").toString());
				}
				else {
					openArcRejectionInput.setOfficialEmailId(null);
				}
	    openArcRejectionInput.setPropertyIdentifiedFlag(null!=mcpRequestFromGet.get("propertyIdentifiedFlag") ? (Boolean)mcpRequestFromGet.get("propertyIdentifiedFlag") : null);
		mcpRequest.setOpenArcRejectionInput(openArcRejectionInput);
		JSONObject mcpRequestjson = CreditBusinessHelper.getJSONObject(mcpRequest);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, mcpRequestjson);
	}

	private void setCity(JSONObject mcpRequestFromGet, OpenArcRejectionInput openArcRejectionInput) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "setCity : method started for mcp"+openArcRejectionInput.getRejectionType());
		if (null != mcpRequestFromGet.get("addressList")) {
			Gson gson = new Gson();
			String addressJson = gson.toJson(mcpRequestFromGet.get("addressList"));
			JSONArray addressDetails = gson.fromJson(addressJson, JSONArray.class);
			if(!CollectionUtils.isEmpty(addressDetails)) {
				for(int i = 0; i < addressDetails.size(); i++)
				{
				      JSONObject address = CreditBusinessHelper.getJSONObject(addressDetails.get(i));
				      if("50".equals(address.get("addressTypeKey").toString()) && null!=address.get("pincodeKey")) {
				    	  LocationResponseBean pinCodeMaster = masterDataRedisHelper.getPinCodeByKey(Long.valueOf(address.get("pincodeKey").toString()));
				    	  openArcRejectionInput.setCity(pinCodeMaster.getCityName());
				      }
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "setCity : method ended for mcp"+openArcRejectionInput.getRejectionType());
	}

	public List<PanDetails> getNsdlPanResponse(DelegateExecution execution) {
		List<PanDetails> panDetailsList = null;
		if (execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE) != null) {
			JSONObject nsdlPanResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE));
			panDetailsList = new ArrayList<PanDetails>();
			PanDetails panDetails = new PanDetails();
			panDetails.setNameMatch(nsdlPanResponse.get("nameMatch") != null ? nsdlPanResponse.get("nameMatch").toString() : null);
			panDetails.setMatchScore(null);
			panDetails.setPanType(null);
			panDetails.setPanStatus(nsdlPanResponse.get("panStatus") != null ? nsdlPanResponse.get("panStatus").toString() : null);
			panDetailsList.add(panDetails);
		}
		return panDetailsList;
	}

	private void setUserProfileData(DelegateExecution execution, JSONObject userProfile, OpenArcRejectionInput openArcRejectionInput) {
				openArcRejectionInput.setAge(null != userProfile.get(CreditBusinessConstants.DATE_OF_BIRTH)
								? (float) CreditBusinessHelper.calculateAge(userProfile.get(CreditBusinessConstants.DATE_OF_BIRTH).toString())
								: null);
		openArcRejectionInput.setPanNumber(
				null != userProfile.get(CreditBusinessConstants.PAN_NUMBER) ? userProfile.get(CreditBusinessConstants.PAN_NUMBER).toString() : null);

				if (userProfile.get("qualification") != null) {
					String qualificationValue = userProfile.get("qualification").toString();
			LookupCodeValuesResponseBean qualificationMaster = masterDataRedisHelper.getLookupValueByLookupCodeAndSortTxt("QUALIFICATION",
					qualificationValue);
			if (qualificationMaster != null) {
				openArcRejectionInput.setEducationQualification(qualificationMaster.getCode());
						}
					}
		if (userProfile.get("genderKey") != null) {
			Double generKey = Double.valueOf(userProfile.get("genderKey").toString());
			String gender = masterDataRedisHelper.getGenderByTypeKey(generKey.longValue());
			openArcRejectionInput.setGender(gender);
			}
					}

	private void setSalariedData(DelegateExecution execution, OpenArcRejectionInput openArcRejectionInput, JSONObject salariedDetail) {
			JSONObject designation = CreditBusinessHelper.getJSONObject(salariedDetail.get("designation"));
			openArcRejectionInput.setDesignation(
					null != designation && null != designation.get(CreditBusinessConstants.VALUE) ? designation.get(CreditBusinessConstants.VALUE).toString()
							: null);
			String exp = null != salariedDetail.get("experience") ? salariedDetail.get("experience").toString() : null;
			openArcRejectionInput.setWorkExperience(exp != null && !"null".equalsIgnoreCase(exp) ? Float.valueOf(exp) : null);
		openArcRejectionInput.setEmployerType(execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY) != null
				? execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY).toString()
				: null);
		openArcRejectionInput.setCompanyCategory(execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY) != null
				? execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY).toString()
				: null);
		
		if (salariedDetail.get("employerName") != null) {
			JSONObject employer = CreditBusinessHelper.getJSONObject(salariedDetail.get("employerName"));
			if (employer.get(CreditBusinessConstants.KEY) != null) {
				Long employerId = Double.valueOf(employer.get(CreditBusinessConstants.KEY).toString()).longValue();
				JSONObject employerMaster = apiCallsHelper.getEmployerMaster(employerId);
				if (employerMaster != null && null != employerMaster.get(CreditBusinessConstants.INDMASTKEY)) {
					Integer industryTypeKey = Integer
							.valueOf(employerMaster.get(CreditBusinessConstants.INDMASTKEY).toString());
					String industryTypeValue = apiCallsHelper.getSOLIndustryType(industryTypeKey);
					openArcRejectionInput.setIndustryType(industryTypeValue);
				}
			}
		}
	}

	private void setBusinessOwnerData(DelegateExecution execution, OpenArcRejectionInput openArcRejectionInput, JSONObject businessOwnerDetails) {
		openArcRejectionInput.setBusinessPAN(businessOwnerDetails.get("businessPan") != null ? businessOwnerDetails.get("businessPan").toString() : null);
		openArcRejectionInput.setOfficeType(businessOwnerDetails.get("officeType") != null ? businessOwnerDetails.get("officeType").toString() : null);
		openArcRejectionInput.setProfitAfterTax(
				businessOwnerDetails.get("profitAfterTax") != null ? Double.valueOf(businessOwnerDetails.get("profitAfterTax").toString()) : null);
		openArcRejectionInput.setAverageBankBalance(
				businessOwnerDetails.get("averageBankBalance") != null ? Double.valueOf(businessOwnerDetails.get("averageBankBalance").toString()) : null);
			JSONObject anualTurnover = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("anualTurnover"));
			if (null != anualTurnover && null != anualTurnover.get(CreditBusinessConstants.VALUE)) {
				String annualTurnOverValue = anualTurnover.get(CreditBusinessConstants.VALUE).toString();
				ArrayList<Map<String, Object>> annualTurnoverList = (ArrayList<Map<String, Object>>) execution
						.getVariable(CreditBusinessConstants.ANNUALTURNOVER_LOOKUP_LIST);
				if (annualTurnOverValue != null && !CollectionUtils.isEmpty(annualTurnoverList)) {
					Optional<Map<String, Object>> annulturnOverOptional = annualTurnoverList.stream()
							.filter(turnover -> annualTurnOverValue.equalsIgnoreCase(turnover.get(CreditBusinessConstants.VALUE).toString())).findFirst();
					if (!annulturnOverOptional.isEmpty()) {
						openArcRejectionInput.setAnnualTurnOver(annulturnOverOptional.get().get(CreditBusinessConstants.CODE) != null
								? annulturnOverOptional.get().get(CreditBusinessConstants.CODE).toString()
								: null);
					}
				}
			}

			 if(businessOwnerDetails.get("businessVintage") != null) {
	                openArcRejectionInput.setBusinessVintage(Integer.valueOf(businessOwnerDetails.get("businessVintage").toString()));
	  }
		
			JSONObject natureOfBusiness = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("natureOfBusiness"));
			openArcRejectionInput.setNatureOfBusiness(null != natureOfBusiness && null != natureOfBusiness.get(CreditBusinessConstants.KEY)
				? natureOfBusiness.get(CreditBusinessConstants.KEY).toString()
					: null);

			JSONObject businessType = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("businessType"));
			openArcRejectionInput.setCompanyType(null != businessType && null != businessType.get(CreditBusinessConstants.KEY)
				? businessType.get(CreditBusinessConstants.KEY).toString() : null);
			
			JSONObject industryType = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("industryType"));
			if(null != industryType && null!= industryType.get(CreditBusinessConstants.KEY) ) {
				Long industryTypeKey = Double.valueOf(industryType.get(CreditBusinessConstants.KEY).toString()).longValue();
				String industryTypeValue = apiCallsHelper.getIndustryType(industryTypeKey);
				openArcRejectionInput.setIndustryType(industryTypeValue);
			}
			openArcRejectionInput.setSubIndustryType(null);//Need to ask
			
		}

	public void mcpSecondPost(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start mcpSecondPost");
		JSONObject mcpOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		boolean cibilRequired = false;
		boolean karzaRequired = false;
		execution.setVariable(CreditBusinessConstants.CIBIL_REQUIRED, cibilRequired);
		execution.setVariable(CreditBusinessConstants.CV_REQUIRED, Boolean.FALSE);
		if (mcpOutput != null && mcpOutput.get("openArcRejectionOutput") != null) {
			JSONObject rejectionOutput = CreditBusinessHelper.getJSONObject(mcpOutput.get("openArcRejectionOutput"));
			if (rejectionOutput.get("cibilRequired") != null && (Boolean) rejectionOutput.get("cibilRequired")) {
				cibilRequired = true;
				execution.setVariable(CreditBusinessConstants.CIBIL_REQUIRED, cibilRequired);
			}
			if (null != rejectionOutput.get(CreditBusinessConstants.CV_REQUIRED) && (Boolean) rejectionOutput.get(CreditBusinessConstants.CV_REQUIRED)) {
				execution.setVariable(CreditBusinessConstants.CV_REQUIRED, Boolean.TRUE);
			}
			if (null != rejectionOutput.get(CIBIL_TYPE_FROM_MCP)) {
				execution.setVariable(CIBIL_TYPE, rejectionOutput.get(CIBIL_TYPE_FROM_MCP).toString());
				logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, rejectionOutput.get(CIBIL_TYPE_FROM_MCP).toString());
			}
			if (null != rejectionOutput.get(CreditBusinessConstants.KARZA_REQUIRED) && (Boolean) rejectionOutput.get(CreditBusinessConstants.KARZA_REQUIRED)) {
				karzaRequired = true;
			}
		}
		execution.setVariable(CreditBusinessConstants.KARZA_REQUIRED, karzaRequired);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "karzaRequired flag from MCP2 is " + karzaRequired);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "CibilRequired flag from MCP2 is " + cibilRequired);
		this.post(execution);	
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End mcpSecondPost");
	}

	@SuppressWarnings("unchecked")
	public void post(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start MCP post");
		execution.setVariable(UPDATE_MCP, CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT)));
		Boolean eligiblePrincipleFound = false;
		Map<String, Boolean> partnerDedupeRequiredMap = new HashMap<String, Boolean>(); 
		if (execution.getVariable(CreditBusinessConstants.OUTPUT) != null) {
			JSONObject mcpOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
			if (mcpOutput != null && mcpOutput.get("openArcRejectionOutput") != null) {
				JSONObject rejectionOutput = CreditBusinessHelper.getJSONObject(mcpOutput.get("openArcRejectionOutput"));
				if (rejectionOutput != null && rejectionOutput.get("principleProductDetails") != null) {
					List<Map<String, Object>> principleProdDetailList = (List<Map<String, Object>>) rejectionOutput.get("principleProductDetails");
					if (!CollectionUtils.isEmpty(principleProdDetailList)) {
						for (Map<String, Object> product : principleProdDetailList) {
							if ((boolean) product.get("isEligible") && !eligiblePrincipleFound) {
								eligiblePrincipleFound = (boolean) product.get("isEligible");
							}
							
							PrincipleDedupeRequiredEnum principleDedupeRequireEnum = 
									PrincipleDedupeRequiredEnum.getPrincipleDedupeRequiredEnum(product.get("principleProductCode").toString());
							if (((boolean) product.get("isEligible")) && null != principleDedupeRequireEnum) {
								partnerDedupeRequiredMap.put(principleDedupeRequireEnum.getValue(), true);
							}
						}
					}
				}
			}
		}
		
		dedupeCardinality = 0;
		
		if(partnerDedupeRequiredMap.containsValue(true)) {
			execution.setVariable("partnerDedupeRequiredMap", partnerDedupeRequiredMap);
			execution.setVariable("partnerDedupeRequired", true);
			
			partnerDedupeRequiredMap.forEach((key, value) -> {
				if(value) {
					dedupeCardinality++;
				}
			});
			execution.setVariable("dedupeCardinality", dedupeCardinality);
		} else {
			execution.setVariable("partnerDedupeRequired", false);
		}
		
		execution.setVariable(CreditBusinessConstants.IS_REJECTED, !eligiblePrincipleFound);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start MCP post");
	}

	public void updateMcp(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start updateMcp");
		JSONObject updateMCP = CreditBusinessHelper.getJSONObject(execution.getVariable(UPDATE_MCP));
		updateMCP.put(REJECTION_SYSTEM, execution.getVariable(REJECTION_SYSTEM));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, updateMCP);
		execution.setVariable(REJECTION_SYSTEM, null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start updateMcp");
	}

	public void prepareMcpRequest(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preMcpRequest");
		execution.setVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT,
				CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT)));
		JSONObject mcp = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		JSONObject prodCategory = CreditBusinessHelper.getJSONObject(mcp.get("prodCategory"));
		execution.setVariable(CreditBusinessConstants.PRODUCTDESC, prodCategory.get("prodCatDesc"));
		execution.setVariable(CreditBusinessConstants.PRODUCTCODE, prodCategory.get("prodCatCode"));
		execution.setVariable(CreditBusinessConstants.CV_REQUIRED, null != mcp.get(CreditBusinessConstants.CV_REQUIRED) ? (Boolean)mcp.get(CreditBusinessConstants.CV_REQUIRED) : Boolean.FALSE);
		execution.setVariable(CreditBusinessConstants.BTBANKMASTERKEY, (null != mcp.get("btBankMasterKey") && !mcp.get("btBankMasterKey").equals("null"))  ? Integer.parseInt(mcp.get("btBankMasterKey").toString()) : null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preMcpRequest");
	}

	@SuppressWarnings("unchecked")
	public JSONObject setOccupationValue(DelegateExecution execution, JSONObject occupationFromMcpRequest) {
		if(!execution.hasVariable(CreditBusinessConstants.OCCUPATION_TYPE)){
			execution.setVariable(CreditBusinessConstants.OCCUPATION_TYPE, null);
		}
		if(!execution.hasVariable(CreditBusinessConstants.OCCUPATIONTYPECODE)){
			execution.setVariable(CreditBusinessConstants.OCCUPATIONTYPECODE, null);
		}
		
		if (occupationFromMcpRequest != null && occupationFromMcpRequest.get("ocupationType") != null) {
			Map<String, Object> occupationType = (Map<String, Object>) occupationFromMcpRequest.get("ocupationType");
				if (occupationType.get("key") != null) {
					Double occupationKey = Double.valueOf(occupationType.get("key").toString());
					OccupationMaster occupationMaster =  masterDataRedisHelper.getOccupationByKey(occupationKey.longValue());
					if (occupationMaster != null) {
						occupationType.put(CreditBusinessConstants.VALUE, occupationMaster.getOccupationValue());
						occupationType.put(CreditBusinessConstants.CODE, occupationMaster.getOccupationCode());
						execution.setVariable(CreditBusinessConstants.OCCUPATION_TYPE, occupationMaster.getOccupationValue());
						execution.setVariable(CreditBusinessConstants.OCCUPATIONTYPECODE, occupationMaster.getOccupationCode());
						occupationFromMcpRequest.put("ocupationType", occupationType);
					}
				}
			}
		return occupationFromMcpRequest;
	}
	
	public void preGetPincodeForMcp(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preGetPincodeForMcp");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject residencePincode = CreditBusinessHelper.getJSONObject(request.get("residencePincode"));
		execution.setVariable(CreditBusinessConstants.PINCODEKEY, null != residencePincode && null != residencePincode.get("pincode") ? residencePincode.get("pincode").toString():null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preGetPincodeForMcp");
	}
	
	public void postGetPincodeForMcp(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetPincodeForMcp");
		execution.setVariable("pincodeValue", null);
		JSONObject pincodeDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (null != pincodeDetails) {
			String pincodeValue = null != pincodeDetails.get("pincode") ? pincodeDetails.get("pincode").toString() : null;
			execution.setVariable("pincodeValue", pincodeValue);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetPincodeForMcp");
	}
	
	private JSONArray addPincodeInMCPRequest(DelegateExecution execution,JSONArray principleProductDetails,String rejectionType){
		JSONArray principleProductDetailsUpdated = new JSONArray();
		String pincodeValue = null != execution.getVariable("pincodeValue") ? execution.getVariable("pincodeValue").toString(): null;
		for(int i = 0; i < principleProductDetails.size(); i++){
			JSONObject principleProductDetailJsonObject = CreditBusinessHelper.getJSONObject(principleProductDetails.get(i));
			JSONObject pincodeJsonObject = CreditBusinessHelper.getJSONObject(principleProductDetailJsonObject.get("pincode"));
			pincodeJsonObject.put("pincode", pincodeValue);
			principleProductDetailJsonObject.put("pincode", pincodeJsonObject);
			principleProductDetailsUpdated.add(principleProductDetailJsonObject);
		}
		return principleProductDetailsUpdated;
	}
	
	public JSONArray addOfficePincodeInMCPRequest(DelegateExecution execution,JSONArray principleProductDetails,String rejectionType) {
		Reference officepincode =null;
		JSONArray principleProductDetailsUpdated = new JSONArray();
		if(execution.getVariable("officepincode")!=null ) {
			officepincode = (Reference) execution.getVariable("officepincode");	
		}
		for(int i = 0; i < principleProductDetails.size(); i++) {
			JSONObject principleProductDetailJsonObject = CreditBusinessHelper.getJSONObject(principleProductDetails.get(i));
			JSONObject officepincodeJsonObject = CreditBusinessHelper.getJSONObject(principleProductDetailJsonObject.get("officePinCode"));
			if(officepincode!=null) {
				officepincodeJsonObject.put("officepincode",officepincode.getValue());
			}
			principleProductDetailJsonObject.put("officepincode", officepincodeJsonObject);
			principleProductDetailsUpdated.add(principleProductDetailJsonObject);
		}
		return principleProductDetailsUpdated;
		
	}
	
	public void setMcpBreReRun(DelegateExecution execution) {
		execution.setVariable("mcpBreReRan", true);
	}
	
	public void preGetMcp3Request(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetMcp3Request");
		execution.setVariable("applicationresources", "APPLICATION,APP_ATTRIBUTE,APP_OCCUPATION,APP_ADDRESS,APP_REJECTION_DEVIATION,"
																 + "APP_OFFER, APP_STATUS, APP_UTM,APP_PRINCIPAL_CUST_INFO,APP_EMAIL");	
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetMcp3Request");
	}
	
	public void preMcp3(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preMcp3");
		execution.setVariable(REJECTION_SYSTEM, RejectionSystemSourceEnum.REJBRE3.getValue());
		JSONObject mcpRequestFromGet = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		JSONObject prodCategory = CreditBusinessHelper.getJSONObject(mcpRequestFromGet.get("prodCategory"));
		execution.setVariable(CreditBusinessConstants.PRODUCTDESC, prodCategory.get("prodCatDesc"));
		execution.setVariable(CreditBusinessConstants.PRODUCTCODE, prodCategory.get("prodCatCode"));
		JSONObject residencePincode = null;
		ResidenceMaster residenceType = getResidanceType(mcpRequestFromGet);
		String resiType = (null != residenceType && null != residenceType.getResidenceValue() ? residenceType.getResidenceValue() : null);
		JSONObject occupationFromMcpRequest = CreditBusinessHelper.getJSONObject(mcpRequestFromGet.get("occupation"));
		JSONObject occupation = setOccupationValue(execution, occupationFromMcpRequest);
		preparePayload(execution, "3", mcpRequestFromGet, occupation, residencePincode, resiType);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preMcp3");
	}
	
	public void postMcp3(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postMcp3");
		execution.setVariable(IS_REJECTED, false);
		execution.setVariable(TAKE_BACK_TO_LISTING_PAGE, false);
		
		execution.setVariable(UPDATE_MCP, CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT)));
		String l3ProductCode = execution.getVariable(CreditBusinessConstants.L3_PRODUCT_CODE).toString();
		boolean currentL3Rejected = false;
		JSONObject mcpOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		boolean eligiblePrincipleFound = false;
		if (mcpOutput != null && mcpOutput.get("openArcRejectionOutput") != null) {
			JSONObject rejectionOutput = CreditBusinessHelper.getJSONObject(mcpOutput.get("openArcRejectionOutput"));
			if (rejectionOutput != null && rejectionOutput.get("principleProductDetails") != null) {
				List<Map<String, Object>> principleProdDetailList = (List<Map<String, Object>>) rejectionOutput.get("principleProductDetails");
				if (!CollectionUtils.isEmpty(principleProdDetailList)) {
					for (Map<String, Object> product : principleProdDetailList) {
						if (!eligiblePrincipleFound && (boolean) product.get("isEligible")) {
							eligiblePrincipleFound = true;
						}

						if (product.get("principleProductCode") != null && product.get("principleProductCode").toString().equalsIgnoreCase(l3ProductCode)
								&& !(boolean) product.get("isEligible")) {
							currentL3Rejected = true;
						}

					}
				}
			}
		}
		
		if(!eligiblePrincipleFound) {
			execution.setVariable(CreditBusinessConstants.IS_REJECTED, true);
		}else if(currentL3Rejected) {
			execution.setVariable(CreditBusinessConstants.TAKE_BACK_TO_LISTING_PAGE, true);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postMcp3 for applicationId: " + execution.getVariable(CreditBusinessConstants.APPLICATION_ID) + " isRejected: " + execution.getVariable(CreditBusinessConstants.IS_REJECTED));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postMcp3 for applicationId: " + execution.getVariable(CreditBusinessConstants.APPLICATION_ID) + " takeBackToListingPage: " + execution.getVariable(CreditBusinessConstants.TAKE_BACK_TO_LISTING_PAGE));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postMcp3");
	}
	
	private OpenArcRejectionInput setSpecialisationDetails(JSONObject mcpRequestFromGet, OpenArcRejectionInput openArcRejectionInput) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getSpecialisationDetails Start");
		Specilizations specilizations = null;
		try {
			if(null != mcpRequestFromGet.get("specializationCode")) {
				Double specilizationCode = (Double) mcpRequestFromGet.get("specializationCode");
				specilizations = apiCallsHelper.getSpecialisationDetails(String.valueOf(specilizationCode.intValue()));
				if(null != specilizations) {
					openArcRejectionInput.setSpecializationCode(Integer.parseInt(specilizations.getSpclmastcode()));
				}
			}
			
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error in fetching getSpecialisationDetails", e);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getSpecialisationDetails end ");
		return openArcRejectionInput;
	}
	
	private OpenArcRejectionInput setQualificationDetails(JSONObject mcpRequestFromGet, OpenArcRejectionInput openArcRejectionInput) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getQualificationDetails Start");
		Qualification qualificationMaster = null;
		try {
			if (null != mcpRequestFromGet.get("degree")) {
				qualificationMaster = apiCallsHelper.getQualificationDetails((String)mcpRequestFromGet.get("degree"));
				if(null != qualificationMaster) {

					openArcRejectionInput.setDegree(qualificationMaster.getQlfydesc());
				}
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error in fetching getQualificationDetails", e);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "getQualificationDetails end ");
		return openArcRejectionInput;
	}
	
	
}
