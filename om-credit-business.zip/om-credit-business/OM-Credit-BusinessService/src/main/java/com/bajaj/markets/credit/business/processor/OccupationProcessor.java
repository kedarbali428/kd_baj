package com.bajaj.markets.credit.business.processor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;

@Component
public class OccupationProcessor implements BaseProcessor {

	@Autowired
	ApplictionClient applictionClient;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASSNAME = EmailProcessor.class.getName();
	
	private ThreadLocal<Boolean> occupationUpdateFlag = new ThreadLocal<Boolean>();
	
	@Override
	public boolean initDataCopy(List<OfferDetailsBean> dataCources, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside OccupationProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		occupationUpdateFlag.set(false);
		try {
			dataCources.forEach(dataSource -> {
				if(!CollectionUtils.isEmpty(dataSource.getOccupations())){
					dataSource.getOccupations().forEach(occupation -> {
						occupationUpdateFlag.set(applictionClient.saveOccupation(occupation, applicantDataBean));
					});
					
					if(occupationUpdateFlag.get()) {
						logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside OccupationProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - occupation data processed for "+dataSource.getDataSourceName());
						throw new CreditBusinessException();
					} else {
						logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside OccupationProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - occupation data not processed for "+dataSource.getDataSourceName());
					}
				}
			});
		} catch (CreditBusinessException exception) {
			return true;
		} catch(Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside OccupationProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - occupation call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside OccupationProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return false;
	}
}