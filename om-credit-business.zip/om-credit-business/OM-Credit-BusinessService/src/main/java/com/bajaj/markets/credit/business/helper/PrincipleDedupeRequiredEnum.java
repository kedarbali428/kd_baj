package com.bajaj.markets.credit.business.helper;

public enum PrincipleDedupeRequiredEnum {

	LKBOL("11"), CVSOL("24"), PAYSSOL("15"), PAYBOL("15"), CVBOL("24");

	private final String value;
	
	private PrincipleDedupeRequiredEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

	public static PrincipleDedupeRequiredEnum getPrincipleDedupeRequiredEnum(String key) {
		try {
			return PrincipleDedupeRequiredEnum.valueOf(key);
		} catch (IllegalArgumentException | NullPointerException exception) {
			return null;
		}
	}
	
}
