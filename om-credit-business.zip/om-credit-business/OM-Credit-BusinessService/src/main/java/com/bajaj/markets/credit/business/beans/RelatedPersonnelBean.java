package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class RelatedPersonnelBean implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5374505946847046557L;
	
	@NotBlank
	private String fullName;
	@NotBlank
	@Size(min = 10, max = 10, message 
		      = "Mobile number  can not be less than 10 or greater than 10")
	@Digits(fraction = 0, integer = 10, message = "Mobile number can not be other than digits")
	private String mobileNumber;
	private Reference relationship;
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Reference getRelationship() {
		return relationship;
	}
	public void setRelationship(Reference relationship) {
		this.relationship = relationship;
	}
	@Override
	public String toString() {
		return "RelatedPersonnelBean [fullName=" + fullName + ", mobileNumber=" + mobileNumber + ", relationship="
				+ relationship + "]";
	}
	
}