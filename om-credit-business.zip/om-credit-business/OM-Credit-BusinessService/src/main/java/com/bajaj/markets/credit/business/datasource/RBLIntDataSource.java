package com.bajaj.markets.credit.business.datasource;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.AddressDetails;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.BFDLProspectDetails;
import com.bajaj.markets.credit.business.beans.BusinessOwnerDetails;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.Gender;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.MaritalStatus;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.beans.PersonalDetails;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResponseBean;
import com.bajaj.markets.credit.business.beans.SalariedDetail;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class RBLIntDataSource implements DataSource {
	
	@Value("${api.emicnsb.creditcardoffer.GET.url}")
	private String creditCardOfferUrl;
	
	@Value("${api.omreferencedatareferencedataservice.getmaritalstatus.get.url}")
	private String getmaritalStatusURL;
	
	@Value("${api.omreferencedatareferencedataservice.getgender.get.url}")
	private String getgenderURL;
	
	@Value("${api.omreferencedatareferencedataservice.location.pincode.get.url}")
	private String pinCodeUrl;
	
	@Value("${api.referencedata.offersource.GET.url}")
	private String getOfferSourceUrl;
	
	@Value("${RBL_OFFER_PRODUCTS}")
	private String rblOfferProducts;
	
	@Value("${CC.RBLIntDataSource.precedence}")
	private String precedence;
	
	@Autowired
	private CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private BFLLoggerUtil loggerUtil;
	
	private ObjectMapper mapper = new ObjectMapper();
	
	private static final String CLASSNAME = RBLIntDataSource.class.getName();
	
	@Override
	public void registerDataSource(DataSourceRegistry dataSourceRegistry) {
		dataSourceRegistry.registerDataSource(this);
		loggerUtil.info(CLASSNAME, BFLLoggerComponent.UTILITY, "registerDataSource - RBLIntDataSource registration done");
	}
	
	@Override
	public OfferDetailsBean initDataSource(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		OfferDetailsBean offerDetailsBean = new OfferDetailsBean();
		try {			
			offerDetailsBean.setPrecedence(Integer.parseInt(precedence));
			offerDetailsBean.setDataSourceName(this.getClass().getSimpleName());
			BFDLProspectDetails cardsProspectOfferDetails = getCardsProspectOfferDetails(applicantDataBean);
			
			if(null != cardsProspectOfferDetails) {
				PersonalDetails personalDetails = getPersonalDetailsForCards(cardsProspectOfferDetails, applicantDataBean.getOfferApiRequest().getDob());
				
				if(!StringUtils.isEmpty(cardsProspectOfferDetails.getCardLimit())) {
					populateOfferDetails(cardsProspectOfferDetails, applicantDataBean, offerDetailsBean);
				}
				populateUserProfileDetails(personalDetails, offerDetailsBean);
				populateDocumentDetails(personalDetails, offerDetailsBean);
				populateEmailDetails(personalDetails, offerDetailsBean);
				populateAddressDetails(cardsProspectOfferDetails, applicantDataBean, offerDetailsBean);
				populateOccupationDetails(cardsProspectOfferDetails, applicantDataBean, offerDetailsBean);
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - RBL Internal offer not found.");
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - Population process failed", e);
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
		return offerDetailsBean;
	}
	
	@SuppressWarnings("unchecked")
	private BFDLProspectDetails getCardsProspectOfferDetails(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getCardsProspectOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		
		try {
			BFDLProspectDetails prospectDetails = null;
			Map<String, String> params = new HashMap<String, String>();
			params.put("mobilenumber", applicantDataBean.getOfferApiRequest().getMobileNo());
			params.put("productcode", applicantDataBean.getProductCode());
			params.put("apputmSource", "");
			params.put("consent", "false");
			
			ResponseEntity<Object> offerApiResponse = (ResponseEntity<Object>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, creditCardOfferUrl, Object.class, params, null, applicantDataBean.getHeaders());
			if(null!=offerApiResponse && HttpStatus.OK.equals(offerApiResponse.getStatusCode()) && null!=offerApiResponse.getBody()) {
				ResponseBean responseBean = mapper.convertValue(offerApiResponse.getBody(), ResponseBean.class);
				prospectDetails = mapper.convertValue(responseBean.getPayload(), BFDLProspectDetails.class);
				if(null != prospectDetails) {
					logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getCardsProspectOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
					return prospectDetails;
				} else {
					logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getCardsProspectOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - prospect offer data not found");
					return null;
				}
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getCardsProspectOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - prospect offer data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getCardsProspectOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - failed", e);
			return null;
		}
	}
	
	private void populateOfferDetails(BFDLProspectDetails prospectDetails, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		List<AppOfferDetBean> offers = new ArrayList<>();
		if(null != prospectDetails) {
			List<String> rblProducts = new ArrayList<>();
			rblProducts = Arrays.asList(rblOfferProducts.split(","));
		
			String offersrckey = getOfferSrcKey("INTOFFTBL", applicantDataBean.getHeaders());
			
			if(null != offersrckey) {
				for(String l3prodCode : rblProducts) {
					AppOfferDetBean appOfferDetBean = new AppOfferDetBean();
					appOfferDetBean.setApplicationKey(Long.valueOf(applicantDataBean.getOfferApiRequest().getApplicationKey()));
					appOfferDetBean.setProductCode(l3prodCode);
					appOfferDetBean.setIsOfferAvailable(true);
					appOfferDetBean.setOfferAmt(new BigDecimal(prospectDetails.getCardLimit()));
					appOfferDetBean.setOfferSrcKey(Long.valueOf(offersrckey));
					appOfferDetBean.setIsCardHolder(prospectDetails.getIsCreditCardHolder());
					offers.add(appOfferDetBean);
				}
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - offersrckey not found");
			}
		}
	    offerDetailsBean.setOffers(offers);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
	}
	
	@SuppressWarnings("unchecked")
	private String getOfferSrcKey(String srccode, HttpHeaders headers) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getOfferSrcKey method - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("srccode", srccode);
			paramMap.put("srckey", "");
			ResponseEntity<Object> offerSourceResponse = (ResponseEntity<Object>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, getOfferSourceUrl, List.class, paramMap, null, headers);
			List<Object> offerSource = mapper.convertValue(offerSourceResponse.getBody(), new TypeReference<List<Object>>() {});
			
			String offerSour = offerSource.get(0).toString();
			org.activiti.engine.impl.util.json.JSONObject json = new org.activiti.engine.impl.util.json.JSONObject(offerSour);
			String offersrckey = json.get("offersrckey").toString();
			logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getOfferSrcKey method - ended");
			return offersrckey;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getOfferSrcKey method - failed", e);
			return null;
		}
	}
	
	private void populateUserProfileDetails(PersonalDetails personalDetails, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateUserProfileDetails method - started");
		List<UserProfileBean> userProfileBeans = new ArrayList<>();
		if(null != personalDetails) {
			UserProfileBean userProfileBean = new UserProfileBean();
			Name name = new Name();
			name.setFirstName(personalDetails.getFirstName());
			name.setMiddleName(personalDetails.getMiddleName());
			name.setLastName(personalDetails.getLastName());
			userProfileBean.setName(name);
			userProfileBean.setDateOfBirth(personalDetails.getDob());
			userProfileBean.setMobile(personalDetails.getMobileNo());
			if (!StringUtils.isEmpty(personalDetails.getMaritalStatus())) {
				userProfileBean.setMaritalStatusKey(getMaritalStatusKey(personalDetails.getMaritalStatus()));
			}
			if (!StringUtils.isEmpty(personalDetails.getGender())) {
				userProfileBean.setGenderKey(getGenderKey(personalDetails.getGender()));
			}
			userProfileBeans.add(userProfileBean);
		}
		offerDetailsBean.setUserProfileBeans(userProfileBeans);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateUserProfileDetails method - ended");
	}
	
	@SuppressWarnings("unchecked")
	private Long getMaritalStatusKey(final String maritalStatus) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getMaritalStatusKey method - started");
		try {
			ResponseEntity<List<MaritalStatus>> responseEntity = (ResponseEntity<List<MaritalStatus>>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, getmaritalStatusURL, List.class, null, null, new HttpHeaders());
			List<MaritalStatus> maritalStatusList;
			Long maritalStatusKey = null;
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				maritalStatusList = mapper.convertValue(responseEntity.getBody(),
						new TypeReference<List<MaritalStatus>>() {});
				for (MaritalStatus marStatus : maritalStatusList) {
					if ((marStatus.getMaritalStatusValue()).equalsIgnoreCase(maritalStatus)) {
						maritalStatusKey = marStatus.getMaritalStatusKey();
						break;
					}
				}
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getMaritalStatusKey method - ended");
				return maritalStatusKey;
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getMaritalStatusKey method - marital status not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getMaritalStatusKey method - failed", e);
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	private Long getGenderKey(final String gender) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getGenderKey method - started");
		try {
			ResponseEntity<List<Gender>> responseEntity = (ResponseEntity<List<Gender>>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, getgenderURL, List.class, null, null, new HttpHeaders());
			List<Gender> genderList;
			Long genderKey = null;
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				genderList = mapper.convertValue(responseEntity.getBody(), 
						new TypeReference<List<Gender>>() {});
				for (Gender genderObj : genderList) {
					if (genderObj.getGenderValue().equalsIgnoreCase(gender)) {
						genderKey = genderObj.getGenderKey();
						break;
					}
				}
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getGenderKey method - ended");
				return genderKey;
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getGenderKey method - gender data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getGenderKey method - failed", e);
			return null;
		}
	}
	
	private void populateDocumentDetails(PersonalDetails personalDetails, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateDocumentDetails method - started");
		List<DocumentDetails> documents = new ArrayList<>();
		if(null != personalDetails) {
			if(!StringUtils.isEmpty(personalDetails.getPan())) {
				DocumentDetails documentDetail = new DocumentDetails();
				documentDetail.setDocumentNameKey(1L);
				documentDetail.setDocumentNumber(personalDetails.getPan());
				documents.add(documentDetail);
			}
		}
		offerDetailsBean.setDocuments(documents);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateDocumentDetails method - ended");
	}
	
	private void populateEmailDetails(PersonalDetails personalDetails, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateEmailDetails method - started");
		List<Email> emails = new ArrayList<>();
		if(null != personalDetails) {
			if (!StringUtils.isEmpty(personalDetails.getPersonalEmailId())) {
				Email email = new Email();
				email.setEmail(personalDetails.getPersonalEmailId());
				email.setTypeKey(CreditBusinessConstants.PERSONAL_EMAIL_TYPE);
				emails.add(email);
			}
		}
		offerDetailsBean.setEmails(emails);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateEmailDetails method - ended");
	}
	
	private void populateAddressDetails(BFDLProspectDetails prospectDetails, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateAddressDetails method - started");
		List<Address> addresses = new ArrayList<>();
		if(null != prospectDetails) {
			List<AddressDetails> addressDetailsList = new ArrayList<>();
			
			AddressDetails currentAddress = new AddressDetails();
			currentAddress.setAddressType(AddressTypeEnum.CURRENT.getValue());
			currentAddress.setAddressLine1(prospectDetails.getCurrentAddressLine1());
			currentAddress.setAddressLine2(prospectDetails.getCurrentAddressLine2()+" "+prospectDetails.getCurrentAddressLine3());
			currentAddress.setPinCode(prospectDetails.getZipcode());
			currentAddress.setCity(prospectDetails.getCurrentCity());
			currentAddress.setState(prospectDetails.getCurrentState());
			
			AddressDetails permanentAddress = new AddressDetails();
			permanentAddress.setAddressType(AddressTypeEnum.PERMANENT.getValue());
			permanentAddress.setAddressLine1(prospectDetails.getPermanentAddressLine1());
			permanentAddress.setAddressLine2(prospectDetails.getPermanentAddressLine2()+" "+prospectDetails.getPermanentAddressLine3());
			permanentAddress.setPinCode(prospectDetails.getPermanentZipcode());
			permanentAddress.setCity(prospectDetails.getPermanentCity());
			permanentAddress.setState(prospectDetails.getPermanentState());
			
			AddressDetails officeAddress = new AddressDetails();
			officeAddress.setAddressType(AddressTypeEnum.OFFICE.getValue());
			officeAddress.setAddressLine1(prospectDetails.getOfficeAddressLine1());
			officeAddress.setAddressLine2(prospectDetails.getOfficeAddressLine2()+" "+prospectDetails.getOfficeAddressLine3());
			officeAddress.setPinCode(prospectDetails.getOfficePincode());
			officeAddress.setCity(prospectDetails.getOfficeCity());
			officeAddress.setState(prospectDetails.getOfficeState());
			
			addressDetailsList.add(currentAddress);
			addressDetailsList.add(permanentAddress);
			addressDetailsList.add(officeAddress);
			
			for(AddressDetails addressDetail : addressDetailsList) {
				Address address = new Address();
				address.setAddressTypeKey(addressDetail.getAddressType());
				address.setAddressLine1(addressDetail.getAddressLine1());
				address.setAddressLine2(addressDetail.getAddressLine2());
				address.setPincode(addressDetail.getPinCode());
				address.setAddressSource(CreditBusinessConstants.OFFER_API);
				if (!StringUtils.isEmpty(addressDetail.getPinCode())) {
					LocationAddressBean locationAddressBean = getLocationAddressBean(addressDetail, applicantDataBean.getHeaders());
					if(null != locationAddressBean) {
						address.setCityKey(null != locationAddressBean.getCityId() ? String.valueOf(locationAddressBean.getCityId()) : null);
						address.setPincodeKey(null != locationAddressBean.getPinId() ? String.valueOf(locationAddressBean.getPinId()) : null);
						address.setCountryKey(null != locationAddressBean.getCountryId() ? String.valueOf(locationAddressBean.getCountryId()) : null);
						address.setStateKey(null != locationAddressBean.getStateId() ? String.valueOf(locationAddressBean.getStateId()) : null);
					}
					addresses.add(address);
				}
			}
		}
		offerDetailsBean.setAddresses(addresses);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateAddressDetails method - ended");
	}
	
	@SuppressWarnings("unchecked")
	private LocationAddressBean getLocationAddressBean(AddressDetails addressDetail, HttpHeaders headers) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getLocationAddressBean method - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("pincode", addressDetail.getPinCode());
			ResponseEntity<LocationAddressBean> responseEntity = (ResponseEntity<LocationAddressBean>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, pinCodeUrl, LocationAddressBean.class, paramMap,
							null, headers);
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getLocationAddressBean method - ended");
				return responseEntity.getBody();
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getLocationAddressBean method - location address data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - getLocationAddressBean method - failed", e);
			return null;
		}
	}
	
	private void populateOccupationDetails(BFDLProspectDetails prospectDetails, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateOccupationDetails method - started");
		List<Occupation> occupations = new ArrayList<>();
		if(null != prospectDetails) {
			String employment = prospectDetails.getEmploymentType();
			if(!StringUtils.isEmpty(employment) && employment.equalsIgnoreCase("Self-Employed Professional")) {
				Occupation occupation = new Occupation();
				BusinessOwnerDetails businessOwnerDetails = new BusinessOwnerDetails();
				businessOwnerDetails.setBusinessName(prospectDetails.getNameOfCompanyBusiness());
				occupation.setBusinessOwnerDetails(businessOwnerDetails);
				occupation.setOcupationType(getReference(2l, "SEMP", "Self Employed"));
				occupations.add(occupation);
			} else if (!StringUtils.isEmpty(employment) && employment.equalsIgnoreCase("Salaried")) {
				Occupation occupation = new Occupation();
				SalariedDetail salariedDetail = new SalariedDetail();
				salariedDetail.setEmployerNameOther(prospectDetails.getNameOfCompanyBusiness());
				occupation.setSalariedDetail(salariedDetail);
				occupation.setOcupationType(getReference(1l, "SALR", "Salaried"));
				occupations.add(occupation);
			}
		}
		offerDetailsBean.setOccupations(occupations);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside RBLIntDataSource - populateOccupationDetails method - ended");
	}
	
	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;
	}
	
	private PersonalDetails getPersonalDetailsForCards(BFDLProspectDetails prospectDetails, String dob) {
		PersonalDetails personalDetails = null;
		if(null != prospectDetails) {
			personalDetails = new PersonalDetails();
			personalDetails.setFirstName(prospectDetails.getName());
			personalDetails.setMiddleName(prospectDetails.getMiddleName());
			personalDetails.setLastName(prospectDetails.getLastName());
			personalDetails.setDob(dob);
			personalDetails.setPan(prospectDetails.getPan());
			personalDetails.setMobileNo(prospectDetails.getMobileNumber());
			personalDetails.setMaritalStatus(prospectDetails.getMaritalStatus());
			personalDetails.setGender(prospectDetails.getGender());
			personalDetails.setPersonalEmailId(prospectDetails.getEmail());
		}
		return personalDetails;
	}
}