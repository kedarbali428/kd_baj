package com.bajaj.markets.credit.business.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.service.CreditBusinessOfferDetailsService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessOfferDetailsController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessOfferDetailsService creditBusinessOfferDetailsService;
	
	private static final String CLASS_NAME = CreditBusinessOfferDetailsController.class.getCanonicalName();
	
	@ApiOperation(value = "API to fetch offer amount.", notes = "API to fetch offer amount.", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fetch offer amount successfully.", response = Object.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@GetMapping(path = "${api.omcreditbusinessservice.offeramount.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getOfferAmount(
			@PathVariable(value = "applicationid") String applicationId,
			@RequestParam(name = "productCode") String productCode,
			@RequestHeader HttpHeaders headers){
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Started getOfferAmount in controller with Request:: applicationId : " + applicationId + "and productCode : "+productCode);
		Object offerDetailsObject = creditBusinessOfferDetailsService.getOfferAmount(applicationId, productCode);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"End getOfferAmount in controller with Response : " + offerDetailsObject);
		return new ResponseEntity<>(offerDetailsObject, HttpStatus.OK);
	}
}
