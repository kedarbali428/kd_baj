package com.bajaj.markets.credit.business.controller;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.Application;
import com.bajaj.markets.credit.business.beans.ApplicationInfo;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.FreshApplication;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OfferCase;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Resume;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBussinessApplicationController {

	@Autowired
	private Validator validator;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessService creditBusinessService;

	@Autowired
	CustomDefaultHeaders customHeader;
	
	@Value("${spring.session.enabled:false}")
	private boolean sessionEnabled;

	private static final String CLASS_NAME = CreditBussinessApplicationController.class.getCanonicalName();

	/**
	 * 
	 * @param 1)Check if application exists with mob dob and product code 2)Create
	 *                new application (not for PL)if application not exits 3)Get
	 *                user Profiles (userattribute key) 4) Update Profession
	 *                5)Update Application Stage to 5% 6)Check Applicant exists or
	 *                not 7) Start Activiti
	 * @param headers
	 * @return
	 */
	@Secured(value = {Role.SYSTEM, Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.SYSTEMPARTNER, Role.CUSTOMER })
	@ApiOperation(value = "create Credit Application and Start workflow", notes = "create Credit Application and Start workflow", httpMethod = "POST", response = ApplicationResponse.class)
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Successfully Created the Application and started the Workflow or resumed the application", response = ApplicationResponse.class),
			@ApiResponse(code = 422, message = "Bad input parameter", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Application Key or any parameter is not according the data type specified"),
			@ApiResponse(code = 500, message = "Some Internal Eror Occured", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unathenticated"),
			@ApiResponse(code = 403, message = "Unauthorized")})
	@CrossOrigin
	@PostMapping(path = "/v1/credit/applications", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApplicationResponse> createCreditApplication(@RequestBody Application applicationRequest,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Start createCreditApplication in controller with Request : " + applicationRequest);

		Set<ConstraintViolation<Application>> validationErrors = validator.validate(applicationRequest,
				!StringUtils.isEmpty(applicationRequest.getOfferId()) ? 
						OfferCase.class : 
							null != applicationRequest.getApplicationKey() ? 
									Resume.class : 
										FreshApplication.class
							);

		if (!CollectionUtils.isEmpty(validationErrors)) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Not a valid request");
			String message = "";
			if(validationErrors.stream().findFirst().isPresent()) {
				message = validationErrors.stream().findFirst().get().getMessage();
			}
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB-422", message));
		}

		ApplicationResponse applicationResponse = creditBusinessService.createCreditApplication(applicationRequest,
				headers);

		HttpHeaders httpHeaders = new HttpHeaders();
		if (null != customHeader && null != customHeader.getAuthtoken()) {
          	httpHeaders.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, CustomDefaultHeaders.AUTH_TOKEN);
			if (sessionEnabled) {
				httpHeaders.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, CreditBusinessConstants.HEADER_X_SESSION_TOKEN);
			}
			httpHeaders.set(CustomDefaultHeaders.AUTH_TOKEN, customHeader.getAuthtoken());
		}

		return new ResponseEntity<>(applicationResponse, httpHeaders, HttpStatus.CREATED);

	}

	/**
	 * fetch userprofiles,profession,product,mobile and dob
	 * 
	 * @param applicationid
	 * @param headers
	 * @return
	 */
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "API to fetch landing page application details", notes = "API to fetch landing page application details", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched landing page application details", response = Application.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found for given applicationId", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@CrossOrigin
	@GetMapping(path = "/v1/credit/applications/{applicationid}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Application> application(
			@PathVariable(value = "applicationid", required = true) String applicationid,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Start getApplication with applicationid : " + applicationid);

		Application application = creditBusinessService.getApplication(applicationid, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"End getApplication with applicationid : " + applicationid);

		return new ResponseEntity<>(application, HttpStatus.OK);

	}
	/**
	 * fetch userprofiles,profession,product,mobile and dob and name
	 * 
	 * @param applicationid
	 * @param headers
	 * @return
	 */
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.SYSTEM, Role.CUSTOMER})
	@ApiOperation(value = "API to fetch application details to expose to Esign UI ", notes = "API to fetch application details to expose to Esign UI", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched landing page application details", response = Application.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found for given applicationId", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@CrossOrigin
	@GetMapping(path = "/v1/credit/applicationsinfo/{applicationid}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApplicationInfo> applicationInfo(
			@PathVariable(value = "applicationid", required = true) String applicationid,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Start getapplicationInfo with applicationid : " + applicationid);

		ApplicationInfo applicationinfo = creditBusinessService.getApplicationInfo(applicationid, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"End getapplicationInfo with applicationid : " + applicationid);

		return new ResponseEntity<>(applicationinfo, HttpStatus.OK);

	}
	
	/**
	 * This API is used to create/resume application with different scenarios as below and starts the FLDG workflow process
	 * 1. campaign (offer id case)
	 * 2. application dedupe true
	 * 3. application dedeup false and create application
	 * 4. EP application resume
	 * 
	 * @param applicationRequest
	 * @param headers
	 * @return
	 */
	@Secured(value = {Role.SYSTEM, Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.SYSTEMPARTNER, Role.CUSTOMER })
	@ApiOperation(value = "create Credit Application and Start FLDG workflow", notes = "create Credit Application and Start FLDG workflow", httpMethod = "POST", response = ApplicationResponse.class)
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Successfully Created the Application and started the Workflow or resumed the application", response = ApplicationResponse.class),
			@ApiResponse(code = 422, message = "Bad input parameter", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Application Key or any parameter is not according the data type specified"),
			@ApiResponse(code = 500, message = "Some Internal Eror Occured", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unathenticated"),
			@ApiResponse(code = 403, message = "Unauthorized")})
	@CrossOrigin
	@PostMapping(path = "/v2/credit/applications", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApplicationResponse> createCreditApplicationV2(@RequestBody Application applicationRequest,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Start createCreditApplicationV2 in controller with Request : " + applicationRequest);
		Set<ConstraintViolation<Application>> validationErrors = validator.validate(applicationRequest,
				!StringUtils.isEmpty(applicationRequest.getOfferId()) ? 
						OfferCase.class : 
							null != applicationRequest.getApplicationKey() ? 
									Resume.class : 
										FreshApplication.class
							);

		if (!CollectionUtils.isEmpty(validationErrors)) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Not a valid request");
			String message = "";
			if(validationErrors.stream().findFirst().isPresent()) {
				message = validationErrors.stream().findFirst().get().getMessage();
			}
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB-422", message));
		}
		
		applicationRequest.setFldgApplication(Boolean.TRUE);
		ApplicationResponse applicationResponse = creditBusinessService.createCreditApplication(applicationRequest,
				headers);

		HttpHeaders httpHeaders = new HttpHeaders();
		if (null != customHeader && null != customHeader.getAuthtoken()) {
          	httpHeaders.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, CustomDefaultHeaders.AUTH_TOKEN);
			if (sessionEnabled) {
				httpHeaders.add(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, CreditBusinessConstants.HEADER_X_SESSION_TOKEN);
			}
			httpHeaders.set(CustomDefaultHeaders.AUTH_TOKEN, customHeader.getAuthtoken());
		}
		return new ResponseEntity<>(applicationResponse, httpHeaders, HttpStatus.CREATED);
	}

}
