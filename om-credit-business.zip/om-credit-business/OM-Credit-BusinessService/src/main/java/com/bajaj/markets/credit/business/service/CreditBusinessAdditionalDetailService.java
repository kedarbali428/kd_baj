package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.bajaj.markets.credit.business.beans.AdditionalDetail;
import com.bajaj.markets.credit.business.beans.AdditionalDetailLoans;
import com.bajaj.markets.credit.business.beans.AdditionalDetailPricing;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;

public interface CreditBusinessAdditionalDetailService {

	public ApplicationResponse saveAdditionalDetail(AdditionalDetail additionalDetail, HttpHeaders headers);

	public AdditionalDetail getAdditionalDetail(String applicationId, String l3ProductCode);

	public ResponseEntity<ApplicationResponse> saveLoansAdditionalDetail(AdditionalDetailLoans additionalDetail, HttpHeaders headers);

	public AdditionalDetailLoans getLoansAdditionalDetail(String applicationId, HttpHeaders headers);
	
	public AdditionalDetailPricing getPricing(String applicationId, HttpHeaders headers);


}
