package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

public class ProcessStatus implements Serializable{

	private static final long serialVersionUID = 2703536940790074418L;
	
	@NotBlank(message = "childStatus can not be null or empty")
	private String childStatus;
	
	private String applicationid;

	public String getChildStatus() {
		return childStatus;
	}

	public void setChildStatus(String childStatus) {
		this.childStatus = childStatus;
	}

	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	@Override
	public String toString() {
		return "ProcessStatus [childStatus=" + childStatus + ", applicationid=" + applicationid + "]";
	}
}
