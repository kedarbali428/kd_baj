package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class ProductList {
	private List<Product> productList;
	private Double requiredLoanAmout;
	private Double requiredTenor;
	private Double maxEligibility;
	private Double maxTenor;
	private Name name;
	private Double minLoanAmountRequired;
	private Double minTenorRequired;
	private String status;
	private Boolean isCardSelected;
	private Boolean isEpPricingHonoured;

	public Boolean getIsCardSelected() {
		return isCardSelected;
	}

	public void setIsCardSelected(Boolean isCardSelected) {
		this.isCardSelected = isCardSelected;
	}

	public Boolean getIsEpPricingHonoured() {
		return isEpPricingHonoured;
	}

	public void setIsEpPricingHonoured(Boolean isEpPricingHonoured) {
		this.isEpPricingHonoured = isEpPricingHonoured;
	}

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

	public Double getRequiredLoanAmout() {
		return requiredLoanAmout;
	}

	public void setRequiredLoanAmout(Double requiredLoanAmout) {
		this.requiredLoanAmout = requiredLoanAmout;
	}

	public Double getRequiredTenor() {
		return requiredTenor;
	}

	public void setRequiredTenor(Double requiredTenor) {
		this.requiredTenor = requiredTenor;
	}

	public Double getMaxEligibility() {
		return maxEligibility;
	}

	public void setMaxEligibility(Double maxEligibility) {
		this.maxEligibility = maxEligibility;
	}

	public Double getMaxTenor() {
		return maxTenor;
	}

	public void setMaxTenor(Double maxTenor) {
		this.maxTenor = maxTenor;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public Double getMinLoanAmountRequired() {
		return minLoanAmountRequired;
	}

	public void setMinLoanAmountRequired(Double minLoanAmountRequired) {
		this.minLoanAmountRequired = minLoanAmountRequired;
	}

	public Double getMinTenorRequired() {
		return minTenorRequired;
	}

	public void setMinTenorRequired(Double minTenorRequired) {
		this.minTenorRequired = minTenorRequired;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ProductList [productList=" + productList + ", requiredLoanAmout=" + requiredLoanAmout + ", requiredTenor=" + requiredTenor + ", maxEligibility="
				+ maxEligibility + ", maxTenor=" + maxTenor + ", name=" + name + ", minLoanAmountRequired=" + minLoanAmountRequired + ", minTenorRequired="
				+ minTenorRequired + ", status=" + status + "]";
	}

}
