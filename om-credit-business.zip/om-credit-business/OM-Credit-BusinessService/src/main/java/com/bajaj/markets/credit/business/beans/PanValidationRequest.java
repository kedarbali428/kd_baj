package com.bajaj.markets.credit.business.beans;

import com.bajaj.markets.credit.business.beans.validator.ValidString;

public class PanValidationRequest {

	@ValidString(pattern = "[A-Z]{3}P[A-Z]{1}[0-9]{4}[A-Z]{1}", message = "Invalid Pan")
	private String panNumber;

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

}
