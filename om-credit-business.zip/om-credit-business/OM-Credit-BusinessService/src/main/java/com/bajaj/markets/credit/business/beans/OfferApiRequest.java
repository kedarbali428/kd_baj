package com.bajaj.markets.credit.business.beans;

public class OfferApiRequest {
	private String offerId;
	private String mobileNo;
	private String dob;
	private String productCode;
	private String applicationKey;
	private String applicationUserAttributeKey;
	private String occupationTypeKey;
	private String pan;
	private String l2ProductCode;
	private String l1Productmastcode;

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getApplicationUserAttributeKey() {
		return applicationUserAttributeKey;
	}

	public void setApplicationUserAttributeKey(String applicationUserAttributeKey) {
		this.applicationUserAttributeKey = applicationUserAttributeKey;
	}
	
	public String getOfferId() {
		return offerId;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	public String getOccupationTypeKey() {
		return occupationTypeKey;
	}

	public void setOccupationTypeKey(String occupationTypeKey) {
		this.occupationTypeKey = occupationTypeKey;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getL2ProductCode() {
		return l2ProductCode;
	}

	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}

	public String getL1Productmastcode() {
		return l1Productmastcode;
	}

	public void setL1Productmastcode(String l1Productmastcode) {
		this.l1Productmastcode = l1Productmastcode;
	}

	@Override
	public String toString() {
		return "OfferApiRequest [offerId=" + offerId + ", mobileNo=" + mobileNo + ", dob=" + dob + ", productCode="
				+ productCode + ", applicationKey=" + applicationKey + ", applicationUserAttributeKey="
				+ applicationUserAttributeKey + ", occupationTypeKey=" + occupationTypeKey + ", pan=" + pan
				+ ", l2ProductCode=" + l2ProductCode + ", l1Productmastcode=" + l1Productmastcode + "]";
	}
}