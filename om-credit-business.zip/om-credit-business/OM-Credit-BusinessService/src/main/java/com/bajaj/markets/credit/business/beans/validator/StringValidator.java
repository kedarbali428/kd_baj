package com.bajaj.markets.credit.business.beans.validator;

import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;

@Component
public class StringValidator implements ConstraintValidator<ValidString, String> {

	private String pattern;

	@Override
	public void initialize(ValidString validStringAnnotation) {
		this.pattern = validStringAnnotation.pattern();
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		try {
			return Pattern.matches(pattern, value);
		} catch (Exception e) {
			BFLLoggerUtil.error(null, StringValidator.class.getCanonicalName(), 
					BFLLoggerComponent.UTILITY, "Exception occurred while validating string", e);
			return false;
		}
	}
	
	public boolean isValidString(String value, String regExPattern) {
		if(null == value || null == regExPattern || value.isBlank() || regExPattern.isBlank()) {
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("Invalid input for processing", "Invalid input for processing"));
		}
		this.pattern = regExPattern;
		return this.isValid(value, null);
	}

}
