package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class ProfileDetailsV2 implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6829208617296847398L;
	
	private String panNumber;
    @NotNull
    private String name;
    @NotNull
	private String personalEmailId;
    
	private Reference gender;
	@NotNull
	private Reference maritalStatus;
	
	private Reference residenceType;
	
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPersonalEmailId() {
		return personalEmailId;
	}
	public void setPersonalEmailId(String personalEmailId) {
		this.personalEmailId = personalEmailId;
	}
	public Reference getGender() {
		return gender;
	}
	public void setGender(Reference gender) {
		this.gender = gender;
	}
	public Reference getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(Reference maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public Reference getResidenceType() {
		return residenceType;
	}
	public void setResidenceType(Reference residenceType) {
		this.residenceType = residenceType;
	}
		
	@Override
	public String toString() {
		return "ProfileDetails [panNumber=" + panNumber + ", personalEmailId=" + personalEmailId + ", gender=" + gender
				+ ", maritalStatus=" + maritalStatus + ", residenceType=" + residenceType + "]";
	}
	
}
