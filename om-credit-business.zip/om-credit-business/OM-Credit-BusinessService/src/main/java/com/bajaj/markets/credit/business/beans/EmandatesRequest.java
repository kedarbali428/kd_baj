package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;

public class EmandatesRequest {

	private String name;

	private boolean isRecurring;

	private String frequency;

	private boolean sendMandateBitly;

	private String mandateBitlyUrl;

	private String transactionMessage;

	private String firstCollectionDate;

	private String numberOfPayments;

	private BigDecimal repaymentAmmount;

	private String validThrough;

	private String applicantKey;

	private Long mobileNumber;

	private String emailId;

	private String applicationKey;

	private String productCategoryCode;

	private String productCode;

	private String productMasterKey;

	private String principal;

	private String mandateExpiryDate;

	private String mandateCreationSource;

	private String mandateUpdateSource;

	private String chanelMandateRefId;

	private String chanelTransactionId;

	private String modeofPayment;

	private String status;

	private String micrCode;

	private String authenticationTime;

	private String umrn;

	private String enachId;

	private String authMode;

	private String mandateCategory;

	private BigDecimal limit;

	private String accountNumber;

	private String ifscCode;

	private String accountType;

	private String bankName;

	private String responseString;

	private String barcode;
	
	private Long mandateType;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean getIsRecurring() {
		return isRecurring;
	}

	public void setIsRecurring(boolean isRecurring) {
		this.isRecurring = isRecurring;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public boolean getSendMandateBitly() {
		return sendMandateBitly;
	}

	public void setSendMandateBitly(boolean sendMandateBitly) {
		this.sendMandateBitly = sendMandateBitly;
	}

	public String getMandateBitlyUrl() {
		return mandateBitlyUrl;
	}

	public void setMandateBitlyUrl(String mandateBitlyUrl) {
		this.mandateBitlyUrl = mandateBitlyUrl;
	}

	public String getTransactionMessage() {
		return transactionMessage;
	}

	public void setTransactionMessage(String transactionMessage) {
		this.transactionMessage = transactionMessage;
	}

	public String getFirstCollectionDate() {
		return firstCollectionDate;
	}

	public void setFirstCollectionDate(String firstCollectionDate) {
		this.firstCollectionDate = firstCollectionDate;
	}

	public String getNumberOfPayments() {
		return numberOfPayments;
	}

	public void setNumberOfPayments(String numberOfPayments) {
		this.numberOfPayments = numberOfPayments;
	}

	public BigDecimal getRepaymentAmmount() {
		return repaymentAmmount;
	}

	public void setRepaymentAmmount(BigDecimal repaymentAmmount) {
		this.repaymentAmmount = repaymentAmmount;
	}

	public String getValidThrough() {
		return validThrough;
	}

	public void setValidThrough(String validThrough) {
		this.validThrough = validThrough;
	}

	public String getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getProductCategoryCode() {
		return productCategoryCode;
	}

	public void setProductCategoryCode(String productCategoryCode) {
		this.productCategoryCode = productCategoryCode;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductMasterKey() {
		return productMasterKey;
	}

	public void setProductMasterKey(String productMasterKey) {
		this.productMasterKey = productMasterKey;
	}

	public String getPrincipal() {
		return principal;
	}

	public void setPrincipal(String principal) {
		this.principal = principal;
	}

	public String getChanelMandateRefId() {
		return chanelMandateRefId;
	}

	public void setChanelMandateRefId(String chanelMandateRefId) {
		this.chanelMandateRefId = chanelMandateRefId;
	}

	public String getChanelTransactionId() {
		return chanelTransactionId;
	}

	public void setChanelTransactionId(String chanelTransactionId) {
		this.chanelTransactionId = chanelTransactionId;
	}

	public String getModeofPayment() {
		return modeofPayment;
	}

	public void setModeofPayment(String modeofPayment) {
		this.modeofPayment = modeofPayment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public String getAuthenticationTime() {
		return authenticationTime;
	}

	public void setAuthenticationTime(String authenticationTime) {
		this.authenticationTime = authenticationTime;
	}

	public String getUmrn() {
		return umrn;
	}

	public void setUmrn(String umrn) {
		this.umrn = umrn;
	}

	public String getEnachId() {
		return enachId;
	}

	public void setEnachId(String enachId) {
		this.enachId = enachId;
	}

	public String getAuthMode() {
		return authMode;
	}

	public void setAuthMode(String authMode) {
		this.authMode = authMode;
	}

	public String getMandateCategory() {
		return mandateCategory;
	}

	public void setMandateCategory(String mandateCategory) {
		this.mandateCategory = mandateCategory;
	}

	public BigDecimal getLimit() {
		return limit;
	}

	public void setLimit(BigDecimal limit) {
		this.limit = limit;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getResponseString() {
		return responseString;
	}

	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}

	public String getMandateExpiryDate() {
		return mandateExpiryDate;
	}

	public void setMandateExpiryDate(String mandateExpiryDate) {
		this.mandateExpiryDate = mandateExpiryDate;
	}

	public String getMandateCreationSource() {
		return mandateCreationSource;
	}

	public void setMandateCreationSource(String mandateCreationSource) {
		this.mandateCreationSource = mandateCreationSource;
	}

	public String getMandateUpdateSource() {
		return mandateUpdateSource;
	}

	public void setMandateUpdateSource(String mandateUpdateSource) {
		this.mandateUpdateSource = mandateUpdateSource;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	
	

	public Long getMandateType() {
		return mandateType;
	}

	public void setMandateType(Long mandateType) {
		this.mandateType = mandateType;
	}

	@Override
	public String toString() {
		return "EmandateRequest [name=" + name + ", isRecurring=" + isRecurring + ", frequency=" + frequency
				+ ", sendMandateBitly=" + sendMandateBitly + ", mandateBitlyUrl=" + mandateBitlyUrl
				+ ", transactionMessage=" + transactionMessage + ", firstCollectionDate=" + firstCollectionDate
				+ ", numberOfPayments=" + numberOfPayments + ", repaymentAmmount=" + repaymentAmmount
				+ ", validThrough=" + validThrough + ", applicantKey=" + applicantKey + ", mobileNumber=" + mobileNumber
				+ ", emailId=" + emailId + ", applicationKey=" + applicationKey + ", productCategoryCode="
				+ productCategoryCode + ", productCode=" + productCode + ", productMasterKey=" + productMasterKey
				+ ", principal=" + principal + ", mandateExpiryDate=" + mandateExpiryDate + ", mandateCreationSource="
				+ mandateCreationSource + ", mandateUpdateSource=" + mandateUpdateSource + ", chanelMandateRefId="
				+ chanelMandateRefId + ", chanelTransactionId=" + chanelTransactionId + ", modeofPayment="
				+ modeofPayment + ", status=" + status + ", micrCode=" + micrCode + ", authenticationTime="
				+ authenticationTime + ", umrn=" + umrn + ", enachId=" + enachId + ", authMode=" + authMode
				+ ", mandateCategory=" + mandateCategory + ", limit=" + limit + ", accountNumber=" + accountNumber
				+ ", ifscCode=" + ifscCode + ", accountType=" + accountType + ", bankName=" + bankName
				+ ", responseString=" + responseString + ", barcode=" + barcode + ", mandateType=" + mandateType + "]";
	}

	
}
