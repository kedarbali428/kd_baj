package com.bajaj.markets.credit.business.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.joda.time.PeriodType;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.amazonaws.services.sns.model.PublishResult;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationStageDetails;
import com.bajaj.markets.credit.business.beans.BankMaster;
import com.bajaj.markets.credit.business.beans.CibilResponse;
import com.bajaj.markets.credit.business.beans.CibilTypeAndScore;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.PrincipalBean;
import com.bajaj.markets.credit.business.beans.Product;
import com.bajaj.markets.credit.business.beans.ProductList;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.DialerIntegrationException;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.bajaj.markets.insurance.remoteapitrackinglib.bean.TypedRemoteApiTrackingVO;
import com.bajaj.markets.insurance.remoteapitrackinglib.service.impl.RemoteApiTrackingImpl;
import com.google.gson.Gson;

@Component
public class DiallerIntegrationProcessor {
	
	private static final String STATUS_FAILURE = "FAILURE";
	private static final String STATUS_SUCCESS = "SUCCESS";
	private static final String CREDIT_BUSINESS_DIALER_EVENT_PUBLISH_SOURCE = "CREDIT_DIALER";
	private static final String CREDIT_BUSINESS_DIALER_EVENT_PUBLISH_TARGET = "CREDIT_DIALER_EVENT_PUBLISH";

	private static final String CLASS_NAME = DiallerIntegrationProcessor.class.getName();

	@Autowired
	private CreditBusinessApiCallsHelper creditBusinessApiCallsHelper;

	@Autowired
	private CustomDefaultHeaders customHeaders;

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private Environment env;

	@Autowired
	private PublisherService publisherService;

	@Autowired
	private MasterDataRedisClientHelper masterDataRedisClientHelper;
	@Value("${business.aip.ok.flag.rejectionsrc}")
	private List<String> isAipOkRejectionSrc;
	@Value("${business.mcp.ok.flag.rejectionsrc}")
	private List<String> isMcpOkRejectionSrc;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String getChildApplicationsUrl;
	
	@Autowired
	private RemoteApiTrackingImpl apiTracking;

	public void pushLead(String applicationId) {
		try {
			pushlead(applicationId);
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Dialer lead push failed for applicationId " + applicationId);
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "Dialer lead push failed for applicationId " + applicationId, e);
			throw new DialerIntegrationException(HttpStatus.INTERNAL_SERVER_ERROR,
					"applicationId ia " + applicationId + "Dialer lead push failed Error message " + e.getMessage());
		}
	}

	private void pushlead(String applicationId) {
		JSONObject dialerLeadRequest = new JSONObject();
		PublishResult publishResult = null;
		TypedRemoteApiTrackingVO remoteApiTrackingVO = new TypedRemoteApiTrackingVO();
		try {
			remoteApiTrackingVO.setApplicationId(Long.valueOf(applicationId));
			remoteApiTrackingVO.setRequestTimeStamp(System.currentTimeMillis());
			remoteApiTrackingVO.setTargetApi(env.getProperty("aws.publisher.applicationupdate.topic.arn"));
			remoteApiTrackingVO.setSource(CREDIT_BUSINESS_DIALER_EVENT_PUBLISH_SOURCE);
			remoteApiTrackingVO.setTarget(CREDIT_BUSINESS_DIALER_EVENT_PUBLISH_TARGET);
			remoteApiTrackingVO.setCorrelationId(logger.getCorrelationID());
			
			customHeaders.setAuthtoken(creditBusinessApiCallsHelper.getInternalToken(applicationId));
	
			UserProfileBean userProfile = getUserProfileObject(applicationId);
	
			Map<String, Object> diallerMap = new HashMap<>();
			populateStageParams(applicationId, diallerMap);
	
			JSONObject applicationJsonObject = getApplicationJsonObject(applicationId,
					userProfile.getApplicationUserAttributeKey());
	
			populateApplicationParameters(applicationId, applicationJsonObject, diallerMap);
			diallerMap.put("mobileNumber", userProfile.getMobile());
	
			populateL2Params(applicationJsonObject, diallerMap);
	
			populateUtmParams(applicationJsonObject, diallerMap);
	
			populateSecuredFields(diallerMap, applicationJsonObject);
			populateAppScore(applicationJsonObject, diallerMap);
	
			diallerMap.put("bfsdSystem", "OM");
	
			populateSalary(applicationJsonObject, diallerMap);
	
			// populateCompanyCategory(applicationJsonObject, diallerMap);
	
			populateLoanAmountRequired(applicationId, diallerMap, applicationJsonObject);
	
			populateApplicationCreditStatus(applicationJsonObject, diallerMap);
	
			populateOccupation(applicationJsonObject, diallerMap);
	
			populateL3Fields(applicationJsonObject, diallerMap);
	
			populateL4Fields(applicationId, diallerMap, applicationJsonObject);
	
			populateCibilScore(applicationId, diallerMap, applicationJsonObject, userProfile.getApplicationUserAttributeKey());
	
			populateSchedularType(diallerMap);
	
			populateIsMcpOkAndIsAipFlag(applicationId, applicationJsonObject, diallerMap);
			populateAge(diallerMap,userProfile);
	
			dialerLeadRequest = getFinalDialerLeadRequestObject(diallerMap);
			remoteApiTrackingVO.setRequestPayload(dialerLeadRequest.toString());
			
			publishResult = publishToTopic(dialerLeadRequest);
			remoteApiTrackingVO.setResponsePayload(publishResult.getMessageId());
			remoteApiTrackingVO.setStatus(STATUS_SUCCESS);
	
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"publishResult messageId: " + publishResult.getMessageId());
		} catch (Exception exception) {
			remoteApiTrackingVO.setStatus(STATUS_FAILURE);
			remoteApiTrackingVO.setError(ExceptionUtils.getStackTrace(exception));
			
			logger.warn(CLASS_NAME, BFLLoggerComponent.UTILITY, "Dialer lead push failed for the application: " + applicationId, exception);
			throw exception;
		} finally {
			remoteApiTrackingVO.setResponseTimeStamp(System.currentTimeMillis());
			apiTracking.saveRemoteRequestResponse(remoteApiTrackingVO);
		}
	}

	private void populateSchedularType(Map<String, Object> diallerMap) {
		diallerMap.put("schedularType", "FRESH");
	}

	private PublishResult publishToTopic(JSONObject dialerLeadRequest) {
		PublishResult publishResult = publisherService.publish(
				env.getProperty("aws.publisher.applicationupdate.topic.arn"), createEventMessage(dialerLeadRequest));
		return publishResult;
	}

	@SuppressWarnings("unchecked")
	private JSONObject getFinalDialerLeadRequestObject(Map<String, Object> diallerMap) {
		JSONObject dialerLeadRequest = new JSONObject();
		dialerLeadRequest.put("leadData", new JSONObject(diallerMap));
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"dialler json " + CreditBusinessHelper.objectToJson(dialerLeadRequest));
		return dialerLeadRequest;
	}

	private JSONObject getApplicationJsonObject(String applicationId, String applicationUserAttributeKey) {
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put(CreditBusinessConstants.APPLICATION_ID, applicationId);
		queryParam.put("userattributekey", applicationUserAttributeKey);
		return creditBusinessApiCallsHelper.callApi(
				env.getProperty("api.omcreditapplicationservice.mcpdetails.get.url"), HttpMethod.GET, queryParam, null,
				JSONObject.class);
	}

	private UserProfileBean getUserProfileObject(String applicationId) {
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put(CreditBusinessConstants.APPLICATION_ID, applicationId);
		return creditBusinessApiCallsHelper.getUserProfile(queryParam);
	}

	private void populateSecuredFields(Map<String, Object> diallerMap, JSONObject applicationJsonObject) {
		diallerMap.put("propertyIdentified",
				Objects.nonNull(applicationJsonObject.get("propertyIdentifiedFlag"))
						? applicationJsonObject.get("propertyIdentifiedFlag").toString()
						: "");

		diallerMap.put("hlProductIntent",
				Objects.nonNull(applicationJsonObject.get("hlProductIntent"))
						? applicationJsonObject.get("hlProductIntent").toString()
						: "");
		populateBtBankName(applicationJsonObject, diallerMap);
	}

	private void populateCibilScore(String applicationId, Map<String, Object> diallerMap,
			JSONObject applicationJsonObject, String userAttributeKey) {
		
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("applicationid", applicationId);
		queryParams.put("userattributekey", userAttributeKey);
		DocumentDetails documentDetails = creditBusinessApiCallsHelper.getDocumentDetail(queryParams, 2l);
		
		String cibilReferenceKey = null != documentDetails && null != documentDetails.getDocumentNumber() && 
				documentDetails.getDocumentNumber().matches("\\d+") ? documentDetails.getDocumentNumber() : null;
		
		CibilResponse[] cibilResponse = creditBusinessApiCallsHelper.getCibilReference(applicationId, "", null, cibilReferenceKey);
		if (null != cibilResponse && cibilResponse.length > 0) {
			List<CibilTypeAndScore> cibilTypeAndScore = cibilResponse[0].getCibilTypeAndScore();
			if (cibilTypeAndScore.size() > 0) {
				diallerMap.put("CIBILScore", cibilTypeAndScore.get(0).getScoreV3());
			}
		}
	}

	private void populateL4Fields(String applicationId, Map<String, Object> diallerMap,
			JSONObject applicationJsonObject) {
		try {
			ApplicationDetail applicationDetail = creditBusinessApiCallsHelper
					.getChildApplications(applicationId, "true").get(0);
			diallerMap.put("l3ProductCode", applicationDetail.getL3ProductCode());
			diallerMap.put("l3Productdescription", applicationDetail.getL3ProductDesc());
			diallerMap.put("loanTypeCode", applicationDetail.getL4ProductCode());
			diallerMap.put("loanTypedescription", applicationDetail.getL4ProductDesc());
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Error occured while fetching child pplications", e);
			logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"It seems there is no child application yet created");
		}

	}

	@SuppressWarnings("unchecked")
	private void populateL3Fields(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		String intent = applicationJsonObject.get("hlProductIntent") != null
				? applicationJsonObject.get("hlProductIntent").toString()
				: "";
		List<Map<String, Object>> mcpAddressDetails = (List<Map<String, Object>>) applicationJsonObject
				.get("mcpAddressDetails");
		if (mcpAddressDetails != null && mcpAddressDetails.get(0) != null) {
			List<Map<String, Object>> principleProductDetailsArr = (List<Map<String, Object>>) mcpAddressDetails.get(0)
					.get("principleProductDetails");
			if (Objects.nonNull(principleProductDetailsArr) && !principleProductDetailsArr.isEmpty()) {
				Set<String> existingCustomerPrinciple = new HashSet<>();
				Set<String> offerL3 = new HashSet<>();
				Set<String> offerPrincipal = new HashSet<>();
				Set<String> riskOfferType = new HashSet<>();
				Set<String> rejectedL3Code = new HashSet<>();
				Set<String> rejectionCodes = new HashSet<>();
				Set<String> principalRejected = new HashSet<>();
				Map<String, Set<String>> principleL3Map = new HashMap<>();
				Map<String, Set<String>> principleRejectedL3Map = new HashMap<>();
				for (Map<String, Object> principleProductDetails : principleProductDetailsArr) {
					String l3Code = principleProductDetails.get("principleProductCode").toString();
					String principleKey = principleProductDetails.get("principleKey").toString();
					if (!StringUtils.isBlank(intent) && !l3Code.contains(intent)) {
						continue;
					}
					principleL3Map.computeIfAbsent(principleKey, k -> new HashSet<String>()).add(l3Code);
					List<Map<String, Object>> rejectionList = (List<Map<String, Object>>) principleProductDetails
							.get("rejectionList");
					if (Objects.nonNull(rejectionList) && !rejectionList.isEmpty()) {
						for (Map<String, Object> rejectionObj : rejectionList) {
							List<String> rejectionCodeList = (List<String>) rejectionObj.get("rejectCodeList");
							for (String rejectionCode : rejectionCodeList) {
								rejectionCodes.add(l3Code + "_" + rejectionCode);
							}
						}
						rejectedL3Code.add(l3Code);
						principleRejectedL3Map.computeIfAbsent(principleKey, k -> new HashSet<String>()).add(l3Code);
					}
					List<Map<String, Object>> offerDetails = (List<Map<String, Object>>) principleProductDetails
							.get("offerDetails");
					if (Objects.nonNull(offerDetails) && !offerDetails.isEmpty()) {
						for (Map<String, Object> offerObj : offerDetails) {
							String isOfferAvailable = offerObj.get("isOfferAvailable").toString();
							String offerSource = Objects.nonNull(offerObj.get("offerSource"))
									? offerObj.get("offerSource").toString()
									: "";
							String offerPriority = Objects.nonNull(offerObj.get("offerPriority"))
									? offerObj.get("offerPriority").toString()
									: "";

							if (isOfferAvailable.equals("true") || offerSource.equals("1")) {
								offerL3.add(l3Code);
								offerPrincipal.add(principleKey);
							}
							if (Objects.nonNull(offerObj.get("riskOfferType")) && offerPriority.equals("1")) {
								riskOfferType.add(offerObj.get("riskOfferType").toString());
							}
						}
					}

					String existingCustomerType = Objects.nonNull(principleProductDetails.get("existingCustomerType"))
							? principleProductDetails.get("existingCustomerType").toString()
							: "";
					if ("true".equals(existingCustomerType)) {
						existingCustomerPrinciple.add(principleKey);
					}
				}

				for (String principleKey : principleL3Map.keySet()) {
					if (Objects.nonNull(principleRejectedL3Map.get(principleKey))
							&& principleL3Map.get(principleKey).equals(principleRejectedL3Map.get(principleKey))) {
						principalRejected.add(principleKey);
					}
				}
				List<PrincipalBean> principalDetails = creditBusinessApiCallsHelper.getPrincipalDetails();
				List<String> rejectedPrincipleNames = new ArrayList<>();
				for (String principleKey : principalRejected) {
					PrincipalBean principalBean = principalDetails.stream().filter(
							principleDetail -> principleDetail.getPrinciplekey().toString().equals(principleKey))
							.findFirst().orElse(new PrincipalBean());
					rejectedPrincipleNames.add(principalBean.getPrincipleName());
				}

				diallerMap.put("principalRejected", String.join(",", rejectedPrincipleNames));
				diallerMap.put("L3CodeRejected", String.join(",", rejectedL3Code));
				diallerMap.put("L3Code_rejectionCode", String.join(",", rejectionCodes));

				List<String> offerPrincipleNames = new ArrayList<>();
				for (String principleKey : offerPrincipal) {
					PrincipalBean principalBean = principalDetails.stream().filter(
							principleDetail -> principleDetail.getPrinciplekey().toString().equals(principleKey))
							.findFirst().orElse(new PrincipalBean());
					offerPrincipleNames.add(principalBean.getPrincipleName());
				}

				diallerMap.put("IsofferavailablePrincipal", String.join(",", offerPrincipleNames));
				diallerMap.put("Isofferavailable", String.join(",", offerL3));
				diallerMap.put("riskOfferType", !CollectionUtils.isEmpty(riskOfferType)?riskOfferType.toArray()[0]:null);

				List<String> existingCustomerPrincipleNames = new ArrayList<>();
				for (String principleKey : existingCustomerPrinciple) {
					PrincipalBean principalBean = principalDetails.stream().filter(
							principleDetail -> principleDetail.getPrinciplekey().toString().equals(principleKey))
							.findFirst().orElse(new PrincipalBean());
					existingCustomerPrincipleNames.add(principalBean.getPrincipleName());
				}

				diallerMap.put("principal_IsExistingCust", String.join(",", existingCustomerPrincipleNames));
			}
		}

	}

	@SuppressWarnings("unchecked")
	private void populateApplicationParameters(String applicationId, JSONObject applicationJsonObject,
			Map<String, Object> diallerMap) {
		diallerMap.put("appCreationDate", applicationJsonObject.get("appCreationDate").toString());
		diallerMap.put("appId", applicationId);
		diallerMap.put("appStatus",
				Objects.nonNull(applicationJsonObject.get("applicationStatusDesc"))
						? applicationJsonObject.get("applicationStatusDesc").toString()
						: "");
		populateCity(applicationJsonObject, diallerMap);
		populateBranch(applicationJsonObject, diallerMap);
		if (Objects.nonNull(applicationJsonObject.get("appSegmentation"))) {
			Map<String, Object> appSegmentation = (Map<String, Object>) applicationJsonObject.get("appSegmentation");
			diallerMap.put("customerSegment",
					Objects.nonNull(appSegmentation.get("segDesc")) ? appSegmentation.get("segDesc").toString() : "");
			diallerMap.put("segment",
					Objects.nonNull(appSegmentation.get("customerProfileSegment")) ? appSegmentation.get("customerProfileSegment").toString() : "");
			diallerMap.put("subSegment",
					Objects.nonNull(appSegmentation.get("microSegment")) ? appSegmentation.get("microSegment").toString() : "");
			diallerMap.put("incomeBand",
					Objects.nonNull(appSegmentation.get("profileIncomeSegment")) ? appSegmentation.get("profileIncomeSegment").toString() : "");
				 
		}
		populateDispositionFields(applicationJsonObject, diallerMap);
		populateMaxEligibility(applicationJsonObject, diallerMap);
	}

	@SuppressWarnings("unchecked")
	private void populateMaxEligibility(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		if (Objects.nonNull(applicationJsonObject.get("applicationLoanDetails"))) {
			Map<String, Object> applicationLoanDetails = (Map<String, Object>) applicationJsonObject
					.get("applicationLoanDetails");
			diallerMap.put("maxloanAmountEligible",
					Objects.nonNull(applicationLoanDetails.get("maxeligibility"))
							? applicationLoanDetails.get("maxeligibility").toString()
							: "");
		}

	}

	@SuppressWarnings("unchecked")
	private void populateDispositionFields(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		if (Objects.nonNull(applicationJsonObject.get("dispositionDetails"))) {
			Map<String, Object> dispositionDetails = (Map<String, Object>) applicationJsonObject
					.get("dispositionDetails");
			diallerMap.put("telcallerDispositionStatus",
					Objects.nonNull(dispositionDetails.get("dispositionStatus"))
							? dispositionDetails.get("dispositionStatus").toString()
							: "");
			diallerMap.put("telcallerSubDispositionStatus",
					Objects.nonNull(dispositionDetails.get("dispositionSubStatus"))
							? dispositionDetails.get("dispositionSubStatus").toString()
							: "");
			diallerMap.put("followUpDate",
					Objects.nonNull(dispositionDetails.get("followUpDate"))
							? dispositionDetails.get("followUpDate").toString()
							: "");
			diallerMap.put("followUpTime",
					Objects.nonNull(dispositionDetails.get("followUpTime"))
							? dispositionDetails.get("followUpTime").toString()
							: "");
		}
	}

	private void populateLoanAmountRequired(String applicationId, Map<String, Object> diallerMap,
			JSONObject applicationJsonObject) {
		Long percentageCompletion = Objects.nonNull(applicationJsonObject.get("subStagePercentage"))
				? Long.valueOf(applicationJsonObject.get("subStagePercentage").toString())
				: null;
		if (Objects.nonNull(percentageCompletion) && percentageCompletion >= 50) {
			ProductList productList = creditBusinessApiCallsHelper.getProductListForApplication(applicationId);
			if (!CollectionUtils.isEmpty(productList.getProductList())) {
				Product listingProduct = productList.getProductList().stream().filter(prod -> {
					if (prod.getL3productCode() != null && prod.getL4ProductCode() != null) {
						return true;
					}
					return false;
				}).findFirst().orElse(new Product());
				diallerMap.put("loanAmountRequired",
						Objects.nonNull(listingProduct.getRequiredLoanAmount())
								? listingProduct.getRequiredLoanAmount().toString()
								: "");

			}
		}
	}

	@SuppressWarnings("unchecked")
	private void populateCompanyCategory(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		if (applicationJsonObject.get("mcpAddressDetails") != null) {
			List<Map<String, Object>> mcpAddressDetails = (List<Map<String, Object>>) applicationJsonObject
					.get("mcpAddressDetails");
			if (mcpAddressDetails != null && mcpAddressDetails.get(0) != null) {
				List<Map<String, Object>> principleProductDetailsArr = (List<Map<String, Object>>) mcpAddressDetails
						.get(0).get("principleProductDetails");
				if (Objects.nonNull(principleProductDetailsArr) && !principleProductDetailsArr.isEmpty()) {
					Map<String, Object> principleProductDetails = principleProductDetailsArr.get(0);
					if (Objects.nonNull(principleProductDetails.get("employerType"))) {
						Optional<String> employeeTypeCode = creditBusinessApiCallsHelper.getEmployeeTypes().stream()
								.filter(type -> type.getEmployertypekey().toString()
										.equals(principleProductDetails.get("employerType").toString()))
								.map(type -> type.getEmployertypecode()).findFirst();
						diallerMap.put("companyCategory", employeeTypeCode.orElse(""));

					}
				}
			}
		}
	}

	private void populateStageParams(String applicationId, Map<String, Object> diallerMap) {
		ApplicationStageDetails stageDetails = creditBusinessApiCallsHelper.getStageDetails(applicationId);
		diallerMap.put("percentageCompletion", stageDetails.getPercentageCompletion().toString());

		diallerMap.put("stageInTime", stageDetails.getStageInTime());

		diallerMap.put("Stage", stageDetails.getStageDesc());
		diallerMap.put("subStage", stageDetails.getSubStageDesc());
	}

	@SuppressWarnings("unchecked")
	private void populateL2Params(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		if (applicationJsonObject.get("prodCategory") != null) {
			Map<String, Object> productCategory = (Map<String, Object>) applicationJsonObject.get("prodCategory");
			diallerMap.put("l2ProductCode",
					Objects.nonNull(productCategory.get("prodCatCode")) ? productCategory.get("prodCatCode").toString()
							: "");
			diallerMap.put("productL2Description",
					Objects.nonNull(productCategory.get("prodCatDesc")) ? productCategory.get("prodCatDesc").toString()
							: "");
		}
	}

	@SuppressWarnings("unchecked")
	private void populateOccupation(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		if (applicationJsonObject.get("occupation") != null) {
			Map<String, Object> occupation = (Map<String, Object>) applicationJsonObject.get("occupation");
			if (occupation.get("ocupationType") != null) {
				Map<String, Object> ocupationType = (Map<String, Object>) occupation.get("ocupationType");
				if (Objects.nonNull(ocupationType.get("key"))) {
					diallerMap.put("occupationType", masterDataRedisClientHelper
							.getOccupationDesciptionForKey(Long.valueOf(ocupationType.get("key").toString())));
					;
				}
			}
			if (occupation.get("salariedDetail") != null) {
				Map<String, Object> salariedDetail = (Map<String, Object>) occupation.get("salariedDetail");
				if (salariedDetail.get("employerName") != null) {
					Map<String, Object> employerName = (Map<String, Object>) salariedDetail.get("employerName");
                    if (Objects.nonNull(employerName.get("key"))) {
                        JSONObject employerMaster = creditBusinessApiCallsHelper
                                .getEmployerMaster(Long.valueOf(employerName.get("key").toString()));
                        if (Objects.nonNull(employerMaster)) {
                            diallerMap.put("companyCategory",
                                    Objects.nonNull(employerMaster.get("emprMastSubcategory"))
                                            ? employerMaster.get("emprMastSubcategory").toString()
                                            : "");
                        } else {
                            diallerMap.put("companyCategory", "");
                        }
                    } else {
                        diallerMap.put("companyCategory", "");
                    }
                    
                }
                String employerNameOther = "";
                if (salariedDetail.get("employerNameOther") != null) {
                    employerNameOther = String.valueOf(salariedDetail.get("employerNameOther"));
                }
                diallerMap.put("Other_Employee", employerNameOther);

			}
		}
	}

	@SuppressWarnings("unchecked")
	private void populateUtmParams(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		if (applicationJsonObject.get("additionalParameterDetail") != null) {
			Map<String, Object> additionalParameterDetail = (Map<String, Object>) applicationJsonObject
					.get("additionalParameterDetail");
			diallerMap.put("sourcingChannel",
					Objects.nonNull(additionalParameterDetail.get("utmChannel"))
							? additionalParameterDetail.get("utmChannel").toString()
							: "");
			diallerMap.put("utmCampaign",
					Objects.nonNull(additionalParameterDetail.get("utmCampaign"))
							? additionalParameterDetail.get("utmCampaign").toString()
							: "");
			diallerMap.put("utmMedium",
					Objects.nonNull(additionalParameterDetail.get("utmMedium"))
							? additionalParameterDetail.get("utmMedium").toString()
							: "");
			diallerMap.put("utmSource",
					Objects.nonNull(additionalParameterDetail.get("utmSource"))
							? additionalParameterDetail.get("utmSource").toString()
							: "");
		}
	}

	private void populateAppScore(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		if (applicationJsonObject.get("appScoreDetails") != null) {
			JSONObject appScore = CreditBusinessHelper.getJSONObject(applicationJsonObject.get("appScoreDetails"));
			diallerMap.put("appScore",
					Objects.nonNull(appScore.get("finalScore")) ? appScore.get("finalScore").toString() : "");
		}
	}

	@SuppressWarnings("unchecked")
	private void populateSalary(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		List<Map<String, Object>> estimatedNetMonthlySalaryList = (List<Map<String, Object>>) applicationJsonObject
				.get("estimatedNetMonthlySalaryDetails");
		if (Objects.nonNull(estimatedNetMonthlySalaryList) && !estimatedNetMonthlySalaryList.isEmpty()) {
			Map<String, Object> estimatedNetMonthlySalaryMap = estimatedNetMonthlySalaryList.get(0);
			diallerMap.put("netSalary",
					Objects.nonNull(estimatedNetMonthlySalaryMap.get("salaryAmount"))
							? estimatedNetMonthlySalaryMap.get("salaryAmount").toString()
							: "");
		}
	}

	private void populateBtBankName(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		if (Objects.nonNull(applicationJsonObject.get("btBankMasterKey"))
				&& !("null".equals(applicationJsonObject.get("btBankMasterKey")))) {

			BankMaster[] bankDetails = creditBusinessApiCallsHelper
					.getBankDetails(Long.valueOf(applicationJsonObject.get("btBankMasterKey").toString()));
			if (bankDetails.length > 0) {
				diallerMap.put("btBankName", bankDetails[0].getBankName());
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void populateCity(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		String currentAddressTypeKey = masterDataRedisClientHelper
				.getAddressTypeKeyForCode(CreditBusinessConstants.CURRENT_ADDR).toString();
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "currentAddressTypeKey = " + currentAddressTypeKey);
		/*
		 * if (Objects.nonNull(applicationJsonObject.get("cityKey"))) {
		 * diallerMap.put("city", creditBusinessApiCallsHelper
		 * .getCityDetails(applicationJsonObject.get("cityKey").toString()).getCityname(
		 * )); }
		 */
		if (applicationJsonObject.get("addressList") != null) {
			List<Map<String, Object>> addressList = (List<Map<String, Object>>) applicationJsonObject
					.get("addressList");

			Optional<Map<String, Object>> currentAddressObject = addressList.stream()
					.filter(addressObj -> addressObj.get("addressTypeKey").toString().equals(currentAddressTypeKey))
					.findFirst();
			if (currentAddressObject.isPresent()) {
				diallerMap.put("city", creditBusinessApiCallsHelper
						.getCityDetails(currentAddressObject.get().get("cityKey").toString()).getCityname());
			} else {
				diallerMap.put("city", "");
			}

		}
	}

	private void populateBranch(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		if (Objects.nonNull(applicationJsonObject.get("bflBranchKey"))) {
			try {
				diallerMap.put("loanApplicationBranch", creditBusinessApiCallsHelper
						.getBranchDetails("1111",applicationJsonObject.get("bflBranchKey").toString()).getBranchName());
			} catch (Exception e) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Could not find branch details");
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Some error occured during fething branch details ", e);
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void populateApplicationCreditStatus(JSONObject applicationJsonObject, Map<String, Object> diallerMap) {
		if (applicationJsonObject.get("creditStatus") != null) {
			Map<String, Object> creditStatusMap = (Map<String, Object>) applicationJsonObject.get("creditStatus");

			try {
				diallerMap.put("crediStatusEligibility", Objects.nonNull(creditStatusMap.get("creditEligibilityStatus"))
						? masterDataRedisClientHelper.getLookupValueByLookupCodeAndSortTxt("CREDITSTS",
								creditStatusMap.get("creditEligibilityStatus").toString()).getValue()
						: "");
				diallerMap
						.put("disbursementCreditStatus",
								Objects.nonNull(creditStatusMap.get("creditDisbursementStatus"))
										? masterDataRedisClientHelper
												.getLookupValueByLookupCodeAndSortTxt("CREDITSTS",
														creditStatusMap.get("creditDisbursementStatus").toString())
												.getValue()
										: "");
			} catch (Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
						"Some error occured during setting up credit status ", e);
			}

		}
	}

	private EventMessage createEventMessage(Object payload) {
		Map<String, String> headers = new HashMap<>();
		headers.put(CreditBusinessConstants.AUTH_TOKEN, customHeaders.getAuthtoken());
		headers.put(CreditBusinessConstants.CMPT_CORR_ID, customHeaders.getCmptcorrid());
		EventMessage eventMessage = new EventMessage();
		eventMessage.setEventName("APPLICATION_UPDATE");
		eventMessage.setEventType("UPDATE");
		eventMessage.setPayload(payload);
		eventMessage.setHeaders(headers);
		return eventMessage;
	}

	private void populateIsMcpOkAndIsAipFlag(String applicationId, JSONObject applicationJsonObject,
			Map<String, Object> diallerMap) {
		List<String> isAipOkProducts = new ArrayList<>();
		List<String> isMcpOkProducts = new ArrayList<>();
		try {
			String eligibleProductObject = getEligibleProductsForApplication(applicationId);
			if(null != eligibleProductObject) {
				Gson g=new Gson();
				JSONArray eligibleProducts = g.fromJson(eligibleProductObject, JSONArray.class);
				for(Object eligibleProduct : eligibleProducts) {
					 JSONObject eligibleProductForApplication = CreditBusinessHelper.getJSONObject(eligibleProduct);
					 String isEligible = (String) eligibleProductForApplication.get("iseligible");
					 String source = (String) eligibleProductForApplication.get("source");
					if("TRUE".equals(isEligible) && isMcpOkRejectionSrc.contains(source)) {
						isMcpOkProducts.add((String) eligibleProductForApplication.get("l3ProductCode"));
					}
					if("TRUE".equals(isEligible) && isAipOkRejectionSrc.contains(source)) {
						isAipOkProducts.add((String) eligibleProductForApplication.get("l3ProductCode"));
					}
					
				}
			}
			diallerMap.put("mcpOkProducts", StringUtils.join(isMcpOkProducts, ","));
			diallerMap.put("aipOkProducts", StringUtils.join(isAipOkProducts, ","));
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
					"Exception while setting mcp and aip flag for dialer.", e);
		}
	}

	private String getEligibleProductsForApplication(String applicationId) {
			Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put(CreditBusinessConstants.APPLICATION_ID, applicationId);
		return creditBusinessApiCallsHelper.callApi(
				env.getProperty("api.omcreditapplicationservice.eligible.status.products.get.url"), HttpMethod.GET, queryParam, null,
				String.class);
	}

    private void populateAge(Map<String, Object> diallerMap, UserProfileBean userProfile) {
        if (!StringUtils.isEmpty(userProfile.getDateOfBirth())) {
            Integer age = calculateAge(userProfile.getDateOfBirth());
            diallerMap.put("Age", age.toString());
        } else {
            diallerMap.put("Age", "");
        }
    }

        public Integer calculateAge(String dateOfBirth) {
            LocalDate birthDate = new LocalDate(dateOfBirth);
            LocalDate now = new LocalDate();
            Period period = new Period(birthDate, now, PeriodType.yearMonthDay());
            return period.getYears();

        }
}