package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class BflRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String applicationId;
	private String firstName; 
	private String middleName;
	private String lastName;
	private String mob;
	private String dob;
	private String pan;
	private String mobile;
	private String pinCode;
	private String city;
	private String email;
	private String officialEmail;
	private String occupationType;
	private String userAttributeKey;
	private String l2ProductCode;
	private Long principleKey;
	private String hlProductIntent;
	private String productCode;
	private String principalName;
	
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOfficialEmail() {
		return officialEmail;
	}
	public void setOfficialEmail(String officialEmail) {
		this.officialEmail = officialEmail;
	}
	public String getOccupationType() {
		return occupationType;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public String getUserAttributeKey() {
		return userAttributeKey;
	}
	public void setUserAttributeKey(String userAttributeKey) {
		this.userAttributeKey = userAttributeKey;
	}
	public String getL2ProductCode() {
		return l2ProductCode;
	}
	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}
	public Long getPrincipleKey() {
		return principleKey;
	}
	public void setPrincipleKey(Long principleKey) {
		this.principleKey = principleKey;
	}
	
	public String getHlProductIntent() {
		return hlProductIntent;
	}
	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}
	
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getPrincipalName() {
		return principalName;
	}
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}
	@Override
	public String toString() {
		return "BflRequest [applicationId=" + applicationId + ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", mob=" + mob + ", dob=" + dob + ", pan=" + pan + ", mobile=" + mobile
				+ ", pinCode=" + pinCode + ", city=" + city + ", email=" + email + ", officialEmail=" + officialEmail
				+ ", occupationType=" + occupationType + ", userAttributeKey=" + userAttributeKey + ", l2ProductCode="
				+ l2ProductCode + ", principleKey=" + principleKey + ", hlProductIntent=" + hlProductIntent
				+ ", productCode=" + productCode + ", principalName=" + principalName + "]";
	}

}