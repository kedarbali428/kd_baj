package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Business;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CAICWA;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.DoctorSelfEmployed;

public class BusinessOwnerDetails implements Serializable {

	private static final long serialVersionUID = 2703536940790674845L;

	@NotBlank(groups = Business.class, message = "businessName cannot be null or empty")
	private String businessName;

	@NotNull(groups = Business.class, message = "businessType cannot be null or empty")
	private Reference businessType;

	@NotNull(groups = Business.class, message = "natureOfBusiness cannot be null or empty")
	private Reference natureOfBusiness;

	private Reference industryType;

	private Reference anualTurnover;

	@NotNull(groups = Business.class, message = "businessVintage cannot be null or empty")
	private String businessVintage;

	private String proprieterName;

	private String businessPan;

	private String gstNumber;

	private BigDecimal profitAfterTax;

	private BigDecimal averageBankBalance;
	
	private String netMonthlyIncome;

	private Integer presentBusinessVintage;
	
	private String officetype;
	
	@NotNull(groups = {DoctorSelfEmployed.class}, message = "qualification can not be null")
	private Reference qualification;
	
	private Reference specialization;
	
	private String otherSpecialization;
	
	@NotNull(groups = {DoctorSelfEmployed.class}, message = "yearOfGraduation can not be null")
	private Integer yearOfGraduation;
	
	private Integer yearOfPostGraduation;
	
	private Reference regCouncil;
	
	private String doctorRegistrationNumber;
	
	private Reference hospital;
	
	private String hospitalNameOther;
	
	@NotBlank(groups = {DoctorSelfEmployed.class}, message = "practiceType can not be null")
	private String practiceType;
	
	@NotNull(groups = CAICWA.class, message = "caRegistrationNumber cannot be null or empty")
	private String caRegistrationNumber;
	
	@NotNull(groups = CAICWA.class, message = "certificateOfPracticeYear cannot be null or empty")
	private Integer certificateOfPracticeYear;

	private Reference shopStatus;
	
	private Reference corporateLinkageType;
	
	private Reference businessNature;

	public String getBusinessPan() {
		return businessPan;
	}

	public void setBusinessPan(String businessPan) {
		this.businessPan = businessPan;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public Reference getNatureOfBusiness() {
		return natureOfBusiness;
	}

	public void setNatureOfBusiness(Reference natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}

	public Reference getIndustryType() {
		return industryType;
	}

	public void setIndustryType(Reference industryType) {
		this.industryType = industryType;
	}

	public Reference getAnualTurnover() {
		return anualTurnover;
	}

	public void setAnualTurnover(Reference anualTurnover) {
		this.anualTurnover = anualTurnover;
	}

	public String getBusinessVintage() {
		return businessVintage;
	}

	public void setBusinessVintage(String businessVintage) {
		this.businessVintage = businessVintage;
	}

	public String getProprieterName() {
		return proprieterName;
	}

	public void setProprieterName(String proprieterName) {
		this.proprieterName = proprieterName;
	}

	public BigDecimal getProfitAfterTax() {
		return profitAfterTax;
	}

	public void setProfitAfterTax(BigDecimal profitAfterTax) {
		this.profitAfterTax = profitAfterTax;
	}

	public BigDecimal getAverageBankBalance() {
		return averageBankBalance;
	}

	public void setAverageBankBalance(BigDecimal averageBankBalance) {
		this.averageBankBalance = averageBankBalance;
	}

	public Reference getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Reference businessType) {
		this.businessType = businessType;
	}
	
	public String getNetMonthlyIncome() {
		return netMonthlyIncome;
	}

	public void setNetMonthlyIncome(String netMonthlyIncome) {
		this.netMonthlyIncome = netMonthlyIncome;
	}

	public Integer getPresentBusinessVintage() {
		return presentBusinessVintage;
	}

	public void setPresentBusinessVintage(Integer presentBusinessVintage) {
		this.presentBusinessVintage = presentBusinessVintage;
	}

	public String getOfficetype() {
		return officetype;
	}

	public void setOfficetype(String officetype) {
		this.officetype = officetype;
	}

	public Reference getQualification() {
		return qualification;
	}

	public void setQualification(Reference qualification) {
		this.qualification = qualification;
	}

	public Reference getSpecialization() {
		return specialization;
	}

	public void setSpecialization(Reference specialization) {
		this.specialization = specialization;
	}

	public String getOtherSpecialization() {
		return otherSpecialization;
	}

	public void setOtherSpecialization(String otherSpecialization) {
		this.otherSpecialization = otherSpecialization;
	}

	public Integer getYearOfGraduation() {
		return yearOfGraduation;
	}

	public void setYearOfGraduation(Integer yearOfGraduation) {
		this.yearOfGraduation = yearOfGraduation;
	}

	public Integer getYearOfPostGraduation() {
		return yearOfPostGraduation;
	}

	public void setYearOfPostGraduation(Integer yearOfPostGraduation) {
		this.yearOfPostGraduation = yearOfPostGraduation;
	}

	public Reference getRegCouncil() {
		return regCouncil;
	}

	public void setRegCouncil(Reference regCouncil) {
		this.regCouncil = regCouncil;
	}

	public String getDoctorRegistrationNumber() {
		return doctorRegistrationNumber;
	}

	public void setDoctorRegistrationNumber(String doctorRegistrationNumber) {
		this.doctorRegistrationNumber = doctorRegistrationNumber;
	}

	public Reference getHospital() {
		return hospital;
	}

	public void setHospital(Reference hospital) {
		this.hospital = hospital;
	}

	public String getHospitalNameOther() {
		return hospitalNameOther;
	}

	public void setHospitalNameOther(String hospitalNameOther) {
		this.hospitalNameOther = hospitalNameOther;
	}

	public String getPracticeType() {
		return practiceType;
	}

	public void setPracticeType(String practiceType) {
		this.practiceType = practiceType;
	}

	public String getCaRegistrationNumber() {
		return caRegistrationNumber;
	}

	public void setCaRegistrationNumber(String caRegistrationNumber) {
		this.caRegistrationNumber = caRegistrationNumber;
	}

	public Integer getCertificateOfPracticeYear() {
		return certificateOfPracticeYear;
	}

	public void setCertificateOfPracticeYear(Integer certificateOfPracticeYear) {
		this.certificateOfPracticeYear = certificateOfPracticeYear;
	}
	
	public Reference getShopStatus() {
		return shopStatus;
	}

	public void setShopStatus(Reference shopStatus) {
		this.shopStatus = shopStatus;
	}

	public Reference getCorporateLinkageType() {
		return corporateLinkageType;
	}

	public void setCorporateLinkageType(Reference corporateLinkageType) {
		this.corporateLinkageType = corporateLinkageType;
	}

	
	public Reference getBusinessNature() {
		return businessNature;
	}

	public void setBusinessNature(Reference businessNature) {
		this.businessNature = businessNature;
	}

	@Override
	public String toString() {
		return "BusinessOwnerDetails [businessName=" + businessName + ", businessType=" + businessType
				+ ", natureOfBusiness=" + natureOfBusiness + ", industryType=" + industryType + ", anualTurnover="
				+ anualTurnover + ", businessVintage=" + businessVintage + ", proprieterName=" + proprieterName
				+ ", businessPan=" + businessPan + ", gstNumber=" + gstNumber + ", profitAfterTax=" + profitAfterTax
				+ ", averageBankBalance=" + averageBankBalance + ", netMonthlyIncome=" + netMonthlyIncome
				+ ", presentBusinessVintage=" + presentBusinessVintage + ", officetype=" + officetype
				+ ", qualification=" + qualification + ", specialization=" + specialization + ", otherSpecialization="
				+ otherSpecialization + ", yearOfGraduation=" + yearOfGraduation + ", yearOfPostGraduation="
				+ yearOfPostGraduation + ", regCouncil=" + regCouncil + ", doctorRegistrationNumber="
				+ doctorRegistrationNumber + ", hospital=" + hospital + ", hospitalNameOther=" + hospitalNameOther
				+ ", practiceType=" + practiceType + ", caRegistrationNumber=" + caRegistrationNumber
				+ ", certificateOfPracticeYear=" + certificateOfPracticeYear + ", shopStatus=" + shopStatus
				+ ", corporateLinkageType=" + corporateLinkageType + ", businessNature=" + businessNature + "]";
	}
}
