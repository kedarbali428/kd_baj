package com.bajaj.markets.credit.business.listner;

import java.util.ArrayList;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class MasterData {

	@Autowired
	BFLLoggerUtilExt logger;

	final ObjectMapper mapper = new ObjectMapper();

	private static final String CLASS_NAME = MasterData.class.getCanonicalName();
	
	public void setResiType(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start setResiType");
		ArrayList<?> outputArray = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		execution.setVariable(CreditBusinessConstants.RESI_TYPE_LIST, outputArray);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End setResiType");
	}

	@SuppressWarnings("unchecked")
	public void setOccupation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start setOccupation");
		ArrayList<Map<String, Object>> outputArray = (ArrayList<Map<String, Object>>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		execution.setVariable(CreditBusinessConstants.OCCUPATION_LIST, outputArray);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End setOccupation");
	}

	@SuppressWarnings("unchecked")
	public void getEmailTypes(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start getEmailTypes");
		ArrayList<Map<String, Object>> outputArray = (ArrayList<Map<String, Object>>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		execution.setVariable(CreditBusinessConstants.EMAILTYPE_LIST, outputArray);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End getEmailTypes");
	}
 
	@SuppressWarnings("unchecked")
	public void getGenders(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start getGenders");
		ArrayList<Map<String, Object>> outputArray = (ArrayList<Map<String, Object>>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		execution.setVariable(CreditBusinessConstants.GENDER_LIST, outputArray);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End getGenders");
	}
	
	@SuppressWarnings("unchecked")
	public void setMaritalStatus(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start setMaritalStatus");
		ArrayList<Map<String, Object>> outputArray = (ArrayList<Map<String, Object>>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		execution.setVariable("maritalStatusList", outputArray);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End setMaritalStatus");
	}
	
	public void postGetCity(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetCity");
		execution.setVariable(CreditBusinessConstants.CITYNAME, null);
		JSONObject pincodeDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (null != pincodeDetails) {
			String city = null != pincodeDetails.get(CreditBusinessConstants.CITYNAME) ? pincodeDetails.get(CreditBusinessConstants.CITYNAME).toString() : null;
			execution.setVariable(CreditBusinessConstants.CITYNAME, city);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetCity");
	}
}
