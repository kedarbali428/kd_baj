package com.bajaj.markets.credit.business.beans;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicantProfileDetails{
	private long applicantKey;

	@Temporal(TemporalType.DATE)
	private Date apltDateOfBirth;

	private BigDecimal apltGrossMthIncome;

	private Integer apltIsActive;

	private BigDecimal apltNetMthIncome;

	private String apltStatus;

	private Integer genderKey;

	private Integer langKey;

	private Integer maritalStatusKey;

	private Integer nationalityKey;

	private Integer salutationKey;
	
	private Long residenceTypeKey;
	
	private ApplicantNameDetails nameDetails;

	private ApplicantPANDetails panDetails;

	public ApplicantProfileDetails() {
		super();
	}

	public long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Date getApltDateOfBirth() {
		return apltDateOfBirth;
	}

	public void setApltDateOfBirth(Date apltDateOfBirth) {
		this.apltDateOfBirth = apltDateOfBirth;
	}

	public BigDecimal getApltGrossMthIncome() {
		return apltGrossMthIncome;
	}

	public void setApltGrossMthIncome(BigDecimal apltGrossMthIncome) {
		this.apltGrossMthIncome = apltGrossMthIncome;
	}

	public Integer getApltIsActive() {
		return apltIsActive;
	}

	public void setApltIsActive(Integer apltIsActive) {
		this.apltIsActive = apltIsActive;
	}

	public BigDecimal getApltNetMthIncome() {
		return apltNetMthIncome;
	}

	public void setApltNetMthIncome(BigDecimal apltNetMthIncome) {
		this.apltNetMthIncome = apltNetMthIncome;
	}

	public String getApltStatus() {
		return apltStatus;
	}

	public void setApltStatus(String apltStatus) {
		this.apltStatus = apltStatus;
	}

	public Integer getGenderKey() {
		return genderKey;
	}

	public void setGenderKey(Integer genderKey) {
		this.genderKey = genderKey;
	}

	public Integer getLangKey() {
		return langKey;
	}

	public void setLangKey(Integer langKey) {
		this.langKey = langKey;
	}

	public Integer getMaritalStatusKey() {
		return maritalStatusKey;
	}

	public void setMaritalStatusKey(Integer maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}

	public Integer getNationalityKey() {
		return nationalityKey;
	}

	public void setNationalityKey(Integer nationalityKey) {
		this.nationalityKey = nationalityKey;
	}

	public Integer getSalutationKey() {
		return salutationKey;
	}

	public void setSalutationKey(Integer salutationKey) {
		this.salutationKey = salutationKey;
	}

	public Long getResidenceTypeKey() {
		return residenceTypeKey;
	}

	public void setResidenceTypeKey(Long residenceTypeKey) {
		this.residenceTypeKey = residenceTypeKey;
	}

	public ApplicantNameDetails getNameDetails() {
		return nameDetails;
	}

	public void setNameDetails(ApplicantNameDetails nameDetails) {
		this.nameDetails = nameDetails;
	}

	public ApplicantPANDetails getPanDetails() {
		return panDetails;
	}

	public void setPanDetails(ApplicantPANDetails panDetails) {
		this.panDetails = panDetails;
	}

	@Override
	public String toString() {
		return "ApplicantProfileDetails [applicantKey=" + applicantKey + ", apltDateOfBirth=" + apltDateOfBirth + ", apltGrossMthIncome=" + apltGrossMthIncome
				+ ", apltIsActive=" + apltIsActive + ", apltNetMthIncome=" + apltNetMthIncome + ", apltStatus=" + apltStatus + ", genderKey=" + genderKey
				+ ", langKey=" + langKey + ", maritalStatusKey=" + maritalStatusKey + ", nationalityKey=" + nationalityKey + ", salutationKey=" + salutationKey
				+ ", residenceTypeKey=" + residenceTypeKey + ", nameDetails=" + nameDetails + ", panDetails=" + panDetails + "]";
	}

	
	
}