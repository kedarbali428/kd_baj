package com.bajaj.markets.credit.business.helper;

import java.util.HashMap;
import java.util.Map;

public enum OfferType {
	QULFD(2), LINE(1), APPRD(3);
	

	private final int offerTypeKey;

	private static final Map<String, Integer> offerKey = new HashMap<>();
	
	OfferType(int offerType) {
		this.offerTypeKey = offerType;
	}

	static {
		for (OfferType d : OfferType.values()) {
			offerKey.put(d.name(), d.offerTypeKey);
		}
	}

	public int getOfferTypeKey() {
		return offerTypeKey;
	}

	public static int getOfferType(String offerCode) {
		return offerKey.get(offerCode);
	}

}
