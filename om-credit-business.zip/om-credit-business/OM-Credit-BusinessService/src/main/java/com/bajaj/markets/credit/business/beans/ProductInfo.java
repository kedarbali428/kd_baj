package com.bajaj.markets.credit.business.beans;

public class ProductInfo {

	private String applicationKey;
	private String productCategoryCode;
	private String productCode;
	private String principal;
	private String productMasterKey;

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getProductCategoryCode() {
		return productCategoryCode;
	}

	public void setProductCategoryCode(String productCategoryCode) {
		this.productCategoryCode = productCategoryCode;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getPrincipal() {
		return principal;
	}

	public void setPrincipal(String principal) {
		this.principal = principal;
	}

	public String getProductMasterKey() {
		return productMasterKey;
	}

	public void setProductMasterKey(String productMasterKey) {
		this.productMasterKey = productMasterKey;
	}

	@Override
	public String toString() {
		return "ProductInfo [applicationKey=" + applicationKey + ", productCategoryCode=" + productCategoryCode
				+ ", productCode=" + productCode + ", principal=" + principal + ", productMasterKey=" + productMasterKey
				+ "]";
	}

}
