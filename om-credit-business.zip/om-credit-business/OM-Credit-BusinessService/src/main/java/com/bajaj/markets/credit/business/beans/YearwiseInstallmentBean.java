package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class YearwiseInstallmentBean {

	private String year;
	private String principal;
	private String interest;
	private String total;
	private String policyCode;
	private List<MonthwiseInstallmentBean> monthlyInstallment;
	
	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getPrincipal() {
		return principal;
	}

	public void setPrincipal(String principal) {
		this.principal = principal;
	}

	public String getInterest() {
		return interest;
	}

	public void setInterest(String interest) {
		this.interest = interest;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getPolicyCode() {
		return policyCode;
	}

	public void setPolicyCode(String policyCode) {
		this.policyCode = policyCode;
	}

	public List<MonthwiseInstallmentBean> getMonthlyInstallment() {
		return monthlyInstallment;
	}

	public void setMonthlyInstallment(List<MonthwiseInstallmentBean> monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}

	@Override
	public String toString() {
		return "YearwiseInstallmentBean [year=" + year + ", principal=" + principal + ", interest=" + interest
				+ ", total=" + total + ", monthlyInstallment=" + monthlyInstallment + "]";
	}
	
	


}
