package com.bajaj.markets.credit.business.listner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.OMProductToBauProduct;
import com.google.gson.Gson;

@Component
public class Analytics {

	private static final String SALRYSOURCE_BFLPERFIOS = "BFLPERFIOS";
	private static final String LOANAGAINSTPROPERTYBALTRANSFER = "LAPBT";
	private static final String HOMELOANBALANCETRANSFER = "HLBT";
	private static final String LOANAGAINSTPROPERTY = "LAP";
	private static final String HOMELOANFRESH = "HLF";
	private static final String ACCOUNTTYPE_HOUSINGLOAN = "02";
	private static final String ACCOUNTTYPE = "44";
	private static final String ACCOUNTTYPE_PROPERTYLOAN = "03";
	
	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private McpCheck mcpCheck;
	
	@Autowired
	private CreditBusinessApiCallsHelper apiCallsHelper;

	private static final String CLASS_NAME = Analytics.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void preAppScore(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAppScore");
		JSONObject appScoreRequest = new JSONObject();
		JSONObject mcp2Request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		JSONObject cibilJson = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.CIBIL_JSON));

		ResidenceMaster resitype = mcpCheck.getResidanceType(mcp2Request);
		if (resitype != null) {
			appScoreRequest.put(CreditBusinessConstants.RESIDENCE_STATUS, resitype.getResidenceValue());
		}

		JSONObject maritalStatus = getMaritalStatus(execution, mcp2Request);
		if (maritalStatus != null) {
			appScoreRequest.put(CreditBusinessConstants.MARITALSTATUS, maritalStatus.get(CreditBusinessConstants.MARITALSTATUSVALUE));
		}

		appScoreRequest.put(CreditBusinessConstants.APPLICANT_ID, "1234");
		appScoreRequest.put(CreditBusinessConstants.APPLICATIONID, execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		appScoreRequest.put(CreditBusinessConstants.CIBIL_RESPONSE, cibilJson);
		appScoreRequest.put(CreditBusinessConstants.CITY, execution.getVariable(CreditBusinessConstants.CITY));
		appScoreRequest.put(CreditBusinessConstants.L2_PRODUCT_CODE, execution.getVariable(CreditBusinessConstants.PRODUCTCODE));
		appScoreRequest.put(CreditBusinessConstants.OCCUPATION_TYPE, execution.getVariable(CreditBusinessConstants.OCCUPATIONTYPECODE));

		execution.setVariable(CreditBusinessConstants.PAYLOAD, appScoreRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preAppScore");
	}

	@SuppressWarnings("unchecked")
	public void postAppScore(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postAppScore");
		JSONObject appScoreResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.APPSCORE, null);
		execution.setVariable(CreditBusinessConstants.LRSCORE, null);
		execution.setVariable(CreditBusinessConstants.MLSCORE, null);
		execution.setVariable(CreditBusinessConstants.LRSCOREV2, null);
		execution.setVariable(CreditBusinessConstants.APPSCORE_UPDATE, Boolean.FALSE);
		if (null != appScoreResponse) {
				String appscore = null != appScoreResponse.get(CreditBusinessConstants.FINALSCORE)
						? String.valueOf(((Double) appScoreResponse.get(CreditBusinessConstants.FINALSCORE)).intValue())
						: null;
				if (!StringUtils.isEmpty(appscore) || null!=appScoreResponse.get("hmlScoreDetails")) {
					execution.setVariable(CreditBusinessConstants.APPSCORE, appscore);
					execution.setVariable(CreditBusinessConstants.LRSCORE,
							null != appScoreResponse.get(CreditBusinessConstants.LRSCORE)
									? String.valueOf(((Double) appScoreResponse.get(CreditBusinessConstants.LRSCORE)).intValue())
									: null);
					execution.setVariable(CreditBusinessConstants.MLSCORE,
							null != appScoreResponse.get(CreditBusinessConstants.MLSCORE)
									? String.valueOf(((Double) appScoreResponse.get(CreditBusinessConstants.MLSCORE)).intValue())
									: null);
					execution.setVariable(CreditBusinessConstants.LRSCOREV2,
							null != appScoreResponse.get(CreditBusinessConstants.LRSCOREV2)
									? String.valueOf(((Double) appScoreResponse.get(CreditBusinessConstants.LRSCOREV2)).intValue())
									: null);
					execution.setVariable(CreditBusinessConstants.APPSCORE_UPDATE, Boolean.TRUE);
				}
			
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, appScoreResponse);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postAppScore");
	}

	@SuppressWarnings("unchecked")
	public void preGetCityForApScore(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preGetCityForApScore");
		JSONObject mcp2Request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		List<Address> addressDetails = (List<Address>) mcp2Request.get(CreditBusinessConstants.ADDRESSLIST);
		if (null != addressDetails && !addressDetails.isEmpty()) {
			JSONObject address = CreditBusinessHelper.getJSONObject(addressDetails.get(0));
			String pincodeKey = null != address && null != address.get(CreditBusinessConstants.PINCODEKEY)
					? address.get(CreditBusinessConstants.PINCODEKEY).toString()
					: null;
			execution.setVariable(CreditBusinessConstants.PINCODEKEY, pincodeKey);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preGetCityForApScore");
	}

	public void postGetCityForApScore(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetCityForApScore");
		execution.setVariable(CreditBusinessConstants.CITY, null);
		JSONObject pincodeDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (null != pincodeDetails) {
			String city = null != pincodeDetails.get(CreditBusinessConstants.CITYNAME) ? pincodeDetails.get(CreditBusinessConstants.CITYNAME).toString() : null;
			execution.setVariable(CreditBusinessConstants.CITY, city);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetCityForApScore");
	}

	public static JSONObject getMaritalStatus(DelegateExecution execution, JSONObject mcpRequestFromGet) {
		JSONObject userProfile = CreditBusinessHelper.getJSONObject(mcpRequestFromGet.get(CreditBusinessConstants.USERPROFILE));
		if (userProfile != null && userProfile.get(CreditBusinessConstants.MARITALSTATUSKEY) != null) {
			Double maritalStatusKey = (Double) userProfile.get(CreditBusinessConstants.MARITALSTATUSKEY);
			ArrayList<?> maritalStatusArr = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.MARITALSTATUSLIST);
			for (Object maritalStatus : maritalStatusArr) {
				JSONObject maritalStatusObject = CreditBusinessHelper.getJSONObject(maritalStatus);
				if (maritalStatusKey.equals((Double) maritalStatusObject.get(CreditBusinessConstants.MARITALSTATUSKEY))) {
					return maritalStatusObject;
				}
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public void preDerog(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDerog");
		JSONObject derogRequest = new JSONObject();
		JSONObject cibilJson = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.CIBIL_JSON));
		String l2ProductCode = execution.getVariable(CreditBusinessConstants.PRODUCTCODE).toString();
		derogRequest.put(CreditBusinessConstants.APP_SCORE, execution.getVariable(CreditBusinessConstants.APPSCORE));
		derogRequest.put(CreditBusinessConstants.APPLICANT_ID, null);
		derogRequest.put(CreditBusinessConstants.APPLICATIONID, execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		derogRequest.put(CreditBusinessConstants.BRANCHNAME, execution.getVariable(CreditBusinessConstants.CITY));
		derogRequest.put(CreditBusinessConstants.CIBILRESPONSEJSON, cibilJson);
		derogRequest.put(CreditBusinessConstants.CUSTOMERID, null);
		if(l2ProductCode.equals(CreditBusinessConstants.PRODUCT_CODE_OMSL)) {
			switch(execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT).toString()) {
			case HOMELOANFRESH:
				derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, OMProductToBauProduct.getBauProd(HOMELOANFRESH));
				break;
			case LOANAGAINSTPROPERTY :
				derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, OMProductToBauProduct.getBauProd(LOANAGAINSTPROPERTY));
				break;
			case HOMELOANBALANCETRANSFER :
				derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, OMProductToBauProduct.getBauProd(HOMELOANBALANCETRANSFER));
				break;
			case LOANAGAINSTPROPERTYBALTRANSFER :
				derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, OMProductToBauProduct.getBauProd(LOANAGAINSTPROPERTYBALTRANSFER));
				break;
			}
		}
		else {
		derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, execution.getVariable(CreditBusinessConstants.OCCUPATION_TYPE));
		}
		switch(l2ProductCode) {
		case CreditBusinessConstants.CC :
			derogRequest.put(CreditBusinessConstants.SOURCE, CreditBusinessConstants.CONSUMER_CIBIL);
			break;
		case CreditBusinessConstants.PRODUCT_CODE_OMPL :
			derogRequest.put(CreditBusinessConstants.SOURCE, CreditBusinessConstants.COMMERCIAL_CIBIL);
			break;
		case CreditBusinessConstants.PRODUCT_CODE_OMSL :
			derogRequest.put(CreditBusinessConstants.SOURCE, CreditBusinessConstants.CONSUMER_CIBIL);
			break;
		}

		execution.setVariable(CreditBusinessConstants.L2_PRODUCT_CODE, l2ProductCode);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, derogRequest);

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preDerog");
	}

	public void postDerog(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postDerog");
		//		ArrayList<?> derogResponse = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		execution.setVariable(CreditBusinessConstants.DEROG_JSON, execution.getVariable(CreditBusinessConstants.OUTPUT));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postDerog");
	}

	@SuppressWarnings("unchecked")
	public void preGetObligation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preGetObligation");
		JSONObject payload = new JSONObject();
		payload.put("appScore", execution.getVariable("appscore"));
		payload.put("applicationId", execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		payload.put("branchName", execution.getVariable(CreditBusinessConstants.CITY));
		payload.put("cibilResponseJSON", CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.CIBIL_JSON)));
		payload.put("productType", execution.getVariable(CreditBusinessConstants.PRODUCTDESC));
		payload.put("applicantId", execution.getVariable(CreditBusinessConstants.APPLICANTID));
		payload.put("customerId", execution.getVariable(CreditBusinessConstants.APPLICANTID));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preGetObligation");
	}
	
	public void postGetObligation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetObligation");
		execution.setVariable(CreditBusinessConstants.OBLIGATION_AMT, execution.getVariable(CreditBusinessConstants.OUTPUT));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetObligation");
	}
	
	@SuppressWarnings("unchecked")
	public void preSaveObligation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preSaveObligation");
		JSONObject payload = new JSONObject();
		payload.put("applicationKey", execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		JSONObject obligationJSON = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OBLIGATION_AMT));
		if(null != obligationJSON) {
			payload.put("obligationAmount", null != obligationJSON.get("emiSum") ? obligationJSON.get("emiSum").toString() : "0.0");
		}
		else {
			payload.put("obligationAmount", "0.0");
		}
		payload.put("obligationSource", "ANALYTICS_API");
		populateCurrentBalanceForSecured(execution,payload,obligationJSON);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preSaveObligation");
	}
	
	private void populateCurrentBalanceForSecured(DelegateExecution execution, JSONObject payload,
			JSONObject obligationJSON) {
		String l2ProductCode = execution.getVariable(CreditBusinessConstants.PRODUCTCODE).toString();
		if (l2ProductCode.equals(CreditBusinessConstants.PRODUCT_CODE_OMSL)) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start populateCurrentBalanceForSecured");
			Integer currentBalance;
			List<Map<String, Object>> obligationDetailsList = (List<Map<String, Object>>) obligationJSON.get("emiList");
			if (!obligationDetailsList.isEmpty()) {
				switch (execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT).toString()) {
				case HOMELOANBALANCETRANSFER:
					currentBalance = obligationDetailsList.stream()
							.filter(x -> x.containsKey("accountType")
									&& (x.get("accountType").equals(ACCOUNTTYPE_HOUSINGLOAN)
											|| x.get("accountType").equals(ACCOUNTTYPE)))
							.map(o -> o.get("currentBalance")).mapToInt(s -> Integer.parseInt(s.toString())).sum();

					payload.put("currentBalance", null != currentBalance ? currentBalance : 0);
					break;
				case LOANAGAINSTPROPERTYBALTRANSFER:
					currentBalance = obligationDetailsList.stream()
							.filter(x -> x.containsKey("accountType")
									&& x.get("accountType").equals(ACCOUNTTYPE_PROPERTYLOAN))
							.map(o -> o.get("currentBalance")).mapToInt(s -> Integer.parseInt(s.toString())).sum();

					payload.put("currentBalance", null != currentBalance ? currentBalance : 0);
					break;
				}
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End populateCurrentBalanceForSecured");
		}
	}

	public void preFetchEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preFetchEmail");
		execution.setVariable(CreditBusinessConstants.TYPE_KEY, EmailTypeEnum.OFFICE.getValue().toString());
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preFetchEmail");
	}

	public void postFetchEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postFetchEmail");
		execution.setVariable(CreditBusinessConstants.EMAIL, null);
		JSONObject getEmailResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (null != getEmailResponse) {
			execution.setVariable(CreditBusinessConstants.EMAIL,
					null != getEmailResponse.get(CreditBusinessConstants.EMAIL) ? getEmailResponse.get(CreditBusinessConstants.EMAIL).toString() : null);
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postFetchEmail");
	}
	
	public void postFetchDerog(DelegateExecution execution) {
		execution.setVariable(CreditBusinessConstants.DEROG_JSON, execution.getVariable(CreditBusinessConstants.OUTPUT));
	}
	
	@SuppressWarnings("unchecked")
	public void preDerogIV(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDerogIV");
		JSONObject derogRequest = new JSONObject();
		JSONObject cibilJson = execution.getVariable(CreditBusinessConstants.CIBIL_JSON) != null
				? CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.CIBIL_JSON))
				: null;

		JSONObject mcpRequest = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));

		String l2ProductCode = execution.getVariable(CreditBusinessConstants.PRODUCTCODE).toString();
		if (mcpRequest.get("appScoreDetails") != null) {
			JSONObject appScore = CreditBusinessHelper.getJSONObject(mcpRequest.get("appScoreDetails"));
			derogRequest.put(CreditBusinessConstants.APP_SCORE,
					appScore.get("finalScore") != null ? Float.valueOf(appScore.get("finalScore").toString()) : null);
		}

		if (mcpRequest.get("addressList") != null) {
			List<Map<String, Object>> addressList = (List<Map<String, Object>>) mcpRequest.get("addressList");
			if (!CollectionUtils.isEmpty(addressList)) {
				Map<String, Object> address = addressList.get(0);
				if (address.get("pincodeKey") != null) {
					LocationResponseBean locationAddressBean = apiCallsHelper.getPinCodeMaster(address.get("pincodeKey").toString());
					derogRequest.put(CreditBusinessConstants.BRANCHNAME, locationAddressBean.getCityName());

				}
			}
		}
		
		mcpCheck.setOccupationValue(execution, CreditBusinessHelper.getJSONObject(mcpRequest.get("occupation")));
		if (null != execution.getVariable("occupationType")) {
			derogRequest.put(CreditBusinessConstants.PRODUCTTYPE, execution.getVariable(CreditBusinessConstants.OCCUPATION_TYPE));
		}
		
		derogRequest.put(CreditBusinessConstants.APPLICATIONID, execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		derogRequest.put(CreditBusinessConstants.CIBILRESPONSEJSON, cibilJson);
		derogRequest.put(CreditBusinessConstants.SOURCE, CreditBusinessConstants.COMMERCIAL_CIBIL);
		derogRequest.put(CreditBusinessConstants.APPLICANT_ID, null);
		derogRequest.put(CreditBusinessConstants.CUSTOMERID, null);

		execution.setVariable(CreditBusinessConstants.L2_PRODUCT_CODE, l2ProductCode);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, derogRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preDerogIV");
	}
	
	@SuppressWarnings("unchecked")
	public void preAnalyticsIncomeEstimation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAnalyticsIncomeEstimation");
		execution.setVariable(CreditBusinessConstants.SKIP_API_EXCEPTION, true);
		
		JSONObject estimatedIncomeRequest = new JSONObject();
		JSONObject cibilJson = execution.getVariable(CreditBusinessConstants.CIBIL_JSON) != null
				? CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.CIBIL_JSON)): null;
		estimatedIncomeRequest.put(CreditBusinessConstants.CIBIL_RESPONSJSON, cibilJson);
		
		estimatedIncomeRequest.put(CreditBusinessConstants.PRODUCTTYPE, execution.getVariable(CreditBusinessConstants.OCCUPATION_TYPE));
		estimatedIncomeRequest.put(CreditBusinessConstants.APP_SCORE, execution.getVariable(CreditBusinessConstants.APPSCORE));
		estimatedIncomeRequest.put(CreditBusinessConstants.APPLICATIONID, execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		estimatedIncomeRequest.put(CreditBusinessConstants.APPLICANT_ID, execution.getVariable(CreditBusinessConstants.APPLICANTID));
		estimatedIncomeRequest.put(CreditBusinessConstants.SOURCE, CreditBusinessConstants.COMMERCIAL_CIBIL);
		estimatedIncomeRequest.put(CreditBusinessConstants.CUSTOMERID, null);
		
		JSONObject mcpRequest = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		if (mcpRequest.get("addressList") != null) {
			List<Map<String, Object>> addressList = (List<Map<String, Object>>) mcpRequest.get("addressList");
			if (!CollectionUtils.isEmpty(addressList)) {
				Map<String, Object> address = addressList.get(0);
				if (address.get("pincodeKey") != null) {
					LocationResponseBean locationAddressBean = apiCallsHelper.getPinCodeMaster(address.get("pincodeKey").toString());
					estimatedIncomeRequest.put(CreditBusinessConstants.BRANCHNAME, locationAddressBean.getCityName());

				}
			}
		}
		
		if (mcpRequest.get("estimatedNetMonthlySalaryDetails") != null) {
			List<Map<String, Object>> salaryDetails = (List<Map<String, Object>>) mcpRequest.get("estimatedNetMonthlySalaryDetails");
			if (!CollectionUtils.isEmpty(salaryDetails)) {
				estimatedIncomeRequest.put(CreditBusinessConstants.CUSTOMER_DECLARED_INCOME, null);
				estimatedIncomeRequest.put(CreditBusinessConstants.PERFIOS_SALARY, null);
				estimatedIncomeRequest.put(CreditBusinessConstants.EPCREDIT_SALARY, null);
				for (Map<String, Object> salary : salaryDetails) {
					if ((salary.get(CreditBusinessConstants.SALARY_SOURCE) != null)
							&& salary.get(CreditBusinessConstants.SALARY_SOURCE).toString()
									.equalsIgnoreCase(CreditBusinessConstants.JOURNEY)) {
						estimatedIncomeRequest.put(CreditBusinessConstants.CUSTOMER_DECLARED_INCOME,
								salary.get("salaryAmount"));
					}
					if ((salary.get(CreditBusinessConstants.SALARY_SOURCE) != null)
							&& salary.get(CreditBusinessConstants.SALARY_SOURCE).toString()
									.equalsIgnoreCase(SALRYSOURCE_BFLPERFIOS)) {
						estimatedIncomeRequest.put(CreditBusinessConstants.PERFIOS_SALARY, salary.get("salaryAmount"));
					}
					if ((salary.get(CreditBusinessConstants.SALARY_SOURCE) != null)
							&& salary.get(CreditBusinessConstants.SALARY_SOURCE).toString()
									.equalsIgnoreCase(CreditBusinessConstants.SALARYSOURCE_EPCREDIT)) {
						estimatedIncomeRequest.put(CreditBusinessConstants.EPCREDIT_SALARY, salary.get("salaryAmount"));
					}
				}
			}
		}
		
		JSONObject demog = new JSONObject();
		demog.put(CreditBusinessConstants.CITY, execution.getVariable(CreditBusinessConstants.CITY));
		demog.put(CreditBusinessConstants.DOB, execution.getVariable(CreditBusinessConstants.DOB));
		estimatedIncomeRequest.put(CreditBusinessConstants.DEMOG, demog);	
		
		execution.setVariable(CreditBusinessConstants.PAYLOAD, estimatedIncomeRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preAnalyticsIncomeEstimation");
	}
	
	@SuppressWarnings("unchecked")
	public void postAnalyticsIncomeEstimation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postAnalyticsIncomeEstimation");
		execution.setVariable(CreditBusinessConstants.SALARY, null);
		execution.setVariable(CreditBusinessConstants.ANALYTICS_SALARY_NOT_FOUND, false);
		Object apiException = execution.getVariable(CreditBusinessConstants.API_EXCEPTION_ARISE);

		if (null == apiException || !(boolean) apiException) {
			JSONObject analyticsIncomeEstimationResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
			if (null != analyticsIncomeEstimationResponse) {
				execution.setVariable(CreditBusinessConstants.SALARY,
						null != analyticsIncomeEstimationResponse.get(CreditBusinessConstants.ESTIMATED_INCOME)
								? String.valueOf(((Double) analyticsIncomeEstimationResponse.get(CreditBusinessConstants.ESTIMATED_INCOME)).intValue()) : null);
			}
			
			if (null != analyticsIncomeEstimationResponse) {
				execution.setVariable(CreditBusinessConstants.FINAL_INCOME,
						null != analyticsIncomeEstimationResponse.get(CreditBusinessConstants.FINAL_INCOME)
								? String.valueOf(((Double) analyticsIncomeEstimationResponse.get(CreditBusinessConstants.FINAL_INCOME)).intValue()) : null);
			}
		}else {
			execution.setVariable(CreditBusinessConstants.ANALYTICS_SALARY_NOT_FOUND, true);
		}
		
		// remove exception skip flags from execution once task gets completed
		List<String> variablesToRemoveFromExecution = new ArrayList<String>();
		variablesToRemoveFromExecution.add(CreditBusinessConstants.SKIP_API_EXCEPTION);
		variablesToRemoveFromExecution.add(CreditBusinessConstants.API_EXCEPTION_ARISE);
		execution.removeVariables(variablesToRemoveFromExecution);			
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postAnalyticsIncomeEstimation");
	}
	
	@SuppressWarnings("unchecked")
	public void preAnalyticsIncomeEstimationVer2(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAnalyticsIncomeEstimationVer2");
		execution.setVariable(CreditBusinessConstants.SKIP_API_EXCEPTION, true);
		
		JSONObject estimatedIncomeRequest = new JSONObject();
		JSONObject cibilJson = execution.getVariable(CreditBusinessConstants.CIBIL_JSON) != null
				? CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.CIBIL_JSON)): null;
		estimatedIncomeRequest.put(CreditBusinessConstants.CIBIL_RESPONSJSON, cibilJson);
		
		estimatedIncomeRequest.put(CreditBusinessConstants.PRODUCTTYPE, execution.getVariable(CreditBusinessConstants.OCCUPATION_TYPE));
		estimatedIncomeRequest.put(CreditBusinessConstants.APPLICATIONID, execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		estimatedIncomeRequest.put(CreditBusinessConstants.APPLICANT_ID, execution.getVariable(CreditBusinessConstants.APPLICANTID));
		estimatedIncomeRequest.put(CreditBusinessConstants.SOURCE, CreditBusinessConstants.COMMERCIAL_CIBIL);
		estimatedIncomeRequest.put(CreditBusinessConstants.CUSTOMERID, null);
		JSONObject mcpRequest = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		if (mcpRequest.get("appScoreDetails") != null) {
			JSONObject appScore = CreditBusinessHelper.getJSONObject(mcpRequest.get("appScoreDetails"));
			estimatedIncomeRequest.put(CreditBusinessConstants.APP_SCORE,
					appScore.get("finalScore") != null ? Double.valueOf(appScore.get("finalScore").toString()) : null);
		}
		
		ArrayList<?> salariesDetails = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.SALARY_DETAILS);
		estimatedIncomeRequest.put(CreditBusinessConstants.CUSTOMER_DECLARED_INCOME, null);
		estimatedIncomeRequest.put(CreditBusinessConstants.PERFIOS_SALARY, null);
		estimatedIncomeRequest.put(CreditBusinessConstants.EPCREDIT_SALARY, null);
		if (!CollectionUtils.isEmpty(salariesDetails)) {
			for (Object salary : salariesDetails) {
				JSONObject salaryJson = CreditBusinessHelper.getJSONObject(salary);
				if (salaryJson.get(CreditBusinessConstants.SALARY_SOURCE) != null) {
					if (salaryJson.get(CreditBusinessConstants.SALARY_SOURCE).toString()
							.equalsIgnoreCase(CreditBusinessConstants.JOURNEY)) {
						estimatedIncomeRequest.put(CreditBusinessConstants.CUSTOMER_DECLARED_INCOME,
								salaryJson.get("salary"));
					}
					if (salaryJson.get(CreditBusinessConstants.SALARY_SOURCE).toString()
							.equalsIgnoreCase(SALRYSOURCE_BFLPERFIOS)) {
						estimatedIncomeRequest.put(CreditBusinessConstants.PERFIOS_SALARY,
								salaryJson.get("salary"));
					}
					if (salaryJson.get(CreditBusinessConstants.SALARY_SOURCE).toString()
							.equalsIgnoreCase(CreditBusinessConstants.SALARYSOURCE_EPCREDIT)) {
						estimatedIncomeRequest.put(CreditBusinessConstants.EPCREDIT_SALARY,
								salaryJson.get("salary"));
					}
				}
			}
		}
		JSONObject demog = new JSONObject();
		if (mcpRequest.get("addressList") != null) {
			Gson gson = new Gson();
			String addressJson = gson.toJson(mcpRequest.get("addressList"));
			JSONArray addressDetails = gson.fromJson(addressJson, JSONArray.class);
			if (!CollectionUtils.isEmpty(addressDetails)) {
				for (int i = 0; i < addressDetails.size(); i++) {
					JSONObject address = CreditBusinessHelper.getJSONObject(addressDetails.get(i));
					if ("50".equals(address.get("addressTypeKey").toString()) && null != address.get("pincodeKey")) {
						LocationResponseBean pinCodeMaster = apiCallsHelper
								.getPinCodeMaster(address.get("pincodeKey").toString());
						estimatedIncomeRequest.put(CreditBusinessConstants.BRANCHNAME, pinCodeMaster.getCityName());
						demog.put(CreditBusinessConstants.CITY, pinCodeMaster.getCityName());
					}
				}
			}
		}
			Map<String, Object> userProfile = (Map<String, Object>) mcpRequest.get("userProfile");
			if (userProfile != null) {
				if (userProfile.get("dateOfBirth") != null) {
					String dob = (String) userProfile.get("dateOfBirth");
					demog.put(CreditBusinessConstants.DOB, dob);

				}
			}
		estimatedIncomeRequest.put(CreditBusinessConstants.DEMOG, demog);	
	
		execution.setVariable(CreditBusinessConstants.PAYLOAD, estimatedIncomeRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preAnalyticsIncomeEstimationVer2");
	}
	
}
