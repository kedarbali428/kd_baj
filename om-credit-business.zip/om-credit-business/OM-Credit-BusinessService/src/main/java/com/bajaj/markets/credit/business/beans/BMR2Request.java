package com.bajaj.markets.credit.business.beans;

public class BMR2Request {

	private String applicationId;
	private String occupationType;
	private String addressTypeKey;
	private String principalKey;
	private String l2ProductCode;
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getOccupationType() {
		return occupationType;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public String getPrincipalKey() {
		return principalKey;
	}
	public void setPrincipalKey(String principalKey) {
		this.principalKey = principalKey;
	}
	public String getAddressTypeKey() {
		return addressTypeKey;
	}
	public void setAddressTypeKey(String addressTypeKey) {
		this.addressTypeKey = addressTypeKey;
	}
	public String getL2ProductCode() {
		return l2ProductCode;
	}
	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}
	@Override
	public String toString() {
		return "BMR2Request [applicationId=" + applicationId + ", occupationType=" + occupationType
				+ ", addressTypeKey=" + addressTypeKey + ", principalKey=" + principalKey + ", l2ProductCode="
				+ l2ProductCode + "]";
	}
}