package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_REF_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE_CONSUMER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PROCESS_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.CibilReference;
import com.bajaj.markets.credit.business.beans.CibilRequest;
import com.bajaj.markets.credit.business.beans.CibilResponse;
import com.bajaj.markets.credit.business.beans.CibilResponseWrapper;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessCibilOtpService;
import com.google.gson.Gson;

@Component
public class CreditBusinessCibilOtpServiceImpl implements CreditBusinessCibilOtpService {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	WorkflowHelper workflowHelper;

	@Value("${api.omcibilverificationservice.cibil.get.url}")
	private String getCibilReferenceUrl;

	@Value("${api.omcibilverificationservice.cibil.authentication.post.url}")
	private String postCibilAuthenticateUrl;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;

	@Override
	public CibilReference getCibilReference(Long applicationId) {
		CibilReference cibilReference = null;

		Map<String, String> params = new HashMap<String, String>();
		params.put(CIBIL_TYPE, CIBIL_TYPE_CONSUMER);
		params.put("applicationkey", applicationId.toString());
		params.put("applicationid", applicationId.toString());
		
		UserProfileBean userProfile = apiCallsHelper.getUserProfile(params, "1", false);

		if(null != userProfile) {
			HttpHeaders headers = new HttpHeaders();
			
			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put("applicationid", applicationId.toString());
			queryParams.put("userattributekey", userProfile.getApplicationUserAttributeKey());
			DocumentDetails documentDetails = apiCallsHelper.getDocumentDetail(queryParams, 2l);
			
			params.put("applicantkey", userProfile.getApplicantKey());
			params.put("cibilreferencekey", null != documentDetails && null != documentDetails.getDocumentNumber() && 
					documentDetails.getDocumentNumber().matches("\\d+") ? documentDetails.getDocumentNumber() : null);
	
			ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getCibilReferenceUrl,
					String.class, params, null, headers);
	
			if (null != responseEntity && HttpStatus.OK.equals(responseEntity.getStatusCode())
					&& null != responseEntity.getBody()) {
				Class<CibilResponse[]> clazz = CibilResponse[].class;
				CibilResponse[] cibilResponses = new Gson().fromJson((String) responseEntity.getBody(), clazz);
				if (null != cibilResponses && cibilResponses.length > 0) {
					for (CibilResponse cibilResponse : cibilResponses) {
						if("INITIATED".equals(cibilResponse.getState())) {
							cibilReference = new CibilReference();
							cibilReference.setCibilReferenceId(cibilResponse.getCibilReferenceNumber());
							cibilReference.setCibilStatus(cibilResponse.getState());
							break;
						}
					}
				}
			}
			return cibilReference;
		} else {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE, "User Profile not found for application: " + applicationId);
			throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("OMCB-404","Record not found for provided application"));
		}
	}

	@Override
	public CibilResponseWrapper authenticateCibil(Long applicationId, Long cibilReferenceKey, CibilRequest cibilRequest,
			HttpHeaders headers) {
		CibilResponseWrapper cibilResponseWrapper = new CibilResponseWrapper();
		Map<String, Object> vars = new HashMap<String, Object>();
		vars.put(REQUEST, cibilRequest);
		vars.put(CIBIL_REF_KEY, cibilReferenceKey);
		vars.put(APPLICATION_ID, applicationId);

		try {
			String nextTaskKey = workflowHelper.completeTask(headers.get(PROCESS_ID).get(0), vars);

			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			cibilResponseWrapper.setNextTask(task);
			cibilResponseWrapper.setPayload(workflowHelper.getFromExecutionMap("cibilAuthenticateErrorRes",
					workflowHelper.getActiveProcessId(headers.get(PROCESS_ID).get(0))));

			return cibilResponseWrapper;
		} catch (CreditBusinessException e) {

			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
					"Exception completing workflow task" + e);
			throw e;
		} catch (Exception e) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
					"Exception occured while calling the service" + e);
			throw new CreditBusinessException(e.getCause());
		}
	}

}
