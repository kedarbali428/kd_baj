package com.bajaj.markets.credit.business.beans;

public class MCPRequest {
	private OpenArcRejectionInput openArcRejectionInput;
	private AdditionalParameterDetail additionalParameterDetail;

	public void setOpenArcRejectionInput(OpenArcRejectionInput openArcRejectionInput) {
		this.openArcRejectionInput = openArcRejectionInput;
	}
	
	public void setAdditionalParameterDetail(AdditionalParameterDetail additionalParameterDetail) {
		this.additionalParameterDetail = additionalParameterDetail;
	}

	@Override
	public String toString() {
		return "MCPRequest [openArcRejectionInput=" + openArcRejectionInput + ", additionalParameterDetail="
				+ additionalParameterDetail + "]";
	}

}
