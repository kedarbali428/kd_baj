package com.bajaj.markets.credit.business.session;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.data.redis.RedisIndexedSessionRepository;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.AuthenticatedUser;
import com.bajaj.markets.credit.business.beans.SessionInfo;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;

@Component
public class ApplicationSessionManager {

	private static final String CLASS_NAME = ApplicationSessionManager.class.getCanonicalName();

	@Autowired(required = false)
	private SessionRegistry sessionRegistry;

	@Autowired(required = false)
	private RedisIndexedSessionRepository redisOperationsSessionRepository;

	@Autowired
	@Qualifier("redisTemplate")
	private RedisTemplate<String, SessionInfo> redisTemplate;

	@Autowired
	private BFLLoggerUtilExt logger;

	@Value("${spring.session.enabled:false}")
	private boolean sessionEnabled;

	private static List<String> customerRoles = Arrays.asList("pvcustomer", "pcustomer", "customer");

	public void validateSession(HttpServletRequest httpServletRequest, String applicationId,
			boolean overrideCustomerSession) {

		if (!sessionEnabled) {
			return;
		}
		String currentSesssionId = httpServletRequest.getSession().getId();
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Current SessionId is  : " + currentSesssionId + " for applicationId " + applicationId);

		// Index sessions using applicationid
		httpServletRequest.getSession().setAttribute(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME,
				applicationId);

		Set<String> usersSessionIds = findAllSessionsOfApplication(applicationId);
		List<String> activeSessions = findActiveSessions(usersSessionIds);
		clearActiveSessionsIfMoreThanOneExceptCurrentSession(activeSessions, currentSesssionId);

		AuthenticatedUser currentAuthenticatedUser = (AuthenticatedUser) SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Current User Role " + currentAuthenticatedUser.getRole());
		if (activeSessions.size() == 1) {
			String redisSessionId = activeSessions.stream().collect(Collectors.toList()).get(0);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Redis SessionId is  : " + redisSessionId);
			if (currentSesssionId.equals(redisSessionId)) {
				SessionInfo redisAdditionalInfo = redisTemplate.opsForValue().get(currentSesssionId);
				if (Objects.nonNull(redisAdditionalInfo)) {
					return;
				}
			} else {
				SessionInfo redisAdditionalInfo = redisTemplate.opsForValue().get(redisSessionId);
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Redis SessionInfo " + redisAdditionalInfo);
				SessionInformation redisSessionInformation = sessionRegistry.getSessionInformation(redisSessionId);
				if (Objects.nonNull(redisAdditionalInfo)) {
					if (customerRoles.contains(redisAdditionalInfo.getRole())
							&& customerRoles.contains(currentAuthenticatedUser.getRole())) {
						expirePreviousCustomerSession(applicationId, redisSessionId, redisSessionInformation);
					} else {
						if (redisAdditionalInfo.getRole().equals("employee")
								&& currentAuthenticatedUser.getRole().equals("employee")) {
							expirePreviousEmployeeSession(applicationId, redisSessionId, redisSessionInformation);
						} else {
							if (customerRoles.contains(redisAdditionalInfo.getRole())
									&& currentAuthenticatedUser.getRole().equals("employee")) {
								expirePreviousCustomerSessionIfConfirmed(httpServletRequest, applicationId,
										overrideCustomerSession, currentSesssionId, redisSessionId,
										redisSessionInformation);
							} else {
								if (redisAdditionalInfo.getRole().equals("employee")
										&& customerRoles.contains(currentAuthenticatedUser.getRole())) {
	
									expireEmployeeSession(applicationId, redisSessionId, redisSessionInformation);
								}
							}
						}
					}
				}else {
					expireRedisSession(redisSessionId, redisSessionInformation);
				}
			}
		}

		setSessionInfoIntoRedis(applicationId, currentSesssionId, currentAuthenticatedUser);

	}

	private void expireRedisSession(String redisSessionId, SessionInformation redisSessionInformation) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Expire redis session as redisAdditionalInfo is null " + redisSessionId);
		if (null != redisSessionInformation)
			redisSessionInformation.expireNow();
	}

	private void setSessionInfoIntoRedis(String applicationId, String currentSesssionId,
			AuthenticatedUser currentAuthenticatedUser) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "setSessionInfoIntoRedis start " );
		SessionInfo sessionInfo = new SessionInfo();
		sessionInfo.setApplicationKey(Long.valueOf(applicationId));
		sessionInfo.setUserKey(null != currentAuthenticatedUser.getAdditionalInfo()
				? currentAuthenticatedUser.getAdditionalInfo().getUserKey()
				: null);
		sessionInfo.setRole(
				currentAuthenticatedUser.getRole().equals("system") ? "pcustomer" : currentAuthenticatedUser.getRole());
		redisTemplate.opsForValue().set(currentSesssionId, sessionInfo);
		redisTemplate.expire(currentSesssionId, 3, TimeUnit.HOURS);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "setSessionInfoIntoRedis end " );
	}

	private void expireEmployeeSession(String applicationId, String redisSessionId,
			SessionInformation redisSessionInformation) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Employee session already exists for applicationId " + applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Expire employee session " + redisSessionId);
		if (null != redisSessionInformation)
			redisSessionInformation.expireNow();
	}

	private void expirePreviousCustomerSessionIfConfirmed(HttpServletRequest httpServletRequest, String applicationId,
			boolean overrideCustomerSession, String currentSesssionId, String redisSessionId,
			SessionInformation redisSessionInformation) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Customer session already exists for applicationId " + applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Invalidate current session and throw exception" + currentSesssionId);
		if (null != redisSessionInformation) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Customer session was last accessed at " + redisSessionInformation.getLastRequest());
		}

		if (overrideCustomerSession) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Override is true so expire previous customer sessionId " + redisSessionId);
			if (null != redisSessionInformation)
				redisSessionInformation.expireNow();
		} else {
			httpServletRequest.getSession().invalidate();
			throw new CreditBusinessException(HttpStatus.EXPECTATION_FAILED, "Customer Session is in progress");
		}
	}

	private void expirePreviousEmployeeSession(String applicationId, String redisSessionId,
			SessionInformation redisSessionInformation) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Both Redis and Current Session belong to Employee role for applicationId " + applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Expire previous employee sessionId " + redisSessionId);
		if (null != redisSessionInformation)
			redisSessionInformation.expireNow();
	}

	private void expirePreviousCustomerSession(String applicationId, String redisSessionId,
			SessionInformation redisSessionInformation) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Both Redis and Current Session belong to customer role for applicationId " + applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Expire previous customer sessionId " + redisSessionId);
		if (null != redisSessionInformation)
			redisSessionInformation.expireNow();
	}

	private Set<String> findAllSessionsOfApplication(String applicationId) {
		Set<String> usersSessionIds = redisOperationsSessionRepository
				.findByIndexNameAndIndexValue(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME, applicationId)
				.keySet();
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Total number of sessions " + usersSessionIds.size());
		return usersSessionIds;
	}

	private List<String> findActiveSessions(Set<String> usersSessionIds) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Finding Session in Redis ");
		List<String> activeSessions = usersSessionIds.stream().filter((usersSessionId) -> {
			SessionInformation sessionInformation = sessionRegistry.getSessionInformation(usersSessionId);
			return (null != sessionInformation && !sessionInformation.isExpired());
		}).collect(Collectors.toList());

		return activeSessions;
	}

	private void clearActiveSessionsIfMoreThanOneExceptCurrentSession(List<String> activeSessions, String currentSesssionId) {
		if (activeSessions.size() > 1) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Something went wrong, should not be here; closing provious sessions, allow current one");
			for (String usersSessionId : activeSessions) {
				if(!usersSessionId.equals(currentSesssionId)) {
					SessionInformation sessionInformation = sessionRegistry.getSessionInformation(usersSessionId);
					if (null != sessionInformation)
						sessionInformation.expireNow();
				}
			}
			activeSessions.retainAll(List.of(currentSesssionId));
		}
	}
}
