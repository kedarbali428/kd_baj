package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class PanDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2918404494181826969L;
	private String nameMatch;
	private Integer matchScore;
	private String panType;
	private String panStatus;

	public void setNameMatch(String nameMatch) {
		this.nameMatch = nameMatch;
	}

	public void setMatchScore(Integer matchScore) {
		this.matchScore = matchScore;
	}

	public void setPanType(String panType) {
		this.panType = panType;
	}

	public void setPanStatus(String panStatus) {
		this.panStatus = panStatus;
	}

	@Override
	public String toString() {
		return "PanDetails [nameMatch=" + nameMatch + ", matchScore=" + matchScore + ", panType=" + panType
				+ ", panStatus=" + panStatus + "]";
	}

}
