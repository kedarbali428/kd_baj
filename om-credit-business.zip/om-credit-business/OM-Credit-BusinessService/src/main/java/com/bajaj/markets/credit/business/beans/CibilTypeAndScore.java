package com.bajaj.markets.credit.business.beans;

public class CibilTypeAndScore {
	private String scoreV3;

	public String getScoreV3() {
		return scoreV3;
	}

	public void setScoreV3(String scoreV3) {
		this.scoreV3 = scoreV3;
	}

}
