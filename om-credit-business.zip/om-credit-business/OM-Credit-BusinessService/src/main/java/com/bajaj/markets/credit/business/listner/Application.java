package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATIONKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CHILDAPPLICATIONID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DOC_SENT_STATUS_SUCCESS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMPLOYER_KID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMPLOYER_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMPLOYER_NAME_OTHER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.IS_OFFICIALEMAIL_PRESENT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.KID_PRESENT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2PRODUCTKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2_PRODUCT_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L3_PRODUCT_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NETSALARY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OFFER_AVAILABLE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PARENT_APPLICATION_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PARENT_STATUS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PRINCIPALKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST_HEADERS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.RESIDENCE_TYPE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.RISKOFFERTYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SKIP_API_EXCEPTION;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SOURCE_JOURNEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CITY_KEY;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationResume;
import com.bajaj.markets.credit.business.beans.EmployerMasterBean;
import com.bajaj.markets.credit.business.helper.ApplicationStatusEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EtbVariantEnum;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.OccupationTypeEnum;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Application {

	private static final String APPLICATION_PARAMETERS = "applicationParameters";
	private static final String REQUESTEDCREDITAMOUNT = "requestedCreditAmount";
	private static final String REQUIRED_LOAN_AMOUNT = "requiredLoanAmount";
	private static final String CHILD_APPLICATION_RESPONSE = "ChildApplicationResponse";
	private static final String RISK_OFFER_TYPE_ = "riskOfferType";
	private static final String RISK_OFFER_TYPE = "riskoffertype";
	private static final String OFFICE = "OFFICE";
	private static final String UTM_APP_CREATE_EVENT = "PARENT CREATED";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	UpdateProfile updateProfile;
	
	@Autowired
	McpCheck mcpCheck;
	
	@Autowired
	CreditBusinessGinHelper ginHelper;

	final ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	MasterDataRedisClientHelper redisHelper;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	@Value("${analytics.repayment.flow.enable}")
	private boolean analyticsRepaymentFlowFlag;
	
	private static final String CLASS_NAME = Application.class.getCanonicalName();

	public void postGetApplication(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetApplication");
		JSONObject application = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		String l2ProdCode = application.get(CreditBusinessConstants.L2_PRODUCT_CODE) != null
				? application.get(CreditBusinessConstants.L2_PRODUCT_CODE).toString()
				: null;

		String l2ProductDesc = application.get(CreditBusinessConstants.L2_PRODUCT_DESC) != null
				? application.get(CreditBusinessConstants.L2_PRODUCT_DESC).toString()
				: null;

		Long l2ProductKey = application.get(CreditBusinessConstants.L2_PRODUCT_KEY) != null
				? ((Double) application.get(CreditBusinessConstants.L2_PRODUCT_KEY)).longValue()
				: null;

		String l3ProdCode = application.get(CreditBusinessConstants.L3_PRODUCT_CODE) != null
				? application.get(CreditBusinessConstants.L3_PRODUCT_CODE).toString()
				: null;

		Long l3ProductKey = application.get(CreditBusinessConstants.L3_PRODUCT_KEY) != null
				? ((Double) application.get(CreditBusinessConstants.L3_PRODUCT_KEY)).longValue()
				: null;

		String applicationKey = application.get(CreditBusinessConstants.APPLICATIONKEY) != null
				? application.get(CreditBusinessConstants.APPLICATIONKEY).toString()
				: null;
		
		String parentAppKey = application.get(CreditBusinessConstants.PARENT_APPLICATION_KEY) != null
				? application.get(CreditBusinessConstants.PARENT_APPLICATION_KEY).toString()
				: null;

		Long cityKey = application.get(CITY_KEY) != null ? ((Double)application.get(CITY_KEY)).longValue() : null;
		Long principalKey = application.get(PRINCIPALKEY) != null ? ((Double) application.get(PRINCIPALKEY)).longValue() : null;

		String hlProductIntent = null != application.get("hlProductIntent") ? application.get("hlProductIntent").toString() : null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "L2 Product Code  == " + l2ProdCode + ", Application Id : " + applicationKey);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "L3 Product Code  == " + l3ProdCode + ", Application Id : " + applicationKey);

		execution.setVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY, parentAppKey);
		execution.setVariable(CreditBusinessConstants.CHILDAPPLICATIONID, applicationKey);
		if (parentAppKey != null) {
			execution.setVariable(CreditBusinessConstants.APPLICATION_ID, parentAppKey);
			execution.setVariable(CreditBusinessConstants.APPLICATIONKEY, parentAppKey);
		} else {
			execution.setVariable(CreditBusinessConstants.APPLICATION_ID, applicationKey);
			execution.setVariable(CreditBusinessConstants.APPLICATIONKEY, applicationKey);
		}
		
		execution.setVariable(CreditBusinessConstants.APPLICANTID, application.get(CreditBusinessConstants.APPLICANTKEY));
		execution.setVariable(CreditBusinessConstants.L2_PRODUCT_CODE, l2ProdCode);
		execution.setVariable(CreditBusinessConstants.L2_PRODUCT_DESC, l2ProductDesc);
		execution.setVariable(CreditBusinessConstants.L3_PRODUCT_CODE, l3ProdCode);
		execution.setVariable(CreditBusinessConstants.CITY_KEY,cityKey);

		execution.setVariable(PRINCIPALKEY, principalKey);
		execution.setVariable(L2PRODUCTKEY, l2ProductKey);
		execution.setVariable(L2_PRODUCT_KEY, l2ProductKey);
		execution.setVariable(L3_PRODUCT_KEY, l3ProductKey);
		execution.setVariable(CreditBusinessConstants.HLPRODUCTINTENT, hlProductIntent);
		
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ApplicationDetail appDetails = mapper.convertValue(execution.getVariable(CreditBusinessConstants.OUTPUT), ApplicationDetail.class);
		execution.setVariable(CreditBusinessConstants.APPLICATION_DETAILS, appDetails);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetApplication");
	}

	public void preCreateCardApplication(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCreateCardApplication");
		JSONObject applicationDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject childApplication = new JSONObject();
		childApplication = getChildApplicationRequest(applicationDetails, childApplication);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, childApplication);
		execution.setVariable(CreditBusinessConstants.APPLICATION_ID,
				null != applicationDetails.get(CreditBusinessConstants.PARENT_APPLICATION_KEY)
						? applicationDetails.get(CreditBusinessConstants.PARENT_APPLICATION_KEY).toString()
						: null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCreateCardApplication");
	}

	public void postCreateCardApplication(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postCreateCardApplication");
		JSONObject childApplicationObject = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CHILD_APPLICATION_RESPONSE, childApplicationObject);
		execution.setVariable("childApplicationId",
				null != childApplicationObject.get("applicationKey") ? childApplicationObject.get("applicationKey").toString() : null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postCreateCardApplication");
	}

	public void postGetApplicationForPrinciple(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetApplicationForPrinciple");
		JSONObject application = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		String l3ProductCode = null != application.get(CreditBusinessConstants.L3_PRODUCT_CODE)
				? application.get(CreditBusinessConstants.L3_PRODUCT_CODE).toString()
				: null;
		String principalKey = application.get(CreditBusinessConstants.PRINCIPALKEY) != null
				? String.valueOf(((Double) application.get(CreditBusinessConstants.PRINCIPALKEY)).intValue())
				: null;
		Double l3ProductKey = application.get(CreditBusinessConstants.L3_PRODUCT_KEY) != null
				? (Double) application.get(CreditBusinessConstants.L3_PRODUCT_KEY)
				: null;
		execution.setVariable(CreditBusinessConstants.L3_PRODUCT_CODE, l3ProductCode);
		execution.setVariable(CreditBusinessConstants.PRINCIPALKEY, principalKey);
		execution.setVariable(CreditBusinessConstants.L3_PRODUCT_KEY, l3ProductKey);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetApplicationForPrinciple");
	}

	@SuppressWarnings("unchecked")
	public void preCreateLoanApplication(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCreateLoanApplication");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject childApplication = new JSONObject();
		execution.setVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY,
				null != request.get(CreditBusinessConstants.PARENT_APPLICATION_KEY) ? request.get(CreditBusinessConstants.PARENT_APPLICATION_KEY).toString()
						: null);
		childApplication = getChildApplicationRequest(request, childApplication);
		childApplication.put(CreditBusinessConstants.PRODUCT_LISTING_KEY, request.get(CreditBusinessConstants.PRODUCT_LISTING_KEY));
		childApplication.put(CreditBusinessConstants.HLPRODUCTINTENT,
				null != execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT)
						? execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT).toString()
						: null);
		childApplication.put(RISK_OFFER_TYPE, request.get(RISK_OFFER_TYPE_));
		execution.setVariable(CreditBusinessConstants.APPLICATION_ID,
				null != request.get(CreditBusinessConstants.PARENT_APPLICATION_KEY) ? request.get(CreditBusinessConstants.PARENT_APPLICATION_KEY).toString()
						: null);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, childApplication);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCreateLoanApplication");
	}

	public void postCreateLoanApplication(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postCreateLoanApplication");
		JSONObject childApplicationObject = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CHILD_APPLICATION_RESPONSE, childApplicationObject);
		execution.setVariable(CreditBusinessConstants.CHILDAPPLICATIONID,
				null != childApplicationObject.get("applicationKey") ? childApplicationObject.get("applicationKey").toString() : null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postCreateLoanApplication");
	}

	public void postGetLoanPricing(DelegateExecution execution) {
		Map<String, Object> existingpricing = getJourneyPricing(execution);
		existingpricing.put(CreditBusinessConstants.PARENT_APPLICATION_KEY,
				execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, existingpricing);
	}
	
	public void postGetCityLocation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetCityLocation");
		JSONObject cityResponseBean = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable("cityLocation", cityResponseBean.get("cityname"));
	}

	public void preGetChildApp(DelegateExecution execution) {
		execution.setVariable(CreditBusinessConstants.ISINPROCESSING, true);
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getJourneyPricing(DelegateExecution execution) {
		if (execution.getVariable(CreditBusinessConstants.OUTPUT) != null) {
			List<Map<String, Object>> outputList = (ArrayList<Map<String, Object>>) execution.getVariable(CreditBusinessConstants.OUTPUT);
			if (!CollectionUtils.isEmpty(outputList)) {
				for (Map<String, Object> output : outputList) {
					if (output.get("source") != null && CreditBusinessConstants.JOURNEY.equalsIgnoreCase(output.get("source").toString())) {
						return output;
					}
				}
			}
		}
		return null;
	}

	public void postGetRepaymentSchedule(DelegateExecution execution) {
		execution.setVariable(CreditBusinessConstants.PENNENT_SUCCESS, false);
		JSONObject pricing = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (null != execution.getVariable(CreditBusinessConstants.IS_EP_PRICING_APPROVED)
				&& (boolean) execution.getVariable(CreditBusinessConstants.IS_EP_PRICING_APPROVED)) {
			pricing.put("source", CreditBusinessConstants.EP.toUpperCase());
			pricing.put("pricingStatus", CreditBusinessConstants.APPROVED.toUpperCase());
		} else {
			pricing.put("source", CreditBusinessConstants.JOURNEY.toUpperCase());
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, pricing);
	}

	@SuppressWarnings("unchecked")
	private JSONObject getChildApplicationRequest(JSONObject applicationDetails, JSONObject childApplication) {
		childApplication.put(CreditBusinessConstants.PARENT_APPLICATION_KEY, applicationDetails.get(CreditBusinessConstants.PARENT_APPLICATION_KEY));
		childApplication.put(CreditBusinessConstants.L2_PRODUCT_KEY, applicationDetails.get(CreditBusinessConstants.L2_PRODUCT_KEY));
		childApplication.put(CreditBusinessConstants.L2_PRODUCT_CODE, applicationDetails.get(CreditBusinessConstants.L2_PRODUCT_CODE));
		childApplication.put(CreditBusinessConstants.L3_PRODUCT_CODE, applicationDetails.get(CreditBusinessConstants.L3_PRODUCT_CODE));
		childApplication.put(CreditBusinessConstants.L4_PRODUCT_CODE, applicationDetails.get(CreditBusinessConstants.L4_PRODUCT_CODE));
		return childApplication;
	}

	public void postGetApplicationForResume(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetApplicationForResume");
		JSONObject application = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		String l2ProductCode = application.get(CreditBusinessConstants.L2_PRODUCT_CODE) != null
				? application.get(CreditBusinessConstants.L2_PRODUCT_CODE).toString()
				: null;
		Double l2ProductKey = application.get(CreditBusinessConstants.L2_PRODUCT_KEY) != null ? (Double) application.get(CreditBusinessConstants.L2_PRODUCT_KEY)
				: null;
		String applicationKey = application.get(CreditBusinessConstants.APPLICATIONKEY) != null
				? application.get(CreditBusinessConstants.APPLICATIONKEY).toString()
				: null;
		String applicationStatus = application.get(CreditBusinessConstants.APPLICATION_STATUS) != null
				? String.valueOf(((Double) application.get(CreditBusinessConstants.APPLICATION_STATUS)).intValue())
				: null;
		String applicantKey = application.get(CreditBusinessConstants.APPLICANTKEY) != null ? application.get(CreditBusinessConstants.APPLICANTKEY).toString()
				: null;

		ApplicationResume applicationResume = new ApplicationResume();
		applicationResume.setApplicationKey(applicationKey);
		applicationResume.setL2ProductCode(l2ProductCode);
		applicationResume.setL2ProductKey(l2ProductKey != null ? l2ProductKey.intValue() : null);
		applicationResume.setResume(true);
		applicationResume.setOfferDetails(getOffersWithOfferPriorityOne(applicationKey));
		execution.setVariable(CreditBusinessConstants.APPLICATIONKEY, applicationKey);
		execution.setVariable(CreditBusinessConstants.L2_PRODUCT_CODE, l2ProductCode);
		execution.setVariable(CreditBusinessConstants.L2_PRODUCT_KEY, null != l2ProductKey ? l2ProductKey.longValue() : null);
		execution.setVariable(CreditBusinessConstants.APPLICATION_STATUS, applicationStatus);
		execution.setVariable(CreditBusinessConstants.ISINPROCESSING, true);
		execution.setVariable(CreditBusinessConstants.APPLICATION_RESUME, applicationResume);
		String hlProductIntent = null != application.get("hlProductIntent") ? application.get("hlProductIntent").toString() : null;
		execution.setVariable(CreditBusinessConstants.HLPRODUCTINTENT, hlProductIntent);
		execution.setVariable(CreditBusinessConstants.APPLICATION_ID, applicationKey);
		execution.setVariable(CreditBusinessConstants.APPLICANTID, applicantKey);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetApplicationForResume");
	}

	@SuppressWarnings("unchecked")
	public void postGetChildApplications(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetChildApplications");
		List<Object> applicationArray = (List<Object>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		JSONObject childApplication = CreditBusinessHelper.getJSONObject(applicationArray.get(0));

		String l2ProductCode = childApplication.get(CreditBusinessConstants.L2_PRODUCT_CODE) != null
				? childApplication.get(CreditBusinessConstants.L2_PRODUCT_CODE).toString()
				: null;
		Double l2ProductKey = childApplication.get(CreditBusinessConstants.L2_PRODUCT_KEY) != null
				? (Double) childApplication.get(CreditBusinessConstants.L2_PRODUCT_KEY)
				: null;
		String childApplicationKey = childApplication.get(CreditBusinessConstants.APPLICATIONKEY) != null
				? childApplication.get(CreditBusinessConstants.APPLICATIONKEY).toString()
				: null;
		String applicationStatus = childApplication.get(CreditBusinessConstants.APPLICATION_STATUS) != null
				? String.valueOf(((Double) childApplication.get(CreditBusinessConstants.APPLICATION_STATUS)).intValue())
				: null;
		String l3ProductCode = childApplication.get(CreditBusinessConstants.L3_PRODUCT_CODE) != null
				? childApplication.get(CreditBusinessConstants.L3_PRODUCT_CODE).toString()
				: null;
		Double l3ProductKey = childApplication.get(CreditBusinessConstants.L3_PRODUCT_KEY) != null
				? (Double) childApplication.get(CreditBusinessConstants.L3_PRODUCT_KEY)
				: null;
		String l4ProductCode = childApplication.get(CreditBusinessConstants.L4_PRODUCT_CODE) != null
				? childApplication.get(CreditBusinessConstants.L4_PRODUCT_CODE).toString()
				: null;
		Double l4ProductKey = childApplication.get(CreditBusinessConstants.L4_PRODUCT_KEY) != null
				? (Double) childApplication.get(CreditBusinessConstants.L4_PRODUCT_KEY)
				: null;
		Double principalKey = childApplication.get(CreditBusinessConstants.PRINCIPALKEY) != null
				? (Double) childApplication.get(CreditBusinessConstants.PRINCIPALKEY)
				: null;
		String parentApplicationKey = childApplication.get(CreditBusinessConstants.PARENT_APPLICATION_KEY) != null
				? childApplication.get(CreditBusinessConstants.PARENT_APPLICATION_KEY).toString()
				: null;
		String applicantKey = childApplication.get(CreditBusinessConstants.APPLICANTKEY) != null
				? childApplication.get(CreditBusinessConstants.APPLICANTKEY).toString()
				: null;

		String riskOfferType = childApplication.get(CreditBusinessConstants.RISKOFFERTYPE) != null
				? childApplication.get(CreditBusinessConstants.RISKOFFERTYPE).toString()
				: null;

		ApplicationResume applicationResume = new ApplicationResume();
		applicationResume.setApplicationKey(parentApplicationKey);
		applicationResume.setL2ProductCode(l2ProductCode);
		applicationResume.setL2ProductKey(null != l2ProductKey ? l2ProductKey.intValue() : null);
		applicationResume.setChildApplicationKey(childApplicationKey);
		applicationResume.setL3ProductCode(l3ProductCode);
		applicationResume.setL3ProductKey(null != l3ProductKey ? l3ProductKey.intValue() : null);
		applicationResume.setL4ProductCode(l4ProductCode);
		applicationResume.setL4ProductKey(null != l4ProductKey ? l4ProductKey.intValue() : null);
		applicationResume.setPrincipalKey(null != principalKey ? principalKey.intValue() : null);
		applicationResume.setResume(true);
		applicationResume.setOfferDetails(getOffersWithOfferPriorityOne(parentApplicationKey));

		execution.setVariable(CreditBusinessConstants.APPLICATIONKEY, parentApplicationKey);
		execution.setVariable(CreditBusinessConstants.APPLICATION_ID, parentApplicationKey);
		execution.setVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY, parentApplicationKey);
		execution.setVariable(CreditBusinessConstants.CHILDAPPLICATIONID, childApplicationKey);

		execution.setVariable(CreditBusinessConstants.L2_PRODUCT_CODE, l2ProductCode);
		execution.setVariable(CreditBusinessConstants.L3_PRODUCT_CODE, l3ProductCode);
		execution.setVariable(CreditBusinessConstants.L4_PRODUCT_CODE, l4ProductCode);

		execution.setVariable(CreditBusinessConstants.L2PRODUCTKEY, l2ProductKey);
		execution.setVariable(CreditBusinessConstants.L3_PRODUCT_KEY, l3ProductKey);
		execution.setVariable(CreditBusinessConstants.L4_PRODUCT_KEY, l4ProductKey);
		execution.setVariable(CreditBusinessConstants.RISKOFFERTYPE, riskOfferType);

		execution.setVariable(CreditBusinessConstants.PRINCIPALKEY, null != principalKey ? String.valueOf(principalKey.intValue()) : null);
		execution.setVariable(CreditBusinessConstants.APPLICANTID, applicantKey);
		execution.setVariable(CreditBusinessConstants.APPLICATION_STATUS, applicationStatus);
		execution.setVariable(CreditBusinessConstants.APPLICATION_RESUME, applicationResume);

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetChildApplications");
	}

	public void postGetProfession(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetProfession");
		execution.setVariable(CreditBusinessConstants.KID_PRESENT, false);
		execution.setVariable(CreditBusinessConstants.EMPLOYER_KID, null);
		execution.setVariable(CreditBusinessConstants.EMPLOYERID, null);
		execution.setVariable(CreditBusinessConstants.IS_SALARIED, false);
		execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, false);
		execution.setVariable(IS_OFFICIALEMAIL_PRESENT, false);
		execution.setVariable(NETSALARY, null);
		execution.setVariable(CreditBusinessConstants.IS_PROL_APPLICANT, false);
		
		JSONObject profession = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (profession != null && profession.get("ocupationType") != null) {
			JSONObject occupationType = CreditBusinessHelper.getJSONObject(profession.get("ocupationType"));
			if (occupationType != null) {
				if (occupationType.get(CreditBusinessConstants.KEY) != null) {
					Double occupationTypeKey = Double.valueOf(occupationType.get(CreditBusinessConstants.KEY).toString());
					execution.setVariable(CreditBusinessConstants.OCCUPATION_TYPE_KEY, occupationTypeKey.intValue());
				}

				if (occupationType.get("code") != null && OccupationTypeEnum.SALARIED.getValue().equalsIgnoreCase(occupationType.get("code").toString())) {
					execution.setVariable(CreditBusinessConstants.IS_SALARIED, true);

					JSONObject salariedDetail = CreditBusinessHelper.getJSONObject(profession.get("salariedDetail"));
					updateProfile.setOfficialEmailPresentFlag(execution, salariedDetail);
				}
				execution.setVariable(CreditBusinessConstants.OCCUPATIONTYPECODE, occupationType.get("code"));
				mcpCheck.setOccupationValue(execution, profession);
				
				if (occupationType.get("code") != null && (OccupationTypeEnum.DOCTOR_SALARIED.getValue()
						.equalsIgnoreCase(occupationType.get("code").toString())
						|| OccupationTypeEnum.DOCTOR_SELF_EMPLOYED.getValue()
								.equalsIgnoreCase(occupationType.get("code").toString())
						|| OccupationTypeEnum.CA_CS_ICWA.getValue()
								.equalsIgnoreCase(occupationType.get("code").toString()))) {
					execution.setVariable(CreditBusinessConstants.IS_PROL_APPLICANT, true);
				}
			}
		}

		if (profession != null && profession.get("salariedDetail") != null) {
			JSONObject salariedDetail = CreditBusinessHelper.getJSONObject(profession.get("salariedDetail"));
			if (salariedDetail != null && salariedDetail.get("employerName") != null) {
				JSONObject employerReference = CreditBusinessHelper.getJSONObject(salariedDetail.get("employerName"));
				if (employerReference.get(CreditBusinessConstants.KEY) != null) {
					Double employerKey = Double.valueOf(employerReference.get(CreditBusinessConstants.KEY).toString());
					execution.setVariable(CreditBusinessConstants.EMPLOYERID, employerKey.intValue());
				}else if(salariedDetail.get(EMPLOYER_NAME_OTHER) != null){ 
					execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, true);
					execution.setVariable(EMPLOYER_NAME_OTHER, salariedDetail.get(EMPLOYER_NAME_OTHER));
				}
			}
			if (salariedDetail != null && salariedDetail.get(NETSALARY) != null) {
				execution.setVariable(NETSALARY, salariedDetail.get(NETSALARY).toString());
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetProfession");
	}

	public void postGetEmployer(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetEmployer");
		execution.setVariable(KID_PRESENT, false);
		execution.setVariable(EMPLOYER_KID, null);
		execution.setVariable(EMPLOYER_NAME, null);
		JSONObject employer = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (employer != null) {
			execution.setVariable(CreditBusinessConstants.EMPRMASTCATEGORY, employer.get(CreditBusinessConstants.EMPRMASTCATEGORY));
			execution.setVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY, employer.get(CreditBusinessConstants.EMPRMASTSUBCATEGORY));
			execution.setVariable(CreditBusinessConstants.EMPR_CLASSIFICATION, employer.get(CreditBusinessConstants.EMPR_CLASSIFICATION));

			if (employer.get(EMPLOYER_KID) != null) {
				execution.setVariable(KID_PRESENT, true);
				execution.setVariable(EMPLOYER_KID, employer.get(EMPLOYER_KID));
			}
			if (employer.get("emprMasterName") != null) {
				execution.setVariable(EMPLOYER_NAME, employer.get("emprMasterName").toString());
			}
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetEmployer");
	}
	
	public void postGetResidenceType(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetResidenceTyp");
		ArrayList<?> residenceTypes = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		String residenceTypeKey = String.valueOf(execution.getVariable(RESIDENCE_TYPE_KEY));
		if (residenceTypes != null) {
			for (Object object : residenceTypes) {
				JSONObject residenceType = CreditBusinessHelper.getJSONObject(object);
				if (residenceType != null) {
					String residenceKey = ((Double) residenceType.get("residenceKey")).toString();
					if (residenceKey.equalsIgnoreCase(residenceTypeKey)) {
						execution.setVariable("residenceValue", residenceType.get("residenceValue"));
						break;
					}
				}
			}

		}
	}

	@SuppressWarnings("unchecked")
	public void preGetEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetEmployer");
		execution.setVariable(CreditBusinessConstants.TYPE_KEY, null);
		ArrayList<Map<String, Object>> outputArray = (ArrayList<Map<String, Object>>) execution.getVariable(CreditBusinessConstants.EMAILTYPE_LIST);
		if (!CollectionUtils.isEmpty(outputArray)) {
			for (Map<String, Object> emailType : outputArray) {
				if (emailType.get(CreditBusinessConstants.EMAILCODE) != null
						&& emailType.get(CreditBusinessConstants.EMAILCODE).toString().equalsIgnoreCase(OFFICE)) {
					execution.setVariable(CreditBusinessConstants.TYPE_KEY,
							emailType.get("emailKey") != null ? Double.valueOf(emailType.get("emailKey").toString()).intValue() : null);
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetEmployer");
	}

	@SuppressWarnings("unchecked")
	public void preUpdateWorkEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preUpdateWorkEmail");
		JSONObject karzaResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.KARZA_VERIFICATION_RESPONSE));
		JSONObject updateEmail = new JSONObject();
		updateEmail.put(CreditBusinessConstants.EMAIL, execution.getVariable(CreditBusinessConstants.WORKEMAILID));
		updateEmail.put(CreditBusinessConstants.TYPE_KEY, execution.getVariable(CreditBusinessConstants.TYPE_KEY));
		updateEmail.put(CreditBusinessConstants.VERIFICATION, karzaResponse != null ? karzaResponse.get(CreditBusinessConstants.VERIFICATION) : null);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, updateEmail);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preUpdateWorkEmail");
	}

	public void postGetEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetEmail");
		JSONObject emailOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		String email = emailOutput.get(CreditBusinessConstants.EMAIL) != null ? (String) emailOutput.get(CreditBusinessConstants.EMAIL) : null;
		execution.setVariable(CreditBusinessConstants.WORKEMAILID, email);
		execution.setVariable(CreditBusinessConstants.ISINPROCESSING, true);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetEmail");
	}

	public void postGetInProgressChildApplication(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetInProgressChildApplication");
		List<Object> applicationArray = (List<Object>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		JSONObject childApplication = CreditBusinessHelper.getJSONObject(applicationArray.get(0));

		String l2ProductCode = childApplication.get(CreditBusinessConstants.L2_PRODUCT_CODE) != null
				? childApplication.get(CreditBusinessConstants.L2_PRODUCT_CODE).toString()
				: null;
		Long l2ProductKey = childApplication.get(CreditBusinessConstants.L2_PRODUCT_KEY) != null
				? ((Double) childApplication.get(CreditBusinessConstants.L2_PRODUCT_KEY)).longValue()
				: null;
		String childApplicationKey = childApplication.get(CreditBusinessConstants.APPLICATIONKEY) != null
				? childApplication.get(CreditBusinessConstants.APPLICATIONKEY).toString()
				: null;
		String l3ProductCode = childApplication.get(CreditBusinessConstants.L3_PRODUCT_CODE) != null
				? childApplication.get(CreditBusinessConstants.L3_PRODUCT_CODE).toString()
				: null;
		Long l3ProductKey = childApplication.get(CreditBusinessConstants.L3_PRODUCT_KEY) != null
				? ((Double) childApplication.get(CreditBusinessConstants.L3_PRODUCT_KEY)).longValue()
				: null;
		String l4ProductCode = childApplication.get(CreditBusinessConstants.L4_PRODUCT_CODE) != null
				? childApplication.get(CreditBusinessConstants.L4_PRODUCT_CODE).toString()
				: null;
		Long l4ProductKey = childApplication.get(CreditBusinessConstants.L4_PRODUCT_KEY) != null
				? ((Double) childApplication.get(CreditBusinessConstants.L4_PRODUCT_KEY)).longValue()
				: null;
		Long principalKey = childApplication.get(CreditBusinessConstants.PRINCIPALKEY) != null
				? ((Double) childApplication.get(CreditBusinessConstants.PRINCIPALKEY)).longValue()
				: null;
		String parentApplicationKey = childApplication.get(CreditBusinessConstants.PARENT_APPLICATION_KEY) != null
				? childApplication.get(CreditBusinessConstants.PARENT_APPLICATION_KEY).toString()
				: null;
		String applicantKey = childApplication.get(CreditBusinessConstants.APPLICANTKEY) != null
				? childApplication.get(CreditBusinessConstants.APPLICANTKEY).toString()
				: null;
		String riskOffetType = null != childApplication.get(RISKOFFERTYPE) ? childApplication.get(RISKOFFERTYPE).toString() : null;

		execution.setVariable(CreditBusinessConstants.APPLICATIONKEY, parentApplicationKey);
		execution.setVariable(CreditBusinessConstants.APPLICATION_ID, parentApplicationKey);
		execution.setVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY, parentApplicationKey);
		execution.setVariable(CreditBusinessConstants.CHILDAPPLICATIONID, childApplicationKey);

		execution.setVariable(CreditBusinessConstants.L2_PRODUCT_CODE, l2ProductCode);
		execution.setVariable(CreditBusinessConstants.L3_PRODUCT_CODE, l3ProductCode);
		execution.setVariable(CreditBusinessConstants.L4_PRODUCT_CODE, l4ProductCode);

		execution.setVariable(CreditBusinessConstants.L2PRODUCTKEY, l2ProductKey);
		execution.setVariable(CreditBusinessConstants.L3_PRODUCT_KEY, l3ProductKey);
		execution.setVariable(CreditBusinessConstants.L4_PRODUCT_KEY, l4ProductKey);

		execution.setVariable(CreditBusinessConstants.PRINCIPALKEY, null != principalKey ? String.valueOf(principalKey.intValue()) : null);

		execution.setVariable(CreditBusinessConstants.APPLICANTID, applicantKey);
		
		execution.setVariable(RISKOFFERTYPE, riskOffetType);
		
		execution.setVariable(CreditBusinessConstants.ETB_TYPE, "NA");
		if(CreditBusinessConstants.PRODUCT_CODE_OMPL.equalsIgnoreCase(l2ProductCode) && riskOffetType != null && ginHelper.checkIsNonGinRiskOffer(riskOffetType)) {
			execution.setVariable(CreditBusinessConstants.ETB_TYPE, EtbVariantEnum.NONGIN.getValue());
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetInProgressChildApplication");
	}

	@SuppressWarnings("unchecked")
	public void preUpdateLoanPurpose(DelegateExecution execution) {
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (null != request && null != request.get("loanPurpose")) {
			JSONObject loanPurpose = CreditBusinessHelper.getJSONObject(request.get("loanPurpose"));
			loanPurpose.put("key", ((Double) loanPurpose.get("key")).longValue());
			execution.setVariable(PAYLOAD, loanPurpose);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "loanPurpose not available in the request");
		}
	}

	public void postGetBTBankDetails(DelegateExecution execution) {
		ArrayList<Map<String, Object>> btBankList = (ArrayList<Map<String, Object>>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		for (Map<String, Object> g : btBankList) {
			execution.setVariable(CreditBusinessConstants.BTBANKNAME, g.get("bankName").toString());
		}
	}

	public void postGetParentApplicationStatus(DelegateExecution execution) {
		JSONObject statusResponse = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		String status = null;
		if (null != statusResponse && null != statusResponse.get("statusValue")) {
			status = statusResponse.get("statusValue").toString();
		}
		execution.setVariable(PARENT_STATUS, status);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_CONTROLLER, "Parent Application Status: " + status);
	}

	public void setTakeBackToListingAction(DelegateExecution execution) {
		if (null == execution.getVariable("action")) {
			execution.setVariable("action", null);
		}
		execution.setVariable(CreditBusinessConstants.TAKE_BACK_TO_LISTING_PAGE, true);
	}

	public void postGetSecuredLoanPricing(DelegateExecution execution) {
		Map<String, Object> existingpricing = getSecuredJourneyPricing(execution);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, existingpricing);
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getSecuredJourneyPricing(DelegateExecution execution) {
		if (execution.getVariable(CreditBusinessConstants.OUTPUT) != null) {
			List<Map<String, Object>> outputList = (ArrayList<Map<String, Object>>) execution.getVariable(CreditBusinessConstants.OUTPUT);
			if (!CollectionUtils.isEmpty(outputList)) {
				for (Map<String, Object> output : outputList) {
					List<Map<String, Object>> feesList = (List<Map<String, Object>>) output.get("fees");
					Double totalFee = 0d;
					Double netDisbursementamount = 0d;
					for (Map<String, Object> f : feesList) {
						totalFee = Double.sum(totalFee, BigDecimal.valueOf((Double) (f.get("feesInAmount"))).doubleValue());
					}
					netDisbursementamount = BigDecimal.valueOf((Double) (output.get("finalLoanAmount"))).doubleValue() - totalFee;
					output.put("netDisbursementAmount", netDisbursementamount);
					if (output.get("source") != null && CreditBusinessConstants.JOURNEY.equalsIgnoreCase(output.get("source").toString())) {
						return output;

					}
				}
			}
		}
		return null;
	}

	public void removeRequestPayload(DelegateExecution execution) {
		execution.removeVariable(PAYLOAD);
	}

	public void preGetUTMs(DelegateExecution execution) {
		execution.setVariable("utm_event", UTM_APP_CREATE_EVENT);
	}

	public void postGetUTMs(DelegateExecution execution) {
		Object utmResponseObject = execution.getVariable(CreditBusinessConstants.OUTPUT);

		Map<String, String> utmForHeaders = null;
		if (null != utmResponseObject) {
			List<Map<String, Object>> utmResponse = (ArrayList<Map<String, Object>>) utmResponseObject;
			JSONObject utmParams = CreditBusinessHelper.getJSONObject(utmResponse.get(0));

			utmForHeaders = new HashMap<String, String>();

			utmForHeaders.put("utm_source", null != utmParams.get("utmsource") ? utmParams.get("utmsource").toString() : null);
			utmForHeaders.put("utm_medium", null != utmParams.get("utmmedium") ? utmParams.get("utmmedium").toString() : null);
			utmForHeaders.put("utm_content", null != utmParams.get("utmcontent") ? utmParams.get("utmcontent").toString() : null);
			utmForHeaders.put("utm_term", null != utmParams.get("utmterm") ? utmParams.get("utmterm").toString() : null);
			utmForHeaders.put("utm_campaign", null != utmParams.get("utmcampaign") ? utmParams.get("utmcampaign").toString() : null);

		}
		execution.setVariable(REQUEST_HEADERS, utmForHeaders);
	}

	public void postGetAddress(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetAddress");
		JSONObject addressOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.PINCODEKEY, addressOutput.get("pincodeKey"));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetAddress");
	}

	public void postGetDocumentPushStatus(DelegateExecution execution) {
		Object documentPushStatusResponse = execution.getVariable(OUTPUT);

		execution.setVariable("documentPushRequired", true);
		if (null != documentPushStatusResponse) {
			List<Object> documentTrackingBeans = (List<Object>) documentPushStatusResponse;

			documentTrackingBeans.stream().forEach(documentTrackingBean -> {
				if (null != documentTrackingBean) {
					JSONObject documentTrackingBeanJson = CreditBusinessHelper.getJSONObject(documentTrackingBean);
					if (null != documentTrackingBeanJson.get("docsentstatus")
							&& DOC_SENT_STATUS_SUCCESS.equalsIgnoreCase(documentTrackingBeanJson.get("docsentstatus").toString())) {
						execution.setVariable("documentPushRequired", false);
					}
				}
			});
		}

	}

	public void preDocumentPush(DelegateExecution execution) {
		execution.setVariable("documentPushSource", SOURCE_JOURNEY);

		JSONObject payload = new JSONObject();
		payload.put("principleKey", execution.getVariable(PRINCIPALKEY).toString());

		execution.setVariable(PAYLOAD, payload);
	}

	public void preOffersFetch(DelegateExecution execution) {
		execution.setVariable(SKIP_API_EXCEPTION, true);
	}

	public void postOffersFetch(DelegateExecution execution) {
		Object apiException = execution.getVariable(API_EXCEPTION_ARISE);

		if (null != apiException && (boolean) apiException) {
			execution.setVariable(OFFER_AVAILABLE, false);
		} else {
			List<Object> offerResponse = (List<Object>) execution.getVariable(OUTPUT);

			execution.setVariable(OFFER_AVAILABLE, false);
			for (Object offer : offerResponse) {
				JSONObject offerJson = CreditBusinessHelper.getJSONObject(offer);
				if (null != offerJson && null != offerJson.get("offerSrcKey") && 3l == ((Double) offerJson.get("offerSrcKey")).longValue()) {
					execution.setVariable(OFFER_AVAILABLE, true);
					break;
			}
		}

		}

		// remove exception skip flags from execution once task gets completed
		List<String> variablesToRemoveFromExecution = new ArrayList<String>();
		variablesToRemoveFromExecution.add(SKIP_API_EXCEPTION);
		variablesToRemoveFromExecution.add(API_EXCEPTION_ARISE);

		execution.removeVariables(variablesToRemoveFromExecution);
	}
	
	@SuppressWarnings("unchecked")
	public void preDocumentSynchWithChildApp(DelegateExecution execution) {
		JSONObject documentSynchRequest = new JSONObject();
		documentSynchRequest.put("parentApplicationId", execution.getVariable(PARENT_APPLICATION_KEY));
		documentSynchRequest.put("childApplicationId", execution.getVariable(CHILDAPPLICATIONID));
		documentSynchRequest.put("principalKey", execution.getVariable(PRINCIPALKEY));
		
		execution.setVariable(CreditBusinessConstants.PAYLOAD, documentSynchRequest);
	}
	
	public void preUpdateRelatedPersonnel(DelegateExecution execution) {
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (request != null && request.get("relatedPersonnelDetails") != null) {
			ArrayList<JSONObject> payloadArr = new ArrayList<JSONObject>() ;
			ArrayList<?> relatedPersonnelsArr = (ArrayList<?>) request.get("relatedPersonnelDetails");
			for (Object eachRelatedPersonnelObj : relatedPersonnelsArr) {
				JSONObject eachRelatedPersonnel = CreditBusinessHelper.getJSONObject(eachRelatedPersonnelObj);
				payloadArr.add(eachRelatedPersonnel);
			}
			execution.setVariable(CreditBusinessConstants.PAYLOAD, payloadArr);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "relatedPersonnelDetails not available in the request");
		}
	}
	
	public void postGetPersonalEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetPersonalEmail");
		JSONObject emailOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		String email = emailOutput.get(CreditBusinessConstants.EMAIL) != null ? (String) emailOutput.get(CreditBusinessConstants.EMAIL) : null;
		execution.setVariable(CreditBusinessConstants.PERSONALEMAILID, email);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetPersonalEmail");
	}
	
	private AppOfferDetBean getOffersWithOfferPriorityOne(String applicationKey) {
		List<AppOfferDetBean> offerDetails = apiCallsHelper.fetchOffers(applicationKey, null, new HttpHeaders());
			if (!CollectionUtils.isEmpty(offerDetails)) {
				List<AppOfferDetBean> appOfferDetails = offerDetails.stream()
						.filter(offerDet -> Objects.nonNull(offerDet.getOfferPriority()))
						.filter(offerDet -> offerDet.getOfferPriority().intValue() == 1)
						.collect(Collectors.toList());
				if(!CollectionUtils.isEmpty(appOfferDetails)) {
					return appOfferDetails.get(0);
				}
			}
		return null;
	}
	
	public void getEmployer(DelegateExecution execution) throws JsonProcessingException {
		execution.setVariable(KID_PRESENT, false);
		execution.setVariable(EMPLOYER_KID, null);
		execution.setVariable(EMPLOYER_NAME, null);
		if (null != execution.getVariable(CreditBusinessConstants.EMPLOYERID)) {
			Long employerKey = Long.parseLong(execution.getVariable(CreditBusinessConstants.EMPLOYERID).toString());
			EmployerMasterBean employerMaster = redisHelper.getEmployerByKey(employerKey);
			if (null != employerMaster) {
				execution.setVariable(CreditBusinessConstants.EMPRMASTCATEGORY, employerMaster.getEmprMastCategory());
				execution.setVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY,
						employerMaster.getEmprMastSubcategory());
				execution.setVariable(EMPLOYER_NAME, employerMaster.getEmprMasterName());
				if (null != employerMaster.getEmployerKid()) {
					execution.setVariable(KID_PRESENT, true);
					execution.setVariable(EMPLOYER_KID, employerMaster.getEmployerKid());
				}
			}
		}
	}
	
	public void checkRepaymentFlowFlag(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start checkRepaymentFlowFlag");
		execution.setVariable(CreditBusinessConstants.ANALYTICS_REPAYMENT_FLOW_FLAG, analyticsRepaymentFlowFlag);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end checkRepaymentFlowFlag");
	}
	
	public void getApprovedLoanPricing(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start getApprovedLoanPricing");
		Map<String, Object> existingpricing = (Map<String, Object>) getEpApprovedPricing(execution);
		if (null == existingpricing) {
			existingpricing = getJourneyPricing(execution);
		}
		existingpricing.put(CreditBusinessConstants.PARENT_APPLICATION_KEY,
				execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, existingpricing);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start getApprovedLoanPricing");
	}

	private Object getEpApprovedPricing(DelegateExecution execution) {
		List<?> loanPricingDetails = (List<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		if (!CollectionUtils.isEmpty(loanPricingDetails)) {
			Optional<?> epPricing = loanPricingDetails.stream().filter(i -> {
				Map<String, Object> j = (Map<String, Object>) i;
				return (j.get("pricingStatus") != null && j.get("source") != null
						&& "EP".equalsIgnoreCase(j.get("source").toString())
						&& CreditBusinessConstants.APPROVED.equalsIgnoreCase(j.get("pricingStatus").toString()));
			}).findFirst();

			if (epPricing.isPresent()) {
				return epPricing.get();
			}
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public void preCreateChildApplication(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCreateChildApplication");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject childApplication = new JSONObject();
		childApplication.put(CreditBusinessConstants.PARENT_APPLICATION_KEY, request.get(CreditBusinessConstants.PARENT_APPLICATION_KEY));
		childApplication.put(CreditBusinessConstants.L2_PRODUCT_KEY, request.get(CreditBusinessConstants.L2_PRODUCT_KEY));
		childApplication.put(CreditBusinessConstants.L2_PRODUCT_CODE, request.get(CreditBusinessConstants.L2_PRODUCT_CODE));
		childApplication.put(CreditBusinessConstants.L3_PRODUCT_CODE, request.get(CreditBusinessConstants.L3_PRODUCT_CODE));
		childApplication.put(CreditBusinessConstants.L4_PRODUCT_CODE, request.get(CreditBusinessConstants.L4_PRODUCT_CODE));
		childApplication.put(CreditBusinessConstants.PRODUCT_LISTING_KEY, request.get(CreditBusinessConstants.PRODUCT_LISTING_KEY));
		childApplication.put(RISK_OFFER_TYPE, request.get(RISK_OFFER_TYPE_));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, childApplication);
		execution.setVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY, request.get(CreditBusinessConstants.PARENT_APPLICATION_KEY));
		execution.setVariable(CreditBusinessConstants.APPLICATION_ID, request.get(CreditBusinessConstants.PARENT_APPLICATION_KEY).toString());
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCreateChildApplication");
	}
	
	public void postCreateChildApplication(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postCreateChildApplication");
		JSONObject childApplicationObject = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CHILD_APPLICATION_RESPONSE, childApplicationObject);
		execution.setVariable(CreditBusinessConstants.CHILDAPPLICATIONID,
				null != childApplicationObject.get(APPLICATIONKEY) ? childApplicationObject.get(APPLICATIONKEY).toString() : null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postCreateChildApplication");
	}
	
	@SuppressWarnings("unchecked")
	public void buildRequestForUpdateApplicationParameters(DelegateExecution execution) {
		JSONObject profilePageRequestPayload = CreditBusinessHelper.getJSONObject(execution.getVariable(REQUEST));
		if (null != profilePageRequestPayload) {
			JSONObject payload = new JSONObject();
			JSONObject applicationParameters = new JSONObject();
			if (null != profilePageRequestPayload.get(REQUIRED_LOAN_AMOUNT)) {
				Double reqLoanAmt = (Double) profilePageRequestPayload.get(REQUIRED_LOAN_AMOUNT);
				applicationParameters.put(REQUESTEDCREDITAMOUNT, null != reqLoanAmt ? reqLoanAmt.intValue() : null);
			}
			payload.put(APPLICATION_PARAMETERS, applicationParameters);
			execution.setVariable(PAYLOAD, payload);
		}
	}
	
	public void preRejectionApplicationStatusUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preRejectionApplicationStatusUpdate - start");
		JSONObject payload = new JSONObject();
		payload.put("statusValue", ApplicationStatusEnum.REJECTED.getCode());
		payload.put("statusKey", ApplicationStatusEnum.REJECTED.getKey());
		execution.setVariable(PAYLOAD, payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preRejectionApplicationStatusUpdate - end");
	}
}
