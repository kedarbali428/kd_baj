package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
public class IciciBankCardsJourneyListener {
	
	private static final String CLASS_NAME = IciciBankCardsJourneyListener.class.getCanonicalName();
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@SuppressWarnings("unchecked")
	public void preDocumentKeyUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "preDocumentKeyUpdate - Start");
		JSONObject payload = null;
		List<Long> principleDocTypeKeys = new ArrayList<Long>();
		JSONObject additionalDetails = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (null != additionalDetails && null != additionalDetails.get("applicantIdProof")
				&& null != additionalDetails.get("addressProof")) {
			JSONObject applicantIdProof = CreditBusinessHelper.getJSONObject(additionalDetails.get("applicantIdProof"));
			JSONObject addressProof = CreditBusinessHelper.getJSONObject(additionalDetails.get("addressProof"));

			if (null != applicantIdProof && null != applicantIdProof.get("key") && null != addressProof
					&& null != addressProof.get("key")) {
				payload = new JSONObject();
				principleDocTypeKeys.add(Double.valueOf(applicantIdProof.get("key").toString()).longValue());
				principleDocTypeKeys.add(Double.valueOf(addressProof.get("key").toString()).longValue());
				payload.put("principleDocTypeKeys", principleDocTypeKeys);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE,
						" applicantIdProofkey  and addressProofkey not present with request: " + additionalDetails);
			}
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE,
					"applicantIdProof  and addressProof not present with request: " + additionalDetails);
		}
		execution.setVariable(PAYLOAD, payload);
	}
	
	@SuppressWarnings("unchecked")
	public void prePrincipalAdditionalDetailUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "prePrincipalAdditionalDetailUpdate - Start");
		JSONObject payload = null;
		JSONObject applicationPrincipalAdditionalDetails = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (null != applicationPrincipalAdditionalDetails) {
			payload = new JSONObject();
			payload.put("hasSalaryAccount", applicationPrincipalAdditionalDetails.get("hasSalaryAccount"));
			payload.put("appointmentDateTimeFrom",
					 applicationPrincipalAdditionalDetails.get("appointmentDateTimeFrom"));
			payload.put("appointmentDateTimeTo",
					 applicationPrincipalAdditionalDetails.get("appointmentDateTimeTo"));
			payload.put("appointmentAddressTypeCode",
					applicationPrincipalAdditionalDetails.get("appointmentAddressTypeCode"));
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE,
					"applicationPrincipalAdditionalDetails not present with request: "
							+ applicationPrincipalAdditionalDetails);
		}
		execution.setVariable(PAYLOAD, payload);
	}
}
