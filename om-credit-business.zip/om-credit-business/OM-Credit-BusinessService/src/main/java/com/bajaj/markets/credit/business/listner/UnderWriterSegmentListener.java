package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMPRMASTCATEGORY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;

@Component
public class UnderWriterSegmentListener {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	private static final String CLASS_NAME = UnderWriterSegmentListener.class.getCanonicalName();
	
	public void preApi(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preApi");
		JSONObject uwSegmentBRERequest = new JSONObject();
		uwSegmentBRERequest.put(EMPRMASTCATEGORY, execution.getVariable(EMPRMASTCATEGORY));
		uwSegmentBRERequest.put(CreditBusinessConstants.EMPRMASTSUBCATEGORY,
				execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY));
		uwSegmentBRERequest.put(CreditBusinessConstants.CREDITVIDYA_RISKCATEGORY,
				execution.getVariable(CreditBusinessConstants.CREDITVIDYA_RISKCATEGORY));
		uwSegmentBRERequest.put(CreditBusinessConstants.ADDITIONAL_CIBILFLAG,
				execution.getVariable(CreditBusinessConstants.ADDITIONAL_CIBILFLAG));
		uwSegmentBRERequest.put(CreditBusinessConstants.CIBIL_SCORE,
				execution.getVariable(CreditBusinessConstants.CIBIL_SCORE));
		uwSegmentBRERequest.put(CreditBusinessConstants.NSDLNAMEMATCHFLAG,
				execution.getVariable(CreditBusinessConstants.NSDLNAMEMATCHFLAG));
		uwSegmentBRERequest.put("officialMailVerification",execution.getVariable("emailVerified"));
		uwSegmentBRERequest.put("residenceType",execution.getVariable("residenceValue"));
		uwSegmentBRERequest.put("cityLocation", execution.getVariable("cityLocation"));
		execution.setVariable(PAYLOAD, uwSegmentBRERequest);
	}
}
