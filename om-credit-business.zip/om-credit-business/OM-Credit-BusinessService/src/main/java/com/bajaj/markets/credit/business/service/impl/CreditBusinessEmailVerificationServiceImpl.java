package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CREDIT_JOURNEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OFFICIAL_EMAIL_TYPE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PROCESS_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.RESUME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.RISKOFFERTYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.TYPE_KEY;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.EmailDetails;
import com.bajaj.markets.credit.business.beans.EmailPageActions;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.beans.Verification;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessEmailVerificationService;

@Component
public class CreditBusinessEmailVerificationServiceImpl implements CreditBusinessEmailVerificationService {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	WorkflowHelper workflowHelper;
	
	@Autowired
	CreditBusinessHelper helper;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallHelper;
	
	@Autowired
	CreditBusinessGinHelper etbGinHelper;
	
	@Value("${api.omcreditapplicationservice.getemail.get.url}")
	String emailGetURL;
	
	@Value("#{'${om.email.verification.tasknames}'.split(',')}")
	List<String> emailVerificationTasknames;
	
	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String childApplicationGetURL;
	
	@Value("${api.applicationservice.productlist.get.url}")
	private String productListGetURL;
	
	@Value("${om.email.verification.sources}")
	private String configuredVerificationSources;
	
	public static final String CLASS_NAME = CreditBusinessEmailVerificationServiceImpl.class.getCanonicalName();
	
	@Override
	public ApplicationResponse validateEmail(Long applicationId, EmailDetails emailDetails, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start - validateEmailOtp: " + emailDetails);
		try {
			ApplicationResponse applicationResponse = null;
			if(!EmailPageActions.VALIDATEEMAILTOKEN.toString().equals(emailDetails.getAction().toString())) {
				String processId = headers.get(PROCESS_ID).get(0);
				
				Map<String, Object> vars = new HashMap<>();
				vars.put(APPLICATION_ID, applicationId);
				vars.put("action", emailDetails.getAction().toString());
				vars.put("EX_emailDetail", CreditBusinessHelper.objectToJson(emailDetails));
	
				NextTask nextTask = new NextTask();
				
				nextTask.setNextTaskKey(workflowHelper.completeTask(processId, vars));
				
				applicationResponse = new ApplicationResponse();
	
				applicationResponse.setNextTask(nextTask);
				
				Object emailResponse = workflowHelper.getFromExecutionMap("emailPageResponsePayload", processId);
				applicationResponse.setPayload(null != emailResponse ? CreditBusinessHelper.getJSONObject(emailResponse) : null);
	
				logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End - validateEmailOtp: " + applicationResponse);
				
			} else {
				try {
					emailDetails.setVerified(false);
					
					JSONObject payload = new JSONObject();
					payload.put(CreditBusinessConstants.APPLICATION_ID, applicationId.toString());
					payload.put(CreditBusinessConstants.JOURNEY, RESUME);
					
					NextTask nextTask = workflowHelper.startActivitiProcess(CREDIT_JOURNEY, payload);
					
					if (null != nextTask && !StringUtils.isEmpty(nextTask.getNextTaskKey()) 
							&& emailVerificationTasknames.contains(nextTask.getNextTaskKey())) {
						Map<String, Object> vars = new HashMap<>();
						vars.put(APPLICATION_ID, applicationId);
						vars.put("action", emailDetails.getAction().toString());
						vars.put("EX_emailDetail", CreditBusinessHelper.objectToJson(emailDetails));
						
						workflowHelper.completeTask(nextTask.getProcessID(), vars);
						
						Object emailVerifiedObj = workflowHelper.getFromExecutionMap("emailVerified", nextTask.getProcessID());
						if(null != emailVerifiedObj) {
							emailDetails.setVerified(Boolean.valueOf(emailVerifiedObj.toString()));
						}
					} else {
						logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Not a valid stage for email verification: " + applicationId);
					}
					
				} catch (CreditBusinessException businessExpetion) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while validating email token for: " + applicationId,
							businessExpetion);
				}	
				
				applicationResponse = new ApplicationResponse();
				applicationResponse.setPayload(emailDetails);
				applicationResponse.setNextTask(null);
			}
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End - validateEmailOtp: " + applicationResponse);
			
			return applicationResponse;
		} catch (CreditBusinessException creditBusinessException) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "CreditBusinessException: ", creditBusinessException);
			throw creditBusinessException;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while validating email otp: " + e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-500", "Some Technical Exception Occurred"));
		}
	}

	@Override
	public EmailDetails getEmailVerificationDetails(Long applicationId, HttpHeaders headers, String task) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "start - getEmailVerificationDetails with request: " + applicationId);
		EmailDetails emailDetail = null;
		
		Map<String, String> params = new HashMap<>();
		
		try {
			// Get user attribute key
			params.put(APPLICATION_ID, applicationId.toString());
			UserProfileBean userProfile = apiCallHelper.getUserProfile(params);
			
			if(null != userProfile) {
				// Get Email
				params.put("userattributekey", userProfile.getApplicationUserAttributeKey());
				params.put(TYPE_KEY, OFFICIAL_EMAIL_TYPE_KEY);
				
				Email email = getEmailDetails(params, headers, task);
				
				if(null != email) {
					emailDetail = new EmailDetails();
					
					emailDetail.setEmail(email.getEmail());
					emailDetail.setEmailTypeKey(email.getTypeKey());
					
					List<Verification> verifications = email.getVerifications();
					
					emailDetail.setVerified(false);
					if(null != verifications) {
						for (Verification verification : verifications) {
							if(configuredVerificationSources.contains(verification.getVerificationSource())) {
								emailDetail.setVerified(verification.getIsVerified());
								break;
							}
						}
					}
				} 
				
				if(!StringUtils.isEmpty(task) && !"emailverification".equalsIgnoreCase(task)) {
					if (null != emailDetail && null != emailDetail.getVerified() && !emailDetail.getVerified()) {
						emailDetail.setEmailVerificationVisible(checkEtbOfferAndEmailVerificationRequired(params, userProfile, headers));
					} else {
						emailDetail = new EmailDetails();
						emailDetail.setEmailVerificationVisible(false);
					}
				}
				
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "User profile not found for application: " + applicationId);
				throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("", "User Profile Not Found!"));
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "end - getEmailVerificationDetails with response: " + emailDetail);
			return emailDetail;
		} catch (CreditBusinessException creditBusinessException) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured : " + creditBusinessException);
			if (HttpStatus.NOT_FOUND.equals(creditBusinessException.getCode())) {
				throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("CBS-102", "Resource not found."));
			}
			throw creditBusinessException;
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,"Exception Occured while getting Email Details with applicationid: " + applicationId
					 		+ " with exception: " + exception);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "Some Technical Exception Occured"));
		}
	}

	private Email getEmailDetails(Map<String, String> params, HttpHeaders headers, String task) {
		ResponseEntity<Email> apiResponse = null;
		try {
			apiResponse = (ResponseEntity<Email>) helper.invokeRestEndpoint(HttpMethod.GET, emailGetURL, Email.class, params, null, headers);
		} catch(CreditBusinessException creditBusinessException) {
			if (HttpStatus.NOT_FOUND.equals(creditBusinessException.getCode()) && !StringUtils.isEmpty(task)
					&& !"emailverification".equalsIgnoreCase(task)) {
				return null;
			} else {
				throw creditBusinessException;
			}
		}
		return apiResponse != null ? apiResponse.getBody() : null;
	}
	
	@SuppressWarnings("unchecked")
	private boolean checkEtbOfferAndEmailVerificationRequired(Map<String, String> params, UserProfileBean userProfile, HttpHeaders headers) {
		boolean isEmailVerificationRequired = false;
		boolean etbOffer = false;
		
		params.put("applicationkey", userProfile.getApplicationKey());
		params.put("isInProcessing", "true");
		
		ResponseEntity<?> applicationResponseEntity = helper.invokeRestEndpoint(HttpMethod.GET, 
				childApplicationGetURL, Object.class, params, null, headers);

		ArrayList<Object> applicationResponseList = null != applicationResponseEntity.getBody() ? 
				(ArrayList<Object>) applicationResponseEntity.getBody() : null;
				
		if(!CollectionUtils.isEmpty(applicationResponseList) && applicationResponseList.size() == 1) {
			JSONObject applicationResponse = CreditBusinessHelper.getJSONObject(applicationResponseList.get(0));
			
			etbOffer = etbGinHelper.checkIsEtbOffer(null != applicationResponse.get(RISKOFFERTYPE) ?
					applicationResponse.get(RISKOFFERTYPE).toString() : null);
			
			if(etbOffer) {
				isEmailVerificationRequired = isEmailVerificationRequired(null != applicationResponse.get("applicationKey") ?
					applicationResponse.get("applicationKey").toString() : null, headers);
			}
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Etb offer flag for child application offer type: " + etbOffer);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Either child application is null or non unique for the application: " + userProfile);
		}
		return etbOffer && isEmailVerificationRequired;
	}
	
	@SuppressWarnings("unchecked")
	private boolean isEmailVerificationRequired(String childApplicationKey, HttpHeaders headers) {
		boolean isEmailVerificationRequired = false;
		
		Map<String, String> params = new HashMap<>();
		params.put(APPLICATION_ID, childApplicationKey);
		
		ResponseEntity<?> productListResponseEntity = helper.invokeRestEndpoint(HttpMethod.GET, 
				productListGetURL, Object.class, params, null, headers);
		
		JSONObject productListReponse = CreditBusinessHelper.getJSONObject(productListResponseEntity.getBody());
		ArrayList<Object> productList = null != productListReponse && null != productListReponse.get("productList") 
				? (ArrayList<Object>) productListReponse.get("productList") : null;
		
		if(!CollectionUtils.isEmpty(productList)) {
			Object emailVerificationRequiredFlag = CreditBusinessHelper.getJSONObject(productList.get(0)).get("emailverificationrequiredflag");
			if (null != emailVerificationRequiredFlag && 1 == ((Double) emailVerificationRequiredFlag).intValue()) {
				isEmailVerificationRequired = true;
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "either emailverificationrequiredflag null or 0 for: " + childApplicationKey);
			}
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "product list null for child application: " + childApplicationKey);
		}
		
		return isEmailVerificationRequired;
	}
}
