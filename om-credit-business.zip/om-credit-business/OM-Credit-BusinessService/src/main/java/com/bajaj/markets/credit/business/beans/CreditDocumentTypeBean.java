package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.sql.Timestamp;

public class CreditDocumentTypeBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer creditdoctype;
	
	private Integer prodmastkey;
	
	private Long prodcatkey;
	
	private Long prodkey;
	
	private String doccatcode;
	
	private String doctypecode;
	
	private String bfsddocname;
		
	private String partnerdocname;
	
	private Integer docavailable;
	
	private Timestamp doccreateddt;	

	private String partnerdoctype;
	
	private Integer filesizelimitkb;
	
	private String docformat;

	public Integer getCreditdoctype() {
		return creditdoctype;
	}

	public void setCreditdoctype(Integer creditdoctype) {
		this.creditdoctype = creditdoctype;
	}

	public Integer getProdmastkey() {
		return prodmastkey;
	}

	public void setProdmastkey(Integer prodmastkey) {
		this.prodmastkey = prodmastkey;
	}

	public Long getProdcatkey() {
		return prodcatkey;
	}

	public void setProdcatkey(Long prodcatkey) {
		this.prodcatkey = prodcatkey;
	}

	public Long getProdkey() {
		return prodkey;
	}

	public void setProdkey(Long prodkey) {
		this.prodkey = prodkey;
	}

	public String getBfsddocname() {
		return bfsddocname;
	}

	public void setBfsddocname(String bfsddocname) {
		this.bfsddocname = bfsddocname;
	}

	public String getPartnerdocname() {
		return partnerdocname;
	}

	public void setPartnerdocname(String partnerdocname) {
		this.partnerdocname = partnerdocname;
	}

	public Integer getDocavailable() {
		return docavailable;
	}

	public void setDocavailable(Integer docavailable) {
		this.docavailable = docavailable;
	}

	public Timestamp getDoccreateddt() {
		return doccreateddt;
	}

	public void setDoccreateddt(Timestamp doccreateddt) {
		this.doccreateddt = doccreateddt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getPartnerdoctype() {
		return partnerdoctype;
	}

	public void setPartnerdoctype(String partnerdoctype) {
		this.partnerdoctype = partnerdoctype;
	}

	public Integer getFilesizelimitkb() {
		return filesizelimitkb;
	}

	public void setFilesizelimitkb(Integer filesizelimitkb) {
		this.filesizelimitkb = filesizelimitkb;
	}

	public String getDocformat() {
		return docformat;
	}

	public void setDocformat(String docformat) {
		this.docformat = docformat;
	}

	public String getDoccatcode() {
		return doccatcode;
	}

	public void setDoccatcode(String doccatcode) {
		this.doccatcode = doccatcode;
	}

	public String getDoctypecode() {
		return doctypecode;
	}

	public void setDoctypecode(String doctypecode) {
		this.doctypecode = doctypecode;
	}

	@Override
	public String toString() {
		return "ApplicationDocumentPushMasterResponseBean [creditdoctype=" + creditdoctype + ", prodmastkey="
				+ prodmastkey + ", prodcatkey=" + prodcatkey + ", prodkey=" + prodkey + ", doccatcode=" + doccatcode
				+ ", doctypecode=" + doctypecode + ", bfsddocname=" + bfsddocname + ", partnerdocname=" + partnerdocname
				+ ", docavailable=" + docavailable + ", doccreateddt=" + doccreateddt + ", partnerdoctype="
				+ partnerdoctype + ", filesizelimitkb=" + filesizelimitkb + ", docformat=" + docformat + "]";
	}

	
	
	
}
