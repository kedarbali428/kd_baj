package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.ADD_SRC_APPLICANT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.ADD_SRC_OFFERAPI;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.ALLOW_CURRENT_ADDRESS_UPDATE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CITY_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DATE_OF_BIRTH;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DOB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.FULLNAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PINCODEKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SALARIED;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OccupationReference;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.beans.SaveUserTaskRequest;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.beans.UserTaskContent;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.EtbVariantEnum;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.OccupationTypeEnum;
import com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class NonGinEtbListener {

	private static final String PINCODE = "pincode";
	private static final String OCCUPATION_TYPE_KEY = "occupationTypeKey";
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallHelper;
	
	@Autowired
	MasterDataRedisClientHelper masterDataRedisClientHelper;
	
	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getOccupationUrl;
	
	@Autowired
	CreditBusinessGinHelper ginHelper;

	private static final String CLASS_NAME = NonGinEtbListener.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void preBasicDetail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preBasicDetail in GinEtb flow");
		JSONObject profileDetails = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		Gson gson = new Gson();
		SaveUserTaskRequest saveUserTask = gson.fromJson(profileDetails.toString(), SaveUserTaskRequest.class);
		JSONObject updateProfile = new JSONObject();
		for (UserTaskContent userTaskContent : saveUserTask.getUserTaskContent()) {
			if (null != userTaskContent.getContent()) {
				switch (userTaskContent.getName()) {
				case "Name":
					String fullName = userTaskContent.getContent().getText();
					String[] nameArr = fullName.split("\\s+");
					JSONObject nameObj = new JSONObject();
					nameObj.put("firstName", nameArr[0]);
					nameObj.put("middleName", fullName.substring(fullName.indexOf(" "), fullName.lastIndexOf(" ")));
					nameObj.put("lastName", nameArr[nameArr.length - 1]);
					updateProfile.put(CreditBusinessConstants.NAME, nameObj);
					execution.setVariable(CreditBusinessConstants.NAME, nameObj);
					execution.setVariable(CreditBusinessConstants.FULLNAME, fullName);
					break;
				case "pan":
					updateProfile.put(CreditBusinessConstants.PAN_NUMBER, userTaskContent.getContent().getText());
					execution.setVariable(CreditBusinessConstants.PAN_NUMBER, userTaskContent.getContent().getText());
					break;
				case "resiStatus":
					ResidenceMaster[] resiTypes = apiCallHelper.getAllResitypes();
					if (null != resiTypes && resiTypes.length > 0) {
						for (ResidenceMaster resi : resiTypes) {
							if (null != userTaskContent.getContent() && null != userTaskContent.getContent().getCode()
									&& resi.getResidenceCode().equals(userTaskContent.getContent().getCode())) {
								updateProfile.put(CreditBusinessConstants.RESIDENCETYPEKEY,
										resi.getResidenceKey().toString());
							}
						}
					}
					break;
				case PINCODE:
					execution.setVariable(PINCODE, userTaskContent.getContent().getText());
					Long pincodeKey = (long)Double.parseDouble(userTaskContent.getContent().getCode());
					execution.setVariable("ffPincodeKey", pincodeKey.toString());
					LocationResponseBean locationResponseBean = masterDataRedisClientHelper.getPinCodeByKey(pincodeKey);
					execution.setVariable(CreditBusinessConstants.CITY_KEY,locationResponseBean.getCityKey());
				default:

				}
			}
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, updateProfile);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End  preBasicDetail in GinEtb flow");
	}
	
	@SuppressWarnings("unchecked")
	public void professionUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start professionUpdate");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		Gson gson = new Gson();
		SaveUserTaskRequest saveUserTask = gson.fromJson(request.toString(), SaveUserTaskRequest.class);
		String employerName = null;
		String employerText = null;
		String salary = null;
		execution.setVariable(CreditBusinessConstants.IS_SALARIED, false);
		execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, false);
		execution.setVariable(CreditBusinessConstants.EMPLOYERID, null);
		for (UserTaskContent userTaskContent : saveUserTask.getUserTaskContent()) {
			if (null != userTaskContent.getContent()) {
				switch (userTaskContent.getName()) {
				case "employerName":
					employerName = userTaskContent.getContent().getCode();
					employerText = userTaskContent.getContent().getText();
					break;
				case "salary":
					salary = userTaskContent.getContent().getText();
					break;
				default:
					
				}
			}
		}
		JSONObject salariedDetail = new JSONObject();
		JSONObject professJsonObject = new JSONObject();
		salariedDetail.put("netSalary", salary);
		Map<String, String> params = new HashMap<>();
		params.put(CreditBusinessConstants.APPLICATION_ID, execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		params.put("userattributekey",execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
		ResponseEntity<?> getOccupationResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getOccupationUrl, Object.class, params, null,
				new HttpHeaders());
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		Occupation occupation = mapper.convertValue(getOccupationResponse.getBody(), Occupation.class);
		execution.setVariable(OCCUPATION_TYPE_KEY, occupation.getOcupationType().getKey());
		if (OccupationTypeEnum.SALARIED.getValue().equalsIgnoreCase(occupation.getOcupationType().getCode())) {
			execution.setVariable(CreditBusinessConstants.IS_SALARIED, true);
			execution.setVariable(CreditBusinessConstants.SALARY, salariedDetail.get("netSalary"));
			if (!StringUtils.isEmpty(employerName)) {
				salariedDetail.put("employerName", getReference(Long.valueOf(employerName), null, null));
				execution.setVariable(CreditBusinessConstants.EMPLOYERID,
						employerName);
			} else {
				salariedDetail.put("employerName", getReference(null, null, null));
				salariedDetail.put("employerNameOther", employerText);
				execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, true);
			}
			professJsonObject.put("salariedDetail", salariedDetail);
		} else {
			execution.setVariable(CreditBusinessConstants.IS_SALARIED, false);
		}
		execution.setVariable(CreditBusinessConstants.SALARY, salariedDetail.get("netSalary"));
		professJsonObject.put("salariedDetail", salariedDetail);
		professJsonObject.put("ocupationType", CreditBusinessHelper.getJSONObject(occupation.getOcupationType()));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, professJsonObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End professionUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void preCreateApplicant(DelegateExecution execution) {
		JSONObject profileDetails = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		Gson gson = new Gson();
		SaveUserTaskRequest saveUserTask = gson.fromJson(profileDetails.toString(), SaveUserTaskRequest.class);
		JSONObject applicantRequest = new JSONObject();
		for (UserTaskContent userTaskContent : saveUserTask.getUserTaskContent()) {
			if ("Name".equalsIgnoreCase(userTaskContent.getName()) && null != userTaskContent.getContent()) {
				String fullName = userTaskContent.getContent().getText();
				String[] nameArr = fullName.split("\\s+");
				applicantRequest.put("firstName", nameArr[0]);
				applicantRequest.put("middleName",
						fullName.substring(fullName.indexOf(" "), fullName.lastIndexOf(" ")));
				applicantRequest.put("lastName", nameArr[nameArr.length - 1]);
				applicantRequest.put(DATE_OF_BIRTH, execution.getVariable(DOB));
				applicantRequest.put("mobileNumber", execution.getVariable(MOBILE));
			}
		}
		execution.setVariable(PAYLOAD, applicantRequest);
	}

	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;
	}
	
	public void allowCurrentAddressCheck(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start allowCurrentAddressCheck");
		execution.setVariable(ALLOW_CURRENT_ADDRESS_UPDATE, true);
		List<String> addressSources = new ArrayList<>();
		addressSources.add(ADD_SRC_OFFERAPI);
		addressSources.add(ADD_SRC_APPLICANT);
		String pincode = execution.getVariable(PINCODE).toString();
		Gson gson = new Gson();
		List<Address> addressList = getAllCurrentAddress(execution);
		if (!CollectionUtils.isEmpty(addressList)) {
			for (Object addressObj : addressList) {
				String addressJson = gson.toJson(addressObj);
				Address address = gson.fromJson(addressJson, Address.class);
				if (address.getAddressSource() != null
						&& addressSources.contains(address.getAddressSource().toLowerCase()) && pincode != null
						&& pincode.equalsIgnoreCase(address.getPincode())) {
					execution.setVariable(ALLOW_CURRENT_ADDRESS_UPDATE, false);
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End allowCurrentAddressCheck with checkValue"+execution.getVariable(ALLOW_CURRENT_ADDRESS_UPDATE));
	}

	private List<Address> getAllCurrentAddress(DelegateExecution execution) {
		List<Address> addressList = null;
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		params.put("userattributekey",
				execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
		params.put("returnSingleCurrentAddressFlag", Boolean.FALSE.toString());
		params.put("removeExactMatchCurrentAddress",Boolean.FALSE.toString());
		params.put(CreditBusinessConstants.TYPE_KEY, AddressTypeEnum.CURRENT.getValue());
		try {
			addressList = apiCallHelper.getAddressV2(new HttpHeaders(), params);
		} catch (CreditBusinessException e) {
			if (HttpStatus.NOT_FOUND.equals(e.getCode())) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Resource Not Found exception while fetching V2 address with params = " + params);
				return Collections.emptyList();
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Exception while fetching V2 address with params = " + params, e);
				throw e;
			}
		}
		return addressList;
	}

	@SuppressWarnings("unchecked")
	public void addressUpdate(DelegateExecution execution){
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start addressUpdate");
		String pincode = execution.getVariable(PINCODE).toString();
		Long pincodeKey = null!=execution.getVariable(CreditBusinessConstants.PINCODEKEY)?(long)Double.parseDouble(execution.getVariable(CreditBusinessConstants.PINCODEKEY).toString()):null;
		Long pincodeKeyFromFf1 = (long)Double.parseDouble(execution.getVariable("ffPincodeKey").toString());
		LocationResponseBean locationResponseBean = masterDataRedisClientHelper.getPinCodeByKey(pincodeKeyFromFf1);

		JSONObject addressObject = new JSONObject();
		JSONObject verification = new JSONObject();
		addressObject.put("addressLine1", "");
		addressObject.put("addressLine2", "");
		if(pincodeKey!=null && pincodeKey.equals(pincodeKeyFromFf1)) {
			addressObject.put("addressLine1", execution.getVariable("addressLine1"));
			addressObject.put("addressLine2", execution.getVariable("addressLine2"));
		}
		addressObject.put("addressSource", "JOURNEY");
		addressObject.put("addressTypeKey", AddressTypeEnum.CURRENT.getValue());
		addressObject.put("cityKey", locationResponseBean.getCityKey());
		addressObject.put("countryKey", locationResponseBean.getCountryKey());
		addressObject.put(PINCODE, pincode);
		addressObject.put("pincodeKey", pincodeKeyFromFf1);
		addressObject.put("stateKey", locationResponseBean.getStateKey());
		verification.put(CreditBusinessConstants.IS_VERIFIED, false);
		verification.put(CreditBusinessConstants.VERIFICATION_DATE, "");
		verification.put(CreditBusinessConstants.VERIFICATION_SOURCE, "");
		verification.put(CreditBusinessConstants.VERIFIEDFOR, "");
		addressObject.put("verification", verification);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, addressObject);
		execution.setVariable(CITY_KEY, locationResponseBean.getCityKey());
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End addressUpdate");

	}
	
	@SuppressWarnings("unchecked")
	public void prePersonalPanUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start prePeronalPanUpdate");
		String pan =execution.getVariable(CreditBusinessConstants.PAN_NUMBER).toString();
		JSONObject documentUpdate = new JSONObject();

		documentUpdate.put(CreditBusinessConstants.DOCUMENT_NAME_KEY, 1);
		documentUpdate.put(CreditBusinessConstants.DOCUMENT_NUMBER, pan);

		execution.setVariable(CreditBusinessConstants.PAYLOAD, documentUpdate);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End prePeronalPanUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void personalPanVerifyPre(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start personalPanPre");
		String pan = execution.getVariable(CreditBusinessConstants.PAN_NUMBER).toString();
		JSONObject panUpdatePayload = new JSONObject();
		panUpdatePayload.put("panNumber", pan);
		panUpdatePayload.put("applicationKey", execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		panUpdatePayload.put("applicantKey", execution.getVariable(CreditBusinessConstants.APPLICANTID));
		panUpdatePayload.put("fullName", execution.getVariable(FULLNAME));
		panUpdatePayload.put("l2ProductKey", execution.getVariable(CreditBusinessConstants.L2_PRODUCT_KEY));
		panUpdatePayload.put("l2ProductCode", execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, panUpdatePayload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End personalPanPre");
	}
	
	public void personalPanVerifyPost(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start personalPanVerifyPost");
		JSONObject panResp = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.NSDLPANRESPONSE_VERIFY, panResp);
		execution.setVariable(CreditBusinessConstants.NSDLPANRESPONSE, panResp);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End personalPanVerifyPost");
	}
	
	public void postGetAddress(DelegateExecution execution) {
		JSONObject addrObject = CreditBusinessHelper.getJSONObject(execution.getVariable(OUTPUT));
		execution.setVariable(PINCODEKEY, addrObject.get(PINCODEKEY));
		execution.setVariable("addressLine1", addrObject.get("addressLine1"));
		execution.setVariable("addressLine2", addrObject.get("addressLine2"));
	}
	
	public void getNonGinPersonalEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start getNonGinPersonalEmail");
		Email emailDetails = null;
		String applicationId= execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString();
		try {
			emailDetails = apiCallHelper.getEmail(applicationId, execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString(), EmailTypeEnum.PERON1.getValue().toString());
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception while fetching email for appId = " + applicationId, e);
		}
		if (null != emailDetails) {
			execution.setVariable(CreditBusinessConstants.PERSONALEMAILID, emailDetails.getEmail());
			execution.setVariable(CreditBusinessConstants.ISINPROCESSING, true);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end getNonGinPersonalEmail");
	
	}
	
	public void etbCheck(DelegateExecution execution) {
		if (execution.getVariable(CreditBusinessConstants.ETB_TYPE) == null
				|| "NA".equalsIgnoreCase(execution.getVariable(CreditBusinessConstants.ETB_TYPE).toString())) {
			Boolean isEtb = ginHelper.checkIsEtbCustomer(execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
			if (isSalaried(execution) && isEtb != null && isEtb) {
				execution.setVariable(CreditBusinessConstants.ETB_TYPE, EtbVariantEnum.NONGIN.getValue());
			}
		}
	}
	
	public void getCurrentAddress(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start getCurrentAddress");
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		params.put("userattributekey",
				execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
		params.put(CreditBusinessConstants.TYPE_KEY, AddressTypeEnum.CURRENT.getValue());
		Address address = null;
		try {
			address = apiCallHelper.getAddress(new HttpHeaders(), params);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception while fetching address with params = " + params, e);
		}
		if (null != address) {
			execution.setVariable(CreditBusinessConstants.PINCODEKEY, address.getPincodeKey());
			execution.setVariable("addressLine1", address.getAddressLine1());
			execution.setVariable("addressLine2", address.getAddressLine2());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end getCurrentAddress");
	}
	
	private boolean isSalaried(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start isSalaried");
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationid", execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		boolean isSalaried = false;
		UserProfileBean userProfile = apiCallHelper.getUserProfile(params);
		if (userProfile != null) {
			params = new HashMap<>();
			params.put("applicationid", execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
			params.put("userattributekey", userProfile.getApplicationUserAttributeKey());
			OccupationReference occupationReference = apiCallHelper.getOccupationValue(params);
			if (null != occupationReference) {
				Reference occupationType = getReference(occupationReference.getOccupationKey(),
						occupationReference.getOccupationCode(), occupationReference.getOccupationValue());
				if (SALARIED.equalsIgnoreCase(occupationType.getCode())) {
					isSalaried = true;
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end isSalaried with flag :"+isSalaried);
		return isSalaried;
	}

}

