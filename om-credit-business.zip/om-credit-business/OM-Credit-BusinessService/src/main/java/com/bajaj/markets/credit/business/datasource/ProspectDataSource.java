package com.bajaj.markets.credit.business.datasource;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.activiti.engine.impl.util.CollectionUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.AddressDetails;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.BankDetail;
import com.bajaj.markets.credit.business.beans.BankDetailsBean;
import com.bajaj.markets.credit.business.beans.BusinessOwnerDetails;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.EmandatesRequest;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.LookupCodeResponse;
import com.bajaj.markets.credit.business.beans.LookupCodeValuesResponseBean;
import com.bajaj.markets.credit.business.beans.MandateDetailsBean;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.NatureOfBusinessMaster;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OfferDetail;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.beans.PersonalDetails;
import com.bajaj.markets.credit.business.beans.ProspectDetails;
import com.bajaj.markets.credit.business.beans.ProspectOfferDetails;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResponseBean;
import com.bajaj.markets.credit.business.beans.SalariedDetail;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.OccupationTypeEnum;
import com.bajaj.markets.credit.business.helper.OfferType;
import com.bajaj.markets.credit.business.helper.RiskOfferTypeToL3Prod;
import com.bajaj.markets.insurance.remoteapitrackinglib.bean.RemoteApiTrackingBean;
import com.bajaj.markets.insurance.remoteapitrackinglib.service.impl.RemoteApiTrackingImpl;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class ProspectDataSource implements DataSource {
	
	private static final String DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_S = "yyyy-MM-dd HH:mm:ss.S";

	@Value("${api.offers.offerDetailsForPlatform.POST.url}")
	private String offersUrl;
	
	@Value("${api.omofferservice.offer.GET.url}")
	private String newOffersUrl;
	
	@Value("${api.omreferencedatareferencedataservice.getmaritalstatus.get.url}")
	private String getmaritalStatusURL;
	
	@Value("${api.omreferencedatareferencedataservice.getgender.get.url}")
	private String getgenderURL;
	
	@Value("${api.omreferencedatareferencedataservice.lookup.code.get.url}")
	private String lookUpCodeUrl;
	
	@Value("${api.omreferencedatareferencedataservice.natureofbusiness.get.url}")
	private String natureOfBusinessUrl;
	
	@Value("${api.omreferencedatareferencedataservice.location.pincode.get.url}")
	private String pinCodeUrl;
	
	@Value("${OMPL.ProspectDatasource.precedence}")
	private String precedence;
	
	@Value("${api.omcreditapplicationservice.applications.city.PUT.url}")
	private String cityUrl;
		
	@Autowired
	private CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private BFLLoggerUtil loggerUtil;
	
	@Autowired
	RemoteApiTrackingImpl remoteApiTrackingImpl;
	
	@Value("#{${offer.riskoffertype.map}}")
	private Map<String,Integer> offerPriorityMap;
	
	private static final String CLASSNAME = ProspectDataSource.class.getName();
	
	@Value("${api.referencedata.employername.GET.url}")
	private String employerUrl;
	
	@Override
	public void registerDataSource(DataSourceRegistry dataSourceRegistry) {
		dataSourceRegistry.registerDataSource(this);
		loggerUtil.info(CLASSNAME, BFLLoggerComponent.UTILITY, "registerDataSource - ProspectDataSource registration done");
	}
	
	@Override
	public OfferDetailsBean initDataSource(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		OfferDetailsBean offerDetailsBean = new OfferDetailsBean();
		try {			
			offerDetailsBean.setPrecedence(Integer.parseInt(precedence));
			offerDetailsBean.setDataSourceName(this.getClass().getSimpleName());
			ProspectOfferDetails prospectOfferDetails = getProspectOfferDetails(applicantDataBean);
			
			if (null != prospectOfferDetails && !CollectionUtil.isEmpty(prospectOfferDetails.getProspectDetails())) {
				ProspectDetails requiredProspect = null;
				for (ProspectDetails prospectDetails : prospectOfferDetails.getProspectDetails()) {
					if (!CollectionUtils.isEmpty(prospectDetails.getOfferDetails())) {
						requiredProspect = prospectDetails;
						break;
					}
				}
				if (null == requiredProspect) {
					requiredProspect = prospectOfferDetails.getProspectDetails().get(0);
				}
				populateUserProfileDetails(requiredProspect.getPersonalDetails(), offerDetailsBean);
				populateEmailDetails(requiredProspect.getPersonalDetails(), offerDetailsBean);
				populateOccupationDetails(requiredProspect, applicantDataBean, offerDetailsBean);
				populateAddressDetails(requiredProspect, applicantDataBean, offerDetailsBean);
				populateOfferDetails(requiredProspect, applicantDataBean, offerDetailsBean);
				populateDocumentDetails(requiredProspect.getPersonalDetails(), applicantDataBean, offerDetailsBean);
				populateBankDetails(requiredProspect.getBankDetails(), offerDetailsBean, applicantDataBean);
				populateMandateDetails(requiredProspect.getMandateDetails(), applicantDataBean, offerDetailsBean);
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - Offer not found.");
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - Population process failed", e);
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
		return offerDetailsBean;
	}
	
	@SuppressWarnings("unchecked")
	private ProspectOfferDetails getProspectOfferDetails(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getProspectOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			applicantDataBean.getOfferApiRequest().setDob(dateToddmmmyy(applicantDataBean.getOfferApiRequest().getDob()));
			
			Gson gson = new Gson();
			
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("mobile", applicantDataBean.getOfferApiRequest().getMobileNo());
			paramMap.put("dateOfBirth", applicantDataBean.getOfferApiRequest().getDob());
			paramMap.put("offerId", applicantDataBean.getOfferApiRequest().getOfferId());
			paramMap.put("pan", applicantDataBean.getOfferApiRequest().getPan());
			paramMap.put("l2ProductCode", applicantDataBean.getOfferApiRequest().getL2ProductCode());
			paramMap.put("l1Productmastcode", applicantDataBean.getOfferApiRequest().getL1Productmastcode());
			paramMap.put("policyNumber", "");
			paramMap.put("occupationTypeKey", "");
			if (!"6".equals(applicantDataBean.getOfferApiRequest().getOccupationTypeKey()) && !"9".equals(applicantDataBean.getOfferApiRequest().getOccupationTypeKey())) {
				paramMap.put("occupationTypeKey", applicantDataBean.getOfferApiRequest().getOccupationTypeKey());
			}
			
			ResponseEntity<Object> responseEntity = null;
			
			//multi offer flow
			String url;
			String reqJson = null;
			if("OMPL".equals(applicantDataBean.getProductCode()) || "OMPL".equals(applicantDataBean.getOfferApiRequest().getL2ProductCode())){
				responseEntity = (ResponseEntity<Object>) creditBusinessHelper
						.invokeRestEndpoint(HttpMethod.GET, newOffersUrl, Object.class, paramMap, null, new HttpHeaders());
				url = newOffersUrl;
				reqJson = paramMap.toString();
			} else {
				reqJson = gson.toJson(applicantDataBean.getOfferApiRequest());
				responseEntity = (ResponseEntity<Object>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.POST, offersUrl, Object.class, null, reqJson, new HttpHeaders());
				url=offersUrl;
			}
			
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
			    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				ResponseBean responseBean = mapper.convertValue(responseEntity.getBody(), ResponseBean.class);
				ProspectOfferDetails prospectOfferDetails = mapper.convertValue(responseBean.getPayload(),
						ProspectOfferDetails.class);
				RemoteApiTrackingBean remoteApiTrackingBean = new RemoteApiTrackingBean();
				remoteApiTrackingBean.setApplicantId(applicantDataBean.getApplicantKey());
				remoteApiTrackingBean.setApplicationId(applicantDataBean.getOfferApiRequest().getApplicationKey());
				remoteApiTrackingBean.setRequestPayload(reqJson);
				remoteApiTrackingBean.setRequestTimeStamp(new Timestamp(System.currentTimeMillis()).toString());
				remoteApiTrackingBean.setResponsePayload(responseBean.getPayload().toString());
				remoteApiTrackingBean.setResponseTimeStamp(new Timestamp(System.currentTimeMillis()).toString());
				remoteApiTrackingBean.setSource(CreditBusinessConstants.KIBANA_OFFER_SRC);
				remoteApiTrackingBean.setTarget(CreditBusinessConstants.KIBANA_OFFER_TARGET);
				remoteApiTrackingBean.setStatus(CreditBusinessConstants.SUCCESS);
				remoteApiTrackingBean.setTargetApi(url);
				try {
					remoteApiTrackingImpl.saveRequestResponse(remoteApiTrackingBean);
				}catch(Exception e) {
					logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Error occured while api tracking");
				}
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getProspectOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
				return prospectOfferDetails;
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getProspectOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - prospect offer data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getProspectOfferDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - failed", e);
			return null;
		}
	}
	
	private String dateToddmmmyy(String inputDate) {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");
		Date date = null;
		try {
			date = format1.parse(inputDate);
		} catch (ParseException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - dateToddmmmyy method - date parsing fails", e);
			return null;
		}
		return format2.format(date);
	}
	
	private void populateUserProfileDetails(PersonalDetails personalDetails, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateUserProfileDetails method - started");
		List<UserProfileBean> userProfileBeans = new ArrayList<>();
		if(null != personalDetails) {
			UserProfileBean userProfileBean = new UserProfileBean();
			Name name = new Name();
			name.setFirstName(personalDetails.getFirstName());
			if(!StringUtils.isEmpty(personalDetails.getMiddleName())){
				name.setMiddleName(personalDetails.getMiddleName());
			}
			name.setLastName(personalDetails.getLastName());
			userProfileBean.setName(name);
			userProfileBean.setDateOfBirth(dateToYYYYMMDD(personalDetails.getDob()));
			userProfileBean.setPanNumber(personalDetails.getPan());
			userProfileBean.setMobile(personalDetails.getMobileNo());
			userProfileBean.setMaritalStatusKey(personalDetails.getMaritalStatusKey());	
			userProfileBean.setGenderKey(personalDetails.getGenderKey());
			userProfileBeans.add(userProfileBean);
		}
		offerDetailsBean.setUserProfileBeans(userProfileBeans);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateUserProfileDetails method - ended");
	}
	
	private String dateToYYYYMMDD(String inputDate) {
		SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MMM-yy");
		Date date = null;
		try {
			date = format1.parse(inputDate);
		} catch (ParseException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - dateToYYYYMMDD method - date parsing fails", e);
			return null;
		}
		return format2.format(date);
	}
	
	private void populateEmailDetails(PersonalDetails personalDetails, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateEmailDetails method - started");
		List<Email> emails = new ArrayList<>();
		if(null != personalDetails) {
			if (!StringUtils.isEmpty(personalDetails.getPersonalEmailId())) {
				Email email = new Email();
				email.setEmail(personalDetails.getPersonalEmailId());
				email.setTypeKey(CreditBusinessConstants.PERSONAL_EMAIL_TYPE);
				emails.add(email);
			}
			
			if (!StringUtils.isEmpty(personalDetails.getOfficeEmailID())) {
				Email email = new Email();
				email.setEmail(personalDetails.getOfficeEmailID());
				email.setTypeKey(CreditBusinessConstants.OFFICIAL_EMAIL_TYPE);
				emails.add(email);
			}
		}
		offerDetailsBean.setEmails(emails);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateEmailDetails method - ended");
	}
	
	private void populateAddressDetails(ProspectDetails prospectDetails, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateAddressDetails method - started");
		List<Address> addresses = new ArrayList<>();
		if (null != prospectDetails && !CollectionUtils.isEmpty(prospectDetails.getAddressDetails())) {
			prospectDetails.getAddressDetails().forEach(addressDetail -> {
				if (StringUtils.isNotEmpty(addressDetail.getPinCode())) {
					Address address = new Address();
					setAddressLine1and2(addressDetail, address);
					setAddressTypeAndAddressSource(addressDetail, address);
					address.setResiType(null != prospectDetails.getPersonalDetails()
							? prospectDetails.getPersonalDetails().getResidenceType()
							: null);
					address.setPincode(addressDetail.getPinCode());
					if (!StringUtils.isEmpty(addressDetail.getPinCode())) {
						LocationAddressBean locationAddressBean = getLocationAddressBean(addressDetail,
								applicantDataBean.getHeaders());
						if (null != locationAddressBean) {
							updateBranch(applicantDataBean, offerDetailsBean, locationAddressBean);
							address.setCityKey(null != locationAddressBean.getCityId()
									? String.valueOf(locationAddressBean.getCityId())
									: null);
							address.setPincodeKey(null != locationAddressBean.getPinId()
									? String.valueOf(locationAddressBean.getPinId())
									: null);
							address.setCountryKey(null != locationAddressBean.getCountryId()
									? String.valueOf(locationAddressBean.getCountryId())
									: null);
							address.setStateKey(null != locationAddressBean.getStateId()
									? String.valueOf(locationAddressBean.getStateId())
									: null);
						}
					}
					addresses.add(address);
				}

			});
		}
		offerDetailsBean.setAddresses(addresses);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateAddressDetails method - ended");
	}

	private void updateBranch(ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean,
			LocationAddressBean locationAddressBean) {
		if(null != locationAddressBean.getCityId()) {
			try {
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateAddressDetails method - applicationkey = "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - citykey = "+locationAddressBean.getCityId() );
				Map<String, String> paramMap = new HashMap<>();
				paramMap.put("applicationkey", applicantDataBean.getOfferApiRequest().getApplicationKey());
				paramMap.put("citykey", String.valueOf(locationAddressBean.getCityId()));
				paramMap.put("occupationTypeKey", offerDetailsBean.getOccupations().size() > 0 ? String.valueOf(offerDetailsBean.getOccupations().get(0).getOcupationType().getKey()) : null);
				paramMap.put("pincodekey", null);
				ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT,
						cityUrl, Object.class, paramMap, null, applicantDataBean.getHeaders());
				if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
					logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateAddressDetails method - branch stamped successfully");
				} else {
					logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateAddressDetails method - branch not stamped successfully");
				}		
			} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateAddressDetails method - branch stamping endpoint failed", e);
			}
		}
	}

	private void setAddressTypeAndAddressSource(AddressDetails addressDetail, Address address) {
		if (CreditBusinessConstants.CURRENT_ADDRESS.equals(addressDetail.getAddressType())
				|| CreditBusinessConstants.OTHER_ADDRESS.equalsIgnoreCase(addressDetail.getAddressType())) {
			address.setAddressTypeKey(AddressTypeEnum.CURRENT.getValue());
			address.setAddressSource(CreditBusinessConstants.OFFER_API);
		}
		else if (CreditBusinessConstants.PERMANENT_ADDRESS.equals(addressDetail.getAddressType())) {
			address.setAddressTypeKey(AddressTypeEnum.PERMANENT.getValue());
			address.setAddressSource(CreditBusinessConstants.SOURCE_JOURNEY);
		}
		else {
			address.setAddressTypeKey(AddressTypeEnum.OFFICE.getValue());
			address.setAddressSource(CreditBusinessConstants.SOURCE_JOURNEY);
		}
	}

	private void setAddressLine1and2(AddressDetails addressDetail, Address address) {
		String addressLine1 = StringUtils.isNotEmpty(addressDetail.getAddressLine1())
				? creditBusinessHelper.skipSpecialCharactersFromAddress(addressDetail.getAddressLine1())
				: null;
		String addressLine2 = StringUtils.isNotEmpty(addressDetail.getAddressLine2())
				? creditBusinessHelper.skipSpecialCharactersFromAddress(addressDetail.getAddressLine2())
				: null;
		if (null==addressLine2 && null != addressLine1) {
			addressLine1 = addressLine1.contains(" ")?addressLine1.substring(0, addressLine1.lastIndexOf(" ")):addressLine1;
			addressLine2 = addressLine1.substring(addressLine1.lastIndexOf(" ") + 1);
		}
		address.setAddressLine1(addressLine1);
		address.setAddressLine2(addressLine2);
		if ((null != addressLine1 && addressLine1.length() > 50)
				|| (null != addressLine2 && addressLine2.length() > 50)) {
			Map<String, String> addressLines = creditBusinessHelper.addLinebreaks(addressLine1 + " " + addressLine2,
					50);
			address.setAddressLine1(addressLines.get("addressLine1"));
			address.setAddressLine2(addressLines.get("addressLine2"));
		}
	}
	
	@SuppressWarnings("unchecked")
	private LocationAddressBean getLocationAddressBean(AddressDetails addressDetail, HttpHeaders headers) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateAddressDetails method - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("pincode", addressDetail.getPinCode());
			ResponseEntity<LocationAddressBean> responseEntity = (ResponseEntity<LocationAddressBean>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, pinCodeUrl, LocationAddressBean.class, paramMap,
							null, headers);
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateAddressDetails method - ended");
				return responseEntity.getBody();
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateAddressDetails method - location address data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateAddressDetails method - failed", e);
			return null;
		}
	}
	
	private void populateOccupationDetails(ProspectDetails prospectDetails, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateOccupationDetails method - started");
		List<Occupation> occupations = new ArrayList<>();
		if(null != prospectDetails.getPersonalDetails()) {
			Occupation occupation = new Occupation();
			PersonalDetails personalDetails = prospectDetails.getPersonalDetails();
			if (StringUtils.equalsAny(applicantDataBean.getOccupationType(), OccupationTypeEnum.BUSINESS.getValue(),OccupationTypeEnum.DOCTOR_SELF_EMPLOYED.getValue(),OccupationTypeEnum.CA_CS_ICWA.getValue())) {
				BusinessOwnerDetails businessOwnerDetails = new BusinessOwnerDetails();
				if (!StringUtils.isEmpty(prospectDetails.getPersonalDetails().getAnnualTurnover())) {
					businessOwnerDetails.setAnualTurnover(getAnualTurnover(prospectDetails.getPersonalDetails().getAnnualTurnover()));
				}
				if (!StringUtils.isEmpty(prospectDetails.getPersonalDetails().getBusinessVintage())) {
					businessOwnerDetails.setBusinessVintage(prospectDetails.getPersonalDetails().getBusinessVintage());
				}
				businessOwnerDetails.setBusinessPan(prospectDetails.getPersonalDetails().getBusinessEntityPAN());
				businessOwnerDetails.setBusinessName(prospectDetails.getPersonalDetails().getBusinessName());
				// For nature of business key code value
				if (!StringUtils.isEmpty(prospectDetails.getPersonalDetails().getNatureOfBusiness())) {
					businessOwnerDetails.setNatureOfBusiness(getNatureOfBusiness(prospectDetails.getPersonalDetails().getNatureOfBusiness(), applicantDataBean.getHeaders()));
				}
				setDocCaDetailsForSelfEmployed(personalDetails, businessOwnerDetails);
				occupation.setOcupationType(getReference(Long.valueOf(applicantDataBean.getOfferApiRequest().getOccupationTypeKey()), null, null));
				occupation.setBusinessOwnerDetails(businessOwnerDetails);
			} else {
				SalariedDetail salariedDetail = new SalariedDetail();
				salariedDetail.setDesignation(
						getReference(null, null, prospectDetails.getPersonalDetails().getDesignation()));
				if (null != prospectDetails.getPersonalDetails().getEmployerId()) {
					salariedDetail.setEmployerName(
							getReference(prospectDetails.getPersonalDetails().getEmployerId(), null, null));
				}
				occupation.setSalariedDetail(salariedDetail);
				setDocDetailsForSalaried(personalDetails, salariedDetail);
				occupation.setOcupationType(getReference(Long.valueOf(applicantDataBean.getOfferApiRequest().getOccupationTypeKey()), null, null));
			}
			occupations.add(occupation);
		}
		offerDetailsBean.setOccupations(occupations);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateOccupationDetails method - ended");
	}

	private void setDocCaDetailsForSelfEmployed(PersonalDetails personalDetails, BusinessOwnerDetails businessOwnerDetails) {
		businessOwnerDetails.setCaRegistrationNumber(personalDetails.getCaregnumber());
		businessOwnerDetails.setCertificateOfPracticeYear(null!=personalDetails.getCopattainyear()?personalDetails.getCopattainyear().intValue():null);
		businessOwnerDetails.setDoctorRegistrationNumber(personalDetails.getMrn());
		businessOwnerDetails.setHospital(getReference(personalDetails.getHospitalKey(), null, null));
		businessOwnerDetails.setHospitalNameOther(personalDetails.getOthHospitalName());
		businessOwnerDetails.setRegCouncil(getReference(personalDetails.getRcmastKey(), null, null));
		businessOwnerDetails.setSpecialization(getReference(personalDetails.getRcmastKey(), null, null));
		businessOwnerDetails.setYearOfGraduation(null!=personalDetails.getUgYearOfGraduation()?personalDetails.getUgYearOfGraduation().intValue():null);
		businessOwnerDetails.setYearOfPostGraduation(null!=personalDetails.getPgYearOfGraduation()?personalDetails.getPgYearOfGraduation().intValue():null);
		businessOwnerDetails.setQualification(getReference(personalDetails.getQlfymastkey(), null, null));
	}
	
	private void setDocDetailsForSalaried(PersonalDetails personalDetails, SalariedDetail salariedDetails) {
		salariedDetails.setDoctorRegistrationNumber(personalDetails.getMrn());
		salariedDetails.setHospital(getReference(personalDetails.getHospitalKey(), null, null));
		salariedDetails.setHospitalNameOther(personalDetails.getOthHospitalName());
		salariedDetails.setRegCouncil(getReference(personalDetails.getRcmastKey(), null, null));
		salariedDetails.setSpecialization(getReference(personalDetails.getRcmastKey(), null, null));
		salariedDetails.setYearOfGraduation(null!=personalDetails.getUgYearOfGraduation()?personalDetails.getUgYearOfGraduation().intValue():null);
		salariedDetails.setYearOfPostGraduation(null!=personalDetails.getPgYearOfGraduation()?personalDetails.getPgYearOfGraduation().intValue():null);
		salariedDetails.setQualification(getReference(personalDetails.getQlfymastkey(), null, null));
	}
	
	private Reference getAnualTurnover(String annualTurnover) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getAnualTurnover method - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.LKPCODE, CreditBusinessConstants.LKPCODE_ANNUALTURNOVER);
			ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					lookUpCodeUrl, Object.class, paramMap, null, new HttpHeaders());
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				LookupCodeResponse lookUpCode = mapper.convertValue(responseEntity.getBody(),
						LookupCodeResponse.class);
				List<LookupCodeValuesResponseBean> annualTurnOverList = lookUpCode.getLookupValuesResponseList()
						.stream().filter(o -> o.getValue().contains(annualTurnover))
						.collect(Collectors.toList());
				if (!CollectionUtils.isEmpty(annualTurnOverList)) {
					logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getAnualTurnover method - ended");
					return getReference(annualTurnOverList.get(0).getKey().longValue(),
									annualTurnOverList.get(0).getCode(), annualTurnOverList.get(0).getValue());
				} else {
					logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getAnualTurnover method - anual turnover data not found");
					return null;
				}
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getAnualTurnover method - anual turnover data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getAnualTurnover method - failed", e);
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	private Reference getNatureOfBusiness(String natureOfBusiness, HttpHeaders headers) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getNatureOfBusiness method - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.LKPCODE, CreditBusinessConstants.LKPCODE_BUSINESSVINTAGE);
			ResponseEntity<List<NatureOfBusinessMaster>> responseEntity = (ResponseEntity<List<NatureOfBusinessMaster>>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, natureOfBusinessUrl, List.class, null, null, headers);
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				List<NatureOfBusinessMaster> natureOfBusinessList;
				natureOfBusinessList = mapper.convertValue(responseEntity.getBody(),
						new TypeReference<List<NatureOfBusinessMaster>>() {
						});
				if (!CollectionUtils.isEmpty(natureOfBusinessList)) {
					List<NatureOfBusinessMaster> nobList = natureOfBusinessList.stream().filter(
							nob -> nob.getNatureOfBusinessValue().equals(natureOfBusiness))
							.collect(Collectors.toList());
					logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getNatureOfBusiness method - ended");
					return getReference(nobList.get(0).getNatureOfBusinessKey(),
							nobList.get(0).getNatureOfBusinessCode(), nobList.get(0).getNatureOfBusinessValue());
				} else {
					logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getNatureOfBusiness method - nob data not found");
					return null;
				}
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getNatureOfBusiness method - nob data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - getNatureOfBusiness method - failed", e);
			return null;
		}
	}
	
	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;
	}
	
	private void populateOfferDetails(ProspectDetails prospectDetails, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateOfferDetails method - started");
		List<AppOfferDetBean> offers = new ArrayList<>();
		Map<String,Integer> riskOffertypeMap = getRiskOfferTypeMap(prospectDetails);
		if (!CollectionUtils.isEmpty(prospectDetails.getOfferDetails())) {
			prospectDetails.getOfferDetails().forEach(offer -> {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
				if ((null == offer.getOccupationKey())
						|| (offer.getOccupationKey().toString()
						.equals(applicantDataBean.getOfferApiRequest().getOccupationTypeKey()))
						|| ("6".equals(applicantDataBean.getOfferApiRequest().getOccupationTypeKey())
								&& StringUtils.equalsAny(offer.getOccupationKey().toString(), "6", "9"))) {
					AppOfferDetBean appOfferDetBean = new AppOfferDetBean();
					appOfferDetBean.setIsOfferAvailable(true);
					appOfferDetBean.setOfferAmt(offer.getOfferAmount());
					try {
						appOfferDetBean.setOfferAppliedDt(StringUtils.isEmpty(offer.getOfferCreatedDate()) ? null
								: format.parse(offer.getOfferCreatedDate()));
						appOfferDetBean.setOfferExpiryDt(StringUtils.isEmpty(offer.getExpiryDate()) ? null
								: format.parse(offer.getExpiryDate()));
					} catch (ParseException e) {
						logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
								"populateOfferDetails: Parsing exception occured " + e);
					}
					appOfferDetBean.setOfferType(
							!StringUtils.isEmpty(offer.getOfferType()) ? OfferType.getOfferType(offer.getOfferType())
									: 2);
					appOfferDetBean.setRiskOfferType(offer.getRiskOffertype());
					appOfferDetBean.setIsBaseRate(offer.getOfferBaseRate());
					appOfferDetBean.setGenerationRule(offer.getGenerationRule());
					appOfferDetBean.setOfferGenerationSource(offer.getOfferSource());
					appOfferDetBean.setIsBaseRate(offer.getLnISBaseRate());
					appOfferDetBean.setTlBaseRate(offer.getLnTLBaseRate());
					appOfferDetBean.setOfferId(offer.getOfferId());
					appOfferDetBean.setOfferRoi(offer.getOfferROI());
					appOfferDetBean.setOfferSrcKey(1l);
					appOfferDetBean.setOfferPriority(
							!CollectionUtils.isEmpty(riskOffertypeMap) ? riskOffertypeMap.get(offer.getRiskOffertype())
									: null);
					appOfferDetBean.setApplicationKey(
							Long.valueOf(applicantDataBean.getOfferApiRequest().getApplicationKey()));
					appOfferDetBean
							.setOfferTenure(null != offer.getOfferTenure() ? offer.getOfferTenure().intValue() : null);
					if (!StringUtils.isEmpty(offer.getProdCode())) {
						appOfferDetBean.setProductCode(offer.getProdCode());
					} else if (!StringUtils.isEmpty(offer.getRiskOffertype())) {
						appOfferDetBean.setProductCode(
								RiskOfferTypeToL3Prod.getL3ProductCode(offer.getRiskOffertype().toUpperCase()));
					}
					if(StringUtils.isEmpty(appOfferDetBean.getProductCode())){
						appOfferDetBean.setProductCode(offer.getProdCode());
					}
					appOfferDetBean.setRiskOfferType(offer.getRiskOffertype());
					appOfferDetBean.setRiskSegment(offer.getRiskSegment());
					if (null != prospectDetails.getPersonalDetails()) {
						appOfferDetBean
								.setProspectId(String.valueOf(prospectDetails.getPersonalDetails().getProspectKey()));
					}
					if (null != offer.getNetMonthlySalary()) {
						appOfferDetBean.setNetMonthlySalary(offer.getNetMonthlySalary());
					}

					appOfferDetBean.setCibilScore(offer.getCibilScore());
					appOfferDetBean.setSubSource(offer.getSubSource());
					appOfferDetBean.setAppsScore(offer.getAppsScore());
					appOfferDetBean.setCustSegment(offer.getCustSegment());
					appOfferDetBean.setObligations(offer.getObligations());
					appOfferDetBean.setSource(prospectDetails.getPersonalDetails().getProspectsrc());
					appOfferDetBean.setIsEmiAmount(offer.getIsEmiAmount());
					// appOfferDetBean.setOfferStatus(offer.getOfferStatus());
					offers.add(appOfferDetBean);
				}
			});
		}
		offerDetailsBean.setOffers(offers);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateOfferDetails method - ended");
	}

	private Map<String,Integer> getRiskOfferTypeMap(ProspectDetails prospectDetails) {
		if (!CollectionUtils.isEmpty(prospectDetails.getOfferDetails())) {
			List<String> riskOfferTypesToOrder = prospectDetails.getOfferDetails().stream()
					.map(OfferDetail::getRiskOffertype)
					.filter(a -> !StringUtils.isBlank(a) && offerPriorityMap.containsKey(a)).sorted((left, right) -> {
						Integer leftIndex = offerPriorityMap.get(left);
						Integer rightIndex = offerPriorityMap.get(right);
						if (leftIndex == null) {
							return -1;
						}
						if (rightIndex == null) {
							return 1;
						}
						return Integer.compare(leftIndex, rightIndex);
					}).collect(Collectors.toList());
			return IntStream.range(0, riskOfferTypesToOrder.size()).boxed().collect(Collectors.toMap(riskOfferTypesToOrder::get,i->i+1));
		}
		return null;
	}
	
	private void populateDocumentDetails(PersonalDetails personalDetails, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateDocumentDetails method - started");
		List<DocumentDetails> documents = new ArrayList<>();
		if(!StringUtils.isEmpty(personalDetails.getPan())) {
			DocumentDetails documentDetail = new DocumentDetails();
			documentDetail.setDocumentNameKey(1L);
			documentDetail.setDocumentNumber(personalDetails.getPan());
			documents.add(documentDetail);
		}
		offerDetailsBean.setDocuments(documents);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateDocumentDetails method - ended");
	}
	
	private void populateMandateDetails(List<MandateDetailsBean> mandateDetailsBeans, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateMandateDetails method - started");
		List<EmandatesRequest> mandates = new ArrayList<>();
		if(!CollectionUtils.isEmpty(mandateDetailsBeans)) {
			mandateDetailsBeans.forEach(mandateDetail -> {
				EmandatesRequest emandateRequest = new EmandatesRequest();
				String name = null;
				if(!CollectionUtils.isEmpty(offerDetailsBean.getUserProfileBeans())) {
					name = null != offerDetailsBean.getUserProfileBeans().get(0).getName() ? offerDetailsBean.getUserProfileBeans().get(0).getName().getFirstName() : null;
				}
				emandateRequest.setName(name);
				emandateRequest.setAccountNumber(mandateDetail.getMandateaccountnumber());
				emandateRequest.setLimit(null != mandateDetail.getMandatebalancelimit() ? new BigDecimal(mandateDetail.getMandatebalancelimit()) : null);
				emandateRequest.setBankName(mandateDetail.getMandatebankname());
				emandateRequest.setMandateExpiryDate(null != mandateDetail.getMandateexpirydate() ? DateUtils.formatDate((mandateDetail.getMandateexpirydate())) : null);
				emandateRequest.setIfscCode(mandateDetail.getMandateifsc());
				emandateRequest.setMicrCode(mandateDetail.getMandatemicr());
				emandateRequest.setUmrn(mandateDetail.getMandateregistrationnumber());
				emandateRequest.setMandateType(null != mandateDetail.getMandatetype() ? Long.valueOf(mandateDetail.getMandatetype()) : null);
				emandateRequest.setApplicantKey(applicantDataBean.getApplicantKey());
				emandateRequest.setApplicationKey(applicantDataBean.getOfferApiRequest().getApplicationKey());
				emandateRequest.setMobileNumber(null != applicantDataBean.getOfferApiRequest().getMobileNo() ? Long.valueOf(applicantDataBean.getOfferApiRequest().getMobileNo()) : null );
				emandateRequest.setProductCategoryCode(applicantDataBean.getProductKey().toString());
				emandateRequest.setProductCode("10");
				emandateRequest.setProductMasterKey("69");
				emandateRequest.setPrincipal("3");
				emandateRequest.setMandateCreationSource("OFFER_API"); 
				emandateRequest.setMandateUpdateSource("JOURNEY");
				emandateRequest.setStatus("CREATED");
				mandates.add(emandateRequest);
			});
		}
		offerDetailsBean.setMandates(mandates);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateMandateDetails method - ended");
	}
	
	private void populateBankDetails(List<BankDetailsBean> bankDetails, OfferDetailsBean offerDetailsBean, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateBankDetails method - started");
		List<BankDetail> banks = new ArrayList<>();
		if(!CollectionUtils.isEmpty(bankDetails)) {
			bankDetails.forEach(bankDetail -> {
				BankDetail bank = new BankDetail();
				bank.setAccoutNumber(bankDetail.getAccnum());
				bank.setBankAccountTypeKey(null != bankDetail.getAcctypkey() ? bankDetail.getAcctypkey().toString() : null);
				bank.setBankDetailsKey(null != bankDetail.getBankmastkey() ? bankDetail.getBankmastkey().toString() : null);
				bank.setBranchKey(null != bankDetail.getBranchkey() ? bankDetail.getBranchkey().toString() : null);
				bank.setUserAttributeKey(applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey());
				bank.setSource("JOURNEY");
				banks.add(bank);
			});
		}
		offerDetailsBean.setBanks(banks);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateBankDetails method - ended");
	}
	
}