package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;


public class IndustryMaster implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer industryMasterKey;
	
	private String industryMasterCode;
	
	private String indMastSubsectorCode;
	
	private String industryMasterDesc;
	
	private BigDecimal industryMasterLimit;
	
	private Integer isActive;
	
	private String categoryCode;

	public Integer getIndustryMasterKey() {
		return industryMasterKey;
	}

	public void setIndustryMasterKey(Integer industryMasterKey) {
		this.industryMasterKey = industryMasterKey;
	}

	public String getIndustryMasterCode() {
		return industryMasterCode;
	}

	public void setIndustryMasterCode(String industryMasterCode) {
		this.industryMasterCode = industryMasterCode;
	}

	public String getIndMastSubsectorCode() {
		return indMastSubsectorCode;
	}

	public void setIndMastSubsectorCode(String indMastSubsectorCode) {
		this.indMastSubsectorCode = indMastSubsectorCode;
	}

	public String getIndustryMasterDesc() {
		return industryMasterDesc;
	}

	public void setIndustryMasterDesc(String industryMasterDesc) {
		this.industryMasterDesc = industryMasterDesc;
	}

	public BigDecimal getIndustryMasterLimit() {
		return industryMasterLimit;
	}

	public void setIndustryMasterLimit(BigDecimal industryMasterLimit) {
		this.industryMasterLimit = industryMasterLimit;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
}
