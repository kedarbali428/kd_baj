package com.bajaj.markets.credit.business.datasource;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.processor.AddressProcessor;
import com.bajaj.markets.credit.business.processor.ApplicantProfileProcessor;
import com.bajaj.markets.credit.business.processor.BankProcessor;
import com.bajaj.markets.credit.business.processor.DocumentProcessor;
import com.bajaj.markets.credit.business.processor.EmailProcessor;
import com.bajaj.markets.credit.business.processor.MandateProcessor;
import com.bajaj.markets.credit.business.processor.OccupationProcessor;
import com.bajaj.markets.credit.business.processor.OfferProcessor;
import com.bajaj.markets.credit.business.processor.PrincipalCustProcessor;

@Component
public class OfferDataSourceHandler {
	
	@Autowired
	private OfferDataSourceService offerDataSourceService;
	
	@Autowired
	private ApplicantProfileProcessor applicantProfileProcessor;
	
	@Autowired
	private EmailProcessor emailProcessor;
	
	@Autowired
	private AddressProcessor addressProcessor;
	
	@Autowired
	private BankProcessor bankProcessor;
	
	@Autowired
	private OccupationProcessor occupationProcessor;
	
	@Autowired
	private OfferProcessor offerProcessor;
	
	@Autowired
	private DocumentProcessor documentProcessor;
	
	@Autowired
	private PrincipalCustProcessor principalCustProcessor;
	
	@Autowired
	MandateProcessor mandateProcessor;
		
	@Autowired
	private BFLLoggerUtilExt logger;
	
	private static final String CLASSNAME = OfferDataSourceHandler.class.getName();
		
	public Boolean process(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceHandler - process method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");		
		
		List<OfferDetailsBean> dataSources = offerDataSourceService.processOfferData(applicantDataBean);
		List<OfferDetailsBean> sortedDataSources = sortDataSourecs(dataSources, applicantDataBean);
		Boolean otpFlag = saveDataSources(sortedDataSources, applicantDataBean);
		
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceHandler - process method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - OtpFlag ="+otpFlag);
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceHandler - process method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
		return otpFlag;
	}
	
	private List<OfferDetailsBean> sortDataSourecs(List<OfferDetailsBean> dataSources, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceHandler - sortDataSourecs method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		//sort datasources on the basis of precedence (lower number precedence is higher in priority)
		dataSources.sort(new Comparator<OfferDetailsBean>() {
			@Override
			public int compare(OfferDetailsBean o1, OfferDetailsBean o2) {
				return o1.getPrecedence().compareTo(o2.getPrecedence());
			}
		});
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceHandler - sortDataSourecs method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
		return dataSources;
	}
	
	private Boolean saveDataSources(List<OfferDetailsBean> dataSources, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceHandler - saveDataSources method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		
		List<Boolean> executionList = new ArrayList<>();
		Boolean otpFlag = false;
		
		//save profile data
		otpFlag = applicantProfileProcessor.initDataCopy(dataSources, applicantDataBean);
		executionList.add(otpFlag);

		//save email data
		otpFlag = emailProcessor.initDataCopy(dataSources, applicantDataBean);
		executionList.add(otpFlag);
		
		//save address data
		otpFlag = addressProcessor.initDataCopy(dataSources, applicantDataBean);
		executionList.add(otpFlag);
		
		//save bank data
		otpFlag = bankProcessor.initDataCopy(dataSources, applicantDataBean);
		executionList.add(otpFlag);
		
		//save occupation data
		otpFlag = occupationProcessor.initDataCopy(dataSources, applicantDataBean);
		executionList.add(otpFlag);
		
		//save offer data
		otpFlag = offerProcessor.initDataCopy(dataSources, applicantDataBean);
		
		//save document data
		otpFlag = documentProcessor.initDataCopy(dataSources, applicantDataBean);
		executionList.add(otpFlag);
		
		//save principal customer data
		otpFlag = principalCustProcessor.initDataCopy(dataSources, applicantDataBean);
		
		//save mandate data
		otpFlag = mandateProcessor.initDataCopy(dataSources, applicantDataBean);
		executionList.add(otpFlag);
		
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceHandler - saveDataSources method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
		return executionList.contains(true);
	}
}