package com.bajaj.markets.credit.business.controller;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.ImpsRequestMetadata;
import com.bajaj.markets.credit.business.beans.ProfileDetail;
import com.bajaj.markets.credit.business.beans.ProfileDetails;
import com.bajaj.markets.credit.business.beans.ProfileDetailsWrapper;
import com.bajaj.markets.credit.business.beans.validator.OccupationValidatorClass;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Back;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CAICWA;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.OccupationTypeEnum;
import com.bajaj.markets.credit.business.service.CreditBusinessService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessController {

	@Autowired
	private Validator validator;

	@Autowired
	CreditBusinessService creditBusinessService;

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	private Environment env;

	private static final String CLASS_NAME = CreditBusinessController.class.getCanonicalName();


	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(	value = "Update the basic details of Application", notes = "Update profile details", httpMethod = "POST",
					response = ApplicationResponse.class)
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Succesfully updated the profile details", response = ProfileDetailsWrapper.class),
			@ApiResponse(code = 400, message = "bad input parameter", response = ErrorBean.class),
			@ApiResponse(code = 409, message = "application Already exists", response = ErrorBean.class) })
	@CrossOrigin
	@PostMapping(	path = "/v1/credit/applications/{applicationid}/profile", consumes = MediaType.APPLICATION_JSON_VALUE,
					produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ProfileDetailsWrapper> profile(@PathVariable(value = "applicationid", required = true) String applicationid,
			@Valid @RequestBody ProfileDetails profileDetails, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Started updateProfile for Applicationid : " + applicationid);
		Set<ConstraintViolation<ProfileDetails>> validationErrors = validator.validate(profileDetails, getValidatorClassByOccupation(profileDetails));
		
		if (!CollectionUtils.isEmpty(validationErrors)) {
			String message = "";
			if(validationErrors.stream().findFirst().isPresent()) {
				message = validationErrors.stream().findFirst().get().getMessage();
			}
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside updateProfile method - invalid parameters passed "+message);
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_11", message));
		}
		ProfileDetailsWrapper wrapperResponse = creditBusinessService.updateProfile(profileDetails, applicationid, headers,profileDetails.getAction());
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End updateProfile for Applicationid : " + applicationid);
		return new ResponseEntity<>(wrapperResponse, HttpStatus.CREATED);
	}

	private Class getValidatorClassByOccupation(ProfileDetails profile) {
		String occupation = profile.getOccupation();
		if (null != profile.getAction() && "back".equalsIgnoreCase(profile.getAction())) {
			return Back.class;
		} else if (null != occupation && !occupation.isEmpty()) {
			try {
				return OccupationValidatorClass.valueOf(occupation).getOccupationValidatorClass();
			} catch(IllegalArgumentException | NullPointerException exception) {
				logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Occupation Type");
				throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_1001", env.getProperty("OMCB_1001")));
			}
		}else if (OccupationTypeEnum.CA_CS_ICWA.getValue().equalsIgnoreCase(occupation)) {
			return CAICWA.class;
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "profile method - occupation can not be null or empty");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_1002", env.getProperty("OMCB_1002")));
		}
	}

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "API To Fetch Profile Details", notes = "Profile Details", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Fetching profile details successfully.", response = ProfileDetail.class),
			@ApiResponse(code = 400, message = "Bad input parameter", response = ErrorBean.class),
			@ApiResponse(code = 409, message = "Application Already exists", response = ErrorBean.class) })
	@GetMapping(path = "/v1/credit/applications/{applicationid}/profile", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> getProfile(@PathVariable(value = "applicationid") String applicationId, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside controller : Fetching profile details started" + applicationId);
		String source = CreditBusinessConstants.JOURNEY;
		ProfileDetail response = creditBusinessService.getProfile(applicationId,source);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside controller : Fetching profile details completed Successfully." + applicationId);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "API To Fetch imps Details", notes = "Imps Details", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Fetching Imps details successfully.", response = ImpsRequestMetadata.class),
			@ApiResponse(code = 400, message = "Bad input parameter", response = ErrorBean.class),
			@ApiResponse(code = 409, message = "Application Already exists", response = ErrorBean.class) })
	@GetMapping(path = "/v1/credit/applications/{applicationid}/imps", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> getImpsDetails(@PathVariable(value = "applicationid") String applicationId, 
			@RequestParam(name = "bankAcctcatKey") Integer bankAcctcatKey,@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside controller : Fetching imps details started" + applicationId);
		List<ImpsRequestMetadata> response = creditBusinessService.getImpsDetails(applicationId,bankAcctcatKey, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside controller : Fetching imps details completed Successfully." + applicationId);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "Update profile details of Application on EP", notes = "Update profile details of Application on EP", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Succesfully updated the profile details"),
			@ApiResponse(code = 400, message = "bad input parameter", response = ErrorBean.class),
			@ApiResponse(code = 409, message = "application Already exists", response = ErrorBean.class) })
	@CrossOrigin
	@PostMapping(path = "/v1/credit/applications/{applicationid}/bmr", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateProfileDetails(
			@PathVariable(value = "applicationid", required = true) String applicationid,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"In updateProfileDetails method for Applicationid : " + applicationid);
		
		creditBusinessService.updateProfileDetails(applicationid,headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Out updateProfileDetails method for Applicationid : " + applicationid);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
}