package com.bajaj.markets.credit.business.beans;

public class VerifiedNamePanBean {

	private String applicantName;
	
	private String applicantPan;
	
	private boolean panVerified;
	
	private boolean nameVerified;
	
	private String prospectName;
	
	private String prospectPan;

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getApplicantPan() {
		return applicantPan;
	}

	public void setApplicantPan(String applicantPan) {
		this.applicantPan = applicantPan;
	}

	public boolean isPanVerified() {
		return panVerified;
	}

	public void setPanVerified(boolean panVerified) {
		this.panVerified = panVerified;
	}

	public boolean isNameVerified() {
		return nameVerified;
	}

	public void setNameVerified(boolean nameVerified) {
		this.nameVerified = nameVerified;
	}

	public String getProspectName() {
		return prospectName;
	}

	public void setProspectName(String prospectName) {
		this.prospectName = prospectName;
	}

	public String getProspectPan() {
		return prospectPan;
	}

	public void setProspectPan(String prospectPan) {
		this.prospectPan = prospectPan;
	}

}
