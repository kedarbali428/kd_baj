package com.bajaj.markets.credit.business.beans;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BFDLProspectDetails {
	
	@JsonProperty("Name")
	private String name;
	
	@JsonProperty("MiddleName")
	private String middleName;
	
	@JsonProperty("LastName")
	private String lastName;
	
	@JsonProperty("Email")
	private String email;
	
	@JsonProperty("currentAddressLine1")
	private String currentAddressLine1;
	
	@JsonProperty("currentAddressLine2")
	private String currentAddressLine2;
	
	@JsonProperty("currentAddressLine3")
	private String currentAddressLine3;
	
	@JsonProperty("zipCode")
	private String zipcode;
	
	@JsonProperty("currentCity")
	private String currentCity;
	
	@JsonProperty("currentState")
	private String currentState;
	
	@JsonProperty("PanNumber")
	private String pan;
	
	@JsonProperty("MobileNumber")
	private String mobileNumber;
	
	@JsonProperty("DateOfBirth")
	private String dob;
	
	@JsonProperty("EmploymentType")
	private String employmentType;
	
	@JsonProperty("NameOfCompanyBusiness")
	private String nameOfCompanyBusiness;
	
	@JsonProperty("MaritalStatus")
	private String maritalStatus;
	
	@JsonProperty("Gender")
	private String gender;
	
	@JsonProperty("OfficeAddressLine1")
	private String officeAddressLine1;
	
	@JsonProperty("OfficeAddressLine2")
	private String officeAddressLine2;
	
	@JsonProperty("OfficeAddressLine3")
	private String officeAddressLine3;
	
	@JsonProperty("officePinCode")
	private String officePincode;
	
	@JsonProperty("officeState")
	private String officeState;
	
	@JsonProperty("officeCity")
	private String officeCity;
	
	@JsonProperty("AlternateNumber")
	private String alternateNumber;
	
	@JsonProperty("permanentAddressLine1")
	private String permanentAddressLine1;
	
	@JsonProperty("permanentAddressLine2")
	private String permanentAddressLine2;
	
	@JsonProperty("permanentAddressLine3")
	private String permanentAddressLine3;
	
	@JsonProperty("PermanentzipCode")
	private String permanentZipcode;
	
	@JsonProperty("PermanentCity")
	private String permanentCity;
	
	@JsonProperty("PermanentState")
	private String permanentState;
	
	@JsonProperty("CustomerId")
	private String customerId;
	
	@JsonProperty("Salutation")
	private String salutation;
	
	@JsonProperty("IsCreditCardHolder")
	private String isCreditCardHolder;
	
	@JsonProperty("totalEMI")
	private String totalEmi;
	
	@JsonProperty("RequestedLoanAmount")
	private String requestedLoanAmount;
	
	@JsonProperty("LoanUpdatedDate")
	private String loanUpdatedDate;
	
	@JsonProperty("ProductCode")
	private String productCode;
	
	@JsonProperty("FinOneCode")
	private String finOneCode;
	
	@JsonProperty("DealId")
	private String dealId;
	
	@JsonProperty("EmploymentId")
	private String employmentId;
	
	@JsonProperty("LAN_Number")
	private String lanNumber;
	
	@JsonProperty("CibilScore")
	private String cibilScore;
	
	@JsonProperty("AppRefNo")
	private String apprefNo;
	
	@JsonProperty("InstaFlag")
	private String instaFlag;
	
	@JsonProperty("nonCardedRiskBand")
	private String nonCardedRiskBand;
	
	@JsonProperty("CardedRiskBand")
	private String cardedRiskBand;
	
	@JsonProperty("utmSrc")
	private String utmSrc;
	
	@JsonProperty("cardLimit")
	private String cardLimit;
	
	@JsonProperty("oldCibilDatetime")
	private String oldCibilDateTime;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCurrentAddressLine1() {
		return currentAddressLine1;
	}

	public void setCurrentAddressLine1(String currentAddressLine1) {
		this.currentAddressLine1 = currentAddressLine1;
	}

	public String getCurrentAddressLine2() {
		return currentAddressLine2;
	}

	public void setCurrentAddressLine2(String currentAddressLine2) {
		this.currentAddressLine2 = currentAddressLine2;
	}

	public String getCurrentAddressLine3() {
		return currentAddressLine3;
	}

	public void setCurrentAddressLine3(String currentAddressLine3) {
		this.currentAddressLine3 = currentAddressLine3;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getCurrentCity() {
		return currentCity;
	}

	public void setCurrentCity(String currentCity) {
		this.currentCity = currentCity;
	}

	public String getCurrentState() {
		return currentState;
	}

	public void setCurrentState(String currentState) {
		this.currentState = currentState;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}

	public String getNameOfCompanyBusiness() {
		return nameOfCompanyBusiness;
	}

	public void setNameOfCompanyBusiness(String nameOfCompanyBusiness) {
		this.nameOfCompanyBusiness = nameOfCompanyBusiness;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getOfficeAddressLine1() {
		return officeAddressLine1;
	}

	public void setOfficeAddressLine1(String officeAddressLine1) {
		this.officeAddressLine1 = officeAddressLine1;
	}

	public String getOfficeAddressLine2() {
		return officeAddressLine2;
	}

	public void setOfficeAddressLine2(String officeAddressLine2) {
		this.officeAddressLine2 = officeAddressLine2;
	}

	public String getOfficeAddressLine3() {
		return officeAddressLine3;
	}

	public void setOfficeAddressLine3(String officeAddressLine3) {
		this.officeAddressLine3 = officeAddressLine3;
	}

	public String getOfficePincode() {
		return officePincode;
	}

	public void setOfficePincode(String officePincode) {
		this.officePincode = officePincode;
	}

	public String getOfficeState() {
		return officeState;
	}

	public void setOfficeState(String officeState) {
		this.officeState = officeState;
	}

	public String getOfficeCity() {
		return officeCity;
	}

	public void setOfficeCity(String officeCity) {
		this.officeCity = officeCity;
	}

	public String getAlternateNumber() {
		return alternateNumber;
	}

	public void setAlternateNumber(String alternateNumber) {
		this.alternateNumber = alternateNumber;
	}

	public String getPermanentAddressLine1() {
		return permanentAddressLine1;
	}

	public void setPermanentAddressLine1(String permanentAddressLine1) {
		this.permanentAddressLine1 = permanentAddressLine1;
	}

	public String getPermanentAddressLine2() {
		return permanentAddressLine2;
	}

	public void setPermanentAddressLine2(String permanentAddressLine2) {
		this.permanentAddressLine2 = permanentAddressLine2;
	}

	public String getPermanentAddressLine3() {
		return permanentAddressLine3;
	}

	public void setPermanentAddressLine3(String permanentAddressLine3) {
		this.permanentAddressLine3 = permanentAddressLine3;
	}

	public String getPermanentZipcode() {
		return permanentZipcode;
	}

	public void setPermanentZipcode(String permanentZipcode) {
		this.permanentZipcode = permanentZipcode;
	}

	public String getPermanentCity() {
		return permanentCity;
	}

	public void setPermanentCity(String permanentCity) {
		this.permanentCity = permanentCity;
	}

	public String getPermanentState() {
		return permanentState;
	}

	public void setPermanentState(String permanentState) {
		this.permanentState = permanentState;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getIsCreditCardHolder() {
		return isCreditCardHolder;
	}

	public void setIsCreditCardHolder(String isCreditCardHolder) {
		this.isCreditCardHolder = isCreditCardHolder;
	}

	public String getTotalEmi() {
		return totalEmi;
	}

	public void setTotalEmi(String totalEmi) {
		this.totalEmi = totalEmi;
	}

	public String getRequestedLoanAmount() {
		return requestedLoanAmount;
	}

	public void setRequestedLoanAmount(String requestedLoanAmount) {
		this.requestedLoanAmount = requestedLoanAmount;
	}

	public String getLoanUpdatedDate() {
		return loanUpdatedDate;
	}

	public void setLoanUpdatedDate(String loanUpdatedDate) {
		this.loanUpdatedDate = loanUpdatedDate;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getFinOneCode() {
		return finOneCode;
	}

	public void setFinOneCode(String finOneCode) {
		this.finOneCode = finOneCode;
	}

	public String getDealId() {
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public String getEmploymentId() {
		return employmentId;
	}

	public void setEmploymentId(String employmentId) {
		this.employmentId = employmentId;
	}

	public String getLanNumber() {
		return lanNumber;
	}

	public void setLanNumber(String lanNumber) {
		this.lanNumber = lanNumber;
	}

	public String getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(String cibilScore) {
		this.cibilScore = cibilScore;
	}

	public String getApprefNo() {
		return apprefNo;
	}

	public void setApprefNo(String apprefNo) {
		this.apprefNo = apprefNo;
	}

	public String getInstaFlag() {
		return instaFlag;
	}

	public void setInstaFlag(String instaFlag) {
		this.instaFlag = instaFlag;
	}

	public String getNonCardedRiskBand() {
		return nonCardedRiskBand;
	}

	public void setNonCardedRiskBand(String nonCardedRiskBand) {
		this.nonCardedRiskBand = nonCardedRiskBand;
	}

	public String getCardedRiskBand() {
		return cardedRiskBand;
	}

	public void setCardedRiskBand(String cardedRiskBand) {
		this.cardedRiskBand = cardedRiskBand;
	}

	public String getUtmSrc() {
		return utmSrc;
	}

	public void setUtmSrc(String utmSrc) {
		this.utmSrc = utmSrc;
	}

	public String getCardLimit() {
		return cardLimit;
	}

	public void setCardLimit(String cardLimit) {
		this.cardLimit = cardLimit;
	}

	public String getOldCibilDateTime() {
		return oldCibilDateTime;
	}

	public void setOldCibilDateTime(String oldCibilDateTime) {
		this.oldCibilDateTime = oldCibilDateTime;
	}

	@Override
	public String toString() {
		return "CreditCardsOfferProspectDetails [name=" + name + ", middleName=" + middleName + ", lastName=" + lastName
				+ ", email=" + email + ", currentAddressLine1=" + currentAddressLine1 + ", currentAddressLine2="
				+ currentAddressLine2 + ", currentAddressLine3=" + currentAddressLine3 + ", zipcode=" + zipcode
				+ ", currentCity=" + currentCity + ", currentState=" + currentState + ", pan=" + pan + ", mobileNumber="
				+ mobileNumber + ", dob=" + dob + ", employmentType=" + employmentType + ", nameOfCompanyBusiness="
				+ nameOfCompanyBusiness + ", maritalStatus=" + maritalStatus + ", gender=" + gender
				+ ", officeAddressLine1=" + officeAddressLine1 + ", officeAddressLine2=" + officeAddressLine2
				+ ", officeAddressLine3=" + officeAddressLine3 + ", officePincode=" + officePincode + ", officeState="
				+ officeState + ", officeCity=" + officeCity + ", alternateNumber=" + alternateNumber
				+ ", permanentAddressLine1=" + permanentAddressLine1 + ", permanentAddressLine2="
				+ permanentAddressLine2 + ", permanentAddressLine3=" + permanentAddressLine3 + ", permanentZipcode="
				+ permanentZipcode + ", permanentCity=" + permanentCity + ", permanentState=" + permanentState
				+ ", customerId=" + customerId + ", salutation=" + salutation + ", isCreditCardHolder="
				+ isCreditCardHolder + ", totalEmi=" + totalEmi + ", requestedLoanAmount=" + requestedLoanAmount
				+ ", loanUpdatedDate=" + loanUpdatedDate + ", productCode=" + productCode + ", finOneCode=" + finOneCode
				+ ", dealId=" + dealId + ", employmentId=" + employmentId + ", lanNumber=" + lanNumber + ", cibilScore="
				+ cibilScore + ", apprefNo=" + apprefNo + ", instaFlag=" + instaFlag + ", nonCardedRiskBand="
				+ nonCardedRiskBand + ", cardedRiskBand=" + cardedRiskBand + ", utmSrc=" + utmSrc + ", cardLimit="
				+ cardLimit + ", oldCibilDateTime=" + oldCibilDateTime + "]";
	}
	
}
