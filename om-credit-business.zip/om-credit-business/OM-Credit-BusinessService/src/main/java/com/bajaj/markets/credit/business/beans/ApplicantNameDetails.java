package com.bajaj.markets.credit.business.beans;

import org.hibernate.validator.constraints.NotEmpty;

public class ApplicantNameDetails {
@NotEmpty(message = "Please provide a name")
private String firstName;
private String middleName;
@NotEmpty(message = "Please provide a name")
private String lastName;
private String verificationflg;
private String verificationsrc;
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getMiddleName() {
	return middleName;
}
public void setMiddleName(String middleName) {
	this.middleName = middleName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getVerificationflg() {
	return verificationflg;
}
public void setVerificationflg(String verificationflg) {
	this.verificationflg = verificationflg;
}
public String getVerificationsrc() {
	return verificationsrc;
}
public void setVerificationsrc(String verificationsrc) {
	this.verificationsrc = verificationsrc;
}
}
