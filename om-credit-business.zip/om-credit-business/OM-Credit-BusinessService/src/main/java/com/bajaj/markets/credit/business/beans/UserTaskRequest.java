package com.bajaj.markets.credit.business.beans;

import java.util.Map;

public class UserTaskRequest {

	private Map<String,Object> content;
	private Map<String,String> properties;
	public Map<String, Object> getContent() {
		return content;
	}
	public void setContent(Map<String, Object> content) {
		this.content = content;
	}
	public Map<String, String> getProperties() {
		return properties;
	}
	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}
	@Override
	public String toString() {
		return "UserTaskRequest [content=" + content + ", properties=" + properties + "]";
	}
	
}
