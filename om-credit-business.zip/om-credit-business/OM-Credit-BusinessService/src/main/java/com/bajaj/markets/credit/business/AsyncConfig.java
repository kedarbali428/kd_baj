package com.bajaj.markets.credit.business;

import java.util.concurrent.Executor;

import javax.sql.DataSource;

import org.jboss.logging.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskDecorator;
import org.springframework.lang.NonNull;
import org.springframework.scheduling.annotation.AsyncConfigurerSupport;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;

@Configuration
@EnableAsync
public class AsyncConfig extends AsyncConfigurerSupport {
	@Value("${credit.offer.asyncThread.corePoolSize:80}")
	private String asyncThreadCorePoolSize = "";

	@Value("${credit.offer.asyncThread.maxPoolSize:100}")
	private String asyncThreadMaxPoolSize = "";

	@Value("${credit.offer.asyncThread.queueCapacity:80}")
	private String asyncThreadQueueCapacity = "";

	@Value("${credit.offer.asyncThread.threadNamePrefix:AsyncThread-}")
	private String asyncThreadNamePrefix = "";

	@Autowired
	DataSource dataSource;

	/**
	 * @author Ravindra
	 */
	@Override
	@Bean("customExecutor")
	public Executor getAsyncExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(Integer.parseInt(asyncThreadCorePoolSize));
		executor.setMaxPoolSize(Integer.parseInt(asyncThreadMaxPoolSize));
		executor.setQueueCapacity(Integer.parseInt(asyncThreadQueueCapacity));
		executor.setThreadNamePrefix(asyncThreadNamePrefix);
		executor.setTaskDecorator(new ContextCopyingDecorator());
		executor.initialize();
		return executor;
	}

	static class ContextCopyingDecorator implements TaskDecorator {
		@NonNull
		@Override
		public Runnable decorate(@NonNull Runnable runnable) {
			RequestAttributes context = cloneRequestAttributes(RequestContextHolder.currentRequestAttributes());

			CustomDefaultHeaders customDefaultHeaders = (CustomDefaultHeaders) context.getAttribute("scopedTarget.customDefaultHeaders",
					RequestAttributes.SCOPE_REQUEST);
			System.out.println("Before try block" + customDefaultHeaders);
			return () -> {
				try {
					MDC.put("correlationId", customDefaultHeaders.getCmptcorrid());
					MDC.put("authtoken", customDefaultHeaders.getAuthtoken());
					MDC.put("guardtoken", customDefaultHeaders.getGuardtoken());
					MDC.put("defaultRole", customDefaultHeaders.getDefaultRole());
					MDC.put("userKey", customDefaultHeaders.getUserKey());
					MDC.put("platform", customDefaultHeaders.getPlatform());
					RequestContextHolder.setRequestAttributes(context, true);
					runnable.run();
				} finally {

					RequestContextHolder.resetRequestAttributes();
				}
			};
		}

		private RequestAttributes cloneRequestAttributes(RequestAttributes requestAttributes) {
			RequestAttributes clonedRequestAttribute = null;
			try {
				clonedRequestAttribute = new ServletRequestAttributes(((ServletRequestAttributes) requestAttributes).getRequest(),
						((ServletRequestAttributes) requestAttributes).getResponse());
				if (requestAttributes.getAttributeNames(RequestAttributes.SCOPE_REQUEST).length > 0) {
					for (String name : requestAttributes.getAttributeNames(RequestAttributes.SCOPE_REQUEST)) {
						clonedRequestAttribute.setAttribute(name, requestAttributes.getAttribute(name, RequestAttributes.SCOPE_REQUEST),
								RequestAttributes.SCOPE_REQUEST);
					}
				}
				if (requestAttributes.getAttributeNames(RequestAttributes.SCOPE_SESSION).length > 0) {
					for (String name : requestAttributes.getAttributeNames(RequestAttributes.SCOPE_SESSION)) {
						clonedRequestAttribute.setAttribute(name, requestAttributes.getAttribute(name, RequestAttributes.SCOPE_SESSION),
								RequestAttributes.SCOPE_SESSION);
					}
				}
				return clonedRequestAttribute;
			} catch (Exception e) {
				return requestAttributes;
			}
		}
	}
}