package com.bajaj.markets.credit.business.processor;

import java.util.List;

import org.springframework.stereotype.Component;

import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;

@Component
public interface BaseProcessor {
	public boolean initDataCopy(List<OfferDetailsBean> dataSources, ApplicantDataBean applicantDataBean);
}