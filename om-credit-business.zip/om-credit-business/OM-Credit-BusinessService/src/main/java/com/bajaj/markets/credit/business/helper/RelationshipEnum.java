package com.bajaj.markets.credit.business.helper;

/**
 * Enum to map string representation of relationship type with its key, code, value
 * 
 * @author 764504
 *
 */
public enum RelationshipEnum {

	SPOUSE("Spouse", "1", 1), FATHER("Father", "2", 2), MOTHER("Mother", "3", 3), DAUGHTER("Daughter", "4", 4), SON("Son", "5", 5), BROTHER("Brother", "6", 6),
	SISTER("Sister", "7", 7);

	private final String value;
	private final String code;
	private final Integer key;

	private RelationshipEnum(String value, String code, Integer key) {
		this.value = value;
		this.code = code;
		this.key = key;
	}

	public static RelationshipEnum getByValue(String value) {
		for (RelationshipEnum e : RelationshipEnum.values()) {
			if (e.getValue().equalsIgnoreCase(value)) {
				return e;
			}
		}
		return null;
	}

	public String getValue() {
		return this.value;
	}

	public String getCode() {
		return this.code;
	}

	public Integer getKey() {
		return this.key;
	}

}
