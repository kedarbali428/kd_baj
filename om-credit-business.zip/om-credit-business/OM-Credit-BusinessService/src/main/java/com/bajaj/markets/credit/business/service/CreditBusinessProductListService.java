package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ChildApplication;
import com.bajaj.markets.credit.business.beans.ProductList;

public interface CreditBusinessProductListService {

	public ApplicationResponse createProductApplication(ChildApplication childApplication, HttpHeaders headers);

	public ResponseEntity<ProductList> getProductList(String applicationId, Double loanAmount, Double tenure, Integer isSmallTicket);

}
