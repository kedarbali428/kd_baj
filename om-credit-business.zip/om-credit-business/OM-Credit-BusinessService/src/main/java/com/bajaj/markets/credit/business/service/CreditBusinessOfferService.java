package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.BFDLProspectDetails;
import com.bajaj.markets.credit.business.beans.OfferApiRequest;
import com.bajaj.markets.credit.business.beans.ProspectDetails;

public interface CreditBusinessOfferService {

	ProspectDetails getProspectOffer(OfferApiRequest offerApiRequest, HttpHeaders headers);
	
	BFDLProspectDetails getCardsProspectOffer(OfferApiRequest offerApiRequest, HttpHeaders headers);

}
