package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CREDIT_OFFER_CHECK;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2_PRODUCT_CODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OFFER_CHECK;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST;

import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EventMessageHelper;
import com.bajaj.markets.credit.publisher.service.PublisherService;

@Component
public class BmrTwoListener {

	@Autowired
	BFLLoggerUtilExt logger;

	@Value("${aws.publisher.topic.arn}")
	private String topicArn;

	@Autowired
	PublisherService publisherService;

	@Autowired
	EventMessageHelper eventHelper;

	public static final String CLASS_NAME = BmrTwoListener.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void publishEvent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start - BMR2 event publish");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(REQUEST));
		JSONObject profession = CreditBusinessHelper.getJSONObject(request.get("profession"));
		JSONObject occupation = CreditBusinessHelper.getJSONObject(profession.get("ocupationType"));
		JSONObject payload = new JSONObject();
		payload.put("applicationId", execution.getVariable(APPLICATION_ID));
		payload.put("principalKey", "3");
		payload.put(L2_PRODUCT_CODE, execution.getVariable(L2_PRODUCT_CODE));

		payload.put("occupationType", occupation.get("code").toString());
		payload.put("addressTypeKey", AddressTypeEnum.CURRENT.getValue());

		Map<String, String> messageFilterAttributes = new HashMap<String, String>();
		messageFilterAttributes.put("applicationEvent", CreditBusinessConstants.BMR2);

		EventMessage eventMessage = eventHelper.createEventMessageForBMR2(CREDIT_OFFER_CHECK, OFFER_CHECK, null,
				payload, messageFilterAttributes);
		try {
			publisherService.publish(topicArn, eventMessage);
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
					"BMR2 event pulish failed for: " + eventMessage, exception);
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end - BMR2 event publish");
	}

}
