package com.bajaj.markets.credit.business.service;

import com.bajaj.markets.credit.business.beans.EmicResponse;

public interface CreditBusinessEmicService {

	EmicResponse encryptEmicRequest(String applicationId, String responseFormat);

}
