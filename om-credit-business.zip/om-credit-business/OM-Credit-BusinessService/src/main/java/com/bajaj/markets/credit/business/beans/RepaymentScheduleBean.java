package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class RepaymentScheduleBean {


	List <YearwiseInstallmentBean> selectedEmiData;

	public List<YearwiseInstallmentBean> getSelectedEmiData() {
		return selectedEmiData;
	}

	public void setSelectedEmiData(List<YearwiseInstallmentBean> selectedEmiData) {
		this.selectedEmiData = selectedEmiData;
	}

	@Override
	public String toString() {
		return "RepaymentScheduleBean [selectedEmiData=" + selectedEmiData + "]";
	}


}
