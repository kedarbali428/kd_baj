package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;

public class OfferDetail {
	private String offerType;

	private String riskOffertype;

	private BigDecimal offerAmount;

	private BigDecimal offerBaseRate;

	private BigDecimal offerFinalRate;

	private BigDecimal offerStatus;

	private String offerCreatedDate;

	private String offerId;

	private String prodCode;

	private BigDecimal subProdTypeKey;

	private BigDecimal offerROI;

	private BigDecimal offerTenure;

	private long prodMastKey;

	private String expiryDate;

	private BigDecimal lnISBaseRate;

	private BigDecimal lnTLBaseRate;

	private long prospectKey;

	private String riskSegment;

	private BigDecimal netMonthlySalary;

	private String offerBranch;

	private BigDecimal finalObligations;

	private String generationRule;

	private String offerSource;

	private String btBankCategory;
	
	private BigDecimal occupationKey;
	
	private BigDecimal cibilScore;
	
	private String subSource;
	
	private BigDecimal appsScore;
	
	private String custSegment;
	
	private BigDecimal obligations;
	
	private BigDecimal isEmiAmount;

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public String getRiskOffertype() {
		return riskOffertype;
	}

	public void setRiskOffertype(String riskOffertype) {
		this.riskOffertype = riskOffertype;
	}

	public BigDecimal getOfferAmount() {
		return offerAmount;
	}

	public void setOfferAmount(BigDecimal offerAmount) {
		this.offerAmount = offerAmount;
	}

	public BigDecimal getOfferBaseRate() {
		return offerBaseRate;
	}

	public void setOfferBaseRate(BigDecimal offerBaseRate) {
		this.offerBaseRate = offerBaseRate;
	}

	public BigDecimal getOfferFinalRate() {
		return offerFinalRate;
	}

	public void setOfferFinalRate(BigDecimal offerFinalRate) {
		this.offerFinalRate = offerFinalRate;
	}

	public BigDecimal getOfferStatus() {
		return offerStatus;
	}

	public void setOfferStatus(BigDecimal offerStatus) {
		this.offerStatus = offerStatus;
	}

	public String getOfferCreatedDate() {
		return offerCreatedDate;
	}

	public void setOfferCreatedDate(String offerCreatedDate) {
		this.offerCreatedDate = offerCreatedDate;
	}

	public String getOfferId() {
		return offerId;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	public String getProdCode() {
		return prodCode;
	}

	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}

	public BigDecimal getSubProdTypeKey() {
		return subProdTypeKey;
	}

	public void setSubProdTypeKey(BigDecimal subProdTypeKey) {
		this.subProdTypeKey = subProdTypeKey;
	}

	public BigDecimal getOfferROI() {
		return offerROI;
	}

	public void setOfferROI(BigDecimal offerROI) {
		this.offerROI = offerROI;
	}

	public BigDecimal getOfferTenure() {
		return offerTenure;
	}

	public void setOfferTenure(BigDecimal offerTenure) {
		this.offerTenure = offerTenure;
	}

	public long getProdMastKey() {
		return prodMastKey;
	}

	public void setProdMastKey(long prodMastKey) {
		this.prodMastKey = prodMastKey;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public BigDecimal getLnISBaseRate() {
		return lnISBaseRate;
	}

	public void setLnISBaseRate(BigDecimal lnISBaseRate) {
		this.lnISBaseRate = lnISBaseRate;
	}

	public BigDecimal getLnTLBaseRate() {
		return lnTLBaseRate;
	}

	public void setLnTLBaseRate(BigDecimal lnTLBaseRate) {
		this.lnTLBaseRate = lnTLBaseRate;
	}

	public long getProspectKey() {
		return prospectKey;
	}

	public void setProspectKey(long prospectKey) {
		this.prospectKey = prospectKey;
	}

	public String getRiskSegment() {
		return riskSegment;
	}

	public void setRiskSegment(String riskSegment) {
		this.riskSegment = riskSegment;
	}

	public BigDecimal getNetMonthlySalary() {
		return netMonthlySalary;
	}

	public void setNetMonthlySalary(BigDecimal netMonthlySalary) {
		this.netMonthlySalary = netMonthlySalary;
	}

	/**
	 * @return the offerBranch
	 */
	public String getOfferBranch() {
		return offerBranch;
	}

	/**
	 * @param offerBranch the offerBranch to set
	 */
	public void setOfferBranch(String offerBranch) {
		this.offerBranch = offerBranch;
	}

	/**
	 * @return the finalObligations
	 */
	public BigDecimal getFinalObligations() {
		return finalObligations;
	}

	/**
	 * @param finalObligations the finalObligations to set
	 */
	public void setFinalObligations(BigDecimal finalObligations) {
		this.finalObligations = finalObligations;
	}

	/**
	 * @return the generationRule
	 */
	public String getGenerationRule() {
		return generationRule;
	}

	/**
	 * @param generationRule the generationRule to set
	 */
	public void setGenerationRule(String generationRule) {
		this.generationRule = generationRule;
	}

	/**
	 * @return the offerSource
	 */
	public String getOfferSource() {
		return offerSource;
	}

	/**
	 * @param offerSource the offerSource to set
	 */
	public void setOfferSource(String offerSource) {
		this.offerSource = offerSource;
	}

	/**
	 * @return the btBankCategory
	 */
	public String getBtBankCategory() {
		return btBankCategory;
	}

	/**
	 * @param btBankCategory the btBankCategory to set
	 */
	public void setBtBankCategory(String btBankCategory) {
		this.btBankCategory = btBankCategory;
	}

	public BigDecimal getOccupationKey() {
		return occupationKey;
	}

	public void setOccupationKey(BigDecimal occupationKey) {
		this.occupationKey = occupationKey;
	}

	public BigDecimal getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(BigDecimal cibilScore) {
		this.cibilScore = cibilScore;
	}

	public String getSubSource() {
		return subSource;
	}

	public void setSubSource(String subSource) {
		this.subSource = subSource;
	}

	public BigDecimal getAppsScore() {
		return appsScore;
	}

	public void setAppsScore(BigDecimal appsScore) {
		this.appsScore = appsScore;
	}

	public String getCustSegment() {
		return custSegment;
	}

	public void setCustSegment(String custSegment) {
		this.custSegment = custSegment;
	}

	public BigDecimal getObligations() {
		return obligations;
	}

	public void setObligations(BigDecimal obligations) {
		this.obligations = obligations;
	}

	public BigDecimal getIsEmiAmount() {
		return isEmiAmount;
	}

	public void setIsEmiAmount(BigDecimal isEmiAmount) {
		this.isEmiAmount = isEmiAmount;
	}
}
