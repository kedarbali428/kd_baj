package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class CibilReference implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long cibilReferenceId;

	private String cibilStatus;

	public Long getCibilReferenceId() {
		return cibilReferenceId;
	}

	public void setCibilReferenceId(Long cibilReferenceId) {
		this.cibilReferenceId = cibilReferenceId;
	}

	public String getCibilStatus() {
		return cibilStatus;
	}

	public void setCibilStatus(String cibilStatus) {
		this.cibilStatus = cibilStatus;
	}

}
