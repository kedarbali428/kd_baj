package com.bajaj.markets.credit.business.beans;

public class ApplicationBFLDocsRequestBean {
	
	private long applicantId;
	private long applicationId;
	private long appApplicantId;
	private String docListType;
	private boolean coApplicantExistFlag;
	private String productCode;
	private String documentFor;
	private boolean omProductFlag;

	public long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}
	
	
	public long getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(long applicantId) {
		this.applicantId = applicantId;
	}
	
	
	/**
	 * @return the appApplicantId
	 */
	public long getAppApplicantId() {
		return appApplicantId;
	}
	/**
	 * @param appApplicantId the appApplicantId to set
	 */
	public void setAppApplicantId(long appApplicantId) {
		this.appApplicantId = appApplicantId;
	}
	public String getDocListType() {
		return docListType;
	}
	public void setDocListType(String docListType) {
		this.docListType = docListType;
	}
	/**
	 * @return the coApplicantExistFlag
	 */
	public boolean isCoApplicantExistFlag() {
		return coApplicantExistFlag;
	}
	/**
	 * @param coApplicantExistFlag the coApplicantExistFlag to set
	 */
	public void setCoApplicantExistFlag(boolean coApplicantExistFlag) {
		this.coApplicantExistFlag = coApplicantExistFlag;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getDocumentFor() {
		return documentFor;
	}
	public void setDocumentFor(String documentFor) {
		this.documentFor = documentFor;
	}
	public boolean isOmProductFlag() {
		return omProductFlag;
	}
	public void setOmProductFlag(boolean omProductFlag) {
		this.omProductFlag = omProductFlag;
	}
	@Override
	public String toString() {
		return "ApplicationBFLDocsRequestBean [applicantId=" + applicantId + ", applicationId=" + applicationId
				+ ", appApplicantId=" + appApplicantId + ", docListType=" + docListType + ", coApplicantExistFlag="
				+ coApplicantExistFlag + ", productCode=" + productCode + ", documentFor=" + documentFor
				+ ", omProductFlag=" + omProductFlag + "]";
	}
	
}
