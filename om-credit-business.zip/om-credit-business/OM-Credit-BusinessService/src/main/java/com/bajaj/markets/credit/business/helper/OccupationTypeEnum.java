package com.bajaj.markets.credit.business.helper;

/**
 * Enum to map string representation of occupation type with its string value
 * 
 * @author 764504
 *
 */
public enum OccupationTypeEnum {

	BUSINESS("SEMP"),
	SALARIED("SALR"), 
	DOCTOR_SALARIED("DOCSAL"),
	DOCTOR_SELF_EMPLOYED("DOCSEMP"), 
	CA_CS_ICWA("CAICWA"), 
	OTHER("OTHER");

	private final String value;

	private OccupationTypeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}
	
	public static OccupationTypeEnum getByValue(String value) {
		for (OccupationTypeEnum e : OccupationTypeEnum.values()) {
			if (e.getValue().equalsIgnoreCase(value)) {
				return e;
			}
		}
		return null;
	}

}
