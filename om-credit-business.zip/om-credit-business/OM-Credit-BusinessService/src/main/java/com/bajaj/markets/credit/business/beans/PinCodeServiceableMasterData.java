package com.bajaj.markets.credit.business.beans;

public class PinCodeServiceableMasterData {
	
	private Long pinServiceKey;
	
private Long pincodeKey;
	
	private Long prodKey;
	
	private String cityName;
	
	private String tier;
	
	private String stdCode;
	
	private String stateName;
	
	private String cityCode;
	
	private boolean oglFlg;

	public Long getPinServiceKey() {
		return pinServiceKey;
	}

	public void setPinServiceKey(Long pinServiceKey) {
		this.pinServiceKey = pinServiceKey;
	}

	public Long getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(Long pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public Long getProdKey() {
		return prodKey;
	}

	public void setProdKey(Long prodKey) {
		this.prodKey = prodKey;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public String getStdCode() {
		return stdCode;
	}

	public void setStdCode(String stdCode) {
		this.stdCode = stdCode;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public boolean isOglFlg() {
		return oglFlg;
	}

	public void setOglFlg(boolean oglFlg) {
		this.oglFlg = oglFlg;
	}

	@Override
	public String toString() {
		return "PinCodeServiceableMasterData [pinServiceKey=" + pinServiceKey + ", pincodeKey=" + pincodeKey
				+ ", prodKey=" + prodKey + ", cityName=" + cityName + ", tier=" + tier + ", stdCode=" + stdCode
				+ ", stateName=" + stateName + ", cityCode=" + cityCode + ", oglFlg=" + oglFlg + "]";
	}

	


}
