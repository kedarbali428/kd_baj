package com.bajaj.markets.credit.business.beans;

public class UtmSourceChannelBean {

	private Long utmSourceChannelMasterKey;

	private String channelType;

	private String sourcingChannel;

	private String utmMedium;

	private String utmSource;

	public Long getUtmSourceChannelMasterKey() {
		return utmSourceChannelMasterKey;
	}

	public void setUtmSourceChannelMasterKey(Long utmSourceChannelMasterKey) {
		this.utmSourceChannelMasterKey = utmSourceChannelMasterKey;
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public String getSourcingChannel() {
		return sourcingChannel;
	}

	public void setSourcingChannel(String sourcingChannel) {
		this.sourcingChannel = sourcingChannel;
	}

	public String getUtmMedium() {
		return utmMedium;
	}

	public void setUtmMedium(String utmMedium) {
		this.utmMedium = utmMedium;
	}

	public String getUtmSource() {
		return utmSource;
	}

	public void setUtmSource(String utmSource) {
		this.utmSource = utmSource;
	}

	@Override
	public String toString() {
		return "UtmSourceChannelBean [utmSourceChannelMasterKey=" + utmSourceChannelMasterKey + ", channelType="
				+ channelType + ", sourcingChannel=" + sourcingChannel + ", utmMedium=" + utmMedium + ", utmSource="
				+ utmSource + "]";
	}

}
