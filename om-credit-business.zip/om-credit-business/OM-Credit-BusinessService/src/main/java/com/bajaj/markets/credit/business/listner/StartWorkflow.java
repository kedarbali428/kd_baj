package com.bajaj.markets.credit.business.listner;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;

@Component
public class StartWorkflow {

	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = StartWorkflow.class.getCanonicalName();

	public void initialize(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start initialize");
		execution.setVariable(CreditBusinessConstants.BASIC_DETAILS, false);
		execution.setVariable(CreditBusinessConstants.PROFESSION_DETAILS, false);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End initialize");
	}

	public void postAdditionalDetail(DelegateExecution execution) {
		System.out.println(execution.getVariable("additionalDetailsBack"));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postAdditionalDetail" + "---" + execution.getVariable("additionalDetailsBack"));
	}
}
