package com.bajaj.markets.credit.business.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationParameter;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.PrincipalTransDetail;
import com.bajaj.markets.credit.business.beans.ProcessCard;
import com.bajaj.markets.credit.business.beans.ProcessStatus;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessPrincipleService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CreditBusinessPrincipleServiceImpl implements CreditBusinessPrincipleService{
	
	private static final String URL2 = "url2";
	
	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	WorkflowHelper workflowHelper;
	
	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String getChildApplicationsUrl;
	
	@Value("${api.omprincipalintegrationservice.application.credit.transaction.GET.url}")
	private String getPrincipalTransactionUrl;
	
	@Value("${api.omcreditapplicationservice.creditapplication.parameters.url}")
	private String getApplicationParameterUrl;
	
	private static final String CLASSNAME = CreditBusinessPrincipleServiceImpl.class.getName();

	/**
	 * Consent validation & details sent to partner for approval/rejection by calling process api.
	 * Resend otp functionality & validation flow integrated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ApplicationResponse processCard(ProcessCard processCard, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start processCard resource :" + processCard);

		Map<String, Object> vars = new HashMap<String, Object>();
		
		if(null != processCard.getAction()){
			vars.put(CreditBusinessConstants.CONSENT_ACTION, processCard.getAction());
		}else{
			vars.put(CreditBusinessConstants.REQUEST, processCard);
			vars.put(CreditBusinessConstants.CONSENT_ACTION, "");
		}
		
		try {
			
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			ApplicationResponse applicationResponse = new ApplicationResponse();
			if(null == processCard.getAction()){
				Object payload = workflowHelper.getFromExecutionMap(CreditBusinessConstants.IS_CASE_CREATED, headers.get(CreditBusinessConstants.PROCESS_ID).get(0));
				JSONObject json = new JSONObject();
				json.put(CreditBusinessConstants.OTP_VALIDATION, payload);
				applicationResponse.setPayload(json);
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End processCard");
			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			applicationResponse.setNextTask(task);
			
			return applicationResponse;
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception completing workflow task" + e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured while calling the service" + e);
			throw new CreditBusinessException(e.getCause());
		}
	}

	/**
	 * Call parent status api to check the status whether approved, rejected or pending for further processing. 
	 */
	@Override
	public ApplicationResponse processStatus(ProcessStatus processStatus, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Input cardStatus method ,applicationId: " + processStatus.getApplicationid());
		if(StringUtils.equals("Sent to Bank", processStatus.getChildStatus())) {
			processStatus.setChildStatus("Sent to Bank");
		}
			
		Map<String, Object> vars = new HashMap<String, Object>();
		vars.put(CreditBusinessConstants.APPLICATION_ID, processStatus.getApplicationid());
		vars.put(CreditBusinessConstants.CHILDSTATUS, processStatus.getChildStatus());
		
		try {
			//vars.put("stage", "inprogress");
			//vars.put("childApplicationId", applicationId);
			//NextTask nextTask = workflowHelper.startActivitiProcess("axisJourney", vars);
			//String nextTaskKey = workflowHelper.completeTask(nextTask.getProcessID(),vars);
			//Object payload = workflowHelper.getFromExecutionMap(CreditBusinessConstants.CARD_STATUS, nextTask.getProcessID());
			
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			
			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			ApplicationResponse applicationResponse = new ApplicationResponse();
			applicationResponse.setNextTask(task);
			
			return applicationResponse;
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception completing workflow task" + e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured while calling the service" + e);
			throw new CreditBusinessException(e.getCause());
		}
	}

	@Override
	public ApplicationParameter fetchApprovedDetails(String applicationId, String l3ProductCode) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside fetchApprovedDetails method ,applicationId: " + applicationId);
		Map<String, String> applicationParameters = new HashMap<>();
		ApplicationParameter applicationParameter = new ApplicationParameter();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationkey", applicationId);
		params.put("isInProcessing", "true");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		try {
			
			ResponseEntity<?> childApplicationListRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					getChildApplicationsUrl, List.class, params, null, headers);
			
			if(null != childApplicationListRes && null != childApplicationListRes.getBody()){
				List<ApplicationDetail> childApplicationList = mapper.convertValue(childApplicationListRes.getBody(),new TypeReference<List<ApplicationDetail>>() {});
				Optional<ApplicationDetail> filteredChild = childApplicationList.stream().filter(o -> o.getL3ProductCode().contentEquals(l3ProductCode)).findFirst();
				if (filteredChild.isPresent()) {
					Map<String, String> params2 = new HashMap<>();
					params2.put("applicationid", applicationId);
					ResponseEntity<?> applicationParameterResp = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
							getApplicationParameterUrl, ApplicationParameter.class, params2, null, headers);
					
					ApplicationParameter fetchedParameter = mapper.convertValue(applicationParameterResp.getBody(), ApplicationParameter.class);
					applicationParameters.putAll(fetchedParameter.getApplicationParameters());
					applicationParameters.put("okycLink", null);
					
					ApplicationDetail childAppDetail = filteredChild.get();
					Long principalkey= childAppDetail.getPrincipalKey();
					if (principalkey != null && 3l == principalkey) {
						params.put("applicationid", applicationId);
					}else {
						params.put("applicationid", filteredChild.get().getApplicationKey());
					}
					params.put("principalkey", principalkey != null ? principalkey.toString() : null);
					ResponseEntity<?> principalTransactionResp = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
							getPrincipalTransactionUrl, PrincipalTransDetail.class, params, null, headers);
					
					PrincipalTransDetail principalTransDetail = mapper.convertValue(principalTransactionResp.getBody(), PrincipalTransDetail.class);
					applicationParameters.put("okycLink", principalTransDetail.getUrl1());
					applicationParameters.put("refId2", principalTransDetail.getPrincipleRefId2());
					applicationParameters.put(URL2, principalTransDetail.getUrl2());
					
					if (principalkey != null && 3l == principalkey) {
						applicationParameters.put("modelbredirectionurl", principalTransDetail.getUrl1());
					}
					if (principalkey != null && 32 == principalkey
							&& !StringUtils.isBlank(principalTransDetail.getLpStatusMessage())) {

						applicationParameters.put("lpStatusMessage", principalTransDetail.getLpStatusMessage());
						if (("Accepted").equalsIgnoreCase(principalTransDetail.getLpStatusMessage())
								|| ("Suspended").equalsIgnoreCase(principalTransDetail.getLpStatusMessage())) {
							applicationParameters.put("inPrincipleLimit",
									null != principalTransDetail.getLoanamount()
											? principalTransDetail.getLoanamount().toString()
											: "0");
							applicationParameters.put("inPrincipleTenor",
									null != principalTransDetail.getTenure()
											? principalTransDetail.getTenure().toString()
											: "0");
						}
					}
				}else{
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside fetchApprovedDetails method Child App not found,applicationId: " + applicationId);
					throw new CreditBusinessException(HttpStatus.NOT_FOUND,new ErrorBean("OMCB_23", "Child App not found"));
				}
			}
			
		}catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,"CreditBusinessException Occured while fetching application parameters, applicationid: " + applicationId + " with exception: " , e);
			if (e.getCode().equals(HttpStatus.NOT_FOUND) && !CollectionUtils.isEmpty(applicationParameters)) {
				applicationParameter.setApplicationParameters(applicationParameters);
				return applicationParameter;
			}else {
				throw e;
			}
		}catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,"Exception Occured while fetching application parameters, applicationid: " + applicationId + " with exception: " , e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,new ErrorBean("OMCB_24", "Some Technical Exception Occured"));
		}
		applicationParameter.setApplicationParameters(applicationParameters);
		return applicationParameter;
	}
}
