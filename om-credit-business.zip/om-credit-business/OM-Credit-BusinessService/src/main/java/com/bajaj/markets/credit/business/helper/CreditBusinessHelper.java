package com.bajaj.markets.credit.business.helper;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CB_500;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CB_501;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CB_502;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CB_503;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.LISTING_BRE_ELIGILITY_TYPE_IV;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SALARIED_DOCTOR;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SELF_EMPLOYED_DOCTOR;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.STATUS_COMPLETED;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.StringTokenizer;

import org.activiti.engine.delegate.DelegateExecution;
import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.joda.time.PeriodType;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.Application;
import com.bajaj.markets.credit.business.beans.BankMaster;
import com.bajaj.markets.credit.business.beans.BranchDetails;
import com.bajaj.markets.credit.business.beans.CreateApplicationRequest;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.PanDetails;
import com.bajaj.markets.credit.business.beans.Product;
import com.bajaj.markets.credit.business.beans.ProductList;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Component
@Scope("prototype")
public class CreditBusinessHelper {

	private static final String PRINCIAL_SELECTEDBY_CUSTOMER_DETAIL = "princialSelectedbyCustomerDetail";

	private static final String PRINCIAL_SELECTEDBY_CUSTOMER = "princialSelectedByCustomer";

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	CustomDefaultHeaders customHeaders;

	@Autowired
	MasterDataRedisClientHelper masterDataRedisHelper;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	@Autowired
	private Environment env;

	@Value("#{'${omcreditbusinessservice.validHeaderKeys}'.split(',')}")
	private List<String> validHeaderKeys;
	
	ObjectMapper mapper = new ObjectMapper();

	private static final String CLASS_NAME = CreditBusinessHelper.class.getCanonicalName();
	
	final String APPLICATIONID = "applicationId";
	final String PRODUCT = "product";
	final String OCCUPATIONTYPE = "occupationType";
	final String CIBILJSON = "cibilJson";
	final String CIBILSOCORE = "cibilScore";
	final String EMPLOYERTYPE = "employerType";
	final String EMPLOYERCATEGORY = "employerCategory";
	final String EMPLOYERCLASIFICATION = "employerClassification";
	final String APPSCORELR = "appScoreLr";
	final String LRSCORE = "lrScore";
	final String APPSCOREML = "appScoreMl";
	final String MLSCORE = "mlScore";
	final String APPSCORELRV2 = "appScoreLrV2";
	final String LRSCOREV2 = "lrScoreV2"; 
	final String APPSCOREMLV2 = "appScoreMlV2";
	final String AGE = "age";
	final String USERPROFILE = "userProfile";
	final String DATEOFBIRTH = "dateOfBirth";
	final String MCPADDRESSDETAILS = "mcpAddressDetails";
	final String PRINCIPALPRODUCTDETAILS = "principalProductDetails";
	final String PRINCIPLEPRODUCTDETAILS = "principleProductDetails";
	final String PINCODEKEY = "pincodeKey";
	final String CITY = "city";
	final String BFLBRANCHKEY = "bflBranchKey";
	final String BFLBRANCH = "bflBranch";
	final String SUBSTAGEPERCENTAGE = "subStagePercentage";
	final String MONTHLYSALARYDETAILS = "monthlySalaryDetails";
	final String ESTIMATEDNETMONTHLYSALARYDETAILS = "estimatedNetMonthlySalaryDetails";
	final String JOURNEYSTAMP = "journeyStamp";
	final String SMALL_EMPLOYER = "Small Employer";
	final String ADDRESSLIST = "addressList";
	final String ADDRESSTYPEKEY = "addressTypeKey";
	final String FIFTY = "50";
	
	public ResponseEntity<?> invokeRestEndpoint(HttpMethod httpMethod, String url, Class<?> responseType, Map<String, String> params, String requestJson,
			HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start invokeRestEndpoint");
		removeUnwantedHeaders(headers);
		updateHttpHeaders(headers, customHeaders);
		HttpEntity<Object> entity = null;
		ResponseEntity<?> responseEntity = null;
		try {
			entity = new HttpEntity<>(requestJson, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "RequestEndpoint : " + url);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request JSON : " + requestJson);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Params : " + params);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request Type : " + httpMethod);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Headers : " + headers);

			if (params != null) {
				responseEntity = restTemplate.exchange(url, httpMethod, entity, responseType, params);
			} else {
				responseEntity = restTemplate.exchange(url, httpMethod, entity, responseType);
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Response from endpoint : " + responseEntity);
			if (responseEntity != null && responseEntity.getBody() != null)
				logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Body == " + mapper.writeValueAsString(responseEntity.getBody()));
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "End excuteRestCall");
			return new ResponseEntity<>(responseEntity.getBody(), responseEntity.getHeaders(), responseEntity.getStatusCode());
		} catch (HttpClientErrorException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					" Call failed for url: " + url + ", Error : " + e.getMessage() + ", Body == " + e.getResponseBodyAsString());
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, " HttpClientErrorException during " + url + " call for request: " + requestJson + e);
			if (e.getRawStatusCode() == 409) {
				return new ResponseEntity<>(e.getResponseBodyAsString(), e.getResponseHeaders(), e.getStatusCode());
			}
			if (e.getRawStatusCode() == 404) {
				throw new CreditBusinessException(e.getStatusCode(), null, e.getResponseBodyAsString(), e);
			}
			if (e.getRawStatusCode() == 406) {
				throw new CreditBusinessException(e.getStatusCode(), null, e.getResponseBodyAsString(), e);
			}
			throw new CreditBusinessException(e.getStatusCode(), new ErrorBean(CB_500, env.getProperty(CB_500)), null, e);
		} catch (HttpStatusCodeException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Call failed " + url + ", Error : " + e.getMessage());
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "HttpStatusCodeException during " + url + " call for request: " + requestJson, e);
			if (e.getRawStatusCode() == 500) {
				throw new CreditBusinessException(e.getStatusCode(), null, e.getResponseBodyAsString(), e);
			}
			throw new CreditBusinessException(e.getStatusCode(), new ErrorBean(CB_501, env.getProperty(CB_501)), null, e);
		} catch (RestClientException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Call failed " + url + ", Error : " + e.getMessage());
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, " RestClientException during " + url + " call for request: " + requestJson, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(CB_502, env.getProperty(CB_502)), null, e);
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Call failed " + url + ", Error : " + e.getMessage());
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, " Exception during " + url + " call for request: " + requestJson, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean(CB_503, env.getProperty(CB_503)), null, e);
		}
	}

	public static String objectToJson(Object object) {
		if (object != null && object instanceof String)
			return object.toString();
		Gson gson = new GsonBuilder().disableHtmlEscaping().serializeNulls().create();
		return gson.toJson(object);
	}

	public CreateApplicationRequest mapRequest(Application application) {
		CreateApplicationRequest createApplicationRequest = new CreateApplicationRequest();
		createApplicationRequest.setDateOfBirth(application.getDateOfBirth());
		createApplicationRequest.setMobile(application.getMobileNumber());
		createApplicationRequest.setL2ProductKey(application.getProductKey());
		createApplicationRequest.setHlProductIntent(null != application.getHlProductIntent() ? application.getHlProductIntent().getCode() : null);
		Map<String, String> nameMap = splitfullNameToFnameMnameLname(application.getName());
		Name name = new Name();
		name.setFirstName(nameMap.get(CreditBusinessConstants.FIRST_NAME));
		name.setMiddleName(nameMap.get(CreditBusinessConstants.MIDDLE_NAME));
		name.setLastName(nameMap.get(CreditBusinessConstants.LAST_NAME));
		createApplicationRequest.setName(name);
		return createApplicationRequest;
	}

	public static JSONObject getJSONObject(Object object) {
		String jsonString = objectToJson(object);
		Gson g = new GsonBuilder().disableHtmlEscaping().create();
		return g.fromJson(jsonString, JSONObject.class);
	}

	@SuppressWarnings("unchecked")
	public static JSONObject setName(String fullName) {
		int idx = fullName.lastIndexOf(' ');
		if (idx == -1)
			throw new IllegalArgumentException("Only a single name: " + fullName);
		JSONObject name = new JSONObject();
		name.put(CreditBusinessConstants.FIRST_NAME, fullName.substring(0, fullName.indexOf(' ')));
		name.put(CreditBusinessConstants.MIDDLE_NAME, fullName.substring(fullName.indexOf(' '), idx));
		name.put(CreditBusinessConstants.LAST_NAME, fullName.substring(idx + 1));
		return name;
	}

	public static Integer calculateAge(String dateOfBirth) {
		LocalDate birthDate = new LocalDate(dateOfBirth);
		LocalDate now = new LocalDate();
		Period period = new Period(birthDate, now, PeriodType.yearMonthDay());
		return period.getYears();

	}

	@SuppressWarnings("unchecked")
	public void populateBreRequestFromMcpDetails(JSONObject openArcCardListingInput, JSONObject mcpRequest, boolean callFromWorkflow, Double reqLoanAmount,
			Double reqTenure, Integer isSmallTicket) {
		if (mcpRequest != null && openArcCardListingInput != null) {
			String applicationId = openArcCardListingInput.get("applicationId").toString();
			String l2ProductCode = null;
			openArcCardListingInput.put("obligationAmount", mcpRequest.get("obligationAmount"));
			openArcCardListingInput.put("creditObligation", mcpRequest.get("creditObligation"));
			openArcCardListingInput.put("subStagePercentage", mcpRequest.get("subStagePercentage"));
			openArcCardListingInput.put("yearOfGraduation", mcpRequest.get("yearOfGraduation"));
			openArcCardListingInput.put("yearOfPostGraduation", mcpRequest.get("yearOfPostGraduation"));
			openArcCardListingInput.put("approvedFlag", mcpRequest.get("approvedFlag"));
			openArcCardListingInput.put("bmr1ApprovedFlag", mcpRequest.get("bmr1ApprovedFlag"));
			openArcCardListingInput.put("bmr2ApprovedFlag", mcpRequest.get("bmr2ApprovedFlag"));
			openArcCardListingInput.put("degreeCategory", mcpRequest.get("degreeCategory"));
			
			setBMR2CallsData(openArcCardListingInput, applicationId);
			
			openArcCardListingInput.put("registrationNumber", mcpRequest.get("registrationNumber"));
			openArcCardListingInput.put("yrOfAttainingCertificate", mcpRequest.get("yrOfAttainingCertificate"));
			openArcCardListingInput.put("journeyStamp", mcpRequest.get("journeyStamp"));
			
			
			if (null != mcpRequest.get("appSegmentation")) {
				Map<String, Object> appSegmentation = (Map<String, Object>) mcpRequest.get("appSegmentation");

				openArcCardListingInput.put("customerProfileSegment", appSegmentation.get("customerProfileSegment"));
				openArcCardListingInput.put("microSegment", appSegmentation.get("microSegment"));
				openArcCardListingInput.put("customerSegment", appSegmentation.get("customerSegment"));
				openArcCardListingInput.put("profileIncomeSegment", appSegmentation.get("profileIncomeSegment"));

			}

			if (mcpRequest.get("prodCategory") != null) {
				Map<String, Object> productCategory = (Map<String, Object>) mcpRequest.get("prodCategory");
				Object productDesc = productCategory != null ? productCategory.get("prodCatDesc") : null;
				l2ProductCode = productCategory.get("prodCatCode") != null ? productCategory.get("prodCatCode").toString() : null;
				openArcCardListingInput.put("product", productDesc);
			}

			Map<String, Object> userProfile = (Map<String, Object>) mcpRequest.get("userProfile");
			if (userProfile != null) {
				openArcCardListingInput.put("personalPAN",
						null != userProfile.get(CreditBusinessConstants.PAN_NUMBER) ? userProfile.get(CreditBusinessConstants.PAN_NUMBER).toString() : null);

				if (!callFromWorkflow && userProfile.get("applicationKey") != null && userProfile.get("applicantKey") != null) {
					Long applicationKey = Double.valueOf(userProfile.get("applicationKey").toString()).longValue();
					Long applicantKey = Double.valueOf(userProfile.get("applicantKey").toString()).longValue();
					JSONObject nsdlPanResponse = apiCallsHelper.getPanVerification(applicationKey, applicantKey);
					if (nsdlPanResponse != null) {
						logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Response From Pan Verifcation for : " + applicationKey + ":" + nsdlPanResponse);
						List<PanDetails> panDetailsList = new ArrayList<PanDetails>();
						PanDetails panDetails = new PanDetails();
						panDetails.setNameMatch(nsdlPanResponse.get("nameMatch") != null ? nsdlPanResponse.get("nameMatch").toString() : null);
						panDetails.setMatchScore(null);
						panDetails.setPanType(null);
						panDetails.setPanStatus(nsdlPanResponse.get("panStatus") != null ? nsdlPanResponse.get("panStatus").toString() : null);
						panDetailsList.add(panDetails);
						openArcCardListingInput.put("panDetails", panDetailsList);
					}
				}
				if (userProfile.get("dateOfBirth") != null) {
					String dob = (String) userProfile.get("dateOfBirth");
					openArcCardListingInput.put("DOB", dob);
					Integer age = calculateAge(dob);
					openArcCardListingInput.put("age", age);
				}

				if (userProfile.get("genderKey") != null) {
					Double genderKey = Double.valueOf(userProfile.get("genderKey").toString());
					String gender = masterDataRedisHelper.getGenderByTypeKey(genderKey.longValue());
					openArcCardListingInput.put("gender", gender);
				}

				if (!callFromWorkflow && userProfile.get("residenceTypeKey") != null) {
					ResidenceMaster[] resiTypes = apiCallsHelper.getAllResitypes();
					Double resiTypeKey = Double.valueOf(userProfile.get("residenceTypeKey").toString());
					if (resiTypes != null && resiTypes.length > 0) {
						for (ResidenceMaster resi : resiTypes) {
							if (resiTypeKey.longValue() == resi.getResidenceKey()) {
								openArcCardListingInput.put("resiType", resi.getResidenceValue());
								break;
							}
						}
					}
				}

			}

			Map<String, Object> occupation = (Map<String, Object>) mcpRequest.get("occupation");

			if (occupation != null && occupation.get("salariedDetail") != null) {
				Map<String, Object> salariedDet = (Map<String, Object>) occupation.get("salariedDetail");
				openArcCardListingInput.put("workExperience", salariedDet.get("experience"));

				if (!callFromWorkflow && salariedDet.get("employerName") != null) {
					JSONObject employer = CreditBusinessHelper.getJSONObject(salariedDet.get("employerName"));
					if (employer.get(CreditBusinessConstants.KEY) != null) {
						Long employerId = Double.valueOf(employer.get(CreditBusinessConstants.KEY).toString()).longValue();
						JSONObject employerMaster = apiCallsHelper.getEmployerMaster(employerId);
						if (employerMaster != null) {
							openArcCardListingInput.put("employerType", employerMaster.get(CreditBusinessConstants.EMPRMASTCATEGORY));
							openArcCardListingInput.put("companyCategory", employerMaster.get(CreditBusinessConstants.EMPRMASTSUBCATEGORY));
							
							if(salariedDet.get("industryType")== null) {
								if (null != employerMaster.get(CreditBusinessConstants.INDMASTKEY)) {
									Integer industryTypeKey = Integer.valueOf(employerMaster.get(CreditBusinessConstants.INDMASTKEY).toString());
									String industryTypeValue = apiCallsHelper.getSOLIndustryType(industryTypeKey);
									openArcCardListingInput.put("industryType", industryTypeValue);
								}
							}
				}
			}
				}
			}

			if (occupation != null && occupation.get("businessOwnerDetails") != null) {
				Map<String, Object> businessOwnerDetails = (Map<String, Object>) occupation.get("businessOwnerDetails");
				openArcCardListingInput.put("businessPAN", businessOwnerDetails.get("businessPan"));
				openArcCardListingInput.put("officeType", businessOwnerDetails.get("officeType"));

				if (openArcCardListingInput.get("companyType") == null && businessOwnerDetails.get("businessType") != null) {
					openArcCardListingInput.put("companyType", businessOwnerDetails.get("businessType").toString());
				}

				JSONObject industryType = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("industryType"));
				if (null != industryType && null != industryType.get(CreditBusinessConstants.KEY)) {
					Long industryTypeKey = Double.valueOf(industryType.get(CreditBusinessConstants.KEY).toString()).longValue();
					String industryTypeValue = apiCallsHelper.getIndustryType(industryTypeKey);
					openArcCardListingInput.put("industryType", industryTypeValue);
				}
				openArcCardListingInput.put("profitAfterTax",
						businessOwnerDetails.get("profitAfterTax") != null ? Double.valueOf(businessOwnerDetails.get("profitAfterTax").toString()) : null);
				openArcCardListingInput.put("averageBankBalance",
						businessOwnerDetails.get("averageBankBalance") != null ? Double.valueOf(businessOwnerDetails.get("averageBankBalance").toString())
								: null);

				if (businessOwnerDetails.get("businessVintage") != null) {
					openArcCardListingInput.put("businessVintage", businessOwnerDetails.get("businessVintage"));
				}
				JSONObject natureOfBusiness = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("natureOfBusiness"));
				openArcCardListingInput.put("natureOfBusiness",
						null != natureOfBusiness && null != natureOfBusiness.get(CreditBusinessConstants.KEY)
								? natureOfBusiness.get(CreditBusinessConstants.KEY).toString()
								: null);
				if (!callFromWorkflow && businessOwnerDetails.get("anualTurnover") != null) {
					JSONObject annualTurnover = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("anualTurnover"));
					if (annualTurnover.get(CreditBusinessConstants.VALUE) != null) {
						String annualTurnOverValue = annualTurnover.get(CreditBusinessConstants.VALUE).toString();
						JSONObject annualTurnOver = apiCallsHelper.getLookupByCode("ANNUALTURNOVER");
						ArrayList<Map<String, Object>> lookupValuesResponseList = (ArrayList<Map<String, Object>>) annualTurnOver
								.get("lookupValuesResponseList");
						if (annualTurnOverValue != null && !CollectionUtils.isEmpty(lookupValuesResponseList)) {
							for (Map<String, Object> turnOver : lookupValuesResponseList) {
								if (annualTurnOverValue.equalsIgnoreCase(turnOver.get(CreditBusinessConstants.VALUE).toString())) {
									openArcCardListingInput.put("annualTurnover",
											turnOver.get(CreditBusinessConstants.CODE) != null ? turnOver.get(CreditBusinessConstants.CODE).toString() : null);
								}
							}
						}
					}
				}
			}

			if (mcpRequest.get("mcpAddressDetails") != null) {
				List<Map<String, Object>> mcpAddressDetails = (List<Map<String, Object>>) mcpRequest.get("mcpAddressDetails");
				if (mcpAddressDetails != null && mcpAddressDetails.get(0) != null) {
					List<Map<String, Object>> principleProductDetailsArr = (List<Map<String, Object>>) mcpAddressDetails.get(0).get("principleProductDetails");
					openArcCardListingInput.put("principleProductDetails", principleProductDetailsArr);
				}
			}

			openArcCardListingInput.put("estimatedNetMonthlySalaryDetails", mcpRequest.get("estimatedNetMonthlySalaryDetails"));
			if (mcpRequest.get(PRINCIAL_SELECTEDBY_CUSTOMER_DETAIL) != null) {
				List prinicpleSelectedList = (List) mcpRequest.get(PRINCIAL_SELECTEDBY_CUSTOMER_DETAIL);
				openArcCardListingInput.put(PRINCIAL_SELECTEDBY_CUSTOMER, prinicpleSelectedList.isEmpty() ? null : prinicpleSelectedList);
			}

			if (mcpRequest.get("appScoreDetails") != null) {
				JSONObject appScore = CreditBusinessHelper.getJSONObject(mcpRequest.get("appScoreDetails"));
				openArcCardListingInput.put(CreditBusinessConstants.APP_SCORE,
						appScore.get("finalScore") != null ? Double.valueOf(appScore.get("finalScore").toString()) : null);
				openArcCardListingInput.put("appScoreLR", appScore.get("lrScore") != null ? Double.valueOf(appScore.get("lrScore").toString()) : null);
				openArcCardListingInput.put("appScoreML", appScore.get("mlScore") != null ? Double.valueOf(appScore.get("mlScore").toString()) : null);
				openArcCardListingInput.put("appScoreLRV2", appScore.get("lrScorev2") != null ? Double.valueOf(appScore.get("lrScorev2").toString()) : null);
				openArcCardListingInput.put("appScoreV2", appScore.get("lrScorev2") != null ? Double.valueOf(appScore.get("lrScorev2").toString()) : null);
			}

			setHlProductIntentandBTBankName(openArcCardListingInput, mcpRequest);
			setCoApplicantIncomeandObligation(openArcCardListingInput, mcpRequest);
			setPropertyDetails(openArcCardListingInput, mcpRequest);
			setExternalCallsData(openArcCardListingInput, applicationId, l2ProductCode);
			openArcCardListingInput.put("requiredProductList", getRequiredLoanAmtAndTenure(applicationId, mcpRequest, isSmallTicket));
		}

		if (!LISTING_BRE_ELIGILITY_TYPE_IV.equalsIgnoreCase(openArcCardListingInput.get("eligibilityType") != null ? openArcCardListingInput.get("eligibilityType").toString() : null)) {
			JSONObject incomeEstimation = apiCallsHelper.getIncomeEstimation(openArcCardListingInput.get("applicationId").toString(),null);

			if (null != incomeEstimation && null != incomeEstimation.get("status")
					&& STATUS_COMPLETED.equalsIgnoreCase(incomeEstimation.get("status").toString()) && null != incomeEstimation.get("incomemputationKey")) {

				openArcCardListingInput.put("noOfMonthsPerfiosDone",
						null != incomeEstimation.get("statementCollected") ? Double.valueOf(incomeEstimation.get("statementCollected").toString()).intValue()
								: null);
				openArcCardListingInput.put("perfiosJason",
						apiCallsHelper.fetchIncomeEstimatedChannelJson(incomeEstimation.get("incomemputationKey").toString()));
			}
		}

		if (mcpRequest.get("addressList") != null) {
			Gson gson = new Gson();
			String addressJson = gson.toJson(mcpRequest.get("addressList"));
			JSONArray addressDetails = gson.fromJson(addressJson, JSONArray.class);
			if (!CollectionUtils.isEmpty(addressDetails)) {
				for (int i = 0; i < addressDetails.size(); i++) {
					JSONObject address = CreditBusinessHelper.getJSONObject(addressDetails.get(i));
					if ("50".equals(address.get("addressTypeKey").toString()) && null!=address.get("pincodeKey")) {
						LocationResponseBean pinCodeMaster = apiCallsHelper
								.getPinCodeMaster(address.get("pincodeKey").toString());
						openArcCardListingInput.put("pincode", pinCodeMaster.getPincode());
						openArcCardListingInput.put("city", pinCodeMaster.getCityName());
					}
				}
			}
		}
		openArcCardListingInput.put("deactivateOfferList", mcpRequest.get("deactivateOfferList"));
		if(openArcCardListingInput.get("occupationType") != null && 
				(String.valueOf(openArcCardListingInput.get("occupationType")).equalsIgnoreCase(SELF_EMPLOYED_DOCTOR) || 
				String.valueOf(openArcCardListingInput.get("occupationType")).equalsIgnoreCase(SALARIED_DOCTOR))) {
			setDoctorsDetailsDetails(openArcCardListingInput,mcpRequest);
		}
	}

	@SuppressWarnings("unchecked")
	private void setExternalCallsData(JSONObject openArcCardListingInput, String applicationId, String l2ProductCode) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "into setExternalCallsData started");
		String creditVidyaStatus = null;
		String bmrDetails = null;
		List<String> externalCalls = new ArrayList<>();
		externalCalls.add("BMR");
		externalCalls.add("CreditVidya");

		for (String call : externalCalls) {
			try {
				if ("BMR".equalsIgnoreCase(call)) {
					bmrDetails = apiCallsHelper.getBmrDetails(applicationId);
				} else if ("CreditVidya".equalsIgnoreCase(call)) {
					JSONObject cvOutput = apiCallsHelper.getCreditVidyaStatus(applicationId, null);
					if (cvOutput != null) {
						creditVidyaStatus = cvOutput.get("validationstatus").toString();
					}
				}
			} catch (CreditBusinessException e) {
				if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
					logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
							"No " + call + " data found for application  " + applicationId);
					logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
							"No " + call + " found for application  " + applicationId);
				} else {
					logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
							"Exception while fetching " + call + " details ", e);
					throw e;
				}
			}
		}
		openArcCardListingInput.put("dedupeJson", bmrDetails);
		openArcCardListingInput.put("educationQualification", creditVidyaStatus);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "setExternalCallsData completed");
	}

	@SuppressWarnings("unchecked")
	private void setBMR2CallsData(JSONObject openArcCardListingInput, String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "into setBMR2CallsData started");
		String bmr2Response = null;
			try {
				bmr2Response = apiCallsHelper.getBmr2ResponseFromMongo(applicationId);
			} catch (CreditBusinessException e) {
				if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
					logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
							"No BMR2 data found for application  " + applicationId);
					logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
							"No BMR2 found for application  " + applicationId);
				} else {
					logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
							"Exception while fetching BMR2 details ", e);
				}
			}
		openArcCardListingInput.put("bmr2Response",bmr2Response);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "setBMR2CallsData completed");
	}
	
	private void setCoApplicantIncomeandObligation(JSONObject openArcCardListingInput, JSONObject mcpRequest) {
		openArcCardListingInput.put("coApplicantIncome",
				null != mcpRequest.get("coApplicantIncome") ? Double.valueOf(mcpRequest.get("coApplicantIncome").toString()) : 0);
		openArcCardListingInput.put("coApplicantObligation",
				null != mcpRequest.get("coapplicantObligation") ? Double.valueOf(mcpRequest.get("coapplicantObligation").toString()) : 0);
	}

	@SuppressWarnings("unchecked")
	private void setHlProductIntentandBTBankName(JSONObject openArcCardListingInput, JSONObject mcpRequest) {
		//set hlProductIntent for secured loan
		openArcCardListingInput.put("hlProductIntent", null != mcpRequest.get("hlProductIntent") ? mcpRequest.get("hlProductIntent") : null);

		//set BT Bank Name for Secured Balance Transfer Loan
		if (mcpRequest.get("btBankMasterKey") != null && null != mcpRequest.get("hlProductIntent")
				&& mcpRequest.get("hlProductIntent").toString().contains("BT")) {
			Long btBankMasterKey = Double.valueOf(mcpRequest.get("btBankMasterKey").toString()).longValue();
			BankMaster[] btBankMaster = apiCallsHelper.getBankDetails(btBankMasterKey);
			if (btBankMaster != null) {
				for (BankMaster bankMaster : btBankMaster) {
					openArcCardListingInput.put(CreditBusinessConstants.BTBANKNAME, bankMaster.getBankName());
				}
			}
		}
	}

	public static void updateHttpHeaders(HttpHeaders headers, CustomDefaultHeaders customDefaultHeaders) {
		if (headers != null) {
			headers.set("Content-Type", "application/json");
			if (null != customDefaultHeaders) {
				if (Objects.nonNull(customDefaultHeaders.getAuthtoken())) {
					headers.set(CustomDefaultHeaders.AUTH_TOKEN, customDefaultHeaders.getAuthtoken());
					headers.set(CustomDefaultHeaders.GUARD_TOKEN, customDefaultHeaders.getGuardtoken());
					headers.set(CustomDefaultHeaders.CMPTCORR_ID, customDefaultHeaders.getCmptcorrid());
					if (!StringUtils.isEmpty(customDefaultHeaders.getPlatform()))
						headers.set(CustomDefaultHeaders.PLATFORM, customDefaultHeaders.getPlatform());
				} else {
					headers.set(CustomDefaultHeaders.AUTH_TOKEN, MDC.get("authtoken"));
					headers.set(CustomDefaultHeaders.GUARD_TOKEN, MDC.get("guardtoken"));
					headers.set(CustomDefaultHeaders.CMPTCORR_ID, MDC.get("correlationId"));
					if (!StringUtils.isEmpty(MDC.get("platform")))
						headers.set(CustomDefaultHeaders.PLATFORM, MDC.get("platform"));
				}
			}
		}
	}

	private void removeUnwantedHeaders(HttpHeaders headers) {
		if (null != headers && !CollectionUtils.isEmpty(headers.keySet())) {
			Iterator<String> itr = headers.keySet().iterator();
			itr.forEachRemaining(key -> {
				if (!validHeaderKeys.stream().anyMatch(key::equalsIgnoreCase)) {
					itr.remove();
				}
			});
		}
	}

	public Map<String, String> setrequestParams(Object requestParamsLocal) {
		Map<String, String> map = new HashMap<>();
		if (requestParamsLocal != null) {
			StringTokenizer tokenizer = new StringTokenizer(requestParamsLocal.toString(), ";");
			String token = null;
			String key;
			String value;
			while (tokenizer.hasMoreTokens()) {
				token = tokenizer.nextToken();
				key = token.substring(0, token.indexOf('='));
				value = token.substring(token.indexOf('=') + 1);
				if (null != value && value.startsWith("{") && value.endsWith("}")) {
					JSONParser parser = new JSONParser();
					JSONObject jsonObject = new JSONObject();
					try {
						jsonObject = (JSONObject) parser.parse(value);
					} catch (ParseException e) {
						logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "Exception ocurred while parsing pathvariable" + e);
					}
					map.put(key, jsonObject.get(key) != null ? jsonObject.get(key).toString() : null);
				} else {
					map.put(key, value);
				}
			}
		}
		return map;
	}

	@SuppressWarnings("deprecation")
	public static String dateFormatter(String inputDateString, String inputDateFormat, String outputDateFormat) {
		String outputDate = null;
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat(inputDateFormat);
			SimpleDateFormat outputFormat = new SimpleDateFormat(outputDateFormat);
			outputFormat.setLenient(false);

			Date inputDate = inputFormat.parse(inputDateString);

			return outputFormat.format(inputDate);
		} catch (Exception exception) {
			BFLLoggerUtil.error(null, CLASS_NAME, BFLLoggerComponent.UTILITY, "Date format failed with exception: ", exception);
		}
		return outputDate;
	}

	@SuppressWarnings("unchecked")
	public void populatePropertyBreRequestFromMcpDetails(JSONObject propertyInput, JSONObject mcpRequest) {
		if (mcpRequest != null && propertyInput != null) {
			propertyInput.put("obligationAmount", mcpRequest.get("obligationAmount"));
			propertyInput.put("creditObligation", mcpRequest.get("creditObligation"));
			propertyInput.put("subStagePercentage", mcpRequest.get("subStagePercentage"));

			if (mcpRequest.get("prodCategory") != null) {
				Map<String, Object> productCategory = (Map<String, Object>) mcpRequest.get("prodCategory");
				Object productDesc = productCategory != null ? productCategory.get("prodCatDesc") : null;
				propertyInput.put("product", productDesc);
			}

			Map<String, Object> userProfile = (Map<String, Object>) mcpRequest.get("userProfile");
			if (userProfile != null) {
				propertyInput.put("personalPAN",
						null != userProfile.get(CreditBusinessConstants.PAN_NUMBER) ? userProfile.get(CreditBusinessConstants.PAN_NUMBER).toString() : null);

				if (userProfile.get("dateOfBirth") != null) {
					String dob = (String) userProfile.get("dateOfBirth");
					propertyInput.put("DOB", dob);
					Integer age = calculateAge(dob);
					propertyInput.put("age", age);
				}

				if (userProfile.get("genderKey") != null) {
					Double genderKey = Double.valueOf(userProfile.get("genderKey").toString());
					String gender = masterDataRedisHelper.getGenderByTypeKey(genderKey.longValue());
					propertyInput.put("gender", gender);
				}

				if (userProfile.get("residenceTypeKey") != null) {
					ResidenceMaster[] resiTypes = apiCallsHelper.getAllResitypes();
					Double resiTypeKey = Double.valueOf(userProfile.get("residenceTypeKey").toString());
					if (resiTypes != null && resiTypes.length > 0) {
						for (ResidenceMaster resi : resiTypes) {
							if (resiTypeKey.longValue() == resi.getResidenceKey()) {
								propertyInput.put("resiType", resi.getResidenceValue());
								break;
							}
						}
					}
				}

			}

			Map<String, Object> occupation = (Map<String, Object>) mcpRequest.get("occupation");

			if (occupation != null && occupation.get("salariedDetail") != null) {
				Map<String, Object> salariedDet = (Map<String, Object>) occupation.get("salariedDetail");
				propertyInput.put("workExperience", salariedDet.get("experience"));

				if (salariedDet.get("employerName") != null) {
					JSONObject employer = CreditBusinessHelper.getJSONObject(salariedDet.get("employerName"));
					if (employer.get(CreditBusinessConstants.KEY) != null) {
						Long employerId = Double.valueOf(employer.get(CreditBusinessConstants.KEY).toString()).longValue();
						JSONObject employerMaster = apiCallsHelper.getEmployerMaster(employerId);
						if (employerMaster != null) {
							propertyInput.put("employerType", employerMaster.get(CreditBusinessConstants.EMPRMASTCATEGORY));
							propertyInput.put("companyCategory", employerMaster.get(CreditBusinessConstants.EMPRMASTSUBCATEGORY));
						}
					}
				}
			}

			if (occupation != null && occupation.get("businessOwnerDetails") != null) {
				Map<String, Object> businessOwnerDetails = (Map<String, Object>) occupation.get("businessOwnerDetails");
				propertyInput.put("businessPAN", businessOwnerDetails.get("businessPan"));
				propertyInput.put("officeType", businessOwnerDetails.get("officeType"));

				if (propertyInput.get("companyType") == null && businessOwnerDetails.get("businessType") != null) {
					propertyInput.put("companyType", businessOwnerDetails.get("businessType").toString());
				}

				JSONObject industryType = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("industryType"));
				if (null != industryType && null != industryType.get(CreditBusinessConstants.KEY)) {
					Long industryTypeKey = Double.valueOf(industryType.get(CreditBusinessConstants.KEY).toString()).longValue();
					String industryTypeValue = apiCallsHelper.getIndustryType(industryTypeKey);
					propertyInput.put("industryType", industryTypeValue);
				}
				propertyInput.put("profitAfterTax",
						businessOwnerDetails.get("profitAfterTax") != null ? Double.valueOf(businessOwnerDetails.get("profitAfterTax").toString()) : null);
				propertyInput.put("averageBankBalance",
						businessOwnerDetails.get("averageBankBalance") != null ? Double.valueOf(businessOwnerDetails.get("averageBankBalance").toString())
								: null);

				if (businessOwnerDetails.get("businessVintage") != null) {
					propertyInput.put("businessVintage", businessOwnerDetails.get("businessVintage"));
				}
				JSONObject natureOfBusiness = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("natureOfBusiness"));
				propertyInput.put("natureOfBusiness",
						null != natureOfBusiness && null != natureOfBusiness.get(CreditBusinessConstants.KEY)
								? natureOfBusiness.get(CreditBusinessConstants.KEY).toString()
								: null);
				if (businessOwnerDetails.get("anualTurnover") != null) {
					JSONObject annualTurnover = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("anualTurnover"));
					if (annualTurnover.get(CreditBusinessConstants.VALUE) != null) {
						String annualTurnOverValue = annualTurnover.get(CreditBusinessConstants.VALUE).toString();
						JSONObject annualTurnOver = apiCallsHelper.getLookupByCode("ANNUALTURNOVER");
						ArrayList<Map<String, Object>> lookupValuesResponseList = (ArrayList<Map<String, Object>>) annualTurnOver
								.get("lookupValuesResponseList");
						if (annualTurnOverValue != null && !CollectionUtils.isEmpty(lookupValuesResponseList)) {
							for (Map<String, Object> turnOver : lookupValuesResponseList) {
								if (annualTurnOverValue.equalsIgnoreCase(turnOver.get(CreditBusinessConstants.VALUE).toString())) {
									propertyInput.put("annualTurnover",
											turnOver.get(CreditBusinessConstants.CODE) != null ? turnOver.get(CreditBusinessConstants.CODE).toString() : null);
								}
							}
						}
					}
				}
			}

			propertyInput.put("additionalParameterDetail", mcpRequest.get("additionalParameterDetail"));
			propertyInput.put("estimatedNetMonthlySalaryDetails", mcpRequest.get("estimatedNetMonthlySalaryDetails"));

			if (mcpRequest.get("appScoreDetails") != null) {
				JSONObject appScore = CreditBusinessHelper.getJSONObject(mcpRequest.get("appScoreDetails"));
				propertyInput.put(CreditBusinessConstants.APP_SCORE,
						appScore.get("finalScore") != null ? Double.valueOf(appScore.get("finalScore").toString()) : null);
				propertyInput.put("appScoreLR", appScore.get("lrScore") != null ? Double.valueOf(appScore.get("lrScore").toString()) : null);
				propertyInput.put("appScoreML", appScore.get("mlScore") != null ? Double.valueOf(appScore.get("mlScore").toString()) : null);
			}

			setHlProductIntentandBTBankName(propertyInput, mcpRequest);
		}

		if (mcpRequest.get("addressList") != null) {
			List<Map<String, Object>> addressList = (List<Map<String, Object>>) mcpRequest.get("addressList");
			if (!CollectionUtils.isEmpty(addressList)) {
				Map<String, Object> address = addressList.get(0);
				if (address.get("pincodeKey") != null) {
					LocationResponseBean locationAddressBean = apiCallsHelper.getPinCodeMaster(address.get("pincodeKey").toString());
					propertyInput.put("pincode", locationAddressBean.getPincode());
					propertyInput.put("city", locationAddressBean.getCityName());
				}
			}
		}

	}

	public static HttpHeaders updateHttpHeaders(HashMap<String, String> headersToUpdate, HttpHeaders headers) {
		if (null != headers && null != headersToUpdate) {
			Set<String> keys = headersToUpdate.keySet();

			if (!keys.isEmpty()) {
				keys.forEach(key -> {
					if (null != headersToUpdate.get(key)) {
						headers.set(key, headersToUpdate.get(key).toString());
					}
				});
			}
		}
		return headers;
	}

	@SuppressWarnings("unchecked")
	public List<JSONObject> getRequiredLoanAmtAndTenure(String applicationId,JSONObject mcpRequest, Integer isSmallTicket) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "into getRequiredLoanAmtAndTenure started");
		List<JSONObject> requiredProductList = new ArrayList<JSONObject>();
		JSONObject reqProduct = new JSONObject();
		reqProduct.put("requiredLoanAmount",  mcpRequest.get("requiredLoanAmount"));
		reqProduct.put("tenor", mcpRequest.get("requiredTenor"));

		if (isSmallTicket != null && 1 == isSmallTicket) {
			reqProduct.put("productSize", "STS");
		} else {
			reqProduct.put("productSize", "HTS");
		}

		requiredProductList.add(reqProduct);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "into getRequiredLoanAmtAndTenure completed");
		return requiredProductList;
	}

	private void setPropertyDetails(JSONObject openArcCardListingInput, JSONObject mcpRequest) {
		openArcCardListingInput.put("propertyIdentifiedFlag", mcpRequest.get("propertyIdentifiedFlag"));
	}

	public String formFullName(String firstName, String middleName, String lastName) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start - formFullNamemiddleName ");
		StringBuilder fullName = new StringBuilder();
		if (!StringUtils.isEmpty(firstName)) {
			fullName.append(firstName);
			if (!StringUtils.isEmpty(middleName)) {
				fullName.append(" ").append(middleName);
			}
			if (!StringUtils.isEmpty(lastName)) {
				fullName.append(" ").append(lastName);
			}
			return fullName.toString();
		} else {
			return null;
		}
	}
	
	public Map<String, String> addLinebreaks(String input, int maxLineLength) {
		Map<String, String> address = new HashMap<>();
		input = skipSpecialCharactersFromAddress(input);
		if(input.length()<maxLineLength) {
			address.put("addressLine1", input.substring(0, input.lastIndexOf(" ")));
			address.put("addressLine2", input.substring(input.lastIndexOf(" ") + 1));
		}
		StringTokenizer tok = new StringTokenizer(input, " ");
		StringBuilder output = new StringBuilder(input.length());
		int lineLen = 0;
		int counter = 1;
		while (tok.hasMoreTokens()) {
			String word = tok.nextToken() + " ";
			if (lineLen + word.length() > maxLineLength) {
				address.put("addressLine" + counter, output.toString().trim());
				output = new StringBuilder(input.length());
				lineLen = 0;
				counter++;
			}
			output.append(word);
			lineLen += word.length();
		}
		return address;
	}
	
	public String skipSpecialCharactersFromAddress(String address) {
		return org.apache.commons.lang3.StringUtils.normalizeSpace(address.replace(",", " ").replace("/", " ").replaceAll(CreditBusinessConstants.ADDRESS_SPECIAL_CHAR_SKIP, ""));
		
	}
	
	
	public ResponseEntity<?> invokeRestEndPointWithOptionalParams(HttpMethod httpMethod,
			UriComponentsBuilder url,
			Class<?> responseType,
			Map<String, String> params, String requestJson, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start invokeRestEndpoint" + CLASS_NAME);
		HttpEntity<Object> entity = null;
		ResponseEntity<?> responseEntity = null;
		try {
			entity = new HttpEntity<>(requestJson, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "RequestEndpoint : " + url.toUriString());
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request JSON : " + requestJson);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Params : " + params);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Request Type : " + httpMethod);
			responseEntity = restTemplate.exchange(
					url.toUriString(),
					httpMethod,
	                entity,
	                responseType
	        );
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Response from endpoint : " + responseEntity);
			if (responseEntity != null && responseEntity.getBody() != null)
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Body == " + mapper.writeValueAsString(responseEntity.getBody()));
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "End excuteRestCall");
			return new ResponseEntity<>(responseEntity.getBody(), responseEntity.getHeaders(),
					responseEntity.getStatusCode());
		} catch (HttpStatusCodeException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Call failed " + url + ", Error : " + e.getMessage());
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, "HttpStatusCodeException during " + url + " call" + requestJson + e);
			if (e.getRawStatusCode() == 500) {
				throw new CreditBusinessException(e.getStatusCode(), e.getResponseBodyAsString());
			}
			throw new CreditBusinessException(e.getStatusCode(),
					new ErrorBean(CreditBusinessConstants.CB_501, "HttpStatusCodeException while calling " + url + " " + e.getLocalizedMessage()));
		} catch (RestClientException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Call failed " + url + ", Error : " + e.getMessage());
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, " RestClientException during " + url + " call for" + requestJson + e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(CreditBusinessConstants.CB_502, "RestClientException while calling" + url + " " + e.getLocalizedMessage()));
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, " Call failed " + url + ", Error : " + e.getMessage());
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY, " Exception during " + url + " call for" + requestJson + e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean(CreditBusinessConstants.CB_503, "Exception while calling" + url + " " + e.getLocalizedMessage()));
		}
	}
	
	private void setDoctorsDetailsDetails(JSONObject openArcCardListingInput, JSONObject mcpRequest) {
		openArcCardListingInput.put("yearOfGraduation", mcpRequest.get("yearOfGraduation"));
		openArcCardListingInput.put("yearOfPostGraduation", mcpRequest.get("yearOfPostGraduation"));
		openArcCardListingInput.put("specialization", mcpRequest.get("specialization"));
		openArcCardListingInput.put("registrationCouncil", mcpRequest.get("registrationCouncil"));
		openArcCardListingInput.put("practiceType", mcpRequest.get("practiceType"));
	}

	public Map<String, String> splitfullNameToFnameMnameLname(String fullName) {
		Map<String, String> nameComponent = new HashMap<>();
		if (!org.apache.commons.lang3.StringUtils.isBlank(fullName)) {
			String[] nameArr = fullName.split(org.apache.commons.lang3.StringUtils.SPACE);
			if (nameArr.length >= 3) {
				nameComponent.put(CreditBusinessConstants.FIRST_NAME,
						fullName.substring(0, fullName.indexOf(org.apache.commons.lang3.StringUtils.SPACE)).trim());
				nameComponent.put(CreditBusinessConstants.MIDDLE_NAME,
						fullName.substring(fullName.indexOf(org.apache.commons.lang3.StringUtils.SPACE),
								org.apache.commons.lang3.StringUtils.lastIndexOf(fullName,
										org.apache.commons.lang3.StringUtils.SPACE))
								.trim());
				nameComponent.put(CreditBusinessConstants.LAST_NAME,
						fullName.substring(
								org.apache.commons.lang3.StringUtils.lastIndexOf(fullName,
										org.apache.commons.lang3.StringUtils.SPACE))
								.trim());
			} else if (nameArr.length == 2) {
				nameComponent.put(CreditBusinessConstants.FIRST_NAME,
						fullName.substring(0, fullName.indexOf(org.apache.commons.lang3.StringUtils.SPACE)).trim());
				nameComponent.put(CreditBusinessConstants.LAST_NAME,
						fullName.substring(
								org.apache.commons.lang3.StringUtils.lastIndexOf(fullName,
										org.apache.commons.lang3.StringUtils.SPACE))
								.trim());
			}
		}
		return nameComponent;
	}
	
	@SuppressWarnings("unchecked")
	public JSONObject populateSegmentationBRErequest(DelegateExecution execution, JSONObject mcpRequest) {
		String applicationKey = (String) execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY);
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Start populateSegmentationBRErequest for : " + applicationKey);
		JSONObject segmentationRequest = new JSONObject();
		try {			
			segmentationRequest.put(APPLICATIONID, execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
			segmentationRequest.put(PRODUCT, execution.getVariable(CreditBusinessConstants.PRODUCTDESC));
			segmentationRequest.put(OCCUPATIONTYPE, execution.getVariable(OCCUPATIONTYPE));
			segmentationRequest.put(CIBILJSON, execution.getVariable(CreditBusinessConstants.CIBIL_JSON));
			segmentationRequest.put(CIBILSOCORE, execution.getVariable(CIBILSOCORE));

			segmentationRequest.put(EMPLOYERTYPE,
					execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY) != null
							? execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY).toString()
							: null);
			segmentationRequest.put(EMPLOYERCATEGORY,
					execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY) != null
							? execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY).toString()
							: null);
			segmentationRequest.put(EMPLOYERCLASIFICATION,
					execution.getVariable(CreditBusinessConstants.EMPR_CLASSIFICATION) != null
							? execution.getVariable(CreditBusinessConstants.EMPR_CLASSIFICATION).toString()
							: SMALL_EMPLOYER);

			segmentationRequest.put(APPSCORELR,
					null != execution.getVariable(LRSCORE)
							? Integer.valueOf(execution.getVariable(LRSCORE).toString())
							: null);
			segmentationRequest.put(APPSCOREML,
					null != execution.getVariable(MLSCORE)
							? Integer.valueOf(execution.getVariable(MLSCORE).toString())
							: null);
			segmentationRequest.put(APPSCORELRV2,
					null != execution.getVariable(LRSCOREV2)
							? Integer.valueOf(execution.getVariable(LRSCOREV2).toString())
							: null);
			segmentationRequest.put(APPSCOREMLV2, null);

			populateDatafromMCP(mcpRequest, segmentationRequest, applicationKey);

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					" Exception during populateSegmentationBRErequest for : " + applicationKey + e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("1010", "Exception during populateSegmentationBRErequest"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Start populateSegmentationBRErequest for : " + applicationKey);
		return segmentationRequest;
	}

	@SuppressWarnings("unchecked")
	public void populateSegmentationBRErequestFromMcp(JSONObject mcpRequest, JSONObject segmentationRequest) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start populateSegmentationBRErequestFromMcp");

		try {
			if (mcpRequest.get("prodCategory") != null) {
				Map<String, Object> productCategory = (Map<String, Object>) mcpRequest.get("prodCategory");
				Object productDesc = productCategory != null ? productCategory.get("prodCatDesc") : null;
				segmentationRequest.put(PRODUCT, productDesc);
			}
			Map<String, Object> occupation = (Map<String, Object>) mcpRequest.get("occupation");
			if (occupation != null && occupation.get("salariedDetail") != null) {

				Map<String, Object> salariedDet = (Map<String, Object>) occupation.get("salariedDetail");
				if (salariedDet.get("employerName") != null) {
					JSONObject employer = CreditBusinessHelper.getJSONObject(salariedDet.get("employerName"));
					if (employer.get(CreditBusinessConstants.KEY) != null) {
						Long employerId = Double.valueOf(employer.get(CreditBusinessConstants.KEY).toString())
								.longValue();
						JSONObject employerMaster = apiCallsHelper.getEmployerMaster(employerId);
						if (employerMaster != null) {
							segmentationRequest.put(EMPLOYERTYPE,
									employerMaster.get(CreditBusinessConstants.EMPRMASTCATEGORY));
							segmentationRequest.put(EMPLOYERCATEGORY,
									employerMaster.get(CreditBusinessConstants.EMPRMASTSUBCATEGORY));
							segmentationRequest.put(EMPLOYERCLASIFICATION,
									employerMaster.get(CreditBusinessConstants.EMPR_CLASSIFICATION));
						}
					}
				}
			}

			if (mcpRequest.get("appScoreDetails") != null) {
				JSONObject appScore = CreditBusinessHelper.getJSONObject(mcpRequest.get("appScoreDetails"));
				segmentationRequest.put(APPSCORELR,
						appScore.get("lrScore") != null ? Double.valueOf(appScore.get("lrScore").toString()) : null);
				segmentationRequest.put(APPSCOREML,
						appScore.get("mlScore") != null ? Double.valueOf(appScore.get("mlScore").toString()) : null);
				segmentationRequest.put(APPSCORELRV2,
						appScore.get("lrScorev2") != null ? Double.valueOf(appScore.get("lrScorev2").toString())
								: null);
				segmentationRequest.put(APPSCOREMLV2, null);

			}
			segmentationRequest.put(SUBSTAGEPERCENTAGE, mcpRequest.get(SUBSTAGEPERCENTAGE));
			segmentationRequest.put(MONTHLYSALARYDETAILS, mcpRequest.get(ESTIMATEDNETMONTHLYSALARYDETAILS));
			segmentationRequest.put(JOURNEYSTAMP, mcpRequest.get(JOURNEYSTAMP));

			Map<String, Object> userProfile = (Map<String, Object>) mcpRequest.get(USERPROFILE);
			if (userProfile.get(DATEOFBIRTH) != null) {
				String dob = (String) userProfile.get(DATEOFBIRTH);
				Integer age = calculateAge(dob);
				segmentationRequest.put(AGE, age);
			}

			if (null != mcpRequest.get(MCPADDRESSDETAILS)) {
				List<Map<String, Object>> mcpAddressDetails = (List<Map<String, Object>>) mcpRequest
						.get(MCPADDRESSDETAILS);
				if (null != mcpAddressDetails && null != mcpAddressDetails.get(0)) {
					List<Map<String, Object>> principleProductDetailsArr = (List<Map<String, Object>>) mcpAddressDetails
							.get(0).get(PRINCIPLEPRODUCTDETAILS);
					segmentationRequest.put(PRINCIPALPRODUCTDETAILS, principleProductDetailsArr);
				}
			}

			if (mcpRequest.get(ADDRESSLIST) != null) {
				Gson gson = new Gson();
				String addressJson = gson.toJson(mcpRequest.get(ADDRESSLIST));
				JSONArray addressDetails = gson.fromJson(addressJson, JSONArray.class);
				for (Object addressObj : addressDetails) {
					JSONObject address = CreditBusinessHelper.getJSONObject(addressObj);
					if (FIFTY.equals(address.get(ADDRESSTYPEKEY).toString()) && null != address.get(PINCODEKEY)) {
						LocationResponseBean pinCodeMaster = apiCallsHelper
								.getPinCodeMaster(address.get(PINCODEKEY).toString());
						segmentationRequest.put(CITY, null != pinCodeMaster ? pinCodeMaster.getCityName() : null);
						String cityKey = null != pinCodeMaster.getCityKey() ? pinCodeMaster.getCityKey().toString()
								: null;
						String bflBranchKey = null != mcpRequest.get(BFLBRANCHKEY)
								? mcpRequest.get(BFLBRANCHKEY).toString()
								: null;
						if (null != cityKey && null != bflBranchKey) {
							Integer bflBranch = (int) Float.parseFloat(bflBranchKey);
							BranchDetails branchDetails = apiCallsHelper.getBranchDetails(cityKey,
									bflBranch.toString());
							segmentationRequest.put(BFLBRANCH,
									null != branchDetails ? branchDetails.getBranchName() : null);
						}
					}
				}
			}

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.UTILITY,
					" Exception during populateSegmentationBRErequestFromMcp  " + mcpRequest, e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("1010", "Exception during populateSegmentationBRErequestFromMcp"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start populateSegmentationBRErequestFromMcp ");
	}
	

	@SuppressWarnings("unchecked")
	private void populateDatafromMCP(JSONObject mcpRequest, JSONObject segmentationRequest, String applicationKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start populateDatafromMCP for : " + applicationKey);
		
		segmentationRequest.put(SUBSTAGEPERCENTAGE, mcpRequest.get(SUBSTAGEPERCENTAGE));
		segmentationRequest.put(MONTHLYSALARYDETAILS, mcpRequest.get(ESTIMATEDNETMONTHLYSALARYDETAILS));
		segmentationRequest.put(JOURNEYSTAMP, mcpRequest.get(JOURNEYSTAMP));

		Map<String, Object> userProfile = (Map<String, Object>) mcpRequest.get(USERPROFILE);
		if (userProfile.get(DATEOFBIRTH) != null) {
			String dob = (String) userProfile.get(DATEOFBIRTH);
			Integer age = calculateAge(dob);
			segmentationRequest.put(AGE, age);
		}

		if (null != mcpRequest.get(MCPADDRESSDETAILS)) {
			List<Map<String, Object>> mcpAddressDetails = (List<Map<String, Object>>) mcpRequest
					.get(MCPADDRESSDETAILS);
			if (null != mcpAddressDetails && null != mcpAddressDetails.get(0)) {
				List<Map<String, Object>> principleProductDetailsArr = (List<Map<String, Object>>) mcpAddressDetails
						.get(0).get(PRINCIPLEPRODUCTDETAILS);
				segmentationRequest.put(PRINCIPALPRODUCTDETAILS, principleProductDetailsArr);
			}
		}

		if (mcpRequest.get(ADDRESSLIST) != null) {
			Gson gson = new Gson();
			String addressJson = gson.toJson(mcpRequest.get(ADDRESSLIST));
			JSONArray addressDetails = gson.fromJson(addressJson, JSONArray.class);
			for (Object addressObj : addressDetails) {
				JSONObject address = CreditBusinessHelper.getJSONObject(addressObj);
				if (FIFTY.equals(address.get(ADDRESSTYPEKEY).toString()) && null != address.get(PINCODEKEY)) {
					LocationResponseBean pinCodeMaster = apiCallsHelper
							.getPinCodeMaster(address.get(PINCODEKEY).toString());
					segmentationRequest.put(CITY, null != pinCodeMaster ? pinCodeMaster.getCityName() : null);
					String cityKey = null != pinCodeMaster.getCityKey() ? pinCodeMaster.getCityKey().toString() : null;
					String bflBranchKey = null != mcpRequest.get(BFLBRANCHKEY) ? mcpRequest.get(BFLBRANCHKEY).toString()
							: null;
					if (null != cityKey && null != bflBranchKey) {
						Integer bflBranch = (int) Float.parseFloat(bflBranchKey);
						BranchDetails branchDetails = apiCallsHelper.getBranchDetails(cityKey, bflBranch.toString());
						segmentationRequest.put(BFLBRANCH,
								null != branchDetails ? branchDetails.getBranchName() : null);
					}
				}
			}
		}
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Start populateDatafromMCP for : " + applicationKey);
	}
	
	public String removeNullFromGivenString(String requestStr) {
		final String NULL = "NULL";
		if (null != requestStr) {
			String split[] = requestStr.split("\\s+");
			List<String> strlist = new ArrayList<>(Arrays.asList(split));
			StringBuffer buffer = new StringBuffer();
			for (String str : strlist) {
				if (!StringUtils.isEmpty(str) && !NULL.equalsIgnoreCase(str))
					buffer.append(str.trim() + " ");
			}
			return buffer.toString();
		}
		return null;
	}
}