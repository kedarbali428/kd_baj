package com.bajaj.markets.credit.business.controller;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.EmicResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.service.CreditBusinessEmicService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Valid
public class CreditBusinessEmicController {
	@Autowired
	private CreditBusinessEmicService creditBusinessEmicService;
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	private static final String CLASS_NAME = CreditBusinessEmicController.class.getCanonicalName();

	@Secured(value = { Role.SYSTEM, Role.CUSTOMER, Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE })
	@ApiOperation(value = "Encrypt Reuqest", notes = "Encrypt Request which is required to redirect on emic.", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "SuccessFully Encrypted", response = EmicResponse.class),
			@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Bad input parameter", response = ErrorBean.class),
			@ApiResponse(code = 400, message = "Application Key or any parameter is not according the data type specified"),
			@ApiResponse(code = 500, message = "Some Internal Eror Occured", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unathenticated"), @ApiResponse(code = 403, message = "Unauthorized") })
	@GetMapping("/v1/credit/applications/{applicationid}/lead-info")
	@CrossOrigin
	public ResponseEntity<EmicResponse> encryptEmicRequest(
			@Valid @PathVariable("applicationid") @NotBlank(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") String applicationId,
			@RequestParam("responseFormat") String responseFormat,
			@RequestParam("principalCode") String principalCode) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"encryptEmicRequest start with " + applicationId + " responseFormat : " + responseFormat + " For "
						+ principalCode);
		EmicResponse encryptedResponse = creditBusinessEmicService.encryptEmicRequest(applicationId, responseFormat);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"encryptEmicRequest end with " + encryptedResponse.toString());
		return new ResponseEntity<>(encryptedResponse, HttpStatus.OK);
		
	}

}
