package com.bajaj.markets.credit.business.beans;

public class Qualification {
	
	private Long qlfymastkey;
	
	private String qlfyprefcode;
	
	private String qlfyname;
	
	private String qlfydesc;
	
	private String qlfytype;
	
	private char categorycd;
	
	private int displayorder;
	
	private int specializationflag;
	
	private int pgflag;

	public Long getQlfymastkey() {
		return qlfymastkey;
	}

	public void setQlfymastkey(Long qlfymastkey) {
		this.qlfymastkey = qlfymastkey;
	}

	public String getQlfyprefcode() {
		return qlfyprefcode;
	}

	public void setQlfyprefcode(String qlfyprefcode) {
		this.qlfyprefcode = qlfyprefcode;
	}

	public String getQlfyname() {
		return qlfyname;
	}

	public void setQlfyname(String qlfyname) {
		this.qlfyname = qlfyname;
	}

	public String getQlfydesc() {
		return qlfydesc;
	}

	public void setQlfydesc(String qlfydesc) {
		this.qlfydesc = qlfydesc;
	}

	public String getQlfytype() {
		return qlfytype;
	}

	public void setQlfytype(String qlfytype) {
		this.qlfytype = qlfytype;
	}
	
	public char getCategorycd() {
		return categorycd;
	}

	public void setCategorycd(char categorycd) {
		this.categorycd = categorycd;
	}

	public int getDisplayorder() {
		return displayorder;
	}

	public void setDisplayorder(int displayorder) {
		this.displayorder = displayorder;
	}

	public int getSpecializationflag() {
		return specializationflag;
	}

	public void setSpecializationflag(int specializationflag) {
		this.specializationflag = specializationflag;
	}

	public int getPgflag() {
		return pgflag;
	}

	public void setPgflag(int pgflag) {
		this.pgflag = pgflag;
	}

	@Override
	public String toString() {
		return "QualifyMaster [qlfymastkey=" + qlfymastkey + ", qlfyprefcode=" + qlfyprefcode + ", qlfyname=" + qlfyname
				+ ", qlfydesc=" + qlfydesc + ", qlfytype=" + qlfytype + ", categorycd=" + categorycd + ", displayorder="
				+ displayorder + ", specializationflag=" + specializationflag + ", pgflag=" + pgflag + "]";
	}

}