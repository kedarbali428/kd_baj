package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;

public class EmployerDetails{
	
	private Long emprMasterId;
	
	private String emprMasterName;
	
	private String emprMastClassCode;
	
	private BigDecimal emprWeightage;
	
	private String emprMastCategory;
	
	private String emprMastSubcategory;

	public Long getEmprMasterId() {
		return emprMasterId;
	}

	public void setEmprMasterId(Long emprMasterId) {
		this.emprMasterId = emprMasterId;
	}

	public String getEmprMasterName() {
		return emprMasterName;
	}

	public void setEmprMasterName(String emprMasterName) {
		this.emprMasterName = emprMasterName;
	}

	public String getEmprMastClassCode() {
		return emprMastClassCode;
	}

	public void setEmprMastClassCode(String emprMastClassCode) {
		this.emprMastClassCode = emprMastClassCode;
	}

	public BigDecimal getEmprWeightage() {
		return emprWeightage;
	}

	public void setEmprWeightage(BigDecimal emprWeightage) {
		this.emprWeightage = emprWeightage;
	}

	public String getEmprMastCategory() {
		return emprMastCategory;
	}

	public void setEmprMastCategory(String emprMastCategory) {
		this.emprMastCategory = emprMastCategory;
	}

	public String getEmprMastSubcategory() {
		return emprMastSubcategory;
	}

	public void setEmprMastSubcategory(String emprMastSubcategory) {
		this.emprMastSubcategory = emprMastSubcategory;
	}
}
