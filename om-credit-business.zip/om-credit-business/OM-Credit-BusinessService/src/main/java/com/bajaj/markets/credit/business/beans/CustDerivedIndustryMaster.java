package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * The persistent class for the cust_derived_industry_master database table.
 * 
 */
public class CustDerivedIndustryMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long custIndMastKey;

	private String categoryCd;

	private String custIndMastCode;

	private String custIndMastDesc;

	private String custIndMastSubSectorCode;

	private Integer isActive;

	private Long lastUpdateBy;

	private Timestamp lastUpdateDt;

	public CustDerivedIndustryMaster() {
	}

	public Long getCustIndMastKey() {
		return custIndMastKey;
	}

	public void setCustIndMastKey(Long custIndMastKey) {
		this.custIndMastKey = custIndMastKey;
	}

	public String getCategoryCd() {
		return categoryCd;
	}

	public void setCategoryCd(String categoryCd) {
		this.categoryCd = categoryCd;
	}

	public String getCustIndMastCode() {
		return custIndMastCode;
	}

	public void setCustIndMastCode(String custIndMastCode) {
		this.custIndMastCode = custIndMastCode;
	}

	public String getCustIndMastDesc() {
		return custIndMastDesc;
	}

	public void setCustIndMastDesc(String custIndMastDesc) {
		this.custIndMastDesc = custIndMastDesc;
	}

	public String getCustIndMastSubSectorCode() {
		return custIndMastSubSectorCode;
	}

	public void setCustIndMastSubSectorCode(String custIndMastSubSectorCode) {
		this.custIndMastSubSectorCode = custIndMastSubSectorCode;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public Long getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(Long lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	public Timestamp getLastUpdateDt() {
		return lastUpdateDt;
	}

	public void setLastUpdateDt(Timestamp lastUpdateDt) {
		this.lastUpdateDt = lastUpdateDt;
	}


}