package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Business;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Salaried;

public class ProfileDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2703536940790674848L;

	private String name;

	private Gender gender;

	private MaritalStatus maritalStatus;
	private String pan;

	@NotEmpty(groups = { Salaried.class, Business.class }, message = "Personal Email can not be null or empty")
	private String personalEmailId;

	@NotEmpty(groups = { Business.class }, message = "Business Pan Can not be null or empty")
	private String businessPan;

	private String gstNumber;

	private OccupationDetail occupationType;

	private Long employerType;

	private String otherEmployerName;

	private EmployerNameDetail employerName;
	
	private Boolean isDentalDegree;
	
	private Boolean isCounsilDetailRequired;

	private Reference regCouncil;
	
	private String doctorRegistrationNumber;
	
	private Reference hospital;
	
	private String hospitalNameOther;
	
	private boolean officePinCodeRequired;

	private Reference officePinCode;
	
	public boolean isOfficePinCodeRequired() {
		return officePinCodeRequired;
	}

	public void setOfficePinCodeRequired(boolean officePinCodeRequired) {
		this.officePinCodeRequired = officePinCodeRequired;
	}

	public Reference getOfficePinCode() {
		return officePinCode;
	}

	public void setOfficePinCode(Reference officePinCode) {
		this.officePinCode = officePinCode;
	}

	public String getName() {
		return name;
	}

	private Long natureOfBusinessKey;
	
	private Long businessTypeKey;
	
	public void setName(String name) {
		this.name = name;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public MaritalStatus getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(MaritalStatus maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getPersonalEmailId() {
		return personalEmailId;
	}

	public void setPersonalEmailId(String personalEmailId) {
		this.personalEmailId = personalEmailId;
	}

	public String getBusinessPan() {
		return businessPan;
	}

	public void setBusinessPan(String businessPan) {
		this.businessPan = businessPan;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public OccupationDetail getOccupationType() {
		return occupationType;
	}

	public void setOccupationType(OccupationDetail occupationType) {
		this.occupationType = occupationType;
	}

	public EmployerNameDetail getEmployerName() {
		return employerName;
	}

	public void setEmployerName(EmployerNameDetail employerName) {
		this.employerName = employerName;
	}

	public Long getEmployerType() {
		return employerType;
	}

	public void setEmployerType(Long employerType) {
		this.employerType = employerType;
	}

	public String getOtherEmployerName() {
		return otherEmployerName;
	}

	public void setOtherEmployerName(String otherEmployerName) {
		this.otherEmployerName = otherEmployerName;
	}

	public Long getNatureOfBusinessKey() {
		return natureOfBusinessKey;
	}

	public void setNatureOfBusinessKey(Long natureOfBusinessKey) {
		this.natureOfBusinessKey = natureOfBusinessKey;
	}

	public Long getBusinessTypeKey() {
		return businessTypeKey;
	}

	public void setBusinessTypeKey(Long businessTypeKey) {
		this.businessTypeKey = businessTypeKey;
	}
	
	public Boolean getIsDentalDegree() {
		return isDentalDegree;
	}

	public void setIsDentalDegree(Boolean isDentalDegree) {
		this.isDentalDegree = isDentalDegree;
	}

	public Boolean getIsCounsilDetailRequired() {
		return isCounsilDetailRequired;
	}

	public void setIsCounsilDetailRequired(Boolean isCounsilDetailRequired) {
		this.isCounsilDetailRequired = isCounsilDetailRequired;
	}

	public Reference getRegCouncil() {
		return regCouncil;
	}

	public void setRegCouncil(Reference regCouncil) {
		this.regCouncil = regCouncil;
	}

	public String getDoctorRegistrationNumber() {
		return doctorRegistrationNumber;
	}

	public void setDoctorRegistrationNumber(String doctorRegistrationNumber) {
		this.doctorRegistrationNumber = doctorRegistrationNumber;
	}

	public Reference getHospital() {
		return hospital;
	}

	public void setHospital(Reference hospital) {
		this.hospital = hospital;
	}

	public String getHospitalNameOther() {
		return hospitalNameOther;
	}

	public void setHospitalNameOther(String hospitalNameOther) {
		this.hospitalNameOther = hospitalNameOther;
	}

	@Override
	public String toString() {
		return "ProfileDetail [name=" + name + ", gender=" + gender + ", maritalStatus=" + maritalStatus + ", pan="
				+ pan + ", personalEmailId=" + personalEmailId + ", businessPan=" + businessPan + ", gstNumber="
				+ gstNumber + ", occupationType=" + occupationType + ", employerType=" + employerType
				+ ", otherEmployerName=" + otherEmployerName + ", employerName=" + employerName + ", isDentalDegree="
				+ isDentalDegree + ", isCounsilDetailRequired=" + isCounsilDetailRequired + ", regCouncil=" + regCouncil
				+ ", doctorRegistrationNumber=" + doctorRegistrationNumber + ", hospital=" + hospital
				+ ", hospitalNameOther=" + hospitalNameOther + ", natureOfBusinessKey=" + natureOfBusinessKey
				+ ", businessTypeKey=" + businessTypeKey + "]";
	}
	
}
