package com.bajaj.markets.credit.business.helper;

/**
 * Enum containing all application status'
 * 
 * @author 764504
 *
 */
public enum ApplicationStatusEnum {

	INPROGRESS("Inprogress", 1), 
	AIP("AIP", 2), 
	REJECTED("Rejected",3), 
	APPROVAL("Approval",4);
	 
	private final String code;
	private final Integer key;

	private ApplicationStatusEnum(String code, Integer key) {
		this.code = code;
		this.key = key;
	}

	public Integer getKey() {
		return key;
	}
	
	public String getCode() {
		return code;
	}

}
