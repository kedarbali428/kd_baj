package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.STATUS_COMPLETED;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.impl.util.json.JSONArray;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.helper.ApplicantUpdateDetails;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Component
public class CreditBusinessUnderWriterServiceImpl {
	@Value("${api.omcibilverificationservice.cibil.get.url}")
	private String getCibilReferenceKeyUrl;

	@Value("${api.omcibilverificationservice.cibil.details.get.url}")
	private String getCibilDocumentUrl;
	@Value("${api.omcreditapplicationservice.application.underwriter-checks.post.url}")
	private String underwriterChecksUrl;

	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	private CreditBusinessHelper creditBusinessHelper;
	@Autowired
    CreditBusinessApiCallsHelper apiCallsHelper;

	private static final String CLASS_NAME = CreditBusinessUnderWriterServiceImpl.class.getCanonicalName();

    public void excuteUnderWriterCheckData(String applicationId, String applicantKey) {
        logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                "start excuteUnderWriterCheckData method for applicationId :" + applicationId + "applicantKey:="
                        + applicantKey);
        Map<String, String> queryParam = new HashMap<>();
        try {
            if (!StringUtils.isEmpty(applicationId) && !StringUtils.isEmpty(applicantKey)) {
                queryParam.put(CreditBusinessConstants.APPLICATIONKEY, applicationId);
                queryParam.put(CreditBusinessConstants.APPLICANTKEY, applicantKey);
                queryParam.put(CreditBusinessConstants.APPLICATION_KEY, applicationId);
                queryParam.put(CreditBusinessConstants.APPLICANT_KEY, applicantKey);
                queryParam.put(CreditBusinessConstants.CIBIL_REFERENCE_KEY, "");
                String cibilResponse = getCibilData(queryParam);
                JSONArray sourceArray = new JSONArray();
                if (!StringUtils.isEmpty(cibilResponse)) {
                    addSourceObject(CreditBusinessConstants.CIBIL_SOURCE_CONSTANT, cibilResponse, sourceArray);
                } else {
                    logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
                            "Error while getting Cibil Data ,it is either Null or have invalid Data for application Id :-"
                                    + applicationId);
                }
                String perfiosResponse = getPerfiosData(applicationId, applicantKey);
                if (!StringUtils.isEmpty(perfiosResponse)) {
                    addSourceObject(CreditBusinessConstants.PERFIOS_SOURCE_CONSTANT, perfiosResponse, sourceArray);
                } else {
                    logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
                            "Error while getting Perfios Data ,it is either Null or have invalid Data for application Id :-"
                                    + applicationId);
                }
                if (sourceArray.length() > 0) {
                    String requestPayload = sourceArray.toString();
                    logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                            "excuteUnderWriterCheckData  with Application Id: " + applicationId + "request Payload:="
                                    + requestPayload);
                    String underwriterChecksResponse = callApi(underwriterChecksUrl, HttpMethod.POST, queryParam,
                            requestPayload, String.class);
                    logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                            "excuteUnderWriterCheckData  with Application Id: " + applicationId
                                    + " get Response From Url :=" + underwriterChecksUrl + "Response :="
                                    + underwriterChecksResponse);
                } else {
                    logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                            "Error while getting data from source (cibil, perfios) ,it is either Null or have invalid Data for application Id :-"
                                    + applicationId);
                    throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
                            new ErrorBean("CBS-123", "source (cibil, perfios)Data Not Found"));
                }
            } else {
                logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                        "Error while getting ApplicationKey and Applicant Key From Execution ,it is either Null or Empty :-");
                throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
                        new ErrorBean("CBS-123", "ApplicationKey or Applicant Key Missing"));
            }
        } catch (CreditBusinessException e) {
            throw e;
        } catch (Exception e) {
            logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occurred while calling  UnderwriterChecks", e);
            throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
                    new ErrorBean("CBS-106", "Error occurred while calling  UnderwriterChecks"));
        }
    }

	
	
	private void addSourceObject(String sourceName, String sourceValue, JSONArray jsonArray) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("sourceName", sourceName);
		jsonObject.put("sourceValue", sourceValue);
		jsonArray.put(jsonObject);
	}

	private String getCibilData(Map<String, String> queryParam) {
	    String applicationId=queryParam.get(CreditBusinessConstants.APPLICATIONKEY);
	    logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start getCibilData for applicationId:- " + applicationId);
		String cibilDocumentResponse = null;
		String cibilType = null;
		try {
		JSONObject referenceKeyResponse = getCibilReferenceKeyResp(queryParam);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"referenceKeyResponse for applicationId:- " + applicationId + "response=" + referenceKeyResponse);
		if (null != referenceKeyResponse) {
			if (referenceKeyResponse.get("cibilTypeAndScore") != null) {
				List<Map<String, Object>> typeScoreList = (List<Map<String, Object>>) referenceKeyResponse
						.get("cibilTypeAndScore");
				if (!CollectionUtils.isEmpty(typeScoreList) && typeScoreList.get(0).get("cibilType") != null) {
					cibilType = typeScoreList.get(0).get("cibilType").toString();
				}
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,"cibilType  for applicationId:- " + applicationId+" cibilType="+cibilType);                 			
			if (referenceKeyResponse.get("cibilReferenceNumber") != null) {
				String cibilReferenceKey = referenceKeyResponse.get("cibilReferenceNumber").toString();
				cibilDocumentResponse = getCibilDocumentData(cibilReferenceKey, cibilType, applicationId);
			}else {
			    logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
		                "cibilReferenceNumber is missing  for applicationId:- " + applicationId);
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Exit From getCibilData for applicationId:- " + applicationId);
		}
        catch (Exception e) {
            logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occurred while getting cibil data for Application Id:-"+applicationId, e);
        }

		return cibilDocumentResponse;
	}

	private String getCibilDocumentData(String cibilReferenceKey, String cibilType, String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start getCibilDocumentData for applicationId:- "
				+ applicationId + " cibilType=" + cibilType + "cibilReferenceKey " + cibilReferenceKey);
		String cibilDocumentResponse = null;
		Map<String, String> qMap = new HashMap<>();
		qMap.put(CreditBusinessConstants.CIBIL_REFERENCE, cibilReferenceKey);
		qMap.put(CreditBusinessConstants.CIBIL_TYPE, cibilType);
		qMap.put(CreditBusinessConstants.FORMAT, CreditBusinessConstants.CIBIL_TYPE_COMMERCIAL);
		cibilDocumentResponse = callApi(getCibilDocumentUrl, HttpMethod.GET, qMap, null, String.class);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, " CIBIL document fetched" );
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,"Exit from  getCibilDocumentData for applicationId:- " + applicationId);				
		return cibilDocumentResponse;

	}

	private JSONObject getCibilReferenceKeyResp(Map<String, String> queryParam) {
	    String applicationId=queryParam.get(CreditBusinessConstants.APPLICATIONKEY);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Start getCibilReferenceKeyResp for applicationId:- " + applicationId);
		JSONObject referenceKeyResponse = null;
		queryParam.put(CreditBusinessConstants.CIBIL_TYPE, "");
		JSONObject[] referenceKeyRespArr = callApi(getCibilReferenceKeyUrl, HttpMethod.GET, queryParam, null,
				JSONObject[].class);
		if (referenceKeyRespArr != null && referenceKeyRespArr.length > 0) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,"CIBIL refernce key found for Application Id:-" + applicationId);					
			for (JSONObject referenceKeyResp : referenceKeyRespArr) {
				if (null != referenceKeyResp && null != referenceKeyResp.get("state")
						&& referenceKeyResp.get("state").toString().equals("COMPLETED")) {
					referenceKeyResponse = referenceKeyResp;
					break;
				} else {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "referenceKeyResp data" + referenceKeyResp);
				}
			}
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"cibil referenceKeyResponse either Null or empty for applicationId:- " + applicationId);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Exit from  getCibilReferenceKeyResp for applicationId:- " + applicationId);

		return referenceKeyResponse;
	}

	@SuppressWarnings("unchecked")
	private <T> T callApi(String url, HttpMethod methodType, Map<String, String> queryParam, String requestJson,
			Class<T> responseType) {
		ResponseEntity<T> apiResponse = (ResponseEntity<T>) creditBusinessHelper.invokeRestEndpoint(methodType, url,
				responseType, queryParam, requestJson, new HttpHeaders());
		return apiResponse != null ? apiResponse.getBody() : null;
	}
	
    private String getPerfiosData(String applicationId, String applicantId) {
        logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                "Start getPerfiosData for applicationId:- " + applicationId);
        String perfiosData = null;
        try {
            JSONObject incomeEstimation = apiCallsHelper.getIncomeEstimation(applicationId, applicantId);
            if (null != incomeEstimation && null != incomeEstimation.get("status")
                    && STATUS_COMPLETED.equalsIgnoreCase(incomeEstimation.get("status").toString())
                    && null != incomeEstimation.get("incomemputationKey")) {
                perfiosData = apiCallsHelper
                        .fetchIncomeEstimatedChannelJson(incomeEstimation.get("incomemputationKey").toString());
            }
        } catch (Exception e) {
            logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
                    "Error occurred while getting perfios data for Application Id:-" + applicationId, e);
        }
        logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
                "Exit From getPerfiosData for applicationId:- " + applicationId);

        return perfiosData;
    }

}
