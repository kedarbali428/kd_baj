package com.bajaj.markets.credit.business.beans;

import org.springframework.http.HttpHeaders;

public class ApplicantDataBean {
	private String applicantKey;
	private String occupationType;
	private String productCode;
	private HttpHeaders headers;
	private OfferApiRequest offerApiRequest;
	private String hlProductIntent;
	private Integer productKey;
	
	public String getApplicantKey() {
		return applicantKey;
	}
	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}
	public String getOccupationType() {
		return occupationType;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public HttpHeaders getHeaders() {
		return headers;
	}
	public void setHeaders(HttpHeaders headers) {
		this.headers = headers;
	}
	public OfferApiRequest getOfferApiRequest() {
		return offerApiRequest;
	}
	public void setOfferApiRequest(OfferApiRequest offerApiRequest) {
		this.offerApiRequest = offerApiRequest;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getHlProductIntent() {
		return hlProductIntent;
	}
	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}
	public Integer getProductKey() {
		return productKey;
	}
	public void setProductKey(Integer productKey) {
		this.productKey = productKey;
	}
	@Override
	public String toString() {
		return "ApplicantDataBean [applicantKey=" + applicantKey + ", occupationType=" + occupationType
				+ ", productCode=" + productCode + ", headers=" + headers + ", offerApiRequest=" + offerApiRequest
				+ ", hlProductIntent=" + hlProductIntent + ", productKey=" + productKey + "]";
	}
}