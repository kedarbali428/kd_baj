package com.bajaj.markets.credit.business.delegate;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST_HEADERS;

import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
@Scope("prototype")
public class ParellelRestClient implements JavaDelegate {

	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = ParellelRestClient.class.getCanonicalName();
	private Expression requestURL;
	private Expression requestType;
	private Expression requestParams;

	@Autowired
	Environment env;

	@Override
	public void execute(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "************* Start ParellelExecute *************");
		String taskId = execution.getCurrentActivityId();
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "ParellelExecution started for task = " + taskId);
		Object requestURLLocal = null;
		Object requestTypeLocal = null;
		Object requestParamsLocal = null;
		HashMap<String, String> requestHeadersLocal = null;
		String requestEntity = null;
		String requestUrl = null;
		HttpMethod method = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		if (null != requestURL && requestURL.getValue(execution) != null) {
			requestURLLocal = requestURL.getValue(execution);
			if (env.getProperty(requestURLLocal.toString()) != null)
				requestUrl = env.getProperty(requestURLLocal.toString()).trim();
		}
		if (null != requestType && requestType.getValue(execution) != null) {
			requestTypeLocal = requestType.getValue(execution);
			method = HttpMethod.resolve(requestTypeLocal.toString());
		}

		if (null != requestParams && null != requestParams.getValue(execution)) {
			requestParamsLocal = requestParams.getValue(execution);
		}

		Object requestHeaders = execution.getVariable(taskId.concat("_" + REQUEST_HEADERS));
		if (null != requestHeaders) {
			requestHeadersLocal = (HashMap<String, String>) requestHeaders;
			headers = CreditBusinessHelper.updateHttpHeaders(requestHeadersLocal, headers);
			execution.removeVariable(taskId.concat("_" + REQUEST_HEADERS));
		}

		ResponseEntity<?> responseEntity = null;
		try {
			if (!HttpMethod.GET.equals(method)) {
				requestEntity = CreditBusinessHelper.objectToJson(execution.getVariable(taskId.concat("_" + PAYLOAD)));
			}

			Map<String, String> map = creditBusinessHelper.setrequestParams(requestParamsLocal);
			responseEntity = creditBusinessHelper.invokeRestEndpoint(method, requestUrl, Object.class, map, requestEntity, headers);
		} catch (CreditBusinessException e) {
			throw new CreditBusinessException(e.getCode(), e.getErrorBean());
		}

		if (null != responseEntity) {
			if (null != responseEntity.getBody()) {
				execution.setVariable(taskId.concat("_" + OUTPUT), responseEntity.getBody());
			} else {
				execution.setVariable(taskId.concat("_" + OUTPUT), null);
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_DELEGATE, "************* End ParellelExecute for TaskId " + taskId + " *************");
	}
}
