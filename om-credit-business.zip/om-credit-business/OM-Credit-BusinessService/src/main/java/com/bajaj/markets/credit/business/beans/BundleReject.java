package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

public class BundleReject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8069296474154656668L;
	@NotBlank(message = "action can not be null")
	private String action;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "[action:" + action + "]";
	}

}
