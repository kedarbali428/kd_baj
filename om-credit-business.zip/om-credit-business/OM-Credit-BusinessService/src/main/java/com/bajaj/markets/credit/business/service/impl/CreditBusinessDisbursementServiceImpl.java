package com.bajaj.markets.credit.business.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.DisbursementEventRequestBean;
import com.bajaj.markets.credit.business.beans.DisbursementEventResponseBean;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.PrincipalTypeEnum;
import com.bajaj.markets.credit.business.service.CreditBusinessDisbursementService;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.google.gson.Gson;

@Component
public class CreditBusinessDisbursementServiceImpl implements CreditBusinessDisbursementService {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CustomDefaultHeaders customHeaders;
	
	@Autowired
	PublisherService publisherService;

	@Value("${aws.publisher.disb.topic.arn}")
	private String disbtopicArn;
	
	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Value("${api.omcreditapplicationservice.applicationDetails.get.url}")
	private String applicationDetailsUrl;
	
	@Value("${disb.sns.topic}")
	private String disbEventName;
	
	@Value("${api.omcreditapplicationservice.validaterequest.get.url}")
	private String validateRequestUrl;

	private static final String CLASS_NAME = CreditBusinessDisbursementServiceImpl.class.getCanonicalName();
	
	@Override
	public DisbursementEventResponseBean processDisbursement(String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start service processDisbursement :" + applicationId);
		Boolean isvalidRequest =validateRequest(applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start service processDisbursement after validation :" + applicationId);
		DisbursementEventResponseBean disbResponse = new DisbursementEventResponseBean();
		if(isvalidRequest)
		 disbResponse=initiateDisbursement(applicationId);
		else
		  throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("DISB_01", "Pre Checks Failed"));	
		return disbResponse;
	}
	
	
	@SuppressWarnings("unchecked")
	private Boolean validateRequest(String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start service validateRequest :" + applicationId);
		Map<String, String> params = new HashMap<>();
		params.put("applicationId",applicationId);
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		header.add("authtoken",customHeaders.getAuthtoken());
		header.add("cmptcorrid",customHeaders.getCmptcorrid());
		header.add("guardtoken",customHeaders.getGuardtoken());
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,validateRequestUrl,String.class, params, null, header);
		Gson gson = new Gson();
		Boolean isvalidRequest=false;
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				isvalidRequest = gson.fromJson(excuteRestCall.getBody().toString(),
						Boolean.class);
				 return isvalidRequest;
			}
		} catch (Exception e) {
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception occured while parsing validation request");
		}
		return isvalidRequest;
	}
	
	@SuppressWarnings("unchecked")
	public String fetchApplicationDetails(String applicationKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start service fetchApplicationDetails :" + applicationKey);
		String productCode=null;
		Map<String, String> params = new HashMap<>();
		params.put("applicationid",applicationKey);
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		header.add("authtoken",customHeaders.getAuthtoken());
		header.add("cmptcorrid",customHeaders.getCmptcorrid());
		header.add("guardtoken",customHeaders.getGuardtoken());
		ResponseEntity<String> excuteRestCall = (ResponseEntity<String>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,applicationDetailsUrl,String.class, params, null, header);
		Gson gson = new Gson();
		ApplicationDetail appDtl = new ApplicationDetail();
		try {
			if (null != excuteRestCall && null != excuteRestCall.getBody()) {
				 appDtl = gson.fromJson(excuteRestCall.getBody().toString(),
						ApplicationDetail.class);
				 productCode=appDtl.getL3ProductCode();
			}
		} catch (Exception e) {
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception occured while parsing fetchApplicationDetails request");
		}
		return productCode;
	}
	
	public DisbursementEventResponseBean initiateDisbursement(String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start service initiateDisbursement :" + applicationId);
		DisbursementEventRequestBean payload = new DisbursementEventRequestBean();
		payload.setEventType("INITIATE_DISBURSEMENT");
		payload.setProductCode(fetchApplicationDetails(applicationId)); 
		payload.setApplicationId(applicationId);
		DisbursementEventResponseBean response =ManageEvents(applicationId,payload);
		return response;
	}
	
	private DisbursementEventResponseBean ManageEvents(String applicationId,DisbursementEventRequestBean payload) {
		DisbursementEventResponseBean response = new DisbursementEventResponseBean();
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start service ManageEvents :" + applicationId);
			EventMessage eventMessage = createEventMessage(payload, PrincipalTypeEnum.BFL);
			publisherService.publish(disbtopicArn, eventMessage);
			response.setEventType(payload.getEventType());
			response.setMsg("Event Published Successfully");
			response.setStatus("SUCCESS");
			return response;
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Event : " + payload.getEventType() + " failed for Application: " + applicationId);
			response.setEventType(payload.getEventType());
			response.setMsg("Event Failed");
			response.setStatus("FAILURE");
			return response;
		}
	}
	
	private EventMessage createEventMessage(Object payload, PrincipalTypeEnum principalEnum) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start service createEventMessage :::");
		DisbursementEventRequestBean request =(DisbursementEventRequestBean) payload;
		request.setPrincipalName(principalEnum.getValue());
		
		Map<String, String> headers = new HashMap<>();
		Map<String, String> messageFilterAttributes = new HashMap<String, String>();
		
		headers.put(CreditBusinessConstants.AUTH_TOKEN, customHeaders.getAuthtoken());
		headers.put("cmptcorrid", customHeaders.getCmptcorrid());
		headers.put("guardtoken", customHeaders.getGuardtoken());
		
		messageFilterAttributes.put("productCode", request.getProductCode());
		messageFilterAttributes.put("principalName", principalEnum.getValue());
		
		EventMessage eventMessage = new EventMessage();
		eventMessage.setEventName(disbEventName);
		eventMessage.setEventType(request.getEventType());
		eventMessage.setPayload(payload);
		eventMessage.setHeaders(headers);
		eventMessage.setMessageFilterAttributes(messageFilterAttributes);
		return eventMessage;
	}

}