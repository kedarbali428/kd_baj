package com.bajaj.markets.credit.business.beans;

import java.util.Date;

public class ConsumerAddress {
	private String addressLine1;
	private String pinCode;
	private String addressCategory;
	private Date dateReported;

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getAddressCategory() {
		return addressCategory;
	}

	public void setAddressCategory(String addressCategory) {
		this.addressCategory = addressCategory;
	}

	public Date getDateReported() {
		return dateReported;
	}

	public void setDateReported(Date dateReported) {
		this.dateReported = dateReported;
	}

	@Override
	public String toString() {
		return "ConsumerAddress [addressLine1=" + addressLine1 + ", pinCode=" + pinCode + ", addressCategory="
				+ addressCategory + ", dateReported=" + dateReported + "]";
	}

}
