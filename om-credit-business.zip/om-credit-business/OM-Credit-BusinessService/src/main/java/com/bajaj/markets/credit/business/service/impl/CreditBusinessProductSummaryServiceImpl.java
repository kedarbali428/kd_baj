package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.Fees;
import com.bajaj.markets.credit.business.beans.FppPdfReportResponseBean;
import com.bajaj.markets.credit.business.beans.LoanDetails;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.RepaymentScheduleBean;
import com.bajaj.markets.credit.business.beans.SummaryDetails;
import com.bajaj.markets.credit.business.beans.SummaryResponse;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessProductSummaryService;
import com.bajaj.markets.referencedataclientlib.bean.LookupCodeValuesResponseBean;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.json.simple.JSONObject;

import be.quodlibet.boxable.BaseTable;
import be.quodlibet.boxable.Cell;
import be.quodlibet.boxable.Row;
import com.bajaj.markets.credit.business.beans.YearwiseInstallmentBean;
import com.bajaj.markets.credit.business.beans.MonthwiseInstallmentBean;
import java.io.ByteArrayInputStream;

/**
 * Controller for operations of Product Summary
 * 
 * @author 764504
 *
 */
@Service
public class CreditBusinessProductSummaryServiceImpl implements CreditBusinessProductSummaryService {
	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private WorkflowHelper workflowHelper;

	@Autowired
	private CreditBusinessHelper creditBusinessHelper;

	@Autowired
	private CreditBusinessApiCallsHelper apiCallsHelper;

	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String getChildApplicationUrl;

	@Value("${api.omcreditapplicationservice.loan.pricing.get.url}")
	private String getLoanPricingUrl;
	
	@Value("${api.omcreditcardsprincipalintegrationservice.repayment.GET.url}")
	private String getRepaymentScheduleUrl; 
	
	@Value("${api.omvasapplicationservice.pdfreporturl.GET.url}")
	private String getFppPdfReportResponseBeanUrl;

	@Value("${api.omcreditapplicationservice.getapplicationproduct.get.url}")
	private String getApplicationProduct;
	
	@Value("${analytics.repayment.flow.enable}")
	private boolean isAnalyticsRepayFlowEnabled;
	
	@Autowired
	MasterDataRedisClientHelper masterDataRedisClientHelper;

	private static final String CLASS_NAME = CreditBusinessProductSummaryServiceImpl.class.getCanonicalName();

	/**
	 * Method for used for processing product summary operations
	 * 
	 * @param String applicationId 
	 * @param SummaryDetails summaryRequest 
	 * @param HttpHeaders headers
	 * @return SummaryDetails
	 */
	@Override
	public ResponseEntity<SummaryDetails> postSummary(String applicationId, SummaryDetails summaryRequest, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start postSummary for applicationid : " + applicationId + " Request : " + summaryRequest);
		try {
			if (applicationId == null || !org.apache.commons.lang3.StringUtils.isNumeric(applicationId)) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Invalid application id passed");
				throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CBPS-102", "Invalid application id passed"));
			}
			Map<String, Object> vars = new HashMap<String, Object>();
			vars.put(CreditBusinessConstants.REQUEST, summaryRequest);
			vars.put("action", summaryRequest.getAction() != null ? summaryRequest.getAction().toLowerCase() : "next");
			vars.put(APPLICATION_ID, applicationId);
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			if (!StringUtils.isEmpty(nextTaskKey)) {
				NextTask task = new NextTask();
				task.setNextTaskKey(nextTaskKey);
				summaryRequest.setNextTask(task);
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End postSummary for applicationid : " + applicationId + " Response : " + summaryRequest);
			return new ResponseEntity<SummaryDetails>(summaryRequest, HttpStatus.CREATED);
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while completing workflow" + e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while completing workflow" + e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception occured while completing workflow");

		}
	}

	/**
	 * Method for used for fetching product summary details for active child of given applicationId
	 * Return if pricing with source EP and status Approved is present else returns pricing with source Journey
	 * 
	 * @param String applicationId 
	 * @param HttpHeaders headers
	 * @return SummaryResponse
	 */
	@Override
	public ResponseEntity<SummaryResponse> getSummary(String applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start getSummary for applicationid : " + applicationId);
		SummaryResponse response = null;
		try {
			response = setPricingDetails(applicationId, headers, response);
			return new ResponseEntity<SummaryResponse>(response, HttpStatus.OK);
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while fetching summary" + e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while fetching summary" + e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception occured while fetching summary");
		}
	}

	/**
	 * Method fetches pricing of isInProgress child of given applicationId.
	 * Return if pricing with source EP and status Approved is present else returns pricing with source Journey
	 * 
	 * @param parentApplicationId
	 * @param headers
	 * @param response
	 * @return SummaryResponse
	 */
	private SummaryResponse setPricingDetails(String parentApplicationId, HttpHeaders headers, SummaryResponse response) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start setPricingDetails for applicationid : " + parentApplicationId);

		Map<String, Object> childApplication = getActiveChild(parentApplicationId);
		String childApplicationKey = childApplication.get(CreditBusinessConstants.APPLICATIONKEY) != null
				? childApplication.get(CreditBusinessConstants.APPLICATIONKEY).toString()
				: null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Fetching Summary data for child app  :" + childApplicationKey);
		return getLoanPricing(headers, childApplicationKey);
		
	}

	@SuppressWarnings("unchecked")
	public SummaryResponse getLoanPricing(HttpHeaders headers, String childApplicationKey) {
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", childApplicationKey);
		ResponseEntity<List<?>> pricingResponse = (ResponseEntity<List<?>>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getLoanPricingUrl,
				List.class, params, null, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Response from Get Loan Pricing " + pricingResponse);
		if (pricingResponse != null && !CollectionUtils.isEmpty(pricingResponse.getBody())) {
			String hlProductIntent = null;
			//get hlProductIntent from application Id
			params.put("applicationid", childApplicationKey);
			ResponseEntity<?> getApplicationProductResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					getApplicationProduct, String.class, params, null, headers);
			Gson gson = new Gson();
			JSONObject payload = gson.fromJson((String) getApplicationProductResponse.getBody(), JSONObject.class);
			if(null != payload.get("hlProductIntent")) {
				LookupCodeValuesResponseBean lookupCodeValuesResponseBean = masterDataRedisClientHelper.getLookupValueByLookupCodeAndSortTxt("HLPRODUCTINTENT", payload.get("hlProductIntent").toString());
				if (null != lookupCodeValuesResponseBean) {
					hlProductIntent = lookupCodeValuesResponseBean.getValue();
				}
			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Checking if pricing with source EP and Approved status is present ");
			Optional<?> epPricing = pricingResponse.getBody().stream().filter(i -> {
				Map<String, Object> j = (Map<String, Object>) i;
				return (j.get("pricingStatus") != null && j.get("source") != null && "EP".equalsIgnoreCase(j.get("source").toString())
						&& CreditBusinessConstants.APPROVED.equalsIgnoreCase(j.get("pricingStatus").toString()));
			}).findFirst();

			if (epPricing.isPresent()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Returning EP pricing");
				return prepareResponse((Map<String, Object>) epPricing.get(),hlProductIntent);
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Checking if pricing with source Journey and Approved status is present ");
				Optional<?> journeyPricing = pricingResponse.getBody().stream().filter(i -> {
					Map<String, Object> j = (Map<String, Object>) i;
					return (j.get("pricingStatus") != null && j.get("source") != null && "Journey".equalsIgnoreCase(j.get("source").toString())
							&& CreditBusinessConstants.APPROVED.equalsIgnoreCase(j.get("pricingStatus").toString()));
				}).findFirst();
				if (journeyPricing.isPresent()) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Returning Journey pricing");
					return prepareResponse((Map<String, Object>) journeyPricing.get(),hlProductIntent);
				}
			}
		}
		logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "No Journey/EP pricing available for applicationId " + childApplicationKey);
		throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
				new ErrorBean("CBPS-101", "No Journey/EP pricing available for applicationId " + childApplicationKey));
	}

	@SuppressWarnings("unchecked")
	private Map<String, Object> getActiveChild(String parentApplicationId) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("applicationkey", parentApplicationId);
		params.put("isInProcessing", Boolean.TRUE.toString());
		List<Map<String, Object>> childApps = apiCallsHelper.callApi(getChildApplicationUrl, HttpMethod.GET, params, null, List.class);
		if (CollectionUtils.isEmpty(childApps)) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "No active child found for appliction " + parentApplicationId);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-101", "No active child found for appliction " + parentApplicationId));
		}

		Map<String, Object> childApplication = childApps.get(0);
		return childApplication;
	}

	@SuppressWarnings("unchecked")
	private SummaryResponse prepareResponse(Map<String, Object> body, String hlProductIntent) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start prepareResponse");
		SummaryResponse response = new SummaryResponse();
		response.setL2productCode(body.get("prodCategoryCode") != null ? body.get("prodCategoryCode").toString() : null);
		response.setL3productCode(body.get("l3ProductCode") != null ? body.get("l3ProductCode").toString() : null);
		response.setL4productCode(body.get("l4ProductCode") != null ? body.get("l4ProductCode").toString() : null);
		response.setTotalAmount(body.get("finalLoanAmount") != null ? Double.valueOf(body.get("finalLoanAmount").toString()) : null);
		response.setNetDisbursementAmount(body.get("netDisbursementAmount") != null ? Double.valueOf(body.get("netDisbursementAmount").toString()) : null);
		response.setBundleSelected(body.get("bundleSelected") != null && Integer.parseInt(body.get("bundleSelected").toString()) == 1 ? true : false);
		LoanDetails loanDetails = new LoanDetails();
		loanDetails.setAmount(body.get("finalLoanAmount") != null ? Double.valueOf(body.get("finalLoanAmount").toString()) : null);
		loanDetails.setEmi(body.get("emiAmount") != null ? Double.valueOf(body.get("emiAmount").toString()) : null);
		loanDetails.setRoi(body.get("finalRoi") != null ? Double.valueOf(body.get("finalRoi").toString()) : null);
		loanDetails.setRoiWithoutBundle(body.get("roiWithoutBundle")!=null?Double.valueOf(body.get("roiWithoutBundle").toString()):null);

		loanDetails.setEmidate(body.get("firstDueDate") != null ? body.get("firstDueDate").toString() : null);
		if (!StringUtils.isEmpty(loanDetails.getEmidate())) {
			String[] dateArr = loanDetails.getEmidate().split("-");
			loanDetails.setEmiCycleDate(dateArr[dateArr.length - 1]);
		}

		Double isTenure = body.get("isTenure") != null ? Double.valueOf(body.get("isTenure").toString()) : 0;
		Double dropLineTenure = body.get("droplineTenure") != null ? Double.valueOf(body.get("droplineTenure").toString()) : 0;
		Double totalTenor = Double.sum(isTenure, dropLineTenure);
		 
		loanDetails.setTenor(totalTenor);
		response.setLoanDetails(loanDetails);

		List<Fees> fees = null;
		Double totalFee = 0d;
		if (body.get("fees") != null) {
			List<Map<String, Object>> feesList = (List<Map<String, Object>>) body.get("fees");
			fees = new ArrayList<>();
			for (Map<String, Object> f : feesList) {
				Fees fee = new Fees();
				fee.setFeeCode((String) f.get("feeCode"));
				fee.setFeesInAmount(BigDecimal.valueOf((Double) (f.get("feesInAmount"))));
				fee.setFeesInPercent(BigDecimal.valueOf((Double) (f.get("feesInPercent"))));
				totalFee = Double.sum(totalFee, fee.getFeesInAmount().doubleValue());
				fees.add(fee);
			}
		}
		Double bundleCost = null;
		Double loanAmmountWithBundle = body.get("loanAmmountWithBundle") != null ? Double.valueOf(body.get("loanAmmountWithBundle").toString()) : 0;
		Double loanAmmountWithoutBundle = body.get("loanAmmountWithoutBundle") != null ? Double.valueOf(body.get("loanAmmountWithoutBundle").toString()) : 0;
		Double netDisbursementAmt = body.get("netDisbursementAmount") != null ? Double.valueOf(body.get("netDisbursementAmount").toString()) : null;
		if (loanAmmountWithBundle != 0D) {
			bundleCost = loanAmmountWithBundle - loanAmmountWithoutBundle;
			if (0D == bundleCost) {
				bundleCost = loanAmmountWithoutBundle - netDisbursementAmt - totalFee;
			}
		}
		response.setBundleCost(bundleCost);
		response.setFeeList(fees);
		response.setTotalFeeAmount(totalFee);
		//		response.setChildApplicationId(applicationId);
		//HL Product Intent for Secured Loan
		response.setHlProductIntent(null != hlProductIntent ? hlProductIntent : null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End prepareResponse");
		return response;
	}
	
	@Override
	public ByteArrayInputStream generatePDFByRepaymentSchedule (String applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start generate PDF with applicationId  : " + applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start getting child applicationId for parentApplicationid : " + applicationId);
		ObjectMapper mapper = new ObjectMapper();
		RepaymentScheduleBean repaymentScheduleBean = null;
		Map<String, Object> childApplication = getActiveChild(applicationId);
		String childApplicationKey = childApplication.get(CreditBusinessConstants.APPLICATIONKEY) != null
				? childApplication.get(CreditBusinessConstants.APPLICATIONKEY).toString()
				: null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Fetching repayment schedule bean for child applicationId  :" + childApplicationKey);
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put("applicationid", childApplicationKey);
		if(isAnalyticsRepayFlowEnabled) {
			queryParam.put("repaymentSource", CreditBusinessConstants.ANALYTICS_REPAYMENT_SOURCE);
		}else {
			queryParam.put("repaymentSource", CreditBusinessConstants.PENNANT_REPAYMENT_SOURCE);
		}
		try {
		ResponseEntity<?> getRepaymentScheduleResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				getRepaymentScheduleUrl, Object.class, queryParam, null, headers);
		repaymentScheduleBean = mapper.convertValue(getRepaymentScheduleResponse.getBody(),RepaymentScheduleBean.class);
		ByteArrayInputStream response = null;
		response = generatePDFByRepaymentSchedule(repaymentScheduleBean);
		return response;
		}catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while generating pdf" + e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while generating pdf" + e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception occured while generating pdf");
		}
	}
	
   private ByteArrayInputStream generatePDFByRepaymentSchedule(RepaymentScheduleBean bean) throws IOException {
		float margin = 37;
		// Initialize Document
		PDDocument doc = new PDDocument();
		PDPage page = new PDPage();
		doc.addPage(page);
		float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
		float yStartNewPage = page.getMediaBox().getHeight() - (2 * margin);
		boolean drawContent = true;
		boolean drawLines = true;
		float yStart = yStartNewPage;
		float pageBottomMargin = 70;
		BaseTable table = new BaseTable(yStart, yStartNewPage, pageBottomMargin, tableWidth, margin, doc, page, drawLines,drawContent);

		int fontSizeValue = 10;
		int rowSizeValue = 25;
		PDFont font = PDType1Font.HELVETICA_BOLD;
		
		PDPageContentStream titleRepaymentSchedule =null;
		
		try {
			titleRepaymentSchedule = new PDPageContentStream(doc, page, true, true);
		}
		catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while generatePDFByRepaymentSchedule" + e);
			throw e;
		} finally {
			titleRepaymentSchedule.close(); 
		}
		titleRepaymentSchedule.beginText();
		titleRepaymentSchedule.setFont(font, 18);
		titleRepaymentSchedule.newLineAtOffset(230, 750);
		String text = "";
		titleRepaymentSchedule.showText(text);
		titleRepaymentSchedule.endText();
		titleRepaymentSchedule.close();		
		
		
		Row<PDPage> rowHeader = table.createRow(rowSizeValue);
		Cell<PDPage> cellHeaderYear = rowHeader.createCell(rowSizeValue,"Year");
		cellHeaderYear.setFont(font);
		cellHeaderYear.setFillColor(Color.LIGHT_GRAY);
		cellHeaderYear.setTextColor(Color.BLACK);
		cellHeaderYear.setFontSize(fontSizeValue);
		Cell<PDPage> cellHeaderPricipal = rowHeader.createCell(rowSizeValue,"Principal");
		cellHeaderPricipal.setFont(font);
		cellHeaderPricipal.setFillColor(Color.LIGHT_GRAY);
		cellHeaderPricipal.setTextColor(Color.BLACK);
		cellHeaderPricipal.setFontSize(fontSizeValue);
		Cell<PDPage> cellHeaderInterest = rowHeader.createCell(rowSizeValue,"Interest");
		cellHeaderInterest.setFont(font);
		cellHeaderInterest.setFillColor(Color.LIGHT_GRAY);
		cellHeaderInterest.setTextColor(Color.BLACK);
		cellHeaderInterest.setFontSize(fontSizeValue);			
		Cell<PDPage> cellHeaderTotal = rowHeader.createCell(rowSizeValue,"Total");
		cellHeaderTotal.setFont(font);
		cellHeaderTotal.setFillColor(Color.LIGHT_GRAY);
		cellHeaderTotal.setTextColor(Color.BLACK);
		cellHeaderTotal.setFontSize(fontSizeValue);
		
		for (YearwiseInstallmentBean yearwiseInstallmentBean : bean.getSelectedEmiData()) {
			
			// Creation of Year data
			Row<PDPage> rowYearValue =  table.createRow(rowSizeValue);

			Cell<PDPage> cellYearRowYear = rowYearValue.createCell(rowSizeValue,yearwiseInstallmentBean.getYear());
			cellYearRowYear.setFont(font);
			cellYearRowYear.setFillColor(Color.YELLOW);
			cellYearRowYear.setTextColor(Color.BLACK);
			cellYearRowYear.setFontSize(fontSizeValue);
			Cell<PDPage> cellYearRowPricipal = rowYearValue.createCell(rowSizeValue,yearwiseInstallmentBean.getPrincipal());
			cellYearRowPricipal.setFont(font);
			cellYearRowPricipal.setFillColor(Color.YELLOW);
			cellYearRowPricipal.setTextColor(Color.BLACK);
			cellYearRowPricipal.setFontSize(fontSizeValue);
			Cell<PDPage> cellYearRowInterest = rowYearValue.createCell(rowSizeValue,yearwiseInstallmentBean.getInterest());
			cellYearRowInterest.setFont(font);
			cellYearRowInterest.setFillColor(Color.YELLOW);
			cellYearRowInterest.setTextColor(Color.BLACK);
			cellYearRowInterest.setFontSize(fontSizeValue);			
			Cell<PDPage> cellYearRowTotal = rowYearValue.createCell(rowSizeValue,yearwiseInstallmentBean.getTotal());
			cellYearRowTotal.setFont(font);
			cellYearRowTotal.setFillColor(Color.YELLOW);
			cellYearRowTotal.setTextColor(Color.BLACK);
			cellYearRowTotal.setFontSize(fontSizeValue);
			
			for(MonthwiseInstallmentBean monthwiseInstallmentBean : yearwiseInstallmentBean.getMonthlyInstallment()){
				// Creation of Month data
				Row<PDPage> rowMonthValue =  table.createRow(rowSizeValue);
				Cell<PDPage> cellMonthRowMonth = rowMonthValue.createCell(rowSizeValue,monthwiseInstallmentBean.getMonth());
				cellMonthRowMonth.setFontSize(fontSizeValue);
				Cell<PDPage> cellMonthRowPrincipal = rowMonthValue.createCell(rowSizeValue,monthwiseInstallmentBean.getMonthlyPrincipal());
				cellMonthRowPrincipal.setFontSize(fontSizeValue);
				Cell<PDPage> cellMonthRowInterest = rowMonthValue.createCell(rowSizeValue,monthwiseInstallmentBean.getMonthlyInterest());
				cellMonthRowInterest.setFontSize(fontSizeValue);			
				Cell<PDPage> cellMonthRowTotal = rowMonthValue.createCell(rowSizeValue,monthwiseInstallmentBean.getMonthlyTotal());
				cellMonthRowTotal.setFontSize(fontSizeValue);
			}		
		}		
		table.draw();
		
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		doc.save(byteArrayOutputStream);
		doc.close();
		
		return new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
	}

   @Override
   public ResponseEntity<FppPdfReportResponseBean> getFppPdfReportUrl(String applicationId, HttpHeaders headers){
	    logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start getting FPP PDF Report URL  : " + applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start getting child applicationId for parentApplicationid : " + applicationId);
		ObjectMapper mapper = new ObjectMapper();
	    FppPdfReportResponseBean fppPdfReportResponseBean = null;
	    Map<String, Object> childApplication = getActiveChild(applicationId);
		String childApplicationKey = childApplication.get(CreditBusinessConstants.APPLICATIONKEY) != null
				? childApplication.get(CreditBusinessConstants.APPLICATIONKEY).toString(): null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Fetching FPP PDF Report bean for child applicationId  :" + childApplicationKey);
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put("applicationKey",childApplicationKey);
				try {
					ResponseEntity<?> getFppPdfReportResponseBean = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
							getFppPdfReportResponseBeanUrl, Object.class, queryParam, null, headers);
					fppPdfReportResponseBean = mapper.convertValue(getFppPdfReportResponseBean.getBody(),FppPdfReportResponseBean.class);
				}catch (CreditBusinessException e) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while generating pdf" + e);
					throw e;
				} catch (Exception e) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while generating pdf" + e);
					throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception occured while generating pdf");
				}
			
		return new ResponseEntity<FppPdfReportResponseBean>(fppPdfReportResponseBean, HttpStatus.OK);
	   
   }
}
