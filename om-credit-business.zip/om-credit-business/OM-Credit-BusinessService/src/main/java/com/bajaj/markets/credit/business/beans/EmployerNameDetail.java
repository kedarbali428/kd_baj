package com.bajaj.markets.credit.business.beans;

public class EmployerNameDetail {

	private Long employerNameKey;

	private String employerNameCode;

	private String employerNameValue;

	public Long getEmployerNameKey() {
		return employerNameKey;
	}

	public void setEmployerNameKey(Long employerNameKey) {
		this.employerNameKey = employerNameKey;
	}

	public String getEmployerNameCode() {
		return employerNameCode;
	}

	public void setEmployerNameCode(String employerNameCode) {
		this.employerNameCode = employerNameCode;
	}

	public String getEmployerNameValue() {
		return employerNameValue;
	}

	public void setEmployerNameValue(String employerNameValue) {
		this.employerNameValue = employerNameValue;
	}

	@Override
	public String toString() {
		return "EmployerNameDetail [employerNameKey=" + employerNameKey + ", employerNameCode=" + employerNameCode
				+ ", employerNameValue=" + employerNameValue + "]";
	}

}
