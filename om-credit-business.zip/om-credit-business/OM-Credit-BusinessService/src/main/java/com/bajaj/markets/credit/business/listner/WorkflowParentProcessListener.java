package com.bajaj.markets.credit.business.listner;

import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.delegate.Expression;
import org.springframework.stereotype.Component;

@Component
public class WorkflowParentProcessListener implements ExecutionListener {

	private static final long serialVersionUID = 1L;
	Expression process;

	public void pre(DelegateExecution execution) {
		Map<String, Object> maps = execution.getVariables();
		execution.setVariable("var", maps);
	}

	@SuppressWarnings("unchecked")
	public void post(DelegateExecution execution) {
		Map<String, ? extends Object> maps = (Map<String, ? extends Object>) execution.getVariable("var");
		execution.setVariables(maps);
		execution.removeVariable("var");
	}

	@Override
	public void notify(DelegateExecution execution) {
		try {
			if (process == null || process.getValue(execution) == null) {
				post(execution);
			} else {
				pre(execution);
			}
		} finally {
			process = null;
		}
	}

}
