package com.bajaj.markets.credit.business.beans;

public class ProfileDetailsWrapper {

	private ProfileDetails payload;
	private NextTask nextTask;

	public ProfileDetailsWrapper(ProfileDetails payload, NextTask nextTask) {
		super();
		this.payload = payload;
		this.nextTask = nextTask;
	}

	public ProfileDetails getPayload() {
		return payload;
	}

	public void setPayload(ProfileDetails payload) {
		this.payload = payload;
	}

	public NextTask getNextTask() {
		return nextTask;
	}

	public void setNextTask(NextTask nextTask) {
		this.nextTask = nextTask;
	}

	@Override
	public String toString() {
		return "ProfileDetailsWrapper [payload=" + payload + ", nextTask=" + nextTask + "]";
	}

}
