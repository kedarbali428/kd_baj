package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.BUSINESS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PARENT_APPLICATION_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST_HEADERS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SALARIED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SKIP_API_EXCEPTION;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.OccupationReference;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
public class PaySenseListener {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallHelper;
	
	@Autowired
	private CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	private Environment env;
	
	private static final String OCCUPATION = "occupation";
	
	public static final String CLASS_NAME = PaySenseListener.class.getCanonicalName();

	public void preCheckEligibility(DelegateExecution execution) {
		execution.setVariable("principal", "PaySense");
		
		Map<String, String> checkEligibilityRequestHeaders = new HashMap<String, String>();
		
		checkEligibilityRequestHeaders.put("mobilenumber", execution.getVariable(MOBILE).toString());
		checkEligibilityRequestHeaders.put("applicationid", execution.getVariable(PARENT_APPLICATION_KEY).toString());
		
		execution.setVariable(REQUEST_HEADERS, checkEligibilityRequestHeaders);
	}
	
	public void postCheckEligibility(DelegateExecution execution) {
		Object partnerEligibilityResponseObj = execution.getVariable(OUTPUT);
		if(null != partnerEligibilityResponseObj) {
			JSONObject partnerEligibilityResponse = CreditBusinessHelper.getJSONObject(partnerEligibilityResponseObj);
			if(null != partnerEligibilityResponse.get("isCustomerEligible")) {
				execution.setVariable("partnerEligible", partnerEligibilityResponse.get("isCustomerEligible").toString());
				execution.setVariable("statementToBeCollected", 3);
			} else {
				execution.setVariable("partnerEligible", "not found");
			}
		} else {
			execution.setVariable("partnerEligible", "not found");
		}
	}
	
	public void preUpdateAverageBankBalance(DelegateExecution execution) {
		// additional details request payload
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		
		// occupation fetched response
		JSONObject occupation = CreditBusinessHelper.getJSONObject(execution.getVariable(OCCUPATION));
		JSONObject occupationType = CreditBusinessHelper.getJSONObject(occupation.get("ocupationType"));
		JSONObject salariedDetail = CreditBusinessHelper.getJSONObject(occupation.get("salariedDetail"));
		JSONObject businessOwnerDetail = CreditBusinessHelper.getJSONObject(occupation.get("businessOwnerDetails"));
		
		// get occupation code from master
		OccupationReference occupationReference = apiCallHelper.getOccupationMasterFromOccupationId(
				((Double) occupationType.get("key")).longValue());
		
		occupationType.put("key", occupationReference.getOccupationKey());
		
		// set payload to update occupation details
		JSONObject professionJson = new JSONObject();
		professionJson.put("ocupationType", occupationType);
		
		switch(occupationReference.getOccupationCode()) {
			case SALARIED:
				salariedDetail = new JSONObject();
				salariedDetail.put("averageBankBalance", null != request.get("averageBankBalance") 
						? ((Double) request.get("averageBankBalance")).intValue() : null);
				professionJson.put("salariedDetail", salariedDetail);
				break;
			case BUSINESS:
				businessOwnerDetail = new JSONObject();
				businessOwnerDetail.put("averageBankBalance", null != request.get("averageBankBalance") 
						? ((Double) request.get("averageBankBalance")).intValue() : null);
				professionJson.put("businessOwnerDetails", businessOwnerDetail);
				break;
			default:
				logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "No case found for l4ProductKey");
				break;
		}
		
		execution.setVariable(PAYLOAD, professionJson);
	}
	
	public void preBankDetail(DelegateExecution execution) {
		execution.setVariable(SKIP_API_EXCEPTION, true);
	}
	
	public void isBankDetailAvailable(DelegateExecution execution) {
		boolean isPerfiosBankDetailAvailable = false;
		Object apiCallException = execution.getVariable(CreditBusinessConstants.API_EXCEPTION_ARISE);
		if(null == apiCallException || !((boolean) apiCallException)) {
			ArrayList<?> bankDetails = (ArrayList<?>) execution.getVariable(OUTPUT);
			for (Object bankDetailObject : bankDetails) {
				JSONObject bankDetail = CreditBusinessHelper.getJSONObject(bankDetailObject);
				if(null != bankDetail.get("source") && "PERFIOS".equalsIgnoreCase(bankDetail.get("source").toString())) {
					Object bankAccountNumber = bankDetail.get("accoutNumber");
					Object branchKey = bankDetail.get("branchKey");
					Object bankMasterKey = bankDetail.get("bankMasterKey");
					boolean isNonNullBankData = null != bankAccountNumber && null != branchKey && null != bankMasterKey;
					if(isNonNullBankData &&
							!StringUtils.isEmpty(bankAccountNumber.toString()) && !StringUtils.isEmpty(branchKey.toString())
							&& !StringUtils.isEmpty(bankMasterKey.toString())) {
						isPerfiosBankDetailAvailable = true;
					}
				}
			}
		}
		execution.setVariable("isBankDataAvailable", isPerfiosBankDetailAvailable);
		
		// remove exception skip flags from execution once task gets completed
		List<String> variablesToRemoveFromExecution = new ArrayList<String>();
		variablesToRemoveFromExecution.add(SKIP_API_EXCEPTION);
		variablesToRemoveFromExecution.add(API_EXCEPTION_ARISE);
		
		execution.removeVariables(variablesToRemoveFromExecution);
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "isPerfiosBankDataAvailable: " + isPerfiosBankDetailAvailable);
	}

	@Async
	public void loanPlanDetails(DelegateExecution execution) {
		try {
			logger.info(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
					"Start  loanPlanDetails() method for application: "
							+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
			JSONObject pricingDetails = getPricingDetails(execution);
			if (Objects.nonNull(pricingDetails)) {
				callLoanPlanDetailsApi(execution, pricingDetails);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
						"Loan Plan Details api is not triggered for application: "
								+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY)
								+ " , as pricing details are not present");
			}
		} catch (Exception ex) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
					"Paysense loanPlanDeatils aync call failed for applicationId : "
							+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY),
					ex);
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End loanPlanDetails() method for application: "
				+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
	}

	private void callLoanPlanDetailsApi(DelegateExecution execution, JSONObject pricingDetails) {
		logger.info(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start  callLoanPlanDetailsApi() method for application: "
						+ execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		JSONObject loanPlanDetailsRequest = new JSONObject();
		loanPlanDetailsRequest.put("loanAmount", pricingDetails.get("finalLoanAmount"));
		loanPlanDetailsRequest.put("tenure", pricingDetails.get("tenureDropline"));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"Triggering Loan Plan Details api for application: "
						+ execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID) + " with request: "
						+ loanPlanDetailsRequest.toString());
		HttpHeaders headers = new HttpHeaders();
		headers.add("applicationid", (String) execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
		Map<String, String> params = new HashMap<String, String>();
		params.put("principalkey", "15");
		creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST,
				env.getProperty("api.omcreditcardsprincipalintegrationservice.principal.plandetails.POST.url"),
				String.class, params, loanPlanDetailsRequest.toString(), headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"Inside callLoanPlanDetailsApi() method : Plan Details api triggered  for application: "
						+ execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID) + " with request: "
						+ loanPlanDetailsRequest.toString());
		logger.info(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
					"End  callLoanPlanDetailsApi() method for application: "
							+ execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
	}

	private JSONObject getPricingDetails(DelegateExecution execution) {
		logger.info(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start getPricingDetails() method for application: "
						+ execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", (String) execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		JSONObject loanPricingResponse = apiCallHelper.callApi(
				env.getProperty("api.omcreditapplicationservice.vas.disbursementeventpricing.GET.url"), HttpMethod.GET,
				params, null, JSONObject.class);
		if (Objects.nonNull(loanPricingResponse) && (null == loanPricingResponse.get("finalLoanAmount")
				|| null == loanPricingResponse.get("tenureDropline"))) {
			logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
					"Pricing Details are not present for application: "
							+ execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
			throw new CreditBusinessException(HttpStatus.EXPECTATION_FAILED,
					"Pricing Details are not present for application: "
							+ execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		} else {
			logger.info(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
					"Pricing Details response for application: "
							+ execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID) + " response: "
							+ loanPricingResponse);
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End getPricingDetails() method for application: "
				+ execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		return loanPricingResponse;
	}

}
