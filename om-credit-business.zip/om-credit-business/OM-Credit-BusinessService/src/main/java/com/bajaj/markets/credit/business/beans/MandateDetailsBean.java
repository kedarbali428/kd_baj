package com.bajaj.markets.credit.business.beans;

import java.util.Date;

public class MandateDetailsBean {
	private String mandateavailable;
	private String mandatelimit;
	private Date mandateexpirydate;
	private String mandateaccountnumber;
	private String mandateifsc;
	private String mandatemicr;
	private String mandateregistrationnumber;
	private String mandatebalancelimit;
	private String mandatebankname;
	private String mandatetype;
	private String mandateid;
	
	public String getMandateavailable() {
		return mandateavailable;
	}
	public void setMandateavailable(String mandateavailable) {
		this.mandateavailable = mandateavailable;
	}
	public String getMandatelimit() {
		return mandatelimit;
	}
	public void setMandatelimit(String mandatelimit) {
		this.mandatelimit = mandatelimit;
	}
	public Date getMandateexpirydate() {
		return mandateexpirydate;
	}
	public void setMandateexpirydate(Date mandateexpirydate) {
		this.mandateexpirydate = mandateexpirydate;
	}
	public String getMandateaccountnumber() {
		return mandateaccountnumber;
	}
	public void setMandateaccountnumber(String mandateaccountnumber) {
		this.mandateaccountnumber = mandateaccountnumber;
	}
	public String getMandateifsc() {
		return mandateifsc;
	}
	public void setMandateifsc(String mandateifsc) {
		this.mandateifsc = mandateifsc;
	}
	public String getMandatemicr() {
		return mandatemicr;
	}
	public void setMandatemicr(String mandatemicr) {
		this.mandatemicr = mandatemicr;
	}
	public String getMandateregistrationnumber() {
		return mandateregistrationnumber;
	}
	public void setMandateregistrationnumber(String mandateregistrationnumber) {
		this.mandateregistrationnumber = mandateregistrationnumber;
	}
	public String getMandatebalancelimit() {
		return mandatebalancelimit;
	}
	public void setMandatebalancelimit(String mandatebalancelimit) {
		this.mandatebalancelimit = mandatebalancelimit;
	}
	public String getMandatebankname() {
		return mandatebankname;
	}
	public void setMandatebankname(String mandatebankname) {
		this.mandatebankname = mandatebankname;
	}
	public String getMandatetype() {
		return mandatetype;
	}
	public void setMandatetype(String mandatetype) {
		this.mandatetype = mandatetype;
	}
	public String getMandateid() {
		return mandateid;
	}
	public void setMandateid(String mandateid) {
		this.mandateid = mandateid;
	}
}