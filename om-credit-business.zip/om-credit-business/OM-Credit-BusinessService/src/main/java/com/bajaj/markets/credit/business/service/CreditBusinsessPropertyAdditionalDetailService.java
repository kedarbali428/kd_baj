package com.bajaj.markets.credit.business.service;

import javax.validation.Valid;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.AdditionalPageInfo;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.PropertyAdditionalDetails;

public interface CreditBusinsessPropertyAdditionalDetailService {
	
	public PropertyAdditionalDetails getPropertyAdditionalDetails(String applicationId);

	public ApplicationResponse postPropertyDetails(String applicationId,
			@Valid PropertyAdditionalDetails propertyAdditionalDetailsRequest, HttpHeaders headers);
	
	public AdditionalPageInfo getAdditionalPageInformation(String applicationId, HttpHeaders headers);
	
	public ApplicationResponse postAdditionalDetails(String applicationId, @Valid AdditionalPageInfo additionalPageInfo,
			HttpHeaders headers);

}
