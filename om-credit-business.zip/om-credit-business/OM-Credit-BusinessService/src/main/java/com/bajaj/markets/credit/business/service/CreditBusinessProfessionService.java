package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.CreditParameters;

public interface CreditBusinessProfessionService {

	ApplicationResponse saveProfessionalDet(CreditParameters creditParameters, String applicationId, HttpHeaders headers);

	CreditParameters getProfessionalDet(String applicationId);

}
