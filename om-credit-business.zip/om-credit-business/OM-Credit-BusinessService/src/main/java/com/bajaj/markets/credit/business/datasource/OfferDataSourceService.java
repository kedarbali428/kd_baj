package com.bajaj.markets.credit.business.datasource;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.helper.OMProductToBauProduct;

@Component
public class OfferDataSourceService {
			
	@Autowired
	private BFLLoggerUtilExt logger;
		
	@Value("#{${product.datasource.map}}")
	private Map<String, String> dataSourceCfgMap;
	
	@Autowired
	private Executor customExecutor;
	
	private DataSourceRegistry dataSourceRegistry = new DataSourceRegistry();
	
	private static final String CLASSNAME = OfferDataSourceService.class.getName();
	
	private static final String LOANAGAINSTPROPERTYBALTRANSFER = "LAPBT";
	private static final String HOMELOANBALANCETRANSFER = "HLBT";
	private static final String LOANAGAINSTPROPERTY = "LAP";
	private static final String HOMELOANFRESH = "HLF";
	
	@Autowired
	public OfferDataSourceService(ListableBeanFactory beanFactory) {
		Collection<DataSource> interfaces = beanFactory.getBeansOfType(DataSource.class).values();
		interfaces.forEach(dataSource -> {
			dataSource.registerDataSource(dataSourceRegistry);
		});
	}
	
	public List<OfferDetailsBean> processOfferData(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceService - processOfferData method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		
		//Executor customExecutor = (Executor)applicationContext.getBean("customExecutor");
		
		List<OfferDetailsBean> finalDataSources = new ArrayList<>();
		try {
			if(!StringUtils.isEmpty(applicantDataBean.getOfferApiRequest().getProductCode())){
				applicantDataBean.getOfferApiRequest().setProductCode(OMProductToBauProduct.getBauProd(applicantDataBean.getOfferApiRequest().getProductCode()));
				
				if(null != applicantDataBean.getHlProductIntent()) {
					switch(applicantDataBean.getHlProductIntent()) {
					case HOMELOANFRESH :
						applicantDataBean.getOfferApiRequest().setProductCode("DHL");
						break;
					case HOMELOANBALANCETRANSFER:
						applicantDataBean.getOfferApiRequest().setProductCode("DHB");
						break;
					case LOANAGAINSTPROPERTY:
						applicantDataBean.getOfferApiRequest().setProductCode("DLAP");
						break;
					case LOANAGAINSTPROPERTYBALTRANSFER:
						applicantDataBean.getOfferApiRequest().setProductCode("DLAPB");
						break;
					}
				}
			}
			
			List<DataSource> dataSourceImplementations = dataSourceRegistry.getDataSouces();
			List<DataSource> dataSources = getDataSources(dataSourceImplementations, applicantDataBean.getProductCode());
			
			List<CompletableFuture<Void>> dataSourcesFutures = dataSources
					.stream().map(
							dataSource -> CompletableFuture
									.supplyAsync(() -> dataSource.initDataSource(applicantDataBean), customExecutor)
									.exceptionally(e -> {
										logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceService - processOfferData method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - Error in fetching data from datasource "+ dataSource.getClass(), e);
										return null;
									}).thenAccept(offerDetailsBean -> {	
										finalDataSources.add(offerDetailsBean);
									}))
					.collect(Collectors.toList());
	
			CompletableFuture.allOf(dataSourcesFutures.toArray(new CompletableFuture[dataSourcesFutures.size()])).join();
			
			logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceService - processOfferData method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
			return finalDataSources;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceService - processOfferData method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - Exception occured in initDataSource call", e);
			return finalDataSources;
		}
	}
	
	private List<DataSource> getDataSources(List<DataSource> dataSourceImplementations, String productCode) {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceService - getDataSources method - started");

		List<String> dataSourcesNames = Stream.of(dataSourceCfgMap.get(productCode).split(","))
				.collect(Collectors.toList());
		
		List<DataSource> finalDataSources = new ArrayList<>();
		dataSourceImplementations.forEach(dataSource -> {
			String dataSourceName = dataSource.getClass().getSimpleName();
			if(dataSourcesNames.contains(dataSourceName)) {
				finalDataSources.add(dataSource);
			}
		});
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "inside OfferDataSourceService - getDataSources method - ended");
		return finalDataSources;
	}
}