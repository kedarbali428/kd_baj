package com.bajaj.markets.credit.business.beans;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MonthwiseInstallmentBean {

	private String month;
	@JsonProperty("principal")
	private String monthlyPrincipal;
	@JsonProperty("interest")
	private String monthlyInterest;
	@JsonProperty("total")
	private String monthlyTotal;
	private String emiDate;
	
	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}


	public String getEmiDate() {
		return emiDate;
	}

	public void setEmiDate(String emiDate) {
		this.emiDate = emiDate;
	}

	public String getMonthlyPrincipal() {
		return monthlyPrincipal;
	}

	public void setMonthlyPrincipal(String monthlyPrincipal) {
		this.monthlyPrincipal = monthlyPrincipal;
	}

	public String getMonthlyInterest() {
		return monthlyInterest;
	}

	public void setMonthlyInterest(String monthlyInterest) {
		this.monthlyInterest = monthlyInterest;
	}

	public String getMonthlyTotal() {
		return monthlyTotal;
	}

	public void setMonthlyTotal(String monthlyTotal) {
		this.monthlyTotal = monthlyTotal;
	}

	@Override
	public String toString() {
		return "MonthwiseInstallmentBean [month=" + month + ", monthlyPrincipal=" + monthlyPrincipal
				+ ", monthlyInterest=" + monthlyInterest + ", monthlyTotal=" + monthlyTotal + ", emiDate=" + emiDate
				+ "]";
	}



}
