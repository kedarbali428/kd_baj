package com.bajaj.markets.credit.business.controller;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ApplicationParameter;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.ProcessCard;
import com.bajaj.markets.credit.business.beans.ProcessStatus;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Business;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Salaried;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessPrincipleService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessPrincipleController {

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessPrincipleService CreditBusinessPrincipleService;
	
	@Autowired
	private Validator validator;
	
	private static final String CLASS_NAME = CreditBusinessPrincipleController.class.getCanonicalName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "Consent validation & details sent to partner for approval/rejection", notes = "Consent validation & details sent to partner for approval/rejection", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Details successsfully sent to partner for card processing.", response = ApplicationResponse.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(path = "/v1/credit/applications/{applicationid}/card/process", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationResponse> processCard(@PathVariable("applicationid") String applicationId,@Valid @RequestBody ProcessCard processCard, @RequestHeader HttpHeaders headers){
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start processCard :" + applicationId);
		Set<ConstraintViolation<ProcessCard>> validationErrors = validator.validate(processCard, null !=processCard.getAction() && !processCard.getAction().isBlank() ? Business.class : Salaried.class);
		if(!CollectionUtils.isEmpty(validationErrors)){
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside processCard method controller - resource validation failed");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,new ErrorBean("OMCB_25", validationErrors.stream().findFirst().get().getMessage()));
		}else {
			processCard.setApplicationid(applicationId);
			ApplicationResponse applicationResponse = CreditBusinessPrincipleService.processCard(processCard, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End processCard");
			return new ResponseEntity<>(applicationResponse, HttpStatus.CREATED);
		}
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "Decision to land on approval, rejection, Listing & other pages after processing child & parent app status", notes = "Decision to land on approval, rejection, Listing & other pages after processing child & parent app status", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Decision successsfully done", response = ApplicationResponse.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorize", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class)})
	@PostMapping(path = "/v1/credit/applications/{applicationid}/status", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationResponse> processStatus(@PathVariable("applicationid") String applicationId, @Valid @RequestBody ProcessStatus processStatus, BindingResult result,@RequestHeader HttpHeaders headers){
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Input processStatus, applicationId: " + applicationId + " processStatus: " + processStatus);
		ApplicationResponse applicationResponse;
		if(!StringUtils.isNumeric(applicationId) || result.hasFieldErrors()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside processStatus method controller - resource validation failed");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_20", "Invalid input"));	
		}else{
			processStatus.setApplicationid(applicationId);
			applicationResponse = CreditBusinessPrincipleService.processStatus(processStatus, headers);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Output processStatus, applicationResponse: " + applicationResponse);
		return new ResponseEntity<>(applicationResponse, HttpStatus.CREATED);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "Get application parameters like card limit, loan limit ,okyc link etc.", notes = "Get application parameters like card limit, loan limit ,okyc link etc.", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "application parameters fetched successfully", response = ApplicationParameter.class),
							@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class),
							@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
							@ApiResponse(code = 403, message = "Unauthorize", response = ErrorBean.class),
							@ApiResponse(code = 422, message = "Invalid Input", response = ErrorBean.class),
							@ApiResponse(code = 404, message = "Resource not found", response = ErrorBean.class)})
	@GetMapping(path = "/v1/credit/applications/{applicationid}/parameters", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<Object> fetchApprovedDetails(@PathVariable("applicationid") String applicationId,
			@RequestParam String l3ProductCode,@RequestHeader HttpHeaders headers){
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Input fetchApprovedDetails, applicationId: " + applicationId +" ,l3ProductCode: " + l3ProductCode);
		ApplicationParameter applicationParameter;
		if (StringUtils.isNumeric(applicationId) && !StringUtils.isBlank(l3ProductCode)) {
			applicationParameter = CreditBusinessPrincipleService.fetchApprovedDetails(applicationId, l3ProductCode);
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid applicationId or l3productcode.");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,new ErrorBean("OMCB_22", "Invalid input"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Output fetchApprovedDetails, applicationParameter: " + applicationParameter);
		return new ResponseEntity<>(applicationParameter, HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "Consent trigger & validation for demog details, disbursement", notes = "Consent trigger & validation for demog details, disbursement", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Consent trigger or validation done successfully.", response = ApplicationResponse.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(path = "/v1/credit/applications/{applicationid}/loan/process", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationResponse> processPartnerConsent(@PathVariable("applicationid") String applicationId,@Valid @RequestBody ProcessCard processCard, @RequestHeader HttpHeaders headers){
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Start processPartnerConsent , applicationId: " + applicationId);
		Set<ConstraintViolation<ProcessCard>> validationErrors = validator.validate(processCard, null !=processCard.getAction() && !processCard.getAction().isBlank() ? Business.class : Salaried.class);
		if(!CollectionUtils.isEmpty(validationErrors)){
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside processPartnerConsent method controller , applicationId: "+ applicationId + " - resource validation failed");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,new ErrorBean("OMCB_25", validationErrors.stream().findFirst().get().getMessage()));
		}else {
			processCard.setApplicationid(applicationId);
			ApplicationResponse applicationResponse = CreditBusinessPrincipleService.processCard(processCard, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End processPartnerConsent");
			return new ResponseEntity<>(applicationResponse, HttpStatus.CREATED);
		}
	}
}
