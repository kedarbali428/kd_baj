
package com.bajaj.markets.credit.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.data.redis.RedisIndexedSessionRepository;
import org.springframework.session.security.SpringSessionBackedSessionRegistry;

@Configuration
@ConditionalOnProperty(value = "spring.session.enabled", havingValue = "true", matchIfMissing = false)
public class SessionWebSecurityConfig {

	@Value("${spring.session.enabled:false}")
	private boolean sessionEnabled;

	@Autowired
	private RedisIndexedSessionRepository redisOperationsSessionRepository;

	@Bean
	// @ConditionalOnBean(RedisIndexedSessionRepository.class)
	public SpringSessionBackedSessionRegistry sessionRegistry() {
		return new SpringSessionBackedSessionRegistry<>(redisOperationsSessionRepository);
	}

}
