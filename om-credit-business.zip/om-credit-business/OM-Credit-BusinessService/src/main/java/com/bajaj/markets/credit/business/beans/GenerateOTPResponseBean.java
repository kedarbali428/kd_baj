package com.bajaj.markets.credit.business.beans;

public class GenerateOTPResponseBean { 

	private transient Object payload;

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}

	
	
	
}
