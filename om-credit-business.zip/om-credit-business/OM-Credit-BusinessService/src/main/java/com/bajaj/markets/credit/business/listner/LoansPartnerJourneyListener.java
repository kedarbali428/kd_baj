package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.RISKOFFERTYPE;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;

@Component
public class LoansPartnerJourneyListener {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessGinHelper etbGinHelper;

	private static final String CLASS_NAME = LoansPartnerJourneyListener.class.getCanonicalName();

	public void principleFlowNotExist(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "principle flow not exist for principleKey: " + execution.getVariable(CreditBusinessConstants.PRINCIPALKEY));
		execution.setVariable("action", "back");
	}
	
	public void setETBFlowFlagForBFLJourney(DelegateExecution execution) {
		Object riskOfferType = execution.getVariable(RISKOFFERTYPE);
		execution.setVariable(CreditBusinessConstants.IS_ETB_CUSTOMER, etbGinHelper.checkIsEtbOffer(null != riskOfferType ? riskOfferType.toString() : null));
	}
}
