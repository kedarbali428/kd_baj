package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICANTID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICANTKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_JSON;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE_COMMERCIAL;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DATE_OF_BIRTH;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMAIL;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMAILID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MCP_REQUEST_OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OCCUPATION_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OPEN_ARC_CARD_LISTING_OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OPEN_MARKET_LOAN_LISTING;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PARENT_APPLICATION_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PRINCIPALKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REJECTION_SYSTEM;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.TYPE_KEY;
import static com.bajaj.markets.credit.business.helper.RejectionSystemSourceEnum.LISTBREAPI;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.helper.ApplicationStatusEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.google.gson.Gson;

@Component
public class IncomeVerificationListener {

	private static final String IV_CHILD_STATUS_KEY = "iVchildStatusKey";

	private static final String IV_CHILD_STATUS_CODE = "iVchildStatusCode";
	

	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	McpCheck mcpCheck;
	
	@Value("${incomeverification.perfios.default.statementstobecollected:3}")
	private int defaultStmtToBeColleted;

	private static final String CLASS_NAME = IncomeVerificationListener.class.getCanonicalName();
	
	private static final String OCCUPATION_LIST = "occupationList";
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallHelper;

	public void isIncomeVerificationRequired(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside isIncomeVerificationRequired - start");

		JSONObject productListObject = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable("status", "");
		execution.setVariable("incomeVerificationRequired", false);
		if (null != productListObject) {
			ArrayList<?> productList = (ArrayList<?>) productListObject.get("productList");
			JSONObject product = CreditBusinessHelper.getJSONObject(productList.get(0));
			
			Object perfiosRequiredFlag = product.get("perfiosRequiredFlag");
			Object statementToBeCollected = product.get("statementToBeCollected");
			
			if (null != perfiosRequiredFlag)
				if("1".equals(perfiosRequiredFlag.toString())) {
					execution.setVariable("incomeVerificationRequired", true);
					if(null != statementToBeCollected) {
						execution.setVariable("statementToBeCollected", Double.valueOf(statementToBeCollected.toString()).intValue());
					} else {
						logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "statementToBeCollected is not stamped in application domain");
						execution.setVariable("statementToBeCollected", defaultStmtToBeColleted);
					}
				}
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside isIncomeVerificationRequired - end");
	}
	
	@SuppressWarnings("unchecked")
	public void preIVPostCall(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preIVPostCall - start");

		String parentApplicationKey = execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY).toString();

		JSONObject incomeVerificationPayload = new JSONObject();
		incomeVerificationPayload.put("channeltransactionKey", parentApplicationKey);
		incomeVerificationPayload.put("channel", "PERFIOS");
		incomeVerificationPayload.put("imputaionModel", "STATEMENT");
		incomeVerificationPayload.put("status", "CREATED");
		incomeVerificationPayload.put("salaryDetected", false);
		incomeVerificationPayload.put("applicationid", parentApplicationKey);
		incomeVerificationPayload.put("applicantid", execution.getVariable(APPLICANTID));
		incomeVerificationPayload.put("occupationType", execution.getVariable(OCCUPATION_TYPE));
		incomeVerificationPayload.put("dateOfBirth", execution.getVariable(DATE_OF_BIRTH));
		incomeVerificationPayload.put("emailId", execution.getVariable(EMAILID));
		incomeVerificationPayload.put("principalKey", execution.getVariable(PRINCIPALKEY));
		incomeVerificationPayload.put("statementToBeCollected", execution.getVariable("statementToBeCollected"));

		execution.setVariable(PAYLOAD, incomeVerificationPayload);

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preIVPostCall - end");
	}

	public void postFetchEstimation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preFetchEstimation - start");

		ArrayList<?> incomeEstimationList = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);

		JSONObject incomeEstimation = CreditBusinessHelper.getJSONObject(incomeEstimationList.get(0));
		JSONObject accountInformation = CreditBusinessHelper.getJSONObject(incomeEstimation.get("accountInformation"));

		execution.setVariable("incomeEstimation", incomeEstimation);

		execution.setVariable("incomeputationkey", incomeEstimation.get("incomemputationKey"));
		execution.setVariable("status", incomeEstimation.get("status"));

		execution.setVariable("skipBankUpdate", true);
		if(null != accountInformation) {
			if(null != accountInformation.get("accountNumber") && !StringUtils.isEmpty(accountInformation.get("accountNumber").toString())) {
				execution.setVariable("skipBankUpdate", false);
				execution.setVariable("PERFIOS_ACCOUNT_NUMBER", accountInformation.get("accountNumber"));
				execution.setVariable("ifscCode", accountInformation.get("ifscCode"));
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "perfios response not having proper accountInformation");
			}
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "perfios response not having accountInformation");
		}

		execution.setVariable("salaryDetected", false);
		
		Object salaryDetected = incomeEstimation.get("salaryDetected");
		if (null != salaryDetected) {
			if(true == (Boolean) salaryDetected) {
				execution.setVariable("salaryDetected", true);
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "salary detected is not true: " + salaryDetected);
			}
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "salary detected flag is null");
		}
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preFetchEstimation - end");
	}

	public void fetchChannelJson(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside fetchChannelJson - start");
		JSONObject channelResponseJson = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));

		execution.setVariable("perfiosJson", channelResponseJson.get("channelResponse"));

		execution.setVariable(CIBIL_TYPE, CIBIL_TYPE_COMMERCIAL);

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside fetchChannelJson - end");
	}

	public void postGetApplication(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postGetApplication - start");

		JSONObject application = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(APPLICANTID, application.get(APPLICANTKEY));

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postGetApplication - end");
	}

	public void postGetUserProfile(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postGetUserProfile - start");

		ArrayList<?> userProfiles = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);

		if (null != userProfiles) {
			for (Object object : userProfiles) {
				JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
				if (null != userProfile && userProfile.get(APPLICATION_USER_ATTRIBUTE_TYPE).equals("1")) {
					execution.setVariable(APPLICATION_USER_ATTRIBUTE_KEY,
							userProfile.get(APPLICATION_USER_ATTRIBUTE_KEY));
					execution.setVariable(MOBILE, userProfile.get(MOBILE));
					execution.setVariable(DATE_OF_BIRTH, userProfile.get(DATE_OF_BIRTH));
					// for next personal email fetch call
					execution.setVariable(TYPE_KEY, 70);
				}
			}
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postGetUserProfile - end");
	}

	public void postGetPersonalEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postGetPersonalEmail - start");

		JSONObject emailObject = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable("emailId", emailObject.get(EMAIL));

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postGetPersonalEmail - end");
	}

	public void postGetOccupationFromMaster(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postGetOccupationFromMaster - start");

		ArrayList<?> occupationsFromMaster = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);

		execution.setVariable(OCCUPATION_LIST, occupationsFromMaster);

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postGetOccupationFromMaster - end");
	}

	public void postGetOccupation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postGetOccupation - start");

		JSONObject occupationObject = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));

		JSONObject occupationType = CreditBusinessHelper.getJSONObject(occupationObject.get("ocupationType"));
		Object occupationKey = occupationType.get("key");
		Object occupationCode = null;

		ArrayList<?> occupationList = (ArrayList<?>) execution.getVariable(OCCUPATION_LIST);

		for (Object object : occupationList) {
			JSONObject occupationTypeFromMaster = CreditBusinessHelper.getJSONObject(object);
			if (occupationKey.equals(occupationTypeFromMaster.get("occupationKey"))) {
				occupationCode = occupationTypeFromMaster.get("occupationCode");
				break;
			}
		}

		execution.setVariable("occupationType", occupationCode);

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postGetOccupation - end");
	}

	public void postIVPostCall(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postIVPostCall - start");

		JSONObject incomeVerificationResponse = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable("status", incomeVerificationResponse.get("status"));

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postIVPostCall - end");
	}

	@SuppressWarnings("unchecked")
	public void preSalaryUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preSalaryUpdate - start");

		JSONObject incomeEstimation = CreditBusinessHelper.getJSONObject(execution.getVariable("incomeEstimation"));
		JSONObject estimatedIncome = CreditBusinessHelper.getJSONObject(incomeEstimation.get("estimatedIncome"));

		JSONObject salaryUpdateRequest = new JSONObject();
		JSONArray salarySources = new JSONArray();
		JSONObject salarySource = new JSONObject();

		salarySource.put("salarySource", estimatedIncome.get("source"));
		salarySource.put("salary", estimatedIncome.get("income"));

		salarySources.add(salarySource);

		salaryUpdateRequest.put("salarySources", salarySources);

		execution.setVariable(PAYLOAD, salaryUpdateRequest);

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preSalaryUpdate - end");
	}

	public void fetchMCPforBRERequest(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside fetchMCPforBRERequest - start");

		execution.setVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT,
				CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT)));

		JSONObject mcp = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		JSONObject prodCategory = CreditBusinessHelper.getJSONObject(mcp.get("prodCategory"));
		execution.setVariable(CreditBusinessConstants.PRODUCTDESC, prodCategory.get("prodCatDesc"));
		execution.setVariable(CreditBusinessConstants.PRODUCTCODE, prodCategory.get("prodCatCode"));

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside fetchMCPforBRERequest - end");
	}

	@SuppressWarnings("unchecked")
	public void preBRECall(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preBRECall - start");

		JSONObject mcpRequest = CreditBusinessHelper.getJSONObject(execution.getVariable(MCP_REQUEST_OUTPUT));
		JSONObject incomeEstimation = CreditBusinessHelper.getJSONObject(execution.getVariable("incomeEstimation"));

		JSONObject breRequest = new JSONObject();
		JSONObject openArcCardListingInput = new JSONObject();

		openArcCardListingInput.put("applicationId", execution.getVariable(PARENT_APPLICATION_KEY));
		openArcCardListingInput.put("eligibilityType", "IV");
		openArcCardListingInput.put("noOfMonthsPerfiosDone", null != incomeEstimation.get("statementCollected") 
				? Double.valueOf(incomeEstimation.get("statementCollected").toString()).intValue() : 0);

		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcCardListingInput, mcpRequest, false, null, null, null);

		ResidenceMaster residance = mcpCheck.getResidanceType(mcpRequest);

		if (null != residance) {
			openArcCardListingInput.put("resiType", residance.getResidenceValue());
		}

		mcpCheck.setOccupationValue(execution, CreditBusinessHelper.getJSONObject(mcpRequest.get("occupation")));
		if (null != execution.getVariable("occupationType")) {
			openArcCardListingInput.put("occupationType", execution.getVariable("occupationType").toString());
		}

		Object salaryDetected = incomeEstimation.get("salaryDetected");
		if (null != salaryDetected) {
			if (true == (Boolean) salaryDetected) {
				prepareBreRequestWithSalaryIdentified(openArcCardListingInput, incomeEstimation, mcpRequest);
			} else {
				prepareBreRequestWithSalaryUnidentified(openArcCardListingInput, incomeEstimation, mcpRequest);
			}
		} else {
			prepareBreRequestWithSalaryUnidentified(openArcCardListingInput, incomeEstimation, mcpRequest);
		}

		openArcCardListingInput.put("perfiosDateVarFlag", incomeEstimation.get("salaryDateVariation"));
		openArcCardListingInput.put("perfiosJason", execution.getVariable("perfiosJson"));

		openArcCardListingInput.put("cibilJson", execution.getVariable(CIBIL_JSON));
		openArcCardListingInput.put("cibilType", execution.getVariable("cibilType"));
		openArcCardListingInput.put("cibilScore", execution.getVariable("cibilScore"));
		
		Object derogJson = execution.getVariable(CreditBusinessConstants.DEROG_JSON);
		if (null != derogJson) {
			Gson gson = new Gson();
			String derogJsonStr = gson.toJson(derogJson);
			openArcCardListingInput.put(CreditBusinessConstants.DEROG_JSON, derogJsonStr);
		}

		breRequest.put("openArcCardListingInput", openArcCardListingInput);
		breRequest.put("additionalParameterDetail", mcpRequest.get("additionalParameterDetail"));
		
		execution.setVariable(REJECTION_SYSTEM, LISTBREAPI.getValue());
		execution.setVariable(PAYLOAD, breRequest);

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preBRECall - end");
	}

	@SuppressWarnings("unchecked")
	private void prepareBreRequestWithSalaryUnidentified(JSONObject openArcCardListingInput,
			JSONObject incomeEstimation, JSONObject mcpRequest) {

		openArcCardListingInput.put("perfiosIdentifiedSalaryFlag", false);

		ArrayList<?> salaryTransactions = (ArrayList<?>) incomeEstimation.get("salaryTransactions");

		JSONArray perfiosSalaryDetails = new JSONArray();

		for (Object object : salaryTransactions) {
			JSONObject salaryTranx = CreditBusinessHelper.getJSONObject(object);
			if ((boolean) salaryTranx.get("isUserSelectedSalaryTransaction")) {
				JSONObject perfiosSalaryDetail = new JSONObject();
				perfiosSalaryDetail.put("perfiosSalary", salaryTranx.get("tansactionAmount"));
				perfiosSalaryDetail.put("perfiosMonthDate", salaryTranx.get("transactionDateTime"));

				perfiosSalaryDetails.add(perfiosSalaryDetail);
			}
		}

		openArcCardListingInput.put("perfiosSalaryDetails", perfiosSalaryDetails);
	}

	@SuppressWarnings("unchecked")
	private void prepareBreRequestWithSalaryIdentified(JSONObject openArcCardListingInput, JSONObject incomeEstimation,
			JSONObject mcpRequest) {
		openArcCardListingInput.put("perfiosIdentifiedSalaryFlag", true);
		
		Object salaryTransactionsObj = incomeEstimation.get("salaryTransactions");

		if(null != salaryTransactionsObj) {
			JSONArray perfiosSalaryDetails = new JSONArray();
			ArrayList<Object> salaryTransactionList = (ArrayList<Object>) salaryTransactionsObj;
			
			for (Object object : salaryTransactionList) {
				JSONObject salaryTranx = CreditBusinessHelper.getJSONObject(object);
				
				JSONObject perfiosSalaryDetail = new JSONObject();
				perfiosSalaryDetail.put("perfiosSalary", salaryTranx.get("tansactionAmount"));
				perfiosSalaryDetail.put("perfiosMonthDate", salaryTranx.get("transactionDateTime"));
				
				perfiosSalaryDetails.add(perfiosSalaryDetail);
			}
			openArcCardListingInput.put("perfiosSalaryDetails", perfiosSalaryDetails);
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "salary transactions not available");
			openArcCardListingInput.put("perfiosSalaryDetails", null);
		}
	}

	public void postBRECall(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postBRECall - start");
		execution.setVariable("breEstimatedSalary", false);
		execution.setVariable("breResponseUpdateAvailable", false);
		execution.setVariable(IV_CHILD_STATUS_CODE, null);
		execution.setVariable(IV_CHILD_STATUS_KEY, null);
		execution.setVariable(CreditBusinessConstants.IS_SEGMENT_RERUN, false);
		JSONObject breOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		boolean eligiblePrincipleFound = false;
		if (breOutput != null && breOutput.get(OPEN_ARC_CARD_LISTING_OUTPUT) != null) {
			JSONObject openArcCardOutput = CreditBusinessHelper.getJSONObject(breOutput.get(OPEN_ARC_CARD_LISTING_OUTPUT));
			JSONObject openMarketLoanListing = CreditBusinessHelper.getJSONObject(openArcCardOutput.get(OPEN_MARKET_LOAN_LISTING));

			Object estimatedSalaries = openMarketLoanListing.get("estimatedNetMonthlySalaryDetails");
			if (null != estimatedSalaries && !CollectionUtils.isEmpty((ArrayList<?>) estimatedSalaries)) {
				execution.setVariable("estimatedSalaries", estimatedSalaries);
				execution.setVariable("breEstimatedSalary", true);
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "estimated salaries not available in BRE response");
			}

			Object principalProductDetails = openMarketLoanListing.get("principalProductDetails");
			if (null != principalProductDetails && !CollectionUtils.isEmpty((ArrayList<?>) principalProductDetails)) {
				boolean inprogressChildRejected = false;
				boolean isSegmentReRunFlag = false;
				execution.setVariable("breResponse", breOutput.toString());
				execution.setVariable("breResponseUpdateAvailable", true);

				List<Map<String, Object>> loanPrinciple = (List<Map<String, Object>>) principalProductDetails;
				if (!CollectionUtils.isEmpty(loanPrinciple)) {
					eligiblePrincipleFound = loanPrinciple.stream().anyMatch(p -> (boolean) p.get("isEligible"));
					for (Map<String, Object> principle : loanPrinciple) {
						if (principle.get("principalSelectedByCustomer") != null
								&& "Yes".equalsIgnoreCase(principle.get("principalSelectedByCustomer").toString())
								&& !((boolean) principle.get("isEligible"))) {
							inprogressChildRejected = true;
						}
					}
				}
				if(openMarketLoanListing.get("segmentReRunFlag")!=null && "true".equalsIgnoreCase(openMarketLoanListing.get("segmentReRunFlag").toString())) {
					isSegmentReRunFlag=true;
				}
				Long principalKey = Long.valueOf(execution.getVariable(CreditBusinessConstants.PRINCIPALKEY).toString());
				ApplicationStatusEnum childStatus = getChildStatus(!eligiblePrincipleFound, inprogressChildRejected, principalKey);
				logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Response from getChildStatus() - " + childStatus);
				execution.setVariable(IV_CHILD_STATUS_CODE, childStatus.getCode());
				execution.setVariable(IV_CHILD_STATUS_KEY, childStatus.getKey());
				execution.setVariable(CreditBusinessConstants.IS_SEGMENT_RERUN, isSegmentReRunFlag);
			} else {
				logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "no product details available in BRE reponse");
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postBRECall - end");
	}

	public void postIncomeVerificationComplete(DelegateExecution execution) {
		Object takeBackToListingPage = execution.getVariable("takeBackToListingPage");
		if (null == takeBackToListingPage) {
			execution.setVariable("takeBackToListingPage", false);
		}
	}
	
	public void postFetchBranchDetails(DelegateExecution execution) {
		Object branchDetailObj = execution.getVariable(OUTPUT);
		if(null != branchDetailObj) {
			ArrayList<?> branchDetails = (ArrayList<?>) branchDetailObj;
			JSONObject branchDetail = CreditBusinessHelper.getJSONObject(branchDetails.get(0));
			execution.setVariable("branchKey", ((Double) branchDetail.get("branchKey")).longValue());
			execution.setVariable("bankMasterKey", ((Double) branchDetail.get("bankMasterKey")).longValue());
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Branch details not available for ifscCode");
		}
	}
	
	public void postFetchBankReference(DelegateExecution execution) {
		ArrayList<?> bankDetails = (ArrayList<?>) execution.getVariable(OUTPUT);
		JSONObject bankDetail = CreditBusinessHelper.getJSONObject(bankDetails.get(0));
		execution.setVariable("bankMasterKey", ((Double) bankDetail.get("bankMasterKey")).longValue());
	}
	
	@SuppressWarnings("unchecked")
	public void preSaveBankDetails(DelegateExecution execution) {
		JSONObject bankDetailSaveRequest = new JSONObject();
		
		bankDetailSaveRequest.put("accoutNumber", execution.getVariable("PERFIOS_ACCOUNT_NUMBER"));
		bankDetailSaveRequest.put("beneficiaryType", null);
		bankDetailSaveRequest.put("branchKey", execution.getVariable("branchKey"));
		bankDetailSaveRequest.put("bankMasterKey", execution.getVariable("bankMasterKey"));
		bankDetailSaveRequest.put("holderName", null);
		bankDetailSaveRequest.put("source", "PERFIOS");
		bankDetailSaveRequest.put("userAttributeKey", execution.getVariable(APPLICATION_USER_ATTRIBUTE_KEY));
		
		execution.setVariable(PAYLOAD, bankDetailSaveRequest);
	}
	
	@SuppressWarnings("unchecked")
	public void preEstimatedSalaryUpdate(DelegateExecution execution) {

		ArrayList<?> estimatedSalaries = (ArrayList<?>) execution.getVariable("estimatedSalaries");
		
		JSONObject salaryUpdateRequest = new JSONObject();
		JSONArray salarySources = new JSONArray();

		for (Object estimatedSalary : estimatedSalaries) {
			JSONObject estimatedSalaryJson = CreditBusinessHelper.getJSONObject(estimatedSalary);
			JSONObject salarySource = new JSONObject();
			
			salarySource.put("salarySource", estimatedSalaryJson.get("salarySource"));
			salarySource.put("salary", estimatedSalaryJson.get("salaryAmount"));
			
			salarySources.add(salarySource);
		}

		salaryUpdateRequest.put("salarySources", salarySources);

		execution.setVariable(PAYLOAD, salaryUpdateRequest);
	}
	
	@SuppressWarnings("unchecked")
	public void preListingUpdate(DelegateExecution execution) {
		JSONObject breResponse = CreditBusinessHelper.getJSONObject(execution.getVariable("breResponse"));
		
		if (breResponse != null) {
			JSONObject listingOutput = CreditBusinessHelper.getJSONObject(breResponse.get(OPEN_ARC_CARD_LISTING_OUTPUT));
			listingOutput.put("openArcCardListing", null);
			breResponse.put(OPEN_ARC_CARD_LISTING_OUTPUT, listingOutput);
			execution.setVariable(CreditBusinessConstants.PAYLOAD, breResponse);
		} else {
			execution.setVariable(CreditBusinessConstants.PAYLOAD, null);
		}
	}
	
	public void preIVStatusUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preIVStatusUpdate - start");
		JSONObject payload = new JSONObject();
		payload.put("statusValue", execution.getVariable(IV_CHILD_STATUS_CODE));
		payload.put("statusKey", execution.getVariable(IV_CHILD_STATUS_KEY));
		execution.setVariable(PAYLOAD, payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preIVStatusUpdate - end");
	}
	
	public void preIVApplicationStatusUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preIVApplicationStatusUpdate - start");
		JSONObject payload = new JSONObject();
		payload.put("statusValue", ApplicationStatusEnum.APPROVAL.getCode());
		payload.put("statusKey", ApplicationStatusEnum.APPROVAL.getKey());
		execution.setVariable(PAYLOAD, payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside preIVApplicationStatusUpdate - end");
	}
	
	
	private ApplicationStatusEnum getChildStatus(boolean allProductRejected, boolean selectedProductRejected, Long principleKey) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside getChildStatus - start");
		if (allProductRejected || selectedProductRejected) {
			return ApplicationStatusEnum.REJECTED;
		} else {
			if (3 == principleKey) {
				return ApplicationStatusEnum.APPROVAL;
			} else {
				return ApplicationStatusEnum.INPROGRESS;
			}
		}
	}
	
	public void setStatementToBeCollected(DelegateExecution execution, int statementToBeCollected) {
		execution.setVariable("statementToBeCollected", statementToBeCollected);
	}
	
	public void getPersonalEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start getPersonalEmail");
		Email emailDetails = null;
		String applicationId= execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString();
		try {
			emailDetails = apiCallHelper.getEmail(applicationId, execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString(), EmailTypeEnum.PERON1.getValue().toString());
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception while fetching email for appId = " + applicationId, e);
		}
		if (null != emailDetails) {
			execution.setVariable("emailId", emailDetails.getEmail());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end getPersonalEmail");
	
	}
	
	public void postSalaryDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Inside postSalaryDetails - start");
		ArrayList<?> salariesDetails = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		execution.setVariable(CreditBusinessConstants.SALARY_DETAILS, salariesDetails);
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postSalaryDetails");
	}

}
