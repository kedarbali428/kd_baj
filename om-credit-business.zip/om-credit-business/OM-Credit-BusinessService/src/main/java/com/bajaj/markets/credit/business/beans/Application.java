package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.bajaj.markets.credit.business.beans.validator.DateConstraint;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.FreshApplication;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OfferCase;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Resume;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class Application implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1122361701102372417L;

	@NotNull(groups = FreshApplication.class, message = "mobile number can not be null")
	@Pattern(groups = FreshApplication.class, message = "mobile number is not valid", regexp = "^[6-9][0-9]{9}$")
	private String mobileNumber;

	@NotNull(groups = FreshApplication.class, message = "date of birth can not be null")
	@DateConstraint(groups = FreshApplication.class, format = "yyyy-MM-dd", message = "date of birth not valid")
	private String dateOfBirth;

	@NotNull(groups = {FreshApplication.class, OfferCase.class, Resume.class}, message = "productCode can not be null")
	private String productCode;
	
	@NotNull(groups = {FreshApplication.class, OfferCase.class, Resume.class}, message = "productKey can not be null")
	private Integer productKey;
	
	//@NotNull(groups = FreshApplication.class, message = "profession can not be null")
	private Reference profession;

	@Null(groups = OfferCase.class, message = "applicationKey must be null")
	@Digits(groups = Resume.class, fraction = 0, integer = 20, message = "applicationkey is not valid")
	private Long applicationKey;
	
	private Reference hlProductIntent;

	private String offerId;
	
	private boolean overrideCustomerSession;
	
	private boolean resume;
	
	private String name;
	
	@JsonIgnore(value = true)
	private Boolean fldgApplication;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Integer getProductKey() {
		return productKey;
	}

	public void setProductKey(Integer productKey) {
		this.productKey = productKey;
	}

	public Reference getProfession() {
		return profession;
	}

	public void setProfession(Reference profession) {
		this.profession = profession;
	}

	public Long getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(Long applicationKey) {
		this.applicationKey = applicationKey;
	}

    public Reference getHlProductIntent() {
		return hlProductIntent;
	}

	public void setHlProductIntent(Reference hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}
	
	public String getOfferId() {
		return offerId;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	
	public boolean isResume() {
		return resume;
	}

	public void setResume(boolean resume) {
		this.resume = resume;
	}

	@JsonIgnore
	public boolean isApplicationCreationPossible() {
		return StringUtils.isNotBlank(this.getMobileNumber()) && StringUtils.isNotBlank(this.getDateOfBirth()) && null != this.getProfession()
				&& null != this.getProfession().getKey();
	}

	
	public boolean isOverrideCustomerSession() {
		return overrideCustomerSession;
	}

	public void setOverrideCustomerSession(boolean overrideCustomerSession) {
		this.overrideCustomerSession = overrideCustomerSession;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Boolean getFldgApplication() {
		return fldgApplication;
	}

	public void setFldgApplication(Boolean fldgApplication) {
		this.fldgApplication = fldgApplication;
	}

	@Override
	public String toString() {
		return "Application [mobileNumber=" + mobileNumber + ", dateOfBirth=" + dateOfBirth + ", productCode="
				+ productCode + ", productKey=" + productKey + ", profession=" + profession + ", applicationKey="
				+ applicationKey + ", hlProductIntent=" + hlProductIntent + ", offerId=" + offerId
				+ ", overrideCustomerSession=" + overrideCustomerSession + ", resume=" + resume + ", name=" + name
				+ "]";
	}

}