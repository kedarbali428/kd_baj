package com.bajaj.markets.credit.business.beans;

public class UpdatePrincipalParam {
	private String applicationId;
	private String mobileNumber;
	private String utmSrc;
	private String consent;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getUtmSrc() {
		return utmSrc;
	}

	public void setUtmSrc(String utmSrc) {
		this.utmSrc = utmSrc;
	}

	public String getConsent() {
		return consent;
	}

	public void setConsent(String consent) {
		this.consent = consent;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	@Override
	public String toString() {
		return "UpdatePrincipalParam [applicationId=" + applicationId + ", mobileNumber=" + mobileNumber + ", utmSrc="
				+ utmSrc + ", consent=" + consent + "]";
	}

}
