package com.bajaj.markets.credit.business.processor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;

@Component
public class AddressProcessor implements BaseProcessor {

	@Autowired
	ApplictionClient applictionClient;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASSNAME = AddressProcessor.class.getName();
	
	private ThreadLocal<Boolean> addressUpdateFlag = new ThreadLocal<Boolean>();
	
	@Override
	public boolean initDataCopy(List<OfferDetailsBean> dataSources, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside AddressProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		addressUpdateFlag.set(false);
		try {
			dataSources.forEach(dataSource -> {
				if(!CollectionUtils.isEmpty(dataSource.getAddresses())){
					dataSource.getAddresses().forEach(address -> {
						addressUpdateFlag.set(applictionClient.saveAddress(address, applicantDataBean));
					});

					if(addressUpdateFlag.get()) {
						logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside AddressProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - address data processed for "+dataSource.getDataSourceName());
						throw new CreditBusinessException();
					} else {
						logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside AddressProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - address data not processed for "+dataSource.getDataSourceName());
					}
				}
			});
		} catch (CreditBusinessException exception) {
			return true;
		} catch(Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside AddressProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - address call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside AddressProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return false;
	}
}