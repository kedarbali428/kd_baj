package com.bajaj.markets.credit.business.beans;

public class PanValidationResponse {

	private String nameAsPerPan;
	private PanVerificationStatusEnum verificationStatus;

	public String getNameAsPerPan() {
		return nameAsPerPan;
	}

	public void setNameAsPerPan(String nameAsPerPan) {
		this.nameAsPerPan = nameAsPerPan;
	}

	public PanVerificationStatusEnum getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(PanVerificationStatusEnum verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

}
