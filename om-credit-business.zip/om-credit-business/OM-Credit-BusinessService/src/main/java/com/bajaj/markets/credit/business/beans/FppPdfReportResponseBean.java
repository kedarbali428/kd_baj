package com.bajaj.markets.credit.business.beans;

public class FppPdfReportResponseBean {

	private String reportUrl;

	public String getReportUrl() {
		return reportUrl;
	}

	public void setReportUrl(String reportUrl) {
		this.reportUrl = reportUrl;
	}

	@Override
	public String toString() {
		return "FppPdfReportResponseBean [reportUrl=" + reportUrl + "]";	
	}
	

}
