package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.ADD_SRC_APPLICANT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.ADD_SRC_OFFERAPI;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.ALLOW_CURRENT_ADDRESS_UPDATE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.BUSINESS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CITY_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DESIGNATION_REQUIRED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMPLOYER_REQUIRED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.IS_OFFICIALEMAIL_PRESENT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OCCUPATIONTYPECODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAN_NUMBER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SALARIED;
import static com.bajaj.markets.credit.business.helper.OccupationTypeEnum.DOCTOR_SALARIED;
import static com.bajaj.markets.credit.business.helper.OccupationTypeEnum.DOCTOR_SELF_EMPLOYED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.VERIFICATION;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NSDLNAMEMATCHFLAG;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AdditionalDetailLoans;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.CreditParameters;
import com.bajaj.markets.credit.business.beans.OccupationReference;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.OccupationTypeEnum;
import com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Component
public class UpdateProfile {
	
	private static final String OTHER = "OTHER";
	private static final String SAVE_BUSINESS_OWNER_DATA = "saveBusinessOwnerData";
	private static final String OCCUPATION_TYPE = "occupationType";
	private static final String OCCUPATION = "occupation";
	private static final String UPDATE_DOCTOR_DATA = "updateDoctorData";
	
	private static final String SALR_OCCUPATION = "SALR";
	private static final String SEMP_OCCUPATION = "SEMP";
	private static final String DOCSAL_OCCUPATION = "DOCSAL";
	private static final String DOCSEMP_OCCUPATION = "DOCSEMP";
	private static final String CA_OCCUPATION = "CAICWA";
	private static final String OTHER_OCCUPATION = "OTHER";
	
	private static final String NAME_TOBE_PRINTED_ON_CARD = "nameToBePrintedOnCard";
	private static final String OCCUPATIONTYPE = "ocupationType";
	private static final String SALARIED_DETAILS = "salariedDetail";
	private static final String DESIGNATION = "designation";
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallHelper;
	
	@Autowired
	MasterDataRedisClientHelper masterDataRedisClientHelper;

	private static final String CLASS_NAME = UpdateProfile.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void pre(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preUpdateProfile");
		JSONObject profileDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		execution.setVariable(CreditBusinessConstants.APPLICATION_ID, profileDetails.get(CreditBusinessConstants.APPLICATION_ID));
		JSONObject updateProfile = new JSONObject();
		
		String fullName = (String) profileDetails.get(CreditBusinessConstants.NAME);
		String nameArr[] = fullName.split("\\s+");
		JSONObject nameObj = new JSONObject();
		nameObj.put("firstName", nameArr[0]);
		nameObj.put("middleName", fullName.substring(fullName.indexOf(" "), fullName.lastIndexOf(" ")));
		nameObj.put("lastName", nameArr[nameArr.length - 1]);
		updateProfile.put(CreditBusinessConstants.NAME, nameObj);
		
		JSONObject resiType = CreditBusinessHelper.getJSONObject(profileDetails.get(CreditBusinessConstants.RESITYPE));
		updateProfile.put(CreditBusinessConstants.RESIDENCETYPEKEY, resiType.get(CreditBusinessConstants.KEY));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, updateProfile);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preUpdateProfile");
	}

	@SuppressWarnings("unchecked")
	public void addressUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start addressUpdate");
		JSONObject address = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject pinCode = CreditBusinessHelper.getJSONObject(address.get("residencePincode"));
		JSONObject city = CreditBusinessHelper.getJSONObject(pinCode.get("city"));
		JSONObject country = CreditBusinessHelper.getJSONObject(pinCode.get("country"));
		JSONObject state = CreditBusinessHelper.getJSONObject(pinCode.get("state"));
		
		Long pincodeKey = null!=execution.getVariable(CreditBusinessConstants.PINCODEKEY)?(long)Double.parseDouble(execution.getVariable(CreditBusinessConstants.PINCODEKEY).toString()):null;
		Long ff1PinCodeKey = (long)Double.parseDouble(pinCode.get("pincode").toString());
		
		String cityKey = String.format("%.0f", city.get("key"));
		//JSONObject resiType = CreditBusinessHelper.getJSONObject(address.get(CreditBusinessConstants.RESITYPE));
		JSONObject addressObject = new JSONObject();
		JSONObject verification = new JSONObject();
		addressObject.put("addressLine1", "");
		addressObject.put("addressLine2", "");
		if(pincodeKey!=null && pincodeKey.equals(ff1PinCodeKey)) {
			addressObject.put("addressLine1", execution.getVariable("addressLine1"));
			addressObject.put("addressLine2", execution.getVariable("addressLine2"));
		}
		addressObject.put("addressSource", "JOURNEY");
		addressObject.put("addressTypeKey", AddressTypeEnum.CURRENT.getValue());
		addressObject.put("cityKey", cityKey);
		addressObject.put("countryKey", (String.format("%.0f", country.get("key"))));
		addressObject.put("pincode", pinCode.get("pincode"));
		addressObject.put("pincodeKey", pinCode.get("pincode"));
		//addressObject.put("resiType", (String.format("%.0f", resiType.get("key"))));
		addressObject.put("stateKey", (String.format("%.0f", state.get("key"))));
		verification.put(CreditBusinessConstants.IS_VERIFIED, false);
		verification.put(CreditBusinessConstants.VERIFICATION_DATE, "");
		verification.put(CreditBusinessConstants.VERIFICATION_SOURCE, "");
		verification.put(CreditBusinessConstants.VERIFIEDFOR, "");
		addressObject.put("verification", verification);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, addressObject);
		execution.setVariable(CITY_KEY, cityKey);
		execution.setVariable("ffPincodeKey", pinCode.get("pincode"));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End addressUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void pincodeUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start pincodeUpdate");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject officePincode = CreditBusinessHelper.getJSONObject(request.get("officePinCode"));
		Long  pinCodeValue= Double.valueOf(officePincode.get("value").toString()).longValue();
		Long pinCodeKey = Double.valueOf(officePincode.get("key").toString()).longValue();
		LocationResponseBean address = masterDataRedisClientHelper.getPinCodeByKey(pinCodeKey);
		
		JSONObject addressObject = new JSONObject();
		JSONObject verification = new JSONObject();
		addressObject.put("addressLine1", "");
		addressObject.put("addressLine2", "");
		addressObject.put("addressSource", "JOURNEY");
		addressObject.put("addressTypeKey", AddressTypeEnum.OFFICE.getValue());
		addressObject.put("cityKey", address.getCityKey());
		addressObject.put("countryKey",address.getCountryKey());
		addressObject.put("stateKey", address.getStateKey());
		addressObject.put("pincode", pinCodeValue);
		addressObject.put("pincodeKey", pinCodeKey);

		verification.put(CreditBusinessConstants.IS_VERIFIED, false);
		verification.put(CreditBusinessConstants.VERIFICATION_DATE, "");
		verification.put(CreditBusinessConstants.VERIFICATION_SOURCE, "");
		verification.put(CreditBusinessConstants.VERIFIEDFOR, "");
		addressObject.put("verification", verification);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, addressObject);
		execution.setVariable(CITY_KEY, null);
		execution.setVariable("ffPincodeKey", null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End pincodeUpdate");
	}

	@SuppressWarnings("unchecked")
	public void occupationUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start occupationUpdate");
		JSONObject occupation = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject profession = CreditBusinessHelper.getJSONObject(occupation.get("profesion"));
		JSONObject professJsonObject = new JSONObject();
		professJsonObject.put("occupationTypeKey", profession.get("key"));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, professJsonObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End occupationUpdate");
	}

	@SuppressWarnings("unchecked")
	public void professionUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start professionUpdate");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject profession = CreditBusinessHelper.getJSONObject(request.get("profession"));
		JSONObject ocupationType = CreditBusinessHelper.getJSONObject(profession.get("ocupationType"));
		execution.setVariable(CreditBusinessConstants.IS_SALARIED, false);
		execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, false);
		execution.setVariable(CreditBusinessConstants.EMPLOYERID, null);
		JSONObject professionUpdatePayload = this.updateOccupationBasisOccupationCode(execution, profession, ocupationType.get("code").toString());
		professionUpdatePayload.put("ocupationType", ocupationType);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, professionUpdatePayload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End professionUpdate");
	}

	@SuppressWarnings("unchecked")
	public void preBasicDetail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preBasicDetail");
		JSONObject profileDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		execution.setVariable(CreditBusinessConstants.APPLICATION_ID, profileDetails.get(CreditBusinessConstants.APPLICATION_ID));
		JSONObject updateProfile = new JSONObject();

		JSONObject gender = CreditBusinessHelper.getJSONObject(profileDetails.get(CreditBusinessConstants.GENDER));
		JSONObject maritailStatus = CreditBusinessHelper.getJSONObject(profileDetails.get(CreditBusinessConstants.MARITALSTATUS));
		updateProfile.put(CreditBusinessConstants.GENDERKEY, gender.get(CreditBusinessConstants.KEY));
		updateProfile.put(CreditBusinessConstants.MARITALSTATUSKEY, maritailStatus.get(CreditBusinessConstants.KEY));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, updateProfile);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBasicDetail");
	}

	@SuppressWarnings("unchecked")
	public void prePersonalEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start prePersonalEmail");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (request.get(CreditBusinessConstants.APPLICATION_ID) != null) {
			execution.setVariable(CreditBusinessConstants.APPLICATION_ID, request.get(CreditBusinessConstants.APPLICATION_ID));
		}
		JSONObject updateProfile = new JSONObject();
		String personalEmail = request.get(CreditBusinessConstants.PERSONALEMAILID) != null
				? (String) request.get(CreditBusinessConstants.PERSONALEMAILID)
				: null;
		updateProfile.put("email", personalEmail);
		updateProfile.put("typeKey", EmailTypeEnum.PERON1.getValue());
		
		execution.setVariable(CreditBusinessConstants.PERSONALEMAILID, personalEmail);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, updateProfile);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End prePersonalEmail");
	}

	@SuppressWarnings("unchecked")
	public void personalPanVerifyPre(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start personalPanPre");
		JSONObject profile = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject profileDet = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.NAME));
		String firstName = (String)profileDet.get("firstName");
		String middleName = null != profileDet.get("middleName") ? (String)profileDet.get("middleName") : null;
		String lastName = (String)profileDet.get("lastName");
		String fullName = "";
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "firstName = "+firstName+"--- middleName = "+middleName+" --- lastName = "+lastName);
		if(null != middleName) {
			fullName = firstName + " " + middleName + " " + lastName;
		} else {
			fullName = firstName + " " + lastName;
		}
		String pan = profile.get(CreditBusinessConstants.PAN) != null ? profile.get(CreditBusinessConstants.PAN).toString() : null;
		JSONObject panUpdatePayload = new JSONObject();
		panUpdatePayload.put("panNumber", pan);
		panUpdatePayload.put("applicationKey", profile.get("applicationid"));
		panUpdatePayload.put("applicantKey", execution.getVariable(CreditBusinessConstants.APPLICANTID));
		panUpdatePayload.put("fullName", fullName);
		panUpdatePayload.put("l2ProductKey", execution.getVariable(CreditBusinessConstants.L2_PRODUCT_KEY));
		panUpdatePayload.put("l2ProductCode", execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, panUpdatePayload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End personalPanPre");
	}

	public void personalPanVerifyPost(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start personalPanVerifyPost");
		JSONObject panResp = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.NSDLPANRESPONSE_VERIFY, panResp);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End personalPanVerifyPost");
	}
	
	public void postGetPanVerify(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postGetPanVerify");
		JSONObject panResp = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (null != panResp) {
			execution.setVariable(NSDLNAMEMATCHFLAG, panResp.get("nameMatch"));
		}
		execution.setVariable(CreditBusinessConstants.NSDLPANRESPONSE, panResp);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetPanVerify");
	}

	@SuppressWarnings("unchecked")
	public void prePeronalPanUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start prePeronalPanUpdate");
		JSONObject document = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		String pan = (String) document.get(CreditBusinessConstants.PAN);
		JSONObject documentUpdate = new JSONObject();

		documentUpdate.put(CreditBusinessConstants.DOCUMENT_NAME_KEY, 1);
		documentUpdate.put(CreditBusinessConstants.DOCUMENT_NUMBER, pan);
		
		execution.setVariable(PAN_NUMBER, pan);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, documentUpdate);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End prePeronalPanUpdate");
	}

	@SuppressWarnings("unchecked")
	public void preWorkEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preWorkEmail");
		JSONObject additionalDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject updateProfile = new JSONObject();
		String email = additionalDetails.get(CreditBusinessConstants.WORKEMAILID) != null ? (String) additionalDetails.get(CreditBusinessConstants.WORKEMAILID)
				: null;
		updateProfile.put("email", email);
		updateProfile.put("typeKey", EmailTypeEnum.OFFICE.getValue());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, updateProfile);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preWorkEmail");
	}

	@SuppressWarnings("unchecked")
	public void preBusinessOwnerBasicDetail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preBusinessOwnerBasicDetail");
		JSONObject profileDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject businessOwnerDetails = new JSONObject();
		businessOwnerDetails.put("businessPan", (String) profileDetails.get("businessPan"));
		businessOwnerDetails.put("gstNumber", (String) profileDetails.get("gstNumber"));

		JSONObject professJsonObject = new JSONObject();
		professJsonObject.put("ocupationType", execution.getVariable(OCCUPATION_TYPE));
		professJsonObject.put("businessOwnerDetails", businessOwnerDetails);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, professJsonObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBusinessOwnerBasicDetail");
	}
	
	@SuppressWarnings("unchecked")
	public void preDoctorOccupationBasicDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preBusinessOwnerBasicDetail");
		JSONObject profileDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		String occupationTypeCode = execution.getVariable(OCCUPATIONTYPECODE).toString();
		JSONObject dataToBeUpdated = new JSONObject();
		dataToBeUpdated.put("regCouncil", profileDetails.get("regCouncil"));
		dataToBeUpdated.put("doctorRegistrationNumber", profileDetails.get("doctorRegistrationNumber"));
		dataToBeUpdated.put("hospital", profileDetails.get("hospital"));
		dataToBeUpdated.put("hospitalNameOther", profileDetails.get("hospitalNameOther"));

		JSONObject professJsonObject = new JSONObject();
		professJsonObject.put("ocupationType", execution.getVariable(OCCUPATION_TYPE));
		if (DOCTOR_SALARIED.getValue().equalsIgnoreCase(occupationTypeCode)) {
			professJsonObject.put("salariedDetail", dataToBeUpdated);
		} else if (DOCTOR_SELF_EMPLOYED.getValue().equalsIgnoreCase(occupationTypeCode)) {
			professJsonObject.put("businessOwnerDetails", dataToBeUpdated);
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, professJsonObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBusinessOwnerBasicDetail");
	}

	@SuppressWarnings("unchecked")
	public void preCurrentAddressUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCurrentAddressUpdate");
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		List<Address> addressDetails = (List<Address>) additionalDetail.get("addressDetails");
		if (null != addressDetails && !addressDetails.isEmpty()) {
			execution.setVariable(CreditBusinessConstants.PAYLOAD, CreditBusinessHelper.getJSONObject(addressDetails.get(0)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCurrentAddressUpdate");
	}

	@SuppressWarnings("unchecked")
	public void preWorkAddressUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCurrentAddressUpdate");
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		List<Address> addressDetails = (List<Address>) additionalDetail.get("addressDetails");
		if (null != addressDetails && !addressDetails.isEmpty()) {
			execution.setVariable(CreditBusinessConstants.PAYLOAD, CreditBusinessHelper.getJSONObject(addressDetails.get(1)));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCurrentAddressUpdate");
	}

	@SuppressWarnings("unchecked")
	public void preDeliveryAddressUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCurrentAddressUpdate");
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		List<Address> addressDetails = (List<Address>) additionalDetail.get("addressDetails");
		Boolean deliveryAddressFlag = (Boolean) additionalDetail.get("deliveryAddressFlag");
		Gson g = new Gson();
		for (int i = 0; i < addressDetails.size(); i++) {
			String json = g.toJson(addressDetails.get(i));
			Address address = g.fromJson(json, Address.class);
			if ("50".equalsIgnoreCase(address.getAddressTypeKey()) && deliveryAddressFlag) {
				address.setAddressTypeKey("56");
				execution.setVariable(CreditBusinessConstants.PAYLOAD, CreditBusinessHelper.getJSONObject(address));
			} else if ("46".equalsIgnoreCase(address.getAddressTypeKey()) && !deliveryAddressFlag) {
				address.setAddressTypeKey("56");
				execution.setVariable(CreditBusinessConstants.PAYLOAD, CreditBusinessHelper.getJSONObject(address));
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCurrentAddressUpdate");
	}

	@SuppressWarnings("unchecked")
	public void preUpdateAdditionalProfileDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preUpdateAdditionalProfileDetails");
		JSONObject userDetail = new JSONObject();
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		execution.setVariable("updateProfileFlag", Boolean.FALSE);
		execution.setVariable("deliveryAddressUpdateFlag", Boolean.TRUE);
		execution.setVariable("workAddressUpdateFlag", Boolean.TRUE);
		execution.setVariable("otherAddressUpdateFlag", Boolean.FALSE);
		execution.setVariable("alternateMobileNumberFlag", Boolean.FALSE);
		execution.setVariable("officialemailFlag", Boolean.FALSE);
		if (null != additionalDetail) {
			JSONObject qualification = CreditBusinessHelper.getJSONObject(additionalDetail.get("qualification"));
			if(null != qualification && null != qualification.get(CreditBusinessConstants.CODE)){
				userDetail.put("qualification", qualification.get(CreditBusinessConstants.CODE).toString());
				execution.setVariable("updateProfileFlag", Boolean.TRUE);
			}
			if(null != additionalDetail.get("motherName")){
				userDetail.put("motherName",additionalDetail.get("motherName").toString());
				execution.setVariable("updateProfileFlag", Boolean.TRUE);
			}
			if(null != additionalDetail.get("fatherName")){
				userDetail.put("fatherName",additionalDetail.get("fatherName").toString());
				execution.setVariable("updateProfileFlag", Boolean.TRUE);
			}
			if(additionalDetail.get("deliveryAddressFlag")==null){
				execution.setVariable("deliveryAddressUpdateFlag", Boolean.FALSE);
			}
			List<Address> addressDetails = null != additionalDetail.get("addressDetails") ? (List<Address>) additionalDetail.get("addressDetails") : null;
			if(null != addressDetails && !addressDetails.isEmpty() && !(addressDetails.size()>1)){
				execution.setVariable("workAddressUpdateFlag", Boolean.FALSE);
			}
			if(null != additionalDetail.get("otherAddressDetails")){
				execution.setVariable("otherAddressUpdateFlag", Boolean.TRUE);
			}
			if(null != additionalDetail.get("alternateMobileNumber")){
				execution.setVariable("alternateMobileNumberFlag", Boolean.TRUE);
			}
			if(null != additionalDetail.get("workEmailId") && !org.apache.commons.lang3.StringUtils.isBlank(String.valueOf(additionalDetail.get("workEmailId")))){
				execution.setVariable("officialemailFlag", Boolean.TRUE);
			}
			if(null != additionalDetail.get(NAME_TOBE_PRINTED_ON_CARD) && !String.valueOf(additionalDetail.get(NAME_TOBE_PRINTED_ON_CARD)).isBlank()) {
				userDetail.put(NAME_TOBE_PRINTED_ON_CARD, additionalDetail.get(NAME_TOBE_PRINTED_ON_CARD).toString().trim());
				execution.setVariable("updateProfileFlag", Boolean.TRUE);
			}
			JSONObject gender = CreditBusinessHelper.getJSONObject(additionalDetail.get("gender"));
			if(null != gender && null != gender.get(CreditBusinessConstants.KEY)) {
				userDetail.put("genderKey",((Double) gender.get(CreditBusinessConstants.KEY)).longValue());
				execution.setVariable("updateProfileFlag", Boolean.TRUE);
			}
			JSONObject residenceType = CreditBusinessHelper.getJSONObject(additionalDetail.get("residenceType"));
			if(null != residenceType && null != residenceType.get(CreditBusinessConstants.KEY)) {
				userDetail.put("residenceTypeKey", ((Double) residenceType.get(CreditBusinessConstants.KEY)).longValue());
				execution.setVariable("updateProfileFlag", Boolean.TRUE);
			}
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, userDetail);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preUpdateAdditionalProfileDetails");
	}
	
	public void preOtherAddressUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preOtherAddressUpdate");
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (null != additionalDetail.get("otherAddressDetails")) {
			execution.setVariable(CreditBusinessConstants.PAYLOAD, CreditBusinessHelper.getJSONObject(additionalDetail.get("otherAddressDetails")));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preOtherAddressUpdate");
	}

	@SuppressWarnings("unchecked")
	public void preLoansAdditionalDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preUpdateAdditionalProfileDetails");
		JSONObject userDetail = new JSONObject();
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (null != additionalDetail) {
			userDetail.put("motherName", null != additionalDetail.get("motherName") ? additionalDetail.get("motherName").toString() : null);
			userDetail.put("fatherName", null != additionalDetail.get("fatherName") ? additionalDetail.get("fatherName").toString() : null);
			JSONObject qualification = CreditBusinessHelper.getJSONObject(additionalDetail.get("qualification"));
			JSONObject gender = CreditBusinessHelper.getJSONObject(additionalDetail.get("gender"));
			JSONObject residenceType = CreditBusinessHelper.getJSONObject(additionalDetail.get("residenceType"));
			if(null != qualification && null != qualification.get(CreditBusinessConstants.CODE)){
				userDetail.put("qualification", qualification.get(CreditBusinessConstants.CODE).toString());
			}
			if(null != gender && null != gender.get(CreditBusinessConstants.KEY)) {
				userDetail.put("genderKey", ((Double) gender.get(CreditBusinessConstants.KEY)).longValue());
			}
			if(null != residenceType && null != residenceType.get(CreditBusinessConstants.KEY)) {
				userDetail.put("residenceTypeKey", ((Double) residenceType.get(CreditBusinessConstants.KEY)).longValue());
			}
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, userDetail);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preUpdateAdditionalProfileDetails");
	}

	public void preLoansCurrentAddress(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preLoansCurrentAddress");
		setAddress(execution, AddressTypeEnum.CURRENT.getValue());
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preLoansCurrentAddress");
	}

	public void preLoansOfficeAddress(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preLoansOfficeAddress");
		setAddress(execution, AddressTypeEnum.OFFICE.getValue());
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preLoansOfficeAddress");
	}

	public void preLoansPermanentAddress(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preLoansPermanentAddress");
		setAddress(execution, AddressTypeEnum.PERMANENT.getValue());
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preLoansPermanentAddress");
	}

	private void setAddress(DelegateExecution execution, String addressType) {
		String additionalDetailString = CreditBusinessHelper.objectToJson(execution.getVariable(CreditBusinessConstants.REQUEST));
		Gson g = new Gson();
		if (additionalDetailString != null) {
			AdditionalDetailLoans additionalDetails = g.fromJson(additionalDetailString, AdditionalDetailLoans.class);
			if (additionalDetails != null && !CollectionUtils.isEmpty(additionalDetails.getAddressDetails())) {
				for (Address address : additionalDetails.getAddressDetails()) {
					if (addressType.equalsIgnoreCase(address.getAddressTypeKey())) {
						execution.setVariable(CreditBusinessConstants.PAYLOAD, CreditBusinessHelper.getJSONObject(address));
						break;
					} else {
						execution.setVariable(CreditBusinessConstants.PAYLOAD, null);
					}
				}
			}
		}
	}

	public void postGetOccupationBasicDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetOccupationBasicDetails");
		execution.setVariable(CreditBusinessConstants.EMPLOYERID, null);
		execution.setVariable(CreditBusinessConstants.IS_SALARIED, false);
		execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, false);
		execution.setVariable(OCCUPATION_TYPE, null);
		execution.setVariable(SAVE_BUSINESS_OWNER_DATA, false);
		execution.setVariable(IS_OFFICIALEMAIL_PRESENT, false);
		execution.setVariable(UPDATE_DOCTOR_DATA, false);
		
		JSONObject profession = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		JSONObject ocupationType = CreditBusinessHelper.getJSONObject(profession.get("ocupationType"));
		JSONObject salariedDetail = CreditBusinessHelper.getJSONObject(profession.get("salariedDetail"));
		String occupationTypeCode = ocupationType.get("code").toString();
		execution.setVariable(OCCUPATIONTYPECODE, occupationTypeCode);
		if (OccupationTypeEnum.SALARIED.getValue().equalsIgnoreCase(occupationTypeCode)) {
			execution.setVariable(CreditBusinessConstants.IS_SALARIED, true);
			if (salariedDetail != null && salariedDetail.get("employerName") != null) {
				JSONObject employerName = CreditBusinessHelper.getJSONObject(salariedDetail.get("employerName"));
				if(employerName != null && employerName.get("key") != null) {
					execution.setVariable(CreditBusinessConstants.EMPLOYERID, new BigDecimal(employerName.get("key").toString()).intValue());
				}else if(salariedDetail.get("employerNameOther") != null){ 
					execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, true);
				}
				
			}
			setOfficialEmailPresentFlag(execution, salariedDetail);
		} else {
			execution.setVariable(CreditBusinessConstants.IS_SALARIED, false);
		}
		execution.setVariable(OCCUPATION_TYPE, ocupationType);

		JSONObject profileDetails = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (profileDetails != null) {
			if (OccupationTypeEnum.BUSINESS.getValue().equalsIgnoreCase(occupationTypeCode) && 
					(!StringUtils.isEmpty(profileDetails.get("businessPan")) || !StringUtils.isEmpty(profileDetails.get("gstNumber")))) {
				execution.setVariable(SAVE_BUSINESS_OWNER_DATA, true);
			} else if (DOCTOR_SALARIED.getValue().equalsIgnoreCase(occupationTypeCode) 
					|| DOCTOR_SELF_EMPLOYED.getValue().equalsIgnoreCase(occupationTypeCode)) {
				if (null != profileDetails.get("regCouncil") || !StringUtils.isEmpty(profileDetails.get("doctorRegistrationNumber"))
						|| null != profileDetails.get("hospital") && !StringUtils.isEmpty(profileDetails.get("hospitalNameOther"))) {
					execution.setVariable(UPDATE_DOCTOR_DATA, true);
			}
		}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetProfession");
	}

	@SuppressWarnings("unchecked")
	public void preUpdateAdditionalProfessionDet(DelegateExecution execution) {
		// additional details request payload
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		
		// occupation fetched response
		JSONObject occupation = CreditBusinessHelper.getJSONObject(execution.getVariable(OCCUPATION));
		JSONObject occupationType = CreditBusinessHelper.getJSONObject(occupation.get("ocupationType"));
		JSONObject salariedDetail = CreditBusinessHelper.getJSONObject(occupation.get("salariedDetail"));
		JSONObject businessOwnerDetail = CreditBusinessHelper.getJSONObject(occupation.get("businessOwnerDetails"));
		
		// get occupation code from master
		OccupationReference occupationReference = apiCallHelper.getOccupationMasterFromOccupationId(
				((Double) occupationType.get("key")).longValue());
		
		occupationType.put("key", occupationReference.getOccupationKey());
		
		// set payload to update occupation details
		JSONObject professionJson = new JSONObject();
		professionJson.put("ocupationType", occupationType);

		switch (occupationReference.getOccupationCode()) {
			case SALARIED:
			if (salariedDetail == null) {
				salariedDetail = new JSONObject();
			}
			if (request.get("currentWorkExperience") != null) {
				salariedDetail.put("workExperienceInMonths",
						null != request.get("currentWorkExperience") ? ((Double) request.get("currentWorkExperience")).intValue() : null);
			}
			
			if (request.get("experience") != null) {
				salariedDetail.put("experience",
						null != request.get("experience") ? request.get("experience") : null);
			}
			
			if (request.get("designation") != null ) {
				salariedDetail.put("designation", null != request.get("designation") ? request.get("designation") : null);
			}
			
			if (execution.getVariable(EMPLOYER_REQUIRED) != null && (boolean) execution.getVariable(EMPLOYER_REQUIRED)) {
				salariedDetail.put("employerName", null != request.get("employerName") ? request.get("employerName") : null);
			}
				salariedDetail.put("averageBankBalance", null != request.get("averageBankBalance") 
						? ((Double) request.get("averageBankBalance")).intValue() : null);
				salariedDetail.put("employerType", null != request.get("employerType") 
						? ((Double) request.get("employerType")).intValue() : null);
				salariedDetail.put("subEmployerType", null != request.get("subEmployerType") 
						? ((Double) request.get("subEmployerType")).intValue() : null);
				professionJson.put("salariedDetail", salariedDetail);
				break;
			case BUSINESS:
				if (businessOwnerDetail == null) {
				businessOwnerDetail = new JSONObject();
				}
				if(request.get("presentBusinessVintage") != null) {
				businessOwnerDetail.put("presentBusinessVintage", null != request.get("presentBusinessVintage") 
						? ((Double) request.get("presentBusinessVintage")).intValue() : null);
				}
				
				businessOwnerDetail.put("averageBankBalance", null != request.get("averageBankBalance") 
						? ((Double) request.get("averageBankBalance")).intValue() : null);
				
				businessOwnerDetail.put("shopStatus", request.get("shopStatus"));
				businessOwnerDetail.put("corporateLinkageType", request.get("corporateLinkageType"));
				professionJson.put("businessOwnerDetails", businessOwnerDetail);
				break;
			default:
				logger.error(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "No case found for l4ProductKey");
				break;
		}
		execution.setVariable(OCCUPATION_TYPE,occupationReference.getOccupationCode());
		execution.setVariable(PAYLOAD, professionJson);
	}
	
	public void postGetOccupation(DelegateExecution execution) {
		execution.setVariable(OCCUPATION, execution.getVariable(OUTPUT));
	}
	
	@SuppressWarnings("unchecked")
	public void salaryUpdate(DelegateExecution execution, String salarySource) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start salaryUpdate");
	    JSONObject salaryUpdate = new JSONObject();
	    JSONObject salarySourcesJson = new JSONObject();
	    JSONObject salarySourcesJsonEstIncome = new JSONObject();
		List<JSONObject> salarySources = new ArrayList<JSONObject>();
		salarySourcesJson.put("salarySource",salarySource);
		String salary = execution.getVariable(CreditBusinessConstants.SALARY).toString();
		salarySourcesJson.put("salary",Integer.valueOf(salary) );
		
		if (salarySource.equals(CreditBusinessConstants.IMPUTEDINCOME)) {
			salarySourcesJsonEstIncome.put("salarySource",CreditBusinessConstants.FINAL_INCOME);
			if (null != execution.getVariable(CreditBusinessConstants.FINAL_INCOME)) {
				salary = execution.getVariable(CreditBusinessConstants.FINAL_INCOME).toString();

				salarySourcesJsonEstIncome.put("salary", Integer.valueOf(salary));
			}
		}
		salarySources.add(salarySourcesJson);
		salarySources.add(salarySourcesJsonEstIncome);
		salaryUpdate.put("salarySources", salarySources);
		execution.setVariable(CreditBusinessConstants.PAYLOAD,salaryUpdate);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End salaryUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void preUpdateCoAppforSecured(DelegateExecution execution) {
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject userProfile = new JSONObject();
		userProfile.put(CreditBusinessConstants.APPLICATIONKEY, request.get(CreditBusinessConstants.APPLICATION_ID));
		userProfile.put(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY, null!=execution.getVariable(CreditBusinessConstants.CO_APPLICATION_USER_ATTRIBUTE_KEY) ? execution.getVariable(CreditBusinessConstants.CO_APPLICATION_USER_ATTRIBUTE_KEY).toString() : null);
		userProfile.put(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE, "2");
		userProfile.put("coapplicantObligation", request.get("coapplicantObligation"));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, userProfile);
	}
	
	@SuppressWarnings("unchecked")
	public void postUpdateCoAppforSecured(DelegateExecution execution) {
		JSONObject userProfile = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.CO_APPLICATION_USER_ATTRIBUTE_KEY, userProfile.get(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY));
	}
	
	@SuppressWarnings("unchecked")
	public void preUpdateCoAppIncomeforSecured(DelegateExecution execution) {
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject occupationType = new JSONObject();
		//occupationType.put(CreditBusinessConstants.KEY, masterDataRedisClientHelper.getOccupationKeyForCode(OTHER));
		occupationType.put(CreditBusinessConstants.KEY, 8l);
		occupationType.put(CreditBusinessConstants.CODE, OTHER);
		occupationType.put(CreditBusinessConstants.VALUE, OTHER);
		JSONObject salariedDetail = new JSONObject();
		salariedDetail.put(CreditBusinessConstants.NETSALARY, request.get("coapplicantIncome"));
		JSONObject professionJson = new JSONObject();
		professionJson.put("ocupationType", occupationType);
		professionJson.put("salariedDetail", salariedDetail);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, professionJson);
	}
	
	public void setOfficialEmailPresentFlag(DelegateExecution execution, JSONObject salariedDetail) {
		if (salariedDetail != null && salariedDetail.get("employerType") != null) {
			Long employerType = salariedDetail.get("employerType") != null ? new BigDecimal(salariedDetail.get("employerType").toString()).longValue() : null;
			if(employerType!=null) {
				if(employerType != 2 && employerType != 3 && employerType != 4) {
				   execution.setVariable(IS_OFFICIALEMAIL_PRESENT, true);
				}
				else{
				   execution.setVariable(IS_OFFICIALEMAIL_PRESENT, false);
				}
			}
		}else if(salariedDetail != null && salariedDetail.get("employerType") == null){
			  execution.setVariable(IS_OFFICIALEMAIL_PRESENT, true);
		}
	}
	
	public void allowCurrentAddressCheck(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetAddressV2MultiEntries");
		execution.setVariable(ALLOW_CURRENT_ADDRESS_UPDATE, true);
		
		Gson gson = new GsonBuilder().serializeNulls().create();
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		String requestJson = gson.toJson(request);
		CreditParameters profileRequest = gson.fromJson(requestJson, CreditParameters.class);

		List<String> addressSources = new ArrayList<String>();
		addressSources.add(ADD_SRC_OFFERAPI);
		addressSources.add(ADD_SRC_APPLICANT);

		List<Address> addressList = getAllCurrentAddress(execution);
		if (!CollectionUtils.isEmpty(addressList) && profileRequest.getResidencePincode() != null) {
			String pinCodeFromRequest = profileRequest.getResidencePincode().getPincode();
			for (Object addressObj : addressList) {
				String addressJson = gson.toJson(addressObj);
				Address address = gson.fromJson(addressJson, Address.class);
				if (address.getAddressSource() != null && addressSources.contains(address.getAddressSource().toLowerCase())
						&& pinCodeFromRequest != null && pinCodeFromRequest.equalsIgnoreCase(address.getPincode())) {
					execution.setVariable(ALLOW_CURRENT_ADDRESS_UPDATE, false);
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetAddressV2MultiEntries");
	}

	private List<Address> getAllCurrentAddress(DelegateExecution execution) {
		List<Address> addressList = null;
		Map<String, String> params = new HashMap<String, String>(); 
		params.put("applicationid", execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		params.put("userattributekey", execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
		params.put("returnSingleCurrentAddressFlag",Boolean.FALSE.toString());
		params.put("removeExactMatchCurrentAddress",Boolean.FALSE.toString());
		params.put(CreditBusinessConstants.TYPE_KEY, AddressTypeEnum.CURRENT.getValue());
		try {
			addressList = apiCallHelper.getAddressV2(new HttpHeaders(), params);
		} catch (CreditBusinessException e) {
			if (HttpStatus.NOT_FOUND.equals(e.getCode())) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found exception while fetching V2 address with params = " + params);
				return null;
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while fetching V2 address with params = " + params, e);
				throw e;
			}
		}
		return addressList;
	}
	
	
	public void postUpdateOccupationAdditionalDetail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postUpdateOccupationAdditionalDetail");
		execution.setVariable(CreditBusinessConstants.EMPLOYERID, null);
		execution.setVariable(CreditBusinessConstants.IS_SALARIED, false);
		execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, false);

		JSONObject profession = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		JSONObject ocupationType = CreditBusinessHelper.getJSONObject(profession.get("ocupationType"));
		if (OccupationTypeEnum.SALARIED.getValue().equalsIgnoreCase(ocupationType.get("code").toString())) {
			JSONObject salariedDetail = CreditBusinessHelper.getJSONObject(profession.get("salariedDetail"));
			execution.setVariable(CreditBusinessConstants.IS_SALARIED, true);
			if (salariedDetail != null && salariedDetail.get("employerName") != null) {
				JSONObject employerName = CreditBusinessHelper.getJSONObject(salariedDetail.get("employerName"));
				if (employerName != null && employerName.get("key") != null) {
					execution.setVariable(CreditBusinessConstants.EMPLOYERID, new BigDecimal(employerName.get("key").toString()).intValue());
				} else if (salariedDetail.get("employerNameOther") != null) {
					execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, true);
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postUpdateOccupationAdditionalDetail");
	}
	
	public void getCurrentAddress(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start getCurrentAddress");
		Map<String, String> params = new HashMap<>();
		params.put("applicationid", execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		params.put("userattributekey",
				execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
		params.put(CreditBusinessConstants.TYPE_KEY, AddressTypeEnum.CURRENT.getValue());
		Address address = null;
		try {
			address = apiCallHelper.getAddress(new HttpHeaders(), params);
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception while fetching address with params = " + params, e);
		}
		if (null != address) {
			execution.setVariable(CreditBusinessConstants.PINCODEKEY, address.getPincodeKey());
			execution.setVariable("addressLine1", address.getAddressLine1());
			execution.setVariable("addressLine2", address.getAddressLine2());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end getCurrentAddress");
	}
	
	public void preUpdateCibilGender(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preUpdateCibilGender");
		Object cibilGender = null;
		String cibilStr = execution.getVariable(CreditBusinessConstants.CIBIL_JSON).toString();
		cibilStr = cibilStr.replaceAll("\\\\", "");
		JSONObject cibilJson = CreditBusinessHelper.getJSONObject(cibilStr);

		if (cibilJson.get("firstCibilRecord") != null) {
			JSONObject firstCibilRecord = CreditBusinessHelper.getJSONObject(cibilJson.get("firstCibilRecord"));
			if (firstCibilRecord.get("cibilResponse") != null) {
				JSONObject cibilResponse = CreditBusinessHelper.getJSONObject(firstCibilRecord.get("cibilResponse"));
				if (cibilResponse.get("consumerName") != null) {
					JSONObject consumerName = CreditBusinessHelper.getJSONObject(cibilResponse.get("consumerName"));
					cibilGender = consumerName.get("gender");
				}
			}
		}
		
		JSONObject userProfile = new JSONObject();
		Long cibilGenderValue = new BigDecimal(cibilGender.toString()).longValue();
		if(1 == cibilGenderValue) {// 1 is for Female from Cibil
			userProfile.put("genderKey", 21);
		}else {
			//Male and others
			userProfile.put("genderKey", 22);
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, userProfile);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end preUpdateCibilGender");
	}
	
	public void preAlternateMobileNumberUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAlternateMobileNumberUpdate");
		JSONObject additionalDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		execution.setVariable(CreditBusinessConstants.ALTERNATE_MOBILE_NUMBER_FLAG, Boolean.FALSE);
		if (null != additionalDetail.get("alternateMobileNumber")) {
			JSONObject alternateMobNo=new JSONObject();
			alternateMobNo.put("alternateMobileNumber", additionalDetail.get("alternateMobileNumber"));
			execution.setVariable(CreditBusinessConstants.PAYLOAD,alternateMobNo);
			execution.setVariable(CreditBusinessConstants.ALTERNATE_MOBILE_NUMBER_FLAG, Boolean.TRUE);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preAlternateMobileNumberUpdate");
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject updateOccupationBasisOccupationCode(DelegateExecution execution, JSONObject profession, String occupationCode) {
		JSONObject salariedDetail = CreditBusinessHelper.getJSONObject(profession.get("salariedDetail"));
		JSONObject businessOwnerDetails = CreditBusinessHelper.getJSONObject(profession.get("businessOwnerDetails"));
		
		JSONObject professionUpdatePayload = new JSONObject();
		switch (occupationCode) {
		case SALR_OCCUPATION:
			execution.setVariable(CreditBusinessConstants.IS_SALARIED, true);
			execution.setVariable(CreditBusinessConstants.SALARY,salariedDetail.get("netSalary"));
			professionUpdatePayload.put("salariedDetail", salariedDetail);
			if (salariedDetail != null && salariedDetail.get("employerName") != null) {
				JSONObject employerName = CreditBusinessHelper.getJSONObject(salariedDetail.get("employerName"));
				if(employerName != null && employerName.get("key") != null) {
					execution.setVariable(CreditBusinessConstants.EMPLOYERID, new BigDecimal(employerName.get("key").toString()).intValue());
				}else if(salariedDetail.get("employerNameOther") != null){ 
					execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, true);
				}
			}
			
			break;
			
		case SEMP_OCCUPATION:
			professionUpdatePayload.put("businessOwnerDetails", businessOwnerDetails);
			
			break;
			
		case DOCSAL_OCCUPATION:
			professionUpdatePayload.put("salariedDetail", salariedDetail);
			break;
			
		case DOCSEMP_OCCUPATION:
			professionUpdatePayload.put("businessOwnerDetails", businessOwnerDetails);
			break;
		
		case CA_OCCUPATION:
			professionUpdatePayload.put("businessOwnerDetails", businessOwnerDetails);
			break;
			
		case OTHER_OCCUPATION:
			professionUpdatePayload.put("businessOwnerDetails", businessOwnerDetails);
			break;
			
		default:
			break;
		}
		
		return professionUpdatePayload;
	}
	
	@SuppressWarnings("unchecked")
	public void preUpdateAdditionalProfessionDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start preUpdateAdditionalProfessionDetails for : "
						+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));

		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject occupation = CreditBusinessHelper.getJSONObject(execution.getVariable(OCCUPATION));
		JSONObject occupationType = CreditBusinessHelper.getJSONObject(occupation.get(OCCUPATIONTYPE));
		JSONObject salariedDetail = CreditBusinessHelper.getJSONObject(occupation.get(SALARIED_DETAILS));
		JSONObject professionJson = new JSONObject();
		professionJson.put(OCCUPATIONTYPE, occupationType);
		if (null != salariedDetail) {
			salariedDetail.put(DESIGNATION, request.get(DESIGNATION));
			professionJson.put(SALARIED_DETAILS, salariedDetail);
		}
		execution.setVariable(PAYLOAD, professionJson);
	}
}

