package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.Esign;
import com.bajaj.markets.credit.business.beans.EsignRequest;
import com.bajaj.markets.credit.business.beans.EsignResponse;
import com.bajaj.markets.credit.business.beans.GenerateOTPResponseBean;

public interface CreditBusinessEsignService {
	
	public GenerateOTPResponseBean consentOTP(String  applicationKey,HttpHeaders headers);

	public EsignResponse createDocument(String applicationKey,EsignRequest esignRequest, HttpHeaders headers);

	public EsignResponse  getDocumentStatus(String applicationKey , HttpHeaders headers);
	public ApplicationResponse completeEsign(Esign esignRequest, HttpHeaders headers);
} 

