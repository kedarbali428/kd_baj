package com.bajaj.markets.credit.business.service;

import java.io.ByteArrayInputStream;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.bajaj.markets.credit.business.beans.FppPdfReportResponseBean;
import com.bajaj.markets.credit.business.beans.SummaryDetails;
import com.bajaj.markets.credit.business.beans.SummaryResponse;

public interface CreditBusinessProductSummaryService {


	public ResponseEntity<SummaryDetails> postSummary(String applicationId, SummaryDetails summaryRequest, HttpHeaders headers);

	public ResponseEntity<SummaryResponse> getSummary(String applicationId, HttpHeaders headers);

	public ByteArrayInputStream generatePDFByRepaymentSchedule(String applicationId, HttpHeaders headers);
	
	public ResponseEntity<FppPdfReportResponseBean> getFppPdfReportUrl(String applicationId, HttpHeaders headers);
}
