package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class ErrorBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9047402882402676409L;
	private String errorCode;
	private String errorMessage;
	
	public ErrorBean(String errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "ErrorBean [errorCode=" + errorCode + ", errorMessage=" + errorMessage + "]";
	}
	
}
