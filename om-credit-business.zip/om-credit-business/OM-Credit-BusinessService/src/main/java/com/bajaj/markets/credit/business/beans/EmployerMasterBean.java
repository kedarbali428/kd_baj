package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class EmployerMasterBean implements Serializable {
	
	private static final long serialVersionUID = -8475306167354480824L;

	private Long emprMasterId;
	
	private String emprMasterName;
	
	private Timestamp emprMastEstablishmentDate;
	
	private String emprMastClassCode;
	
	private String emprMastHouseNumber;
	
	private String emprMastFlatNumber;
	
	private String emprMastAddStreet;
	
	private String emprMastAddLine1;
	
	private String emprMastAddLine2;
	
	private String emprMastPostboxNumber;
	
	private Long countryKey;
	
	private Long stateKey;
	
	private Long cityKey;
	
	private Long pincodeKey;
	
	private String emprMasterPhone;
	
	private String emprMasterFax;
	
	private String emprMasttelexno;
	
	private String emprMastEmailAddress;
	
	private String emprMastContactPersonName;
	
	private String emprMastContactPersonNumber;
	
	private String emprMastAllocationType;
	
	private Long indMastKey;
	
	private String emprMastCorpidNo;
	
	private String emprMastStatus;
	
	private String emprMastRegState;
	
	private String emprMastClass;
	
	private String emprMastRegofComp;
	
	private String emprMastPrincipalBusActivity;
	
	private String emprMastEmailDomains;
	
	private BigDecimal emprWeightage;
	
	private String emprMastCategory;
	
	private String emprMastSubcategory;
	
	private Long employerTypeKey;
	
	private String employerKid;
	
	private Integer isActive;
	
	private Date timestamp;

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public Long getEmprMasterId() {
		return emprMasterId;
	}

	public void setEmprMasterId(Long emprMasterId) {
		this.emprMasterId = emprMasterId;
	}

	public String getEmprMasterName() {
		return emprMasterName;
	}

	public void setEmprMasterName(String emprMasterName) {
		this.emprMasterName = emprMasterName;
	}

	public Timestamp getEmprMastEstablishmentDate() {
		return emprMastEstablishmentDate;
	}

	public void setEmprMastEstablishmentDate(Timestamp emprMastEstablishmentDate) {
		this.emprMastEstablishmentDate = emprMastEstablishmentDate;
	}

	public String getEmprMastClassCode() {
		return emprMastClassCode;
	}

	public void setEmprMastClassCode(String emprMastClassCode) {
		this.emprMastClassCode = emprMastClassCode;
	}

	public String getEmprMastHouseNumber() {
		return emprMastHouseNumber;
	}

	public void setEmprMastHouseNumber(String emprMastHouseNumber) {
		this.emprMastHouseNumber = emprMastHouseNumber;
	}

	public String getEmprMastFlatNumber() {
		return emprMastFlatNumber;
	}

	public void setEmprMastFlatNumber(String emprMastFlatNumber) {
		this.emprMastFlatNumber = emprMastFlatNumber;
	}

	public String getEmprMastAddStreet() {
		return emprMastAddStreet;
	}

	public void setEmprMastAddStreet(String emprMastAddStreet) {
		this.emprMastAddStreet = emprMastAddStreet;
	}

	public String getEmprMastAddLine1() {
		return emprMastAddLine1;
	}

	public void setEmprMastAddLine1(String emprMastAddLine1) {
		this.emprMastAddLine1 = emprMastAddLine1;
	}

	public String getEmprMastAddLine2() {
		return emprMastAddLine2;
	}

	public void setEmprMastAddLine2(String emprMastAddLine2) {
		this.emprMastAddLine2 = emprMastAddLine2;
	}

	public String getEmprMastPostboxNumber() {
		return emprMastPostboxNumber;
	}

	public void setEmprMastPostboxNumber(String emprMastPostboxNumber) {
		this.emprMastPostboxNumber = emprMastPostboxNumber;
	}

	public Long getCountryKey() {
		return countryKey;
	}

	public void setCountryKey(Long countryKey) {
		this.countryKey = countryKey;
	}

	public Long getStateKey() {
		return stateKey;
	}

	public void setStateKey(Long stateKey) {
		this.stateKey = stateKey;
	}

	public Long getCityKey() {
		return cityKey;
	}

	public void setCityKey(Long cityKey) {
		this.cityKey = cityKey;
	}

	public Long getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(Long pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public String getEmprMasterPhone() {
		return emprMasterPhone;
	}

	public void setEmprMasterPhone(String emprMasterPhone) {
		this.emprMasterPhone = emprMasterPhone;
	}

	public String getEmprMasterFax() {
		return emprMasterFax;
	}

	public void setEmprMasterFax(String emprMasterFax) {
		this.emprMasterFax = emprMasterFax;
	}

	public String getEmprMasttelexno() {
		return emprMasttelexno;
	}

	public void setEmprMasttelexno(String emprMasttelexno) {
		this.emprMasttelexno = emprMasttelexno;
	}

	public String getEmprMastEmailAddress() {
		return emprMastEmailAddress;
	}

	public void setEmprMastEmailAddress(String emprMastEmailAddress) {
		this.emprMastEmailAddress = emprMastEmailAddress;
	}

	public String getEmprMastContactPersonName() {
		return emprMastContactPersonName;
	}

	public void setEmprMastContactPersonName(String emprMastContactPersonName) {
		this.emprMastContactPersonName = emprMastContactPersonName;
	}

	public String getEmprMastContactPersonNumber() {
		return emprMastContactPersonNumber;
	}

	public void setEmprMastContactPersonNumber(String emprMastContactPersonNumber) {
		this.emprMastContactPersonNumber = emprMastContactPersonNumber;
	}

	public String getEmprMastAllocationType() {
		return emprMastAllocationType;
	}

	public void setEmprMastAllocationType(String emprMastAllocationType) {
		this.emprMastAllocationType = emprMastAllocationType;
	}

	public Long getIndMastKey() {
		return indMastKey;
	}

	public void setIndMastKey(Long indMastKey) {
		this.indMastKey = indMastKey;
	}

	public String getEmprMastCorpidNo() {
		return emprMastCorpidNo;
	}

	public void setEmprMastCorpidNo(String emprMastCorpidNo) {
		this.emprMastCorpidNo = emprMastCorpidNo;
	}

	public String getEmprMastStatus() {
		return emprMastStatus;
	}

	public void setEmprMastStatus(String emprMastStatus) {
		this.emprMastStatus = emprMastStatus;
	}

	public String getEmprMastRegState() {
		return emprMastRegState;
	}

	public void setEmprMastRegState(String emprMastRegState) {
		this.emprMastRegState = emprMastRegState;
	}

	public String getEmprMastClass() {
		return emprMastClass;
	}

	public void setEmprMastClass(String emprMastClass) {
		this.emprMastClass = emprMastClass;
	}

	public String getEmprMastRegofComp() {
		return emprMastRegofComp;
	}

	public void setEmprMastRegofComp(String emprMastRegofComp) {
		this.emprMastRegofComp = emprMastRegofComp;
	}

	public String getEmprMastPrincipalBusActivity() {
		return emprMastPrincipalBusActivity;
	}

	public void setEmprMastPrincipalBusActivity(String emprMastPrincipalBusActivity) {
		this.emprMastPrincipalBusActivity = emprMastPrincipalBusActivity;
	}

	public String getEmprMastEmailDomains() {
		return emprMastEmailDomains;
	}

	public void setEmprMastEmailDomains(String emprMastEmailDomains) {
		this.emprMastEmailDomains = emprMastEmailDomains;
	}
	
	public BigDecimal getEmprWeightage() {
		return emprWeightage;
	}

	public void setEmprWeightage(BigDecimal emprWeightage) {
		this.emprWeightage = emprWeightage;
	}

	public String getEmprMastCategory() {
		return emprMastCategory;
	}

	public void setEmprMastCategory(String emprMastCategory) {
		this.emprMastCategory = emprMastCategory;
	}

	public String getEmprMastSubcategory() {
		return emprMastSubcategory;
	}

	public void setEmprMastSubcategory(String emprMastSubcategory) {
		this.emprMastSubcategory = emprMastSubcategory;
	}

	public Long getEmployerTypeKey() {
		return employerTypeKey;
	}

	public void setEmployerTypeKey(Long employerTypeKey) {
		this.employerTypeKey = employerTypeKey;
	}

	public String getEmployerKid() {
		return employerKid;
	}

	public void setEmployerKid(String employerKid) {
		this.employerKid = employerKid;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
}