package com.bajaj.markets.credit.business.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.AppDocumentTrackingBean;
import com.bajaj.markets.credit.business.beans.DocumentPushResponseBean;
import com.bajaj.markets.credit.business.beans.InitiateDocumentPushRequest;

public interface CreditBusinessApplicationDocumentPushService {

	DocumentPushResponseBean fetchDocumentPushDetails(Long applicationId, HttpHeaders headers);

	List<AppDocumentTrackingBean> initiateDocumentPush(@Valid InitiateDocumentPushRequest initiateDocumentPushRequest,
			String source, HttpHeaders headers,Long applicationId);

}
