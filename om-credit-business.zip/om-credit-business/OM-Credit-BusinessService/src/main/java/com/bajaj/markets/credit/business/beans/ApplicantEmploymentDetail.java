package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class ApplicantEmploymentDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long apltEmpDetEmpKey;

	private BigDecimal apltEmpDetCurrExp;

	private String apltEmpDetDesignForOth;

	private String apltEmpDetEmpNameForOth;

	private Date apltEmpDetEndDate;

	private BigDecimal apltEmpDetIsActive;

	private String apltEmpDetLstUpdateBy;

	private Timestamp apltEmpDetLstUpdateDt;
	
	private BigDecimal apltEmpDetEmploymentType;

	private Date apltEmpDetStartDate;

	private BigDecimal apltEmpDetTotalExp;

	private Long applicantKey;

	private Long emplrDesigKey;

	private Long emprMastId;
	
	private Long apltEmpDetEmployerType;

	public ApplicantEmploymentDetail() {
	}

	public Long getApltEmpDetEmpKey() {
		return apltEmpDetEmpKey;
	}

	public void setApltEmpDetEmpKey(Long apltEmpDetEmpKey) {
		this.apltEmpDetEmpKey = apltEmpDetEmpKey;
	}

	public BigDecimal getApltEmpDetCurrExp() {
		return apltEmpDetCurrExp;
	}

	public void setApltEmpDetCurrExp(BigDecimal apltEmpDetCurrExp) {
		this.apltEmpDetCurrExp = apltEmpDetCurrExp;
	}

	public String getApltEmpDetDesignForOth() {
		return apltEmpDetDesignForOth;
	}

	public void setApltEmpDetDesignForOth(String apltEmpDetDesignForOth) {
		this.apltEmpDetDesignForOth = apltEmpDetDesignForOth;
	}

	public String getApltEmpDetEmpNameForOth() {
		return apltEmpDetEmpNameForOth;
	}

	public void setApltEmpDetEmpNameForOth(String apltEmpDetEmpNameForOth) {
		this.apltEmpDetEmpNameForOth = apltEmpDetEmpNameForOth;
	}

	public Date getApltEmpDetEndDate() {
		return apltEmpDetEndDate;
	}

	public void setApltEmpDetEndDate(Date apltEmpDetEndDate) {
		this.apltEmpDetEndDate = apltEmpDetEndDate;
	}

	public BigDecimal getApltEmpDetIsActive() {
		return apltEmpDetIsActive;
	}

	public void setApltEmpDetIsActive(BigDecimal apltEmpDetIsActive) {
		this.apltEmpDetIsActive = apltEmpDetIsActive;
	}

	public String getApltEmpDetLstUpdateBy() {
		return apltEmpDetLstUpdateBy;
	}

	public void setApltEmpDetLstUpdateBy(String apltEmpDetLstUpdateBy) {
		this.apltEmpDetLstUpdateBy = apltEmpDetLstUpdateBy;
	}

	public Timestamp getApltEmpDetLstUpdateDt() {
		return apltEmpDetLstUpdateDt;
	}

	public void setApltEmpDetLstUpdateDt(Timestamp apltEmpDetLstUpdateDt) {
		this.apltEmpDetLstUpdateDt = apltEmpDetLstUpdateDt;
	}

	public BigDecimal getApltEmpDetEmploymentType() {
		return apltEmpDetEmploymentType;
	}

	public void setApltEmpDetEmploymentType(BigDecimal apltEmpDetEmploymentType) {
		this.apltEmpDetEmploymentType = apltEmpDetEmploymentType;
	}

	public Date getApltEmpDetStartDate() {
		return apltEmpDetStartDate;
	}

	public void setApltEmpDetStartDate(Date apltEmpDetStartDate) {
		this.apltEmpDetStartDate = apltEmpDetStartDate;
	}

	public BigDecimal getApltEmpDetTotalExp() {
		return apltEmpDetTotalExp;
	}

	public void setApltEmpDetTotalExp(BigDecimal apltEmpDetTotalExp) {
		this.apltEmpDetTotalExp = apltEmpDetTotalExp;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getEmplrDesigKey() {
		return emplrDesigKey;
	}

	public void setEmplrDesigKey(Long emplrDesigKey) {
		this.emplrDesigKey = emplrDesigKey;
	}

	public Long getEmprMastId() {
		return emprMastId;
	}

	public void setEmprMastId(Long emprMastId) {
		this.emprMastId = emprMastId;
	}

	public Long getApltEmpDetEmployerType() {
		return apltEmpDetEmployerType;
	}

	public void setApltEmpDetEmployerType(Long apltEmpDetEmployerType) {
		this.apltEmpDetEmployerType = apltEmpDetEmployerType;
	}

}