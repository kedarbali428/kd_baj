package com.bajaj.markets.credit.business.helper;

/**
 * Enum to map string representation of Rejection System Sources
 * 
 * @author 764504
 *
 */
public enum RejectionSystemSourceEnum {
	REJBRE1("REJBRE1"),
	REJBRE2("REJBRE2"),
	REJBRE3("REJBRE3"),
	LLISTBRE("LLISTBRE"),
	LISTBREAPI("LISTBREAPI"),
	LISTBREIV("LISTBREIV"),
	PRINCIPALAXISBANK("PRINCIPALAXISBANK"),
	PRINCIPALFULLERTON("PRINCIPALFULLERTON"),
	KARZABRE("KARZABRE"),
	RADDDET("RADDDET"),
	PRINCIPALREJECT("PRINCIPALREJECT");

	

	private final String value;

	private RejectionSystemSourceEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

}
