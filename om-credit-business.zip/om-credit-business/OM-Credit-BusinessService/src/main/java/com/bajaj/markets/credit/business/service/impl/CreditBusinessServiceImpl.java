package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.bfsd.security.beans.CustomDefaultHeaders.AUTH_TOKEN;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CARD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CREDIT_JOURNEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DATE_OF_BIRTH;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.LEAD_BOOST_EVENT_FILTER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.LEAD_BOOST_QUEUE_FILTER_ATTRB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PARENT_APPLICATION_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SECURED_LOAN;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.UNSECURED_LOAN;
import static com.bajaj.markets.credit.business.helper.OccupationTypeEnum.DOCTOR_SALARIED;
import static com.bajaj.markets.credit.business.helper.OccupationTypeEnum.DOCTOR_SELF_EMPLOYED;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.activiti.engine.RuntimeService;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.authentication.principal.AuthenticatedUser;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.Application;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationInfo;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ApplicationResume;
import com.bajaj.markets.credit.business.beans.ApplicationStageDetails;
import com.bajaj.markets.credit.business.beans.BusinessOwnerDetails;
import com.bajaj.markets.credit.business.beans.CreateApplicationRequest;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.EmployerNameDetail;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.Gender;
import com.bajaj.markets.credit.business.beans.ImpsRequestMetadata;
import com.bajaj.markets.credit.business.beans.ImpsResponseMetadata;
import com.bajaj.markets.credit.business.beans.LeadRequest;
import com.bajaj.markets.credit.business.beans.MaritalStatus;
import com.bajaj.markets.credit.business.beans.MobileLoginRequest;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OccupationDetail;
import com.bajaj.markets.credit.business.beans.OccupationReference;
import com.bajaj.markets.credit.business.beans.OfferApiRequest;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.beans.PinCodeServiceableMasterData;
import com.bajaj.markets.credit.business.beans.PrincipalRequest;
import com.bajaj.markets.credit.business.beans.ProfDetail;
import com.bajaj.markets.credit.business.beans.ProfileDetail;
import com.bajaj.markets.credit.business.beans.ProfileDetails;
import com.bajaj.markets.credit.business.beans.ProfileDetailsWrapper;
import com.bajaj.markets.credit.business.beans.RBLEvent;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResponseBean;
import com.bajaj.markets.credit.business.beans.SalariedDetail;
import com.bajaj.markets.credit.business.beans.TokenResponse;
import com.bajaj.markets.credit.business.beans.UserProfile;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.beans.UtmSourceChannelBean;
import com.bajaj.markets.credit.business.datasource.OfferDataSourceHandler;
import com.bajaj.markets.credit.business.datasource.ProspectDataSource;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.AsychRestHelper;
import com.bajaj.markets.credit.business.helper.BAUProductToOccupation;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.EventMessageHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.OMProductToBauProduct;
import com.bajaj.markets.credit.business.helper.OccupationTypeEnum;
import com.bajaj.markets.credit.business.helper.PrincipalTypeEnum;
import com.bajaj.markets.credit.business.helper.ProductCodeEnum;
import com.bajaj.markets.credit.business.helper.ReferenceOf;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.processor.ApplictionClient;
import com.bajaj.markets.credit.business.service.CreditBusinessService;
import com.bajaj.markets.credit.business.session.ApplicationSessionManager;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.bajaj.markets.referencedataclientlib.bean.LookupCodeValuesResponseBean;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@Component
public class CreditBusinessServiceImpl implements CreditBusinessService {

	private static final String ERROR_CODE_OMCB_REDIRECT_V2 = "OMCB-REDIRECT-V2";
	private static final String ERROR_CODE_OMCB_REDIRECT_V1 = "OMCB-REDIRECT-V1";

	@Autowired
	RuntimeService runtimeService;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;

	@Autowired
	PublisherService publisherService;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	WorkflowHelper workflowHelper;

	@Autowired
	CustomDefaultHeaders customHeader;

	@Autowired
	HttpServletRequest httpServletRequest;

	@Autowired
	MasterDataRedisClientHelper masterDataRedisClientHelper;

	@Autowired
	CreditBusinessOfferServiceImpl creditBusinessOfferServiceImpl;
	
	@Autowired
	OfferDataSourceHandler offerDataSourceHandler;
	
	@Autowired
	ProspectDataSource prospectDataSource;
	
	@Autowired
	ApplictionClient applicationClient;
	
	@Autowired
	AsychRestHelper asynchRestHelper;

	@Value("${aws.publisher.topic.arn}")
	private String topicArn;

	@Value("${api.omreferencedatareferencedataservice.getmaritalstatus.get.url}")
	private String getmaritalStatusURL;

	@Value("${api.omreferencedatareferencedataservice.getoccupation.get.url}")
	private String getOccupationDetailurl;

	@Value("${api.omreferencedatareferencedataservice.getgender.get.url}")
	private String getgenderURL;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getOccupationUrl;

	@Value("${api.omcreditapplicationservice.getdocument.get.url}")
	private String getDocumentUrl;
	
	@Value("${api.omcreditapplicationservice.oglflg.GET.url}")
	private String getPincodeUrl;

	@Value("${api.omcreditapplicationservice.getaddress.get.url}")
	private String getAddressURL;

	@Value("${api.omcreditapplicationservice.creditapplication.post.url}")
	private String createApplicatonUrl;

	@Value("${api.omcreditapplicationservice.userprofiles.get.url}")
	private String getUserProfiles;

	@Value("${api.omcreditapplicationservice.updateoccupation.put.url}")
	private String updateprofession;

	@Value("${api.omcreditapplicationservice.getapplications.get.url}")
	private String getApplications;

	@Value("${api.omcreditapplicationservice.updatestage.put.url}")
	private String updateStages;

	@Value("${api.applicantservice.getapplicant.get.url}")
	private String checkApplicant;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getProfession;

	@Value("${api.omcreditapplicationservice.getprofessionreferencedata.get.url}")
	private String getProfessionReferenceData;

	@Value("${api.omcreditapplicationservice.getapplicationproduct.get.url}")
	private String getApplicationProduct;

	@Value("${api.authentication.authenticatemobiledobandgeneratetokenV2.POST.url}")
	private String pseudoTokenGenerateUrl;
	
	@Value("${api.omcreditapplicationservice.updateIntent.put.url}")
	private String updateIntentUrl;
	
	@Value("${api.referencedata.utmsourcechannel.utmSource.param.url}")
	private String getUtmSourceKey;

	@Value("${api.omcreditapplicationservice.updateapplicant.put.url}")
	private String updateApplicantUrl;
	
	@Value("${api.applicant.openMarkets.getApplicantWithMoDob.GET.url}")
	private String getApplicantUrl;
	
	@Value("${diplay.occupation.error:false}")
	private boolean diplayOccupationError;
	
	@Value("${api.omcreditapplicationservice.imps.get.url}")
	private String getImpsDetailsUrl;
	
	@Value("${api.verification.imps.get.url}")
	private String verificationUrl;
	
	@Value("${api.offers.mobdob.GET.url}")
	private String getMobDobLoanOfferURL;
	
	@Value("${api.emicnsb.creditcardoffer.mobdob.GET.url}")
	private String getMobDobCardOfferURL;
	
	@Value("${bau.date.format:dd-MMM-yy}")
	private String bauDateFormat;
	
	@Value("${om.date.format:yyyy-MM-dd}")
	private String omDateFormat;
	
	@Value("${otp.authorization.required:true}")
	private boolean otpAuthorizationRequired;
	
	@Value("${om.campaign.otp.required:true}")
	private boolean campaignOtpRequired;
	
	@Value("${api.omcreditcardsprincipalintegrationservice.customerid.PUT.url}")
	private String extCustomerCheckUrl;
	
	@Value("${api.omofferservice.mobdob.GET.url}")
	private String getMobDobOfferURL;
	
	@Value("${api.omcreditapplicationservice.userprofiles.post.url}")
	private String updateProfileUrl;

	@Autowired
	private ApplicationSessionManager applicationSessionManager;
	
	@Value("#{'${degrees.registration.capture.skip}'.split(',')}")
	private List<String> degreesToSkipRegNumberCapture;
	
	@Value("#{'${dental.degrees}'.split(',')}")
	private List<String> dentalDegrees;
	
	@Autowired
	private EventMessageHelper eventMessageHelper;
	
	@Value("${om.credit.parent.workflow.processname:fldgCreditJourney}")
	private String parentWorkflowProcessName;
	
	@Autowired
	private Environment env;
	
	private static final String CLASS_NAME = CreditBusinessServiceImpl.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	@Override
	public ProfileDetailsWrapper updateProfile(ProfileDetails profileDetails, String applicationid, HttpHeaders headers,String action) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start updateProfile for applicationid : " + applicationid);
		profileDetails.setApplicationid(applicationid);
		String source = CreditBusinessConstants.JOURNEY;
		try {
			ApplicationDetail application = apiCallsHelper.getApplicationDetails(applicationid, headers);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "application : " + application);
			
			if ((StringUtils.isEmpty(action) || !"back".equals(action)) && CreditBusinessConstants.PRODUCT_CODE_OMPL.equalsIgnoreCase(application.getL2ProductCode())) {
				unsecuredProfileDedupeEvents(profileDetails, application);
				eventMessageHelper.publishBMR1Event(application, profileDetails,source);
				eventMessageHelper.publishBMR2Event(application, profileDetails,source);
			}
			if(CreditBusinessConstants.PRODUCT_CODE_CC.equalsIgnoreCase(application.getL2ProductCode())){
				Map<String, String> fetchUserProfileParams = new HashMap<>(); 
				fetchUserProfileParams.put("applicationid", application.getApplicationKey());
				UserProfileBean userProfileBean= apiCallsHelper.getUserProfile(fetchUserProfileParams);
				if(null != userProfileBean && null != userProfileBean.getMobile()){
					JSONObject hdfcCardOfferRequest = new JSONObject();
					hdfcCardOfferRequest.put("applicationId", application.getApplicationKey());
					hdfcCardOfferRequest.put("mob", userProfileBean.getMobile());
					hdfcCardOfferRequest.put("productCode", CreditBusinessConstants.PRODUCT_CODE_CC);
					hdfcCardOfferRequest.put("principalName", PrincipalTypeEnum.HDFC.getValue());
					hdfcCardOfferRequest.put("pan", profileDetails.getPan());

					triggerOfferEvent(CreditBusinessConstants.PRODUCT_CODE_CC, PrincipalTypeEnum.HDFC, hdfcCardOfferRequest);
				}else{
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "UserProfile data is not proper for publishing Hdfc offer event ,application : " + application.getApplicationKey());
				}

			}
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Publishing finished... : " + applicationid);

			productLevelValidation(application, profileDetails);

			Map<String, Object> vars = new HashMap<String, Object>();
			vars.put(CreditBusinessConstants.REQUEST, profileDetails);
			vars.put("action", profileDetails.getAction() != null ? profileDetails.getAction().toLowerCase() : "next");
			vars.put("applicationId", applicationid);
			vars.put(CreditBusinessConstants.L2_PRODUCT_CODE, application.getL2ProductCode());
			vars.put(CreditBusinessConstants.L2_PRODUCT_KEY, application.getL2ProductKey());
	        vars.put("officePincodeRequired",profileDetails.getOfficePinCodeRequired());
	        vars.put("officepincode", profileDetails.getOfficePinCode());
//			vars.put("stagePercentage", 30);
//			NextTask nextTask = workflowHelper.startActivitiProcess("ginPreListingFlowBpmn", vars);
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End updateProfile for applicationid : " + applicationid);
			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			return new ProfileDetailsWrapper(profileDetails, task);
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception completing workflow task" + e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while caaling the service" + e);
			throw new CreditBusinessException(e.getCause());

		}
	}

	@SuppressWarnings("unchecked")
	private void unsecuredProfileDedupeEvents(ProfileDetails profileDetails, ApplicationDetail application) {
		if (CreditBusinessConstants.PRODUCT_CODE_OMPL.equalsIgnoreCase(application.getL2ProductCode())) {
			Map<String, String> fetchUserProfileParams = new HashMap<>();
			fetchUserProfileParams.put("applicationid", application.getApplicationKey());
			UserProfileBean userProfileBean= apiCallsHelper.getUserProfile(fetchUserProfileParams);
			if (null != userProfileBean && null != userProfileBean.getMobile()) {
				JSONObject earlySalaryUnsecuredDedupeRequest = new JSONObject();
				earlySalaryUnsecuredDedupeRequest.put("applicationId", application.getApplicationKey());
				earlySalaryUnsecuredDedupeRequest.put("mob", userProfileBean.getMobile());
				earlySalaryUnsecuredDedupeRequest.put("productCode", CreditBusinessConstants.PRODUCT_CODE_OMPL);
				earlySalaryUnsecuredDedupeRequest.put("principalName", PrincipalTypeEnum.EARLYSALARY.getValue());
				earlySalaryUnsecuredDedupeRequest.put("pan", profileDetails.getPan());
				earlySalaryUnsecuredDedupeRequest.put("userAttributeKey", userProfileBean.getApplicationUserAttributeKey());
				
				triggerOfferEvent(CreditBusinessConstants.PRODUCT_CODE_OMPL, PrincipalTypeEnum.EARLYSALARY, earlySalaryUnsecuredDedupeRequest);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "UserProfile data is not proper for publishing EarlySalary dedupe event, application : "+application.getApplicationKey());
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "UserProfile data is not proper for publishing EarlySalary dedupe event, application : "+application.getApplicationKey());
			}
		}
	}
	
	private void productLevelValidation(ApplicationDetail application, ProfileDetails profile) {
		if (ProductCodeEnum.LOANS.getValue().equalsIgnoreCase(application.getL2ProductCode())) {
			if (OccupationTypeEnum.BUSINESS.getValue().equalsIgnoreCase(profile.getOccupation())) {
				if (profile.getBusinessPan() == null) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Business PAN is not available for application " + profile.getApplicationid());
					throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
							new ErrorBean("OMCB_022", "Business PAN can not be null or empty for loan applicatio"));
				}
			}
						}
					}

	private boolean isAuthorizedApplication(Long applicationKey, boolean offeredCase) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "isResumeAllowed - start");
		boolean resumeAllowed = false;

		if ((httpServletRequest.isUserInRole(Role.PSEUDO_CUSTOMER) && !offeredCase) || httpServletRequest.isUserInRole(Role.PSEUDO_VERIFIED_CUSTOMER)) {
			AuthenticatedUser authenticatedUser = (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (null != authenticatedUser && null != authenticatedUser.getAdditionalInfo()
					&& applicationKey.equals(authenticatedUser.getAdditionalInfo().getApplicationKey())) {
				resumeAllowed = true;
			}
		} else if (httpServletRequest.isUserInRole(Role.EMPLOYEE) || httpServletRequest.isUserInRole(Role.CUSTOMER)) {
			resumeAllowed = true;
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "isResumeAllowed - end with: " + resumeAllowed);
		return resumeAllowed;
	}

	/**
	 * 1)Check if application exists with mob dob and product code 2)Create new
	 * application (not for PL)if application not exits 3)Get user Profiles
	 * (userattribute key) 4) Update Profession 5)Update Application Stage to 5%
	 * 6)Check Applicant exists or not 7) Start Activiti
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ApplicationResponse createCreditApplication(Application application, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start createCreditApplication in serviceImpl");
		PrincipalRequest principalRequest = null;
		ApplicationResponse applicationResponse = new ApplicationResponse();
		NextTask nextTask = new NextTask();
		Gson gson = new Gson();
		Map<String, String> params = new HashMap<>();
		
		// used for offer scenario otp skip check
		boolean offeredCase = false;
		
		// EP resume
		if (null != application.getApplicationKey() && 0l != application.getApplicationKey()) {
			
			if(httpServletRequest.isUserInRole(Role.PSEUDO_VERIFIED_CUSTOMER) || httpServletRequest.isUserInRole(Role.CUSTOMER)){
				//Save mobile verification details
				apiCallsHelper.saveVerificationDetails(application.getApplicationKey().toString(), "MOBILE", "BFSD_OTP");
			}
			
			if (isAuthorizedApplication(application.getApplicationKey(), offeredCase)) {

				applicationSessionManager.validateSession(httpServletRequest, application.getApplicationKey().toString(), application.isOverrideCustomerSession());
				// check for occupation update required, update the occupation and offer if any
				checkForOccupationAndOfferUpdate(application, params, headers);

				if(null != application.getHlProductIntent()) {
					Map<String,String> param = new HashMap<>();
					JSONObject productIntent = new JSONObject();
					productIntent.put("hlProductIntent", null != application.getHlProductIntent() ? application.getHlProductIntent().getCode() : null);
					param.put("applicationKey", application.getApplicationKey().toString());
					String productIntentRequest = CreditBusinessHelper.objectToJson(productIntent);
					creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateIntentUrl, String.class, param, productIntentRequest, headers);
				}
				if (StringUtils.equals(CreditBusinessConstants.PRODUCT_CODE_EMIC, application.getProductCode())) {
					params.put(APPLICATION_ID, application.getApplicationKey().toString());
					JSONObject emicStage = new JSONObject();
					UserProfile userProfile = new UserProfile();
					emicStage.put("percentageCompletion", 70);
					String emicStageJson = CreditBusinessHelper.objectToJson(emicStage);
					try {
						Map<String, String> nameMap = creditBusinessHelper
								.splitfullNameToFnameMnameLname(application.getName());
						Name name = new Name();
						name.setFirstName(nameMap.get(CreditBusinessConstants.FIRST_NAME));
						name.setMiddleName(nameMap.get(CreditBusinessConstants.MIDDLE_NAME));
						name.setLastName(nameMap.get(CreditBusinessConstants.LAST_NAME));
						userProfile.setName(name);
						userProfile.setApplicationUserAttributeType("1");
						userProfile.setApplicationKey(String.valueOf(application.getApplicationKey()));
						String userProfileRequest = CreditBusinessHelper.objectToJson(userProfile);
						creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, updateProfileUrl, String.class, params,
								userProfileRequest, headers);
						if (!application.isResume()) {
							creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateStages, String.class, params,
									emicStageJson, headers);
						}
					} catch (Exception exception) {
						logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
								"Exception while updating stage for EMIC app : " + application.getApplicationKey(),
								exception);
						throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
								new ErrorBean("CBS-001", "Some Technical exception occurred"));
					}
				}
				
				return startActivitiWithResumeFlow(application);

			} else if (UNSECURED_LOAN == application.getProductKey()) {
				params.put(APPLICATION_ID, application.getApplicationKey().toString());
				
				try {
					UserProfileBean userProfile = apiCallsHelper.getUserProfile(params);
					
					if(null != userProfile) {
						application.setMobileNumber(userProfile.getMobile());
						application.setDateOfBirth(userProfile.getDateOfBirth());
						
						nextTask.setNextTaskKey("otpscreen");
						applicationResponse.setNextTask(nextTask);
						application.setResume(true);
						applicationResponse.setPayload(application);
						
						return applicationResponse;
					} else {
						throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("CBS-123", "Profile not found!"));
					}
				} catch (CreditBusinessException businessException) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Business Exception occurred while fetching " + "user profile for application: " + application.getApplicationKey(),
							businessException);
					throw businessException;
				} catch (Exception exception) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Technical Exception occurred while fetching " + "user profile for application: " + application.getApplicationKey(), exception);
					throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "Some technical exception occurred"));
				}
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "");
				throw new CreditBusinessException(HttpStatus.FORBIDDEN, new ErrorBean("CBS-403", "You are not authorized to resume the application"));
			}
		}

		try {
			Long key = getUTMSource(headers);
			if(key!=null) {
				headers.set("sourcing_channel", key.toString());
			}
			// Campaign/Offer case
			if(!StringUtils.isEmpty(application.getOfferId())) {
				offeredCase = fetchCreateAppRequiredDataFromOffer(application, params, headers);
				
				if(application.isApplicationCreationPossible()) {
					// if resumable application exist resume it else direct to create application flow
					return checkApplicationExistenceAndResume(application, params, headers);
				} else {
					applicationResponse.setPayload(application);
					throw new CreditBusinessException(HttpStatus.PARTIAL_CONTENT, applicationResponse);
				}
			} else { // Fresh Application case
				// if resumable application exist resume it else direct to create application flow
				return checkApplicationExistenceAndResume(application, params, headers);
			}		

		} catch (CreditBusinessException ex) {
			if (ex.getCode().equals(HttpStatus.NOT_FOUND)) {
				try {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Response with Status Code : " + ex.getCode());
					Long key = getUTMSource(headers);
					CreateApplicationRequest createApplicationRequest = creditBusinessHelper.mapRequest(application);
					//for Application creation from V2 API flow
					if (null != application.getFldgApplication() && application.getFldgApplication()) {
						createApplicationRequest.setAppProcessIdentifier(parentWorkflowProcessName);
					}
					String jsonApplicationRequest = CreditBusinessHelper.objectToJson(createApplicationRequest);
					if(key!=null) {
					headers.set("sourcing_channel", key.toString());
					}
					ResponseEntity<?> createApplicationResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, createApplicatonUrl, String.class,
							null, jsonApplicationRequest, headers);
					JSONObject payload = gson.fromJson((String) createApplicationResponse.getBody(), JSONObject.class);
					Long applicationKey = Long.parseLong(payload.get(CreditBusinessConstants.APPLICATIONKEY).toString());
					payload.put("resume", false);
					payload.put(CreditBusinessConstants.PRODUCTCODE, application.getProductCode());
					applicationResponse.setPayload(payload);
					
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Payload ==== " + payload);
					
					if(null != payload && null != payload.get(CreditBusinessConstants.APPLICATIONKEY) && httpServletRequest.isUserInRole(Role.CUSTOMER)){
						//Save mobile verification details
						apiCallsHelper.saveVerificationDetails(payload.get(CreditBusinessConstants.APPLICATIONKEY).toString(), "MOBILE", "BFSD_OTP");
					}
					
					if (null != payload && null != payload.get(CreditBusinessConstants.APPLICATIONKEY) && null != payload.get(CreditBusinessConstants.MOBILE)) {
						principalRequest = new PrincipalRequest();
						principalRequest.setMob(payload.get(CreditBusinessConstants.MOBILE).toString());
						principalRequest.setApplicationId(payload.get(CreditBusinessConstants.APPLICATIONKEY).toString());
					}

					if(payload != null) {
						payload.put("subStage", "");
						payload.put(CreditBusinessConstants.APPLICATION_ID, applicationKey.toString());
						params.put(CreditBusinessConstants.APPLICATION_ID, applicationKey.toString());
						payload.put(CreditBusinessConstants.JOURNEY, "");
						payload.put("stagePercentage", 0);
					}
					
					MobileLoginRequest loginRequest = new MobileLoginRequest();
					loginRequest.setApplicationKey(applicationKey);
					loginRequest.setMobile(application.getMobileNumber());
					loginRequest.setDateOfBirth(application.getDateOfBirth());
					loginRequest.setSource("journey");
					String tokenGenerateRequest = CreditBusinessHelper.objectToJson(loginRequest);
					ResponseEntity<?> authenticationResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, pseudoTokenGenerateUrl,
							ResponseBean.class, null, tokenGenerateRequest, headers);
					ResponseBean tokenResponseBean = (ResponseBean) authenticationResponse.getBody();
					TokenResponse tokenResponse = gson.fromJson(tokenResponseBean.getPayload().toString(), TokenResponse.class);

					String requestAuthToken = headers.getFirst(CustomDefaultHeaders.AUTH_TOKEN);
					customHeader.setAuthtoken(tokenResponse.getTokens().get(0).getToken());
					headers.remove(CustomDefaultHeaders.AUTH_TOKEN);
					headers.add(CustomDefaultHeaders.AUTH_TOKEN, customHeader.getAuthtoken());
					
					ResponseEntity<?> userProfileResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getUserProfiles, List.class, params, null,
							headers);

					ObjectMapper mapper = new ObjectMapper();
					mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
					List<UserProfileBean> userProfileList = mapper.convertValue(userProfileResponse.getBody(), new TypeReference<List<UserProfileBean>>() {
							});
					
					UserProfileBean userProfile = new UserProfileBean();
					for (UserProfileBean userProfileBean : userProfileList) {
						if (userProfileBean.getApplicationUserAttributeType().equals("1")) {
							userProfile = userProfileBean;
							break;
						}
					}
					
					params.put("userattributekey", userProfile.getApplicationUserAttributeKey());
					
					if(CreditBusinessConstants.PRODUCT_CODE_OMPL.equalsIgnoreCase(application.getProductCode())) {
						Thread.sleep(1000);
						bflExistingCustomerApiCheck(applicationKey, application.getMobileNumber(), userProfile.getApplicationUserAttributeKey(), headers);
						
						JSONObject axisUnsecuredLoanofferRequest = new JSONObject();
						axisUnsecuredLoanofferRequest.put("applicationId", applicationKey.toString());
						axisUnsecuredLoanofferRequest.put("mob", application.getMobileNumber());
						axisUnsecuredLoanofferRequest.put("userAttributeKey", userProfile.getApplicationUserAttributeKey());
						axisUnsecuredLoanofferRequest.put("productCode", application.getProductCode());
						axisUnsecuredLoanofferRequest.put("principalName", PrincipalTypeEnum.AXIS.getValue());
						axisUnsecuredLoanofferRequest.put("dob", application.getDateOfBirth());
						
						triggerOfferEvent(application.getProductCode(), PrincipalTypeEnum.AXIS, axisUnsecuredLoanofferRequest);
						
						JSONObject casheUnsecuredLoanofferRequest = axisUnsecuredLoanofferRequest;
						casheUnsecuredLoanofferRequest.put("principalName", PrincipalTypeEnum.CASHE.getValue());
						triggerOfferEvent(application.getProductCode(), PrincipalTypeEnum.CASHE, casheUnsecuredLoanofferRequest);
						
						JSONObject unsecuredLoanOfferFanoutRequest = axisUnsecuredLoanofferRequest;
						unsecuredLoanOfferFanoutRequest.put("productCode", "DEFAULT");
						unsecuredLoanOfferFanoutRequest.put("principalName", PrincipalTypeEnum.DEFAULT.getValue());
						unsecuredLoanOfferFanoutRequest.put("sourceContext", "createApp");
						triggerOfferEvent("DEFAULT", PrincipalTypeEnum.DEFAULT, unsecuredLoanOfferFanoutRequest);
					}
					
					//Null check added for lead boost
					if(null != application.getProfession()){
						Reference ocupationType = new Reference();
						ocupationType.setKey(application.getProfession().getKey());
						ocupationType.setCode(application.getProfession().getCode());
						ocupationType.setValue(application.getProfession().getValue());
						JSONObject professionObject = new JSONObject();
						professionObject.put("ocupationType", ocupationType);
						String jsonProfessionRequest = CreditBusinessHelper.objectToJson(professionObject);
						creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateprofession, String.class, params, jsonProfessionRequest, headers);
					}

					Long applicantKey = getApplicant(application.getMobileNumber(), application.getDateOfBirth(), headers);
					
					if(null != applicantKey) {
						updateApplicant(applicationKey, applicantKey, headers);					
					}
					
					Boolean applicationPrePopulated = false;
							
					try {
						OfferApiRequest offerApiRequest = new OfferApiRequest();
						offerApiRequest.setMobileNo(application.getMobileNumber());
						offerApiRequest.setDob(application.getDateOfBirth());
						if(null != application.getProfession()){
							offerApiRequest.setProductCode(application.getProfession().getCode());
							offerApiRequest.setOccupationTypeKey(application.getProfession().getKey().toString());
						}
						offerApiRequest.setApplicationKey(applicationKey.toString());
						offerApiRequest.setApplicationUserAttributeKey(userProfile.getApplicationUserAttributeKey());
						
						if(offeredCase)
							offerApiRequest.setOfferId(application.getOfferId());
						
						offerApiRequest.setPan(userProfile.getPanNumber());
						offerApiRequest.setL2ProductCode(application.getProductCode());
						ApplicantDataBean applicantDataBean = new ApplicantDataBean();
						applicantDataBean.setHeaders(headers);
						applicantDataBean.setProductCode(application.getProductCode());
						applicantDataBean.setProductKey(application.getProductKey());
						applicantDataBean.setOfferApiRequest(offerApiRequest);
						applicantDataBean.setApplicantKey(null != applicantKey ? applicantKey.toString() : null);
						if(null != application.getProfession()){
							applicantDataBean.setOccupationType(application.getProfession().getCode());
						}
						applicantDataBean.setHlProductIntent(null != application.getHlProductIntent() ? application.getHlProductIntent().getCode() : null);
						applicationPrePopulated = offerDataSourceHandler.process(applicantDataBean);
						logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
								"inside CreditBusinessServiceImpl - createCreditApplication method for application " + applicationKey
										+ " - applicationPrePopulated " + applicationPrePopulated);
					
					} catch(Exception e) {
						logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
								"inside CreditBusinessServiceImpl - createCreditApplication method for application " + applicationKey
										+ " - datasource call failed " + e);
					}

					JSONObject stageJsonObject = new JSONObject();
					stageJsonObject.put("percentageCompletion", 10);
					String jsonStageRequest = CreditBusinessHelper.objectToJson(stageJsonObject);

					creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateStages, String.class, params, jsonStageRequest, headers);
					
					//Publish RBL Lead boost event
					if(!StringUtils.isEmpty(application.getProductCode()) 
							&& !CreditBusinessConstants.PRODUCT_CODE_CC.equalsIgnoreCase(application.getProductCode()) 
							&& application.getProfession()!=null) {
						try {
							RBLEvent rblEvent = new RBLEvent();
							rblEvent.setApplicationId(String.valueOf(application.getApplicationKey()));
							rblEvent.setMob(application.getMobileNumber());
							rblEvent.setDob(application.getDateOfBirth());
							String utmSource = "LEAD_BOOST";
							if(!StringUtils.isEmpty(application.getProductCode()))
								utmSource += "_" + application.getProductCode();
							rblEvent.setUtmSource(utmSource);
							rblEvent.setProfession(application.getProfession());
							rblEvent.setProductCode(CreditBusinessConstants.PRODUCT_CODE_CC);
							rblEvent.setPrincipalName(PrincipalTypeEnum.RBL.getValue());

							EventMessage eventMessage = eventMessageHelper.createEventMessage(CreditBusinessConstants.PRODUCT_CODE_CC, rblEvent,
									PrincipalTypeEnum.RBL);
							publisherService.publish(topicArn, eventMessage); 
							logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Message published for Non-CC - " + eventMessage);
						}catch(Exception e) {
							logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occured while publishing RBL Lead boost event ", e);
						}
						
					} 
					if (!httpServletRequest.isUserInRole(Role.SYSTEMPARTNER)) {
						LeadRequest leadRequest = new LeadRequest();
						Map<String, String> leadBoostHeaders = new HashMap<>();
						Map<String, String> messageFilterAttributes = new HashMap<String, String>();
						
						//payload
						leadRequest.setDateOfBirth(application.getDateOfBirth());
						leadRequest.setMobile(application.getMobileNumber());
						leadRequest.setProfession(application.getProfession());
						leadRequest.setProductCode(application.getProductCode());
						
						//header
						leadBoostHeaders.put(AUTH_TOKEN, customHeader.getAuthtoken());
						leadBoostHeaders.put("utm_source", "Corss-Sell");
						leadBoostHeaders.put("utm_medium", "LEAD_BOOST_" + application.getProductCode());
						
						//filter attributes
						messageFilterAttributes.put(LEAD_BOOST_QUEUE_FILTER_ATTRB, LEAD_BOOST_EVENT_FILTER);
						
						//event message
						EventMessage eventMessage = new EventMessage();
						eventMessage.setEventName(CreditBusinessConstants.OMPL_LEAD_BOOST_EVENT_NAME);
						eventMessage.setEventType(CreditBusinessConstants.OMPL_LEAD_BOOST_EVENT_TYPE);
						eventMessage.setMessageFilterAttributes(messageFilterAttributes);
						eventMessage.setPayload(leadRequest);
						eventMessage.setHeaders(leadBoostHeaders);
						
						publisherService.publish(topicArn, eventMessage);
					}

					// Publish event message for productCode "CC" or non CC.
					principalRequest.setUserAttributeKey(userProfile.getApplicationUserAttributeKey());
					publishCreateEventMessage(application.getProductCode(), principalRequest);

					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Application Pre-populated: " + applicationPrePopulated + " is offered case: " + offeredCase);
					if(otpAuthorizationRequired && ( ( applicationPrePopulated && !offeredCase && !isAuthorizedApplication(applicationKey, offeredCase) )
							|| ( UNSECURED_LOAN == application.getProductKey() && !offeredCase 
								&& !isAuthorizedApplication(applicationKey, offeredCase) )
							|| ( UNSECURED_LOAN == application.getProductKey() && campaignOtpRequired && offeredCase 
									&& !isAuthorizedApplication(applicationKey, offeredCase)))) {
						ApplicationResume applicationResume = new ApplicationResume();
						applicationResume.setApplicationKey(applicationKey.toString());
						applicationResume.setL2ProductCode(application.getProductCode());
						applicationResume.setL2ProductKey(application.getProductKey());
						applicationResume.setMobile(application.getMobileNumber());
						applicationResume.setOfferDetails(getOffersWithOfferPriorityOne(applicationKey.toString()));
						applicationResume.setDateofbirth(application.getDateOfBirth());
						
						nextTask.setNextTaskKey("otpscreen");
						
						applicationResponse.setNextTask(nextTask);
						applicationResponse.setPayload(applicationResume);
						
						// replace authtoken of request header in the response header to avoid exposing the pseudo token
						customHeader.setAuthtoken(requestAuthToken);
						updateApplicationIdInSession(applicationKey);
					} else if(!httpServletRequest.isUserInRole(Role.SYSTEMPARTNER)){//Activiti not to start for SYSTEMPARTNER/Lead boost
						payload.put(CreditBusinessConstants.REQUEST, application);
						setUserRoleAndValidateSession(applicationKey);
						if (null == application.getFldgApplication() || !application.getFldgApplication())
							nextTask = workflowHelper.startActivitiProcess(CreditBusinessConstants.CREDIT_JOURNEY, payload);
						else 
							nextTask = workflowHelper.startActivitiProcess(parentWorkflowProcessName, payload);
						applicationResponse.setNextTask(nextTask);
					}
				} catch (CreditBusinessException businessException) {
					throw businessException;
				} catch (Exception exception) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured in application creation flow with request: " + application, exception);
					throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "Some technical exception occurred while creating an application"));
				}
				
			} else if (ex.getCode().equals(HttpStatus.PARTIAL_CONTENT)) {
				throw ex;
			} else if (ex.getCode().equals(HttpStatus.EXPECTATION_FAILED)) {
				if(null != ex.getPayload() && ex.getPayload().toString().equalsIgnoreCase("Offer Not Exist")) {
					throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("CBS-102", "Resource not found."));
				}
				throw ex;
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Business exception from application fetch flow with request: " + application, ex);
				throw ex;
			}
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured in application/offer fetch flow with request: " + application, exception);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "Some technical exception occurred"));
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End createCreditApplication in serviceImpl");
		return applicationResponse;
	}

	private void setUserRoleAndValidateSession(Long applicationKey) {
		AuthenticatedUser currentAuthenticatedUser = (AuthenticatedUser) SecurityContextHolder.getContext() .getAuthentication().getPrincipal();
		UserDetails user = new AuthenticatedUser(currentAuthenticatedUser.getUserId(), customHeader.getAuthtoken(), "pcustomer", currentAuthenticatedUser.getAdditionalInfo());
		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(user, customHeader.getAuthtoken(), user.getAuthorities());
		SecurityContextHolder.getContext().setAuthentication(authentication); 
		applicationSessionManager.validateSession(httpServletRequest, applicationKey.toString(), false);
	}

	private Long getUTMSource(HttpHeaders headers) {
		Long utmSourceChannelMasterKey=null;
		ObjectMapper mapper1=new ObjectMapper();
		Map<String,String> param=new HashMap<>();
		try {
		if(!CollectionUtils.isEmpty(headers.get("utm_source"))) {
		String utmsource=headers.get("utm_source").get(0);
		param.put("utmSource",utmsource);
		mapper1.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				ResponseEntity<List<UtmSourceChannelBean>> utmSourceResponse = (ResponseEntity<List<UtmSourceChannelBean>>) creditBusinessHelper
						.invokeRestEndpoint(HttpMethod.GET, getUtmSourceKey, List.class, param, null, headers);
		  if(utmSourceResponse!=null) {
		  List<UtmSourceChannelBean> utmSourceList = mapper1.convertValue(utmSourceResponse.getBody(),
				new TypeReference<List<UtmSourceChannelBean>>() {
				});
		  for (UtmSourceChannelBean bean : utmSourceList) {
			utmSourceChannelMasterKey=bean.getUtmSourceChannelMasterKey();
		  }
		 }
		}
	  }catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Some techical error occured while calling utm reference data ", e);
	  }
		return utmSourceChannelMasterKey;
	}
	
	private void publishCreateEventMessage(String productcode, PrincipalRequest principalRequest) {

		try {
			if (null != principalRequest && CreditBusinessConstants.PRODUCT_CODE_CC.equalsIgnoreCase(productcode)) {

				EventMessage eventMessage = eventMessageHelper.createEventMessage(productcode, principalRequest, PrincipalTypeEnum.AXIS);
				publisherService.publish(topicArn, eventMessage);
				
				/*
				 * EventMessage eventMessageRBL =
				 * creditBusinessHelper.createEventMessage(productcode, principalRequest,
				 * PrincipalTypeEnum.RBL); publisherService.publish(topicArn, eventMessageRBL);
				 */
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Message published for CC - " + eventMessage);
			}
		} // As this should not impact the flow, used main EXCEPTION class here.
		catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Some techical error occured while PUBLISHING EVENT MESSAGE ", e);
		}
	}

	@Override
	public ProfileDetail getProfile(String applicationId,String source) {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside Service : Fetching profile details started." + applicationId);
		ProfileDetail profileDetail = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		Occupation occupation = null;
		Email persEmail = null;
		String appAttributeKey = null;
		Long maritalStatusKey = null;
		Long genderKey = null;
		Long occupationkey = null;
		DocumentDetails pan = null;
		StringBuilder fullname = new StringBuilder();
		Name name = null;
		if (!StringUtils.isNumeric(applicationId)) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Field validation exception.");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_020", "ApplicationId should be numeric."));
		}
		try {
			ObjectMapper mapper = new ObjectMapper();
			profileDetail = new ProfileDetail();
			Map<String, String> queryParam = new HashMap<String, String>();
			// For Name
			queryParam.put("applicationid", applicationId);
			String uri = null;
			UriComponents builder=null;
			builder = UriComponentsBuilder.fromHttpUrl(getUserProfiles)
					.queryParam("allApplicantRquired", true).build();
					uri = builder.toUriString();
			ResponseEntity<List<ProfDetail>> response = (ResponseEntity<List<ProfDetail>>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, uri, List.class, queryParam, null, headers);
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Response = " + response);
			List<ProfDetail> userProfileList = response.getBody();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			userProfileList = mapper.convertValue(response.getBody(), new TypeReference<List<ProfDetail>>() {
			});
			for (ProfDetail profDetail : userProfileList) {
				if (CreditBusinessConstants.EP.equals(source) && CreditBusinessConstants.APPLICANT_TYPE_TWO.equals(profDetail.getApplicationUserAttributeType())) {
					appAttributeKey = profDetail.getApplicationUserAttributeKey();
					name = profDetail.getName();
					maritalStatusKey = profDetail.getMaritalStatusKey();
					genderKey = profDetail.getGenderKey();
				}
				if (CreditBusinessConstants.JOURNEY.equals(source) && CreditBusinessConstants.APPLICANT_TYPE_ONE.equals(profDetail.getApplicationUserAttributeType())) {
					appAttributeKey = profDetail.getApplicationUserAttributeKey();
					name = profDetail.getName();
					maritalStatusKey = profDetail.getMaritalStatusKey();
					genderKey = profDetail.getGenderKey();
				}
			}
			if (!StringUtils.isBlank(name.getFirstName())) {
			fullname.append(name.getFirstName());
			if (!StringUtils.isBlank(name.getMiddleName())) {
				fullname.append(" ").append(name.getMiddleName());
			}
				if (!StringUtils.isBlank(name.getLastName())) {
					fullname.append(" ").append(name.getLastName());
				}
			profileDetail.setName(fullname.toString());
			}

			// For Marital key code value
			ResponseEntity<List<MaritalStatus>> getmaritalStatusResponse = (ResponseEntity<List<MaritalStatus>>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, getmaritalStatusURL, List.class, queryParam, null, headers);
			List<MaritalStatus> maritalStatusList = getmaritalStatusResponse.getBody();
			maritalStatusList = mapper.convertValue(getmaritalStatusResponse.getBody(), new TypeReference<List<MaritalStatus>>() {
					});
			for (MaritalStatus marStatus : maritalStatusList) {
				if ((marStatus.getMaritalStatusKey()).equals(maritalStatusKey)) {
					if(CreditBusinessConstants.MARITAL_STATUS_M.equals(marStatus.getMaritalStatusCode()) || CreditBusinessConstants.MARITAL_STATUS_S.equals(marStatus.getMaritalStatusCode())) {
						profileDetail.setMaritalStatus(marStatus);
					} else {
						MaritalStatus maritalStatus = new MaritalStatus();
						maritalStatus.setMaritalStatusKey(CreditBusinessConstants.MARITAL_STATUS_M_KEY);
						maritalStatus.setMaritalStatusCode(CreditBusinessConstants.MARITAL_STATUS_M);
						maritalStatus.setMaritalStatusValue(CreditBusinessConstants.MARRIED);
						profileDetail.setMaritalStatus(maritalStatus);
					}
				}
			}
			// For Gender key code value
			ResponseEntity<List<Gender>> getgenderResponse = (ResponseEntity<List<Gender>>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					getgenderURL, List.class, queryParam, null, headers);
			List<Gender> genderList = getgenderResponse.getBody();
			genderList = mapper.convertValue(getgenderResponse.getBody(), new TypeReference<List<Gender>>() {
			});
			for (Gender gender : genderList) {
				if ((gender.getGenderKey()).equals(genderKey)) {
					if(CreditBusinessConstants.GENDER_M.equals(gender.getGenderCode()) || CreditBusinessConstants.GENDER_F.equals(gender.getGenderCode())) {
						profileDetail.setGender(gender);
					} else {
						Gender gender2 = new Gender();
						gender2.setGenderKey(CreditBusinessConstants.GENDER_KEY);
						gender2.setGenderCode(CreditBusinessConstants.GENDER_M);
						gender2.setGenderValue(CreditBusinessConstants.MALE);
						profileDetail.setGender(gender2);
					}
				}
			}
			
			if (!StringUtils.isEmpty(appAttributeKey)) {

				// For GSTNumber and BusinessPan
				queryParam.put("userattributekey", appAttributeKey);
				ResponseEntity<?> getOccupationResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getOccupationUrl, Object.class, queryParam,
						null, new HttpHeaders());
				occupation = mapper.convertValue(getOccupationResponse.getBody(), Occupation.class);
				
				// Occcupation Key Code Value
				ResponseEntity<List<OccupationDetail>> getOccupationKeyCodeValue = (ResponseEntity<List<OccupationDetail>>) creditBusinessHelper
						.invokeRestEndpoint(HttpMethod.GET, getOccupationDetailurl, List.class, queryParam, null, headers);
				List<OccupationDetail> occupationDetailList = getOccupationKeyCodeValue.getBody();
				occupationDetailList = mapper.convertValue(getOccupationKeyCodeValue.getBody(), new TypeReference<List<OccupationDetail>>() {
						});
				
				occupationkey = occupation.getOcupationType().getKey();
				String occupationCode = null; 
				for (OccupationDetail occupationDetail : occupationDetailList) {
					if ((occupationDetail.getOccupationKey()).equals(occupationkey)) {
						profileDetail.setOccupationType(occupationDetail);
						occupationCode = occupationDetail.getOccupationCode();
					}
				}
				
				if (null != occupation.getBusinessOwnerDetails()) {
					profileDetail.setBusinessPan(occupation.getBusinessOwnerDetails().getBusinessPan());
					profileDetail.setGstNumber(occupation.getBusinessOwnerDetails().getGstNumber());
					profileDetail.setNatureOfBusinessKey(occupation.getBusinessOwnerDetails().getNatureOfBusiness().getKey());
					profileDetail.setBusinessTypeKey(occupation.getBusinessOwnerDetails().getBusinessType().getKey());
					
					if (null != occupationCode && DOCTOR_SELF_EMPLOYED.getValue().equalsIgnoreCase(occupationCode)) {
						setDoctorCreditParameters(profileDetail, occupation.getBusinessOwnerDetails());
				}
				}

				if (null != occupation.getSalariedDetail()) {
					profileDetail.setEmployerType(occupation.getSalariedDetail().getEmployerType());
					profileDetail.setOtherEmployerName(occupation.getSalariedDetail().getEmployerNameOther());

					EmployerNameDetail employerDetails = new EmployerNameDetail();
					employerDetails.setEmployerNameKey(occupation.getSalariedDetail().getEmployerName().getKey());
					employerDetails.setEmployerNameCode(occupation.getSalariedDetail().getEmployerName().getCode());
					employerDetails.setEmployerNameValue(occupation.getSalariedDetail().getEmployerName().getValue());
					profileDetail.setEmployerName(employerDetails);
					
					if (null != occupationCode && DOCTOR_SALARIED.getValue().equalsIgnoreCase(occupationCode)) {
						setDoctorCreditParameters(profileDetail, occupation.getSalariedDetail());
				}
					}

				// For Pan
				try {
					ResponseEntity<?> getPanResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getDocumentUrl, Object.class, queryParam, null,
							new HttpHeaders());
				pan = mapper.convertValue(getPanResponse.getBody(), DocumentDetails.class);
				profileDetail.setPan(pan.getDocumentNumber());
				} catch (Exception e) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception Occurred while calling application service for pan." + e);
				}

				// For PersonalEmailId
				try {
					persEmail = apiCallsHelper.getEmail(applicationId, appAttributeKey, EmailTypeEnum.PERON1.getValue().toString());
				profileDetail.setPersonalEmailId(persEmail.getEmail());
				} catch (Exception e) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception Occurred while calling application service for personal email." + e);
				}
				
				ApplicationDetail applicationDetails = apiCallsHelper.getApplicationDetails(applicationId, headers);
				String l2productCode = applicationDetails.getL2ProductCode();
				if((profileDetail.getOccupationType().getOccupationCode().equalsIgnoreCase("CAICWA") || profileDetail.getOccupationType().getOccupationCode().equalsIgnoreCase("DOCSEMP")) && l2productCode.equalsIgnoreCase("OMPL")) {
					getAddressDetail(applicationId,appAttributeKey,headers,profileDetail);
				}
			}
		} catch (CreditBusinessException e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured : " + e);
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Resource Not Found. " + e);
				throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("CBS-102", "Resource not found."));
			}
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "CreditBusinessException occured while fetiching profile details : ", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Some techical error occured while fetching profile details ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-001", "Some techical error occured while fetching profile details"));
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside Service : Fetching profile details completed successfully." + applicationId);
		return profileDetail;
	}

	private void setDoctorCreditParameters(ProfileDetail profileDetail, BusinessOwnerDetails businessOwnerDetails) {
		Reference qualification = businessOwnerDetails.getQualification();
		if(null != qualification && null != qualification.getKey()) {
			setCounsilAndDentalFlags(profileDetail, qualification);
		}
		profileDetail.setHospitalNameOther(businessOwnerDetails.getHospitalNameOther());
		profileDetail.setDoctorRegistrationNumber(businessOwnerDetails.getDoctorRegistrationNumber());
		
		if(null != businessOwnerDetails.getHospital() && null != businessOwnerDetails.getHospital().getKey()) {
			MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
			queryParams.add("hospitalKey", businessOwnerDetails.getHospital().getKey().toString());
			profileDetail.setHospital(apiCallsHelper.getReference(ReferenceOf.HOSPITAL, queryParams, null));
		}
		if(null != businessOwnerDetails.getRegCouncil() && null != businessOwnerDetails.getRegCouncil().getKey()) {
			MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
			queryParams.add("rcMasterkey", businessOwnerDetails.getRegCouncil().getKey().toString());
			profileDetail.setRegCouncil(apiCallsHelper.getReference(ReferenceOf.REGISTRATION_COUNSIL, queryParams, null));
		}
	}
	
	private void setDoctorCreditParameters(ProfileDetail profileDetail, SalariedDetail salariedDetails) {
		Reference qualification = salariedDetails.getQualification();
		if(null != qualification && null != qualification.getKey()) {
			setCounsilAndDentalFlags(profileDetail, qualification);
		}
		profileDetail.setHospitalNameOther(salariedDetails.getHospitalNameOther());
		profileDetail.setDoctorRegistrationNumber(salariedDetails.getDoctorRegistrationNumber());
		
		if(null != salariedDetails.getHospital() && null != salariedDetails.getHospital().getKey()) {
			MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
			queryParams.add("hospitalKey", salariedDetails.getHospital().getKey().toString());
			profileDetail.setHospital(apiCallsHelper.getReference(ReferenceOf.HOSPITAL, queryParams, null));
		}
		if(null != salariedDetails.getRegCouncil() && null != salariedDetails.getRegCouncil().getKey()) {
			MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
			queryParams.add("rcMasterkey", salariedDetails.getRegCouncil().getKey().toString());
			profileDetail.setRegCouncil(apiCallsHelper.getReference(ReferenceOf.REGISTRATION_COUNSIL, queryParams, null));
		}
	}
	
	private void setCounsilAndDentalFlags(ProfileDetail profileDetail, Reference qualification) {
		boolean isCounsilDetailRequired = true;
		boolean isDentalDegree = false;
		Reference qualificationReference = apiCallsHelper.getReference(ReferenceOf.QUALIFICATION, null,
				getReference(qualification.getKey(), null, null));
		if (null != qualificationReference && null != qualificationReference.getCode()) {
			if (degreesToSkipRegNumberCapture.contains(qualificationReference.getCode())) {
				isCounsilDetailRequired = false;
			}
			if (dentalDegrees.contains(qualificationReference.getCode())) {
				isDentalDegree = true;
			}
		}
		profileDetail.setIsCounsilDetailRequired(isCounsilDetailRequired);
		profileDetail.setIsDentalDegree(isDentalDegree);
	}
	
	public void getAddressDetail(String applicationId, String appAttributeKey, HttpHeaders headers,
			ProfileDetail profileDetail) {
		ObjectMapper mapper = new ObjectMapper();
		Address officialAddress = null;
		PinCodeServiceableMasterData pincodeSewrviceableMasterData = null;
		Map<String, String> param = new HashMap<>();
		Map<String, String> queryParam = new HashMap<String, String>();
		param.put("applicationid", applicationId);
		param.put("userattributekey", appAttributeKey);
		param.put("typeKey", AddressTypeEnum.CURRENT.getValue());
		try {
			Address currentAddress = apiCallsHelper.getAddress(headers, param);
			queryParam.put("pincodeKey", currentAddress.getPincodeKey());
			if (profileDetail.getOccupationType().getOccupationCode().equalsIgnoreCase("CAICWA")) {
				String productKey = "13";
				queryParam.put("productKey", productKey);
			} else if (profileDetail.getOccupationType().getOccupationCode().equalsIgnoreCase("DOCSEMP")) {
				String productKey = "12";
				queryParam.put("productKey", productKey);
			}
			
			try {
				ResponseEntity<?> getPincodeSewrviceableMasterData = creditBusinessHelper
						.invokeRestEndpoint(HttpMethod.GET, getPincodeUrl, Object.class, queryParam, null, headers);
				pincodeSewrviceableMasterData = mapper.convertValue(getPincodeSewrviceableMasterData.getBody(),
						PinCodeServiceableMasterData.class);
			} catch (CreditBusinessException e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Exception Occurred while fetching oglFlag for applicationId" + applicationId + " Exception "
								+ e);
			}
			 
			if (pincodeSewrviceableMasterData != null) {
				if (pincodeSewrviceableMasterData.isOglFlg() == true) {
					Map<String, String> paramForOfficePinCode = new HashMap<>();
					Reference officialPinCode = new Reference();
					profileDetail.setOfficePinCodeRequired(true);
					paramForOfficePinCode.put("applicationid", applicationId);
					paramForOfficePinCode.put("userattributekey", appAttributeKey);
					paramForOfficePinCode.put("typeKey", AddressTypeEnum.OFFICE.getValue());
					try {
					 officialAddress = apiCallsHelper.getAddress(headers, paramForOfficePinCode);
					}catch(Exception e) {
						logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
								"Exception Occurred while getting address for applicationId." + applicationId);
					}
					if (officialAddress != null) {
						officialPinCode.setKey(Long.valueOf(officialAddress.getPincodeKey()));
						officialPinCode.setCode(null);
						officialPinCode.setValue(officialAddress.getPincode());
						profileDetail.setOfficePinCode(officialPinCode);
					} else {
						logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
								" official address are null for applicationId." + applicationId);
					}
				} else {
					profileDetail.setOfficePinCodeRequired(false);
				}
			} else {
				profileDetail.setOfficePinCodeRequired(false);
			}
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Exception Occurred while calling application service for current address." + e);
		}
	}
	/**
	 * 
	 */
	@Override
	public Application getApplication(String applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start getApplication in service for applicationid : " + applicationId);
		Application application = new Application();
		Reference profession = new Reference();
		Gson gson = new Gson();
		if (!StringUtils.isNumeric(applicationId)) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Field validation exception.");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_020", "ApplicationId should be numeric."));
		}
		try {
			// getuserattributekey
			Map<String, String> params = new HashMap<>();
			params.put(CreditBusinessConstants.APPLICATION_ID, applicationId);
			ResponseEntity<?> userProfileResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getUserProfiles, List.class, params, null, headers);

			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			List<UserProfileBean> userProfileList = mapper.convertValue(userProfileResponse.getBody(),
					new TypeReference<List<UserProfileBean>>() {
					});
			for (UserProfileBean userProfile : userProfileList) {
				if (userProfile.getApplicationUserAttributeType().equals("1")) {
					application.setDateOfBirth(userProfile.getDateOfBirth());
					application.setMobileNumber(userProfile.getMobile());
					params.put("userattributekey", userProfile.getApplicationUserAttributeKey());
					params.put(CreditBusinessConstants.DATE_OF_BIRTH, userProfile.getDateOfBirth());
					params.put(CreditBusinessConstants.MOBILE, userProfile.getMobile());
				}
			}
			// fetch profession
			ResponseEntity<?> professionResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getProfession, String.class, params, null, headers);
			JSONObject response = gson.fromJson((String) professionResponse.getBody(), JSONObject.class);
			JSONObject occupationType = CreditBusinessHelper.getJSONObject(response.get("ocupationType"));
			Long occupationTypeKey = Long.valueOf((String.format("%.0f", occupationType.get(CreditBusinessConstants.KEY))));
			profession.setKey(occupationTypeKey);
			ResponseEntity<?> professionReferenceDataResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getProfessionReferenceData, List.class,
					params, null, headers);
			List<OccupationReference> occupationReferenceList = mapper.convertValue(professionReferenceDataResponse.getBody(),
					new TypeReference<List<OccupationReference>>() {
					});
			for (OccupationReference occupationReference : occupationReferenceList) {
				if (occupationTypeKey.equals(occupationReference.getOccupationKey())) {
					profession.setCode(occupationReference.getOccupationCode());
					profession.setValue(occupationReference.getOccupationValue());
				}
			}
			application.setProfession(profession);
			// fetch applicationProduct
			ResponseEntity<?> getApplicationProductResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getApplicationProduct, String.class,
					params, null, headers);
			JSONObject payload = gson.fromJson((String) getApplicationProductResponse.getBody(), JSONObject.class);

			application.setProductCode(payload.get("l2ProductCode").toString());
			application.setProductKey(Integer.valueOf(String.format("%.0f", (payload.get("l2ProductKey")))));
			
			//fetch HLProductIntent
			fetchHlProductIntent(application,payload);
			updateApplicationIdInSession(Long.valueOf(applicationId));

		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while fetching application details for landing page ", e);
			throw e;
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End getApplication in service for applicationid : " + applicationId);
		return application;
	}

	private void fetchHlProductIntent(Application application, JSONObject payload) {
		if(null != payload.get("hlProductIntent")) {
			LookupCodeValuesResponseBean lookupCodeValuesResponseBean = masterDataRedisClientHelper.getLookupValueByLookupCodeAndSortTxt("HLPRODUCTINTENT",
					payload.get("hlProductIntent").toString());
			if (null != lookupCodeValuesResponseBean) {
				application.setHlProductIntent(getReference(lookupCodeValuesResponseBean.getKey().longValue(),lookupCodeValuesResponseBean.getCode(),
						lookupCodeValuesResponseBean.getValue()));
			}
		}
	}
	
	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;

	}

@Override
	public ApplicationInfo getApplicationInfo(String applicationId, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start getApplicationInfo in service for applicationid : " + applicationId);
		ApplicationInfo applicationInfo = new ApplicationInfo();
		Name name=null;
		StringBuilder fullname = new StringBuilder();
		if (!StringUtils.isNumeric(applicationId)) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Field validation exception.");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_020", "ApplicationId should be numeric."));
		}
		try {
			Map<String, String> params = new HashMap<>();
			params.put(CreditBusinessConstants.APPLICATION_ID, applicationId);
			ResponseEntity<?> userProfileResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getUserProfiles, List.class, params, null, headers);

			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			List<UserProfileBean> userProfileList = mapper.convertValue(userProfileResponse.getBody(), new TypeReference<List<UserProfileBean>>() {
					});
			for (UserProfileBean userProfileBean : userProfileList) {
				if (userProfileBean.getApplicationUserAttributeType().equals("1")) {
					applicationInfo.setDateOfBirth(userProfileBean.getDateOfBirth());
					applicationInfo.setMobile(userProfileBean.getMobile());
					applicationInfo.setPanNumber(userProfileBean.getPanNumber());
					name=userProfileBean.getName();
					if (!StringUtils.isBlank(name.getFirstName())) {
						fullname.append(name.getFirstName());
						if (!StringUtils.isBlank(name.getMiddleName())) {
							fullname.append(" ").append(name.getMiddleName());
						}
							if (!StringUtils.isBlank(name.getLastName())) {
								fullname.append(" ").append(name.getLastName());
							}
							applicationInfo.setName(fullname.toString());
						}
					
				}
			}
		 
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occured while fetching application details for Esign page ", e);
			throw e;
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End getApplicationInfo in service for applicationid : " + applicationId);
		return applicationInfo;
	}
	
	@SuppressWarnings("unchecked")
	private Long getApplicant(String mobileNumber, String dateOfBirth, HttpHeaders headers) {
		try {
			Map<String, String> params = new HashMap<>();
			params.put(CreditBusinessConstants.DATE_OF_BIRTH, dateOfBirth);
			params.put(CreditBusinessConstants.MOBILE, mobileNumber);
			
			ResponseEntity<?> applicantResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getApplicantUrl, String.class, params, null, headers);
			Gson gson = new Gson();
			JSONObject payload = gson.fromJson((String) applicantResponse.getBody(), JSONObject.class);

			if (null != payload && null !=  payload.get(CreditBusinessConstants.APPLICANTKEY)) {
				 double applicantId = (Double) payload.get(CreditBusinessConstants.APPLICANTKEY);
				 return Math.round(applicantId);
			}
			return null;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occured while getting applicant details", e);
			return null;
		}
	} 
		
	@SuppressWarnings("unchecked")
	private void updateApplicant(Long applicationKey, Long applicantKey, HttpHeaders headers) {
		try {
			Map<String, String> params = new HashMap<>();
			params.put(CreditBusinessConstants.APPLICATION_ID, applicationKey.toString());
			params.put(CreditBusinessConstants.APPLICANTID, applicantKey.toString());
			
			creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateApplicantUrl, String.class, params, null, headers);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occured while updating the applicant details ", e);
		}
	} 
	
	private void checkForOccupationAndOfferUpdate(Application request, Map<String, String> params, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "checkAndUpdateOccupation - start");
		//if(null != request.getProfession() && null != request.getProfession().getKey()) {
			try {
				params.put(APPLICATION_ID, request.getApplicationKey().toString());
				
				UserProfileBean userProfile = apiCallsHelper.getUserProfile(params);
				
				if(null != userProfile) {
					params.put("userattributekey", userProfile.getApplicationUserAttributeKey());
					
					OccupationReference occupationReference = apiCallsHelper.getOccupationValue(params);
					
					if(null != occupationReference) {
						if(!occupationReference.getOccupationKey().equals(request.getProfession().getKey())) {
							if(updateOccupation(request, params, headers)) {
								params.put(MOBILE, userProfile.getMobile());
								params.put(DATE_OF_BIRTH, userProfile.getDateOfBirth());
								
								fetchOfferWithUpdatedOccupation(request, params, headers);
							}
						} else {
							logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "User Not opted for occupation update");
						}
					}else if(occupationReference==null && null !=request.getMobileNumber() && null != request.getProfession()){//Lead Boost changes
						//diplayOccupationError=true;
						updateOccupation(request, params, headers);
					}else{
						logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Occupation reference not found");
						request.setMobileNumber(userProfile.getMobile());
						request.setDateOfBirth(userProfile.getDateOfBirth());
						//diplayOccupationError=true;
						throw new CreditBusinessException(HttpStatus.PARTIAL_CONTENT, request);//Lead Boost changes
						//throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("CBS-122", "Occupation not found!"));
					}
				} else {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "User profile not found for the application");
					throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("CBS-123", "Profile not found!"));
				}
			} catch (CreditBusinessException businessException) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Business Exception Occurred: " + businessException);
				if(HttpStatus.PARTIAL_CONTENT.equals(businessException.getCode())){
					throw businessException;
				}
				if(diplayOccupationError) {
					if(HttpStatus.NOT_FOUND.equals(businessException.getCode())) {
						throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("CBS-102", "Resource not found!"));
					}
					throw businessException;
				}
			} catch (AccessDeniedException accessDeniedException) {
				if(diplayOccupationError) {
					throw new CreditBusinessException(HttpStatus.FORBIDDEN, new ErrorBean("CBS-403", "Not Allowed for updating the occupation"));
				}
			} catch (Exception exception) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Technical Exception occurred: ", exception);
				if(diplayOccupationError) {
					throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "Internal Server Error"));
				}
			}
		//} else {
			// occupation update not required as occupation or key is null
		//}
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "checkAndUpdateOccupation - end");
	}
	
	@SuppressWarnings("unchecked")
	public boolean updateOccupation(Application request, Map<String, String> params, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "updateOccupation - start");
		boolean occupationUpdated = false;
		if (httpServletRequest.isUserInRole(Role.PSEUDO_CUSTOMER) || httpServletRequest.isUserInRole(Role.PSEUDO_VERIFIED_CUSTOMER)
				|| httpServletRequest.isUserInRole(Role.CUSTOMER) || httpServletRequest.isUserInRole(Role.EMPLOYEE)) {
			
			Reference ocupationType = new Reference();
			ocupationType.setKey(request.getProfession().getKey());
			ocupationType.setCode(request.getProfession().getCode());
			ocupationType.setValue(request.getProfession().getValue());
			JSONObject professionObject = new JSONObject();
			professionObject.put("ocupationType", ocupationType);
			
			String jsonProfessionRequest = CreditBusinessHelper.objectToJson(professionObject);
			
			ResponseEntity<String> response = (ResponseEntity<String>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateprofession, String.class,
					params, jsonProfessionRequest, headers);
			
			if(null != response && response.getStatusCode().equals(HttpStatus.CONFLICT)) {
				throw new CreditBusinessException(HttpStatus.CONFLICT, new ErrorBean("CBS-109", "Occupation update not allowed at the current stage!"));
			} else {
				occupationUpdated = true;
			}

		} else {
			throw new AccessDeniedException("Not allowed for occupation update");
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "updateOccupation - end");
		return occupationUpdated;
	}
	
	@SuppressWarnings("unchecked")
	private ApplicationResponse startActivitiWithResumeFlow(Application application) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "startActivitiWithResumeFlow - start");
		ApplicationResponse applicationResponse = new ApplicationResponse();
		NextTask nextTask = new NextTask();
		Object response = null;
		JSONObject payload = new JSONObject();
		payload.put(CreditBusinessConstants.APPLICATION_ID, application.getApplicationKey().toString());
		payload.put(CreditBusinessConstants.JOURNEY, CreditBusinessConstants.RESUME);
		payload.put(CreditBusinessConstants.PRODUCTCODE, application.getProductCode());
		payload.put(CreditBusinessConstants.REQUEST, application);
		
		nextTask = workflowHelper.startActivitiProcess(this.getParentProcessToStart(application), payload);
		if (null != nextTask
				&& !StringUtils.equals(CreditBusinessConstants.REDIRECT_TO_EMIC, nextTask.getNextTaskKey())) {
			response = workflowHelper.getFromExecutionMap(CreditBusinessConstants.APPLICATION_RESUME,
					nextTask.getProcessID());
		}
		applicationResponse.setNextTask(nextTask);
		applicationResponse.setPayload(response);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "startActivitiWithResumeFlow - end");
		return applicationResponse;
	}
	
	public List<ImpsRequestMetadata> getImpsDetails(String applicationKey, Integer bankAcctcatKey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR, "Inside getImpsDetails - Start");
		Gson gson = new Gson();
		HashMap<String, String> params = new HashMap<>();
		params.put("applicationid", applicationKey);
		UriComponentsBuilder builder=null;
		builder = UriComponentsBuilder.fromUriString(getImpsDetailsUrl).queryParam("bankAcctcatKey", bankAcctcatKey);
		String uri = builder.buildAndExpand(params).toString();
		//ImpsRequestMetadata impsRequestMetadata = new ImpsRequestMetadata();
		ImpsResponseMetadata impsResponseMetadata= null;
		List<ImpsRequestMetadata> impsRequestMetadataList = new ArrayList<>();
		try {
			ResponseEntity<?> impsDetails = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, uri, String.class, params, null, headers);
			if (impsDetails.getStatusCode().equals(HttpStatus.OK)) {
				ImpsRequestMetadata impsRequestMetadata = gson.fromJson(impsDetails.getBody().toString(), ImpsRequestMetadata.class);
				//impsRequestMetadataList = Arrays.asList(impsRequestMetada);
				//impsRequestMetadata = impsRequestMetadataList.get(0);				
				String jsonRequest = CreditBusinessHelper.objectToJson(impsRequestMetadata);
				ResponseEntity<?> verificationPostCall = creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, verificationUrl, String.class, null,
						jsonRequest, headers);
				try {
					if (null != verificationPostCall.getBody()) {
						logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Mapping response...");
						impsResponseMetadata = gson.fromJson(verificationPostCall.getBody().toString(), ImpsResponseMetadata.class);
						impsResponseMetadata.setBeneAccNo(impsRequestMetadata.getBeneAccNo());
						impsResponseMetadata.setApplicationBankDetKey(impsRequestMetadata.getApplicationBankDetKey());						
						String jsonImpsResponse = CreditBusinessHelper.objectToJson(impsResponseMetadata);
						creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, getImpsDetailsUrl, String.class, params, jsonImpsResponse, headers);
					}
				} catch (Exception e) {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while parsing response " + e);
					throw new CreditBusinessException(HttpStatus.NOT_FOUND,"");
				}
			} 
			
			else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Error occurred in getEmandateRegistrationDetails service call" + impsDetails.getBody().toString());
				throw new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("CBS-102", "Resource not found!"));
			}
		
		}catch (CreditBusinessException e) {
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error while fetching Application Details for applicationId == " + applicationKey);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("OMCB_022", "Error while fetching Application Details for"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.PROCESSOR,
				"Inside getEmandateRegistrationDetails - End. " + "Response String : " + impsRequestMetadataList.toString());
		
		return impsRequestMetadataList;
		
	}
	
	private ApplicationResponse checkApplicationExistenceAndResume(Application application, Map<String, String> params, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "checkApplicationExistenceAndResume - start");
		ApplicationResponse applicationResponse = new ApplicationResponse();
		NextTask nextTask = new NextTask();
		
		params.put(CreditBusinessConstants.DATE_OF_BIRTH, application.getDateOfBirth());
		params.put(CreditBusinessConstants.MOBILE, application.getMobileNumber());
		params.put("hlProductIntent", null != application.getHlProductIntent() ? application.getHlProductIntent().getCode() : null);
		params.put("productKey", application.getProductKey().toString());
		
		ResponseEntity<?> getApplicationsResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getApplications, List.class, params, null, headers);
		if (null != getApplicationsResponse && null != getApplicationsResponse.getBody()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "finding resumable app  -");
			nextTask.setNextTaskKey("otpscreen");
			applicationResponse.setNextTask(nextTask);
			Object resumableApp = null;
			List<Object> appList = (List<Object>) getApplicationsResponse.getBody();
			for (int i = 0; i < appList.size(); i++) {
				JSONObject applicationObject = CreditBusinessHelper.getJSONObject(appList.get(i));
				Boolean isResumable = null != applicationObject.get("inProcessing") ? (Boolean) applicationObject.get("inProcessing") : null;
				if (null != isResumable && isResumable) {
					applicationObject.put("resume", true);
					String applicationkey = applicationObject.get(PARENT_APPLICATION_KEY).toString();
					AppOfferDetBean appOffers = getOffersWithOfferPriorityOne(applicationkey);
					if(null!=appOffers) {
						applicationObject.put("offerDetails", CreditBusinessHelper.getJSONObject(appOffers));
					}
					resumableApp = applicationObject;
				}
			}
			if (resumableApp == null) {
				throw new CreditBusinessException(HttpStatus.NOT_FOUND, null);
			}
			applicationResponse.setPayload(resumableApp);
			
			Long parentApplication = Long.valueOf(((JSONObject) resumableApp).get(PARENT_APPLICATION_KEY).toString());
			updateApplicationIdInSession(parentApplication);
			
			if(isAuthorizedApplication(parentApplication, false)) {
				application.setApplicationKey(parentApplication);
				
				applicationSessionManager.validateSession(httpServletRequest, application.getApplicationKey().toString(), application.isOverrideCustomerSession());
				
				checkForOccupationAndOfferUpdate(application, params, headers);
				
				if(null != application.getHlProductIntent()) {
					Map<String,String> param = new HashMap<>();
					JSONObject productIntent = new JSONObject();
					productIntent.put("hlProductIntent", null != application.getHlProductIntent() ? application.getHlProductIntent().getCode() : null);
					param.put("applicationKey", application.getApplicationKey().toString());
					String productIntentRequest = CreditBusinessHelper.objectToJson(productIntent);
					creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, updateIntentUrl, String.class, param, productIntentRequest, headers);
				}
				
				return startActivitiWithResumeFlow(application);
			} else if (UNSECURED_LOAN == application.getProductKey()) {
				nextTask.setNextTaskKey("otpscreen");
				applicationResponse.setNextTask(nextTask);
			}
		}
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "checkApplicationExistenceAndResume - end");
		return applicationResponse;
	}

	private AppOfferDetBean getOffersWithOfferPriorityOne(String applicationKey) {
		List<AppOfferDetBean> offerDetails = apiCallsHelper.fetchOffers(applicationKey, null, new HttpHeaders());
			if (!CollectionUtils.isEmpty(offerDetails)) {
				List<AppOfferDetBean> appOfferDetails = offerDetails.stream()
						.filter(offerDet -> Objects.nonNull(offerDet.getOfferPriority()))
						.filter(offerDet -> offerDet.getOfferPriority().intValue() == 1)
						.collect(Collectors.toList());
				if(!CollectionUtils.isEmpty(appOfferDetails)) {
					return appOfferDetails.get(0);
				}
			}
		return null;
	}
	
	private void updateApplicationIdInSession(Long applicationId) {
		httpServletRequest.getSession().setAttribute(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME,
				applicationId.toString());

	}

	private boolean fetchCreateAppRequiredDataFromOffer(Application applicationRequest, Map<String, String> params, HttpHeaders headers) {
		boolean offerExist = false;
		
		try {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchCreateApplicationDataFromOffer - start");
			ResponseEntity<?> response = null;
			JSONObject offerResponse = null;
			
			switch(applicationRequest.getProductKey()) {
				case UNSECURED_LOAN:
					try {
					params.put("offerId", applicationRequest.getOfferId());
					params.put("l2ProductCode", applicationRequest.getProductCode());
					response = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getMobDobOfferURL, String.class, params, null, headers);
					if (null != response && null != response.getBody() && HttpStatus.OK.equals(response.getStatusCode())) {
						offerResponse = CreditBusinessHelper.getJSONObject(response.getBody());
						if(null != offerResponse) {
							applicationRequest.setMobileNumber(null != offerResponse.get("mobile") ? offerResponse.get("mobile").toString() : null);
							applicationRequest.setDateOfBirth(null != offerResponse.get("dob")
							? CreditBusinessHelper.dateFormatter(offerResponse.get("dob").toString(), bauDateFormat, omDateFormat)
							: null);
						
							OccupationReference occupationReference = apiCallsHelper.getOccupationMasterFromOccupationId(Long.parseLong(offerResponse.get("occupationkey").toString()));
							applicationRequest.setProfession(new Reference(occupationReference.getOccupationKey(), occupationReference.getOccupationCode(), occupationReference.getOccupationValue()));
							logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "occupationReference value ---> "+occupationReference.getOccupationKey() + " -- "+occupationReference.getOccupationCode()+" -- "+occupationReference.getOccupationValue());
						
							offerExist = true;
						}
					}else {
						logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside fetchCreateAppRequiredDataFromOffer - offer not found for offerid "+applicationRequest.getOfferId());
					}
					}catch(Exception e) {
						logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "inside fetchCreateAppRequiredDataFromOffer - offer not found for offerid "+applicationRequest.getOfferId());
					}
					break;
				case CARD:
					params.put("offerid", applicationRequest.getOfferId());
					response = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getMobDobCardOfferURL, String.class, params, null, headers);
					
					offerResponse = CreditBusinessHelper.getJSONObject(response.getBody());
					
					if(null != offerResponse) {
						applicationRequest.setMobileNumber(null != offerResponse.get("mobile") ? offerResponse.get("mobile").toString() : null);
						applicationRequest.setDateOfBirth(null != offerResponse.get("dob") ? offerResponse.get("dob").toString() : null);
						
					applicationRequest.setProfession(
							null != offerResponse.get("occupationType") ? BAUProductToOccupation.getOccupation(offerResponse.get("occupationType").toString())
									: null);
						
						offerExist = true;
					}
					break;
				case SECURED_LOAN:
					params.put("offerId", applicationRequest.getOfferId());
					response = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getMobDobLoanOfferURL, String.class, params, null, headers);
					
					offerResponse = CreditBusinessHelper.getJSONObject(response.getBody());
					
					if(null != offerResponse) {
						applicationRequest.setMobileNumber(null != offerResponse.get("mobile") ? offerResponse.get("mobile").toString() : null);
					applicationRequest.setDateOfBirth(null != offerResponse.get("dob")
							? CreditBusinessHelper.dateFormatter(offerResponse.get("dob").toString(), bauDateFormat, omDateFormat)
							: null);
						
					applicationRequest.setProfession(
							null != offerResponse.get("occupationType") ? BAUProductToOccupation.getOccupation(offerResponse.get("occupationType").toString())
									: null);
						
						offerExist = true;
					}
					break;
				default:
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Offer Fetch not defined for gived product");
					break;
			}
			
		} catch (CreditBusinessException businessException) {
			if(businessException.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Offer not exist");
				throw new CreditBusinessException(HttpStatus.EXPECTATION_FAILED, "Offer Not Exist");
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Business Exception Occurred while calling offer API", businessException);
				throw businessException;
			}
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Technical exception occurred while calling offer API", exception);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "Some technical exception occurred"));
		}
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchCreateApplicationDataFromOffer - end");
		return offerExist;
	}
	
	private void fetchOfferWithUpdatedOccupation(Application request, Map<String, String> params, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchOfferWithUpdatedOccupation - start");
		
		ApplicantDataBean processorDataBean = new ApplicantDataBean();
		OfferApiRequest offerRequest = new OfferApiRequest();
		offerRequest.setApplicationKey(params.get(APPLICATION_ID));
		offerRequest.setApplicationUserAttributeKey(params.get("userattributekey"));
		offerRequest.setDob(params.get(DATE_OF_BIRTH));
		offerRequest.setMobileNo(params.get(MOBILE));
		offerRequest.setProductCode(OMProductToBauProduct.getBauProd(request.getProfession().getCode()));
		offerRequest.setL2ProductCode(request.getProductCode());
		offerRequest.setOccupationTypeKey(request.getProfession().getKey().toString());
		offerRequest.setOfferId(request.getOfferId());
		processorDataBean.setOfferApiRequest(offerRequest);
		processorDataBean.setHeaders(headers);
		
		if(UNSECURED_LOAN == request.getProductKey()) {
			// fetch Offer
			OfferDetailsBean offerDetailsBean = prospectDataSource.initDataSource(processorDataBean);
			AppOfferDetBean appOffer = new AppOfferDetBean();
			appOffer.setApplicationKey(Long.valueOf(params.get(APPLICATION_ID)));
			appOffer.setOfferSrcKey(1l);
			appOffer.setDeactivateOffers(true);
			applicationClient.saveOffer(appOffer, processorDataBean);
			
			// update Offer
			if(!CollectionUtils.isEmpty(offerDetailsBean.getOffers())) {
				offerDetailsBean.getOffers().stream().forEach(offer -> {
					applicationClient.saveOffer(offer, processorDataBean);
				});
			} 
		}
		
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "fetchOfferWithUpdatedOccupation - end");
	}
	
	@SuppressWarnings("unchecked")
	private void bflExistingCustomerApiCheck(Long applicationKey, String mobile, String appattrbkey, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "bflExistingCustomerApiCheck - start");
		JSONObject extCustRequest= new JSONObject();
		extCustRequest.put("appattrbkey", appattrbkey);
		extCustRequest.put("applicationId", applicationKey);
		extCustRequest.put("mobile", mobile);
		String requestStr = CreditBusinessHelper.objectToJson(extCustRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Asynch call to BFL Existing Customer API with request = "+requestStr);
		asynchRestHelper.invokeAsynchRestEndpoint(HttpMethod.PUT, extCustomerCheckUrl, Object.class, null, requestStr, headers,
				new CustomDefaultHeaders(customHeader));
	}
	@Override
	public void updateProfileDetails(String applicationid, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "In updateProfileDetails method for applicationid : "+applicationid);
		String source = CreditBusinessConstants.EP;
		ProfileDetails profileDetails = new ProfileDetails();
		ApplicationDetail application = apiCallsHelper.getApplicationDetails(applicationid, headers);
		ProfileDetail profile = getProfile(applicationid,source);
		profileDetails.setPan(profile.getPan());
		profileDetails.setOccupation(profile.getOccupationType().getOccupationCode());
		profileDetails.setPersonalEmailId(profile.getPersonalEmailId());	
		eventMessageHelper.publishBMR1Event(application, profileDetails,source);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Out updateProfileDetails method");
	}
	
	private void triggerOfferEvent(String productCode, PrincipalTypeEnum principalTypeEnum, Object offerRequest){
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Input triggerOfferEvent method for productCode: "+ productCode+ " , principalTypeEnum : "+ principalTypeEnum + " , offerRequest: "+ offerRequest);
		try {
			EventMessage eventMessage = eventMessageHelper.createEventMessage(productCode, offerRequest, principalTypeEnum);
			publisherService.publish(topicArn, eventMessage);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "TriggerOfferEvent method successful");
		} catch (Exception e) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception in triggerOfferEvent.");
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception in triggerOfferEvent",e);
		}
	}

	private String getParentProcessToStart(Application application) {		
		if (null != application.getProductCode()
				&& !application.getProductCode().equals(CreditBusinessConstants.PRODUCT_CODE_OMPL)
				|| !isSalaried(application)) {
			return CREDIT_JOURNEY;
		}
		ApplicationDetail appDetails = apiCallsHelper.getApplicationDetails(application.getApplicationKey().toString(),
				new HttpHeaders());
		String appProcessIdentifier = appDetails.getAppProcessIdentifier();

		if (null != application.getFldgApplication() && application.getFldgApplication()) {
			// from V2 API call
			if (null != appProcessIdentifier && !appProcessIdentifier.isBlank()
					&& parentWorkflowProcessName.equals(appProcessIdentifier)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Resume allowed with FLDG API for FLDG app with request: " + application);
				return parentWorkflowProcessName;
			} else {
				logger.warn(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Resume not allowed with FLDG API for non-FLDG app with request: " + application);
				throw new CreditBusinessException(HttpStatus.BAD_REQUEST,
						new ErrorBean(ERROR_CODE_OMCB_REDIRECT_V1, env.getProperty(ERROR_CODE_OMCB_REDIRECT_V1)));
			}
		} else {
			// from V1 API call
			if (null == appProcessIdentifier || appProcessIdentifier.isBlank()) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
						"Resume allowed with non-FLDG API for non-FLDG app with request: " + application);
				return CREDIT_JOURNEY;
			} else {
				ApplicationStageDetails appStageDetails = apiCallsHelper
						.getStageDetails(application.getApplicationKey().toString());
				Integer stagePercentage = appStageDetails.getPercentageCompletion();
				if (stagePercentage > 50) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Resume allowed with non-FLDG API for FLDG app having stage > 50");
					return parentWorkflowProcessName;
				} else {
					logger.warn(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"Resume not allowed with non-FLDG API for FLDG app with request: " + application);
					throw new CreditBusinessException(HttpStatus.BAD_REQUEST,
							new ErrorBean(ERROR_CODE_OMCB_REDIRECT_V2, env.getProperty(ERROR_CODE_OMCB_REDIRECT_V2)));
				}
			}
		}
	}

	private Boolean isSalaried(Application application) {
		Map<String, String> params = new HashMap<>();
		params.put(APPLICATION_ID, application.getApplicationKey().toString());
		UserProfileBean userProfile = apiCallsHelper.getUserProfile(params);
		Boolean isSalaried = false;
		if (null != userProfile) {
			params.put(CreditBusinessConstants.USERATTRIBUTEKEY, userProfile.getApplicationUserAttributeKey());
			OccupationReference occupationReference = apiCallsHelper.getOccupationValue(params);
			if (null != occupationReference && OccupationTypeEnum.SALARIED.getValue()
					.equalsIgnoreCase(occupationReference.getOccupationCode())) {
				isSalaried = true;
			}
		}
		return isSalaried;
	}
}