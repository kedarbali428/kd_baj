package com.bajaj.markets.credit.business.controller;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.CreditParameters;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.validator.OccupationValidatorClass;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants.Back;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessProfessionService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessProfessionController {

	@Autowired
	private Validator validator;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessProfessionService creditBusinessProfessionService;
	
	@Autowired
	Environment env;

	private static final String CLASS_NAME = CreditBusinessProfessionController.class.getCanonicalName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "This will submit the professional data to the running process", notes = "This will submit the professional data to the running process", httpMethod = "POST")
	@ApiImplicitParams({ @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Professional details saved successfully", response = ApplicationResponse.class),
			@ApiResponse(code = 422, message = "Invalid input parameters", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@PostMapping(path = "/v1/credit/applications/{applicationid}/creditparameters", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApplicationResponse> saveProfessionalDet(@PathVariable(value = "applicationid") String applicationId,
			@Valid @RequestBody CreditParameters creditParameters, BindingResult result, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Started saveProfessionalDet in controller with Request : " + creditParameters);

		if (null != creditParameters.getProfession() || !StringUtils.isEmpty(creditParameters.getAction())) {
			Set<ConstraintViolation<CreditParameters>> validationErrors = validator.validate(creditParameters,
					!StringUtils.isEmpty(creditParameters.getAction()) && creditParameters.getAction().equalsIgnoreCase("back") ? Back.class
							: this.getValidatorClass(creditParameters.getProfession()));

			if (!CollectionUtils.isEmpty(validationErrors)) {
				logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside saveProfessionalDet method - invalid parameters passed");
				String message = "";
				if (validationErrors.stream().findFirst().isPresent()) {
					message = validationErrors.stream().findFirst().get().getMessage();
				}
				throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_11", message));
			} else {
				ApplicationResponse applicationResponse = creditBusinessProfessionService.saveProfessionalDet(creditParameters, applicationId, headers);
				logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End saveProfessionalDet in controller with Response : ");
				return new ResponseEntity<>(applicationResponse, HttpStatus.CREATED);
			}
		} else {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside saveProfessionalDet method - invalid parameters passed");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_11", "profession detail is null or empty"));
		}

	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER })
	@ApiOperation(value = "This will get credit parameters.", notes = "This will get credit parameters for to and fro on application.", httpMethod = "GET")
	@ApiImplicitParams({ @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Fetch all credit parameters successfully.", response = CreditParameters.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@GetMapping(path = "/v1/credit/applications/{applicationid}/creditparameters", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CreditParameters> getProfessionalDet(@PathVariable(value = "applicationid") String applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Started getProfessionalDet in controller with Request : " + applicationId);
		CreditParameters creditParameters = creditBusinessProfessionService.getProfessionalDet(applicationId);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End getProfessionalDet in controller with Response : " + creditParameters);
		return new ResponseEntity<>(creditParameters, HttpStatus.OK);
	}
	
	private Class<?> getValidatorClass(Occupation profession) {
		if(null != profession && null != profession.getOcupationType() && !StringUtils.isEmpty(profession.getOcupationType().getCode())) {
			try {
				return OccupationValidatorClass.valueOf(profession.getOcupationType().getCode()).getOccupationValidatorClass();
			} catch(IllegalArgumentException | NullPointerException exception) {
				logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Invalid Occupation Type" + profession);
				throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_1001", env.getProperty("OMCB_1001")));
			}
		} else {
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("OMCB_1002", env.getProperty("OMCB_1002")));
		}
	}
}
