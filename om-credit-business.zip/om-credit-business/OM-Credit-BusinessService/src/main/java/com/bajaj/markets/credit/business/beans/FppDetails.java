package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.FppNotSelected;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.FppSelected;

public class FppDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private NextTask nextTask;
	private String action;

	@NotNull(groups = {FppNotSelected.class, FppSelected.class}, message = "fppSelected flag can not be null")
	private Boolean isFppSelected; 

	@Valid
	@NotNull(groups = FppSelected.class, message = "FPP Product Bundle can not be null")
	private FppBundleBean bundleData;

	@Valid
	@NotEmpty(groups = FppSelected.class, message = "Health question's answers can not be null or empty")
	private List<FppQuestionAnswer> questionAnswerList;

	@Valid
	@NotNull(groups = FppSelected.class, message = "Height & Weight are mandatory")
	private FppAtributes fppAttributeAtributes;

	public NextTask getNextTask() {
		return nextTask;
	}

	public String getAction() {
		return action;
	}

	public FppBundleBean getBundleData() {
		return bundleData;
	}

	public void setNextTask(NextTask nextTask) {
		this.nextTask = nextTask;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setBundleData(FppBundleBean bundleData) {
		this.bundleData = bundleData;
	}

	public List<FppQuestionAnswer> getQuestionAnswerList() {
		return questionAnswerList;
	}

	public FppAtributes getFppAttributeAtributes() {
		return fppAttributeAtributes;
	}

	public void setQuestionAnswerList(List<FppQuestionAnswer> questionAnswerList) {
		this.questionAnswerList = questionAnswerList;
	}

	public void setFppAttributeAtributes(FppAtributes fppAttributeAtributes) {
		this.fppAttributeAtributes = fppAttributeAtributes;
	}

	public Boolean getIsFppSelected() {
		return isFppSelected;
	}

	public void setIsFppSelected(Boolean isFppSelected) {
		this.isFppSelected = isFppSelected;
	}

	@Override
	public String toString() {
		return "FppDetails [nextTask=" + nextTask + ", action=" + action + ", isFppSelected=" + isFppSelected
				+ ", bundleData=" + bundleData + ", questionAnswerList=" + questionAnswerList
				+ ", fppAttributeAtributes=" + fppAttributeAtributes + "]";
	}
	
}