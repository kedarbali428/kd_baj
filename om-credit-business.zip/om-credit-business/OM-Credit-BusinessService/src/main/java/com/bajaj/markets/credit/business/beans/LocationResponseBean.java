package com.bajaj.markets.credit.business.beans;

public class LocationResponseBean {

	private Long pincodeKey;
	private String pincode;
	private Long cityKey;
	private String cityCode;
	private String cityName;
	private Long stateKey;
	private String StateCode;
	private String stateName;
	private Long countryKey;
	private String countryCode;
	private String countryName;
	private Integer pinNegativeAreaFlg;
	private Integer pinOglFlg;
	public Long getPincodeKey() {
		return pincodeKey;
	}
	public void setPincodeKey(Long pincodeKey) {
		this.pincodeKey = pincodeKey;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public Long getCityKey() {
		return cityKey;
	}
	public void setCityKey(Long cityKey) {
		this.cityKey = cityKey;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public Long getStateKey() {
		return stateKey;
	}
	public void setStateKey(Long stateKey) {
		this.stateKey = stateKey;
	}
	public String getStateCode() {
		return StateCode;
	}
	public void setStateCode(String stateCode) {
		StateCode = stateCode;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public Long getCountryKey() {
		return countryKey;
	}
	public void setCountryKey(Long countryKey) {
		this.countryKey = countryKey;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public Integer getPinNegativeAreaFlg() {
		return pinNegativeAreaFlg;
	}
	public void setPinNegativeAreaFlg(Integer pinNegativeAreaFlg) {
		this.pinNegativeAreaFlg = pinNegativeAreaFlg;
	}
	public Integer getPinOglFlg() {
		return pinOglFlg;
	}
	public void setPinOglFlg(Integer pinOglFlg) {
		this.pinOglFlg = pinOglFlg;
	}
	@Override
	public String toString() {
		return "LocationResponseBean [pincodeKey=" + pincodeKey + ", pincode=" + pincode + ", cityKey=" + cityKey
				+ ", cityCode=" + cityCode + ", cityName=" + cityName + ", stateKey=" + stateKey + ", StateCode="
				+ StateCode + ", stateName=" + stateName + ", countryKey=" + countryKey + ", countryCode=" + countryCode
				+ ", countryName=" + countryName + ", pinNegativeAreaFlg=" + pinNegativeAreaFlg + ", pinOglFlg="
				+ pinOglFlg + "]";
	}
	

}
