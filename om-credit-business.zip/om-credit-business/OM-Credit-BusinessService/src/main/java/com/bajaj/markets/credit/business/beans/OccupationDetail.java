package com.bajaj.markets.credit.business.beans;

public class OccupationDetail {
	
	private Long occupationKey;
	
	private String occupationCode;
	
	private String occupationValue;
	
	public Long getOccupationKey() {
		return occupationKey;
	}

	public void setOccupationKey(Long occupationKey) {
		this.occupationKey = occupationKey;
	}

	public String getOccupationCode() {
		return occupationCode;
	}

	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}

	public String getOccupationValue() {
		return occupationValue;
	}

	public void setOccupationValue(String occupationValue) {
		this.occupationValue = occupationValue;
	}
	

	@Override
	public String toString() {
		return "OccupationDetail [occupationKey=" + occupationKey + ", occupationCode=" + occupationCode
				+ ", occupationValue=" + occupationValue + "]";
	}

	
}

	


