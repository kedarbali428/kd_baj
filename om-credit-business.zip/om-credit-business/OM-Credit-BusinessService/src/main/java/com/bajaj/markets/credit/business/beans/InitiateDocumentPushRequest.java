package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotNull;

public class InitiateDocumentPushRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	List<AppDocumentTrackingBean> appDocumentTrackingBeanList;
	
	@NotNull(message = "principleKey cannot be null or empty")
	Long principleKey;

	String principleName;

	public List<AppDocumentTrackingBean> getAppDocumentTrackingBeanList() {
		return appDocumentTrackingBeanList;
	}

	public void setAppDocumentTrackingBeanList(List<AppDocumentTrackingBean> appDocumentTrackingBeanList) {
		this.appDocumentTrackingBeanList = appDocumentTrackingBeanList;
	}

	public Long getPrincipleKey() {
		return principleKey;
	}

	public void setPrincipleKey(Long principleKey) {
		this.principleKey = principleKey;
	}

	public String getPrincipleName() {
		return principleName;
	}

	public void setPrincipleName(String principleName) {
		this.principleName = principleName;
	}

	@Override
	public String toString() {
		return "InitiateDocumentPushRequest [appDocumentTrackingBeanList=" + appDocumentTrackingBeanList
				+ ", principleKey=" + principleKey + ", principleName=" + principleName + "]";
	}

}
