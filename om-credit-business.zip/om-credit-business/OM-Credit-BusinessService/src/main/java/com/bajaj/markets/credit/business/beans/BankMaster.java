package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class BankMaster implements Serializable{

	private Long bankMasterKey;
	private String bankCode;
	private String bankName;

	public Long getBankMasterKey() {
		return bankMasterKey;
	}

	public void setBankMasterKey(Long bankMasterKey) {
		this.bankMasterKey = bankMasterKey;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Override
	public String toString() {
		return "BankMaster [bankMasterKey=" + bankMasterKey + ", bankCode=" + bankCode + ", bankName=" + bankName + "]";
	}

}
