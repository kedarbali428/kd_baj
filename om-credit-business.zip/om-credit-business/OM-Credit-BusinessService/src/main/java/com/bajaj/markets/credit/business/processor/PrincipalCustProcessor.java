package com.bajaj.markets.credit.business.processor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;

@Component
public class PrincipalCustProcessor implements BaseProcessor {

	@Autowired
	ApplictionClient applictionClient;
	
	@Autowired
	BFLLoggerUtilExt logger;
     
	private static final String CLASSNAME = PrincipalCustProcessor.class.getName();
	
	private ThreadLocal<Boolean> principalCustInfoFlag = new ThreadLocal<Boolean>();
	
	@Override
	public boolean initDataCopy(List<OfferDetailsBean> dataCources, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside PrincipalCustProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		principalCustInfoFlag.set(false);
		try {
			dataCources.forEach(dataSource -> {
				if(!CollectionUtils.isEmpty(dataSource.getPrincipalCustomerDetails())){
					dataSource.getPrincipalCustomerDetails().forEach(principalCustomer -> {
						principalCustInfoFlag.set(applictionClient.savePrincipalCustomerInfo(principalCustomer, applicantDataBean));
					});
					
					if(principalCustInfoFlag.get()) {
						logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside PrincipalCustProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - PrincipalCustomer data processed for "+dataSource.getDataSourceName());
						throw new CreditBusinessException();
					} else {
						logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside PrincipalCustProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - PrincipalCustomer data not processed for "+dataSource.getDataSourceName());
					}
				}
			});
		} catch (CreditBusinessException exception) {
			return true;
		} catch(Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside PrincipalCustProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - PrincipalCustomer call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside PrincipalCustProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return false;
	}

}