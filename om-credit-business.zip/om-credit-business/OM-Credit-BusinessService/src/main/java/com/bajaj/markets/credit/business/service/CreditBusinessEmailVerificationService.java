package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.EmailDetails;

public interface CreditBusinessEmailVerificationService {

	public ApplicationResponse validateEmail(Long applicationId, EmailDetails emailDetails, HttpHeaders headers);
	
	public EmailDetails getEmailVerificationDetails(Long applicationId, HttpHeaders headers, String task);
}
