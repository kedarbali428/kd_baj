package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Business;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.CaIcwaSelfEmployed;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.DoctorSalaried;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.DoctorSelfEmployed;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Salaried;

public class ProfileDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2703536940790674848L;

	private String action;

	@NotNull(groups = { Salaried.class, Business.class, CaIcwaSelfEmployed.class, DoctorSalaried.class,
			DoctorSelfEmployed.class }, message = "Occupation cannot be null or empty")
	private String occupation;

	@Valid
	@NotNull(groups = { Salaried.class, Business.class, CaIcwaSelfEmployed.class, DoctorSalaried.class,
			DoctorSelfEmployed.class }, message = "Maritial Status can not be null or empty")
	private Reference maritalStatus;

	@Valid
	@NotNull(groups = { Salaried.class, Business.class, CaIcwaSelfEmployed.class, DoctorSalaried.class,
			DoctorSelfEmployed.class }, message = "Gender can not be null or empty")
	private Reference gender;

	@NotEmpty(groups = { Salaried.class, CaIcwaSelfEmployed.class, DoctorSalaried.class,
			DoctorSelfEmployed.class }, message = "PAN no. can not be null or empty")
	private String pan;

	private PinCodeDetails pinCode;

	@NotEmpty(groups = { Salaried.class, Business.class, CaIcwaSelfEmployed.class, DoctorSalaried.class,
			DoctorSelfEmployed.class }, message = "Personal Email can not be null or empty")
	private String personalEmailId;

	private String businessPan;

	private String gstNumber;

	private String applicationid;
	
	private boolean officePinCodeRequired;
	
	private Reference officePinCode;

	private Reference regCouncil;

	private String doctorRegistrationNumber;

	private Reference hospital;

	private String hospitalNameOther;
	
	public Reference getOfficePinCode() {
		return officePinCode;
	}

	public void setOfficePinCode(Reference officePinCode) {
		this.officePinCode = officePinCode;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Reference getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(Reference maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public Reference getGender() {
		return gender;
	}

	public void setGender(Reference gender) {
		this.gender = gender;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public PinCodeDetails getPinCode() {
		return pinCode;
	}

	public void setPinCode(PinCodeDetails pinCode) {
		this.pinCode = pinCode;
	}

	public String getPersonalEmailId() {
		return personalEmailId;
	}

	public void setPersonalEmailId(String personalEmailId) {
		this.personalEmailId = personalEmailId;
	}

	public String getBusinessPan() {
		return businessPan;
	}

	public void setBusinessPan(String businessPan) {
		this.businessPan = businessPan;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public Reference getRegCouncil() {
		return regCouncil;
	}

	public void setRegCouncil(Reference regCouncil) {
		this.regCouncil = regCouncil;
	}

	public String getDoctorRegistrationNumber() {
		return doctorRegistrationNumber;
	}

	public void setDoctorRegistrationNumber(String doctorRegistrationNumber) {
		this.doctorRegistrationNumber = doctorRegistrationNumber;
	}

	public Reference getHospital() {
		return hospital;
	}

	public void setHospital(Reference hospital) {
		this.hospital = hospital;
	}

	public String getHospitalNameOther() {
		return hospitalNameOther;
	}

	public void setHospitalNameOther(String hospitalNameOther) {
		this.hospitalNameOther = hospitalNameOther;
	}
	
	public boolean getOfficePinCodeRequired() {
		return officePinCodeRequired;
	}

	public void setOfficePinCodeRequired(boolean officePinCodeRequired) {
		this.officePinCodeRequired = officePinCodeRequired;
	}

	@Override
	public String toString() {
		return "ProfileDetails [action=" + action + ", occupation=" + occupation + ", maritalStatus=" + maritalStatus + ", gender=" + gender + ", pan=" + pan
				+ ", pinCode=" + pinCode + ", personalEmailId=" + personalEmailId + ", businessPan=" + businessPan + ", gstNumber=" + gstNumber
				+ ", applicationid=" + applicationid + ", regCouncil=" + regCouncil + ", doctorRegistrationNumber=" + doctorRegistrationNumber + ", hospital="
				+ hospital + ", hospitalNameOther=" + hospitalNameOther + "]";
	}
}
