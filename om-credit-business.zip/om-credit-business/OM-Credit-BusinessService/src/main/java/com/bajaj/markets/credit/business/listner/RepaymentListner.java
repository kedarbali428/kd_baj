package com.bajaj.markets.credit.business.listner;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;

@Component
public class RepaymentListner {

	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASS_NAME = RepaymentListner.class.getCanonicalName();
	
	public void setDefaultFlags(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start setDefaultFlags");
		if (null == execution.getVariable(CreditBusinessConstants.IS_EP_PRICING_APPROVED)) {
			execution.setVariable(CreditBusinessConstants.IS_EP_PRICING_APPROVED, false);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End setDefaultFlags");
	}
}
