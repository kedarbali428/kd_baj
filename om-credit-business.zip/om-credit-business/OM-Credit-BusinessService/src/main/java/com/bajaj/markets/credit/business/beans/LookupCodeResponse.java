package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class LookupCodeResponse {
	
	private List<LookupCodeValuesResponseBean> lookupValuesResponseList;

	public List<LookupCodeValuesResponseBean> getLookupValuesResponseList() {
		return lookupValuesResponseList;
	}

	public void setLookupValuesResponseList(List<LookupCodeValuesResponseBean> lookupValuesResponseList) {
		this.lookupValuesResponseList = lookupValuesResponseList;
	}

}
