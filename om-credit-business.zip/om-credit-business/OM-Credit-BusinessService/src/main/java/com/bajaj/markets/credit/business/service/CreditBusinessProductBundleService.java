package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.BundleReject;
import com.bajaj.markets.credit.business.beans.FppBundleBean;
import com.bajaj.markets.credit.business.beans.FppDetails;

public interface CreditBusinessProductBundleService {

	public FppBundleBean fetchFppBundle(String applicationId, HttpHeaders headers);

	public FppDetails saveFppBundle(FppDetails request, Long applicationId, HttpHeaders headers);

	public ApplicationResponse rejectBundle(BundleReject request, Long applicationId, HttpHeaders headers);

}
