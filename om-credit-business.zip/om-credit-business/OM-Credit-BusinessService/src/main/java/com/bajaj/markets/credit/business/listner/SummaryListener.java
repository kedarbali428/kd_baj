package com.bajaj.markets.credit.business.listner;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
public class SummaryListener {

	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = SummaryListener.class.getCanonicalName();

	public void postProductSummary(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postProductSummary");
		execution.setVariable(CreditBusinessConstants.KARZA_TYPE, 1);
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (request != null && request.get("action") != null) {
			if ("back".equalsIgnoreCase((String) request.get("action"))) {
				execution.setVariable(CreditBusinessConstants.APPLICATIONKEY, execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postProductSummary");
	}

}
