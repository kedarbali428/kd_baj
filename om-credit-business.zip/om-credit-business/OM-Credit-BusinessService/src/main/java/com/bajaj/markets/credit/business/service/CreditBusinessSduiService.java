package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.ApplicationResponse;

public interface CreditBusinessSduiService {

	public Object getUserTask(String applicationkey, String taskName, HttpHeaders headers);
	
	ApplicationResponse saveUserTaskContent(String applicationId, String taskName, Object userTaskContent,
			HttpHeaders headers);
}
