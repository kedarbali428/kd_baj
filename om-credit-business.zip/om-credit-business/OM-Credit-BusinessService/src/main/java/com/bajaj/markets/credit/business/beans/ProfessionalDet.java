package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

public class ProfessionalDet implements Serializable {

	private static final long serialVersionUID = 1122361701102372417L;

	private Reference education;

	private Reference profession;

	@NotNull(message = "Company name can not be null or empty")
	private Reference companyName;

	private Reference natureOfBussiness;

	private BigDecimal workExperience;

	private Long monthlySalary;

	@NotNull(message = "Official email address can not be null or empty")
	private Reference officialEmail;

	private Reference companyType;

	private String applicationid;

	private String nextTaskKey;

	public Reference getEducation() {
		return education;
	}

	public void setEducation(Reference education) {
		this.education = education;
	}

	public Reference getProfession() {
		return profession;
	}

	public void setProfession(Reference profession) {
		this.profession = profession;
	}

	public Reference getCompanyName() {
		return companyName;
	}

	public void setCompanyName(Reference companyName) {
		this.companyName = companyName;
	}

	public Reference getNatureOfBussiness() {
		return natureOfBussiness;
	}

	public void setNatureOfBussiness(Reference natureOfBussiness) {
		this.natureOfBussiness = natureOfBussiness;
	}

	public BigDecimal getWorkExperience() {
		return workExperience;
	}

	public void setWorkExperience(BigDecimal workExperience) {
		this.workExperience = workExperience;
	}

	public Long getMonthlySalary() {
		return monthlySalary;
	}

	public void setMonthlySalary(Long monthlySalary) {
		this.monthlySalary = monthlySalary;
	}

	public Reference getOfficialEmail() {
		return officialEmail;
	}

	public void setOfficialEmail(Reference officialEmail) {
		this.officialEmail = officialEmail;
	}

	public Reference getCompanyType() {
		return companyType;
	}

	public void setCompanyType(Reference companyType) {
		this.companyType = companyType;
	}

	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	public String getNextTaskKey() {
		return nextTaskKey;
	}

	public void setNextTaskKey(String nextTaskKey) {
		this.nextTaskKey = nextTaskKey;
	}

	@Override
	public String toString() {
		return "ProfessionalDet [education=" + education + ", profession=" + profession + ", companyName=" + companyName
				+ ", natureOfBussiness=" + natureOfBussiness + ", workExperience=" + workExperience + ", monthlySalary="
				+ monthlySalary + ", officialEmail=" + officialEmail + ", companyType=" + companyType
				+ ", applicationid=" + applicationid + ", nextTaskKey=" + nextTaskKey + "]";
	}


}
