package com.bajaj.markets.credit.business.listner;

import java.util.ArrayList;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
public class ProductListing {

	private static final String PRODUCT_LIST = "productList";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	private static final String CLASS_NAME = ProductListing.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void postGetProductListing(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start ProductListing");
		execution.setVariable(CreditBusinessConstants.FPPAPPLICABLE, false);
		execution.setVariable(CreditBusinessConstants.CV_REQUIRED, false);
		JSONObject output = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (output != null && output.get(PRODUCT_LIST) != null) {
			ArrayList<Map<String, Object>> productList = (ArrayList<Map<String, Object>>) output.get(PRODUCT_LIST);
			if (!CollectionUtils.isEmpty(productList)) {
				for (Map<String, Object> product : productList) {
					if (product.get(CreditBusinessConstants.FPPAPPLICABLE) != null
							&& Boolean.valueOf(product.get(CreditBusinessConstants.FPPAPPLICABLE).toString())) {
						execution.setVariable(CreditBusinessConstants.FPPAPPLICABLE, true);
					}

					if (product.get(CreditBusinessConstants.CV_REQUIRED) != null
							&& Boolean.valueOf(product.get(CreditBusinessConstants.CV_REQUIRED).toString())) {
						execution.setVariable(CreditBusinessConstants.CV_REQUIRED, true);
					}
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End ProductListing");
	}

	public void checkChildPresent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start checkChildPresent");
		execution.setVariable(CreditBusinessConstants.CHILDPRESENT, false);
		execution.setVariable(CreditBusinessConstants.ISINPROCESSING, true);
		if (execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID) != null) {
			execution.setVariable(CreditBusinessConstants.CHILDPRESENT, true);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End checkChildPresent");
	}

}
