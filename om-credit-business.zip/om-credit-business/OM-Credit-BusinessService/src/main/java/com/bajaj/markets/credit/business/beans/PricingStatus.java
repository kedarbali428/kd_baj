package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class PricingStatus {

	@NotBlank(message="approvalStatus can not be blank or null")
	@Pattern(regexp = "APPROVED|REJECTED", flags = Pattern.Flag.CASE_INSENSITIVE)
	private String approvalStatus;
	
	private BigDecimal approvedBy;
	
	private BigDecimal raisedBy;

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public BigDecimal getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(BigDecimal approvedBy) {
		this.approvedBy = approvedBy;
	}

	public BigDecimal getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(BigDecimal raisedBy) {
		this.raisedBy = raisedBy;
	}

}
