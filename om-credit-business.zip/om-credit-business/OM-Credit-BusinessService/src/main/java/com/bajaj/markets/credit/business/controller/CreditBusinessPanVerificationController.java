package com.bajaj.markets.credit.business.controller;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.constraints.Digits;
import javax.validation.groups.Default;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.PanValidationRequest;
import com.bajaj.markets.credit.business.beans.PanValidationResponse;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessPanVerificationService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessPanVerificationController {

	private static final String ERROR_CODE_OMCB_1150 = "OMCB-1150";

	private static final String CLASS_NAME = CreditBusinessPanVerificationController.class.getCanonicalName();

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private Environment env;

	@Autowired
	private Validator validator;

	@Autowired
	private CreditBusinessPanVerificationService creditBusinessPanVerificationService;

	@Secured(value = { Role.CUSTOMER, Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE })
	@ApiOperation(value = "Validate PAN and fetch name from the pan verification", notes = "Validate PAN and respond with name from pan verification if pan verified successfully. Also stamps pan number to the application attribute if verified successfully", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"), })
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "pan validated successfully", response = PanValidationResponse.class),
			@ApiResponse(code = 400, message = "bad request or invalid pan number or pan validation not successful", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "internal server error", response = ErrorBean.class), })
	@PostMapping(path = "/v2/credit/applications/{applicationId}/pan-verification", consumes = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<PanValidationResponse> validateAndUpdatePan(
			@PathVariable(name = "applicationId") @Digits(fraction = 0, integer = 19, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestBody PanValidationRequest panValidationRequest) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside- validateAndUpdatePan() - start with: " + applicationId);
		Set<ConstraintViolation<PanValidationRequest>> validationErrors = validator.validate(panValidationRequest,
				Default.class);
		if (!CollectionUtils.isEmpty(validationErrors)) {
			logger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"Invalid request for validateAndUpdatePan() - " + applicationId);
			Optional<ConstraintViolation<PanValidationRequest>> validationError = validationErrors.stream().findFirst();
			String errorMessage = validationError.isPresent() ? validationError.get().getMessage()
					: env.getProperty(ERROR_CODE_OMCB_1150);
			throw new CreditBusinessException(BAD_REQUEST, new ErrorBean(ERROR_CODE_OMCB_1150, errorMessage));
		} else {
			return new ResponseEntity<>(
					creditBusinessPanVerificationService.validateAndUpdatePan(applicationId, panValidationRequest),
					HttpStatus.CREATED);
		}
	}
}
