package com.bajaj.markets.credit.business.beans;

import java.math.BigDecimal;

public class PrincipalTransDetail {

	private String url1;
	private String url2;
	private String principleRefId2;
	private String lpStatusMessage;
	private Long loanamount;
	private Long tenure;
	
	
	public String getUrl1() {
		return url1;
	}

	public void setUrl1(String url1) {
		this.url1 = url1;
	}

	public String getUrl2() {
		return url2;
	}

	public void setUrl2(String url2) {
		this.url2 = url2;
	}

	public String getPrincipleRefId2() {
		return principleRefId2;
	}

	public void setPrincipleRefId2(String principleRefId2) {
		this.principleRefId2 = principleRefId2;
	}

	
	public String getLpStatusMessage() {
		return lpStatusMessage;
	}

	public void setLpStatusMessage(String lpStatusMessage) {
		this.lpStatusMessage = lpStatusMessage;
	}

	public Long getLoanamount() {
		return loanamount;
	}

	public void setLoanamount(Long loanamount) {
		this.loanamount = loanamount;
	}

	public Long getTenure() {
		return tenure;
	}

	public void setTenure(Long tenure) {
		this.tenure = tenure;
	}

	@Override
	public String toString() {
		return "PrincipalTransDetail [url1=" + url1 + ", url2=" + url2 + ", principleRefId2=" + principleRefId2
				+ ", lpStatusMessage=" + lpStatusMessage + ", loanamount=" + loanamount + ", tenure=" + tenure + "]";
	}
	
	
	

	

}
