package com.bajaj.markets.credit.business.listner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ObligationDetail;
import com.bajaj.markets.credit.business.beans.PanDetails;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.ProductCodeEnum;
import com.bajaj.markets.credit.business.helper.RejectionSystemSourceEnum;
import com.google.gson.Gson;

@Component
public class BreListener {

	private static final String REJECT_SYSTEM_SEGMETATIONBRE = "SEGMETATIONBRE";
	private static final String SEND_NOTIFICATION = "sendNotification";
	private static final String OPENMARKETSLOANLISTING = "openMarketsLoanListing";
	private static final String OPENARCCARDLISTING = "openArcCardListing";
	private static final String OPEN_ARC_CARD_LISTING_OUTPUT = "openArcCardListingOutput";
	private static final String OPEN_ARC_CARD_LIST_INPUT = "openArcCardListingInput";
	private static final String REJECTION_SYSTEM = "rejectionSystem";
	private static final String APPLICATIONID = "applicationId";
	private static final String PRODUCT = "product";
	private static final String OCCUPATIONTYPE = "occupationType";
	private static final String CIBILJSON = "cibilJson";
	private static final String CIBILSOCORE = "cibilScore";
	@Autowired
	BFLLoggerUtilExt logger;
	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	private McpCheck mcpCheck;

	private static final String CLASS_NAME = BreListener.class.getCanonicalName();
	
	@SuppressWarnings("unchecked")
	public void preListing(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preListing");
		Object cibilJson = execution.getVariable(CreditBusinessConstants.CIBIL_JSON);
		JSONObject mcp2Request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		JSONObject breRequest = new JSONObject();
		JSONObject openArcCardListingInput = new JSONObject();
		openArcCardListingInput.put("applicationId", execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		openArcCardListingInput.put("eligibilityType", "AIP");
		openArcCardListingInput.put("cibilJson", cibilJson);
		openArcCardListingInput.put("cibilType", execution.getVariable("cibilType"));
		openArcCardListingInput.put("cibilScore", execution.getVariable("cibilScore"));
		openArcCardListingInput.put("product", execution.getVariable(CreditBusinessConstants.PRODUCTDESC));
		openArcCardListingInput.put("occupationType", execution.getVariable("occupationType"));

		openArcCardListingInput.put("customerProfileSegment",execution.getVariable(CreditBusinessConstants.CUSTOMER_PROFILESEGMENT));
		openArcCardListingInput.put("microSegment", execution.getVariable(CreditBusinessConstants.MICRO_SEGMENT));
		openArcCardListingInput.put("customerSegment", execution.getVariable(CreditBusinessConstants.CUSTOMER_SEGMENT));
	
	
		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcCardListingInput, mcp2Request, true, null, null, null);
		
		openArcCardListingInput.put("employerType",
				execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY) != null
						? execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY).toString()
						: null);
		openArcCardListingInput.put("companyCategory",
				execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY) != null
						? execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY).toString()
						: null);

		List<PanDetails> panDetailsList = mcpCheck.getNsdlPanResponse(execution);
		openArcCardListingInput.put("panDetails", panDetailsList);

		ResidenceMaster resitype = mcpCheck.getResidanceType(mcp2Request);
		if (resitype != null) {
			openArcCardListingInput.put("resiType", resitype.getResidenceValue());
		}

		Map<String, Object> occupation = (Map<String, Object>) mcp2Request.get("occupation");
		if (occupation != null && occupation.get("businessOwnerDetails") != null) {
			setAnnualTurnover(execution, openArcCardListingInput, occupation);
		}

		//Appscore , Derog & credit vidya response to pass in listing bre input
		openArcCardListingInput.put("appScore",
				null != execution.getVariable("appscore") ? Integer.valueOf(execution.getVariable("appscore").toString()) : null);
		openArcCardListingInput.put("appScoreLR",
				null != execution.getVariable("lrScore") ? Integer.valueOf(execution.getVariable("lrScore").toString()) : null);
		openArcCardListingInput.put("appScoreML",
				null != execution.getVariable("mlScore") ? Integer.valueOf(execution.getVariable("mlScore").toString()) : null);
		openArcCardListingInput.put("appScoreLRV2",
				null != execution.getVariable("lrScorev2") ? Integer.valueOf(execution.getVariable("lrScorev2").toString()) : null);

		if (null != execution.getVariable(CreditBusinessConstants.DEROG_JSON)) {
			Gson gson = new Gson();
			String derogJson = gson.toJson(execution.getVariable(CreditBusinessConstants.DEROG_JSON));
			openArcCardListingInput.put(CreditBusinessConstants.DEROG_JSON, derogJson);
		}

		openArcCardListingInput.put("educationQualification",
				null != execution.getVariable("cvValidationstatus") ? execution.getVariable("cvValidationstatus").toString() : null);
		
		JSONObject obligationJSON = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OBLIGATION_AMT));
		if(null != obligationJSON) {
			openArcCardListingInput.put("obligationAmount", null != obligationJSON.get("emiSum") ? obligationJSON.get("emiSum").toString() : null);
			List<Map<String, Object>> obligationDetailsList = (List<Map<String, Object>>) obligationJSON.get("emiList");
			List<ObligationDetail> obligationList = null;
			if (!obligationDetailsList.isEmpty()) {
				obligationList= new ArrayList<>();
				for (Map<String, Object> obligation : obligationDetailsList) {
					ObligationDetail details = new ObligationDetail();
					details.setAccountType(obligation.get("accountType") != null ? obligation.get("accountType").toString() : null);
					details.setCurrentBalance((obligation.get("currentBalance") != null && !obligation.get("currentBalance").toString().equals("")) ? Integer.parseInt(obligation.get("currentBalance").toString()) : 0);
					details.setEmiAmount((obligation.get("emiAmount") != null && !obligation.get("emiAmount").equals("")) ? Integer.parseInt(obligation.get("emiAmount").toString()) : 0);
					if(obligation.get("mob") != null) {
						double m = Double.parseDouble(obligation.get("mob").toString());
						Integer mob =(int) m;
						details.setMob(mob);
					}
					details.setHighCreditSanctionAmt((obligation.get("highCreditSanctionAmt") != null
							&& !obligation.get("highCreditSanctionAmt").toString().equals(""))
									? Integer.parseInt(obligation.get("highCreditSanctionAmt").toString())
									: 0);
					details.setReportingShortName(obligation.get("reportingShortName") != null
							? obligation.get("reportingShortName").toString()
							: null);
					obligationList.add(details);
				}
			}
			openArcCardListingInput.put("obligationDetailList",obligationList);
			openArcCardListingInput.put("obligationJson",obligationJSON.get("obligationJson"));
		}
		
		openArcCardListingInput.put("btBankName", null != execution.getVariable(CreditBusinessConstants.BTBANKNAME) ? execution.getVariable(CreditBusinessConstants.BTBANKNAME) : null);
		//Added hlProduct Intent for Secured Loan
		openArcCardListingInput.put("hlProductIntent", null != execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT) ? execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT).toString() : null);

		JSONObject ocupationType = null;
		JSONObject salariedDetail = null;
		JSONObject businessOwnerDetails = null;
		if (null != occupation) { 
			ocupationType = CreditBusinessHelper.getJSONObject(occupation.get("ocupationType"));
			salariedDetail = CreditBusinessHelper.getJSONObject(occupation.get("salariedDetail"));
			businessOwnerDetails = CreditBusinessHelper.getJSONObject(occupation.get("businessOwnerDetails"));
		}
		/*openArcCardListingInput.put("occupationType",
				null != ocupationType && null != ocupationType.get(CreditBusinessConstants.VALUE)
						? ocupationType.get(CreditBusinessConstants.VALUE).toString()
						: null);*/ //Ask whether to set

		if (null != salariedDetail && salariedDetail.get("employerName") != null) {
			JSONObject employer = CreditBusinessHelper.getJSONObject(salariedDetail.get("employerName"));
			if (employer.get(CreditBusinessConstants.KEY) != null) {
				Long employerId = Double.valueOf(employer.get(CreditBusinessConstants.KEY).toString()).longValue();
				JSONObject employerMaster = mcpCheck.apiCallsHelper.getEmployerMaster(employerId);
				if (employerMaster != null && null != employerMaster.get(CreditBusinessConstants.INDMASTKEY)) {
					Integer industryTypeKey = Integer
							.valueOf(employerMaster.get(CreditBusinessConstants.INDMASTKEY).toString());
					String industryTypeValue = mcpCheck.apiCallsHelper.getSOLIndustryType(industryTypeKey);
					openArcCardListingInput.put(CreditBusinessConstants.INDUSTRY_TYPE, industryTypeValue);
				}
			}
		}

		if (null != businessOwnerDetails) {
			JSONObject industryType = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get(CreditBusinessConstants.INDUSTRY_TYPE));
			if(null != industryType && null!= industryType.get(CreditBusinessConstants.KEY) ) {
				Long industryTypeKey = Double.valueOf(industryType.get(CreditBusinessConstants.KEY).toString()).longValue();
				String industryTypeValue = mcpCheck.apiCallsHelper.getIndustryType(industryTypeKey);
				openArcCardListingInput.put(CreditBusinessConstants.INDUSTRY_TYPE, industryTypeValue);
			}
		}
		
		breRequest.put(OPEN_ARC_CARD_LIST_INPUT, openArcCardListingInput);
		breRequest.put("additionalParameterDetail", mcp2Request.get("additionalParameterDetail"));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, breRequest);
		execution.setVariable(REJECTION_SYSTEM, RejectionSystemSourceEnum.LISTBREAPI.getValue());
		execution.setVariable(SEND_NOTIFICATION, true);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preListing");
	}

	@SuppressWarnings("unchecked")
	private void setAnnualTurnover(DelegateExecution execution, JSONObject openArcCardListingInput, Map<String, Object> occupation) {
		Map<String, Object> businessOwnerDetails = (Map<String, Object>) occupation.get("businessOwnerDetails");
		JSONObject anualTurnover = CreditBusinessHelper.getJSONObject(businessOwnerDetails.get("anualTurnover"));
		if (null != anualTurnover && null != anualTurnover.get(CreditBusinessConstants.VALUE)) {
			String annualTurnOverValue = anualTurnover.get(CreditBusinessConstants.VALUE).toString();
			ArrayList<Map<String, Object>> annualTurnoverList = (ArrayList<Map<String, Object>>) execution
					.getVariable(CreditBusinessConstants.ANNUALTURNOVER_LOOKUP_LIST);
			if (annualTurnOverValue != null && !CollectionUtils.isEmpty(annualTurnoverList)) {
				Optional<Map<String, Object>> annulturnOverOptional = annualTurnoverList.stream()
						.filter(turnover -> annualTurnOverValue.equalsIgnoreCase(turnover.get(CreditBusinessConstants.VALUE).toString())).findFirst();
				if (!annulturnOverOptional.isEmpty()) {
					openArcCardListingInput.put("annualTurnover",
							annulturnOverOptional.get().get(CreditBusinessConstants.CODE) != null
									? annulturnOverOptional.get().get(CreditBusinessConstants.CODE).toString()
									: null);
				}
			}
		}
	}

	public void postListing(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postListing");
		JSONObject breOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		Boolean eligiblePrincipleFound = false;
		if (breOutput != null && breOutput.get(OPEN_ARC_CARD_LISTING_OUTPUT) != null) {
			JSONObject openArcCardOutput = CreditBusinessHelper.getJSONObject(breOutput.get(OPEN_ARC_CARD_LISTING_OUTPUT));
			eligiblePrincipleFound = checkRejection(eligiblePrincipleFound, openArcCardOutput);
		}
		execution.setVariable(CreditBusinessConstants.IS_REJECTED, !eligiblePrincipleFound);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postListing");
	}

	@SuppressWarnings("unchecked")
	private Boolean checkRejection(Boolean eligiblePrincipleFound, JSONObject openArcOutput) {

		if (openArcOutput.get(OPENARCCARDLISTING) != null) {
			JSONObject cardLisitngOutput = CreditBusinessHelper.getJSONObject(openArcOutput.get(OPENARCCARDLISTING));
			List<Map<String, Object>> cardPrinciples = (List<Map<String, Object>>) cardLisitngOutput.get("principleProductDetails");
			if (!CollectionUtils.isEmpty(cardPrinciples)) {
				eligiblePrincipleFound = cardPrinciples.stream().anyMatch(principle -> (boolean) principle.get("isEligible"));
			}
		}

		if (openArcOutput.get(OPENMARKETSLOANLISTING) != null) {
			JSONObject cardLisitngOutput = CreditBusinessHelper.getJSONObject(openArcOutput.get(OPENMARKETSLOANLISTING));
			List<Map<String, Object>> loanPrinciple = (List<Map<String, Object>>) cardLisitngOutput.get("principalProductDetails");
			if (!CollectionUtils.isEmpty(loanPrinciple)) {
				eligiblePrincipleFound = loanPrinciple.stream().anyMatch(principle -> (boolean) principle.get("isEligible"));
			}
		}
		return eligiblePrincipleFound;
	}

	@SuppressWarnings("unchecked")
	public void preListingUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preListingUpdate");
		JSONObject output = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));

		if (output != null) {
			JSONObject listingOutput = CreditBusinessHelper.getJSONObject(output.get(OPEN_ARC_CARD_LISTING_OUTPUT));
			if (ProductCodeEnum.CREDIT_CARD.getValue().equalsIgnoreCase((String) execution.getVariable(CreditBusinessConstants.PRODUCTCODE))) {
				listingOutput.put(OPENMARKETSLOANLISTING, null);
			} else {
				listingOutput.put(OPENARCCARDLISTING, null);
			}
			output.put(OPEN_ARC_CARD_LISTING_OUTPUT, listingOutput);
			output.put(REJECTION_SYSTEM, execution.getVariable(REJECTION_SYSTEM));
			output.put(SEND_NOTIFICATION, execution.getVariable(SEND_NOTIFICATION) != null ? execution.getVariable(SEND_NOTIFICATION) : false);
			execution.setVariable(CreditBusinessConstants.PAYLOAD, output);
			execution.setVariable(SEND_NOTIFICATION, false); 
		} else {
			execution.setVariable(CreditBusinessConstants.PAYLOAD, null);
		}
		execution.setVariable(REJECTION_SYSTEM, null);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preListingUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void preFeesBre(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preFeesBre");
		JSONObject payload = new JSONObject();
		payload.put("occupationtype", execution.getVariable(CreditBusinessConstants.OCCUPATIONTYPECODE));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preFeesBre");
	}
	
	@SuppressWarnings("unchecked")
	public void preSegmentationBRE(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preSegmentationBRE for : "
				+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
		
		JSONObject mcpRequest = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		JSONObject segmentation = new JSONObject();
		JSONObject segmentationRequest = creditBusinessHelper.populateSegmentationBRErequest(execution, mcpRequest);
		segmentation.put("segmentationRequest", segmentationRequest);
		segmentation.put("additionalParameterDetail", mcpRequest.get("additionalParameterDetail"));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, segmentation);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preSegmentationBRE for : "
				+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
	}
	
	@SuppressWarnings("unchecked")
	public void postSegmentationBRE(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postSegmentationBRE for : "
				+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));

		Map<String, Object> segmentationDetail = (Map<String, Object>) execution
				.getVariable(CreditBusinessConstants.OUTPUT);
		if (null != segmentationDetail && null != segmentationDetail.get("segmentationResponse")) {
			Map<String, Object> segmentationResponse = (Map<String, Object>) segmentationDetail
					.get("segmentationResponse");
			execution.setVariable(CreditBusinessConstants.CUSTOMER_SEGMENT,
					segmentationResponse.get(CreditBusinessConstants.CUSTOMER_SEGMENT));
			execution.setVariable(CreditBusinessConstants.CUSTOMER_PROFILESEGMENT,
					segmentationResponse.get(CreditBusinessConstants.CUSTOMER_PROFILESEGMENT));
			execution.setVariable(CreditBusinessConstants.MICRO_SEGMENT,
					segmentationResponse.get(CreditBusinessConstants.MICRO_SEGMENT));
			
			segmentationDetail.put(REJECTION_SYSTEM, REJECT_SYSTEM_SEGMETATIONBRE);
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, segmentationDetail);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postSegmentationBRE for : "
				+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
	}
	@SuppressWarnings("unchecked")
	public void preSegmentationBREVer2(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preSegmentationBRE for : "
				+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
		
		JSONObject mcpRequest = CreditBusinessHelper
				.getJSONObject(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT));
		JSONObject segmentation = new JSONObject();
		JSONObject segmentationRequest = new JSONObject();
		segmentationRequest.put(APPLICATIONID, execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		segmentationRequest.put(OCCUPATIONTYPE, execution.getVariable(OCCUPATIONTYPE));
		segmentationRequest.put(CIBILJSON, execution.getVariable(CreditBusinessConstants.CIBIL_JSON));
		segmentationRequest.put(CIBILSOCORE, execution.getVariable(CIBILSOCORE));
		
		creditBusinessHelper.populateSegmentationBRErequestFromMcp(mcpRequest,segmentationRequest);
		segmentation.put("segmentationRequest", segmentationRequest);
		segmentation.put("additionalParameterDetail", mcpRequest.get("additionalParameterDetail"));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, segmentation);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preSegmentationBRE for : "
				+ execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY));
	}
}
