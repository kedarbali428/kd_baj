package com.bajaj.markets.credit.business.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.service.CreditMasterDataService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditMasterDataController {

	@Autowired
	private CreditMasterDataService creditMasterDataService;

	@Autowired
	private BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = CreditMasterDataController.class.getCanonicalName();

	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch servicable master data.", notes = "Fetch servicable master data.", httpMethod = "GET")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched data for given principal", response = Reference.class, responseContainer = "list"),
			@ApiResponse(code = 400, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Resource not found.", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Internal Server Error.", response = ErrorBean.class) })
	@GetMapping("/v1/credit/principals/{principalCode}/reference-attributes/{referenceAttributeCode}/serviceable-codes")
	@CrossOrigin
	public ResponseEntity<List<Reference>> getServiceableMasterData(@PathVariable("principalCode") String principalCode,
			@PathVariable("referenceAttributeCode") String serviceableCode,
			@ApiParam(name = "status", value = "Status of isactive flag of entry. accepted value: all , active", example = "all,active") @RequestParam("status") String status,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside CreditMasterDataController :  getServiceableMasterData method. Start");
		List<Reference> serviceableMasterData = creditMasterDataService.getServiceableMasterData(principalCode,
				serviceableCode, status, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside CreditMasterDataController :  getServiceableMasterData method. End");
		return new ResponseEntity<>(serviceableMasterData, HttpStatus.OK);

	}

}
