package com.bajaj.markets.credit.business.beans;

public class DeactivateOffer {
	
	private Long customerId;
	private String status;
	private String holdReason;
	private String inactiveDate;
	private String activeDate;

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getHoldReason() {
		return holdReason;
	}

	public void setHoldReason(String holdReason) {
		this.holdReason = holdReason;
	}

	public String getInactiveDate() {
		return inactiveDate;
	}

	public void setInactiveDate(String inactiveDate) {
		this.inactiveDate = inactiveDate;
	}

	public String getActiveDate() {
		return activeDate;
	}

	public void setActiveDate(String activeDate) {
		this.activeDate = activeDate;
	}

	@Override
	public String toString() {
		return "DeactivateOffer [customerId=" + customerId + ", status=" + status + ", holdReason=" + holdReason
				+ ", inactiveDate=" + inactiveDate + ", activeDate=" + activeDate + "]";
	}

	
	
}
