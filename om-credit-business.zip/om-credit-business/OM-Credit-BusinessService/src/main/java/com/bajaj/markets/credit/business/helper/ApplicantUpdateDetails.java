package com.bajaj.markets.credit.business.helper;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.amazonaws.services.sns.model.PublishResult;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.bean.EventMessage;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.ApplicantUpdateBean;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.ProfessionDetail;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.beans.Verification;
import com.bajaj.markets.credit.publisher.service.PublisherService;

@Component
public class ApplicantUpdateDetails {

	private static final String PAN = "DOCUMENTDETAILS";

	private static final String OCCUPATION2 = "OCCUPATION";

	private static final String BASICPROFILEDETAILS = "BASICPROFILEDETAILS";

	private static final String ADDRESS2 = "ADDRESS";

	private static final String EMAIL = "EMAIL";
	
	private static final String PROFESSIONCODE_DOCTOR = "DOCTOR";
	
	private static final String PROFESSIONCODE_CA = "CA";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CustomDefaultHeaders customHeaders;

	@Value("${aws.publisher.applicantupdate.topic.arn}")
	private String topicArn;

	@Autowired
	PublisherService publisherService;

	@Autowired
	private CreditBusinessApiCallsHelper apiHelper;

	@Autowired
	private Executor customExecutor;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getOccupationUrl;

	@Value("${api.omcreditapplicationservice.getemail.get.url}")
	private String getEmailUrl;

	@Value("${api.omcreditapplicationservice.getdocument.get.url}")
	private String getDocumentUrl;

	@Autowired
	MasterDataRedisClientHelper masterDataRedisClientHelper;

	private static final String CLASS_NAME = ApplicantUpdateDetails.class.getCanonicalName();

	public void updateApplicantData(DelegateExecution execution) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "start updateApplicantData");
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put(CreditBusinessConstants.APPLICATION_ID,
				execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		queryParam.put("userattributekey",
				execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
		List<ApplicantUpdateBean> attributeList = new ArrayList<>();
		Long applicantKey = new Long(execution.getVariable(CreditBusinessConstants.APPLICANTID).toString());

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "update Applicant Data Event for Application ID" + queryParam.get(CreditBusinessConstants.APPLICATION_ID));
		
		Verification verificationObject = getVerificationObject(execution);
		
		// Base User Profile
		CompletableFuture<Void> getUserProfile = CompletableFuture
				.supplyAsync(() -> getUserProfile(queryParam), customExecutor)
				.exceptionally(ex -> new UserProfileBean()).thenAccept(userProfile -> {
					Verification nameVerificationObject=verificationObject.clone();
					nameVerificationObject.setVerifiedFor("NAME");
					userProfile.getName().setVerification(nameVerificationObject);
					setApplicantUpdateList(BASICPROFILEDETAILS, applicantKey, userProfile,attributeList);
				});

		// Occupation
		CompletableFuture<Void> getOccupation = CompletableFuture
				.supplyAsync(() -> getOccupation(queryParam), customExecutor).exceptionally(ex -> new Occupation())
				.thenAccept(occupation -> {
					setOccupationTypeAndProfession(occupation);
					setApplicantUpdateList(OCCUPATION2, applicantKey, occupation,attributeList);
				});

		// Pan
		CompletableFuture<Void> getPanResponse = CompletableFuture
				.supplyAsync(() -> getDocumentDetails(queryParam), customExecutor)
				.exceptionally(ex -> new DocumentDetails()).thenAccept(panResponse -> {
					panResponse.setDocumentNameKey(1l);
					verificationObject.setVerifiedFor("PAN");
					panResponse.setVerification(verificationObject);
					setApplicantUpdateList(PAN, applicantKey, panResponse,attributeList);
				});

		// PersonalEmailId
		CompletableFuture<Void> getPersonalEmail = CompletableFuture
				.supplyAsync(() -> getEmailDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"), CreditBusinessConstants.PERSONAL_EMAIL_TYPE.toString()),
						customExecutor)
				.exceptionally(ex -> new Email()).thenAccept(personalEmail -> {
					setApplicantUpdateList(EMAIL, applicantKey, personalEmail,attributeList);
				});

		// WorkEmailId
		CompletableFuture<Void> getWorkEmail = CompletableFuture
				.supplyAsync(() -> getEmailDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"), CreditBusinessConstants.OFFICIAL_EMAIL_TYPE.toString()),
						customExecutor)
				.exceptionally(ex -> new Email()).thenAccept(workEmail -> {
					setApplicantUpdateList(EMAIL, applicantKey, workEmail,attributeList);
				});

		CompletableFuture<Void> getOtherAddress = CompletableFuture
				.supplyAsync(
						() -> getAddressDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"),
								masterDataRedisClientHelper
										.getAddressTypeKeyForCode(CreditBusinessConstants.OTHER_ADDR).toString()),
						customExecutor)
				.exceptionally(ex -> null).thenAccept(otherAddress -> {
					setApplicantUpdateList(ADDRESS2, applicantKey, otherAddress,attributeList);
				});

		CompletableFuture<?> getPropertyAddress = CompletableFuture.supplyAsync(
				() -> getAddressDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"), masterDataRedisClientHelper
						.getAddressTypeKeyForCode(CreditBusinessConstants.ADDRESS_TYPE_PROPERTY).toString()),
				customExecutor).exceptionally(ex -> null).thenAccept(propertyAddress -> {
					setApplicantUpdateList(ADDRESS2, applicantKey, propertyAddress,attributeList);
				});

		// Address
		CompletableFuture<Void> getCurrentAddress = CompletableFuture
				.supplyAsync(
						() -> getAddressDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"),
								masterDataRedisClientHelper
										.getAddressTypeKeyForCode(CreditBusinessConstants.CURRENT_ADDR).toString()),
						customExecutor)
				.exceptionally(ex -> null).thenAccept(currentAddress -> {
					setApplicantUpdateList(ADDRESS2, applicantKey, currentAddress,attributeList);
				});

		CompletableFuture<Void> getOfficeAddress = CompletableFuture
				.supplyAsync(
						() -> getAddressDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"),
								masterDataRedisClientHelper
										.getAddressTypeKeyForCode(CreditBusinessConstants.OFFICE_ADDR).toString()),
						customExecutor)
				.exceptionally(ex -> null).thenAccept(officeAddress -> {
					setApplicantUpdateList(ADDRESS2, applicantKey, officeAddress,attributeList);
				});

		CompletableFuture<Void> getPermanentAddress = CompletableFuture
				.supplyAsync(
						() -> getAddressDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"), masterDataRedisClientHelper
								.getAddressTypeKeyForCode(CreditBusinessConstants.PERMANENT_ADDR).toString()),
						customExecutor)
				.exceptionally(ex -> null).thenAccept(permanentAddress -> {
					setApplicantUpdateList(ADDRESS2, applicantKey, permanentAddress,attributeList);
				});

		CompletableFuture.allOf(getUserProfile, getOccupation, getPersonalEmail, getWorkEmail, getOtherAddress,
				getPropertyAddress, getPanResponse, getCurrentAddress, getOfficeAddress, getPermanentAddress).join();

		EventMessage eventMessage = createEventMessage(attributeList, execution);
		PublishResult publish = publisherService.publish(topicArn, eventMessage);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Applicant Update Event publish completed for MessageId : " + publish.getMessageId() + " and Application ID :" + queryParam.get(CreditBusinessConstants.APPLICATION_ID));
	}

	@SuppressWarnings("unchecked")
	private Verification getVerificationObject(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getVerificationObject start");
		Verification verificationObj = new Verification();
		if (execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE_VERIFY) != null) {
			JSONObject nsdlPanVerResponse = CreditBusinessHelper
					.getJSONObject(execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE_VERIFY));

			boolean isVerified = false;

			ArrayList<Map<String, Object>> ruleList = (ArrayList<Map<String, Object>>) nsdlPanVerResponse
					.get("ruleDetails");
			for (Map<String, Object> rule : ruleList) {
				if ((rule.get("ruleName").equals("exact_match") && rule.get("ruleValue").equals("1"))
						|| (rule.get("ruleName").equals("sorted_exact_match") && rule.get("ruleValue").equals("1"))) {
					isVerified = true;
					break;
				}
			}
			verificationObj.setIsVerified(isVerified);
			Map<String, Object> verificationObject = (Map<String, Object>) nsdlPanVerResponse.get("verification");

			try {
				if (null != verificationObject.get("verificationDate")) {
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.SSS][Z]");
					LocalDateTime localDate = LocalDateTime.parse(verificationObject.get("verificationDate").toString(),
							formatter);
					verificationObj.setVerificationDate(Timestamp.valueOf(localDate));
				}
			} catch (Exception e) {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occurred while parsing verification date",
						e);
			}
			verificationObj.setVerificationReference(null != verificationObject.get("verificationReference")
					? Double.valueOf(verificationObject.get("verificationReference").toString()).longValue()
					: null);
			verificationObj.setVerificationSource(null != verificationObject.get("verificationSource")
					? (String) verificationObject.get("verificationSource")
					: null);
			verificationObj.setVerifyingProductCategoryKey(
					null != execution.getVariable(CreditBusinessConstants.L2_PRODUCT_KEY)
							? (Long) execution.getVariable(CreditBusinessConstants.L2_PRODUCT_KEY)
							: null);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getVerificationObject end " + verificationObj);
		return verificationObj;
	}

	public void updateApplicantAddress(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "start updateApplicantAddress");
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put(CreditBusinessConstants.APPLICATION_ID,
				execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		queryParam.put("userattributekey",
				execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
		List<ApplicantUpdateBean> attributeList = new ArrayList<>();
		Long applicantKey = new Long(execution.getVariable(CreditBusinessConstants.APPLICANTID).toString());

		// Address
		CompletableFuture<Void> getCurrentAddress = CompletableFuture
				.supplyAsync(
						() -> getAddressDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"),
								masterDataRedisClientHelper
										.getAddressTypeKeyForCode(CreditBusinessConstants.CURRENT_ADDR).toString()),
						customExecutor)
				.exceptionally(ex -> null).thenAccept(currentAddress -> {
					setApplicantUpdateList(ADDRESS2, applicantKey, currentAddress,attributeList);
				});

		CompletableFuture<Void> getOfficeAddress = CompletableFuture
				.supplyAsync(
						() -> getAddressDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"),
								masterDataRedisClientHelper
										.getAddressTypeKeyForCode(CreditBusinessConstants.OFFICE_ADDR).toString()),
						customExecutor)
				.exceptionally(ex -> null).thenAccept(officeAddress -> {
					setApplicantUpdateList(ADDRESS2, applicantKey, officeAddress,attributeList);
				});

		CompletableFuture<Void> getPermanentAddress = CompletableFuture
				.supplyAsync(
						() -> getAddressDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"), masterDataRedisClientHelper
								.getAddressTypeKeyForCode(CreditBusinessConstants.PERMANENT_ADDR).toString()),
						customExecutor)
				.exceptionally(ex -> null).thenAccept(permanentAddress -> {
						setApplicantUpdateList(ADDRESS2, applicantKey, permanentAddress,attributeList);
				});

		CompletableFuture<Void> getDeliveryAddress = CompletableFuture
				.supplyAsync(
						() -> getAddressDetails(queryParam.get(CreditBusinessConstants.APPLICATION_ID),queryParam.get("userattributekey"),
								masterDataRedisClientHelper
										.getAddressTypeKeyForCode(CreditBusinessConstants.DELIVERY_ADDRESS).toString()),
						customExecutor)
				.exceptionally(ex -> null).thenAccept(deliveryAddress -> {
					setApplicantUpdateList(ADDRESS2, applicantKey, deliveryAddress,attributeList);
				});

		CompletableFuture.allOf(getCurrentAddress, getOfficeAddress, getPermanentAddress, getDeliveryAddress).join();

		EventMessage eventMessage = createEventMessage(attributeList, execution);
		PublishResult publish = publisherService.publish(topicArn, eventMessage);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Applicant Update Event publish completed for MessageId : " + publish.getMessageId() + " and Application ID :" + queryParam.get(CreditBusinessConstants.APPLICATION_ID));
	}

	private Address getAddressDetails(String applicationId, String userAttributeId, String typeKey) {
		Address address = null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getAddressDetails for applicationID :"+ applicationId +"and Type Key" + typeKey);
		Map<String, String> param = new HashMap<>();
		param.put("applicationid", applicationId);
		param.put("userattributekey", userAttributeId);
		param.put("typeKey", typeKey);
		address = apiHelper.getAddress(new HttpHeaders(), param);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getAddressDetails :" + address);
		return address;
	}

	private Email getEmailDetails(String applicationId, String userAttributeId, String typeKey) {
		Email email = null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getEmailDetails for applicationID :"+ applicationId +"and Type Key" + typeKey);
		Map<String, String> param = new HashMap<>();
		param.put("applicationid", applicationId);
		param.put("userattributekey", userAttributeId);
		param.put("typeKey", typeKey);
		email = apiHelper.callApi(getEmailUrl, HttpMethod.GET, param, null, Email.class);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "getEmailDetails :" + email);
		return email;
	}

	private DocumentDetails getDocumentDetails(Map<String, String> queryParam) {
		return apiHelper.callApi(getDocumentUrl, HttpMethod.GET, queryParam, null, DocumentDetails.class);
	}

	private Occupation getOccupation(Map<String, String> queryParam) {
		return apiHelper.callApi(getOccupationUrl, HttpMethod.GET, queryParam, null, Occupation.class);
	}

	private UserProfileBean getUserProfile(Map<String, String> queryParam) {
		return apiHelper.getUserProfile(queryParam);
	}

	private void setApplicantUpdateList(String attributeName, Long applicantKey, Object payload,List<ApplicantUpdateBean> attributeList ) {
		if(null != payload) {
			ApplicantUpdateBean applicantUpdateBean = new ApplicantUpdateBean();
			applicantUpdateBean.setAttributeName(attributeName);
			applicantUpdateBean.setAttributeType(attributeName);
			applicantUpdateBean.setValue(payload);
			applicantUpdateBean.setApplicantKey(applicantKey);
			attributeList.add(applicantUpdateBean);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, attributeName+":"+CreditBusinessHelper.objectToJson(payload));
		}
	}

	private EventMessage createEventMessage(Object payload, DelegateExecution execution) {
		Map<String, String> headers = new HashMap<>();
		Map<String, String> messageFilterAttributes = new HashMap<String, String>();
		
		headers.put(CreditBusinessConstants.AUTH_TOKEN,
				null != customHeaders.getAuthtoken() ? customHeaders.getAuthtoken()
						: MDC.get(CreditBusinessConstants.AUTH_TOKEN));
		headers.put(CreditBusinessConstants.CMPT_CORR_ID,
				null != customHeaders.getCmptcorrid() ? customHeaders.getCmptcorrid()
						: MDC.get(CreditBusinessConstants.CMPT_CORR_ID));
		headers.put(CreditBusinessConstants.USERKEY,
				0l != customHeaders.getUserKey() ? String.valueOf(customHeaders.getUserKey())
						: MDC.get(CreditBusinessConstants.USERKEY));
		headers.put(CreditBusinessConstants.APPLICATIONID,
				execution.getVariable(CreditBusinessConstants.APPLICATIONID).toString());
		headers.put(CreditBusinessConstants.MOBILE, execution.getVariable(CreditBusinessConstants.MOBILE).toString());
		
		messageFilterAttributes.put("productCode", execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE).toString());
		messageFilterAttributes.put("principalName", PrincipalTypeEnum.BHFL.toString());
		
		EventMessage eventMessage = new EventMessage();
		eventMessage.setEventName(CreditBusinessConstants.APPLICANT_UPDATE);
		eventMessage.setEventType(CreditBusinessConstants.APPLICANT_UPDATE_EVENT_TYPE);
		eventMessage.setPayload(payload);
		eventMessage.setHeaders(headers);
		eventMessage.setMessageFilterAttributes(messageFilterAttributes);
		
		return eventMessage;
	}

	private void setOccupationTypeAndProfession(Occupation occupation) {
		if (occupation.getOcupationType().getCode().equals("DOCSAL")) {
			occupation.setOcupationType(getReference(1l, "SALR", "Salaried"));
			occupation.setProfession(getProfession(PROFESSIONCODE_DOCTOR));
		} else if (occupation.getOcupationType().getCode().equals("DOCSEMP")) {
			occupation.setOcupationType(getReference(2l, "SEMP", "Self Employed"));
			occupation.setProfession(getProfession(PROFESSIONCODE_DOCTOR));
		} else if (occupation.getOcupationType().getCode().equals("CAICWA")) {
			occupation.setOcupationType(getReference(2l, "SEMP", "Self Employed"));
			occupation.setProfession(getProfession(PROFESSIONCODE_CA));
		}
	}

	private ProfessionDetail getProfession(String professionCode) {
		ProfessionDetail professionalDetail = new ProfessionDetail();
		professionalDetail.setProfession(getReference(null, professionCode, null));
		return professionalDetail;
	}

	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;
	}

}
