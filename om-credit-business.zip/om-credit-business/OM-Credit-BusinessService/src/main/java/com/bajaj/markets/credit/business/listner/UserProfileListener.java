package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICANTID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICANTKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATIONKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CHILD_APPLICATION_USER_ATTRIBUTE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DATE_OF_BIRTH;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DOB;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.FIRST_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.FULLNAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.FULL_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.GENDER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.GENDERKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2_PRODUCT_CODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2_PRODUCT_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.LAST_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MARITALSTATUS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MARITALSTATUSKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MIDDLE_NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.MOBILE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NAME;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAN_NUMBER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAYLOAD;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.RESIDENCETYPEKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.RESIDENCE_TYPE_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.RESITYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SPACE_DELIMETER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.WORK_EMAIL_REQUIRED;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;

@Component
public class UserProfileListener {

	private static final String APPLICANT_KEY = "applicantKey";
	private static final String APPLICATION_KEY = "applicationKey";
	private static final String DOCUMENT_NUMBER = "documentNumber";
	private static final String TYPE_KEY = "typeKey";
	private static final String EMAIL = "email";
	private static final String SEMP_OCCUPATION = "SEMP";
	private static final String SALR_OCCUPATION = "SALR";
	private static final String PROFILE_DETAILS = "profileDetails";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	UserProfile userProfile;

	@Autowired
	private CreditBusinessHelper creditBusinessHelper;

	private static final String CLASS_NAME = UserProfileListener.class.getCanonicalName();

	public void pre(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start UserProfileListener :: pre");
		userProfile.pre(execution);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End UserProfileListener :: pre");
	}

	public void post(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start UserProfileListener :: post");
		userProfile.post(execution);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End UserProfileListener :: post");
	}

	public void postGetUserProfileOnAdditionalDet(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetUserProfileOnAdditionalDet :: post");
		userProfile.post(execution);

		execution.setVariable("permanentAddressRequired", false);
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (request != null) {
			if (request.get("permanentAddressRequired") != null && (Boolean) request.get("permanentAddressRequired")) {
				execution.setVariable("permanentAddressRequired", true);
			}

			if (request.get("workEmailRequired") != null && (Boolean) request.get("workEmailRequired")) {
				execution.setVariable("workEmailRequired", true);
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetUserProfileOnAdditionalDet :: post");
	}

	public void postGetUserProfileOnSecuredJourney(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetUserProfileOnSecuredJourney :: post");
		ArrayList<?> s = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		JSONObject userProfile = CreditBusinessHelper.getJSONObject(s.get(0));
		execution.setVariable(CreditBusinessConstants.MOBILE, userProfile.get(CreditBusinessConstants.MOBILE));
		execution.setVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY, userProfile.get(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY));
		execution.setVariable(CreditBusinessConstants.APPLICATION_ID, userProfile.get(CreditBusinessConstants.APPLICATIONKEY));
		if (null != userProfile.get(CreditBusinessConstants.NAME)) {
			JSONObject name = CreditBusinessHelper.getJSONObject(userProfile.get(CreditBusinessConstants.NAME));
			String firstName = null != name.get(CreditBusinessConstants.FIRST_NAME) ? name.get(CreditBusinessConstants.FIRST_NAME).toString() : null;
			String middleName = null != name.get(CreditBusinessConstants.MIDDLE_NAME) ? name.get(CreditBusinessConstants.MIDDLE_NAME).toString() : null;
			String lastName = null != name.get(CreditBusinessConstants.LAST_NAME) ? name.get(CreditBusinessConstants.LAST_NAME).toString() : null;
			execution.setVariable(CreditBusinessConstants.NAME, creditBusinessHelper.formFullName(firstName, middleName, lastName));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetUserProfileOnAdditionalDet :: post");
	}

	public void fetchPrimaryUserAttributeProfile(DelegateExecution execution) {
		ArrayList<?> userProfiles = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);

		if (null != userProfiles) {
			for (Object object : userProfiles) {
				JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
				if (null != userProfile && userProfile.get(APPLICATION_USER_ATTRIBUTE_TYPE).equals("1")) {
					execution.setVariable(APPLICATION_USER_ATTRIBUTE_KEY, userProfile.get(APPLICATION_USER_ATTRIBUTE_KEY));
					execution.setVariable(MOBILE, userProfile.get(MOBILE));
					execution.setVariable(DOB, userProfile.get(DATE_OF_BIRTH));
					execution.setVariable(NAME, userProfile.get(NAME));
					execution.setVariable(GENDERKEY, userProfile.get(GENDERKEY));
					execution.setVariable(APPLICANTKEY, userProfile.get(APPLICANTKEY));
					execution.setVariable(APPLICATIONKEY, userProfile.get(APPLICATIONKEY));
					execution.setVariable(RESIDENCE_TYPE_KEY,userProfile.get(RESIDENCE_TYPE_KEY));
					break;
				}
			}
		}
	}

	public void postGetPanDetails(DelegateExecution execution) {
		JSONObject documentDetail = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (null != documentDetail) {
			execution.setVariable(PAN_NUMBER, documentDetail.get(DOCUMENT_NUMBER));
		}
	}

	public void postGetUserProfileOnSecuredJourneyCoApplicant(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetUserProfileOnSecuredJourney :: post");
		execution.setVariable(CreditBusinessConstants.CO_APPLICATION_USER_ATTRIBUTE_KEY, null);
		ArrayList<?> s = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		for (Object object : s) {
			JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
			if (userProfile.get(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE).equals("2")) {
				execution.setVariable(CreditBusinessConstants.CO_APPLICATION_USER_ATTRIBUTE_KEY,
						userProfile.get(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY));
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetUserProfileOnAdditionalDet :: post");
	}

	public void postGetChildUserProfile(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetChildUserProfile ");
		ArrayList<?> s = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		execution.setVariable(WORK_EMAIL_REQUIRED, false);
		if (null != s) {
			for (Object object : s) {
				JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
				if (null != userProfile && userProfile.get(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE).equals("1")) {
					execution.setVariable(CreditBusinessConstants.CHILD_USERPROFILEOUTPUT, userProfile);
					execution.setVariable(CHILD_APPLICATION_USER_ATTRIBUTE_KEY, userProfile.get(APPLICATION_USER_ATTRIBUTE_KEY));
					if (userProfile.get(WORK_EMAIL_REQUIRED) != null && (boolean) userProfile.get(WORK_EMAIL_REQUIRED)) {
						execution.setVariable(WORK_EMAIL_REQUIRED, true);
					}
					break;
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetChildUserProfile");
	}
	
	public void postGetChildUserAttribute(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetUserProfileOnAdditionalDet :: post");
		fetchPrimaryUserAttributeProfileOfChild(execution);

		execution.setVariable("permanentAddressRequired", false);
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (request != null && request.get("permanentAddressRequired") != null && (Boolean) request.get("permanentAddressRequired")) {
			execution.setVariable("permanentAddressRequired", true);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetUserProfileOnAdditionalDet :: post");
	}
	
	public void fetchPrimaryUserAttributeProfileOfChild(DelegateExecution execution) {
		ArrayList<?> userProfiles = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);

		execution.setVariable(WORK_EMAIL_REQUIRED, false);
		if (null != userProfiles) {
			for (Object object : userProfiles) {
				JSONObject userProfile = CreditBusinessHelper.getJSONObject(object);
				if (null != userProfile && userProfile.get(APPLICATION_USER_ATTRIBUTE_TYPE).equals("1")) {
					execution.setVariable(CHILD_APPLICATION_USER_ATTRIBUTE_KEY,
							userProfile.get(APPLICATION_USER_ATTRIBUTE_KEY));
					execution.setVariable(APPLICATION_USER_ATTRIBUTE_TYPE,
							userProfile.get(APPLICATION_USER_ATTRIBUTE_TYPE));
					execution.setVariable(MOBILE, userProfile.get(MOBILE));
					execution.setVariable(DOB, userProfile.get(DATE_OF_BIRTH));
					execution.setVariable(NAME, userProfile.get(NAME));
					if (null != userProfile.get(WORK_EMAIL_REQUIRED) && (boolean) userProfile.get(WORK_EMAIL_REQUIRED)) {
						execution.setVariable(WORK_EMAIL_REQUIRED, true);
					}
					break;
				}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	public void buildProfilePageUpdatePayload(DelegateExecution execution) {
		JSONObject profilePageRequestPayload = CreditBusinessHelper.getJSONObject(execution.getVariable(REQUEST));
		if (null != profilePageRequestPayload && null != profilePageRequestPayload.get(PROFILE_DETAILS)) {
			JSONObject profileDetails = CreditBusinessHelper.getJSONObject(profilePageRequestPayload.get(PROFILE_DETAILS));
			JSONObject maritailStatus = CreditBusinessHelper.getJSONObject(profileDetails.get(MARITALSTATUS));
			
			JSONObject payload = new JSONObject();
			
			String fullName = profileDetails.get(NAME).toString().trim();
			String[] nameArr = fullName.split(SPACE_DELIMETER);
			JSONObject nameObj = new JSONObject();
			nameObj.put(FIRST_NAME, nameArr[0]);
			nameObj.put(MIDDLE_NAME, fullName.substring(fullName.indexOf(SPACE_DELIMETER), fullName.lastIndexOf(SPACE_DELIMETER)));
			nameObj.put(LAST_NAME, nameArr[nameArr.length - 1]);
			
			payload.put(NAME, nameObj);
			payload.put(MARITALSTATUSKEY, maritailStatus.get(KEY));
			
			execution.setVariable(PAYLOAD, payload);
			execution.setVariable(NAME, nameObj);
			execution.setVariable(FULL_NAME, fullName);
			execution.setVariable(FULLNAME, fullName);
			execution.setVariable(PAYLOAD, payload);
		} else {
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("profile details is null", "profile details is null"));
		}
	}
	
	@SuppressWarnings("unchecked")
	public void buildProfilePageProfessionPayload(DelegateExecution execution) {
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(REQUEST));
		JSONObject profession = CreditBusinessHelper.getJSONObject(request.get("profession"));
		JSONObject occupation = CreditBusinessHelper.getJSONObject(profession.get("ocupationType"));
		execution.setVariable(CreditBusinessConstants.IS_SALARIED, false);
		execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, false);
		execution.setVariable(CreditBusinessConstants.EMPLOYERID, null);
		execution.setVariable(CreditBusinessConstants.OCCUPATION_TYPE_KEY, Double.valueOf(occupation.get("key").toString()).longValue());
		JSONObject professionUpdatePayload = this.updateOccupationBasisOccupationCode(execution, profession, occupation.get("code").toString());
		professionUpdatePayload.put("ocupationType", occupation);
		execution.setVariable(PAYLOAD, professionUpdatePayload);
	}
	
	@SuppressWarnings("unchecked")
	public void buildPersonalEmailUpdatePayload(DelegateExecution execution) {
		JSONObject profilePageRequestPayload = CreditBusinessHelper.getJSONObject(execution.getVariable(REQUEST));
		if (null != profilePageRequestPayload && null != profilePageRequestPayload.get(PROFILE_DETAILS)) {
			JSONObject profileDetails = CreditBusinessHelper.getJSONObject(profilePageRequestPayload.get(PROFILE_DETAILS));
			JSONObject payload = new JSONObject();
			String personalEmail = profileDetails.get(CreditBusinessConstants.PERSONALEMAILID) != null
					? (String) profileDetails.get(CreditBusinessConstants.PERSONALEMAILID)
					: null;
			payload.put(EMAIL, personalEmail);
			payload.put(TYPE_KEY, EmailTypeEnum.PERON1.getValue());
			
			execution.setVariable(CreditBusinessConstants.PERSONALEMAILID, personalEmail);
			execution.setVariable(PAYLOAD, payload);
		} else {
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("profile details is null", "profile details is null"));
		}
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject updateOccupationBasisOccupationCode(DelegateExecution execution, JSONObject profession, String occupationCode) {
		JSONObject salariedDetail = CreditBusinessHelper.getJSONObject(profession.get("salariedDetail"));
		JSONObject businessOwnerDetails = CreditBusinessHelper.getJSONObject(profession.get("businessOwnerDetails"));
		
		JSONObject professionUpdatePayload = new JSONObject();
		switch (occupationCode) {
			case SALR_OCCUPATION:
				execution.setVariable(CreditBusinessConstants.IS_SALARIED, true);
				execution.setVariable(CreditBusinessConstants.SALARY,salariedDetail.get("netSalary"));
				professionUpdatePayload.put("salariedDetail", salariedDetail);
				if (null != salariedDetail && null != salariedDetail.get("employerName")) {
					JSONObject employerName = CreditBusinessHelper.getJSONObject(salariedDetail.get("employerName"));
					if(employerName != null && employerName.get("key") != null) {
						execution.setVariable(CreditBusinessConstants.EMPLOYERID, new BigDecimal(employerName.get("key").toString()).intValue());
					}else if(salariedDetail.get("employerNameOther") != null){ 
						execution.setVariable(CreditBusinessConstants.SALARIED_OTHR_EMPLOYER, true);
					}
				}
				
				break;
				
			case SEMP_OCCUPATION:
				professionUpdatePayload.put("businessOwnerDetails", businessOwnerDetails);
				
				break;
				
			default:
				break;
		}
		
		return professionUpdatePayload;
	}
	
	public void postFetchPan(DelegateExecution execution) {
		JSONObject panDocument = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(PAN_NUMBER, panDocument.get(DOCUMENT_NUMBER));
	}
	
	@SuppressWarnings("unchecked")
	public void prepareRequestForNameMatchPanVerification(DelegateExecution execution) {
		JSONObject panVerificationNameMatchPayload = new JSONObject();
		panVerificationNameMatchPayload.put(PAN_NUMBER, execution.getVariable(PAN_NUMBER));
		panVerificationNameMatchPayload.put(APPLICATION_KEY, execution.getVariable(APPLICATION_ID));
		panVerificationNameMatchPayload.put(APPLICANT_KEY, execution.getVariable(APPLICANTID));
		panVerificationNameMatchPayload.put(FULLNAME, execution.getVariable(FULLNAME));
		panVerificationNameMatchPayload.put(L2_PRODUCT_KEY, execution.getVariable(L2_PRODUCT_KEY));
		panVerificationNameMatchPayload.put(L2_PRODUCT_CODE	, execution.getVariable(L2_PRODUCT_CODE));
		execution.setVariable(PAYLOAD, panVerificationNameMatchPayload);
	}
}
