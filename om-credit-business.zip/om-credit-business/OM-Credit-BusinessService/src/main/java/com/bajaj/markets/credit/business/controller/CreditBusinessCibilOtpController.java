package com.bajaj.markets.credit.business.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.CibilReference;
import com.bajaj.markets.credit.business.beans.CibilRequest;
import com.bajaj.markets.credit.business.beans.CibilResponseWrapper;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessCibilOtpService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessCibilOtpController {

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessCibilOtpService creditBusinessCibilOtpService;

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "Fetch Cibil reference for an applicaiton", notes = "Fetch Cibil reference an application", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully found cibil reference", response = CibilReference.class),
			@ApiResponse(code = 204, message = "No content", response = ErrorBean.class), })
	@GetMapping(value = "/v1/applications/{applicationid}/cibil", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> getCibilReference(@PathVariable(name = "applicationid") Long applicationId) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER, "Start getCibilReference");
		ResponseEntity<?> response = new ResponseEntity<CibilReference>(
				creditBusinessCibilOtpService.getCibilReference(applicationId), HttpStatus.OK);
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER, "End getCibilReference");
		return response;
	}

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(value = "Business Orchestration for Consumer Cibil OTP Authentication", notes = "Authenticate Cibil OTP", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully found cibil refference", response = CibilResponseWrapper.class),
			@ApiResponse(code = 401, message = "Invalid OTP", response = ErrorBean.class) })
	@PostMapping(value = "/v1/applications/{applicationid}/cibil/{cibilreference}/authentication", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<?> authenticateCibil(@PathVariable(name = "applicationid") Long applicationId,
			@PathVariable(name = "cibilreference") Long cibilReferenceKey, @RequestBody CibilRequest cibilRequest,
			BindingResult bindingResult, @RequestHeader HttpHeaders headers) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER, "Start authenticateCibil");
		ResponseEntity<?> response = new ResponseEntity<CibilResponseWrapper>(creditBusinessCibilOtpService
				.authenticateCibil(applicationId, cibilReferenceKey, cibilRequest, headers), HttpStatus.OK);
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.CONTROLLER, "End authenticateCibil");
		return response;
	}
}
