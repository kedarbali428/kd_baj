package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.RISKOFFERTYPE;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.BundleProduct;
import com.bajaj.markets.credit.business.beans.BundleProductRider;
import com.bajaj.markets.credit.business.beans.FppBundleBean;
import com.bajaj.markets.credit.business.beans.FppDetails;
import com.bajaj.markets.credit.business.beans.Nominee;
import com.bajaj.markets.credit.business.beans.OpenArcFppOutput;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.VasAppStatusEnum;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Component
public class Fpp {
	private static final String NAME = "name";
	private static final String DATEOFBIRTH = "dateOfBirth";
	private static final String RELATIONSHIP = "relationship";
	private static final String APP_STATUS = "appstatus";
	private static final String APP_LOAN_PRICING_KEY = "appLoanPricingKey";

	static final String PRICING_PAYLOAD = "pricingPayload";
	
	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private CustomDefaultHeaders customDefaultHeaders;

	@Autowired
	private Application applicationListener;

	@Autowired
	private MasterDataRedisClientHelper redisHelper;

	@Autowired
	private CreditBusinessGinHelper ginHelper;

	Gson g = new GsonBuilder().serializeNulls().create();

	private static final String CLASS_NAME = Fpp.class.getCanonicalName();

	public void setDefaultFlags(DelegateExecution execution) {
		execution.setVariable(CreditBusinessConstants.FPPAPPLICABLE, false);
		execution.setVariable(CreditBusinessConstants.BUNDLEPRESENT, false);
		execution.setVariable(CreditBusinessConstants.BUNDLE_REJECTED, false);
		execution.setVariable(CreditBusinessConstants.VALID_FPP_BUNDLE, false);

		boolean employerRequired = false;
		if (execution.getVariable(RISKOFFERTYPE) != null) {
			employerRequired = ginHelper.checkAllowEmployerForEtbGin(execution.getVariable(RISKOFFERTYPE).toString());
		}
		execution.setVariable(CreditBusinessConstants.EMPLOYER_REQUIRED, employerRequired);
	}

	@SuppressWarnings("unchecked")
	public void preVasApplicationCreate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preVasApplicationCreate");
		JSONObject vasApplicationRequest = new JSONObject();
		JSONObject userProfile = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.USERPROFILEOUTPUT));
		String requestStr = CreditBusinessHelper.objectToJson(execution.getVariable(CreditBusinessConstants.REQUEST));
		FppDetails request = g.fromJson(requestStr, FppDetails.class);
		if (request != null && request.getBundleData() != null && request.getBundleData().getOpenArcFppOutput() != null && userProfile != null) {
			if (execution.getVariable(CreditBusinessConstants.BUNDLEPRESENT) != null
					&& (boolean) execution.getVariable(CreditBusinessConstants.BUNDLEPRESENT)) {
				if (execution.getVariable(CreditBusinessConstants.VAS_APPLICATION_KEY) != null
						&& !"0".equals(execution.getVariable(CreditBusinessConstants.VAS_APPLICATION_KEY).toString())) {
					vasApplicationRequest.put("applicationKey", execution.getVariable(CreditBusinessConstants.VAS_APPLICATION_KEY));
				}
			}

			vasApplicationRequest.put("sourceApplicationKey", execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
			vasApplicationRequest.put("applicantKey", execution.getVariable(CreditBusinessConstants.APPLICANTID));
			vasApplicationRequest.put("dateOfBirth", userProfile.get(CreditBusinessConstants.DATE_OF_BIRTH));
			vasApplicationRequest.put("mobileNumber", userProfile.get(CreditBusinessConstants.MOBILE));
			vasApplicationRequest.put(CreditBusinessConstants.NAME, userProfile.get(CreditBusinessConstants.NAME));

			JSONObject applicationResume = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.APPLICATION_RESUME));
			if (applicationResume != null) {
				vasApplicationRequest.put("sourceProductCategoryKey", applicationResume.get("l2ProductKey"));
				vasApplicationRequest.put("prodkey", applicationResume.get("l3ProductKey"));
				vasApplicationRequest.put("sourceProductMasterKey", 69);
			}

			Double genderKey = Double.valueOf(userProfile.get(CreditBusinessConstants.GENDERKEY).toString());
			if (genderKey != null) {
				Reference genderRef = redisHelper.getGenderReferenceByTypeKey(genderKey.longValue());
				vasApplicationRequest.put("gender", genderRef.getCode());
			}

			FppBundleBean bundleData = request.getBundleData();
			OpenArcFppOutput openArcFppOut = bundleData.getOpenArcFppOutput();
			vasApplicationRequest.put("fppPlanCode", openArcFppOut.getPlanCode());
			if (!CollectionUtils.isEmpty(openArcFppOut.getProducts())) {
				List<JSONObject> productList = new ArrayList<>();
				for (BundleProduct product : openArcFppOut.getProducts()) {
					JSONObject p = new JSONObject();
					p.put("costWithGst", product.getCostWithGst());
					p.put("perceivedvalue", product.getPv());
					p.put("premiumWithGst", product.getPremiumWithGst());
					p.put("premiumwithoutgst", product.getPremiumWithoutGST());
					p.put("productCode", product.getProductCode());
					p.put("productName", product.getProductName());
					p.put("sumAssured", product.getSumAssured());
					p.put("tenure", product.getTenure());
					if (!CollectionUtils.isEmpty(product.getRiders())) {
						List<JSONObject> riderList = new ArrayList<>();
						for (BundleProductRider rider : product.getRiders()) {
							if (!StringUtils.isEmpty(rider.getRiderCode())) {
								JSONObject r = new JSONObject();
								r.put("premiumAmmount", rider.getPremiumAmount());
								r.put("riderCode", rider.getRiderCode());
								r.put("riderName", rider.getRiderUserFriendlyName());
								r.put("sumAssured", rider.getSumAssured());
								r.put("tenure", rider.getTenure());
								riderList.add(r);
							}
						}
						p.put("riders", riderList);
					}
					productList.add(p);
				}
				vasApplicationRequest.put("products", productList);
			}
		}
		execution.setVariable(CreditBusinessConstants.PAYLOAD, vasApplicationRequest);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preVasApplicationCreate");
	}

	public void postVasApplicationCreate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postVasApplicationCreate");
		execution.setVariable(CreditBusinessConstants.VAS_APPLICATION_KEY, null);
		JSONObject vasOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		if (vasOutput != null && vasOutput.get(CreditBusinessConstants.APPLICATIONKEY) != null) {
			Double vasAppKey = Double.valueOf(vasOutput.get(CreditBusinessConstants.APPLICATIONKEY).toString());
			execution.setVariable(CreditBusinessConstants.VAS_APPLICATION_KEY, vasAppKey.longValue());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postVasApplicationCreate");
	}

	@SuppressWarnings("unchecked")
	public void preVasCostSave(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preVasCostSave");
		String requestStr = CreditBusinessHelper.objectToJson(execution.getVariable(CreditBusinessConstants.REQUEST));
		FppDetails request = g.fromJson(requestStr, FppDetails.class);
		if (request != null && request.getBundleData() != null && request.getBundleData().getOpenArcFppOutput() != null) {
			FppBundleBean bundleData = request.getBundleData();
			OpenArcFppOutput openArcFppOut = bundleData.getOpenArcFppOutput();

			JSONObject payload = new JSONObject();
			payload.put("applicationKey", execution.getVariable(CreditBusinessConstants.VAS_APPLICATION_KEY));
			payload.put("actualPrice", openArcFppOut.getActualFppPriceWithGST());
			payload.put("maxPrice", openArcFppOut.getActualFppPriceWithGST());
			payload.put("floorPrice", openArcFppOut.getFloorPriceWithGST());
			payload.put("oldProfit", openArcFppOut.getOldProfit());
			payload.put("withPlanRoi", openArcFppOut.getWithFppRoi());
			payload.put("saveRoi", openArcFppOut.getWithFppSaveRoi());
			payload.put("savingAmount", openArcFppOut.getWithFppSavingAmount());
			payload.put("source", CreditBusinessConstants.JOURNEY);
			payload.put("status", CreditBusinessConstants.APPROVED);
			if (customDefaultHeaders != null) {
				payload.put("raisedBy", customDefaultHeaders.getUserKey());
				payload.put("approvedBy", customDefaultHeaders.getUserKey());
			}
			payload.put("newProfit", null);
			execution.setVariable(CreditBusinessConstants.PAYLOAD, payload);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preVasCostSave");
	}

	public void postVasCostSave(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postVasCostSave");
		execution.setVariable(CreditBusinessConstants.VAS_COST_OUTPUT, execution.getVariable(CreditBusinessConstants.OUTPUT));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postVasCostSave");
	}

	@SuppressWarnings("unchecked")
	public void preSaveQuestions(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preSaveQuestions");
		String requestStr = CreditBusinessHelper.objectToJson(execution.getVariable(CreditBusinessConstants.REQUEST));
		FppDetails request = g.fromJson(requestStr, FppDetails.class);
		if (request != null && !CollectionUtils.isEmpty(request.getQuestionAnswerList())) {
			JSONObject questionRequest = new JSONObject();
			questionRequest.put("questionAnswerList", request.getQuestionAnswerList());
			execution.setVariable(CreditBusinessConstants.PAYLOAD, questionRequest);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preSaveQuestions");
	}

	public void postSaveQuestions(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postSaveQuestions");
		JSONObject output = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.BUNDLE_REJECTED, false);
		if (output != null && output.get("rejectStatus") != null) {
			execution.setVariable(CreditBusinessConstants.BUNDLE_REJECTED, (Boolean) output.get("rejectStatus"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postSaveQuestions");
	}

	public void prePiData(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start prePiData");
		String requestStr = CreditBusinessHelper.objectToJson(execution.getVariable(CreditBusinessConstants.REQUEST));
		FppDetails request = g.fromJson(requestStr, FppDetails.class);
		if (request != null && request.getFppAttributeAtributes() != null) {
			execution.setVariable(CreditBusinessConstants.PAYLOAD, request.getFppAttributeAtributes());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End prePiData");
	}

	@SuppressWarnings("unchecked")
	public void prePricingUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start prePricingUpdate");
		execution.setVariable(CreditBusinessConstants.PAYLOAD, null);
		Map<String, Object> existingPricing = (Map<String, Object>) execution.getVariable(PRICING_PAYLOAD);
		JSONObject vasCostOutput = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.VAS_COST_OUTPUT));
		if (vasCostOutput != null && existingPricing != null) {
			existingPricing.put(CreditBusinessConstants.FPPSELECTED, true);
			existingPricing.put("roiWithBundle", vasCostOutput.get("withPlanRoi"));
			existingPricing.put("pricingStatus", "Approved");
			existingPricing.put("raisedBy", vasCostOutput.get("raisedBy"));
			existingPricing.put("source", CreditBusinessConstants.JOURNEY.toUpperCase());
			List<JSONObject> bundlePriceList = new ArrayList<JSONObject>();
			JSONObject bundlePrice = new JSONObject();
			bundlePrice.put("bundleFinalPrice", vasCostOutput.get("actualPrice"));
			bundlePrice.put("bundleFloorPrice", vasCostOutput.get("floorPrice"));
			bundlePrice.put("bundleMaxPrice", vasCostOutput.get("maxPrice"));
			bundlePriceList.add(bundlePrice);
			existingPricing.put("bundlePrice", bundlePriceList);
			execution.setVariable(CreditBusinessConstants.PAYLOAD, existingPricing);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End prePricingUpdate");
	}

	@SuppressWarnings("unchecked")
	public void preBundleKeyUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preBundleKeyUpdate");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("bundleSelected", true);
		jsonObject.put("apploanpricingkey", execution.getVariable(APP_LOAN_PRICING_KEY));
		jsonObject.put("applicationKey", execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		jsonObject.put("bundleApplicationKey", execution.getVariable(CreditBusinessConstants.VAS_APPLICATION_KEY));
		jsonObject.put("source", CreditBusinessConstants.JOURNEY.toUpperCase());
		jsonObject.put("bundlerevision", 1);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, jsonObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBundleKeyUpdate");
	}

	@SuppressWarnings("unchecked")
	public void preBundleKeyRemove(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preBundleKeyRemove");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("bundleSelected", false);
		jsonObject.put("apploanpricingkey", execution.getVariable(APP_LOAN_PRICING_KEY));
		jsonObject.put("applicationKey", execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID));
		jsonObject.put("bundleApplicationKey", null);
		jsonObject.put("source", CreditBusinessConstants.JOURNEY.toUpperCase());
		jsonObject.put("bundlerevision", 0);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, jsonObject);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBundleKeyRemove");
	}

	public void postGetBundle(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postGetBundle");
		execution.setVariable(CreditBusinessConstants.FPPSELECTED, false);
		execution.setVariable(CreditBusinessConstants.VAS_APPLICATION_KEY, null);
		ArrayList<?> responseList = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		if (!CollectionUtils.isEmpty(responseList)) {
			for (Object o : responseList) {
				JSONObject jsonObject = CreditBusinessHelper.getJSONObject(o);
				if (jsonObject.get("source") != null && CreditBusinessConstants.JOURNEY.equalsIgnoreCase(jsonObject.get("source").toString())) {
					if (jsonObject.get("bundleSelected") != null && (boolean) jsonObject.get("bundleSelected")) {
						execution.setVariable(CreditBusinessConstants.FPPSELECTED, true);
						Double vasAppKey = Double.valueOf(jsonObject.get("bundleApplicationKey").toString());
						execution.setVariable(CreditBusinessConstants.VAS_APPLICATION_KEY, vasAppKey.longValue());
					}
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetBundle");
	}

	@SuppressWarnings("unchecked")
	public void preNomineeUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preNomineeUpdate");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (request != null && request.get("nomineeDetails") != null) {
			ArrayList<JSONObject> payloadArr = new ArrayList<JSONObject>();
			ArrayList<?> nomineeArr = (ArrayList<?>) request.get("nomineeDetails");
			for (Object n : nomineeArr) {
				JSONObject nominee = CreditBusinessHelper.getJSONObject(n);
				JSONObject relationship = CreditBusinessHelper.getJSONObject(nominee.get("relationship"));
				JSONObject payload = new JSONObject();
				payload.put("name", nominee.get("name"));
				payload.put("dateOfBirth", nominee.get("dateOfBirth"));
				payload.put("relationship", relationship.get(CreditBusinessConstants.VALUE));
				payloadArr.add(payload);
			}
			execution.setVariable(CreditBusinessConstants.PAYLOAD, payloadArr);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preNomineeUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void prefppNomineeUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preNomineeUpdate");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		FppDetails fppDetailsReq = mapper.convertValue(request, FppDetails.class);
		if (null != fppDetailsReq && null != fppDetailsReq.getBundleData()) {
			ArrayList<JSONObject> payloadArr = new ArrayList<JSONObject>();
			List<Nominee> nomineeArr = fppDetailsReq.getBundleData().getNomineeDetails();
			for (Nominee nominee : nomineeArr) {
				JSONObject payload = new JSONObject();
				payload.put(NAME, nominee.getName());
				payload.put(DATEOFBIRTH, nominee.getDateOfBirth());
				payload.put(RELATIONSHIP,
						null != nominee.getRelationship() ? nominee.getRelationship().getValue() : null);
				payloadArr.add(payload);
			}
			execution.setVariable(CreditBusinessConstants.PAYLOAD, payloadArr);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preNomineeUpdate");
	}

	@SuppressWarnings("unchecked")
	public void postGetLoanPricingFpp(DelegateExecution execution) {
		applicationListener.postGetLoanPricing(execution);
		Map<String, Object> existingpricing = (Map<String, Object>) execution.getVariable(CreditBusinessConstants.PAYLOAD);
		execution.setVariable(PRICING_PAYLOAD, existingpricing);
		execution.setVariable(APP_LOAN_PRICING_KEY, existingpricing.get(APP_LOAN_PRICING_KEY));
	}

	public void prePricingUpdateWithoutFpp(DelegateExecution execution) {
		execution.setVariable(CreditBusinessConstants.PAYLOAD, execution.getVariable(PRICING_PAYLOAD));
	}

	@SuppressWarnings("unchecked")
	public void postGetBundleSelected(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postGetBundleSelected");
		execution.setVariable(CreditBusinessConstants.BUNDLEPRESENT, false);
		execution.setVariable(CreditBusinessConstants.VAS_APPLICATION_KEY, null);
		ArrayList<?> responseList = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		if (!CollectionUtils.isEmpty(responseList)) {
			for (Object bundle : responseList) {
				Map<String, Object> bundleData = (Map<String, Object>) bundle;
				if (bundleData.get("source") != null && CreditBusinessConstants.JOURNEY.equalsIgnoreCase(bundleData.get("source").toString())) {
					if (bundleData != null && bundleData.get("bundleSelected") != null && (boolean) bundleData.get("bundleSelected")) {
						execution.setVariable(CreditBusinessConstants.BUNDLEPRESENT, true);
						execution.setVariable(CreditBusinessConstants.VAS_APPLICATION_KEY, bundleData.get("bundleApplicationKey"));
					}
					break;
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end postGetBundleSelected");
	}

	public void postGetVasApplication(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postGetVasApplication");
		JSONObject vasApplication = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		execution.setVariable(CreditBusinessConstants.BUNDLE_REJECTED, false);
		if (vasApplication.get(APP_STATUS) != null && VasAppStatusEnum.REJECTED.getValue().equalsIgnoreCase(vasApplication.get(APP_STATUS).toString())) {
			execution.setVariable(CreditBusinessConstants.BUNDLE_REJECTED, true);
			execution.setVariable(CreditBusinessConstants.VALID_FPP_BUNDLE, false);
		} else {
			execution.setVariable(CreditBusinessConstants.VALID_FPP_BUNDLE, true);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetVasApplication");
	}

	@SuppressWarnings("unchecked")
	public void preUpdateUserProfile(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start preUpdateUserProfile");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject bundleData = CreditBusinessHelper.getJSONObject(request.get("bundleData"));
		JSONObject gender = CreditBusinessHelper.getJSONObject(bundleData.get(CreditBusinessConstants.GENDER));
		JSONObject payload = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.USERPROFILEOUTPUT));
		payload.put(CreditBusinessConstants.GENDERKEY, gender.get(CreditBusinessConstants.KEY));
		execution.setVariable(CreditBusinessConstants.PAYLOAD, payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preUpdateUserProfile");
	}

	public void postUpdateUserProfile(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postUpdateUserProfile");
		execution.setVariable(CreditBusinessConstants.USERPROFILEOUTPUT, execution.getVariable(CreditBusinessConstants.OUTPUT));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postUpdateUserProfile");
	}
	
	public void postCheckEpPricingApproval(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start postCheckEpPricingApproval");
		List<?> loanPricingDetails = (List<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		boolean isEpPricingApproved = false;
		if (!CollectionUtils.isEmpty(loanPricingDetails)) {
			Optional<?> epPricing = loanPricingDetails.stream().filter(i -> {
				Map<String, Object> j = (Map<String, Object>) i;
				return (j.get("pricingStatus") != null && j.get("source") != null
						&& "EP".equalsIgnoreCase(j.get("source").toString())
						&& CreditBusinessConstants.APPROVED.equalsIgnoreCase(j.get("pricingStatus").toString()));
			}).findFirst();

			if (epPricing.isPresent()) {
				isEpPricingApproved = true;
			}
		}
		execution.setVariable(CreditBusinessConstants.IS_EP_PRICING_APPROVED, isEpPricingApproved);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postCheckEpPricingApproval");
	}
	
	public void buildRequestForApplicationParamsUpdate(DelegateExecution execution) {
		JSONObject payload = new JSONObject();
		JSONObject applicationParameters = new JSONObject();
		applicationParameters.put("fppselectedbyuser", execution.getVariable(CreditBusinessConstants.FPPSELECTED));
		payload.put("applicationParameters", applicationParameters);
		
		execution.setVariable(CreditBusinessConstants.PAYLOAD, payload);
	}
	
	public void setDefaultParams(DelegateExecution execution){
		if(null == execution.getVariable(CreditBusinessConstants.FPPSELECTED)) {
			logger.warn(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "FPP not received from user" + execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
			execution.setVariable(CreditBusinessConstants.FPPSELECTED, true);
		}
	}
}
