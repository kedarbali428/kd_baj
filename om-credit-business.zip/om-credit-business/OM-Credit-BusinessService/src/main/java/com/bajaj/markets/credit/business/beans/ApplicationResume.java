package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class ApplicationResume implements Serializable{

	private static final long serialVersionUID = 1122361701102372777L;
	
	private String applicationKey;
	private String childApplicationKey;
	private String l2ProductCode;
	private Integer l2ProductKey;
	private String l3ProductCode;
	private Integer l3ProductKey;
	private String l4ProductCode;
	private Integer l4ProductKey;
	private Integer principalKey;
	private AppOfferDetBean offerDetails;
	private boolean resume;
	private String mobile;
	private String dateofbirth;
	
	public String getApplicationKey() {
		return applicationKey;
	}
	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}
	public String getChildApplicationKey() {
		return childApplicationKey;
	}
	public void setChildApplicationKey(String childApplicationKey) {
		this.childApplicationKey = childApplicationKey;
	}
	public String getL2ProductCode() {
		return l2ProductCode;
	}
	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}
	public Integer getL2ProductKey() {
		return l2ProductKey;
	}
	public void setL2ProductKey(Integer l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}
	public String getL3ProductCode() {
		return l3ProductCode;
	}
	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}
	public Integer getL3ProductKey() {
		return l3ProductKey;
	}
	public void setL3ProductKey(Integer l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}
	public String getL4ProductCode() {
		return l4ProductCode;
	}
	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}
	public Integer getL4ProductKey() {
		return l4ProductKey;
	}
	public void setL4ProductKey(Integer l4ProductKey) {
		this.l4ProductKey = l4ProductKey;
	}
	public Integer getPrincipalKey() {
		return principalKey;
	}
	public void setPrincipalKey(Integer principalKey) {
		this.principalKey = principalKey;
	}
	public boolean isResume() {
		return resume;
	}
	public void setResume(boolean resume) {
		this.resume = resume;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public AppOfferDetBean getOfferDetails() {
		return offerDetails;
	}
	public void setOfferDetails(AppOfferDetBean offerDetails) {
		this.offerDetails = offerDetails;
	}
	
}
