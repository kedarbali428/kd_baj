package com.bajaj.markets.credit.business.beans;

public class AdditionalParameterDetail {
	
	private String utmSource;
	private String utmCampaign;
	private String utmMedium;
	private String utmContent;
	private String utmTerm;
	private String utmChannel;

	public void setUtmSource(String utmSource) {
		this.utmSource = utmSource;
	}

	public void setUtmCampaign(String utmCampaign) {
		this.utmCampaign = utmCampaign;
	}

	public void setUtmMedium(String utmMedium) {
		this.utmMedium = utmMedium;
	}

	public void setUtmContent(String utmContent) {
		this.utmContent = utmContent;
	}

	public void setUtmTerm(String utmTerm) {
		this.utmTerm = utmTerm;
	}

	public void setUtmChannel(String utmChannel) {
		this.utmChannel = utmChannel;
	}

	 

}
