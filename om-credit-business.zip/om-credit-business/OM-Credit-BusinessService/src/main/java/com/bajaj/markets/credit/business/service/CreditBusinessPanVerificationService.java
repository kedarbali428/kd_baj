package com.bajaj.markets.credit.business.service;

import com.bajaj.markets.credit.business.beans.PanValidationRequest;
import com.bajaj.markets.credit.business.beans.PanValidationResponse;

public interface CreditBusinessPanVerificationService {

	PanValidationResponse validateAndUpdatePan(Long applicationId, PanValidationRequest panValidationRequest);

}
