package com.bajaj.markets.credit.business.beans;

import java.util.List;

public class CustomerDemog {

	private List<Address> addressList;
	private UserProfile userProfile;
	
	public List<Address> getAddressList() {
		return addressList;
	}
	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}
	public UserProfile getUserProfile() {
		return userProfile;
	}
	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}
	@Override
	public String toString() {
		return "CustomerDemog [addressList=" + addressList + ", userProfile=" + userProfile + "]";
	}
}
