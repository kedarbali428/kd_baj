package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SUB_STAGE_CODE;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@Component
public class StageSubStage {

	private static final String EMPTY_STRING = "";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	private static final String CLASS_NAME = StageSubStage.class.getCanonicalName();

	public void preAdditionalDetailForChild(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCardApplication");
		updateStage(execution, 60L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCardApplication");
	}

	public void preCardListing(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCardListing");
		updateStage(execution, 50L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCardListing");
	}

	public void preBasicDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preBasicDetails stage update");
		updateStage(execution, 30L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBasicDetails");
	}

	@SuppressWarnings("unchecked")
	public void updateStage(DelegateExecution execution, Long percetage) {
		JSONObject stageUpdate = new JSONObject();
		stageUpdate.put("percentageCompletion", percetage);
		execution.setVariable(CreditBusinessConstants.PAYLOAD, stageUpdate);
	}

	public void preConsentStageForChild(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preConsentStageForChild");
		updateStage(execution, 65L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preConsentStageForChild");
	}

	public void preSentToBankStageForChild(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preSentToBankStageForChild");
		updateStage(execution, 70L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preSentToBankStageForChild");
	}

	public void preBankApprovalStageForChild(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preBankApprovalStageForChild");
		updateStage(execution, 80L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBankApprovalStageForChild");
	}

	public void preProfessionalDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preProfessionalDetails stage update");
		updateStage(execution, 20L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preProfessionalDetails");
	}

	public void preCibilConsent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCibilConsent stage update");
		updateStage(execution, 40L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCibilConsent");
	}

	public void preProductSummary(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preProductSummary stage update");
		updateStage(execution, 55L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preProductSummary");
	}

	public void postFetchStageSubStage(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postFetchStageSubStage");
		JSONObject fetchStageSubStage = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		Double percentageCompletion = null != fetchStageSubStage.get(CreditBusinessConstants.PERCENTAGECOMPLETION)
				? ((Double) fetchStageSubStage.get(CreditBusinessConstants.PERCENTAGECOMPLETION))
				: null;
		Object subStageCode = fetchStageSubStage.get(SUB_STAGE_CODE);
		
		execution.setVariable(CreditBusinessConstants.STAGEPERCENTAGE, percentageCompletion != null ? percentageCompletion.intValue() : null);
		execution.setVariable(SUB_STAGE_CODE, null != subStageCode ? subStageCode.toString() : EMPTY_STRING);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postFetchStageSubStage");
	}

	public void preRejection(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preRejection");
		updateStage(execution, 45L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preRejection");
	}

	public void preKarzaRejection(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preKarzaRejection");
		updateStage(execution, 45L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preKarzaRejection");
	}

	public void preEsign(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preESign");
		updateStage(execution, 90L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preESign");
	}

	public void preThankyou(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preThankyou");
		updateStage(execution, 93L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preThankyou");
	}

	public void preFppBundleSelection(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preFppBundleSelection");
		updateStage(execution, 52L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preFppBundleSelection");
	}

	public void preBundleRejection(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preBundleRejection");
		updateStage(execution, 53L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBundleRejection");
	}

	public void preExcusive(DelegateExecution execution) {
		System.out.println(execution.getVariable(CreditBusinessConstants.STAGEPERCENTAGE));
	}

	public void preIncomeVerification(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preIncomeVerification");
		updateStage(execution, 70L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preIncomeVerification");
	}

	public void preSalarySelection(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preIncomeVerification");
		updateStage(execution, 72L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preIncomeVerification");
	}

	public void preBankVerification(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preBankVerification");
		updateStage(execution, 80L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBankVerification");
	}

	public void preAdditionalDetailForLoansChild(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preAdditionalDetailForLoansChild");
		updateStage(execution, 60L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preAdditionalDetailForLoansChild");
	}

	public void preEmailVerification(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preEmailVerification");
		updateStage(execution, 77L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preEmailVerification");
	}

	public void preLeadPush(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preCasePushToPartner");
		updateStage(execution, Long.valueOf(execution.getVariable("leadPushStagePercentage").toString()));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preCasePushToPartner");
	}

	public void prePartnerSoftApproval(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preLeadPush");
		updateStage(execution, 65L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preLeadPush");
	}
	
	public void prePartnerFinalApproval(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preLeadPush");
		updateStage(execution, 75L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preLeadPush");
	}

	public void postSecuredLeadPush(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preIncomeVerification");
		updateStage(execution, 70L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preIncomeVerification");
	}

	public void postSecuredLeadPushFailure(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preIncomeVerification");
		updateStage(execution, 67L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preIncomeVerification");
	}

	public void preRejectionAfterListing(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preRejectionAfterListing");
		updateStage(execution, 50L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preRejectionAfterListing");
	}
	
	public void preAdditonalPropertyDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preRejectionAfterListing");
		updateStage(execution, 60L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preRejectionAfterListing");
	}
	
	public void preSecuredAdditonalDetails(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preRejectionAfterListing");
		updateStage(execution, 65L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preRejectionAfterListing");
	}
	
	public void preBflModelBLeadPush(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preBflModelBLeadPush");
		updateStage(execution, 51L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preBflModelBLeadPush");
	}

	public void preDemogConsent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDemogConsent");
		updateStage(execution, 53L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preDemogConsent");
	}
	
	public void preDemog(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDemog");
		updateStage(execution, 55L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preDemog");
	}
	
	public void preStageUpdateForMuthoot(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preStageUpdateForMuthoot");
		updateStage(execution, 63L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preStageUpdateForMuthoot");
	}
	
	public void preDemogConsentLoans(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDemogConsentLoans");
		updateStage(execution, 57L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preDemogConsentLoans");
	}
	
	public void preDemogLoans(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDemogLoans");
		updateStage(execution, 58L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preDemogLoans");
	}
	
	public void preDisbursementConsent(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDisbursementConsent");
		updateStage(execution, 91L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preDisbursementConsent");
	}
	
	public void preDisbursementConsentVerification(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDisbursementConsentVerification");
		updateStage(execution, 98L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preDisbursementConsentVerification");
	}
	
	public void preDisbursementInitiation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preDisbursementInitiation");
		updateStage(execution, 99L);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preDisbursementInitiation");
	}
	
	public void preProfileDetails(DelegateExecution execution) {
		updateStage(execution, 20L);
	}
	
	public void preProductList(DelegateExecution execution) {
		updateStage(execution, 50L);
	}
}
