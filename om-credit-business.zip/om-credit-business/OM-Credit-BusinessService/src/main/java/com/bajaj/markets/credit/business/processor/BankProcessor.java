package com.bajaj.markets.credit.business.processor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;

@Component
public class BankProcessor implements BaseProcessor {

	@Autowired
	ApplictionClient applictionClient;
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	private static final String CLASSNAME = BankProcessor.class.getName();
	
	private ThreadLocal<Boolean> bankUpdateFlag = new ThreadLocal<Boolean>();
		
	@Override
	public boolean initDataCopy(List<OfferDetailsBean> dataCources, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside BankProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		bankUpdateFlag.set(false);
		try {
			dataCources.forEach(dataSource -> {
				if(!CollectionUtils.isEmpty(dataSource.getBanks())){
					dataSource.getBanks().forEach(bank -> {
						bankUpdateFlag.set(applictionClient.saveBank(bank, applicantDataBean));
					});
					
					if(bankUpdateFlag.get()) {
						logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside BankProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - bank data processed for "+dataSource.getDataSourceName());
						throw new CreditBusinessException();
					} else {
						logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside BankProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - bank data not processed for "+dataSource.getDataSourceName());
					}
				}
			});
		} catch (CreditBusinessException exception) {
			return true;
		} catch(Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside BankProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - bank call failed", e);
			return false;
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside BankProcessor - initDataCopy method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - end");
		return false;
	}
}