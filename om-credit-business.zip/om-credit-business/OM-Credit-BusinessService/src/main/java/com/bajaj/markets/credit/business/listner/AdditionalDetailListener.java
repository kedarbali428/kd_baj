package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.ADD_SRC_OFFERAPI;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DESIGNATION_REQUIRED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMPLOYER_REQUIRED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.IS_DUMMY_EMAIL;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.IS_REJECTED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PERSONAL_EMAIL_REQUIRED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.TAKE_BACK_TO_LISTING_PAGE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.WORKEMAILID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.DUMMYEMAIL_REGEX;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class AdditionalDetailListener {


	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Value("${api.omcreditapplicationservice.address.PUT.url}")
	private String putAddressURLV2;

	private static final String CLASS_NAME = AdditionalDetailListener.class.getCanonicalName();
	private static final String OCCUPATION = "occupation";

	public void postAdditionalDetailsLoan(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postAdditionalDetailsLoan");
		execution.setVariable(CreditBusinessConstants.KARZA_TYPE, 2);
		execution.setVariable(PERSONAL_EMAIL_REQUIRED, false);
		execution.setVariable(DESIGNATION_REQUIRED, false);
		execution.setVariable(EMPLOYER_REQUIRED, false);
		execution.setVariable(IS_REJECTED, false);
		execution.setVariable(TAKE_BACK_TO_LISTING_PAGE, false);
		
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		
		if (request.get(PERSONAL_EMAIL_REQUIRED) != null && (boolean) request.get(PERSONAL_EMAIL_REQUIRED)) {
			execution.setVariable(PERSONAL_EMAIL_REQUIRED, true);
		}
		
		if (request.get(DESIGNATION_REQUIRED) != null && (boolean) request.get(DESIGNATION_REQUIRED)) {
			execution.setVariable(DESIGNATION_REQUIRED, true);
		}
		
		if (request.get(EMPLOYER_REQUIRED) != null && (boolean) request.get(EMPLOYER_REQUIRED)) {
			execution.setVariable(EMPLOYER_REQUIRED, true);
		}
		
		if (request.get(WORKEMAILID) != null) {
			String workEmail = (String) request.get(WORKEMAILID);
			boolean isDummyEmail = Pattern.matches(DUMMYEMAIL_REGEX, workEmail.toLowerCase());
			execution.setVariable(IS_DUMMY_EMAIL, isDummyEmail);
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postAdditionalDetailsLoan");
	}

	public void multipleAddressUpdate(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start multipleAddressUpdate");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		if (request.get("addressDetails") != null) {
			ArrayList<?> addressList = (ArrayList<?>) request.get("addressDetails");
			if (!CollectionUtils.isEmpty(addressList)) {
				Map<String, String> params = new HashMap<String, String>();
				params.put("applicationid", execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID).toString());
				params.put("userattributekey", execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
				for(Object adrs : addressList) {
					String addressStr = CreditBusinessHelper.objectToJson(adrs);
					JSONObject addressJson = CreditBusinessHelper.getJSONObject(adrs);
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "multipleAddressUpdate : addressJson before character skip "+addressJson);
					addressJson.put("addressLine1",creditBusinessHelper.skipSpecialCharactersFromAddress(addressJson.get("addressLine1").toString()));
					addressJson.put("addressLine2",creditBusinessHelper.skipSpecialCharactersFromAddress(addressJson.get("addressLine2").toString()));
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "multipleAddressUpdate : addressJson after character skip "+addressJson);
					apiCallsHelper.callApi(putAddressURLV2, HttpMethod.PUT, params, CreditBusinessHelper.objectToJson(addressJson), Object.class);
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End multipleAddressUpdate");
	}
	
	@SuppressWarnings("unchecked")
	public void preNonGinPersonalEmail(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start preNonGinPersonalEmail");
		JSONObject request = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.REQUEST));
		JSONObject payload = new JSONObject();
		String personalEmail = request.get(CreditBusinessConstants.PERSONALEMAILID) != null ? (String) request.get(CreditBusinessConstants.PERSONALEMAILID)
				: null;
		payload.put("email", personalEmail);
		payload.put("typeKey", EmailTypeEnum.PERON1.getValue());
		execution.setVariable(CreditBusinessConstants.PAYLOAD, payload);
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End preNonGinPersonalEmail");
	}
	
	
	public void preGinPutV2Address(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGinGetV2Address");
		ArrayList<?> output = (ArrayList<?>) execution.getVariable(CreditBusinessConstants.OUTPUT);
		ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<Address> addressList = mapper.convertValue(output, new TypeReference<List<Address>>() {
		});

		for (Address address : addressList) {
			if (address.getAddressSource() != null && address.getAddressSource().equalsIgnoreCase(ADD_SRC_OFFERAPI)) {
				address.setPreferredFlag(true);
				execution.setVariable(CreditBusinessConstants.PAYLOAD, address);
				break;
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGinGetV2Address");
	}
	
	public void postGetOccupation(DelegateExecution execution) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "Start postGetOccupation");
		JSONObject profession = CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
		JSONObject ocupationType = CreditBusinessHelper.getJSONObject(profession.get("ocupationType"));
		execution.setVariable(CreditBusinessConstants.OCCUPATION_TYPE, ocupationType.get(CreditBusinessConstants.CODE).toString());
		execution.setVariable(OCCUPATION, execution.getVariable(CreditBusinessConstants.OUTPUT));
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "End postGetOccupation");
	}
}
