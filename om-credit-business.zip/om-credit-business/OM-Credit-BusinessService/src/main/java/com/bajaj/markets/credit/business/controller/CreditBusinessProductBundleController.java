package com.bajaj.markets.credit.business.controller;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.BundleReject;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.FppBundleBean;
import com.bajaj.markets.credit.business.beans.FppDetails;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.FppNotSelected;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.FppSelected;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.service.CreditBusinessProductBundleService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * 
 * Controller used for Product Bundle related Resources
 * @author 764504
 *
 */
@RestController
@Validated
public class CreditBusinessProductBundleController {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	private CreditBusinessProductBundleService service;

	@Autowired
	private Validator validator;

	private static final String CLASSNAME = CreditBusinessProductBundleController.class.getName();

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = { @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Fetch FPP product bundle", notes = "Fetch FPP product bundle", httpMethod = "GET")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "FPP details fetched successfully.", response = FppBundleBean.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@GetMapping(path = "${api.omcreditbusinessservice.bundle.fpp.GET.uri}", produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<FppBundleBean> fetchFppBundle(
			@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start  - fetchFppBundle method  :");
		FppBundleBean response = service.fetchFppBundle(applicationId.toString(), headers);
		response.setApplicationId(applicationId.toString());
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "End fetchFppBundle ");
		return new ResponseEntity<FppBundleBean>(response, HttpStatus.OK);
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = { @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Create FPP Bundle against loan application", notes = "Create FPP Bundle against loan application.", httpMethod = "POST")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "FPP bundle created successfully.", response = FppDetails.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(path = "${api.omcreditbusinessservice.bundle.fpp.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<FppDetails> saveFppBundle(
			@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestBody FppDetails request, BindingResult result, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start  - saveFppBundle method  :");

		Class validationObject = getValidationClass(request);
		Set<ConstraintViolation<FppDetails>> validationErrors = validator.validate(request, validationObject);
		if (!CollectionUtils.isEmpty(validationErrors)) {
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Inside saveFppBundle method  - resource validation failed");
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_20", validationErrors.stream().findFirst().get().getMessage()));
		} else {
			FppDetails response = service.saveFppBundle(request, applicationId, headers);
			logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "End saveFppBundle ");
			return new ResponseEntity<FppDetails>(response, HttpStatus.CREATED);
		}
	}

	@Secured(value = { Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.CUSTOMER, Role.EMPLOYEE })
	@ApiImplicitParams(value = { @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header") })
	@ApiOperation(value = "Move rejection stage of workflow", notes = "Move rejection stage of workflow", httpMethod = "POST")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Move rejection stage of workflow", response = ApplicationResponse.class),
			@ApiResponse(code = 401, message = "Unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "Unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input", response = ErrorBean.class),
			@ApiResponse(code = 404, message = "Application not found", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class) })
	@PostMapping(path = "${api.omcreditbusinessservice.bundle.reject.POST.uri}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationResponse> rejectBundle(
			@PathVariable("applicationid") @NotNull(message = "applicationid can not be null or empty") @Digits(fraction = 0, integer = 20, message = "applicationid should be numeric & should not exceeds size") Long applicationId,
			@RequestBody BundleReject request, BindingResult result, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start  - rejectBundle method  :");
		ApplicationResponse response = service.rejectBundle(request, applicationId, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.CONTROLLER, "Start  - rejectBundle method  :");
		return new ResponseEntity<ApplicationResponse>(response, HttpStatus.CREATED);
	}

	private Class getValidationClass(FppDetails req) {
		if (null != req.getIsFppSelected() && req.getIsFppSelected()) {
			return FppSelected.class;
		}
		return FppNotSelected.class;
	}
	
}
