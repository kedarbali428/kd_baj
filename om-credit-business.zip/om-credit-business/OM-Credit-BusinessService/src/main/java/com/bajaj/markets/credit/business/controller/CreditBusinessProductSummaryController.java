package com.bajaj.markets.credit.business.controller;

import java.io.ByteArrayInputStream;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.FppPdfReportResponseBean;
import com.bajaj.markets.credit.business.beans.SummaryDetails;
import com.bajaj.markets.credit.business.beans.SummaryResponse;
import com.bajaj.markets.credit.business.service.CreditBusinessProductSummaryService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
/**
 * Controller for operations of Product Summary
 * 
 * @author 764504
 *
 */
@RestController
public class CreditBusinessProductSummaryController {

	@Autowired
	CreditBusinessProductSummaryService service;

	@Autowired
	BFLLoggerUtilExt logger;

	private static final String CLASS_NAME = CreditBusinessProductSummaryController.class.getCanonicalName();

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(	value = "This API will submit product summary data to the running process",
					notes = "This API will submit product summary data to the running process", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Summary saved successfully", response = SummaryDetails.class),
			@ApiResponse(code = 422, message = "Invalid input parameters", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@PostMapping(	path = "/v1/credit/applications/{applicationid}/summary", consumes = MediaType.APPLICATION_JSON_VALUE,
					produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SummaryDetails> summary(@PathVariable(value = "applicationid") String applicationId,
			@Valid @RequestBody SummaryDetails summaryRequest, BindingResult result, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Started post summary with Request : " + summaryRequest);
		ResponseEntity<SummaryDetails> response = service.postSummary(applicationId, summaryRequest, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End post summary method: ");
		return response;
	}

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(	value = "This API will fetch product summary data to the given application",
					notes = "This API will submit product summary data to the running process", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Summary saved successfully", response = SummaryResponse.class),
			@ApiResponse(code = 404, message = "Resourse not available", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input parameters", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@GetMapping(path = "/v1/credit/applications/{applicationid}/summary", consumes = MediaType.APPLICATION_JSON_VALUE,
				produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SummaryResponse> summary(@PathVariable(value = "applicationid") String applicationId, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Started get summary with applicationId : " + applicationId);
		ResponseEntity<SummaryResponse> response = service.getSummary(applicationId, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End post summary method: ");
		return response;
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(	value = "Export to PDF",
					notes = "This API will create the PDF and save it to document location and return url to respective PDF", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Summary saved successfully" ),
			@ApiResponse(code = 404, message = "Resourse not available", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input parameters", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@GetMapping(path = "/v1/credit/applications/{applicationid}/loanRepaymentSchedule")
	public ResponseEntity<InputStreamResource> generatePDF(@PathVariable(value = "applicationid") String applicationId, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Started generate PDF with applicationId : " + applicationId);
		ByteArrayInputStream result = service.generatePDFByRepaymentSchedule(applicationId,headers);
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Disposition", "inline; filename=loanRepaymentSchedule.pdf");
		header.setContentType(MediaType.parseMediaType("application/pdf"));
		header.setContentLength(result.available());
		InputStreamResource inputStreamResource =new InputStreamResource(result);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Ended generate PDF with applicationId : " + applicationId);
		return new ResponseEntity<InputStreamResource>(inputStreamResource,header,HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE,Role.CUSTOMER})
	@ApiOperation(	value = "This API will fetch FPP PDF Report URL",
					notes = "This API will fetch FPP PDF Report URL", httpMethod = "GET")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "FPP PDF Report URL fetched successfully", response = FppPdfReportResponseBean.class),
			@ApiResponse(code = 404, message = "Resourse not available", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "Invalid input parameters", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some internal error occured", response = ErrorBean.class), })
	@CrossOrigin
	@GetMapping(path = "/v1/credit/applications/{applicationid}/fppPdfReportUrl",
				produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FppPdfReportResponseBean> getFppPdfReportUrl(@PathVariable(value = "applicationid") String applicationId, @RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Started getFppPdfReportUrl for applicationId : " + applicationId);
		ResponseEntity<FppPdfReportResponseBean> response = service.getFppPdfReportUrl(applicationId, headers);
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "End getFppPdfReportUrl method: ");
		return response;
	}
}
