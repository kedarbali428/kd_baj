package com.bajaj.markets.credit.business.helper;

public enum CorporateLinkageEnum {
	GOVTTIEUP("GOVTTIEUP", "Govt. Tie-ups"), CORPORATELLP("CORPORATELLP", "Corporate/ LLP tie-up"),
	INSTITUTE("INSTITUTE", "Trust/Institute/Co-op Society/Hospital/School"), NOTIEUP("NOTIEUP", "NoTie-ups");

	private String code;
	private String value;

	private CorporateLinkageEnum(String code, String value) {
		this.code = code;
		this.value = value;
	}

	public String getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}

	public static String getValueOfCorporateLinkage(String corporateLinkageCode) {
		for (CorporateLinkageEnum map : CorporateLinkageEnum.values()) {
			if (map.code.equals(corporateLinkageCode)) {
				return map.value;
			}
		}
		return null;
	}
}
