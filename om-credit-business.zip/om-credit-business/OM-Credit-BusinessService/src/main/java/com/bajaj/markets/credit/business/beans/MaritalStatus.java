package com.bajaj.markets.credit.business.beans;

public class MaritalStatus {

	private Long maritalStatusKey;
	
	private String maritalStatusCode;
	
	private String maritalStatusValue;

	public Long getMaritalStatusKey() {
		return maritalStatusKey;
	}

	public void setMaritalStatusKey(Long maritalStatusKey) {
		this.maritalStatusKey = maritalStatusKey;
	}

	public String getMaritalStatusCode() {
		return maritalStatusCode;
	}

	public void setMaritalStatusCode(String maritalStatusCode) {
		this.maritalStatusCode = maritalStatusCode;
	}

	public String getMaritalStatusValue() {
		return maritalStatusValue;
	}

	public void setMaritalStatusValue(String maritalStatusValue) {
		this.maritalStatusValue = maritalStatusValue;
	}

	@Override
	public String toString() {
		return "MaritalStatus [maritalStatusKey=" + maritalStatusKey + ", maritalStatusCode=" + maritalStatusCode
				+ ", maritalStatusValue=" + maritalStatusValue + "]";
	}

		
}

