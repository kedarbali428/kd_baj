/**
 * 
 */
package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

/**
 * @author pranoti.pandole
 *
 */
public class DisbursementEventResponseBean  implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String eventType;
	private String status;
	private String msg;
	
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	

}
