package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class ApplicationDetail implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String applicationKey;

	private String parentApplicationKey;

	private String mobile;

	private String dateofbirth;

	private String applicantKey;

	private Long l2ProductKey;

	private String l2ProductCode;

	private Long l3ProductKey;

	private String l3ProductCode;
	
	private Long l4ProductKey;
	
	private String l4ProductCode;
	
	private boolean isInProcessing;

	private Integer applicationStatus;
	
	private String riskoffertype;	

	private Long principalKey;
	
	private LoanPurpose loanPurpose;
	
	private String hlProductIntent;

	private String l2ProductDesc;

	private String l3ProductDesc;

	private String l4ProductDesc;
	
	private String appProcessIdentifier;

	public String getApplicationKey() {
		return applicationKey;
	}

	public void setApplicationKey(String applicationKey) {
		this.applicationKey = applicationKey;
	}

	public String getParentApplicationKey() {
		return parentApplicationKey;
	}

	public void setParentApplicationKey(String parentApplicationKey) {
		this.parentApplicationKey = parentApplicationKey;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(String applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getL2ProductKey() {
		return l2ProductKey;
	}

	public void setL2ProductKey(Long l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}

	public Long getL3ProductKey() {
		return l3ProductKey;
	}

	public void setL3ProductKey(Long l3ProductKey) {
		this.l3ProductKey = l3ProductKey;
	}

	public String getL2ProductCode() {
		return l2ProductCode;
	}

	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public Long getPrincipalKey() {
		return principalKey;
	}

	public void setPrincipalKey(Long principalKey) {
		this.principalKey = principalKey;
	}

	public Long getL4ProductKey() {
		return l4ProductKey;
	}

	public String getL4ProductCode() {
		return l4ProductCode;
	}

	public boolean isInProcessing() {
		return isInProcessing;
	}

	public Integer getApplicationStatus() {
		return applicationStatus;
	}

	public String getRiskoffertype() {
		return riskoffertype;
	}

	public void setL4ProductKey(Long l4ProductKey) {
		this.l4ProductKey = l4ProductKey;
	}

	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}

	public void setInProcessing(boolean isInProcessing) {
		this.isInProcessing = isInProcessing;
	}

	public void setApplicationStatus(Integer applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public void setRiskoffertype(String riskoffertype) {
		this.riskoffertype = riskoffertype;
	}

	public LoanPurpose getLoanPurpose() {
		return loanPurpose;
	}

	public void setLoanPurpose(LoanPurpose loanPurpose) {
		this.loanPurpose = loanPurpose;
	}
	
	public void setHlProductIntent(String hlProductIntent) {
		this.hlProductIntent = hlProductIntent;
	}

	public String getHlProductIntent() {
		return hlProductIntent;
	}

	public String getL2ProductDesc() {
		return l2ProductDesc;
	}

	public void setL2ProductDesc(String l2ProductDesc) {
		this.l2ProductDesc = l2ProductDesc;
	}

	public String getL3ProductDesc() {
		return l3ProductDesc;
	}

	public void setL3ProductDesc(String l3ProductDesc) {
		this.l3ProductDesc = l3ProductDesc;
	}

	public String getL4ProductDesc() {
		return l4ProductDesc;
	}

	public void setL4ProductDesc(String l4ProductDesc) {
		this.l4ProductDesc = l4ProductDesc;
	}
	
	public String getAppProcessIdentifier() {
		return appProcessIdentifier;
	}

	public void setAppProcessIdentifier(String appProcessIdentifier) {
		this.appProcessIdentifier = appProcessIdentifier;
	}

	@Override
	public String toString() {
		return "ApplicationDetail [applicationKey=" + applicationKey + ", parentApplicationKey=" + parentApplicationKey
				+ ", mobile=" + mobile + ", dateofbirth=" + dateofbirth + ", applicantKey=" + applicantKey
				+ ", l2ProductKey=" + l2ProductKey + ", l2ProductCode=" + l2ProductCode + ", l3ProductKey="
				+ l3ProductKey + ", l3ProductCode=" + l3ProductCode + ", l4ProductKey=" + l4ProductKey
				+ ", l4ProductCode=" + l4ProductCode + ", isInProcessing=" + isInProcessing + ", applicationStatus="
				+ applicationStatus + ", riskoffertype=" + riskoffertype + ", principalKey=" + principalKey
				+ ", loanPurpose=" + loanPurpose + ", hlProductIntent=" + hlProductIntent + ", l2ProductDesc=" + l2ProductDesc + ", l3ProductDesc="
				+ l3ProductDesc + ", l4ProductDesc=" + l4ProductDesc + " appProcessIdentifier=" + appProcessIdentifier + "]";
	}
}
