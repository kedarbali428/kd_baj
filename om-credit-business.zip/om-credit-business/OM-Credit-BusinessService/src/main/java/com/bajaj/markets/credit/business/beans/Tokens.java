package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

public class Tokens implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String token;
	private String guardKey;
	private String type;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	 

	@Override
	public String toString() {
		return "Tokens [token=" + token + ", guardKey=" + guardKey + ", type=" + type + "]";
	}

}
