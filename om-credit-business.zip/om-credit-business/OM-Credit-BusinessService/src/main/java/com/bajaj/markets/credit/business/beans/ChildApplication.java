package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.NotRejected;
import com.bajaj.markets.credit.business.helper.CreditBusinessContraints.Rejected;

public class ChildApplication implements Serializable {

	private static final long serialVersionUID = 2703536940790674849L;

	private String action;

	@NotNull(groups = NotRejected.class, message = "l2ProductKey cannot be null or empty")
	private Integer l2ProductKey;

	@NotBlank(groups = { NotRejected.class, Rejected.class }, message = "l2ProductCode cannot be null or empty")
	private String l2ProductCode;

	@NotBlank(groups = NotRejected.class, message = "l3ProductCode cannot be null or empty")
	private String l3ProductCode;

	private String l4ProductCode;

	private String parentApplicationKey;

	private String productListingKey;

	private String riskOfferType;
	
	private Boolean isFppSelected;

	public Boolean getIsFppSelected() {
		return isFppSelected;
	}

	public void setIsFppSelected(Boolean isFppSelected) {
		this.isFppSelected = isFppSelected;
	}

	public Integer getL2ProductKey() {
		return l2ProductKey;
	}

	public void setL2ProductKey(Integer l2ProductKey) {
		this.l2ProductKey = l2ProductKey;
	}

	public String getL2ProductCode() {
		return l2ProductCode;
	}

	public void setL2ProductCode(String l2ProductCode) {
		this.l2ProductCode = l2ProductCode;
	}

	public String getL3ProductCode() {
		return l3ProductCode;
	}

	public void setL3ProductCode(String l3ProductCode) {
		this.l3ProductCode = l3ProductCode;
	}

	public String getParentApplicationKey() {
		return parentApplicationKey;
	}

	public void setParentApplicationKey(String parentApplicationKey) {
		this.parentApplicationKey = parentApplicationKey;
	}

	public String getProductListingKey() {
		return productListingKey;
	}

	public void setProductListingKey(String productListingKey) {
		this.productListingKey = productListingKey;
	}

	public String getL4ProductCode() {
		return l4ProductCode;
	}

	public void setL4ProductCode(String l4ProductCode) {
		this.l4ProductCode = l4ProductCode;
	}

	public String getRiskOfferType() {
		return riskOfferType;
	}

	public void setRiskOfferType(String riskOfferType) {
		this.riskOfferType = riskOfferType;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "ChildApplication [action=" + action + ", l2ProductKey=" + l2ProductKey + ", l2ProductCode="
				+ l2ProductCode + ", l3ProductCode=" + l3ProductCode + ", l4ProductCode=" + l4ProductCode
				+ ", parentApplicationKey=" + parentApplicationKey + ", productListingKey=" + productListingKey
				+ ", riskOfferType=" + riskOfferType + ", isFppSelected=" + isFppSelected + "]";
	}

}
