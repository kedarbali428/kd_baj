package com.bajaj.markets.credit.business;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.context.request.RequestAttributes;

public class CustomRequestScopeAttribute implements RequestAttributes {

	private Map<String, Object> requestAttributeMap = new HashMap<>();

	@Override
	public Object getAttribute(String name, int scope) {
		if (scope == RequestAttributes.SCOPE_REQUEST) {
			return this.requestAttributeMap.get(name);
		}
		return null;
	}

	@Override
	public void setAttribute(String name, Object value, int scope) {
		if (scope == RequestAttributes.SCOPE_REQUEST) {
			this.requestAttributeMap.put(name, value);
		}
	}

	@Override
	public void removeAttribute(String name, int scope) {
		// TODO Auto-generated method stub

	}

	@Override
	public String[] getAttributeNames(int scope) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void registerDestructionCallback(String name, Runnable callback, int scope) {
		// TODO Auto-generated method stub

	}

	@Override
	public Object resolveReference(String key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSessionId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getSessionMutex() {
		// TODO Auto-generated method stub
		return null;
	}

}
