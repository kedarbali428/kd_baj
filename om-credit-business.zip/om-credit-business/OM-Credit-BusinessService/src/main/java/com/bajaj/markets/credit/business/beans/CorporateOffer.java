package com.bajaj.markets.credit.business.beans;

public class CorporateOffer {

	private String offerCode; 
	private String offerDescription;
	
	public String getOfferCode() {
		return offerCode;
	}
	public void setOfferCode(String offerCode) {
		this.offerCode = offerCode;
	}
	public String getOfferDescription() {
		return offerDescription;
	}
	public void setOfferDescription(String offerDescription) {
		this.offerDescription = offerDescription;
	}
	@Override
	public String toString() {
		return "CorporateOffer [offerCode=" + offerCode + ", offerDescription=" + offerDescription + "]";
	}
}