package com.bajaj.markets.credit.business.beans;

public class OfferSource {

	private Integer offersrckey;
	private String offersrccode;
	private String offersrcdesc;
	private Integer isactive;
	
	public Integer getOffersrckey() {
		return offersrckey;
	}
	public void setOffersrckey(Integer offersrckey) {
		this.offersrckey = offersrckey;
	}
	public String getOffersrccode() {
		return offersrccode;
	}
	public void setOffersrccode(String offersrccode) {
		this.offersrccode = offersrccode;
	}
	public String getOffersrcdesc() {
		return offersrcdesc;
	}
	public void setOffersrcdesc(String offersrcdesc) {
		this.offersrcdesc = offersrcdesc;
	}
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	@Override
	public String toString() {
		return "OfferSource [offersrckey=" + offersrckey + ", offersrccode=" + offersrccode + ", offersrcdesc="
				+ offersrcdesc + ", isactive=" + isactive + "]";
	}
}