package com.bajaj.markets.credit.business.beans;

public class BrePreferredBankResponse {

	private Boolean bankDetailsEditableFlag;
	private Boolean mandateRequiredFlag;
	private Boolean accountNumberEditFlag;
	private BankDetailsBRE bankDetails;

	public Boolean getBankDetailsEditableFlag() {
		return bankDetailsEditableFlag;
	}

	public void setBankDetailsEditableFlag(Boolean bankDetailsEditableFlag) {
		this.bankDetailsEditableFlag = bankDetailsEditableFlag;
	}

	public Boolean getMandateRequiredFlag() {
		return mandateRequiredFlag;
	}

	public void setMandateRequiredFlag(Boolean mandateRequiredFlag) {
		this.mandateRequiredFlag = mandateRequiredFlag;
	}

	public Boolean getAccountNumberEditFlag() {
		return accountNumberEditFlag;
	}

	public void setAccountNumberEditFlag(Boolean accountNumberEditFlag) {
		this.accountNumberEditFlag = accountNumberEditFlag;
	}

	public BankDetailsBRE getBankDetails() {
		return bankDetails;
	}

	public void setBankDetails(BankDetailsBRE bankDetails) {
		this.bankDetails = bankDetails;
	}

}
