package com.bajaj.markets.credit.business.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.PricingConsentCaptureRequest;
import com.bajaj.markets.credit.business.beans.PricingConsentRequest;
import com.bajaj.markets.credit.business.beans.PricingConsentResponse;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessPricingConsentService;
import com.google.gson.Gson;

@Component
public class CreditBusinessPricingConsentServiceImpl implements CreditBusinessPricingConsentService {

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CreditBusinessServiceImpl businessServiceImpl;

	@Autowired
	private CreditBusinessHelper creditBusinessHelper;

	@Value("${api.omcreditapplicationservice.pricingnotification.consent.POST.url}")
	private String savePricingConsentUrl;

	@Value("${api.omcreditapplicationservice.pricingconsent.capture.PUT.url}")
	private String capturePricingConsentUrl;

	private static final String CLASS_NAME = CreditBusinessPricingConsentServiceImpl.class.getCanonicalName();

	@Override
	public PricingConsentResponse pricingConsent(String applicationKey, PricingConsentRequest pricingConsentRequest,
			HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start pricingConsent");

		// 2.insert data in consent table & send notification

		PricingConsentResponse pricingConsentResponse = saveAppPricingConsent(Long.valueOf(applicationKey),
				pricingConsentRequest, headers);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End pricingConsent Response  " + pricingConsentResponse);

		return pricingConsentResponse;
	}

	@SuppressWarnings("unchecked")
	private PricingConsentResponse saveAppPricingConsent(Long applicationKey,
			PricingConsentRequest pricingConsentRequest, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start saveAppPricingConsent");
		PricingConsentResponse pricingConsentResponse = new PricingConsentResponse();
		try {
			Gson gson = new Gson();
			Map<String, String> params = new HashMap<>();
			params.put("applicationKey", applicationKey.toString());
			pricingConsentRequest.setSource("EP");
			String jsonReq = gson.toJson(pricingConsentRequest);
			if (!StringUtils.isEmpty(jsonReq)) {
				ResponseEntity<PricingConsentResponse> consentResponse = (ResponseEntity<PricingConsentResponse>) creditBusinessHelper
						.invokeRestEndpoint(HttpMethod.POST, savePricingConsentUrl, PricingConsentResponse.class,
								params, jsonReq, headers);

				if (consentResponse != null && consentResponse.getStatusCode().equals(HttpStatus.OK)) {
					pricingConsentResponse = consentResponse.getBody();

				} else {
					logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occurred while send pricing consent alert");
					throw new CreditBusinessException(consentResponse.getStatusCode(),
							consentResponse.getBody());
				}
			}
		} catch (CreditBusinessException e) {
			throw e;
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occurred while saveAppPricingConsent response",
					e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,
					new ErrorBean("CBS-105", "Error occurred while saveAppPricingConsent response"));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End saveAppPricingConsent Response ");
		return pricingConsentResponse;
	}

	@Override
	public PricingConsentResponse pricingconsentCapture(String applicationKey, String consentRef,
			@Valid PricingConsentCaptureRequest pricingConsentCaptureRequest, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "inside pricingconsentCapture" + applicationKey);

		PricingConsentResponse pricingConsentResponse = capturePricingConsent(applicationKey, consentRef,
				pricingConsentCaptureRequest, headers);

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "exit pricingconsentCapture" + pricingConsentResponse);
		return pricingConsentResponse;
	}

	@SuppressWarnings("unchecked")
	public PricingConsentResponse capturePricingConsent(String applicationKey, String consentRef,
			PricingConsentCaptureRequest pricingConsentCaptureRequest, HttpHeaders headers) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Start getAppPricingConsent for consentRef " + applicationKey);
		PricingConsentResponse consentResponse = new PricingConsentResponse();

		try {
			Gson gson = new Gson();
			Map<String, String> params = new HashMap<String, String>();
			params.put("applicationKey", applicationKey);
			params.put("channel", pricingConsentCaptureRequest.getChannel());
			String jsonReq = gson.toJson(pricingConsentCaptureRequest);

			ResponseEntity<PricingConsentResponse> pricingConsentResponse = (ResponseEntity<PricingConsentResponse>) creditBusinessHelper.invokeRestEndpoint(
					HttpMethod.PUT, capturePricingConsentUrl, PricingConsentResponse.class, params, jsonReq, headers);

			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "get Response :: " + applicationKey);

			if (pricingConsentResponse != null && pricingConsentResponse.getStatusCode().equals(HttpStatus.OK)) {
				consentResponse = pricingConsentResponse.getBody();

			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occurred while capturing pricing consent");
				throw new CreditBusinessException(pricingConsentResponse.getStatusCode(),
						pricingConsentResponse.getBody());
			}
		} catch (CreditBusinessException e) {
			throw e;

		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error occurred while getAppPricingConsent response",
					e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-105", e.toString()));
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "End getAppPricingConsent response ");
		return consentResponse;
	}

}