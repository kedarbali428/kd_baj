package com.bajaj.markets.credit.business.datasource;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.ApltBusinessDet;
import com.bajaj.markets.credit.business.beans.ApplicantAddressDetails;
import com.bajaj.markets.credit.business.beans.ApplicantBankDetail;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.ApplicantEmailDetails;
import com.bajaj.markets.credit.business.beans.ApplicantEmploymentDetail;
import com.bajaj.markets.credit.business.beans.ApplicantProfileDetails;
import com.bajaj.markets.credit.business.beans.BankDetail;
import com.bajaj.markets.credit.business.beans.BusinessOwnerDetails;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.NatureOfBusinessMaster;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.SalariedDetail;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ApplicantDataSource implements DataSource {
	
	@Value("${api.applicant.openMarkets.applicant.GET.url}")
	private String getApplicantUrl;
	
	@Value("${api.applicant.openMarkets.address.GET.url}")
	private String getApplicantAddressUrl;
	
	@Value("${api.applicant.openMarkets.emails.GET.url}")
	private String getApplicantEmailDetailsUrl;
	
	@Value("${api.applicant.openMarkets.employmentdetails.GET.url}")
	private String getApplicantEmploymentDetailsUrl;
	
	@Value("${api.applicant.openMarkets.businessdetails.GET.url}")
	private String getApplicantBusinessDetailsUrl;
	
	@Value("${api.applicant.openMarkets.bankdetails.GET.url}")
	private String getApplicantBankDetailsUrl;
	
	@Value("${api.omreferencedatareferencedataservice.lookup.code.get.url}")
	private String lookUpCodeUrl;
	
	@Value("${api.omreferencedatareferencedataservice.natureofbusiness.get.url}")
	private String natureOfBusinessUrl;
	
	@Value("${api.omcreditapplicationservice.applications.city.PUT.url}")
	private String cityUrl;
	
	@Value("${api.omreferencedatareferencedataservice.location.pincodekey.get.url}")
	private String pinCodeUrl; 
	
	@Autowired
	CreditBusinessHelper creditBusinessHelper;
	
	@Autowired
	Environment env;
	
	@Autowired
	private BFLLoggerUtilExt logger;
	
	@Autowired
	private BFLLoggerUtil loggerUtil;
		
	private static final String CLASSNAME = ApplicantDataSource.class.getName();
	
	@Override
	public void registerDataSource(DataSourceRegistry dataSourceRegistry) {
		dataSourceRegistry.registerDataSource(this);
		loggerUtil.info(CLASSNAME, BFLLoggerComponent.UTILITY, "registerDataSource - ApplicantDataSource registration done");
	}
	
	@Override
	public OfferDetailsBean initDataSource(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		OfferDetailsBean offerDetailsBean = new OfferDetailsBean();
		try {
			String precedence = env.getProperty(applicantDataBean.getProductCode()+".ApplicantDataSource.precedence");
			offerDetailsBean.setPrecedence(Integer.parseInt(precedence));
			offerDetailsBean.setDataSourceName(this.getClass().getSimpleName());
			if(null != applicantDataBean.getApplicantKey()) {
				ApplicantProfileDetails applicantProfileDetails = getApplicantProfileDetails(applicantDataBean);
				List<ApplicantEmailDetails> applicantEmailDetails = getApplicantEmailDetails(applicantDataBean); 
				List<ApplicantAddressDetails> applicantAddressDetails = getApplicantAddressDetails(applicantDataBean);
				List<ApplicantEmploymentDetail> applicantEmploymentDetails = getApplicantEmploymentDetails(applicantDataBean); 
				List<ApltBusinessDet> apltBusinessDets = getApplicantBusinessDetails(applicantDataBean); 
				List<ApplicantBankDetail> applicantBankDetails = getApplicantBankDetails(applicantDataBean);
				  
				populateUserProfileDetails(applicantProfileDetails, applicantDataBean, offerDetailsBean);
				populateEmailDetails(applicantEmailDetails, offerDetailsBean);
				populateAddressDetails(applicantAddressDetails, offerDetailsBean, applicantDataBean);
				populateBankDetails(applicantBankDetails, offerDetailsBean, applicantDataBean);
				populateOccupationDetails(applicantEmploymentDetails, apltBusinessDets, applicantDataBean, offerDetailsBean, applicantProfileDetails);
				populateDocumentDetails(applicantProfileDetails, applicantDataBean, offerDetailsBean);
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - applicantkey found null, so applicantdatasource calls not executed.");
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - Population process failed", e);
		}
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - initDataSource method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
		return offerDetailsBean;
	}
	
	
	private ApplicantProfileDetails getApplicantProfileDetails(ApplicantDataBean applicantDataBean) {
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantProfileDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.APPLICANTKEY, applicantDataBean.getApplicantKey());
			ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					getApplicantUrl, Object.class, paramMap, null, applicantDataBean.getHeaders());
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				ApplicantProfileDetails applicantProfileDetails = mapper.convertValue(responseEntity.getBody(), ApplicantProfileDetails.class);
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantProfileDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
				return applicantProfileDetails;
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantProfileDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - applicant data not found");
				return null;
			}		
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantProfileDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - failed", e);
			return null;
		}
	}

	private List<ApplicantEmailDetails> getApplicantEmailDetails(ApplicantDataBean applicantDataBean) {
		try {
			logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantEmailDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.APPLICANTKEY, applicantDataBean.getApplicantKey());
			ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					getApplicantEmailDetailsUrl, List.class, paramMap, null, new HttpHeaders());
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				List<ApplicantEmailDetails> applicantEmails = mapper.convertValue(responseEntity.getBody(), new TypeReference<List<ApplicantEmailDetails>>(){});
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantEmailDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
				return applicantEmails;
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantEmailDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - email data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantEmailDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - failed", e);
			return null;
		}
	}
	
	private List<ApplicantAddressDetails> getApplicantAddressDetails(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantAddressDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.APPLICANTKEY, applicantDataBean.getApplicantKey());
			ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					getApplicantAddressUrl, List.class, paramMap, null, new HttpHeaders());
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				List<ApplicantAddressDetails> applicantAddressDetails = mapper.convertValue(responseEntity.getBody(), new TypeReference<List<ApplicantAddressDetails>>(){});
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantAddressDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
				return applicantAddressDetails;
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantAddressDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - address data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantAddressDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - failed", e);
			return null;
		}
	}	
	
	private List<ApplicantEmploymentDetail> getApplicantEmploymentDetails(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantEmploymentDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.APPLICANTKEY, applicantDataBean.getApplicantKey());
			ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					getApplicantEmploymentDetailsUrl, List.class, paramMap, null, new HttpHeaders());
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				List<ApplicantEmploymentDetail> applicantEmploymentDetails = mapper.convertValue(responseEntity.getBody(), new TypeReference<List<ApplicantEmploymentDetail>>(){});
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantEmploymentDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
				return applicantEmploymentDetails;
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantEmploymentDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - address data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantEmploymentDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - failed", e);
			return null;
		}
	}

	private List<ApplicantBankDetail> getApplicantBankDetails(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantBankDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.APPLICANTKEY, applicantDataBean.getApplicantKey());
			ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					getApplicantBankDetailsUrl, List.class, paramMap, null, new HttpHeaders());
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				List<ApplicantBankDetail> applicantBankDetails = mapper.convertValue(responseEntity.getBody(), new TypeReference<List<ApplicantBankDetail>>(){});
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantBankDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
				return applicantBankDetails;
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantBankDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - address data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantBankDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - failed", e);
			return null;
		}
	}

	private List<ApltBusinessDet> getApplicantBusinessDetails(ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantBusinessDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.APPLICANTKEY, applicantDataBean.getApplicantKey());
			ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
					getApplicantBusinessDetailsUrl, List.class, paramMap, null, new HttpHeaders());
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				List<ApltBusinessDet> apltBusinessDets = mapper.convertValue(responseEntity.getBody(), new TypeReference<List<ApltBusinessDet>>(){});
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantBusinessDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
				return apltBusinessDets;
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantBusinessDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - address data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getApplicantBusinessDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - failed", e);
			return null;
		}
	}
	
	private void populateUserProfileDetails(ApplicantProfileDetails applicantProfileDetailsObj, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateUserProfileDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - started");
		List<UserProfileBean> userProfileBeans = new ArrayList<>();
		if(null != applicantProfileDetailsObj) {
			UserProfileBean userProfileBean = new UserProfileBean();
			userProfileBean.setApplicationKey(applicantDataBean.getOfferApiRequest().getApplicationKey());
			userProfileBean.setApplicationUserAttributeKey(applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey());
			userProfileBean.setDateOfBirth(new SimpleDateFormat("yyyy-MM-dd").format(applicantProfileDetailsObj.getApltDateOfBirth()));
			userProfileBean.setGenderKey(null != applicantProfileDetailsObj.getGenderKey() ? Long.valueOf(applicantProfileDetailsObj.getGenderKey()) : null);
			userProfileBean.setMaritalStatusKey(null != applicantProfileDetailsObj.getMaritalStatusKey() ? Long.valueOf(applicantProfileDetailsObj.getMaritalStatusKey()) : null);
			Name name = new Name();
			name.setFirstName(applicantProfileDetailsObj.getNameDetails().getFirstName());
			name.setLastName(applicantProfileDetailsObj.getNameDetails().getLastName());
			userProfileBean.setName(name);
			userProfileBean.setPanNumber(applicantProfileDetailsObj.getPanDetails().getPanNumber());
			userProfileBean.setResidenceTypeKey(null != applicantProfileDetailsObj.getResidenceTypeKey() ? applicantProfileDetailsObj.getResidenceTypeKey().longValue() : null);
			userProfileBeans.add(userProfileBean);
		}
		offerDetailsBean.setUserProfileBeans(userProfileBeans);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateUserProfileDetails method for application "+applicantDataBean.getOfferApiRequest().getApplicationKey()+" - ended");
	}
	
	private void populateEmailDetails(List<ApplicantEmailDetails> applicantEmailDetails, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateEmailDetails method for application - started");
		List<Email> emails = new ArrayList<>();
		if(!CollectionUtils.isEmpty(applicantEmailDetails)) {
			applicantEmailDetails.forEach(emailObj -> {
				Email email = new Email();
				email.setEmail(emailObj.getApltEmailAddress());
				email.setTypeKey(emailObj.getEmailTypeKey());
				emails.add(email);
			});
		}
		offerDetailsBean.setEmails(emails);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateEmailDetails method - ended");
	}

	private void populateAddressDetails(List<ApplicantAddressDetails> applicantAddressDetails, OfferDetailsBean offerDetailsBean,  ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateAddressDetails method - started");
		List<Address> addresses = new ArrayList<>();
		if(!CollectionUtils.isEmpty(applicantAddressDetails)) {
			applicantAddressDetails.forEach(applicantAddressDetailObj -> {
				Address address = new Address();
				address.setAddressKey(null != applicantAddressDetailObj.getApltAddrKey() ? applicantAddressDetailObj.getApltAddrKey().toString() : null);
				address.setAddressLine1(applicantAddressDetailObj.getApltAddrAddressLine1());
				address.setAddressLine2(applicantAddressDetailObj.getApltAddrAddressLine2());
				address.setAddressSource(CreditBusinessConstants.APPLICANT);
				if (AddressTypeEnum.PERMANENT.getValue().equals(applicantAddressDetailObj.getAddrTypKey().toString())
						|| AddressTypeEnum.OFFICE.getValue()
								.equals(applicantAddressDetailObj.getAddrTypKey().toString())) {
					address.setAddressSource(CreditBusinessConstants.SOURCE_JOURNEY);
				}
				address.setAddressTypeKey(null != applicantAddressDetailObj.getAddrTypKey() ? applicantAddressDetailObj.getAddrTypKey().toString() : null);
				address.setCityKey(applicantAddressDetailObj.getCityKey());
				address.setCountryKey(applicantAddressDetailObj.getCountryKey());
				address.setLocalitykey(null != applicantAddressDetailObj.getLocalityKey() ? applicantAddressDetailObj.getLocalityKey().toString() : null);
				address.setPincodeKey(null != applicantAddressDetailObj.getPincodeKey() ? applicantAddressDetailObj.getPincodeKey().toString() : null);
				address.setStateKey(applicantAddressDetailObj.getStateKey());
				 if (null!=applicantAddressDetailObj.getPincodeKey()) {
					 LocationResponseBean locationResponseBean = getLocationResponseBean(applicantAddressDetailObj,applicantDataBean,
							applicantDataBean.getHeaders());
					if (null != locationResponseBean) {

						updateBranch(applicantDataBean, offerDetailsBean, locationResponseBean);
						}
				}
				addresses.add(address);
			});
		}
		offerDetailsBean.setAddresses(addresses);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateAddressDetails method - ended");
	}
	
	private void updateBranch(ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean,
			LocationResponseBean locationResponseBean) {
		if (null != locationResponseBean.getCityKey()) {
			try {
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY,
						"inside ApplicantDataSource - populateAddressDetails method - applicationkey = "
								+ applicantDataBean.getOfferApiRequest().getApplicationKey() + " - citykey = "
								+ locationResponseBean.getCityKey());
				Map<String, String> paramMap = new HashMap<>();
				paramMap.put(CreditBusinessConstants.APPLICATION_KEY, applicantDataBean.getOfferApiRequest().getApplicationKey());
				paramMap.put(CreditBusinessConstants.CITYKEY, String.valueOf(locationResponseBean.getCityKey()));
				paramMap.put(CreditBusinessConstants.OCCUPATION_TYPE_KEY,
						null != applicantDataBean.getOfferApiRequest()
								? applicantDataBean.getOfferApiRequest().getOccupationTypeKey()
								: null);

				paramMap.put(CreditBusinessConstants.PINCODE_KEY, null != locationResponseBean.getPincodeKey()? locationResponseBean.getPincodeKey().toString() : null);
				ResponseEntity<?> responseEntity = creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, cityUrl,
						Object.class, paramMap, null, applicantDataBean.getHeaders());
				if (null != responseEntity && null != responseEntity.getBody()
						&& HttpStatus.OK.equals(responseEntity.getStatusCode())) {
					logger.info(CLASSNAME, BFLLoggerComponent.UTILITY,
							"inside ApplicantDataSource - populateAddressDetails method - branch stamped successfully");
				} else {
					logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
							"inside ApplicantDataSource - populateAddressDetails method - branch not stamped successfully");
				}
			} catch (Exception e) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
						"inside ApplicantDataSource - populateAddressDetails method - branch stamping endpoint failed for applicationkey ="
								+ applicantDataBean.getOfferApiRequest().getApplicationKey(),
						e);
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private LocationResponseBean getLocationResponseBean(ApplicantAddressDetails applicantAddressDetails, ApplicantDataBean applicantDataBean,
			HttpHeaders headers) {

		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY,
				"inside ApplicantDataSource - populateAddressDetails method - started for applicationkey  "
						+ applicantDataBean.getOfferApiRequest().getApplicationKey());
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.PINCODEKEY, Long.toString(applicantAddressDetails.getPincodeKey()));
			ResponseEntity<LocationResponseBean> responseEntity = (ResponseEntity<LocationResponseBean>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, pinCodeUrl, LocationResponseBean.class, paramMap, null, headers);
			if (null != responseEntity && null != responseEntity.getBody()
					&& HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY,
						"inside ApplicantDataSource - populateAddressDetails method - ended");
				return responseEntity.getBody();
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
						"inside ApplicantDataSource - populateAddressDetails method - location address data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"inside ApplicantDataSource - populateAddressDetails method - failed for applicationKey"
							+ applicantDataBean.getOfferApiRequest().getApplicationKey(),
					e);
			
			return null;
		}
	}
	
	private void populateBankDetails(List<ApplicantBankDetail> applicantBankDetails, OfferDetailsBean offerDetailsBean, ApplicantDataBean applicantDataBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateBankDetails method - started");
		List<BankDetail> banks = new ArrayList<>();
		if(!CollectionUtils.isEmpty(applicantBankDetails)) {
			applicantBankDetails.forEach(applicantBankDetail -> {
				BankDetail bank = new BankDetail();
				bank.setAccoutNumber(applicantBankDetail.getApltBnkDetAccNum());
				bank.setBankAccountTypeKey(null != applicantBankDetail.getAccTypKey() ? applicantBankDetail.getAccTypKey().toString() : null);
				bank.setBankDetailsKey(null != applicantBankDetail.getApplicantBankDetKey() ? applicantBankDetail.getApplicantBankDetKey().toString() : null);
				bank.setBranchKey(null != applicantBankDetail.getBranchKey() ? applicantBankDetail.getBranchKey().toString() : null);
				bank.setHolderName(applicantBankDetail.getApltBnkDetHolderName());
				bank.setUserAttributeKey(applicantDataBean.getOfferApiRequest().getApplicationUserAttributeKey());
				banks.add(bank);
			});
		}
		offerDetailsBean.setBanks(banks);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateBankDetails method - ended");
	}
	
	private void populateOccupationDetails(List<ApplicantEmploymentDetail> applicantEmploymentDetails, List<ApltBusinessDet> apltBusinessDets, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean, ApplicantProfileDetails applicantProfileDetails) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateOccupationDetails method - started for applicationId:"+ applicantDataBean.getOfferApiRequest().getApplicationKey());
		List<Occupation> occupations = new ArrayList<>();
		if(!CollectionUtils.isEmpty(apltBusinessDets) || !CollectionUtils.isEmpty(applicantEmploymentDetails)) {
			Occupation occupation = new Occupation();
			if (StringUtils.equals(applicantDataBean.getOfferApiRequest().getProductCode(), "DBOL")) {
				BusinessOwnerDetails businessOwnerDetails = new BusinessOwnerDetails();
				if (!StringUtils.isEmpty( null != apltBusinessDets.get(0).getBusinessVintage() ? apltBusinessDets.get(0).getBusinessVintage().toString() : null)) {
					businessOwnerDetails.setBusinessVintage(apltBusinessDets.get(0).getBusinessVintage().toString());
				}
				// For nature of business key code value
				if (!StringUtils.isEmpty(null != apltBusinessDets.get(0).getNobKey() ? apltBusinessDets.get(0).getNobKey().toString() : null)) {
					businessOwnerDetails.setNatureOfBusiness(getNatureOfBusiness(apltBusinessDets.get(0).getNobKey().toString(), applicantDataBean.getHeaders()));
				}
				occupation.setOcupationType(getReference(2l, "SEMP", "Self Employed"));
				occupation.setBusinessOwnerDetails(businessOwnerDetails);
			} else {
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateOccupationDetails  for salaried:" + applicantDataBean.getOfferApiRequest().getApplicationKey());
				SalariedDetail salariedDetail = new SalariedDetail();
				salariedDetail.setDesignation(getReference(null, null, applicantEmploymentDetails.get(0).getApltEmpDetDesignForOth()));
				salariedDetail.setNetSalary(null != applicantProfileDetails && null != applicantProfileDetails.getApltNetMthIncome()
						? applicantProfileDetails.getApltNetMthIncome().toString()
						: null);
				salariedDetail.setWorkExperienceInMonths(
						null != applicantEmploymentDetails.get(0).getApltEmpDetTotalExp() ? applicantEmploymentDetails.get(0).getApltEmpDetTotalExp().intValue()
								: null);
				salariedDetail.setExperience(null != applicantEmploymentDetails.get(0).getApltEmpDetCurrExp()
						? String.valueOf(applicantEmploymentDetails.get(0).getApltEmpDetCurrExp())
						: null);
				salariedDetail.setEmployerName(getReference(applicantEmploymentDetails.get(0).getEmprMastId(), null, null));
				salariedDetail.setEmployerNameOther(
						null != applicantEmploymentDetails.get(0).getApltEmpDetEmpNameForOth() ? applicantEmploymentDetails.get(0).getApltEmpDetEmpNameForOth()
								: null);
				occupation.setSalariedDetail(salariedDetail);
				occupation.setOcupationType(getReference(1l, "SALR", "Salaried"));
				logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateOccupationDetails  for salaried :" + applicantDataBean.getOfferApiRequest().getApplicationKey() + occupation);
			}
			occupations.add(occupation);
		}
		offerDetailsBean.setOccupations(occupations);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - populateOccupationDetails method - ended for applicationId:" + applicantDataBean.getOfferApiRequest().getApplicationKey());
	}
	
	@SuppressWarnings("unchecked")
	private Reference getNatureOfBusiness(String natureOfBusiness, HttpHeaders headers) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getNatureOfBusiness method - started");
		try {
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put(CreditBusinessConstants.LKPCODE, CreditBusinessConstants.LKPCODE_BUSINESSVINTAGE);
			ResponseEntity<List<NatureOfBusinessMaster>> responseEntity = (ResponseEntity<List<NatureOfBusinessMaster>>) creditBusinessHelper
					.invokeRestEndpoint(HttpMethod.GET, natureOfBusinessUrl, List.class, null, null, headers);
			if (null != responseEntity && null != responseEntity.getBody() && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				ObjectMapper mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				List<NatureOfBusinessMaster> natureOfBusinessList;
				natureOfBusinessList = mapper.convertValue(responseEntity.getBody(),
						new TypeReference<List<NatureOfBusinessMaster>>() {
						});
				if (!CollectionUtils.isEmpty(natureOfBusinessList)) {
					List<NatureOfBusinessMaster> nobList = natureOfBusinessList.stream().filter(
							nob -> nob.getNatureOfBusinessValue().equals(natureOfBusiness))
							.collect(Collectors.toList());
					logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getNatureOfBusiness method - ended");
					return getReference(nobList.get(0).getNatureOfBusinessKey(),
							nobList.get(0).getNatureOfBusinessCode(), nobList.get(0).getNatureOfBusinessValue());
				} else {
					logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getNatureOfBusiness method - nob data not found");
					return null;
				}
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getNatureOfBusiness method - nob data not found");
				return null;
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ApplicantDataSource - getNatureOfBusiness method - failed", e);
			return null;
		}
	}
	
	
	private void populateDocumentDetails(ApplicantProfileDetails applicantProfileDetailsObj, ApplicantDataBean applicantDataBean, OfferDetailsBean offerDetailsBean) {
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateDocumentDetails method - started");
		List<DocumentDetails> documents = new ArrayList<>();
		if(null != applicantProfileDetailsObj && !StringUtils.isEmpty(applicantProfileDetailsObj.getPanDetails().getPanNumber())) {
			DocumentDetails documentDetail = new DocumentDetails();
			documentDetail.setDocumentNameKey(1L);
			documentDetail.setDocumentNumber(applicantProfileDetailsObj.getPanDetails().getPanNumber());
			documents.add(documentDetail);
		}
		offerDetailsBean.setDocuments(documents);
		logger.info(CLASSNAME, BFLLoggerComponent.UTILITY, "inside ProspectDataSource - populateDocumentDetails method - ended");
	}
	
	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;
	}
}