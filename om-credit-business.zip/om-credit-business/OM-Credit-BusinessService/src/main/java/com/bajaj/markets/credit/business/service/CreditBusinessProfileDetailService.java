package com.bajaj.markets.credit.business.service;

import org.springframework.http.HttpHeaders;

import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ProfileDetailsReqResp;

public interface CreditBusinessProfileDetailService {

	public ProfileDetailsReqResp getProfileDetails(String applicationId);

	public ApplicationResponse saveProfileDetails(ProfileDetailsReqResp profileDetails, String applicationId,
			HttpHeaders headers);
}
