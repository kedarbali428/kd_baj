package com.bajaj.markets.credit.business.helper;

/**
 * Enum of ETB variants
 * 
 * @author 764504
 *
 */
public enum EtbVariantEnum {

	NONGIN("NON-GIN"), GIN("GIN");

	private final String value;

	private EtbVariantEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

}
