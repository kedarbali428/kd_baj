package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.AMEX_PRINCIPALKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.BUSINESS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.ICICI_CARDS_PRINCIPALKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.LOOKUP_SOURCE_QUALIFICATION;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SALARIED;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SPACE_DELIMETER;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.activiti.engine.impl.util.CollectionUtil;
import org.apache.commons.lang3.ArrayUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AdditionalDetail;
import com.bajaj.markets.credit.business.beans.AdditionalDetailLoans;
import com.bajaj.markets.credit.business.beans.AdditionalDetailPricing;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationPhoneNumberDetails;
import com.bajaj.markets.credit.business.beans.ApplicationRelationShipDetails;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.BusinessOwnerDetails;
import com.bajaj.markets.credit.business.beans.CustomerDemog;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.EmployerMasterBean;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.LookupCodeResponse;
import com.bajaj.markets.credit.business.beans.LookupCodeValuesResponseBean;
import com.bajaj.markets.credit.business.beans.Name;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.Nominee;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OccupationReference;
import com.bajaj.markets.credit.business.beans.PrincipalBean;
import com.bajaj.markets.credit.business.beans.PrincipalFeature;
import com.bajaj.markets.credit.business.beans.PrincipalIndustryDetail;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.RelationReference;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.beans.SalariedDetail;
import com.bajaj.markets.credit.business.beans.SummaryResponse;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.AddressTypeEnum;
import com.bajaj.markets.credit.business.helper.CorporateLinkageEnum;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.ReferenceOf;
import com.bajaj.markets.credit.business.helper.RelationshipEnum;
import com.bajaj.markets.credit.business.helper.ShopStatusEnum;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessAdditionalDetailService;
import com.bajaj.markets.referencedataclientlib.bean.CacheServiceException;
import com.bajaj.markets.referencedataclientlib.bean.OccupationMaster;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CreditBusinessAdditionalDetailServiceImpl implements CreditBusinessAdditionalDetailService {

	private static final long HDFC_PRINCIPLEKEY = 17L;
	private static final String IS_IN_PROCESSING = "isInProcessing";
	private static final String APPLICATIONKEY = "applicationkey";
	private static final String L3_PRODUCT_CODE = "l3ProductCode";
	private static final String TYPE_KEY = "typeKey";
	private static final String LEAD = "LEAD";
	private static final String ETB = "ETB";
	private static final String PRINCIPLE_CUST_TYPE = "principleCustType";
	private static final String NTB = "NTB";
	private static final String PRINCIPALKEY = "principalkey";
	private static final String PRIMARY_USER_ATTRIBUTE = "1";
	private static final String USERATTRIBUTEKEY = "userattributekey";
	private static final String APPLICATION_ID = "applicationid";
	private static final String PRINCIPLE_DOC_TYPE_KEY = "principleDocTypeKey";
	private static final String PRINCIPLE_DOC_TYPE_KEYS = "principleDocTypeKeys";
	private static final String ID_PROOF = "ID_PROOF";
	private static final String ADDRESS_PROOF = "ADDRESS_PROOF";
	private static final String HASSALARYACCOUNT = "hasSalaryAccount";
	private static final String APPOINTMENT_DATETIME_FROM = "appointmentDateTimeFrom";
	private static final String APPOINTMENT_DATETIME_TO = "appointmentDateTimeTo";
	private static final String APPOINTMENT_ADDRESS_TYPE_CODE = "appointmentAddressTypeCode";
	

	private static final String RELATIONCODE = "relationcode";

	private static final String RELATIONKEY = "relationkey";
	private static final String BFL_PRINCIPLEKEY = "3";
	private static final String RETURNSINGLECURRENTADDRESSFLAG = "returnSingleCurrentAddressFlag";
	private static final String REMOVEEXACTMATCHCURRENTADDRESS = "removeExactMatchCurrentAddress";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	WorkflowHelper workflowHelper;

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	CreditBusinessProductSummaryServiceImpl summaryImpl;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;

	@Value("${api.omcreditapplicationservice.userprofiles.get.url}")
	private String getUserProfilesUrl;

	@Value("${api.omreferencedatareferencedataservice.lookup.code.get.url}")
	private String lookUpCodeUrl;

	@Value("${api.omcreditapplicationservice.getaddress.get.url}")
	private String getAddressURL;

	@Value("${api.omcreditapplicationservice.creditapplication.get.url}")
	private String getApplicationUrl;

	@Value("${api.omreferencedatareferencedataservice.location.pincodekey.get.url}")
	private String getAddressOnPincodeKeyUrl;
	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String getChildApplicationsUrl;
	@Value("${api.omcreditapplicationservice.principal.feature.put.url}")
	private String getPrincipalFeatureUrl;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getOccupationUrl;
	@Value("${api.omreferencedatareferencedataservice.getoccupation.get.url}")
	private String getOccupationDetailurl;
	@Value("${api.omreferencedatareferencedataservice.getprincipalindustry.get.url}")
	private String getPrincipalIndustryUrl;

	@Value("${api.omcreditapplicationservice.bundle.GET.url}")
	private String getBundleSelected;

	@Value("${api.omvasapplicationservice.nominee.GET.url}")
	private String getNominee;

	@Value("${api.omcreditapplicationservice.loan.pricing.get.url}")
	private String getLoanPricingUrl;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getProfessionUrl;

	@Value("${api.omcreditcardprincipleintegration.custdemog.GET.url}")
	private String getPrincipalCustDemogUrl;

	@Value("${api.omcreditapplicationservice.principalcustinfo.offers.url}")
	private String getPrincipalCustInfoUrl;

	@Value("${api.omcreditapplicationservice.relatedpersonnels.GET.url}")
	private String getRelatedPersonnelUrl;

	@Value("${occupation.salaried.companySubCategoryTypes}")
	private String companySubCategoryTypes;
	
	@Value("${api.omcreditapplicationservice.getalternatemobileno.GET.url}")
	private String getAlternateMobileNumber;
	
	@Value("${api.omcreditapplicationservice.document.url}")
	private String applicationDocumentUrl;

	@Value("${api.omcreditapplicationservice.relation.url}")
	private String applicationRelationUrl;
	
	@Value("${api.omcreditapplicationservice.principalAddDetails.url}")
	private String applicationPrincipalAdditionalDetailsUrl;
	
	@Value("#{${principal.required.relationship}}")
	private Map<String, String> principalRequiredRelations;
	
	@Value("#{${permanentAddressrequired.l3ProductCodes}}")
	private Map<String, String> permanentAddressRequired;
	
	@Value("#{${genderRequired.l3ProductCodes}}")
	private Map<String, String> genderRequiredl3ProductCodes;
	
	@Value("#{${permanentAddressShow.ResiType}}")
	private Map<String,String> permanentAddressShowOnResiType;

	@Value("#{${principal.permanentAddress.enabled}}")
	private Map<String, String> permanentAddressRelations;
		
	@Value("#{${additionaldetails.address.sources}}")
	private Map<String, String> additionalDetailsAddressSources;

	
	@Autowired
	private MasterDataRedisClientHelper masterDataHelper;

	@Autowired
	private CreditBusinessGinHelper ginHelper;

	private static final String CLASSNAME = CreditBusinessAdditionalDetailServiceImpl.class.getName();

	@Override
	public ApplicationResponse saveAdditionalDetail(AdditionalDetail additionalDetail, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start saveAdditionalDetail additionalDetail resource :" + additionalDetail);

		Map<String, Object> vars = new HashMap<>();
		if (null != additionalDetail.getAction() && "back".equalsIgnoreCase(additionalDetail.getAction())) {
			vars.put("additionalDetailsBack", "back");
		} else {
			vars.put(CreditBusinessConstants.REQUEST, additionalDetail);
			vars.put("additionalDetailsBack", "");
		}

		try {
			String nextTaskKey = workflowHelper.completeTask(headers.get(CreditBusinessConstants.PROCESS_ID).get(0), vars);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "End saveAdditionalDetail");
			NextTask task = new NextTask();
			task.setNextTaskKey(nextTaskKey);
			ApplicationResponse applicationResponse = new ApplicationResponse();
			applicationResponse.setNextTask(task);
			applicationResponse.setPayload(additionalDetail);
			return applicationResponse;
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception completing workflow task", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured while calling the service", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-101", "Exception while completing activiti task"));
		}
	}

	private AdditionalDetail updatePrincipalCodeInAdditionalDetails(String applicationId,
			AdditionalDetail additionalDetail) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Start updatePrincipalCodeInAdditionalDetails for ApplicationID :" + applicationId);

		List<PrincipalBean> listPrincipals = apiCallsHelper.getPrincipalDetails();

		Map<Long, String> principalMap = listPrincipals.stream()
				.collect(Collectors.toMap(PrincipalBean::getPrinciplekey, PrincipalBean::getPrincipleCode));

		additionalDetail.setPrincipalCode(principalMap.get(additionalDetail.getPrincipalKey()));

		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"End updatePrincipalCodeInAdditionalDetails for ApplicationID :" + applicationId);

		return additionalDetail;
	}
	
	@Override
	public AdditionalDetail getAdditionalDetail(String applicationId, String l3ProductCode) {
		AdditionalDetail additionalDetail = new AdditionalDetail();
		String appUserAttributeKey = null;
		List<Address> addresses = new ArrayList<>();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		ObjectMapper mapper = new ObjectMapper();		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			additionalDetail.setCppFlag(true);
			Optional<ApplicationDetail> filteredChild = getChildAppByL3Code(applicationId, l3ProductCode, headers, mapper);
			if (filteredChild.isPresent()) {
				String qualification = null;
				ApplicationDetail chidlApp = filteredChild.get();
				additionalDetail.setL3ProductCode(l3ProductCode);
				additionalDetail.setPrincipalKey(chidlApp.getPrincipalKey());
				
				updatePrincipalCodeInAdditionalDetails(applicationId, additionalDetail);

				HashMap<String, String> childParams = new HashMap<>();
				childParams.put(APPLICATION_ID, chidlApp.getApplicationKey());
				List<UserProfileBean> userProfileList = this.getUserProfiles(headers, childParams, mapper);
				for (UserProfileBean userProfile : userProfileList) {
					if (userProfile.getApplicationUserAttributeType().equals(PRIMARY_USER_ATTRIBUTE)) {
						appUserAttributeKey = userProfile.getApplicationUserAttributeKey();
						additionalDetail.setMotherName(userProfile.getMotherName());
						additionalDetail.setFatherName(userProfile.getFatherName());
						List<RelationReference> relationDetails = this.getRelationReference(applicationId, chidlApp.getPrincipalKey(), mapper);
						additionalDetail.setRelationReference(!CollectionUtils.isEmpty(relationDetails) ? relationDetails.get(0) : null);
						additionalDetail.setNameToBePrintedOnCard(userProfile.getNameToBePrintedOnCard());
						additionalDetail.setCustomerFullName(this.generateFullNameFromNameObject(userProfile.getName()));
						qualification = userProfile.getQualification();
						this.setQualification(additionalDetail, mapper, qualification);
						this.setOccupationSpecificDetails(additionalDetail, userProfile, chidlApp, mapper);
						this.setAlternateMobileNumber(additionalDetail, headers, mapper, chidlApp);
						this.setCustomerTypeAndRelatedDetails(applicationId, additionalDetail, headers, mapper);
						additionalDetail.setApplicantIdProof(this.getApplicantIdProof(chidlApp));
						additionalDetail.setAddressProof(this.getAddressProof(chidlApp));
						this.setApplicationPrincipalAdditionalDetails(chidlApp, additionalDetail);
						this.setAddresses(additionalDetail, appUserAttributeKey, addresses, chidlApp);
						break;
					}
				}

				additionalDetail.setPrincipalFeatures(this.getPrincipalFeature(l3ProductCode, mapper, chidlApp));
			}
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Reource not found Exception occured : " + e);
				additionalDetail.setAddressDetails(addresses);
				return additionalDetail;
			}
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Exception Occured while getting Additional Details for Cards with applicationid: " + applicationId + " with exception: ", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Exception Occured while getting Additional Details for Cards with applicationid: " + applicationId + " with exception: ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "Some Technical Exception Occured"));
		}
		return additionalDetail;
	}
	
	private Reference getApplicantIdProof(ApplicationDetail chidlApp) {
		Reference documentReference = null;
		ArrayList<?> principleDocTypeKeys = getPrincipalDocTypeKeys(chidlApp);
		if (!CollectionUtils.isEmpty(principleDocTypeKeys)) {
			Map<String, String> pathParameters = new HashMap<>();
			pathParameters.put(PRINCIPALKEY, chidlApp.getPrincipalKey().toString());
			for (Object principleDocTypeKey : principleDocTypeKeys) {
				documentReference = new Reference(Double.valueOf(principleDocTypeKey.toString()).longValue(), null,
						null);
				documentReference = apiCallsHelper.getReferenceV2(ReferenceOf.PRINCIPLE_DOCUMENTS, pathParameters, null,
						documentReference);
				if (null != documentReference && documentReference.getCode().equals(ID_PROOF)) {
					break;
				} else if (documentReference.getCode().equals(ADDRESS_PROOF)) {
					documentReference = null;
				}
			}
		}
		return documentReference;
	}
	
	private Reference getAddressProof(ApplicationDetail chidlApp) {
		Reference documentReference = null;
		ArrayList<?> principleDocTypeKeys = getPrincipalDocTypeKeys(chidlApp);
		if (!CollectionUtils.isEmpty(principleDocTypeKeys)) {
			Map<String, String> pathParameters = new HashMap<>();
			pathParameters.put(PRINCIPALKEY, chidlApp.getPrincipalKey().toString());
			for (Object principleDocTypeKey : principleDocTypeKeys) {
				documentReference = new Reference(Double.valueOf(principleDocTypeKey.toString()).longValue(), null,
						null);
				documentReference = apiCallsHelper.getReferenceV2(ReferenceOf.PRINCIPLE_DOCUMENTS, pathParameters, null,
						documentReference);
				if (null != documentReference && documentReference.getCode().equals(ADDRESS_PROOF)) {
					break;
				} else if (documentReference.getCode().equals(ID_PROOF)) {
					documentReference = null;
				}
			}
		}
		return documentReference;
	}

	private void setApplicationPrincipalAdditionalDetails(ApplicationDetail chidlApp,
			AdditionalDetail additionalDetail) {
		if (null != chidlApp.getPrincipalKey()
				&& ICICI_CARDS_PRINCIPALKEY.toString().equals(chidlApp.getPrincipalKey().toString())) {
			try {
				Map<String, String> params = new HashMap<>();
				params.put(APPLICATION_ID, chidlApp.getApplicationKey());
				params.put(PRINCIPALKEY, chidlApp.getPrincipalKey().toString());
				ResponseEntity<?> applicationPrincipalAdditionalDetail = creditBusinessHelper.invokeRestEndpoint(
						HttpMethod.GET, applicationPrincipalAdditionalDetailsUrl, Object.class, params, null,
						new HttpHeaders());
				if (null != applicationPrincipalAdditionalDetail
						&& null != applicationPrincipalAdditionalDetail.getBody()) {
					JSONObject applicationPrincipalAdditiomalDetailResponse = CreditBusinessHelper
							.getJSONObject(applicationPrincipalAdditionalDetail.getBody());
					additionalDetail.setHasSalaryAccount(
							null != applicationPrincipalAdditiomalDetailResponse.get(HASSALARYACCOUNT)
									? (Boolean) applicationPrincipalAdditiomalDetailResponse.get(HASSALARYACCOUNT)
									: null);
					additionalDetail.setAppointmentDateTimeFrom(
							null != applicationPrincipalAdditiomalDetailResponse.get(APPOINTMENT_DATETIME_FROM)
									? applicationPrincipalAdditiomalDetailResponse.get(APPOINTMENT_DATETIME_FROM)
											.toString()
									: null);
					additionalDetail.setAppointmentDateTimeTo(
							null != applicationPrincipalAdditiomalDetailResponse.get(APPOINTMENT_DATETIME_TO)
									? applicationPrincipalAdditiomalDetailResponse.get(APPOINTMENT_DATETIME_TO)
											.toString()
									: null);
					additionalDetail.setAppointmentAddressTypeCode(
							null != applicationPrincipalAdditiomalDetailResponse.get(APPOINTMENT_ADDRESS_TYPE_CODE)
									? applicationPrincipalAdditiomalDetailResponse.get(APPOINTMENT_ADDRESS_TYPE_CODE)
											.toString()
									: null);

				} else {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
							"applicationPrincipalAdditionalDetails not to be fetched for child app: " + chidlApp);
				}
			} catch (Exception exception) {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
						"Exception occurred while fetching applicationPrincipalAdditionalDetails  for: "
								+ chidlApp.getApplicationKey(),
						exception);
			}
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"applicationPrincipalAdditionalDetails not to be fetched for child app: " + chidlApp);
		}
	}

	private String generateFullNameFromNameObject(Name name) {
		if(null != name) {
			StringBuilder sb = new StringBuilder(name.getFirstName());
			if(!StringUtils.isEmpty(name.getMiddleName())) {
				sb.append(SPACE_DELIMETER).append(name.getMiddleName());
			}
			if(!StringUtils.isEmpty(name.getLastName())) {
				sb.append(SPACE_DELIMETER).append(name.getLastName());
			}
			return sb.toString();
		} else {
			return null;
		}
	}
	
	private List<RelationReference> getRelationReference(String applicationId, Long principalKey, ObjectMapper mapper) {
		List<RelationReference> relationReferences = new ArrayList<>();
		try {
			if(!StringUtils.isEmpty(principalRequiredRelations.get(principalKey.toString()))) {
				Map<String, String> params = new HashMap<>();
				params.put(APPLICATION_ID, applicationId);
				ResponseEntity<?> relationDetailsResponseEntity = creditBusinessHelper
						.invokeRestEndpoint(HttpMethod.GET, applicationRelationUrl, String.class, params, null, new HttpHeaders());
				
				if(null != relationDetailsResponseEntity.getBody()) {
					List<ApplicationRelationShipDetails> appRelationshipDetails = mapper.readValue(relationDetailsResponseEntity.getBody().toString(),
							new TypeReference<List<ApplicationRelationShipDetails>>() {});
					
					if(null != appRelationshipDetails && !appRelationshipDetails.isEmpty()) {
						List<String> principalRequiredRelationList = List.of(principalRequiredRelations.get(principalKey.toString()).split(","));
						appRelationshipDetails.stream()
							.filter(appRelation -> principalRequiredRelationList.contains(appRelation.getRelationCodeMasterKey().toString()))
							.forEach(appRelation -> {
								RelationReference relationReference = new RelationReference();
								relationReference.setFullName(appRelation.getName());
								relationReference.setSalutation(apiCallsHelper.getReferenceV2(ReferenceOf.SALUTATION, null, null,
										new Reference(appRelation.getSalutationKey(), null, null)));
								Map<String, String> parameters = new HashMap<>();
								parameters.put(RELATIONKEY, appRelation.getRelationCodeMasterKey().toString());
								parameters.put(RELATIONCODE, null);
								relationReference.setRelation(apiCallsHelper.getReferenceV2(ReferenceOf.RELATION, parameters, null,
										new Reference(appRelation.getRelationCodeMasterKey(), null, null)));
								relationReferences.add(relationReference);
							});
						
						return relationReferences;
					}
				}
			} else {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Required relation for principal: " + principalKey + " is not defined!");
			}
		} catch (Exception exception) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occurred while fetching relation details for: " + applicationId, exception);
		}
		return relationReferences;
	}

	private List<PrincipalFeature> getPrincipalFeature(String l3ProductCode, ObjectMapper mapper, ApplicationDetail chidlApp) {
		HashMap<String, String>  params = new HashMap<>();
		params.put(APPLICATION_ID, chidlApp.getApplicationKey());
		params.put(L3_PRODUCT_CODE, l3ProductCode);
		ResponseEntity<?> principalFeatureRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getPrincipalFeatureUrl, List.class, params,
				null, new HttpHeaders());
		List<PrincipalFeature> principalFeatures = mapper.convertValue(principalFeatureRes.getBody(), new TypeReference<List<PrincipalFeature>>() {
		});
		if (!CollectionUtils.isEmpty(principalFeatures)) {
			return principalFeatures;
		} else {
			return null;
		}
	}

	private void setAddresses(AdditionalDetail additionalDetail, String appUserAttributeKey, List<Address> addresses,
			ApplicationDetail chidlApp) {
		HashMap<String, String> childParams;
		childParams = new HashMap<>();
		childParams.put(APPLICATION_ID, chidlApp.getApplicationKey());
		childParams.put(USERATTRIBUTEKEY, appUserAttributeKey);
		// fetch current address
		childParams.put(TYPE_KEY, AddressTypeEnum.CURRENT.getValue());
		Address currentAddress = apiCallsHelper.getAddress(new HttpHeaders(), childParams);
		if (currentAddress != null)
			addresses.add(currentAddress);

		// fetch work address
		childParams.put(TYPE_KEY, AddressTypeEnum.OFFICE.getValue());
		try {
			Address workAddress = apiCallsHelper.getAddress(new HttpHeaders(), childParams);
			if (workAddress != null)
				addresses.add(workAddress);
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Reource not found Exception occured : ", e);
			}
		}

		additionalDetail.setAddressDetails(addresses);
		// fetch delivery address
		childParams.put(TYPE_KEY, AddressTypeEnum.DELIVERY.getValue());
		Address deliveryAddress = apiCallsHelper.getAddress(new HttpHeaders(), childParams);

		// set delivery address flag on basis of current and delivery address check. 
		// if delivery address selected as current address then flag true else false
		additionalDetail.setDeliveryAddressFlag(false);
		if (null != currentAddress && currentAddress.equals(deliveryAddress)) {
			additionalDetail.setDeliveryAddressFlag(true);
		}

		// fetch other address
		try {
			Address otherAddress = null;
			if (chidlApp.getPrincipalKey().equals(AMEX_PRINCIPALKEY) || chidlApp.getPrincipalKey().equals(HDFC_PRINCIPLEKEY)) {
				childParams.put(TYPE_KEY, AddressTypeEnum.PERMANENT.getValue());
				otherAddress = apiCallsHelper.getAddress(new HttpHeaders(), childParams);
			} else {
				childParams.put(TYPE_KEY, AddressTypeEnum.OTHERS.getValue());
				otherAddress = apiCallsHelper.getAddress(new HttpHeaders(), childParams);
			}
			if (otherAddress != null)
				additionalDetail.setOtherAddressDetails(otherAddress);
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Reource not found Exception occured : ", e);
			}
		}
	}

	private void setCustomerTypeAndRelatedDetails(String applicationId, AdditionalDetail additionalDetail,
			HttpHeaders headers, ObjectMapper mapper) {
		additionalDetail.setCustomerType(NTB);
		HashMap<String, String> params = new HashMap<>();
		params.put(APPLICATION_ID, applicationId);
		params.put(PRINCIPALKEY, additionalDetail.getPrincipalKey().toString());
		JSONObject jsonObject = null;
		try {
			ResponseEntity<?> getPrincipalCustInfo = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getPrincipalCustInfoUrl,
					JSONObject.class, params, null, headers);
			jsonObject = mapper.convertValue(getPrincipalCustInfo.getBody(), JSONObject.class);
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Reource not found Exception occured : ", e);
			}
		}
		if (null != jsonObject && null != jsonObject.get(PRINCIPLE_CUST_TYPE)
				&& (ETB.equalsIgnoreCase(jsonObject.get(PRINCIPLE_CUST_TYPE).toString())
						|| LEAD.equalsIgnoreCase(jsonObject.get(PRINCIPLE_CUST_TYPE).toString()))
				&& PRIMARY_USER_ATTRIBUTE.equalsIgnoreCase(additionalDetail.getPrincipalKey().toString())) {
			additionalDetail.setCustomerType(ETB);
			//Get partner address from mongo db
			headers.add(APPLICATION_ID, applicationId);
			ResponseEntity<?> getCustomerDemog = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getPrincipalCustDemogUrl,
					CustomerDemog.class, params, null, headers);
			CustomerDemog customerDemog = mapper.convertValue(getCustomerDemog.getBody(), CustomerDemog.class);
			if (null != customerDemog && !CollectionUtils.isEmpty(customerDemog.getAddressList())) {
				Optional<Address> address = customerDemog.getAddressList().stream()
						.filter(add -> AddressTypeEnum.CURRENT.getValue().equalsIgnoreCase(add.getAddressTypeKey())).findFirst();
				additionalDetail.setPartnerAddressDetails(address.isPresent() ? address.get() : null);
			}
		}
	}

	private void setAlternateMobileNumber(AdditionalDetail additionalDetail, HttpHeaders headers, ObjectMapper mapper,
			ApplicationDetail chidlApp) {
		HashMap<String, String> param = new HashMap<>();
		param.put(APPLICATION_ID, chidlApp.getApplicationKey());
		if (chidlApp.getPrincipalKey().equals(AMEX_PRINCIPALKEY)) {
			ResponseEntity<?> response = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getAlternateMobileNumber, Object.class, param,
					null, headers);
			ApplicationPhoneNumberDetails alternateMobileNoDetails = mapper.convertValue(response.getBody(), new TypeReference<ApplicationPhoneNumberDetails>() {});
			additionalDetail.setAlternateMobileNumber(alternateMobileNoDetails.getPhoneNumber());
		}
	}

	private void setOccupationSpecificDetails(AdditionalDetail additionalDetail, UserProfileBean userProfile,
			ApplicationDetail chidlApp, ObjectMapper mapper) {
		Map<String, String> params = new HashMap<>();
		params.put(APPLICATION_ID, chidlApp.getApplicationKey());
		params.put(USERATTRIBUTEKEY, userProfile.getApplicationUserAttributeKey());
		Occupation occupation = this.getProfessionalDetail(params, new HttpHeaders());
		if (occupation != null) {
			OccupationReference occupationReference = apiCallsHelper
					.getOccupationMasterFromOccupationId(occupation.getOcupationType().getKey());
			if (occupationReference != null) {
				Reference occupationType = getReference(occupationReference.getOccupationKey(), occupationReference.getOccupationCode(),
						occupationReference.getOccupationValue());
				additionalDetail.setOccupationType(occupationType);
				if (SALARIED.equalsIgnoreCase(occupationType.getCode())) {
					this.setWorkEmail(additionalDetail, userProfile, chidlApp);
				}
			}
			SalariedDetail salariedDetail = occupation.getSalariedDetail();
			if (null != salariedDetail) {
				if(null != salariedDetail.getPrincipalIndustry()) {
					this.setPrincipalIndustryDetails(additionalDetail, mapper, occupation);
				}
				Reference empSectorService = salariedDetail.getEmpSectorService();
				if(null != empSectorService) {
					additionalDetail.setEmpSectorService(this.getReference(empSectorService.getKey(), empSectorService.getCode(), empSectorService.getValue()));
				}
			}
			BusinessOwnerDetails businessOwnerDetails = occupation.getBusinessOwnerDetails();
			if (null != businessOwnerDetails) {
				if(null != businessOwnerDetails.getProfitAfterTax()) {
					additionalDetail.setAnnualItr(businessOwnerDetails.getProfitAfterTax().doubleValue());
				}
				Reference natureOfBusiness = businessOwnerDetails.getNatureOfBusiness();
				if(null != natureOfBusiness) {
					additionalDetail.setBusinessNature(this.getReference(natureOfBusiness.getKey(), natureOfBusiness.getCode(), natureOfBusiness.getValue()));
				}
			}
		}
	}

	private void setWorkEmail(AdditionalDetail additionalDetail, UserProfileBean userProfile,
			ApplicationDetail chidlApp) {
		Email workEmail = getEmail(chidlApp.getApplicationKey(), userProfile.getApplicationUserAttributeKey(), 
				EmailTypeEnum.OFFICE.getValue().toString());
		additionalDetail.setWorkEmailId(workEmail != null ? workEmail.getEmail() : null);
	}

	private void setPrincipalIndustryDetails(AdditionalDetail additionalDetail, ObjectMapper mapper,
			Occupation occupation) {
		Map<String, String> params;
		Long principalIndustryKey = occupation.getSalariedDetail().getPrincipalIndustry().getKey();
		if (null != principalIndustryKey) {
			params = new HashMap<>();
			params.put("principalIndustryMasterKey", String.valueOf(principalIndustryKey));
			params.put("industryCode", "");

			//ReferenceData PrincipalIndustry call
			ResponseEntity<?> getPrincipalIndustry = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getPrincipalIndustryUrl,
					List.class, params, null, new HttpHeaders());

			List<PrincipalIndustryDetail> principalIndustryList = mapper.convertValue(getPrincipalIndustry.getBody(),
					new TypeReference<List<PrincipalIndustryDetail>>() {
					});

			for (PrincipalIndustryDetail industry : principalIndustryList) {
				if ((industry.getPrincipalIndustryMasterKey()).equals(principalIndustryKey)) {
					Reference industryType = getReference(industry.getPrincipalIndustryMasterKey(), industry.getIndustryCode(),
							industry.getIndustryName());
					additionalDetail.setIndustryType(industryType);
					break;
				}
			}
		}
	}

	private void setQualification(AdditionalDetail additionalDetail, ObjectMapper mapper, String qualification) {
		List<LookupCodeValuesResponseBean> qualificationList = getQualificationList(mapper, qualification);
		if (!CollectionUtils.isEmpty(qualificationList)) {
			additionalDetail.setQualification(getReference(qualificationList.get(0).getKey().longValue(), qualificationList.get(0).getCode(),
					qualificationList.get(0).getValue()));
		}
	}

	private ArrayList<?> getPrincipalDocTypeKeys(ApplicationDetail childApplication) {
		ArrayList<?> principleDocTypeKeys = null;
		if (null != childApplication.getPrincipalKey() && 
				ICICI_CARDS_PRINCIPALKEY.toString().equals(childApplication.getPrincipalKey().toString())) {
			try {
				Map<String, String> params = new HashMap<>();
				params.put(APPLICATION_ID, childApplication.getApplicationKey());
				ResponseEntity<?> applicationDocumentResponseEntity = creditBusinessHelper.invokeRestEndpoint(
						HttpMethod.GET, applicationDocumentUrl, Object.class, params, null, new HttpHeaders());
				
				JSONObject applicationDocumentResponse = CreditBusinessHelper.getJSONObject(applicationDocumentResponseEntity.getBody());
				if (null != applicationDocumentResponse
						&& null != applicationDocumentResponse.get(PRINCIPLE_DOC_TYPE_KEYS)) {
					 principleDocTypeKeys = (ArrayList<?>) applicationDocumentResponse
							.get(PRINCIPLE_DOC_TYPE_KEYS);
				}
			} catch (Exception exception) {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occurred while fetching PrincipleDocTypeKeys for: "
						+ childApplication.getApplicationKey(), exception);
			}
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "PrincipleDocTypeKeys not to be fetched for child app: " + childApplication);
		}
		return principleDocTypeKeys;
	}
	
	private Optional<ApplicationDetail> getChildAppByL3Code(String applicationId, String l3ProductCode, HttpHeaders headers, ObjectMapper mapper) {
		HashMap<String, String> params = new HashMap<>();
		params.put(APPLICATIONKEY, applicationId);
		params.put(IS_IN_PROCESSING, "false");
		ResponseEntity<?> childApplicationListRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getChildApplicationsUrl, List.class, params, null,
				headers);

		List<ApplicationDetail> childApplicationList = mapper.convertValue(childApplicationListRes.getBody(), new TypeReference<List<ApplicationDetail>>() {
		});

		return childApplicationList.stream().filter(o -> o.getL3ProductCode().contentEquals(l3ProductCode)).findFirst();
	}

	private Reference getReference(Long key, String code, String value) {
		Reference reference = new Reference();
		reference.setCode(code);
		reference.setKey(key);
		reference.setValue(value);
		return reference;

	}

	/**
	 * Method used to save addional details for loans
	 * 
	 * @param AdditionalDetailLoans additionalDetail
	 * @param HttpHeaders           headers
	 * @return ApplicationResponse
	 */
	@Override
	public ResponseEntity<ApplicationResponse> saveLoansAdditionalDetail(AdditionalDetailLoans additionalDetail, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Start saveLoansAdditionalDetail for request : " + additionalDetail);
		ApplicationResponse response = new ApplicationResponse();

		try {
			if (additionalDetail == null || additionalDetail.getApplicationid() == null
					|| !org.apache.commons.lang3.StringUtils.isNumeric(additionalDetail.getApplicationid())) {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Invalid application id passed");
				throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean("CBPS-102", "Invalid application id passed"));
			}
			Map<String, Object> vars = new HashMap<String, Object>();
			vars.put("action", additionalDetail.getAction() != null ? additionalDetail.getAction().toLowerCase() : "next");
			vars.put(CreditBusinessConstants.APPLICATION_ID, additionalDetail.getApplicationid());

			if(!CreditBusinessConstants.BACK.equals(vars.get("action")) && additionalDetail.getPermanentAddressShowOnResiType()) {
				if(null!=additionalDetail.getResidenceType() && null!= additionalDetail.getResidenceType().getCode()
						&& !CreditBusinessConstants.RESIDENCE_OWN.equalsIgnoreCase(additionalDetail.getResidenceType().getCode())) {
					additionalDetail.setPermanentAddressRequired(true);
				} else {
					additionalDetail.setPermanentAddressRequired(false);
				}
			}
			vars.put(CreditBusinessConstants.REQUEST, additionalDetail);

			String processId = headers.get(CreditBusinessConstants.PROCESS_ID).get(0);
			String nextTaskKey = workflowHelper.completeTask(processId, vars);
			if (!StringUtils.isEmpty(nextTaskKey)) {
				NextTask task = new NextTask();
				task.setNextTaskKey(nextTaskKey);
				response.setNextTask(task);
			}
			response.setPayload(additionalDetail);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "saveLoansAdditionalDetail completed ");
			return new ResponseEntity<ApplicationResponse>(response, HttpStatus.CREATED);
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured while completing workflow" + e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured while completing workflow" + e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception occured while completing workflow");

		}
	}

	/**
	 * Method used to fetch addional details for loans
	 * 
	 * @param String      applicationId
	 * @param HttpHeaders headers
	 * @return AdditionalDetailLoans
	 */
	@Override
	public AdditionalDetailLoans getLoansAdditionalDetail(String applicationId, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "getLoansAdditionalDetail started ");
		AdditionalDetailLoans response = new AdditionalDetailLoans();
		headers.setContentType(MediaType.APPLICATION_JSON);
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			HashMap<String, String> params = new HashMap<>();
			params.put(APPLICATIONKEY, applicationId);
			params.put(IS_IN_PROCESSING, "true");
			ResponseEntity<?> childApplicationListRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getChildApplicationsUrl, List.class, params,
					null, headers);

			List<ApplicationDetail> childApplicationList = mapper.convertValue(childApplicationListRes.getBody(), new TypeReference<List<ApplicationDetail>>() {
			});
			ApplicationDetail childApp = childApplicationList.get(0);
			response.setL3ProductCode(childApp.getL3ProductCode());
			response.setL4ProductCode(childApp.getL4ProductCode());
			response.setLoanPurpose(childApp.getLoanPurpose());
			boolean isSalaried = isSalaried(headers, childApp);
			if (isSalaried && !CreditBusinessConstants.BFLSOLFLDG.equals(childApp.getL3ProductCode())
					&& Boolean.TRUE.equals(ginHelper.checkIsEtbCustomer(applicationId))
					&& BFL_PRINCIPLEKEY.equals(childApp.getPrincipalKey().toString())) {
				setResponseForEtbNonGinFlow(headers, response, childApp);
				return response;
			} else {
				setResponseForNtbFlow(headers, response, childApp);
				return response;
			}
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"CreditBusinessException Occured while getting Additional Details for Loans with applicationid: " + applicationId + " with exception: ", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Exception Occured while getting Additional Details for Loans with applicationid: " + applicationId + " with exception: ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "Some Technical Exception Occured"));
		}
	}

	private boolean isSalaried(HttpHeaders headers, ApplicationDetail childApp) {
		HashMap<String, String> childParams = new HashMap<>();
		childParams.put("applicationid", childApp.getApplicationKey());
		boolean isSalaried = false;
		UserProfileBean userProfile = apiCallsHelper.getUserProfile(childParams);
		if (userProfile != null) {
			childParams = new HashMap<>();
			childParams.put("applicationid", childApp.getApplicationKey());
			childParams.put("userattributekey", userProfile.getApplicationUserAttributeKey());
			Occupation occupation = getProfessionalDetail(childParams, headers);
			if (null != occupation) {
				OccupationReference occupationReference = apiCallsHelper
						.getOccupationMasterFromOccupationId(occupation.getOcupationType().getKey());
				if (null != occupationReference) {
					Reference occupationType = getReference(occupationReference.getOccupationKey(),
							occupationReference.getOccupationCode(), occupationReference.getOccupationValue());
					if (SALARIED.equalsIgnoreCase(occupationType.getCode())) {
						isSalaried = true;
					}
				}
			}
		}
		return isSalaried;
	}

	private void setBundleAndNomineeData(HttpHeaders headers, AdditionalDetailLoans response, String childAppId) {
		HashMap<String, String> params;
		params = new HashMap<>();
		params.put(APPLICATION_ID, childAppId);
		JSONObject[] bundleKeyRespArr = apiCallsHelper.callApi(getBundleSelected, HttpMethod.GET, params, null, JSONObject[].class);
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "GetBundle response " + bundleKeyRespArr);
		JSONObject bundleResp = null;
		if (!ArrayUtils.isEmpty(bundleKeyRespArr)) {
			for (JSONObject bundle : bundleKeyRespArr) {
				if (bundle.get("source") != null && CreditBusinessConstants.JOURNEY.equalsIgnoreCase(bundle.get("source").toString())) {
					bundleResp = bundle;
					break;
				}
			}

			if (bundleResp != null && bundleResp.get("bundleSelected") != null && (boolean) bundleResp.get("bundleSelected")) {
				response.setBundleSelected(true);
				List<JSONObject> nomineeData = null;
				try {

					nomineeData = getNomineeDataFromVas(bundleResp.get("bundleApplicationKey"), headers);
					List<Nominee> nomineeList = mapNominee(nomineeData);
					response.setNomineeDetails(nomineeList);

				} catch (CreditBusinessException e) {
					if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
						logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Resource Not Found exception for Nominee details");
					} else {
						logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception while fetching Nominee details ", e);
						throw e;
					}
				}
			}
		} else {
			response.setBundleSelected(false);
		}
	}

	private List<JSONObject> getNomineeDataFromVas(Object vasApplicationId, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Started getNomineeDataFromVas for VAS ApplicationKey " + vasApplicationId);
		Map<String, String> params = new HashMap<>();
		params.put("applicationKey", vasApplicationId.toString());
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Calling VAS Application Service");
		ResponseEntity<?> nomineeResp = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getNominee, List.class, params, null, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Response received from Vas Domain " + nomineeResp);
		if (nomineeResp != null && HttpStatus.OK.equals(nomineeResp.getStatusCode()) && nomineeResp.getBody() != null) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "getNomineeDataFromVas finished ");
			return mapper.convertValue(nomineeResp.getBody(), new TypeReference<List<JSONObject>>() {
			});
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "getNomineeData finished ");
		return null;
	}

	private void setAddresses(HttpHeaders headers, Boolean permanentAddressRequired, HashMap<String, String> params,
			AdditionalDetailLoans response) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "started setAddresses for params: " + params);
		List<Address> addresses = new ArrayList<>();
		params.put(TYPE_KEY, null);
		params.put(RETURNSINGLECURRENTADDRESSFLAG, Boolean.FALSE.toString());
		params.put(REMOVEEXACTMATCHCURRENTADDRESS, Boolean.FALSE.toString());
		List<Address> addressList = getV2Address(new HttpHeaders(), params);
		if (!CollectionUtil.isEmpty(addressList)) {
			for (Address address : addressList) {
				if ("true".equals(additionalDetailsAddressSources.get(address.getAddressSource()))
						&& AddressTypeEnum.CURRENT.getValue().equalsIgnoreCase(address.getAddressTypeKey())) {
					addresses.add(address);
				}
				if (AddressTypeEnum.OFFICE.getValue().equalsIgnoreCase(address.getAddressTypeKey())) {
					addresses.add(address);
				}
				if (AddressTypeEnum.PERMANENT.getValue().equalsIgnoreCase(address.getAddressTypeKey())
						&& permanentAddressRequired) {
					addresses.add(address);
				}
			}
		}
		response.setAddressDetails(addresses);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "completed setAddresses ");
	}

	private List<UserProfileBean> getUserProfiles(HttpHeaders headers, HashMap<String, String> params, ObjectMapper mapper) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching userprofiles for params : " + params);
		ResponseEntity<?> userProfileResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getUserProfilesUrl, List.class, params, null, headers);
		List<UserProfileBean> userProfileList = mapper.convertValue(userProfileResponse.getBody(), new TypeReference<List<UserProfileBean>>() {
		});
		return userProfileList;
	}

	private List<LookupCodeValuesResponseBean> getQualificationList(ObjectMapper mapper, String qualification) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "fetching qualification lookup ");
		List<LookupCodeValuesResponseBean> qualificationList = null;
		if (!StringUtils.isEmpty(qualification)) {
			final String nonModifibleQualCode = qualification;
			HashMap<String, String> params = new HashMap<>();
			params.put("lkpcode", "QUALIFICATION");
			ResponseEntity<?> getlLookUpCodeRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, lookUpCodeUrl, Object.class, params, null,
					new HttpHeaders());
			LookupCodeResponse lookUpCode = mapper.convertValue(getlLookUpCodeRes.getBody(), LookupCodeResponse.class);
			qualificationList = lookUpCode.getLookupValuesResponseList().stream().filter(o -> nonModifibleQualCode.equalsIgnoreCase(o.getCode()))
					.collect(Collectors.toList());
		}
		return qualificationList;
	}

	public AdditionalDetailPricing getPricing(String applicationId, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "started getPricing for : " + applicationId);
		headers.setContentType(MediaType.APPLICATION_JSON);
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		AdditionalDetailPricing response = new AdditionalDetailPricing();
		HashMap<String, String> params = new HashMap<>();
		params.put(APPLICATIONKEY, applicationId);
		params.put(IS_IN_PROCESSING, "true");
		try {
			ResponseEntity<?> childApplicationListRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getChildApplicationsUrl, List.class, params,
					null, headers);
			if (childApplicationListRes.getBody() != null) {
				List<ApplicationDetail> childApplicationList = mapper.convertValue(childApplicationListRes.getBody(),
						new TypeReference<List<ApplicationDetail>>() {
						});
				ApplicationDetail childApp = childApplicationList.get(0);
				response.setL3ProductCode(childApp.getL3ProductCode());
				response.setL4ProductCode(childApp.getL4ProductCode());

				SummaryResponse summary = summaryImpl.getLoanPricing(headers, childApp.getApplicationKey());
				response.setAmount(summary.getTotalAmount());
				response.setNetDisbursementAmount(summary.getNetDisbursementAmount());
				response.setTotalFeeAmount(summary.getTotalFeeAmount());
				if (summary.getLoanDetails() != null) {
					response.setEmi(summary.getLoanDetails().getEmi());
					response.setRoi(summary.getLoanDetails().getRoi());
				}
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Completed getPricing " + response);
			return response;
		} catch (CreditBusinessException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"CreditBusinessException Occured while Additional Details getPricing with applicationid: " + applicationId + " with exception: ", e);
			throw e;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
					"Exception Occured while Additional Details getPricing with applicationid: " + applicationId + " with exception: ", e);
			throw new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("CBS-001", "Some Technical Exception Occured"));
		}
	}

	private void setProfessionalDetails(AdditionalDetailLoans response, Map<String, String> params, HttpHeaders headers,ApplicationDetail childApp)
			throws JsonMappingException, CacheServiceException, JsonProcessingException {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "started setProfessionalDetails with params : " + params);
		Occupation occupation = getProfessionalDetail(params, headers);
		OccupationMaster occupationMaster = masterDataHelper.getOccupationByKey(occupation.getOcupationType().getKey());
		String occupationType = occupationMaster.getOccupationCode();
		switch (occupationType) {
		case SALARIED: {
			response.setIsSelfEmployed(false);			
			if (occupation.getSalariedDetail() != null) {
				SalariedDetail salariedDetail = occupation.getSalariedDetail();
				response.setCurrentWorkExperience(salariedDetail.getWorkExperienceInMonths());
				response.setExperience(salariedDetail.getExperience());
				response.setAverageBankBalance(salariedDetail.getAverageBankBalance());

				if (salariedDetail.getEmployerName() != null && salariedDetail.getEmployerName().getKey() != null) {
					Long employerId = salariedDetail.getEmployerName().getKey();
					EmployerMasterBean employerMaster = masterDataHelper.getEmployerByKey(employerId);
					if (employerMaster != null) {
						String companySubCategory = employerMaster.getEmprMastSubcategory();
						response.setGenericEmailAllowed(checkCompanySubCategoryIsPresent(companySubCategory));
					}
				}
				response.setEmployerType(null != occupation.getSalariedDetail().getEmployerType()
						? occupation.getSalariedDetail().getEmployerType() : null);
				response.setSubEmployerType(null != occupation.getSalariedDetail().getSubEmployerType()
						? occupation.getSalariedDetail().getSubEmployerType() : null);
				if(null != occupation.getSalariedDetail().getDesignation()) {
					response.setDesignation(occupation.getSalariedDetail().getDesignation());
				}
			}

			Email workEmail = getEmail(params.get(APPLICATION_ID), params.get(USERATTRIBUTEKEY), EmailTypeEnum.OFFICE.getValue().toString());
			if(null == workEmail) {
				workEmail = getEmail(params.get(APPLICATION_ID), params.get(USERATTRIBUTEKEY), EmailTypeEnum.OTHER.getValue().toString());
			}
			response.setWorkEmailId(workEmail != null ? workEmail.getEmail():null);
			break;
		}
		case BUSINESS: {
			populateBusinessDetails(response, occupation);
			break;
		}
		default:
			break;
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "completed setProfessionalDetails ");
	}

	public boolean checkCompanySubCategoryIsPresent(String companySubCategory) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "started checkCompanySubCategoryIsPresent :" + companySubCategory);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Configured companySubCategorys :" + companySubCategoryTypes);
		if (companySubCategory != null) {
			List<String> companyCategoryTypeList = Arrays.asList(companySubCategoryTypes.split(","));
			if (companySubCategory != null && !CollectionUtils.isEmpty(companyCategoryTypeList)) {
				return companyCategoryTypeList.contains(companySubCategory);
			}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "completed checkCompanySubCategoryIsPresent ");
		return false;
	}


	@SuppressWarnings("unchecked")
	private Occupation getProfessionalDetail(Map<String, String> params, HttpHeaders headers) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "started getProfessionalDetail fetching occupation for params : " + params);
		ResponseEntity<Occupation> occupationReponse = (ResponseEntity<Occupation>) creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getProfessionUrl,
				Occupation.class, params, null, headers);
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "completed getProfessionalDetail ");
		return null != occupationReponse ? occupationReponse.getBody() : null;
	}

	private Email getEmail(String applicationKey, String userAttributeKey, String emailTypeKey) {
		try {
			return apiCallsHelper.getEmail(applicationKey, userAttributeKey, emailTypeKey);
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Email not found on additional detail page for applicationId = " + applicationKey
						+ ", UserAttributeKey = " + userAttributeKey + " and EmailTypeKey =" + emailTypeKey);
				return null;
			} else {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured while fetching email on additional detail page for applicationId = "
						+ applicationKey + ", UserAttributeKey = " + userAttributeKey + " and EmailTypeKey =" + emailTypeKey);
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured while fetching email on additional detail  ", e);
				throw e;
			}
		}
	}

	private void setQualificationData(AdditionalDetailLoans response, ObjectMapper mapper, String qualification) {
		try {
			Object qualificationReferenceObject = masterDataHelper.getGetLookupByValueAndSource(qualification, LOOKUP_SOURCE_QUALIFICATION);
			LookupCodeValuesResponseBean qualificationReference = mapper.convertValue(qualificationReferenceObject, LookupCodeValuesResponseBean.class);
			response.setQualification(
					getReference(qualificationReference.getKey().longValue(), qualificationReference.getCode(), qualificationReference.getValue()));
		} catch (CacheServiceException cacheException) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occurred while fetching lookup from cache", cacheException);
		}
	}

	private boolean getPermanantAddressRequiredFlag(Long residanceTypeKey) {
		ResidenceMaster[] resiTypes = apiCallsHelper.getAllResitypes();
		if (resiTypes != null && resiTypes.length > 0) {
			for (ResidenceMaster resi : resiTypes) {
				if (residanceTypeKey != null && residanceTypeKey == resi.getResidenceKey() && !"OWN".equalsIgnoreCase(resi.getResidenceCode())) {
					return true;
				}
			}
		}
		return false;
	}

	private void setResponseForEtbGinFlow(HttpHeaders headers, AdditionalDetailLoans response, ApplicationDetail childApp)
			throws JsonMappingException, CacheServiceException, JsonProcessingException {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "setResponseForEtbGinFlow started");
		response.setIsGinFlow(true);
		response.setPermanentAddressRequired(false);

		String childAppId = childApp.getApplicationKey();
		HashMap<String, String> params = new HashMap<>();
		params.put(APPLICATION_ID, childAppId);
		UserProfileBean userProfile = apiCallsHelper.getUserProfile(params);
		if (userProfile != null) {
			params.put(USERATTRIBUTEKEY, userProfile.getApplicationUserAttributeKey());
			response.setMotherName(userProfile.getMotherName());
			response.setFatherName(userProfile.getFatherName());
			response.setWorkEmailRequired(userProfile.getWorkEmailRequired());

			if (ginHelper.checkAllowEmployerForEtbGin(childApp.getRiskoffertype())) {
				response.setEmployerRequired(true);
				Occupation occupation = getProfessionalDetail(params, headers);
				if (occupation != null && occupation.getSalariedDetail() != null) {
					SalariedDetail salariedDetail = occupation.getSalariedDetail();
					if (salariedDetail.getEmployerName() != null && salariedDetail.getEmployerName().getKey() != null) {
						EmployerMasterBean employerMaster = masterDataHelper
								.getEmployerByKey(salariedDetail.getEmployerName().getKey());
						if (null != employerMaster) {
							salariedDetail.getEmployerName().setValue(employerMaster.getEmprMasterName());
							String companySubCategory = employerMaster.getEmprMastSubcategory();
							response.setGenericEmailAllowed(checkCompanySubCategoryIsPresent(companySubCategory));
						}
					}
					response.setEmployerName(occupation.getSalariedDetail().getEmployerName());
				} else if (null != occupation && null != occupation.getBusinessOwnerDetails()) {
					populateBusinessDetails(response, occupation);
				}
			}
			
			Email workEmail = getEmail(params.get(APPLICATION_ID), params.get(USERATTRIBUTEKEY), EmailTypeEnum.OFFICE.getValue().toString());
			if(null == workEmail) {

				workEmail = getEmail(params.get(APPLICATION_ID), params.get(USERATTRIBUTEKEY), EmailTypeEnum.OTHER.getValue().toString());

			}
			response.setWorkEmailId(workEmail != null ? workEmail.getEmail() : null);
			
			response.setPersonalEmailRequired(false);			
			
		}

		// checks if bundle is present and if true then fetches nominee data 
		setBundleAndNomineeData(headers, response, childApp.getApplicationKey());
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "setResponseForEtbGinFlow completed");
	}

	private void setResponseForNtbFlow(HttpHeaders headers, AdditionalDetailLoans response, ApplicationDetail childApp)
			throws JsonMappingException, CacheServiceException, JsonProcessingException {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside setResponseForNonEtbFlow ");
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		HashMap<String, String> params = new HashMap<>();
		String childAppId = childApp.getApplicationKey();
		// checks if bundle is present and if true then fetches nominee data 
		if (!CreditBusinessConstants.BFLSOLFLDG.equals(response.getL3ProductCode())) {
			setBundleAndNomineeData(headers, response, childAppId);
		}
		params.put(APPLICATION_ID, childAppId);
		UserProfileBean userProfile = apiCallsHelper.getUserProfile(params);
		if (userProfile != null) {
			response.setMotherName(userProfile.getMotherName());
			response.setFatherName(userProfile.getFatherName());
			response.setWorkEmailRequired(userProfile.getWorkEmailRequired());

			//For Credit vidya, Paysense permanent address to be shown always
			String childPrincipalKey = String.valueOf(childApp.getPrincipalKey());
			String l3ProductCode = childApp.getL3ProductCode();
			if ("true".equalsIgnoreCase(permanentAddressRequired.get(l3ProductCode))) {
				response.setPermanentAddressRequired(true);
			} else if ("false".equalsIgnoreCase(permanentAddressRequired.get(l3ProductCode))) {
				response.setPermanentAddressRequired(false);
			} else {
				response.setPermanentAddressRequired(getPermanantAddressRequiredFlag(userProfile.getResidenceTypeKey()));
				logger.warn(CLASSNAME,BFLLoggerComponent.SERVICE,"Permanent address not configured for product code" + l3ProductCode);
			}
			
			if("true".equalsIgnoreCase(permanentAddressShowOnResiType.get(l3ProductCode))) {
				response.setPermanentAddressShowOnResiType(true);
			} else {
				response.setPermanentAddressShowOnResiType(false);
			}
			
			setGenderDetailsResponse(userProfile,response,childApp);
			response.setResidenceType(setResidenceTypeResponse(userProfile));
			
			params.put(USERATTRIBUTEKEY, userProfile.getApplicationUserAttributeKey());
			//set address details
			setAddresses(headers, response.getPermanentAddressRequired(), params, response);

			// set professional details
			setProfessionalDetails(response, params, headers,childApp);

			String qualification = userProfile.getQualification();
			if (!StringUtils.isEmpty(qualification)) {
				setQualificationData(response, mapper, qualification);
			}
			
			//Get partner address from mongo db
			headers.add("applicationid", childApp.getParentApplicationKey());
			params.put("principalkey", childApp.getPrincipalKey().toString());
			setPartnerAddress(response, params, headers, mapper);
			
			setPersonalEmail(response, params);

		}
		response.setIsNtbFlow(true);
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "setResponseForNonEtbFlow completed");
	}

	private void setResponseForEtbNonGinFlow(HttpHeaders headers, AdditionalDetailLoans response, ApplicationDetail childApp) throws JsonProcessingException {
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside setResponseForEtbNonGinFlow ");
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		HashMap<String, String> params = new HashMap<>();
		String childAppId = childApp.getApplicationKey();
		// checks if bundle is present and if true then fetches nominee data 
		setBundleAndNomineeData(headers, response, childAppId);

		params.put(APPLICATION_ID, childAppId);
		UserProfileBean userProfile = apiCallsHelper.getUserProfile(params);
		if (userProfile != null) {
			params.put(USERATTRIBUTEKEY, userProfile.getApplicationUserAttributeKey());
			response.setWorkEmailRequired(userProfile.getWorkEmailRequired());
			response.setMotherName(userProfile.getMotherName());
			response.setFatherName(userProfile.getFatherName());

			boolean permanantAddRequired = getPermanantAddressRequiredFlag(userProfile.getResidenceTypeKey());
			response.setPermanentAddressRequired(permanantAddRequired);

			setProfessionalDetails(response, params, headers,childApp);
			
			//set address details
			params.put("returnSingleCurrentAddressFlag", Boolean.FALSE.toString());
			params.put("removeExactMatchCurrentAddress", Boolean.TRUE.toString());
			params.put(TYPE_KEY, null);
			List<Address> addressList = getV2Address(headers, params);
			if (!CollectionUtils.isEmpty(addressList)) {
				for (Address address : addressList) {
					if ((address.getAddressLine1() != null && address.getAddressLine1().length() > 50)
							|| (address.getAddressLine2() != null && address.getAddressLine2().length() > 50)) {
						Map<String,String> addressLines = creditBusinessHelper.addLinebreaks(address.getAddressLine1()+" "+address.getAddressLine2(), 50);
						address.setAddressLine1(addressLines.get("addressLine1"));
						address.setAddressLine2(addressLines.get("addressLine2"));
					}
				}
			}
			response.setAddressDetails(addressList);

			boolean isDesignationRequired = ginHelper.checkAllowDesignationForEtbNonGin(childApp.getRiskoffertype());
			if (isDesignationRequired) {
				Occupation occupation = getProfessionalDetail(params, headers);
				if (occupation.getSalariedDetail() != null) {
					response.setDesignation(occupation.getSalariedDetail().getDesignation());
				}
			}
			response.setDesignationRequired(isDesignationRequired);

			

			setPersonalEmail(response, params);
		}

		response.setWorkEmailRequired(true);
		
		response.setIsNonGinFlow(true);
		
		response.setIsSelfEmployed(false);
		logger.info(CLASSNAME, BFLLoggerComponent.SERVICE, "setResponseForEtbNonGinFlow completed");
	}

	private void setPersonalEmail(AdditionalDetailLoans response, HashMap<String, String> params) {
		Email personalEmail = getEmail(params.get("applicationid"), params.get("userattributekey"), EmailTypeEnum.PERON1.getValue().toString());
		if (personalEmail == null) {
			response.setPersonalEmailRequired(true);
		} else {
			response.setPersonalEmailRequired(false);
			response.setPersonalEmailId(personalEmail.getEmail());
		}
	}

	private List<Address> getV2Address(HttpHeaders headers, HashMap<String, String> params) {
		try {
			return apiCallsHelper.getAddressV2(headers, params);
		} catch (CreditBusinessException e) {
			if (HttpStatus.NOT_FOUND.equals(e.getCode())) {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Resource Not Found exception while fetching V2 address with params = " + params);
				return null;
			} else {
				logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception while fetching V2 address with params = " + params, e);
				throw e;
			}
		}
	}

	private List<Nominee> mapNominee(List<JSONObject> nomineeData) {
		List<Nominee> nomineeList = null;
		if (!CollectionUtils.isEmpty(nomineeData)) {
			nomineeList = new ArrayList<Nominee>();
			for (JSONObject n : nomineeData) {
				Nominee nominee = new Nominee();
				nominee.setDateOfBirth(n.get("dateOfBirth") != null ? n.get("dateOfBirth").toString() : null);
				nominee.setName(n.get("name") != null ? n.get("name").toString() : null);
				if (n.get("relationship") != null) {
					RelationshipEnum relation = RelationshipEnum.getByValue(n.get("relationship").toString());
					if (relation != null) {
						Reference ref = new Reference();
						ref.setCode(relation.getCode());
						ref.setValue(relation.getValue());
						ref.setKey(Long.valueOf(relation.getKey().toString()));
						nominee.setRelationship(ref);
					}
				}
				nomineeList.add(nominee);
			}
		}
		return nomineeList;
	}
	
	private void setPartnerAddress(AdditionalDetailLoans response, Map<String, String> params, HttpHeaders headers, ObjectMapper mapper) {
		if (params.get("principalkey").equals(CreditBusinessConstants.AXIS_LOAN_KEY)) {
			try {
				ResponseEntity<?> getCustomerDemog = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, getPrincipalCustDemogUrl,
						CustomerDemog.class, params, null, headers);
				CustomerDemog customerDemog = mapper.convertValue(getCustomerDemog.getBody(), CustomerDemog.class);
				if (null != customerDemog && !CollectionUtils.isEmpty(customerDemog.getAddressList())) {
					Optional<Address> address = customerDemog.getAddressList().stream()
							.filter(add -> AddressTypeEnum.CURRENT.getValue().equalsIgnoreCase(add.getAddressTypeKey())).findFirst();
					response.setPartnerAddressDetails(address.isPresent() ? address.get() : null);
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, 
							"Successfully added partner address from mongo.");
				}
			} catch (CreditBusinessException e) {
				if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Partner address not found. ", e);
				}
			}
		}
	}
	private void populateBusinessDetails(AdditionalDetailLoans response, Occupation occupation) {
		response.setIsSelfEmployed(true);
		response.setPresentBusinessVintage(occupation.getBusinessOwnerDetails().getPresentBusinessVintage());
		response.setWorkEmailId(null);
		if (null != occupation.getBusinessOwnerDetails().getShopStatus()
				&& null != occupation.getBusinessOwnerDetails().getShopStatus().getCode()) {
			response.setShopStatus(
					getReference(null, occupation.getBusinessOwnerDetails().getShopStatus().getCode(), ShopStatusEnum
							.getValueOfShopStatus(occupation.getBusinessOwnerDetails().getShopStatus().getCode())));
		}
		if (null != occupation.getBusinessOwnerDetails().getCorporateLinkageType()
				&& null != occupation.getBusinessOwnerDetails().getCorporateLinkageType().getCode()) {
			response.setCorporateLinkageType(
					getReference(null, occupation.getBusinessOwnerDetails().getCorporateLinkageType().getCode(),
							CorporateLinkageEnum.getValueOfCorporateLinkage(
									occupation.getBusinessOwnerDetails().getCorporateLinkageType().getCode())));
		}
		if (null != occupation.getBusinessOwnerDetails().getNatureOfBusiness()
				&& null != occupation.getBusinessOwnerDetails().getNatureOfBusiness().getKey()) {
			response.setNatureOfBusiness(
					getReference(occupation.getBusinessOwnerDetails().getNatureOfBusiness().getKey(), null, null));
		}
	}
	private void setGenderDetailsResponse(UserProfileBean userProfile, AdditionalDetailLoans response, ApplicationDetail childAppDetails) {
		String childPrincipalKey = String.valueOf(childAppDetails.getPrincipalKey());
		String l3ProductCode = childAppDetails.getL3ProductCode();
		String childApplicationId = childAppDetails.getApplicationKey();
		response.setIsGenderRequired(false);
		if("true".equalsIgnoreCase(genderRequiredl3ProductCodes.get(l3ProductCode))){
			if("3".equals(childPrincipalKey)) {
				JSONObject applicationParamDetails = apiCallsHelper.getApplicationParameterDetails(childApplicationId);
				Map applicationParameters = (Map) applicationParamDetails.get("applicationParameters");
				Object fppSelectedByUser = applicationParameters.get("fppselectedbyuser");
				if(null == fppSelectedByUser || !Boolean.valueOf(fppSelectedByUser.toString())) {
					response.setIsGenderRequired(true);
				}
			} else {
				response.setIsGenderRequired(true);
			}
			if(null!=userProfile.getGenderKey() && response.getIsGenderRequired()) {
				Reference gender = masterDataHelper.getGenderReferenceByTypeKey(userProfile.getGenderKey());
				response.setGender(gender);
			}
		}
	}
	
	private Reference setResidenceTypeResponse(UserProfileBean userProfile) {
		Reference filterReference = getReference(userProfile.getResidenceTypeKey(), null, null);
		Reference residence = apiCallsHelper.getReference(ReferenceOf.RESIDENCE, null, filterReference);
		return residence;
	}
	
}
