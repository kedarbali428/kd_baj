package com.bajaj.markets.credit.business.service.impl;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.BITLY_NEXT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CREDIT_JOURNEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.ESIGN_TASKKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.ESIGN_THANK_YOU_TASKKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PROCESS_ID;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.RESUME;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.Esign;
import com.bajaj.markets.credit.business.beans.EsignRequest;
import com.bajaj.markets.credit.business.beans.EsignResponse;
import com.bajaj.markets.credit.business.beans.GenerateOTPResponseBean;
import com.bajaj.markets.credit.business.beans.NextTask;
import com.bajaj.markets.credit.business.beans.Status;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EmailTypeEnum;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessEsignService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CreditBusinessEsignServiceImpl implements CreditBusinessEsignService {

	@Autowired
	CreditBusinessHelper creditBusinessHelper;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	WorkflowHelper workflowHelper;

	@Value("${api.omcreditesignservice.esigndocument.GET.url}")
	private String getEsignStatusUrl;

	@Value("${api.omcreditesignservice.esigndocument.PUT.url}")
	private String createEsignStampedDocUrl;

	@Value("${api.omcreditesignservice.esignconsent.PUT.url}")
	private String esignconsentUrl;
	
	@Value("${api.omcreditapplicationservice.updatestage.put.url}")
	private String applicationStageUrl;

	@Autowired
	CustomDefaultHeaders customDefaultHeaders;

	@Value("${api.omcreditapplicationservice.childapplications.get.url}")
	private String getChildApplicationsUrl;

	private final String erroCode = "OMCB_020";

	private final String errorMessage = "ApplicationKey should be numeric";

	private final String fieldValidationException = "Field validation exception.";

	@Value("${esigncommmunicationappend}")
	private String communicationEsignAppender;

	private ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	CreditBusinessApiCallsHelper apiCallHelper;

	private static final String CLASS_NAME = CreditBusinessEsignServiceImpl.class.getCanonicalName();

	@Override
	public GenerateOTPResponseBean consentOTP(String applicationKey, HttpHeaders headers) {
		String childApplicationKey = null;
		if (!StringUtils.isNumeric(applicationKey)) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, fieldValidationException);
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean(erroCode, errorMessage));
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside consentOTP of creditEsignServiceImpl " + applicationKey);
		GenerateOTPResponseBean consentResponse = null;
		childApplicationKey = getChildApplication(applicationKey, headers);
		Map<String, String> params = new HashMap<>();
		params.put(CreditBusinessConstants.APPLICATIONKEY, childApplicationKey);
		ResponseEntity<?> esignConsentResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT,
				esignconsentUrl, Object.class, params, null, headers);
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Response from Esgin consentAPI " + esignConsentResponse);
		if (null != esignConsentResponse && HttpStatus.OK.equals(esignConsentResponse.getStatusCode())
				&& null != esignConsentResponse.getBody()) {
			consentResponse = mapper.convertValue(esignConsentResponse.getBody(), GenerateOTPResponseBean.class);
		}

		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Exiting consentOTP of creditEsignServiceImpl and consentResponse " + consentResponse);
		return consentResponse;

	}

	@Override
	public EsignResponse createDocument(String applicationKey, EsignRequest esignRequest, HttpHeaders headers) {
		if (!StringUtils.isNumeric(applicationKey)) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, fieldValidationException);
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean(erroCode, errorMessage));
		}

		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside createDocument of creditEsignServiceImpl " + applicationKey);
		EsignResponse esignResponse = null;
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		String esignReq;
		String childApplicationKey = null;
		try {
			esignReq = mapper.writeValueAsString(esignRequest);
		} catch (JsonProcessingException e) {
			logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Request cant be mapped " + e);
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY,
					new ErrorBean("OMCB_050", "Request cant be mapped"));
		}
		childApplicationKey = getChildApplication(applicationKey, headers);
		Map<String, String> params = new HashMap<>();
		params.put(CreditBusinessConstants.APPLICATIONKEY, childApplicationKey);
		ResponseEntity<?> esignDocResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT,
				createEsignStampedDocUrl, Object.class, params, esignReq, headers);
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Response from Esgin create doc " + esignDocResponse);
		if (null != esignDocResponse && HttpStatus.OK.equals(esignDocResponse.getStatusCode())
				&& null != esignDocResponse.getBody()) {

			esignResponse = mapper.convertValue(esignDocResponse.getBody(), EsignResponse.class);
		}
		
		if (Status.COMPLETED.equals(esignResponse.getStatus())) {
			markEsignCompletedStage(childApplicationKey, params, headers);
		}
		
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Exiting createDocument of creditEsignServiceImpl and esignResponse is  " + esignResponse);
		return esignResponse;

	}

	private String getChildApplication(String applicationKey, HttpHeaders headers) {
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside getChildApplication of creditEsignServiceImpl for applicationKey " + applicationKey);
		String childApplicationKey = null;
		Map<String, String> chilParams = new HashMap<>();
		chilParams.put("applicationkey", applicationKey);
		chilParams.put("isInProcessing", "true");
		ResponseEntity<?> childApplicationListRes = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				getChildApplicationsUrl, List.class, chilParams, null, headers);
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Response from getChildApplication is   " + childApplicationListRes);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<ApplicationDetail> childApplicationList = mapper.convertValue(childApplicationListRes.getBody(),
				new TypeReference<List<ApplicationDetail>>() {
				});
		if (Objects.nonNull(childApplicationList) && !childApplicationList.isEmpty()) {
			ApplicationDetail additionalDetail = childApplicationList.get(0);
			if (null != additionalDetail)
				childApplicationKey = additionalDetail.getApplicationKey();
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Exiting getChildApplication of creditEsignServiceImpl for childApplicationKey" + childApplicationKey);
		return childApplicationKey;

	}

	@Override
	public EsignResponse getDocumentStatus(String applicationKey, HttpHeaders headers) {
		if (!StringUtils.isNumeric(applicationKey)) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, fieldValidationException);
			throw new CreditBusinessException(HttpStatus.UNPROCESSABLE_ENTITY, new ErrorBean(erroCode, errorMessage));
		}
		String childApplicationKey = null;
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Inside getDocumentStatus of creditEsignServiceImpl ");
		EsignResponse esignResponse = null;
		childApplicationKey = getChildApplication(applicationKey, headers);
		Map<String, String> params = new HashMap<>();
		params.put(CreditBusinessConstants.APPLICATIONKEY, childApplicationKey);
		params.put(CreditBusinessConstants.COMMUNICATION, String.valueOf(true));
		String getEsignCompleteUrl = getEsignStatusUrl + communicationEsignAppender;
		ResponseEntity<?> esignDocResponse = creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				getEsignCompleteUrl, Object.class, params, null, headers);
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE, "Response from Esgin create doc " + esignDocResponse);
		if (null != esignDocResponse && HttpStatus.OK.equals(esignDocResponse.getStatusCode())
				&& null != esignDocResponse.getBody()) {
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			esignResponse = mapper.convertValue(esignDocResponse.getBody(), EsignResponse.class);
			esignResponse.setPersonalEmailRequired(getPersonalEmailRequiredFlag(applicationKey));
		}
		logger.info(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Exiting getDocumentStatus of creditEsignServiceImpl and esignREsponse is " + esignResponse);
		return esignResponse;
	}

	@Override
	public ApplicationResponse completeEsign(Esign esignRequest, HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Starting Post Esign with Request : " + esignRequest);

		Map<String, Object> vars = new HashMap<String, Object>();
		vars.put(CreditBusinessConstants.REQUEST, esignRequest);
		vars.put("action", esignRequest.getAction() != null ? esignRequest.getAction().toLowerCase() : "next");
		vars.put(CreditBusinessConstants.APPLICATIONID, esignRequest.getApplicationid());

		try {
			ApplicationResponse applicationResponse = new ApplicationResponse();
			
			if(!BITLY_NEXT.equalsIgnoreCase(vars.get("action").toString())) {
				if (headers.get(PROCESS_ID) != null) {
					String nextTaskKey = workflowHelper.completeTask(headers.get(PROCESS_ID).get(0), vars);
	
					NextTask nextTask = new NextTask();
					nextTask.setNextTaskKey(nextTaskKey);
					applicationResponse.setNextTask(nextTask);
				}
			} else {
				JSONObject payload = new JSONObject();
				payload.put(CreditBusinessConstants.APPLICATION_ID, esignRequest.getApplicationid());
				payload.put(CreditBusinessConstants.JOURNEY, RESUME);
				
				NextTask nextTask = workflowHelper.startActivitiProcess(CREDIT_JOURNEY, payload);
				
				if (null != nextTask && !StringUtils.isEmpty(nextTask.getNextTaskKey()) 
						&& ESIGN_TASKKEY.equalsIgnoreCase(nextTask.getNextTaskKey())) {
					String nextTaskKey = workflowHelper.completeTask(nextTask.getProcessID(), vars);
					nextTask.setNextTaskKey(nextTaskKey);
				} else {
					nextTask.setNextTaskKey(ESIGN_THANK_YOU_TASKKEY);
				}
				
				nextTask.setProcessID(null);
				applicationResponse.setNextTask(nextTask);
			}
			
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Ending Post Esign with Response" + applicationResponse);
			return applicationResponse;
			
		} catch (CreditBusinessException e) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
					"Exception completing workflow task" + e);
			throw e;
		} catch (Exception e) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.SERVICE,
					"Exception occured while calling the service" + e);
			throw new CreditBusinessException(e.getCause());
		}

	}
	
	@SuppressWarnings("unchecked")
	private void markEsignCompletedStage(String childApplicationKey, Map<String, String> params, HttpHeaders headers) {
		try {
			params.put(APPLICATION_ID, childApplicationKey);
			if(validateCurrentStageEsign(childApplicationKey, params, headers)) {
				JSONObject stageUpdate = new JSONObject();
				stageUpdate.put("percentageCompletion", 93l);
				creditBusinessHelper.invokeRestEndpoint(HttpMethod.PUT, applicationStageUrl, Object.class, params, stageUpdate.toString(), headers);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Current stage is not esign. Not updating stage to thank you page for: " 
						+ childApplicationKey);
			}
		} catch (CreditBusinessException businessException) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Business Exception occurred while updating stage for child app: " + childApplicationKey,
					businessException);
		} catch (Exception exception) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception occurred while updating stage for child app: "
					+ childApplicationKey, exception);
		}
	}
	
	private boolean validateCurrentStageEsign(String childApplicationKey, Map<String, String> params, HttpHeaders headers) {
		boolean isStageEsign = false;
		ResponseEntity<?> currentStageResponse =  creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET,
				applicationStageUrl, Object.class, params, null, headers);
		
		if(null != currentStageResponse && HttpStatus.OK.equals(currentStageResponse.getStatusCode())
				&& null != currentStageResponse.getBody()) {
			JSONObject currentSubStage = CreditBusinessHelper.getJSONObject(currentStageResponse.getBody());
			
			if(null != currentSubStage && null != currentSubStage.get("percentageCompletion") 
					&& 90l == ((Double) currentSubStage.get("percentageCompletion")).longValue()) {
				isStageEsign = true;
			}
		}
		return isStageEsign;
	}
	
	private boolean getPersonalEmailRequiredFlag(String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "start getPersonalEmailRequiredFlag");
		boolean personalEmailRequired = false;
		Email emailDetails = null;
		try {
			Map<String,String> params = new HashMap<>();
			params.put(APPLICATION_ID,applicationId);
			UserProfileBean userProfile = apiCallHelper.getUserProfile(params);
			emailDetails = apiCallHelper.getEmail(applicationId, userProfile.getApplicationUserAttributeKey(), EmailTypeEnum.PERON1.getValue().toString());
		} catch (CreditBusinessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE,
					"Email not found for application " + applicationId);
		}
		if (null == emailDetails) {
			personalEmailRequired=true;
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.WORKFLOW_LISTENER, "end getPersonalEmailRequiredFlag");
		return personalEmailRequired;
	}

}
