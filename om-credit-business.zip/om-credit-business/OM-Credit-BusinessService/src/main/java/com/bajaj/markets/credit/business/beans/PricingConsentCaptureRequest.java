package com.bajaj.markets.credit.business.beans;

public class PricingConsentCaptureRequest {

	private String consentToken;
	private String employeeUserKey;
	private String channel;
	private Boolean employeeCaptured;
	public String getConsentToken() {
		return consentToken;
	}
	public void setConsentToken(String consentToken) {
		this.consentToken = consentToken;
	}
	public String getEmployeeUserKey() {
		return employeeUserKey;
	}
	public void setEmployeeUserKey(String employeeUserKey) {
		this.employeeUserKey = employeeUserKey;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public Boolean getEmployeeCaptured() {
		return employeeCaptured;
	}
	public void setEmployeeCaptured(Boolean employeeCaptured) {
		this.employeeCaptured = employeeCaptured;
	}
	@Override
	public String toString() {
		return "PricingConsentCaptureRequest [consentToken=" + consentToken + ", employeeUserKey=" + employeeUserKey
				+ ", channel=" + channel + ", employeeCaptured=" + employeeCaptured + "]";
	}
	
}
