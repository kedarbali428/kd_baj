package com.bajaj.markets.credit.business.listner;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.ConsumerAddress;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;

import io.jsonwebtoken.lang.Collections;

@Async
@Component
public class CibilAddressUpdateListener {
	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private CreditBusinessApiCallsHelper apiCallHelper;

	@Autowired
	private Environment env;

	@Autowired
	private MasterDataRedisClientHelper masterDataRedisClientHelper;

	public static final String ADD_LENGTH = "addLength";
	public static final String ADD_LINE = "addressLine";
	public static final String ADD_MIN_LENGTH = "addMinLength";

	public void updateCibilAddress(DelegateExecution execution) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start updateCibilAddress for applicationkey:"
						+ execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		if (execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE).equals(CreditBusinessConstants.CC)) {
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
					"Inside updateCibilAddress for credit card");
			JSONObject cibiljson = getCibilJsonForCards(execution);
			processConsumerAddress(execution, cibiljson);
		} else {
			JSONObject cibil = CreditBusinessHelper
					.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT));
			processConsumerAddress(execution, cibil);
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End updateCibilAddress");
	}

	private JSONObject getCibilJsonForCards(DelegateExecution execution) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start getCibilJsonForCards");
		JSONObject cibiljson = null;
		String cibil = apiCallHelper.getCommercialFormatCibil(
				execution.getVariable(CreditBusinessConstants.CIBIL_REF_KEY).toString(),
				execution.getVariable(CreditBusinessConstants.CIBIL_TYPE).toString(), "COMMERCIALCIBIL");
		if (!StringUtils.isBlank(cibil)) {
			cibiljson = CreditBusinessHelper.getJSONObject(cibil);
		} else {
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
					"Inside updateCibilAddress - cibil String for application is null ");
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End getCibilJsonForCards");
		return cibiljson;
	}

	private void processConsumerAddress(DelegateExecution execution, JSONObject cibil) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start updateConsumerAddress for applicationId: "
						+ execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
		try {
			List<ConsumerAddress> consuemrAddress = getAddressList(cibil);
			if (Objects.nonNull(consuemrAddress) && !Collections.isEmpty(consuemrAddress)) {
				List<Address> addressDetails = new ArrayList<>();
				Optional<Address> residenceAddresses = getResidenceAddress(consuemrAddress);
				addAddressToList(residenceAddresses, addressDetails);
				if (!checkOfficeAddressExist(execution)) {
					Optional<Address> officeAddresses = getOfficeAddress(consuemrAddress);
					addAddressToList(officeAddresses, addressDetails);
				}
				callAddressUpdateApi(execution, addressDetails);
			} else {
				logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
						"Consumer address list is empty for application: "
								+ execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
			}
		} catch (Exception exception) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
					"Inside processConsumerAddress - Exception occured in proccesing Cibil Address for applicationId: "
							+ execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString(),
					exception);
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End updateConsumerAddress for applicationId:"
						+ execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
	}

	private void addAddressToList(Optional<Address> address, List<Address> addressDetails) {
		if (address.isPresent()) {
			addressDetails.add(address.get());
		}
	}

	@SuppressWarnings("unchecked")
	private List<ConsumerAddress> getAddressList(JSONObject cibil) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "Start getAddressList ");
		List<ConsumerAddress> consuemrAddresses = new ArrayList<>();
		if (null != cibil && null != cibil.get(CreditBusinessConstants.FIRST_CIBIL_RECORD)) {
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
					"Start getAddressList - cibil record Exist ");
			JSONObject firstCibilRecord = CreditBusinessHelper
					.getJSONObject(cibil.get(CreditBusinessConstants.FIRST_CIBIL_RECORD));
			if (null != firstCibilRecord.get(CreditBusinessConstants.CIBIL_RESPONSE)) {
				JSONObject cibilResponse = CreditBusinessHelper
						.getJSONObject(firstCibilRecord.get(CreditBusinessConstants.CIBIL_RESPONSE));
				List<Map<String, Object>> consuemrAddress = (List<Map<String, Object>>) cibilResponse
						.get(CreditBusinessConstants.CONSUMER_ADDRESS);
				consuemrAddresses = consuemrAddress.stream()
						.filter(address -> (CreditBusinessConstants.CIBIL_RESIDENCE_ADDRESS_CATEGORY_CODE
								.equals(address.get(CreditBusinessConstants.CIBIL_ADDRESS_CATEGORY))
								|| CreditBusinessConstants.CIBIL_OFFCIE_ADDRESS_CATEGORY_CODE
										.equals(address.get(CreditBusinessConstants.CIBIL_ADDRESS_CATEGORY)))
								&& !StringUtils
										.isBlank(address.get(CreditBusinessConstants.CIBIL_ADDRESSLINE1).toString()))
						.map(addr -> {
							try {
								return populateConsumerAddress(addr);
							} catch (ParseException exception) {
								logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
										"populateConsumerAddress - Exception occured in formatting dateReported");
								logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
										"populateConsumerAddress - Exception occured in formatting date ", exception);
								throw new CreditBusinessException(exception);
							}
						}).collect(Collectors.toList());
				logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
						"Consumer address list is " + consuemrAddresses);
			}
		} else {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
					"Consumer address list is null");
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER, "Start getAddressList ");
		return consuemrAddresses;
	}

	private ConsumerAddress populateConsumerAddress(Map<String, Object> address) throws ParseException {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start populateConsumerAddress ");
		ConsumerAddress consumerAddress = new ConsumerAddress();
		consumerAddress.setAddressCategory(address.get("addressCategory").toString());
		if (!StringUtils.isBlank((String) address.get("addressLine1"))
				|| !StringUtils.isBlank((String) address.get("addressLine2"))
				|| !StringUtils.isBlank((String) address.get("addressLine3"))) {
			consumerAddress.setAddressLine1(String.join(" ", address.get("addressLine1").toString(),
					address.get("addressLine2").toString(), address.get("addressLine3").toString()));
		}
		consumerAddress.setPinCode(address.get("pinCode").toString());
		if (!StringUtils.isBlank((String) address.get(CreditBusinessConstants.CIBIL_DATE_REPORTED))) {
			String dateReported = (String) address.get(CreditBusinessConstants.CIBIL_DATE_REPORTED);
			consumerAddress.setDateReported(DateUtils.parseDate(dateReported, "ddMMyyyy"));
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End populateConsumerAddress ");
		return consumerAddress;
	}

	private Optional<Address> getResidenceAddress(List<ConsumerAddress> addresses) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start getResidenceAddressSortedByDateReported");
		Optional<Address> residenceAddress = addresses.stream()
				.filter(address -> (CreditBusinessConstants.CIBIL_RESIDENCE_ADDRESS_CATEGORY_CODE
						.equals(address.getAddressCategory())))
				.sorted(Comparator.comparing(ConsumerAddress::getDateReported,
						Comparator.nullsLast(Comparator.reverseOrder())))
				.map(addr -> {
					return populateAddress(addr);
				}).findFirst();
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End getResidenceAddressSortedByDateReported");
		return residenceAddress;
	}

	private Address populateAddress(ConsumerAddress address) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start populateAddress for address: " + address);
		Address addressEntity = new Address();
		addressEntity.setPincode(address.getPinCode());
		LocationAddressBean locationAddressBean = apiCallHelper.getPinCodeMasterByPinCode(address.getPinCode());
		if (null != locationAddressBean) {
			addressEntity.setPincodeKey(locationAddressBean.getPinId().toString());
			addressEntity.setCityKey(locationAddressBean.getCityId().toString());
			addressEntity.setStateKey(locationAddressBean.getStateId().toString());
			addressEntity.setCountryKey(locationAddressBean.getCountryId().toString());
		}
		mapAddressLines(address, addressEntity, locationAddressBean);
		if (address.getAddressCategory().equals(CreditBusinessConstants.CIBIL_RESIDENCE_ADDRESS_CATEGORY_CODE)) {
			addressEntity.setAddressTypeKey(masterDataRedisClientHelper
					.getAddressTypeKeyForCode(CreditBusinessConstants.CURRENT_ADDR).toString());
			addressEntity.setAddressSource(CreditBusinessConstants.CIBIL_ADDRESS_SOURCE);
		} else {
			addressEntity.setAddressTypeKey(masterDataRedisClientHelper
					.getAddressTypeKeyForCode(CreditBusinessConstants.OFFICE_ADDR).toString());
			addressEntity.setAddressSource(CreditBusinessConstants.SOURCE_JOURNEY);
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End populateAddress with address: " + addressEntity);
		return addressEntity;
	}

	private Optional<Address> getOfficeAddress(List<ConsumerAddress> addresses) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start getOfficeAddressSortedByDateReported");
		Optional<Address> officeAddress = addresses.stream()
				.filter(address -> (CreditBusinessConstants.CIBIL_OFFCIE_ADDRESS_CATEGORY_CODE
						.equals(address.getAddressCategory())))
				.sorted(Comparator.comparing(ConsumerAddress::getDateReported,
						Comparator.nullsLast(Comparator.reverseOrder())))
				.map(address -> {
					return populateAddress(address);
				}).findFirst();
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End getOfficeAddressSortedByDateReported");
		return officeAddress;
	}

	public void callAddressUpdateApi(DelegateExecution execution, List<Address> addressDetails) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"Start callAddressUpdateApi for applicationkey:"
						+ execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
		if (!CollectionUtils.isEmpty(addressDetails)) {
			Map<String, String> params = new HashMap<>();
			params.put("applicationid", execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
			params.put("userattributekey",
					execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
			for (Address adrs : addressDetails) {
				String addressStr = CreditBusinessHelper.objectToJson(adrs);
				apiCallHelper.callApi(env.getProperty("api.omcreditapplicationservice.address.PUT.url"), HttpMethod.PUT,
						params, CreditBusinessHelper.objectToJson(addressStr), Object.class);
			}
		}
		logger.info(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End callAddressUpdateApi for applicationkey:"
						+ execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
	}

	private boolean checkOfficeAddressExist(DelegateExecution execution) {
		boolean officeAddressExist = false;
		try {
			logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
					"Start checkOfficeAddressExist for applicationKey:"
							+ execution.getVariable(CreditBusinessConstants.APPLICATION_ID));
			String officeTypeKey = masterDataRedisClientHelper
					.getAddressTypeKeyForCode(CreditBusinessConstants.OFFICE_ADDR).toString();
			Map<String, String> params = new HashMap<String, String>();
			params.put("applicationid", execution.getVariable(CreditBusinessConstants.APPLICATION_ID).toString());
			params.put("userattributekey",
					execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY).toString());
			params.put("typeKey", officeTypeKey);
			Address officeAddress = apiCallHelper.getAddress(new HttpHeaders(), params);
			if (null != officeAddress) {
				officeAddressExist = true;
			}
		} catch (Exception ex) {
			logger.error(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
					"End checkOfficeAddressExist Exception in calling address endpoint for offcie address appliationId :"
							+ execution.getVariable(CreditBusinessConstants.APPLICATION_ID),
					ex);
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End checkOfficeAddressExist officeAddressExist :" + officeAddressExist);
		return officeAddressExist;
	}

	private void mapAddressLines(ConsumerAddress addrress, Address addressEntity,
			LocationAddressBean locationAddressBean) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"start mapAddressLines for address :" + addrress);
		String address = StringUtils.normalizeSpace(
				addrress.getAddressLine1().replaceAll(CreditBusinessConstants.ADDRESS_SPECIAL_CHAR_SKIP, ""));
		Map<String, String> inputMap = new HashMap<>();
		inputMap.put(ADD_LENGTH + 1, "50");
		inputMap.put(ADD_LENGTH + 2, "50");
		inputMap.put(ADD_MIN_LENGTH + 1, "5");
		inputMap.put(ADD_MIN_LENGTH + 2, "5");
		Map<String, String> splitAddressLine = new HashMap<>();
		if (address.length() <= 50) {
			String[] addWordArray = address.split(" ");
			splitAddressLine = splitAddressMinVal(addWordArray, address.length(), inputMap);
		} else {
			splitAddressLine = splitAddressLine(address, 1, inputMap);
		}
		addressEntity.setAddressLine1(
				null != splitAddressLine.get(ADD_LINE + 1) ? splitAddressLine.get(ADD_LINE + 1) : null);
		addressEntity.setAddressLine2(
				null != splitAddressLine.get(ADD_LINE + 2) ? splitAddressLine.get(ADD_LINE + 2) : null);
		if ((StringUtils.isEmpty(addressEntity.getAddressLine2()) || addressEntity.getAddressLine2().length() <= 5)
				&& null != locationAddressBean) {
			String addressLine2 = String.join(" ",
					null != addressEntity.getAddressLine2() ? addressEntity.getAddressLine2() : " ",
					locationAddressBean.getCity(), locationAddressBean.getState());
			addressEntity.setAddressLine2(StringUtils.normalizeSpace(addressLine2));
		}
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"End mapAddressLines with address entity :" + addressEntity);
	}

	private Map<String, String> splitAddressLine(String combinedAddLines, int counter, Map<String, String> paramMap) {
		if (0 != combinedAddLines.length()) {
			combinedAddLines = combinedAddLines.replaceAll(CreditBusinessConstants.ADDRESS_SPECIAL_CHAR_SKIP, "")
					.trim();
			String add = "";
			String space = " ";
			if (counter != 2 && combinedAddLines.contains(space) && null != paramMap.get(ADD_LENGTH + counter)) {
				add = combinedAddLines.substring(0, Math.min(Integer.parseInt(paramMap.get(ADD_LENGTH + counter)),
						combinedAddLines.lastIndexOf(space)));
			} else if (null != paramMap.get(ADD_LENGTH + counter)) {
				add = combinedAddLines.substring(0,
						Math.min(Integer.parseInt(paramMap.get(ADD_LENGTH + counter)), combinedAddLines.length()));
			} else {
				return null;
			}
			if (counter != 2 && add.contains(space) && null != paramMap.get(ADD_LENGTH + counter)) {
				add = combinedAddLines.substring(0,
						Math.min(Integer.parseInt(paramMap.get(ADD_LENGTH + counter)), add.lastIndexOf(space)));
			} else if (null != paramMap.get(ADD_LENGTH + counter)) {
				add = combinedAddLines.substring(0,
						Math.min(Integer.parseInt(paramMap.get(ADD_LENGTH + counter)), add.length()));
			}
			int addLength = add.length();
			String replacedString = combinedAddLines.substring(addLength, combinedAddLines.length());
			paramMap.put(ADD_LINE + counter++, add.trim());
			splitAddressLine(replacedString.trim(), counter, paramMap);
		}
		return paramMap;
	}

	private Map<String, String> splitAddressMinVal(String[] addWordArray, int addressLength,
			Map<String, String> inputMap) {
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"splitAddressMinVal Started");
		Map<String, String> paramMap = new HashMap<>();
		String finalString = "";
		int counter = 1;
		int addressLengthPerLine = addressLength / 2;
		for (String string : addWordArray) {
			if (finalString.length() < Math.max(addressLengthPerLine,
					Integer.parseInt(inputMap.get(ADD_MIN_LENGTH + counter)))) {
				finalString = finalString + " " + string;
			} else if (finalString.length() >= Integer.parseInt(inputMap.get(ADD_MIN_LENGTH + counter))) {
				paramMap.put(ADD_LINE + counter, finalString.trim());
				finalString = string;
				counter++;
			}
		}
		paramMap.put(ADD_LINE + counter, finalString);
		logger.debug(this.getClass().getCanonicalName(), BFLLoggerComponent.WORKFLOW_LISTENER,
				"splitAddressMinVal  End");
		return paramMap;
	}
}
