package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class ApltBusinessDet implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long apltBusiDetKey;

	private BigDecimal businessVintage;

	private BigDecimal constitution;

	private String gstIn;

	private BigDecimal isActive;

	private String lstUpdatedBy;

	private Timestamp lstUpdateDt;

	private Long nobKey;

	private Long applicantKey;

	private Long subIndMastKey;

	private Long custIndMastKey;

	public ApltBusinessDet() {
	}

	public Long getApltBusiDetKey() {
		return apltBusiDetKey;
	}

	public void setApltBusiDetKey(Long apltBusiDetKey) {
		this.apltBusiDetKey = apltBusiDetKey;
	}

	public BigDecimal getBusinessVintage() {
		return businessVintage;
	}

	public void setBusinessVintage(BigDecimal businessVintage) {
		this.businessVintage = businessVintage;
	}

	public BigDecimal getConstitution() {
		return constitution;
	}

	public void setConstitution(BigDecimal constitution) {
		this.constitution = constitution;
	}

	public String getGstIn() {
		return gstIn;
	}

	public void setGstIn(String gstIn) {
		this.gstIn = gstIn;
	}

	public BigDecimal getIsActive() {
		return isActive;
	}

	public void setIsActive(BigDecimal isActive) {
		this.isActive = isActive;
	}

	public String getLstUpdatedBy() {
		return lstUpdatedBy;
	}

	public void setLstUpdatedBy(String lstUpdatedBy) {
		this.lstUpdatedBy = lstUpdatedBy;
	}

	public Timestamp getLstUpdateDt() {
		return lstUpdateDt;
	}

	public void setLstUpdateDt(Timestamp lstUpdateDt) {
		this.lstUpdateDt = lstUpdateDt;
	}

	public Long getNobKey() {
		return nobKey;
	}

	public void setNobKey(Long nobKey) {
		this.nobKey = nobKey;
	}

	public Long getApplicantKey() {
		return applicantKey;
	}

	public void setApplicantKey(Long applicantKey) {
		this.applicantKey = applicantKey;
	}

	public Long getSubIndMastKey() {
		return subIndMastKey;
	}

	public void setSubIndMastKey(Long subIndMastKey) {
		this.subIndMastKey = subIndMastKey;
	}

	public Long getCustIndMastKey() {
		return custIndMastKey;
	}

	public void setCustIndMastKey(Long custIndMastKey) {
		this.custIndMastKey = custIndMastKey;
	}
}