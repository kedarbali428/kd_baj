package com.bajaj.markets.credit.business.helper;

/**
 * Enum to represent Principal types.
 * 
 */
public enum PrincipalTypeEnum {

	BFL("bfl"), AXIS("axis"), RBL("rbl"), BHFL("bhfl"), CASHE("cashe"), HDFC("hdfc"), EARLYSALARY("earlysalary"), DEFAULT("default");

	private final String value;

	private PrincipalTypeEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}
}
