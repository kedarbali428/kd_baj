package com.bajaj.markets.credit.business.helper;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PRODUCT_CODE_OMPL;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.EmployerMasterBean;
import com.bajaj.markets.credit.business.beans.PanDetails;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CreditBusinessGinHelper {

	private static final String PRINCIAL_SELECTEDBY_CUSTOMER_DETAIL = "princialSelectedbyCustomerDetail";

	private static final String PRINCIAL_SELECTEDBY_CUSTOMER = "princialSelectedByCustomer";

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	CustomDefaultHeaders customHeaders;

	@Autowired
	MasterDataRedisClientHelper masterDataRedisHelper;

	@Autowired
	CreditBusinessApiCallsHelper apiCallsHelper;

	@Autowired
	CreditBusinessHelper helper;

	ObjectMapper mapper = new ObjectMapper();

	@Value("${etb.nongin.flow.riskoffertypes}")
	private String nonGinRiskOfferTypes;

	@Value("${etb.nongin.allow.designation.riskoffertypes}")
	private String etbNonGinAllowDesignationRiskofferTypes;

	@Value("${etb.gin.allow.employer.riskoffertypes}")
	private String etbGinAllowEmployerRiskofferTypes;	


	private static final String CLASS_NAME = CreditBusinessGinHelper.class.getCanonicalName();

	@SuppressWarnings("unchecked")
	public void prepareBreRequestForGinFlow(JSONObject openArcCardListingInput, JSONObject mcpRequest, Double reqLoanAmount, Double reqTenure,
			Integer isSmallTicket) throws Exception {
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Into prepareBreRequestForGinFlow started");
		if (mcpRequest != null && openArcCardListingInput != null) {
			openArcCardListingInput.put("obligationAmount", mcpRequest.get("obligationAmount"));
			openArcCardListingInput.put("creditObligation", mcpRequest.get("creditObligation"));
			openArcCardListingInput.put("subStagePercentage", mcpRequest.get("subStagePercentage"));
			openArcCardListingInput.put("approvedFlag", mcpRequest.get("approvedFlag"));
			openArcCardListingInput.put("bmr1ApprovedFlag", mcpRequest.get("bmr1ApprovedFlag"));
			openArcCardListingInput.put("bmr2ApprovedFlag", mcpRequest.get("bmr2ApprovedFlag"));
	
			if (mcpRequest.get("prodCategory") != null) {
				Map<String, Object> productCategory = (Map<String, Object>) mcpRequest.get("prodCategory");
				Object productDesc = productCategory != null ? productCategory.get("prodCatDesc") : null;
				openArcCardListingInput.put("product", productDesc);
			}

			Map<String, Object> userProfile = (Map<String, Object>) mcpRequest.get("userProfile");
			if (userProfile != null) {
				openArcCardListingInput.put("personalPAN",
						null != userProfile.get(CreditBusinessConstants.PAN_NUMBER) ? userProfile.get(CreditBusinessConstants.PAN_NUMBER).toString() : null);

				if (userProfile.get("applicationKey") != null && userProfile.get("applicantKey") != null) {
					Long applicationKey = Double.valueOf(userProfile.get("applicationKey").toString()).longValue();
					Long applicantKey = Double.valueOf(userProfile.get("applicantKey").toString()).longValue();
					JSONObject nsdlPanResponse = apiCallsHelper.getPanVerification(applicationKey, applicantKey);
					if (nsdlPanResponse != null) {
						logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Response From Pan Verifcation for : " + applicationKey + ":" + nsdlPanResponse);
						List<PanDetails> panDetailsList = new ArrayList<PanDetails>();
						PanDetails panDetails = new PanDetails();
						panDetails.setNameMatch(nsdlPanResponse.get("nameMatch") != null ? nsdlPanResponse.get("nameMatch").toString() : null);
						panDetails.setMatchScore(null);
						panDetails.setPanType(null);
						panDetails.setPanStatus(nsdlPanResponse.get("panStatus") != null ? nsdlPanResponse.get("panStatus").toString() : null);
						panDetailsList.add(panDetails);
						openArcCardListingInput.put("panDetails", panDetailsList);
					}
				}

				if (userProfile.get("dateOfBirth") != null) {
					String dob = (String) userProfile.get("dateOfBirth");
					openArcCardListingInput.put("DOB", dob);
					Integer age = CreditBusinessHelper.calculateAge(dob);
					openArcCardListingInput.put("age", age);
				}

				if (userProfile.get("genderKey") != null) {
					Double genderKey = Double.valueOf(userProfile.get("genderKey").toString());
					String gender = masterDataRedisHelper.getGenderByTypeKey(genderKey.longValue());
					openArcCardListingInput.put("gender", gender);
				}

				if (userProfile.get("residenceTypeKey") != null) {
					Double resiTypeKey = Double.valueOf(userProfile.get("residenceTypeKey").toString());
					ResidenceMaster resiType = masterDataRedisHelper.findResitypeByKey(resiTypeKey.longValue());
					openArcCardListingInput.put("resiType", resiType.getResidenceValue());
				}
			}
		}

		Map<String, Object> occupation = (Map<String, Object>) mcpRequest.get("occupation");
		if (occupation != null && occupation.get("salariedDetail") != null) {
			Map<String, Object> salariedDet = (Map<String, Object>) occupation.get("salariedDetail");
			openArcCardListingInput.put("workExperience", salariedDet.get("experience"));

			if (salariedDet.get("employerName") != null) {
				JSONObject employer = CreditBusinessHelper.getJSONObject(salariedDet.get("employerName"));
				if (employer.get(CreditBusinessConstants.KEY) != null) {
					Long employerId = Double.valueOf(employer.get(CreditBusinessConstants.KEY).toString()).longValue();
					EmployerMasterBean employerMaster = masterDataRedisHelper.getEmployerByKey(employerId.longValue());
					if (employerMaster != null) {
						openArcCardListingInput.put("employerType", employerMaster.getEmprMastCategory());
						openArcCardListingInput.put("companyCategory", employerMaster.getEmprMastSubcategory());
					}
				}
			}

			if (mcpRequest.get("mcpAddressDetails") != null) {
				List<Map<String, Object>> mcpAddressDetails = (List<Map<String, Object>>) mcpRequest.get("mcpAddressDetails");
				if (mcpAddressDetails != null && mcpAddressDetails.get(0) != null) {
					List<Map<String, Object>> principleProductDetailsArr = (List<Map<String, Object>>) mcpAddressDetails.get(0).get("principleProductDetails");
					openArcCardListingInput.put("principleProductDetails", principleProductDetailsArr);
				}
			}

			openArcCardListingInput.put("estimatedNetMonthlySalaryDetails", mcpRequest.get("estimatedNetMonthlySalaryDetails"));
			if (mcpRequest.get(PRINCIAL_SELECTEDBY_CUSTOMER_DETAIL) != null) {
				List<?> prinicpleSelectedList = (List<?>) mcpRequest.get(PRINCIAL_SELECTEDBY_CUSTOMER_DETAIL);
				openArcCardListingInput.put(PRINCIAL_SELECTEDBY_CUSTOMER, prinicpleSelectedList.isEmpty() ? null : prinicpleSelectedList.get(0));
			}

			if (mcpRequest.get("appScoreDetails") != null) {
				JSONObject appScore = CreditBusinessHelper.getJSONObject(mcpRequest.get("appScoreDetails"));
				openArcCardListingInput.put(CreditBusinessConstants.APP_SCORE,
						appScore.get("finalScore") != null ? Double.valueOf(appScore.get("finalScore").toString()) : null);
				openArcCardListingInput.put("appScoreLR", appScore.get("lrScore") != null ? Double.valueOf(appScore.get("lrScore").toString()) : null);
				openArcCardListingInput.put("appScoreML", appScore.get("mlScore") != null ? Double.valueOf(appScore.get("mlScore").toString()) : null);
				openArcCardListingInput.put("appScoreLRV2", appScore.get("lrScorev2") != null ? Double.valueOf(appScore.get("lrScorev2").toString()) : null);
			}

			openArcCardListingInput.put("coApplicantIncome",
					null != mcpRequest.get("coApplicantIncome") ? Double.valueOf(mcpRequest.get("coApplicantIncome").toString()) : 0);
			openArcCardListingInput.put("coApplicantObligation",
					null != mcpRequest.get("coapplicantObligation") ? Double.valueOf(mcpRequest.get("coapplicantObligation").toString()) : 0);
		}

		if (openArcCardListingInput.get("applicationId") != null) {
			String applicationId = openArcCardListingInput.get("applicationId").toString();
			openArcCardListingInput.put("requiredProductList", helper.getRequiredLoanAmtAndTenure(applicationId, mcpRequest, isSmallTicket));
		}

		if (mcpRequest.get("addressList") != null) {
			List<Map<String, Object>> addressList = (List<Map<String, Object>>) mcpRequest.get("addressList");
			if (!CollectionUtils.isEmpty(addressList)) {
				Map<String, Object> address = addressList.get(0);
				if (address.get("pincodeKey") != null) {
					Double pincodeKey = Double.valueOf(address.get("pincodeKey").toString());
					com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean locationAddressBean = masterDataRedisHelper
							.getPinCodeByKey(pincodeKey.longValue());
					openArcCardListingInput.put("pincode", locationAddressBean.getPincode());
					openArcCardListingInput.put("city", locationAddressBean.getCityName());
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.UTILITY, "Into prepareBreRequestForGinFlow completed");
	}

	public boolean checkIsEtbOffer(String riskOfferTyype) {
		if (!StringUtils.isEmpty(riskOfferTyype)) {
			List<String> nonGinRiskOfferTypeList = Arrays.asList(nonGinRiskOfferTypes.split(","));
			if (nonGinRiskOfferTypeList.contains(riskOfferTyype)) {
				return true;
			} 
		}
		return false; 
	}

	public EtbVariantEnum checkEtbVariantFromAppOfferDet(String applicationId, Long occupationKey, String l2ProductCode) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "into checkEtbVariantFromAppOfferDet ");
		if (1 == occupationKey && PRODUCT_CODE_OMPL.equalsIgnoreCase(l2ProductCode)) {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			List<AppOfferDetBean> offerList = apiCallsHelper.fetchOffers(applicationId, null, headers);
			if (!CollectionUtils.isEmpty(offerList)) {
				List<String> nonGinRiskOfferTypeList = Arrays.asList(nonGinRiskOfferTypes.split(","));

				AppOfferDetBean appOffer = offerList.stream().filter(o -> o.getRiskOfferType() != null && o.getOfferPriority() != null)
						.sorted(Comparator.comparing(AppOfferDetBean::getOfferPriority)).findFirst().orElse(null);

				if (null!=appOffer && nonGinRiskOfferTypeList.contains(appOffer.getRiskOfferType())) {
					logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
							"RiskOfferType from AppOfferDet for application " + applicationId + " is = " + appOffer.getRiskOfferType());
						logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
								"Completed checkEtbVariantFromAppOfferDet : RiskOfferType for application " + applicationId + " is valid for ETB NON-GIN");
						return EtbVariantEnum.NONGIN;
				}
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Completed checkEtbVariantFromAppOfferDet No ETB riskOfferType applicable for application " + applicationId);
		return null;
	}

	public boolean checkAllowDesignationForEtbNonGin(String riskOfferType) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside checkAllowDesignationForEtbNonGin :: Configured RiskOfferTypes = " + etbNonGinAllowDesignationRiskofferTypes);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "RiskOfferType of Application = " + riskOfferType);
		List<String> ginRiskOfferTypeList = Arrays.asList(etbNonGinAllowDesignationRiskofferTypes.split(","));
		if (riskOfferType != null && !CollectionUtils.isEmpty(ginRiskOfferTypeList)) {
			return ginRiskOfferTypeList.contains(riskOfferType);
		}
		return false;
	}

	public boolean checkIsNonGinRiskOffer(String riskOfferType) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "inside checkIsNonGinRiskOffer :: Configured RiskOfferTypes for GIN flow " + nonGinRiskOfferTypes);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "RiskOfferType of Application = " + riskOfferType);
		List<String> ginRiskOfferTypeList = Arrays.asList(nonGinRiskOfferTypes.split(","));
		if (riskOfferType != null && !CollectionUtils.isEmpty(ginRiskOfferTypeList)) {
			return ginRiskOfferTypeList.contains(riskOfferType);
		}
		return false;
	}

	public boolean checkAllowEmployerForEtbGin(String riskOfferType) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE,
				"Inside checkAllowEmployerForEtbGin :: Configured RiskOfferTypes = " + etbGinAllowEmployerRiskofferTypes);
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "RiskOfferType of Application = " + riskOfferType);
		List<String> ginRiskOfferTypeList = Arrays.asList(etbGinAllowEmployerRiskofferTypes.split(","));
		if (riskOfferType != null && !CollectionUtils.isEmpty(ginRiskOfferTypeList)) {
			return ginRiskOfferTypeList.contains(riskOfferType);
		}
		return false;
	}
	
	public Boolean checkIsEtbCustomer(String applicationId) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Fetching PrincipalCustInfo for application : " + applicationId);
		try {
			JSONObject principalCustInfo = apiCallsHelper.getPrincipalCustInfo(applicationId, "3");
			if(principalCustInfo != null && principalCustInfo.get("isEtb") != null) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "PrincipalCustInfo found");
				return (Boolean) principalCustInfo.get("isEtb");
			}
		} catch (CreditBusinessException e) {
			if (e.getCode().equals(HttpStatus.NOT_FOUND)) {
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "PrincipalCustInfo not present for application  occured : " + applicationId);
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.SERVICE, "Exception while fetiching PrincipalCustInfo  ", e);
				throw e;
			}
		}
		return null;
	}	

}
