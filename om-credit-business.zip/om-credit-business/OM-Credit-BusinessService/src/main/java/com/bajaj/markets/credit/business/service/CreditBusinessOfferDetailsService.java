package com.bajaj.markets.credit.business.service;

public interface CreditBusinessOfferDetailsService {

	public Object getOfferAmount(String applicationId, String productCode);
}
