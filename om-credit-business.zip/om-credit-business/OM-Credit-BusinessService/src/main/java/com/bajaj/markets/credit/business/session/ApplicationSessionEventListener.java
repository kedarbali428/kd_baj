package com.bajaj.markets.credit.business.session;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.session.FindByIndexNameSessionRepository;
import org.springframework.session.Session;
import org.springframework.session.events.SessionCreatedEvent;
import org.springframework.session.events.SessionExpiredEvent;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.CustomRequestScopeAttribute;
import com.bajaj.markets.credit.business.beans.SessionInfo;
import com.bajaj.markets.credit.business.processor.DiallerIntegrationProcessor;

@Component
@ConditionalOnProperty(value = "spring.session.enabled", havingValue = "true", matchIfMissing = false)
public class ApplicationSessionEventListener {

	private static final SessionInfo LEAD_PUSH_DEFAULT_SESSION_INFO = new SessionInfo();

	private static final String UNDEFINED = "undefined|";

	private static final String CLASS_NAME = ApplicationSessionEventListener.class.getCanonicalName();

	@Autowired
	private SessionRegistry sessionRegistry;

	@Autowired
	private DiallerIntegrationProcessor diallerIntegrationProcessor;

	@Autowired
	@Qualifier("redisTemplate")
	private RedisTemplate<String, SessionInfo> redisTemplate;
	
	@Autowired
	private Environment env;
	
	@Value("${application.dialer.leadpush.eventraise.locktime}")
	private String leadpushTimeout;

	@SuppressWarnings("deprecation")
	@EventListener
	public void sessionCreated(SessionCreatedEvent event) {
		String correlationId = UNDEFINED + event.getSessionId();
		BFLLoggerUtil.debug(correlationId, CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Session Created Event triggered " + event.getSessionId());
		SessionInformation sessionInformation = sessionRegistry.getSessionInformation(event.getSessionId());
		if (null != sessionInformation)
			BFLLoggerUtil.debug(correlationId, CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Principle Information " + sessionInformation.getPrincipal());

	}

	@SuppressWarnings("deprecation")
	@EventListener
	public void sessionExpired(SessionExpiredEvent event) {
		String correlationId = UNDEFINED + event.getSessionId();

		BFLLoggerUtil.debug(correlationId, CLASS_NAME, BFLLoggerComponent.UTILITY,
				"Session Expiry Event triggered " + event.getSessionId());
		Session session = event.getSession();
		
		boolean proceed = redisTemplate.opsForValue().setIfAbsent("leadpush" + event.getSessionId(),
				LEAD_PUSH_DEFAULT_SESSION_INFO, Duration.ofMinutes(2L));
		if(proceed) {
			BFLLoggerUtil.debug(correlationId, CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Lead payload preparation started by this thread");
			SessionInformation sessionInformation = sessionRegistry.getSessionInformation(event.getSessionId());
			if (null != sessionInformation)
				BFLLoggerUtil.debug(correlationId, CLASS_NAME, BFLLoggerComponent.UTILITY,
						"Principle Information " + sessionInformation.getPrincipal());

			if (null != session.getAttribute(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME)) {
				String applicationId = (String) session
						.getAttribute(FindByIndexNameSessionRepository.PRINCIPAL_NAME_INDEX_NAME);
				BFLLoggerUtil.debug(correlationId, CLASS_NAME, BFLLoggerComponent.UTILITY,
						"From session applicationId = " + applicationId);
				setCustomerHeader(UNDEFINED + applicationId);
				SessionInfo redisAdditionalInfo = redisTemplate.opsForValue().get(event.getSessionId());
				if (null != redisAdditionalInfo && "employee".equals(redisAdditionalInfo.getRole())
						&& !env.getProperty("enableDialerLeadPushForEmployee", boolean.class)) {
					BFLLoggerUtil.debug(correlationId, CLASS_NAME, BFLLoggerComponent.UTILITY,
							"Current session belongs to employee, but enableDialerLeadPushForEmployee is false so will not push lead ");
				} else {
					boolean dialerPushApplicationLevelLock = redisTemplate.opsForValue().setIfAbsent("leadpush" + applicationId,
							LEAD_PUSH_DEFAULT_SESSION_INFO, Duration.ofMinutes(Long.parseLong(leadpushTimeout)));
					if (dialerPushApplicationLevelLock) {
						diallerIntegrationProcessor.pushLead(applicationId);
					}
				}
			} else {
				BFLLoggerUtil.debug(correlationId, CLASS_NAME, BFLLoggerComponent.UTILITY,
						"PRINCIPAL_NAME_INDEX_NAME is empty");
			}
		}else {
			BFLLoggerUtil.debug(correlationId, CLASS_NAME, BFLLoggerComponent.UTILITY,
					"Lead payload preparation started by another thread");
		}
	}

	private void setCustomerHeader(String correlationId) {
		CustomDefaultHeaders defaultHeaders = new CustomDefaultHeaders();
		defaultHeaders.setCmptcorrid(correlationId);
		CustomRequestScopeAttribute custAttribute = new CustomRequestScopeAttribute();
		custAttribute.setAttribute("scopedTarget.customDefaultHeaders", defaultHeaders,
				RequestAttributes.SCOPE_REQUEST);
		RequestContextHolder.setRequestAttributes(custAttribute, true);
	}

}