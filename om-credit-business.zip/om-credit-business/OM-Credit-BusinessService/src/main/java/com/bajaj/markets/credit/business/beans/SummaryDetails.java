package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

public class SummaryDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@NotBlank
	private String action;
	
	
	
	private NextTask nextTask;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "SummaryDetails [action=" + action + "]";
	}

	public NextTask getNextTask() {
		return nextTask;
	}

	public void setNextTask(NextTask nextTask) {
		this.nextTask = nextTask;
	}
}
