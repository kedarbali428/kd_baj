package com.bajaj.markets.credit.business.helper;

/**
 * Enum to map string representation of email type with its key value
 * 
 * @author 764504
 *
 */
public enum EmailTypeEnum {

	PERON1(70L), OFFICE(67L),OTHER(68L);

	private final Long value;

	private EmailTypeEnum(Long value) {
		this.value = value;
	}

	public Long getValue() {
		return this.value;
	}

}
