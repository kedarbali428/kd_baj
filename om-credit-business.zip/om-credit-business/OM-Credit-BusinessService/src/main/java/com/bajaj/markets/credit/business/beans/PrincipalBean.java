package com.bajaj.markets.credit.business.beans;

public class PrincipalBean {
	private Long principlekey;

	private String principleCode;

	private String principleName;

	public Long getPrinciplekey() {
		return principlekey;
	}

	public void setPrinciplekey(Long principlekey) {
		this.principlekey = principlekey;
	}

	public String getPrincipleCode() {
		return principleCode;
	}

	public void setPrincipleCode(String principleCode) {
		this.principleCode = principleCode;
	}

	public String getPrincipleName() {
		return principleName;
	}

	public void setPrincipleName(String principleName) {
		this.principleName = principleName;
	}

}
