package com.bajaj.markets.credit.business.beans;

import java.io.Serializable;
import java.util.Objects;

public class Address implements Serializable {
	private static final long serialVersionUID = 1L;
	
//	@NotBlank(message = "addressTypeKey can not be null")
	private String addressKey;
	private String addressTypeKey;
	private String resiType;
	private String addressLine1;
	private String addressLine2;
//	@NotBlank(message = "pincode can not be null")
	private String pincode;
//	@NotBlank(message = "pincodeKey can not be null")
	private String pincodeKey;
	private String cityKey;
	private String stateKey;
	private String countryKey;
	private Verification verification;
	private String addressSource;
	private String numberOfMonths;
	private String localitykey;
	private String cityName;
	private Boolean preferredFlag;
	private LocationResponseBean pinCodeBean;
	
	public String getAddressKey() {
		return addressKey;
	}

	public void setAddressKey(String addressKey) {
		this.addressKey = addressKey;
	}

	public String getAddressTypeKey() {
		return addressTypeKey;
	}

	public void setAddressTypeKey(String addressTypeKey) {
		this.addressTypeKey = addressTypeKey;
	}

	public String getResiType() {
		return resiType;
	}

	public void setResiType(String resiType) {
		this.resiType = resiType;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getPincodeKey() {
		return pincodeKey;
	}

	public void setPincodeKey(String pincodeKey) {
		this.pincodeKey = pincodeKey;
	}

	public String getCityKey() {
		return cityKey;
	}

	public void setCityKey(String cityKey) {
		this.cityKey = cityKey;
	}

	public String getStateKey() {
		return stateKey;
	}

	public void setStateKey(String stateKey) {
		this.stateKey = stateKey;
	}

	public String getCountryKey() {
		return countryKey;
	}

	public void setCountryKey(String countryKey) {
		this.countryKey = countryKey;
	}

	public Verification getVerification() {
		return verification;
	}

	public void setVerification(Verification verification) {
		this.verification = verification;
	}

	public String getAddressSource() {
		return addressSource;
	}

	public void setAddressSource(String addressSource) {
		this.addressSource = addressSource;
	}
	
	public String getNumberOfMonths() {
		return numberOfMonths;
	}

	public void setNumberOfMonths(String numberOfMonths) {
		this.numberOfMonths = numberOfMonths;
	}

	@Override
	public int hashCode() {
		return Objects.hash(addressLine1, addressLine2, pincode);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		return Objects.equals(addressLine1, other.addressLine1) && Objects.equals(addressLine2, other.addressLine2)
				&& Objects.equals(pincode, other.pincode);
	}

	public String getLocalitykey() {
		return localitykey;
	}

	public void setLocalitykey(String localitykey) {
		this.localitykey = localitykey;
	}
	
	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Boolean getPreferredFlag() {
		return preferredFlag;
	}

	public void setPreferredFlag(Boolean preferredFlag) {
		this.preferredFlag = preferredFlag;
	}

	public LocationResponseBean getPinCodeBean() {
		return pinCodeBean;
	}

	public void setPinCodeBean(LocationResponseBean pinCodeBean) {
		this.pinCodeBean = pinCodeBean;
	}

	@Override
	public String toString() {
		return "Address [addressKey=" + addressKey + ", addressTypeKey=" + addressTypeKey + ", resiType=" + resiType + ", addressLine1=" + addressLine1
				+ ", addressLine2=" + addressLine2 + ", pincode=" + pincode + ", pincodeKey=" + pincodeKey + ", cityKey=" + cityKey + ", stateKey=" + stateKey
				+ ", countryKey=" + countryKey + ", verification=" + verification + ", addressSource=" + addressSource + ", numberOfMonths=" + numberOfMonths
				+ ", localitykey=" + localitykey + ", cityName=" + cityName + ", preferredFlag=" + preferredFlag + ", pinCodeBean=" + pinCodeBean + "]";
	}
	
	
}