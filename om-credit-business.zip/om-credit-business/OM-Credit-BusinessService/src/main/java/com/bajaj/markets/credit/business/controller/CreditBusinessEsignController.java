package com.bajaj.markets.credit.business.controller;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.authentication.principal.Role;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.Esign;
import com.bajaj.markets.credit.business.beans.EsignRequest;
import com.bajaj.markets.credit.business.beans.EsignResponse;
import com.bajaj.markets.credit.business.beans.GenerateOTPResponseBean;
import com.bajaj.markets.credit.business.service.CreditBusinessEsignService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CreditBusinessEsignController {
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	CreditBusinessEsignService  creditBusinessEsignService;
	
	private static final String CLASS_NAME = CreditBusinessEsignController.class.getCanonicalName();
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.SYSTEM, Role.EMPLOYEE })
	@ApiOperation(value = "Create or update consolidated Esign doc into dms and stamp in db ", notes = "Create or update consolidated Esign doc into dms and stamp in db", httpMethod = "PUT")
	@ApiImplicitParams({
	  @ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header"),
	  @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string",paramType = "header") })
	@ApiResponses(value = {
					@ApiResponse(code = 200, message = "Esign created Successfully", response = EsignResponse.class),
					@ApiResponse(code = 404, message = "Error in esign document generation ",response = ErrorBean.class),
					@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
					@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
    @CrossOrigin
    @PutMapping(path = "${api.omcreditbusinessservice.esigndocument.PUT.uri}")
	//@PutMapping(value = "/v1/applications/{applicationKey}/esign",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> createDocument(@PathVariable("applicationKey") @NotBlank(message = "applicationKey cannot be null or empty") String  applicationKey ,
			 @RequestBody EsignRequest esignRequest,@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside createDocument method controller for applicationKey :" + applicationKey +"and esignRequest is "+esignRequest);
		return new ResponseEntity<>(creditBusinessEsignService.createDocument(applicationKey,esignRequest,headers), HttpStatus.OK);
	}

	
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.SYSTEM, Role.EMPLOYEE })
	@ApiOperation(value = "To get the status of the esign document ", notes = "To get the status of the esign application", httpMethod = "GET")
	@ApiImplicitParams({
	  @ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header"),
	  @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string",paramType = "header") })
	@ApiResponses(value = {
					@ApiResponse(code = 200, message = "Esign created Successfully", response = EsignResponse.class),
					@ApiResponse(code = 404, message = "Error in esign document generation ",response = ErrorBean.class),
					@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
					@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
    @CrossOrigin
    @GetMapping(path = "${api.omcreditbusinessservice.esignstatus.GET.uri}")
	//@PutMapping(value = "/v1/applications/{applicationKey}/esign",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> esignStatus(@PathVariable("applicationKey") @NotBlank(message = "applicationKey cannot be null or empty") String  applicationKey ,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside esignStatus method controller for applicationKey :" + applicationKey);
		return new ResponseEntity<>(creditBusinessEsignService.getDocumentStatus(applicationKey, headers),HttpStatus.OK);
	}
	
	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.SYSTEM, Role.EMPLOYEE })
	@ApiOperation(value = "To send OTP to customer for esign consent ", notes = "To send OTP to customer for esign consent ", httpMethod = "PUT")
	@ApiImplicitParams({
	  @ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header"),
	  @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  @ApiImplicitParam(name = "guardtoken", required = true, dataType = "string",paramType = "header") })
	@ApiResponses(value = {
					@ApiResponse(code = 200, message = "Esign created Successfully", response = GenerateOTPResponseBean.class),
					@ApiResponse(code = 404, message = "Error in esign document generation ",response = ErrorBean.class),
					@ApiResponse(code = 422, message = "Invalid input",response = ErrorBean.class),
					@ApiResponse(code = 500, message = "Some technical error occurred",response = ErrorBean.class)})
    @CrossOrigin
    @PutMapping(path = "${api.omcreditbusinessservice.esignconsent.PUT.uri}")
	//@PutMapping(value = "/v1/applications/{applicationKey}/esign",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> consentOTP(@PathVariable("applicationKey") @NotBlank(message = "applicationKey cannot be null or empty") String  applicationKey ,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside consentOTP method controller for applicationKey :" + applicationKey);
		return new ResponseEntity<>(creditBusinessEsignService.consentOTP(applicationKey, headers),HttpStatus.OK);
	}

	@Secured(value = {Role.PSEUDO_CUSTOMER, Role.PSEUDO_VERIFIED_CUSTOMER, Role.EMPLOYEE, Role.CUSTOMER})
	@ApiOperation(	value = "Complete Esign and Get the next user task", notes = "Complete Esign process, checks status of esign and gets the next user task", httpMethod = "POST")
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "authtoken", required = true, dataType = "string", paramType = "header"),
	  })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Succesfully Completed Esign", response = ApplicationResponse.class),
			@ApiResponse(code = 400, message = "bad input parameter", response = ErrorBean.class),
			@ApiResponse(code = 401, message = "unauthenticated", response = ErrorBean.class),
			@ApiResponse(code = 403, message = "unauthorized", response = ErrorBean.class),
			@ApiResponse(code = 422, message = "invalid input parameter", response = ErrorBean.class),
			@ApiResponse(code = 500, message = "Some technical error occurred", response = ErrorBean.class)})
	
	@PostMapping(value = "/v1/credit/applications/{applicationid}/esign",consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@CrossOrigin
	public ResponseEntity<ApplicationResponse> completeEsign(
			@PathVariable(value = "applicationid") String applicationId,
			@Valid @RequestBody Esign esignRequest,
			@RequestHeader HttpHeaders headers) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
				"Inside completeEsign with applicationId: " + applicationId + "  and with request " + esignRequest);
		esignRequest.setApplicationid(applicationId);
		ApplicationResponse response = creditBusinessEsignService.completeEsign(esignRequest,headers);
        logger.debug(CLASS_NAME, BFLLoggerComponent.CONTROLLER, "Inside complete Esign - end");
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}
	
}


