package com.bajaj.markets.credit.business.beans;

public class LeadRequest {

	private String mobile;
	private String dateOfBirth;
	private Reference profession;
	private String productCode;

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Reference getProfession() {
		return profession;
	}

	public void setProfession(Reference profession) {
		this.profession = profession;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	@Override
	public String toString() {
		return "LeadRequest [mobile=" + mobile + ", dateOfBirth=" + dateOfBirth + ", profession=" + profession
				+ ", productCode=" + productCode + "]";
	}

}
