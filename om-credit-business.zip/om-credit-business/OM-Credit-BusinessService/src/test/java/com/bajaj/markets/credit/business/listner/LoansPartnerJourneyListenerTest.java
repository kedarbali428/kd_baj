package com.bajaj.markets.credit.business.listner;

import org.activiti.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;

@SpringBootTest
public class LoansPartnerJourneyListenerTest {
	
	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	LoansPartnerJourneyListener listener;
	
	@Mock
	CreditBusinessGinHelper etbGinHelper;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testPrincipleFlowNotExist() {
		listener.principleFlowNotExist(execution);
	}
	
	@Test
	public void testSetETBFlowFlagForBFLJourney() {
		Mockito.when(execution.getVariable(Mockito.anyString())).thenReturn("RISTOFFERTYPE", null);
		listener.setETBFlowFlagForBFLJourney(execution);
		listener.setETBFlowFlagForBFLJourney(execution);
	}
}
