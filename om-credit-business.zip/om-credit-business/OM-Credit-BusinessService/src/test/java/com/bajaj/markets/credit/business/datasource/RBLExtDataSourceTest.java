package com.bajaj.markets.credit.business.datasource;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.EligibilityResponse;
import com.bajaj.markets.credit.business.beans.Gender;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.MaritalStatus;
import com.bajaj.markets.credit.business.beans.OfferApiRequest;
import com.bajaj.markets.credit.business.beans.OfferSource;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.google.gson.Gson;

@SpringBootConfiguration
@SpringBootTest
public class RBLExtDataSourceTest {

	@Mock
	CreditBusinessHelper creditBusinessHelper;

	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	BFLLoggerUtil loggerUtil;

	@InjectMocks
	RBLExtDataSource rblExtDataSource;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(rblExtDataSource, "logger", logger);
		ReflectionTestUtils.setField(rblExtDataSource, "precedence", "0");
	}

	@Test
	public void registerDataSourceTest() {
		DataSourceRegistry dataSourceRegistry = Mockito.mock(DataSourceRegistry.class);
		rblExtDataSource.registerDataSource(dataSourceRegistry);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void test_init_DataSource() {
		Gson g = new Gson();
	
		EligibilityResponse eligibilityResponse = g.fromJson(
						"{\"isCustomerEligible\"= null, \"custType\"=\"ETB\",\r\n"
						+ "	\"custName\"= \"Ankit\", \"customerId\"= null,\r\n"
						+ "	\"customerSerialKey\"= null, \"appRefId\"= null,\r\n"
						+ "	\"serviceability\"= \"Invalid\",\r\n"
						+ "	\"additionalInfo\": \r\n"
						+ " {\"panNumber\"=\"TOOMG9932N\", \"name\"=\"ANKIT\",\r\n"
						+ " \"maritalStatus\"=\"Married\", \"lastName\"=\"GOYAL\", \"personalEmail\"=\"xyz@abc.com\", \r\n"
						+ " \"currentState\"=\"MAHARASHTRA\", \"currentCity\"=\"PUNE\", \r\n"
						+ " \"currentAddressLine3\"=\"Kothrud\", \"currentAddressLine2\"=\"Paramhansnagar\", \r\n"
						+ " \"currentAddressLine1\"=\"Sai prasad\", \"zipCode\"=\"411009\", \r\n"
						+ " \"permanentState\"=\"MAHARASHTRA\", \"permanentCity\"=\"PUNE\", \r\n"
						+ " \"permanentAddressLine3\"=\"Kothrud\", \"permanentAddressLine2\"=\"Paramhansnagar\", \r\n"
						+ " \"permanentAddressLine1\"=\"Sai prasad\", \"permanentzipCode\"=\"411009\", \r\n"
						+ " \"officeState\"=\"MAHARASHTRA\", \"officeCity\"=\"PUNE\", \r\n"
						+ " \"officeAddressLine3\"=\"Kothrud\", \"officeAddressLine2\"=\"Paramhansnagar\", \r\n"
						+ " \"officeAddressLine1\"=\"Sai prasad\", \"officePinCode\"=\"411009\", \r\n"
						+ " \"employmentType\"=\"Self-Employed Professional\", \"nameOfCompanyBusiness\"=\"ANKIT\",\r\n"
						+ " \"gender\"=\"Male\", \"dateOfBirth\"=\"1991-09-16\"},\r\n" 
						+ "	\"offerDetails\": [{\"accountNumber\"=null, \"accountOpeningDate\"=null, \r\n"
						+ " \"cardNumber\"=null, \"cardLimit\"=90000, \"cardFees\"=245, \r\n" 
						+ " \"corporateOffer\"=null, \"promo\"=[{\"promoCode\"=null, \"promoDescription\"=null}], \r\n" 
						+ " \"productCode\"=\"CCRBLPLTCHOICE\", \"productType\"=\"Platinum Choice\", \"productOffer\"=null, \r\n"
						+ " \"offerLoadDateTime\"=null, \"offerStartDate\"=null, \r\n" 
						+ " \"offerExpiryDate\"=null, \"additionalOfferDetails\"=null, \"productUsageType\"=null, \"offerType\"=null}]\r\n" + "}",
				EligibilityResponse.class);

		OfferSource[] offerSource = g.fromJson(
				"[{\r\n" + "	\"offersrckey\": \"3\",\r\n" + "	\"offersrccode\": \"PRTOFFAPI\",\r\n"
						+ "	\"offersrcdesc\": \"Partner Offer API\",\r\n" + "	\"isactive \": \"1\"\r\n" + "}]",
				OfferSource[].class);
		
		MaritalStatus[] maritalState = g.fromJson("[{"+"\"maritalStatusKey\":11, "+"\"maritalStatusCode\":M, "+"\"maritalStatusValue\":Married}]", MaritalStatus[].class);
		Gender[] gender = g.fromJson("[{"+"\"genderKey\":11, "+"\"genderCode\":M, "+"\"genderValue\":Male}]", Gender[].class);
		LocationAddressBean locationAddressBean = g.fromJson("{\"city\":\"PUNE\",\"cityId\":1784,\"state\":\"MAHARASHTRA\",\"stateId\":257,\"stateShortName\":\"MH\",\"pinCode\":\"411014\",\"pinId\":113548,\"country\":\"INDIA\",\"countryId\":91,\"formattedAddress\":\"PUNE, MAHARASHTRA 411014, INDIA\",\"pinNegativeAreaFlg\":0,\"pinOglFlg\":0}", LocationAddressBean.class);
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(eligibilityResponse, HttpStatus.OK),
						new ResponseEntity(offerSource, HttpStatus.OK),
						new ResponseEntity(gender, HttpStatus.OK),
						new ResponseEntity(maritalState, HttpStatus.OK),
						new ResponseEntity(locationAddressBean, HttpStatus.OK));
		
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("SEMP");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		rblExtDataSource.initDataSource(applicantDataBean);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void test_init_DataSource_else() {
		Gson g = new Gson();
		EligibilityResponse eligibilityResponse = g.fromJson(
				"{\"isCustomerEligible\"= null, \"custType\"=\"ETB\",\r\n"
				+ "	\"custName\"= \"Ankit\", \"customerId\"= null,\r\n"
				+ "	\"customerSerialKey\"= null, \"appRefId\"= null,\r\n"
				+ "	\"serviceability\"= \"Invalid\",\r\n"
				+ "	\"additionalInfo\": \r\n"
				+ " {\"panNumber\"=\"TOOMG9932N\", \"name\"=\"ANKIT\",\r\n"
				+ " \"maritalStatus\"=\"Married\", \"lastName\"=\"GOYAL\", \"personalEmail\"=\"xyz@abc.com\", \r\n"
				+ " \"currentState\"=\"MAHARASHTRA\", \"currentCity\"=\"PUNE\", \r\n"
				+ " \"currentAddressLine3\"=\"Kothrud\", \"currentAddressLine2\"=\"Paramhansnagar\", \r\n"
				+ " \"currentAddressLine1\"=\"Sai prasad\", \"zipCode\"=\"411009\", \r\n"
				+ " \"permanentState\"=\"MAHARASHTRA\", \"permanentCity\"=\"PUNE\", \r\n"
				+ " \"permanentAddressLine3\"=\"Kothrud\", \"permanentAddressLine2\"=\"Paramhansnagar\", \r\n"
				+ " \"permanentAddressLine1\"=\"Sai prasad\", \"permanentzipCode\"=\"411009\", \r\n"
				+ " \"officeState\"=\"MAHARASHTRA\", \"officeCity\"=\"PUNE\", \r\n"
				+ " \"officeAddressLine3\"=\"Kothrud\", \"officeAddressLine2\"=\"Paramhansnagar\", \r\n"
				+ " \"officeAddressLine1\"=\"Sai prasad\", \"officePinCode\"=\"411009\", \r\n"
				+ " \"employmentType\"=\"Salaried\", \"nameOfCompanyBusiness\"=\"ANKIT\",\r\n"
				+ " \"gender\"=\"Male\", \"dateOfBirth\"=\"1991-09-16\"},\r\n" 
				+ "	\"offerDetails\": [{\"accountNumber\"=null, \"accountOpeningDate\"=null, \r\n"
				+ " \"cardNumber\"=null, \"cardLimit\"=90000, \"cardFees\"=245, \r\n" 
				+ " \"corporateOffer\"=null, \"promo\"=[{\"promoCode\"=null, \"promoDescription\"=null}], \r\n" 
				+ " \"productCode\"=\"CCRBLPLTCHOICE\", \"productType\"=\"Platinum Choice\", \"productOffer\"=null, \r\n"
				+ " \"offerLoadDateTime\"=null, \"offerStartDate\"=null, \r\n" 
				+ " \"offerExpiryDate\"=null, \"additionalOfferDetails\"=null, \"productUsageType\"=null, \"offerType\"=null}]\r\n" + "}",
		EligibilityResponse.class);

		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(eligibilityResponse, HttpStatus.OK),
						new ResponseEntity(null, HttpStatus.OK),
						new ResponseEntity(null, HttpStatus.OK),
						new ResponseEntity(null, HttpStatus.OK),
						new ResponseEntity(null, HttpStatus.OK));

		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("SEMP");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		rblExtDataSource.initDataSource(applicantDataBean);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void test_init_DataSource_offer_sourceKey_notNull() {
		Gson g = new Gson();
		EligibilityResponse eligibilityResponse = g.fromJson(
				"{\"isCustomerEligible\"= null, \"custType\"=\"ETB\",\r\n"
				+ "	\"custName\"= \"Ankit\", \"customerId\"= null,\r\n"
				+ "	\"customerSerialKey\"= null, \"appRefId\"= null,\r\n"
				+ "	\"serviceability\"= \"Invalid\",\r\n"
				+ "	\"additionalInfo\": \r\n"
				+ " {\"panNumber\"=\"TOOMG9932N\", \"name\"=\"ANKIT\",\r\n"
				+ " \"maritalStatus\"=\"Married\", \"lastName\"=\"GOYAL\", \"personalEmail\"=\"xyz@abc.com\", \r\n"
				+ " \"currentState\"=\"MAHARASHTRA\", \"currentCity\"=\"PUNE\", \r\n"
				+ " \"currentAddressLine3\"=\"Kothrud\", \"currentAddressLine2\"=\"Paramhansnagar\", \r\n"
				+ " \"currentAddressLine1\"=\"Sai prasad\", \"zipCode\"=\"411009\", \r\n"
				+ " \"permanentState\"=\"MAHARASHTRA\", \"permanentCity\"=\"PUNE\", \r\n"
				+ " \"permanentAddressLine3\"=\"Kothrud\", \"permanentAddressLine2\"=\"Paramhansnagar\", \r\n"
				+ " \"permanentAddressLine1\"=\"Sai prasad\", \"permanentzipCode\"=\"411009\", \r\n"
				+ " \"officeState\"=\"MAHARASHTRA\", \"officeCity\"=\"PUNE\", \r\n"
				+ " \"officeAddressLine3\"=\"Kothrud\", \"officeAddressLine2\"=\"Paramhansnagar\", \r\n"
				+ " \"officeAddressLine1\"=\"Sai prasad\", \"officePinCode\"=\"411009\", \r\n"
				+ " \"employmentType\"=\"Salaried\", \"nameOfCompanyBusiness\"=\"ANKIT\",\r\n"
				+ " \"gender\"=\"Male\", \"dateOfBirth\"=\"1991-09-16\"},\r\n" 
				+ "	\"offerDetails\": [{\"accountNumber\"=null, \"accountOpeningDate\"=null, \r\n"
				+ " \"cardNumber\"=null, \"cardLimit\"=90000, \"cardFees\"=245, \r\n" 
				+ " \"corporateOffer\"=null, \"promo\"=[{\"promoCode\"=null, \"promoDescription\"=null}], \r\n" 
				+ " \"productCode\"=\"CCRBLPLTCHOICE\", \"productType\"=\"Platinum Choice\", \"productOffer\"=null, \r\n"
				+ " \"offerLoadDateTime\"=null, \"offerStartDate\"=null, \r\n" 
				+ " \"offerExpiryDate\"=null, \"additionalOfferDetails\"=null, \"productUsageType\"=null, \"offerType\"=null}]\r\n" + "}",
		EligibilityResponse.class);

		OfferSource[] offerSource = null;

		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(eligibilityResponse, HttpStatus.OK),
						new ResponseEntity(offerSource, HttpStatus.OK));

		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("SEMP");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		rblExtDataSource.initDataSource(applicantDataBean);
	}

	@Test(expected=Exception.class)
	public void test_init_DataSource_offer_ex1() {
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenThrow(Exception.class);
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("SEMP");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		rblExtDataSource.initDataSource(applicantDataBean);
	}
}