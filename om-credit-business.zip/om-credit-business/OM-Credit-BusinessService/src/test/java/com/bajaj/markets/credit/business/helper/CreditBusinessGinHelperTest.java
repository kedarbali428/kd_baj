package com.bajaj.markets.credit.business.helper;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.EmployerMasterBean;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.beans.ProductList;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.google.gson.Gson;

@SpringBootTest
public class CreditBusinessGinHelperTest {

	@Mock
	private RestTemplate restTemplate;

	@Mock
	HttpHeaders header;

	@InjectMocks
	private CreditBusinessHelper helper;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CustomDefaultHeaders customHeaders;

	@Mock
	MasterDataRedisClientHelper masterDataRedisHelper;

	@Mock
	CreditBusinessApiCallsHelper apiCallsHelper;

	@InjectMocks
	private CreditBusinessGinHelper ginHelper;

	private String getPanVerification = "getPanVerification";

	private String nonGinRiskOfferTypes = "SOL_PA,PLTB,SOL_PQ,PLCS_HTS,SOL_PF,PA,PLCS_MTS,PQ,PF";
	private String etbNonGinAllowDesignationRiskofferTypes = "PLCS_HTS,PLCS_MTS";

	String err = "error";

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(apiCallsHelper, "getPanVerification", getPanVerification);
		ReflectionTestUtils.setField(ginHelper, "helper", helper);
		ReflectionTestUtils.setField(ginHelper, "nonGinRiskOfferTypes", nonGinRiskOfferTypes);
		ReflectionTestUtils.setField(ginHelper, "etbNonGinAllowDesignationRiskofferTypes", etbNonGinAllowDesignationRiskofferTypes);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testPrepareBreRequestForGinFlow() throws Exception {
		JSONObject openArcInput = new JSONObject();
		openArcInput.put("eligibilityType", "AIP");
		openArcInput.put("applicationId", "1234");

		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":69,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null}},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000007316\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250004\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":2,\"genderKey\":21,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234H\",\"applicantKey\":122234},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5367\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);
		JSONObject appScoreDetails = new JSONObject();
		mcpReq.put("appScoreDetails", appScoreDetails);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);

		com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean pinCode = new com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean();
		pinCode.setPincode("411041");
		pinCode.setCityName("Pune");

		ProductList productList = g.fromJson(
				"{\"productList\":[{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.0,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":2,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLHFL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.1,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":200000,\"tenor\":48},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":\"FICCLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.2,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":0,\"priorityOrder\":4,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":\"BFLPLCSTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"Fullerton Personal loan - Business Owner\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Pocket Personal Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPPL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPPL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - C.A.\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLCAL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLCAL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - DOCTOR\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLDOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLDOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Business Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null}],\"requiredLoanAmout\":null,\"requiredTenor\":null,\"maxEligibility\":null,\"maxTenor\":null,\"name\":null} ",
				ProductList.class);

		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);
		Mockito.when(masterDataRedisHelper.getGenderByTypeKey(Mockito.any())).thenReturn("Male");
		Mockito.when(masterDataRedisHelper.findResitypeByKey(Mockito.any())).thenReturn(resi);
		Mockito.when(masterDataRedisHelper.getEmployerByKey(Mockito.any())).thenReturn(new EmployerMasterBean());
		Mockito.when(masterDataRedisHelper.getPinCodeByKey(Mockito.any())).thenReturn(pinCode);
		Mockito.when(apiCallsHelper.getProductListForApplication(Mockito.any())).thenReturn(productList);
		ginHelper.prepareBreRequestForGinFlow(openArcInput, mcpReq, null, null, 1);
	}

	@Test
	public void testCheckNonGinFlowFromAppOfferDet() {
		List<AppOfferDetBean> offerList = new ArrayList<AppOfferDetBean>();
		AppOfferDetBean offer = new AppOfferDetBean();
		offer.setRiskOfferType("PF");
		offer.setOfferPriority(1);
		offerList.add(offer);
		Mockito.when(apiCallsHelper.fetchOffers(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(offerList);
		EtbVariantEnum output = ginHelper.checkEtbVariantFromAppOfferDet("1234", 1L, CreditBusinessConstants.PRODUCT_CODE_OMPL);
		assertEquals(EtbVariantEnum.NONGIN, output);
	}
	
	@Test
	public void testCheckNonEtbFlowFromAppOfferDet() {
		List<AppOfferDetBean> offerList = new ArrayList<AppOfferDetBean>();
		AppOfferDetBean offer = new AppOfferDetBean();
		offer.setRiskOfferType("ABC");
		offerList.add(offer);
		Mockito.when(apiCallsHelper.fetchOffers(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(offerList);
		EtbVariantEnum output = ginHelper.checkEtbVariantFromAppOfferDet("1234", 1L, CreditBusinessConstants.PRODUCT_CODE_OMPL);
		assertNull(output);
	}

	@Test
	public void testCheckIsEtbOffer() {
		Assert.assertEquals(true, ginHelper.checkIsEtbOffer("SOL_PA"));
		Assert.assertEquals(false, ginHelper.checkIsEtbOffer("ANOTHER"));
	}
	
	@Test
	public void testCheckIsEtbOffer_RiskOfferNull() {
		ginHelper.checkIsEtbOffer("");
	}
	
	@Test
	public void testCheckAllowDesignationForEtbNonGin() {
		ginHelper.checkAllowDesignationForEtbNonGin("PLCS_MTS");
	}
	
	@Test
	public void testCheckIsEtbCustomer() {
		JSONObject principalCustInfo = new JSONObject();
		principalCustInfo.put("isEtb", true);
		Mockito.when(apiCallsHelper.getPrincipalCustInfo(Mockito.any(), Mockito.any())).thenReturn(principalCustInfo);
		ginHelper.checkIsEtbCustomer("123");
	}
	
	@Test
	public void testCheckIsEtbCustomer_404() {
		Mockito.when(apiCallsHelper.getPrincipalCustInfo(Mockito.any(), Mockito.any()))
				.thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("test", "test")));
		ginHelper.checkIsEtbCustomer("123");
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testCheckIsEtbCustomer_500() {
		Mockito.when(apiCallsHelper.getPrincipalCustInfo(Mockito.any(), Mockito.any()))
				.thenThrow(new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, new ErrorBean("test", "test")));
		ginHelper.checkIsEtbCustomer("123");
	}
}
