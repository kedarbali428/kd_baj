package com.bajaj.markets.credit.business.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.validation.Validation;
import javax.validation.Validator;

import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.EmailDetails;
import com.bajaj.markets.credit.business.service.CreditBusinessEmailVerificationService;

/**
 * @author akash.thumar
 *
 */
@SpringBootTest
public class CreditBusinessEmailVerificationControllerTest {

	@InjectMocks
	CreditBusinessEmailVerificationController creditBusinessEmailVerificationController;
	
	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CreditBusinessEmailVerificationService creditBusinessEmailVerificationService;
	
	private Validator validator;
	
	private MockMvc mockMvc;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		validator = Validation.buildDefaultValidatorFactory().getValidator();
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessEmailVerificationController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();
		
		ReflectionTestUtils.setField(creditBusinessEmailVerificationController, "validator", validator);
	}
	
	@Test
	public void testValidateEmail() throws Exception {
		JSONObject request = new JSONObject();
		request.put("action", "verified");
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/emailverification", 1234l).contentType(MediaType.APPLICATION_JSON).content(request.toString()).headers(new HttpHeaders())).andExpect(status().isCreated());
	}
	
	@Test
	public void testValidateEmail_InvalidAction() throws Exception {
		JSONObject request = new JSONObject();
		request.put("action", "notverified");
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/emailverification", 1234l).contentType(MediaType.APPLICATION_JSON).content(request.toString()).headers(new HttpHeaders())).andExpect(status().isUnprocessableEntity());
	}
	
	@Test
	public void testValidateEmail_InvalidOtp() throws Exception {
		JSONObject request = new JSONObject();
		request.put("action", "validate");
		request.put("otp", "12345678");
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/emailverification", 1234l).contentType(MediaType.APPLICATION_JSON).content(request.toString()).headers(new HttpHeaders())).andExpect(status().isUnprocessableEntity());
	}
	
	@Test
	public void testGetEmailDetailsToVerified() throws Exception {
		when(creditBusinessEmailVerificationService.getEmailVerificationDetails(1234l, new HttpHeaders(), "esignthankyoupage")).thenReturn(new EmailDetails());
		mockMvc.perform(get("/v1/credit/applications/{applicationid}/emailverification", 1234l).headers(new HttpHeaders()).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	
	@Test
	public void testValidateEmail_InvalidToken() throws Exception {
		JSONObject request = new JSONObject();
		request.put("action", "validatetoken");
		request.put("emailToken", "");
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/emailverification", 1234l).contentType(MediaType.APPLICATION_JSON).content(request.toString()).headers(new HttpHeaders())).andExpect(status().isUnprocessableEntity());
	}
}
