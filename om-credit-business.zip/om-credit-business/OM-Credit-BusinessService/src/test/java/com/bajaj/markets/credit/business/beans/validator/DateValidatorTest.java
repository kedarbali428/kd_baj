package com.bajaj.markets.credit.business.beans.validator;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.markets.credit.business.helper.CreditBusinessException;

@SpringBootTest
public class DateValidatorTest {

	@InjectMocks
	private DateValidator dateValidator;

	@Before
	public void inIt() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testIcicAppointmentDateTime() {
		dateValidator.validateAppointmentDateTime("ICICI BANK", "2021-12-12 08:00:00", "2021-12-12 09:00:00");
	}

	@Test(expected = CreditBusinessException.class)
	public void testIcicAppointmentDateTimeInvalid() {
		dateValidator.validateAppointmentDateTime("ICICI BANK", "2021-12-12 09:00:00", "2021-12-12 09:00:00");
	}

	@Test
	public void testIcicAppointmentDateTimeNotIcici() {
		dateValidator.validateAppointmentDateTime("", "2021-12-12 09:00:00", "2021-12-12 09:00:00");
	}

	@Test(expected = CreditBusinessException.class)
	public void testIcicAppointmentDateTimeEmpty() {
		dateValidator.validateAppointmentDateTime("ICICI BANK", null, "2021-12-12 09:00:00");
	}

	@Test(expected = CreditBusinessException.class)
	public void testIcicAppointmentDateTimeEmpty2() {
		dateValidator.validateAppointmentDateTime("ICICI BANK", "2021-12-12 09:00:00", null);
	}

}
