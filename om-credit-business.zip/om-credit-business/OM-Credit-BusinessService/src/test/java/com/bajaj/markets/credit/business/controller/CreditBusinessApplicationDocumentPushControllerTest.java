package com.bajaj.markets.credit.business.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.AppDocumentTrackingBean;
import com.bajaj.markets.credit.business.beans.DocumentPushResponseBean;
import com.bajaj.markets.credit.business.beans.InitiateDocumentPushRequest;
import com.bajaj.markets.credit.business.service.CreditBusinessApplicationDocumentPushService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@SpringBootTest
public class CreditBusinessApplicationDocumentPushControllerTest {

	@Mock
	private BFLLoggerUtilExt logger;

	@InjectMocks
	private CreditBusinessApplicationDocumentPushController creditBusinessApplicationDocumentPushController;

	@Mock
	private CreditBusinessApplicationDocumentPushService creditBusinessApplicationDocumentPushService;

	@Mock
	private CustomDefaultHeaders customDefaultHeaders;

	private MockMvc mockMvc;
	ObjectMapper mapper = new ObjectMapper();

	private String fetchurl = "/v1/credit/applications/{applicationid}/document/push";
	private String updateurl = "/v1/credit/applications/{applicationid}/document/push/{source}/initiate";

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessApplicationDocumentPushController).build();
	}

	@Test
	public void fetchDocumentPushResponseTest() throws Exception {
		Long applicationId = 1100000000012275L;
		DocumentPushResponseBean documentPushResponseBean = new DocumentPushResponseBean();
		documentPushResponseBean.setApplicationKey(applicationId);
		when(creditBusinessApplicationDocumentPushService.fetchDocumentPushDetails(Mockito.any(), Mockito.any()))
				.thenReturn(documentPushResponseBean);
		mockMvc.perform(get(fetchurl, applicationId).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	public void initiateDocumentPushTest() throws Exception {
		InitiateDocumentPushRequest initiateDocumentPushRequest = new InitiateDocumentPushRequest();

		Long principlekey = 7L;
		Long applicationId = 1100000000012275L;
		initiateDocumentPushRequest.setPrincipleKey(principlekey);
		String source = "EP";
		List<AppDocumentTrackingBean> response = new ArrayList<AppDocumentTrackingBean>();
		AppDocumentTrackingBean appDocumentTrackingBean = new AppDocumentTrackingBean();
		appDocumentTrackingBean.setCreditdoctype(2);
		appDocumentTrackingBean.setDocerrordesc("aa");
		response.add(appDocumentTrackingBean);
		initiateDocumentPushRequest.setAppDocumentTrackingBeanList(response);
		Mockito.when(creditBusinessApplicationDocumentPushService.initiateDocumentPush(Mockito.any(), Mockito.any(),
				Mockito.any(),Mockito.any())).thenReturn(response);
		Gson gson=new Gson();
		String requestJson=gson.toJson(initiateDocumentPushRequest);
		mockMvc.perform(put(updateurl, applicationId, source)
				.content(requestJson)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

}
