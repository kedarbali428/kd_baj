package com.bajaj.markets.credit.business.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Validator;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.DocumentInfo;
import com.bajaj.markets.credit.business.beans.EmbededDocuments;
import com.bajaj.markets.credit.business.beans.EsignRequest;
import com.bajaj.markets.credit.business.beans.EsignResponse;
import com.bajaj.markets.credit.business.beans.EsignValidation;
import com.bajaj.markets.credit.business.beans.GenerateOTPResponseBean;
import com.bajaj.markets.credit.business.beans.Location;
import com.bajaj.markets.credit.business.beans.Status;
import com.bajaj.markets.credit.business.service.CreditBusinessEsignService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
@SpringBootTest
public class CreditBusinessEsignControllerTest {


	@Mock
	CreditBusinessEsignService creditBusinessEsignService;

	@InjectMocks
	CreditBusinessEsignController creditBusinessEsignController;

	@Autowired
	Environment env;


	@Mock
	HttpHeaders mockheader;
	
	@Mock
	BFLLoggerUtilExt loggerUtilExt;
	
	@Mock
	Validator validator;
	
	private MockMvc mockMvc;

	private String stampDocUrl = "/v1/creditbusiness/{applicationKey}/esign";
	private String getStatusUrl = "/v1/creditbusiness/{applicationKey}/esign";
	private String consentUrl = "/v1/creditbusiness/{applicationKey}/esign/consent";

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessEsignController)
				.addPlaceholderValue("api.omcreditbusinessservice.esignstatus.GET.uri",
						"/v1/creditbusiness/{applicationKey}/esign")
				.addPlaceholderValue("api.omcreditbusinessservice.esigndocument.PUT.uri",
						"/v1/creditbusiness/{applicationKey}/esign")
				.addPlaceholderValue("api.omcreditbusinessservice.esignconsent.PUT.uri",
						"/v1/creditbusiness/{applicationKey}/esign/consent")
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();

	}

	@Test
	public void testesignStatus() throws Exception {
		EsignResponse esignStatusResponse = new EsignResponse();
		esignStatusResponse.setEsignReferenceNumber(8989l);
		Status statusCode = Status.COMPLETED;
		esignStatusResponse.setStatus(statusCode);
		DocumentInfo documentInfo = new DocumentInfo();
		documentInfo.setCategory("Form");
		documentInfo.setContentType("terma and conditions");
		documentInfo.setDesc("cosolidated form");
		documentInfo.setDocId("9889");
		documentInfo.setName("UnSign_Consolidated_Form");
		documentInfo.setType("document");
		documentInfo.setUrl("s3urlofDocument");
		documentInfo.setUrlKey("urlekey");
		esignStatusResponse.setDocumentInfo(documentInfo);
		Mockito.when(creditBusinessEsignService.getDocumentStatus(Mockito.any(), Mockito.any()))
				.thenReturn(esignStatusResponse);
		mockMvc.perform(put(stampDocUrl, "8989").contentType(
				MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().is4xxClientError());
	}

	@Test
	public void testesignDocument() throws Exception {
		EsignRequest esignRequest = new EsignRequest();
		EsignValidation esignValidation = new EsignValidation();
		esignValidation.setDateOfBirth("20-09-1996");
		Location location = new Location();
		location.setLatitude(424D);
		location.setLongitude(84892D);
		esignValidation.setLocation(location);
		esignValidation.setMobile("9999999999");
		esignValidation.setName("Testing");
		esignValidation.setOtp("989898");
		esignRequest.setEsignValidation(esignValidation);
		esignRequest.setIsForced(true);
		esignRequest.setGenerateBitly(true);
		esignRequest.setGenerateDocument(true);
		EsignResponse esignResponse = populateEsignReponseDetails();
		Mockito.when(creditBusinessEsignService.createDocument(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenReturn(esignResponse);
		mockMvc.perform(get(getStatusUrl, "8989").content(prepareRequestJsonString(
				esignRequest))
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void testConsentOTP() throws Exception {
		GenerateOTPResponseBean generateOTPResponse = new GenerateOTPResponseBean();
		generateOTPResponse.setPayload("success");
		Mockito.when(creditBusinessEsignService.consentOTP(Mockito.any(), Mockito.any()))
				.thenReturn(generateOTPResponse);
		mockMvc.perform(
				put(consentUrl, "8989").contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk());

	}

	public EsignResponse populateEsignReponseDetails() {
		EsignResponse esignResponse = new EsignResponse();
		DocumentInfo documentInfo = new DocumentInfo();
		documentInfo.setCategory("Form");
		documentInfo.setContentType("terma and conditions");
		documentInfo.setDesc("cosolidated form");
		documentInfo.setDocId("9889");
		documentInfo.setName("UnSign_Consolidated_Form");
		documentInfo.setType("document");
		documentInfo.setUrl("s3urlofDocument");
		documentInfo.setUrlKey("urlekey");
		esignResponse.setDocumentInfo(documentInfo);
		esignResponse.setStatus(Status.INITIAITED);
		esignResponse.setIsCreated(true);
		esignResponse.setIsEsigned(false);
		esignResponse.setIsOTPRequired(false);
		esignResponse.setIsDocumentGenerated(true);
		esignResponse.setL3productCode("BFLSOL");
		List<EmbededDocuments> embededDocuments = new ArrayList();
		EmbededDocuments docs = new EmbededDocuments();
		String setOfFiles = "Application Form" + "," + "T &C";
		docs.setListofFiles(setOfFiles);
		embededDocuments.add(docs);
		esignResponse.setEmbededDocuments(embededDocuments);
		return esignResponse;

	}

	private String prepareRequestJsonString(Object requestObject) {
		String requestJson = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			requestJson = mapper.writeValueAsString(requestObject);
		} catch (JsonProcessingException e) {
		}
		return requestJson;

	}
	
	@Test
	public void completeESignTest() throws Exception {
		ApplicationResponse responseEntity = new ApplicationResponse();
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(responseEntity);
		when(creditBusinessEsignService.completeEsign( Mockito.any(), Mockito.any())).thenReturn(responseEntity);
	mockMvc.perform(post("/v1/credit/applications/{applicationid}/esign/","12345").content(requestJson).contentType(MediaType.APPLICATION_JSON).headers(mockheader)).andExpect(status().isCreated());
	}
}


	

	



