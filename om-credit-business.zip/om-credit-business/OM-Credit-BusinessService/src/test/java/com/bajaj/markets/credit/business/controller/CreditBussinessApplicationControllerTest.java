package com.bajaj.markets.credit.business.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.service.CreditBusinessService;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CreditBussinessApplicationControllerTest {
	@Mock
	BFLLoggerUtilExt logger;

	@InjectMocks
	CreditBussinessApplicationController creditBusinessController;

	@Autowired
	CreditBusinessControllerAdvice creditBusinessControllerAdvice;

	@Mock
	private CreditBusinessService creditBusinessService;

	@Autowired
	private MockMvc mockMvc;

	ApplicationResponse applicationResponse;

	ObjectMapper mapper = new ObjectMapper();
	
	private static Validator validator;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();
		
		 validator = Validation.buildDefaultValidatorFactory().getValidator();
		 
		 ReflectionTestUtils.setField(creditBusinessController, "validator", validator);
	}

	@Test
	public void testCreateCreditApplication() throws Exception {
		String request = "{ \"dateOfBirth\": \"1980-02-12\", \"mobileNumber\": \"8734567890\", \"productCode\": \"CC\", \"productKey\": 10001, \"profession\": { \"code\": \"SAL\", \"key\": 10, \"value\": \"SALARIED\" } }";
		mockMvc.perform(post("/v1/credit/applications").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isCreated());
	}
	
	@Test
	public void testCreateCreditApplication_CustomHeaderNotNull() throws Exception {
		CustomDefaultHeaders customHeader = Mockito.mock(CustomDefaultHeaders.class);
		ReflectionTestUtils.setField(creditBusinessController, "customHeader", customHeader);
		when(customHeader.getAuthtoken()).thenReturn("authtoken");
		
		String request = "{ \"dateOfBirth\": \"1980-02-12\", \"mobileNumber\": \"8797899870\", \"productCode\": \"CC\", \"productKey\": 10001, \"profession\": { \"code\": \"SAL\", \"key\": 10, \"value\": \"SALARIED\" }, \"applicationKey\":10000  }";
		mockMvc.perform(post("/v1/credit/applications").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isCreated());
	}

	@Test
	public void testCreateCreditApplication_exp() throws Exception {
		String request = "{ \"dateOfBirth\": \"\", \"mobileNumber\": \"\", \"productCode\": \"CC\", \"productKey\": 10001, \"profession\": { \"code\": \"SAL\", \"key\": 10, \"value\": \"SALARIED\" } }";
		mockMvc.perform(post("/v1/credit/applications").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().is4xxClientError());
	}

	@Test
	public void testApplication() throws Exception {
		mockMvc.perform(
				get("/v1/credit/applications/{applicationid}", "763456").contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk());
	}
	
	@Test
	public void applicationInfo() throws Exception {
		mockMvc.perform(
				get("/v1/credit/applicationsinfo/{applicationid}", "763456").contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testCreateCreditApplication_CampaignCase() throws Exception {
		String request = "{\"profession\":null,\"productCode\":\"OMPL\",\"productKey\":10002,\"mobileNumber\":null,\"dateOfBirth\":null,\"applicationKey\":null,\"offerId\":\"3969979 | BFDL_PL | 2018-08-07\"}";
		mockMvc.perform(post("/v1/credit/applications").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isCreated());
	}
	
	@Test
	public void testCreateCreditApplication_CampaignCase_Unprocessable() throws Exception {
		String request = "{\"profession\":null,\"productCode\":null,\"productKey\":10002,\"mobileNumber\":null,\"dateOfBirth\":null,\"applicationKey\":null,\"offerId\":\"3969979 | BFDL_PL | 2018-08-07\"}";
		mockMvc.perform(post("/v1/credit/applications").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().is4xxClientError());
	}
	
	@Test
	public void testCreateCreditApplicationV2() throws Exception {
		String request = "{ \"dateOfBirth\": \"1980-02-12\", \"mobileNumber\": \"8734567890\", \"productCode\": \"OMPL\", \"productKey\": 10002, \"profession\": { \"code\": \"SAL\", \"key\": 10, \"value\": \"SALARIED\" } }";
		mockMvc.perform(post("/v2/credit/applications").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isCreated());
	}
	
	@Test
	public void testCreateCreditApplicationV2_CustomHeaderNotNull() throws Exception {
		CustomDefaultHeaders customHeader = Mockito.mock(CustomDefaultHeaders.class);
		ReflectionTestUtils.setField(creditBusinessController, "sessionEnabled", true);
		ReflectionTestUtils.setField(creditBusinessController, "customHeader", customHeader);
		when(customHeader.getAuthtoken()).thenReturn("authtoken");
		
		String request = "{ \"dateOfBirth\": \"1980-02-12\", \"mobileNumber\": \"8797899870\", \"productCode\": \"OMPL\", \"productKey\": 10002, \"profession\": { \"code\": \"SAL\", \"key\": 10, \"value\": \"SALARIED\" }, \"applicationKey\":10000  }";
		mockMvc.perform(post("/v2/credit/applications").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isCreated());
	}

	@Test
	public void testCreateCreditApplicationV2_exp() throws Exception {
		String request = "{ \"dateOfBirth\": \"\", \"mobileNumber\": \"\", \"productCode\": \"OMPL\", \"productKey\": 10002, \"profession\": { \"code\": \"SAL\", \"key\": 10, \"value\": \"SALARIED\" } }";
		mockMvc.perform(post("/v2/credit/applications").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().is4xxClientError());
	}
	
	@Test
	public void testCreateCreditApplicationV2_CampaignCase() throws Exception {
		String request = "{\"profession\":null,\"productCode\":\"OMPL\",\"productKey\":10002,\"mobileNumber\":null,\"dateOfBirth\":null,\"applicationKey\":null,\"offerId\":\"3969979 | BFDL_PL | 2018-08-07\"}";
		mockMvc.perform(post("/v2/credit/applications").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isCreated());
	}
	
	@Test
	public void testCreateCreditApplicationV2_CampaignCase_Unprocessable() throws Exception {
		String request = "{\"profession\":null,\"productCode\":null,\"productKey\":10002,\"mobileNumber\":null,\"dateOfBirth\":null,\"applicationKey\":null,\"offerId\":\"3969979 | BFDL_PL | 2018-08-07\"}";
		mockMvc.perform(post("/v2/credit/applications").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().is4xxClientError());
	}
}