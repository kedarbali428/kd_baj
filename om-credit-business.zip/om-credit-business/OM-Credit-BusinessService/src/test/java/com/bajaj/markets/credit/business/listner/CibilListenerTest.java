package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_REF_KEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.CIBIL_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.L2_PRODUCT_CODE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SKIP_API_EXCEPTION;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.publisher.service.PublisherService;

@SpringBootConfiguration
@SpringBootTest
public class CibilListenerTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;
	
	@Mock
	CustomDefaultHeaders customHeaders;
	
	@Mock
	PublisherService publisherService;

	@InjectMocks
	CibilListener listener;
	
	@Mock
	CreditBusinessApiCallsHelper apiCallHelper;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testpostFetchCibil() {
		List<JSONObject> cibilResp = new ArrayList<JSONObject>();
		JSONObject fetchcibil = CreditBusinessHelper.getJSONObject(
				"{\"cibilTypeAndScore\":[{\"cibilType\":\"COMMERCIALCIBIL\",\"scoreV3\":\"804\",\"scoreV1\":\"\",\"cibilReferenceNumber\":2595,\"addlCibilFlg\":1}],\"applicantKey\":123546,\"authenticationRequired\":false,\"provider\":\"TRANSUNION\",\"applicationKey\":1100000000009339,\"state\":\"COMPLETED\",\"cibilReferenceNumber\":2595}");
		cibilResp.add(fetchcibil);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		listener.postFetchCibil(execution);
	}

	@Test
	public void testpostFetchCibil2() {
		List<JSONObject> cibilResp = new ArrayList<JSONObject>();
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		listener.postFetchCibil(execution);
	}

	@Test
	public void testpreAuthenticateCibil() {
		JSONObject cibilResp = new JSONObject();
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(cibilResp);
		listener.preAuthenticateCibil(execution);
	}

	@Test
	public void testpostAuthenticateCibil() {
		JSONObject cibilResp = new JSONObject();
		cibilResp.put("cibilReferenceNumber", "1");
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		listener.postAuthenticateCibil(execution);
	}

	@Test
	public void testpostAuthenticateCibil2() {
		JSONObject cibilResp = new JSONObject();
		cibilResp.put("errorCode", "1");
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		listener.postAuthenticateCibil(execution);
	}

	@Test
	public void testPreCibil() {
		JSONObject cibilResp = new JSONObject();
		JSONObject name = new JSONObject();
		when(execution.getVariable(CreditBusinessConstants.NAME)).thenReturn(name);
		when(execution.getVariable(CIBIL_TYPE)).thenReturn("CONSUMERCIBIL");
		when(execution.getVariable(L2_PRODUCT_CODE)).thenReturn("OMPL");
		listener.preCibil(execution, false);

		when(execution.getVariable(CIBIL_TYPE)).thenReturn("COMMERCIALCIBIL");
		when(execution.getVariable(L2_PRODUCT_CODE)).thenReturn("CC");
		listener.preCibil(execution, false);

		when(execution.getVariable(CIBIL_TYPE)).thenReturn("a");
		listener.preCibil(execution, false);
	}
	
	@Test
	public void testPreCibil_ForCommercialCibil() {
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(new JSONObject());
		listener.preCibil(execution, true);
	}

	@Test
	public void testpostCibil() {
		JSONObject cibilResp = new JSONObject();
		cibilResp.put("cibilReferenceNumber", "1");
		when(execution.getVariable(SKIP_API_EXCEPTION)).thenReturn(false);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		listener.postCibil(execution);
	}

	@Test
	public void testpostCibil_skipApiExceptionExceptionArised() {
		when(execution.getVariable(SKIP_API_EXCEPTION)).thenReturn(true);
		when(execution.getVariable(API_EXCEPTION_ARISE)).thenReturn(true);
		listener.postCibil(execution);
	}
	
	@Test
	public void testpostCibil_skipApiExceptionCibilResponseWithError() {
		JSONObject cibilResp = new JSONObject();
		cibilResp.put("errorCode", "VERIFICATION-101");
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		when(execution.getVariable(SKIP_API_EXCEPTION)).thenReturn(true);
		listener.postCibil(execution);
	}
	
	@Test
	public void testpostCibil_skipApiExceptionCibilNoError() {
		JSONObject cibilResp = new JSONObject();
		cibilResp.put("cibilReferenceNumber", "1");
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		when(execution.getVariable(SKIP_API_EXCEPTION)).thenReturn(true);
		listener.postCibil(execution);
	}
	
	@Test
	public void testpostCibil_skipApiExceptionCibilInactiveState() {
		JSONObject cibilResp = new JSONObject();
		cibilResp.put("cibilReferenceNumber", "1");
		cibilResp.put("state", "INACTIVE");
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		when(execution.getVariable(SKIP_API_EXCEPTION)).thenReturn(true);
		listener.postCibil(execution);
	}
	
	@Test
	public void testpostCibil_skipApiExceptionCibilCompletedState() {
		JSONObject cibilResp = new JSONObject();
		cibilResp.put("cibilReferenceNumber", "1");
		cibilResp.put("state", "COMPLETED");
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		when(execution.getVariable(SKIP_API_EXCEPTION)).thenReturn(true);
		listener.postCibil(execution);
	}
	
	@Test
	public void testfetchCibilDocumentPost() {
		JSONObject cibilResp = new JSONObject();
		cibilResp.put("cibilJson", "1");
		when(execution.getVariable(CreditBusinessConstants.IS_API_RESPONSE_NULL)).thenReturn(false);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		listener.fetchCibilDocumentPost(execution);
	}
	
	@Test
	public void testfetchCibilDocumentPost_NullCibilResponseJson() {
		JSONObject cibilResp = new JSONObject();
		cibilResp.put("cibilJson", "1");
		when(execution.getVariable(CreditBusinessConstants.IS_API_RESPONSE_NULL)).thenReturn(true);
		when(execution.getVariable("cibilResponseFromPostAPI")).thenReturn(cibilResp);
		listener.fetchCibilDocumentPost(execution);
	}

	@Test
	public void testfetchBasicUserProfileForCibilPost() {
		List<JSONObject> cibilResp = new ArrayList<JSONObject>();
		JSONObject profile = new JSONObject();
		profile.put(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE, "1");
		cibilResp.add(profile);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		listener.fetchBasicUserProfileForCibilPost(execution);
	}

	@Test
	public void testfetchPersonalEmailForCibilPost() {
		JSONObject cibilResp = new JSONObject();
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		listener.fetchPersonalEmailForCibilPost(execution);
	}

	public void testfetchAddressForCibilPost() {
		JSONObject cibilResp = new JSONObject();
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		listener.fetchAddressForCibilPost(execution);
	}

	public void fetchPanDocumentForCibilPost() {
		JSONObject cibilResp = new JSONObject();
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(cibilResp);
		listener.fetchPanDocumentForCibilPost(execution);
	}
	
	public void testpreFetchCibilForCibilType() {
		when(execution.getVariable(CreditBusinessConstants.CIBIL_TYPE)).thenReturn(null);
		listener.preFetchCibilForCibilType(execution);
	}

	@Test
	public void testGePersonalEmail() {
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("1111");
		listener.getPersonalEmail(execution);
	}

	@Test
	public void testPreUpdateCibilRefKey() {
		when(execution.getVariable(CIBIL_REF_KEY)).thenReturn(123l);
		listener.preUpdateCibilRefKey(execution);
	}
	
	@Test
	public void testTriggerFhcrEvent() {
		when(execution.getVariable(CIBIL_REF_KEY)).thenReturn(123l);
		when(execution.getVariable("cibilState")).thenReturn("COMPLETED");
		when(execution.getVariable(CIBIL_TYPE)).thenReturn("CONSUMERCIBIL");
		when(customHeaders.getUserKey()).thenReturn(1l);
		listener.triggerFhcrEvent(execution);
	}
	
	@Test
	public void testTriggerFhcrEvent_ConditionNotSatisfied() {
		when(execution.getVariable(CIBIL_REF_KEY)).thenReturn(123l);
		when(execution.getVariable("cibilState")).thenReturn("");
		when(execution.getVariable(CIBIL_TYPE)).thenReturn("CONSUMERCIBIL");
		when(customHeaders.getUserKey()).thenReturn(1l);
		listener.triggerFhcrEvent(execution);
	}
	
	@Test
	public void testSetAppAttributeTaggedCibilReferenceKeyToExecution () {
		UserProfileBean userProfile = new UserProfileBean();
		userProfile.setApplicationUserAttributeKey("1234");
		DocumentDetails documentDetails = new DocumentDetails();
		documentDetails.setDocumentNumber("1234");
		when(execution.getVariable(Mockito.anyString())).thenReturn("12345");
		when(apiCallHelper.getUserProfile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(userProfile);
		when(apiCallHelper.getDocumentDetail(Mockito.any(), Mockito.any())).thenReturn(documentDetails);
		listener.setAppAttributeTaggedCibilReferenceKeyToExecution(execution);
	}
	
	@Test
	public void testSetAppAttributeTaggedCibilReferenceKeyToExecution_DocumentNotPresent () {
		UserProfileBean userProfile = new UserProfileBean();
		userProfile.setApplicationUserAttributeKey("1234");
		DocumentDetails documentDetails = new DocumentDetails();
		documentDetails.setDocumentNumber("null");
		when(execution.getVariable(Mockito.anyString())).thenReturn("12345");
		when(apiCallHelper.getUserProfile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(userProfile);
		when(apiCallHelper.getDocumentDetail(Mockito.any(), Mockito.any())).thenReturn(documentDetails);
		listener.setAppAttributeTaggedCibilReferenceKeyToExecution(execution);
	}
}
