package com.bajaj.markets.credit.business.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ChildApplication;
import com.bajaj.markets.credit.business.beans.ProductList;
import com.bajaj.markets.credit.business.service.CreditBusinessProductListService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
public class CreditBusinessProductListControllerTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CreditBusinessProductListService service;

	@InjectMocks
	CreditBusinessProductListController controller;

	private MockMvc mockMvc;

	@Autowired
	Validator validator;

	ObjectMapper mapper = new ObjectMapper();

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(CreditBusinessControllerAdvice.class).build();
		validator = Validation.buildDefaultValidatorFactory().getValidator();
		ReflectionTestUtils.setField(controller, "validator", validator);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testProductList() throws Exception {
		ResponseEntity<ProductList> resp = new ResponseEntity(new ProductList(), HttpStatus.OK);
		when(service.getProductList(Mockito.any(), Mockito.eq(0d), Mockito.eq(0d), Mockito.eq(0))).thenReturn(resp);
		mockMvc.perform(get("/v1/credit/applications/1234/product").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testProductList_ex() throws Exception {
		ResponseEntity<ProductList> resp = new ResponseEntity(new ProductList(), HttpStatus.UNPROCESSABLE_ENTITY);
		when(service.getProductList(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(resp);
		mockMvc.perform(get("/v1/credit/applications/abcd/product").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isUnprocessableEntity());
	}

	@Test
	public void testCreateProductApplication() throws Exception {
		ChildApplication childApplication = new ChildApplication();
		childApplication.setL2ProductCode("CC");
		childApplication.setL2ProductKey(123);
		childApplication.setL3ProductCode("CCAXNeon");
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(childApplication);

		mockMvc.perform(post("/v1/credit/applications/{applicationid}/product", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}

	@Test
	public void testCreateProductApplication_ValidationError() throws Exception {
		ChildApplication childApplication = new ChildApplication();
		childApplication.setL2ProductKey(123);
		childApplication.setL3ProductCode("CCAXNeon");
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(childApplication);
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/product", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isUnprocessableEntity());
	}

	@Test
	public void testCreateProductApplicationOmplRejected() throws Exception {
		ChildApplication childApplication = new ChildApplication();
		childApplication.setAction("Rejected");
		childApplication.setL2ProductCode("OMPL");
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(childApplication);
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/product", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}

	@Test
	public void testCreateProductApplicationOmplValidationError2() throws Exception {
		ChildApplication childApplication = new ChildApplication();
		childApplication.setL2ProductCode("OMPL");
		childApplication.setAction(null);
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(childApplication);
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/product", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isUnprocessableEntity());
	}
}
