package com.bajaj.markets.credit.business.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AdditionalPageInfo;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.PropertyAdditionalDetails;
import com.bajaj.markets.credit.business.service.CreditBusinsessPropertyAdditionalDetailService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@AutoConfigureMockMvc
@WebMvcTest
public class CreditBusinessPropertyAdditionalDetailControllerTest {
	
	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CreditBusinsessPropertyAdditionalDetailService propertyAdditionalDetailService;

	@InjectMocks
	CreditBusinessPropertyAdditionalDetailController propertyAdditionalDetailController;
	
	@Mock
	BindingResult result;

	private MockMvc mockMvc;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(propertyAdditionalDetailController).setControllerAdvice(CreditBusinessControllerAdvice.class).build();
	}
	
	@Test
	public void testGetPropertyAdditionalDetails() throws Exception {
		PropertyAdditionalDetails additionalDetail = new PropertyAdditionalDetails();
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(additionalDetail);
		Mockito.when(propertyAdditionalDetailService.getPropertyAdditionalDetails(Mockito.any())).thenReturn(additionalDetail);
		mockMvc.perform(
				get("/v1/credit/applications/secureloans/{applicationid}/property/additionaldetail", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testPropertyAdditionalDetails() {
		PropertyAdditionalDetails additionalDetail = new PropertyAdditionalDetails();
		ApplicationResponse applicationResponse = new ApplicationResponse();
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = null;
		try {
			requestJson = mapper.writeValueAsString(additionalDetail);
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Mockito.when(propertyAdditionalDetailService.postPropertyDetails(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(applicationResponse);
		try {
			mockMvc.perform(
					post("/v1/credit/applications/secureloans/{applicationid}/property/additionaldetail", "123",additionalDetail,result,httpHeaders).content(requestJson).contentType(MediaType.APPLICATION_JSON))
					.andExpect(status().isCreated());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void test_getAdditionalPageInfo() throws Exception {
		AdditionalPageInfo additionalPageInfo = new AdditionalPageInfo();
		additionalPageInfo.setCoAppName("test");
		Mockito.when(propertyAdditionalDetailService.getAdditionalPageInformation(Mockito.anyString(), Mockito.any())).thenReturn(additionalPageInfo);
		mockMvc.perform(get("/v1/credit/applications/secureloans/{applicationid}/additionaldetail","123")).andExpect(status().isOk());
		assertEquals("test", additionalPageInfo.getCoAppName());
	}
	
	@Test
	public void testAdditionalDetails() {
		PropertyAdditionalDetails additionalDetail = new PropertyAdditionalDetails();
		ApplicationResponse applicationResponse = new ApplicationResponse();
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = null;
		try {
			requestJson = mapper.writeValueAsString(additionalDetail);
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Mockito.when(propertyAdditionalDetailService.postAdditionalDetails(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(applicationResponse);
		try {
			mockMvc.perform(
					post("/v1/credit/applications/secureloans/{applicationid}/additionaldetail", "123",additionalDetail,result,httpHeaders).content(requestJson).contentType(MediaType.APPLICATION_JSON))
					.andExpect(status().isCreated());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
