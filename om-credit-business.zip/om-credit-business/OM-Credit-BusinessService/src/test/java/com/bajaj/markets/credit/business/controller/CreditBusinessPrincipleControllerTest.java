package com.bajaj.markets.credit.business.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.Validator;
import javax.validation.metadata.ConstraintDescriptor;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ProcessCard;
import com.bajaj.markets.credit.business.beans.ProcessStatus;
import com.bajaj.markets.credit.business.beans.ProfileDetails;
import com.bajaj.markets.credit.business.service.CreditBusinessPrincipleService;
import com.fasterxml.jackson.databind.ObjectMapper;

@AutoConfigureMockMvc
@WebMvcTest
public class CreditBusinessPrincipleControllerTest {

	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	CreditBusinessPrincipleService CreditBusinessPrincipleService;
	
	@Mock
	private Validator validator;
	
	@InjectMocks
	CreditBusinessPrincipleController creditBusinessPrincipleController;
	
	private MockMvc mockMvc;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessPrincipleController).setControllerAdvice(CreditBusinessControllerAdvice.class).build();
	}

	@Test
	public void testProcessCard() throws Exception{
		Set<ConstraintViolation<Object>> validationErrors = new HashSet<>();
		ConstraintViolation<Object> validationError = new ConstraintViolation<Object>() {

			@Override
			public <U> U unwrap(Class<U> type) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Class<Object> getRootBeanClass() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ProfileDetails getRootBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Path getPropertyPath() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getMessageTemplate() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getMessage() {
				// TODO Auto-generated method stub
				return "consent can not be null or empty";
			}

			@Override
			public Object getLeafBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getInvalidValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getExecutableReturnValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object[] getExecutableParameters() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ConstraintDescriptor<?> getConstraintDescriptor() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		validationErrors.add(validationError);
		when(validator.validate(any(), any())).thenReturn(validationErrors);
		ProcessCard processCard = new ProcessCard();
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(processCard);
		mockMvc.perform(
				post("/v1/credit/applications/{applicationid}/card/process","123")
				.content(requestJson)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isUnprocessableEntity());
	}
	
	@Test
	public void testProcessCard_Success() throws Exception{
		ProcessCard processCard = new ProcessCard();
		processCard.setAction("fdsfd");
		processCard.setConsent("dfg");
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(processCard);
		mockMvc.perform(
				post("/v1/credit/applications/{applicationid}/card/process","123")
				.content(requestJson)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}
	
	@Test
	public void testProcessStatus() throws Exception{
		ProcessStatus processStatus = new ProcessStatus();
		processStatus.setApplicationid("123");
		processStatus.setChildStatus("Approval");
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(processStatus);
		mockMvc.perform(
				post("/v1/credit/applications/{applicationid}/status","123")
				.content(requestJson)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}
	
	@Test
	public void testProcessStatus_InvalidInput() throws Exception{
		ProcessStatus processStatus = new ProcessStatus();
		processStatus.setApplicationid(null);
		processStatus.setChildStatus("Approval");
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(processStatus);
		mockMvc.perform(
				post("/v1/credit/applications/{applicationid}/status"," ")
				.content(requestJson)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isUnprocessableEntity());
	}
	
	@Test
	public void testFetchApprovedDetails() throws Exception{
		mockMvc.perform(
				get("/v1/credit/applications/{applicationid}/parameters","123")
				.param("l3ProductCode", "CCAXISNEON")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testFetchApprovedDetails_InvalidInput() throws Exception{
		mockMvc.perform(
				get("/v1/credit/applications/{applicationid}/parameters","123")
				.param("l3ProductCode", "")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isUnprocessableEntity());
	}
	
	@Test
	public void testProcessPartnerConsent() throws Exception{
		Set<ConstraintViolation<Object>> validationErrors = new HashSet<>();
		ConstraintViolation<Object> validationError = new ConstraintViolation<Object>() {

			@Override
			public <U> U unwrap(Class<U> type) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Class<Object> getRootBeanClass() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ProfileDetails getRootBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Path getPropertyPath() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getMessageTemplate() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getMessage() {
				// TODO Auto-generated method stub
				return "consent can not be null or empty";
			}

			@Override
			public Object getLeafBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getInvalidValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getExecutableReturnValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object[] getExecutableParameters() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ConstraintDescriptor<?> getConstraintDescriptor() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		validationErrors.add(validationError);
		when(validator.validate(any(), any())).thenReturn(validationErrors);
		ProcessCard processCard = new ProcessCard();
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(processCard);
		mockMvc.perform(
				post("/v1/credit/applications/{applicationid}/loan/process","123")
				.content(requestJson)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isUnprocessableEntity());
	}
	
	@Test
	public void testProcessPartnerConsent_Success() throws Exception{
		ProcessCard processCard = new ProcessCard();
		processCard.setAction("fdsfd");
		processCard.setConsent("dfg");
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(processCard);
		mockMvc.perform(
				post("/v1/credit/applications/{applicationid}/loan/process","123")
				.content(requestJson)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}
}
