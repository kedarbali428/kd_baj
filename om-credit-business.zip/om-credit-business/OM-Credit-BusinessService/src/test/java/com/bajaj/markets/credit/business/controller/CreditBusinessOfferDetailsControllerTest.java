package com.bajaj.markets.credit.business.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.service.CreditBusinessOfferDetailsService;

@AutoConfigureMockMvc
@WebMvcTest(CreditBusinessOfferDetailsController.class)
public class CreditBusinessOfferDetailsControllerTest {
	
	@InjectMocks
	CreditBusinessOfferDetailsController creditBusinessOfferDetailsController;
	
	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CreditBusinessOfferDetailsService creditBusinessOfferDetailsService;
	
	private MockMvc mockMvc;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessOfferDetailsController).setControllerAdvice(CreditBusinessControllerAdvice.class)
				.addPlaceholderValue("api.omcreditbusinessservice.offeramount.GET.uri",
						"/v1/credit/applications/{applicationid}/offer").build();
	}
	
	@Test
	public void getProfile() throws Exception {
		Mockito.when(creditBusinessOfferDetailsService.getOfferAmount(Mockito.anyString(),Mockito.anyString())).thenReturn(BigDecimal.ONE);
		mockMvc.perform(get("/v1/credit/applications/{applicationid}/offer", "1100000000000406").param("productCode","OMPL").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

}
