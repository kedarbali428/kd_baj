package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;

import java.util.HashMap;

import org.activiti.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.sns.model.AuthorizationErrorException;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.EventMessageHelper;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.google.gson.Gson;

@SpringBootTest
public class BmrTwoListenerTest {
	@InjectMocks
	BmrTwoListener bmrTwoListener;

	@Mock
	BFLLoggerUtilExt logger;

	private String topicArn = "topicArn";

	@Mock
	PublisherService publisherService;

	@Mock
	EventMessageHelper eventHelper;

	@Mock
	DelegateExecution execution;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

		ReflectionTestUtils.setField(bmrTwoListener, "topicArn", topicArn);
	}

	@Test
	public void testPublishEvent() {
		Gson g = new Gson();
		HashMap<String, Object> request = g.fromJson(
				"{\"action\":\"string\",\"profession\":{\"businessOwnerDetails\":{\"anualTurnover\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"averageBankBalance\":0,\"businessName\":\"string\",\"businessNature\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"businessPan\":\"string\",\"businessType\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"businessVintage\":\"string\",\"caRegistrationNumber\":\"string\",\"certificateOfPracticeYear\":0,\"corporateLinkageType\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"doctorRegistrationNumber\":\"string\",\"gstNumber\":\"string\",\"hospital\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"hospitalNameOther\":\"string\",\"industryType\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"natureOfBusiness\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"netMonthlyIncome\":\"string\",\"officetype\":\"string\",\"otherSpecialization\":\"string\",\"practiceType\":\"string\",\"presentBusinessVintage\":0,\"profitAfterTax\":0,\"proprieterName\":\"string\",\"qualification\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"regCouncil\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"shopStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"specialization\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"yearOfGraduation\":0,\"yearOfPostGraduation\":0},\"ocupationType\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"salariedDetail\":{\"averageBankBalance\":0,\"designation\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"doctorRegistrationNumber\":\"string\",\"empSectorService\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"employerName\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"employerNameOther\":\"string\",\"employerType\":0,\"experience\":\"string\",\"hospital\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"hospitalNameOther\":\"string\",\"netSalary\":\"string\",\"otherSpecialization\":\"string\",\"practiceType\":\"string\",\"principalIndustry\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"qualification\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"regCouncil\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"specialization\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"subEmployerType\":0,\"workExperienceInMonths\":0,\"yearOfGraduation\":0,\"yearOfPostGraduation\":0}},\"profileDetails\":{\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"name\":\"string ABCDA XSDE\",\"panNumber\":\"string\",\"personalEmailId\":\"string\",\"residenceType\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"}},\"requiredLoanAmount\":0,\"residencePincode\":{\"city\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"country\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"negativeAreaFlag\":true,\"oglFlag\":true,\"pincode\":\"string\",\"state\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"}}}",
				HashMap.class);
		Mockito.when(execution.getVariable(Mockito.eq(CreditBusinessConstants.REQUEST))).thenReturn(request);
		bmrTwoListener.publishEvent(execution);
	}

	@Test
	public void testPublishEvent_Exception() {
		Gson g = new Gson();
		HashMap<String, Object> request = g.fromJson(
				"{\"action\":\"string\",\"profession\":{\"businessOwnerDetails\":{\"anualTurnover\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"averageBankBalance\":0,\"businessName\":\"string\",\"businessNature\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"businessPan\":\"string\",\"businessType\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"businessVintage\":\"string\",\"caRegistrationNumber\":\"string\",\"certificateOfPracticeYear\":0,\"corporateLinkageType\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"doctorRegistrationNumber\":\"string\",\"gstNumber\":\"string\",\"hospital\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"hospitalNameOther\":\"string\",\"industryType\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"natureOfBusiness\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"netMonthlyIncome\":\"string\",\"officetype\":\"string\",\"otherSpecialization\":\"string\",\"practiceType\":\"string\",\"presentBusinessVintage\":0,\"profitAfterTax\":0,\"proprieterName\":\"string\",\"qualification\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"regCouncil\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"shopStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"specialization\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"yearOfGraduation\":0,\"yearOfPostGraduation\":0},\"ocupationType\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"salariedDetail\":{\"averageBankBalance\":0,\"designation\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"doctorRegistrationNumber\":\"string\",\"empSectorService\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"employerName\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"employerNameOther\":\"string\",\"employerType\":0,\"experience\":\"string\",\"hospital\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"hospitalNameOther\":\"string\",\"netSalary\":\"string\",\"otherSpecialization\":\"string\",\"practiceType\":\"string\",\"principalIndustry\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"qualification\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"regCouncil\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"specialization\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"subEmployerType\":0,\"workExperienceInMonths\":0,\"yearOfGraduation\":0,\"yearOfPostGraduation\":0}},\"profileDetails\":{\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"name\":\"string ABCDA XSDE\",\"panNumber\":\"string\",\"personalEmailId\":\"string\",\"residenceType\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"}},\"requiredLoanAmount\":0,\"residencePincode\":{\"city\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"country\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"negativeAreaFlag\":true,\"oglFlag\":true,\"pincode\":\"string\",\"state\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"}}}",
				HashMap.class);
		Mockito.when(execution.getVariable(Mockito.eq(CreditBusinessConstants.REQUEST))).thenReturn(request);
		when(publisherService.publish(Mockito.anyString(), Mockito.any()))
				.thenThrow(new AuthorizationErrorException("unauthorized"));
		bmrTwoListener.publishEvent(execution);
	}

}
