package com.bajaj.markets.credit.business.datasource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.OfferApiRequest;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@SpringBootConfiguration
@SpringBootTest
public class OfferDataSourceServiceTest {

	@Mock
	CreditBusinessHelper creditBusinessHelper;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	DataSourceRegistry dataSourceRegistry;
		
	@Mock
	private Executor customExecutor;
	
	OfferDataSourceService offerDataSourceService;
	
	private Map<String, String> dataSourceCfgMap;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		dataSourceCfgMap = new HashMap<>();
		dataSourceCfgMap.put("OMPL", "ProspectDataSource,ApplicantDataSource");
		ListableBeanFactory listableBeanFactory = Mockito.mock(ListableBeanFactory.class);
		offerDataSourceService = new OfferDataSourceService(listableBeanFactory);
		ReflectionTestUtils.setField(offerDataSourceService, "logger", logger);
		ReflectionTestUtils.setField(offerDataSourceService, "dataSourceRegistry", dataSourceRegistry);
		ReflectionTestUtils.setField(offerDataSourceService, "dataSourceCfgMap", dataSourceCfgMap);
		ReflectionTestUtils.setField(offerDataSourceService, "customExecutor", customExecutor);
	}	
	
	@Test
	public void processOfferDataTest() {
		List<DataSource> dataSourceList = new ArrayList<>();
		ProspectDataSource prospectDataSource = new ProspectDataSource();
		ApplicantDataSource applicantDataSource = new ApplicantDataSource();
		dataSourceList.add(prospectDataSource);
		dataSourceList.add(applicantDataSource);
		Mockito.when(dataSourceRegistry.getDataSouces()).thenReturn(dataSourceList);
		//ThreadPoolTaskExecutor customExecutor = Mockito.mock(ThreadPoolTaskExecutor.class); 
		//Mockito.when(applicationContext.getBean("customExecutor")).thenReturn(customExecutor);
		Mockito.doAnswer((InvocationOnMock invocation) -> {
			((Runnable) invocation.getArguments()[0]).run();
			return null;
		}).when(customExecutor).execute(Mockito.any(Runnable.class));
		
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataBean.setProductCode("OMPL");
		
		offerDataSourceService.processOfferData(applicantDataBean);
	}
}