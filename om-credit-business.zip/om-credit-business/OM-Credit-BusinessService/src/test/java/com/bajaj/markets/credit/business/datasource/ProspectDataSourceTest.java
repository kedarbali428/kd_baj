package com.bajaj.markets.credit.business.datasource;

import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AddressDetails;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.EmployerMaster;
import com.bajaj.markets.credit.business.beans.Gender;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.LookupCodeResponse;
import com.bajaj.markets.credit.business.beans.LookupCodeValuesResponseBean;
import com.bajaj.markets.credit.business.beans.MaritalStatus;
import com.bajaj.markets.credit.business.beans.NatureOfBusinessMaster;
import com.bajaj.markets.credit.business.beans.OfferApiRequest;
import com.bajaj.markets.credit.business.beans.OfferDetail;
import com.bajaj.markets.credit.business.beans.PersonalDetails;
import com.bajaj.markets.credit.business.beans.ProspectDetails;
import com.bajaj.markets.credit.business.beans.ProspectOfferDetails;
import com.bajaj.markets.credit.business.beans.ResponseBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@SpringBootConfiguration
@SpringBootTest
public class ProspectDataSourceTest {

	@Mock
	CreditBusinessHelper creditBusinessHelper;

	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	BFLLoggerUtil loggerUtil;

	@InjectMocks
	ProspectDataSource prospectDataSource;
			
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(prospectDataSource, "logger", logger);
		ReflectionTestUtils.setField(prospectDataSource, "precedence", "0");
	}	
	
	@Test
	public void registerDataSourceTest() {
		DataSourceRegistry dataSourceRegistry = Mockito.mock(DataSourceRegistry.class);
		prospectDataSource.registerDataSource(dataSourceRegistry);
	}
	
	@Test
	public void initDataSourceTest() {
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		prospectDataSource.initDataSource(applicantDataBean);
	}
	
	@Test
	public void initDataSourceTest_ELSE() {
		ResponseEntity<Object> popOfferRes = new ResponseEntity<Object>(new ResponseBean(popProspectOfferDetails()),
				HttpStatus.OK);
		ResponseEntity<Object> popMarrital = new ResponseEntity<Object>(popMaritalStat(), HttpStatus.NOT_FOUND);
		ResponseEntity<Object> popGender = new ResponseEntity<Object>(popGenderMas(), HttpStatus.NOT_FOUND);
		ResponseEntity<Object> popAnnual = new ResponseEntity<Object>(popLookupCodeAnnual(), HttpStatus.NOT_FOUND);
		ResponseEntity<Object> popNOb = new ResponseEntity<Object>(popNOB(), HttpStatus.NOT_FOUND);
		ResponseEntity<Object> popLocationaddress = new ResponseEntity<Object>(popLocationAddressBean(), HttpStatus.NOT_FOUND);
		ResponseEntity<Object> branch = new ResponseEntity<Object>(popNOB(), HttpStatus.NOT_FOUND);

		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		
		doReturn(popOfferRes).doReturn(popMarrital).doReturn(popGender).doReturn(popLocationaddress).doReturn(branch).doReturn(popAnnual).doReturn(popNOb).when(creditBusinessHelper)
				.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
						Mockito.any());
		prospectDataSource.initDataSource(applicantDataBean);
	}
	
	@Test
	public void initDataSourceTest_ELSE1() {
		ResponseEntity<Object> popOfferRes = new ResponseEntity<Object>(new ResponseBean(popProspectOfferDetails1()),
				HttpStatus.OK);
		ResponseEntity<Object> popMarrital = new ResponseEntity<Object>(popMaritalStat(), HttpStatus.NOT_FOUND);
		ResponseEntity<Object> popGender = new ResponseEntity<Object>(popGenderMas(), HttpStatus.NOT_FOUND);
		ResponseEntity<Object> popAnnual = new ResponseEntity<Object>(popLookupCodeAnnual(), HttpStatus.NOT_FOUND);
		ResponseEntity<Object> popNOb = new ResponseEntity<Object>(popNOB(), HttpStatus.NOT_FOUND);
		ResponseEntity<Object> popLocationaddress = new ResponseEntity<Object>(popLocationAddressBean(), HttpStatus.NOT_FOUND);
		ResponseEntity<Object> branch = new ResponseEntity<Object>(popNOB(), HttpStatus.NOT_FOUND);
		
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		
		doReturn(popOfferRes).doReturn(popMarrital).doReturn(popGender).doReturn(popLocationaddress).doReturn(branch).doReturn(popAnnual).doReturn(popNOb).when(creditBusinessHelper)
				.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
						Mockito.any());
		prospectDataSource.initDataSource(applicantDataBean);
	}
	
	@Test
	public void initDataSourceTest_SEMP() {
		ResponseEntity<Object> popOfferRes = new ResponseEntity<Object>(new ResponseBean(popProspectOfferDetails()),
				HttpStatus.OK);
		ResponseEntity<Object> popMarrital = new ResponseEntity<Object>(popMaritalStat(), HttpStatus.OK);
		ResponseEntity<Object> popGender = new ResponseEntity<Object>(popGenderMas(), HttpStatus.OK);
		ResponseEntity<Object> popAnnual = new ResponseEntity<Object>(popLookupCodeAnnual(), HttpStatus.OK);
		ResponseEntity<Object> popNOb = new ResponseEntity<Object>(popNOB(), HttpStatus.OK);
		ResponseEntity<Object> popLocationaddress = new ResponseEntity<Object>(popLocationAddressBean(), HttpStatus.OK);
		ResponseEntity<Object> branch = new ResponseEntity<Object>(popNOB(), HttpStatus.OK);
		
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		
		doReturn(popOfferRes).doReturn(popMarrital).doReturn(popGender).doReturn(popLocationaddress).doReturn(branch).doReturn(popAnnual).doReturn(popNOb).when(creditBusinessHelper)
				.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
						Mockito.any());
		prospectDataSource.initDataSource(applicantDataBean);
	}
	
	@Test
	public void initDataSourceTest_SALR() {
		ResponseEntity<Object> popOfferRes = new ResponseEntity<Object>(new ResponseBean(popProspectOfferDetails()),
				HttpStatus.OK);
		ResponseEntity<Object> popMarrital = new ResponseEntity<Object>(popMaritalStat(), HttpStatus.OK);
		ResponseEntity<Object> popGender = new ResponseEntity<Object>(popGenderMas(), HttpStatus.OK);
		ResponseEntity<Object> popAnnual = new ResponseEntity<Object>(popLookupCodeAnnual(), HttpStatus.OK);
		ResponseEntity<Object> popNOb = new ResponseEntity<Object>(popNOB(), HttpStatus.OK);
		ResponseEntity<Object> popLocationaddress = new ResponseEntity<Object>(popLocationAddressBean(), HttpStatus.OK);
		ResponseEntity<Object> branch = new ResponseEntity<Object>(popNOB(), HttpStatus.OK);
		ResponseEntity<Object> popEmployer = new ResponseEntity<Object>(popEmployer(), HttpStatus.OK);
		
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("SAL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		
		doReturn(popOfferRes).doReturn(popMarrital).doReturn(popGender).doReturn(popEmployer).doReturn(popLocationaddress).doReturn(branch).doReturn(popAnnual).doReturn(popNOb).when(creditBusinessHelper)
				.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
						Mockito.any());
		prospectDataSource.initDataSource(applicantDataBean);
	}

	private LocationAddressBean popLocationAddressBean() {
		LocationAddressBean locationResponseBean = new LocationAddressBean();
		locationResponseBean.setCityId(12l);
		locationResponseBean.setStateId(123l);
		locationResponseBean.setPinId(123l);
		locationResponseBean.setCountryId(123l);
		return locationResponseBean;
	}

	private LookupCodeResponse popLookupCodeAnnual() {
		LookupCodeResponse lookupCodeResponse = new LookupCodeResponse();
		List<LookupCodeValuesResponseBean> list = new ArrayList<>();
		LookupCodeValuesResponseBean codeValuesResponseBean = new LookupCodeValuesResponseBean();
		codeValuesResponseBean.setCode("ANNUALTURNOVER");
		codeValuesResponseBean.setKey(1);
		codeValuesResponseBean.setValue("12345");
		list.add(codeValuesResponseBean);
		lookupCodeResponse.setLookupValuesResponseList(list);
		return lookupCodeResponse;
	}
	
	private ProspectOfferDetails popProspectOfferDetails() {
		ProspectOfferDetails pro = new ProspectOfferDetails();
		List<ProspectDetails> proslist = new ArrayList<>();
		proslist.add(popProspectDetails());
		pro.setProspectDetails(proslist);
		return pro;
	}
	
	private ProspectOfferDetails popProspectOfferDetails1() {
		ProspectOfferDetails pro = new ProspectOfferDetails();
		List<ProspectDetails> proslist = new ArrayList<>();

		ProspectDetails prospectDetails = new ProspectDetails();
		prospectDetails.setAddressDetails(popAddressList());
		prospectDetails.setPersonalDetails(personalDetails());
	
		proslist.add(prospectDetails);
		pro.setProspectDetails(proslist);
		return pro;
	}

	private ProspectDetails popProspectDetails() {
		ProspectDetails prospectDetails = new ProspectDetails();
		prospectDetails.setAddressDetails(popAddressList());
		prospectDetails.setPersonalDetails(personalDetails());
		prospectDetails.setOfferDetails(popOfferDetails());
		return prospectDetails;
	}

	private PersonalDetails personalDetails() {
		PersonalDetails personalDetails = new PersonalDetails();
		personalDetails.setAnnualTurnover("12345");
		personalDetails.setGender("Male");
		personalDetails.setMaritalStatus("Married");
		personalDetails.setBusinessVintage("1-2");
		personalDetails.setPincode("411014");
		personalDetails.setDob("02-Apr-83");
		personalDetails.setPersonalEmailId("test@mail.com");
		personalDetails.setOfficeEmailID("o@office.com");
		personalDetails.setNatureOfBusiness("nob");
		personalDetails.setPan("ANGVD3456N");
		personalDetails.setCompanyName("Hdfc Bank");
		return personalDetails;
	}

	private List<AddressDetails> popAddressList() {
		List<AddressDetails> addList = new ArrayList<>();
		AddressDetails addressDetails=new AddressDetails();
		addressDetails.setAddressLine1("add");
		addressDetails.setAddressLine2("123");
		addressDetails.setAddressLine3("");
		addressDetails.setAddressType("");
		addressDetails.setCity("");
		addressDetails.setPinCode("411014");
		addressDetails.setState("");
		addList.add(addressDetails);
		return addList;
	}

	private List<OfferDetail> popOfferDetails() {
		List<OfferDetail> offList = new ArrayList<>();
		OfferDetail offerDetail = new OfferDetail();
		offerDetail.setBtBankCategory("");
		offerDetail.setExpiryDate("");
		offerDetail.setFinalObligations(BigDecimal.ONE);
		offerDetail.setGenerationRule("");
		offerDetail.setLnISBaseRate(BigDecimal.ONE);
		offerDetail.setLnTLBaseRate(BigDecimal.ONE);
		offerDetail.setNetMonthlySalary(BigDecimal.ONE);
		offerDetail.setOfferAmount(BigDecimal.ONE);
		offerDetail.setOfferBaseRate(BigDecimal.ONE);
		offerDetail.setOfferBranch("");
		offerDetail.setOfferId("");
		offerDetail.setSubProdTypeKey(BigDecimal.ONE);
		offerDetail.setRiskOffertype("SOL PF");
		offList.add(offerDetail);
		return offList;

	}

	private List<MaritalStatus> popMaritalStat() {
		List<MaritalStatus> maritalStat = new ArrayList<>();
		MaritalStatus maritalStatus = new MaritalStatus();
		maritalStatus.setMaritalStatusCode("M");
		maritalStatus.setMaritalStatusKey(1l);
		maritalStatus.setMaritalStatusValue("Married");
		maritalStat.add(maritalStatus);
		return maritalStat;
	}

	private List<Gender> popGenderMas() {
		List<Gender> gen = new ArrayList<>();
		Gender gender = new Gender();
		gender.setGenderCode("M");
		gender.setGenderKey(1l);
		gender.setGenderValue("Male");
		gen.add(gender);
		return gen;
	}

	private List<NatureOfBusinessMaster> popNOB() {
		List<NatureOfBusinessMaster> nob = new ArrayList<>();
		NatureOfBusinessMaster businessMaster = new NatureOfBusinessMaster();
		businessMaster.setNatureOfBusinessCode("");
		businessMaster.setNatureOfBusinessValue("nob");
		businessMaster.setNatureOfBusinessKey(1l);
		nob.add(businessMaster);
		return nob;
	}
	
	private List<EmployerMaster> popEmployer() {
		List<EmployerMaster> employerMasters = new ArrayList<>();
		EmployerMaster employerMaster = new EmployerMaster();
		employerMaster.setCityKey(123l);
		employerMaster.setCountryKey(123l);
		employerMaster.setEmployerKid("tets");
		employerMaster.setEmployerTypeKey(123l);
		employerMaster.setEmprMastAddLine1("test");
		employerMaster.setEmprMastAddLine2("test");
		employerMaster.setEmprMastAddStreet("test");
		employerMaster.setEmprMastAllocationType("test");
		employerMaster.setEmprMastCategory("test");
		employerMaster.setEmprMastClass("test");
		employerMaster.setEmprMastClassCode("test");
		employerMaster.setEmprMastContactPersonName("test");
		employerMaster.setEmprMastContactPersonNumber("test");
		employerMaster.setEmprMastCorpidNo("test");
		employerMaster.setEmprMastEmailAddress("test");
		employerMaster.setEmprMastEmailDomains("test");
		employerMaster.setEmprMasterFax("test");
		employerMaster.setEmprMasterId(123L);
		employerMaster.setEmprMasterName("Hdfc Bank");
		employerMaster.setEmprMasterPhone("test");
		employerMaster.setEmprMastEstablishmentDate(new Timestamp(System.currentTimeMillis()));
		employerMaster.setEmprMastFlatNumber("test");
		employerMaster.setEmprMastHouseNumber("test");
		employerMaster.setEmprMastPostboxNumber("test");
		employerMaster.setEmprMastPrincipalBusActivity("test");
		employerMaster.setEmprMastRegofComp("test");
		employerMaster.setEmprMastRegState("test");
		employerMaster.setEmprMastStatus("test");
		employerMaster.setEmprMastSubcategory("test");
		employerMaster.setEmprMasttelexno("test");
		employerMaster.setEmprWeightage(BigDecimal.ONE);
		employerMaster.setIndMastKey(123l);
		employerMaster.setIsActive(1);
		employerMaster.setPincodeKey(123l);
		employerMaster.setStateKey(123l);
		employerMasters.add(employerMaster);
		return employerMasters;
	}
}