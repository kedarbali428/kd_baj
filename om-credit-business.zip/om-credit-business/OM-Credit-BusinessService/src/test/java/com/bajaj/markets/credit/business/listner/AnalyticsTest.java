package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@SpringBootConfiguration
@SpringBootTest
public class AnalyticsTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	Analytics analytics;

	@InjectMocks
	McpCheck mcpCheck;
	
	@Mock
	CreditBusinessApiCallsHelper apiCallsHelper;

	@Mock
	MasterDataRedisClientHelper masterDataRedisHelper;
	
	private Object json;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(mcpCheck, "masterDataRedisHelper", masterDataRedisHelper);
		ReflectionTestUtils.setField(analytics, "mcpCheck", mcpCheck);
		Gson g = new Gson();
		json = g.fromJson("{\r\n" + "  \"additionalCibilFlag\": 0,\r\n" + "  \"additionalParameterDetail\": {\r\n" + "    \"utmCampaign\": \"string\",\r\n"
				+ "    \"utmChannel\": \"string\",\r\n" + "    \"utmContent\": \"string\",\r\n" + "    \"utmMedium\": \"string\",\r\n"
				+ "    \"utmSource\": \"string\",\r\n" + "    \"utmTerm\": \"string\"\r\n" + "  },\r\n" + "  \"addressList\": [\r\n" + "    {\r\n"
				+ "      \"addressKey\": \"string\",\r\n" + "      \"addressLine1\": \"string\",\r\n" + "      \"addressLine2\": \"string\",\r\n"
				+ "      \"addressSource\": \"string\",\r\n" + "      \"addressTypeKey\": \"string\",\r\n" + "      \"cityKey\": \"string\",\r\n"
				+ "      \"countryKey\": \"string\",\r\n" + "      \"pincode\": \"string\",\r\n" + "      \"pincodeKey\": \"string\",\r\n"
				+ "      \"resiType\": \"string\",\r\n" + "      \"stateKey\": \"string\",\r\n" + "      \"verification\": {\r\n"
				+ "        \"isVerified\": true,\r\n" + "        \"verificationDate\": \"2020-05-29T06:53:48.138Z\",\r\n"
				+ "        \"verificationReference\": 0,\r\n" + "        \"verificationSource\": \"string\",\r\n" + "        \"verifiedFor\": \"string\"\r\n"
				+ "      }\r\n" + "    }\r\n" + "  ],\r\n" + "  \"appScoreDetails\": {\r\n" + "    \"finalScore\": 0,\r\n" + "    \"lrScore\": 0,\r\n"
				+ "    \"miScore\": 0\r\n" + "  },\r\n" + "  \"estimatedNetMonthlySalaryDetails\": [\r\n" + "    {\r\n" + "      \"salaryAmount\": 0,\r\n"
				+ "      \"salarySource\": \"string\"\r\n" + "    }\r\n" + "  ],\r\n" + "  \"existingCustomerFlag\": true,\r\n"
				+ "  \"mcpAddressDetails\": [\r\n" + "    {\r\n" + "      \"addressTypeKey\": \"string\",\r\n" + "      \"pinCodeKey\": \"string\",\r\n"
				+ "      \"principleProductDetails\": [\r\n" + "        {\r\n" + "          \"bflApplicableLocationFlag\": true,\r\n"
				+ "          \"dedupeJson\": \"string\",\r\n" + "          \"deviationCodes\": [\r\n" + "            \"string\"\r\n" + "          ],\r\n"
				+ "          \"employerCat\": \"string\",\r\n" + "          \"employerType\": \"string\",\r\n" + "          \"existingCustomerType\": true,\r\n"
				+ "          \"offerDetails\": [\r\n" + "            {\r\n" + "              \"isBaseRate\": 0,\r\n"
				+ "              \"isOfferAvailable\": true,\r\n" + "              \"offerAcceptedStatus\": \"string\",\r\n"
				+ "              \"offerAmount\": 0,\r\n" + "              \"offerExpirayDate\": \"string\",\r\n"
				+ "              \"offerExpiryDate\": \"string\",\r\n" + "              \"offerID\": \"string\",\r\n"
				+ "              \"offerProgramCode\": \"string\",\r\n" + "              \"offerSource\": \"string\",\r\n"
				+ "              \"offerType\": \"string\",\r\n" + "              \"riskClassification\": \"string\",\r\n"
				+ "              \"riskOfferType\": \"string\",\r\n" + "              \"tlBaseRate\": 0\r\n" + "            }\r\n" + "          ],\r\n"
				+ "          \"pincode\": {\r\n" + "            \"negativeAreaFlag\": true,\r\n" + "            \"oglFlag\": true\r\n" + "          },\r\n"
				+ "          \"principleCustType\": \"string\",\r\n" + "          \"principleProductCode\": \"string\",\r\n"
				+ "          \"rejectCodeList\": [\r\n" + "            \"string\"\r\n" + "          ]\r\n" + "        }\r\n" + "      ]\r\n" + "    }\r\n"
				+ "  ],\r\n" + "  \"occupation\": {\r\n" + "    \"averageBankBlance\": 0,\r\n" + "    \"businessOwnerDetails\": {\r\n"
				+ "      \"anualTurnover\": {\r\n" + "        \"code\": \"string\",\r\n" + "        \"key\": 0,\r\n" + "        \"value\": \"string\"\r\n"
				+ "      },\r\n" + "      \"averageBankBalance\": 0,\r\n" + "      \"businessName\": \"string\",\r\n" + "      \"businessPan\": \"string\",\r\n"
				+ "      \"businessType\": {\r\n" + "        \"code\": \"string\",\r\n" + "        \"key\": 0,\r\n" + "        \"value\": \"string\"\r\n"
				+ "      },\r\n" + "      \"businessVintage\": {\r\n" + "        \"code\": \"string\",\r\n" + "        \"key\": 0,\r\n"
				+ "        \"value\": \"string\"\r\n" + "      },\r\n" + "      \"gstNumber\": \"string\",\r\n" + "      \"industryType\": {\r\n"
				+ "        \"code\": \"string\",\r\n" + "        \"key\": 0,\r\n" + "        \"value\": \"string\"\r\n" + "      },\r\n"
				+ "      \"natureOfBusiness\": {\r\n" + "        \"code\": \"string\",\r\n" + "        \"key\": 0,\r\n" + "        \"value\": \"string\"\r\n"
				+ "      },\r\n" + "      \"netMonthlyIncome\": \"string\",\r\n" + "      \"profitAfterTax\": 0,\r\n"
				+ "      \"proprieterName\": \"string\",\r\n" + "      \"subindumastkey\": {\r\n" + "        \"code\": \"string\",\r\n"
				+ "        \"key\": 0,\r\n" + "        \"value\": \"string\"\r\n" + "      }\r\n" + "    },\r\n" + "    \"employerType\": \"string\",\r\n"
				+ "    \"ocupationType\": {\r\n" + "      \"code\": \"string\",\r\n" + "      \"key\": 0,\r\n" + "      \"value\": \"string\"\r\n"
				+ "    },\r\n" + "    \"profitAfterTax\": 0,\r\n" + "    \"salariedDetail\": {\r\n" + "      \"designation\": {\r\n"
				+ "        \"code\": \"string\",\r\n" + "        \"key\": 0,\r\n" + "        \"value\": \"string\"\r\n" + "      },\r\n"
				+ "      \"employerName\": {\r\n" + "        \"code\": \"string\",\r\n" + "        \"key\": 0,\r\n" + "        \"value\": \"string\"\r\n"
				+ "      },\r\n" + "      \"employerNameOther\": \"string\",\r\n" + "      \"employerType\": 0,\r\n" + "      \"experience\": \"string\",\r\n"
				+ "      \"netSalary\": \"string\"\r\n" + "    }\r\n" + "  },\r\n" + "  \"panDetails\": {\r\n" + "    \"matchScore\": 0,\r\n"
				+ "    \"nameMatch\": \"string\",\r\n" + "    \"panType\": \"string\"\r\n" + "  },\r\n" + "  \"princialSelectedbyCustomerDetail\": [\r\n"
				+ "    {\r\n" + "      \"applicableMultiplier\": 0,\r\n" + "      \"approvalChances\": \"string\",\r\n" + "      \"bScore\": 0,\r\n"
				+ "      \"baseRate\": {\r\n" + "        \"baseRateCode\": \"string\",\r\n" + "        \"baseRateValue\": 0\r\n" + "      },\r\n"
				+ "      \"dropLineTenor\": 0,\r\n" + "      \"dueDateDetails\": [\r\n" + "        {\r\n" + "          \"dueDate\": 0,\r\n"
				+ "          \"firstDueDate\": \"string\"\r\n" + "        }\r\n" + "      ],\r\n" + "      \"eligibilityAmount\": 0,\r\n"
				+ "      \"eligibilityType\": \"string\",\r\n" + "      \"emiAmount\": 0,\r\n" + "      \"feesList\": [\r\n" + "        {\r\n"
				+ "          \"feeCode\": \"string\",\r\n" + "          \"feesInAmount\": 0,\r\n" + "          \"feesInPercent\": 0\r\n" + "        }\r\n"
				+ "      ],\r\n" + "      \"finalFoir\": 0,\r\n" + "      \"finalMultiplier\": 0,\r\n" + "      \"finalUnsecuredFoir\": 0,\r\n"
				+ "      \"foirEligibilityEmi\": 0,\r\n" + "      \"fppApplicable\": true,\r\n" + "      \"isEligible\": true,\r\n"
				+ "      \"isTenor\": 0,\r\n" + "      \"loanTypeRecommendation\": \"string\",\r\n" + "      \"maxEmiAsPerFoir\": 0,\r\n"
				+ "      \"multiplierEligibility\": 0,\r\n" + "      \"nextDueDateDetails\": [\r\n" + "        {\r\n" + "          \"graceTerm\": 0,\r\n"
				+ "          \"nextDueDate\": \"string\"\r\n" + "        }\r\n" + "      ],\r\n" + "      \"offerAmount\": 0,\r\n"
				+ "      \"offerType\": 0,\r\n" + "      \"pennantloanTypeRecommendation\": \"string\",\r\n" + "      \"perfiosRequired\": true,\r\n"
				+ "      \"preApproved\": \"string\",\r\n" + "      \"principleProductCode\": \"string\",\r\n" + "      \"priorityOrder\": 0,\r\n"
				+ "      \"productSize\": \"string\",\r\n" + "      \"requiredLoanAmount\": 0,\r\n" + "      \"riskOfferType\": \"string\",\r\n"
				+ "      \"roi\": 0,\r\n" + "      \"tenor\": 0\r\n" + "    }\r\n" + "  ],\r\n" + "  \"prodCategory\": {\r\n"
				+ "    \"prodCatCode\": \"string\",\r\n" + "    \"prodCatDesc\": \"string\"\r\n" + "  },\r\n" + "  \"userProfile\": {\r\n"
				+ "    \"applicationKey\": \"string\",\r\n" + "    \"applicationUserAttributeKey\": \"string\",\r\n"
				+ "    \"applicationUserAttributeType\": \"string\",\r\n" + "    \"dateOfBirth\": \"string\",\r\n" + "    \"fatherName\": \"string\",\r\n"
				+ "    \"genderKey\": 0,\r\n" + "    \"maritalStatusKey\": 0,\r\n" + "    \"mobile\": \"string\",\r\n" + "    \"motherName\": \"string\",\r\n"
				+ "    \"name\": {\r\n" + "      \"firstName\": \"string\",\r\n" + "      \"lastName\": \"string\",\r\n"
				+ "      \"middleName\": \"string\",\r\n" + "      \"salutationKey\": 0,\r\n" + "      \"verification\": {\r\n"
				+ "        \"isVerified\": true,\r\n" + "        \"verificationDate\": \"2020-05-29T06:53:48.141Z\",\r\n"
				+ "        \"verificationReference\": 0,\r\n" + "        \"verificationSource\": \"string\",\r\n" + "        \"verifiedFor\": \"string\"\r\n"
				+ "      }\r\n" + "    },\r\n" + "    \"panNumber\": \"string\",\r\n" + "    \"qualification\": \"string\",\r\n"
				+ "    \"residenceTypeKey\": 0\r\n" + "  }\r\n" + "}", JSONObject.class);
	}

	@Test
	public void testPreAppScore() {
		Gson g = new Gson();
		Object resiType = g.fromJson("{\r\n" + "    \"isactive\": 0,\r\n" + "    \"residenceCode\": \"string\",\r\n" + "    \"residenceKey\": 0,\r\n"
				+ "    \"residenceValue\": \"string\"\r\n" + "  }", JSONObject.class);
		List<Object> resiTypeList = new ArrayList<>();
		resiTypeList.add(resiType);

		Object remaritalStatusType = g.fromJson("{\r\n" + "    \"isactive\": 0,\r\n" + "    \"maritalStatusCode\": \"string\",\r\n"
				+ "    \"maritalStatusKey\": 0,\r\n" + "    \"maritalStatusValue\": \"string\"\r\n" + "  }", JSONObject.class);
		List<Object> maritalStatusList = new ArrayList<>();
		maritalStatusList.add(remaritalStatusType);
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(json);
		when(execution.getVariable("maritalStatusList")).thenReturn(maritalStatusList);
		analytics.preAppScore(execution);
	}

	@Test
	public void testPostAppScore() {
		Gson g = new Gson();
		Object output = g.fromJson(
				"{ \"applicationKey\": \"1100000000001929\", \"finalScore\": 845, \"lrScore\": 845, \"mlScore\": 842, \"customerSegment\": null }",
				JSONObject.class);
		when(execution.getVariable(CreditBusinessConstants.PRODUCTCODE)).thenReturn("OMPL");
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		analytics.postAppScore(execution);
	}

	@Test
	public void testPreGetCityForApScore() {
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(json);
		analytics.preGetCityForApScore(execution);
	}

	@Test
	public void testPostGetCityForApScore() {
		Gson g = new Gson();
		Object output = g.fromJson("{\r\n" + "		  \"cityCode\": \"string\",\r\n" + "		  \"cityKey\": 0,\r\n" + "		  \"cityName\": \"string\"}",
				JSONObject.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		analytics.postGetCityForApScore(execution);
	}

	@Test
	public void testPreDerog() {
		when(execution.getVariable(CreditBusinessConstants.PRODUCTCODE)).thenReturn("CC");
		analytics.preDerog(execution);
	}

	@Test
	public void testPostDerog() {
		analytics.postDerog(execution);
	}

	@Test
	public void testPreFetchEmail() {
		analytics.preFetchEmail(execution);
	}

	@Test
	public void testPostFetchEmail() {
		Gson g = new Gson();
		Object output = g.fromJson("{\r\n" + "  \"email\": \"string\",\r\n" + "  \"typeKey\": 0,\r\n" + "  \"verification\": {\r\n"
				+ "    \"isVerified\": true,\r\n" + "    \"verificationDate\": \"2020-05-29T06:53:47.888Z\",\r\n" + "    \"verificationReference\": 0,\r\n"
				+ "    \"verificationSource\": \"string\",\r\n" + "    \"verifiedFor\": \"string\"\r\n" + "  }\r\n" + "}", JSONObject.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		analytics.postFetchEmail(execution);
	}

	@Test
	public void testpreGetObligation() {
		analytics.preGetObligation(execution);
	}

	@Test
	public void testpostGetObligation() {
		analytics.postGetObligation(execution);
	}

	@Test
	public void testPostFetchDerog() {
		analytics.postFetchDerog(execution);
	}

	@Test
	public void testPreSaveObligation_HLBT() {
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1234");
		when(execution.getVariable(CreditBusinessConstants.PRODUCTCODE)).thenReturn("OMSL");
		when(execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT)).thenReturn("HLBT");
		when(execution.getVariable(CreditBusinessConstants.OBLIGATION_AMT)).thenReturn(
				"{\"emiList\":[{\"accountType\":\"02\",\"currentBalance\":\"0\",\"emiAmount\":\"\",\"mob\":\"24.0\",\"highCreditSanctionAmt\":\"11999\",\"reportingShortName\":\"BAJAJ FIN LTD\"},{\"accountType\":\"07\",\"currentBalance\":\"0\",\"emiAmount\":\"4667\",\"mob\":\"5.0\",\"highCreditSanctionAmt\":\"56000\",\"reportingShortName\":\"SBI\"},{\"accountType\":\"44\",\"currentBalance\":\"1479\",\"emiAmount\":\"594\",\"mob\":\"9.0\",\"highCreditSanctionAmt\":\"4799\",\"reportingShortName\":\"HOME CREDIT\"},{\"accountType\":\"01\",\"currentBalance\":\"220238\",\"emiAmount\":\"8290\",\"mob\":\"9.0\",\"highCreditSanctionAmt\":\"250000\",\"reportingShortName\":\"IDFC FIRST BANK\"},{\"accountType\":\"13\",\"currentBalance\":\"2104\",\"emiAmount\":\"\",\"mob\":\"60.0\",\"highCreditSanctionAmt\":\"57600\",\"reportingShortName\":\"BAJAJ FIN LTD\"},{\"accountType\":\"06\",\"currentBalance\":\"17100\",\"emiAmount\":\"3000\",\"mob\":\"59.0\",\"highCreditSanctionAmt\":\"30000\",\"reportingShortName\":\"IDFC FIRST BANK\"},{\"accountType\":\"07\",\"currentBalance\":\"0\",\"emiAmount\":\"\",\"mob\":\"20.0\",\"highCreditSanctionAmt\":\"161000\",\"reportingShortName\":\"SBI\"},{\"accountType\":\"10\",\"currentBalance\":\"22607\",\"emiAmount\":\"\",\"mob\":\"141.0\",\"highCreditSanctionAmt\":\"22607\",\"reportingShortName\":\"ICICI BANK\"},{\"accountType\":\"05\",\"currentBalance\":\"79638\",\"emiAmount\":\"3540\",\"mob\":\"1.0\",\"highCreditSanctionAmt\":\"81000\",\"reportingShortName\":\"HOME CREDIT\"},{\"accountType\":\"07\",\"currentBalance\":\"0\",\"emiAmount\":\"\",\"mob\":\"20.0\",\"highCreditSanctionAmt\":\"70000\",\"reportingShortName\":\"SBI\"}],\"emiSum\":\"11830.0\"}");
		analytics.preSaveObligation(execution);
	}

	@Test
	public void testPreSaveObligation_LAPBT() {
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1234");
		when(execution.getVariable(CreditBusinessConstants.PRODUCTCODE)).thenReturn("OMSL");
		when(execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT)).thenReturn("LAPBT");
		when(execution.getVariable(CreditBusinessConstants.OBLIGATION_AMT)).thenReturn(
				"{\"emiList\":[{\"accountType\":\"06\",\"currentBalance\":\"0\",\"emiAmount\":\"\",\"mob\":\"24.0\",\"highCreditSanctionAmt\":\"11999\",\"reportingShortName\":\"BAJAJ FIN LTD\"},{\"accountType\":\"07\",\"currentBalance\":\"0\",\"emiAmount\":\"4667\",\"mob\":\"5.0\",\"highCreditSanctionAmt\":\"56000\",\"reportingShortName\":\"SBI\"},{\"accountType\":\"02\",\"currentBalance\":\"1479\",\"emiAmount\":\"594\",\"mob\":\"9.0\",\"highCreditSanctionAmt\":\"4799\",\"reportingShortName\":\"HOME CREDIT\"},{\"accountType\":\"44\",\"currentBalance\":\"220238\",\"emiAmount\":\"8290\",\"mob\":\"9.0\",\"highCreditSanctionAmt\":\"250000\",\"reportingShortName\":\"IDFC FIRST BANK\"},{\"accountType\":\"03\",\"currentBalance\":\"2104\",\"emiAmount\":\"\",\"mob\":\"60.0\",\"highCreditSanctionAmt\":\"57600\",\"reportingShortName\":\"BAJAJ FIN LTD\"},{\"accountType\":\"06\",\"currentBalance\":\"17100\",\"emiAmount\":\"3000\",\"mob\":\"59.0\",\"highCreditSanctionAmt\":\"30000\",\"reportingShortName\":\"IDFC FIRST BANK\"},{\"accountType\":\"07\",\"currentBalance\":\"0\",\"emiAmount\":\"\",\"mob\":\"20.0\",\"highCreditSanctionAmt\":\"161000\",\"reportingShortName\":\"SBI\"},{\"accountType\":\"10\",\"currentBalance\":\"22607\",\"emiAmount\":\"\",\"mob\":\"141.0\",\"highCreditSanctionAmt\":\"22607\",\"reportingShortName\":\"ICICI BANK\"},{\"accountType\":\"05\",\"currentBalance\":\"79638\",\"emiAmount\":\"3540\",\"mob\":\"1.0\",\"highCreditSanctionAmt\":\"81000\",\"reportingShortName\":\"HOME CREDIT\"},{\"accountType\":\"07\",\"currentBalance\":\"0\",\"emiAmount\":\"\",\"mob\":\"20.0\",\"highCreditSanctionAmt\":\"70000\",\"reportingShortName\":\"SBI\"}],\"emiSum\":\"11830.0\"}");
		analytics.preSaveObligation(execution);
	}

	@Test
	public void testPreSaveObligation_obligationListEmpty() {
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1234");
		when(execution.getVariable(CreditBusinessConstants.PRODUCTCODE)).thenReturn("OMSL");
		when(execution.getVariable(CreditBusinessConstants.HLPRODUCTINTENT)).thenReturn("HLBT");
		when(execution.getVariable(CreditBusinessConstants.OBLIGATION_AMT)).thenReturn("{\"emiList\":[],\"emiSum\":\"11830.0\"}");
		analytics.preSaveObligation(execution);
	}
	
	@Test
	public void testPreDerogIV() {
		Gson g = new GsonBuilder().serializeNulls().create();
		JSONObject mcpReq = g.fromJson(
				"{\"hlProductIntent\" : \"YES\", \"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69,\"workExperienceInMonths\":null,\"principalIndustry\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null},\"presentBusinessVintage\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000008597\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9907090001\",\"dateOfBirth\":\"1990-02-02\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\",\"applicantKey\":123101},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"6582\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000}],\"appScoreDetails\":{\"finalScore\":834,\"lrScore\":834,\"miScore\":830},\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);
		
		LocationResponseBean pinCode = new LocationResponseBean();
		pinCode.setCityName("TestCity");
		
		when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(pinCode);
		when(execution.getVariable(CreditBusinessConstants.PRODUCTCODE)).thenReturn("OMPL");
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(mcpReq);
		when(execution.getVariable(CreditBusinessConstants.CIBIL_JSON)).thenReturn(new JSONObject());

		analytics.preDerogIV(execution);
	}
	
	@Test
	public void testPreAnalyticsIncomeEstimation() {
		Gson g = new GsonBuilder().serializeNulls().create();
		JSONObject mcpReq = g.fromJson(
				"{\"hlProductIntent\" : \"YES\", \"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69,\"workExperienceInMonths\":null,\"principalIndustry\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null},\"presentBusinessVintage\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000008597\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9907090001\",\"dateOfBirth\":\"1990-02-02\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\",\"applicantKey\":123101},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"6582\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000},{\"salarySource\":\"Perfios\",\"salaryAmount\":110000},{\"salarySource\":\"epcredit\",\"salaryAmount\":130000}],\"appScoreDetails\":{\"finalScore\":834,\"lrScore\":834,\"miScore\":830},\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);
		LocationResponseBean pinCode = new LocationResponseBean();
		pinCode.setCityName("TestCity");
		when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(pinCode);
		when(execution.getVariable(CreditBusinessConstants.PRODUCTTYPE)).thenReturn("OMPL");
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(mcpReq);
		when(execution.getVariable(CreditBusinessConstants.CIBIL_JSON)).thenReturn(new JSONObject());
		analytics.preAnalyticsIncomeEstimation(execution);
	}

	@Test
	public void testPostAnalyticsIncomeEstimation() {
		Gson g = new Gson();
		Object output = g.fromJson(
				"{ \"applicationId\": \"1100000000001929\", \"estimatedIncome\": 845111,\"finalIncome\":232121,\"applicantId\": \"111\" }",
				JSONObject.class);
		when(execution.getVariable(CreditBusinessConstants.ESTIMATED_INCOME)).thenReturn("845111");
		when(execution.getVariable(CreditBusinessConstants.FINAL_INCOME)).thenReturn("231121");
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		analytics.postAnalyticsIncomeEstimation(execution);
	}
	
	@Test
	public void testPostAnalyticsIncomeEstimation_exc() {
		Gson g = new Gson();
		Object output = g.fromJson(
				"{ \"applicationId\": \"1100000000001929\", \"estimatedIncome\": 845111,\"applicantId\": \"111\" }",
				JSONObject.class);
		when(execution.getVariable(CreditBusinessConstants.API_EXCEPTION_ARISE)).thenReturn(true);
		when(execution.getVariable(CreditBusinessConstants.ESTIMATED_INCOME)).thenReturn("845111");
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		analytics.postAnalyticsIncomeEstimation(execution);
	}
	
	@Test
	public void testPreAnalyticsIncomeEstimationVer2() {
		Gson g = new GsonBuilder().serializeNulls().create();
		JSONObject mcpReq = g.fromJson(
				"{\"hlProductIntent\" : \"YES\", \"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69,\"workExperienceInMonths\":null,\"principalIndustry\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null},\"presentBusinessVintage\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000008597\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9907090001\",\"dateOfBirth\":\"1990-02-02\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\",\"applicantKey\":123101},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"6582\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"princialSelectedbyCustomerDetail\":[],\"appScoreDetails\":{\"finalScore\":834,\"lrScore\":834,\"miScore\":830},\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);
		JSONObject estimatedSalary = new JSONObject();
		estimatedSalary.put("salary", 123.0d);
		estimatedSalary.put("salarySource", "BFLPERFIOS");
		JSONObject estimatedSalary1 = new JSONObject();
		estimatedSalary1.put("salary", 123.0d);
		estimatedSalary1.put("salarySource", CreditBusinessConstants.JOURNEY);
		JSONObject estimatedSalary2 = new JSONObject();
		estimatedSalary2.put("salary", 123.0d);
		estimatedSalary2.put("salarySource", CreditBusinessConstants.SALARYSOURCE_EPCREDIT);
		ArrayList<JSONObject> estimatedSalaries = new ArrayList<JSONObject>();
		estimatedSalaries.add(estimatedSalary);
		estimatedSalaries.add(estimatedSalary1);
		estimatedSalaries.add(estimatedSalary2);
		LocationResponseBean pinCode = new LocationResponseBean();
		pinCode.setCityName("TestCity");
		when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(pinCode);
		when(execution.getVariable(CreditBusinessConstants.PRODUCTTYPE)).thenReturn("OMPL");
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(mcpReq);
		when(execution.getVariable(CreditBusinessConstants.CIBIL_JSON)).thenReturn(new JSONObject());
		when(execution.getVariable(CreditBusinessConstants.SALARY_DETAILS)).thenReturn(estimatedSalaries);	
		analytics.preAnalyticsIncomeEstimationVer2(execution);
	}
      
}
