package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_TYPE;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.NAME;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.JSONException;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.BankDetailsReponse;
import com.bajaj.markets.credit.business.beans.BrePreferredMandateResponse;
import com.bajaj.markets.credit.business.beans.EmandateResponse;
import com.bajaj.markets.credit.business.beans.MandateBreRequest;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.service.CreditBusinessBankDetailsService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
public class BankDetailsListenerTests {

	@InjectMocks
	private BankDetailsListener bankDetailsListener;

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;
	
	@Mock
	private CreditBusinessBankDetailsService creditBusinessBankDetailsService;
	
	@Mock
	private CustomDefaultHeaders customDefaultHeaders;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testPreSaveBankDetails() {
		JSONObject branchDetails = new JSONObject();
		branchDetails.put("branchKey", 23.0d);
		branchDetails.put("bankMasterKey", 1001.0d);
		
		JSONObject bankDetails = new JSONObject();
		bankDetails.put("mandateReference", "1234");
		bankDetails.put("mandateAddedBy", "journey");

		when(execution.getVariable(Mockito.anyString())).thenReturn(branchDetails).thenReturn(bankDetails);

		bankDetailsListener.preSaveBankDetails(execution);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testPostSaveBankDetails() {
		JSONObject bankDetailsReponse = new JSONObject();
		bankDetailsReponse.put("bankDetailsKey", 1.0d);

		when(execution.getVariable(Mockito.anyString())).thenReturn(bankDetailsReponse);

		bankDetailsListener.postSaveBankDetails(execution);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testFetchPrimaryUserProfile() {
		List<JSONObject> userProfiles = new ArrayList<JSONObject>();
		JSONObject profile = new JSONObject();
		JSONObject name = new JSONObject();
		name.put("firstName", "fname");
		name.put("middleName", null);
		name.put("lastName", "lname");
		profile.put(APPLICATION_USER_ATTRIBUTE_TYPE, "1");
		profile.put(NAME, name);
		userProfiles.add(profile);

		when(execution.getVariable(Mockito.anyString())).thenReturn(userProfiles);

		bankDetailsListener.fetchPrimaryUserProfile(execution);
	}

	@Test
	public void testPreMandateCreate() {
		when(execution.getVariable(Mockito.anyString())).thenReturn(new JSONObject());
		bankDetailsListener.preMandateCreation(execution);
	}
	
	@Test
	public void testGetBankDetails() {
		when(execution.getVariable(Mockito.anyString())).thenReturn(new ArrayList<JSONObject>());
		bankDetailsListener.postGetBankDetails(execution);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testPostMandateGet_RefAvailalble() {
		JSONObject mandateDet = new JSONObject();
		mandateDet.put("mandateReference", "1234");
		ArrayList<JSONObject> mandateDets = new ArrayList<JSONObject>();
		mandateDets.add(mandateDet);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(null).thenReturn(mandateDets);
		bankDetailsListener.postMandateGet(execution, true);
	}
	
	@Test
	public void testPostMandateGet_RefNotAvailalble() {
		JSONObject mandateDet = new JSONObject();
		ArrayList<JSONObject> mandateDets = new ArrayList<JSONObject>();
		mandateDets.add(mandateDet);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(false).thenReturn(mandateDets);
		bankDetailsListener.postMandateGet(execution, true);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testPostMandateGet_RefAvailalble_ChildApp() {
		JSONObject mandateDet = new JSONObject();
		mandateDet.put("mandateReference", "1234");
		ArrayList<JSONObject> mandateDets = new ArrayList<JSONObject>();
		mandateDets.add(mandateDet);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(null).thenReturn(mandateDets);
		bankDetailsListener.postMandateGet(execution, false);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testPostBreCall() {
		JSONObject preferredMandate = new JSONObject();
		preferredMandate.put("mandateRequiredFlag", true);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(preferredMandate);
		bankDetailsListener.postBreCall(execution);
	}
	
	@Test
	public void testPreMandateUpdate() throws JsonMappingException, JsonProcessingException, JSONException {
		org.json.JSONObject brePreferredMandateJson = new org.json.JSONObject("{\"bankDetailsEditableFlag\":true,\"mandateRequiredFlag\":false,\"bankDetailsTobeConsidered\":null,\"accountNumberEditFlag\":null,\"mandatePartner\":null,\"eMandateFlag\":null,\"principal\":null,\"mandateDetails\":{\"mandateExpiryDate\":\"2040-02-23 00:00:00.0\",\"mandateRegistrationNumber\":\"BFL500021115\",\"maxLimit\":50000,\"balanceLimit\":50000,\"accountNo\":522702010009322,\"bankBranchName\":null,\"bankName\":\"UNION BANK OF INDIA\",\"cName\":\"NEELAKANTA M\",\"ifscCode\":null,\"micrCode\":\"560026023\",\"sourceName\":\"BMR\",\"mandateCreatedsourceName\":\"BMR\",\"mandatereference\":\"2\",\"channelType\":null,\"channelMandateReferenceId\":null}\n" + 
				",\"bankDetails\":{\"accountNo\":\"522702010009322\",\"bankBranchName\":null,\"bankName\":null,\"cName\":\"MADAKA NEELAKANTA\",\"ifscCode\":null,\"micrCode\":null,\"sourceName\":\"PERFIOS\",\"mandateAddedby\":null,\"mandatereference\":null}}");
		
		ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		BrePreferredMandateResponse brePreferredMandateResponse = mapper.readValue(brePreferredMandateJson.toString(), BrePreferredMandateResponse.class);
		
		JSONObject preferredMandate = CreditBusinessHelper.getJSONObject(brePreferredMandateResponse);
		
		when(execution.getVariable("preferredMandate")).thenReturn(preferredMandate);
		bankDetailsListener.preMandateUpdate(execution);
	}
	
	@Test
	public void testPrepareBreRequest_EmandateParentNotAvailable() {
		List<BankDetailsReponse> bankDetailsReponses = new ArrayList<BankDetailsReponse>();
		List<EmandateResponse> emandateResponses = new ArrayList<EmandateResponse>();
		MandateBreRequest mandateBreRequest = new MandateBreRequest();
		
		doReturn(bankDetailsReponses).doReturn(emandateResponses).doReturn(null).doReturn(1234l).when(execution).getVariable(Mockito.anyString());
		when(creditBusinessBankDetailsService.createBreRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(mandateBreRequest);
		bankDetailsListener.prepareBreRequest(execution);
	}
	
	@Test
	public void testPrepareBreRequest_EmandateChildNotAvailable() {
		List<BankDetailsReponse> bankDetailsReponses = new ArrayList<BankDetailsReponse>();
		List<EmandateResponse> emandateResponses = new ArrayList<EmandateResponse>();
		MandateBreRequest mandateBreRequest = new MandateBreRequest();
		
		doReturn(bankDetailsReponses).doReturn(null).doReturn(emandateResponses).doReturn(1234l).when(execution).getVariable(Mockito.anyString());
		when(creditBusinessBankDetailsService.createBreRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(mandateBreRequest);
		bankDetailsListener.prepareBreRequest(execution);
	}
}
