package com.bajaj.markets.credit.business;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.web.context.request.RequestAttributes;

public class CustomRequestScopeAttributeTest {

	@InjectMocks
	private CustomRequestScopeAttribute customRequestScopeAttribute;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAttribute() {
		customRequestScopeAttribute.setAttribute("person", new Object(), RequestAttributes.SCOPE_REQUEST);
		assertNotNull(customRequestScopeAttribute.getAttribute("person", RequestAttributes.SCOPE_REQUEST));
	}

	@Test
	public void testGetAttributeFromSessionScope() {
		customRequestScopeAttribute.setAttribute("person", new Object(), RequestAttributes.SCOPE_SESSION);
		assertNull(customRequestScopeAttribute.getAttribute("person", RequestAttributes.SCOPE_SESSION));
	}

	@Test
	public void testRemoveAttribute() {
		customRequestScopeAttribute.removeAttribute("person", RequestAttributes.SCOPE_REQUEST);
	}

	@Test
	public void testGetAttributeNames() {
		customRequestScopeAttribute.getAttributeNames(RequestAttributes.SCOPE_REQUEST);
	}

	@Test
	public void testRegisterDestructionCallback() {
		customRequestScopeAttribute.registerDestructionCallback("person", () -> {
		}, RequestAttributes.SCOPE_REQUEST);
	}

	@Test
	public void testResolveReference() {
		assertNull(customRequestScopeAttribute.resolveReference(""));
	}

	@Test
	public void testGetSessionId() {
		assertNull(customRequestScopeAttribute.getSessionId());
	}

	@Test
	public void testGetSessionMutex() {
		assertNull(customRequestScopeAttribute.getSessionMutex());
	}
}
