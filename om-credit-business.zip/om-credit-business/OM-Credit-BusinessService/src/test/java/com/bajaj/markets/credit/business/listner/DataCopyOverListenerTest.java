package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;
import org.activiti.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@SpringBootTest
public class DataCopyOverListenerTest {

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	DataCopyOverListener listener;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testpreVasApplicationCreate() {
		listener.preAdditionalDetailsChildToParent(execution);
	}
	
	@Test
	public void testpreBankDetailsChildToParent() {
		listener.preBankDetailsChildToParent(execution);
	}
	
	@Test
	public void testpreBankDetailsParentToChild() {
		listener.preBankDetailsParentToChild(execution);
	}
	
	@Test
	public void testdefaultChildToParent() {
		listener.defaultChildToParent(execution);
	}
	
	@Test
	public void testginAdditionalDetailChildToParent() {
		listener.ginAdditionalDetailChildToParent(execution);
	}
	
	@Test
	public void testAddressCopyOverChildToParent() {
		listener.addressCopyOverChildToParent(execution);
	}
	
	@Test
	public void testPrePersonalEmailParentToChild() {
		listener.prePersonalEmailParentToChild(execution);
	}
	
	@Test
	public void testPreAdditionalDetailsChildToParentAxisLoans() {
		listener.preAdditionalDetailsChildToParentAxisLoans(execution);
	}
	
	@Test
	public void testPreCommonAdditionalDetailLoanChildToParent() {
		when(execution.getVariable("currentAddressUpdateFlag")).thenReturn(Boolean.TRUE);
		when(execution.getVariable("workAddressUpdateFlag")).thenReturn(Boolean.TRUE);
		when(execution.getVariable("permanentAddressUpdateFlag")).thenReturn(Boolean.TRUE);
		when(execution.getVariable("userProfileUpdateFlag")).thenReturn(Boolean.TRUE);
		when(execution.getVariable("customerReferenceUpdateFlag")).thenReturn(Boolean.TRUE);
		when(execution.getVariable("workEmailUpdateFlag")).thenReturn(Boolean.TRUE);
		when(execution.getVariable("loanPurposeUpdateFlag")).thenReturn(Boolean.TRUE);
		when(execution.getVariable("personalEmailUpdateFlag")).thenReturn(Boolean.TRUE);
		when(execution.getVariable("experienceUpdateFlag")).thenReturn(Boolean.TRUE);
		when(execution.getVariable("designationUpdateFlag")).thenReturn(Boolean.TRUE);
		listener.preCommonAdditionalDetailLoanChildToParent(execution);
	}
}