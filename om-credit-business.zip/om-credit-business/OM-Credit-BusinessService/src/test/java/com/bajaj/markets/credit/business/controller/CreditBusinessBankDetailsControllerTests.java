package com.bajaj.markets.credit.business.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.BankDetails;
import com.bajaj.markets.credit.business.beans.validator.AccountTypeValidator.AccountType;
import com.bajaj.markets.credit.business.service.CreditBusinessBankDetailsService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@SpringBootConfiguration
public class CreditBusinessBankDetailsControllerTests {

	@InjectMocks
	private CreditBusinessBankDetailsController creditBusinessBankDetailsController;
	
	@Mock
	private BFLLoggerUtilExt logger;
	
	@Mock
	private CreditBusinessBankDetailsService creditBusinessBankDetailsService;
	
	private Validator validator;
	
	private MockMvc mockMvc;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessBankDetailsController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class)
				/* .addPlaceholderValue("/v1/income/verification", "/v1/income/verification") */.build();

		validator = Validation.buildDefaultValidatorFactory().getValidator();
		ReflectionTestUtils.setField(creditBusinessBankDetailsController, "validator", validator);
	}
	
	@Test
	public void testSaveBankDetails() throws Exception {
		BankDetails bankDetailsRequest = new BankDetails();
		bankDetailsRequest.setAccountNumber("123456789");
		bankDetailsRequest.setBankAccountHolderName("Account Holder Name");
		bankDetailsRequest.setBankAccountType(AccountType.SAVINGS.toString());
		bankDetailsRequest.setIfscCode("IFSCCODE");
		
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/bankdetails", 1235l).contentType(MediaType.APPLICATION_JSON).content(prepareRequestJsonString(bankDetailsRequest)).headers(new HttpHeaders())).andExpect(status().isCreated());
	}
	
	@Test
	public void testSaveBankDetails_AccTypeNull() throws Exception {
		BankDetails bankDetailsRequest = new BankDetails();
		bankDetailsRequest.setAccountNumber("123456789");
		bankDetailsRequest.setBankAccountHolderName("Account Holder Name");
		bankDetailsRequest.setIfscCode("IFSCCODE");
		
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/bankdetails", 1235l).contentType(MediaType.APPLICATION_JSON).content(prepareRequestJsonString(bankDetailsRequest)).headers(new HttpHeaders())).andExpect(status().isUnprocessableEntity());
	}
	
	@Test
	public void testSaveBankDetails_AccTypeNotValid() throws Exception {
		BankDetails bankDetailsRequest = new BankDetails();
		bankDetailsRequest.setAccountNumber("123456789");
		bankDetailsRequest.setBankAccountType("3");
		bankDetailsRequest.setBankAccountHolderName("Account Holder Name");
		bankDetailsRequest.setIfscCode("IFSCCODE");
		
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/bankdetails", 1235l).contentType(MediaType.APPLICATION_JSON).content(prepareRequestJsonString(bankDetailsRequest)).headers(new HttpHeaders())).andExpect(status().isUnprocessableEntity());
	}
	
	@Test
	public void testSaveBankDetails_BackAction() throws Exception {
		BankDetails bankDetailsRequest = new BankDetails();
		bankDetailsRequest.setAction("back");
		
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/bankdetails", 1235l).contentType(MediaType.APPLICATION_JSON).content(prepareRequestJsonString(bankDetailsRequest)).headers(new HttpHeaders())).andExpect(status().isCreated());
	}
	
	@Test
	public void testSaveBankDetails_OtherAction() throws Exception {
		BankDetails bankDetailsRequest = new BankDetails();
		bankDetailsRequest.setAction("other");
		
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/bankdetails", 1235l).contentType(MediaType.APPLICATION_JSON).content(prepareRequestJsonString(bankDetailsRequest)).headers(new HttpHeaders())).andExpect(status().isUnprocessableEntity());
	}
	
	@Test
	public void testGetBankDetails() throws Exception {
		Mockito.when(creditBusinessBankDetailsService.getBankDetail(Mockito.anyLong(), Mockito.any())).thenReturn(new BankDetails());
		mockMvc.perform(get("/v1/credit/applications/{applicationid}/bankdetails", 1235l).headers(new HttpHeaders())).andExpect(status().isOk())
			.andExpect(jsonPath("$.bankDetailsEditable", is(nullValue())))
			.andExpect(jsonPath("$.accountNumberEdited", is(nullValue())));
	}
	
	private String prepareRequestJsonString(Object requestObject) {
		String requestJson = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			requestJson = mapper.writeValueAsString(requestObject);
		} catch (JsonProcessingException e) {
		}
		return requestJson;
	}
}
