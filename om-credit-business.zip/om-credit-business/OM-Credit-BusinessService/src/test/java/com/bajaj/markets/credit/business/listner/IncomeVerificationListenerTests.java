package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.google.gson.Gson;

@SpringBootTest
@SpringBootConfiguration
@SuppressWarnings("unchecked")
public class IncomeVerificationListenerTests {

	@InjectMocks
	IncomeVerificationListener incomeVerificationListener;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;

	@Autowired
	RuntimeService runtimeService;
	
	@InjectMocks
	McpCheck mcpCheck;

	@InjectMocks
	CreditBusinessHelper creditBusinessHelper;
	
	@Mock
	MasterDataRedisClientHelper masterDataRedisHelper;
	
	@Mock
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	private int defaultStmtToBeColleted = 3;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(incomeVerificationListener, "mcpCheck", mcpCheck);
		ReflectionTestUtils.setField(incomeVerificationListener, "creditBusinessHelper", creditBusinessHelper);
		ReflectionTestUtils.setField(incomeVerificationListener, "defaultStmtToBeColleted", defaultStmtToBeColleted);
	}

	@Test
	public void testIsIncomeVerificationRequired() {
		JSONObject productListObject = new JSONObject();
		List<JSONObject> productLists = new ArrayList<JSONObject>();
		JSONObject productList = new JSONObject();
		productList.put("perfiosRequiredFlag", "1");

		productLists.add(productList);

		productListObject.put("productList", productLists);

		when(execution.getVariable(Mockito.anyString())).thenReturn(productListObject);

		incomeVerificationListener.isIncomeVerificationRequired(execution);
	}
	
	@Test
	public void testIsIncomeVerificationRequired_statementToBeCollectedPresent() {
		JSONObject productListObject = new JSONObject();
		List<JSONObject> productLists = new ArrayList<JSONObject>();
		JSONObject productList = new JSONObject();
		productList.put("perfiosRequiredFlag", "1");
		productList.put("statementToBeCollected", 3);

		productLists.add(productList);

		productListObject.put("productList", productLists);

		when(execution.getVariable(Mockito.anyString())).thenReturn(productListObject);

		incomeVerificationListener.isIncomeVerificationRequired(execution);
	}

	@Test
	public void testPreIVPostCall() {

		when(execution.getVariable(Mockito.anyString())).thenReturn("1234");

		incomeVerificationListener.preIVPostCall(execution);
	}

	@Test
	public void testPostFetchEstimation() {
		JSONObject incomEstimation = new JSONObject();
		JSONObject accountInformation = new JSONObject();

		accountInformation.put("ifscCode", "IFSCCODE");
		accountInformation.put("accountNumber", "12345678");

		List<JSONObject> incomEstimationList = new ArrayList<JSONObject>();

		incomEstimation.put("salaryDetected", true);
		incomEstimation.put("accountInformation", accountInformation);

		incomEstimationList.add(incomEstimation);
		when(execution.getVariable(Mockito.anyString())).thenReturn(incomEstimationList);

		incomeVerificationListener.postFetchEstimation(execution);
	}

	@Test
	public void testFetchChannelJson() {
		JSONObject channelResponseJson = new JSONObject();
		when(execution.getVariable(Mockito.anyString())).thenReturn(channelResponseJson);
		incomeVerificationListener.fetchChannelJson(execution);
	}

	@Test
	public void testPostGetApplication() {
		JSONObject application = new JSONObject();
		when(execution.getVariable(Mockito.anyString())).thenReturn(application);
		incomeVerificationListener.postGetApplication(execution);
	}

	@Test
	public void testPostGetUserProfile() {
		JSONObject userProfile = new JSONObject();
		List<JSONObject> userProfiles = new ArrayList<JSONObject>();

		userProfile.put("applicationUserAttributeType", "1");

		userProfiles.add(userProfile);

		when(execution.getVariable(Mockito.anyString())).thenReturn(userProfiles);
		incomeVerificationListener.postGetUserProfile(execution);
	}

	@Test
	public void testPostGetPersonalEmail() {
		when(execution.getVariable(Mockito.anyString())).thenReturn(new JSONObject());
		incomeVerificationListener.postGetPersonalEmail(execution);
	}

	@Test
	public void testPostGetOccupationFromMaster() {
		when(execution.getVariable(Mockito.anyString())).thenReturn(new ArrayList<>());
		incomeVerificationListener.postGetOccupationFromMaster(execution);
	}

	@Test
	public void testPostGetOccupation() {
		JSONObject occupationObject = new JSONObject();
		List<JSONObject> occupationList = new ArrayList<JSONObject>();
		JSONObject occupationType = new JSONObject();
		occupationType.put("key", "key");

		occupationObject.put("ocupationType", occupationType);
		occupationObject.put("occupationCode", "occupationCode");
		occupationObject.put("occupationKey", "key");

		occupationList.add(occupationObject);
		when(execution.getVariable(Mockito.anyString())).thenReturn(occupationObject, occupationList);

		incomeVerificationListener.postGetOccupation(execution);

	}

	@Test
	public void testPostIVPostCall() {
		when(execution.getVariable(Mockito.anyString())).thenReturn(new JSONObject());
		incomeVerificationListener.postIVPostCall(execution);
	}

	@Test
	public void testPreSalaryUpdate() {
		JSONObject incomeEstimation = new JSONObject();
		JSONObject estimatedIncome = new JSONObject();

		incomeEstimation.put("estimatedIncome", estimatedIncome);

		when(execution.getVariable(Mockito.anyString())).thenReturn(incomeEstimation);

		incomeVerificationListener.preSalaryUpdate(execution);
	}

	@Test
	public void testFetchMCPforBRERequest() {

		JSONObject mcp = new JSONObject();
		JSONObject prodCategory = new JSONObject();

		mcp.put("prodCategory", prodCategory);

		when(execution.getVariable(Mockito.anyString())).thenReturn(new JSONObject());

		incomeVerificationListener.postIVPostCall(execution);
	}

	@Test
	public void testPreBRECall() throws Exception {
		Gson gson = new Gson();
		String mcpRequestString = "{\"additionalParameterDetail\":{\"utmChannel\":null,\"utmCampaign\":\"\",\"utmContent\":\"\",\"utmMedium\":\"\",\"utmSource\":null,\"utmTerm\":\"\"},\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":null,\"experience\":\"49\",\"netSalary\":\"52342\",\"employerType\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"8767898969\",\"dateOfBirth\":\"1989-11-09\",\"name\":{\"firstName\":\"Test\",\"middleName\":\"\",\"lastName\":\"TEst\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":28,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASDPF2342F\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"3470\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"115400\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":52342}],\"appScoreDetails\":{\"finalScore\":823,\"lrScore\":823,\"miScore\":821},\"existingCustomerFlag\":null,\"additionalCibilFlag\":0}";

		JSONObject mcpRequest = gson.fromJson(mcpRequestString, JSONObject.class);

		JSONObject incomeEstimation = gson.fromJson("{\"accountInformation\":{\"accountNumber\":\"string\",\"ifscCode\":\"string\"},\"applicantid\":\"string\",\"applicationid\":\"string\",\"channel\":\"string\",\"channeltransactionKey\":\"string\",\"dateOfBirth\":\"string\",\"emailId\":\"string\",\"estimatedIncome\":{\"income\":0,\"source\":\"string\"},\"estimatedMeanIncome\":0,\"estimatedhighestIncome\":0,\"imputaionModel\":\"string\",\"incomemputationKey\":\"string\",\"occupationType\":\"string\",\"salaryDateVariation\":true,\"salaryDetected\":false,\"salaryTransactions\":[{\"account\":\"string\",\"balance\":0,\"category\":\"string\",\"chequeNo\":\"string\",\"isSalaryTransaction\":true,\"isUserSelectedSalaryTransaction\":true,\"narration\":\"string\",\"tansactionAmount\":0,\"transactionDateTime\":\"2020-06-02T16:40:01.120Z\",\"transactionId\":0,\"variation\":\"string\"}],\"status\":\"string\",\"transactions\":[{\"account\":\"string\",\"balance\":0,\"category\":\"string\",\"chequeNo\":\"string\",\"isSalaryTransaction\":true,\"isUserSelectedSalaryTransaction\":true,\"narration\":\"string\",\"tansactionAmount\":0,\"transactionDateTime\":\"2020-06-02T16:40:01.120Z\",\"transactionId\":0,\"variation\":\"string\"}],\"statementCollected\":3}", JSONObject.class);

		List<JSONObject> residanceTypeList = new ArrayList<JSONObject>();
		JSONObject residanceType = new JSONObject();
		residanceType.put("residenceKey", 1d);

		residanceTypeList.add(residanceType);

		List<JSONObject> occupationList = new ArrayList<JSONObject>();
		JSONObject occupation = new JSONObject();

		occupation.put("occupationKey", "1");
		occupationList.add(occupation);
		
		List<JSONObject> derogJsonList = new ArrayList<JSONObject>();
		String derogJsonString = "{\"applicantId\":\"1100000000016156\",\"applicationId\":\"1100000000016156\",\"derogRules\":[{\"rule\":\"plrule6\",\"flag\":0},{\"rule\":\"ficclrule5\",\"flag\":0},{\"rule\":\"plrule5\",\"flag\":0},{\"rule\":\"uwrule2\",\"flag\":0},{\"rule\":\"plrule26\",\"flag\":0},{\"rule\":\"ficclrule1\",\"flag\":0},{\"rule\":\"plrule16\",\"flag\":0},{\"rule\":\"plrule10\",\"flag\":0},{\"rule\":\"ficclrule4\",\"flag\":0},{\"rule\":\"plrule14\",\"flag\":0},{\"rule\":\"plrule1\",\"flag\":0},{\"rule\":\"plrule13\",\"flag\":0},{\"rule\":\"plrule34\",\"flag\":0},{\"rule\":\"plrule38\",\"flag\":0},{\"rule\":\"plrule7\",\"flag\":0},{\"rule\":\"plrule2\",\"flag\":0},{\"rule\":\"plrule11\",\"flag\":0},{\"rule\":\"uwrule4\",\"flag\":0},{\"rule\":\"uwrule6\",\"flag\":0},{\"rule\":\"ficclrule8\",\"flag\":0},{\"rule\":\"plrule20\",\"flag\":0},{\"rule\":\"plrule37\",\"flag\":0},{\"rule\":\"plrule9\",\"flag\":0},{\"rule\":\"plrule18\",\"flag\":0},{\"rule\":\"plrule36\",\"flag\":0},{\"rule\":\"plrule3\",\"flag\":0},{\"rule\":\"uwrule3\",\"flag\":0},{\"rule\":\"plrule8\",\"flag\":0},{\"rule\":\"plrule31\",\"flag\":0},{\"rule\":\"ficclrule7\",\"flag\":0},{\"rule\":\"ficclrule3\",\"flag\":0},{\"rule\":\"plrule35\",\"flag\":0},{\"rule\":\"uwrule7\",\"flag\":4},{\"rule\":\"ficclrule2\",\"flag\":0},{\"rule\":\"plrule17\",\"flag\":0},{\"rule\":\"plrule32\",\"flag\":0},{\"rule\":\"ficclrule6\",\"flag\":4},{\"rule\":\"uwrule1\",\"flag\":0},{\"rule\":\"plrule15\",\"flag\":0},{\"rule\":\"plrule33\",\"flag\":0},{\"rule\":\"plrule4\",\"flag\":0},{\"rule\":\"uwrule5\",\"flag\":3},{\"rule\":\"plrule19\",\"flag\":0}],\"productType\":\"Salaried\",\"source\":null,\"liveSecLoans\":{\"liveSecLoans\":\"0\",\"loanList\":[]},\"unexpectedErrorFlag\":false,\"errorFlag\":false}";
		JSONObject derogJson = gson.fromJson(derogJsonString, JSONObject.class);
		derogJsonList.add(derogJson);
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		
		Mockito.when(masterDataRedisHelper.findResitypeByKey(Mockito.any())).thenReturn(new ResidenceMaster());
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		when(execution.getVariable(Mockito.anyString())).thenReturn(mcpRequest, incomeEstimation, "1234", "Salaried", "Salaried", "perfiosJson", "cibilJson", "cibilType", "cibilScore", derogJsonList);

		incomeVerificationListener.preBRECall(execution);
	}

	@Test
	public void testPreBRECall_SalaryDetected() {
		Gson gson = new Gson();
		String mcpRequestString = "{\"additionalParameterDetail\":{\"utmChannel\":null,\"utmCampaign\":\"\",\"utmContent\":\"\",\"utmMedium\":\"\",\"utmSource\":null,\"utmTerm\":\"\"},\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":null,\"experience\":\"49\",\"netSalary\":\"52342\",\"employerType\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"8767898969\",\"dateOfBirth\":\"1989-11-09\",\"name\":{\"firstName\":\"Test\",\"middleName\":\"\",\"lastName\":\"TEst\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":28,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASDPF2342F\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"3470\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"115400\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":52342}],\"appScoreDetails\":{\"finalScore\":823,\"lrScore\":823,\"miScore\":821},\"existingCustomerFlag\":null,\"additionalCibilFlag\":0}";

		JSONObject mcpRequest = gson.fromJson(mcpRequestString, JSONObject.class);

		JSONObject incomeEstimation = gson.fromJson("{\"accountInformation\":{\"accountNumber\":\"string\",\"ifscCode\":\"string\"},\"applicantid\":\"string\",\"applicationid\":\"string\",\"channel\":\"string\",\"channeltransactionKey\":\"string\",\"dateOfBirth\":\"string\",\"emailId\":\"string\",\"estimatedIncome\":{\"income\":0,\"source\":\"string\"},\"estimatedMeanIncome\":0,\"estimatedhighestIncome\":0,\"imputaionModel\":\"string\",\"incomemputationKey\":\"string\",\"occupationType\":\"string\",\"salaryDateVariation\":true,\"salaryDetected\":true,\"salaryTransactions\":[{\"account\":\"string\",\"balance\":0,\"category\":\"string\",\"chequeNo\":\"string\",\"isSalaryTransaction\":true,\"isUserSelectedSalaryTransaction\":true,\"narration\":\"string\",\"tansactionAmount\":0,\"transactionDateTime\":\"2020-06-02T16:40:01.120Z\",\"transactionId\":0,\"variation\":\"string\"}],\"status\":\"string\",\"transactions\":[{\"account\":\"string\",\"balance\":0,\"category\":\"string\",\"chequeNo\":\"string\",\"isSalaryTransaction\":true,\"isUserSelectedSalaryTransaction\":true,\"narration\":\"string\",\"tansactionAmount\":0,\"transactionDateTime\":\"2020-06-02T16:40:01.120Z\",\"transactionId\":0,\"variation\":\"string\"}]}", JSONObject.class);

		List<JSONObject> residanceTypeList = new ArrayList<JSONObject>();
		JSONObject residanceType = new JSONObject();
		residanceType.put("residenceKey", 1d);

		residanceTypeList.add(residanceType);

		List<JSONObject> occupationList = new ArrayList<JSONObject>();
		JSONObject occupation = new JSONObject();

		occupation.put("occupationKey", "1");

		occupationList.add(occupation);

		when(execution.getVariable(Mockito.anyString())).thenReturn(mcpRequest, incomeEstimation, "1234", residanceTypeList, occupationList);
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		incomeVerificationListener.preBRECall(execution);
	}

	@Test
	public void testPreBRECall_SalaryDetectedNull() {
		Gson gson = new Gson();
		String mcpRequestString = "{\"additionalParameterDetail\":{\"utmChannel\":null,\"utmCampaign\":\"\",\"utmContent\":\"\",\"utmMedium\":\"\",\"utmSource\":null,\"utmTerm\":\"\"},\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":null,\"experience\":\"49\",\"netSalary\":\"52342\",\"employerType\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"8767898969\",\"dateOfBirth\":\"1989-11-09\",\"name\":{\"firstName\":\"Test\",\"middleName\":\"\",\"lastName\":\"TEst\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":28,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASDPF2342F\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"3470\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"115400\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":52342}],\"appScoreDetails\":{\"finalScore\":823,\"lrScore\":823,\"miScore\":821},\"existingCustomerFlag\":null,\"additionalCibilFlag\":0}";

		JSONObject mcpRequest = gson.fromJson(mcpRequestString, JSONObject.class);

		JSONObject incomeEstimation = gson.fromJson(
				"{\"accountInformation\":{\"accountNumber\":\"string\",\"ifscCode\":\"string\"},\"applicantid\":\"string\",\"applicationid\":\"string\",\"channel\":\"string\",\"channeltransactionKey\":\"string\",\"dateOfBirth\":\"string\",\"emailId\":\"string\",\"estimatedIncome\":{\"income\":0,\"source\":\"string\"},\"estimatedMeanIncome\":0,\"estimatedhighestIncome\":0,\"imputaionModel\":\"string\",\"incomemputationKey\":\"string\",\"occupationType\":\"string\",\"salaryDateVariation\":true,\"salaryDetected\":null,\"salaryTransactions\":[{\"account\":\"string\",\"balance\":0,\"category\":\"string\",\"chequeNo\":\"string\",\"isSalaryTransaction\":true,\"isUserSelectedSalaryTransaction\":true,\"narration\":\"string\",\"tansactionAmount\":0,\"transactionDateTime\":\"2020-06-02T16:40:01.120Z\",\"transactionId\":0,\"variation\":\"string\"}],\"status\":\"string\",\"transactions\":[{\"account\":\"string\",\"balance\":0,\"category\":\"string\",\"chequeNo\":\"string\",\"isSalaryTransaction\":true,\"isUserSelectedSalaryTransaction\":true,\"narration\":\"string\",\"tansactionAmount\":0,\"transactionDateTime\":\"2020-06-02T16:40:01.120Z\",\"transactionId\":0,\"variation\":\"string\"}]}",
				JSONObject.class);

		List<JSONObject> residanceTypeList = new ArrayList<JSONObject>();
		JSONObject residanceType = new JSONObject();
		residanceType.put("residenceKey", 1d);

		residanceTypeList.add(residanceType);

		List<JSONObject> occupationList = new ArrayList<JSONObject>();
		JSONObject occupation = new JSONObject();

		occupation.put("occupationKey", "1");

		occupationList.add(occupation);

		when(execution.getVariable(Mockito.anyString())).thenReturn(mcpRequest, incomeEstimation, "1234", residanceTypeList, occupationList);
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		incomeVerificationListener.preBRECall(execution);
	}

	@Test
	public void testPostBRECall() {
		String breOutputNoRejects = "{\"openArcCardListingOutput\":{\"openArcCardListing\":null,\"openMarketsLoanListing\":{\"eligibilityType\":\"AIP\",\"maxEligibility\":2000000,\"maxTenor\":5,\"requiredLoanAmount\":100000,\"requiredTenor\":4,\"principalProductDetails\":[{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":true,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLTL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1200,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":2778,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[],\"roi\":14.6,\"preApproved\":\"Yes\",\"bScore\":4,\"approvalChances\":\"Medium\",\"priorityOrder\":1,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"SOLTL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null},{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":true,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLHFL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1400,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":1325,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[{\"graceTerm\":2,\"nextDueDate\":\"02/10/2021\"}],\"roi\":12.6,\"preApproved\":\"Yes\",\"bScore\":4.5,\"approvalChances\":\"Medium\",\"priorityOrder\":2,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"DHPL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null}],\"takeBacktoListingPage\":true,\"estimatedNetMonthlySalaryDetails\":[{\"salaryAmount\":0,\"salarySource\":\"string\"}]}},\"action\":true}";
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(breOutputNoRejects);
		when(execution.getVariable(CreditBusinessConstants.PRINCIPALKEY)).thenReturn(3);
		incomeVerificationListener.postBRECall(execution);
		
		String breOutputAllReject = "{\"openArcCardListingOutput\":{\"openArcCardListing\":null,\"openMarketsLoanListing\":{\"eligibilityType\":\"AIP\",\"maxEligibility\":2000000,\"maxTenor\":5,\"requiredLoanAmount\":100000,\"requiredTenor\":4,\"principalProductDetails\":[{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":false,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLTL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1200,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":2778,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[],\"roi\":14.6,\"preApproved\":\"Yes\",\"bScore\":4,\"approvalChances\":\"Medium\",\"priorityOrder\":1,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"SOLTL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null},{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":false,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLHFL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1400,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":1325,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[{\"graceTerm\":2,\"nextDueDate\":\"02/10/2021\"}],\"roi\":12.6,\"preApproved\":\"Yes\",\"bScore\":4.5,\"approvalChances\":\"Medium\",\"priorityOrder\":2,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"DHPL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null}],\"takeBacktoListingPage\":true,\"estimatedNetMonthlySalaryDetails\":[{\"salaryAmount\":0,\"salarySource\":\"string\"}]}},\"action\":true}";
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(breOutputAllReject);
		incomeVerificationListener.postBRECall(execution);
		
		String breOutputChildRejectAndTakeBkToListingTrue = "{\"openArcCardListingOutput\":{\"openArcCardListing\":null,\"openMarketsLoanListing\":{\"eligibilityType\":\"AIP\",\"maxEligibility\":2000000,\"maxTenor\":5,\"requiredLoanAmount\":100000,\"requiredTenor\":4,\"principalProductDetails\":[{\"principalSelectedByCustomer\":\"Yes\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":false,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLTL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1200,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":2778,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[],\"roi\":14.6,\"preApproved\":\"Yes\",\"bScore\":4,\"approvalChances\":\"Medium\",\"priorityOrder\":1,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"SOLTL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null},{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":true,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLHFL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1400,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":1325,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[{\"graceTerm\":2,\"nextDueDate\":\"02/10/2021\"}],\"roi\":12.6,\"preApproved\":\"Yes\",\"bScore\":4.5,\"approvalChances\":\"Medium\",\"priorityOrder\":2,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"DHPL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null}],\"takeBacktoListingPage\":true,\"estimatedNetMonthlySalaryDetails\":[{\"salaryAmount\":0,\"salarySource\":\"string\"}]}},\"action\":true}";
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(breOutputChildRejectAndTakeBkToListingTrue);
		when(execution.getVariable(CreditBusinessConstants.PRINCIPALKEY)).thenReturn(1);
		incomeVerificationListener.postBRECall(execution);
		
		String breOutputTakeBkToListingFalse= "{\"openArcCardListingOutput\":{\"openArcCardListing\":null,\"openMarketsLoanListing\":{\"eligibilityType\":\"AIP\",\"maxEligibility\":2000000,\"maxTenor\":5,\"requiredLoanAmount\":100000,\"requiredTenor\":4,\"principalProductDetails\":[{\"principalSelectedByCustomer\":\"Yes\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":true,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLTL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1200,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":2778,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[],\"roi\":14.6,\"preApproved\":\"Yes\",\"bScore\":4,\"approvalChances\":\"Medium\",\"priorityOrder\":1,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"SOLTL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null},{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":true,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLHFL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1400,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":1325,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[{\"graceTerm\":2,\"nextDueDate\":\"02/10/2021\"}],\"roi\":12.6,\"preApproved\":\"Yes\",\"bScore\":4.5,\"approvalChances\":\"Medium\",\"priorityOrder\":2,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"DHPL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null}],\"takeBacktoListingPage\":null,\"estimatedNetMonthlySalaryDetails\":[{\"salaryAmount\":0,\"salarySource\":\"string\"}]}},\"action\":true}";
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(breOutputTakeBkToListingFalse);
		when(execution.getVariable(CreditBusinessConstants.PRINCIPALKEY)).thenReturn(1);
		incomeVerificationListener.postBRECall(execution);
		
		String breOutputChildRejectAndTakeBkToListingAndSegmentRerunTrue = "{\"openArcCardListingOutput\":{\"openArcCardListing\":null,\"openMarketsLoanListing\":{\"eligibilityType\":\"AIP\",\"maxEligibility\":2000000,\"maxTenor\":5,\"requiredLoanAmount\":100000,\"requiredTenor\":4,\"principalProductDetails\":[{\"principalSelectedByCustomer\":\"Yes\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":false,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLTL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1200,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":2778,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[],\"roi\":14.6,\"preApproved\":\"Yes\",\"bScore\":4,\"approvalChances\":\"Medium\",\"priorityOrder\":1,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"SOLTL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null},{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":true,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLHFL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1400,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":1325,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[{\"graceTerm\":2,\"nextDueDate\":\"02/10/2021\"}],\"roi\":12.6,\"preApproved\":\"Yes\",\"bScore\":4.5,\"approvalChances\":\"Medium\",\"priorityOrder\":2,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"DHPL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null}],\"takeBacktoListingPage\":true,\"segmentReRunFlag\":true,\"estimatedNetMonthlySalaryDetails\":[{\"salaryAmount\":0,\"salarySource\":\"string\"}]}},\"action\":true}";
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(breOutputChildRejectAndTakeBkToListingAndSegmentRerunTrue);
		when(execution.getVariable(CreditBusinessConstants.PRINCIPALKEY)).thenReturn(1);
		incomeVerificationListener.postBRECall(execution);
		
		String breOutputChildRejectAndTakeBkToListingAndSegmentRerunFalse = "{\"openArcCardListingOutput\":{\"openArcCardListing\":null,\"openMarketsLoanListing\":{\"eligibilityType\":\"AIP\",\"maxEligibility\":2000000,\"maxTenor\":5,\"requiredLoanAmount\":100000,\"requiredTenor\":4,\"principalProductDetails\":[{\"principalSelectedByCustomer\":\"Yes\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":false,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLTL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1200,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":2778,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[],\"roi\":14.6,\"preApproved\":\"Yes\",\"bScore\":4,\"approvalChances\":\"Medium\",\"priorityOrder\":1,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"SOLTL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null},{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":true,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLHFL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1400,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":1325,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/10/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[{\"graceTerm\":2,\"nextDueDate\":\"02/10/2021\"}],\"roi\":12.6,\"preApproved\":\"Yes\",\"bScore\":4.5,\"approvalChances\":\"Medium\",\"priorityOrder\":2,\"fppApplicable\":true,\"perfiosRequired\":false,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"DHPL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[],\"cardTag\":\"\",\"ctaName\":\"\",\"isEligiblityChanged\":null}],\"takeBacktoListingPage\":true,\"segmentReRunFlag\":null,\"estimatedNetMonthlySalaryDetails\":[{\"salaryAmount\":0,\"salarySource\":\"string\"}]}},\"action\":true}";
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(breOutputChildRejectAndTakeBkToListingAndSegmentRerunFalse);
		when(execution.getVariable(CreditBusinessConstants.PRINCIPALKEY)).thenReturn(1);
		incomeVerificationListener.postBRECall(execution);
	}
	@Test
	public void testpostSalaryDetails() {
		JSONObject estimatedSalary = new JSONObject();
		estimatedSalary.put("salaryAmount", 123.0d);
		estimatedSalary.put("salarySource", "PERFIOS");
		ArrayList<JSONObject> estimatedSalaries = new ArrayList<JSONObject>();
		estimatedSalaries.add(estimatedSalary);

		when(execution.getVariable(Mockito.anyString())).thenReturn(estimatedSalaries);
	    incomeVerificationListener.postSalaryDetails(execution);
	}
	@Test
	public void testfetchMCPforBRERequest() {
		Gson gson = new Gson();
		String mcpRequestString = "{\"additionalParameterDetail\":{\"utmChannel\":null,\"utmCampaign\":\"\",\"utmContent\":\"\",\"utmMedium\":\"\",\"utmSource\":null,\"utmTerm\":\"\"},\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":null,\"experience\":\"49\",\"netSalary\":\"52342\",\"employerType\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"8767898969\",\"dateOfBirth\":\"1989-11-09\",\"name\":{\"firstName\":\"Test\",\"middleName\":\"\",\"lastName\":\"TEst\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":28,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASDPF2342F\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"3470\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"115400\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":52342}],\"appScoreDetails\":{\"finalScore\":823,\"lrScore\":823,\"miScore\":821},\"existingCustomerFlag\":null,\"additionalCibilFlag\":0}";
		JSONObject mcpRequest = gson.fromJson(mcpRequestString, JSONObject.class);

		when(execution.getVariable(Mockito.anyString())).thenReturn(mcpRequest);

		incomeVerificationListener.fetchMCPforBRERequest(execution);
	}

	@Test
	public void testPostIncomeVerificationComplete() {
		when(execution.getVariable(Mockito.anyString())).thenReturn(null);
		incomeVerificationListener.postIncomeVerificationComplete(execution);
	}

	@Test
	public void testPostFetchBranchDetails() {
		JSONObject branchDetail = new JSONObject();
		branchDetail.put("branchKey", 123.0d);
		branchDetail.put("bankMasterKey", 123.0d);
		ArrayList<JSONObject> branchDetails = new ArrayList<JSONObject>();
		branchDetails.add(branchDetail);

		when(execution.getVariable(Mockito.anyString())).thenReturn(branchDetails);
		incomeVerificationListener.postFetchBranchDetails(execution);
	}

	@Test
	public void testPostFetchBankReference() {
		JSONObject bankDetail = new JSONObject();
		bankDetail.put("bankMasterKey", 123.0d);
		ArrayList<JSONObject> bankDetails = new ArrayList<JSONObject>();
		bankDetails.add(bankDetail);

		when(execution.getVariable(Mockito.anyString())).thenReturn(bankDetails);
		incomeVerificationListener.postFetchBankReference(execution);
	}

	@Test
	public void testPreSaveBankDetails() {
		when(execution.getVariable(Mockito.anyString())).thenReturn(1234l);
		incomeVerificationListener.preSaveBankDetails(execution);
	}

	@Test
	public void testPreEstimatedSalaryUpdate() {
		JSONObject estimatedSalary = new JSONObject();
		estimatedSalary.put("salaryAmount", 123.0d);
		estimatedSalary.put("salarySource", "PERFIOS");
		ArrayList<JSONObject> estimatedSalaries = new ArrayList<JSONObject>();
		estimatedSalaries.add(estimatedSalary);

		when(execution.getVariable(Mockito.anyString())).thenReturn(estimatedSalaries);
		incomeVerificationListener.preEstimatedSalaryUpdate(execution);
	}

	@Test
	public void testPreListingUpdate() {
		String breResponse = "{\"action\":true,\"openArcCardListingOutput\":{\"openArcCardListing\":{\"cibilRequired\":true,\"principleProductDetails\":[{\"approvalChances\":\"string\",\"bScore\":0,\"cardPriority\":0,\"cardTag\":\"string\",\"ctaName\":\"string\",\"isEligible\":true,\"principleProductCode\":\"string\",\"rejectCodeList\":[\"string\"]}]},\"openMarketsLoanListing\":{\"eligibilityType\":\"string\",\"estimatedNetMonthlySalaryDetails\":[{\"salaryAmount\":0,\"salarySource\":\"string\"}],\"maxEligibility\":0,\"maxTenor\":0,\"principalProductDetails\":[{\"applicableMultiplier\":0,\"approvalChances\":\"string\",\"bScore\":0,\"baseRate\":{\"baseRateCode\":\"string\",\"baseRateValue\":0},\"cardTag\":\"string\",\"ctaName\":\"string\",\"dropLineTenor\":0,\"dueDateDetails\":[{\"dueDate\":0,\"firstDueDate\":\"string\"}],\"eligibilityAmount\":0,\"eligibilityType\":\"string\",\"emiAmount\":0,\"feesList\":[{\"feeCode\":\"string\",\"feesInAmount\":0,\"feesInPercent\":0}],\"finalFoir\":0,\"finalMultiplier\":0,\"finalUnsecuredFoir\":0,\"foirEligibilityEmi\":0,\"fppApplicable\":true,\"isEligible\":true,\"isEligiblityChanged\":true,\"isTenor\":0,\"loanTypeName\":\"string\",\"loanTypeRecommendation\":\"string\",\"maxEmiAsPerFoir\":0,\"multiplierEligibility\":0,\"nextDueDateDetails\":[{\"graceTerm\":0,\"nextDueDate\":\"string\"}],\"offerType\":\"string\",\"pennantloanTypeRecommendation\":\"string\",\"perfiosRequired\":true,\"preApproved\":\"string\",\"principalSelectedByCustomer\":\"string\",\"principleProductCode\":\"string\",\"priorityOrder\":0,\"productSize\":\"string\",\"promotionalOffer\":\"string\",\"rejectCodeList\":[\"string\"],\"requiredLoanAmount\":0,\"riskOfferType\":\"string\",\"roi\":0,\"tenor\":0}],\"requiredLoanAmount\":0,\"requiredTenor\":0,\"takeBacktoListingPage\":\"string\"}}}";
		when(execution.getVariable(Mockito.anyString())).thenReturn(breResponse);
		incomeVerificationListener.preListingUpdate(execution);
	}

	@Test
	public void testPostBRECall_Else() {
		String breResponse = "{\"openArcCardListingOutput\":{\"openArcCardListing\":null,\"openMarketsLoanListing\":{\"eligibilityType\":\"AIP\",\"maxEligibility\":2000000,\"maxTenor\":5,\"requiredLoanAmount\":100000,\"requiredTenor\":4,\"principalProductDetails\":[],\"takeBacktoListingPage\":true,\"estimatedNetMonthlySalaryDetails\":[]}},\"action\":true}";
		when(execution.getVariable(Mockito.anyString())).thenReturn(breResponse);
		incomeVerificationListener.postBRECall(execution);
	}
	
	@Test
	public void testpreIVStatusUpdate() {
		incomeVerificationListener.preIVStatusUpdate(execution);
	}
	
	@Test
	public void testpreIVApplicationStatusUpdate() {
		incomeVerificationListener.preIVApplicationStatusUpdate(execution);
	}
	
	@Test
	public void testSetStatementToBeCollected() {
		incomeVerificationListener.setStatementToBeCollected(execution, 3);
	}
	
	@Test
	public void testGetPersonalEmail() {
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("1111");
		incomeVerificationListener.getPersonalEmail(execution);
	}
	
}
