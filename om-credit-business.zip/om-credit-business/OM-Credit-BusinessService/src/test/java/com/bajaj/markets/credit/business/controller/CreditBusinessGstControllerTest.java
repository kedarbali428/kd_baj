package com.bajaj.markets.credit.business.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.GstRequest;
import com.bajaj.markets.credit.business.service.CreditBusinessGSTService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest

@AutoConfigureMockMvc
public class CreditBusinessGstControllerTest {

	@InjectMocks
	private CreditBusinessGstController creditBusinessGstController;

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	CreditBusinessGSTService creditBusinessGstService;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessGstController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class)
				/* .addPlaceholderValue("/v1/income/verification", "/v1/income/verification") */.build();

	}

	@Test
	public void testgetGstInfo() throws Exception {
		GstRequest gst = new GstRequest();
		gst.setApplicantId(123l);
		gst.setGstPinNo("dfsdff1234");

		mockMvc.perform(
				post("/v1/credit/applications/{applicationid}/gstInfo", 1235l).contentType(MediaType.APPLICATION_JSON)
						.content(prepareRequestJsonString(gst)).headers(new HttpHeaders()))
				.andExpect(status().isOk());
	}

	private String prepareRequestJsonString(Object requestObject) {
		String requestJson = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			requestJson = mapper.writeValueAsString(requestObject);
		} catch (JsonProcessingException e) {
		}
		return requestJson;
	}

}
