package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.sns.message.HttpException;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AppEsignInfoBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@SpringBootTest

@AutoConfigureMockMvc
public class EsignDetailsTest {

	@InjectMocks
	private EsignDetails eSign;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;
	
	@Mock
	private CreditBusinessHelper creditBusinessHelper;
	
	@Mock
	private CreditBusinessApiCallsHelper creditBusinessApiCallsHelper;
	
	private String appLoanPricingUrl = "appLoanPricingUrl";
	private String fetchAllEsignsUrl = "fetchAllEsignsUrl";
	private String updateEsignUrl = "updateEsignUrl";


	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(eSign, "appLoanPricingUrl" , appLoanPricingUrl);
		ReflectionTestUtils.setField(eSign, "fetchAllEsignsUrl", fetchAllEsignsUrl);
		ReflectionTestUtils.setField(eSign, "updateEsignUrl", updateEsignUrl);

	}

	@Test
	public void testFetchESignDetails() {
		JSONObject eSignDetails = new JSONObject();
		eSignDetails.put("status", "initiated");
		when(execution.getVariable(Mockito.anyString())).thenReturn(eSignDetails);
		eSign.fetchEsignDetails(execution);

	}

	@Test
	public void testFetchESignDetailsWithNoValues() {
		JSONObject eSignDetails = new JSONObject();
		when(execution.getVariable(Mockito.anyString())).thenReturn(null);
		eSign.fetchEsignDetails(execution);

	}

	@Test
	public void testPreESignDetails() {

		eSign.preEsignDetails(execution);

	}
	
	@Test
	public void testPostEsignStage() {
		eSign.postEsignStage(execution, true);
	}
	
	@Test
	public void testPrePersonalEmail() {
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn("{\"personalEmail\":\"abc@gmail.com\"}");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("1111");
		eSign.prePersonalEmail(execution);
	}
	
	@Test
	public void testCheckPersonalEmailUpdate() {
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn("{\"personalEmail\":\"abc@gmail.com\"}");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("1111");
		eSign.checkPersonalEmailUpdate(execution);
	}
	
	@Test
	public void testIsEsignRequired_SelfEmployed() {
		JSONObject occupationObject = new JSONObject();
		JSONObject occupationType = new JSONObject();
		occupationType.put("key", 2l);
		occupationObject.put("ocupationType", occupationType);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(occupationObject);
		
		eSign.isEsignRequired(execution);
	}
	
	
	@Test
	public void testIsEsignRequired_NullKey() {
		JSONObject occupationObject = new JSONObject();
		occupationObject.put("ocupationType", new JSONObject());
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(occupationObject);
		
		eSign.isEsignRequired(execution);
	}
	
	@Test
	public void testIsUnderWriterCheckRequired_Salaried() {
		JSONObject occupationObject = new JSONObject();
		JSONObject occupationType = new JSONObject();
		JSONObject salariedDetail = new JSONObject();
		JSONObject employerName = new JSONObject();
		occupationType.put("key", 1l);
		occupationObject.put("ocupationType", occupationType);
		occupationObject.put("salariedDetail",salariedDetail);
		salariedDetail.put("employerName",employerName);
		employerName.put("key",11);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(occupationObject);
		
		eSign.isUnderWriterCheckRequired(execution);
	}
	
	@Test
	public void testIsUnderWriterCheckRequired_NullKey() {
		JSONObject occupationObject = new JSONObject();
		JSONObject salariedDetail = new JSONObject();
		JSONObject employerName = new JSONObject();
		occupationObject.put("ocupationType", new JSONObject());
		occupationObject.put("salariedDetail",salariedDetail);
		salariedDetail.put("employerName",employerName);
		 
	
		when(execution.getVariable(Mockito.anyString())).thenReturn(occupationObject);
		
		eSign.isUnderWriterCheckRequired(execution);
	}
    
	@Test
	public void testIsUnderWriterCheckRequired_NulEmplyerId() {
		JSONObject occupationObject = new JSONObject();
		JSONObject occupationType = new JSONObject();
		JSONObject salariedDetail = new JSONObject();
		JSONObject employerName = new JSONObject();
		occupationType.put("key", 1l);
		occupationObject.put("ocupationType", occupationType);
		occupationObject.put("salariedDetail",salariedDetail);
		salariedDetail.put("employerName",employerName);
		 
		when(execution.getVariable(Mockito.anyString())).thenReturn(occupationObject);
		
		eSign.isUnderWriterCheckRequired(execution);
	}
	
	@Test
	public void testSuspendEsignForRejectedEpPricings() {	
		List<Map<String,String>> appLoanPricingList = new ArrayList<>();
		Map<String, String> loanPricing = new HashMap<>();
		loanPricing.put("source", "EP");
		loanPricing.put("pricingStatus", "Rejected");
		appLoanPricingList.add(loanPricing);
		
		AppEsignInfoBean[] appEsignInfoBeanArray = new AppEsignInfoBean[1];
		AppEsignInfoBean appEsignInfoBean = new AppEsignInfoBean();
		appEsignInfoBean.setIsactive(1);
		appEsignInfoBeanArray[0] = appEsignInfoBean;
		
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATIONKEY)).thenReturn("1111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID)).thenReturn("1111");
		Mockito.when(creditBusinessApiCallsHelper.callApi(Mockito.eq(appLoanPricingUrl),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(appLoanPricingList);
		Mockito.when(creditBusinessApiCallsHelper.callApi(Mockito.eq(fetchAllEsignsUrl),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(appEsignInfoBeanArray);
		Mockito.when(creditBusinessApiCallsHelper.callApi(Mockito.eq(updateEsignUrl),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(appEsignInfoBean);

		eSign.suspendEsignForRejectedEpPricing(execution);
	}
	
	@Test
	public void testSuspendEsignForRejectedEpPricing_Exc() {	
		List<Map<String,String>> appLoanPricingList = new ArrayList<>();
		Map<String, String> loanPricing = new HashMap<>();
		loanPricing.put("source", "EP");
		loanPricing.put("pricingStatus", "Rejected");
		appLoanPricingList.add(loanPricing);
		
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATIONKEY)).thenReturn("1111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID)).thenReturn("1111");
		Mockito.when(creditBusinessApiCallsHelper.callApi(Mockito.eq(appLoanPricingUrl),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenThrow(HttpException.class);
		eSign.suspendEsignForRejectedEpPricing(execution);
	}

}
