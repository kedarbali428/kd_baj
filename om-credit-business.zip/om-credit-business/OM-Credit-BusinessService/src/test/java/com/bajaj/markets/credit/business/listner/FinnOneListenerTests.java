package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.sns.model.AuthorizationErrorException;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.EventMessageHelper;
import com.bajaj.markets.credit.publisher.service.PublisherService;

@SpringBootTest
public class FinnOneListenerTests {

	@InjectMocks
	FinnoneListener finnOneListener;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	private String topicArn = "topicArn";

	@Mock
	PublisherService publisherService;
	
	@Mock
	EventMessageHelper eventHelper;
	
	@Mock
	DelegateExecution execution;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		
		ReflectionTestUtils.setField(finnOneListener, "topicArn", topicArn);
	}
	
	@Test
	public void testPublishEvent() {
		when(execution.getVariable(CreditBusinessConstants.BMR_CUSTOMER_ID)).thenReturn(1);
		finnOneListener.publishEvent(execution);
	}
	
	@Test
	public void testPublishEvent_custId_not_found() {
		when(execution.getVariable(CreditBusinessConstants.BMR_CUSTOMER_ID)).thenReturn(null);
		finnOneListener.publishEvent(execution);
	}
	
	@Test
	public void testPublishEvent_Exception() {
		when(publisherService.publish(Mockito.anyString(), Mockito.any())).thenThrow(new AuthorizationErrorException("unauthorized"));
		finnOneListener.publishEvent(execution);
	}
	
	@Test
	public void testPreFetchBMRCustomerInfo() {
		finnOneListener.preFetchBMRCustomerInfo(execution);
	}
	
	@Test
	public void testPostFetchBMRCustomerInfo() {
		JSONObject response = new JSONObject();
		response.put("principleCustRefId", "1234customerid");
		when(execution.getVariable(CreditBusinessConstants.API_EXCEPTION_ARISE)).thenReturn(false);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(response);
		finnOneListener.postFetchBMRCustomerInfo(execution);
	}
	
	@Test
	public void testPostFetchBMRCustomerInfo_CustomerIdNull() {
		JSONObject response = new JSONObject();
		response.put("principleCustRefId", null);
		when(execution.getVariable(CreditBusinessConstants.API_EXCEPTION_ARISE)).thenReturn(false);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(response);
		finnOneListener.postFetchBMRCustomerInfo(execution);
	}
	
	@Test
	public void testPostFetchBMRCustomerInfo_ExceptionArise() {
		when(execution.getVariable(CreditBusinessConstants.API_EXCEPTION_ARISE)).thenReturn(true);
		finnOneListener.postFetchBMRCustomerInfo(execution);
	}
}
