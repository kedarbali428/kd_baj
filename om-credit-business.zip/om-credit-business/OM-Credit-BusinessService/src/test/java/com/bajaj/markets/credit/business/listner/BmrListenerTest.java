package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.EventMessageHelper;
import com.google.gson.Gson;

@SpringBootTest
public class BmrListenerTest {

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	BmrListener listener;

	@Mock
	EventMessageHelper eventHelper;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

	}

	@Test
	public void testPreListing() {
		JSONObject userProfile = new JSONObject();
		userProfile.put(CreditBusinessConstants.PAN_NUMBER, "ASWPJ1234J");
		Gson g = new Gson();
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_DETAILS)).thenReturn(new ApplicationDetail());
		when(execution.getVariable(CreditBusinessConstants.USERPROFILEOUTPUT)).thenReturn(userProfile);
		when(execution.getVariable(CreditBusinessConstants.PERSONALEMAILID)).thenReturn("abcd@gmail.com");
		when(execution.getVariable(CreditBusinessConstants.OCCUPATIONTYPECODE)).thenReturn("SALR");
		listener.bmrMessageEvents(execution);
	}

}
