package com.bajaj.markets.credit.business.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.validation.Validator;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.DisbursementEventRequestBean;
import com.bajaj.markets.credit.business.beans.DisbursementEventResponseBean;
import com.bajaj.markets.credit.business.service.CreditBusinessDisbursementService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest

@AutoConfigureMockMvc
public class CreditBusinessDisbursementControllerTest {
	@InjectMocks
	private CreditBusinessDisbursementController creditBusinessDisbursementController;
	
	MockMvc mockMvc;
	
	@Mock
	HttpHeaders mockheader;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	Validator validator;
	
	@Mock
	CreditBusinessDisbursementService creditBusinessDisbursementService;
	
	@Before
    public void setUp() {
		MockitoAnnotations.initMocks(this);	
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessDisbursementController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();
	}
	

	
	@Test
	public void processDisbursementTest() throws Exception {
		DisbursementEventResponseBean responsetBean = new DisbursementEventResponseBean();
		DisbursementEventRequestBean responseEntity = new DisbursementEventRequestBean();
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(responseEntity);
		Mockito.when(creditBusinessDisbursementService.processDisbursement(Mockito.any())).thenReturn(responsetBean);
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/disbursement/initiate","1234").content(requestJson).contentType(MediaType.APPLICATION_JSON).headers(mockheader)).andExpect(status().isOk());
	}
	
}
