package com.bajaj.markets.credit.business.helper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ApplicationStageDetails;
import com.bajaj.markets.credit.business.beans.BranchDetails;
import com.bajaj.markets.credit.business.beans.CibilResponse;
import com.bajaj.markets.credit.business.beans.CibilTypeAndScore;
import com.bajaj.markets.credit.business.beans.CityResponseBean;
import com.bajaj.markets.credit.business.beans.CustDerivedIndustryMaster;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.EmployerTypeBean;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OccupationReference;
import com.bajaj.markets.credit.business.beans.PrincipalBean;
import com.bajaj.markets.credit.business.beans.ProductList;
import com.bajaj.markets.credit.business.beans.PropertyAdditionalDetails;
import com.bajaj.markets.credit.business.beans.PropertyPageDetails;
import com.bajaj.markets.credit.business.beans.Qualification;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.beans.ResponseBean;
import com.bajaj.markets.credit.business.beans.Specilizations;
import com.bajaj.markets.credit.business.beans.TokenResponse;
import com.bajaj.markets.credit.business.beans.Tokens;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.beans.Verification;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@SpringBootTest
public class CreditBusinessApiCallsHelperTest {

	@Mock
	CreditBusinessHelper creditBusinessHelper;

	@Mock
	BFLLoggerUtilExt logger;

	@InjectMocks
	CreditBusinessApiCallsHelper apiHelper;
	
	@Mock
	CustomDefaultHeaders customHeaders;
	
	@Mock
	private Environment env;

	private String getAddressURL = "getAddressURL";
	private String getAddressOnPincodeKeyUrl = "getAddressOnPincodeKeyUrl";
	private String getPanVerification = "getPanVerification";
	private String getLookupUrl = "getLookupUrl";
	private String getBmrDetails = "getBmrDetails";
	private String getBmr2ResponseFromMongo="getBmr2ResponseFromMongo";
	private String getCreditVidyaStatus = "getCreditVidyaStatus";
	private String getProductListUrl = "getProductListUrl";
	private String getCreditApplication = "getCreditApplication";
	private String getOffersUrl = "getOffersUrl";
	private String getEmailUrl = "getEmailUrl";
	private String getAddressURLV2 = "getAddressURLV2";
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(apiHelper, "getAddressURL", getAddressURL);
		ReflectionTestUtils.setField(apiHelper, "getAddressOnPincodeKeyUrl", getAddressOnPincodeKeyUrl);
		ReflectionTestUtils.setField(apiHelper, "getPanVerification", getPanVerification);
		ReflectionTestUtils.setField(apiHelper, "getLookupUrl", getLookupUrl);
		ReflectionTestUtils.setField(apiHelper, "getBmrDetails", getBmrDetails);
		ReflectionTestUtils.setField(apiHelper, "getBmr2ResponseFromMongo", getBmr2ResponseFromMongo);
		ReflectionTestUtils.setField(apiHelper, "customHeaders", customHeaders);
		ReflectionTestUtils.setField(apiHelper, "getProductListUrl", getProductListUrl);
		ReflectionTestUtils.setField(apiHelper, "getCreditApplication", getCreditApplication);
		ReflectionTestUtils.setField(apiHelper, "getOffersUrl", getOffersUrl);
		ReflectionTestUtils.setField(apiHelper, "getEmailUrl", getEmailUrl);
		ReflectionTestUtils.setField(apiHelper, "getAddressURLV2", getAddressURLV2);
		ReflectionTestUtils.setField(apiHelper, "specialisationUrl", "https://www.testingurl.com");
		ReflectionTestUtils.setField(apiHelper, "qualificationUrl", "https://www.testingurl.com");
		ReflectionTestUtils.setField(apiHelper, "documentDetailUrl", "http://omcreditapplicationservice.dev.bfsgodirect.com/v1/creditapplication/applications/{applicationid}/userprofiles/{userattributekey}/documentdetails");
	}

	@Test
	public void testGetOccupation() {
		Gson g = new Gson();
		Occupation occupation = g.fromJson(
				"{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":82,\"code\":null,\"value\":\"BAJAJ FINANCE LTD\"},\"designation\":{\"key\":null,\"code\":null,\"value\":\"developer\"},\"experience\":\"39\",\"netSalary\":\"5000\"},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":{\"key\":null,\"code\":null,\"value\":null},\"industryType\":{\"key\":null,\"code\":null,\"value\":null},\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":null,\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null}} ",
				Occupation.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.eq(Occupation.class), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(occupation, HttpStatus.OK));

		OccupationReference[] occupationRef = g.fromJson(
				"[{\"occupationKey\":1,\"occupationCode\":\"SALR\",\"occupationValue\":\"Salaried\",\"isactive\":1},{\"occupationKey\":2,\"occupationCode\":\"SEMP\",\"occupationValue\":\"Self Employed\",\"isactive\":1},{\"occupationKey\":6,\"occupationCode\":\"DOC\",\"occupationValue\":\"Doctor\",\"isactive\":1},{\"occupationKey\":7,\"occupationCode\":\"CAICWA\",\"occupationValue\":\"CA/ICWA\",\"isactive\":1}] ",
				OccupationReference[].class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.eq(OccupationReference[].class), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(occupationRef, HttpStatus.OK));
		apiHelper.getOccupationValue(new HashMap());
	}

	@Test
	public void testGetAllResitypes() {
		Gson g = new Gson();
		ResidenceMaster[] resi = g.fromJson(
				"[{\"residenceKey\":3,\"residenceCode\":\"ORGPROV\",\"residenceValue\":\"Company/Govt provided\",\"isactive\":1},{\"residenceKey\":1,\"residenceCode\":\"OWN\",\"residenceValue\":\"Own\",\"isactive\":1},{\"residenceKey\":5,\"residenceCode\":\"PAYGUEST\",\"residenceValue\":\"Paying Guest\",\"isactive\":1},{\"residenceKey\":2,\"residenceCode\":\"RENTAL\",\"residenceValue\":\"Rental staying alone\",\"isactive\":1},{\"residenceKey\":6,\"residenceCode\":\"RENTALFAMILY\",\"residenceValue\":\"Rental with family\",\"isactive\":1},{\"residenceKey\":7,\"residenceCode\":\"RENTALOTH\",\"residenceValue\":\"Rental with friends/relatives\",\"isactive\":1},{\"residenceKey\":8,\"residenceCode\":\"OTHERS\",\"residenceValue\":\"Others\",\"isactive\":1}] ",
				ResidenceMaster[].class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.eq(ResidenceMaster[].class), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(resi, HttpStatus.OK));
		apiHelper.getAllResitypes();
	}

	
	@Test
	public void testGetAddress() {
		Gson g = new Gson();
		Address address = g.fromJson(
				"{\"addressKey\":\"1477\",\"addressTypeKey\":\"1\",\"resiType\":null,\"addressLine1\":\"line 1 address\",\"addressLine2\":\"line 2 address\",\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":\"line 3 address\"} ",
				Address.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getAddressURL), Mockito.eq(Address.class), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(address, HttpStatus.OK));

		LocationResponseBean pin = g.fromJson(
				"{\"pincodeKey\":116159,\"pincode\":\"411041\",\"cityKey\":1784,\"cityCode\":\"1948\",\"cityName\":\"PUNE\",\"stateKey\":257,\"stateName\":\"MAHARASHTRA\",\"countryKey\":91,\"countryCode\":\"IN\",\"countryName\":\"INDIA\",\"pinNegativeAreaFlg\":0,\"pinOglFlg\":0,\"stateCode\":\"MH\"}",
				LocationResponseBean.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getAddressOnPincodeKeyUrl), Mockito.eq(LocationResponseBean.class),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(pin, HttpStatus.OK));
		apiHelper.getAddress(new HttpHeaders(), new HashMap<>());
	}

	@Test
	public void testPanVerification() {
		Gson g = new Gson();
		JSONObject panResp = g.fromJson(
				"{\"panNumber\":\"ASWPJ1234H\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"applicantKey\":\"122259\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"nameMatch\":false,\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263}}",
				JSONObject.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getPanVerification), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(panResp, HttpStatus.OK));
		apiHelper.getPanVerification(1100000000007332L, 122259L);
	}

	@Test
	public void testgetLookupByCode() {
		Mockito.when(
				creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getLookupUrl), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(new JSONObject(), HttpStatus.OK));
		apiHelper.getLookupByCode("BUSINESSVINTAGE");
	}

	@Test
	public void getPinCodeMaster() {
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getAddressOnPincodeKeyUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(new LocationResponseBean(), HttpStatus.OK));
		apiHelper.getPinCodeMaster("123");
	}
	
	@Test
	public void testBMRDetails() {
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getBmrDetails), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity("{}", HttpStatus.OK)  );
		apiHelper.getBmrDetails("1100000000007332");
	}
	
	@Test
	public void testBMR2ResponseFromMongo() {
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getBmr2ResponseFromMongo), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity("{}", HttpStatus.OK)  );
		apiHelper.getBmr2ResponseFromMongo("1100000000007332");
	}
	
	@Test
	public void testGetIndustryType() {
		ResponseEntity<Object> industrymaster = new ResponseEntity<Object>(popCustDerivedIndustryMaster(),
				HttpStatus.OK);
		doReturn(industrymaster).when(creditBusinessHelper).invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any());
		apiHelper.getIndustryType(123L);
	}
	
	private List<CustDerivedIndustryMaster> popCustDerivedIndustryMaster() {
		List<CustDerivedIndustryMaster> list = new ArrayList<>();
		CustDerivedIndustryMaster custDerivedIndustryMaster = new CustDerivedIndustryMaster();
		custDerivedIndustryMaster.setCategoryCd("");
		custDerivedIndustryMaster.setCustIndMastCode("");
		custDerivedIndustryMaster.setCustIndMastDesc("");
		custDerivedIndustryMaster.setCustIndMastKey(123L);
		custDerivedIndustryMaster.setCustIndMastSubSectorCode("");
		custDerivedIndustryMaster.setIsActive(1);
		custDerivedIndustryMaster.setLastUpdateBy(12l);
		custDerivedIndustryMaster.setLastUpdateDt(new Timestamp(System.currentTimeMillis()));
		list.add(custDerivedIndustryMaster);
		return list;
	}
	
	@Test
	public void testGetIndustryTypeWithDifferentalue() {
		ResponseEntity<Object> industrymaster = new ResponseEntity<Object>(popCustDerivedIndustryMasterDifferentValues(),
				HttpStatus.OK);
		doReturn(industrymaster).when(creditBusinessHelper).invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any());
		apiHelper.getIndustryType(123L);
	}
	
	private List<CustDerivedIndustryMaster> popCustDerivedIndustryMasterDifferentValues() {
		List<CustDerivedIndustryMaster> list = new ArrayList<>();
		CustDerivedIndustryMaster custDerivedIndustryMaster = new CustDerivedIndustryMaster();
		custDerivedIndustryMaster.setCategoryCd("");
		custDerivedIndustryMaster.setCustIndMastCode("");
		custDerivedIndustryMaster.setCustIndMastDesc("");
		custDerivedIndustryMaster.setCustIndMastKey(111L);
		custDerivedIndustryMaster.setCustIndMastSubSectorCode("");
		custDerivedIndustryMaster.setIsActive(1);
		custDerivedIndustryMaster.setLastUpdateBy(12l);
		custDerivedIndustryMaster.setLastUpdateDt(new Timestamp(System.currentTimeMillis()));
		list.add(custDerivedIndustryMaster);
		return list;
	}
	
	@Test
	public void testGetPropertyDetails() {
		String applicationId = "123456";
		Map<String, String> params = new HashMap<>();
		params.put("userattributekey", "1919");
		PropertyAdditionalDetails prop=new PropertyAdditionalDetails();
		PropertyPageDetails propertyDetails = new PropertyPageDetails();
		propertyDetails.setAppPropertyDetKey(12L);
		propertyDetails.setCreated(true);
		propertyDetails.setIsPropertyIdentified(true);
		propertyDetails.setPropertySizeInSqrFeet(new BigDecimal(3));
		prop.setPropertyDetails(propertyDetails);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(prop.getPropertyDetails(), HttpStatus.OK));
		apiHelper.getPropertyDetails(applicationId);
	}
	
	@Test
	public void testgetHlProductIntent() {
		String applicationId = "123456";
		Map<String, String> params = new HashMap<>();
		params.put("userattributekey", "1919");
		ApplicationDetail applicationDetail = new ApplicationDetail();
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(applicationDetail, HttpStatus.OK));
		apiHelper.getHlProductIntent(applicationId);
	}
	
	
	@Test
	public void testgetPropertyAddressDetails() {
		String applicationId = "123456";

		Map<String, String> params = new HashMap<>();
		params.put("userattributekey", "1919");

		List<UserProfileBean> userProfileList = new ArrayList<>();
		UserProfileBean userProfile = new UserProfileBean();
		userProfile.setApplicationUserAttributeKey("1919");
		userProfile.setApplicationUserAttributeType("1");
		userProfileList.add(userProfile);

		Address address = new Address();
		address.setAddressKey("50");
		address.setAddressLine1("");
		address.setAddressLine2("");
		address.setAddressSource("");
		address.setAddressTypeKey("");
		address.setCityKey("");
		address.setCountryKey("");
		address.setPincode("");
		address.setPincodeKey("1234");
		address.setResiType("");
		address.setStateKey("");
		address.setVerification(new Verification());

		LocationResponseBean locationResponseBean = new LocationResponseBean();
		locationResponseBean.setCityCode("");
		locationResponseBean.setCityKey(5l);
		locationResponseBean.setCityName("");
		locationResponseBean.setCountryCode("");
		locationResponseBean.setCountryKey(2l);
		locationResponseBean.setPincode("");
		locationResponseBean.setPincodeKey(3l);
		locationResponseBean.setPinNegativeAreaFlg(1);
		locationResponseBean.setPinOglFlg(0);
		locationResponseBean.setStateCode("");
		locationResponseBean.setStateKey(3l);
		locationResponseBean.setStateName("");

		JSONObject json = new JSONObject();
		json.put("hlProductIntent", "HLF");
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(userProfileList, HttpStatus.OK))
				.thenReturn(new ResponseEntity(address, HttpStatus.OK))
				.thenReturn(new ResponseEntity(locationResponseBean, HttpStatus.OK));
		apiHelper.getPropertyAddressDetails(applicationId);
	}

	public void testGetOccupationValue(){
		doThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, null))
		.when(creditBusinessHelper).invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
		apiHelper.getOccupationValue(null);
	}
	
	@Test
	public void testGetCreditVidyaStatus() {
		Gson g = new Gson();
		JSONObject creditVidyaResp = g.fromJson(
				"{\"applicantKey\":null,\"city\":\"PUNE\",\"mobileNumber\":\"9909010002\",\"dob\":\"1990-12-03 00:00:00.0\",\"companyName\":null,\"applicationKey\":\"1100000000012440\",\"fullName\":\"abc xyz\",\"emailId\":\"abcd@cognizant.com\",\"validationstatus\":\"Medium Risk\",\"salary\":null,\"l2ProductKey\":\"10002\",\"verification\":null}",
				JSONObject.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getCreditVidyaStatus), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(creditVidyaResp, HttpStatus.OK));
		apiHelper.getCreditVidyaStatus("1100000000007332", null);
	}
	
	@Test
	public void testGetCreditVidyaStatusNullValue() {
		apiHelper.getCreditVidyaStatus(null, null);
	}
	
	@Test
	public void testGetProductListForApplication() {
		Gson g = new GsonBuilder().serializeNulls().create();
		ProductList productList = g.fromJson(
				"{\"productList\":[{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.0,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":2,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLHFL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.1,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":200000,\"tenor\":48},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":\"FICCLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.2,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":0,\"priorityOrder\":4,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":\"BFLPLCSTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"Fullerton Personal loan - Business Owner\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Pocket Personal Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPPL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPPL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - C.A.\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLCAL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLCAL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - DOCTOR\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLDOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLDOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Business Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null}],\"requiredLoanAmout\":null,\"requiredTenor\":null,\"maxEligibility\":null,\"maxTenor\":null,\"name\":null} ",
				ProductList.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getProductListUrl), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(productList, HttpStatus.OK));
		apiHelper.getProductListForApplication("123");
	}
	
	@Test
	public void testGetIncomeEstimation_And_testFetchChannelJson() {
		List<JSONObject> incomeEstimationList = new ArrayList<JSONObject>();
		JSONObject incomeEstimation = new JSONObject();
		
		incomeEstimation.put("status", "COMPLETED");
		incomeEstimation.put("statementCollected", 3.0d);
		incomeEstimation.put("channelResponse", "channel response json");
		
		incomeEstimationList.add(incomeEstimation);
		
		doReturn(new ResponseEntity<>(incomeEstimationList, HttpStatus.OK))
			.doReturn(new ResponseEntity<>(incomeEstimation, HttpStatus.OK))
			.when(creditBusinessHelper).invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any());
		
		Assert.assertNotNull(apiHelper.getIncomeEstimation("1234",null));
		Assert.assertNotNull(apiHelper.fetchIncomeEstimatedChannelJson("1000"));
	}
	
	@Test
	public void testGetIncomeEstimation_And_testFetchChannelJson_NotFound() {
		doThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, null)).when(creditBusinessHelper).invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any());
		
		Assert.assertNull(apiHelper.getIncomeEstimation("1234",null));
		Assert.assertNull(apiHelper.fetchIncomeEstimatedChannelJson("1000"));
	}
	
	@Test (expected = CreditBusinessException.class)
	public void testGetIncomeEstimation_AnotherHttpException() {
		doThrow(new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, null)).when(creditBusinessHelper).invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any());
		
		apiHelper.getIncomeEstimation("1234",null);
	}
	
	@Test (expected = CreditBusinessException.class)
	public void testFetchIncomeEstimatedChannelJson_AnotherHttpException() {
		doThrow(new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, null)).when(creditBusinessHelper).invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any());
		
		apiHelper.fetchIncomeEstimatedChannelJson("1000");
	}
	
	@Test
	public void testgetApplicationDetails() {
		Gson g = new GsonBuilder().serializeNulls().create();
		ApplicationDetail app = g.fromJson(
				"{\"applicationKey\":\"1100000000034743\",\"parentApplicationKey\":\"1100000000034743\",\"mobile\":null,\"dateofbirth\":null,\"applicantKey\":null,\"l2ProductKey\":10002,\"l2ProductCode\":\"OMPL\",\"l3ProductKey\":null,\"l3ProductCode\":null,\"l4ProductKey\":null,\"l4ProductCode\":null,\"applicationStatus\":1,\"riskoffertype\":null,\"principalKey\":null,\"loanPurpose\":null,\"hlProductIntent\":null,\"l2ProductDesc\":\"OM Personal loan\",\"l3ProductDesc\":null,\"l4ProductDesc\":null,\"inProcessing\":false} ",
				ApplicationDetail.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getCreditApplication), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(app, HttpStatus.OK));
		apiHelper.getApplicationDetails("123", new HttpHeaders());
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testgetApplicationDetails_500() {
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getCreditApplication), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(null, HttpStatus.INTERNAL_SERVER_ERROR));
		apiHelper.getApplicationDetails("123", new HttpHeaders());
	}
	
	@Test
	public void testgetPrincipalCustInfo() {
		Gson g = new GsonBuilder().serializeNulls().create();
		JSONObject output = g.fromJson(
				"{\"principalKey\":3,\"principleCustRefSrc\":\"CUSTOMER_ID_API\",\"btsSegment\":null,\"principleCustKey\":25774,\"isEtb\":true,\"applicationKey\":1100000000034743,\"principleCustRefId\":\"99790628\",\"principleCustType\":null,\"appattrbkey\":null,\"additionalDetails\":null,\"principleCustSegment\":null} ",
				JSONObject.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getCreditApplication), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(output, HttpStatus.OK));
		apiHelper.getPrincipalCustInfo("123", "1123");
	}
	
	@Test
	public void testFetchOffers() {
		Gson g = new GsonBuilder().serializeNulls().create();
		JSONObject output = g.fromJson(
				"{\"principalKey\":3,\"principleCustRefSrc\":\"CUSTOMER_ID_API\",\"btsSegment\":null,\"principleCustKey\":25774,\"isEtb\":true,\"applicationKey\":1100000000034743,\"principleCustRefId\":\"99790628\",\"principleCustType\":null,\"appattrbkey\":null,\"additionalDetails\":null,\"principleCustSegment\":null} ",
				JSONObject.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getOffersUrl), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(output, HttpStatus.OK));
		apiHelper.fetchOffers("123", "BFLPLCS", new HttpHeaders());
	}
	
	@Test
	public void testGetEmail() {
		Gson g = new GsonBuilder().serializeNulls().create();
		Email email = new Email();
		email.setEmail("abcd@cognizant.com");
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getEmailUrl), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(email, HttpStatus.OK));
		apiHelper.getEmail("123", "123", "1123");
	}
	
	@Test
	public void testSaveVerificationDetails() {
		apiHelper.saveVerificationDetails("123", "MOBILE", "BFSD_OTP");
	}
	
	@Test
	public void testSaveVerificationDetails_ExceptionOccurred() {
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(CreditBusinessException.class);
		apiHelper.saveVerificationDetails("123", "MOBILE", "BFSD_OTP");
	}
	
	@Test
	public void testGetPinCodeMasterByPinCode() {
		String pincode = "411022";
		LocationAddressBean addressBean = new LocationAddressBean();
		addressBean.setCityId(123l);
		addressBean.setCountryId(91l);
		addressBean.setPinId(7667l);
		addressBean.setStateId(26l);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(addressBean, HttpStatus.OK));
		LocationAddressBean loationAddressBean = apiHelper.getPinCodeMasterByPinCode(pincode);
		Assert.assertNotNull(loationAddressBean);
	}

	@Test
	public void testGetCommercialFormatCibilForCards() {
		String cibilRefenceKey = "1234";
		String cibilJson = "{\"cibilReferenceKey\":5557,\"applicationKey\":1100000000014129,\"applicantKey\":141443,\"headersCount\":4,\"cibilAdditionalFlag\":true,\"firstCibilRecord\":{\"cibilResponse\":{\"dataSegmentOccurrencePosition\":1,\"cibilAdditionalFlag\":true,\"cibilHeader\":{\"segmentTag\":\"TUEF\",\"version\":\"12\",\"memberRefNum\":\"00005981712401\",\"futureUse1\":\"\",\"futureUse2\":\"0000\",\"enquiryMemberId\":\"NB66036266\",\"subjectReturnCode\":\"1\",\"enquiryControlNumber\":\"002790036743\",\"dateProcessed\":\"07022019\",\"timeProcessed\":\"173534\"},\"consumerName\":{\"segmentTag\":\"N01\",\"consumerNameField1\":\"BRENDA CHRISTOPHER\",\"consumerNameField2\":\"FERNANDES\",\"consumerNameField3\":\"\",\"consumerNameField4\":\"\",\"consumerNameField5\":\"\",\"dob\":\"02011988\",\"gender\":\"1\",\"dateForErrorCode\":\"\",\"errorSegmentTag\":\"\",\"errorcode\":\"\",\"dateForCibilRemarkCode\":\"\",\"cibilRemarkCode\":\"\",\"dateForErrorOrDisputeCode\":\"\",\"dateForErrorOrDisputeCode1\":\"\",\"dateForErrorOrDisputeCode2\":\"\"},\"employment\":{\"segmentTag\":\"E01\",\"accountType\":\"05\",\"dateReportAndCert\":\"31122018\",\"occupationCode\":\"04\",\"income\":\"\",\"netGrossIncomeIndicator\":\"\",\"monthOrAnnualIncomeIndicator\":\"\",\"dateForErrorCode\":\"\",\"errorCode\":\"\",\"dateForCibilRemarkCode\":\"\",\"cibilRemarkCode\":\"\",\"dateForErrorOrDisputeCode\":\"\",\"dateForErrorOrDisputeCode1\":\"\",\"dateForErrorOrDisputeCode2\":\"\"},\"cibilScore\":{\"scoreName\":\"CIBILTUSCR\",\"scoreCardName\":\"01\",\"scoreCardVersion\":\"10\",\"scoreDate\":\"07022019\",\"score\":\"0\",\"exclusionCode1\":\"\",\"exclusionCode2\":\"\",\"exclusionCode3\":\"\",\"exclusionCode4\":\"\",\"exclusionCode5\":\"\",\"exclusionCode6\":\"\",\"exclusionCode7\":\"\",\"exclusionCode8\":\"\",\"exclusionCode9\":\"\",\"exclusionCode10\":\"\",\"reasonCode1\":\"\",\"reasonCode2\":\"\",\"reasonCode3\":\"\",\"reasonCode4\":\"\",\"reasonCode5\":\"\",\"errorCode\":\"\",\"bureauCharacteristics17\":\"\",\"bureauCharacteristics27\":\"\",\"bureauCharacteristics37\":\"\",\"bureauCharacteristics47\":\"\",\"bureauCharacteristics57\":\"\",\"bureauCharacteristics67\":\"\",\"bureauCharacteristics77\":\"\"},\"consumerAddress\":[{\"segmentTag\":\"A01\",\"addressLine1\":\"ROOM NO 1 BABA TIWARI PLOT  ,JAWAHAR\",\"addressLine2\":\"NAGAR  ,KHAR EAST , ,OPP SHIVAM HOTEL ,\",\"addressLine3\":\"MUMBAI\",\"addressLine4\":\"\",\"addressLine5\":\"\",\"stateCode\":\"27\",\"pinCode\":\"400055\",\"addressCategory\":\"02\",\"residenceCode\":\"\",\"dateReported\":\"07122018\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"Y\"},{\"segmentTag\":\"A02\",\"addressLine1\":\"A 301 KRISHNA BUILDING,JANGID COMPLEX\",\"addressLine2\":\"\",\"addressLine3\":\"\",\"addressLine4\":\"\",\"addressLine5\":\"MUMBAI\",\"stateCode\":\"27\",\"pinCode\":\"401107\",\"addressCategory\":\"04\",\"residenceCode\":\"\",\"dateReported\":\"15102018\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"Y\"},{\"segmentTag\":\"A03\",\"addressLine1\":\"A 301, KRISHNA BLDG,JANGID\",\"addressLine2\":\"\",\"addressLine3\":\"\",\"addressLine4\":\"\",\"addressLine5\":\"MUMBAI\",\"stateCode\":\"27\",\"pinCode\":\"401107\",\"addressCategory\":\"04\",\"residenceCode\":\"\",\"dateReported\":\"15102018\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"Y\"},{\"segmentTag\":\"A04\",\"addressLine1\":\"J P MORGAN SRVS INDIA PVT LTD\",\"addressLine2\":\"6TH FLR MAUNUS TOWER MIND\",\"addressLine3\":\"SPACE LINK ROAD MALAD WEST\",\"addressLine4\":\"\",\"addressLine5\":\"MUMBAI\",\"stateCode\":\"27\",\"pinCode\":\"400064\",\"addressCategory\":\"02\",\"residenceCode\":\"02\",\"dateReported\":\"31082018\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"\"},{\"segmentTag\":\"A04\",\"addressLine1\":\"J P MORGAN SRVS INDIA PVT LTD\",\"addressLine2\":\"6TH FLR MAUNUS TOWER MIND\",\"addressLine3\":\"SPACE LINK ROAD MALAD WEST\",\"addressLine4\":\"\",\"addressLine5\":\"MUMBAI\",\"stateCode\":\"27\",\"pinCode\":\"400064\",\"addressCategory\":\"03\",\"residenceCode\":\"02\",\"dateReported\":\"31082018\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"\"},{\"segmentTag\":\"A04\",\"addressLine1\":\"J P MORGAN SRVS INDIA PVT LTD\",\"addressLine2\":\"6TH FLR MAUNUS TOWER MIND\",\"addressLine3\":\"SPACE LINK ROAD MALAD WEST\",\"addressLine4\":\"\",\"addressLine5\":\"MUMBAI\",\"stateCode\":\"27\",\"pinCode\":\"400064\",\"addressCategory\":\"03\",\"residenceCode\":\"02\",\"dateReported\":\"\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"\"}],\"accountDetail\":[{\"segmentTag\":\"T001\",\"reportingShortName\":\"NOT DISCLOSED\",\"accountNumber\":\"\",\"accountType\":\"05\",\"ownershipIndicator\":\"1\",\"dateOpenedOrDisbursed\":\"11122018\",\"dateLastPayment\":\"\",\"dateClosed\":\"\",\"dateReportedAndCert\":\"31122018\",\"highCreditSanctionAmt\":\"200000\",\"currentBalance\":\"200000\",\"amountOverdue\":\"\",\"paymentHistory1\":\"000\",\"paymentHistory2\":\"\",\"paymentHistoryStartDate\":\"01122018\",\"paymentHistoryEndDate\":\"01122018\",\"suitFieldWilfulDefault\":\"\",\"writtenoffAndSettledStatus\":\"\",\"valueOfCollateral\":\"\",\"typeOfCollateral\":\"\",\"creditLimit\":\"\",\"cashLimit\":\"\",\"rateOfInterest\":\"\",\"repaymentTenure\":\"\",\"emiAmount\":\"\",\"writtenoffAmountTotal\":\"\",\"writtenoffAmountPrincipal\":\"\",\"settlementAmount\":\"\",\"paymentFrequency\":\"03\",\"actualPaymentAmount\":\"\",\"dateForErrorCode\":\"\",\"errorCode\":\"\",\"dateForCibilRemarkCode\":\"\",\"cibilRemarkCode\":\"\",\"dateForErrorOrDisputeCode\":\"\",\"dateForErrorOrDisputeCode1\":\"\",\"dateForErrorOrDisputeCode2\":\"\"},{\"segmentTag\":\"T002\",\"reportingShortName\":\"NOT DISCLOSED\",\"accountNumber\":\"\",\"accountType\":\"10\",\"ownershipIndicator\":\"1\",\"dateOpenedOrDisbursed\":\"31082018\",\"dateLastPayment\":\"05122018\",\"dateClosed\":\"\",\"dateReportedAndCert\":\"31122018\",\"highCreditSanctionAmt\":\"24498\",\"currentBalance\":\"23162\",\"amountOverdue\":\"\",\"paymentHistory1\":\"000000000000000\",\"paymentHistory2\":\"\",\"paymentHistoryStartDate\":\"01122018\",\"paymentHistoryEndDate\":\"01082018\",\"suitFieldWilfulDefault\":\"\",\"writtenoffAndSettledStatus\":\"\",\"valueOfCollateral\":\"\",\"typeOfCollateral\":\"\",\"creditLimit\":\"\",\"cashLimit\":\"\",\"rateOfInterest\":\"\",\"repaymentTenure\":\"\",\"emiAmount\":\"\",\"writtenoffAmountTotal\":\"\",\"writtenoffAmountPrincipal\":\"\",\"settlementAmount\":\"\",\"paymentFrequency\":\"\",\"actualPaymentAmount\":\"\",\"dateForErrorCode\":\"\",\"errorCode\":\"\",\"dateForCibilRemarkCode\":\"\",\"cibilRemarkCode\":\"\",\"dateForErrorOrDisputeCode\":\"\",\"dateForErrorOrDisputeCode1\":\"\",\"dateForErrorOrDisputeCode2\":\"\"}],\"enquiryDetails\":[{\"segmentTag\":\"I001\",\"dateOFEnquiry\":\"01022019\",\"enquiringMemberShortName\":\"NOT DISCLOSED\",\"enquiryPurpose\":\"02\",\"enquiryAmount\":\"2500000\"},{\"segmentTag\":\"I002\",\"dateOFEnquiry\":\"19012019\",\"enquiringMemberShortName\":\"NOT DISCLOSED\",\"enquiryPurpose\":\"02\",\"enquiryAmount\":\"2000000\"},{\"segmentTag\":\"I003\",\"dateOFEnquiry\":\"07122018\",\"enquiringMemberShortName\":\"NOT DISCLOSED\",\"enquiryPurpose\":\"05\",\"enquiryAmount\":\"200000\"},{\"segmentTag\":\"I004\",\"dateOFEnquiry\":\"04112018\",\"enquiringMemberShortName\":\"NOT DISCLOSED\",\"enquiryPurpose\":\"05\",\"enquiryAmount\":\"200000\"},{\"segmentTag\":\"I005\",\"dateOFEnquiry\":\"15102018\",\"enquiringMemberShortName\":\"NOT DISCLOSED\",\"enquiryPurpose\":\"05\",\"enquiryAmount\":\"200000\"}],\"consumerTelephone\":[{\"segmentTag\":\"T01\",\"telNumber\":\"22334455\",\"telExtension\":\"\",\"telType\":\"00\",\"enrichedEnquiry\":\"Y\"},{\"segmentTag\":\"T02\",\"telNumber\":\"61250000\",\"telExtension\":\"\",\"telType\":\"03\",\"enrichedEnquiry\":\"\"},{\"segmentTag\":\"T03\",\"telNumber\":\"40277777\",\"telExtension\":\"\",\"telType\":\"03\",\"enrichedEnquiry\":\"\"},{\"segmentTag\":\"T04\",\"telNumber\":\"9867010360\",\"telExtension\":\"\",\"telType\":\"01\",\"enrichedEnquiry\":\"\"}],\"consumerEmail\":[{\"segmentTag\":\"C01\",\"emailId\":\"VAZ_BRENDA@YAHOO.COM\"}],\"consumerIdentity\":[{\"segmentTag\":\"I01\",\"idType\":\"01\",\"idNumber\":\"AEUPV4890D\",\"issueDate\":\"\",\"expiryDate\":\"\",\"enrichedEnquiry\":\"\"},{\"segmentTag\":\"I02\",\"idType\":\"06\",\"idNumber\":\"864219917400\",\"issueDate\":\"\",\"expiryDate\":\"\",\"enrichedEnquiry\":\"\"}]}},\"additionalCibilRecordsList\":[{\"cibilResponse\":{\"dataSegmentOccurrencePosition\":2,\"cibilAdditionalFlag\":true,\"cibilHeader\":{\"segmentTag\":\"TUEF\",\"version\":\"12\",\"memberRefNum\":\"00005981712401\",\"futureUse1\":\"\",\"futureUse2\":\"0000\",\"enquiryMemberId\":\"NB66036266\",\"subjectReturnCode\":\"1\",\"enquiryControlNumber\":\"000000000000\",\"dateProcessed\":\"07022019\",\"timeProcessed\":\"173534\"},\"consumerName\":{\"segmentTag\":\"N01\",\"consumerNameField1\":\"BRENDA BRENDA VAZ\",\"consumerNameField2\":\"\",\"consumerNameField3\":\"\",\"consumerNameField4\":\"\",\"consumerNameField5\":\"\",\"dob\":\"02011988\",\"gender\":\"2\",\"dateForErrorCode\":\"\",\"errorSegmentTag\":\"\",\"errorcode\":\"\",\"dateForCibilRemarkCode\":\"\",\"cibilRemarkCode\":\"\",\"dateForErrorOrDisputeCode\":\"\",\"dateForErrorOrDisputeCode1\":\"\",\"dateForErrorOrDisputeCode2\":\"\"},\"consumerAddress\":[{\"segmentTag\":\"A01\",\"addressLine1\":\"301 A WING KRISHNA BLDG MUMBAI\",\"addressLine2\":\"\",\"addressLine3\":\"\",\"addressLine4\":\"\",\"addressLine5\":\"\",\"stateCode\":\"27\",\"pinCode\":\"401107\",\"addressCategory\":\"02\",\"residenceCode\":\"\",\"dateReported\":\"29082018\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"Y\"},{\"segmentTag\":\"A02\",\"addressLine1\":\"MAGNUS TOWERS 5TH FLOOR ,MALAD W ,, , ,\",\"addressLine2\":\"MUMBAI\",\"addressLine3\":\"\",\"addressLine4\":\"\",\"addressLine5\":\"\",\"stateCode\":\"27\",\"pinCode\":\"400064\",\"addressCategory\":\"03\",\"residenceCode\":\"\",\"dateReported\":\"20062018\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"Y\"},{\"segmentTag\":\"A03\",\"addressLine1\":\"SERCO HOUSE MINDSPACE LINK ROAD MALAD W\",\"addressLine2\":\"\",\"addressLine3\":\"\",\"addressLine4\":\"\",\"addressLine5\":\"\",\"stateCode\":\"27\",\"pinCode\":\"400064\",\"addressCategory\":\"03\",\"residenceCode\":\"\",\"dateReported\":\"31122014\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"\"},{\"segmentTag\":\"A04\",\"addressLine1\":\"BABA TIWARI PLOT ROOM NO 1 ,JAWAHAR\",\"addressLine2\":\"NAGAR KHAR EAST ,, ,OPP SHIVAM HOTEL ,\",\"addressLine3\":\"MUMBAI\",\"addressLine4\":\"\",\"addressLine5\":\"\",\"stateCode\":\"27\",\"pinCode\":\"400055\",\"addressCategory\":\"04\",\"residenceCode\":\"\",\"dateReported\":\"30092014\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"Y\"}],\"consumerTelephone\":[{\"segmentTag\":\"T01\",\"telNumber\":\"6125800\",\"telExtension\":\"\",\"telType\":\"03\",\"enrichedEnquiry\":\"Y\"},{\"segmentTag\":\"T02\",\"telNumber\":\"9867010360\",\"telExtension\":\"\",\"telType\":\"01\",\"enrichedEnquiry\":\"\"}],\"consumerEmail\":[{\"segmentTag\":\"C01\",\"emailId\":\"VAZ_BRENDA@YAHOO.COM\"}],\"consumerIdentity\":[{\"segmentTag\":\"I01\",\"idType\":\"01\",\"idNumber\":\"AEUPV4890D\",\"issueDate\":\"\",\"expiryDate\":\"\",\"enrichedEnquiry\":\"\"},{\"segmentTag\":\"I02\",\"idType\":\"06\",\"idNumber\":\"864219917400\",\"issueDate\":\"\",\"expiryDate\":\"\",\"enrichedEnquiry\":\"Y\"}]}},{\"cibilResponse\":{\"dataSegmentOccurrencePosition\":3,\"cibilAdditionalFlag\":true,\"cibilHeader\":{\"segmentTag\":\"TUEF\",\"version\":\"12\",\"memberRefNum\":\"00005981712401\",\"futureUse1\":\"\",\"futureUse2\":\"0000\",\"enquiryMemberId\":\"NB66036266\",\"subjectReturnCode\":\"1\",\"enquiryControlNumber\":\"000000000000\",\"dateProcessed\":\"07022019\",\"timeProcessed\":\"173534\"},\"consumerName\":{\"segmentTag\":\"N01\",\"consumerNameField1\":\"BRENDA A VAZ\",\"consumerNameField2\":\"\",\"consumerNameField3\":\"\",\"consumerNameField4\":\"\",\"consumerNameField5\":\"\",\"dob\":\"02011988\",\"gender\":\"1\",\"dateForErrorCode\":\"\",\"errorSegmentTag\":\"\",\"errorcode\":\"\",\"dateForCibilRemarkCode\":\"\",\"cibilRemarkCode\":\"\",\"dateForErrorOrDisputeCode\":\"\",\"dateForErrorOrDisputeCode1\":\"\",\"dateForErrorOrDisputeCode2\":\"\"},\"consumerAddress\":[{\"segmentTag\":\"A01\",\"addressLine1\":\"BABA TIWARI PLOT ROOM NO 1\",\"addressLine2\":\"JAWAHAR NAGAR KHAR EAST\",\"addressLine3\":\"OPP SHIVAM HOTEL\",\"addressLine4\":\"\",\"addressLine5\":\"MUMBAI\",\"stateCode\":\"27\",\"pinCode\":\"400055\",\"addressCategory\":\"04\",\"residenceCode\":\"\",\"dateReported\":\"30092011\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"\"}],\"consumerTelephone\":[{\"segmentTag\":\"T01\",\"telNumber\":\"9867010360\",\"telExtension\":\"\",\"telType\":\"01\",\"enrichedEnquiry\":\"\"},{\"segmentTag\":\"T02\",\"telNumber\":\"2301066\",\"telExtension\":\"\",\"telType\":\"02\",\"enrichedEnquiry\":\"\"},{\"segmentTag\":\"T03\",\"telNumber\":\"66776000\",\"telExtension\":\"\",\"telType\":\"00\",\"enrichedEnquiry\":\"\"}],\"consumerIdentity\":[{\"segmentTag\":\"I01\",\"idType\":\"01\",\"idNumber\":\"AEUPV4890D\",\"issueDate\":\"\",\"expiryDate\":\"\",\"enrichedEnquiry\":\"\"}]}},{\"cibilResponse\":{\"dataSegmentOccurrencePosition\":4,\"cibilAdditionalFlag\":true,\"cibilHeader\":{\"segmentTag\":\"TUEF\",\"version\":\"12\",\"memberRefNum\":\"00005981712401\",\"futureUse1\":\"\",\"futureUse2\":\"0000\",\"enquiryMemberId\":\"NB66036266\",\"subjectReturnCode\":\"1\",\"enquiryControlNumber\":\"000000000000\",\"dateProcessed\":\"07022019\",\"timeProcessed\":\"173534\"},\"consumerName\":{\"segmentTag\":\"N01\",\"consumerNameField1\":\"BSENDA ANTHONY VAZ\",\"consumerNameField2\":\"\",\"consumerNameField3\":\"\",\"consumerNameField4\":\"\",\"consumerNameField5\":\"\",\"dob\":\"02011988\",\"gender\":\"1\",\"dateForErrorCode\":\"\",\"errorSegmentTag\":\"\",\"errorcode\":\"\",\"dateForCibilRemarkCode\":\"\",\"cibilRemarkCode\":\"\",\"dateForErrorOrDisputeCode\":\"\",\"dateForErrorOrDisputeCode1\":\"\",\"dateForErrorOrDisputeCode2\":\"\"},\"consumerAddress\":[{\"segmentTag\":\"A01\",\"addressLine1\":\"R N 1 BABA TIWARI CHAWL,GOLIBAR ROAD JAW\",\"addressLine2\":\"AHAR NGR,KHAR EAST MUMBAI\",\"addressLine3\":\"\",\"addressLine4\":\"\",\"addressLine5\":\"\",\"stateCode\":\"27\",\"pinCode\":\"400055\",\"addressCategory\":\"04\",\"residenceCode\":\"\",\"dateReported\":\"21092011\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"Y\"},{\"segmentTag\":\"A02\",\"addressLine1\":\"INTELENET GLOBAL SERVICES PVT INTELENET\",\"addressLine2\":\"TOWER PLOT CST NO 1406-A/28 MIND SPACE\",\"addressLine3\":\"MALAD (W)\",\"addressLine4\":\"\",\"addressLine5\":\"\",\"stateCode\":\"27\",\"pinCode\":\"400064\",\"addressCategory\":\"04\",\"residenceCode\":\"\",\"dateReported\":\"21092011\",\"memberShortName\":\"\",\"enrichedEnquiry\":\"Y\"}],\"consumerTelephone\":[{\"segmentTag\":\"T01\",\"telNumber\":\"9867010360,66776000\",\"telExtension\":\"\",\"telType\":\"00\",\"enrichedEnquiry\":\"Y\"}],\"consumerIdentity\":[{\"segmentTag\":\"I01\",\"idType\":\"01\",\"idNumber\":\"AEUPV4890D\",\"issueDate\":\"\",\"expiryDate\":\"\",\"enrichedEnquiry\":\"Y\"}]}}]}";
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(cibilJson, HttpStatus.OK));
		Assert.assertNotNull(apiHelper.getCommercialFormatCibil(cibilRefenceKey,"CONSUMERCIBIL","COMMERCIALCIBIL"));
	}
	
	@Test
	public void testGetAddressV2() {
		Gson g = new Gson();
		Address add = new Address();
		add.setPincodeKey("123");
		List<Address> addressList = new ArrayList<>();
		addressList.add(add);

		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getAddressURLV2), Mockito.eq(List.class), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(addressList, HttpStatus.OK));

		LocationResponseBean pin = g.fromJson(
				"{\"pincodeKey\":116159,\"pincode\":\"411041\",\"cityKey\":1784,\"cityCode\":\"1948\",\"cityName\":\"PUNE\",\"stateKey\":257,\"stateName\":\"MAHARASHTRA\",\"countryKey\":91,\"countryCode\":\"IN\",\"countryName\":\"INDIA\",\"pinNegativeAreaFlg\":0,\"pinOglFlg\":0,\"stateCode\":\"MH\"}",
				LocationResponseBean.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getAddressOnPincodeKeyUrl), Mockito.eq(LocationResponseBean.class),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(pin, HttpStatus.OK));
		apiHelper.getAddressV2(new HttpHeaders(), new HashMap<>());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testGetInternalToken() {
		TokenResponse tokenResponse = new TokenResponse();
		Tokens tokens = new Tokens();
		String token = "hsfjhdskjfhs";
		tokens.setToken(token);
		tokenResponse.setTokens(List.of(tokens));

		ResponseBean responseBean = new ResponseBean(tokenResponse);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(responseBean, HttpStatus.OK));
		assertEquals(token, apiHelper.getInternalToken("123"));
	}

	@SuppressWarnings("unchecked")
	@Test(expected = CreditBusinessException.class)
	public void testGetInternalToken_fail() {
		TokenResponse tokenResponse = new TokenResponse();
		Tokens tokens = new Tokens();
		String token = "hsfjhdskjfhs";
		tokens.setToken(token);
		tokenResponse.setTokens(List.of(tokens));

		ResponseBean responseBean = new ResponseBean(tokenResponse);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(responseBean, HttpStatus.INTERNAL_SERVER_ERROR));
		apiHelper.getInternalToken("123");
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetEmployeeTypes() {
		EmployerTypeBean employerTypeBean = new EmployerTypeBean();
		employerTypeBean.setEmployertypekey(1L);
		employerTypeBean.setEmployertypecode("PUBLIC");
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(List.of(employerTypeBean), HttpStatus.OK));
		assertEquals(1, apiHelper.getEmployeeTypes().size());
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetCityDetails() {
		CityResponseBean cityResponseBean = new CityResponseBean();
		cityResponseBean.setCityname("PUNE");
		Gson g = new GsonBuilder().serializeNulls().create();
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(g.toJson(cityResponseBean), HttpStatus.OK));
		assertEquals(cityResponseBean.getCityname(), apiHelper.getCityDetails("1234").getCityname());
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetCityDetails_fail() {
		CityResponseBean cityResponseBean = new CityResponseBean();
		cityResponseBean.setCityname("PUNE");
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(cityResponseBean, HttpStatus.OK));
		assertNull(apiHelper.getCityDetails("1234").getCityname());
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetCibilReference() {
		CibilResponse cibilResponseObj = new CibilResponse();
		CibilTypeAndScore cibilTypeAndScore = new CibilTypeAndScore();
		cibilTypeAndScore.setScoreV3("777");
		cibilResponseObj.setCibilTypeAndScore(List.of(cibilTypeAndScore));
		CibilResponse[] cibilResponse = new CibilResponse[] { cibilResponseObj };
		Gson gsonObject = new GsonBuilder().serializeNulls().create();
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(gsonObject.toJson(cibilResponse), HttpStatus.OK));
		CibilResponse[] cibilReference = apiHelper.getCibilReference("1", "", null, "12345");
		assertEquals(1, cibilReference.length);
		assertEquals("777", cibilReference[0].getCibilTypeAndScore().get(0).getScoreV3());

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetChildApplications() {
		ApplicationDetail applicationDetail = new ApplicationDetail();
		applicationDetail.setL3ProductCode("HFFCHLF");
		applicationDetail.setL3ProductDesc("HFFCHLF Desc");
		applicationDetail.setL4ProductCode("HFFCHLFTL");
		applicationDetail.setL4ProductDesc("HFFCHLFTL Desc");
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(List.of(applicationDetail), HttpStatus.OK));
		assertEquals(1, apiHelper.getChildApplications("1", "true").size());
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetPrincipalDetails() {
		PrincipalBean principalBean = new PrincipalBean();
		principalBean.setPrincipleName("Bajaj Housing Finance Limited");
		principalBean.setPrincipleCode("1");
		principalBean.setPrinciplekey(1L);
		PrincipalBean[] principalBeanArr = new PrincipalBean[] { principalBean };
		Gson gsonObject = new GsonBuilder().serializeNulls().create();
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(gsonObject.toJson(principalBeanArr), HttpStatus.OK));
		assertEquals("Bajaj Housing Finance Limited", apiHelper.getPrincipalDetails().get(0).getPrincipleName());
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetStageDetails() {
		ApplicationStageDetails applicationStageDetails = new ApplicationStageDetails();
		applicationStageDetails.setPercentageCompletion(50);
		applicationStageDetails.setStageDesc("Additional Information");
		applicationStageDetails.setSubStageDesc("Additional Details");
		applicationStageDetails.setStageInTime("2020-07-23 08:11:41");
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(applicationStageDetails, HttpStatus.OK));
		ApplicationStageDetails stageDetails = apiHelper.getStageDetails("1");
		assertEquals("Additional Information", stageDetails.getStageDesc());
		assertEquals("Additional Details", stageDetails.getSubStageDesc());
		assertEquals("2020-07-23 08:11:41", stageDetails.getStageInTime());
		assertEquals(Integer.valueOf(50), stageDetails.getPercentageCompletion());
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetBranchDetails() {
		BranchDetails branchDetails = new BranchDetails();
		branchDetails.setBranchKey(1L);
		branchDetails.setBranchName("PUKARA BRANCH");
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(branchDetails, HttpStatus.OK));
		BranchDetails branch = apiHelper.getBranchDetails("1","5");
		assertEquals("PUKARA BRANCH", branch.getBranchName());
		assertEquals(Long.valueOf(1), branch.getBranchKey());

	}

	@Test
	public void testGetSpecialisationDetails() {
		Specilizations specilization = new Specilizations();
		
		Mockito.when(creditBusinessHelper.invokeRestEndPointWithOptionalParams(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(
						"[{ \"spclmastkey\": 1, \"spclmastcode\": \"1\", \"spcldesc\": \"Anaesthesist\"}]",
						HttpStatus.OK));
		specilization = apiHelper.getSpecialisationDetails("1");
		assertNotNull(specilization);
	}

	@Test
	public void testGetQualificationDetails() {
		Qualification qualification = new Qualification();

		String qualificationJson = "[{\"qlfymastkey\":1,\"qlfyprefcode\":\"1\",\"qlfyname\":\"MBBS\",\"qlfydesc\":\"MBBS\",\"qlfytype\":\"UG\",\"categorycd\":\"D\",\"displayorder\":1,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":2,\"qlfyprefcode\":\"6\",\"qlfyname\":\"MD\",\"qlfydesc\":\"MD\",\"qlfytype\":\"PG\",\"categorycd\":\"D\",\"displayorder\":6,\"specializationflag\":1,\"pgflag\":1},{\"qlfymastkey\":3,\"qlfyprefcode\":\"7\",\"qlfyname\":\"MS\",\"qlfydesc\":\"MS\",\"qlfytype\":\"PG\",\"categorycd\":\"D\",\"displayorder\":7,\"specializationflag\":1,\"pgflag\":1},{\"qlfymastkey\":4,\"qlfyprefcode\":\"8\",\"qlfyname\":\"DNB\",\"qlfydesc\":\"DNB\",\"qlfytype\":\"PG\",\"categorycd\":\"D\",\"displayorder\":8,\"specializationflag\":1,\"pgflag\":1},{\"qlfymastkey\":5,\"qlfyprefcode\":\"10\",\"qlfyname\":\"DM\",\"qlfydesc\":\"DM\",\"qlfytype\":\"PG\",\"categorycd\":\"D\",\"displayorder\":10,\"specializationflag\":1,\"pgflag\":1},{\"qlfymastkey\":6,\"qlfyprefcode\":\"11\",\"qlfyname\":\"M.Ch\",\"qlfydesc\":\"M.Ch\",\"qlfytype\":\"PG\",\"categorycd\":\"D\",\"displayorder\":11,\"specializationflag\":1,\"pgflag\":1},{\"qlfymastkey\":7,\"qlfyprefcode\":\"2\",\"qlfyname\":\"BDS\",\"qlfydesc\":\"BDS\",\"qlfytype\":\"UG\",\"categorycd\":\"D\",\"displayorder\":2,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":8,\"qlfyprefcode\":\"3\",\"qlfyname\":\"MDS\",\"qlfydesc\":\"MDS\",\"qlfytype\":\"PG\",\"categorycd\":\"D\",\"displayorder\":3,\"specializationflag\":1,\"pgflag\":1},{\"qlfymastkey\":9,\"qlfyprefcode\":\"4\",\"qlfyname\":\"BAMS\",\"qlfydesc\":\"BAMS\",\"qlfytype\":\"UG\",\"categorycd\":\"D\",\"displayorder\":4,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":10,\"qlfyprefcode\":\"5\",\"qlfyname\":\"BHMS\",\"qlfydesc\":\"BHMS\",\"qlfytype\":\"UG\",\"categorycd\":\"D\",\"displayorder\":5,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":11,\"qlfyprefcode\":\"20\",\"qlfyname\":\"Other\",\"qlfydesc\":\"Other\",\"qlfytype\":\"NA\",\"categorycd\":\"D\",\"displayorder\":20,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":12,\"qlfyprefcode\":\"16\",\"qlfyname\":\"Naturopathy\",\"qlfydesc\":\"Naturopathy\",\"qlfytype\":\"NA\",\"categorycd\":\"D\",\"displayorder\":16,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":13,\"qlfyprefcode\":\"15\",\"qlfyname\":\"Physiotherapy\",\"qlfydesc\":\"Physiotherapy\",\"qlfytype\":\"NA\",\"categorycd\":\"D\",\"displayorder\":15,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":14,\"qlfyprefcode\":\"17\",\"qlfyname\":\"Siddha Doctor\",\"qlfydesc\":\"Siddha Doctor\",\"qlfytype\":\"NA\",\"categorycd\":\"D\",\"displayorder\":17,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":15,\"qlfyprefcode\":\"19\",\"qlfyname\":\"Veterinary\",\"qlfydesc\":\"Veterinary\",\"qlfytype\":\"NA\",\"categorycd\":\"D\",\"displayorder\":19,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":16,\"qlfyprefcode\":\"18\",\"qlfyname\":\"Unani Doctor\",\"qlfydesc\":\"Unani Doctor\",\"qlfytype\":\"NA\",\"categorycd\":\"D\",\"displayorder\":18,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":17,\"qlfyprefcode\":\"13\",\"qlfyname\":\"GAMS\",\"qlfydesc\":\"GAMS\",\"qlfytype\":\"NA\",\"categorycd\":\"D\",\"displayorder\":13,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":18,\"qlfyprefcode\":\"14\",\"qlfyname\":\"DHMS\",\"qlfydesc\":\"DHMS\",\"qlfytype\":\"UG\",\"categorycd\":\"D\",\"displayorder\":14,\"specializationflag\":0,\"pgflag\":0},{\"qlfymastkey\":19,\"qlfyprefcode\":\"9\",\"qlfyname\":\"FCPS\",\"qlfydesc\":\"FCPS\",\"qlfytype\":\"PG\",\"categorycd\":\"D\",\"displayorder\":9,\"specializationflag\":1,\"pgflag\":1},{\"qlfymastkey\":20,\"qlfyprefcode\":\"12\",\"qlfyname\":\"PG Diploma\",\"qlfydesc\":\"PG Diploma\",\"qlfytype\":\"PG\",\"categorycd\":\"D\",\"displayorder\":12,\"specializationflag\":1,\"pgflag\":1}]";
		Mockito.when(creditBusinessHelper.invokeRestEndPointWithOptionalParams(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(
						qualificationJson,
						HttpStatus.OK));
		qualification = apiHelper.getQualificationDetails("1");
		assertNotNull(qualification);
	}
	
	@Test
	public void testGetReference_FilterKeyMatched() {
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("http://omreferencedatareferencedataservice.qa.bfsgodirect.com/v2/referencedata/specializations");
		List<JSONObject> specializationMasterReponseList =  new ArrayList<JSONObject>();
		JSONObject specialization = new JSONObject();
		
		specialization.put("spclmastkey", "4");
		specialization.put("spclmastcode", "4");
		specialization.put("spcldesc", "Endocrinologist");
		specializationMasterReponseList.add(specialization);
		
		specialization.put("spclmastkey", "1");
		specialization.put("spclmastcode", "1");
		specialization.put("spcldesc", "Anaesthesit");
		specializationMasterReponseList.add(specialization);
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(specializationMasterReponseList, HttpStatus.OK));
		MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
		queryParams.add("spclMasterKey", "3");
		Reference filterReference = new Reference();
		filterReference.setKey(1l);
		Assert.assertNotNull(apiHelper.getReference(ReferenceOf.SPECIALIZATION, queryParams, filterReference).getCode());
	}
	
	@Test
	public void testGetReference_FilterCodeMatched() {
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("");
		List<JSONObject> specializationMasterReponseList =  new ArrayList<JSONObject>();
		JSONObject specialization = new JSONObject();
		
		specialization.put("spclmastkey", "1");
		specialization.put("spclmastcode", "1");
		specialization.put("spcldesc", "Anaesthesit");
		specializationMasterReponseList.add(specialization);
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(specializationMasterReponseList, HttpStatus.OK));
		MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
		queryParams.add("spclMasterKey", "3");
		Reference filterReference = new Reference();
		filterReference.setCode("1");
		Assert.assertNotNull(apiHelper.getReference(ReferenceOf.SPECIALIZATION, queryParams, filterReference).getCode());
	}
	
	@Test
	public void testGetReference_FilterValueMatched() {
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("http://omreferencedatareferencedataservice.qa.bfsgodirect.com/v2/referencedata/specializations");
		List<JSONObject> specializationMasterReponseList =  new ArrayList<JSONObject>();
		JSONObject specialization = new JSONObject();
		
		specialization.put("spclmastkey", "1");
		specialization.put("spclmastcode", "1");
		specialization.put("spcldesc", "Anaesthesit");
		specializationMasterReponseList.add(specialization);
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(specializationMasterReponseList, HttpStatus.OK));
		Reference filterReference = new Reference();
		filterReference.setValue("Anaesthesit");
		Assert.assertNotNull(apiHelper.getReference(ReferenceOf.SPECIALIZATION, null, filterReference).getCode());
	}
	
	@Test
	public void testGetReference_FilterValueNotMatched() {
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn(null);
		List<JSONObject> specializationMasterReponseList =  new ArrayList<JSONObject>();
		JSONObject specialization = new JSONObject();
		
		specialization.put("spclmastkey", "1");
		specialization.put("spclmastcode", "1");
		specialization.put("spcldesc", "Anaesthesit");
		specializationMasterReponseList.add(specialization);
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(specializationMasterReponseList, HttpStatus.OK));
		Reference filterReference = new Reference();
		filterReference.setValue("Anaesthest");
		Assert.assertNull(apiHelper.getReference(ReferenceOf.SPECIALIZATION, null, filterReference));
	}
	
	@Test
	public void testGetReference_NoQueryParamOrFilterReference() {
		Assert.assertNull(apiHelper.getReference(ReferenceOf.SPECIALIZATION, null, null));
	}
	
	@Test
	public void testGetReferenceV2_FilterKeyMatched() {
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("http://omreferencedatareferencedataservice.dev.bfsgodirect.com/v1/referencedata/principals/{principalkey}/documents");
		List<JSONObject> specializationMasterReponseList =  new ArrayList<JSONObject>();
		JSONObject specialization = new JSONObject();
		
		specialization.put("principleDocTypeKey", "1");
		specialization.put("docIdCatCode", "ADDRESS_PROOF");
		specialization.put("documentTypeDescription", "Aadhaar Card");
		specializationMasterReponseList.add(specialization);
		
		specialization = new JSONObject();
		specialization.put("principleDocTypeKey", "2");
		specialization.put("docIdCatCode", "ID_PROOF");
		specialization.put("documentTypeDescription", "PASSPORT");
		specializationMasterReponseList.add(specialization);
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(specializationMasterReponseList, HttpStatus.OK));
		Map<String, String> pathParameters = new HashMap<>();
		pathParameters.put("principalkey", "21");
		Reference filterReference = new Reference();
		filterReference.setKey(1l);
		Assert.assertNotNull(apiHelper.getReferenceV2(ReferenceOf.PRINCIPLE_DOCUMENTS, pathParameters, null, filterReference).getCode());
	}
	
	@Test (expected = CreditBusinessException.class)
	public void testGetReferenceV2_UrlNotDefined() {
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("");
		apiHelper.getReferenceV2(ReferenceOf.PRINCIPLE_DOCUMENTS, null, null, new Reference());
	}
	
	@Test
	public void testGetReferenceV2_PathParametersNull() {
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("http://omreferencedatareferencedataservice.dev.bfsgodirect.com/v1/referencedata/principals/documents");
		List<JSONObject> principalDocumentResponseList =  new ArrayList<JSONObject>();
		JSONObject principalDocument = new JSONObject();
		
		principalDocument.put("principleDocTypeKey", "1");
		principalDocument.put("docIdCatCode", "ADDRESS_PROOF");
		principalDocument.put("documentTypeDescription", "Aadhaar Card");
		principalDocumentResponseList.add(principalDocument);
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(principalDocumentResponseList, HttpStatus.OK));
		Reference filterReference = new Reference();
		filterReference.setValue("Aadhaar Card");
		Assert.assertNotNull(apiHelper.getReferenceV2(ReferenceOf.PRINCIPLE_DOCUMENTS,null, null, filterReference).getCode());
	}
	
	@Test
	public void testGetReferenceV2_PathParametersNull_CodeMatched() {
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("http://omreferencedatareferencedataservice.dev.bfsgodirect.com/v1/referencedata/principals/documents");
		List<JSONObject> principalDocumentResponseList =  new ArrayList<JSONObject>();
		JSONObject principalDocument = new JSONObject();
		
		principalDocument.put("principleDocTypeKey", "1");
		principalDocument.put("docIdCatCode", "ADDRESS_PROOF");
		principalDocument.put("documentTypeDescription", "Aadhaar Card");
		principalDocumentResponseList.add(principalDocument);
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(principalDocumentResponseList, HttpStatus.OK));
		Reference filterReference = new Reference();
		filterReference.setCode("ADDRESS_PROOF");
		Assert.assertNotNull(apiHelper.getReferenceV2(ReferenceOf.PRINCIPLE_DOCUMENTS,null, null, filterReference).getCode());
	}
	
	@Test
	public void testGetReferenceV2_PathParametersNull_NoMatchFound() {
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("http://omreferencedatareferencedataservice.dev.bfsgodirect.com/v1/referencedata/principals/documents");
		List<JSONObject> principalDocumentResponseList =  new ArrayList<JSONObject>();
		JSONObject principalDocument = new JSONObject();
		
		principalDocument.put("principleDocTypeKey", "1");
		principalDocument.put("documentTypeCode", "ADHAR");
		principalDocument.put("documentTypeDescription", "Aadhaar Card");
		principalDocumentResponseList.add(principalDocument);
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(principalDocumentResponseList, HttpStatus.OK));
		Reference filterReference = new Reference();
		filterReference.setValue("AADHAR");
		Assert.assertNull(apiHelper.getReferenceV2(ReferenceOf.PRINCIPLE_DOCUMENTS,null, null, filterReference));
	}
	
	@Test
	public void testGetReferenceV2_InvalidRequestData() {
		Assert.assertNull(apiHelper.getReferenceV2(ReferenceOf.PRINCIPLE_DOCUMENTS,null, null, null));
	}
	
	@Test
	public void testGetappLoanPricing_Ep() {
		Gson g = new Gson();
		List<?> pricng = g.fromJson(
				"[{\"appLoanPricingKey\":\"string\",\"applicationKey\":\"string\",\"approval\":{\"approvalStatus\":\"string\",\"approvedBy\":0,\"raisedBy\":0},\"baseRateCode\":\"string\",\"baseRateValue\":0,\"bundlePrice\":[{\"bundleCostReference\":0,\"bundleFinalPrice\":0,\"bundleFloorPrice\":0,\"bundleMaxPrice\":0}],\"bundleSelected\":0,\"droplineEmi\":0,\"droplineTenure\":0,\"dueDay\":0,\"emiAmount\":0,\"fees\":[{\"appLoanPricingKey\":0,\"feeCode\":\"string\",\"feesInAmount\":0,\"feesInPercent\":0,\"feesKey\":0,\"isactive\":0}],\"finalLoanAmount\":0,\"finalRoi\":0,\"firstDueDate\":\"string\",\"graceTerm\":0,\"isBpiApplicable\":\"string\",\"isEmi\":\"string\",\"isTenure\":0,\"l3ProductCode\":\"string\",\"l3ProductDesc\":\"string\",\"l4ProductCode\":\"string\",\"loanAmmountWithBundle\":0,\"loanAmmountWithoutBundle\":0,\"loanAmount\":0,\"loanType\":\"string\",\"netDisbursementAmount\":0,\"nextDueDate\":\"string\",\"pennantLoanType\":\"string\",\"pricingStatus\":\"APPROVED\",\"prodCategoryCode\":\"string\",\"raisedBy\":0,\"roi\":0,\"roiWithBundle\":0,\"roiWithoutBundle\":0,\"source\":\"EP\"}]",
			List.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(pricng, HttpStatus.OK));
		Assert.assertNotNull(apiHelper.getAppLoanPricing("1234"));
	}
	
	@Test
	public void testGetappLoanPricing_Jrny() {
		Gson g = new Gson();
		List<?> pricng = g.fromJson(
				"[{\"appLoanPricingKey\":\"string\",\"applicationKey\":\"string\",\"approval\":{\"approvalStatus\":\"string\",\"approvedBy\":0,\"raisedBy\":0},\"baseRateCode\":\"string\",\"baseRateValue\":0,\"bundlePrice\":[{\"bundleCostReference\":0,\"bundleFinalPrice\":0,\"bundleFloorPrice\":0,\"bundleMaxPrice\":0}],\"bundleSelected\":0,\"droplineEmi\":0,\"droplineTenure\":0,\"dueDay\":0,\"emiAmount\":0,\"fees\":[{\"appLoanPricingKey\":0,\"feeCode\":\"string\",\"feesInAmount\":0,\"feesInPercent\":0,\"feesKey\":0,\"isactive\":0}],\"finalLoanAmount\":0,\"finalRoi\":0,\"firstDueDate\":\"string\",\"graceTerm\":0,\"isBpiApplicable\":\"string\",\"isEmi\":\"string\",\"isTenure\":0,\"l3ProductCode\":\"string\",\"l3ProductDesc\":\"string\",\"l4ProductCode\":\"string\",\"loanAmmountWithBundle\":0,\"loanAmmountWithoutBundle\":0,\"loanAmount\":0,\"loanType\":\"string\",\"netDisbursementAmount\":0,\"nextDueDate\":\"string\",\"pennantLoanType\":\"string\",\"pricingStatus\":\"APPROVED\",\"prodCategoryCode\":\"string\",\"raisedBy\":0,\"roi\":0,\"roiWithBundle\":0,\"roiWithoutBundle\":0,\"source\":\"JOURNEY\"}]",
				List.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(pricng, HttpStatus.OK));
		Assert.assertNotNull(apiHelper.getAppLoanPricing("1234"));
	}
	
	@Test(expected=CreditBusinessException.class)
	public void testGetappLoanPricing_Exce() {
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenThrow(RuntimeException.class);
		apiHelper.getAppLoanPricing("1234");
	}
	
	@Test
	public void testGetApplicationParameterDetails() {
		Gson g = new Gson();
		String applicationParamater="{\"applicationParameters\": {\"statusApiCount\": null,\"fppselectedbyuser\":false, \"requestedTenureMonths\": \"24\", \"requestedCreditAmount\":\"2500000\",\"applicationCreatedBy\": \"85361\", \"cardLimit\": null}}";
		JSONObject applicationParameters = g.fromJson(applicationParamater, JSONObject.class);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(applicationParameters, HttpStatus.OK));
		assertNotNull(apiHelper.getApplicationParameterDetails("123"));
	}

	@Test
	public void testDocumentDetails_NoResponse() {
		assertNull(apiHelper.getDocumentDetail(new HashMap<String, String>(), 2l));
	}
	
	@Test
	public void testDocumentDetails_WithResponse() {
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any())).thenReturn(new ResponseEntity(new DocumentDetails(), HttpStatus.OK));
		assertNotNull(apiHelper.getDocumentDetail(new HashMap<String, String>(), null));
	}
}