package com.bajaj.markets.credit.business.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.EmicResponse;
import com.bajaj.markets.credit.business.service.CreditBusinessEmicService;

@SpringBootTest
public class CreditBusinessEmicControllerTest {
	
	@InjectMocks
	private CreditBusinessEmicController creditBusinessEmicController;
	
	@Mock
	private CreditBusinessEmicService creditBusinessEmicService;

	@Mock
	private BFLLoggerUtilExt logger;
	
	private MockMvc mockMvc;
	@Mock
	private HttpHeaders headers;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessEmicController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();
	}

	@Test
	public void testGenerateEncryptedEmicRequest() throws Exception {
		Mockito.when(creditBusinessEmicService.encryptEmicRequest(Mockito.any(), Mockito.any()))
				.thenReturn(new EmicResponse());
		mockMvc.perform(
				get("/v1/credit/applications/{applicationid}/lead-info?responseFormat=encrypted&principalCode=BFL",
						"123456")
				.contentType(MediaType.APPLICATION_JSON)
						.headers(new HttpHeaders()))
				.andExpect(status().isOk());
	}

	@Test
	public void testGenerateEncryptedEmicRequestBadRequest() throws Exception {
		Mockito.when(creditBusinessEmicService.encryptEmicRequest(Mockito.any(), Mockito.any()))
				.thenReturn(new EmicResponse());
		mockMvc.perform(
				get("/v1/credit/applications/{applicationid}/lead-info", "").contentType(MediaType.APPLICATION_JSON)
						.headers(new HttpHeaders()))
				.andExpect(status().isNotFound());
	}

}
