package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.BranchDetails;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.ProductCodeEnum;
import com.google.gson.Gson;

@SpringBootTest
public class BreListenerTest {

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	BreListener listener;

	@InjectMocks
	McpCheck mcpCheck;

	@InjectMocks
	CreditBusinessHelper creditBusinessHelper;
	
	@Mock
	MasterDataRedisClientHelper masterDataRedisHelper;
	
	@Mock
	CreditBusinessApiCallsHelper apiCallsHelper;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(listener, "mcpCheck", mcpCheck);
		ReflectionTestUtils.setField(listener, "creditBusinessHelper", creditBusinessHelper);
	}

	@Test
	public void testPreListing() {
		Gson g = new Gson();
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{\"name\":\"Prathamesh Joshi\",\"occupation\":\"SALR\",\"pan\":\"ABCC1234J\",\"personalEmailId\":\"prathamesh@personal.com\",\"workEmailId\":\"prathamesh@work.com\",\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"}}"));
		Object json = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69,\"workExperienceInMonths\":null,\"principalIndustry\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null},\"presentBusinessVintage\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000008597\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9907090001\",\"dateOfBirth\":\"1990-02-02\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\",\"applicantKey\":123101},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"6582\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000}],\"appScoreDetails\":{\"finalScore\":834,\"lrScore\":834,\"miScore\":830},\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);
		Object resitypeList = g.fromJson(
				"[{\"residenceKey\":3,\"residenceCode\":\"ORGPROV\",\"residenceValue\":\"Company/Govt provided\",\"isactive\":1},{\"residenceKey\":1,\"residenceCode\":\"OWN\",\"residenceValue\":\"Own\",\"isactive\":1},{\"residenceKey\":5,\"residenceCode\":\"PAYGUEST\",\"residenceValue\":\"Paying Guest\",\"isactive\":1},{\"residenceKey\":2,\"residenceCode\":\"RENTAL\",\"residenceValue\":\"Rental staying alone\",\"isactive\":1},{\"residenceKey\":6,\"residenceCode\":\"RENTALFAMILY\",\"residenceValue\":\"Rental with family\",\"isactive\":1},{\"residenceKey\":7,\"residenceCode\":\"RENTALOTH\",\"residenceValue\":\"Rental with friends/relatives\",\"isactive\":1},{\"residenceKey\":8,\"residenceCode\":\"OTHERS\",\"residenceValue\":\"Others\",\"isactive\":1}]",
				ArrayList.class);

		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(json);
		when(execution.getVariable("appscore")).thenReturn("123");
		when(execution.getVariable("lrScore")).thenReturn("123");
		when(execution.getVariable("mlScore")).thenReturn("123");
		when(execution.getVariable("derogJson")).thenReturn("123");
		when(execution.getVariable("cvValidationstatus")).thenReturn("High Risk");
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1234");
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		listener.preListing(execution);
	}
	
	@Test
	public void testPreListing_bol() {
		Gson g = new Gson();
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{\"name\":\"Prathamesh Joshi\",\"occupation\":\"SALR\",\"pan\":\"ABCC1234J\",\"personalEmailId\":\"prathamesh@personal.com\",\"workEmailId\":\"prathamesh@work.com\",\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"}}"));
		
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":2,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":null,\"experience\":null,\"netSalary\":null,\"employerType\":null},\"businessOwnerDetails\":{\"businessName\":\"testBusiness\",\"businessType\":null,\"natureOfBusiness\":{\"key\":1,\"code\":null,\"value\":null},\"industryType\":{\"key\":4,\"code\":null,\"value\":null},\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":\"3-5 Cr.\"},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":\"5\"},\"proprieterName\":null,\"businessPan\":\"ASWCP1234J\",\"gstNumber\":\"\",\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":1000000,\"averageBankBalance\":1000000,\"companyType\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"null\"},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250001\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"asdad\",\"middleName\":\"\",\"lastName\":\"sdasdadas\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[\"LENBOLROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5320\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":null}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);
		
		Object resitypeList = g.fromJson(
				"[{\"residenceKey\":3,\"residenceCode\":\"ORGPROV\",\"residenceValue\":\"Company/Govt provided\",\"isactive\":1},{\"residenceKey\":1,\"residenceCode\":\"OWN\",\"residenceValue\":\"Own\",\"isactive\":1},{\"residenceKey\":5,\"residenceCode\":\"PAYGUEST\",\"residenceValue\":\"Paying Guest\",\"isactive\":1},{\"residenceKey\":2,\"residenceCode\":\"RENTAL\",\"residenceValue\":\"Rental staying alone\",\"isactive\":1},{\"residenceKey\":6,\"residenceCode\":\"RENTALFAMILY\",\"residenceValue\":\"Rental with family\",\"isactive\":1},{\"residenceKey\":7,\"residenceCode\":\"RENTALOTH\",\"residenceValue\":\"Rental with friends/relatives\",\"isactive\":1},{\"residenceKey\":8,\"residenceCode\":\"OTHERS\",\"residenceValue\":\"Others\",\"isactive\":1}]",
				ArrayList.class);
		
		Object annuTurn = g.fromJson(
				"[{\"key\":1,\"code\":\"0\",\"value\":\"Less Than 50 Lakhs\"},{\"key\":2,\"code\":\"50\",\"value\":\"50 Lakhs-1 Cr.\"},{\"key\":3,\"code\":\"1\",\"value\":\"1-2 Cr.\"},{\"key\":4,\"code\":\"2\",\"value\":\"2-3 Cr.\"},{\"key\":5,\"code\":\"3\",\"value\":\"3-5 Cr.\"},{\"key\":6,\"code\":\"5\",\"value\":\"5-10 Cr.\"},{\"key\":7,\"code\":\"10\",\"value\":\"10-15 Cr.\"},{\"key\":8,\"code\":\"15\",\"value\":\"More than 15 Cr.\"}]",
				Object.class);

		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(mcpReq);
		when(execution.getVariable(CreditBusinessConstants.ANNUALTURNOVER_LOOKUP_LIST)).thenReturn(annuTurn);
		when(execution.getVariable("appscore")).thenReturn("123");
		when(execution.getVariable("lrScore")).thenReturn("123");
		when(execution.getVariable("mlScore")).thenReturn("123");
		when(execution.getVariable("derogJson")).thenReturn("123");
		when(execution.getVariable("cvValidationstatus")).thenReturn("High Risk");
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1234");
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		listener.preListing(execution);
	}

	@Test
	public void testPreListing_AnalyticsNullResponse() {
		Gson g = new Gson();
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{\"name\":\"Prathamesh Joshi\",\"occupation\":\"SALR\",\"pan\":\"ABCC1234J\",\"personalEmailId\":\"prathamesh@personal.com\",\"workEmailId\":\"prathamesh@work.com\",\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"}}"));
		Object json = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":null,\"salariedDetail\":{\"employerName\":null,\"designation\":null,\"experience\":\"1\",\"netSalary\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":null,\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":\"null\"},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null}},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":null,\"dateOfBirth\":\"1991-02-01\",\"name\":null,\"maritalStatusKey\":null,\"genderKey\":null,\"residenceTypeKey\":1,\"qualification\":null,\"panNumber\":\"ABCC1234J\"},\"prodCategory\":{\"prodCatCode\":\"CC\",\"prodCatDesc\":\"Credit Card\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"CCABMyZOne\",\"rejectCodeList\":[\"CCROGL\",\"CCROGL\",\"CCROGL\",\"CCROGL\",\"CCROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null}},{\"principleProductCode\":\"CCABNeon\",\"rejectCodeList\":[\"CCROGL\",\"CCROGL\",\"CCROGL\",\"CCROGL\",\"CCROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null}},{\"principleProductCode\":\"CCABIOCL\",\"rejectCodeList\":[\"CCROGL\",\"CCROGL\",\"CCROGL\",\"CCROGL\",\"CCROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null}},{\"principleProductCode\":\"CCRBLTRVLESY\",\"rejectCodeList\":[\"CCROGL\",\"CCROGL\",\"CCROGL\",\"CCROGL\",\"CCROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null}},{\"principleProductCode\":\"CCRBLPLTCHOICE\",\"rejectCodeList\":[\"CCROGL\",\"CCROGL\",\"CCROGL\",\"CCROGL\",\"CCROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null}}]}],\"panDetails\":{\"nameMatch\":null},\"addressList\":[{\"addressKey\":\"125\",\"addressTypeKey\":\"1\",\"resiType\":null,\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"411015\",\"cityKey\":\"1\",\"stateKey\":\"1\",\"countryKey\":\"1\",\"verification\":null,\"addressSource\":null}],\"additionalCibilFlag\":0} ",
				JSONObject.class);
		Object resitypeList = g.fromJson(
				"[{\"residenceKey\":3,\"residenceCode\":\"ORGPROV\",\"residenceValue\":\"Company/Govt provided\",\"isactive\":1},{\"residenceKey\":1,\"residenceCode\":\"OWN\",\"residenceValue\":\"Own\",\"isactive\":1},{\"residenceKey\":5,\"residenceCode\":\"PAYGUEST\",\"residenceValue\":\"Paying Guest\",\"isactive\":1},{\"residenceKey\":2,\"residenceCode\":\"RENTAL\",\"residenceValue\":\"Rental staying alone\",\"isactive\":1},{\"residenceKey\":6,\"residenceCode\":\"RENTALFAMILY\",\"residenceValue\":\"Rental with family\",\"isactive\":1},{\"residenceKey\":7,\"residenceCode\":\"RENTALOTH\",\"residenceValue\":\"Rental with friends/relatives\",\"isactive\":1},{\"residenceKey\":8,\"residenceCode\":\"OTHERS\",\"residenceValue\":\"Others\",\"isactive\":1}]",
				ArrayList.class);

		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(json);
		when(execution.getVariable("appscore")).thenReturn(null);
		when(execution.getVariable("lrScore")).thenReturn(null);
		when(execution.getVariable("mlScore")).thenReturn(null);
		when(execution.getVariable("derogJson")).thenReturn(null);
		when(execution.getVariable("cvValidationstatus")).thenReturn(null);
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1234");
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		listener.preListing(execution);
	}

	@Test
	public void testPostListing_Cards() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{\"openArcCardListingOutput\":{\"openArcCardListing\":{\"principleProductDetails\":[{\"cardPriority\":null,\"principleProductCode\":\"CCABMyZOne\",\"rejectCodeList\":[\"CCRSAL\",\"CCROGL\"],\"isEligible\":false,\"bScore\":null},{\"cardPriority\":null,\"principleProductCode\":\"CCABNeon\",\"rejectCodeList\":[\"CCRSAL\",\"CCROGL\"],\"isEligible\":false,\"bScore\":null},{\"cardPriority\":null,\"principleProductCode\":\"CCABIOCL\",\"rejectCodeList\":[\"CCRSAL\",\"CCROGL\"],\"isEligible\":false,\"bScore\":null},{\"cardPriority\":1,\"principleProductCode\":\"CCRBLPLTCHOICE\",\"rejectCodeList\":[],\"isEligible\":true,\"bScore\":4.5},{\"cardPriority\":2,\"principleProductCode\":\"CCRBLTRVLESY\",\"rejectCodeList\":[],\"isEligible\":true,\"bScore\":4.4}],\"cibilRequired\":null},\"openMarketsLoanListing\":null},\"action\":true}"));
		listener.postListing(execution);
	}

	@Test
	public void testPostListing_Cards_rejected() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{\"openArcCardListingOutput\":{\"openArcCardListing\":{\"principleProductDetails\":[{\"cardPriority\":null,\"principleProductCode\":\"CCABMyZOne\",\"rejectCodeList\":[\"CCRSAL\",\"CCROGL\"],\"isEligible\":false,\"bScore\":null},{\"cardPriority\":null,\"principleProductCode\":\"CCABNeon\",\"rejectCodeList\":[\"CCRSAL\",\"CCROGL\"],\"isEligible\":false,\"bScore\":null},{\"cardPriority\":null,\"principleProductCode\":\"CCABIOCL\",\"rejectCodeList\":[\"CCRSAL\",\"CCROGL\"],\"isEligible\":false,\"bScore\":null},{\"cardPriority\":1,\"principleProductCode\":\"CCRBLPLTCHOICE\",\"rejectCodeList\":[],\"isEligible\":false,\"bScore\":4.5},{\"cardPriority\":2,\"principleProductCode\":\"CCRBLTRVLESY\",\"rejectCodeList\":[],\"isEligible\":false,\"bScore\":4.4}],\"cibilRequired\":null},\"openMarketsLoanListing\":null},\"action\":true}"));
		listener.postListing(execution);
	}

	@Test
	public void testPostListing_Loans() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{\"openArcCardListingOutput\":{\"openArcCardListing\":null,\"openMarketsLoanListing\":{\"eligibilityType\":\"AIP\",\"maxEligibility\":2000000,\"maxTenor\":5,\"requiredLoanAmount\":100000,\"requiredTenor\":4,\"principalProductDetails\":[{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":true,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLTL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1200,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":2778,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/08/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[],\"roi\":14.6,\"preApproved\":\"Yes\",\"bScore\":4,\"approvalChances\":\"Medium\",\"priorityOrder\":1,\"fppApplicable\":true,\"perfiosRequired\":true,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"SOLTL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[]},{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":true,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLHFL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1400,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":1325,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/08/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[{\"graceTerm\":2,\"nextDueDate\":\"02/08/2021\"}],\"roi\":12.6,\"preApproved\":\"Yes\",\"bScore\":4.5,\"approvalChances\":\"Medium\",\"priorityOrder\":2,\"fppApplicable\":true,\"perfiosRequired\":true,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"DHPL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[]}]}},\"action\":true}"));
		listener.postListing(execution);
	}

	@Test
	public void testPostListing_Loans_rejected() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{\"openArcCardListingOutput\":{\"openArcCardListing\":null,\"openMarketsLoanListing\":{\"eligibilityType\":\"AIP\",\"maxEligibility\":2000000,\"maxTenor\":5,\"requiredLoanAmount\":100000,\"requiredTenor\":4,\"principalProductDetails\":[{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":false,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLTL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1200,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":2778,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/08/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[],\"roi\":14.6,\"preApproved\":\"Yes\",\"bScore\":4,\"approvalChances\":\"Medium\",\"priorityOrder\":1,\"fppApplicable\":true,\"perfiosRequired\":true,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"SOLTL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[]},{\"principalSelectedByCustomer\":\"\",\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":false,\"principleProductCode\":\"BFLSOL\",\"offerType\":null,\"eligibilityType\":\"AIP\",\"riskOfferType\":null,\"loanTypeRecommendation\":\"BFLSOLHFL\",\"loanTypeName\":null,\"promotionalOffer\":null,\"feesList\":[{\"feesInPercent\":0.2,\"feesInAmount\":1400,\"feeCode\":\"CONV\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"STAMPFEE\"},{\"feesInPercent\":0.2,\"feesInAmount\":200,\"feeCode\":\"PROCFEE\"}],\"isTenor\":12,\"dropLineTenor\":48,\"emiAmount\":1325,\"baseRate\":{\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20},\"dueDateDetails\":[{\"firstDueDate\":\"02/08/2020\",\"dueDate\":2}],\"nextDueDateDetails\":[{\"graceTerm\":2,\"nextDueDate\":\"02/08/2021\"}],\"roi\":12.6,\"preApproved\":\"Yes\",\"bScore\":4.5,\"approvalChances\":\"Medium\",\"priorityOrder\":2,\"fppApplicable\":true,\"perfiosRequired\":true,\"productSize\":\"HTS\",\"pennantloanTypeRecommendation\":\"DHPL\",\"eligibilityAmount\":110000,\"finalUnsecuredFoir\":70,\"applicableMultiplier\":12,\"multiplierEligibility\":1400000,\"finalFoir\":70,\"finalMultiplier\":14,\"maxEmiAsPerFoir\":64679,\"foirEligibilityEmi\":12000,\"rejectCodeList\":[]}]}},\"action\":true}"));
		listener.postListing(execution);
	}

	@Test
	public void testPreListingUpdate() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{\"openArcCardListingOutput\":{\"openArcCardListing\":{\"principleProductDetails\":[{\"cardPriority\":null,\"principleProductCode\":\"\",\"rejectCodeList\":[\"CCRCIBS\"],\"isEligible\":false}],\"cibilRequired\":null},\"openMarketsLoanListing\":{\"eligibilityType\":null,\"maxEligibility\":null,\"maxTenor\":null,\"minEligibility\":null,\"minTenor\":null,\"principalProductDetails\":{\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":null,\"principleProductCode\":null,\"offerType\":null,\"eligibilityType\":null,\"riskOfferType\":null,\"offerAmount\":null,\"loanTypeRecommendation\":null,\"feesList\":[],\"isTenor\":null,\"dropLineTenor\":null,\"emiAmount\":null,\"baseRate\":{\"baseRateCode\":null,\"baseRateValue\":null},\"dueDateDetails\":[],\"nextDueDateDetails\":[],\"roi\":null,\"preApproved\":null,\"bScore\":null,\"approvalChances\":null,\"priorityOrder\":null,\"fppApplicable\":null,\"perfiosRequired\":null},\"rejectCodeList\":[],\"productVariant\":null,\"finalUnsecuredFOIR\":null,\"applicableMultiplier\":null,\"multiplierEligibility\":null,\"finalFOIR\":null,\"finalMultiplier\":null,\"maxEMIasperFOIR\":null,\"foirEligibilityEMI\":null,\"leadQualifiesBflFlag\":null,\"imputedSalary\":null}},\"action\":true}"));
		listener.preListingUpdate(execution);
	}

	@Test
	public void testPreListingUpdate_cards() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{\"openArcCardListingOutput\":{\"openArcCardListing\":{\"principleProductDetails\":[{\"cardPriority\":null,\"principleProductCode\":\"\",\"rejectCodeList\":[\"CCRCIBS\"],\"isEligible\":false}],\"cibilRequired\":null},\"openMarketsLoanListing\":{\"eligibilityType\":null,\"maxEligibility\":null,\"maxTenor\":null,\"minEligibility\":null,\"minTenor\":null,\"principalProductDetails\":{\"requiredLoanAmount\":null,\"tenor\":null,\"isEligible\":null,\"principleProductCode\":null,\"offerType\":null,\"eligibilityType\":null,\"riskOfferType\":null,\"offerAmount\":null,\"loanTypeRecommendation\":null,\"feesList\":[],\"isTenor\":null,\"dropLineTenor\":null,\"emiAmount\":null,\"baseRate\":{\"baseRateCode\":null,\"baseRateValue\":null},\"dueDateDetails\":[],\"nextDueDateDetails\":[],\"roi\":null,\"preApproved\":null,\"bScore\":null,\"approvalChances\":null,\"priorityOrder\":null,\"fppApplicable\":null,\"perfiosRequired\":null},\"rejectCodeList\":[],\"productVariant\":null,\"finalUnsecuredFOIR\":null,\"applicableMultiplier\":null,\"multiplierEligibility\":null,\"finalFOIR\":null,\"finalMultiplier\":null,\"maxEMIasperFOIR\":null,\"foirEligibilityEMI\":null,\"leadQualifiesBflFlag\":null,\"imputedSalary\":null}},\"action\":true}"));
		when(execution.getVariable(CreditBusinessConstants.PRODUCTCODE)).thenReturn(ProductCodeEnum.CREDIT_CARD.getValue());
		listener.preListingUpdate(execution);
	}

	@Test
	public void testPreListingUpdate_nullOutput() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(null);
		listener.preListingUpdate(execution);
	}
	
	@Test
	public void testPreFeesBre() {
		listener.preFeesBre(execution);
	}
	
	@Test
	public void testPreListing_secured_WithObligationJson() {
		Gson g = new Gson();
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{\"name\":\"Prathamesh Joshi\",\"occupation\":\"SALR\",\"pan\":\"ABCC1234J\",\"personalEmailId\":\"prathamesh@personal.com\",\"workEmailId\":\"prathamesh@work.com\",\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"}}"));
		
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":2,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":null,\"experience\":null,\"netSalary\":null,\"employerType\":null},\"businessOwnerDetails\":{\"businessName\":\"testBusiness\",\"businessType\":null,\"natureOfBusiness\":{\"key\":1,\"code\":null,\"value\":null},\"industryType\":{\"key\":4,\"code\":null,\"value\":null},\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":\"3-5 Cr.\"},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":\"5\"},\"proprieterName\":null,\"businessPan\":\"ASWCP1234J\",\"gstNumber\":\"\",\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":1000000,\"averageBankBalance\":1000000,\"companyType\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"null\"},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250001\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"asdad\",\"middleName\":\"\",\"lastName\":\"sdasdadas\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[\"LENBOLROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5320\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":null}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);
		
		Object resitypeList = g.fromJson(
				"[{\"residenceKey\":3,\"residenceCode\":\"ORGPROV\",\"residenceValue\":\"Company/Govt provided\",\"isactive\":1},{\"residenceKey\":1,\"residenceCode\":\"OWN\",\"residenceValue\":\"Own\",\"isactive\":1},{\"residenceKey\":5,\"residenceCode\":\"PAYGUEST\",\"residenceValue\":\"Paying Guest\",\"isactive\":1},{\"residenceKey\":2,\"residenceCode\":\"RENTAL\",\"residenceValue\":\"Rental staying alone\",\"isactive\":1},{\"residenceKey\":6,\"residenceCode\":\"RENTALFAMILY\",\"residenceValue\":\"Rental with family\",\"isactive\":1},{\"residenceKey\":7,\"residenceCode\":\"RENTALOTH\",\"residenceValue\":\"Rental with friends/relatives\",\"isactive\":1},{\"residenceKey\":8,\"residenceCode\":\"OTHERS\",\"residenceValue\":\"Others\",\"isactive\":1}]",
				ArrayList.class);
		
		Object annuTurn = g.fromJson(
				"[{\"key\":1,\"code\":\"0\",\"value\":\"Less Than 50 Lakhs\"},{\"key\":2,\"code\":\"50\",\"value\":\"50 Lakhs-1 Cr.\"},{\"key\":3,\"code\":\"1\",\"value\":\"1-2 Cr.\"},{\"key\":4,\"code\":\"2\",\"value\":\"2-3 Cr.\"},{\"key\":5,\"code\":\"3\",\"value\":\"3-5 Cr.\"},{\"key\":6,\"code\":\"5\",\"value\":\"5-10 Cr.\"},{\"key\":7,\"code\":\"10\",\"value\":\"10-15 Cr.\"},{\"key\":8,\"code\":\"15\",\"value\":\"More than 15 Cr.\"}]",
				Object.class);
		Object obligationjson = g.fromJson(
			    "{\"emiList\":[{\"accountType\":\"06\",\"currentBalance\":\"0\",\"emiAmount\":\"\",\"mob\":\"24.0\"},{\"accountType\":\"07\",\"currentBalance\":\"0\",\"emiAmount\":\"\",\"mob\":\"20.0\",\"highCreditSanctionAmt\":\"96027\",\"reportingShortName\":\"NOT DISCLOSED\"},{\"accountType\":\"10\",\"currentBalance\":\"22607\",\"emiAmount\":\"\",\"mob\":\"141.0\"}],\"emiSum\":\"11830.0\"}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(mcpReq);
		when(execution.getVariable(CreditBusinessConstants.ANNUALTURNOVER_LOOKUP_LIST)).thenReturn(annuTurn);
		when(execution.getVariable(CreditBusinessConstants.OBLIGATION_AMT)).thenReturn(obligationjson);
		when(execution.getVariable("appscore")).thenReturn("123");
		when(execution.getVariable("lrScore")).thenReturn("123");
		when(execution.getVariable("mlScore")).thenReturn("123");
		when(execution.getVariable("derogJson")).thenReturn("123");
		when(execution.getVariable("cvValidationstatus")).thenReturn("High Risk");
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1234");
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		listener.preListing(execution);
	}

	@Test
	public void testpreSegmentationBRE() {
		Gson g = new Gson();
		Object json = g.fromJson(
				"{\"occupation\":{\"ocupationType\":{\"key\":1.0,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"softwareengineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69.0,\"workExperienceInMonths\":null,\"principalIndustry\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1.0,\"code\":null,\"value\":null},\"presentBusinessVintage\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"subStagePercentage\":30.0,\"additionalParameterDetail\":null,\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"additionalCibilFlag\":0.0,\"princialSelectedbyCustomerDetail\":[],\"mcpAddressDetails\":[{\"pinCodeKey\":266388,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"userProfile\":{\"applicationKey\":\"1100000000008597\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9907090001\",\"dateOfBirth\":\"1990-02-02\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27.0,\"genderKey\":22.0,\"residenceTypeKey\":1.0,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\",\"applicantKey\":123101.0},\"appScoreDetails\":{\"finalScore\":834.0,\"lrScore\":834.0,\"miScore\":830.0},\"existingCustomerFlag\":null,\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OMPersonalloan\"},\"addressList\":[{\"addressKey\":\"6582\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"pincodeKey\":\"116159\",\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000.0}]}",
				JSONObject.class);
		LocationResponseBean pinCodeMaster = new LocationResponseBean();
		pinCodeMaster.setCityName("abvcd");
		pinCodeMaster.setCityKey(2534L);
		BranchDetails branchDetails = new BranchDetails();
		branchDetails.setBranchName("ABCD");
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(json);
		when(execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY)).thenReturn("12345");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(pinCodeMaster);
		Mockito.when(apiCallsHelper.getBranchDetails(Mockito.any(), Mockito.any())).thenReturn(branchDetails);
		listener.preSegmentationBRE(execution);
	}
	

	@Test(expected=CreditBusinessException.class)
	public void testpreSegmentationBRE_exc() {
		Gson g = new Gson();
		Object json = g.fromJson(
				"{\"occupation\":{\"ocupationType\":{\"key\":1.0,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"softwareengineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69.0,\"workExperienceInMonths\":null,\"principalIndustry\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1.0,\"code\":null,\"value\":null},\"presentBusinessVintage\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"subStagePercentage\":30.0,\"additionalParameterDetail\":null,\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"additionalCibilFlag\":0.0,\"princialSelectedbyCustomerDetail\":[],\"mcpAddressDetails\":[{\"pinCodeKey\":266388,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"userProfile\":{\"applicationKey\":\"1100000000008597\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9907090001\",\"dateOfBirth\":\"1990-02-02\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27.0,\"genderKey\":22.0,\"residenceTypeKey\":1.0,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\",\"applicantKey\":123101.0},\"appScoreDetails\":{\"finalScore\":834.0,\"lrScore\":834.0,\"miScore\":830.0},\"existingCustomerFlag\":null,\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OMPersonalloan\"},\"addressList\":[{\"addressKey\":\"6582\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"pincodeKey\":\"116159\",\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000.0}]}",
				JSONObject.class);
		LocationResponseBean pinCodeMaster = new LocationResponseBean();
		pinCodeMaster.setCityName("abvcd");
		pinCodeMaster.setCityKey(2534L);
		BranchDetails branchDetails = new BranchDetails();
		branchDetails.setBranchName("ABCD");
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(json);
		when(execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY)).thenReturn("12345");
		when(execution.getVariable(CreditBusinessConstants.EMPR_CLASSIFICATION)).thenReturn("12345");
		when(execution.getVariable("lrScore")).thenReturn("12345");
		when(execution.getVariable("mlScore")).thenReturn("12345");
		when(execution.getVariable("lrScorev2")).thenReturn("12345");
		when(execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY)).thenReturn("12345");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenThrow(RuntimeException.class);
		listener.preSegmentationBRE(execution);
	}
	
	@Test
	public void testpostSegmentationBre() {
		HashMap<String, Object> segmentationDeta = new HashMap<>();
		segmentationDeta.put("segmentationResponse", new HashMap<>());	
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(segmentationDeta);
		when(execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY)).thenReturn("12345");
		listener.postSegmentationBRE(execution);
	}
	
	@Test
	public void testpreSegmentationBREVer2() {
		Gson g = new Gson();
		Object json = g.fromJson(
				"{\"occupation\":{\"ocupationType\":{\"key\":1.0,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"softwareengineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69.0,\"workExperienceInMonths\":null,\"principalIndustry\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1.0,\"code\":null,\"value\":null},\"presentBusinessVintage\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"subStagePercentage\":30.0,\"additionalParameterDetail\":null,\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"additionalCibilFlag\":0.0,\"princialSelectedbyCustomerDetail\":[],\"mcpAddressDetails\":[{\"pinCodeKey\":266388,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"userProfile\":{\"applicationKey\":\"1100000000008597\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9907090001\",\"dateOfBirth\":\"1990-02-02\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27.0,\"genderKey\":22.0,\"residenceTypeKey\":1.0,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\",\"applicantKey\":123101.0},\"appScoreDetails\":{\"finalScore\":834.0,\"lrScore\":834.0,\"miScore\":830.0},\"existingCustomerFlag\":null,\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OMPersonalloan\"},\"addressList\":[{\"addressKey\":\"6582\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"pincodeKey\":\"116159\",\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000.0}]}",
				JSONObject.class);
		LocationResponseBean pinCodeMaster = new LocationResponseBean();
		pinCodeMaster.setCityName("abvcd");
		pinCodeMaster.setCityKey(2534L);
		BranchDetails branchDetails = new BranchDetails();
		branchDetails.setBranchName("ABCD");
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(json);
		when(execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY)).thenReturn("12345");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(pinCodeMaster);
		Mockito.when(apiCallsHelper.getBranchDetails(Mockito.any(), Mockito.any())).thenReturn(branchDetails);
		listener.preSegmentationBREVer2(execution);
	}
	@Test(expected=CreditBusinessException.class)
	public void testpreSegmentationBREVer2_exc() {
		Gson g = new Gson();
		Object json = g.fromJson(
				"{\"occupation\":{\"ocupationType\":{\"key\":1.0,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"softwareengineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69.0,\"workExperienceInMonths\":null,\"principalIndustry\":null},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1.0,\"code\":null,\"value\":null},\"presentBusinessVintage\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"subStagePercentage\":30.0,\"additionalParameterDetail\":null,\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"additionalCibilFlag\":0.0,\"princialSelectedbyCustomerDetail\":[],\"mcpAddressDetails\":[{\"pinCodeKey\":266388,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"FICCLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":false,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"userProfile\":{\"applicationKey\":\"1100000000008597\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9907090001\",\"dateOfBirth\":\"1990-02-02\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27.0,\"genderKey\":22.0,\"residenceTypeKey\":1.0,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\",\"applicantKey\":123101.0},\"appScoreDetails\":{\"finalScore\":834.0,\"lrScore\":834.0,\"miScore\":830.0},\"existingCustomerFlag\":null,\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OMPersonalloan\"},\"addressList\":[{\"addressKey\":\"6582\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null,\"numberOfMonths\":null}],\"pincodeKey\":\"116159\",\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000.0}]}",
				JSONObject.class);
		LocationResponseBean pinCodeMaster = new LocationResponseBean();
		pinCodeMaster.setCityName("abvcd");
		pinCodeMaster.setCityKey(2534L);
		BranchDetails branchDetails = new BranchDetails();
		branchDetails.setBranchName("ABCD");
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(json);
		when(execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY)).thenReturn("12345");
		when(execution.getVariable(CreditBusinessConstants.EMPR_CLASSIFICATION)).thenReturn("12345");
		when(execution.getVariable("lrScore")).thenReturn("12345");
		when(execution.getVariable("mlScore")).thenReturn("12345");
		when(execution.getVariable("lrScorev2")).thenReturn("12345");
		when(execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY)).thenReturn("12345");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenThrow(RuntimeException.class);
		listener.preSegmentationBREVer2(execution);
	}
}
