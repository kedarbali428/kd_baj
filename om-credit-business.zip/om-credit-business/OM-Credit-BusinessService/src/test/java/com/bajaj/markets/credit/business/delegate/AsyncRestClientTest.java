package com.bajaj.markets.credit.business.delegate;

import static org.mockito.Mockito.when;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.helper.AsychRestHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;


@SpringBootConfiguration
@SpringBootTest
public class AsyncRestClientTest {

	CreditBusinessHelper creditBusinessHelper;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	AsychRestHelper asynchRestHelper;

	@Mock
	private CustomDefaultHeaders customDefaultHeaders;

	@Mock
	Environment env;

	@Mock
	private Expression requestURL;
	@Mock
	private Expression requestType;
	@Mock
	private Expression requestParams;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	AsyncRestClient client;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(client, "creditBusinessHelper", new CreditBusinessHelper());
	}

	@Test
	public void testPostExecute() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("POST");
		when(requestParams.getValue(execution)).thenReturn("applicationid=1;userattributekey=2");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn("{}");
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		client.execute(execution);
	}

	@Test
	public void testGetExecute() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("GET");
		when(requestParams.getValue(execution)).thenReturn("applicationid=1;userattributekey=2");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(null);
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		client.execute(execution);
	}
	
	@Test
	public void testPostExecute2() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("POST");
		when(requestParams.getValue(execution)).thenReturn("applicationid={\"userattributekey\":2}");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn("{}");
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		client.execute(execution);
	}

}
