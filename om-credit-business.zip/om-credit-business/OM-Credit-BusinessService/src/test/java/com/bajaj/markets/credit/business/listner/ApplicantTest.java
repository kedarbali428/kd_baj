package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@SpringBootConfiguration
@SpringBootTest
public class ApplicantTest {

	@Mock
	private BFLLoggerUtilExt logger;

	@Autowired
	private CreditBusinessHelper creditBusinessHelper;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	Applicant listener;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testPreApplicantCreate() {
		when(execution.getVariable("name")).thenReturn(UpdateProfileTest.getBasicDetailRequest(
				"{ \"firstName\": \"Krushna\", \"middleName\": null, \"lastName\": \"Kalaskar\", \"salutationKey\": null, \"verification\": null }"));
		listener.preCreateApplicant(execution);
	}

	@Test
	public void testPostApplicantCreate() {
		JSONObject applicant = new JSONObject();
		JSONObject payload = new JSONObject();
		payload.put("applicantKey", 1234.0);
		applicant.put("payload", payload);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(applicant);
		listener.postCreateApplicant(execution);
	}

	@Test
	public void testPostApplicantCreate_NullPayload() {
		JSONObject applicant = new JSONObject();
		applicant.put("payload", null);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(applicant);
		listener.postCreateApplicant(execution);
	}
}
