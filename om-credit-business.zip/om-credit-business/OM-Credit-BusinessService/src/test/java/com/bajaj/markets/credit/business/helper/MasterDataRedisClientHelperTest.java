package com.bajaj.markets.credit.business.helper;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.EmployerMasterBean;
import com.bajaj.markets.credit.business.beans.MaritalStatus;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.referencedataclientlib.bean.AddressTypeMaster;
import com.bajaj.markets.referencedataclientlib.bean.CacheServiceException;
import com.bajaj.markets.referencedataclientlib.bean.GenderMaster;
import com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean;
import com.bajaj.markets.referencedataclientlib.bean.LookupCodeValuesResponseBean;
import com.bajaj.markets.referencedataclientlib.bean.OccupationMaster;
import com.bajaj.markets.referencedataclientlib.bean.RefreshCacheDataBean;
import com.bajaj.markets.referencedataclientlib.helper.MasterDataEnumConstants;
import com.bajaj.markets.referencedataclientlib.service.CacheService;
import com.bajaj.markets.referencedataclientlib.service.CommonCacheService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

@SpringBootTest
public class MasterDataRedisClientHelperTest {

	@Mock
	BFLLoggerUtilExt logger;

	@InjectMocks
	MasterDataRedisClientHelper redisHelper;

	@Mock
	private CacheService cacheService;

	@Mock
	private CommonCacheService commonCacheService;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testgetGenderByTypeKey() {
		Mockito.when(cacheService.findByKey(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new GenderMaster());
		redisHelper.getGenderByTypeKey(1234L);
	}

	@Test
	public void testgetLookupValueByLookupCodeAndKey() {
		Mockito.when(cacheService.findByKey(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new LookupCodeValuesResponseBean());
		redisHelper.getLookupValueByLookupCodeAndKey("abcd", 123L);
	}

	@Test
	public void testgetLookupValueByLookupCodeAndSortTxt() {
		Mockito.when(cacheService.findByKey(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new LookupCodeValuesResponseBean());
		redisHelper.getLookupValueByLookupCodeAndSortTxt("abcd", "abcd");
	}

	@Test
	public void testgetAddressTypeKeyForCode() {
		Mockito.when(cacheService.findByCode(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new AddressTypeMaster());
		redisHelper.getAddressTypeKeyForCode("abcd");
	}

	@Test
	public void testgetGetLookupByValueAndSource() {
		Mockito.when(cacheService.findByCode(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new Object());
		redisHelper.getGetLookupByValueAndSource("abcd", "abcd");
	}

	@Test
	public void testgetOccupationKeyForCode() {
		Mockito.when(cacheService.findByCode(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new OccupationMaster());
		redisHelper.getOccupationKeyForCode("abcd");
	}

	@Test
	public void testgetOccupationByKey() {
		Mockito.when(cacheService.findByKey(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new OccupationMaster());
		redisHelper.getOccupationByKey(1234L);
	}

	@Test
	public void testgetPinCodeByKey() {
		RefreshCacheDataBean commonResonse = new RefreshCacheDataBean();
		commonResonse.setReferenceDataObject(new LocationResponseBean());
		Mockito.when(commonCacheService.findByKeyOrCode(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(commonResonse);
		redisHelper.getPinCodeByKey(1234L);
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testgetPinCodeByKey_ex()  {
		RefreshCacheDataBean commonResonse = new RefreshCacheDataBean();
		commonResonse.setReferenceDataObject(new LocationResponseBean());
		Mockito.when(commonCacheService.findByKeyOrCode(Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException("Test"));
		redisHelper.getPinCodeByKey(1234L);
	}

	@Test
	public void testgetEmployerByKey() throws CacheServiceException, JsonMappingException, JsonProcessingException {
		RefreshCacheDataBean commonResonse = new RefreshCacheDataBean();
		commonResonse.setReferenceDataObject(new EmployerMasterBean());
		Mockito.when(commonCacheService.findByKeyOrCode(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(commonResonse);
		redisHelper.getEmployerByKey(1234L);
	}

	@Test
	public void testFindAllCommonMasters() throws CacheServiceException, JsonMappingException, JsonProcessingException {
		Mockito.when(commonCacheService.findAll(Mockito.any())).thenReturn(new Object());
		redisHelper.findAllCommonMasters(MasterDataEnumConstants.MasterName.GENDER, new HashMap<>(), Object.class);
	}

	@Test
	public void testFindResitypeByKey() throws JsonMappingException, JsonProcessingException {
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		resiArr[0] = resi;
		Mockito.when(commonCacheService.findAll(Mockito.any())).thenReturn(resiArr);
		redisHelper.findResitypeByKey(1L);
	}

	@Test
	public void testfindMaritailStatusByKey() throws JsonMappingException, JsonProcessingException {
		MaritalStatus[] mrsArr = new MaritalStatus[1];
		MaritalStatus mrs = new MaritalStatus();
		mrs.setMaritalStatusKey(1L);
		mrsArr[0] = mrs;
		Mockito.when(commonCacheService.findAll(Mockito.any())).thenReturn(mrsArr);
		redisHelper.findMaritailStatusByKey(1L);
	}
	
	@Test
	public void testgetGenderReferenceByTypeKey() {
		Mockito.when(cacheService.findByKey(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new GenderMaster());
		redisHelper.getGenderReferenceByTypeKey(1234L);
	}

}
