package com.bajaj.markets.credit.business.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.validation.Validation;
import javax.validation.Validator;

import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.validator.StringValidator;
import com.bajaj.markets.credit.business.beans.validator.ValidString;
import com.bajaj.markets.credit.business.service.CreditBusinessPanVerificationService;

@SpringBootTest(classes = { StringValidator.class, ValidString.class})
public class CreditBusinessPanVerificationControllerTest {
	
	@InjectMocks
	CreditBusinessPanVerificationController panVerificationController;
	
	@Mock
	private BFLLoggerUtilExt logger;
	
	@Mock
	private CreditBusinessPanVerificationService creditBusinessPanVerificationService;
	
	@Mock
	private Environment env;
	
	private MockMvc mockMvc;
	
	private Validator validator;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		validator = Validation.buildDefaultValidatorFactory().getValidator();
		ReflectionTestUtils.setField(panVerificationController, "validator", validator);
	}
	
	@Test
	public void testValidateAndUpdatePan_InvalidPanNumber() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(panVerificationController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();
		JSONObject request = new JSONObject();
		request.put("panNumber", "PPPAP1234P");
		mockMvc.perform(post("/v2/credit/applications/{applicationId}/pan-verification", "1234").contentType(MediaType.APPLICATION_JSON).content(request.toString()).headers(new HttpHeaders())).andExpect(status().isBadRequest());
	}
	
	@Test
	public void testValidateAndUpdatePan_InvalidApplicationId() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(panVerificationController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();
		JSONObject request = new JSONObject();
		request.put("panNumber", "PPPAP1234P");
		mockMvc.perform(post("/v2/credit/applications/{applicationId}/pan-verification", "123445678901234567890").content(request.toString()).contentType(MediaType.APPLICATION_JSON).headers(new HttpHeaders())).andExpect(status().isBadRequest());
	}
	
	@Test
	public void testValidateAndUpdatePan_ValidPanNumber() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(panVerificationController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();
		JSONObject request = new JSONObject();
		request.put("panNumber", "PPPPP1234P");
		mockMvc.perform(post("/v2/credit/applications/{applicationId}/pan-verification", "1234").contentType(MediaType.APPLICATION_JSON).content(request.toString()).headers(new HttpHeaders())).andExpect(status().isCreated());
	}
}
