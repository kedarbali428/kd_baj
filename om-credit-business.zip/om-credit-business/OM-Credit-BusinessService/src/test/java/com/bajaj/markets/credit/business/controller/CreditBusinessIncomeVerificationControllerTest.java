package com.bajaj.markets.credit.business.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.service.impl.CreditBusinessIncomeVerificationServiceImpl;

@SpringBootTest
public class CreditBusinessIncomeVerificationControllerTest {

	@InjectMocks
	private CreditBusinessIncomeVerificationController creditBusinessIncomeVeriController;

	@Mock
	private CreditBusinessIncomeVerificationServiceImpl creditBusinessIncomeVeriService;

	@Mock
	private BFLLoggerUtilExt logger;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessIncomeVeriController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class)
				.addPlaceholderValue("/v1/credit/application/{applicationid}/verification/income",
						"/v1/credit/application/{applicationid}/verification/income")
				.build();
	}

	@Test
	public void testCompleteIncomeVerification() throws Exception {
		mockMvc.perform(post("/v1/credit/application/{applicationid}/verification/income", 1234)
				.contentType(MediaType.APPLICATION_JSON_VALUE).headers(new HttpHeaders())).andExpect(status().isCreated());
	}
}
