package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.EMAIL;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@SpringBootTest
public class CreditVidyaListenerTests {
	
	@InjectMocks
	CreditVidyaListener creditVidyaListener;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	DelegateExecution execution;
	
	@Mock
	Application application;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testPostGetPersonalEmail() {
		JSONObject email = new JSONObject();
		email.put(EMAIL, "test@gmail.com");
		Mockito.when(execution.getVariable(Mockito.anyString())).thenReturn(email);
		creditVidyaListener.postGetPersonalEmail(execution);
	}
	
	@Test
	public void testPostGetCreditVidyaRiskCategory() {
		JSONObject creditVidyaResponse = new JSONObject();
		Object apiException  =true;
		Mockito.when(execution.getVariable(Mockito.anyString())).thenReturn(creditVidyaResponse);
		Mockito.when(execution.getVariable(Mockito.anyString())).thenReturn(apiException);
		creditVidyaListener.postGetCreditVidyaRiskCategory(execution);
	}
	
	@Test
	public void testPostGetAddress() {
		creditVidyaListener.postGetAddress(execution);
	}
	
	@Test
	public void testPostGetNSDLPanDetails() {
		creditVidyaListener.postGetNSDLPanDetails(execution);
	}
	
	@Test
	public void testPostGetOccupationMaster() {
		Mockito.when(execution.getVariable(OUTPUT)).thenReturn(new ArrayList<Object>());
		creditVidyaListener.postGetOccupationMaster(execution);
	}
	
	@Test
	public void testPostGetOccupation() {
		JSONObject occupationObject = new JSONObject();
		List<JSONObject> occupationList = new ArrayList<JSONObject>();
		JSONObject occupationType = new JSONObject();
		JSONObject businessOwnerDetails = new JSONObject();
		
		occupationType.put("key", "key");
		
		businessOwnerDetails.put("profitAferTax", new BigDecimal(6500000));

		occupationObject.put("ocupationType", occupationType);
		occupationObject.put("businessOwnerDetails", businessOwnerDetails);
		occupationObject.put("occupationValue", "OccupationValue");
		occupationObject.put("occupationCode", "SEMP");
		occupationObject.put("occupationKey", "key");

		occupationList.add(occupationObject);
		when(execution.getVariable(Mockito.anyString())).thenReturn(occupationObject, occupationList);
		creditVidyaListener.postGetOccupation(execution);
	}
	
	@Test
	public void testPostGetSalaryDetails() {
		Mockito.when(execution.getVariable(OUTPUT)).thenReturn(new ArrayList<Object>());
		creditVidyaListener.postGetSalaryDetails(execution);
	}
	
	@Test
	public void testPostMedhasDecision() {
		JSONObject medhasDecisionStatus = new JSONObject();
		medhasDecisionStatus.put("medhasDecisionApproved", true);
		medhasDecisionStatus.put("medhasOfferPresent", true);
		medhasDecisionStatus.put("incomeVerificationRequired", true);
		Mockito.when(execution.getVariable(OUTPUT)).thenReturn(medhasDecisionStatus);
		creditVidyaListener.postMedhasDecision(execution);
	}
	
	@Test
	public void testFlowFromIncomeVerification() {
		creditVidyaListener.flowFromIncomeVerification(execution, true);
	}
	
	@Test
	public void testPreRegisterUser() {
		Mockito.when(execution.getVariable(Mockito.anyString())).thenReturn("9999999999", "1000000000000000000");
		creditVidyaListener.preRegisterUser(execution);
	}
	
	@Test
	public void testPrepareMedhasDecisionJarRequest() {
		JSONObject nsdlPanVerificationResponse = new JSONObject();
		nsdlPanVerificationResponse.put("panName", "Test Test");
		nsdlPanVerificationResponse.put("panNumber", "PPPPP1234P");
		JSONObject currentAddress = new JSONObject();
		String dob = "1990-10-10";
		String genderkey = "22";
		JSONObject name = new JSONObject();
		name.put("firstName", "firstName");
		name.put("middleName", "middleName");
		name.put("lastName", "lastName");
		String email = "test@gmail.com";
		JSONObject loanPricing = new JSONObject();
		loanPricing.put("finalLoanAmount", 100000);
		loanPricing.put("tenureDropline", 12);
		List<Object> salaries = new ArrayList<Object>();
		String childApplicationId = "100000000000000000";
		String cibilJson = "cibilString";
		String perfiosJson = "perfiosString";
		String occupationType = "Salaried";
		Mockito.when(execution.getVariable(Mockito.anyString())).thenReturn(nsdlPanVerificationResponse, loanPricing, currentAddress, dob, genderkey, name, email, salaries, occupationType, childApplicationId, cibilJson, perfiosJson);
		creditVidyaListener.prepareMedhasDecisionJarRequest(execution);
	}
	
	@Test
	public void testPreChildRejectionBre() {
		creditVidyaListener.preChildRejectionBre(execution);
	}
	
	@Test
	public void testPreUpdatePricingDetails() {
		Mockito.when(execution.getVariable(Mockito.anyString()))
			.thenReturn("{\"high\":21600,\"minProcessingFee\":1500,\"processingFeePercent\":5,\"low\":10000,\"roi\":36,\"tenure\":6}")
			.thenReturn("{\"appLoanPricingKey\":\"49251\",\"applicationKey\":\"1100000000046314\",\"prodCategoryCode\":\"OMPL\",\"isTenure\":0,\"droplineTenure\":48,\"emiAmount\":7822,\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20,\"firstDueDate\":\"2022-01-02\",\"dueDay\":2,\"graceTerm\":null,\"nextDueDate\":null,\"roi\":14.65,\"isEmi\":\"6142\",\"droplineEmi\":6142,\"pennantLoanType\":\"SOLTL\",\"netDisbursementAmount\":190891,\"loanAmount\":200000,\"fees\":[{\"feesKey\":325846,\"appLoanPricingKey\":49251,\"feesInPercent\":2.25,\"feesInAmount\":4610,\"feeCode\":\"PROCFEE\",\"isactive\":1},{\"feesKey\":325845,\"appLoanPricingKey\":49251,\"feesInPercent\":0,\"feesInAmount\":4499,\"feeCode\":\"CONV\",\"isactive\":1},{\"feesKey\":325844,\"appLoanPricingKey\":49251,\"feesInPercent\":0,\"feesInAmount\":0,\"feeCode\":\"STAMPFEE\",\"isactive\":1}],\"loanType\":\"BFLSOLTL\",\"isBpiApplicable\":\"Yes\",\"roiWithBundle\":14.25,\"roiWithoutBundle\":14.65,\"finalLoanAmount\":204920,\"loanAmmountWithBundle\":204920,\"loanAmmountWithoutBundle\":200000,\"pricingStatus\":\"APPROVED\",\"raisedBy\":null,\"finalRoi\":14.25,\"source\":\"JOURNEY\",\"bundlePrice\":[{\"bundleFinalPrice\":4920,\"bundleFloorPrice\":null,\"bundleMaxPrice\":null,\"bundleCostReference\":null}],\"approval\":{\"approvalStatus\":\"APPROVED\",\"approvedBy\":null,\"raisedBy\":null},\"bundleSelected\":1,\"l3ProductCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLTL\",\"l3ProductDesc\":\"BFL Personal Loan - Salaried\"}");
		
		creditVidyaListener.preUpdatePricingDetails(execution);
	}
	
	@Test
	public void testFetchLoanPricing() {
		creditVidyaListener.postFetchLoanPricing(execution);
	}
	
	@Test
	public void testPreGetIncomeImputation() {
		creditVidyaListener.preGetIncomeImputation(execution);
	}
	
	@Test
	@SuppressWarnings("unchecked")
	public void testPostGetIncomeImpuation() {
		List<JSONObject> incomeEstimationList = new ArrayList<JSONObject>();
		JSONObject incomeEstimation = new JSONObject();
		incomeEstimation.put("incomeputationkey", "incomemputationKey");
		incomeEstimation.put("status", "COMPLETED");
		incomeEstimationList.add(incomeEstimation);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(null).thenReturn(incomeEstimationList);
		creditVidyaListener.postGetIncomeImputation(execution);
	}
	
	@Test
	public void testPostGetIncomeImputation_ExceptionArise() {
		when(execution.getVariable(Mockito.anyString())).thenReturn(true);
		creditVidyaListener.postGetIncomeImputation(execution);
	}
	
	@Test
	@SuppressWarnings("unchecked")
	public void testPostFetchChannelJson() {
		JSONObject channelResponse = new JSONObject();
		channelResponse.put("channelResponse", "{\"perfiosJson\":\"\"}");
		when(execution.getVariable(Mockito.anyString())).thenReturn(channelResponse);
		creditVidyaListener.postFetchChannelJson(execution);
	}
	
	@Test
	public void testPreCVApprovalStatus() {
		creditVidyaListener.preCVApprovalStatus(execution);
	}
	
	@Test
	public void testPostFetchCibilReportJson() {
		Object cibilResponse = "{\"cibilReferenceKey\":999842,\"applicationKey\":1100000004591816,\"applicantKey\":16137719,\"assets\":[{\"assetId\":\"2878496136\",\"status\":\"ACTIVE\",\"trueLinkCreditReport\":{\"referenceKey\":\"3840549190\",\"fraudIndicator\":\"false\",\"currentversion\":\"5.0\",\"borrower\":[{\"creditScore\":[{\"riskScore\":\"757\",\"scoreName\":\"CIBILTransUnionScore3\",\"populationRank\":\"21\",\"creditScoreModel\":{\"symbol\":\"CIBILTUSC3\"},\"source\":{\"inquiryDate\":1618252200000,\"borrowerKey\":\"1362519440\"}}],\"borrowerAddress\":[{\"creditAddress\":{\"streetAddress\":[\"BAUNSAMULA,KHORDA,752022\"],\"postalCode\":\"752022\",\"region\":\"21\",\"serialNumber\":\"1388546531\",\"addressType\":\"  \"},\"dateReported\":\"1618252200000\",\"enrichMode\":\"E\",\"dwelling\":{\"symbol\":\"02\"}},{\"creditAddress\":{\"streetAddress\":[\"BHUBANESWAR BHU BHU BHUBANESWAR\"],\"postalCode\":\"751003\",\"region\":\"21\",\"serialNumber\":\"1386484216\",\"addressType\":\"  \"},\"dateReported\":\"1617820200000\",\"enrichMode\":\"E\",\"dwelling\":{\"symbol\":\"02\"}},{\"creditAddress\":{\"streetAddress\":[\"BAUNSMULA KALUPARAGHAT KALUPURAGHAT\"],\"postalCode\":\"752022\",\"region\":\"21\",\"serialNumber\":\"1385514573\",\"addressType\":\"  \"},\"dateReported\":\"1617647400000\",\"enrichMode\":\"E\",\"dwelling\":{\"symbol\":\"01\"}},{\"creditAddress\":{\"streetAddress\":[\"Q NO- A/209,LOKA ,COLONY,JATNI, NEARRAILWAY HEALTH UNIT ,, , , KHORDHA\"],\"postalCode\":\"752050\",\"region\":\"21\",\"serialNumber\":\"1385188366\",\"addressType\":\"  \"},\"dateReported\":\"1617561000000\",\"enrichMode\":\"E\",\"dwelling\":{\"symbol\":\"02\"}}],\"birth\":[{\"birthDate\":{\"year\":1988,\"month\":6,\"day\":2}}],\"creditStatement\":[{\"statementType\":{\"symbol\":\"DISPUTE\"}}],\"employer\":[],\"borrowerTelephone\":[{\"phoneNumber\":{\"number\":\"9438282986\"},\"phoneType\":{\"symbol\":\"03\"},\"enrichMode\":\"E\"},{\"phoneNumber\":{\"number\":\"9237468531\"},\"phoneType\":{\"symbol\":\"03\"},\"enrichMode\":\"E\"},{\"phoneNumber\":{\"number\":\"8455887698\"},\"phoneType\":{\"symbol\":\"01\"},\"enrichMode\":\"R\"},{\"phoneNumber\":{\"number\":\"9237468531\"},\"phoneType\":{\"symbol\":\"01\"},\"enrichMode\":\"R\"}],\"gender\":\"Male\",\"emailAddress\":[{\"email\":\"PSITAKANTA@GMAIL.COM\"}],\"identifierPartition\":[{}]}],\"tradelinePartition\":[{\"tradeline\":[{\"grantedTrade\":{\"accountType\":{\"symbol\":\"05\"},\"payStatusHistory\":{\"status\":\"STD,STD,STD,STD,STD,STD,STD,STD,STD,STD,STD,STD,STD,STD,STD,STD,STD,\",\"startDate\":1614537000000,\"endDate\":1572546600000},\"creditLimit\":\"-1\",\"collateral\":\"-1\",\"cashLimit\":\"-1\",\"interestRate\":\"12.00\",\"termMonths\":\"80\",\"emiamount\":\"19323\",\"actualPaymentAmount\":\"-1\",\"amountPastDue\":\"-1\",\"dateLastPayment\":\"1604341800000\",\"paymentFrequency\":{\"symbol\":\"03\"}},\"creditorName\":\"SBI\",\"accountNumber\":\"#############6454\",\"highBalance\":\"950000\",\"dateAccountStatus\":\"1604341800000\",\"currentBalance\":\"478725\",\"dateOpened\":\"1573756200000\",\"dateReported\":\"1617129000000\",\"accountDesignator\":{\"symbol\":\"1\"},\"writtenOffAmtTotal\":\"-1\",\"writtenOffPrincipal\":\"-1\",\"settlementAmount\":\"-1\",\"accountCondition\":[{\"abbreviation\":\"\",\"symbol\":\"\"}]}],\"accountTypeSymbol\":\"05\"}],\"inquiryPartition\":[{\"inquiry\":[{\"inquiryType\":\"17\",\"subscriberName\":\"MANAPPURAM\",\"amount\":\"1000000\",\"inquiryDate\":\"1618252200000\"}]}]}}]}";
		when(execution.getVariable(Mockito.anyString())).thenReturn(cibilResponse);
		creditVidyaListener.postFetchCibilReportJson(execution);
	}
	
	@Test
	public void testPostFetchCibilReportJson_NullResponse() {
		Object cibilResponse = null;
		when(execution.getVariable(Mockito.anyString())).thenReturn(cibilResponse);
		creditVidyaListener.postFetchCibilReportJson(execution);
	}
}
