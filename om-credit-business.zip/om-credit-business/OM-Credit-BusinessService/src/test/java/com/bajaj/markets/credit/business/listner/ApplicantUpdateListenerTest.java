package com.bajaj.markets.credit.business.listner;

import java.util.concurrent.Executor;

import org.activiti.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.ApplicantUpdateDetails;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;

@SpringBootConfiguration
@SpringBootTest
public class ApplicantUpdateListenerTest {
	
	@InjectMocks
	ApplicantUpdateListener applicantUpdateListener;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	ApplicantUpdateDetails applicantUpdateDetails;
	
	@Mock
	private Executor customExecutor;
	
	@Mock
	DelegateExecution execution;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void updateApplicantDataTest() {
		Mockito.doAnswer((InvocationOnMock invocation) -> {
			((Runnable) invocation.getArguments()[0]).run();
			return null;
		}).when(customExecutor).execute(Mockito.any(Runnable.class));
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("111111");
		applicantUpdateListener.updateApplicantData(execution);
	}
	
	@Test
	public void updateApplicantAddressTest() {
		Mockito.doAnswer((InvocationOnMock invocation) -> {
			((Runnable) invocation.getArguments()[0]).run();
			return null;
		}).when(customExecutor).execute(Mockito.any(Runnable.class));
		applicantUpdateListener.updateApplicantAddress(execution);
	}
}
