package com.bajaj.markets.credit.business.listner;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AdditionalDetailLoans;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
public class AdditionalDetailListenerTest {

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;
	
	@Mock
	CreditBusinessApiCallsHelper apiCallsHelper;

	@InjectMocks
	AdditionalDetailListener listener;
	
	@Mock
	CreditBusinessHelper creditBusinessHelper;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testPostAdditionalDetailsLoan() {
		JSONObject request = new JSONObject();
		request.put(CreditBusinessConstants.DESIGNATION_REQUIRED, true);
		request.put(CreditBusinessConstants.PERSONAL_EMAIL_REQUIRED, true);
		request.put(CreditBusinessConstants.WORKEMAILID, "Dummy1@bajajfinserv.in");
		request.put(CreditBusinessConstants.EMPLOYER_REQUIRED, true);
		Mockito.when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(request);
		listener.postAdditionalDetailsLoan(execution);
	}

	@Test
	public void testMultipleAddressUpdate() throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		AdditionalDetailLoans request = mapper.readValue(
				"{\"action\":null,\"applicationid\":\"1100000000046964\",\"permanentAddressRequired\":false,\"fatherName\":\"Vilas Joshi\",\"l3ProductCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLHFL\",\"principalKey\":null,\"motherName\":\"Vaishali Joshi \",\"presentBusinessVintage\":null,\"currentWorkExperience\":null,\"averageBankBalance\":\"\",\"workEmailId\":\"abcd@cognizant.com\",\"isGinFlow\":false,\"personalEmailId\":\"prathamjoshi@gmail.com\",\"personalEmailRequired\":true,\"designationRequired\":true,\"designation\":{\"code\":null,\"key\":0,\"value\":\"Test designation\"},\"addressDetails\":[{\"addressKey\":null,\"addressLine1\":\"asdasd\",\"addressLine2\":\"asdasdas\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"50\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411041\",\"pincodeKey\":\"116159\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null,\"numberOfMonths\":null},{\"addressKey\":null,\"addressLine1\":\"asdasd\",\"addressLine2\":\"asdasdas\",\"addressSource\":\"ABC\",\"addressTypeKey\":\"50\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411041\",\"pincodeKey\":\"116159\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null,\"numberOfMonths\":null},{\"addressKey\":null,\"addressLine1\":\"asdasd asdasd asda\",\"addressLine2\":\"asda sda asdasd\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"46\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411041\",\"pincodeKey\":\"116159\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},{\"addressKey\":null,\"addressLine1\":\"asdasd asdasd asda\",\"addressLine2\":\"asda sda asdasd\",\"addressSource\":\"XYZ\",\"addressTypeKey\":\"46\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411041\",\"pincodeKey\":\"116159\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null}],\"nomineeDetails\":[{\"dateOfBirth\":\"1982-12-02\",\"name\":\"abcd acbd\",\"relationship\":{\"code\":\"3\",\"key\":3,\"value\":\"Mother\"}}],\"qualification\":{\"code\":null,\"key\":null,\"value\":null},\"loanPurpose\":{\"code\":null,\"key\":null,\"value\":null},\"relatedPersonnelDetails\":[]}",
				AdditionalDetailLoans.class);
		Mockito.when(execution.getVariable(CreditBusinessConstants.CHILDAPPLICATIONID)).thenReturn("123");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn(123);
		Mockito.when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(request);
		
		listener.multipleAddressUpdate(execution);
	}
	
	
	@Test
	public void testpreNonGinPersonalEmail() throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		AdditionalDetailLoans request = mapper.readValue(
				"{\"action\":null,\"applicationid\":\"1100000000046964\",\"permanentAddressRequired\":false,\"fatherName\":\"Vilas Joshi\",\"l3ProductCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLHFL\",\"principalKey\":null,\"motherName\":\"Vaishali Joshi \",\"presentBusinessVintage\":null,\"currentWorkExperience\":null,\"averageBankBalance\":\"\",\"workEmailId\":\"abcd@cognizant.com\",\"isGinFlow\":false,\"personalEmailId\":\"prathamjoshi@gmail.com\",\"personalEmailRequired\":true,\"designationRequired\":true,\"designation\":{\"code\":null,\"key\":0,\"value\":\"Test designation\"},\"addressDetails\":[{\"addressKey\":null,\"addressLine1\":\"asdasd\",\"addressLine2\":\"asdasdas\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"50\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411041\",\"pincodeKey\":\"116159\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null,\"numberOfMonths\":null},{\"addressKey\":null,\"addressLine1\":\"asdasd\",\"addressLine2\":\"asdasdas\",\"addressSource\":\"ABC\",\"addressTypeKey\":\"50\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411041\",\"pincodeKey\":\"116159\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null,\"numberOfMonths\":null},{\"addressKey\":null,\"addressLine1\":\"asdasd asdasd asda\",\"addressLine2\":\"asda sda asdasd\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"46\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411041\",\"pincodeKey\":\"116159\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},{\"addressKey\":null,\"addressLine1\":\"asdasd asdasd asda\",\"addressLine2\":\"asda sda asdasd\",\"addressSource\":\"XYZ\",\"addressTypeKey\":\"46\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411041\",\"pincodeKey\":\"116159\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null}],\"nomineeDetails\":[{\"dateOfBirth\":\"1982-12-02\",\"name\":\"abcd acbd\",\"relationship\":{\"code\":\"3\",\"key\":3,\"value\":\"Mother\"}}],\"qualification\":{\"code\":null,\"key\":null,\"value\":null},\"loanPurpose\":{\"code\":null,\"key\":null,\"value\":null},\"relatedPersonnelDetails\":[]}",
				AdditionalDetailLoans.class);
		Mockito.when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(request);
		listener.preNonGinPersonalEmail(execution);
	}
	
	@Test
	public void testPostGetOccupation(){
		Mockito.when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(
				"{\"ocupationType\":{\"key\":2,\"code\":\"SEMP\",\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":null,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":null},\"experience\":\"null\",\"netSalary\":\"null\",\"employerType\":null},\"businessOwnerDetails\":{\"businessName\":\"sdadadads\",\"businessType\":{\"key\":1,\"code\":null,\"value\":null},\"natureOfBusiness\":{\"key\":1,\"code\":null,\"value\":null},\"industryType\":{\"key\":11,\"code\":null,\"value\":null},\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":\"200000\",\"businessVintage\":{\"key\":null,\"code\":\"5\",\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":null,\"profitAfterTax\":null,\"averageBankBalance\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":null} ");
		listener.postGetOccupation(execution);
	}
	
	@Test
	public void testpreGinPutV2Address() throws JsonMappingException, JsonProcessingException {
		List<Address> addressList = new ArrayList<Address>();
		Address adrs = new Address();
		adrs.setAddressSource(CreditBusinessConstants.ADD_SRC_OFFERAPI);
		addressList.add(adrs);
		Mockito.when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(addressList);
		listener.preGinPutV2Address(execution);
	}

}
