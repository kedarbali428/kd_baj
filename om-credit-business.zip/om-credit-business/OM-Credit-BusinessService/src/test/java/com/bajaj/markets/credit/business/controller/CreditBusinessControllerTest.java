
package com.bajaj.markets.credit.business.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.Validator;
import javax.validation.metadata.ConstraintDescriptor;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.ImpsRequestMetadata;
import com.bajaj.markets.credit.business.beans.ProfileDetail;
import com.bajaj.markets.credit.business.beans.ProfileDetails;
import com.bajaj.markets.credit.business.service.CreditBusinessService;
import com.fasterxml.jackson.databind.ObjectMapper;

@AutoConfigureMockMvc
@WebMvcTest(CreditBusinessController.class)
public class CreditBusinessControllerTest {

	@Mock
	private Validator validator;

	@Mock
	BFLLoggerUtilExt logger;

	@InjectMocks
	CreditBusinessController creditBusinessController;

	@Autowired
	CreditBusinessControllerAdvice creditBusinessControllerAdvice;

	@Mock
	private CreditBusinessService creditBusinessService;

	@Autowired
	private MockMvc mockMvc;
	
	@Mock
	private Environment env;

	ApplicationResponse applicationResponse;
	
	List<ImpsRequestMetadata> impsRequestMetadataList;

	ObjectMapper mapper = new ObjectMapper();

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessController).setControllerAdvice(CreditBusinessControllerAdvice.class).build();
		impsRequestMetadataList = new ArrayList<>();
	}
 
	@Test
	public void testProfile_Post() throws Exception {
		String request = "{\"name\":\"string\",\"occupation\":\"SEMP\",\"pan\":\"string\",\"personalEmailId\":\"string\",\"businessPan\":\"string\",\"gstNumber\":\"string\",\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"ssss\"},\"pinCode\":{\"city\":\"string\",\"cityKey\":\"string\",\"country\":\"string\",\"countryCode\":\"string\",\"negetiveAreaFlag\":true,\"oglFlag\":true,\"pinCode\":0,\"pinKey\":0,\"shortName\":\"string\",\"state\":\"string\",\"stateKey\":\"string\"}}";
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/profile", "1234").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isCreated());
	}

	@Test
	public void testProfile_Post_BusinessValidtion() throws Exception {
		Set<ConstraintViolation<Object>> validationErrors = new HashSet<>();
		ConstraintViolation<Object> validationError = new ConstraintViolation<Object>() {

			@Override
			public <U> U unwrap(Class<U> type) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Class<Object> getRootBeanClass() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ProfileDetails getRootBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Path getPropertyPath() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getMessageTemplate() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getMessage() {
				// TODO Auto-generated method stub
				return "Business Pan can not be null or empty";
			}

			@Override
			public Object getLeafBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getInvalidValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getExecutableReturnValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object[] getExecutableParameters() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ConstraintDescriptor<?> getConstraintDescriptor() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		validationErrors.add(validationError);
		when(validator.validate(any(), any())).thenReturn(validationErrors);
		String request = "{\"name\":\"string\",\"occupation\":\"SEMP\",\"pan\":\"string\",\"personalEmailId\":\"string\",\"businessPan\":\"string\",\"gstNumber\":\"string\",\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"ssss\"},\"pinCode\":{\"city\":\"string\",\"cityKey\":\"string\",\"country\":\"string\",\"countryCode\":\"string\",\"negetiveAreaFlag\":true,\"oglFlag\":true,\"pinCode\":0,\"pinKey\":0,\"shortName\":\"string\",\"state\":\"string\",\"stateKey\":\"string\"}}";
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/profile", "1234").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isUnprocessableEntity());
	}

	@Test
	public void testProfile_Post_SalariedValidtion() throws Exception {
		Set<ConstraintViolation<Object>> validationErrors = new HashSet<>();
		ConstraintViolation<Object> validationError = new ConstraintViolation<Object>() {

			@Override
			public <U> U unwrap(Class<U> type) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Class<Object> getRootBeanClass() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ProfileDetails getRootBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Path getPropertyPath() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getMessageTemplate() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getMessage() {
				// TODO Auto-generated method stub
				return "Work Email can not be null or empty";
			}

			@Override
			public Object getLeafBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getInvalidValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getExecutableReturnValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object[] getExecutableParameters() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ConstraintDescriptor<?> getConstraintDescriptor() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		validationErrors.add(validationError);
		when(validator.validate(any(), any())).thenReturn(validationErrors);
		String request = "{\"name\":\"string\",\"occupation\":\"SALR\",\"pan\":\"string\",\"personalEmailId\":\"string\",\"businessPan\":\"string\",\"gstNumber\":\"string\",\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"ssss\"},\"pinCode\":{\"city\":\"string\",\"cityKey\":\"string\",\"country\":\"string\",\"countryCode\":\"string\",\"negetiveAreaFlag\":true,\"oglFlag\":true,\"pinCode\":0,\"pinKey\":0,\"shortName\":\"string\",\"state\":\"string\",\"stateKey\":\"string\"}}";
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/profile", "1234").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isUnprocessableEntity());
	}

	@Test
	public void testProfile_Post_InvalidOccupation() throws Exception {
		Set<ConstraintViolation<Object>> validationErrors = new HashSet<>();
		ConstraintViolation<Object> validationError = new ConstraintViolation<Object>() {

			@Override
			public <U> U unwrap(Class<U> type) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Class<Object> getRootBeanClass() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ProfileDetails getRootBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Path getPropertyPath() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getMessageTemplate() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getMessage() {
				// TODO Auto-generated method stub
				return "Invalid Occupation passed to parameter";
			}

			@Override
			public Object getLeafBean() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getInvalidValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getExecutableReturnValue() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object[] getExecutableParameters() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ConstraintDescriptor<?> getConstraintDescriptor() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		validationErrors.add(validationError);
		when(validator.validate(any(), any())).thenReturn(validationErrors);
		String request = "{\"name\":\"string\",\"occupation\":\"invalidOccupation\",\"pan\":\"string\",\"personalEmailId\":\"string\",\"businessPan\":\"string\",\"gstNumber\":\"string\",\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"ssss\"},\"pinCode\":{\"city\":\"string\",\"cityKey\":\"string\",\"country\":\"string\",\"countryCode\":\"string\",\"negetiveAreaFlag\":true,\"oglFlag\":true,\"pinCode\":0,\"pinKey\":0,\"shortName\":\"string\",\"state\":\"string\",\"stateKey\":\"string\"}}";
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/profile", "1234").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isUnprocessableEntity());
	}

	
	@Test
	public void getProfile() throws Exception {
		when(creditBusinessService.getProfile(any(), any())).thenReturn(new ProfileDetail());
		String request = "{\"name\":\"string\",\"pan\":\"string\",\"personalEmailId\":\"string\",\"businessPan\":\"string\",\"gstNumber\":\"string\",\"maritalStatus\":{\"code\":\"string\",\"key\":0,\"value\":\"string\"},\"gender\":{\"code\":\"string\",\"key\":0,\"value\":\"ssss\"},\"pinCode\":{\"city\":\"string\",\"cityKey\":\"string\",\"country\":\"string\",\"countryCode\":\"string\",\"negetiveAreaFlag\":true,\"oglFlag\":true,\"pinCode\":0,\"pinKey\":0,\"shortName\":\"string\",\"state\":\"string\",\"stateKey\":\"string\"}}";	
		mockMvc.perform(get("/v1/credit/applications/{applicationid}/profile", "1100000000000406").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isOk());
	}
	
	@Test
	public void getImpsTest() throws Exception {
		Mockito.when(creditBusinessService.getImpsDetails(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(impsRequestMetadataList);
		mockMvc.perform(get("/v1/credit/applications/{applicationid}/imps", "1111").param("bankAcctcatKey", "1234").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
	@Test
	public void testupdateProfileDetails_Post() throws Exception {
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/bmr", "1100000000000406").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}
}
