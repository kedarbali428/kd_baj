package com.bajaj.markets.credit.business.helper;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.Application;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.ProductList;
import com.bajaj.markets.credit.business.beans.Qualification;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.beans.Specilizations;
import com.google.gson.Gson;

@SpringBootTest
@SpringBootConfiguration
public class CreditBusinessHelperTest {

	@Mock
	private RestTemplate restTemplate;

	@Mock
	HttpHeaders header;

	@InjectMocks
	private CreditBusinessHelper creditBusinessHelper;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CustomDefaultHeaders customHeaders;

	@Mock
	MasterDataRedisClientHelper masterDataRedisHelper;

	@Mock
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	@Mock
	private Environment env;

	private String getPanVerification = "getPanVerification";

	String err = "error";

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(apiCallsHelper, "getPanVerification", getPanVerification);
	}

	@Test
	public void TestMapRequest() {
		creditBusinessHelper.mapRequest(new Application());
	}

	
	@Test
	public void testInvokeRestEndpoint_withParams() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class), Mockito.eq(new HashMap<>())))
				.thenReturn(new ResponseEntity(HttpStatus.OK));
		creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, "", Object.class, new HashMap<>(), "", new HttpHeaders());
	}

	@Test
	public void testInvokeRestEndpoint_withoutParams() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(Object.class)))
				.thenReturn(new ResponseEntity(HttpStatus.OK));
		creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, "", Object.class, null, "", new HttpHeaders());
	}

	@Test(expected = CreditBusinessException.class)
	public void testInvokeRestEndpoint_ex1() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class)))
				.thenThrow(new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "", err.getBytes(), null));
		creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, "", Object.class, null, "", new HttpHeaders());
	}

	@Test(expected = CreditBusinessException.class)
	public void testInvokeRestEndpoint_ex2() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class)))
				.thenThrow(new HttpStatusCodeException(HttpStatus.INTERNAL_SERVER_ERROR, "", err.getBytes(), null) {
				});
		creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, "", Object.class, null, "", new HttpHeaders());
	}

	@Test(expected = CreditBusinessException.class)
	public void testInvokeRestEndpoint_ex3() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class)))
				.thenThrow(new RestClientException(err, new Exception()));
		creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, "", Object.class, null, "", new HttpHeaders());
	}

	@Test(expected = CreditBusinessException.class)
	public void testInvokeRestEndpoint_ex4() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(Object.class))).thenReturn(null);
		creditBusinessHelper.invokeRestEndpoint(HttpMethod.GET, "", Object.class, null, "", new HttpHeaders());
	}

	@Test
	public void testpopulateBreRequestFromMcpDetails_salaried() {
		JSONObject openArcInput = createOpenArcListingInput();
		openArcInput.put("applicationId", 1234);
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":69,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null}},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000007316\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250004\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":2,\"genderKey\":21,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234H\",\"applicantKey\":122234},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5367\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30,\"specializationCode\":\"MBBS\",\"degree\":3}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		Specilizations specilization = new Specilizations();
		specilization.setSpclmastcode("1");
		Qualification qualification = new Qualification();
		qualification.setQlfyname("MBBS");
		JSONObject creditVidyaStatusResp = g.fromJson("{\"applicantKey\":null,\"city\":\"PUNE\",\"mobileNumber\":\"9909010002\",\"dob\":\"1990-12-03 00:00:00.0\",\"companyName\":null,\"applicationKey\":\"1100000000012440\",\"fullName\":\"abc xyz\",\"emailId\":\"abcd@cognizant.com\",\"validationstatus\":\"Medium Risk\",\"salary\":null,\"l2ProductKey\":\"10002\",\"verification\":null}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);
		JSONObject employerMaster = g.fromJson("{\"indMastKey\":\"4132\"}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getBmr2ResponseFromMongo(Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, ""));
		Mockito.when(apiCallsHelper.getBmrDetails(Mockito.any())).thenReturn("{\"id\":7825,\"applicationKey\":1100000000009726,\"principalKey\":3,\"principleCustRefId\":null,\"additionalDetails\":{\"matchDetails\":null,\"approveFlag\":\"Y\",\"netSalary\":\"\",\"mandateDetails\":null,\"plLivePos\":\"\",\"errorFlag\":\"true\",\"loanFlags\":null,\"decisionFlags\":null,\"offerDetails\":null,\"pltbOffer\":null,\"customerType\":\"N\",\"bflLoanCount\":null,\"applicantId\":null,\"riskOfferType\":null,\"bflLoanDetails\":null,\"edwResponseTime\":\"\",\"applicationId\":null,\"bflPosDetails\":null,\"productType\":null,\"customerDetails\":null,\"timestamp\":null}}" );
		Mockito.when(apiCallsHelper.getCreditVidyaStatus(Mockito.any(), Mockito.any())).thenReturn(creditVidyaStatusResp);
		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(employerMaster);
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		Mockito.when(apiCallsHelper.getSOLIndustryType(Mockito.any())).thenReturn("COMPUTER RELATED SERVICES");
		Mockito.when(apiCallsHelper.getSpecialisationDetails(Mockito.any())).thenReturn(specilization);
		Mockito.when(apiCallsHelper.getQualificationDetails(Mockito.any())).thenReturn(qualification);
		
		JSONObject incomeEstimation = new JSONObject();
		incomeEstimation.put("status", "COMPLETED");
		incomeEstimation.put("statementCollected", 3.0d);
		incomeEstimation.put("incomemputationKey", "1000");
		Mockito.when(apiCallsHelper.getIncomeEstimation(Mockito.anyString(),Mockito.anyString())).thenReturn(incomeEstimation);
		Mockito.when(apiCallsHelper.fetchIncomeEstimatedChannelJson(Mockito.anyString())).thenReturn("channel json");
		
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		
		ProductList productList = g.fromJson(
				"{\"productList\":[{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.0,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":2,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLHFL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.1,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":200000,\"tenor\":48},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":\"FICCLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.2,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":0,\"priorityOrder\":4,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":\"BFLPLCSTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"Fullerton Personal loan - Business Owner\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Pocket Personal Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPPL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPPL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - C.A.\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLCAL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLCAL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - DOCTOR\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLDOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLDOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Business Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null}],\"requiredLoanAmout\":null,\"requiredTenor\":null,\"maxEligibility\":null,\"maxTenor\":null,\"name\":null} ",
				ProductList.class);
		Mockito.when(apiCallsHelper.getProductListForApplication(Mockito.any())).thenReturn(productList);
		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcInput, mcpReq, false, null, null, 1);
	}
	
	@Test
	public void testpopulateBreRequestFromMcpDetails_404BmrAndProductList() {
		JSONObject openArcInput = createOpenArcListingInput();
		openArcInput.put("applicationId", 1234);
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":69,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null}},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000007316\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250004\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":2,\"genderKey\":21,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234H\",\"applicantKey\":122234},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5367\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);
		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);
		Mockito.when(apiCallsHelper.getBmrDetails(Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, ""));
		Mockito.when(apiCallsHelper.getBmr2ResponseFromMongo(Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, ""));
		Mockito.when(apiCallsHelper.getCreditVidyaStatus(Mockito.any(), Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, ""));
		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		Mockito.when(apiCallsHelper.getProductListForApplication(Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, ""));
		
		
		
		JSONObject incomeEstimation = new JSONObject();
		incomeEstimation.put("status", null);
		Mockito.when(apiCallsHelper.getIncomeEstimation(Mockito.anyString(),Mockito.anyString())).thenReturn(incomeEstimation);
		
		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcInput, mcpReq, false, null, null, 0);
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testpopulateBreRequestFromMcpDetails_500Bmr() {
		JSONObject openArcInput = new JSONObject();
		openArcInput.put("applicationId", 1234);
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":69,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null}},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000007316\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250004\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":2,\"genderKey\":21,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234H\",\"applicantKey\":122234},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5367\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);
		Mockito.when(apiCallsHelper.getBmr2ResponseFromMongo(Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, ""));
		Mockito.when(apiCallsHelper.getBmrDetails(Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, ""));
		Mockito.when(apiCallsHelper.getCreditVidyaStatus(Mockito.any(), Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, ""));
		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());

		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);		
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcInput, mcpReq, false, null, null, null);
	}

	@Test
	public void testpopulateBreRequestFromMcpDetails_forBusinessOwner() {
		JSONObject openArcCardListingInput = createOpenArcListingInput();
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":2,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":null,\"experience\":null,\"netSalary\":null,\"employerType\":null},\"businessOwnerDetails\":{\"businessName\":\"testBusiness\",\"businessType\":null,\"natureOfBusiness\":{\"key\":1,\"code\":null,\"value\":null},\"industryType\":{\"key\":4,\"code\":null,\"value\":null},\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":\"3-5 Cr.\"},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":\"5\"},\"proprieterName\":null,\"businessPan\":\"ASWCP1234J\",\"gstNumber\":\"\",\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":1000000,\"averageBankBalance\":1000000,\"companyType\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"null\"},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250001\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"asdad\",\"middleName\":\"\",\"lastName\":\"sdasdadas\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[\"LENBOLROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5320\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":null}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);

		JSONObject lookupCall = g.fromJson(
				"{\"lookupValuesResponseList\":[{\"key\":1,\"code\":\"0\",\"value\":\"Less Than 50 Lakhs\"},{\"key\":2,\"code\":\"50\",\"value\":\"50 Lakhs-1 Cr.\"},{\"key\":3,\"code\":\"1\",\"value\":\"1-2 Cr.\"},{\"key\":4,\"code\":\"2\",\"value\":\"2-3 Cr.\"},{\"key\":5,\"code\":\"3\",\"value\":\"3-5 Cr.\"},{\"key\":6,\"code\":\"5\",\"value\":\"5-10 Cr.\"},{\"key\":7,\"code\":\"10\",\"value\":\"10-15 Cr.\"},{\"key\":8,\"code\":\"15\",\"value\":\"More than 15 Cr.\"}]} ",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getLookupByCode(Mockito.any())).thenReturn(lookupCall);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);

		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		
		ProductList productList = g.fromJson(
				"{\"productList\":[{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.0,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":2,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLHFL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.1,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":200000,\"tenor\":48},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":\"FICCLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.2,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":0,\"priorityOrder\":4,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":\"BFLPLCSTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"Fullerton Personal loan - Business Owner\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Pocket Personal Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPPL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPPL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - C.A.\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLCAL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLCAL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - DOCTOR\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLDOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLDOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Business Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null}],\"requiredLoanAmout\":null,\"requiredTenor\":null,\"maxEligibility\":null,\"maxTenor\":null,\"name\":null} ",
				ProductList.class);
		Mockito.when(apiCallsHelper.getProductListForApplication(Mockito.any())).thenReturn(productList);
		
		
		JSONObject incomeEstimation = new JSONObject();
		incomeEstimation.put("status", "COMPLETED");
		incomeEstimation.put("statementCollected", null);
		incomeEstimation.put("incomemputationKey", "1000");
		Mockito.when(apiCallsHelper.getIncomeEstimation(Mockito.anyString(),Mockito.anyString())).thenReturn(incomeEstimation);
		Mockito.when(apiCallsHelper.fetchIncomeEstimatedChannelJson(Mockito.anyString())).thenReturn("channel json");
		
		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcCardListingInput, mcpReq, false, null, null ,null);
	}

	@Test
	public void testSetName() {
		creditBusinessHelper.setName("Test Test Test");
	}

	@Test(expected = CreditBusinessException.class)
	public void testInvokeRestEndpoint_406() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class)))
				.thenThrow(new HttpClientErrorException(HttpStatus.NOT_ACCEPTABLE, "", err.getBytes(), null));
		creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, "", Object.class, null, "", new HttpHeaders());
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testInvokeRestEndpoint_404() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class)))
				.thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "", err.getBytes(), null));
		creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, "", Object.class, null, "", new HttpHeaders());
	}
	
	@Test
	public void testInvokeRestEndpoint_409() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class), Mockito.eq(new HashMap<>())))
				.thenReturn(new ResponseEntity("{\"errCode\":\"code\", \"errorMessage\":\"message\"}", HttpStatus.CONFLICT));
		creditBusinessHelper.invokeRestEndpoint(HttpMethod.POST, "", Object.class, new HashMap<>(), "", new HttpHeaders());
	}
	
	@Test
	public void testpopulateBreRequestFromMcpDetails_forBusinessOwner_NullValues() {
		JSONObject openArcCardListingInput = createOpenArcListingInput();
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":null,\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250001\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"asdad\",\"middleName\":\"\",\"lastName\":\"sdasdadas\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":null,\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5320\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":null,\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":null,\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":null}],\"appScoreDetails\":[],\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);

		JSONObject lookupCall = g.fromJson(
				"{\"lookupValuesResponseList\":null} ",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getLookupByCode(Mockito.any())).thenReturn(lookupCall);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);

		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		
		ProductList productList = g.fromJson(
				"{\"productList\":[{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.0,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":2,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLHFL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.1,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":200000,\"tenor\":48},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":\"FICCLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.2,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":0,\"priorityOrder\":4,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":\"BFLPLCSTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"Fullerton Personal loan - Business Owner\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Pocket Personal Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPPL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPPL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - C.A.\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLCAL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLCAL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - DOCTOR\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLDOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLDOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Business Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null}],\"requiredLoanAmout\":null,\"requiredTenor\":null,\"maxEligibility\":null,\"maxTenor\":null,\"name\":null} ",
				ProductList.class);
		Mockito.when(apiCallsHelper.getProductListForApplication(Mockito.any())).thenReturn(productList);
		
		
		Mockito.when(apiCallsHelper.getIncomeEstimation(Mockito.anyString(),Mockito.anyString())).thenReturn(null);
		
		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcCardListingInput, mcpReq, false, null, null, null);
	}

	@Test
	public void testpopulateBreRequestFromMcpDetails_forBusinessOwner_NullAddressList() {
		JSONObject openArcListingInput = createOpenArcListingInput();
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":null,\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250001\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"asdad\",\"middleName\":\"\",\"lastName\":\"sdasdadas\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":null,\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":null,\"princialSelectedbyCustomerDetail\":null,\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":null}],\"appScoreDetails\":[],\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);

		JSONObject lookupCall = g.fromJson(
				"{\"lookupValuesResponseList\":null} ",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getLookupByCode(Mockito.any())).thenReturn(lookupCall);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);

		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		
		ProductList productList = g.fromJson(
				"{\"productList\":[{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.0,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":2,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLHFL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.1,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":200000,\"tenor\":48},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":\"FICCLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.2,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":0,\"priorityOrder\":4,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":\"BFLPLCSTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"Fullerton Personal loan - Business Owner\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Pocket Personal Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPPL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPPL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - C.A.\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLCAL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLCAL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - DOCTOR\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLDOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLDOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Business Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null}],\"requiredLoanAmout\":null,\"requiredTenor\":null,\"maxEligibility\":null,\"maxTenor\":null,\"name\":null} ",
				ProductList.class);
		Mockito.when(apiCallsHelper.getProductListForApplication(Mockito.any())).thenReturn(productList);
		
		
		
		JSONObject incomeEstimation = new JSONObject();
		incomeEstimation.put("status", "COMPLETED");
		incomeEstimation.put("incomemputationKey", null);
		Mockito.when(apiCallsHelper.getIncomeEstimation(Mockito.anyString(),Mockito.anyString())).thenReturn(incomeEstimation);
		
		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcListingInput, mcpReq, false, null, null, null);
	}
	
	@Test
	public void testpopulateBreRequestFromMcpDetails_forBusinessOwner_EmptyAddressList() {
		JSONObject openArcCardListingInput = createOpenArcListingInput();
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":null,\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250001\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"asdad\",\"middleName\":\"\",\"lastName\":\"sdasdadas\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":null,\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[],\"princialSelectedbyCustomerDetail\":null,\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":null}],\"appScoreDetails\":[],\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);

		JSONObject lookupCall = g.fromJson(
				"{\"lookupValuesResponseList\":[]} ",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getLookupByCode(Mockito.any())).thenReturn(lookupCall);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);

		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		
		ProductList productList = g.fromJson(
				"{\"productList\":[{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.0,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":2,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLHFL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.1,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":200000,\"tenor\":48},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":\"FICCLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.2,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":0,\"priorityOrder\":4,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":\"BFLPLCSTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"Fullerton Personal loan - Business Owner\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Pocket Personal Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPPL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPPL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - C.A.\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLCAL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLCAL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - DOCTOR\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLDOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLDOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Business Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null}],\"requiredLoanAmout\":null,\"requiredTenor\":null,\"maxEligibility\":null,\"maxTenor\":null,\"name\":null} ",
				ProductList.class);
		Mockito.when(apiCallsHelper.getProductListForApplication(Mockito.any())).thenReturn(productList);
		
		
		JSONObject incomeEstimation = new JSONObject();
		incomeEstimation.put("status", "FAILED");
		incomeEstimation.put("statementCollected", null);
		Mockito.when(apiCallsHelper.getIncomeEstimation(Mockito.anyString(),Mockito.anyString())).thenReturn(incomeEstimation);
		
		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcCardListingInput, mcpReq, false, null, null, null);
	}
	
	private JSONObject createOpenArcListingInput() {
		JSONObject openArcCardListingInput = new JSONObject();
		openArcCardListingInput.put("eligibilityType", "AIP");
		openArcCardListingInput.put("applicationId", "1234");
		return openArcCardListingInput;
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testpopulateBreRequestFromMcpDetails_500ProductList() {
		JSONObject openArcInput = new JSONObject();
		openArcInput.put("applicationId", 1234);
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":69,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null}},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000007316\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250004\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":2,\"genderKey\":21,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234H\",\"applicantKey\":122234},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5367\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);
		Mockito.when(apiCallsHelper.getBmr2ResponseFromMongo(Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, ""));
		Mockito.when(apiCallsHelper.getBmrDetails(Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, ""));
		Mockito.when(apiCallsHelper.getCreditVidyaStatus(Mockito.any(), Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, ""));
		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());

		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);		
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		
		Mockito.when(apiCallsHelper.getProductListForApplication(Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR, ""));
		Mockito.when(apiCallsHelper.getIncomeEstimation(Mockito.any(),Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.NOT_FOUND, ""));
		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcInput, mcpReq, false, null, null, null);
	}
	
	@Test
	public void testpopulatePropertyBreRequestFromMcpDetails_salaried() {
		JSONObject openArcInput = new JSONObject();
		openArcInput.put("applicationId", 1234);
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":69,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null}},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000007316\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250004\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":2,\"genderKey\":21,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234H\",\"applicantKey\":122234},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5367\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000}],\"appScoreDetails\":{\"finalScore\":-777.0,\"lrScore\":-777.0,\"miScore\":-777.0},\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);
		
		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		creditBusinessHelper.populatePropertyBreRequestFromMcpDetails(openArcInput, mcpReq);
	}

	@Test
	public void testpopulatePropertyBreRequestFromMcpDetails_forBusinessOwner_EmptyAddressList() {
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":null,\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250001\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"asdad\",\"middleName\":\"\",\"lastName\":\"sdasdadas\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":null,\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[],\"princialSelectedbyCustomerDetail\":null,\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":null}],\"appScoreDetails\":[],\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);

		JSONObject lookupCall = g.fromJson(
				"{\"lookupValuesResponseList\":[]} ",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getLookupByCode(Mockito.any())).thenReturn(lookupCall);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);

		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		creditBusinessHelper.populatePropertyBreRequestFromMcpDetails(new JSONObject(), mcpReq);
	}
	
	@Test
	public void testpopulatePropertyBreRequestFromMcpDetails_forBusinessOwner() {
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":2,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":null,\"experience\":null,\"netSalary\":null,\"employerType\":null},\"businessOwnerDetails\":{\"businessName\":\"testBusiness\",\"businessType\":null,\"natureOfBusiness\":{\"key\":1,\"code\":null,\"value\":null},\"industryType\":{\"key\":4,\"code\":null,\"value\":null},\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":\"3-5 Cr.\"},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":\"5\"},\"proprieterName\":null,\"businessPan\":\"ASWCP1234J\",\"gstNumber\":\"\",\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":1000000,\"averageBankBalance\":1000000,\"companyType\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"null\"},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250001\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"asdad\",\"middleName\":\"\",\"lastName\":\"sdasdadas\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[\"LENBOLROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5320\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":null}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);

		JSONObject lookupCall = g.fromJson(
				"{\"lookupValuesResponseList\":[{\"key\":1,\"code\":\"0\",\"value\":\"Less Than 50 Lakhs\"},{\"key\":2,\"code\":\"50\",\"value\":\"50 Lakhs-1 Cr.\"},{\"key\":3,\"code\":\"1\",\"value\":\"1-2 Cr.\"},{\"key\":4,\"code\":\"2\",\"value\":\"2-3 Cr.\"},{\"key\":5,\"code\":\"3\",\"value\":\"3-5 Cr.\"},{\"key\":6,\"code\":\"5\",\"value\":\"5-10 Cr.\"},{\"key\":7,\"code\":\"10\",\"value\":\"10-15 Cr.\"},{\"key\":8,\"code\":\"15\",\"value\":\"More than 15 Cr.\"}]} ",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getLookupByCode(Mockito.any())).thenReturn(lookupCall);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);

		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		creditBusinessHelper.populatePropertyBreRequestFromMcpDetails(new JSONObject(), mcpReq);
	}
	
	@Test
	public void testFormFullName() {
		assertEquals("Test Data",creditBusinessHelper.formFullName("Test", "", "Data"));
	}
	
	@Test
	public void testFormFullNameWithMiddleName() {
		assertEquals("First Middle Last",creditBusinessHelper.formFullName("First", "Middle", "Last"));
	}
	
	/*@Test
	public void testCreateEventMessage() {
		creditBusinessHelper.createEventMessage("EVENT_NAME", "EVENT_TYPE", new EventSchema(), new JSONObject(), new HashMap<String, String>());
	}
	
	@Test
	public void createEventMessageTest_BMR2() {
		creditBusinessHelper.createEventMessage("EVENT_NAME", "EVENT_TYPE", new EventSchema(), new JSONObject(), new HashMap<String, String>());
	}*/
	
	@Test
	public void testAddLinebreaks() {
		Assert.assertNotNull(creditBusinessHelper.addLinebreaks("Flat No. FF -1 \\, First Floor \\, Front Right Hand si Plot No.-1   209 \\, Sector- 1 \\,Vasundhara Ghaziabad", 50));
	}
	
	@Test
	public void testpopulateBreRequestFromMcpDetails_BMR2Exc() {
		JSONObject openArcInput = createOpenArcListingInput();
		openArcInput.put("applicationId", 1234);
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":1,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":69,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":\"software engineer\"},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":69},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":null,\"natureOfBusiness\":null,\"industryType\":null,\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":null},\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":null,\"averageBankBalance\":null,\"companyType\":{\"key\":1,\"code\":null,\"value\":null}},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"1\"},\"userProfile\":{\"applicationKey\":\"1100000000007316\",\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250004\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"Prathamesh\",\"middleName\":\"\",\"lastName\":\"Joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":2,\"genderKey\":21,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234H\",\"applicantKey\":122234},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[\"LENROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"1\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5367\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":100000}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);

		JSONObject panResp = g.fromJson(
				"{\"applicantKey\":\"122259\",\"forcedVerification\":false,\"applicationKey\":\"1100000000007332\",\"fullName\":\"null null JOSH\",\"nameRecieved\":\"null null JOSH\",\"panNumber\":\"ASWPJ1234H\",\"verification\":{\"isVerified\":true,\"verificationSource\":\"NSDL\",\"verifiedFor\":\"PAN\",\"verificationDate\":\"2020-06-26T06:00:52.207+0000\",\"verificationReference\":2263},\"nameMatch\":false}",
				JSONObject.class);
		
		JSONObject creditVidyaStatusResp = g.fromJson("{\"applicantKey\":null,\"city\":\"PUNE\",\"mobileNumber\":\"9909010002\",\"dob\":\"1990-12-03 00:00:00.0\",\"companyName\":null,\"applicationKey\":\"1100000000012440\",\"fullName\":\"abc xyz\",\"emailId\":\"abcd@cognizant.com\",\"validationstatus\":\"Medium Risk\",\"salary\":null,\"l2ProductKey\":\"10002\",\"verification\":null}",
				JSONObject.class);
		Mockito.when(apiCallsHelper.getPanVerification(Mockito.any(), Mockito.any())).thenReturn(panResp);

		ResidenceMaster resi = new ResidenceMaster();
		resi.setResidenceKey(1L);
		ResidenceMaster[] resiArr = new ResidenceMaster[1];
		resiArr[0] = resi;
		LocationResponseBean locationAddressBean = new LocationResponseBean();
		locationAddressBean.setPincode("411057");
		locationAddressBean.setCityName("PUNE");
		Mockito.when(apiCallsHelper.getAllResitypes()).thenReturn(resiArr);
		Mockito.when(apiCallsHelper.getBmr2ResponseFromMongo(Mockito.any())).thenThrow(new CreditBusinessException(HttpStatus.INTERNAL_SERVER_ERROR,null));
		Mockito.when(apiCallsHelper.getBmrDetails(Mockito.any())).thenReturn("{\"id\":7825,\"applicationKey\":1100000000009726,\"principalKey\":3,\"principleCustRefId\":null,\"additionalDetails\":{\"matchDetails\":null,\"approveFlag\":\"Y\",\"netSalary\":\"\",\"mandateDetails\":null,\"plLivePos\":\"\",\"errorFlag\":\"true\",\"loanFlags\":null,\"decisionFlags\":null,\"offerDetails\":null,\"pltbOffer\":null,\"customerType\":\"N\",\"bflLoanCount\":null,\"applicantId\":null,\"riskOfferType\":null,\"bflLoanDetails\":null,\"edwResponseTime\":\"\",\"applicationId\":null,\"bflPosDetails\":null,\"productType\":null,\"customerDetails\":null,\"timestamp\":null}}" );
		Mockito.when(apiCallsHelper.getCreditVidyaStatus(Mockito.any(), Mockito.any())).thenReturn(creditVidyaStatusResp);
		Mockito.when(apiCallsHelper.getEmployerMaster(Mockito.any())).thenReturn(new JSONObject());
		Mockito.when(apiCallsHelper.getPinCodeMaster(Mockito.any())).thenReturn(locationAddressBean);
		
		JSONObject incomeEstimation = new JSONObject();
		incomeEstimation.put("status", "COMPLETED");
		incomeEstimation.put("statementCollected", 3.0d);
		incomeEstimation.put("incomemputationKey", "1000");
		Mockito.when(apiCallsHelper.getIncomeEstimation(Mockito.anyString(),Mockito.anyString())).thenReturn(incomeEstimation);
		Mockito.when(apiCallsHelper.fetchIncomeEstimatedChannelJson(Mockito.anyString())).thenReturn("channel json");
		
		String industryType = "Automobiles";
		Mockito.when(apiCallsHelper.getIndustryType(Mockito.any())).thenReturn(industryType);
		
		ProductList productList = g.fromJson(
				"{\"productList\":[{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.0,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":2,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":\"BFLSOLHFL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.1,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":200000,\"tenor\":48},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":4,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":\"FICCLSOLTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":4.2,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":0.00000,\"feature\":\"\",\"rewardPoint\":null,\"promotionalOffer\":\"\",\"approvalChances\":null,\"cardTag\":null,\"isEligible\":0,\"priorityOrder\":4,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":\"BFLPLCSTL\",\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":\"apply now\",\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":300000,\"tenor\":36},{\"description\":\"Fullerton Personal loan - Business Owner\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"Fullerton Personal loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"FICCLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"FICCLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan Cross Sell\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPLCS\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPLCS\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Pocket Personal Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLPPL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLPPL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - C.A.\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLCAL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLCAL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Professional Loan - DOCTOR\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLDOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLDOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Business Loan\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLBOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLBOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null},{\"description\":\"BFL Personal Loan - Salaried\",\"annualFee\":null,\"feature\":null,\"rewardPoint\":null,\"promotionalOffer\":null,\"approvalChances\":null,\"cardTag\":null,\"isEligible\":1,\"priorityOrder\":null,\"productCode\":\"BFLSOL\",\"isSmallTicket\":null,\"l3productCode\":\"BFLSOL\",\"l4ProductCode\":null,\"productvariant\":null,\"roi\":null,\"emi\":null,\"bScore\":null,\"loanTag\":null,\"loanType\":null,\"fees\":null,\"totalFee\":null,\"productListingKey\":null,\"isSelected\":\"N\",\"ctaName\":null,\"toBeDisplayedOnListingPage\":null,\"usp\":null,\"requiredLoanAmount\":null,\"tenor\":null}],\"requiredLoanAmout\":null,\"requiredTenor\":null,\"maxEligibility\":null,\"maxTenor\":null,\"name\":null} ",
				ProductList.class);
		Mockito.when(apiCallsHelper.getProductListForApplication(Mockito.any())).thenReturn(productList);
		creditBusinessHelper.populateBreRequestFromMcpDetails(openArcInput, mcpReq, false, null, null, 1);
	}

	@Test
	public void testInvokeRestEndPoint_withoutParams() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(Object.class)))
				.thenReturn(new ResponseEntity(HttpStatus.OK));
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl("http://www.testingurl.com")
				.queryParam("test", 1);
		creditBusinessHelper.invokeRestEndPointWithOptionalParams(HttpMethod.GET, uriBuilder, Object.class, null, "", new HttpHeaders());
	}

	@Test(expected = CreditBusinessException.class)
	public void testInvokeRestEndPoint_ex1() {
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl("http://www.testingurl.com")
				.queryParam("test", 1);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class)))
				.thenThrow(new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "", err.getBytes(), null));
		creditBusinessHelper.invokeRestEndPointWithOptionalParams(HttpMethod.POST, uriBuilder, Object.class, null, "", new HttpHeaders());
	}

	@Test(expected = CreditBusinessException.class)
	public void testInvokeRestEndPoint_ex2() {
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl("http://www.testingurl.com")
				.queryParam("test", 1);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class)))
				.thenThrow(new HttpStatusCodeException(HttpStatus.INTERNAL_SERVER_ERROR, "", err.getBytes(), null) {
				});
		creditBusinessHelper.invokeRestEndPointWithOptionalParams(HttpMethod.POST, uriBuilder, Object.class, null, "", new HttpHeaders());
	}

	@Test(expected = CreditBusinessException.class)
	public void testInvokeRestEndPoint_ex3() {
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl("http://www.testingurl.com")
				.queryParam("test", 1);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class)))
				.thenThrow(new RestClientException(err, new Exception()));
		creditBusinessHelper.invokeRestEndPointWithOptionalParams(HttpMethod.POST, uriBuilder, Object.class, null, "", new HttpHeaders());
	}

	@Test(expected = CreditBusinessException.class)
	public void testInvokeRestEndPoint_ex4() {
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl("http://www.testingurl.com")
				.queryParam("test", 1);
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(Object.class))).thenReturn(null);
		creditBusinessHelper.invokeRestEndPointWithOptionalParams(HttpMethod.GET, uriBuilder, Object.class, null, "", new HttpHeaders());
	}


	@Test
	public void testsplitfullNameToFnameMnameLname() {
		Map<String, String> names = creditBusinessHelper.splitfullNameToFnameMnameLname("Koko Johan");
		assertEquals("Koko", names.get("firstName"));
		assertNull(names.get("middleName"));
		assertEquals("Johan", names.get("lastName"));
	}

	@Test
	public void testsplitfullNameToFnameMnameLname2() {
		Map<String, String> names = creditBusinessHelper.splitfullNameToFnameMnameLname("Koko Daniel Johan");
		assertEquals("Koko", names.get("firstName"));
		assertEquals("Daniel", names.get("middleName"));
		assertEquals("Johan", names.get("lastName"));
	}

	@Test
	public void testsplitfullNameToFnameMnameLname3() {
		Map<String, String> names = creditBusinessHelper.splitfullNameToFnameMnameLname("Koko Daniel Jack Johan");
		assertEquals("Koko", names.get("firstName"));
		assertEquals("Daniel Jack", names.get("middleName"));
		assertEquals("Johan", names.get("lastName"));
	}
	
	@Test
	public void testremoveNullFromGivenString() {
		Assert.assertNotNull(creditBusinessHelper.removeNullFromGivenString(" abcd XYZ albgfd"));
	}
	
	@Test
	public void testremoveNullFromGivenString_Null() {
		Assert.assertNull(creditBusinessHelper.removeNullFromGivenString(null));
	}

}
