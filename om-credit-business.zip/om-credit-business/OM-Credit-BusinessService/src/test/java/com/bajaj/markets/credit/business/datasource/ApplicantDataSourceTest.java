package com.bajaj.markets.credit.business.datasource;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApltBusinessDet;
import com.bajaj.markets.credit.business.beans.ApplicantAddressDetails;
import com.bajaj.markets.credit.business.beans.ApplicantBankDetail;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.ApplicantEmailDetails;
import com.bajaj.markets.credit.business.beans.ApplicantEmploymentDetail;
import com.bajaj.markets.credit.business.beans.ApplicantProfileDetails;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.LocationResponseBean;
import com.bajaj.markets.credit.business.beans.LookupCodeResponse;
import com.bajaj.markets.credit.business.beans.LookupCodeValuesResponseBean;
import com.bajaj.markets.credit.business.beans.NatureOfBusinessMaster;
import com.bajaj.markets.credit.business.beans.OfferApiRequest;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.google.gson.Gson;

@SpringBootConfiguration
@SpringBootTest
public class ApplicantDataSourceTest {

	@Mock
	CreditBusinessHelper creditBusinessHelper;

	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	BFLLoggerUtil loggerUtil;

	@Mock
	Environment env;
	
	@Mock
	LocationResponseBean locationResponseBean;
	
	@InjectMocks
	ApplicantDataSource applicantDataSource;
			
	private String cityUrl = "cityUrl";
	private String pinCodeUrl = "pinCodeUrl";
	private String getApplicantAddressUrl = "getApplicantAddressUrl";
	
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(applicantDataSource, "logger", logger);
		ReflectionTestUtils.setField(applicantDataSource, "env", env);
		ReflectionTestUtils.setField(applicantDataSource, "cityUrl" , cityUrl);
		ReflectionTestUtils.setField(applicantDataSource, "pinCodeUrl", pinCodeUrl);
		ReflectionTestUtils.setField(applicantDataSource, "getApplicantAddressUrl", getApplicantAddressUrl);
		
	}
	
	@Test
	public void registerDataSourceTest() {
		DataSourceRegistry dataSourceRegistry = Mockito.mock(DataSourceRegistry.class);
		applicantDataSource.registerDataSource(dataSourceRegistry);
	}
	
	@Test
	public void initDataSourceTest() {
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("0");
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataSource.initDataSource(applicantDataBean);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void initDataSourceTest_ELSE() {
		Gson g = new Gson();
		ApplicantProfileDetails applicantProfileDetails = g.fromJson(
				"{\"applicantKey\": 123431,\"apltDateOfBirth\": \"1983-08-20\",\"apltFirstName\": \"joint\",\"apltGrossMthIncome\": null,\"apltIsActive\": 1,\"apltLastName\": \"covid\",\"apltMiddleName\": null,\"apltNetMthIncome\": null,\"apltPAN\": \"AHGVC5647N\",\"apltStatus\": \"A\",\"genderKey\": 21,\"langKey\": null,\"maritalStatusKey\": 27,\"nationalityKey\": null,\"salutationKey\": null}",
				ApplicantProfileDetails.class);
		
		ApplicantEmailDetails[] applicantEmailDetails = g.fromJson(
				"[{\"apltEmailIdKey\": 157842,\"apltEmailAddress\": \"gvzf@gmail.com\",\"apltEmailEndDt\": \"1983-08-20\",\"apltEmailIdIsVerified\": 0,\"apltEmailIdPriority\": 1,\"apltEmailIsActive\": 1,\"apltEmailLstUpdateBy\": \"266657\",\"apltEmailLstUpdateDt\": \"1983-08-20\",\"apltEmailStartDt\": \"1983-08-20\",\"emailBounceFlag\": null,\"emailBounceDt\": null,\"apltEmailVerificationDt\": null,\"apltEmailVerificationSrc\": null,\"applicantKey\": 123431,\"emailTypeKey\": 70}]",
				ApplicantEmailDetails[].class);
		
		ApplicantAddressDetails[] applicantAddressDetails = g.fromJson(
				"[{\"apltAddrKey\": 11547867,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 50,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null},{\"apltAddrKey\": 11547868,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 48,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null}]",
				ApplicantAddressDetails[].class);
		
		ApplicantEmploymentDetail[] applicantEmploymentDetails = g.fromJson(
				"[{\"apltEmpDetEmpKey\": 55815,\"apltEmpDetCurrExp\": null,\"apltEmpDetDesignForOth\": \"AREA CREDIT MANAGER\",\"apltEmpDetEmpNameForOth\": null,\"apltEmpDetEndDate\": \"1983-08-20\",\"apltEmpDetIsActive\": 1,\"apltEmpDetLstUpdateBy\": \"121733\",\"apltEmpDetLstUpdateDt\": \"1983-08-20\",\"apltEmpDetEmploymentType\": null,\"apltEmpDetStartDate\": \"1983-08-20\",\"apltEmpDetTotalExp\": null,\"applicantKey\": 117559,\"emplrDesigKey\": null,\"emprMastId\": 11637}]",
				ApplicantEmploymentDetail[].class);
		
		ApltBusinessDet[] apltBusinessDets = g.fromJson(
				"[{\"apltBusiDetKey\": 23541,\"businessVintage\": 5,\"constitution\": 1,\"gstIn\": null,\"isActive\": 1,\"lstUpdatedBy\": \"265301\",\"lstUpdateDt\": \"1983-08-20\",\"nobKey\": 2,\"applicantKey\": 120189,\"subIndMastKey\": null,\"custIndMastKey\": 1}]",
				ApltBusinessDet[].class);
		
		ApplicantBankDetail[] applicantBankDetails = g.fromJson(
				"[{\"applicantBankDetKey\": 23725,\"apltBnkDetAccNum\": \"241342314\",\"apltBnkDetAccVerficationDt\": null,\"apltBnkDetAccVerficationSrc\": null,\"apltBnkDetAccVerficationSts\": 0,\"apltBnkDetEndDt\": null,\"apltBnkDetHolderName\": \"wer wer wer\",\"apltBnkDetLstUpdateBy\": \"266741\",\"apltBnkDetLstUpdateDt\": \"1983-08-20\",\"apltBnkDetStartDt\": null,\"apltBnkInfoSalaryAccFlag\": 0,\"apltBnkIsActive\": 1,\"mandateReqdFlg\": null,\"mandateReqFlgChngDt\": null,\"accTypKey\": 22,\"applicantKey\": 123596,\"branchKey\": 251687}]",
				ApplicantBankDetail[].class);
		
		List<NatureOfBusinessMaster> nobResponse = popNOB();
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(applicantProfileDetails, HttpStatus.NOT_FOUND), new ResponseEntity(applicantEmailDetails, HttpStatus.NOT_FOUND), new ResponseEntity(applicantAddressDetails, HttpStatus.NOT_FOUND), new ResponseEntity(applicantEmploymentDetails, HttpStatus.NOT_FOUND), new ResponseEntity(apltBusinessDets, HttpStatus.NOT_FOUND), new ResponseEntity(applicantBankDetails, HttpStatus.NOT_FOUND), new ResponseEntity(nobResponse, HttpStatus.NOT_FOUND));
				
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("0");

		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataSource.initDataSource(applicantDataBean);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void initDataSourceTest_SEMP() {
		Gson g = new Gson();
		ApplicantProfileDetails applicantProfileDetails = g.fromJson(
				"{\"applicantKey\": 123431,\"apltDateOfBirth\": \"1983-08-20\",\"apltFirstName\": \"joint\",\"apltGrossMthIncome\": null,\"apltIsActive\": 1,\"apltLastName\": \"covid\",\"apltMiddleName\": null,\"apltNetMthIncome\": null,\"apltPAN\": \"AHGVC5647N\",\"apltStatus\": \"A\",\"genderKey\": 21,\"langKey\": null,\"maritalStatusKey\": 27,\"nationalityKey\": null,\"salutationKey\": null}",
				ApplicantProfileDetails.class);
		
		ApplicantEmailDetails[] applicantEmailDetails = g.fromJson(
				"[{\"apltEmailIdKey\": 157842,\"apltEmailAddress\": \"gvzf@gmail.com\",\"apltEmailEndDt\": \"1983-08-20\",\"apltEmailIdIsVerified\": 0,\"apltEmailIdPriority\": 1,\"apltEmailIsActive\": 1,\"apltEmailLstUpdateBy\": \"266657\",\"apltEmailLstUpdateDt\": \"1983-08-20\",\"apltEmailStartDt\": \"1983-08-20\",\"emailBounceFlag\": null,\"emailBounceDt\": null,\"apltEmailVerificationDt\": null,\"apltEmailVerificationSrc\": null,\"applicantKey\": 123431,\"emailTypeKey\": 70}]",
				ApplicantEmailDetails[].class);
		
		ApplicantAddressDetails[] applicantAddressDetails = g.fromJson(
				"[{\"apltAddrKey\": 11547867,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 50,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null},{\"apltAddrKey\": 11547868,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 48,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null}]",
				ApplicantAddressDetails[].class);
		
		ApplicantEmploymentDetail[] applicantEmploymentDetails = g.fromJson(
				"[{\"apltEmpDetEmpKey\": 55815,\"apltEmpDetCurrExp\": null,\"apltEmpDetDesignForOth\": \"AREA CREDIT MANAGER\",\"apltEmpDetEmpNameForOth\": null,\"apltEmpDetEndDate\": \"1983-08-20\",\"apltEmpDetIsActive\": 1,\"apltEmpDetLstUpdateBy\": \"121733\",\"apltEmpDetLstUpdateDt\": \"1983-08-20\",\"apltEmpDetEmploymentType\": null,\"apltEmpDetStartDate\": \"1983-08-20\",\"apltEmpDetTotalExp\": null,\"applicantKey\": 117559,\"emplrDesigKey\": null,\"emprMastId\": 11637}]",
				ApplicantEmploymentDetail[].class);
		
		ApltBusinessDet[] apltBusinessDets = g.fromJson(
				"[{\"apltBusiDetKey\": 23541,\"businessVintage\": 5,\"constitution\": 1,\"gstIn\": null,\"isActive\": 1,\"lstUpdatedBy\": \"265301\",\"lstUpdateDt\": \"1983-08-20\",\"nobKey\": 2,\"applicantKey\": 120189,\"subIndMastKey\": null,\"custIndMastKey\": 1}]",
				ApltBusinessDet[].class);
		
		ApplicantBankDetail[] applicantBankDetails = g.fromJson(
				"[{\"applicantBankDetKey\": 23725,\"apltBnkDetAccNum\": \"241342314\",\"apltBnkDetAccVerficationDt\": null,\"apltBnkDetAccVerficationSrc\": null,\"apltBnkDetAccVerficationSts\": 0,\"apltBnkDetEndDt\": null,\"apltBnkDetHolderName\": \"wer wer wer\",\"apltBnkDetLstUpdateBy\": \"266741\",\"apltBnkDetLstUpdateDt\": \"1983-08-20\",\"apltBnkDetStartDt\": null,\"apltBnkInfoSalaryAccFlag\": 0,\"apltBnkIsActive\": 1,\"mandateReqdFlg\": null,\"mandateReqFlgChngDt\": null,\"accTypKey\": 22,\"applicantKey\": 123596,\"branchKey\": 251687}]",
				ApplicantBankDetail[].class);
		
		List<NatureOfBusinessMaster> nobResponse = popNOB();
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(applicantProfileDetails, HttpStatus.OK), new ResponseEntity(applicantEmailDetails, HttpStatus.OK), new ResponseEntity(applicantAddressDetails, HttpStatus.OK), new ResponseEntity(applicantEmploymentDetails, HttpStatus.OK), new ResponseEntity(apltBusinessDets, HttpStatus.OK), new ResponseEntity(applicantBankDetails, HttpStatus.OK), new ResponseEntity(nobResponse, HttpStatus.OK));
				
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("0");

		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataSource.initDataSource(applicantDataBean);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void initDataSourceTest_SEMP_exp() {
		Gson g = new Gson();
		ApplicantProfileDetails applicantProfileDetails = g.fromJson(
				"{\"applicantKey\": 123431,\"apltDateOfBirth\": \"1983-08-20\",\"apltFirstName\": \"joint\",\"apltGrossMthIncome\": null,\"apltIsActive\": 1,\"apltLastName\": \"covid\",\"apltMiddleName\": null,\"apltNetMthIncome\": null,\"apltPAN\": \"AHGVC5647N\",\"apltStatus\": \"A\",\"genderKey\": 21,\"langKey\": null,\"maritalStatusKey\": 27,\"nationalityKey\": null,\"salutationKey\": null}",
				ApplicantProfileDetails.class);
		
		ApplicantEmailDetails[] applicantEmailDetails = g.fromJson(
				"[{\"apltEmailIdKey\": 157842,\"apltEmailAddress\": \"gvzf@gmail.com\",\"apltEmailEndDt\": \"1983-08-20\",\"apltEmailIdIsVerified\": 0,\"apltEmailIdPriority\": 1,\"apltEmailIsActive\": 1,\"apltEmailLstUpdateBy\": \"266657\",\"apltEmailLstUpdateDt\": \"1983-08-20\",\"apltEmailStartDt\": \"1983-08-20\",\"emailBounceFlag\": null,\"emailBounceDt\": null,\"apltEmailVerificationDt\": null,\"apltEmailVerificationSrc\": null,\"applicantKey\": 123431,\"emailTypeKey\": 70}]",
				ApplicantEmailDetails[].class);
		
		ApplicantAddressDetails[] applicantAddressDetails = g.fromJson(
				"[{\"apltAddrKey\": 11547867,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 50,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null},{\"apltAddrKey\": 11547868,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 48,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null}]",
				ApplicantAddressDetails[].class);
		
		ApplicantEmploymentDetail[] applicantEmploymentDetails = g.fromJson(
				"[{\"apltEmpDetEmpKey\": 55815,\"apltEmpDetCurrExp\": null,\"apltEmpDetDesignForOth\": \"AREA CREDIT MANAGER\",\"apltEmpDetEmpNameForOth\": null,\"apltEmpDetEndDate\": \"1983-08-20\",\"apltEmpDetIsActive\": 1,\"apltEmpDetLstUpdateBy\": \"121733\",\"apltEmpDetLstUpdateDt\": \"1983-08-20\",\"apltEmpDetEmploymentType\": null,\"apltEmpDetStartDate\": \"1983-08-20\",\"apltEmpDetTotalExp\": null,\"applicantKey\": 117559,\"emplrDesigKey\": null,\"emprMastId\": 11637}]",
				ApplicantEmploymentDetail[].class);
		
		ApltBusinessDet[] apltBusinessDets = g.fromJson(
				"[{\"apltBusiDetKey\": 23541,\"businessVintage\": 5,\"constitution\": 1,\"gstIn\": null,\"isActive\": 1,\"lstUpdatedBy\": \"265301\",\"lstUpdateDt\": \"1983-08-20\",\"nobKey\": 2,\"applicantKey\": 120189,\"subIndMastKey\": null,\"custIndMastKey\": 1}]",
				ApltBusinessDet[].class);
		
		ApplicantBankDetail[] applicantBankDetails = g.fromJson(
				"[{\"applicantBankDetKey\": 23725,\"apltBnkDetAccNum\": \"241342314\",\"apltBnkDetAccVerficationDt\": null,\"apltBnkDetAccVerficationSrc\": null,\"apltBnkDetAccVerficationSts\": 0,\"apltBnkDetEndDt\": null,\"apltBnkDetHolderName\": \"wer wer wer\",\"apltBnkDetLstUpdateBy\": \"266741\",\"apltBnkDetLstUpdateDt\": \"1983-08-20\",\"apltBnkDetStartDt\": null,\"apltBnkInfoSalaryAccFlag\": 0,\"apltBnkIsActive\": 1,\"mandateReqdFlg\": null,\"mandateReqFlgChngDt\": null,\"accTypKey\": 22,\"applicantKey\": 123596,\"branchKey\": 251687}]",
				ApplicantBankDetail[].class);
		
		List<NatureOfBusinessMaster> nobResponse = popNOB();
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenThrow(CreditBusinessException.class);
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("0");

		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataSource.initDataSource(applicantDataBean);
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void initDataSourceTest_Doc() {
		Gson g = new Gson();
		ApplicantProfileDetails applicantProfileDetails = g.fromJson(
				"{\"applicantKey\": 123431,\"apltDateOfBirth\": \"1983-08-20\",\"apltFirstName\": \"joint\",\"apltGrossMthIncome\": null,\"apltIsActive\": 1,\"apltLastName\": \"covid\",\"apltMiddleName\": null,\"apltNetMthIncome\": null,\"apltPAN\": \"AHGVC5647N\",\"apltStatus\": \"A\",\"genderKey\": 21,\"langKey\": null,\"maritalStatusKey\": 27,\"nationalityKey\": null,\"salutationKey\": null}",
				ApplicantProfileDetails.class);
		
		ApplicantEmailDetails[] applicantEmailDetails = g.fromJson(
				"[{\"apltEmailIdKey\": 157842,\"apltEmailAddress\": \"gvzf@gmail.com\",\"apltEmailEndDt\": \"1983-08-20\",\"apltEmailIdIsVerified\": 0,\"apltEmailIdPriority\": 1,\"apltEmailIsActive\": 1,\"apltEmailLstUpdateBy\": \"266657\",\"apltEmailLstUpdateDt\": \"1983-08-20\",\"apltEmailStartDt\": \"1983-08-20\",\"emailBounceFlag\": null,\"emailBounceDt\": null,\"apltEmailVerificationDt\": null,\"apltEmailVerificationSrc\": null,\"applicantKey\": 123431,\"emailTypeKey\": 70}]",
				ApplicantEmailDetails[].class);
		
		ApplicantAddressDetails[] applicantAddressDetails = g.fromJson(
				"[{\"apltAddrKey\": 11547867,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 50,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null},{\"apltAddrKey\": 11547868,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 48,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null}]",
				ApplicantAddressDetails[].class);
		
		ApplicantEmploymentDetail[] applicantEmploymentDetails = g.fromJson(
				"[{\"apltEmpDetEmpKey\": 55815,\"apltEmpDetCurrExp\": null,\"apltEmpDetDesignForOth\": \"AREA CREDIT MANAGER\",\"apltEmpDetEmpNameForOth\": null,\"apltEmpDetEndDate\": \"1983-08-20\",\"apltEmpDetIsActive\": 1,\"apltEmpDetLstUpdateBy\": \"121733\",\"apltEmpDetLstUpdateDt\": \"1983-08-20\",\"apltEmpDetEmploymentType\": null,\"apltEmpDetStartDate\": \"1983-08-20\",\"apltEmpDetTotalExp\": null,\"applicantKey\": 117559,\"emplrDesigKey\": null,\"emprMastId\": 11637}]",
				ApplicantEmploymentDetail[].class);
		
		ApltBusinessDet[] apltBusinessDets = g.fromJson(
				"[{\"apltBusiDetKey\": 23541,\"businessVintage\": 5,\"constitution\": 1,\"gstIn\": null,\"isActive\": 1,\"lstUpdatedBy\": \"265301\",\"lstUpdateDt\": \"1983-08-20\",\"nobKey\": 2,\"applicantKey\": 120189,\"subIndMastKey\": null,\"custIndMastKey\": 1}]",
				ApltBusinessDet[].class);
		
		ApplicantBankDetail[] applicantBankDetails = g.fromJson(
				"[{\"applicantBankDetKey\": 23725,\"apltBnkDetAccNum\": \"241342314\",\"apltBnkDetAccVerficationDt\": null,\"apltBnkDetAccVerficationSrc\": null,\"apltBnkDetAccVerficationSts\": 0,\"apltBnkDetEndDt\": null,\"apltBnkDetHolderName\": \"wer wer wer\",\"apltBnkDetLstUpdateBy\": \"266741\",\"apltBnkDetLstUpdateDt\": \"1983-08-20\",\"apltBnkDetStartDt\": null,\"apltBnkInfoSalaryAccFlag\": 0,\"apltBnkIsActive\": 1,\"mandateReqdFlg\": null,\"mandateReqFlgChngDt\": null,\"accTypKey\": 22,\"applicantKey\": 123596,\"branchKey\": 251687}]",
				ApplicantBankDetail[].class);
		
		List<NatureOfBusinessMaster> nobResponse = popNOB();
		
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(applicantProfileDetails, HttpStatus.OK), new ResponseEntity(applicantEmailDetails, HttpStatus.OK), new ResponseEntity(applicantAddressDetails, HttpStatus.OK), new ResponseEntity(applicantEmploymentDetails, HttpStatus.OK), new ResponseEntity(apltBusinessDets, HttpStatus.OK), new ResponseEntity(applicantBankDetails, HttpStatus.OK), new ResponseEntity(nobResponse, HttpStatus.OK));
				
		Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("0");

		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DDOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		assertNotNull(applicantDataSource.initDataSource(applicantDataBean));
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void initDataSourceTest_SALR() {
		Gson g = new Gson();
		ApplicantProfileDetails applicantProfileDetails = g.fromJson(
				"{\"applicantKey\":129504,\"apltDateOfBirth\":\"1987-10-12\",\"apltGrossMthIncome\":null,\"apltIsActive\":1,\"apltNetMthIncome\":98000,\"apltPAN\":null,\"apltStatus\":\"A\",\"genderKey\":22,\"langKey\":null,\"maritalStatusKey\":27,\"nationalityKey\":null,\"salutationKey\":null,\"nameDetails\":{\"firstName\":\"Test\",\"middleName\":null,\"lastName\":\"Data\",\"verificationflg\":null,\"verificationsrc\":null},\"panDetails\":{\"panNumber\":\"ASDPF4567K\",\"verificationflg\":null,\"verificationsrc\":null},\"residenceTypeKey\":1}", 
				ApplicantProfileDetails.class);
		
		ApplicantEmailDetails[] applicantEmailDetails = g.fromJson(
				"[{\"apltEmailIdKey\": 157842,\"apltEmailAddress\": \"gvzf@gmail.com\",\"apltEmailEndDt\": \"1983-08-20\",\"apltEmailIdIsVerified\": 0,\"apltEmailIdPriority\": 1,\"apltEmailIsActive\": 1,\"apltEmailLstUpdateBy\": \"266657\",\"apltEmailLstUpdateDt\": \"1983-08-20\",\"apltEmailStartDt\": \"1983-08-20\",\"emailBounceFlag\": null,\"emailBounceDt\": null,\"apltEmailVerificationDt\": null,\"apltEmailVerificationSrc\": null,\"applicantKey\": 123431,\"emailTypeKey\": 70}]",
				ApplicantEmailDetails[].class);
		
		ApplicantAddressDetails[] applicantAddressDetails = g.fromJson(
				"[{\"apltAddrKey\": 11547867,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 50,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null},{\"apltAddrKey\": 11547868,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 48,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null}]",
				ApplicantAddressDetails[].class);
		
		ApplicantEmploymentDetail[] applicantEmploymentDetails = g.fromJson(
				"[{\"apltEmpDetEmpKey\":55815,\"apltEmpDetCurrExp\":60,\"apltEmpDetDesignForOth\":\"AREA CREDIT MANAGER\",\"apltEmpDetEmpNameForOth\":\"OTHER\",\"apltEmpDetEndDate\":\"1983-08-20\",\"apltEmpDetIsActive\":1,\"apltEmpDetLstUpdateBy\":\"121733\",\"apltEmpDetLstUpdateDt\":\"1983-08-20\",\"apltEmpDetEmploymentType\":null,\"apltEmpDetStartDate\":\"1983-08-20\",\"apltEmpDetTotalExp\":null,\"applicantKey\":117559,\"emplrDesigKey\":null,\"emprMastId\":11637,\"apltEmpDetEmployerType\":1}]",
				ApplicantEmploymentDetail[].class);
		
		ApltBusinessDet[] apltBusinessDets = g.fromJson(
				"[{\"apltBusiDetKey\": 23541,\"businessVintage\": 5,\"constitution\": 1,\"gstIn\": null,\"isActive\": 1,\"lstUpdatedBy\": \"265301\",\"lstUpdateDt\": \"1983-08-20\",\"nobKey\": 2,\"applicantKey\": 120189,\"subIndMastKey\": null,\"custIndMastKey\": 1}]",
				ApltBusinessDet[].class);
		
		ApplicantBankDetail[] applicantBankDetails = g.fromJson(
				"[{\"applicantBankDetKey\": 23725,\"apltBnkDetAccNum\": \"241342314\",\"apltBnkDetAccVerficationDt\": null,\"apltBnkDetAccVerficationSrc\": null,\"apltBnkDetAccVerficationSts\": 0,\"apltBnkDetEndDt\": null,\"apltBnkDetHolderName\": \"wer wer wer\",\"apltBnkDetLstUpdateBy\": \"266741\",\"apltBnkDetLstUpdateDt\": \"1983-08-20\",\"apltBnkDetStartDt\": null,\"apltBnkInfoSalaryAccFlag\": 0,\"apltBnkIsActive\": 1,\"mandateReqdFlg\": null,\"mandateReqFlgChngDt\": null,\"accTypKey\": 22,\"applicantKey\": 123596,\"branchKey\": 251687}]",
				ApplicantBankDetail[].class);
		
		LookupCodeResponse lookupCodeResponses = popLookupCodeVintage();
		List<NatureOfBusinessMaster> nobResponse = popNOB();
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getApplicantAddressUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new
		ResponseEntity(applicantAddressDetails, HttpStatus.OK));
	  
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(cityUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(applicantProfileDetails, HttpStatus.OK), new ResponseEntity(applicantEmailDetails, HttpStatus.OK), new ResponseEntity(applicantAddressDetails, HttpStatus.OK), new ResponseEntity(applicantEmploymentDetails, HttpStatus.OK), new ResponseEntity(apltBusinessDets, HttpStatus.OK), new ResponseEntity(applicantBankDetails, HttpStatus.OK), new ResponseEntity(lookupCodeResponses, HttpStatus.OK), new ResponseEntity(nobResponse, HttpStatus.OK));
		
		  Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(pinCodeUrl), Mockito.any(), Mockito.any(), Mockito.any(),
					Mockito.any())).thenReturn(new
		  ResponseEntity(locationResponseBean, HttpStatus.OK));
		   
		 Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("0");
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("SAL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataSource.initDataSource(applicantDataBean);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void initDataSourceTest_SALR_ecp() {
		Gson g = new Gson();
		ApplicantProfileDetails applicantProfileDetails = g.fromJson(
				"{\"applicantKey\":129504,\"apltDateOfBirth\":\"1987-10-12\",\"apltGrossMthIncome\":null,\"apltIsActive\":1,\"apltNetMthIncome\":98000,\"apltPAN\":null,\"apltStatus\":\"A\",\"genderKey\":22,\"langKey\":null,\"maritalStatusKey\":27,\"nationalityKey\":null,\"salutationKey\":null,\"nameDetails\":{\"firstName\":\"Test\",\"middleName\":null,\"lastName\":\"Data\",\"verificationflg\":null,\"verificationsrc\":null},\"panDetails\":{\"panNumber\":\"ASDPF4567K\",\"verificationflg\":null,\"verificationsrc\":null},\"residenceTypeKey\":1}", 
				ApplicantProfileDetails.class);
		
		ApplicantEmailDetails[] applicantEmailDetails = g.fromJson(
				"[{\"apltEmailIdKey\": 157842,\"apltEmailAddress\": \"gvzf@gmail.com\",\"apltEmailEndDt\": \"1983-08-20\",\"apltEmailIdIsVerified\": 0,\"apltEmailIdPriority\": 1,\"apltEmailIsActive\": 1,\"apltEmailLstUpdateBy\": \"266657\",\"apltEmailLstUpdateDt\": \"1983-08-20\",\"apltEmailStartDt\": \"1983-08-20\",\"emailBounceFlag\": null,\"emailBounceDt\": null,\"apltEmailVerificationDt\": null,\"apltEmailVerificationSrc\": null,\"applicantKey\": 123431,\"emailTypeKey\": 70}]",
				ApplicantEmailDetails[].class);
		
		ApplicantAddressDetails[] applicantAddressDetails = g.fromJson(
				"[{\"apltAddrKey\": 11547867,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 50,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null},{\"apltAddrKey\": 11547868,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 48,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null}]",
				ApplicantAddressDetails[].class);
		
		ApplicantEmploymentDetail[] applicantEmploymentDetails = g.fromJson(
				"[{\"apltEmpDetEmpKey\":55815,\"apltEmpDetCurrExp\":60,\"apltEmpDetDesignForOth\":\"AREA CREDIT MANAGER\",\"apltEmpDetEmpNameForOth\":\"OTHER\",\"apltEmpDetEndDate\":\"1983-08-20\",\"apltEmpDetIsActive\":1,\"apltEmpDetLstUpdateBy\":\"121733\",\"apltEmpDetLstUpdateDt\":\"1983-08-20\",\"apltEmpDetEmploymentType\":null,\"apltEmpDetStartDate\":\"1983-08-20\",\"apltEmpDetTotalExp\":null,\"applicantKey\":117559,\"emplrDesigKey\":null,\"emprMastId\":11637,\"apltEmpDetEmployerType\":1}]",
				ApplicantEmploymentDetail[].class);
		
		ApltBusinessDet[] apltBusinessDets = g.fromJson(
				"[{\"apltBusiDetKey\": 23541,\"businessVintage\": 5,\"constitution\": 1,\"gstIn\": null,\"isActive\": 1,\"lstUpdatedBy\": \"265301\",\"lstUpdateDt\": \"1983-08-20\",\"nobKey\": 2,\"applicantKey\": 120189,\"subIndMastKey\": null,\"custIndMastKey\": 1}]",
				ApltBusinessDet[].class);
		
		ApplicantBankDetail[] applicantBankDetails = g.fromJson(
				"[{\"applicantBankDetKey\": 23725,\"apltBnkDetAccNum\": \"241342314\",\"apltBnkDetAccVerficationDt\": null,\"apltBnkDetAccVerficationSrc\": null,\"apltBnkDetAccVerficationSts\": 0,\"apltBnkDetEndDt\": null,\"apltBnkDetHolderName\": \"wer wer wer\",\"apltBnkDetLstUpdateBy\": \"266741\",\"apltBnkDetLstUpdateDt\": \"1983-08-20\",\"apltBnkDetStartDt\": null,\"apltBnkInfoSalaryAccFlag\": 0,\"apltBnkIsActive\": 1,\"mandateReqdFlg\": null,\"mandateReqFlgChngDt\": null,\"accTypKey\": 22,\"applicantKey\": 123596,\"branchKey\": 251687}]",
				ApplicantBankDetail[].class);
		
		LookupCodeResponse lookupCodeResponses = popLookupCodeVintage();
		List<NatureOfBusinessMaster> nobResponse = popNOB();
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getApplicantAddressUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new
		ResponseEntity(applicantAddressDetails, HttpStatus.OK));
	  
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(cityUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(applicantProfileDetails, HttpStatus.OK), new ResponseEntity(applicantEmailDetails, HttpStatus.OK), new ResponseEntity(applicantAddressDetails, HttpStatus.OK), new ResponseEntity(applicantEmploymentDetails, HttpStatus.OK), new ResponseEntity(apltBusinessDets, HttpStatus.OK), new ResponseEntity(applicantBankDetails, HttpStatus.OK), new ResponseEntity(lookupCodeResponses, HttpStatus.OK), new ResponseEntity(nobResponse, HttpStatus.OK));
		
		  Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(pinCodeUrl), Mockito.any(), Mockito.any(), Mockito.any(),
					Mockito.any())).thenReturn(null);
		   
		 Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("0");
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("SAL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataSource.initDataSource(applicantDataBean);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void initDataSourceTest_CreditBsExp() {
		Gson g = new Gson();
		ApplicantProfileDetails applicantProfileDetails = g.fromJson(
				"{\"applicantKey\":129504,\"apltDateOfBirth\":\"1987-10-12\",\"apltGrossMthIncome\":null,\"apltIsActive\":1,\"apltNetMthIncome\":98000,\"apltPAN\":null,\"apltStatus\":\"A\",\"genderKey\":22,\"langKey\":null,\"maritalStatusKey\":27,\"nationalityKey\":null,\"salutationKey\":null,\"nameDetails\":{\"firstName\":\"Test\",\"middleName\":null,\"lastName\":\"Data\",\"verificationflg\":null,\"verificationsrc\":null},\"panDetails\":{\"panNumber\":\"ASDPF4567K\",\"verificationflg\":null,\"verificationsrc\":null},\"residenceTypeKey\":1}", 
				ApplicantProfileDetails.class);
		
		ApplicantEmailDetails[] applicantEmailDetails = g.fromJson(
				"[{\"apltEmailIdKey\": 157842,\"apltEmailAddress\": \"gvzf@gmail.com\",\"apltEmailEndDt\": \"1983-08-20\",\"apltEmailIdIsVerified\": 0,\"apltEmailIdPriority\": 1,\"apltEmailIsActive\": 1,\"apltEmailLstUpdateBy\": \"266657\",\"apltEmailLstUpdateDt\": \"1983-08-20\",\"apltEmailStartDt\": \"1983-08-20\",\"emailBounceFlag\": null,\"emailBounceDt\": null,\"apltEmailVerificationDt\": null,\"apltEmailVerificationSrc\": null,\"applicantKey\": 123431,\"emailTypeKey\": 70}]",
				ApplicantEmailDetails[].class);
		
		ApplicantAddressDetails[] applicantAddressDetails = g.fromJson(
				"[{\"apltAddrKey\": 11547867,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 50,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null},{\"apltAddrKey\": 11547868,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 48,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null}]",
				ApplicantAddressDetails[].class);
		
		ApplicantEmploymentDetail[] applicantEmploymentDetails = g.fromJson(
				"[{\"apltEmpDetEmpKey\":55815,\"apltEmpDetCurrExp\":60,\"apltEmpDetDesignForOth\":\"AREA CREDIT MANAGER\",\"apltEmpDetEmpNameForOth\":\"OTHER\",\"apltEmpDetEndDate\":\"1983-08-20\",\"apltEmpDetIsActive\":1,\"apltEmpDetLstUpdateBy\":\"121733\",\"apltEmpDetLstUpdateDt\":\"1983-08-20\",\"apltEmpDetEmploymentType\":null,\"apltEmpDetStartDate\":\"1983-08-20\",\"apltEmpDetTotalExp\":null,\"applicantKey\":117559,\"emplrDesigKey\":null,\"emprMastId\":11637,\"apltEmpDetEmployerType\":1}]",
				ApplicantEmploymentDetail[].class);
		
		ApltBusinessDet[] apltBusinessDets = g.fromJson(
				"[{\"apltBusiDetKey\": 23541,\"businessVintage\": 5,\"constitution\": 1,\"gstIn\": null,\"isActive\": 1,\"lstUpdatedBy\": \"265301\",\"lstUpdateDt\": \"1983-08-20\",\"nobKey\": 2,\"applicantKey\": 120189,\"subIndMastKey\": null,\"custIndMastKey\": 1}]",
				ApltBusinessDet[].class);
		
		ApplicantBankDetail[] applicantBankDetails = g.fromJson(
				"[{\"applicantBankDetKey\": 23725,\"apltBnkDetAccNum\": \"241342314\",\"apltBnkDetAccVerficationDt\": null,\"apltBnkDetAccVerficationSrc\": null,\"apltBnkDetAccVerficationSts\": 0,\"apltBnkDetEndDt\": null,\"apltBnkDetHolderName\": \"wer wer wer\",\"apltBnkDetLstUpdateBy\": \"266741\",\"apltBnkDetLstUpdateDt\": \"1983-08-20\",\"apltBnkDetStartDt\": null,\"apltBnkInfoSalaryAccFlag\": 0,\"apltBnkIsActive\": 1,\"mandateReqdFlg\": null,\"mandateReqFlgChngDt\": null,\"accTypKey\": 22,\"applicantKey\": 123596,\"branchKey\": 251687}]",
				ApplicantBankDetail[].class);
		
		LookupCodeResponse lookupCodeResponses = popLookupCodeVintage();
		List<NatureOfBusinessMaster> nobResponse = popNOB();
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getApplicantAddressUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new
		ResponseEntity(applicantAddressDetails, HttpStatus.OK));
	  
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(cityUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenThrow(CreditBusinessException.class);
		
		  Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(pinCodeUrl), Mockito.any(), Mockito.any(), Mockito.any(),
					Mockito.any())).thenReturn(new
		  ResponseEntity(locationResponseBean, HttpStatus.OK));
		   
		 Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("0");
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("SAL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataSource.initDataSource(applicantDataBean);
	}

	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void initDataSourceTest_Excp() {
		Gson g = new Gson();
		ApplicantProfileDetails applicantProfileDetails = g.fromJson(
				"{\"applicantKey\":129504,\"apltDateOfBirth\":\"1987-10-12\",\"apltGrossMthIncome\":null,\"apltIsActive\":1,\"apltNetMthIncome\":98000,\"apltPAN\":null,\"apltStatus\":\"A\",\"genderKey\":22,\"langKey\":null,\"maritalStatusKey\":27,\"nationalityKey\":null,\"salutationKey\":null,\"nameDetails\":{\"firstName\":\"Test\",\"middleName\":null,\"lastName\":\"Data\",\"verificationflg\":null,\"verificationsrc\":null},\"panDetails\":{\"panNumber\":\"ASDPF4567K\",\"verificationflg\":null,\"verificationsrc\":null},\"residenceTypeKey\":1}", 
				ApplicantProfileDetails.class);
		
		ApplicantEmailDetails[] applicantEmailDetails = g.fromJson(
				"[{\"apltEmailIdKey\": 157842,\"apltEmailAddress\": \"gvzf@gmail.com\",\"apltEmailEndDt\": \"1983-08-20\",\"apltEmailIdIsVerified\": 0,\"apltEmailIdPriority\": 1,\"apltEmailIsActive\": 1,\"apltEmailLstUpdateBy\": \"266657\",\"apltEmailLstUpdateDt\": \"1983-08-20\",\"apltEmailStartDt\": \"1983-08-20\",\"emailBounceFlag\": null,\"emailBounceDt\": null,\"apltEmailVerificationDt\": null,\"apltEmailVerificationSrc\": null,\"applicantKey\": 123431,\"emailTypeKey\": 70}]",
				ApplicantEmailDetails[].class);
		
		ApplicantAddressDetails[] applicantAddressDetails = g.fromJson(
				"[{\"apltAddrKey\": 11547867,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 50,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null},{\"apltAddrKey\": 11547868,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 48,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null}]",
				ApplicantAddressDetails[].class);
		
		ApplicantEmploymentDetail[] applicantEmploymentDetails = g.fromJson(
				"[{\"apltEmpDetEmpKey\":55815,\"apltEmpDetCurrExp\":60,\"apltEmpDetDesignForOth\":\"AREA CREDIT MANAGER\",\"apltEmpDetEmpNameForOth\":\"OTHER\",\"apltEmpDetEndDate\":\"1983-08-20\",\"apltEmpDetIsActive\":1,\"apltEmpDetLstUpdateBy\":\"121733\",\"apltEmpDetLstUpdateDt\":\"1983-08-20\",\"apltEmpDetEmploymentType\":null,\"apltEmpDetStartDate\":\"1983-08-20\",\"apltEmpDetTotalExp\":null,\"applicantKey\":117559,\"emplrDesigKey\":null,\"emprMastId\":11637,\"apltEmpDetEmployerType\":1}]",
				ApplicantEmploymentDetail[].class);
		
		ApltBusinessDet[] apltBusinessDets = g.fromJson(
				"[{\"apltBusiDetKey\": 23541,\"businessVintage\": 5,\"constitution\": 1,\"gstIn\": null,\"isActive\": 1,\"lstUpdatedBy\": \"265301\",\"lstUpdateDt\": \"1983-08-20\",\"nobKey\": 2,\"applicantKey\": 120189,\"subIndMastKey\": null,\"custIndMastKey\": 1}]",
				ApltBusinessDet[].class);
		
		ApplicantBankDetail[] applicantBankDetails = g.fromJson(
				"[{\"applicantBankDetKey\": 23725,\"apltBnkDetAccNum\": \"241342314\",\"apltBnkDetAccVerficationDt\": null,\"apltBnkDetAccVerficationSrc\": null,\"apltBnkDetAccVerficationSts\": 0,\"apltBnkDetEndDt\": null,\"apltBnkDetHolderName\": \"wer wer wer\",\"apltBnkDetLstUpdateBy\": \"266741\",\"apltBnkDetLstUpdateDt\": \"1983-08-20\",\"apltBnkDetStartDt\": null,\"apltBnkInfoSalaryAccFlag\": 0,\"apltBnkIsActive\": 1,\"mandateReqdFlg\": null,\"mandateReqFlgChngDt\": null,\"accTypKey\": 22,\"applicantKey\": 123596,\"branchKey\": 251687}]",
				ApplicantBankDetail[].class);
		
		LookupCodeResponse lookupCodeResponses = popLookupCodeVintage();
		List<NatureOfBusinessMaster> nobResponse = popNOB();
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getApplicantAddressUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new
		ResponseEntity(applicantAddressDetails, HttpStatus.OK));
	  
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(cityUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ResponseEntity(applicantProfileDetails, HttpStatus.OK), new ResponseEntity(applicantEmailDetails, HttpStatus.OK), new ResponseEntity(applicantAddressDetails, HttpStatus.OK), new ResponseEntity(applicantEmploymentDetails, HttpStatus.OK), new ResponseEntity(apltBusinessDets, HttpStatus.OK), new ResponseEntity(applicantBankDetails, HttpStatus.OK), new ResponseEntity(lookupCodeResponses, HttpStatus.OK), new ResponseEntity(nobResponse, HttpStatus.OK));
		
		  Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(pinCodeUrl), Mockito.any(), Mockito.any(), Mockito.any(),
					Mockito.any())).thenThrow(CreditBusinessException.class);;
		   
		 Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("0");
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("SAL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataSource.initDataSource(applicantDataBean);
	}
	@Test
	public void initDataSourceTest_nullCheck() {
		Gson g = new Gson();
		ApplicantProfileDetails applicantProfileDetails = g.fromJson(
				"{\"applicantKey\":129504,\"apltDateOfBirth\":\"1987-10-12\",\"apltGrossMthIncome\":null,\"apltIsActive\":1,\"apltNetMthIncome\":98000,\"apltPAN\":null,\"apltStatus\":\"A\",\"genderKey\":22,\"langKey\":null,\"maritalStatusKey\":27,\"nationalityKey\":null,\"salutationKey\":null,\"nameDetails\":{\"firstName\":\"Test\",\"middleName\":null,\"lastName\":\"Data\",\"verificationflg\":null,\"verificationsrc\":null},\"panDetails\":{\"panNumber\":\"ASDPF4567K\",\"verificationflg\":null,\"verificationsrc\":null},\"residenceTypeKey\":1}", 
				ApplicantProfileDetails.class);
		
		ApplicantEmailDetails[] applicantEmailDetails = g.fromJson(
				"[{\"apltEmailIdKey\": 157842,\"apltEmailAddress\": \"gvzf@gmail.com\",\"apltEmailEndDt\": \"1983-08-20\",\"apltEmailIdIsVerified\": 0,\"apltEmailIdPriority\": 1,\"apltEmailIsActive\": 1,\"apltEmailLstUpdateBy\": \"266657\",\"apltEmailLstUpdateDt\": \"1983-08-20\",\"apltEmailStartDt\": \"1983-08-20\",\"emailBounceFlag\": null,\"emailBounceDt\": null,\"apltEmailVerificationDt\": null,\"apltEmailVerificationSrc\": null,\"applicantKey\": 123431,\"emailTypeKey\": 70}]",
				ApplicantEmailDetails[].class);
		
		ApplicantAddressDetails[] applicantAddressDetails = g.fromJson(
				"[{\"apltAddrKey\": 11547867,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 50,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null},{\"apltAddrKey\": 11547868,\"apltAddrIsActive\": 1,\"apltAddrLstUpdateBy\": \"266657\",\"apltAddrLstUpdateDt\": \"1983-08-20\",\"apltAddrSrc\": null,\"apltAddReffStartDt\": \"1983-08-20\",\"addrTypKey\": 48,\"applicantKey\": 123431,\"pincodeKey\": 114392,\"apltAddrAddressLine1\": \"dgfjg mbjhj\",\"apltAddrAddressLine2\": null,\"apltAddrFlatNum\": null,\"apltAddrHouseNum\": null,\"apltAddrStreet\": null,\"countryKey\": \"91\",\"stateKey\": \"257\",\"cityKey\": \"1784\",\"localityKey\": null,\"locOGLFlg\": null,\"locNegativeAreaFlg\": null,\"occupancyType\": null}]",
				ApplicantAddressDetails[].class);
		
		ApplicantEmploymentDetail[] applicantEmploymentDetails = g.fromJson(
				"[{\"apltEmpDetEmpKey\":55815,\"apltEmpDetCurrExp\":60,\"apltEmpDetDesignForOth\":\"AREA CREDIT MANAGER\",\"apltEmpDetEmpNameForOth\":\"OTHER\",\"apltEmpDetEndDate\":\"1983-08-20\",\"apltEmpDetIsActive\":1,\"apltEmpDetLstUpdateBy\":\"121733\",\"apltEmpDetLstUpdateDt\":\"1983-08-20\",\"apltEmpDetEmploymentType\":null,\"apltEmpDetStartDate\":\"1983-08-20\",\"apltEmpDetTotalExp\":null,\"applicantKey\":117559,\"emplrDesigKey\":null,\"emprMastId\":11637,\"apltEmpDetEmployerType\":1}]",
				ApplicantEmploymentDetail[].class);
		
		ApltBusinessDet[] apltBusinessDets = g.fromJson(
				"[{\"apltBusiDetKey\": 23541,\"businessVintage\": 5,\"constitution\": 1,\"gstIn\": null,\"isActive\": 1,\"lstUpdatedBy\": \"265301\",\"lstUpdateDt\": \"1983-08-20\",\"nobKey\": 2,\"applicantKey\": 120189,\"subIndMastKey\": null,\"custIndMastKey\": 1}]",
				ApltBusinessDet[].class);
		
		ApplicantBankDetail[] applicantBankDetails = g.fromJson(
				"[{\"applicantBankDetKey\": 23725,\"apltBnkDetAccNum\": \"241342314\",\"apltBnkDetAccVerficationDt\": null,\"apltBnkDetAccVerficationSrc\": null,\"apltBnkDetAccVerficationSts\": 0,\"apltBnkDetEndDt\": null,\"apltBnkDetHolderName\": \"wer wer wer\",\"apltBnkDetLstUpdateBy\": \"266741\",\"apltBnkDetLstUpdateDt\": \"1983-08-20\",\"apltBnkDetStartDt\": null,\"apltBnkInfoSalaryAccFlag\": 0,\"apltBnkIsActive\": 1,\"mandateReqdFlg\": null,\"mandateReqFlgChngDt\": null,\"accTypKey\": 22,\"applicantKey\": 123596,\"branchKey\": 251687}]",
				ApplicantBankDetail[].class);
		
		LookupCodeResponse lookupCodeResponses = popLookupCodeVintage();
		List<NatureOfBusinessMaster> nobResponse = popNOB();
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(getApplicantAddressUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new
		ResponseEntity(applicantAddressDetails, HttpStatus.OK));
	  
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(cityUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(null);
		Mockito.when(creditBusinessHelper.invokeRestEndpoint(Mockito.any(), Mockito.eq(pinCodeUrl), Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new
	  ResponseEntity(locationResponseBean, HttpStatus.OK));
		   
		 Mockito.when(env.getProperty(Mockito.anyString())).thenReturn("0");
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("SAL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataSource.initDataSource(applicantDataBean);
	}
	
	private LookupCodeResponse popLookupCodeVintage() {
		LookupCodeResponse lookupCodeResponse = new LookupCodeResponse();
		List<LookupCodeValuesResponseBean> list = new ArrayList<>();
		LookupCodeValuesResponseBean codeValuesResponseBean = new LookupCodeValuesResponseBean();
		codeValuesResponseBean.setCode("BUSINESSVINTAGE");
		codeValuesResponseBean.setKey(5);
		codeValuesResponseBean.setValue("5");
		list.add(codeValuesResponseBean);
		lookupCodeResponse.setLookupValuesResponseList(list);
		return lookupCodeResponse;
	}
	
	private List<NatureOfBusinessMaster> popNOB() {
		List<NatureOfBusinessMaster> nob = new ArrayList<>();
		NatureOfBusinessMaster businessMaster = new NatureOfBusinessMaster();
		businessMaster.setNatureOfBusinessCode("2");
		businessMaster.setNatureOfBusinessValue("2");
		businessMaster.setNatureOfBusinessKey(1l);
		nob.add(businessMaster);
		return nob;
	}
}