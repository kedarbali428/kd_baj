package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PAN_NUMBER;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PINCODEBEAN;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.PINCODEKEY;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.USERPROFILEOUTPUT;

import java.util.concurrent.Executor;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.EmployerMasterBean;
import com.bajaj.markets.credit.business.beans.MaritalStatus;
import com.bajaj.markets.credit.business.beans.ResidenceMaster;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.EtbVariantEnum;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.WorkflowHelper;
import com.bajaj.markets.referencedataclientlib.bean.CacheServiceException;
import com.bajaj.markets.referencedataclientlib.bean.LocationResponseBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

@SpringBootTest
public class GinPreListingListenerTest {
	@Mock
	MasterDataRedisClientHelper redisHelper;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;

	@Mock
	CreditBusinessGinHelper ginHelper;

	@InjectMocks
	GinPreListingListener listener;

	@Mock
	WorkflowHelper workflowHelper;

	@Mock
	Executor customExecutor;
	
	@Mock
	CreditBusinessApiCallsHelper apiCallHelper;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testpersonalPanVerifyPre() {
		JSONObject userProfile = new JSONObject();
		userProfile.put(PAN_NUMBER, "ASWPJ1234J");
		Mockito.when(execution.getVariable(CreditBusinessConstants.USERPROFILEOUTPUT)).thenReturn(userProfile);
		listener.personalPanVerifyPre(execution);
	}

	@Test
	public void testpreAppScore() throws JsonMappingException, JsonProcessingException {
		JSONObject userProfile = new JSONObject();
		userProfile.put("maritalStatusKey", 1L);
		userProfile.put("residenceTypeKey", 1L);
		Mockito.when(execution.getVariable(USERPROFILEOUTPUT)).thenReturn(userProfile);
		Mockito.when(execution.getVariable(PINCODEBEAN)).thenReturn(new LocationResponseBean());
		Mockito.when(redisHelper.findResitypeByKey(Mockito.any())).thenReturn(new ResidenceMaster());
		Mockito.when(redisHelper.findMaritailStatusByKey(Mockito.any())).thenReturn(new MaritalStatus());
		listener.preAppScore(execution);
	}

	@Test
	public void testPostAppScore() {
		JSONObject appScoreResponse = new JSONObject();
		appScoreResponse.put(CreditBusinessConstants.FINALSCORE, 1234D);
		Mockito.when(execution.getVariable(GinPreListingListener.APPSCORE_TASKID.concat("_" + OUTPUT))).thenReturn(appScoreResponse);
		listener.postAppScore(execution);
	}

	@Test
	public void testPreDerog() {
		Mockito.when(execution.getVariable(PINCODEBEAN)).thenReturn(new LocationResponseBean());
		Mockito.when(execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE)).thenReturn(CreditBusinessConstants.PRODUCT_CODE_OMPL);
		listener.preDerog(execution);
	}

	@Test
	public void testPostDerog() {
		listener.postDerog(execution);
	}

	@Test
	public void testPreGetObligation() {
		Mockito.when(execution.getVariable(PINCODEBEAN)).thenReturn(new LocationResponseBean());
		listener.preGetObligation(execution);
	}

	@Test
	public void testPostGetObligation() {
		listener.postGetObligation(execution);
	}

	@Test
	public void testPreSaveObligation() {
		listener.preSaveObligation(execution);
	}

	@Test
	public void postGetAddress() {
		Mockito.when(execution.getVariable(OUTPUT)).thenReturn(new JSONObject());
		listener.postGetAddress(execution);
	}

	@Test
	public void testFetchPincodeBean() throws JsonMappingException, CacheServiceException, JsonProcessingException {
		Mockito.when(execution.getVariable(PINCODEKEY)).thenReturn("1234");
		Mockito.when(redisHelper.getPinCodeByKey(Mockito.any())).thenReturn(new LocationResponseBean());
		listener.fetchPincodeBean(execution);
	}

	@Test
	public void testFetchEmployerBean() throws JsonMappingException, CacheServiceException, JsonProcessingException {
		Mockito.when(execution.getVariable(CreditBusinessConstants.EMPLOYERID)).thenReturn("1234");
		EmployerMasterBean employer = new EmployerMasterBean();
		employer.setEmployerKid("acvb");
		Mockito.when(redisHelper.getEmployerByKey(Mockito.any())).thenReturn(employer);
		listener.fetchEmployerBean(execution);
	}

	@Test
	public void testcheckGinOffer_gin() throws JsonMappingException, CacheServiceException, JsonProcessingException {
		mockData();
		Mockito.when(ginHelper.checkEtbVariantFromAppOfferDet(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(EtbVariantEnum.GIN);
		listener.checkGinOffer(execution);
	}

	@Test
	public void testcheckGinOffer_nongin() throws JsonMappingException, CacheServiceException, JsonProcessingException {
		mockData();
		Mockito.when(ginHelper.checkEtbVariantFromAppOfferDet(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(EtbVariantEnum.NONGIN);
		listener.checkGinOffer(execution);
	}

	private void mockData() {
		JSONObject request = new JSONObject();
		JSONObject profession = new JSONObject();
		profession.put("key", 1);
		request.put("productCode", CreditBusinessConstants.PRODUCT_CODE_OMPL);
		request.put("profession", profession);

		Mockito.when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(request);
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn(1);
	}

	@Test
	public void testStartAnalyticsFlow() {
		listener.startAnalyticsFlow(execution);
	}

	@Test
	public void testcheckAnalyticsFlow() {
		listener.checkAnalyticsFlow(execution);
	}
	
	@Test
	public void testGinAddressUpdate() throws JsonProcessingException {
		Mockito.when(execution.getVariable(OUTPUT)).thenReturn(new JSONObject());
		listener.ginAddressUpdate(execution);
	}
	
	@Test
	public void testGetGinPersonalEmail() {
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("1111");
		listener.getGinPersonalEmail(execution);
	}

}
