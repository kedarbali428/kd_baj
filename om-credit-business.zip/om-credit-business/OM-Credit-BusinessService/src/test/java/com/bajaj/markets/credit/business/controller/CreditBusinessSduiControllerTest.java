package com.bajaj.markets.credit.business.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.service.CreditBusinessSduiService;

@AutoConfigureMockMvc
@WebMvcTest
public class CreditBusinessSduiControllerTest {
	
	@InjectMocks
	CreditBusinessSduiController creditBusinessSduiController;
	
	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CreditBusinessSduiService creditBusinessSduiService;

	@Mock
	CustomDefaultHeaders customHeader;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessSduiController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();
	}
	
	@Test
	public void testGetUserTask() throws Exception {
		mockMvc.perform(
				get("/v2/applications/{applicationkey}/userTask/{taskName}", "763456","nonGinEtbBasicDetails").contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testSaveUserTaskContent() throws Exception {
		String request = "{\"userTaskContent\":[{\"name\":\"Name\",\"content\":{\"text\":\"Sunaxi Pandey\"}},{\"name\":\"resiStatus\",\"content\":{\"text\":\"Other\",\"code\":\"OH\"}},{\"name\":\"pan\",\"content\":{\"text\":\"GTAPP9876N\"}},{\"name\":\"employerName\",\"content\":{\"text\":\"BAJAJ FINANCE LIMITED\",\"code\":\"68661\"}},{\"name\":\"salary\",\"content\":{\"text\":\"100000\"}}]}";
		mockMvc.perform(post("/v2/applications/{applicationkey}/userTask/{taskName}", "763456","nonGinEtbBasicDetails").contentType(MediaType.APPLICATION_JSON).content(request))
		.andExpect(status().isOk());
	}
	
}
