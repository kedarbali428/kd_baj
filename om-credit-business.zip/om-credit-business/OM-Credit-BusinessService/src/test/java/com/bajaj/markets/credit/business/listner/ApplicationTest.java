package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AdditionalDetailLoans;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.ChildApplication;
import com.bajaj.markets.credit.business.beans.EmployerMasterBean;
import com.bajaj.markets.credit.business.beans.LoanPurpose;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.RelatedPersonnelBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


@SpringBootTest
public class ApplicationTest {

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	Application listener;
	
	@Mock
	UpdateProfile updateProfile;
	
	@Mock
	McpCheck mcpCheck;
	
	@Mock
	CreditBusinessApiCallsHelper apiCallsHelper;

	@Mock
	CreditBusinessGinHelper ginHelper;
	
	@Mock
	MasterDataRedisClientHelper redisHelper;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testPostGetApplication() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new Object());
		JSONObject output = new JSONObject();
		output.put(CreditBusinessConstants.L2_PRODUCT_CODE, "CC");
		output.put(CreditBusinessConstants.L3_PRODUCT_CODE, "CCABNeon");
		when(CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT))).thenReturn(output);
		listener.postGetApplication(execution);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testPostGetApplication_testNull() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new Object());
		JSONObject output = new JSONObject();
		output.put(CreditBusinessConstants.L2_PRODUCT_CODE, null);
		output.put(CreditBusinessConstants.L3_PRODUCT_CODE, null);
		when(CreditBusinessHelper.getJSONObject(execution.getVariable(CreditBusinessConstants.OUTPUT))).thenReturn(output);
		listener.postGetApplication(execution);

	}

	@Test
	public void testPreCreateCardApplication() {
		when(execution.getVariable(any())).thenReturn(new ChildApplication());
		listener.preCreateCardApplication(execution);
	}

	@Test
	public void testPreCreateLoanApplication() {
		when(execution.getVariable(any())).thenReturn(new ChildApplication());
		listener.preCreateLoanApplication(execution);
	}

	@Test
	public void testPostCreateLoanApplication() {
		Gson g = new Gson();
		Object json = g.fromJson(
				"{\"applicationKey\":\"1100000000001676\",\"parentApplicationKey\":\"1100000000001675\",\"mobile\":null,\"dateOfBirth\":null,\"applicantKey\":null,\"l3ProductKey\":null,\"l3ProductCode\":\"BFLSOL\",\"l2ProductKey\":10002,\"l2ProductCode\":\"OMPL\",\"l4ProductKey\":null,\"l4ProductCode\":null,\"productListingKey\":\"1775\"} ",
				JSONObject.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(json);
		listener.postCreateLoanApplication(execution);
	}
	
	@Test
	public void testPostGetResidenceType() {
		String residenceTypeKey ="1234";
		ArrayList<?> residenceTypes = new ArrayList<>();
		when(execution.getVariable(any())).thenReturn(residenceTypeKey);
		when(execution.getVariable(any())).thenReturn(residenceTypes);
		listener.postGetResidenceType(execution);
	}

	@Test
	public void testPostGetLoanPricing() {
		Gson g = new GsonBuilder().serializeNulls().create();
		List output = g.fromJson(
				"[{\"appLoanPricingKey\":\"1934\",\"applicationKey\":\"1100000000006221\",\"prodCategoryCode\":\"OMPL\",\"isTenure\":0,\"droplineTenure\":48,\"emiAmount\":2778.0,\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20.0,\"firstDueDate\":\"2020-10-02\",\"dueDay\":2,\"graceTerm\":null,\"nextDueDate\":null,\"roi\":14.6,\"isEmi\":null,\"droplineEmi\":null,\"pennantLoanType\":\"SOLTL\",\"netDisbursementAmount\":null,\"loanAmount\":100000.0,\"fees\":[{\"feesKey\":18852,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":1200.0,\"feeCode\":\"CONV\"},{\"feesKey\":18851,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"STAMPFEE\"},{\"feesKey\":18850,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"PROCFEE\"}],\"loanType\":\"BFLSOLTL\",\"isBpiApplicable\":\"Yes\",\"roiWithBundle\":14.25,\"roiWithoutBundle\":14.6,\"finalLoanAmount\":104463.0,\"loanAmmountWithBundle\":104463.0,\"loanAmmountWithoutBundle\":100000.0,\"pricingStatus\":\"APPROVED\",\"raisedBy\":0,\"fppSelected\":false,\"source\":\"JOURNEY\",\"bundlePrice\":null,\"approval\":{\"approvalStatus\":\"APPROVED\",\"approvedBy\":0,\"raisedBy\":0}}] ",
				ArrayList.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		listener.postGetLoanPricing(execution);
	}

	@Test
	public void testPostGetRepaymentSchedule() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new HashMap<>());
		when(execution.getVariable(CreditBusinessConstants.IS_EP_PRICING_APPROVED)).thenReturn(true);
		listener.postGetRepaymentSchedule(execution);
	}
	
	@Test
	public void testPostGetRepaymentSchedule_JrnyPricing() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new HashMap<>());
		when(execution.getVariable(CreditBusinessConstants.IS_EP_PRICING_APPROVED)).thenReturn(false);
		listener.postGetRepaymentSchedule(execution);
	}

	@Test
	public void testPostCreateCardApplication() {
		Gson g = new Gson();
		Object json = g.fromJson("{\r\n" + "    \"l3ProductCode\": \"CCABNeon\",\r\n" + "    \"l2ProductCode\": \"CC\",\r\n"
				+ "    \"parentApplicationKey\": \"1100000000001000\",\r\n" + "    \"applicationKey\": \"1100000000001026\",\r\n"
				+ "    \"l2ProductKey\": 10001\r\n" + "  }", JSONObject.class);
		when(execution.getVariable(any())).thenReturn(json);
		listener.postCreateCardApplication(execution);
	}

	@Test
	public void testPostGetApplicationForPrinciple() {
		Gson g = new Gson();
		Object json = g.fromJson("{\r\n" + "    \"l3ProductCode\": \"CCABNeon\",\r\n" + "    \"l2ProductCode\": \"CC\",\r\n"
				+ "    \"parentApplicationKey\": \"1100000000001000\",\r\n" + "    \"applicationKey\": \"1100000000001026\",\r\n"
				+ "    \"l2ProductKey\": 10001\r\n" + "  }", JSONObject.class);
		when(execution.getVariable(any())).thenReturn(json);
		listener.postGetApplicationForPrinciple(execution);
	}

	@Test
	public void testPostGetApplicationForResume() {
		Gson g = new Gson();
		Object json = g.fromJson("{\r\n" + "  \"applicantKey\": \"string\",\r\n" + "  \"applicationKey\": \"string\",\r\n" + "  \"applicationStatus\": 0,\r\n"
				+ "  \"dateofbirth\": \"string\",\r\n" + "  \"inProcessing\": true,\r\n" + "  \"l2ProductCode\": \"string\",\r\n" + "  \"l2ProductKey\": 0,\r\n"
				+ "  \"l3ProductCode\": \"string\",\r\n" + "  \"l3ProductKey\": 0,\r\n" + "  \"l4ProductCode\": \"string\",\r\n" + "  \"l4ProductKey\": 0,\r\n"
				+ "  \"mobile\": \"string\",\r\n" + "  \"parentApplicationKey\": \"string\",\r\n" + "  \"principalKey\": 0\r\n" + "}", JSONObject.class);
		when(execution.getVariable(any())).thenReturn(json);
		listener.postGetApplicationForResume(execution);
	}

	@Test
	public void testPostGetChildApplications() {
		List<ApplicationDetail> applicationDetails = new ArrayList<>();
		ApplicationDetail applicationDetail = new ApplicationDetail();
		applicationDetail.setApplicationKey("1234");
		applicationDetail.setL2ProductCode("CC");
		applicationDetail.setL2ProductKey(123l);
		applicationDetail.setL3ProductCode("CC");
		applicationDetail.setParentApplicationKey("1234");
		applicationDetail.setL3ProductKey(123l);
		applicationDetail.setPrincipalKey(123l);
		applicationDetails.add(applicationDetail);
		when(execution.getVariable(any())).thenReturn(applicationDetails);
		listener.postGetChildApplications(execution);
	}

	@Test
	public void testPostGetProfession() {
		Gson g = new Gson();
		Object response = g.fromJson(
				"{\"ocupationType\":{\"key\":1,\"code\":\"SALR\",\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":69,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":null},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":1},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":{\"key\":null,\"code\":null,\"value\":null},\"natureOfBusiness\":{\"key\":null,\"code\":null,\"value\":null},\"industryType\":{\"key\":null,\"code\":null,\"value\":null},\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":null,\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":null,\"profitAfterTax\":null,\"averageBankBalance\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":null}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(response);
		listener.postGetProfession(execution);
	}
	
	@Test
	public void testPostGetProfession_DOC_SEMP() {
		Gson g = new Gson();
		Object response = g.fromJson(
				"{\"ocupationType\":{\"key\":1,\"code\":\"DOCSEMP\",\"value\":null},\"salariedDetail\":{\"employerName\":{\"key\":69,\"code\":null,\"value\":null},\"employerNameOther\":null,\"designation\":{\"key\":null,\"code\":null,\"value\":null},\"experience\":\"130\",\"netSalary\":\"100000\",\"employerType\":1},\"businessOwnerDetails\":{\"businessName\":null,\"businessType\":{\"key\":null,\"code\":null,\"value\":null},\"natureOfBusiness\":{\"key\":null,\"code\":null,\"value\":null},\"industryType\":{\"key\":null,\"code\":null,\"value\":null},\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":null},\"netMonthlyIncome\":null,\"businessVintage\":null,\"proprieterName\":null,\"businessPan\":null,\"gstNumber\":null,\"subindumastkey\":null,\"profitAfterTax\":null,\"averageBankBalance\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":null}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(response);
		listener.postGetProfession(execution);
	}
	@Test
	public void testpostGetEmployer() {
		Gson g = new Gson();
		JSONObject json = g.fromJson(
				"{\"emprMasterId\":11646,\"emprMasterName\":\"BAJAJ FINSERV LTD\",\"emprMastEstablishmentDate\":\"-0001-12-31T18:30:00.000+0000\",\"emprMastClassCode\":null,\"emprMastHouseNumber\":null,\"emprMastFlatNumber\":null,\"emprMastAddStreet\":null,\"emprMastAddLine1\":null,\"emprMastAddLine2\":null,\"emprMastPostboxNumber\":null,\"countryKey\":null,\"stateKey\":null,\"cityKey\":null,\"pincodeKey\":null,\"emprMasterPhone\":null,\"emprMasterFax\":null,\"emprMasttelexno\":null,\"emprMastEmailAddress\":null,\"emprMastContactPersonName\":null,\"emprMastContactPersonNumber\":null,\"emprMastAllocationType\":null,\"indMastKey\":473,\"emprMastCorpidNo\":\"L65923PN2007PLC130075\",\"emprMastStatus\":null,\"emprMastRegState\":null,\"emprMastClass\":null,\"emprMastRegofComp\":null,\"emprMastPrincipalBusActivity\":\"Non IT\",\"emprMastEmailDomains\":null,\"emprWeightage\":4.944,\"emprMastCategory\":\"Listed\",\"emprMastSubcategory\":\"Diamond\",\"employerTypeKey\":null,\"employerKid\":\"L65923PN2007PLC130075\",\"isActive\":1} ",
				JSONObject.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(json);
		listener.postGetEmployer(execution);
	}

	@Test
	public void testpreGetEmail() {
		Gson g = new Gson();
		Object json = g.fromJson(
				"[{\"emailKey\":61,\"emailCode\":\"COBOR1\",\"isactive\":1},{\"emailKey\":62,\"emailCode\":\"COBOR2\",\"isactive\":1},{\"emailKey\":63,\"emailCode\":\"COMM\",\"isactive\":1},{\"emailKey\":64,\"emailCode\":\"GUARDIAN\",\"isactive\":1},{\"emailKey\":65,\"emailCode\":\"HUSBAND\",\"isactive\":1},{\"emailKey\":66,\"emailCode\":\"NOMINEE\",\"isactive\":1},{\"emailKey\":67,\"emailCode\":\"OFFICE\",\"isactive\":1},{\"emailKey\":68,\"emailCode\":\"OTHER\",\"isactive\":1},{\"emailKey\":69,\"emailCode\":\"PARENT\",\"isactive\":1},{\"emailKey\":70,\"emailCode\":\"PERSON1\",\"isactive\":1},{\"emailKey\":72,\"emailCode\":\"WIFE\",\"isactive\":1},{\"emailKey\":74,\"emailCode\":\"AUTH\",\"isactive\":1},{\"emailKey\":75,\"emailCode\":\"CORP\",\"isactive\":1}] ",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.EMAILTYPE_LIST)).thenReturn(json);
		listener.preGetEmail(execution);
	}

	@Test
	public void testpreUpdateWorkEmail() {
		Gson g = new Gson();
		when(execution.getVariable(CreditBusinessConstants.KARZA_VERIFICATION_RESPONSE)).thenReturn(new Object());
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new Object());
		listener.preUpdateWorkEmail(execution);
	}
	
	@Test
	public void testPostGetEmail() {
		Gson g = new Gson();
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new Object());
		listener.postGetEmail(execution);
	}
	
	@Test
	public void testPreUpdateLoanPurpose() {
		AdditionalDetailLoans additionalDetails = new AdditionalDetailLoans();
		LoanPurpose loanPurpose = new LoanPurpose();
		loanPurpose.setKey(1l);
		loanPurpose.setCode("CODE");
		loanPurpose.setPurposeValue("PURPOSE");
		additionalDetails.setLoanPurpose(loanPurpose);
		
		Gson gson = new Gson();
		String additionalDetailsJson = gson.toJson(additionalDetails);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(additionalDetailsJson);
		listener.preUpdateLoanPurpose(execution);
	}
	
	@Test
	public void testPostGetParentApplicationStatus() {
		JSONObject statusResponse = new JSONObject();
		statusResponse.put("statusValue", "AIP");
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(statusResponse);
		
		listener.postGetParentApplicationStatus(execution);
	}
	
	@Test
	public void testSetTakeBackToListingAction() {
		when(execution.getVariable(Mockito.anyString())).thenReturn(null);
		listener.setTakeBackToListingAction(execution);
	}
	
	@Test
	public void testPostGetInProgressChildApplication() {
		String childApplication = "{\r\n" + "  \"applicantKey\": \"string\",\r\n" + "  \"applicationKey\": \"string\",\r\n" + "  \"applicationStatus\": 0,\r\n"
				+ "  \"dateofbirth\": \"string\",\r\n" + "  \"inProcessing\": true,\r\n" + "  \"l2ProductCode\": \"string\",\r\n" + "  \"l2ProductKey\": 0,\r\n"
				+ "  \"l3ProductCode\": \"string\",\r\n" + "  \"l3ProductKey\": 0,\r\n" + "  \"l4ProductCode\": \"string\",\r\n" + "  \"l4ProductKey\": 0,\r\n"
				+ "  \"mobile\": \"string\",\r\n" + "  \"parentApplicationKey\": \"string\",\r\n" + "  \"principalKey\": 0\r\n" + "}";
		List<Object> childApplications = new ArrayList<Object>();
		childApplications.add(childApplication);
		when(execution.getVariable(any())).thenReturn(childApplications);
		listener.postGetInProgressChildApplication(execution);
	}
	
	@Test
	public void testPostGetInProgressChildApplication_NullData() {
		String childApplication = "[]";
		List<Object> childApplications = new ArrayList<Object>();
		childApplications.add(childApplication);
		when(execution.getVariable(any())).thenReturn(childApplications);
		listener.postGetInProgressChildApplication(execution);
	}
	
	@Test
	public void testPostGetSecuredLoanPricing() {
		Gson g = new GsonBuilder().serializeNulls().create();
		List output = g.fromJson(
				"[{\"appLoanPricingKey\":\"1934\",\"applicationKey\":\"1100000000006221\",\"prodCategoryCode\":\"OMSL\",\"isTenure\":0,\"droplineTenure\":48,\"emiAmount\":2778.0,\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20.0,\"firstDueDate\":\"2020-10-02\",\"dueDay\":2,\"graceTerm\":null,\"nextDueDate\":null,\"roi\":14.6,\"isEmi\":null,\"droplineEmi\":null,\"pennantLoanType\":\"SOLTL\",\"netDisbursementAmount\":null,\"loanAmount\":100000.0,\"fees\":[{\"feesKey\":18852,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":1200.0,\"feeCode\":\"CONV\"},{\"feesKey\":18851,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"STAMPFEE\"},{\"feesKey\":18850,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"PROCFEE\"}],\"loanType\":\"BFLSOLTL\",\"isBpiApplicable\":\"Yes\",\"roiWithBundle\":14.25,\"roiWithoutBundle\":14.6,\"finalLoanAmount\":104463.0,\"loanAmmountWithBundle\":104463.0,\"loanAmmountWithoutBundle\":100000.0,\"pricingStatus\":\"APPROVED\",\"raisedBy\":0,\"fppSelected\":false,\"source\":\"JOURNEY\",\"bundlePrice\":null,\"approval\":{\"approvalStatus\":\"APPROVED\",\"approvedBy\":0,\"raisedBy\":0}}] ",
				ArrayList.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		listener.postGetSecuredLoanPricing(execution);
	}
	
	@Test
	public void testRemoveRequestPayload() {
		listener.removeRequestPayload(execution);
	}
	
	@Test
	public void testPreGetURMs() {
		listener.preGetUTMs(execution);
	}
	
	@Test
	public void testPostGetUTMs() {
		Gson g = new GsonBuilder().serializeNulls().create();
		List output = g.fromJson(
				"[{\"apputmparamkey\":30556,\"applicationkey\":1100000000024856,\"createdt\":\"2020-09-18T10:33:48.994+0000\",\"gclid\":null,\"isactive\":1,\"lstupdateby\":123,\"lstupdatedt\":\"2020-09-18T10:33:48.993+0000\",\"recversion\":1,\"sourcingchannel\":\"745\",\"utmcampaign\":\"utmcapaign\",\"utmcontent\":\"utmcontent\",\"utmmedium\":\"utmmedium\",\"utmreferralcode\":null,\"utmsource\":\"Organic_markets\",\"utmterm\":\"utmterm\",\"event\":\"PARENT CREATED\"}]",
				ArrayList.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		listener.postGetUTMs(execution);
	}
	
	@Test
	public void testPostGetUTMs_NullUtms() {
		Gson g = new GsonBuilder().serializeNulls().create();
		List output = g.fromJson(
				"[{\"apputmparamkey\":30556,\"applicationkey\":1100000000024856,\"createdt\":\"2020-09-18T10:33:48.994+0000\",\"gclid\":null,\"isactive\":1,\"lstupdateby\":123,\"lstupdatedt\":\"2020-09-18T10:33:48.993+0000\",\"recversion\":1,\"sourcingchannel\":\"745\",\"utmcampaign\":null,\"utmcontent\":null,\"utmmedium\":null,\"utmreferralcode\":null,\"utmsource\":null,\"utmterm\":null,\"event\":\"PARENT CREATED\"}]",
				ArrayList.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		listener.postGetUTMs(execution);
	}
	
	@Test
	public void testPostGetAddress() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new Object());
		listener.postGetAddress(execution);
	}
	
	@Test
	public void testPostGetDocumentPushStatus() {
		Gson g = new GsonBuilder().serializeNulls().create();
		List output = g.fromJson("[{\"creditdoctype\":2,\"docsentstatus\":\"Success\",\"docsentdate\":\"2020-11-04T12:06:19.369+0000\",\"docsentby\":41503,\"docerrorcode\":null,\"docerrordesc\":null,\"docerrordt\":null,\"partnerrefid\":\"622175\",\"docsource\":\"EP\"}]", ArrayList.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		listener.postGetDocumentPushStatus(execution);
	}
	
	@Test
	public void testPreDocumentSynchWithChildApp() {
		when(execution.getVariable(Mockito.anyString())).thenReturn("1234").thenReturn("1234").thenReturn("3");
		listener.preDocumentSynchWithChildApp(execution);
	}
	
	@Test
	public void testPostGetDocumentPushStatus_statusNull() {
		Gson g = new GsonBuilder().serializeNulls().create();
		List output = g.fromJson("[{\"creditdoctype\":2,\"docsentstatus\":null,\"docsentdate\":\"2020-11-04T12:06:19.369+0000\",\"docsentby\":41503,\"docerrorcode\":null,\"docerrordesc\":null,\"docerrordt\":null,\"partnerrefid\":\"622175\",\"docsource\":\"EP\"}]", ArrayList.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		listener.postGetDocumentPushStatus(execution);
	}
	
	@Test
	public void testPostGetDocumentPushStatus_Null() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new ArrayList());
		listener.postGetDocumentPushStatus(execution);
	}
	
	@Test
	public void testPostGetDocumentPushStatus_ResponseNull() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(null);
		listener.postGetDocumentPushStatus(execution);
	}
	
	@Test
	public void testPreDocumentPush() {
		when(execution.getVariable(CreditBusinessConstants.PRINCIPALKEY)).thenReturn("14");
		listener.preDocumentPush(execution);
	}
	
	@Test
	public void testPreOffersFetch() {
		listener.preOffersFetch(execution);
	}
	
	@Test
	public void testPostOfferFetch_ExceptionArise() {
		when(execution.getVariable(API_EXCEPTION_ARISE)).thenReturn(true);
		listener.postOffersFetch(execution);
	}
	
	@Test
	public void testPostOfferFetch() {
		Gson g = new GsonBuilder().serializeNulls().create();
		List output = g.fromJson(
				"[{\"appOfferDetKey\":0,\"appattrbkey\":0,\"applicationKey\":0,\"deactivateOffers\":true,\"generationRule\":\"string\",\"isBaseRate\":0,\"isCardHolder\":\"string\",\"isOfferAvailable\":true,\"lineAvailedFlg\":true,\"offerAcceptDt\":\"2020-12-30T11:29:02.590Z\",\"offerAcceptsts\":0,\"offerAmt\":0,\"offerAppliedDt\":\"2020-12-30T11:29:02.590Z\",\"offerCustomerId\":\"string\",\"offerExpiryDt\":\"2020-12-30T11:29:02.590Z\",\"offerGenerationSource\":\"string\",\"offerId\":\"string\",\"offerProcessingFees\":0,\"offerProgramCode\":\"string\",\"offerRoi\":0,\"offerSrcKey\":3,\"offerStartDt\":\"2020-12-30T11:29:02.590Z\",\"offerTenure\":0,\"offerType\":0,\"offerTypeCode\":\"string\",\"partnerOfferId\":\"string\",\"principalKey\":0,\"productCode\":\"string\",\"prospectId\":\"string\",\"riskClassification\":\"string\",\"riskOfferType\":\"string\",\"riskSegment\":\"string\",\"tlBaseRate\":0}]",
				ArrayList.class);
		
		when(execution.getVariable(API_EXCEPTION_ARISE)).thenReturn(null);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		
		listener.postOffersFetch(execution);
	}
	
	@Test
	public void testPreUpdateRelatedPersonnel() {
		AdditionalDetailLoans additionalDetails = new AdditionalDetailLoans();
		List<RelatedPersonnelBean> relatedPersonnelDetails = new ArrayList<>();
		RelatedPersonnelBean relatedPersonnelBean = new RelatedPersonnelBean();
		relatedPersonnelBean.setFullName("name full");
		relatedPersonnelBean.setMobileNumber("8765645678");
		relatedPersonnelBean.setRelationship(new Reference(1L, "1", "SON" ));
		relatedPersonnelDetails.add(relatedPersonnelBean);
		additionalDetails.setRelatedPersonnelDetails(relatedPersonnelDetails );
		
		Gson gson = new Gson();
		String additionalDetailsJson = gson.toJson(additionalDetails);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(additionalDetailsJson);
		listener.preUpdateRelatedPersonnel(execution);
	}
	
	@Test
	public void testPostGetPersonalEmail() {
		Gson g = new Gson();
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new Object());
		listener.postGetPersonalEmail(execution);
	}
	
	@Test
	public void testGetEmployer() throws JsonProcessingException {
		listener.getEmployer(execution);
	}
	
	@Test
	public void testGetEmployer1() throws JsonProcessingException {
		Mockito.when(execution.getVariable(CreditBusinessConstants.EMPLOYERID)).thenReturn("1234");
		EmployerMasterBean employer = new EmployerMasterBean();
		employer.setEmployerKid("acvb");
		Mockito.when(redisHelper.getEmployerByKey(Mockito.any())).thenReturn(employer);
		listener.getEmployer(execution);
	}
	
	@Test
	public void testcheckRepaymentFlowFlag() {
		listener.checkRepaymentFlowFlag(execution);
	}
	
	public void testGetApprovedLoanPricing_SrcEP() {
		Gson g = new Gson();
		Object existingPricing = g.fromJson(
				"[{\"appLoanPricingKey\":\"1934\",\"applicationKey\":\"1100000000006221\",\"prodCategoryCode\":\"OMPL\",\"isTenure\":0,\"droplineTenure\":48,\"emiAmount\":2778.0,\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20.0,\"firstDueDate\":\"2020-10-02\",\"dueDay\":2,\"graceTerm\":null,\"nextDueDate\":null,\"roi\":14.6,\"isEmi\":null,\"droplineEmi\":null,\"pennantLoanType\":\"SOLTL\",\"netDisbursementAmount\":null,\"loanAmount\":100000.0,\"fees\":[{\"feesKey\":18852,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":1200.0,\"feeCode\":\"CONV\"},{\"feesKey\":18851,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"STAMPFEE\"},{\"feesKey\":18850,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"PROCFEE\"}],\"loanType\":\"BFLSOLTL\",\"isBpiApplicable\":\"Yes\",\"roiWithBundle\":14.25,\"roiWithoutBundle\":14.6,\"finalLoanAmount\":104463.0,\"loanAmmountWithBundle\":104463.0,\"loanAmmountWithoutBundle\":100000.0,\"pricingStatus\":\"APPROVED\",\"raisedBy\":0,\"fppSelected\":false,\"source\":\"EP\",\"bundlePrice\":null,\"approval\":{\"approvalStatus\":\"APPROVED\",\"approvedBy\":0,\"raisedBy\":0}}] ",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(existingPricing);
		listener.getApprovedLoanPricing(execution);
	}
	
	@Test
	public void testGetApprovedLoanPricing_SrcJrny() {
		Gson g = new Gson();
		Object existingPricing = g.fromJson(
				"[{\"appLoanPricingKey\":\"1934\",\"applicationKey\":\"1100000000006221\",\"prodCategoryCode\":\"OMPL\",\"isTenure\":0,\"droplineTenure\":48,\"emiAmount\":2778.0,\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20.0,\"firstDueDate\":\"2020-10-02\",\"dueDay\":2,\"graceTerm\":null,\"nextDueDate\":null,\"roi\":14.6,\"isEmi\":null,\"droplineEmi\":null,\"pennantLoanType\":\"SOLTL\",\"netDisbursementAmount\":null,\"loanAmount\":100000.0,\"fees\":[{\"feesKey\":18852,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":1200.0,\"feeCode\":\"CONV\"},{\"feesKey\":18851,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"STAMPFEE\"},{\"feesKey\":18850,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"PROCFEE\"}],\"loanType\":\"BFLSOLTL\",\"isBpiApplicable\":\"Yes\",\"roiWithBundle\":14.25,\"roiWithoutBundle\":14.6,\"finalLoanAmount\":104463.0,\"loanAmmountWithBundle\":104463.0,\"loanAmmountWithoutBundle\":100000.0,\"pricingStatus\":\"APPROVED\",\"raisedBy\":0,\"fppSelected\":false,\"source\":\"JOURNEY\",\"bundlePrice\":null,\"approval\":{\"approvalStatus\":\"APPROVED\",\"approvedBy\":0,\"raisedBy\":0}}] ",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(existingPricing);
		listener.getApprovedLoanPricing(execution);
	}
	@Test
	public void testpreCreateChildApplication() {
		HashMap<String,Object> request = new HashMap<String,Object>();
		request.put("parentApplicationKey","1234");
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(request);
		listener.preCreateChildApplication(execution);
	}
	
	@Test
	public void testpostCreateChildApplication() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new HashMap<String,Object>());
		listener.postCreateChildApplication(execution);
	}
	
	@Test
	public void testBuildRequestForUpdateApplicationParameters() {
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(new HashMap<String,Object>());
		listener.buildRequestForUpdateApplicationParameters(execution);
	}
	
	@Test
	public void testPreRejectionApplicationStatusUpdate() {
		listener.preRejectionApplicationStatusUpdate(execution);
	}
}
