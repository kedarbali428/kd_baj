package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.API_EXCEPTION_ARISE;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.Verification;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@SpringBootTest
public class EmailVerificationListenerTest {

	@InjectMocks
	EmailVerificationListener emailVerificationListener;
	
	@Mock
	private BFLLoggerUtilExt logger;
	
	@Mock
	private DelegateExecution execution;

	private String configuredVerificationSources = "BFSD,EP,PRICING_CONSENT";
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(emailVerificationListener, "configuredVerificationSources", configuredVerificationSources);
	}
	
	@Test
	public void testIsEmailVerificationRequired_true() {
		JSONObject productListObject = new JSONObject();
		List<JSONObject> productList = new ArrayList<JSONObject>();
		JSONObject product = new JSONObject();
		product.put("emailverificationrequiredflag", 1d);
		productList.add(product);
		productListObject.put("productList", productList);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(productListObject);		
		emailVerificationListener.isEmailVerificationRequired(execution);
	}
	
	@Test
	public void testIsEmailVerificationRequired_flagNull() {
		JSONObject productListObject = new JSONObject();
		List<JSONObject> productList = new ArrayList<JSONObject>();
		JSONObject product = new JSONObject();
		productList.add(product);
		productListObject.put("productList", productList);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(productListObject);		
		emailVerificationListener.isEmailVerificationRequired(execution);
	}
	
	@Test
	public void testIsEmailVerificationRequired_nullReponse() {
		JSONObject productListObject = null;
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(productListObject);		
		emailVerificationListener.isEmailVerificationRequired(execution);
	}
	
	@Test
	public void testGetUserProfile() {
		JSONObject userProfile = new JSONObject();
		List<JSONObject> userProfiles = new ArrayList<JSONObject>();
		userProfile.put("applicationUserAttributeType", "1");
		userProfiles.add(userProfile);
		when(execution.getVariable(Mockito.anyString())).thenReturn(userProfiles);
		
		emailVerificationListener.getUserProfile(execution);
	}
	
	@Test
	public void testPostGetEmail() {
		Email email = new Email();
		email.setEmail("test@bajajfinservmarkets.in");
		email.setTypeKey(67l);
		
		List<Verification> verifications = new ArrayList<Verification>();
		Verification verification = new Verification();
		verification.setIsVerified(true);
		verification.setVerificationSource("BFSD");
		verification.setVerifiedFor("1234");
		verification.setVerificationReference(1234l);
		
		verifications.add(verification);
		email.setVerifications(verifications);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(email);
		
		emailVerificationListener.postGetEmail(execution);
	}
	
	@Test
	public void testPostGetEmail_OtherVerifiedSource() {
		Email email = new Email();
		email.setEmail("test@bajajfinservmarkets.in");
		email.setTypeKey(67l);
		
		List<Verification> verifications = new ArrayList<Verification>();
		Verification verification = new Verification();
		verification.setIsVerified(true);
		verification.setVerificationSource("KARZA");
		verification.setVerifiedFor("1234");
		
		verifications.add(verification);
		email.setVerifications(verifications);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(email);
		
		emailVerificationListener.postGetEmail(execution);
	}
	
	@Test
	public void testPostGetEmail_NotVerified() {
		Email email = new Email();
		email.setEmail("test@bajajfinservmarkets.in");
		email.setTypeKey(67l);
		
		List<Verification> verifications = new ArrayList<Verification>();
		Verification verification = new Verification();
		verification.setIsVerified(null);
		verification.setVerificationSource("BFSD");
		verification.setVerifiedFor("1234");
		verification.setVerificationReference(1234l);
		
		verifications.add(verification);
		email.setVerifications(verifications);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(email);
		
		emailVerificationListener.postGetEmail(execution);
	}
	
	@Test
	public void testPostGetEmail_NullVerification() {
		Email email = new Email();
		email.setEmail("test@bajajfinservmarkets.in");
		email.setTypeKey(67l);
		
		email.setVerifications(null);
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(email);
		
		emailVerificationListener.postGetEmail(execution);
	}
	
	@Test
	public void testPostGetEmail_NullEmail() {
		Email email = null;
		
		when(execution.getVariable(Mockito.anyString())).thenReturn(email);
		
		emailVerificationListener.postGetEmail(execution);
	}
	
	@Test
	public void testSetEmailType() {
		emailVerificationListener.setEmailType(execution);
	}
	
	@Test
	public void testPreSendOtp() {
		emailVerificationListener.preSendOtp(execution);
	}
	
	@Test
	public void testPostEmailVerification() {
		JSONObject emailVerificationResponseJson = new JSONObject();
		emailVerificationResponseJson.put("verifiedFlag", true);
		when(execution.getVariable(Mockito.anyString())).thenReturn(emailVerificationResponseJson, new JSONObject());
		emailVerificationListener.postEmailVerification(execution);
	}
	
	@Test
	public void testPostEmailVerification_ErrroOccurred() {
		JSONObject emailVerificationResponseJson = new JSONObject();
		emailVerificationResponseJson.put("errorCode", "error");
		when(execution.getVariable(Mockito.anyString())).thenReturn(emailVerificationResponseJson);
		emailVerificationListener.postEmailVerification(execution);
	}
	
	@Test
	public void testPreEmailVerification_validateOtp() {
		JSONObject emailDetailRequest = new JSONObject();
		emailDetailRequest.put("action", "validate");
		emailDetailRequest.put("otp", "123456");
		when(execution.getVariable(Mockito.anyString())).thenReturn(emailDetailRequest);
		emailVerificationListener.preEmailVerification(execution);
	}
	
	@Test
	public void testPreEmailVerification_validateToken() {
		JSONObject emailDetailRequest = new JSONObject();
		emailDetailRequest.put("action", "validateemailtoken");
		emailDetailRequest.put("otp", "123456");
		when(execution.getVariable(Mockito.anyString())).thenReturn(emailDetailRequest);
		emailVerificationListener.preEmailVerification(execution);
	}
	
	@Test
	public void testSetDummyAction() {
		emailVerificationListener.setDummyAction(execution, "verified");
	}
	
	@Test
	public void testGetEmailInitiationResponse() {
		JSONObject time = new JSONObject();
		time.put("timestamp", "2021-03-05 11:30:32.34");
		JSONObject object = CreditBusinessHelper.getJSONObject(time);
		System.out.println(object);
		Timestamp parsedTimestamp = Timestamp.valueOf(object.get("timestamp").toString());
		System.out.println(parsedTimestamp);
	}
	
	@Test
	public void testSetEmailCommInitiationAndValidationOutsideEVFlow() {
		emailVerificationListener.setEmailCommInitiationAndValidationOutsideEVFlow(execution, false, true);
	}
	
	@Test
	public void testPreGetEmailInitiationResponse() {
		emailVerificationListener.preGetEmailInitiationResponse(execution);
	}
	
	@Test
	public void testPostGetEmailInitiationResponse_ExceptionArise() {
		when(execution.getVariable(API_EXCEPTION_ARISE)).thenReturn(true);
		emailVerificationListener.postGetEmailInitiationResponse(execution);
	}
	
	@Test
	public void testPostGetEmailInitiationResponse_NoException() {
		JSONObject emailVerificationResponse = new JSONObject();
		emailVerificationResponse.put("emailSentFlag", true);
		emailVerificationResponse.put("emailOtpGenerationDate", new Timestamp(System.currentTimeMillis()).toString());
		when(execution.getVariable(Mockito.anyString())).thenReturn(null).thenReturn(emailVerificationResponse);
		emailVerificationListener.postGetEmailInitiationResponse(execution);
	}
	
	@Test
	public void testPostGetEmailInitiationResponse_Exception() {
		JSONObject emailVerificationResponse = new JSONObject();
		emailVerificationResponse.put("emailSentFlag", true);
		emailVerificationResponse.put("emailOtpGenerationDate", "Mar 12, 2020 12:12:12.000");
		when(execution.getVariable(Mockito.anyString())).thenReturn(null).thenReturn(emailVerificationResponse);
		emailVerificationListener.postGetEmailInitiationResponse(execution);
	}
	
	@Test
	public void testPostGetEmailInitiationResponse_NullEmailSentDate() {
		JSONObject emailVerificationResponse = new JSONObject();
		emailVerificationResponse.put("emailSentFlag", true);
		emailVerificationResponse.put("emailOtpGenerationDate", null);
		when(execution.getVariable(Mockito.anyString())).thenReturn(null).thenReturn(emailVerificationResponse);
		emailVerificationListener.postGetEmailInitiationResponse(execution);
	}
}
