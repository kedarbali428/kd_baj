package com.bajaj.markets.credit.business.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.Validator;
import javax.validation.metadata.ConstraintDescriptor;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Profession;
import com.bajaj.markets.credit.business.beans.ProfileDetailsReqResp;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.service.CreditBusinessProfileDetailService;
import com.fasterxml.jackson.databind.ObjectMapper;

@AutoConfigureMockMvc
@WebMvcTest
public class CreditBusinessProfileDetailControllerTest {

	@InjectMocks
	CreditBusinessProfileDetailsController controller;

	@Mock
	BFLLoggerUtilExt logger;
	
    @Mock
    private Validator validator;

	@Mock
	CreditBusinessProfileDetailService creditBusinessProfileDetailService;
	
	private ObjectMapper mapper = new ObjectMapper();

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(CreditBusinessControllerAdvice.class)
				.build();
	}

	@Test
	public void testGetProfileDetails() throws Exception {
		ProfileDetailsReqResp profileDetailsResponse = new ProfileDetailsReqResp();
		Mockito.when(creditBusinessProfileDetailService.getProfileDetails(Mockito.any()))
				.thenReturn(profileDetailsResponse);
		mockMvc.perform(
				get("/v2/credit/applications/{applicationId}/profile", "123").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testSaveProfileDet_UnprocessableEntity() throws Exception {
		String request = mapper.writeValueAsString(new ProfileDetailsReqResp());
		mockMvc.perform(post("/v2/credit/applications/{applicationId}/profile", "123").content(request)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isUnprocessableEntity());
	}
	
	 @Test
	    public void testSaveProfileDet_salaried() throws Exception {
			ProfileDetailsReqResp profileDetailsResponse = new ProfileDetailsReqResp();
	        Reference occType = new Reference();
	        occType.setCode("SALR");
	        Profession profession = new Profession();
	        profession.setOccupation(occType);
	        profileDetailsResponse.setProfession(profession);
	        profileDetailsResponse.setAction(null);
	        String request = mapper.writeValueAsString(profileDetailsResponse);
	        mockMvc.perform(post("/v2/credit/applications/{applicationId}/profile", "123").content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isCreated());
	    }
	 

	 @Test
	    public void testSaveProfileDet_Invalid() throws Exception {
			ProfileDetailsReqResp profileDetailsResponse = new ProfileDetailsReqResp();
	        Reference occType = new Reference();
	        occType.setCode("ABCD");
	        Profession profession = new Profession();
	        profession.setOccupation(occType);
	        profileDetailsResponse.setProfession(profession);
	        profileDetailsResponse.setAction(null);
	        String request = mapper.writeValueAsString(profileDetailsResponse);
	        mockMvc.perform(post("/v2/credit/applications/{applicationId}/profile", "123").content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isUnprocessableEntity());
	    }
	    
	    @Test
	    public void testSaveProfessionalDet_EmptyError() throws Exception {
	    	ProfileDetailsReqResp profileDetailsResponse = new ProfileDetailsReqResp();
	        Profession profession = new Profession();
	        profileDetailsResponse.setProfession(profession);
	        profileDetailsResponse.setAction(null);
	        String request = mapper.writeValueAsString(profileDetailsResponse);
	        mockMvc.perform(post("/v2/credit/applications/{applicationId}/profile", "123").content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isUnprocessableEntity());
	    }

}
