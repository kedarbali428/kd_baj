package com.bajaj.markets.credit.business.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.AdditionalDetail;
import com.bajaj.markets.credit.business.beans.AdditionalDetailLoans;
import com.bajaj.markets.credit.business.beans.AdditionalDetailPricing;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.validator.DateValidator;
import com.bajaj.markets.credit.business.service.CreditBusinessAdditionalDetailService;
import com.fasterxml.jackson.databind.ObjectMapper;

@AutoConfigureMockMvc
@WebMvcTest
public class CreditBusinessAdditionalDetailControllerTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CreditBusinessAdditionalDetailService creditBusinessAdditionalDetailService;

	@InjectMocks
	CreditBusinessAdditionalDetailController creditBusinessAdditionalDetailController;

	private MockMvc mockMvc;

	@Mock
	private DateValidator dateValidator;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBusinessAdditionalDetailController).setControllerAdvice(CreditBusinessControllerAdvice.class).build();
	}

	@Test
	public void testSaveAdditionalDetail() throws Exception {
		AdditionalDetail additionalDetail = new AdditionalDetail();
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(additionalDetail);
		mockMvc.perform(
				post("/v1/credit/applications/{applicationid}/card/additionaldetail", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}
	
	@Test
	public void testSaveAdditionalDetail_invalid_nameToBePrintedOnCard() throws Exception {
		AdditionalDetail additionalDetail = new AdditionalDetail();
		additionalDetail.setNameToBePrintedOnCard("....123");
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(additionalDetail);
		mockMvc.perform(
				post("/v1/credit/applications/{applicationid}/card/additionaldetail", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isUnprocessableEntity());
	}

	@Test
	public void testGetAdditionalDetail() throws Exception {
		mockMvc.perform(get("/v1/credit/applications/{applicationid}/card/additionaldetail", "123").param("l3ProductCode", "123")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	@Test
	public void testGetAdditionalDetailInvalidApp() throws Exception {
		mockMvc.perform(get("/v1/credit/applications/{applicationid}/card/additionaldetail", "12A3").param("l3ProductCode", "123")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isNotFound());
	}

	@Test
	public void testGetAdditionalDetailInvalidL3() throws Exception {
		mockMvc.perform(
				get("/v1/credit/applications/{applicationid}/card/additionaldetail", "123").param("l3ProductCode", " ").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound());
	}

	@Test
	public void testSaveLoansAdditionalDetail() throws Exception {
		AdditionalDetailLoans additionalDetail = new AdditionalDetailLoans();
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(additionalDetail);
		Mockito.when(creditBusinessAdditionalDetailService.saveLoansAdditionalDetail(Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(new ApplicationResponse(), HttpStatus.CREATED));
		mockMvc.perform(
				post("/v1/credit/applications/loans/{applicationid}/additionaldetail", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}

	@Test
	public void testGetLoansAdditionalDetail() throws Exception {
		AdditionalDetailLoans additionalDetail = new AdditionalDetailLoans();
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(additionalDetail);
		Mockito.when(creditBusinessAdditionalDetailService.getLoansAdditionalDetail(Mockito.any(), Mockito.any())).thenReturn(additionalDetail);
		mockMvc.perform(
				get("/v1/credit/applications/loans/{applicationid}/additionaldetail", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testGetPricing() throws Exception {
		AdditionalDetailPricing additionalDetail = new AdditionalDetailPricing();
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(additionalDetail);
		Mockito.when(creditBusinessAdditionalDetailService.getPricing(Mockito.any(), Mockito.any())).thenReturn(additionalDetail);
		mockMvc.perform(
				get("/v1/credit/loans/{applicationid}/summary", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

}
