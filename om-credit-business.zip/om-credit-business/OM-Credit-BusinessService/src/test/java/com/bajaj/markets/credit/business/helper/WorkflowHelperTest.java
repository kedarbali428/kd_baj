package com.bajaj.markets.credit.business.helper;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.ActivitiException;
import org.activiti.engine.ActivitiObjectNotFoundException;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.persistence.entity.ExecutionEntityImpl;
import org.activiti.engine.impl.persistence.entity.TaskEntityImpl;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ExecutionQuery;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.task.TaskQuery;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Application;
import com.bajaj.markets.credit.business.beans.NextTask;

@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
//Test cases will be called in Ascending order of their method name
public class WorkflowHelperTest {

	@Mock
	RuntimeService runtimeService;

	@Mock
	TaskService taskService;

	@Mock
	TaskQuery taskQuery;

	@Mock
	Execution execution;

	@Mock
	ExecutionQuery executionQuery;

	@Mock
	ProcessInstance processInstance;

	@Mock
	BFLLoggerUtilExt logger;

	@InjectMocks
	WorkflowHelper workflowHelper;
	
	@Mock
	private Environment env;
	
	List<Task> taskList = new ArrayList<>();

	List<Execution> exeList = new ArrayList<Execution>();

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		TaskEntityImpl taskEntity = new TaskEntityImpl();
		taskEntity.setTaskDefinitionKey("Test_Task");
		taskList.add(taskEntity);

		Mockito.when(taskService.createTaskQuery()).thenReturn(taskQuery);
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any())).thenReturn(taskQuery);
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any()).list()).thenReturn(taskList);

		Mockito.when(runtimeService.createExecutionQuery()).thenReturn(executionQuery);
		Mockito.when(runtimeService.createExecutionQuery().onlySubProcessExecutions()).thenReturn(executionQuery);
		Mockito.when(runtimeService.createExecutionQuery().onlySubProcessExecutions().rootProcessInstanceId(Mockito.any())).thenReturn(executionQuery);
		Mockito.when(runtimeService.createExecutionQuery().onlySubProcessExecutions().rootProcessInstanceId(Mockito.any()).list()).thenReturn(exeList);
	}

	//Test case to check valid execution - Will be called first
	@Test
	public void testA() {
		exeList.add(execution);
		Execution entityImpl = new ExecutionEntityImpl();
		List<Execution> exeImplList = new ArrayList<>();
		exeImplList.add(entityImpl);
		Mockito.when(runtimeService.createExecutionQuery().onlySubProcessExecutions().rootProcessInstanceId(Mockito.any()).list()).thenReturn(exeImplList);
		assertEquals("Test_Task", workflowHelper.completeTask("1", null));
	}

	//Test case to check exception - process id validation - Will be called second
	@Test(expected = CreditBusinessException.class)
	public void testB() {
		exeList.add(execution);
		Mockito.when(runtimeService.createExecutionQuery().onlySubProcessExecutions().rootProcessInstanceId(Mockito.any()).list()).thenReturn(exeList);
		assertEquals("Test_Task", workflowHelper.completeTask(null, null));
	}

	//Test case to check exception -Will be called third
	@SuppressWarnings("unused")
	@Test(expected = CreditBusinessException.class)
	public void testC() {
		Mockito.when(runtimeService.createExecutionQuery()).thenReturn(null);
		String nextTaskId = workflowHelper.completeTask("1", null);
	}

	//Test case to check exception -Will be called third
	@SuppressWarnings("unused")
	@Test(expected = CreditBusinessException.class)
	public void testD() {
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any())).thenReturn(null);
		String nextTaskId = workflowHelper.completeTask("1", null);
	}

	//Test case to check activiti object not present -Will be called fourth
	@SuppressWarnings("unused")
	@Test(expected = CreditBusinessException.class)
	public void testE() {
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any())).thenThrow(ActivitiObjectNotFoundException.class);
		String nextTaskId = workflowHelper.completeTask("1", null);
	}
	
	@Test
	public void testStartActivitiProcess() {
		TaskEntityImpl taskEntity = new TaskEntityImpl();
		taskEntity.setTaskDefinitionKey("Test_Task");
		taskList.add(taskEntity);

		Mockito.when(taskService.createTaskQuery()).thenReturn(taskQuery);
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any())).thenReturn(taskQuery);
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any()).list()).thenReturn(taskList);

		Mockito.when(runtimeService.startProcessInstanceByKey(Mockito.any(), Mockito.anyMap())).thenReturn(processInstance);
		workflowHelper.startActivitiProcess("testProcess", new HashMap<String, Object>());
	}
	
	@Test
	public void testStartActivitiProcess1() {
		TaskEntityImpl taskEntity = new TaskEntityImpl();
		taskEntity.setTaskDefinitionKey("Test_Task");
		taskList.add(taskEntity);

		Mockito.when(taskService.createTaskQuery()).thenReturn(taskQuery);
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any())).thenReturn(taskQuery);
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any()).list()).thenReturn(taskList);
		exeList.add(execution);
		Mockito.when(runtimeService.startProcessInstanceByKey(Mockito.any(), Mockito.anyMap())).thenReturn(processInstance);
		Mockito.when(runtimeService.createExecutionQuery().onlySubProcessExecutions().rootProcessInstanceId(Mockito.any()).list()).thenReturn(exeList);
		workflowHelper.startActivitiProcess("testProcess", new HashMap<String, Object>());
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testStartActivitiProcessEx2() {
		workflowHelper.startActivitiProcess(null, new HashMap<String, Object>());
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testStartActivitiProcessEx3() {
		HashMap<String, Object> payload = new HashMap<String, Object>();
		payload.put(CreditBusinessConstants.REQUEST, new Application());
		Mockito.when(runtimeService.startProcessInstanceByKey(Mockito.any(), Mockito.anyMap())).thenThrow(ActivitiObjectNotFoundException.class);
		workflowHelper.startActivitiProcess("testProcess", payload);
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testStartActivitiProcess4() {
		TaskEntityImpl taskEntity = new TaskEntityImpl();
		taskEntity.setTaskDefinitionKey("Test_Task");
		taskList.add(taskEntity);

		Mockito.when(taskService.createTaskQuery()).thenReturn(taskQuery);
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any())).thenReturn(taskQuery);
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any()).list()).thenReturn(taskList);
		exeList.add(execution);
		Mockito.when(runtimeService.startProcessInstanceByKey(Mockito.any(), Mockito.anyMap())).thenReturn(processInstance);
		Mockito.when(runtimeService.createExecutionQuery().onlySubProcessExecutions().rootProcessInstanceId(Mockito.any()).list()).thenThrow(new ActivitiObjectNotFoundException(""));
		HashMap<String, Object> payload = new HashMap<String, Object>();
		payload.put(CreditBusinessConstants.REQUEST, new Application());
		workflowHelper.startActivitiProcess("testProcess", payload);
	}

	@Test
	public void testStartActivitiProcessEMIC() {
		TaskEntityImpl taskEntity = new TaskEntityImpl();
		taskEntity.setTaskDefinitionKey("Test_Task");
		taskList.add(taskEntity);

		Mockito.when(taskService.createTaskQuery()).thenReturn(taskQuery);
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any())).thenReturn(taskQuery);
		Mockito.when(taskService.createTaskQuery().processInstanceId(Mockito.any()).list()).thenReturn(taskList);
		exeList.add(execution);
		Mockito.when(runtimeService.startProcessInstanceByKey(Mockito.any(), Mockito.anyMap()))
				.thenReturn(processInstance);
		Mockito.when(runtimeService.createExecutionQuery().onlySubProcessExecutions()
				.rootProcessInstanceId(Mockito.any()).list()).thenReturn(exeList);
		HashMap<String, Object> payload = new HashMap<String, Object>();
		Application value = new Application();
		value.setProductCode(CreditBusinessConstants.PRODUCT_CODE_EMIC);
		payload.put(CreditBusinessConstants.REQUEST, value);
		NextTask startActivitiProcess = workflowHelper.startActivitiProcess("testProcess", payload);
		assertNotNull(startActivitiProcess);
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testStartActivitiProcess_BusinessExceptionInsideActivitException() {
		Mockito.when(runtimeService.startProcessInstanceByKey(Mockito.any(), Mockito.anyMap())).thenThrow(new ActivitiException("outer exception", new ActivitiException("inner exception", new CreditBusinessException())));
		workflowHelper.startActivitiProcess("testProcess", new HashMap<String, Object>());
	}
	
	@Test(expected = CreditBusinessException.class)
	public void testStartActivitiProcess_GenericException() {
		Mockito.when(runtimeService.startProcessInstanceByKey(Mockito.any(), Mockito.anyMap())).thenReturn(null);
		workflowHelper.startActivitiProcess("testProcess", new HashMap<String, Object>());
	}
	
	@Test
	public void testGetFromExecutionMap() {
		Map<String, Object> variables = new HashMap<>();
		variables.put("key", "value");
		Mockito.when(runtimeService.getVariables(Mockito.any())).thenReturn(variables);
		Assert.assertNotNull(workflowHelper.getFromExecutionMap("key", "12345"));
	}
	
	@Test
	public void testGetAllVariablesFromProcessId() {
		Map<String, Object> variables = new HashMap<>();
		variables.put("key", "value");
		Mockito.when(runtimeService.getVariables(Mockito.any())).thenReturn(variables);
		Assert.assertNotNull(workflowHelper.getAllVariablesFromProcessId("12345"));
	}
	
}
