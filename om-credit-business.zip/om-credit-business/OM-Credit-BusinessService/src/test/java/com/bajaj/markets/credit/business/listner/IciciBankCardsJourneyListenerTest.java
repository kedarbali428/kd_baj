package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.activiti.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;

public class IciciBankCardsJourneyListenerTest {
	
	@InjectMocks
	IciciBankCardsJourneyListener iciciBankCardsJourneyListener;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	DelegateExecution execution;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testPreDocumentKeyUpdate() {
		doReturn("{\"action\":null,\"addressDetails\":[{\"addressKey\":null,\"addressLine1\":\"test test\",\"addressLine2\":\"ateatse\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"50\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411014\",\"pincodeKey\":\"113548\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},{\"addressKey\":null,\"addressLine1\":\"test asdf\",\"addressLine2\":\"aear\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"46\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411011\",\"pincodeKey\":\"115400\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null}],\"otherAddressDetails\":{\"addressKey\":null,\"addressLine1\":\"test test\",\"addressLine2\":\"ateatse\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"48\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411014\",\"pincodeKey\":\"113548\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},\"annualItr\":null,\"applicationid\":\"1100000000019297\",\"cppFlag\":null,\"deliveryAddressFlag\":false,\"principalFeatures\":[{\"featureName\":\"ECOM\",\"featureValue\":0},{\"featureName\":\"INTERNATIONAL\",\"featureValue\":0},{\"featureName\":\"CONTACTLESS\",\"featureValue\":0}],\"fatherName\":null,\"l3ProductCode\":\"CCHDFCMIL\",\"motherName\":null,\"qualification\":{\"code\":\"UG\",\"key\":2,\"value\":\"Graduate\"},\"industryType\":{\"code\":null,\"key\":null,\"value\":null},\"occupationType\":{\"code\":\"SALR\",\"key\":1,\"value\":\"Salaried\"},\"workEmailId\":\"asdf@gmail.com\",\"alternateMobileNumber\":null,\"nameToBePrintedOnCard\":\"t. patel\",\"applicantIdProof\":{\"key\":1,\"code\":\"Aadhaar\",\"value\":\"Aadhaar Cards\"},\"addressProof\":{\"key\":2,\"code\":\"Aadhaar\",\"value\":\"Aadhaar Cards\"}}")
			.when(execution).getVariable(Mockito.any());
		iciciBankCardsJourneyListener.preDocumentKeyUpdate(execution);
		verify(logger, times(0)).error(Mockito.any(), Mockito.any(), Mockito.any());
	}
	
	@Test
	public void testPreDocumentKeyUpdate_DocumentKeyNull() {
		doReturn("{\"action\":null,\"addressDetails\":[{\"addressKey\":null,\"addressLine1\":\"test test\",\"addressLine2\":\"ateatse\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"50\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411014\",\"pincodeKey\":\"113548\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},{\"addressKey\":null,\"addressLine1\":\"test asdf\",\"addressLine2\":\"aear\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"46\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411011\",\"pincodeKey\":\"115400\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null}],\"otherAddressDetails\":{\"addressKey\":null,\"addressLine1\":\"test test\",\"addressLine2\":\"ateatse\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"48\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411014\",\"pincodeKey\":\"113548\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},\"annualItr\":null,\"applicationid\":\"1100000000019297\",\"cppFlag\":null,\"deliveryAddressFlag\":false,\"principalFeatures\":[{\"featureName\":\"ECOM\",\"featureValue\":0},{\"featureName\":\"INTERNATIONAL\",\"featureValue\":0},{\"featureName\":\"CONTACTLESS\",\"featureValue\":0}],\"fatherName\":null,\"l3ProductCode\":\"CCHDFCMIL\",\"motherName\":null,\"qualification\":{\"code\":\"UG\",\"key\":2,\"value\":\"Graduate\"},\"industryType\":{\"code\":null,\"key\":null,\"value\":null},\"occupationType\":{\"code\":\"SALR\",\"key\":1,\"value\":\"Salaried\"},\"workEmailId\":\"asdf@gmail.com\",\"alternateMobileNumber\":null,\"nameToBePrintedOnCard\":\"t. patel\",\"applicantIdProof\":{\"key\":null,\"code\":null,\"value\":null},\"addressProof\":{\"key\":null,\"code\":null,\"value\":null}}")
			.when(execution).getVariable(Mockito.any());
		iciciBankCardsJourneyListener.preDocumentKeyUpdate(execution);
		verify(logger, times(1)).error(Mockito.any(), Mockito.any(), Mockito.any());
	}
	
	@Test
	public void testPreDocumentKeyUpdate_DocumentReferenceNull() {
		doReturn("{\"action\":null,\"addressDetails\":[{\"addressKey\":null,\"addressLine1\":\"test test\",\"addressLine2\":\"ateatse\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"50\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411014\",\"pincodeKey\":\"113548\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},{\"addressKey\":null,\"addressLine1\":\"test asdf\",\"addressLine2\":\"aear\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"46\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411011\",\"pincodeKey\":\"115400\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null}],\"otherAddressDetails\":{\"addressKey\":null,\"addressLine1\":\"test test\",\"addressLine2\":\"ateatse\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"48\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411014\",\"pincodeKey\":\"113548\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},\"annualItr\":null,\"applicationid\":\"1100000000019297\",\"cppFlag\":null,\"deliveryAddressFlag\":false,\"principalFeatures\":[{\"featureName\":\"ECOM\",\"featureValue\":0},{\"featureName\":\"INTERNATIONAL\",\"featureValue\":0},{\"featureName\":\"CONTACTLESS\",\"featureValue\":0}],\"fatherName\":null,\"l3ProductCode\":\"CCHDFCMIL\",\"motherName\":null,\"qualification\":{\"code\":\"UG\",\"key\":2,\"value\":\"Graduate\"},\"industryType\":{\"code\":null,\"key\":null,\"value\":null},\"occupationType\":{\"code\":\"SALR\",\"key\":1,\"value\":\"Salaried\"},\"workEmailId\":\"asdf@gmail.com\",\"alternateMobileNumber\":null,\"nameToBePrintedOnCard\":\"t. patel\",\"applicantIdProof\":null,\"addressProof\":null}")
			.when(execution).getVariable(Mockito.any());
		iciciBankCardsJourneyListener.preDocumentKeyUpdate(execution);
		verify(logger, times(1)).error(Mockito.any(), Mockito.any(), Mockito.any());
	}
	
	@Test
	public void testPrePrincipalAdditionalDetailUpdate() {
		doReturn("{\"action\":null,\"addressDetails\":[{\"addressKey\":null,\"addressLine1\":\"test test\",\"addressLine2\":\"ateatse\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"50\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411014\",\"pincodeKey\":\"113548\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},{\"addressKey\":null,\"addressLine1\":\"test asdf\",\"addressLine2\":\"aear\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"46\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411011\",\"pincodeKey\":\"115400\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null}],\"otherAddressDetails\":{\"addressKey\":null,\"addressLine1\":\"test test\",\"addressLine2\":\"ateatse\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"48\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411014\",\"pincodeKey\":\"113548\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},\"annualItr\":null,\"applicationid\":\"1100000000019297\",\"cppFlag\":null,\"deliveryAddressFlag\":false,\"principalFeatures\":[{\"featureName\":\"ECOM\",\"featureValue\":0},{\"featureName\":\"INTERNATIONAL\",\"featureValue\":0},{\"featureName\":\"CONTACTLESS\",\"featureValue\":0}],\"fatherName\":null,\"l3ProductCode\":\"CCHDFCMIL\",\"motherName\":null,\"qualification\":{\"code\":\"UG\",\"key\":2,\"value\":\"Graduate\"},\"industryType\":{\"code\":null,\"key\":null,\"value\":null},\"occupationType\":{\"code\":\"SALR\",\"key\":1,\"value\":\"Salaried\"},\"workEmailId\":\"asdf@gmail.com\",\"alternateMobileNumber\":null,\"nameToBePrintedOnCard\":\"t. patel\",\"applicantIdProof\":{\"key\":1,\"code\":\"Aadhaar\",\"value\":\"Aadhaar Cards\"},\"addressProof\":{\"key\":2,\"code\":\"Aadhaar\",\"value\":\"Aadhaar Cards\"},\"hasSalaryAccount\":true,\"appointmentDateTimeFrom\":\"2018-09-06 11:13:07\",\"appointmentDateTimeTo\":\"2018-09-07 11:13:07\",\"appointmentAddressTypeCode\":\"code\"}")
		.when(execution).getVariable(Mockito.any());
		iciciBankCardsJourneyListener.prePrincipalAdditionalDetailUpdate(execution);
	}
}
