package com.bajaj.markets.credit.business.datasource;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.BFDLProspectDetails;
import com.bajaj.markets.credit.business.beans.Gender;
import com.bajaj.markets.credit.business.beans.LocationAddressBean;
import com.bajaj.markets.credit.business.beans.MaritalStatus;
import com.bajaj.markets.credit.business.beans.OfferApiRequest;
import com.bajaj.markets.credit.business.beans.ResponseBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@SpringBootConfiguration
@SpringBootTest
public class RBLIntDataSourceTest {
	
	@InjectMocks
	private RBLIntDataSource rblIntDataSource;
	
	@Mock
	private CreditBusinessHelper creditBusinessHelper;
	
	@Mock
	private BFLLoggerUtilExt logger;
	
	@Mock
	BFLLoggerUtil loggerUtil;
		
	private String rblOfferProducts = "CCRBLPLTPLUSF,CCRBLVALUEPLUS";
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(rblIntDataSource, "logger", logger);
		ReflectionTestUtils.setField(rblIntDataSource, "precedence", "0");
		ReflectionTestUtils.setField(rblIntDataSource, "rblOfferProducts", rblOfferProducts);
	}
	
	@Test
	public void registerDataSourceTest() {
		DataSourceRegistry dataSourceRegistry = Mockito.mock(DataSourceRegistry.class);
		rblIntDataSource.registerDataSource(dataSourceRegistry);
	}
	
	@Test
	public void initDataSourceTest() {
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		rblIntDataSource.initDataSource(applicantDataBean);
	}
	
	@Test
	public void initDataSourceTest_SALR() {
		ResponseEntity<Object> popOfferResponse = new ResponseEntity<Object>(new ResponseBean(popBFDLProspectOfferDetail()), 
				HttpStatus.OK);
		ResponseEntity<Object> popOfferSrcKey = new ResponseEntity<Object>(popOfferSource(), HttpStatus.OK);
		ResponseEntity<Object> popMarrital = new ResponseEntity<Object>(popMaritalStat(), HttpStatus.OK);
		ResponseEntity<Object> popGender = new ResponseEntity<Object>(popGenderMas(), HttpStatus.OK);
		ResponseEntity<Object> popLocationaddress = new ResponseEntity<Object>(popLocationAddressBean(), HttpStatus.OK);
		
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1990-01-01");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9876543210");
		applicantDataBean.setOccupationType("SALR");
		offerApiRequest.setProductCode("SALR");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataBean.setProductCode("CC");
		
		doReturn(popOfferResponse).doReturn(popOfferSrcKey).doReturn(popMarrital).doReturn(popGender)
			.doReturn(popLocationaddress).when(creditBusinessHelper).invokeRestEndpoint(Mockito.any(), 
					Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
		
		rblIntDataSource.initDataSource(applicantDataBean);
	}
	
	@Test
	public void initDataSourceTest_SEMP() {
		ResponseEntity<Object> popOfferResponse = new ResponseEntity<Object>(new ResponseBean(popBFDLProspectOfferDetailSEMP()), 
				HttpStatus.OK);
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1990-01-01");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9876543210");
		applicantDataBean.setOccupationType("SALR");
		offerApiRequest.setProductCode("SALR");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataBean.setProductCode("CC");
		
		doReturn(popOfferResponse).doThrow(new RuntimeException()).doThrow(new RuntimeException())
			.doThrow(new RuntimeException()).doThrow(new RuntimeException()).when(creditBusinessHelper)
				.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), 
						Mockito.any(), Mockito.any(), Mockito.any());
		
		rblIntDataSource.initDataSource(applicantDataBean);
	}
	
	@Test
	public void initDataSourceTest_NullScenerio() {
		ResponseEntity<Object> popOfferResponse = new ResponseEntity<Object>(new ResponseBean(popBFDLProspectOfferDetail()), 
				HttpStatus.OK);
		ResponseEntity<Object> popOfferSrcKey = new ResponseEntity<Object>(popOfferSource(), HttpStatus.OK);
		
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1990-01-01");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9876543210");
		applicantDataBean.setOccupationType("SALR");
		offerApiRequest.setProductCode("SALR");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataBean.setProductCode("CC");
		
		doReturn(popOfferResponse).doReturn(popOfferSrcKey).doReturn(null).doReturn(null)
			.doReturn(null).when(creditBusinessHelper).invokeRestEndpoint(Mockito.any(), 
				Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
		rblIntDataSource.initDataSource(applicantDataBean);
	}
	
	@Test
	public void initDataSourceTest_OfferException() {
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1990-01-01");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9876543210");
		applicantDataBean.setOccupationType("SALR");
		offerApiRequest.setProductCode("SALR");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataBean.setProductCode("CC");
		
		doThrow(new RuntimeException()).doThrow(new RuntimeException()).doThrow(new RuntimeException())
			.doThrow(new RuntimeException()).doThrow(new RuntimeException()).when(creditBusinessHelper)
			.invokeRestEndpoint(Mockito.any(), Mockito.any(), Mockito.any(), 
					Mockito.any(), Mockito.any(), Mockito.any());
		rblIntDataSource.initDataSource(applicantDataBean);
	}
	
	private BFDLProspectDetails popBFDLProspectOfferDetail() {
		BFDLProspectDetails prospectOfferDetail = new BFDLProspectDetails();
		prospectOfferDetail.setName("Harish");
		prospectOfferDetail.setMiddleName("Prasad");
		prospectOfferDetail.setLastName("Dua");
		prospectOfferDetail.setEmail("harish@gmail.com");
		prospectOfferDetail.setCurrentAddressLine1("abc");
		prospectOfferDetail.setCurrentAddressLine2("bca");
		prospectOfferDetail.setCurrentAddressLine3("xyz");
		prospectOfferDetail.setZipcode("411014");
		prospectOfferDetail.setPan("CDEPO9987N");
		prospectOfferDetail.setMobileNumber("9876543210");
		prospectOfferDetail.setDob("1990-01-01");
		prospectOfferDetail.setEmploymentType("Salaried");
		prospectOfferDetail.setNameOfCompanyBusiness("Cognizant");
		prospectOfferDetail.setMaritalStatus("Single");
		prospectOfferDetail.setGender("Male");
		prospectOfferDetail.setIsCreditCardHolder("YES");
		prospectOfferDetail.setCardLimit("45000");
		
		return prospectOfferDetail;
	}
	
	private BFDLProspectDetails popBFDLProspectOfferDetailSEMP() {
		BFDLProspectDetails prospectOfferDetail = popBFDLProspectOfferDetail();
		prospectOfferDetail.setEmploymentType("Self-Employed Professional");
		
		return prospectOfferDetail;
	}
	
	private Object popOfferSource() {
		String offerSource = "{offersrckey: 1, offerCode: INTOFFTBL}";
		List<String> offerSourceRes = new ArrayList<>();
		offerSourceRes.add(offerSource);
		return offerSourceRes;
	}
	
	private List<MaritalStatus> popMaritalStat() {
		List<MaritalStatus> maritalStat = new ArrayList<>();
		MaritalStatus maritalStatus = new MaritalStatus();
		maritalStatus.setMaritalStatusCode("S");
		maritalStatus.setMaritalStatusKey(1l);
		maritalStatus.setMaritalStatusValue("Single");
		maritalStat.add(maritalStatus);
		return maritalStat;
	}
	
	private List<Gender> popGenderMas() {
		List<Gender> gen = new ArrayList<>();
		Gender gender = new Gender();
		gender.setGenderCode("M");
		gender.setGenderKey(1l);
		gender.setGenderValue("Male");
		gen.add(gender);
		return gen;
	}
	
	private LocationAddressBean popLocationAddressBean() {
		LocationAddressBean locationResponseBean = new LocationAddressBean();
		locationResponseBean.setCityId(12l);
		locationResponseBean.setStateId(123l);
		locationResponseBean.setPinId(123l);
		locationResponseBean.setCountryId(123l);
		return locationResponseBean;
	}

}