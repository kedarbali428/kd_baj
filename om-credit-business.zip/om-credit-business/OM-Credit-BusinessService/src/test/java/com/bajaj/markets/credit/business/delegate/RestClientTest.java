package com.bajaj.markets.credit.business.delegate;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.REQUEST_HEADERS;
import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.SKIP_API_EXCEPTION;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import org.activiti.engine.ActivitiException;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.ErrorBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessException;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;

@SpringBootConfiguration
@SpringBootTest
public class RestClientTest {
	
	@Mock
	CreditBusinessHelper creditBusinessHelper;

	@Mock
	BFLLoggerUtilExt logger;


	@Mock
	private CustomDefaultHeaders customDefaultHeaders;

	@Mock
	Environment env;

	@Mock
	private Expression requestURL;
	@Mock
	private Expression requestType;
	@Mock
	private Expression requestParams;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	RestClient client;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(client, "creditBusinessHelper", creditBusinessHelper);
	}

	@Test
	public void testPostExecute() {
		HashMap<String, String> headersToUpdate = new HashMap<String, String>();
		headersToUpdate.put("utm_source", "utm_soucre");
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("POST");
		when(requestParams.getValue(execution)).thenReturn("applicationid=1;userattributekey=2");
		when(execution.getVariable(REQUEST_HEADERS)).thenReturn(headersToUpdate);
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn("{}");
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		when(creditBusinessHelper.invokeRestEndpoint(Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
		.thenReturn(new ResponseEntity(HttpStatus.OK));
		client.execute(execution);
	}

	@Test
	public void testGetExecute() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("GET");
		when(requestParams.getValue(execution)).thenReturn("applicationid=1;userattributekey=2");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(null);
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		when(creditBusinessHelper.invokeRestEndpoint(Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ResponseEntity(new JSONObject(),HttpStatus.OK));

		client.execute(execution);
	}
	
	@Test
	public void testGetExecute_ex() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("GET");
		when(requestParams.getValue(execution)).thenReturn("applicationid=1;userattributekey=2");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(null);
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		Exception ex = new CreditBusinessException(HttpStatus.NOT_FOUND, "OMCA_151");
		when(creditBusinessHelper.invokeRestEndpoint(Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ex);
		
		client.execute(execution);
	}
	
	@Test
	public void testGetExecute_ex2() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("GET");
		when(requestParams.getValue(execution)).thenReturn("applicationid=1;ifscCode=HDFC00000546");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(null);
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		Exception ex = new CreditBusinessException(HttpStatus.NOT_FOUND, "OMEDS-1018");
		when(creditBusinessHelper.invokeRestEndpoint(Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ex);
		
		client.execute(execution);
	}
	
	@Test (expected = ActivitiException.class)
	public void testGetExecute_ex3() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("GET");
		when(requestParams.getValue(execution)).thenReturn("applicationid=1;ifscCode=HDFC00000546");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(null);
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		Exception ex = new CreditBusinessException(HttpStatus.NOT_FOUND, new ErrorBean("OMEDS-1018", "Error Message"));
		when(creditBusinessHelper.invokeRestEndpoint(Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ex);
		
		client.execute(execution);
	}
	
	@Test
	public void testGetExecute_notAcceptableError() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("POST");
		when(requestParams.getValue(execution)).thenReturn("applicationid=1");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(null);
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		Exception ex = new CreditBusinessException(HttpStatus.NOT_ACCEPTABLE, "OMVER_126");
		when(creditBusinessHelper.invokeRestEndpoint(Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ex);
		
		client.execute(execution);
	}
	
	@Test (expected = ActivitiException.class)
	public void testGetExecute_notAcceptableErrorElse() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("POST");
		when(requestParams.getValue(execution)).thenReturn("applicationid=1");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(null);
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		Exception ex = new CreditBusinessException(HttpStatus.NOT_ACCEPTABLE, new ErrorBean("errorCode", "errorMessage"));
		when(creditBusinessHelper.invokeRestEndpoint(Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ex);
		
		client.execute(execution);
	}
	
	@Test
	public void testGetExecute_ex4() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("GET");
		when(requestParams.getValue(execution)).thenReturn("principal=PaySense");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(null);
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		Exception ex = new CreditBusinessException(HttpStatus.NOT_FOUND, "PAYSENSELIB-001");
		when(creditBusinessHelper.invokeRestEndpoint(Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ex);
		
		client.execute(execution);
	}
	
	@Test
	public void testPostExecute_ExceptionSkip() {
		when(requestURL.getValue(execution)).thenReturn("");
		when(requestType.getValue(execution)).thenReturn("POST");
		when(requestParams.getValue(execution)).thenReturn("applicationid=1");
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(null);
		when(env.getProperty(Mockito.eq(""))).thenReturn("http://test.com");
		when(creditBusinessHelper.invokeRestEndpoint(Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(new CreditBusinessException());
		when(execution.getVariable(SKIP_API_EXCEPTION)).thenReturn(true);
		
		client.execute(execution);
	}

}
