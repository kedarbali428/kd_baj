package com.bajaj.markets.credit.business.helper;

import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;

@SpringBootConfiguration
@SpringBootTest
public class AsychRestHelperTest {

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	private RestTemplate restTemplate;

	@InjectMocks
	AsychRestHelper helper;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testInvokeAsynchRestEndpoint_withParams() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class), Mockito.eq(new HashMap<>())))
				.thenReturn(new ResponseEntity(HttpStatus.OK));
		helper.invokeAsynchRestEndpoint(HttpMethod.POST, "", Object.class, new HashMap<>(), "", new HttpHeaders(), new CustomDefaultHeaders());
	}

	@Test
	public void testInvokeAsynchRestEndpoint_withoutParams() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class)))
				.thenReturn(new ResponseEntity(HttpStatus.OK));
		helper.invokeAsynchRestEndpoint(HttpMethod.POST, "", Object.class, null, "", new HttpHeaders(), new CustomDefaultHeaders());
	}

	@Test
	public void testInvokeAsynchRestEndpoint_withEx() {
		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class), Mockito.eq(new HashMap<>())))
				.thenThrow(RestClientException.class);
		helper.invokeAsynchRestEndpoint(HttpMethod.POST, "", Object.class, new HashMap<>(), "", new HttpHeaders(), new CustomDefaultHeaders());

		when(restTemplate.exchange(Mockito.anyString(), Mockito.eq(HttpMethod.POST), Mockito.any(), Mockito.eq(Object.class), Mockito.eq(new HashMap<>())))
				.thenThrow(NullPointerException.class);
		helper.invokeAsynchRestEndpoint(HttpMethod.POST, "", Object.class, new HashMap<>(), "", new HttpHeaders(), new CustomDefaultHeaders());
	}

}
