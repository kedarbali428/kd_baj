package com.bajaj.markets.credit.business.listner;

import static com.bajaj.markets.credit.business.helper.CreditBusinessConstants.OUTPUT;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.impl.util.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.helper.CreditBusinessApiCallsHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.referencedataclientlib.bean.OccupationMaster;
import com.google.gson.Gson;

@SpringBootTest
public class KarzaTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	Karza listener;
	
	@Mock
	CreditBusinessApiCallsHelper apiCallsHelper;
	
	@Mock
	MasterDataRedisClientHelper masterDataRedisHelper;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testPreApi() {
		JSONObject req = new JSONObject();
		JSONObject name = new JSONObject();
		req.put(CreditBusinessConstants.WORKEMAILID, "abcd@cognizant.com");
		name.put("firstName","Test");
		name.put("middleName","Demo");
		name.put("lastName","Data");
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(req);
		when(execution.getVariable(CreditBusinessConstants.NAME)).thenReturn(name);
		listener.preApi(execution);

		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(null);
		
		listener.preApi(execution);
	}

	@Test
	public void testpostGetVerification() {
		ArrayList output = new ArrayList<>();
		output.add(new Object());
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(new JSONObject());
		listener.postGetVerification(execution);

		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(null);
		listener.postGetVerification(execution);

	}

	@Test
	public void testPreBre() {
		Gson g = new Gson();
		String verification = "{\"emailId\":null,\"applicationKey\":\"1100000000004044\",\"applicantKey\":\"120151\",\"l2ProductCode\":null,\"fulName\":\"prathamesh joshi\",\"employerName\":null,\"employerKid\":\"L65923PN2007PLC130075\",\"mobile\":\"9905190002\",\"employerScore\":null,\"nameConfidence\":null,\"settledFlag\":\"1\",\"recentFlag\":\"0\",\"uniqueFlag\":\"0\",\"nameExactFlag\":\"0\",\"status\":\"1\",\"karzaApproach\":\"2\",\"officialEmailDomain\":null,\"emailVerificationskipFlag\":null,\"verification\":{\"isVerified\":true,\"verificationSource\":\"KARZA\",\"verifiedFor\":\"\",\"verificationDate\":\"2020-05-19T12:25:00.150+0000\",\"verificationReference\":303},\"emailverificationchannel\":null}";
		when(execution.getVariable(CreditBusinessConstants.KARZA_VERIFICATION_RESPONSE)).thenReturn(verification);
		when(execution.getVariable(CreditBusinessConstants.KARZA_TYPE)).thenReturn("1");
		when(execution.getVariable(CreditBusinessConstants.OCCUPATION_TYPE_KEY)).thenReturn(1);
		when(masterDataRedisHelper.getOccupationByKey(Mockito.any())).thenReturn(new OccupationMaster());
		listener.preEmploymentVerificationBre(execution);
		
		when(execution.getVariable(CreditBusinessConstants.EMPRMASTCATEGORY)).thenReturn("test");
		when(execution.getVariable(CreditBusinessConstants.EMPRMASTSUBCATEGORY)).thenReturn("test");
		listener.preEmploymentVerificationBre(execution);

	}
	
	@Test
	public void testPostBre() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn("{\"occupationType\":\"Salaried\",\"branch\":null,\"emplrScore\":null,\"nameConfidence\":null,\"settledFlag\":null,\"recentFlag\":false,\"uniqueFlag\":false,\"officialEmailDomain\":null,\"creditVidyaStatus\":null,\"nameExactFlag\":false,\"karzaApproach\":\"2\",\"karzaId\":\"L65923PN2007PLC130075\",\"status\":1,\"companyCatogery\":null,\"companyType\":\"Unlisted\",\"karzaBreResponse\":{\"karzaVerificationOutput\":{\"employmentVerified\":null,\"creditReviewCode\":null,\"emailVerificationskipFlag\":null,\"rejectCode\":[{\"rejectCode\":\"LENRNC\",\"coolingPeriod\":0}]},\"action\":\"true\"}}");
		listener.postEmploymentVerificationBre(execution);
	}
	
	@Test
	public void testpreGetCreditVidyaDetails() {
		listener.preGetCreditVidyaDetails(execution);
	}
	
	@Test
	public void testpostGetCreditVidyaDetails() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn("{\"emailId\":\"abcd@cognizant.com\",\"applicationKey\":\"1100000000012440\",\"applicantKey\":null,\"validationstatus\":\"Medium Risk\",\"l2ProductKey\":\"10002\",\"fullName\":\"Prathamesh Joshi\",\"city\":\"PUNE\",\"mobileNumber\":\"9909010002\",\"dob\":\"1990-12-03 00:00:00.0\",\"salary\":null,\"verification\":{\"isVerified\":true,\"verificationSource\":\"CREDIT_VIDYA\",\"verifiedFor\":\"EMAIL_DOMAIN\",\"verificationDate\":\"2020-09-01T08:41:28.689+0000\",\"verificationReference\":6578},\"companyName\":null}");
		listener.postGetCreditVidyaDetails(execution);
	}
	
	@Test
	public void testsetDefaultFlags() {
		listener.setDefaultFlags(execution);
	}
	
	@Test
	public void testPreCreditVidya() {
		org.json.simple.JSONObject userProfile = new org.json.simple.JSONObject();
		org.json.simple.JSONObject name = new org.json.simple.JSONObject();
		userProfile.put(CreditBusinessConstants.NAME, name);
		when(execution.getVariable(CreditBusinessConstants.PARENT_APPLICATION_KEY)).thenReturn("1");
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("1");
		when(execution.getVariable(CreditBusinessConstants.USERPROFILEOUTPUT)).thenReturn(userProfile);
		when(apiCallsHelper.getAddress(Mockito.any(), Mockito.any())).thenReturn(new Address());
		listener.preCreditVidya(execution);
	}

	@Test
	public void testPostCreditVidya() {
		listener.postCreditVidya(execution);
	}
	
	@Test
	public void testPreEmailVerificationUpdate() {
		Gson g = new Gson();
		Object output = g.fromJson("{\r\n" + "\"emailId\": \"P@gmail.com\",\r\n" + "\"applicationKey\": \"12345\",\r\n"
				+ "\"applicantKey\": \"1100000000001987\",\r\n" + "\"validationstatus\": \"High Risk\",\r\n" + "\"l2ProductKey\": \"10001\",\r\n"
				+ "\"fullName\": \"abcd abcd abcd\",\r\n" + "\"city\": \"Pune\",\r\n" + "\"mobileNumber\": \"9898989898\",\r\n" + "\"dob\": \"01-01-1992\",\r\n"
				+ "\"salary\": null,\r\n" + "\"verification\":\r\n" + "\r\n"
				+ "{ \"isVerified\": true, \"verificationSource\": \"CREDIT_VIDYA\", \"verifiedFor\": \"OFFICIAL_EMAIL\", \"verificationDate\": \"2020-05-25T09:55:56.034+0000\", \"verificationReference\": 664 }\r\n"
				+ ",\r\n" + "\"companyName\": null\r\n" + "}", JSONObject.class);
		when(execution.getVariable("creditVidyaResponse")).thenReturn(output);
		listener.preEmailVerificationUpdate(execution);
	}
	
	@Test
	public void testCheckDomain() {
		org.json.simple.JSONObject output = new org.json.simple.JSONObject();
		org.json.simple.JSONObject payload = new org.json.simple.JSONObject();
		payload.put("statusFlag", true);
		output.put("payload", payload);
		
		when(execution.getVariable(OUTPUT)).thenReturn(output);
		listener.checkDomain(execution);
	}

}
