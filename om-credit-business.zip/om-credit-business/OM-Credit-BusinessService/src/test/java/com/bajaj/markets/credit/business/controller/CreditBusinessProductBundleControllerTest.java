package com.bajaj.markets.credit.business.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ApplicationResponse;
import com.bajaj.markets.credit.business.beans.FppBundleBean;
import com.bajaj.markets.credit.business.service.CreditBusinessProductBundleService;


@SpringBootTest
public class CreditBusinessProductBundleControllerTest {

	@InjectMocks
	CreditBusinessProductBundleController controller;

	@Mock
	private CreditBusinessProductBundleService service;

	private Validator validator;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	Environment env;

	private MockMvc mockMvc;

	private String bundleGetUrl = null;
	private String bundlePostUrl = null;
	private String bundleRejectUrl = null;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(controller)
				.addPlaceholderValue("api.omcreditbusinessservice.bundle.fpp.GET.uri", "/v1/credit/applications/{applicationid}/bundle/fpp")
				.addPlaceholderValue("api.omcreditbusinessservice.bundle.fpp.POST.uri","/v1/credit/applications/{applicationid}/bundle/fpp")
				.addPlaceholderValue("api.omcreditbusinessservice.bundle.reject.POST.uri","/v1/creditapplications/{applicationid}/bundle/reject")
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();
		validator = Validation.buildDefaultValidatorFactory().getValidator();
		ReflectionTestUtils.setField(controller, "validator", validator);
		bundleGetUrl = "/v1/credit/applications/{applicationid}/bundle/fpp";
		bundlePostUrl = "/v1/credit/applications/{applicationid}/bundle/fpp";
		bundleRejectUrl = "/v1/creditapplications/{applicationid}/bundle/reject";
	}

	@Test
	public void testFetchFppBundle_success() throws Exception {
		Mockito.when(service.fetchFppBundle(Mockito.any(), Mockito.any())).thenReturn(new FppBundleBean());
		mockMvc.perform(get(bundleGetUrl, 1100000000429L).contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void testFetchFppBundle_validationFailure() throws Exception {
		mockMvc.perform(get(bundleGetUrl, "abcd").contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isBadRequest());
	}

	@Test
	public void testsaveFppBundle_success() throws Exception {
		String str = "{\"action\":\"Next\",\"isFppSelected\":true,\"bundleData\":{\"nomineeDetails\":[{\"dateOfBirth\":\"1990-01-02\",\"name\":\"kjkkjkjb\",\"relationcodemastkey\":null,\"relationship\":{\"key\":6,\"code\":\"6\",\"value\":\"Brother\"}}],\"applicationId\":\"1100000000103508\",\"l3ProductKey\":138,\"l3ProductCode\":\"BFLSOLFLDG\",\"genderRequired\":false,\"gender\":null,\"openArcFppOutput\":{\"planCode\":\"FPP\",\"planName\":\"FinservProtectionPlan\",\"planFriendlyName\":\"FinservProtectionPlan\",\"planType\":\"RETAIL\",\"withFppSaveRoi\":0.4,\"withFppRoi\":20.200000000000003,\"withoutFppRoi\":20.6,\"withFppSavingAmount\":1540,\"floorPriceWithGST\":3312,\"actualFppPriceWithGST\":4140,\"oldProfit\":982,\"fppCostPrice\":1276,\"products\":[{\"productCode\":\"GCPP\",\"productName\":\"GroupCreditProtectionPlan\",\"productUserFriendlyName\":\"GroupCreditProtectionPlan\",\"productType\":\"INS\",\"premiumWithGst\":556,\"costWithGst\":0,\"premiumWithoutGST\":471,\"sumAssured\":120000,\"tenure\":48,\"pv\":0,\"riders\":[]},{\"productCode\":\"GPGP\",\"productName\":\"GroupPersonalAccidentPlan\",\"productUserFriendlyName\":\"GroupPersonalAccidentPlan\",\"productType\":\"INS\",\"premiumWithGst\":250,\"costWithGst\":0,\"premiumWithoutGST\":212,\"sumAssured\":2500000,\"tenure\":12,\"pv\":0,\"riders\":[{\"riderCode\":\"GPGPPPD\",\"riderDescription\":\"PermanentPartialDisability\",\"riderUserFriendlyName\":\"PermanentPartialDisability\",\"sumAssured\":1000000,\"premiumAmount\":0,\"tenure\":12},{\"riderCode\":\"GPGPPTD\",\"riderDescription\":\"PermanentTotalDisability\",\"riderUserFriendlyName\":\"PermanentTotalDisability\",\"sumAssured\":1000000,\"premiumAmount\":0,\"tenure\":12},{\"riderCode\":\"GPGPCAAC\",\"riderDescription\":\"AirAmbulanceCover\",\"riderUserFriendlyName\":\"AirAmbulanceCover\",\"sumAssured\":500000,\"premiumAmount\":0,\"tenure\":12},{\"riderCode\":\"GPGPEMIPB\",\"riderDescription\":\"EmiPaymentCover\",\"riderUserFriendlyName\":\"EmiPaymentCover\",\"sumAssured\":200000,\"premiumAmount\":0,\"tenure\":12},{\"riderCode\":\"GPGPRABC\",\"riderDescription\":\"RoadAmbulanceCover\",\"riderUserFriendlyName\":\"RoadAmbulanceCover\",\"sumAssured\":25000,\"premiumAmount\":0,\"tenure\":12}]},{\"productCode\":\"DigitalGold\",\"productName\":\"Goldback\",\"productUserFriendlyName\":\"Goldback\",\"productType\":\"VAS\",\"premiumWithGst\":51,\"costWithGst\":51,\"premiumWithoutGST\":null,\"sumAssured\":51,\"tenure\":0,\"pv\":0,\"riders\":[]},{\"productCode\":\"BFDL_FPP_FAMILY_V2-1YR\",\"productName\":\"FamilyHealthVouchers(1Year)\",\"productUserFriendlyName\":\"FamilyHealthVouchers(1Year)\",\"productType\":\"VAS\",\"premiumWithGst\":699,\"costWithGst\":0,\"premiumWithoutGST\":592,\"sumAssured\":0,\"tenure\":12,\"pv\":12100,\"riders\":[]}]},\"questionAnswerList\":[{\"questionKey\":26,\"questionCode\":\"QA26\",\"questionString\":\"Ihaveneverhad/currentlyhaveanydisorderofheart/circulatorysystem/bloodpressure/stroke/asthma/lung/cancer/tumor/diabetes/hepatitis/liver/digestivetract/urinary/kidney/depression/mental/psychiatric/epilepsy/HIVpositivetest/brain/nervoussystem/blood/musculoskeletal/anydisabilityMeormyfamilymembershavenottestedpositiveforCovid19inlast3months/nothavebeenself-isolatedwithsymptomsonmedicaladvice/advisedtoundergo,repeatorawaitingCovid19test/nocurrentlyorinthepast1monthhavesymptomslikepersistentcough,breathlessness,fever,raisedtemperature/notbeenincontactwithanindividualsuspectedorquarantinedorconfirmedtohaveCOVID-19orSARScov-2/ornotmeorimmediatefamilymembersoccupationrequireme/themtocomeinclosecontactwithCovid-19patientsorwithcoronaviruscontaminatedmaterial?MeormyimmediatefamilymembershavenottravelledorplanstotraveloutsideIndiafornext6months.Ihavenotbeenhospitalizedformorethan5daysinpast(exceptpregnancy)/neverhadanysymptomspersistingmorethan7days/notbeenabsentfromworkforanyillness/injury/disabilityformorethan10daysinlast3yrs.\",\"visibleToUiFlag\":true,\"appQuestionResponseKey\":248299,\"userResponse\":\"Yes\"},{\"questionKey\":1,\"questionCode\":\"QA1\",\"questionString\":\"Ihaveneverhad/currentlyhaveanyExistingDisabilityorInfirmity\",\"visibleToUiFlag\":true,\"appQuestionResponseKey\":248301,\"userResponse\":\"Yes\"}],\"fppAttributeAtributes\":{\"height\":180,\"weight\":76},\"pricingMap\":{\"RIDER_GPGPEMIPB\":200000,\"PRODUCT_DigitalGold\":51,\"PRODUCT_VHEALTH\":12100,\"RIDER_GPGPRABC\":25000,\"PRODUCT_GPGP\":0,\"PRODUCT_GCPP\":120000,\"RIDER_GPGPPTD\":1000000,\"RIDER_GPGPCAAC\":500000,\"RIDER_GPGPPPD\":1000000}},\"fppAttributeAtributes\":{\"height\":180,\"weight\":76},\"questionAnswerList\":[{\"questionKey\":1,\"questionCode\":\"QA1\",\"userResponse\":\"Yes\"},{\"questionKey\":26,\"questionCode\":\"QA26\",\"userResponse\":\"Yes\"}]}";		
		Mockito.when(service.fetchFppBundle(Mockito.any(), Mockito.any())).thenReturn(new FppBundleBean());
		mockMvc.perform(post(bundlePostUrl, 1100000000429L).content(str).contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isCreated());
	}

	@Test
	public void testsaveFppBundle_422() throws Exception {
		String str = "{\"isFppSelected\":true,\"bundleData\":{\"l3ProductKey\":10,\"l3ProductCode\":\"BFLSOL\",\"openArcFppOutput\":{\"planCode\":null,\"planName\":\"Finserv Protection Plan\",\"planFriendlyName\":\"Finserv Protection Plan\",\"planType\":\"RETAIL\",\"withFppSaveRoi\":0.4,\"withFppRoi\":14.25,\"withFppSavingAmount\":1251,\"floorPriceWithGST\":3720,\"actualFppPriceWithGST\":4463,\"oldProfit\":762,\"fppCostPrice\":null,\"products\":[{\"productCode\":\"GCPP\",\"productName\":\"Group Credit Protection Plan\",\"productUserFriendlyName\":\"Group Credit Protection Plan\",\"productType\":\"INS\",\"premiumWithGst\":539,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":60,\"pv\":0,\"riders\":[{\"riderCode\":\"GCPP\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"GPGP\",\"productName\":\"Group Personal Accident Plan\",\"productUserFriendlyName\":\"Group Personal Accident Plan\",\"productType\":\"INS\",\"premiumWithGst\":250,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":12,\"pv\":0,\"riders\":[{\"riderCode\":\"GPGPPPD\",\"riderDescription\":\"Permanent Partial Disability\",\"riderUserFriendlyName\":\"Permanent Partial Disability\",\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPPTD\",\"riderDescription\":\"Permanent Total Disability\",\"riderUserFriendlyName\":\"Permanent Total Disability\",\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPEMIPB\",\"riderDescription\":\"Emi Payment Cover\",\"riderUserFriendlyName\":\"Emi Payment Cover\",\"sumAssured\":200000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPRABC\",\"riderDescription\":\"Road Ambulance Cover\",\"riderUserFriendlyName\":\"Road Ambulance Cover\",\"sumAssured\":25000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPCAAC\",\"riderDescription\":\"Air Ambulance Cover\",\"riderUserFriendlyName\":\"Air Ambulance Cover\",\"sumAssured\":500000,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"BFDL_FPP_FAMILY_V2 - 1YR\",\"productName\":\"Family Health Vouchers (1 Year)\",\"productUserFriendlyName\":\"Family Health Vouchers (1 Year)\",\"productType\":\"VAS\",\"premiumWithGst\":699,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":12,\"pv\":12,\"riders\":[{\"riderCode\":\"\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":0,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"Digital Gold\",\"productName\":\"Gold back\",\"productUserFriendlyName\":\"Gold back\",\"productType\":\"VAS\",\"premiumWithGst\":0,\"costWithGst\":51,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":0,\"pv\":0,\"riders\":[{\"riderCode\":\"\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":0,\"premiumAmount\":0,\"tenure\":0}]}]}},\"fppAttributeAtributes\":{\"height\":170.1,\"weight\":72.7},\"questionAnswerList\":[{\"questionKey\":1,\"questionCode\":\"QA1\",\"questionString\":\"I have never had/currently have any Existing Disability or Infirmity\",\"visibleToUiFlag\":true,\"userResponse\":\"Yes\"},{\"questionKey\":2,\"questionCode\":\"QA2\",\"questionString\":\"I have never had/currently have any disorder of heart/circulatory system/blood pressure/stoke/astama/lung/cancer/tumour/diabetes/hepatitis/liver/digestive tract/urinary/kidney/depression/mental/psychiatric/epilepsy/HIV positive test/brain/nervous system/blood/musculoskeletal/any disability. I have never had symptoms persisting more than 7 days nor been absent from work for any illness/injury/disbility more than 10 days in last 3yrs\",\"visibleToUiFlag\":true,\"userResponse\":\"Yes\"},{\"questionKey\":4,\"questionCode\":\"QA4\",\"questionString\":\"Are you pregnant? If Yes  please state the expected date of delivery\",\"visibleToUiFlag\":true,\"userResponse\":\"No\"}]}";
		Mockito.when(service.fetchFppBundle(Mockito.any(), Mockito.any())).thenReturn(new FppBundleBean());
		mockMvc.perform(post(bundlePostUrl, 1100000000429L).content(str).contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isUnprocessableEntity());
	}

	@Test
	public void testBundleReject() throws Exception {
		String str = "{\"action\":\"back\"}";
		Mockito.when(service.rejectBundle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ApplicationResponse());
		mockMvc.perform(post(bundleRejectUrl, 1100000000429L).content(str).contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isCreated());
	}

}
