package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.bajaj.markets.credit.business.helper.VasAppStatusEnum;
import com.google.gson.Gson;

@SpringBootTest
public class FppTest {

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	private CustomDefaultHeaders customDefaultHeaders;

	@Mock
	DelegateExecution execution;
	@InjectMocks
	Application applicationListener;
	@InjectMocks
	Fpp listener;
	
	@Mock
	MasterDataRedisClientHelper redisHelper;
	
	@Mock
	CreditBusinessGinHelper ginHelper;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(listener, "applicationListener", applicationListener);
	}

	@Test
	public void testpreVasApplicationCreate() {
		Gson g = new Gson();
		Object userProfile = g.fromJson(
				"{\"applicationKey\":\"1100000000006221\",\"applicationUserAttributeKey\":\"5685\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"9906100004\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"prathamesh\",\"middleName\":\"\",\"lastName\":\"joshi\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":28,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":null}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.USERPROFILEOUTPUT)).thenReturn(userProfile);

		Object req = g.fromJson(
				"{\"isFppSelected\":true,\"bundleData\":{\"l3ProductKey\":10,\"l3ProductCode\":\"BFLSOL\",\"openArcFppOutput\":{\"planCode\":\"FPP\",\"planName\":\"Finserv Protection Plan\",\"planFriendlyName\":\"Finserv Protection Plan\",\"planType\":\"RETAIL\",\"withFppSaveRoi\":0.4,\"withFppRoi\":14.25,\"withFppSavingAmount\":1251,\"floorPriceWithGST\":3720,\"actualFppPriceWithGST\":4463,\"oldProfit\":762,\"fppCostPrice\":null,\"products\":[{\"productCode\":\"GCPP\",\"productName\":\"Group Credit Protection Plan\",\"productUserFriendlyName\":\"Group Credit Protection Plan\",\"productType\":\"INS\",\"premiumWithGst\":539,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":60,\"pv\":0,\"riders\":[{\"riderCode\":\"GCPP\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"GPGP\",\"productName\":\"Group Personal Accident Plan\",\"productUserFriendlyName\":\"Group Personal Accident Plan\",\"productType\":\"INS\",\"premiumWithGst\":250,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":12,\"pv\":0,\"riders\":[{\"riderCode\":\"GPGPPPD\",\"riderDescription\":\"Permanent Partial Disability\",\"riderUserFriendlyName\":\"Permanent Partial Disability\",\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPPTD\",\"riderDescription\":\"Permanent Total Disability\",\"riderUserFriendlyName\":\"Permanent Total Disability\",\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPEMIPB\",\"riderDescription\":\"Emi Payment Cover\",\"riderUserFriendlyName\":\"Emi Payment Cover\",\"sumAssured\":200000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPRABC\",\"riderDescription\":\"Road Ambulance Cover\",\"riderUserFriendlyName\":\"Road Ambulance Cover\",\"sumAssured\":25000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPCAAC\",\"riderDescription\":\"Air Ambulance Cover\",\"riderUserFriendlyName\":\"Air Ambulance Cover\",\"sumAssured\":500000,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"BFDL_FPP_FAMILY_V2 - 1YR\",\"productName\":\"Family Health Vouchers (1 Year)\",\"productUserFriendlyName\":\"Family Health Vouchers (1 Year)\",\"productType\":\"VAS\",\"premiumWithGst\":699,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":12,\"pv\":12,\"riders\":[{\"riderCode\":\"\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":0,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"Digital Gold\",\"productName\":\"Gold back\",\"productUserFriendlyName\":\"Gold back\",\"productType\":\"VAS\",\"premiumWithGst\":0,\"costWithGst\":51,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":0,\"pv\":0,\"riders\":[{\"riderCode\":\"\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":0,\"premiumAmount\":0,\"tenure\":0}]}]}},\"fppAttributeAtributes\":{\"height\":170.1,\"weight\":72.7},\"questionAnswerList\":[{\"questionKey\":1,\"questionCode\":\"QA1\",\"questionString\":\"I have never had/currently have any Existing Disability or Infirmity\",\"visibleToUiFlag\":true,\"userResponse\":\"Yes\"},{\"questionKey\":2,\"questionCode\":\"QA2\",\"questionString\":\"I have never had/currently have any disorder of heart/circulatory system/blood pressure/stoke/astama/lung/cancer/tumour/diabetes/hepatitis/liver/digestive tract/urinary/kidney/depression/mental/psychiatric/epilepsy/HIV positive test/brain/nervous system/blood/musculoskeletal/any disability. I have never had symptoms persisting more than 7 days nor been absent from work for any illness/injury/disbility more than 10 days in last 3yrs\",\"visibleToUiFlag\":true,\"userResponse\":\"Yes\"},{\"questionKey\":4,\"questionCode\":\"QA4\",\"questionString\":\"Are you pregnant? If Yes  please state the expected date of delivery\",\"visibleToUiFlag\":true,\"userResponse\":\"No\"}]}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(req);
		when(redisHelper.getGenderReferenceByTypeKey(Mockito.any())).thenReturn(new Reference());
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_RESUME)).thenReturn(new JSONObject());
		when(execution.getVariable(CreditBusinessConstants.BUNDLEPRESENT)).thenReturn(true);
		when(execution.getVariable(CreditBusinessConstants.VAS_APPLICATION_KEY)).thenReturn("1234");
		listener.preVasApplicationCreate(execution);
	}

	@Test
	public void testpostVasApplicationCreate() {
		Gson g = new Gson();
		Object output = g.fromJson(
				"{\"applicationKey\":2200000000000073,\"applicantKey\":null,\"gender\":\"M\",\"mobileNumber\":\"9906100004\",\"sourceApplicationKey\":\"1100000000006221\",\"name\":{\"firstName\":\"prathamesh\",\"lastName\":\"joshi\",\"middleName\":\"\"},\"fppPlanCode\":\"FPP\",\"planKey\":null,\"dateOfBirth\":\"1990-12-12\",\"products\":[{\"productCode\":\"GCPP\",\"productName\":\"Group Credit Protection Plan\",\"productKey\":0,\"premiumWithGst\":539.0,\"sumAssured\":0.0,\"riders\":[],\"costWithGst\":0.0,\"premiumwithoutgst\":0.0,\"perceivedvalue\":0.0,\"tenure\":60},{\"productCode\":\"GPGP\",\"productName\":\"Group Personal Accident Plan\",\"productKey\":0,\"premiumWithGst\":250.0,\"sumAssured\":0.0,\"riders\":[{\"sumAssured\":100000.0,\"premiumAmmount\":0.0,\"riderCode\":\"GPGPPPD\",\"riderName\":\"Permanent Partial Disability\",\"riderKey\":null,\"tenure\":0},{\"sumAssured\":100000.0,\"premiumAmmount\":0.0,\"riderCode\":\"GPGPPTD\",\"riderName\":\"Permanent Total Disability\",\"riderKey\":null,\"tenure\":0},{\"sumAssured\":200000.0,\"premiumAmmount\":0.0,\"riderCode\":\"GPGPEMIPB\",\"riderName\":\"Emi Payment Cover\",\"riderKey\":null,\"tenure\":0},{\"sumAssured\":25000.0,\"premiumAmmount\":0.0,\"riderCode\":\"GPGPRABC\",\"riderName\":\"Road Ambulance Cover\",\"riderKey\":null,\"tenure\":0},{\"sumAssured\":500000.0,\"premiumAmmount\":0.0,\"riderCode\":\"GPGPCAAC\",\"riderName\":\"Air Ambulance Cover\",\"riderKey\":null,\"tenure\":0}],\"costWithGst\":0.0,\"premiumwithoutgst\":0.0,\"perceivedvalue\":0.0,\"tenure\":12},{\"productCode\":\"BFDL_FPP_FAMILY_V2 - 1YR\",\"productName\":\"Family Health Vouchers (1 Year)\",\"productKey\":0,\"premiumWithGst\":699.0,\"sumAssured\":0.0,\"riders\":[],\"costWithGst\":0.0,\"premiumwithoutgst\":0.0,\"perceivedvalue\":12.0,\"tenure\":12},{\"productCode\":\"Digital Gold\",\"productName\":\"Gold back\",\"productKey\":0,\"premiumWithGst\":0.0,\"sumAssured\":0.0,\"riders\":[],\"costWithGst\":51.0,\"premiumwithoutgst\":0.0,\"perceivedvalue\":0.0,\"tenure\":0}],\"sourceProductCategoryKey\":null,\"sourceProductMasterKey\":null} ",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		listener.postVasApplicationCreate(execution);
	}

	@Test
	public void testpreVasCostSave() {
		Gson g = new Gson();
		Object req = g.fromJson(
				"{\"isFppSelected\":true,\"bundleData\":{\"l3ProductKey\":10,\"l3ProductCode\":\"BFLSOL\",\"openArcFppOutput\":{\"planCode\":\"FPP\",\"planName\":\"Finserv Protection Plan\",\"planFriendlyName\":\"Finserv Protection Plan\",\"planType\":\"RETAIL\",\"withFppSaveRoi\":0.4,\"withFppRoi\":14.25,\"withFppSavingAmount\":1251,\"floorPriceWithGST\":3720,\"actualFppPriceWithGST\":4463,\"oldProfit\":762,\"fppCostPrice\":null,\"products\":[{\"productCode\":\"GCPP\",\"productName\":\"Group Credit Protection Plan\",\"productUserFriendlyName\":\"Group Credit Protection Plan\",\"productType\":\"INS\",\"premiumWithGst\":539,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":60,\"pv\":0,\"riders\":[{\"riderCode\":\"GCPP\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"GPGP\",\"productName\":\"Group Personal Accident Plan\",\"productUserFriendlyName\":\"Group Personal Accident Plan\",\"productType\":\"INS\",\"premiumWithGst\":250,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":12,\"pv\":0,\"riders\":[{\"riderCode\":\"GPGPPPD\",\"riderDescription\":\"Permanent Partial Disability\",\"riderUserFriendlyName\":\"Permanent Partial Disability\",\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPPTD\",\"riderDescription\":\"Permanent Total Disability\",\"riderUserFriendlyName\":\"Permanent Total Disability\",\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPEMIPB\",\"riderDescription\":\"Emi Payment Cover\",\"riderUserFriendlyName\":\"Emi Payment Cover\",\"sumAssured\":200000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPRABC\",\"riderDescription\":\"Road Ambulance Cover\",\"riderUserFriendlyName\":\"Road Ambulance Cover\",\"sumAssured\":25000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPCAAC\",\"riderDescription\":\"Air Ambulance Cover\",\"riderUserFriendlyName\":\"Air Ambulance Cover\",\"sumAssured\":500000,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"BFDL_FPP_FAMILY_V2 - 1YR\",\"productName\":\"Family Health Vouchers (1 Year)\",\"productUserFriendlyName\":\"Family Health Vouchers (1 Year)\",\"productType\":\"VAS\",\"premiumWithGst\":699,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":12,\"pv\":12,\"riders\":[{\"riderCode\":\"\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":0,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"Digital Gold\",\"productName\":\"Gold back\",\"productUserFriendlyName\":\"Gold back\",\"productType\":\"VAS\",\"premiumWithGst\":0,\"costWithGst\":51,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":0,\"pv\":0,\"riders\":[{\"riderCode\":\"\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":0,\"premiumAmount\":0,\"tenure\":0}]}]}},\"fppAttributeAtributes\":{\"height\":170.1,\"weight\":72.7},\"questionAnswerList\":[{\"questionKey\":1,\"questionCode\":\"QA1\",\"questionString\":\"I have never had/currently have any Existing Disability or Infirmity\",\"visibleToUiFlag\":true,\"userResponse\":\"Yes\"},{\"questionKey\":2,\"questionCode\":\"QA2\",\"questionString\":\"I have never had/currently have any disorder of heart/circulatory system/blood pressure/stoke/astama/lung/cancer/tumour/diabetes/hepatitis/liver/digestive tract/urinary/kidney/depression/mental/psychiatric/epilepsy/HIV positive test/brain/nervous system/blood/musculoskeletal/any disability. I have never had symptoms persisting more than 7 days nor been absent from work for any illness/injury/disbility more than 10 days in last 3yrs\",\"visibleToUiFlag\":true,\"userResponse\":\"Yes\"},{\"questionKey\":4,\"questionCode\":\"QA4\",\"questionString\":\"Are you pregnant? If Yes  please state the expected date of delivery\",\"visibleToUiFlag\":true,\"userResponse\":\"No\"}]}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(req);
		listener.preVasCostSave(execution);
	}

	@Test
	public void testPostVasCostSave() {
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(new Object());
		listener.postVasCostSave(execution);
	}

	@Test
	public void testpreSaveQuestions() {
		Gson g = new Gson();
		Object req = g.fromJson(
				"{\"isFppSelected\":true,\"bundleData\":{\"l3ProductKey\":10,\"l3ProductCode\":\"BFLSOL\",\"openArcFppOutput\":{\"planCode\":\"FPP\",\"planName\":\"Finserv Protection Plan\",\"planFriendlyName\":\"Finserv Protection Plan\",\"planType\":\"RETAIL\",\"withFppSaveRoi\":0.4,\"withFppRoi\":14.25,\"withFppSavingAmount\":1251,\"floorPriceWithGST\":3720,\"actualFppPriceWithGST\":4463,\"oldProfit\":762,\"fppCostPrice\":null,\"products\":[{\"productCode\":\"GCPP\",\"productName\":\"Group Credit Protection Plan\",\"productUserFriendlyName\":\"Group Credit Protection Plan\",\"productType\":\"INS\",\"premiumWithGst\":539,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":60,\"pv\":0,\"riders\":[{\"riderCode\":\"GCPP\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"GPGP\",\"productName\":\"Group Personal Accident Plan\",\"productUserFriendlyName\":\"Group Personal Accident Plan\",\"productType\":\"INS\",\"premiumWithGst\":250,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":12,\"pv\":0,\"riders\":[{\"riderCode\":\"GPGPPPD\",\"riderDescription\":\"Permanent Partial Disability\",\"riderUserFriendlyName\":\"Permanent Partial Disability\",\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPPTD\",\"riderDescription\":\"Permanent Total Disability\",\"riderUserFriendlyName\":\"Permanent Total Disability\",\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPEMIPB\",\"riderDescription\":\"Emi Payment Cover\",\"riderUserFriendlyName\":\"Emi Payment Cover\",\"sumAssured\":200000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPRABC\",\"riderDescription\":\"Road Ambulance Cover\",\"riderUserFriendlyName\":\"Road Ambulance Cover\",\"sumAssured\":25000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPCAAC\",\"riderDescription\":\"Air Ambulance Cover\",\"riderUserFriendlyName\":\"Air Ambulance Cover\",\"sumAssured\":500000,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"BFDL_FPP_FAMILY_V2 - 1YR\",\"productName\":\"Family Health Vouchers (1 Year)\",\"productUserFriendlyName\":\"Family Health Vouchers (1 Year)\",\"productType\":\"VAS\",\"premiumWithGst\":699,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":12,\"pv\":12,\"riders\":[{\"riderCode\":\"\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":0,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"Digital Gold\",\"productName\":\"Gold back\",\"productUserFriendlyName\":\"Gold back\",\"productType\":\"VAS\",\"premiumWithGst\":0,\"costWithGst\":51,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":0,\"pv\":0,\"riders\":[{\"riderCode\":\"\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":0,\"premiumAmount\":0,\"tenure\":0}]}]}},\"fppAttributeAtributes\":{\"height\":170.1,\"weight\":72.7},\"questionAnswerList\":[{\"questionKey\":1,\"questionCode\":\"QA1\",\"questionString\":\"I have never had/currently have any Existing Disability or Infirmity\",\"visibleToUiFlag\":true,\"userResponse\":\"Yes\"},{\"questionKey\":2,\"questionCode\":\"QA2\",\"questionString\":\"I have never had/currently have any disorder of heart/circulatory system/blood pressure/stoke/astama/lung/cancer/tumour/diabetes/hepatitis/liver/digestive tract/urinary/kidney/depression/mental/psychiatric/epilepsy/HIV positive test/brain/nervous system/blood/musculoskeletal/any disability. I have never had symptoms persisting more than 7 days nor been absent from work for any illness/injury/disbility more than 10 days in last 3yrs\",\"visibleToUiFlag\":true,\"userResponse\":\"Yes\"},{\"questionKey\":4,\"questionCode\":\"QA4\",\"questionString\":\"Are you pregnant? If Yes  please state the expected date of delivery\",\"visibleToUiFlag\":true,\"userResponse\":\"No\"}]}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(req);
		listener.preSaveQuestions(execution);
	}

	@Test
	public void testprePiData() {
		Gson g = new Gson();
		Object req = g.fromJson(
				"{\"isFppSelected\":true,\"bundleData\":{\"l3ProductKey\":10,\"l3ProductCode\":\"BFLSOL\",\"openArcFppOutput\":{\"planCode\":\"FPP\",\"planName\":\"Finserv Protection Plan\",\"planFriendlyName\":\"Finserv Protection Plan\",\"planType\":\"RETAIL\",\"withFppSaveRoi\":0.4,\"withFppRoi\":14.25,\"withFppSavingAmount\":1251,\"floorPriceWithGST\":3720,\"actualFppPriceWithGST\":4463,\"oldProfit\":762,\"fppCostPrice\":null,\"products\":[{\"productCode\":\"GCPP\",\"productName\":\"Group Credit Protection Plan\",\"productUserFriendlyName\":\"Group Credit Protection Plan\",\"productType\":\"INS\",\"premiumWithGst\":539,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":60,\"pv\":0,\"riders\":[{\"riderCode\":\"GCPP\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"GPGP\",\"productName\":\"Group Personal Accident Plan\",\"productUserFriendlyName\":\"Group Personal Accident Plan\",\"productType\":\"INS\",\"premiumWithGst\":250,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":12,\"pv\":0,\"riders\":[{\"riderCode\":\"GPGPPPD\",\"riderDescription\":\"Permanent Partial Disability\",\"riderUserFriendlyName\":\"Permanent Partial Disability\",\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPPTD\",\"riderDescription\":\"Permanent Total Disability\",\"riderUserFriendlyName\":\"Permanent Total Disability\",\"sumAssured\":100000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPEMIPB\",\"riderDescription\":\"Emi Payment Cover\",\"riderUserFriendlyName\":\"Emi Payment Cover\",\"sumAssured\":200000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPRABC\",\"riderDescription\":\"Road Ambulance Cover\",\"riderUserFriendlyName\":\"Road Ambulance Cover\",\"sumAssured\":25000,\"premiumAmount\":0,\"tenure\":0},{\"riderCode\":\"GPGPCAAC\",\"riderDescription\":\"Air Ambulance Cover\",\"riderUserFriendlyName\":\"Air Ambulance Cover\",\"sumAssured\":500000,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"BFDL_FPP_FAMILY_V2 - 1YR\",\"productName\":\"Family Health Vouchers (1 Year)\",\"productUserFriendlyName\":\"Family Health Vouchers (1 Year)\",\"productType\":\"VAS\",\"premiumWithGst\":699,\"costWithGst\":0,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":12,\"pv\":12,\"riders\":[{\"riderCode\":\"\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":0,\"premiumAmount\":0,\"tenure\":0}]},{\"productCode\":\"Digital Gold\",\"productName\":\"Gold back\",\"productUserFriendlyName\":\"Gold back\",\"productType\":\"VAS\",\"premiumWithGst\":0,\"costWithGst\":51,\"premiumWithotGST\":null,\"sumAssured\":0,\"tenure\":0,\"pv\":0,\"riders\":[{\"riderCode\":\"\",\"riderDescription\":null,\"riderUserFriendlyName\":null,\"sumAssured\":0,\"premiumAmount\":0,\"tenure\":0}]}]}},\"fppAttributeAtributes\":{\"height\":170.1,\"weight\":72.7},\"questionAnswerList\":[{\"questionKey\":1,\"questionCode\":\"QA1\",\"questionString\":\"I have never had/currently have any Existing Disability or Infirmity\",\"visibleToUiFlag\":true,\"userResponse\":\"Yes\"},{\"questionKey\":2,\"questionCode\":\"QA2\",\"questionString\":\"I have never had/currently have any disorder of heart/circulatory system/blood pressure/stoke/astama/lung/cancer/tumour/diabetes/hepatitis/liver/digestive tract/urinary/kidney/depression/mental/psychiatric/epilepsy/HIV positive test/brain/nervous system/blood/musculoskeletal/any disability. I have never had symptoms persisting more than 7 days nor been absent from work for any illness/injury/disbility more than 10 days in last 3yrs\",\"visibleToUiFlag\":true,\"userResponse\":\"Yes\"},{\"questionKey\":4,\"questionCode\":\"QA4\",\"questionString\":\"Are you pregnant? If Yes  please state the expected date of delivery\",\"visibleToUiFlag\":true,\"userResponse\":\"No\"}]}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(req);
		listener.prePiData(execution);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testprePricingUpdate() {
		Gson g = new Gson();
		Map<String, Object> existingPricing = g.fromJson(
				"{\"appLoanPricingKey\":\"1934\",\"applicationKey\":\"1100000000006221\",\"prodCategoryCode\":\"OMPL\",\"isTenure\":0,\"droplineTenure\":48,\"emiAmount\":2778.0,\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20.0,\"firstDueDate\":\"2020-10-02\",\"dueDay\":2,\"graceTerm\":null,\"nextDueDate\":null,\"roi\":14.6,\"isEmi\":null,\"droplineEmi\":null,\"pennantLoanType\":\"SOLTL\",\"netDisbursementAmount\":null,\"loanAmount\":100000.0,\"fees\":[{\"feesKey\":18852,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":1200.0,\"feeCode\":\"CONV\"},{\"feesKey\":18851,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"STAMPFEE\"},{\"feesKey\":18850,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"PROCFEE\"}],\"loanType\":\"BFLSOLTL\",\"isBpiApplicable\":\"Yes\",\"roiWithBundle\":14.25,\"roiWithoutBundle\":14.6,\"finalLoanAmount\":104463.0,\"loanAmmountWithBundle\":104463.0,\"loanAmmountWithoutBundle\":100000.0,\"pricingStatus\":\"APPROVED\",\"raisedBy\":0,\"fppSelected\":false,\"source\":\"JOURNEY\",\"bundlePrice\":null,\"approval\":{\"approvalStatus\":\"APPROVED\",\"approvedBy\":0,\"raisedBy\":0}}",
				HashMap.class);
		when(execution.getVariable(Mockito.eq(Fpp.PRICING_PAYLOAD))).thenReturn(existingPricing);

		Object vasOutput = g.fromJson(
				"{\"appPlanDetkey\":\"78\",\"applicationKey\":\"2200000000000073\",\"floorPrice\":3720.0,\"maxPrice\":0.0,\"oldProfit\":762.0,\"newProfit\":0.0,\"actualPrice\":4463.0,\"saveRoi\":0.4,\"withPlanRoi\":14.25,\"savingAmount\":1251.0,\"source\":\"JOURNEY\",\"status\":\"Approved\",\"raisedBy\":\"9906100004\",\"approvedBy\":\"9906100004\"} ",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.VAS_COST_OUTPUT)).thenReturn(vasOutput);
		listener.prePricingUpdate(execution);
	}

	@Test
	public void testpostSaveQuestions() {
		Gson g = new Gson();
		Object req = g.fromJson(
				"{\"applicationKey\":\"2200000000000098\",\"questionAnswerList\":[{\"questionKey\":1,\"questionCode\":\"QA1\",\"questionString\":\"I have never had/currently have any Existing Disability or Infirmity\",\"visibleToUiFlag\":true,\"appQuestionResponseKey\":1318,\"userResponse\":\"Yes\"},{\"questionKey\":2,\"questionCode\":\"QA2\",\"questionString\":\"I have never had/currently have any disorder of heart/circulatory system/blood pressure/stoke/astama/lung/cancer/tumour/diabetes/hepatitis/liver/digestive tract/urinary/kidney/depression/mental/psychiatric/epilepsy/HIV positive test/brain/nervous system/blood/musculoskeletal/any disability. I have never had symptoms persisting more than 7 days nor been absent from work for any illness/injury/disbility more than 10 days in last 3yrs\",\"visibleToUiFlag\":true,\"appQuestionResponseKey\":1320,\"userResponse\":\"Yes\"},{\"questionKey\":4,\"questionCode\":\"QA4\",\"questionString\":\"Are you pregnant? If Yes  please state the expected date of delivery\",\"visibleToUiFlag\":true,\"appQuestionResponseKey\":1319,\"userResponse\":\"No\"}],\"rejectStatus\":true,\"rejectCodes\":[\"RJC01\"]}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(req);
		listener.postSaveQuestions(execution);
	}

	@Test
	public void testpreBundleKeyUpdate() {
		listener.preBundleKeyUpdate(execution);
	}

	@Test
	public void testpreBundleKeyRemove() {
		listener.preBundleKeyRemove(execution);
	}

	@Test
	public void postGetBundle() {
		Gson g = new Gson();
		Object output = g.fromJson(
				"[{\"bundleSelected\":true,\"bundleApplicationKey\":2200000000000334,\"apploanpricingkey\":null,\"applicationKey\":1100000000010744,\"bundlerevision\":null,\"source\":\"JOURNEY\",\"appBundleKey\":268,\"bundlePlanKey\":5,\"status\":null}] ",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		listener.postGetBundle(execution);
	}

	@Test
	public void testpreNomineeUpdate() {
		Gson g = new Gson();
		Object req = g.fromJson(
				"{\"action\":null,\"applicationid\":\"1100000000007799\",\"fatherName\":\"asdadasd\",\"l3ProductCode\":\"null\",\"l4ProductCode\":null,\"principalKey\":null,\"motherName\":\"adsasda\",\"nomineeDetails\":[{\"dateOfBirth\":\"1991-01-01\",\"name\":\"nomineeone\",\"relationship\":{\"key\":3,\"code\":\"3\",\"value\":\"mother\"}},{\"dateOfBirth\":\"1991-01-01\",\"name\":\"nomineeone\",\"relationship\":{\"key\":2,\"code\":\"2\",\"value\":\"father\"}}],\"addressDetails\":[{\"addressKey\":null,\"addressLine1\":\"abcd\",\"addressLine2\":\"abcd\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"50\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411041\",\"pincodeKey\":\"116159\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},{\"addressKey\":null,\"addressLine1\":\"asdada\",\"addressLine2\":\"sdadsaasd\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"46\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411041\",\"pincodeKey\":\"116159\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null},{\"addressKey\":null,\"addressLine1\":\"ssdsdsdsd\",\"addressLine2\":\"ssdsdsdsd\",\"addressSource\":\"JOURNEY\",\"addressTypeKey\":\"48\",\"cityKey\":\"1784\",\"countryKey\":\"91\",\"pincode\":\"411012\",\"pincodeKey\":\"113683\",\"stateKey\":\"257\",\"resiType\":null,\"verification\":null}]}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(req);
		listener.preNomineeUpdate(execution);
	}

	@Test
	public void testPostGetLoanPricingFpp() {
		Gson g = new Gson();
		Object existingPricing = g.fromJson(
				"[{\"appLoanPricingKey\":\"1934\",\"applicationKey\":\"1100000000006221\",\"prodCategoryCode\":\"OMPL\",\"isTenure\":0,\"droplineTenure\":48,\"emiAmount\":2778.0,\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20.0,\"firstDueDate\":\"2020-10-02\",\"dueDay\":2,\"graceTerm\":null,\"nextDueDate\":null,\"roi\":14.6,\"isEmi\":null,\"droplineEmi\":null,\"pennantLoanType\":\"SOLTL\",\"netDisbursementAmount\":null,\"loanAmount\":100000.0,\"fees\":[{\"feesKey\":18852,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":1200.0,\"feeCode\":\"CONV\"},{\"feesKey\":18851,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"STAMPFEE\"},{\"feesKey\":18850,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"PROCFEE\"}],\"loanType\":\"BFLSOLTL\",\"isBpiApplicable\":\"Yes\",\"roiWithBundle\":14.25,\"roiWithoutBundle\":14.6,\"finalLoanAmount\":104463.0,\"loanAmmountWithBundle\":104463.0,\"loanAmmountWithoutBundle\":100000.0,\"pricingStatus\":\"APPROVED\",\"raisedBy\":0,\"fppSelected\":false,\"source\":\"JOURNEY\",\"bundlePrice\":null,\"approval\":{\"approvalStatus\":\"APPROVED\",\"approvedBy\":0,\"raisedBy\":0}}] ",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(existingPricing);
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(new HashMap<String, Object>());
		listener.postGetLoanPricingFpp(execution);
	}

	@Test
	public void testprePricingUpdateWithoutFpp() {
		listener.prePricingUpdateWithoutFpp(execution);
	}

	@Test
	public void testpostGetBundleSelected() {
		Gson g = new Gson();
		Object bundleResponse = g.fromJson(
				"[{\"bundleSelected\":true,\"appBundleKey\":318,\"applicationKey\":1100000000011974,\"bundleApplicationKey\":2200000000000368,\"bundlePlanKey\":5,\"isActive\":null,\"source\":\"JOURNEY\",\"status\":\"APPROVED\",\"apploanpricingkey\":5736,\"bundlerevision\":1}] ",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(bundleResponse);
		listener.postGetBundleSelected(execution);
	}

	@Test
	public void testSetDefaultFlags() {
		when(execution.getVariable(CreditBusinessConstants.RISKOFFERTYPE)).thenReturn("ABC");
		listener.setDefaultFlags(execution);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testPostGetVasApplication() {
		JSONObject output = new JSONObject();
		output.put("appstatus", VasAppStatusEnum.REJECTED.getValue());
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(output);
		listener.postGetVasApplication(execution);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testPreUpdateUserProfile() {
		JSONObject req = new  JSONObject();
		JSONObject bundleData = new JSONObject();
		JSONObject gender = new JSONObject();
		gender.put("key", 1);
		bundleData.put(CreditBusinessConstants.GENDER, gender);
		req.put("bundleData", bundleData);
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(req);
		when(execution.getVariable(CreditBusinessConstants.USERPROFILEOUTPUT)).thenReturn(new JSONObject());
		listener.preUpdateUserProfile(execution);
	}
	
	@Test
	public void testPostUpdateUserProfile() {
		listener.postUpdateUserProfile(execution);
	}
	
	@Test
	public void testPostCheckEpPricingApproval() {
		Gson g = new Gson();
		Object existingPricing = g.fromJson(
				"[{\"appLoanPricingKey\":\"1934\",\"applicationKey\":\"1100000000006221\",\"prodCategoryCode\":\"OMPL\",\"isTenure\":0,\"droplineTenure\":48,\"emiAmount\":2778.0,\"baseRateCode\":\"MIBOR\",\"baseRateValue\":20.0,\"firstDueDate\":\"2020-10-02\",\"dueDay\":2,\"graceTerm\":null,\"nextDueDate\":null,\"roi\":14.6,\"isEmi\":null,\"droplineEmi\":null,\"pennantLoanType\":\"SOLTL\",\"netDisbursementAmount\":null,\"loanAmount\":100000.0,\"fees\":[{\"feesKey\":18852,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":1200.0,\"feeCode\":\"CONV\"},{\"feesKey\":18851,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"STAMPFEE\"},{\"feesKey\":18850,\"appLoanPricingKey\":1934,\"feesInPercent\":0.2,\"feesInAmount\":200.0,\"feeCode\":\"PROCFEE\"}],\"loanType\":\"BFLSOLTL\",\"isBpiApplicable\":\"Yes\",\"roiWithBundle\":14.25,\"roiWithoutBundle\":14.6,\"finalLoanAmount\":104463.0,\"loanAmmountWithBundle\":104463.0,\"loanAmmountWithoutBundle\":100000.0,\"pricingStatus\":\"APPROVED\",\"raisedBy\":0,\"fppSelected\":false,\"source\":\"JOURNEY\",\"bundlePrice\":null,\"approval\":{\"approvalStatus\":\"APPROVED\",\"approvedBy\":0,\"raisedBy\":0}}] ",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(existingPricing);
		when(execution.getVariable(CreditBusinessConstants.PAYLOAD)).thenReturn(new HashMap<String, Object>());
		listener.postCheckEpPricingApproval(execution);		
	}
	
	@Test
	public void testBuildRequestForApplicationParamsUpdate() {
		listener.buildRequestForApplicationParamsUpdate(execution);
	}
	
	@Test
	public void testSetDefaultParam() {
		when(execution.getVariable(CreditBusinessConstants.FPPSELECTED)).thenReturn(null);
		when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("1234");
		listener.setDefaultParams(execution);
	}
	
	@Test
	public void testprefppNomineeUpdate() {
		Gson g = new Gson();
		Object req = g.fromJson(
				"{\"action\":\"Next\",\"isFppSelected\":true,\"bundleData\":{\"nomineeDetails\":[{\"dateOfBirth\":\"1990-01-02\",\"name\":\"kjkkjkjb\",\"relationcodemastkey\":null,\"relationship\":{\"key\":6,\"code\":\"6\",\"value\":\"Brother\"}}],\"applicationId\":\"1100000000103508\",\"l3ProductKey\":138,\"l3ProductCode\":\"BFLSOLFLDG\",\"genderRequired\":false,\"gender\":null,\"openArcFppOutput\":{\"planCode\":\"FPP\",\"planName\":\"FinservProtectionPlan\",\"planFriendlyName\":\"FinservProtectionPlan\",\"planType\":\"RETAIL\",\"withFppSaveRoi\":0.4,\"withFppRoi\":20.200000000000003,\"withoutFppRoi\":20.6,\"withFppSavingAmount\":1540,\"floorPriceWithGST\":3312,\"actualFppPriceWithGST\":4140,\"oldProfit\":982,\"fppCostPrice\":1276,\"products\":[{\"productCode\":\"GCPP\",\"productName\":\"GroupCreditProtectionPlan\",\"productUserFriendlyName\":\"GroupCreditProtectionPlan\",\"productType\":\"INS\",\"premiumWithGst\":556,\"costWithGst\":0,\"premiumWithoutGST\":471,\"sumAssured\":120000,\"tenure\":48,\"pv\":0,\"riders\":[]},{\"productCode\":\"GPGP\",\"productName\":\"GroupPersonalAccidentPlan\",\"productUserFriendlyName\":\"GroupPersonalAccidentPlan\",\"productType\":\"INS\",\"premiumWithGst\":250,\"costWithGst\":0,\"premiumWithoutGST\":212,\"sumAssured\":2500000,\"tenure\":12,\"pv\":0,\"riders\":[{\"riderCode\":\"GPGPPPD\",\"riderDescription\":\"PermanentPartialDisability\",\"riderUserFriendlyName\":\"PermanentPartialDisability\",\"sumAssured\":1000000,\"premiumAmount\":0,\"tenure\":12},{\"riderCode\":\"GPGPPTD\",\"riderDescription\":\"PermanentTotalDisability\",\"riderUserFriendlyName\":\"PermanentTotalDisability\",\"sumAssured\":1000000,\"premiumAmount\":0,\"tenure\":12},{\"riderCode\":\"GPGPCAAC\",\"riderDescription\":\"AirAmbulanceCover\",\"riderUserFriendlyName\":\"AirAmbulanceCover\",\"sumAssured\":500000,\"premiumAmount\":0,\"tenure\":12},{\"riderCode\":\"GPGPEMIPB\",\"riderDescription\":\"EmiPaymentCover\",\"riderUserFriendlyName\":\"EmiPaymentCover\",\"sumAssured\":200000,\"premiumAmount\":0,\"tenure\":12},{\"riderCode\":\"GPGPRABC\",\"riderDescription\":\"RoadAmbulanceCover\",\"riderUserFriendlyName\":\"RoadAmbulanceCover\",\"sumAssured\":25000,\"premiumAmount\":0,\"tenure\":12}]},{\"productCode\":\"DigitalGold\",\"productName\":\"Goldback\",\"productUserFriendlyName\":\"Goldback\",\"productType\":\"VAS\",\"premiumWithGst\":51,\"costWithGst\":51,\"premiumWithoutGST\":null,\"sumAssured\":51,\"tenure\":0,\"pv\":0,\"riders\":[]},{\"productCode\":\"BFDL_FPP_FAMILY_V2-1YR\",\"productName\":\"FamilyHealthVouchers(1Year)\",\"productUserFriendlyName\":\"FamilyHealthVouchers(1Year)\",\"productType\":\"VAS\",\"premiumWithGst\":699,\"costWithGst\":0,\"premiumWithoutGST\":592,\"sumAssured\":0,\"tenure\":12,\"pv\":12100,\"riders\":[]}]},\"questionAnswerList\":[{\"questionKey\":26,\"questionCode\":\"QA26\",\"questionString\":\"Ihaveneverhad/currentlyhaveanydisorderofheart/circulatorysystem/bloodpressure/stroke/asthma/lung/cancer/tumor/diabetes/hepatitis/liver/digestivetract/urinary/kidney/depression/mental/psychiatric/epilepsy/HIVpositivetest/brain/nervoussystem/blood/musculoskeletal/anydisabilityMeormyfamilymembershavenottestedpositiveforCovid19inlast3months/nothavebeenself-isolatedwithsymptomsonmedicaladvice/advisedtoundergo,repeatorawaitingCovid19test/nocurrentlyorinthepast1monthhavesymptomslikepersistentcough,breathlessness,fever,raisedtemperature/notbeenincontactwithanindividualsuspectedorquarantinedorconfirmedtohaveCOVID-19orSARScov-2/ornotmeorimmediatefamilymembersoccupationrequireme/themtocomeinclosecontactwithCovid-19patientsorwithcoronaviruscontaminatedmaterial?MeormyimmediatefamilymembershavenottravelledorplanstotraveloutsideIndiafornext6months.Ihavenotbeenhospitalizedformorethan5daysinpast(exceptpregnancy)/neverhadanysymptomspersistingmorethan7days/notbeenabsentfromworkforanyillness/injury/disabilityformorethan10daysinlast3yrs.\",\"visibleToUiFlag\":true,\"appQuestionResponseKey\":248299,\"userResponse\":\"Yes\"},{\"questionKey\":1,\"questionCode\":\"QA1\",\"questionString\":\"Ihaveneverhad/currentlyhaveanyExistingDisabilityorInfirmity\",\"visibleToUiFlag\":true,\"appQuestionResponseKey\":248301,\"userResponse\":\"Yes\"}],\"fppAttributeAtributes\":{\"height\":180,\"weight\":76},\"pricingMap\":{\"RIDER_GPGPEMIPB\":200000,\"PRODUCT_DigitalGold\":51,\"PRODUCT_VHEALTH\":12100,\"RIDER_GPGPRABC\":25000,\"PRODUCT_GPGP\":0,\"PRODUCT_GCPP\":120000,\"RIDER_GPGPPTD\":1000000,\"RIDER_GPGPCAAC\":500000,\"RIDER_GPGPPPD\":1000000}},\"fppAttributeAtributes\":{\"height\":180,\"weight\":76},\"questionAnswerList\":[{\"questionKey\":1,\"questionCode\":\"QA1\",\"userResponse\":\"Yes\"},{\"questionKey\":26,\"questionCode\":\"QA26\",\"userResponse\":\"Yes\"}]}",
				Object.class);
		when(execution.getVariable(CreditBusinessConstants.REQUEST)).thenReturn(req);
		listener.prefppNomineeUpdate(execution);
	}

}
