package com.bajaj.markets.credit.business.helper;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.amazonaws.services.sns.model.PublishResult;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.ApplicationDetail;
import com.bajaj.markets.credit.business.beans.Profession;
import com.bajaj.markets.credit.business.beans.ProfileDetails;
import com.bajaj.markets.credit.business.beans.ProfileDetailsReqResp;
import com.bajaj.markets.credit.business.beans.ProfileDetailsV2;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.google.gson.Gson;

@SpringBootTest
public class EventMessageHelperTest {

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	PublisherService publisherService;

	@Mock
	CustomDefaultHeaders customHeaders;

	@Mock
	CreditBusinessApiCallsHelper apiCallsHelper;

	@InjectMocks
	EventMessageHelper helper;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testPublishBMR1Event(){
		Gson g = new Gson();
		ApplicationDetail applicationDetail = new ApplicationDetail();
		applicationDetail.setL2ProductCode(ProductCodeEnum.LOANS.getValue());
		applicationDetail.setApplicationKey("1100000000004989");
		Mockito.when(apiCallsHelper.getApplicationDetails(Mockito.any(), Mockito.any())).thenReturn(applicationDetail);
		Mockito.when(publisherService.publish(Mockito.any(), Mockito.any())).thenReturn(new PublishResult());
		UserProfileBean userProfile = g.fromJson(
				"{\"applicationKey\":\"1100000000004989\",\"applicationUserAttributeKey\":\"4453\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"6787865764\",\"dateOfBirth\":\"1983-02-06\",\"name\":{\"firstName\":null,\"middleName\":null,\"lastName\":null,\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":null,\"genderKey\":null,\"residenceTypeKey\":2,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":null}",
				UserProfileBean.class);
		Mockito.when(apiCallsHelper.getUserProfile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(userProfile);
		Mockito.when(apiCallsHelper.getAddress(Mockito.any(), Mockito.any())).thenReturn(new Address());
		helper.publishBMR1Event(applicationDetail, new ProfileDetails(), CreditBusinessConstants.JOURNEY.toUpperCase());
	}
   
	@Test
	public void testPublishBMR1Event_Exception(){
		Gson g = new Gson();
		ApplicationDetail applicationDetail = new ApplicationDetail();
		applicationDetail.setL2ProductCode(ProductCodeEnum.LOANS.getValue());
		applicationDetail.setApplicationKey("1100000000004989");

		UserProfileBean userProfile = g.fromJson(
				"{\"applicationKey\":\"1100000000004989\",\"applicationUserAttributeKey\":\"4453\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"6787865764\",\"dateOfBirth\":\"1983-02-06\",\"name\":{\"firstName\":null,\"middleName\":null,\"lastName\":null,\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":null,\"genderKey\":null,\"residenceTypeKey\":2,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":null}",
				UserProfileBean.class);

		Mockito.when(apiCallsHelper.getApplicationDetails(Mockito.any(), Mockito.any())).thenReturn(applicationDetail);
		Mockito.when(apiCallsHelper.getUserProfile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(userProfile);
		Mockito.when(publisherService.publish(Mockito.any(), Mockito.any())).thenThrow(new NullPointerException("TestException"));
		helper.publishBMR1Event(applicationDetail, new ProfileDetails(), CreditBusinessConstants.JOURNEY);
	}
	
	@Test
	public void testPublishBMR2Event(){
		Gson g = new Gson();
		ApplicationDetail applicationDetail = new ApplicationDetail();
		applicationDetail.setL2ProductCode(ProductCodeEnum.LOANS.getValue());
		applicationDetail.setApplicationKey("1100000000004989");
		Mockito.when(apiCallsHelper.getApplicationDetails(Mockito.any(), Mockito.any())).thenReturn(applicationDetail);
		Mockito.when(publisherService.publish(Mockito.any(), Mockito.any())).thenReturn(new PublishResult());
		UserProfileBean userProfile = g.fromJson(
				"{\"applicationKey\":\"1100000000004989\",\"applicationUserAttributeKey\":\"4453\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"6787865764\",\"dateOfBirth\":\"1983-02-06\",\"name\":{\"firstName\":null,\"middleName\":null,\"lastName\":null,\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":null,\"genderKey\":null,\"residenceTypeKey\":2,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":null}",
				UserProfileBean.class);
		Mockito.when(apiCallsHelper.getUserProfile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(userProfile);
		Mockito.when(apiCallsHelper.getAddress(Mockito.any(), Mockito.any())).thenReturn(new Address());
		helper.publishBMR2Event(applicationDetail, new ProfileDetails(), CreditBusinessConstants.JOURNEY);
	}
    
	@Test
	public void testpublishBMR1EventV2() {
		Gson g = new Gson();
		ApplicationDetail applicationDetail = new ApplicationDetail();
		applicationDetail.setL2ProductCode(ProductCodeEnum.LOANS.getValue());
		applicationDetail.setApplicationKey("1100000000004989");
		Mockito.when(apiCallsHelper.getApplicationDetails(Mockito.any(), Mockito.any())).thenReturn(applicationDetail);
		Mockito.when(publisherService.publish(Mockito.any(), Mockito.any())).thenReturn(new PublishResult());
		UserProfileBean userProfile = g.fromJson(
				"{\"applicationKey\":\"1100000000004989\",\"applicationUserAttributeKey\":\"4453\",\"applicationUserAttributeType\":\"1\",\"mobile\":\"6787865764\",\"dateOfBirth\":\"1983-02-06\",\"name\":{\"firstName\":null,\"middleName\":null,\"lastName\":null,\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":null,\"genderKey\":null,\"residenceTypeKey\":2,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":null}",
				UserProfileBean.class);
		Mockito.when(apiCallsHelper.getUserProfile(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(userProfile);
		Mockito.when(apiCallsHelper.getAddress(Mockito.any(), Mockito.any())).thenReturn(new Address());
		ProfileDetailsReqResp profileDetailsReqResp = new ProfileDetailsReqResp();
		Reference reference = new Reference();
		reference.setCode("SALR");
		Profession profession = new Profession();
		profession.setOccupation(reference);
		ProfileDetailsV2 profileDetailsV2 = new ProfileDetailsV2();
		profileDetailsV2.setPanNumber("ANKPT9770H");
		profileDetailsV2.setPersonalEmailId("test@gmail.com");
		profileDetailsReqResp.setProfession(profession);
		profileDetailsReqResp.setProfileDetails(profileDetailsV2);

		helper.publishBMR1EventV2(applicationDetail, profileDetailsReqResp);
	}
	
}
