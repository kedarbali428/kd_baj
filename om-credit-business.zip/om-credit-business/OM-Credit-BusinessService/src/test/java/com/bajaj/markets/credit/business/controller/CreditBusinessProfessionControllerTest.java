package com.bajaj.markets.credit.business.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.Validator;
import javax.validation.metadata.ConstraintDescriptor;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.CreditParameters;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.service.CreditBusinessProfessionService;
import com.fasterxml.jackson.databind.ObjectMapper;
 
@AutoConfigureMockMvc
@WebMvcTest
public class CreditBusinessProfessionControllerTest {
 
    @Mock
    BFLLoggerUtilExt logger;
 
    private MockMvc mockMvc;
 
    @InjectMocks
    CreditBusinessProfessionController controller;
 
    @Autowired
    CreditBusinessControllerAdvice advice;
 
    @Mock
    CreditBusinessProfessionService service;
    
    @Mock
    private Validator validator;
    
    @Mock
    private Environment env;
 
    ObjectMapper mapper = new ObjectMapper();
 
    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(CreditBusinessControllerAdvice.class).build();
    }
    
    @Test
    public void testSaveProfessionalDet_UnprocessableEntity() throws Exception {
        String request = mapper.writeValueAsString(new CreditParameters());
        mockMvc.perform(post("/v1/credit/applications/{applicationid}/creditparameters","123").content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isUnprocessableEntity());
    }
 
    @Test
    public void testSaveProfessionalDet_bo() throws Exception {
        CreditParameters creditParameters = new CreditParameters();
        Reference occType = new Reference();
        occType.setCode("SEMP");
        Occupation profession = new Occupation();
        profession.setOcupationType(occType);
        creditParameters.setProfession(profession);
        creditParameters.setAction(null);
        String request = mapper.writeValueAsString(creditParameters);
        mockMvc.perform(post("/v1/credit/applications/{applicationid}/creditparameters","123").content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isCreated());
    }
    
    @Test
    public void testSaveProfessionalDet_Error() throws Exception {
        CreditParameters creditParameters = new CreditParameters();
        Occupation profession = new Occupation();
        creditParameters.setProfession(profession);
        creditParameters.setAction(null);
        String request = mapper.writeValueAsString(creditParameters);
        Set<ConstraintViolation<Object>> validationErrors = new HashSet<>();
        ConstraintViolation<Object> validationError = new ConstraintViolation<Object>() {
            
            @Override
            public <U> U unwrap(Class<U> type) {
                // TODO Auto-generated method stub
                return null;
            }
            
            @Override
            public Class<Object> getRootBeanClass() {
                // TODO Auto-generated method stub
                return null;
            }
            
            @Override
            public Path getPropertyPath() {
                // TODO Auto-generated method stub
                return null;
            }
            
            @Override
            public String getMessageTemplate() {
                // TODO Auto-generated method stub
                return null;
            }
            
            @Override
            public String getMessage() {
                // TODO Auto-generated method stub
                return "residencePincode cannot be null or empty";
            }
            
            @Override
            public Object getLeafBean() {
                // TODO Auto-generated method stub
                return null;
            }
            
            @Override
            public Object getInvalidValue() {
                // TODO Auto-generated method stub
                return null;
            }
            
            @Override
            public Object getExecutableReturnValue() {
                // TODO Auto-generated method stub
                return null;
            }
            
            @Override
            public Object[] getExecutableParameters() {
                // TODO Auto-generated method stub
                return null;
            }
            
            @Override
            public ConstraintDescriptor<?> getConstraintDescriptor() {
                // TODO Auto-generated method stub
                return null;
            }
 
            @Override
            public Object getRootBean() {
                // TODO Auto-generated method stub
                return null;
            }
        };
        validationErrors.add(validationError);
        when(validator.validate(any(), any())).thenReturn(validationErrors);
        mockMvc.perform(post("/v1/credit/applications/{applicationid}/creditparameters","123").content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isUnprocessableEntity());
    }
    
    @Test
    public void testgetProfessionalDet() throws Exception {
        CreditParameters creditParameters = new CreditParameters();
        Occupation profession = new Occupation();
        creditParameters.setProfession(profession);
        creditParameters.setAction(null);
        when(service.getProfessionalDet(Mockito.any())).thenReturn(creditParameters);
        mockMvc.perform(get("/v1/credit/applications/{applicationid}/creditparameters","123").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }
 
    @Test
    public void testSaveProfessionalDet_CA() throws Exception {
        CreditParameters creditParameters = new CreditParameters();
        Reference occType = new Reference();
        occType.setCode("CAICWA");
        Occupation profession = new Occupation();
        profession.setOcupationType(occType);
        creditParameters.setProfession(profession);
        creditParameters.setAction(null);
        String request = mapper.writeValueAsString(creditParameters);
        mockMvc.perform(post("/v1/credit/applications/{applicationid}/creditparameters","123").content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isCreated());
    }
    
    @Test
    public void testSaveProfessionalDet_salaried() throws Exception {
        CreditParameters creditParameters = new CreditParameters();
        Reference occType = new Reference();
        occType.setCode("SALR");
        Occupation profession = new Occupation();
        profession.setOcupationType(occType);
        creditParameters.setProfession(profession);
        creditParameters.setAction(null);
        String request = mapper.writeValueAsString(creditParameters);
        mockMvc.perform(post("/v1/credit/applications/{applicationid}/creditparameters","123").content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isCreated());
    }
    
    @Test
    public void testSaveProfessionalDet_invalid() throws Exception {
        CreditParameters creditParameters = new CreditParameters();
        Reference occType = new Reference();
        occType.setCode("abcd");
        Occupation profession = new Occupation();
        profession.setOcupationType(occType);
        creditParameters.setProfession(profession);
        creditParameters.setAction(null);
        String request = mapper.writeValueAsString(creditParameters);
        mockMvc.perform(post("/v1/credit/applications/{applicationid}/creditparameters","123").content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isUnprocessableEntity());
    }
    
    @Test
    public void testSaveProfessionalDet_back() throws Exception {
        CreditParameters creditParameters = new CreditParameters();
        creditParameters.setAction("back");
        String request = mapper.writeValueAsString(creditParameters);
        mockMvc.perform(post("/v1/credit/applications/{applicationid}/creditparameters","123").content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isCreated());
    }
 
}

