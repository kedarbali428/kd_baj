package com.bajaj.markets.credit.business.controller;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.ConsentMethod;
import com.bajaj.markets.credit.business.beans.PricingConsentCaptureRequest;
import com.bajaj.markets.credit.business.beans.PricingConsentRequest;
import com.bajaj.markets.credit.business.service.CreditBusinessPricingConsentService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest

@AutoConfigureMockMvc
public class CreditBusinessPricingConsentControllerTest {

	@InjectMocks
	private CreditBussinessPricingConsentController creditBussinessPricingConsentController;

	@Mock
	private BFLLoggerUtilExt logger;

	@Mock
	private CreditBusinessPricingConsentService pricingConsentService;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditBussinessPricingConsentController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class)
				/* .addPlaceholderValue("/v1/income/verification", "/v1/income/verification") */.build();

	}

	@Test
	public void testgetPricingConsent() throws Exception {
		PricingConsentRequest request = new PricingConsentRequest();
		List<ConsentMethod> list = new ArrayList<>();
		ConsentMethod consentMethod = new ConsentMethod();
		consentMethod.setConsentMechanism("EMAIL");
		consentMethod.setConsentMechanism("SMS");
		request.setConsentMethodlist(list);

		mockMvc.perform(
				post("/v1/credit/applications/{applicationid}/pricingconsent", 1235l).contentType(MediaType.APPLICATION_JSON)
						.content(prepareRequestJsonString(request)).headers(new HttpHeaders()))
				.andExpect(status().isCreated());
	}

	
	
	@Test
	public void testupdatePricingConsent() throws Exception {
		PricingConsentCaptureRequest request = new PricingConsentCaptureRequest();
        request.setConsentToken("qwrewqfrew12");
        request.setEmployeeCaptured(true);
        request.setEmployeeUserKey("12");
		mockMvc.perform(
				put("/v1/credit/applications/{applicationid}/pricingconsent/{consentref}", 1235l,22).contentType(MediaType.APPLICATION_JSON)
						.content(prepareRequestJsonString(request)).headers(new HttpHeaders()))
				.andExpect(status().isOk());
	}

	private String prepareRequestJsonString(Object requestObject) {
		String requestJson = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			requestJson = mapper.writeValueAsString(requestObject);
		} catch (JsonProcessingException e) {
		}
		return requestJson;
	}
}
