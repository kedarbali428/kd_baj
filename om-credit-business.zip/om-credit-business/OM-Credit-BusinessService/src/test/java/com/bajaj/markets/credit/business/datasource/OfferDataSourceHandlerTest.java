package com.bajaj.markets.credit.business.datasource;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.util.ReflectionTestUtils;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.Address;
import com.bajaj.markets.credit.business.beans.AppOfferDetBean;
import com.bajaj.markets.credit.business.beans.ApplicantDataBean;
import com.bajaj.markets.credit.business.beans.BankDetail;
import com.bajaj.markets.credit.business.beans.DocumentDetails;
import com.bajaj.markets.credit.business.beans.Email;
import com.bajaj.markets.credit.business.beans.EmandatesRequest;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.OfferApiRequest;
import com.bajaj.markets.credit.business.beans.OfferDetailsBean;
import com.bajaj.markets.credit.business.beans.PrincipalCustomer;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.processor.AddressProcessor;
import com.bajaj.markets.credit.business.processor.ApplicantProfileProcessor;
import com.bajaj.markets.credit.business.processor.BankProcessor;
import com.bajaj.markets.credit.business.processor.DocumentProcessor;
import com.bajaj.markets.credit.business.processor.EmailProcessor;
import com.bajaj.markets.credit.business.processor.MandateProcessor;
import com.bajaj.markets.credit.business.processor.OccupationProcessor;
import com.bajaj.markets.credit.business.processor.OfferProcessor;
import com.bajaj.markets.credit.business.processor.PrincipalCustProcessor;

@SpringBootConfiguration
@SpringBootTest
public class OfferDataSourceHandlerTest {

	@Mock
	CreditBusinessHelper creditBusinessHelper;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	OfferDataSourceService offerDataSourceService;
		
	@Mock
	ApplicantProfileProcessor applicantProfileProcessor;
	
	@Mock
	EmailProcessor emailProcessor;
	
	@Mock
	AddressProcessor addressProcessor;
	
	@Mock
	BankProcessor bankProcessor;
	
	@Mock
	OccupationProcessor occupationProcessor;
	
	@Mock
	OfferProcessor offerProcessor;
	
	@Mock
	DocumentProcessor documentProcessor;
	
	@Mock
	PrincipalCustProcessor principalCustProcessor;
	
	@Mock
	MandateProcessor mandateProcessor;
	
	@InjectMocks
	OfferDataSourceHandler offerDataSourceHandler;
		
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(offerDataSourceHandler, "logger", logger);
		ReflectionTestUtils.setField(offerDataSourceHandler, "offerDataSourceService", offerDataSourceService);
		ReflectionTestUtils.setField(offerDataSourceHandler, "principalCustProcessor", principalCustProcessor);
		ReflectionTestUtils.setField(offerDataSourceHandler, "documentProcessor", documentProcessor);
		ReflectionTestUtils.setField(offerDataSourceHandler, "offerProcessor", offerProcessor);
		ReflectionTestUtils.setField(offerDataSourceHandler, "occupationProcessor", occupationProcessor);
		ReflectionTestUtils.setField(offerDataSourceHandler, "bankProcessor", bankProcessor);
		ReflectionTestUtils.setField(offerDataSourceHandler, "addressProcessor", addressProcessor);
		ReflectionTestUtils.setField(offerDataSourceHandler, "emailProcessor", emailProcessor);
		ReflectionTestUtils.setField(offerDataSourceHandler, "applicantProfileProcessor", applicantProfileProcessor);
		ReflectionTestUtils.setField(offerDataSourceHandler, "mandateProcessor", mandateProcessor);
	}	
	
	@Test
	public void processApplicantDetailsTest() {
		List<OfferDetailsBean> dataSourceList = new ArrayList<>();
		OfferDetailsBean offerDetailsBean1 = new OfferDetailsBean();
		List<Address> addresses = new ArrayList<>();
		offerDetailsBean1.setAddresses(addresses);
		List<BankDetail> banks = new ArrayList<>();
		offerDetailsBean1.setBanks(banks);
		offerDetailsBean1.setDataSourceName("ProspectDataSource");
		List<DocumentDetails> documents = new ArrayList<>();
		offerDetailsBean1.setDocuments(documents);
		List<Email> emails = new ArrayList<>();
		offerDetailsBean1.setEmails(emails);
		List<Occupation> occupations = new ArrayList<>();
		offerDetailsBean1.setOccupations(occupations);
		List<AppOfferDetBean> offers = new ArrayList<>();
		offerDetailsBean1.setOffers(offers);
		List<PrincipalCustomer> principalCustomerDetails = new ArrayList<>();
		offerDetailsBean1.setPrincipalCustomerDetails(principalCustomerDetails);
		List<UserProfileBean> userProfileBeans = new ArrayList<>();
		offerDetailsBean1.setUserProfileBeans(userProfileBeans);
		List<EmandatesRequest> mandates = new ArrayList<>();
		offerDetailsBean1.setMandates(mandates);
		offerDetailsBean1.setPrecedence(1);
		OfferDetailsBean offerDetailsBean2 = new OfferDetailsBean();
		offerDetailsBean2.setPrecedence(2);
		dataSourceList.add(offerDetailsBean1);
		dataSourceList.add(offerDetailsBean2);
		
		Mockito.when(offerDataSourceService.processOfferData(Mockito.any())).thenReturn(dataSourceList);
		
		ApplicantDataBean applicantDataBean = new ApplicantDataBean();
		OfferApiRequest offerApiRequest = new OfferApiRequest();
		applicantDataBean.setApplicantKey("123");
		offerApiRequest.setApplicationKey("123");
		offerApiRequest.setApplicationUserAttributeKey("123");
		offerApiRequest.setDob("1983-08-20");
		applicantDataBean.setHeaders(new HttpHeaders());
		offerApiRequest.setMobileNo("9624313162");
		applicantDataBean.setOccupationType("test");
		offerApiRequest.setProductCode("DBOL");
		applicantDataBean.setOfferApiRequest(offerApiRequest);
		applicantDataBean.setProductCode("OMPL");
		offerDataSourceHandler.process(applicantDataBean);
		
	}
}