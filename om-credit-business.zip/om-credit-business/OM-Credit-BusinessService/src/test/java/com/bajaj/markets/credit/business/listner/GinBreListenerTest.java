package com.bajaj.markets.credit.business.listner;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.helper.CreditBusinessConstants;
import com.bajaj.markets.credit.business.helper.CreditBusinessGinHelper;
import com.bajaj.markets.credit.business.helper.CreditBusinessHelper;
import com.bajaj.markets.credit.business.helper.MasterDataRedisClientHelper;
import com.google.gson.Gson;

@SpringBootTest
public class GinBreListenerTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CreditBusinessHelper creditBusinessHelper;

	@Mock
	CreditBusinessGinHelper creditBusinessGinHelper;

	@Mock
	MasterDataRedisClientHelper redisHelper;

	@Mock
	BreListener breListener;

	@InjectMocks
	GinBreListener ginListener;

	@Mock
	DelegateExecution execution;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void preListing() throws Exception {
		Gson g = new Gson();
		JSONObject mcpReq = g.fromJson(
				"{\"additionalParameterDetail\":null,\"occupation\":{\"ocupationType\":{\"key\":2,\"code\":null,\"value\":null},\"salariedDetail\":{\"employerName\":null,\"employerNameOther\":null,\"designation\":null,\"experience\":null,\"netSalary\":null,\"employerType\":null},\"businessOwnerDetails\":{\"businessName\":\"testBusiness\",\"businessType\":null,\"natureOfBusiness\":{\"key\":1,\"code\":null,\"value\":null},\"industryType\":{\"key\":4,\"code\":null,\"value\":null},\"anualTurnover\":{\"key\":null,\"code\":null,\"value\":\"3-5 Cr.\"},\"netMonthlyIncome\":null,\"businessVintage\":{\"key\":null,\"code\":null,\"value\":\"5\"},\"proprieterName\":null,\"businessPan\":\"ASWCP1234J\",\"gstNumber\":\"\",\"subindumastkey\":{\"key\":null,\"code\":null,\"value\":null},\"profitAfterTax\":1000000,\"averageBankBalance\":1000000,\"companyType\":null},\"profitAfterTax\":null,\"averageBankBlance\":null,\"employerType\":\"null\"},\"userProfile\":{\"applicationKey\":null,\"applicationUserAttributeKey\":null,\"applicationUserAttributeType\":null,\"mobile\":\"9906250001\",\"dateOfBirth\":\"1990-12-12\",\"name\":{\"firstName\":\"asdad\",\"middleName\":\"\",\"lastName\":\"sdasdadas\",\"salutationKey\":null,\"verification\":null},\"maritalStatusKey\":27,\"genderKey\":22,\"residenceTypeKey\":1,\"qualification\":null,\"motherName\":null,\"fatherName\":null,\"panNumber\":\"ASWPJ1234J\"},\"prodCategory\":{\"prodCatCode\":\"OMPL\",\"prodCatDesc\":\"OM Personal loan\"},\"mcpAddressDetails\":[{\"pinCodeKey\":null,\"addressTypeKey\":null,\"principleProductDetails\":[{\"principleProductCode\":\"BFLSOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLBOL\",\"rejectCodeList\":[\"LENBOLROGL\"],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLDOL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLCAL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPPL\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null},{\"principleProductCode\":\"BFLPLCS\",\"rejectCodeList\":[],\"pincode\":{\"oglFlag\":true,\"negativeAreaFlag\":null},\"offerDetails\":[],\"employerType\":\"null\",\"employerCat\":null,\"existingCustomerType\":null,\"principleCustType\":null,\"dedupeJson\":null,\"deviationCodes\":null,\"bflApplicableLocationFlag\":null}]}],\"panDetails\":{\"nameMatch\":null,\"matchScore\":null,\"panType\":null},\"addressList\":[{\"addressKey\":\"5320\",\"addressTypeKey\":\"50\",\"resiType\":\"1\",\"addressLine1\":null,\"addressLine2\":null,\"pincode\":null,\"pincodeKey\":\"116159\",\"cityKey\":\"1784\",\"stateKey\":\"257\",\"countryKey\":\"91\",\"verification\":null,\"addressSource\":null,\"localitykey\":null}],\"princialSelectedbyCustomerDetail\":[],\"estimatedNetMonthlySalaryDetails\":[{\"salarySource\":\"Journey\",\"salaryAmount\":null}],\"appScoreDetails\":null,\"existingCustomerFlag\":null,\"additionalCibilFlag\":0,\"subStagePercentage\":30}",
				JSONObject.class);
		when(execution.getVariable(CreditBusinessConstants.MCP_REQUEST_OUTPUT)).thenReturn(mcpReq);
		Mockito.when(execution.getVariable(CreditBusinessConstants.DEROG_JSON)).thenReturn(new String());
		List<Map<String, Object>> obligationDetailsList = new ArrayList<>();
		Map<String, Object> emiMap = new HashMap<>();
		emiMap.put("mob", 9960414D);
		obligationDetailsList.add(emiMap);
		JSONObject obligationAmt = new JSONObject();
		obligationAmt.put("emiList", obligationDetailsList);
		Mockito.when(execution.getVariable(CreditBusinessConstants.OBLIGATION_AMT)).thenReturn(obligationAmt);
		ginListener.preListing(execution);
	}

	@Test
	public void testpostListing() {
		ginListener.postListing(execution);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetBreRequest() {
		JSONObject mcp = new JSONObject();
		mcp.put("prodCategory", new JSONObject());
		Mockito.when(execution.getVariable(CreditBusinessConstants.OUTPUT)).thenReturn(mcp);
		ginListener.postGetBreRequest(execution);
	}

}
