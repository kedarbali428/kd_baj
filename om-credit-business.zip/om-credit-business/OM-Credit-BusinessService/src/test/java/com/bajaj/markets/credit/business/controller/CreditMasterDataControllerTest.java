package com.bajaj.markets.credit.business.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.service.CreditMasterDataService;

@SpringBootTest
public class CreditMasterDataControllerTest {

	@Mock
	private CreditMasterDataService creditMasterDataService;

	@Mock
	private BFLLoggerUtilExt logger;

	private MockMvc mockMvc;

	@InjectMocks
	private CreditMasterDataController creditMasterDataController;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(creditMasterDataController)
				.setControllerAdvice(CreditBusinessControllerAdvice.class).build();
	}

	@Test
	public void testgetServiceableMasterData() throws Exception {
		mockMvc.perform(get(
				"/v1/credit/principals/{principalCode}/reference-attributes/{referenceAttributeCode}/serviceable-codes?status={status}",
				"123", "qwe", "").headers(new HttpHeaders())).andExpect(status().isOk());
	}

}
