package com.bajaj.markets.credit.business.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.markets.credit.business.beans.FppPdfReportResponseBean;
import com.bajaj.markets.credit.business.beans.SummaryDetails;
import com.bajaj.markets.credit.business.beans.SummaryResponse;
import com.bajaj.markets.credit.business.service.CreditBusinessProductSummaryService;
import com.fasterxml.jackson.databind.ObjectMapper;

@AutoConfigureMockMvc
@WebMvcTest
public class CreditBusinessProductSummaryControllerTest {

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CreditBusinessProductSummaryService service;

	@InjectMocks
	CreditBusinessProductSummaryController controller;

	private MockMvc mockMvc;

	ObjectMapper mapper = new ObjectMapper();

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(CreditBusinessControllerAdvice.class).build();
	}

	@Test
	public void testSummaryPost_Back() throws Exception {

		ResponseEntity<SummaryDetails> responseEntity = new ResponseEntity<SummaryDetails>(HttpStatus.CREATED);
		SummaryDetails request = new SummaryDetails();
		request.setAction("back");
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = mapper.writeValueAsString(request);
		when(service.postSummary(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		mockMvc.perform(post("/v1/credit/applications/{applicationid}/summary", "123").content(requestJson).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());
	}
	
	
	@Test
	public void testSummaryGet() throws Exception {
		ResponseEntity<SummaryResponse> responseEntity = new ResponseEntity<SummaryResponse>(HttpStatus.OK);
		when(service.getSummary(Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		mockMvc.perform(get("/v1/credit/applications/{applicationid}/summary", "123").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	public void testGeneratePDF() throws Exception{
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		when(service.generatePDFByRepaymentSchedule(Mockito.any(), Mockito.any())).thenReturn(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
		mockMvc.perform(get("/v1/credit/applications/{applicationid}/loanRepaymentSchedule","123")).andExpect(status().isOk());
	}
	
	@Test
	public void testGetFppPdfReportUrl() throws Exception {
		ResponseEntity<FppPdfReportResponseBean> responseEntity = new ResponseEntity<FppPdfReportResponseBean>(HttpStatus.OK);
		when(service.getFppPdfReportUrl(Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		mockMvc.perform(get("/v1/credit/applications/{applicationid}/fppPdfReportUrl", "123").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

}
