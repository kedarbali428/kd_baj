package com.bajaj.markets.credit.business.listner;

import org.activiti.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;

@SpringBootConfiguration
@SpringBootTest
public class KycListenerTests {

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	DelegateExecution execution;

	@InjectMocks
	KycListener listener;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testPostFetchCibil() {
		Mockito.when(execution.getVariable(Mockito.anyString())).thenReturn("100000000000001")
			.thenReturn("1000000000000000").thenReturn("1234").thenReturn("3").thenReturn("10")
			.thenReturn("9999999999").thenReturn("1900-10-10").thenReturn("PPPPP1111P");
		listener.preCkycSearchOrDownload(execution);
	}

}
