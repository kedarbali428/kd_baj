package com.bajaj.markets.credit.business.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executor;

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import com.amazonaws.services.sns.model.PublishResult;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.markets.credit.business.beans.Occupation;
import com.bajaj.markets.credit.business.beans.Reference;
import com.bajaj.markets.credit.business.beans.UserProfileBean;
import com.bajaj.markets.credit.publisher.service.PublisherService;
import com.google.gson.Gson;

@SpringBootConfiguration
@SpringBootTest
public class ApplicantUpdateDetailsTest {
	
	@InjectMocks
	ApplicantUpdateDetails applicantUpdateDetails;

	@Mock
	BFLLoggerUtilExt logger;

	@Mock
	CustomDefaultHeaders customHeaders;

	@Value("${aws.publisher.applicantupdate.topic.arn}")
	private String topicArn;

	@Mock
	PublisherService publisherService;

	@Mock
	private CreditBusinessApiCallsHelper apiHelper;

	@Mock
	private Executor customExecutor;

	@Value("${api.omcreditapplicationservice.getprofession.get.url}")
	private String getOccupationUrl;

	@Value("${api.omcreditapplicationservice.getemail.get.url}")
	private String getEmailUrl;

	@Value("${api.omcreditapplicationservice.getdocument.get.url}")
	private String getDocumentUrl;

	@Mock
	MasterDataRedisClientHelper masterDataRedisClientHelper;
	
	@Mock
	DelegateExecution execution;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test(expected = CompletionException.class)
	public void updateApplicantDataTest() {
		Gson g = new Gson();
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put("applicationid", "242425");
		queryParam.put("userattributekey","242525");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("111111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("23353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICANTID)).thenReturn("35353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE)).thenReturn("OMSL");
		Mockito.when(execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE_VERIFY)).thenReturn(getNSDLResponseObject("2021-01-13T07:19:34.367+0000"));
		Mockito.doAnswer((InvocationOnMock invocation) -> {
			((Runnable) invocation.getArguments()[0]).run();
			return null;
		}).when(customExecutor).execute(Mockito.any(Runnable.class));
		String json = "{\"applicationKey\": \"1100000000013659\",\"applicationUserAttributeKey\": \"13199\",\"applicationUserAttributeType\": \"1\",\"mobile\":\"8600498484\",\"dateOfBirth\": \"1991-05-04\",\"name\": {\"firstName\": \"Test\",\"middleName\": \"\",\"lastName\": \"Test\"},\"maritalStatusKey\": 27,\"genderKey\": 22,\"residenceTypeKey\": 1}";
		UserProfileBean userProfileBean = g.fromJson(json, UserProfileBean.class);
		Mockito.when(apiHelper.getUserProfile(Mockito.any())).thenReturn(userProfileBean);
		applicantUpdateDetails.updateApplicantData(execution);
	}
	
	@Test(expected = CompletionException.class)
	public void updateApplicantDataTest_InvalidVerificationDate() {
		Gson g = new Gson();
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put("applicationid", "242425");
		queryParam.put("userattributekey","242525");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("111111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("23353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICANTID)).thenReturn("35353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE)).thenReturn("OMSL");
		Mockito.when(execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE_VERIFY)).thenReturn(getNSDLResponseObject("2021-01-13"));
		Mockito.doAnswer((InvocationOnMock invocation) -> {
			((Runnable) invocation.getArguments()[0]).run();
			return null;
		}).when(customExecutor).execute(Mockito.any(Runnable.class));
		String json = "{\"applicationKey\": \"1100000000013659\",\"applicationUserAttributeKey\": \"13199\",\"applicationUserAttributeType\": \"1\",\"mobile\":\"8600498484\",\"dateOfBirth\": \"1991-05-04\",\"name\": {\"firstName\": \"Test\",\"middleName\": \"\",\"lastName\": \"Test\"},\"maritalStatusKey\": 27,\"genderKey\": 22,\"residenceTypeKey\": 1}";
		UserProfileBean userProfileBean = g.fromJson(json, UserProfileBean.class);
		Mockito.when(apiHelper.getUserProfile(Mockito.any())).thenReturn(userProfileBean);
		applicantUpdateDetails.updateApplicantData(execution);
	}
	
	@Test(expected = CompletionException.class)
	public void updateApplicantDataTest__SortedExactMatch() {
		Gson g = new Gson();
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put("applicationid", "242425");
		queryParam.put("userattributekey","242525");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("111111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("23353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICANTID)).thenReturn("35353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE)).thenReturn("OMSL");
		Mockito.when(execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE_VERIFY)).thenReturn(getNSDLResponseObject_SortedExactMatch("2021-01-13T07:19:34.367+0000"));
		Mockito.doAnswer((InvocationOnMock invocation) -> {
			((Runnable) invocation.getArguments()[0]).run();
			return null;
		}).when(customExecutor).execute(Mockito.any(Runnable.class));
		String json = "{\"applicationKey\": \"1100000000013659\",\"applicationUserAttributeKey\": \"13199\",\"applicationUserAttributeType\": \"1\",\"mobile\":\"8600498484\",\"dateOfBirth\": \"1991-05-04\",\"name\": {\"firstName\": \"Test\",\"middleName\": \"\",\"lastName\": \"Test\"},\"maritalStatusKey\": 27,\"genderKey\": 22,\"residenceTypeKey\": 1}";
		UserProfileBean userProfileBean = g.fromJson(json, UserProfileBean.class);
		Mockito.when(apiHelper.getUserProfile(Mockito.any())).thenReturn(userProfileBean);
		applicantUpdateDetails.updateApplicantData(execution);
	}
	
	@Test(expected = NullPointerException.class)
	public void updateApplicantAddressTest() {
		Gson g = new Gson();
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put("applicationid", "242425");
		queryParam.put("userattributekey","242525");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("111111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("23353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICANTID)).thenReturn("35353");
		Mockito.doAnswer((InvocationOnMock invocation) -> {
			((Runnable) invocation.getArguments()[0]).run();
			return null;
		}).when(customExecutor).execute(Mockito.any(Runnable.class));
		String json = "{\"applicationKey\": \"1100000000013659\",\"applicationUserAttributeKey\": \"13199\",\"applicationUserAttributeType\": \"1\",\"mobile\":\"8600498484\",\"dateOfBirth\": \"1991-05-04\",\"name\": {\"firstName\": \"Test\",\"middleName\": \"\",\"lastName\": \"Test\"},\"maritalStatusKey\": 27,\"genderKey\": 22,\"residenceTypeKey\": 1}";
		UserProfileBean userProfileBean = g.fromJson(json, UserProfileBean.class);
		Mockito.when(apiHelper.getUserProfile(queryParam)).thenReturn(userProfileBean);
		applicantUpdateDetails.updateApplicantAddress(execution);
	}
	
	private JSONObject getNSDLResponseObject(String verificationDate){
		Map<String, Object> rule1 = new HashMap<>();
		Map<String, Object> rule2 = new HashMap<>();
		rule1.put("ruleName", "exact_match");
		rule1.put("ruleValue", "1");
		rule2.put("ruleName", "sorted_exact_match");
		rule2.put("ruleValue", "1");
		List<Map<String, Object>> ruleList = new ArrayList<Map<String, Object>>();
		ruleList.add(rule1);
		ruleList.add(rule2);
		Map<String, Object> verificationObject = new HashMap<>();
		verificationObject.put("isVerified", true);
		verificationObject.put("verificationSource", "NSDL");
		verificationObject.put("verificationDate", verificationDate);
		verificationObject.put("verificationReference", 9024);
		verificationObject.put("verifyingProductCategoryKey", 10003);
		JSONObject nsdlPanVerResponse = new JSONObject();
		nsdlPanVerResponse.put("ruleDetails", ruleList);
		nsdlPanVerResponse.put("verification", verificationObject);
		return nsdlPanVerResponse;
	}
	
	private JSONObject getNSDLResponseObject_SortedExactMatch(String verificationDate){
		Map<String, Object> rule1 = new HashMap<>();
		Map<String, Object> rule2 = new HashMap<>();
		rule1.put("ruleName", "exact_match");
		rule1.put("ruleValue", "0");
		rule2.put("ruleName", "sorted_exact_match");
		rule2.put("ruleValue", "1");
		List<Map<String, Object>> ruleList = new ArrayList<Map<String, Object>>();
		ruleList.add(rule1);
		ruleList.add(rule2);
		Map<String, Object> verificationObject = new HashMap<>();
		verificationObject.put("isVerified", true);
		verificationObject.put("verificationSource", "NSDL");
		verificationObject.put("verificationDate", verificationDate);
		verificationObject.put("verificationReference", 9024);
		verificationObject.put("verifyingProductCategoryKey", 10003);
		JSONObject nsdlPanVerResponse = new JSONObject();
		nsdlPanVerResponse.put("ruleDetails", ruleList);
		nsdlPanVerResponse.put("verification", verificationObject);
		return nsdlPanVerResponse;
	}
	
	@Test
	public void updateApplicantDataTest_OccupationUpdateWithoutProfession() {
		Gson g = new Gson();
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put("applicationid", "242425");
		queryParam.put("userattributekey", "242525");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATIONID)).thenReturn("12345");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("111111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("23353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICANTID)).thenReturn("35353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE)).thenReturn("OMSL");
		Mockito.when(execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE_VERIFY))
				.thenReturn(getNSDLResponseObject("2021-01-13T07:19:34.367+0000"));
		Mockito.when(execution.getVariable(CreditBusinessConstants.MOBILE)).thenReturn("9876543210");
		Mockito.doAnswer((InvocationOnMock invocation) -> {
			((Runnable) invocation.getArguments()[0]).run();
			return null;
		}).when(customExecutor).execute(Mockito.any(Runnable.class));
		String json = "{\"applicationKey\": \"1100000000013659\",\"applicationUserAttributeKey\": \"13199\",\"applicationUserAttributeType\": \"1\",\"mobile\":\"8600498484\",\"dateOfBirth\": \"1991-05-04\",\"name\": {\"firstName\": \"Test\",\"middleName\": \"\",\"lastName\": \"Test\"},\"maritalStatusKey\": 27,\"genderKey\": 22,\"residenceTypeKey\": 1}";
		UserProfileBean userProfileBean = g.fromJson(json, UserProfileBean.class);
		Mockito.when(apiHelper.getUserProfile(Mockito.any())).thenReturn(userProfileBean);
		Mockito.when(apiHelper.callApi(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(getOccupation());
		PublishResult result = new PublishResult();
		result.setMessageId("1234567");
		Mockito.when(publisherService.publish(Mockito.any(), Mockito.any())).thenReturn(result);
		applicantUpdateDetails.updateApplicantData(execution);
	}

	private com.bajaj.markets.credit.business.beans.Occupation getOccupation() {
		Occupation occupation = new Occupation();
		Reference occupationReference = new Reference();
		occupationReference.setCode("SEMP");
		occupationReference.setKey(2l);
		occupationReference.setValue("Self Employed");
		occupation.setOcupationType(occupationReference);
		return occupation;
	}

	@Test
	public void updateApplicantDataTest_OccupationUpdateWithProfession() {
		Gson g = new Gson();
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put("applicationid", "242425");
		queryParam.put("userattributekey", "242525");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATIONID)).thenReturn("12345");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("111111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("23353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICANTID)).thenReturn("35353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE)).thenReturn("OMSL");
		Mockito.when(execution.getVariable(CreditBusinessConstants.NSDLPANRESPONSE_VERIFY))
				.thenReturn(getNSDLResponseObject("2021-01-13T07:19:34.367+0000"));
		Mockito.when(execution.getVariable(CreditBusinessConstants.MOBILE)).thenReturn("9876543210");
		Mockito.doAnswer((InvocationOnMock invocation) -> {
			((Runnable) invocation.getArguments()[0]).run();
			return null;
		}).when(customExecutor).execute(Mockito.any(Runnable.class));
		String json = "{\"applicationKey\": \"1100000000013659\",\"applicationUserAttributeKey\": \"13199\",\"applicationUserAttributeType\": \"1\",\"mobile\":\"8600498484\",\"dateOfBirth\": \"1991-05-04\",\"name\": {\"firstName\": \"Test\",\"middleName\": \"\",\"lastName\": \"Test\"},\"maritalStatusKey\": 27,\"genderKey\": 22,\"residenceTypeKey\": 1}";
		UserProfileBean userProfileBean = g.fromJson(json, UserProfileBean.class);
		Mockito.when(apiHelper.getUserProfile(Mockito.any())).thenReturn(userProfileBean);
		Occupation occupation = new Occupation();
		Reference occupationReference = new Reference();
		occupationReference.setCode("DOCSAL");
		occupationReference.setKey(2l);
		occupationReference.setValue("Salaried Doctor");
		occupation.setOcupationType(occupationReference);
		Mockito.when(apiHelper.callApi(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(occupation);
		PublishResult result = new PublishResult();
		result.setMessageId("1234567");
		Mockito.when(publisherService.publish(Mockito.any(), Mockito.any())).thenReturn(result);
		applicantUpdateDetails.updateApplicantData(execution);
	}

	@Test
	public void updateApplicantDataTest_OccupatiomType_DOCSEMP() {
		Gson g = new Gson();
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put("applicationid", "242425");
		queryParam.put("userattributekey", "242525");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATIONID)).thenReturn("12345");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_ID)).thenReturn("111111");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICATION_USER_ATTRIBUTE_KEY)).thenReturn("23353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.APPLICANTID)).thenReturn("35353");
		Mockito.when(execution.getVariable(CreditBusinessConstants.L2_PRODUCT_CODE)).thenReturn("OMSL");
		Mockito.when(execution.getVariable(CreditBusinessConstants.MOBILE)).thenReturn("9876543210");
		Mockito.doAnswer((InvocationOnMock invocation) -> {
			((Runnable) invocation.getArguments()[0]).run();
			return null;
		}).when(customExecutor).execute(Mockito.any(Runnable.class));
		String json = "{\"applicationKey\": \"1100000000013659\",\"applicationUserAttributeKey\": \"13199\",\"applicationUserAttributeType\": \"1\",\"mobile\":\"8600498484\",\"dateOfBirth\": \"1991-05-04\",\"name\": {\"firstName\": \"Test\",\"middleName\": \"\",\"lastName\": \"Test\"},\"maritalStatusKey\": 27,\"genderKey\": 22,\"residenceTypeKey\": 1}";
		UserProfileBean userProfileBean = g.fromJson(json, UserProfileBean.class);
		Mockito.when(apiHelper.getUserProfile(Mockito.any())).thenReturn(userProfileBean);
		Occupation occupation = new Occupation();
		Reference occupationReference = new Reference();
		occupationReference.setCode("DOCSEMP");
		occupationReference.setKey(7l);
		occupationReference.setValue("SelfEmployed Doctor");
		occupation.setOcupationType(occupationReference);
		Mockito.when(apiHelper.callApi(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(occupation);
		PublishResult result = new PublishResult();
		result.setMessageId("1234567");
		Mockito.when(publisherService.publish(Mockito.any(), Mockito.any())).thenReturn(result);
		applicantUpdateDetails.updateApplicantData(execution);
	}
}
