/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.otp.dao;

import com.bajaj.bfsd.otp.dto.GetOtp;
import com.bajaj.bfsd.otp.model.OtpGenTran;
import com.bajaj.bfsd.otp.model.OtpPolicy;

/**
 * Interface to perform OTP generation and validation DAO operations.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	23/12/2016      Initial Version
 */
public interface OTPDao {
    
    /**
     * Getter method for otp policy.
     *
     * @param policyName the policy name
     * @return otp policy
     */
    public OtpPolicy getOtpPolicy(String policyName);
    
    public OtpGenTran saveOtp(OtpGenTran genTran);

    public String validateOtp(OtpGenTran genTran);

	public String getOtp(GetOtp getOtp);
}
