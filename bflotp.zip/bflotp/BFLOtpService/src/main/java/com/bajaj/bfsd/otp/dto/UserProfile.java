package com.bajaj.bfsd.otp.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



/**
 * The persistent class for the USER_PROFILES database table.
 * 
 */
@Entity
@Table(name = "USER_PROFILES")
@NamedQuery(name = "UserProfile.findAll", query = "SELECT u FROM UserProfile u")
public class UserProfile implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userprofilekey;

	@Temporal(TemporalType.DATE)
	private Date associationdt;

	private String associationid;

	private BigDecimal associationtype;

	@Temporal(TemporalType.DATE)
	private Date dateofbirth;

	private String designation;

	private String emailid;

	private String firstname;

	private BigDecimal genderkey;

	private BigDecimal isactive;

	private String lastname;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal maritalstatuskey;

	private String middlename;

	private String mobileno;

	private BigDecimal salutationkey;

	// bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name = "USERKEY")
	private BfsdUser bfsdUser;

	/** Vendor Data */

	private String address;

	private Long city;

	private String companyname;

	private String contactpersonname;

	private String gst;

	private String landline;

	private String pan;

	private String parentuseremailid;

	private String partnerkey;

	private String servicekey;

	private String pincode;

	@OneToOne
	@JoinColumn(name = "PARENTCOMPANY")
	private UserProfile parentCompany;

	public long getUserprofilekey() {
		return this.userprofilekey;
	}

	public void setUserprofilekey(long userprofilekey) {
		this.userprofilekey = userprofilekey;
	}

	public Date getAssociationdt() {
		return this.associationdt;
	}

	public void setAssociationdt(Date associationdt) {
		this.associationdt = associationdt;
	}

	public String getAssociationid() {
		return this.associationid;
	}

	public void setAssociationid(String associationid) {
		this.associationid = associationid;
	}

	public BigDecimal getAssociationtype() {
		return this.associationtype;
	}

	public void setAssociationtype(BigDecimal associationtype) {
		this.associationtype = associationtype;
	}

	public Date getDateofbirth() {
		return this.dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getDesignation() {
		return this.designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmailid() {
		return this.emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public BigDecimal getGenderkey() {
		return this.genderkey;
	}

	public void setGenderkey(BigDecimal genderkey) {
		this.genderkey = genderkey;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getMaritalstatuskey() {
		return this.maritalstatuskey;
	}

	public void setMaritalstatuskey(BigDecimal maritalstatuskey) {
		this.maritalstatuskey = maritalstatuskey;
	}

	public String getMiddlename() {
		return this.middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getMobileno() {
		return this.mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public BigDecimal getSalutationkey() {
		return this.salutationkey;
	}

	public void setSalutationkey(BigDecimal salutationkey) {
		this.salutationkey = salutationkey;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getCity() {
		return city;
	}

	public void setCity(Long city) {
		this.city = city;
	}

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public String getContactpersonname() {
		return contactpersonname;
	}

	public void setContactpersonname(String contactpersonname) {
		this.contactpersonname = contactpersonname;
	}

	public String getGst() {
		return gst;
	}

	public void setGst(String gst) {
		this.gst = gst;
	}

	public String getLandline() {
		return landline;
	}

	public void setLandline(String landline) {
		this.landline = landline;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getParentuseremailid() {
		return parentuseremailid;
	}

	public void setParentuseremailid(String parentuseremailid) {
		this.parentuseremailid = parentuseremailid;
	}

	public String getPartnerkey() {
		return partnerkey;
	}

	public void setPartnerkey(String partnerkey) {
		this.partnerkey = partnerkey;
	}

	public String getServicekey() {
		return servicekey;
	}

	public void setServicekey(String servicekey) {
		this.servicekey = servicekey;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public UserProfile getParentCompany() {
		return parentCompany;
	}

	public void setParentCompany(UserProfile parentCompany) {
		this.parentCompany = parentCompany;
	}
}