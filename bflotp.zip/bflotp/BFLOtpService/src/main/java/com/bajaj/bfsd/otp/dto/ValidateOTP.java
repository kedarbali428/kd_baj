package com.bajaj.bfsd.otp.dto;

import org.hibernate.validator.constraints.NotEmpty;

public class ValidateOTP {

	private String mobile;
	@NotEmpty(message = "OTP_804")
	private String otp;
	
	private String email;
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
