package com.bajaj.bfsd.otp.service.impl;

import java.lang.reflect.UndeclaredThrowableException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.sql.Timestamp;
import java.util.Arrays;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerHeader;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.otp.dto.GenerateOTP;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.otp.constants.OTPUtil;
import com.bajaj.bfsd.otp.dao.OTPDao;

import com.bajaj.bfsd.otp.dto.GetOtp;
import com.bajaj.bfsd.otp.dto.OTP;
import com.bajaj.bfsd.otp.dto.ValidateOTP;
import com.bajaj.bfsd.otp.model.OtpGenTran;
import com.bajaj.bfsd.otp.model.OtpPolicy;
import com.bajaj.bfsd.otp.service.OTPService;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

/**
 * This class is a service IMPL class for OTP service.
 * 
 * @author 604135
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          604135          01/19/2017      Initial Version
 *
 */
@Component
@RefreshScope
public class OTPServiceImpl extends BFLComponent implements OTPService {

    private static final String VERIFICATION = "Verification";

	private static final String RESUME = "Resume";

	@Autowired
    private OTPDao otpDao; 
    
    @Autowired
    Environment env;
    
	@Autowired
	BFLLoggerUtilExt logger;
    
    private static final String THIS_CLASS = OTPServiceImpl.class.getCanonicalName();
    private static final int[] DIGITS_POWER
    = {1,10,100,1000,10000,100000,1000000,10000000,100000000 };
    
    @Override
    public OtpPolicy getOtpPolicy(String policyName) {
        
        return otpDao.getOtpPolicy(policyName); 
            
    }

    @Override
	public OTP getOtp(String requester, OtpPolicy otpPolicy, GenerateOTP generateOTP) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(BFLLoggerHeader.ID.getValue(), OTPUtil.getCorelationId());
		OTP otp = new OTP();
		long first14 = (long) (Math.random() * 100000000000000L);
		String steps = String.valueOf(5200000000000000L + first14);
		String otpValue = generateTOTP(otpPolicy.getOpencryptionkey(), steps, "6", otpPolicy.getOpalgorithm());
		Long duration = ((otpPolicy.getOpexpirytime().longValue() * 60) + 59) * 1000;
		Timestamp genrationTime = OTPUtil.getCurrentTimestamp();
		Timestamp expTime = new Timestamp(genrationTime.getTime() + duration);
		OtpGenTran genTran = createGenTran(requester, otpPolicy, generateOTP, otpValue, genrationTime, expTime);
		otp.setExpitationTime(expTime);
		
		//logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "OTP generation is MFA flasg received: "+generateOTP.toString());
		if (generateOTP.isMfa() ||  (null != generateOTP.getEmail() && !generateOTP.getEmail().isEmpty()) ) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Saving OTP in database : "+generateOTP.toString());
			otpDao.saveOtp(genTran);
		}else{
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "OTP generation is skipped as IS mFa falg is false");
		}
	
		if (generateOTP.isMfa() && "N".equalsIgnoreCase(env.getProperty("mocked"))) {
				if (!otpValue.isEmpty()) {
					String[] products=env.getProperty("PRODUCTS").split(",");
					if(null != generateOTP.getProductcatcode() && (Arrays.asList(products).contains(generateOTP.getProductcatcode()))){
						if(null !=generateOTP.getStage() && generateOTP.getStage().equals(RESUME)){
							JSONObject notificationJson = new JSONObject();
							notificationJson.put("notificationTypeCode", "SMSOTP_RESUME");
							JSONObject templatedata = new JSONObject();
							templatedata.put("phoneNumber", generateOTP.getMobile());
							templatedata.put("mobile", generateOTP.getMobile());
							templatedata.put("otp", otpValue);
							templatedata.put("time", env.getProperty("NOTIFICATION_TIME"));
							templatedata.put("generatedTime", OTPUtil.formatToISTTimestamp(genrationTime));
							notificationJson.put("templateDataMap", templatedata);
							ResponseEntity<ResponseBean> responseEntity = BFLCommonRestClient.create(
									env.getProperty("api.notifications.sendnotifications.POST.url"), null, String.class, null,
									notificationJson.toString(), headers);
							return sendOtp(otpPolicy, otp, otpValue, genrationTime, responseEntity); 
						}
						else if(null != generateOTP.getStage() && generateOTP.getStage().equals(VERIFICATION)){
							JSONObject notificationJson = new JSONObject();
							notificationJson.put("notificationTypeCode", "SMSOTP_VERIFICATION");
							JSONObject templatedata = new JSONObject();
							templatedata.put("phoneNumber", generateOTP.getMobile());
							templatedata.put("mobile", generateOTP.getMobile());
							templatedata.put("otp", otpValue);
							templatedata.put("time", env.getProperty("NOTIFICATION_TIME"));
							templatedata.put("generatedTime", OTPUtil.formatToISTTimestamp(genrationTime));
							notificationJson.put("templateDataMap", templatedata);
							ResponseEntity<ResponseBean> responseEntity = BFLCommonRestClient.create(
									env.getProperty("api.notifications.sendnotifications.POST.url"), null, String.class, null,
									notificationJson.toString(), headers);
							return sendOtp(otpPolicy, otp, otpValue, genrationTime, responseEntity);
						
						}
						else{
							logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "OTP generation failed");
							throw new BFLTechnicalException("OTP_808", env.getProperty("OTP_808"));
						}
					}
					else{
						JSONObject notificationJson = new JSONObject();
						notificationJson.put("notificationTypeCode", "SMSOTP");
						JSONObject templatedata = new JSONObject();
						templatedata.put("phoneNumber", generateOTP.getMobile());
						templatedata.put("mobile", generateOTP.getMobile());
						templatedata.put("otp", otpValue);
						templatedata.put("time", env.getProperty("NOTIFICATION_TIME"));
						templatedata.put("generatedTime", OTPUtil.formatToISTTimestamp(genrationTime));
						notificationJson.put("templateDataMap", templatedata);
						ResponseEntity<ResponseBean> responseEntity = BFLCommonRestClient.create(
								env.getProperty("api.notifications.sendnotifications.POST.url"), null, String.class, null,
								notificationJson.toString(), headers);
						return sendOtp(otpPolicy, otp, otpValue, genrationTime, responseEntity);
					
					}
				} else {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "OTP generation failed");
					throw new BFLTechnicalException("OTP_808", env.getProperty("OTP_808"));
				}
			} else {
				otp.setOtpValue(otpValue);
				otp.setGenarationTime(OTPUtil.formatToISTTimestamp(genrationTime));
				otp.setValidMins(otpPolicy.getOpexpirytime().toString());
				return otp;
			}
	}

	private OTP sendOtp(OtpPolicy otpPolicy, OTP otp, String otpValue, Timestamp genrationTime,
			ResponseEntity<ResponseBean> responseEntity) {
		if (null != responseEntity && HttpStatus.OK.equals(responseEntity.getStatusCode())
				&& StatusCode.SUCCESS.equals((responseEntity.getBody()).getStatus())) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "OTP sent successfully");
			otp.setOtpValue(otpValue);
			otp.setGenarationTime(OTPUtil.formatToISTTimestamp(genrationTime));
			otp.setValidMins(otpPolicy.getOpexpirytime().toString());
			return otp;
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "OTP sending failed");
			throw new BFLTechnicalException("OTP_807", env.getProperty("OTP_807"));
		}
	}

	private OtpGenTran createGenTran(String requester, OtpPolicy otpPolicy, GenerateOTP generateOTP, String otpValue,
			Timestamp genrationTime, Timestamp expTime) {
		OtpGenTran genTran = new OtpGenTran();
		genTran.setOtpPolicy(otpPolicy);
//		genTran.setOgtrequester(requester);
		genTran.setOgtrequester(generateOTP.getProductcatcode());
		genTran.setOgtrequestdt(genrationTime);
		genTran.setOgtdefaultexpdt(expTime);
		genTran.setOgtemailid(generateOTP.getEmail());
		genTran.setOgtmobile(generateOTP.getMobile());
		genTran.setOgtisactive(new BigDecimal(1));
		genTran.setOgtlstupdatedt(genrationTime);
		genTran.setOtp(otpValue);
		return genTran;
	}
    

	@Override
	public String validateOtp(ValidateOTP validateOTP) {
		OtpGenTran genTran = new OtpGenTran();
		genTran.setOgtmobile(validateOTP.getMobile());
		genTran.setOgtemailid(validateOTP.getEmail());
		genTran.setOtp(validateOTP.getOtp());
		String otp = otpDao.validateOtp(genTran);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "OTP :" + otp);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE,
				"Input OTP :" + validateOTP.getOtp());
		if (null != otp && !otp.isEmpty() && otp.equalsIgnoreCase(validateOTP.getOtp())) {
			return "SUCCESS";
		} else {
			return "ERROR";
		}
	}
    
    /**
     * This method uses the JCE to provide the crypto
     * algorithm.
     * HMAC computes a Hashed Message Authentication Code with the
     * crypto hash algorithm as a parameter.
     *
     * @param crypto     the crypto algorithm (HmacSHA1)
     * @param keyBytes   the bytes to use for the HMAC key
     * @param text       the message or text to be authenticated.
     */
    private static byte[] hmacSha1(String crypto, byte[] keyBytes,
        byte[] text)
    {
        try {
            Mac hmac;
            hmac = Mac.getInstance(crypto);
            SecretKeySpec macKey =
                new SecretKeySpec(keyBytes, "RAW");
            hmac.init(macKey);
            return hmac.doFinal(text);
        } catch (GeneralSecurityException gse) {
            throw new UndeclaredThrowableException(gse);
        }
    }
    
    /**
     * This method converts HEX string to Byte[]
     *
     * @param hex   the HEX string
     *
     * @return      A byte array
     */
    private static byte[] hexStr2Bytes(String hex){
        // Adding one byte to get the right conversion
        // values starting with "0" can be converted
        byte[] bArray = new BigInteger("10" + hex,16).toByteArray();

        // Copy all the REAL bytes, not the "first"
        byte[] ret = new byte[bArray.length - 1];
        for (int i = 0; i < ret.length ; i++)
            ret[i] = bArray[i+1];
        return ret;
    }
    
    /**
     * This method generates an TOTP value for the given
     * set of parameters.
     *
     * @param key   the shared secret, HEX encoded
     * @param time     a value that reflects a time
     * @param returnDigits     number of digits to return
     * @param crypto    the crypto function to use
     *
     * @return      A numeric String in base 10 that includes
     *              {@link truncationDigits} digits
     */
    private static String generateTOTP(String key,
            String time,
            String returnDigits,
            String crypto)
    {
        int codeDigits = Integer.decode(returnDigits).intValue();
        String result;
        byte[] hash;

        // Using the counter
        // First 8 bytes are for the movingFactor
        // Complaint with base RFC 4226 (HOTP)
        while(time.length() < 16 )
            time = "0" + time; //NOSONAR

        // Get the HEX in a Byte[]
        byte[] msg = hexStr2Bytes("0" + time);

        // Adding one byte to get the right conversion
        byte[] k = hexStr2Bytes(key);

        hash = hmacSha1(crypto, k, msg);

        // put selected bytes into result int
        int offset = hash[hash.length - 1] & 0xf;

        int binary =
            ((hash[offset] & 0x7f) << 24) |
            ((hash[offset + 1] & 0xff) << 16) |
            ((hash[offset + 2] & 0xff) << 8) |
            (hash[offset + 3] & 0xff);

        int otp = binary % DIGITS_POWER[codeDigits];

        result = Integer.toString(otp);
        while (result.length() < codeDigits) {
            result = "0" + result;
        }
        return result;
    }
    
    @Override
    public String getOtp(GetOtp getOtp){
    	if(null!=getOtp.getEmail() && null!=getOtp.getMobile()){
    		throw new BFLBusinessException("OTP_814",env.getProperty("OTP_814"));
    	}
    	return otpDao.getOtp(getOtp);
    }
    
}
