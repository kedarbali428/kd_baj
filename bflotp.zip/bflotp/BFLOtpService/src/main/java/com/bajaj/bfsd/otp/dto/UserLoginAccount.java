package com.bajaj.bfsd.otp.dto;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the USER_LOGIN_ACCOUNTS database table.
 * 
 */
@Entity
@Table(name="USER_LOGIN_ACCOUNTS")
@NamedQuery(name="UserLoginAccount.findAll", query="SELECT u FROM UserLoginAccount u")
public class UserLoginAccount implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long userloginacckey;

	private Timestamp creationdate;

	private String loginid;

	private String loginpwd;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal userloginacctype;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="USERKEY")
	private BfsdUser bfsdUser;

	public long getUserloginacckey() {
		return this.userloginacckey;
	}

	public void setUserloginacckey(long userloginacckey) {
		this.userloginacckey = userloginacckey;
	}

	public Timestamp getCreationdate() {
		return this.creationdate;
	}

	public void setCreationdate(Timestamp creationdate) {
		this.creationdate = creationdate;
	}

	public String getLoginid() {
		return this.loginid;
	}

	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}

	public String getLoginpwd() {
		return this.loginpwd;
	}

	public void setLoginpwd(String loginpwd) {
		this.loginpwd = loginpwd;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getUserloginacctype() {
		return this.userloginacctype;
	}

	public void setUserloginacctype(BigDecimal userloginacctype) {
		this.userloginacctype = userloginacctype;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

}