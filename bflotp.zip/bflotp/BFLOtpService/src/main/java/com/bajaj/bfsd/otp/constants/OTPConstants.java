/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.otp.constants;
/**
 * This class is a constant class for OTP service.
 * 
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602          15/12/2016      Initial Version
 *
 */
public enum OTPConstants {

    /**
     * Variable to hold value for otp service app.
     */
    BFL_OTP_SERVICE_APP("BFLOtpService_APP"),
   
    /**
     * Variable to hold value for otp service exec.
     */
    BFL_OTP_SERVICE_EXC("BFLOtpService_EXC"),
    
    /**
     * Variable to hold value for otp service perf.
     */
    BFL_OTP_SERVICE_PERF("BFLOtpService_PERF");
	
	public static final String TRANSACTIONAL = "Transactional";
  
    /**
     * Variable to hold value for value.
     */
    private String value;
    
    /**
     * Instantiates a new otp service constants.
     *
     * @param value the value
     */
    private OTPConstants(String value) {
            this.value = value;
    }
    
    /**
     * Getter method for enum value.
     *
     * @return value
     */
    public String getValue() {
            return this.value;
    }
    
}
