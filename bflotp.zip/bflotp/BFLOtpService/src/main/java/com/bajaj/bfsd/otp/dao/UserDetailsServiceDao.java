package com.bajaj.bfsd.otp.dao;

import java.util.ArrayList;

import com.bajaj.bfsd.otp.dto.BfsdUser;


public interface UserDetailsServiceDao {
	public BfsdUser getBfsdUser(long userKey);
	public ArrayList<String> getApplicantEmail(long userKey);
	public ArrayList<String> getApplicantMobiles(long userKey);
}
