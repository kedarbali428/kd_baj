/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.otp.dto;

import java.util.Date;

/**
 * OTP Class.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	23/12/2016      Initial Version
 */
public class OTP {

	/**
	 * Variable to hold value for otp.
	 */
	private String otpValue;

	/**
	 * Variable to hold value for genaration time.
	 */
	private String genarationTime;

	/**
	 * Variable to hold value for OTP validity mins.
	 */
	private String validMins;
	/**
	 * Variable to hold value for OTP expiry.
	 */
	private Date expitationTime;

	/**
	 * @return
	 */
	public String getOtpValue() {
		return otpValue;
	}

	/**
	 * @param otpValue
	 */
	public void setOtpValue(String otpValue) {
		this.otpValue = otpValue;
	}

	/**
	 * Getter method for genaration time.
	 *
	 * @return genaration time
	 */
	public String getGenarationTime() {
		return genarationTime;
	}

	/**
	 * Sets the value of genaration time.
	 *
	 * @param genarationTime
	 *            the new genaration time
	 */
	public void setGenarationTime(String genarationTime) {
		this.genarationTime = genarationTime;
	}

	/**
	 * Getter method for valid mins.
	 *
	 * @return valid mins
	 */
	public String getValidMins() {
		return validMins;
	}

	/**
	 * Sets the value of valid mins.
	 *
	 * @param validMins
	 *            the new valid mins
	 */
	public void setValidMins(String validMins) {
		this.validMins = validMins;
	}

	public Date getExpitationTime() {
		return expitationTime;
	}

	public void setExpitationTime(Date expitationTime) {
		this.expitationTime = expitationTime;
	}
}
