package com.bajaj.bfsd.otp.dto;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the QUICK_LINK_LIST database table.
 * 
 */
@Entity
@Table(name="QUICK_LINK_LIST")
@NamedQuery(name="QuickLinkList.findAll", query="SELECT q FROM QuickLinkList q")
public class QuickLinkList implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long quicklinkkey;

	private BigDecimal displayorder;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String quicklinkaddress;

	private String quicklinkmodule;

	private String quicklinkname;

	//bi-directional many-to-one association to UserQuickLink
	@OneToMany(mappedBy="quickLinkList")
	private List<UserQuickLink> userQuickLinks;

	public long getQuicklinkkey() {
		return this.quicklinkkey;
	}

	public void setQuicklinkkey(long quicklinkkey) {
		this.quicklinkkey = quicklinkkey;
	}

	public BigDecimal getDisplayorder() {
		return this.displayorder;
	}

	public void setDisplayorder(BigDecimal displayorder) {
		this.displayorder = displayorder;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getQuicklinkaddress() {
		return this.quicklinkaddress;
	}

	public void setQuicklinkaddress(String quicklinkaddress) {
		this.quicklinkaddress = quicklinkaddress;
	}

	public String getQuicklinkmodule() {
		return this.quicklinkmodule;
	}

	public void setQuicklinkmodule(String quicklinkmodule) {
		this.quicklinkmodule = quicklinkmodule;
	}

	public String getQuicklinkname() {
		return this.quicklinkname;
	}

	public void setQuicklinkname(String quicklinkname) {
		this.quicklinkname = quicklinkname;
	}

	public List<UserQuickLink> getUserQuickLinks() {
		return this.userQuickLinks;
	}

	public void setUserQuickLinks(List<UserQuickLink> userQuickLinks) {
		this.userQuickLinks = userQuickLinks;
	}

	public UserQuickLink addUserQuickLink(UserQuickLink userQuickLink) {
		getUserQuickLinks().add(userQuickLink);
		userQuickLink.setQuickLinkList(this);

		return userQuickLink;
	}

	public UserQuickLink removeUserQuickLink(UserQuickLink userQuickLink) {
		getUserQuickLinks().remove(userQuickLink);
		userQuickLink.setQuickLinkList(null);

		return userQuickLink;
	}

}