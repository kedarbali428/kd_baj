package com.bajaj.bfsd.otp.service;

import java.util.ArrayList;

import com.bajaj.bfsd.otp.dto.BfsdUser;

public interface UserDetailsService {
	public BfsdUser getBfsdUser(long userKey);

	public ArrayList<String> getApplicantEmail(long userKey);

	public ArrayList<String> getApplicantMobiles(long userKey);
}
