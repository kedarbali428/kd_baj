package com.bajaj.bfsd.otp.dao.impl;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bajaj.bfsd.otp.dao.UserDetailsServiceDao;
import com.bajaj.bfsd.otp.dto.BfsdUser;

@Repository("UserDetailsServiceDao")
public class UserDetailsServiceDaoImpl implements UserDetailsServiceDao {

	@Autowired
	EntityManager entityManager;

	@Override
	public BfsdUser getBfsdUser(long userKey) {

		String sql = "SELECT BFSD_USERS.* FROM BFSD_USERS WHERE USERKEY  = ?";
		Query query = entityManager.createNativeQuery(sql, BfsdUser.class);
		query.setParameter(1, userKey);
		return (BfsdUser) query.getSingleResult();
	}

	@Override
	public ArrayList<String> getApplicantEmail(long userKey) {
		String sql = "SELECT DISTINCT APLTEMAILADDRESS FROM APPLICANT_EMAILS WHERE APPLICANTKEY IN (SELECT APPLICANTKEY FROM ORGSYSADM.USER_APPLICANT WHERE USERKEY = ? )";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, userKey);
		ArrayList<String> resultList = (ArrayList<String>) query.getResultList();
		return resultList;
	}

	@Override
	public ArrayList<String> getApplicantMobiles(long userKey) {
		String sql = "SELECT DISTINCT APLTPHNUMNUMBER FROM APPLICANT_PHONE_NUMBERS WHERE APPLICANTKEY IN (SELECT APPLICANTKEY FROM ORGSYSADM.USER_APPLICANT WHERE USERKEY = ? )";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter(1, userKey);
		ArrayList<String> resultList = (ArrayList<String>) query.getResultList();
		return resultList;
	}
}
