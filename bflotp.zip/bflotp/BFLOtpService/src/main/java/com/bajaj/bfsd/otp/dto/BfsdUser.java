package com.bajaj.bfsd.otp.dto;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

/**
 * The persistent class for the BFSD_USERS database table.
 * 
 */
@Entity
@Table(name = "BFSD_USERS")
@NamedQuery(name = "BfsdUser.findAll", query = "SELECT b FROM BfsdUser b")
public class BfsdUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userkey;

	private BigDecimal failedlogincount;

	private BigDecimal isactive;

	private Timestamp lstfailedlogindt;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private Timestamp registrationdate;

	private BigDecimal userblockedflg;

	private BigDecimal usertype;

	// bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name = "PARENTUSERKEY")
	private BfsdUser bfsdUser;

	// bi-directional many-to-one association to BfsdUser
	@OneToMany(mappedBy = "bfsdUser")
	private List<BfsdUser> bfsdUsers;

	// bi-directional many-to-one association to UserLoginAccount
	@OneToMany(mappedBy = "bfsdUser", cascade = CascadeType.ALL)
	private List<UserLoginAccount> userLoginAccounts;

	// bi-directional many-to-one association to UserLoginActivity
	@OneToMany(mappedBy = "bfsdUser")
	private List<UserLoginActivity> userLoginActivities;

	// bi-directional many-to-one association to UsersPwdChgHistory
	@OneToMany(mappedBy = "bfsdUser")
	private List<UsersPwdChgHistory> usersPwdChgHistories;

	// bi-directional many-to-one association to UserApplicant
	@OneToMany(mappedBy = "bfsdUser")
	private List<UserApplicant> userApplicants;

	// bi-directional many-to-one association to UserBlockHistory
	@OneToMany(mappedBy = "bfsdUser")
	private List<UserBlockHistory> userBlockHistories;

	// bi-directional many-to-one association to UserLoginActivityLog
	@OneToMany(mappedBy = "bfsdUser")
	private List<UserLoginActivityLog> userLoginActivityLogs;

	// bi-directional many-to-one association to UserProfile
	@OneToMany(mappedBy = "bfsdUser", cascade = CascadeType.ALL)
	private List<UserProfile> userProfiles;

	// bi-directional many-to-one association to UserQuickLink
	@OneToMany(mappedBy = "bfsdUser")
	private List<UserQuickLink> userQuickLinks;

	// bi-directional many-to-one association to UserResetRequest
	@OneToMany(mappedBy = "bfsdUser")
	private List<UserResetRequest> userResetRequests;
	
	
	public long getUserkey() {
		return this.userkey;
	}

	public void setUserkey(long userkey) {
		this.userkey = userkey;
	}

	public BigDecimal getFailedlogincount() {
		return this.failedlogincount;
	}

	public void setFailedlogincount(BigDecimal failedlogincount) {
		this.failedlogincount = failedlogincount;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public Timestamp getLstfailedlogindt() {
		return this.lstfailedlogindt;
	}

	public void setLstfailedlogindt(Timestamp lstfailedlogindt) {
		this.lstfailedlogindt = lstfailedlogindt;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Timestamp getRegistrationdate() {
		return this.registrationdate;
	}

	public void setRegistrationdate(Timestamp registrationdate) {
		this.registrationdate = registrationdate;
	}

	public BigDecimal getUserblockedflg() {
		return this.userblockedflg;
	}

	public void setUserblockedflg(BigDecimal userblockedflg) {
		this.userblockedflg = userblockedflg;
	}

	public BigDecimal getUsertype() {
		return this.usertype;
	}

	public void setUsertype(BigDecimal usertype) {
		this.usertype = usertype;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

	public List<BfsdUser> getBfsdUsers() {
		return this.bfsdUsers;
	}

	public void setBfsdUsers(List<BfsdUser> bfsdUsers) {
		this.bfsdUsers = bfsdUsers;
	}

	public BfsdUser addBfsdUser(BfsdUser bfsdUser) {
		getBfsdUsers().add(bfsdUser);
		bfsdUser.setBfsdUser(this);

		return bfsdUser;
	}

	public BfsdUser removeBfsdUser(BfsdUser bfsdUser) {
		getBfsdUsers().remove(bfsdUser);
		bfsdUser.setBfsdUser(null);

		return bfsdUser;
	}

	public List<UserLoginAccount> getUserLoginAccounts() {
		return this.userLoginAccounts;
	}

	public void setUserLoginAccounts(List<UserLoginAccount> userLoginAccounts) {
		this.userLoginAccounts = userLoginAccounts;
	}

	public UserLoginAccount addUserLoginAccount(UserLoginAccount userLoginAccount) {
		getUserLoginAccounts().add(userLoginAccount);
		userLoginAccount.setBfsdUser(this);

		return userLoginAccount;
	}

	public UserLoginAccount removeUserLoginAccount(UserLoginAccount userLoginAccount) {
		getUserLoginAccounts().remove(userLoginAccount);
		userLoginAccount.setBfsdUser(null);

		return userLoginAccount;
	}

	public List<UserLoginActivity> getUserLoginActivities() {
		return this.userLoginActivities;
	}

	public void setUserLoginActivities(List<UserLoginActivity> userLoginActivities) {
		this.userLoginActivities = userLoginActivities;
	}

	public UserLoginActivity addUserLoginActivity(UserLoginActivity userLoginActivity) {
		getUserLoginActivities().add(userLoginActivity);
		userLoginActivity.setBfsdUser(this);

		return userLoginActivity;
	}

	public UserLoginActivity removeUserLoginActivity(UserLoginActivity userLoginActivity) {
		getUserLoginActivities().remove(userLoginActivity);
		userLoginActivity.setBfsdUser(null);

		return userLoginActivity;
	}

	public List<UsersPwdChgHistory> getUsersPwdChgHistories() {
		return this.usersPwdChgHistories;
	}

	public void setUsersPwdChgHistories(List<UsersPwdChgHistory> usersPwdChgHistories) {
		this.usersPwdChgHistories = usersPwdChgHistories;
	}

	public UsersPwdChgHistory addUsersPwdChgHistory(UsersPwdChgHistory usersPwdChgHistory) {
		getUsersPwdChgHistories().add(usersPwdChgHistory);
		usersPwdChgHistory.setBfsdUser(this);

		return usersPwdChgHistory;
	}

	public UsersPwdChgHistory removeUsersPwdChgHistory(UsersPwdChgHistory usersPwdChgHistory) {
		getUsersPwdChgHistories().remove(usersPwdChgHistory);
		usersPwdChgHistory.setBfsdUser(null);

		return usersPwdChgHistory;
	}

	public List<UserApplicant> getUserApplicants() {
		return this.userApplicants;
	}

	public void setUserApplicants(List<UserApplicant> userApplicants) {
		this.userApplicants = userApplicants;
	}

	public UserApplicant addUserApplicant(UserApplicant userApplicant) {
		getUserApplicants().add(userApplicant);
		userApplicant.setBfsdUser(this);

		return userApplicant;
	}

	public UserApplicant removeUserApplicant(UserApplicant userApplicant) {
		getUserApplicants().remove(userApplicant);
		userApplicant.setBfsdUser(null);

		return userApplicant;
	}

	public List<UserBlockHistory> getUserBlockHistories() {
		return this.userBlockHistories;
	}

	public void setUserBlockHistories(List<UserBlockHistory> userBlockHistories) {
		this.userBlockHistories = userBlockHistories;
	}

	public UserBlockHistory addUserBlockHistory(UserBlockHistory userBlockHistory) {
		getUserBlockHistories().add(userBlockHistory);
		userBlockHistory.setBfsdUser(this);

		return userBlockHistory;
	}

	public UserBlockHistory removeUserBlockHistory(UserBlockHistory userBlockHistory) {
		getUserBlockHistories().remove(userBlockHistory);
		userBlockHistory.setBfsdUser(null);

		return userBlockHistory;
	}

	public List<UserLoginActivityLog> getUserLoginActivityLogs() {
		return this.userLoginActivityLogs;
	}

	public void setUserLoginActivityLogs(List<UserLoginActivityLog> userLoginActivityLogs) {
		this.userLoginActivityLogs = userLoginActivityLogs;
	}

	public UserLoginActivityLog addUserLoginActivityLog(UserLoginActivityLog userLoginActivityLog) {
		getUserLoginActivityLogs().add(userLoginActivityLog);
		userLoginActivityLog.setBfsdUser(this);

		return userLoginActivityLog;
	}

	public UserLoginActivityLog removeUserLoginActivityLog(UserLoginActivityLog userLoginActivityLog) {
		getUserLoginActivityLogs().remove(userLoginActivityLog);
		userLoginActivityLog.setBfsdUser(null);

		return userLoginActivityLog;
	}

	public List<UserProfile> getUserProfiles() {
		return this.userProfiles;
	}

	public void setUserProfiles(List<UserProfile> userProfiles) {
		this.userProfiles = userProfiles;
	}

	public UserProfile addUserProfile(UserProfile userProfile) {
		getUserProfiles().add(userProfile);
		userProfile.setBfsdUser(this);

		return userProfile;
	}

	public UserProfile removeUserProfile(UserProfile userProfile) {
		getUserProfiles().remove(userProfile);
		userProfile.setBfsdUser(null);

		return userProfile;
	}

	public List<UserQuickLink> getUserQuickLinks() {
		return this.userQuickLinks;
	}

	public void setUserQuickLinks(List<UserQuickLink> userQuickLinks) {
		this.userQuickLinks = userQuickLinks;
	}

	public UserQuickLink addUserQuickLink(UserQuickLink userQuickLink) {
		getUserQuickLinks().add(userQuickLink);
		userQuickLink.setBfsdUser(this);

		return userQuickLink;
	}

	public UserQuickLink removeUserQuickLink(UserQuickLink userQuickLink) {
		getUserQuickLinks().remove(userQuickLink);
		userQuickLink.setBfsdUser(null);

		return userQuickLink;
	}

	public List<UserResetRequest> getUserResetRequests() {
		return this.userResetRequests;
	}

	public void setUserResetRequests(List<UserResetRequest> userResetRequests) {
		this.userResetRequests = userResetRequests;
	}

	public UserResetRequest addUserResetRequest(UserResetRequest userResetRequest) {
		getUserResetRequests().add(userResetRequest);
		userResetRequest.setBfsdUser(this);

		return userResetRequest;
	}

	public UserResetRequest removeUserResetRequest(UserResetRequest userResetRequest) {
		getUserResetRequests().remove(userResetRequest);
		userResetRequest.setBfsdUser(null);

		return userResetRequest;
	}

	/*@Override
	public String toString() {
		return "BfsdUser [userkey=" + userkey + ", failedlogincount=" + failedlogincount + ", isactive=" + isactive
				+ ", lstfailedlogindt=" + lstfailedlogindt + ", lstupdateby=" + lstupdateby + ", lstupdatedt="
				+ lstupdatedt + ", registrationdate=" + registrationdate + ", userblockedflg=" + userblockedflg
				+ ", usertype=" + usertype + ", bfsdUser=" + bfsdUser + ", bfsdUsers=" + bfsdUsers
				+ ", userLoginAccounts=" + userLoginAccounts + ", userLoginActivities=" + userLoginActivities
				+ ", usersPwdChgHistories=" + usersPwdChgHistories + ", userApplicants=" + userApplicants
				+ ", userBlockHistories=" + userBlockHistories + ", userLoginActivityLogs=" + userLoginActivityLogs
				+ ", userProfiles=" + userProfiles + ", userQuickLinks=" + userQuickLinks + ", userResetRequests="
				+ userResetRequests + "]";
	}*/
	
}