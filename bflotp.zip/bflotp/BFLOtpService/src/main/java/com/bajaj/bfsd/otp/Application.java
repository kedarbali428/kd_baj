package com.bajaj.bfsd.otp;

import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.PropertySource;

import com.bajaj.bfsd.common.business.baseclasses.BFLBusinessApplication;

/**
 * This class is main class for ApplicationStages service
 * 
 * @author 604135
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          604135          23/11/2016      Initial Version
 *
 */
@PropertySource("classpath:error.properties")
public class Application extends BFLBusinessApplication{

    /**
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
     }
}
