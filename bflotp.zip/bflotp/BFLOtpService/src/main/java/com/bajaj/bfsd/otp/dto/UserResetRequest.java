package com.bajaj.bfsd.otp.dto;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the USER_RESET_REQUESTS database table.
 * 
 */
@Entity
@Table(name="USER_RESET_REQUESTS")
@NamedQuery(name="UserResetRequest.findAll", query="SELECT u FROM UserResetRequest u")
public class UserResetRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long userresetreqkey;

	private String authenticationtoken;

	private String browser;

	private String deviceid;

	private String emailid;

	private String ipaddress;

	private BigDecimal isactive;

	private BigDecimal latitude;

	private BigDecimal longitude;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String mobilenum;

	private Timestamp reqexpirydt;

	private Timestamp reqforceexpirydt;

	private BigDecimal reqforceexpiryflg;

	private String reqforceexpiryreason;

	private BigDecimal reqsendmode;

	private Timestamp userresetreqdt;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="USERKEY")
	private BfsdUser bfsdUser;

	//bi-directional many-to-one association to UserResetReqAuthentication
	@OneToMany(mappedBy="userResetRequest")
	private List<UserResetReqAuthentication> userResetReqAuthentications;

	public long getUserresetreqkey() {
		return this.userresetreqkey;
	}

	public void setUserresetreqkey(long userresetreqkey) {
		this.userresetreqkey = userresetreqkey;
	}

	public String getAuthenticationtoken() {
		return this.authenticationtoken;
	}

	public void setAuthenticationtoken(String authenticationtoken) {
		this.authenticationtoken = authenticationtoken;
	}

	public String getBrowser() {
		return this.browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getDeviceid() {
		return this.deviceid;
	}

	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	public String getEmailid() {
		return this.emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getIpaddress() {
		return this.ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public BigDecimal getLatitude() {
		return this.latitude;
	}

	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	public BigDecimal getLongitude() {
		return this.longitude;
	}

	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getMobilenum() {
		return this.mobilenum;
	}

	public void setMobilenum(String mobilenum) {
		this.mobilenum = mobilenum;
	}

	public Timestamp getReqexpirydt() {
		return this.reqexpirydt;
	}

	public void setReqexpirydt(Timestamp reqexpirydt) {
		this.reqexpirydt = reqexpirydt;
	}

	public Timestamp getReqforceexpirydt() {
		return this.reqforceexpirydt;
	}

	public void setReqforceexpirydt(Timestamp reqforceexpirydt) {
		this.reqforceexpirydt = reqforceexpirydt;
	}

	public BigDecimal getReqforceexpiryflg() {
		return this.reqforceexpiryflg;
	}

	public void setReqforceexpiryflg(BigDecimal reqforceexpiryflg) {
		this.reqforceexpiryflg = reqforceexpiryflg;
	}

	public String getReqforceexpiryreason() {
		return this.reqforceexpiryreason;
	}

	public void setReqforceexpiryreason(String reqforceexpiryreason) {
		this.reqforceexpiryreason = reqforceexpiryreason;
	}

	public BigDecimal getReqsendmode() {
		return this.reqsendmode;
	}

	public void setReqsendmode(BigDecimal reqsendmode) {
		this.reqsendmode = reqsendmode;
	}

	public Timestamp getUserresetreqdt() {
		return this.userresetreqdt;
	}

	public void setUserresetreqdt(Timestamp userresetreqdt) {
		this.userresetreqdt = userresetreqdt;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

	public List<UserResetReqAuthentication> getUserResetReqAuthentications() {
		return this.userResetReqAuthentications;
	}

	public void setUserResetReqAuthentications(List<UserResetReqAuthentication> userResetReqAuthentications) {
		this.userResetReqAuthentications = userResetReqAuthentications;
	}

	public UserResetReqAuthentication addUserResetReqAuthentication(UserResetReqAuthentication userResetReqAuthentication) {
		getUserResetReqAuthentications().add(userResetReqAuthentication);
		userResetReqAuthentication.setUserResetRequest(this);

		return userResetReqAuthentication;
	}

	public UserResetReqAuthentication removeUserResetReqAuthentication(UserResetReqAuthentication userResetReqAuthentication) {
		getUserResetReqAuthentications().remove(userResetReqAuthentication);
		userResetReqAuthentication.setUserResetRequest(null);

		return userResetReqAuthentication;
	}

}