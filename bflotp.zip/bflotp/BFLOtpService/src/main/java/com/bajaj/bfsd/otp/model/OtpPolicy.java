package com.bajaj.bfsd.otp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the OTP_POLICIES database table.
 * 
 */
@Entity
@Table(name="OTP_POLICIES")
@NamedQuery(name="OtpPolicy.findAll", query="SELECT o FROM OtpPolicy o")
public class OtpPolicy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long otppolicykey;

	private String opalgorithm;

	private BigDecimal opencryptionflg;

	private String opencryptionkey;

	private BigDecimal opexpirytime;

	private BigDecimal opisactive;

	private String oplstupdateby;

	private Timestamp oplstupdatedt;

	private BigDecimal oppolicylength;

	private String oppolicymode;

	private String oppolicyname;

	//bi-directional many-to-one association to OtpGenTran
	@OneToMany(mappedBy="otpPolicy")
	private List<OtpGenTran> otpGenTrans;

	public OtpPolicy() {
	}

	public long getOtppolicykey() {
		return this.otppolicykey;
	}

	public void setOtppolicykey(long otppolicykey) {
		this.otppolicykey = otppolicykey;
	}

	public String getOpalgorithm() {
		return this.opalgorithm;
	}

	public void setOpalgorithm(String opalgorithm) {
		this.opalgorithm = opalgorithm;
	}

	public BigDecimal getOpencryptionflg() {
		return this.opencryptionflg;
	}

	public void setOpencryptionflg(BigDecimal opencryptionflg) {
		this.opencryptionflg = opencryptionflg;
	}

	public String getOpencryptionkey() {
		return this.opencryptionkey;
	}

	public void setOpencryptionkey(String opencryptionkey) {
		this.opencryptionkey = opencryptionkey;
	}

	public BigDecimal getOpexpirytime() {
		return this.opexpirytime;
	}

	public void setOpexpirytime(BigDecimal opexpirytime) {
		this.opexpirytime = opexpirytime;
	}

	public BigDecimal getOpisactive() {
		return this.opisactive;
	}

	public void setOpisactive(BigDecimal opisactive) {
		this.opisactive = opisactive;
	}

	public String getOplstupdateby() {
		return this.oplstupdateby;
	}

	public void setOplstupdateby(String oplstupdateby) {
		this.oplstupdateby = oplstupdateby;
	}

	public Timestamp getOplstupdatedt() {
		return this.oplstupdatedt;
	}

	public void setOplstupdatedt(Timestamp oplstupdatedt) {
		this.oplstupdatedt = oplstupdatedt;
	}

	public BigDecimal getOppolicylength() {
		return this.oppolicylength;
	}

	public void setOppolicylength(BigDecimal oppolicylength) {
		this.oppolicylength = oppolicylength;
	}

	public String getOppolicymode() {
		return this.oppolicymode;
	}

	public void setOppolicymode(String oppolicymode) {
		this.oppolicymode = oppolicymode;
	}

	public String getOppolicyname() {
		return this.oppolicyname;
	}

	public void setOppolicyname(String oppolicyname) {
		this.oppolicyname = oppolicyname;
	}

	public List<OtpGenTran> getOtpGenTrans() {
		return this.otpGenTrans;
	}

	public void setOtpGenTrans(List<OtpGenTran> otpGenTrans) {
		this.otpGenTrans = otpGenTrans;
	}

	public OtpGenTran addOtpGenTran(OtpGenTran otpGenTran) {
		getOtpGenTrans().add(otpGenTran);
		otpGenTran.setOtpPolicy(this);

		return otpGenTran;
	}

	public OtpGenTran removeOtpGenTran(OtpGenTran otpGenTran) {
		getOtpGenTrans().remove(otpGenTran);
		otpGenTran.setOtpPolicy(null);

		return otpGenTran;
	}

}