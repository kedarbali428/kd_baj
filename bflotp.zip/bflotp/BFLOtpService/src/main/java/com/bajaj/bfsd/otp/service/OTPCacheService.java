package com.bajaj.bfsd.otp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.cache.config.RedisConfig;
import com.bajaj.bfsd.common.cache.repository.SingleObjectCacheRepositoryImpl;
import com.bajaj.bfsd.otp.dto.GenerateOTP;

@Component
public class OTPCacheService {

	SingleObjectCacheRepositoryImpl<String, GenerateOTP> cacheRepository;

	@Autowired
	protected Environment env;

	@Autowired
	protected RedisConfig redisConfig;

	public GenerateOTP get(String mobileNumber) {
		return getCacheRepository().find(mobileNumber);
	}

	public GenerateOTP get(String mobileNumber, Long ttl) {
		return getCacheRepository().find(mobileNumber, ttl);
	}
	
	public void save(String mobileNumber, GenerateOTP entity, Long ttl) {
		getCacheRepository().save(mobileNumber, entity, ttl);
	}
	
	public void update(String mobileNumber, GenerateOTP entity, Long ttl) {
		getCacheRepository().update(mobileNumber, entity, ttl);
	}

	public void delete(String mobileNumber) {
		getCacheRepository().delete(mobileNumber);
	}

	private SingleObjectCacheRepositoryImpl<String, GenerateOTP> getCacheRepository() {
		if (null == this.cacheRepository) {
			cacheRepository = new SingleObjectCacheRepositoryImpl<>(GenerateOTP.class, env, redisConfig);
		}
		return cacheRepository;
	}
}