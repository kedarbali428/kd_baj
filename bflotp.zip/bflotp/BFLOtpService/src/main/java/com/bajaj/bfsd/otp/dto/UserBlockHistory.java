package com.bajaj.bfsd.otp.dto;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the USER_BLOCK_HISTORY database table.
 * 
 */
@Entity
@Table(name="USER_BLOCK_HISTORY")
@NamedQuery(name="UserBlockHistory.findAll", query="SELECT u FROM UserBlockHistory u")
public class UserBlockHistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long userblockhistorykey;

	private String blockreason;

	private String browser;

	private String deviceid;

	private String ipaddress;

	private BigDecimal latitude;

	private BigDecimal longitude;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private Timestamp userblockdt;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="USERKEY")
	private BfsdUser bfsdUser;

	public long getUserblockhistorykey() {
		return this.userblockhistorykey;
	}

	public void setUserblockhistorykey(long userblockhistorykey) {
		this.userblockhistorykey = userblockhistorykey;
	}

	public String getBlockreason() {
		return this.blockreason;
	}

	public void setBlockreason(String blockreason) {
		this.blockreason = blockreason;
	}

	public String getBrowser() {
		return this.browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getDeviceid() {
		return this.deviceid;
	}

	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	public String getIpaddress() {
		return this.ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public BigDecimal getLatitude() {
		return this.latitude;
	}

	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	public BigDecimal getLongitude() {
		return this.longitude;
	}

	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public Timestamp getUserblockdt() {
		return this.userblockdt;
	}

	public void setUserblockdt(Timestamp userblockdt) {
		this.userblockdt = userblockdt;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

}