package com.bajaj.bfsd.otp.service.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bajaj.bfsd.otp.dao.UserDetailsServiceDao;
import com.bajaj.bfsd.otp.dto.BfsdUser;
import com.bajaj.bfsd.otp.service.UserDetailsService;

@Service("UserDetailsService")
public class UserDetailsServiceImpl  implements UserDetailsService{

	@Autowired
	UserDetailsServiceDao userDetailsServiceDao;
	
	@Override
	public BfsdUser getBfsdUser(long userKey) {
		return userDetailsServiceDao.getBfsdUser(userKey);
	}

	@Override
	public ArrayList<String> getApplicantEmail(long userKey) {
		return userDetailsServiceDao.getApplicantEmail(userKey);
	}

	@Override
	public ArrayList<String> getApplicantMobiles(long userKey) {
		return userDetailsServiceDao.getApplicantMobiles(userKey);
	}
}
