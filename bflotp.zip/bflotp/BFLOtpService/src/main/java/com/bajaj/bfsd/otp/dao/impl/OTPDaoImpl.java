package com.bajaj.bfsd.otp.dao.impl;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.otp.constants.OTPUtil;
import com.bajaj.bfsd.otp.dao.OTPDao;
import com.bajaj.bfsd.otp.dto.GetOtp;
import com.bajaj.bfsd.otp.model.OtpGenTran;
import com.bajaj.bfsd.otp.model.OtpPolicy;
import com.bfl.common.exceptions.BFLBusinessException;

/**
 * This class is a DAO class for OTP service.
 * 
 * @author 604135
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          604135          01/19/2017      Initial Version
 *
 */

@Component
@RefreshScope
@SuppressWarnings("unchecked")
public class OTPDaoImpl extends BFLComponent implements OTPDao {

    private static final String OTP_812 = "OTP_812";

	private static final String OGTEMAILID = "ogtemailid";

	private static final String OGTISACTIVE = "ogtisactive";

	private static final String OGTMOBILE = "ogtmobile";
	
	private static final String OTP = "otp";
	private static final String OGTLSUPDATEDT = "ogtlstupdatedt";
	private static final String OGTDEFAULTEXPDT = "ogtdefaultexpdt";
	private static final String OGTREQUESTDT = "ogtrequestdt";

	@Autowired
    EntityManager entityManager;
	
	@Autowired
    Environment env;
    
	@Autowired
	BFLLoggerUtilExt logger;
    
    private static final String THIS_CLASS = OTPDaoImpl.class.getCanonicalName();
    
    @Override
    public OtpPolicy getOtpPolicy(String policyName) {
        
        OtpPolicy otpPolicy;
        
        Query query = entityManager.createQuery("from OtpPolicy where oppolicyname = :policyName)");
        if(null != policyName){
        	query.setParameter("policyName", policyName.toUpperCase());
        }
        else{
        	query.setParameter("policyName", "PL");
        }
        List<OtpPolicy> otpPolicies = query.getResultList();
        
        if(otpPolicies != null && !otpPolicies.isEmpty())
            otpPolicy = otpPolicies.get(0);
        else 
            otpPolicy = null;            
        
        return otpPolicy;
    }

	@Override
	@Transactional

	public OtpGenTran saveOtp(OtpGenTran genTran) {
		if (null != genTran.getOgtmobile()) {
		 Query updateQuery = entityManager.createQuery(
					"UPDATE OtpGenTran otpGenTran SET otpGenTran.otp=:otp , otpGenTran.ogtlstupdatedt=:ogtlstupdatedt , otpGenTran.ogtdefaultexpdt=:ogtdefaultexpdt , otpGenTran.ogtrequestdt=:ogtrequestdt  where otpGenTran.ogtmobile = :ogtmobile and otpGenTran.ogtisactive=:ogtisactive");
			updateQuery.setParameter(OGTMOBILE, genTran.getOgtmobile());
			updateQuery.setParameter(OGTISACTIVE, new BigDecimal(1));
			updateQuery.setParameter(OTP, genTran.getOtp());
			updateQuery.setParameter(OGTLSUPDATEDT, genTran.getOgtlstupdatedt());
			updateQuery.setParameter(OGTDEFAULTEXPDT, genTran.getOgtdefaultexpdt());
			updateQuery.setParameter(OGTREQUESTDT, genTran.getOgtrequestdt());
			// updateQuery.setParameter("ogtisNotactive", new BigDecimal(0));
			if (updateQuery.executeUpdate() == 0) {
							entityManager.persist(genTran);
			}
		} else {
		Query updateQuery = entityManager.createQuery(
					"UPDATE OtpGenTran otpGenTran SET otpGenTran.otp=:otp , otpGenTran.ogtlstupdatedt=:ogtlstupdatedt , otpGenTran.ogtdefaultexpdt=:ogtdefaultexpdt , otpGenTran.ogtrequestdt=:ogtrequestdt where otpGenTran.ogtemailid = :ogtemailid and otpGenTran.ogtisactive=:ogtisactive");
			updateQuery.setParameter(OGTEMAILID, genTran.getOgtemailid());
			updateQuery.setParameter(OGTISACTIVE, new BigDecimal(1));
			updateQuery.setParameter(OTP, genTran.getOtp());
			updateQuery.setParameter(OGTLSUPDATEDT, genTran.getOgtlstupdatedt());
			updateQuery.setParameter(OGTDEFAULTEXPDT, genTran.getOgtdefaultexpdt());
			updateQuery.setParameter(OGTREQUESTDT, genTran.getOgtrequestdt());
			// updateQuery.setParameter("ogtisNotactive", new BigDecimal(0));
			if (updateQuery.executeUpdate() == 0) {
				entityManager.persist(genTran);
			}
		}
		return genTran;
	}
    
    @Override
	public String validateOtp(OtpGenTran genTran) {
		String otp = null;
		if (null != genTran.getOgtmobile() && !genTran.getOgtmobile().trim().isEmpty()) {
			Query query = entityManager.createQuery( 
					"from OtpGenTran otpGenTran where otpGenTran.ogtmobile = :ogtmobile and otpGenTran.ogtisactive=:ogtisactive ORDER BY otpGenTran.ogtlstupdatedt DESC");
			query.setParameter(OGTMOBILE, genTran.getOgtmobile());
			query.setParameter(OGTISACTIVE, new BigDecimal(1));
			List<OtpGenTran> otpGenTrans = query.getResultList();
			if (null != otpGenTrans && !otpGenTrans.isEmpty()) {
				otp = otpGenTrans.get(0).getOtp();
				if (otpGenTrans.get(0).getOgtdefaultexpdt().after(OTPUtil.getCurrentGMTTimestamp())) {
					return otp;
				} else {
					logger.error(THIS_CLASS, BFLLoggerComponent.DAO, "OTP is expired.");
					throw new BFLBusinessException("OTP_810", env.getProperty("OTP_810"));
				}
			}
		} else if (null != genTran.getOgtemailid() && !genTran.getOgtemailid().trim().isEmpty()) {
			Query query = entityManager.createQuery(
					"from OtpGenTran otpGenTran where otpGenTran.ogtemailid = :ogtemailid and otpGenTran.ogtisactive=:ogtisactive ORDER BY otpGenTran.ogtlstupdatedt DESC");
			query.setParameter(OGTEMAILID, genTran.getOgtemailid());
			query.setParameter(OGTISACTIVE, new BigDecimal(1));
			List<OtpGenTran> otpGenTrans = query.getResultList();
			if (null != otpGenTrans && !otpGenTrans.isEmpty()) {
				otp = otpGenTrans.get(0).getOtp();
				return otp;
			}
		}
		return otp;
	}
    
	@Override
	public String getOtp(GetOtp getOtp) {
		String otp;
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Inside OTPDaoImpl : getOtp call started");
		List<OtpGenTran> otpGenTrans = null;
		if (null != getOtp.getEmail()) {
			Query query = entityManager.createQuery(
					"from OtpGenTran otpGenTran where otpGenTran.ogtemailid = :ogtemailid and otpGenTran.ogtisactive=1");
			query.setParameter(OGTEMAILID, getOtp.getEmail());
			otpGenTrans = query.getResultList();
		} else if (null != getOtp.getMobile()) {
			Query query = entityManager.createQuery(
					"from OtpGenTran otpGenTran where otpGenTran.ogtmobile = :ogtmobile and otpGenTran.ogtisactive=1");
			query.setParameter(OGTMOBILE, getOtp.getMobile());
			otpGenTrans = query.getResultList();
		}
		if (null != otpGenTrans && !otpGenTrans.isEmpty()) {
			otp = otpGenTrans.get(0).getOtp();
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "Inside OTPDaoImpl : getOtp call completed");
			return otp;
		}else{
			throw new BFLBusinessException("OTP_813",env.getProperty("OTP_813"));
		}
	}
}
