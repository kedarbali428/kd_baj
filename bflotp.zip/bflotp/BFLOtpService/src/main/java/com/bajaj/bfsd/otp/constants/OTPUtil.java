package com.bajaj.bfsd.otp.constants;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.enterprise.context.RequestScoped;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLTechnicalException;

public class OTPUtil {
	
	@Autowired
	static Environment env;
	
	@RequestScoped
	@Autowired
    BFLLoggerUtil logger;

	private static String corelationId;
    private OTPUtil(){        
    }
    
    /**
     * Getter method for current timestamp.
     *
     * @return current timestamp
     */
    public static Timestamp getCurrentTimestamp() {
        Date date = Calendar.getInstance().getTime();
        return new Timestamp(date.getTime());
    }
    
    public static String getCurrentTimestamp(Timestamp timestamp){
    	SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return format.format(timestamp);
    }
    
    public static String getISTTimestamp(Timestamp timestamp) {
    	DateFormat gmtFormat = new SimpleDateFormat();
    	TimeZone gmtTime = TimeZone.getTimeZone("IST");
    	gmtFormat.setTimeZone(gmtTime);
    	return gmtFormat.format(timestamp);
    }
	public static String formatToISTTimestamp(Timestamp timestamp) {
		DateFormat gmtFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
		TimeZone gmtTime = TimeZone.getTimeZone("IST");
		gmtFormat.setTimeZone(gmtTime);
		return gmtFormat.format(timestamp);
	}
    
    public static Timestamp getCurrentGMTTimestamp() {
    	DateFormat gmtFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm a");
    	TimeZone gmtTime = TimeZone.getTimeZone("GMT");
    	gmtFormat.setTimeZone(gmtTime);
    	String date = gmtFormat.format(new Date());
    	try {
			return new Timestamp(gmtFormat.parse(date).getTime());
		} catch (ParseException e) {
			throw new BFLTechnicalException("OTP_811",env.getProperty("OTP_811"));
		}
    }
    
    
    /**
     * Getter method for corelation id.
     *
     * @return corelation id
     */
    public static String getCorelationId() {
        return corelationId;
    }

    /**
     * Sets the value of corelation id.
     *
     * @param corelationId the new corelation id
     */
    public static void setCorelationId(String corelationId) {
    	OTPUtil.corelationId = corelationId;
    }
}
