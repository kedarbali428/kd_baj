/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.otp.controller;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerHeader;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.otp.constants.OTPUtil;
import com.bajaj.bfsd.otp.dto.GenerateOTP;
import com.bajaj.bfsd.otp.dto.GetOtp;
import com.bajaj.bfsd.otp.dto.OTP;
import com.bajaj.bfsd.otp.dto.ValidateOTP;
import com.bajaj.bfsd.otp.model.OtpPolicy;
import com.bajaj.bfsd.otp.service.OTPCacheService;
import com.bajaj.bfsd.otp.service.OTPService;
import com.bajaj.bfsd.otp.service.UserDetailsService;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLBusinessException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * This class is a controller class for OTP service.
 * 
 * @author 604135
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          604135          01/19/2017      Initial Version
 *
 */
@RestController
@RefreshScope
public class OTPController extends BFLController {

	private static final String OTP_802 = "OTP_802";
	private static final String OTP_817 = "OTP_817";

	@Autowired
	protected CustomDefaultHeaders customdefaultheaders;

	@Autowired
	private OTPService otpService;

	@Autowired
	private Environment env;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	UserDetailsService service;

	@Autowired
	OTPCacheService oTPCacheService;
	
	@Value("${bfl.cache.emailotp.expiration}")
	Long generateEmailOtp;
	
	@Value("${bfl.cache.mobileotp.expiration}")
	Long generateMobileOtp;

	private static final String THIS_CLASS = OTPController.class.getCanonicalName();

	@ApiOperation(value = "generates OTP", notes = "generates OTP", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.POST, value = "${api.otp.generate.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> generateOtp(@RequestBody GenerateOTP OTP, @RequestHeader HttpHeaders header) {
		GenerateOTP generateOTP = null;
		GenerateOTP reponseOTP = null;
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "generateOtp: Call started " + generateOTP);

		if (null == OTP.getEmail() || OTP.getEmail().isEmpty()) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "generate  Otp : getEmail is not received");
		} else {
			if (null != oTPCacheService.get(OTP.getEmail())) {
				generateOTP = oTPCacheService.get(OTP.getEmail());
				generateOTP.setMfa(OTP.isMfa());
				//ADD This code added to remove the cache object 
				//explicitly if it is not expired after its expiration time.
				if (null != generateOTP && generateOTP.getRetryCount() == 5) {
					generateOTP = deleteOtpFromCacheAfterExpiration(OTP, generateOTP);
				}
			}
		}
		if (null == OTP.getMobile() || OTP.getMobile().trim().isEmpty()) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					"generate  Otp : mobile number is not received");
		} else {
			if (null != oTPCacheService.get(OTP.getMobile())) {
				generateOTP = oTPCacheService.get(OTP.getMobile());
				generateOTP.setMfa(OTP.isMfa());
				//ADD This code added to remove the cache object 
				//explicitly if it is not expired after its expiration time.
				if(generateOTP.getExpitationTime().before(new Date())){
					 oTPCacheService.delete(OTP.getMobile());
					 generateOTP = null;
				}
			}
		}
		OtpPolicy otpPolicy;
		OTP otp;
		String otpExpTime;
		if(null != generateOTP ){
			logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
					generateOTP.toString());
		}
		
		if (null == generateOTP || generateOTP.getRetryCount() < 5 && generateOTP.getValidationCount() < 5) {
			if (generateOTP == null) {
				generateOTP = OTP;
				generateOTP.setMfa(OTP.isMfa());
			}
			otpPolicy = otpService.getOtpPolicy(generateOTP.getPolicyName());
			if (otpPolicy != null)
				otpExpTime = otpPolicy.getOpexpirytime().toString();
			else {
				logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "generateOtp: Policy does not exist");
				throw new BFLBusinessException("OTP_801",
						MessageFormat.format(env.getProperty("OTP_801"), generateOTP.getPolicyName()));
			}
			if (generateOTP.getMobile() == null || generateOTP.getMobile().length() != 10
					|| generateOTP.getMobile().isEmpty()) {
				validateEmailIdForGenerateOtp(generateOTP);
			}
			otp = otpService.getOtp("", otpPolicy, generateOTP);
			//if (!generateOTP.isMfa()) {
				generateOTP.setOtp(otp.getOtpValue());
			//}
			generateOTP.setGenerateTime(otp.getGenarationTime());
			generateOTP.setValidMins(otpExpTime);
			generateOTP.setExpitationTime(otp.getExpitationTime());
			generateOTP.setRetryCount(generateOTP.getRetryCount() + 1);

			if (null != generateOTP.getMobile() && !generateOTP.getMobile().trim().isEmpty()) {
				oTPCacheService.save(generateOTP.getMobile(), generateOTP, generateMobileOtp);
			} else {
				if (null != generateOTP.getEmail() && !generateOTP.getEmail().trim().isEmpty()) {
					oTPCacheService.save(generateOTP.getEmail(), generateOTP, generateEmailOtp);
				}
			}
			reponseOTP = generateOTP;
			
			if (!generateOTP.isMfa()) {
				reponseOTP.setOtp(otp.getOtpValue());
			}else{
				reponseOTP.setOtp("");
			}
			logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "generateOtp: Call completed ");
			return new ResponseEntity<>(new ResponseBean(reponseOTP), HttpStatus.OK);
		} else {
			throw new BFLBusinessException(OTP_817, env.getProperty(OTP_817));
		}
	}

	private GenerateOTP deleteOtpFromCacheAfterExpiration(GenerateOTP otp, GenerateOTP generateOTP) {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
		Date generationTime = null;
		try {
			generationTime = format.parse(generateOTP.getGenerateTime());
		} catch (ParseException e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Parse Exception Occured");
		} 
		 Calendar cal = Calendar.getInstance();
		 cal.setTime(generationTime);
		 cal.add(Calendar.MINUTE, 10);
		if(cal.getTime().before(new Date())){
			 oTPCacheService.delete(otp.getEmail());
			 return null;
		}
		return generateOTP;
	}

	@ApiOperation(value = "validates OTP", notes = "validates OTP", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.POST, value = "${api.otp.validate.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> validateOtp(@Valid @RequestBody ValidateOTP validateOTP, BindingResult result,
			@RequestHeader HttpHeaders header) {

		String cacheKey = "";
		Long ttl = 0L;
		if (validateOTP.getMobile() != null && !validateOTP.getMobile().trim().isEmpty()) {
			cacheKey = validateOTP.getMobile();
			ttl = generateMobileOtp;
		} else {
			if (validateOTP.getEmail() != null && !validateOTP.getEmail().trim().isEmpty()) {
				cacheKey = validateOTP.getEmail();
				ttl = generateEmailOtp;
			}
		}
		if (null != oTPCacheService.get(cacheKey)) {
			if (oTPCacheService.get(cacheKey).getValidationCount() < 5) {
				OTPUtil.setCorelationId(header.getFirst(BFLLoggerHeader.ID.getValue()));
				if (result.hasErrors()) {
					logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Validation error occured.");
					throw new BFLBusinessException(result.getFieldErrors());
				}
				if (validateOTP.getMobile() == null || validateOTP.getMobile().length() != 10
						|| validateOTP.getMobile().isEmpty()) {
					validateEmailId(validateOTP.getEmail());
				}
				String otpValidated = null;
				logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "validateOtp: Call started ");
				// otpValidated = otpService.validateOtp(validateOTP);
				GenerateOTP otp = oTPCacheService.get(cacheKey);
				// otpValidated = otpService.validateOtp(validateOTP);
				// ADDED OTP validation from Cache Object
				if (otp.getOtp().equals(validateOTP.getOtp())) {
					logger.debug(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "otpValidaetd : " + otpValidated);
					oTPCacheService.delete(cacheKey);
					otpValidated = "SUCCESS";
				} else {
					otpValidated = "ERROR";
					GenerateOTP generateOTP = oTPCacheService.get(cacheKey);
					generateOTP.setValidationCount(oTPCacheService.get(cacheKey).getValidationCount() + 1);
					oTPCacheService.update(cacheKey, generateOTP, ttl);
					throw new BFLBusinessException("OTP_809", env.getProperty("OTP_809"));
				}
				logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER,
						"validateOtp: Call completed with response " + otpValidated);
				return new ResponseEntity<>(new ResponseBean(otpValidated), HttpStatus.OK);
			} else {
				//ADD This code added to remove the cache object 
				//explicitly if it is not expired after its expiration time.
				if (null != oTPCacheService.get(cacheKey) ){
					GenerateOTP otp = oTPCacheService.get(cacheKey);
					if(otp.getExpitationTime().before(new Date())){
						if(null != otp.getEmail() && !otp.getEmail().isEmpty()){
							oTPCacheService.delete(otp.getEmail());
						} 
						if(null != otp.getMobile() && !otp.getMobile().isEmpty()){
							oTPCacheService.delete(otp.getMobile());
						} 
					}
				}
				throw new BFLBusinessException("OTP_818", env.getProperty("OTP_818"));
			}
		} else {
			throw new BFLBusinessException("OTP_819", env.getProperty("OTP_819"));
		}
	}

	@ApiOperation(value = "get OTP", notes = "get OTP", httpMethod = "POST")
	@ApiImplicitParam(name = "cmptcorrid", required = true, dataType = "string", paramType = "header")
	@RequestMapping(method = RequestMethod.POST, value = "${api.otp.POST.uri}")
	@CrossOrigin
	public ResponseEntity<ResponseBean> getOtp(@Valid @RequestBody GetOtp getOtp, BindingResult result,
			@RequestHeader HttpHeaders header) {

		OTPUtil.setCorelationId(header.getFirst(BFLLoggerHeader.ID.getValue()));
		if (result.hasErrors()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Validation error occured.");
			throw new BFLBusinessException(result.getFieldErrors());
		}
		if (getOtp.getMobile() == null || getOtp.getMobile().length() != 10 || getOtp.getMobile().isEmpty()) {
			validateEmailId(getOtp.getEmail());
		}
		String otp;
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getOtp: Call started ");
		otp = otpService.getOtp(getOtp);
		logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getOtp: Call completed with response " + otp);
		return new ResponseEntity<>(new ResponseBean(otp), HttpStatus.OK);
	}

	private void validateEmailId(String email) {
		if (null == email || email.isEmpty()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "Invalid input");
			throw new BFLBusinessException(OTP_802, env.getProperty(OTP_802));
		}
	}

	private void validateEmailIdForGenerateOtp(GenerateOTP generateOTP) {
		if (null == generateOTP.getEmail() || generateOTP.getEmail().isEmpty()) {
			logger.error(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "generateOtp: Invalid input");
			throw new BFLBusinessException(OTP_802, env.getProperty(OTP_802));
		}
	}

}