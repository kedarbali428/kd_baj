package com.bajaj.bfsd.otp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the OTP_VALIDATION_TRANS database table.
 * 
 */
@Entity
@Table(name="OTP_VALIDATION_TRANS")
@NamedQuery(name="OtpValidationTran.findAll", query="SELECT o FROM OtpValidationTran o")
public class OtpValidationTran implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long otpvaltrnkey;

	private BigDecimal ovtisactive;

	private String ovtlastupdateby;

	private Timestamp ovtlastupdatedt;

	private String ovtrequester;

	private Timestamp ovtvaliddt;

	private BigDecimal ovtvalidflag;

	//bi-directional many-to-one association to OtpGenTran
	@ManyToOne
	@JoinColumn(name="OTPGENTRANSKEY")
	private OtpGenTran otpGenTran;

	public OtpValidationTran() {
	}

	public long getOtpvaltrnkey() {
		return this.otpvaltrnkey;
	}

	public void setOtpvaltrnkey(long otpvaltrnkey) {
		this.otpvaltrnkey = otpvaltrnkey;
	}

	public BigDecimal getOvtisactive() {
		return this.ovtisactive;
	}

	public void setOvtisactive(BigDecimal ovtisactive) {
		this.ovtisactive = ovtisactive;
	}

	public String getOvtlastupdateby() {
		return this.ovtlastupdateby;
	}

	public void setOvtlastupdateby(String ovtlastupdateby) {
		this.ovtlastupdateby = ovtlastupdateby;
	}

	public Timestamp getOvtlastupdatedt() {
		return this.ovtlastupdatedt;
	}

	public void setOvtlastupdatedt(Timestamp ovtlastupdatedt) {
		this.ovtlastupdatedt = ovtlastupdatedt;
	}

	public String getOvtrequester() {
		return this.ovtrequester;
	}

	public void setOvtrequester(String ovtrequester) {
		this.ovtrequester = ovtrequester;
	}

	public Timestamp getOvtvaliddt() {
		return this.ovtvaliddt;
	}

	public void setOvtvaliddt(Timestamp ovtvaliddt) {
		this.ovtvaliddt = ovtvaliddt;
	}

	public BigDecimal getOvtvalidflag() {
		return this.ovtvalidflag;
	}

	public void setOvtvalidflag(BigDecimal ovtvalidflag) {
		this.ovtvalidflag = ovtvalidflag;
	}

	public OtpGenTran getOtpGenTran() {
		return this.otpGenTran;
	}

	public void setOtpGenTran(OtpGenTran otpGenTran) {
		this.otpGenTran = otpGenTran;
	}

}