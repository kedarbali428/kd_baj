/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.otp.service;


import com.bajaj.bfsd.otp.dto.GenerateOTP;
import com.bajaj.bfsd.otp.dto.GetOtp;
import com.bajaj.bfsd.otp.dto.OTP;
import com.bajaj.bfsd.otp.dto.ValidateOTP;
import com.bajaj.bfsd.otp.model.OtpPolicy;

/**
 * Service interface for OTP operations
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	23/12/2016      Initial Version
 */
public interface OTPService {
    
    /**
     * Getter method for otp policy.
     *
     * @param policyName the policy name
     * @return otp policy
     */
    public OtpPolicy getOtpPolicy(String policyName);
    
    public OTP getOtp(String requester, OtpPolicy otpPolicy, GenerateOTP generateOTP);
    
    public String validateOtp(ValidateOTP validateOTP);

	public String getOtp(GetOtp getOtp);
}
