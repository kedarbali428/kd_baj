package com.bajaj.bfsd.otp.dto;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the USERS_PWD_CHG_HISTORY database table.
 * 
 */
@Entity
@Table(name="USERS_PWD_CHG_HISTORY")
@NamedQuery(name="UsersPwdChgHistory.findAll", query="SELECT u FROM UsersPwdChgHistory u")
public class UsersPwdChgHistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long usrpwdhistorykey;

	private String browser;

	private String deviceid;

	private String ipaddress;

	private BigDecimal latitude;

	private BigDecimal longitude;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private String password;

	private Timestamp pwdchgdt;

	//bi-directional many-to-one association to BfsdUser
	@ManyToOne
	@JoinColumn(name="USERKEY")
	private BfsdUser bfsdUser;

	public long getUsrpwdhistorykey() {
		return this.usrpwdhistorykey;
	}

	public void setUsrpwdhistorykey(long usrpwdhistorykey) {
		this.usrpwdhistorykey = usrpwdhistorykey;
	}

	public String getBrowser() {
		return this.browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getDeviceid() {
		return this.deviceid;
	}

	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}

	public String getIpaddress() {
		return this.ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public BigDecimal getLatitude() {
		return this.latitude;
	}

	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}

	public BigDecimal getLongitude() {
		return this.longitude;
	}

	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Timestamp getPwdchgdt() {
		return this.pwdchgdt;
	}

	public void setPwdchgdt(Timestamp pwdchgdt) {
		this.pwdchgdt = pwdchgdt;
	}

	public BfsdUser getBfsdUser() {
		return this.bfsdUser;
	}

	public void setBfsdUser(BfsdUser bfsdUser) {
		this.bfsdUser = bfsdUser;
	}

}