package com.bajaj.bfsd.otp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the OTP_GEN_TRANS database table.
 * 
 */
@Entity
@Table(name="OTP_GEN_TRANS")
@NamedQuery(name="OtpGenTran.findAll", query="SELECT o FROM OtpGenTran o")
public class OtpGenTran implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long otpgentranskey;

	private Timestamp ogtdefaultexpdt;

	private String ogtemailid;

	private Timestamp ogtforceexpdt;

	private BigDecimal ogtforceexpflg;

	private String ogtforceexprequester;

	private BigDecimal ogtisactive;

	private String ogtlstupdateby;

	private Timestamp ogtlstupdatedt;

	private String ogtmobile;

	private Timestamp ogtrequestdt;

	private String ogtrequester;

	private Timestamp ogtsenddt;

	private String otp;

	//bi-directional many-to-one association to OtpPolicy
	@ManyToOne
	@JoinColumn(name="OGTPOLICYKEY")
	private OtpPolicy otpPolicy;

	//bi-directional many-to-one association to OtpValidationTran
	@OneToMany(mappedBy="otpGenTran")
	private List<OtpValidationTran> otpValidationTrans;

	public OtpGenTran() {
	}

	public long getOtpgentranskey() {
		return this.otpgentranskey;
	}

	public void setOtpgentranskey(long otpgentranskey) {
		this.otpgentranskey = otpgentranskey;
	}

	public Timestamp getOgtdefaultexpdt() {
		return this.ogtdefaultexpdt;
	}

	public void setOgtdefaultexpdt(Timestamp ogtdefaultexpdt) {
		this.ogtdefaultexpdt = ogtdefaultexpdt;
	}

	public String getOgtemailid() {
		return this.ogtemailid;
	}

	public void setOgtemailid(String ogtemailid) {
		this.ogtemailid = ogtemailid;
	}

	public Timestamp getOgtforceexpdt() {
		return this.ogtforceexpdt;
	}

	public void setOgtforceexpdt(Timestamp ogtforceexpdt) {
		this.ogtforceexpdt = ogtforceexpdt;
	}

	public BigDecimal getOgtforceexpflg() {
		return this.ogtforceexpflg;
	}

	public void setOgtforceexpflg(BigDecimal ogtforceexpflg) {
		this.ogtforceexpflg = ogtforceexpflg;
	}

	public String getOgtforceexprequester() {
		return this.ogtforceexprequester;
	}

	public void setOgtforceexprequester(String ogtforceexprequester) {
		this.ogtforceexprequester = ogtforceexprequester;
	}

	public BigDecimal getOgtisactive() {
		return this.ogtisactive;
	}

	public void setOgtisactive(BigDecimal ogtisactive) {
		this.ogtisactive = ogtisactive;
	}

	public String getOgtlstupdateby() {
		return this.ogtlstupdateby;
	}

	public void setOgtlstupdateby(String ogtlstupdateby) {
		this.ogtlstupdateby = ogtlstupdateby;
	}

	public Timestamp getOgtlstupdatedt() {
		return this.ogtlstupdatedt;
	}

	public void setOgtlstupdatedt(Timestamp ogtlstupdatedt) {
		this.ogtlstupdatedt = ogtlstupdatedt;
	}

	public String getOgtmobile() {
		return this.ogtmobile;
	}

	public void setOgtmobile(String ogtmobile) {
		this.ogtmobile = ogtmobile;
	}

	public Timestamp getOgtrequestdt() {
		return this.ogtrequestdt;
	}

	public void setOgtrequestdt(Timestamp ogtrequestdt) {
		this.ogtrequestdt = ogtrequestdt;
	}

	public String getOgtrequester() {
		return this.ogtrequester;
	}

	public void setOgtrequester(String ogtrequester) {
		this.ogtrequester = ogtrequester;
	}

	public Timestamp getOgtsenddt() {
		return this.ogtsenddt;
	}

	public void setOgtsenddt(Timestamp ogtsenddt) {
		this.ogtsenddt = ogtsenddt;
	}

	public String getOtp() {
		return this.otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public OtpPolicy getOtpPolicy() {
		return this.otpPolicy;
	}

	public void setOtpPolicy(OtpPolicy otpPolicy) {
		this.otpPolicy = otpPolicy;
	}

	public List<OtpValidationTran> getOtpValidationTrans() {
		return this.otpValidationTrans;
	}

	public void setOtpValidationTrans(List<OtpValidationTran> otpValidationTrans) {
		this.otpValidationTrans = otpValidationTrans;
	}

	public OtpValidationTran addOtpValidationTran(OtpValidationTran otpValidationTran) {
		getOtpValidationTrans().add(otpValidationTran);
		otpValidationTran.setOtpGenTran(this);

		return otpValidationTran;
	}

	public OtpValidationTran removeOtpValidationTran(OtpValidationTran otpValidationTran) {
		getOtpValidationTrans().remove(otpValidationTran);
		otpValidationTran.setOtpGenTran(null);

		return otpValidationTran;
	}

}