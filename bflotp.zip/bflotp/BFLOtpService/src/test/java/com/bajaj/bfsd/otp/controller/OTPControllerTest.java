package com.bajaj.bfsd.otp.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Matchers.isNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.otp.constants.OTPUtil;
import com.bajaj.bfsd.otp.dao.impl.OTPDaoImpl;
import com.bajaj.bfsd.otp.dto.GenerateOTP;
import com.bajaj.bfsd.otp.model.OtpGenTran;
import com.bajaj.bfsd.otp.model.OtpPolicy;
import com.bajaj.bfsd.otp.service.OTPCacheService;
import com.bajaj.bfsd.otp.service.impl.OTPServiceImpl;

@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@PrepareForTest(BFLCommonRestClient.class)
@TestPropertySource({"classpath:/error.properties","classpath:/application.properties"})
@PowerMockIgnore({"javax.crypto.*" })
public class OTPControllerTest {
	
	private OTPController otpController;
	private OTPServiceImpl otpServiceImpl;
	private OTPDaoImpl otpDaoImpl;
	
	@Mock
	private EntityManager entityManager;
	
	@Autowired
	Environment env;

	private MockMvc mockMvc;
	
	@Mock
	private Query query;
	
	@Mock
	private Query query1;
	
	@Mock
	private Query subStageQuery;
	
	@Mock
	BFLLoggerUtilExt logger;
	
	@Mock
	ResponseEntity<ResponseBean> responseEntity;
	
	@Mock
	OTPCacheService oTPCacheService;
	
	/**
	 * Method for setup
	 */
	@Before
	public void setUp() {
		otpController = new OTPController();
		otpServiceImpl = new OTPServiceImpl();
		otpDaoImpl = new OTPDaoImpl();
		this.mockMvc = MockMvcBuilders.standaloneSetup(otpController).
				addPlaceholderValue("api.otp.generate.POST.uri", env.getProperty("api.otp.generate.POST.uri")).
				addPlaceholderValue("api.otp.validate.POST.uri", env.getProperty("api.otp.validate.POST.uri")).
				addPlaceholderValue("api.otp.POST.uri", env.getProperty("api.otp.POST.uri")).build();
		ReflectionTestUtils.setField(otpController, "otpService", otpServiceImpl);
		ReflectionTestUtils.setField(otpServiceImpl, "otpDao", otpDaoImpl);
		ReflectionTestUtils.setField(otpDaoImpl, "entityManager", entityManager);
		ReflectionTestUtils.setField(otpController, "env", env);
		ReflectionTestUtils.setField(otpDaoImpl, "env", env);
		ReflectionTestUtils.setField(otpServiceImpl, "env", env);
		ReflectionTestUtils.setField(otpController, "logger", logger);
		ReflectionTestUtils.setField(otpDaoImpl, "logger", logger);
		ReflectionTestUtils.setField(otpServiceImpl, "logger", logger);
		ReflectionTestUtils.setField(otpController, "oTPCacheService", oTPCacheService);
	}
	
	/**
	 * @Objective To test Otp is generated and sent on mobile.
	 * @method generateOtp
	 * @Condition Valid data is passed.
	 * @Expected Status is 200
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGenerateOtp() throws Exception {
		List<OtpPolicy> otpPolicies = createOtpPolicies("SMS");
		List<OtpGenTran> genTranses = new ArrayList<>();
		OtpGenTran genTran = new OtpGenTran();
		genTranses.add(genTran);
		when(entityManager.createQuery("from OtpPolicy where oppolicyname = :policyName)")).thenReturn(query);
		when(query.getResultList()).thenReturn(otpPolicies);
		when(entityManager.createQuery(
				"from OtpGenTran otpGenTran where otpGenTran.ogtmobile = :ogtmobile and otpGenTran.ogtisactive=:ogtisactive)")).thenReturn(query1);
		when(entityManager.createQuery(
				"UPDATE OtpGenTran otpGenTran SET otpGenTran.ogtisactive=:ogtisNotactive where otpGenTran.ogtmobile = :ogtmobile and otpGenTran.ogtisactive=:ogtisactive)")).thenReturn(query1);
		when(query1.getResultList()).thenReturn(genTranses);
		when(query1.executeUpdate()).thenReturn(1);
		Mockito.doNothing().when(entityManager).persist(genTran);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		when(BFLCommonRestClient.create(anyString(), isNull(), (Class<?>) any(),
				(Map<String, String>) isNull(), anyString(), isA(HttpHeaders.class)))
						.thenReturn((ResponseEntity) responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		ResponseBean bean = new ResponseBean();
		bean.setStatus(StatusCode.SUCCESS);
		when(responseEntity.getBody()).thenReturn(bean);
		this.mockMvc.perform(post(env.getProperty("api.otp.generate.POST.uri")).header("cmptcorrid", "corelationId")
				.content(
						"{\"policyName\":\"PL\",\"mobile\":\"7755902060\"}")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	
	/**
	 * @Objective To test Otp is generated and sent on mobile.
	 * @method generateOtp
	 * @Condition Message not sent
	 * @Expected Exception is thrown
	 *//*
	@SuppressWarnings({ "unchecked"})
	@Test(expected=Exception.class)
	public void testGenerateOtpWithMessageNotSent() throws Exception {
		List<OtpPolicy> otpPolicies = createOtpPolicies("SMS");
		List<OtpGenTran> genTranses = new ArrayList<>();
		OtpGenTran genTran = new OtpGenTran();
		genTranses.add(genTran);
		when(entityManager.createQuery("from OtpPolicy where oppolicyname = :policyName)")).thenReturn(query);
		when(query.getResultList()).thenReturn(otpPolicies);
		when(entityManager.createQuery(
				"from OtpGenTran otpGenTran where otpGenTran.ogtmobile = :ogtmobile and otpGenTran.ogtisactive=:ogtisactive)")).thenReturn(query1);
		when(entityManager.createQuery(
				"UPDATE OtpGenTran otpGenTran SET otpGenTran.ogtisactive=:ogtisNotactive where otpGenTran.ogtmobile = :ogtmobile and otpGenTran.ogtisactive=:ogtisactive)")).thenReturn(query1);
		when(query1.getResultList()).thenReturn(genTranses);
		when(query1.executeUpdate()).thenReturn(1);
		Mockito.doNothing().when(entityManager).persist(genTran);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		when(BFLCommonRestClient.create(anyString(), isNull(), (Class<?>) any(),
				(Map<String, String>) isNull(), anyString(), isA(HttpHeaders.class)))
						.thenReturn(null);
		this.mockMvc.perform(post(env.getProperty("api.otp.generate.POST.uri")).header("cmptcorrid", "corelationId")
				.content(
						"{\"policyName\":\"PL\",\"mobile\":\"7755902060\"}")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}*/
	
	/**
	 * @Objective To test Otp is generated and sent on mobile.
	 * @method generateOtp
	 * @Condition No rows updated
	 * @Expected Exception is thrown
	 */
	@Test
	public void testGenerateOtpWithUpdateFailed() throws Exception {
		List<OtpPolicy> otpPolicies = createOtpPolicies("SMS");
		List<OtpGenTran> genTranses = new ArrayList<>();
		OtpGenTran genTran = new OtpGenTran();
		genTranses.add(genTran);
		when(entityManager.createQuery("from OtpPolicy where oppolicyname = :policyName)")).thenReturn(query);
		when(query.getResultList()).thenReturn(otpPolicies);
		when(entityManager.createQuery(
				"from OtpGenTran otpGenTran where otpGenTran.ogtmobile = :ogtmobile and otpGenTran.ogtisactive=:ogtisactive)")).thenReturn(query1);
		when(entityManager.createQuery(
				"UPDATE OtpGenTran otpGenTran SET otpGenTran.ogtisactive=:ogtisNotactive where otpGenTran.ogtmobile = :ogtmobile and otpGenTran.ogtisactive=:ogtisactive)")).thenReturn(query1);
		when(query1.getResultList()).thenReturn(genTranses);
		when(query1.executeUpdate()).thenReturn(0);
		Mockito.doNothing().when(entityManager).persist(genTran);
		this.mockMvc.perform(post(env.getProperty("api.otp.generate.POST.uri")).header("cmptcorrid", "corelationId")
				.content(
						"{\"policyName\":\"PL\",\"mobile\":\"7755902060\"}")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	
	/**
	 * @Objective To test Otp is generated for email
	 * @method generateOtp
	 * @Condition No rows updated
	 * @Expected Exception is thrown
	 */
	@Test(expected=Exception.class)
	public void testGenerateOtpForEmailWithError() throws Exception {
		List<OtpPolicy> otpPolicies = createOtpPolicies("SMS");
		List<OtpGenTran> genTranses = new ArrayList<>();
		OtpGenTran genTran = new OtpGenTran();
		genTranses.add(genTran);
		when(entityManager.createQuery("from OtpPolicy where oppolicyname = :policyName)")).thenReturn(query);
		when(query.getResultList()).thenReturn(otpPolicies);
		when(entityManager.createQuery(
				"from OtpGenTran otpGenTran where otpGenTran.ogtemailid = :ogtemailid and otpGenTran.ogtisactive=:ogtisactive)")).thenReturn(query1);
		when(entityManager.createQuery(
				"UPDATE OtpGenTran otpGenTran SET otpGenTran.ogtisactive=:ogtisNotactive where otpGenTran.ogtemailid = :ogtemailid and otpGenTran.ogtisactive=:ogtisactive)")).thenReturn(query1);
		when(query1.getResultList()).thenReturn(genTranses);
		when(query1.executeUpdate()).thenReturn(0);
		Mockito.doNothing().when(entityManager).persist(genTran);
		this.mockMvc.perform(post(env.getProperty("api.otp.generate.POST.uri")).header("cmptcorrid", "corelationId")
				.content(
						"{\"policyName\":\"PL\",\"email\":\"something@gmail.com\"}")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	
	/**
	 * @Objective To test Otp is generated and sent on mobile.
	 * @method generateOtp
	 * @Condition Valid data
	 * @Expected Status is 200
	 */
	@Test
	public void testGenerateOtpForEmail() throws Exception {
		List<OtpPolicy> otpPolicies = createOtpPolicies("EMAIL");
		when(entityManager.createQuery("from OtpPolicy where oppolicyname = :policyName)")).thenReturn(query);
		when(query.getResultList()).thenReturn(otpPolicies);
		List<OtpGenTran> genTranses = new ArrayList<>();
		OtpGenTran genTran = new OtpGenTran();
		genTranses.add(genTran);
		when(entityManager.createQuery(
				"from OtpGenTran otpGenTran where otpGenTran.ogtemailid = :ogtemailid and otpGenTran.ogtisactive=:ogtisactive)")).thenReturn(query1);
		when(entityManager.createQuery(
				"UPDATE OtpGenTran otpGenTran SET otpGenTran.ogtisactive=:ogtisNotactive where otpGenTran.ogtemailid = :ogtemailid and otpGenTran.ogtisactive=:ogtisactive)")).thenReturn(query1);
		when(entityManager.createQuery(
				"UPDATE OtpGenTran otpGenTran SET otpGenTran.otp=:otp , otpGenTran.ogtlstupdatedt=:ogtlstupdatedt , otpGenTran.ogtdefaultexpdt=:ogtdefaultexpdt , otpGenTran.ogtrequestdt=:ogtrequestdt where otpGenTran.ogtemailid = :ogtemailid and otpGenTran.ogtisactive=:ogtisactive")).thenReturn(query);
		when(query1.getResultList()).thenReturn(genTranses);
		when(query1.executeUpdate()).thenReturn(1);
		Mockito.doNothing().when(entityManager).persist(genTran);
		PowerMockito.mockStatic(BFLCommonRestClient.class);
		when(BFLCommonRestClient.create(anyString(), isNull(), (Class<?>) any(),
				(Map<String, String>) isNull(), anyString(), isA(HttpHeaders.class)))
						.thenReturn((ResponseEntity) responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		ResponseBean bean = new ResponseBean();
		bean.setStatus(StatusCode.SUCCESS);
		when(responseEntity.getBody()).thenReturn(bean);
		this.mockMvc.perform(post(env.getProperty("api.otp.generate.POST.uri")).header("cmptcorrid", "corelationId")
				.content(
						"{\"policyName\":\"PL\",\"email\":\"123\"}")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}

	/**
	 * @Objective To test Otp is generated and sent on mobile.
	 * @method generateOtp
	 * @Condition Invalid data is passed
	 * @Expected Exception is thrown
	 */
	@Test(expected=Exception.class)
	public void testGenerateOtpWithInvalidInput() throws Exception{
		List<OtpPolicy> otpPolicies = createOtpPolicies("SMS");
		when(entityManager.createQuery("from OtpPolicy where oppolicyname = :policyName)")).thenReturn(query);
		when(query.getResultList()).thenReturn(otpPolicies);
		this.mockMvc.perform(post(env.getProperty("api.otp.generate.POST.uri")).header("cmptcorrid", "corelationId")
				.content(
						"{\"policyName\":\"PL\",\"mobile\":\"123\"}")
				.contentType(MediaType.APPLICATION_JSON));
	}
	
	/**
	 * @Objective To test Otp is generated and sent on mobile.
	 * @method generateOtp
	 * @Condition Invalid data is passed
	 * @Expected Exception is thrown
	 */
	@Test(expected=Exception.class)
	public void testGenerateOtpWithInvalidInput1() throws Exception{
		when(entityManager.createQuery("from OtpPolicy where oppolicyname = :policyName)")).thenReturn(query);
		when(query.getResultList()).thenReturn(null);
		this.mockMvc.perform(post(env.getProperty("api.otp.generate.POST.uri")).header("cmptcorrid", "corelationId")
				.content(
						"{\"policyName\":\"PL\",\"mobile\":\"123\"}")
				.contentType(MediaType.APPLICATION_JSON));
	}
	
	/**
	 * @Objective To test Otp validated
	 * @method validate
	 * @Condition Valid data
	 * @Expected Status is 200
	 */
	@Test
	public void testValidateOtp() throws Exception{
		List<OtpGenTran> genTranses = new ArrayList<>();
		OtpGenTran genTran = new OtpGenTran();
		genTran.setOtp("123456");
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MINUTE, 5);
		genTran.setOgtdefaultexpdt(new Timestamp(calendar.getTime().getTime()));
		genTranses.add(genTran);
		when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(genTranses);
		GenerateOTP cachedGenerateOtp = new GenerateOTP();
		cachedGenerateOtp.setOtp("123456");
		when(oTPCacheService.get(Mockito.anyString())).thenReturn(cachedGenerateOtp);
		this.mockMvc.perform(post("/OTP/validate").header("cmptcorrid", "corelationId")
				.content(
						"{\"otp\":\"123456\",\"mobile\":\"7755902060\"}")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	
	/**
	 * @Objective To test Otp validated
	 * @method validate
	 * @Condition Valid data
	 * @Expected Status is 200
	 */
	@Test
	public void testValidateOtpWithEmail() throws Exception{
		List<OtpGenTran> genTranses = new ArrayList<>();
		OtpGenTran genTran = new OtpGenTran();
		genTran.setOtp("123456");
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MINUTE, 5);
		genTran.setOgtdefaultexpdt(new Timestamp(calendar.getTime().getTime()));
		genTranses.add(genTran);
		when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(genTranses);
		GenerateOTP cachedGenerateOtp = new GenerateOTP();
		cachedGenerateOtp.setOtp("123456");
		when(oTPCacheService.get(Mockito.anyString())).thenReturn(cachedGenerateOtp);
		this.mockMvc.perform(post("/OTP/validate").header("cmptcorrid", "corelationId")
				.content(
						"{\"otp\":\"123456\",\"email\":\"something@gmail.com\"}")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	
	/**
	 * @Objective To test Otp validated
	 * @method validate
	 * @Condition OTP is expired
	 * @Expected Exception is thrown
	 */
	@Test(expected=Exception.class)
	public void testValidateOtpWithExpiredOTP() throws Exception{
		List<OtpGenTran> genTranses = new ArrayList<>();
		OtpGenTran genTran = new OtpGenTran();
		genTran.setOtp("123456");
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MINUTE, 5);
		genTran.setOgtdefaultexpdt(OTPUtil.getCurrentGMTTimestamp());
		genTranses.add(genTran);
		when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(genTranses);
		this.mockMvc.perform(post("/OTP/validate").header("cmptcorrid", "corelationId")
				.content(
						"{\"otp\":\"123456\",\"mobile\":\"7755902060\"}")
				.contentType(MediaType.APPLICATION_JSON));
	}
	
	/**
	 * @Objective To test Otp validated
	 * @method validate
	 * @Condition InValid data
	 * @Expected Exception is thrown
	 */
	@Test(expected=Exception.class)
	public void testValidateOtpWithInvalidInput() throws Exception{
		this.mockMvc.perform(post("/OTP/validate").header("cmptcorrid", "corelationId")
				.content(
						"{\"otp\":\"123456\"}")
				.contentType(MediaType.APPLICATION_JSON));
	}
	
	/**
	 * @Objective To test Otp validated
	 * @method validate
	 * @Condition InValid data
	 * @Expected Exception is thrown
	 */
	@Test(expected=Exception.class)
	public void testValidateOtpWithInvalidInput1() throws Exception{
		this.mockMvc.perform(post("/OTP/validate").header("cmptcorrid", "corelationId")
				.content(
						"{\"mobile\":\"1234567890\"}")
				.contentType(MediaType.APPLICATION_JSON));
	}
	
	/**
	 * @Objective To test Otp validated
	 * @method validate
	 * @Condition Invalid otp
	 * @Expected Exception is thrown
	 */
	@Test(expected=Exception.class)
	public void testValidateOtpWithInvalidOtp() throws Exception{
		List<OtpGenTran> genTranses = new ArrayList<>();
		OtpGenTran genTran = new OtpGenTran();
		genTran.setOtp("123456");
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MINUTE, 5);
		genTran.setOgtdefaultexpdt(new Timestamp(calendar.getTime().getTime()));
		genTranses.add(genTran);
		when(entityManager.createQuery(Mockito.anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(null);
		this.mockMvc.perform(post("/OTP/validate").header("cmptcorrid", "corelationId")
				.content(
						"{\"otp\":\"123456\",\"mobile\":\"7755902060\"}")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	
	
	/**
	 * @return List<OtpPolicy>
	 */
	private List<OtpPolicy> createOtpPolicies(String policyMode) {
		OtpPolicy otpPolicy = new OtpPolicy();
		otpPolicy.setOpexpirytime(new BigDecimal(10));
		otpPolicy.setOppolicymode(policyMode);
		otpPolicy.setOpencryptionkey("31323334353637383930");
		otpPolicy.setOpalgorithm("HmacSHA1");
		List<OtpPolicy> otpPolicies = new ArrayList<>();
		otpPolicies.add(otpPolicy);
		return otpPolicies;
	}

}
