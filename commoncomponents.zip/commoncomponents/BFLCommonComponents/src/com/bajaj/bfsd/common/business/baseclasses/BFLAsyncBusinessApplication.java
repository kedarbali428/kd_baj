package com.bajaj.bfsd.common.business.baseclasses;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.scheduling.annotation.AsyncConfigurerSupport;
import org.springframework.scheduling.annotation.EnableAsync;

@RefreshScope
@SpringBootApplication
@ComponentScans(value = {@ComponentScan("com.bajaj.bfsd.*"),
        @ComponentScan("com.bfl.bfsd.*"), @ComponentScan("com.bfl.common.*")})
@EnableAsync
//@EnableEurekaClient
public abstract class BFLAsyncBusinessApplication extends AsyncConfigurerSupport
{
	@Value("${asyncThread.corePoolSize:100}")
	private String asyncThreadCorePoolSize;
	
	@Value("${asyncThread.maxPoolSize:200}")
	private String asyncThreadMaxPoolSize;
	
	@Value("${asyncThread.queueCapacity:500}")
	private String asyncThreadQueueCapacity;
	
	@Value("${asyncThread.threadNamePrefix:AsyncThread-}")
	private String asyncThreadNamePrefix;
	
	 /**
     * @author 598520
     */
    @Override
    @Bean
    public Executor getAsyncExecutor() {
    	ContextAwarePoolExecutor  executor = new ContextAwarePoolExecutor ();
        executor.setCorePoolSize(Integer.parseInt(asyncThreadCorePoolSize));
        executor.setMaxPoolSize(Integer.parseInt(asyncThreadMaxPoolSize));
        executor.setQueueCapacity(Integer.parseInt(asyncThreadQueueCapacity));
        executor.setThreadNamePrefix(asyncThreadNamePrefix);
        executor.initialize();
        return executor;
    }
}
