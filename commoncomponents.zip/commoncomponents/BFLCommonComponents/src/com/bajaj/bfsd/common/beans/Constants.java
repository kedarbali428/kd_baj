package com.bajaj.bfsd.common.beans;

public class Constants {

	public static final String PAYLOAD = "payload";
	public static final String JSON_KEY_STATUS = "status";
	public static final String APPLICATION_ID = "applicationId";
	public static final String DYNAMO_DB_TABLE_NAME_TO_SAVE_BALIC_RESPONSE = "BALIC";

	private Constants() {

	}
}
