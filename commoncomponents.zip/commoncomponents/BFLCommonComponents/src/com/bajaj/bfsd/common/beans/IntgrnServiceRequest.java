package com.bajaj.bfsd.common.beans;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpMethod;

public class IntgrnServiceRequest {

	private Object reqObject;
	private String intgrnUrl;
	private String errorCode;
	private String errorMsg;
	private String logServiceName;
	private String logMsg;
	private Map<String, String> pathParamMap = new HashMap<>();
	private Class<?> classType;
	// currently supporting only GET and POST,if reqType is not set then default
	// reqType is GET
	private HttpMethod reqType = HttpMethod.GET;
	private String dynamoDBSource;
	private String dynamoDBSourceType;
	private boolean excepReqd = true;

	public Object getReqObject() {
		return reqObject;
	}

	public void setReqObject(Object reqObject) {
		this.reqObject = reqObject;
	}

	public String getIntgrnUrl() {
		return intgrnUrl;
	}

	public void setIntgrnUrl(String intgrnUrl) {
		this.intgrnUrl = intgrnUrl;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getLogServiceName() {
		return logServiceName;
	}

	public void setLogServiceName(String logServiceName) {
		this.logServiceName = logServiceName;
	}

	public String getLogMsg() {
		return logMsg;
	}

	public void setLogMsg(String logMsg) {
		this.logMsg = logMsg;
	}

	public Class<?> getClassType() {
		return classType;
	}

	public void setClassType(Class<?> classType) {
		this.classType = classType;
	}

	public Map<String, String> getPathParamMap() {
		return pathParamMap;
	}

	public void setPathParamMap(Map<String, String> pathParamMap) {
		if (pathParamMap != null) {
			this.pathParamMap = pathParamMap;
		}
	}

	public void addPathParamMap(String pathParamName, String pathParam) {
		pathParamMap.put(pathParamName, pathParam);
	}

	public HttpMethod getReqType() {
		return reqType;
	}

	public String getDynamoDBSource() {
		return dynamoDBSource;
	}

	public void setDynamoDBSource(String dynamoDBSource) {
		this.dynamoDBSource = dynamoDBSource;
	}

	public String getDynamoDBSourceType() {
		return dynamoDBSourceType;
	}

	public void setDynamoDBSourceType(String dynamoDBSourceType) {
		this.dynamoDBSourceType = dynamoDBSourceType;
	}

	public void setReqType(HttpMethod reqType) {
		if (null == reqType) {
			this.reqType = HttpMethod.GET;// default
		} else {
			this.reqType = reqType;
		}
	}

	public boolean isExcepReqd() {
		return excepReqd;
	}

	public void setExcepReqd(boolean excepReqd) {
		this.excepReqd = excepReqd;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((intgrnUrl == null) ? 0 : intgrnUrl.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IntgrnServiceRequest other = (IntgrnServiceRequest) obj;
		if (intgrnUrl == null) {
			if (other.intgrnUrl != null)
				return false;
		} else if (!intgrnUrl.equals(other.intgrnUrl)) {
			return false;
		}
		return true;
	}
}
