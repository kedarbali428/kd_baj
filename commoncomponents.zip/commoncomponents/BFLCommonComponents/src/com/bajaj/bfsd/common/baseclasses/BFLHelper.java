package com.bajaj.bfsd.common.baseclasses;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.mock.env.MockPropertySource;

public class BFLHelper {
	
	private static boolean isCentralConfigLoaded;
	
	private BFLHelper() {
	    throw new IllegalAccessError("Utility class");
	}
	
	public static void getCentralConfig(Environment env) throws IOException {
		if (!isCentralConfigLoaded) {
			String url = env.getProperty("spring.cloud.config.endpoints.uri");
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String json = response.toString();
			JSONObject jsonObj = new JSONObject(json);
			jsonObj = jsonObj.getJSONArray("propertySources").getJSONObject(0).getJSONObject("source");
			Properties  properties = toProperties(jsonObj);
			((ConfigurableEnvironment)env).getPropertySources().addFirst(new MockPropertySource("centralconfig",properties));
			isCentralConfigLoaded = true;
		}
	}
	
	/**
     * Converts the JSONObject into a property file object.
     * @param jo JSONObject
     * @return java.util.Properties
     * @throws JSONException
     */
	 public static Properties toProperties(JSONObject jo) {
	        Properties  properties = new Properties();
	        if (jo != null) {
	        	Iterator<String> keys = jo.keys();
	        	while (keys.hasNext()) {
	        		String key = keys.next();
	        		properties.put(key, jo.get(key));
	        	}
	        }
	        return properties;
	    }
}
