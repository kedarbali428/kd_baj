package com.bajaj.bfsd.common.baseclasses;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@RefreshScope
public abstract class BFLConfiguration { //NOSONAR
}
