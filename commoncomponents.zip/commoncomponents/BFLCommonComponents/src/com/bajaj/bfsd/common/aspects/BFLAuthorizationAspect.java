package com.bajaj.bfsd.common.aspects;

import static com.bajaj.bfsd.authentication.util.BFLForcedAuthContants.ROLE_CUSTOMER;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.bajaj.bfsd.authentication.filter.AuthenticationFilter;
import com.bajaj.bfsd.authentication.filter.AuthorizationFilter;
import com.bajaj.bfsd.authentication.filter.BFLForcedAuthenticationFilter;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.integration.baseclasses.CamelRequestMapping;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicy;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicyMap;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.security.beans.UserProfileBean;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.fasterxml.jackson.dataformat.csv.CsvSchema.ColumnType;

/*
 * This class is responsible for the Authorization of REST APIs. It will read the URI and call Authorization service to
 * check if caller has access or not. If caller has access then request will be forwarded to be fulfilled else it unathorized 
 * exception will be thrown.
 */
@Aspect
@Component
@Order(value = 1)
@ConfigurationProperties(prefix = "")
public class BFLAuthorizationAspect {

	private static final String CLASSNAME = BFLAuthorizationAspect.class.getName();

	@Autowired
	BFLAuthorizationPolicyMap authMap;

	private static final String EMPTY_STRING = "";
	private static final String ERR_STRING = "Issue during performing authentication, try logging in again.";

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	UserProfileBean upb;

	@Autowired
	CustomDefaultHeaders customHdrs;

	@Autowired
	private Environment env;

	private Map<String, String> policy;

	@Autowired
	AuthenticationFilter authenticationFilter;

	@Autowired
	AuthorizationFilter authorizationFilter;
	
	@Autowired 
	BFLForcedAuthenticationFilter forcedAuthenticationFilter;
	
	@Value("${userprofile.finegrain.authcheck.load}")
	private boolean finegrainCheckLoad;
	
	@Value("${userprofile.finegrain.authcheck.verify:false}")
	private boolean finegrainCheckVerify;
	
	private static final String BFSD_500 = "BFSD-500";

	public Map<String, String> getPolicy() {
		return policy;
	}

	public void setPolicy(Map<String, String> policy) {
		this.policy = policy;
	}

	/**
	 * Pointcut defined for camel bean implementation class
	 */
	@Pointcut("within(com.bajaj.bfsd.common.integration.baseclasses.BFLCamelController+)")
	public void camelControllerBean() {
		// Pointcut method; implementation not needed
	}

	/**
	 * Pointcut defined for camel bean methods
	 */
	@Pointcut("execution(public * *(..)) && @annotation(com.bajaj.bfsd.common.integration.baseclasses.CamelRequestMapping)")
	public void camelMethodPointcut() {
		// Pointcut method; implementation not needed
	}

	/**
	 * Pointcut defined for business controller class
	 */
	@Pointcut("within(com.bajaj.bfsd.common.baseclasses.BFLController+) || within(com.bajaj.bfsd.common.cache.basecontroller.CacheBaseController+)")
	public void controllerBean() {
		logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside controllerBean");
	}

	/**
	 * Pointcut defined for controller methods
	 */
	@Pointcut("execution(public * *(..)) && @annotation(org.springframework.web.bind.annotation.RequestMapping)")
	public void methodPointcut() {
		// Pointcut method; implementation not needed
	}

	@PostConstruct
	public final void createAuthMap() {
		try {
			CsvMapper mapper = new CsvMapper();
			CsvSchema schema = CsvSchema.builder().addColumn("uri", ColumnType.STRING)
					.addColumn("requestMethod", ColumnType.STRING)
					.addColumn("isAuthenticationRequired", ColumnType.STRING_OR_LITERAL)
					.addColumn("isAuthorizationRequired", ColumnType.STRING_OR_LITERAL)
					.addColumn("roles", ColumnType.STRING_OR_LITERAL).setColumnSeparator(';').build();
			ObjectReader r = mapper.reader(BFLAuthorizationPolicy.class).with(schema);
			StringBuilder builder = new StringBuilder();
			if(null!=policy){
				for (Map.Entry<String, String> entry : policy.entrySet()) {
					String propValue = entry.getValue();
					builder.append(propValue);
					builder.append('\n');
				}
			}
			String input = builder.toString();

			MappingIterator<BFLAuthorizationPolicy> it = r.readValues(input);
			while (it.hasNext()) {
				BFLAuthorizationPolicy bflpolicy = it.next();
				String key = bflpolicy.getUri() + bflpolicy.getRequestMethod();
				authMap.putPolicy(key, bflpolicy);
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"BFLAuthorizationAspect.createAuthMap(): Exception :" + e.getMessage());
			throw new BFLTechnicalException("Issue while reading the policies.", e);
		}
	}

	@Before("controllerBean() && methodPointcut()")
	public void beforeRestControllerMethod(JoinPoint joinPoint) {
		performAuthenticationAuthorizationCheck(joinPoint, false);
		if(finegrainCheckLoad && finegrainCheckVerify && ROLE_CUSTOMER.equalsIgnoreCase(customHdrs.getDefaultRole())){
			forceAuthenticateRequest(joinPoint);
		}else{
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "finegrainCheckLoad : "+finegrainCheckLoad);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "finegrainCheckVerify : "+finegrainCheckVerify);
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "customHdrs.getUserKey() : "+customHdrs.getUserKey());
		}
	}

	@Before("camelControllerBean() && camelMethodPointcut()")
	public void beforeCamelControllerMethod(JoinPoint joinPoint) {
		performAuthenticationAuthorizationCheck(joinPoint, true);
	}

	public void performAuthenticationAuthorizationCheck(JoinPoint joinPoint, boolean isCamelController) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
				"In BFLAuthorizationAspect:performAuthenticationAuthorizationCheck");
		try {
			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
					.getRequest();
			if (null == request) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
						"In BFLAuthorizationAspect:performAuthenticationAuthorizationCheck - HTTP Request object NULL!!!");
				throw new BFLTechnicalException(BFSD_500, "Internal Server Error; HTTP request null.");
			}
			extractHeaders(request);
			if (request.getMethod().equalsIgnoreCase(HttpMethod.OPTIONS.toString())) {
				return;// If this is option call then ignore it.
			}
			String uri = isCamelController ? getCamelURI(joinPoint) : getRestURI(joinPoint);
			String retVal = authenticationFilter.isUserAuthenticated(uri);
			if (null == retVal || retVal.trim().length() == 0) {
				long userId = customHdrs == null ? 0L : customHdrs.getUserKey();
				if (!authorizationFilter.isUserAuthorized(uri, userId)) {
					logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
							"In BFLAuthorizationAspect:performAuthenticationAuthorizationCheck - User"
									+ (customHdrs == null ? " not available."
											: (customHdrs.getUserKey() + " is not allowed to access the uri - "
													+ uri)));
					throw new BFLHttpException(HttpStatus.FORBIDDEN,"BFSD-403", "You are not authorized to use this service.!!");
				}
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,
						"In BFLAuthorizationAspect:performAuthenticationAuthorizationCheck - User"
								+ customHdrs.getUserKey() + " is not authenticated for URI - " + uri);
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED,retVal, "You are not authenticated, try logging in again!!");
			}
			populateUserProfile();
		} catch (BFLTechnicalException | BFLHttpException bfle) {
			switch (bfle.getCode()) {
			case "BFSD-403":
				throw new BFLHttpException(HttpStatus.FORBIDDEN,"BFSD-403", "You are not authorized to use this service.!!");
			case "BFSD-401":
				throw new BFLHttpException(HttpStatus.UNAUTHORIZED,"BFSD-401", "You are not authenticated, try logging in again!!");
			default:
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
						"In BFLAuthorizationAspect:performAuthenticationAuthorizationCheck - Issue during performing authentication, try logging in again.",
						bfle);
				throw new BFLTechnicalException(BFSD_500, ERR_STRING);
			}
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"In BFLAuthorizationAspect:performAuthenticationAuthorizationCheck - " + ERR_STRING);
			throw new BFLTechnicalException(ERR_STRING, e);
		}
	}

	private String getCamelURI(JoinPoint joinPoint) {
		String uri = EMPTY_STRING;
		String endPointUri = EMPTY_STRING;
		if (null == joinPoint)
			return uri;
		try {
			MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
			Method endPointMethod = methodSignature.getMethod();
			String requestMethod = null;
			CamelRequestMapping methodAnnotation = endPointMethod.getDeclaredAnnotation(CamelRequestMapping.class);
			if (null != methodAnnotation) {
				// retrieve endpoint uri
				String[] requestPaths = methodAnnotation.value();
				if (null != requestPaths && requestPaths.length > 0) {
					endPointUri = getResolvedURI(requestPaths[0]);
				}
				// retrieve endpoint method (POST,PUT,etc.)
				RequestMethod[] requestMethods = methodAnnotation.method();
				if (null != requestMethods && requestMethods.length > 0)
					requestMethod = requestMethods[0].toString();
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Endpoint URI is - " + endPointUri);
			uri = endPointUri + requestMethod;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"Technical issue retrieving URL from controller method\n" + e.toString(), e);
			uri = EMPTY_STRING;
		}
		nullCheck(uri); // Checking if the retreived URI is null
		return uri;
	}

	private void nullCheck(String uri) {
		if (uri == null) {
			throw new BFLTechnicalException(BFSD_500, "Internal Server Error; URI null.");
		} else if (uri.trim().isEmpty()) {
			throw new BFLTechnicalException(BFSD_500, "Internal Server Error; URI null.");
		}
	}

	private void extractHeaders(HttpServletRequest request) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "in extractHeaders()");
		if (null != request)
			customHdrs.setCustomHeaders(request);
	}

	private void populateUserProfile() {
		upb.setUserid(customHdrs.getUserKey());
		upb.setDefaultRole(customHdrs.getDefaultRole());
	}

	private String getRestURI(JoinPoint joinPoint) {
		String uri = EMPTY_STRING;
		String baseUri = EMPTY_STRING;
		String endPointUri = EMPTY_STRING;
		if (null == joinPoint)
			return uri;
		try {
			Class<?> controllerClass = joinPoint.getSignature().getDeclaringType();
			RequestMapping controllerAnnotation = controllerClass.getAnnotation(RequestMapping.class);
			if (null != controllerAnnotation) {
				String[] baseUris = controllerAnnotation.value();
				if (null != baseUris && baseUris.length > 0)
					baseUri = getResolvedURI(baseUris[0]);
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Base URI is - " + baseUri);
			MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
			Method endPointMethod = methodSignature.getMethod();
			String requestMethod = null;
			RequestMapping methodAnnotation = endPointMethod.getDeclaredAnnotation(RequestMapping.class);
			if (null != methodAnnotation) {
				// retrieve endpoint uri
				String[] requestPaths = methodAnnotation.value();
				if (null != requestPaths && requestPaths.length > 0) {
					endPointUri = getResolvedURI(requestPaths[0]);
				}
				// retrieve endpoint method (POST,PUT,etc.)
				RequestMethod[] requestMethods = methodAnnotation.method();
				if (null != requestMethods && requestMethods.length > 0)
					requestMethod = requestMethods[0].toString();
			}
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Endpoint URI is - " + endPointUri);
			uri = baseUri + endPointUri + requestMethod;
		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"Technical issue retrieving URL from controller method\n" + e.toString(), e);
			uri = EMPTY_STRING;
		}
		nullCheck(uri); // Checking if the retreived URI is null
		return uri;
	}

	private String getResolvedURI(String uriInfo) {
		String defaultURI = EMPTY_STRING;
		String uri = uriInfo;
		if (uri == null) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "URI null!!!");
			return null;
		}

		if (uri.contains(":")) {
			String[] uris = uri.split(":");
			uri = uris[0];
			defaultURI = uris[1];
		}

		if (uri.contains("$")) {
			StringBuffer resolvedURI = new StringBuffer(100); // NOSONAR
			Pattern pattern = Pattern.compile("\\$\\{(.*?)\\}");
			Matcher matcher = pattern.matcher(uri);
			while (matcher.find()) {
				String key = matcher.group().replaceAll("[${}]", "");
				String actualURI = env.getProperty(key);
				if (actualURI == null)
					return defaultURI;
				else
					matcher.appendReplacement(resolvedURI, actualURI);
			}
			matcher.appendTail(resolvedURI);
			logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Resolved URI: " + resolvedURI.toString());
			return resolvedURI.toString();
		}
		return uri;
	}
	
	private void forceAuthenticateRequest(JoinPoint thisJoinPoint) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Inside logRequestBody");
	 try{
	   MethodSignature methodSignature = (MethodSignature) thisJoinPoint.getSignature();
	   Annotation[][] annotationMatrix = methodSignature.getMethod().getParameterAnnotations();
	   int index = -1;
	   for (Annotation[] annotations : annotationMatrix) {
	     index++;
	     for (Annotation annotation : annotations) {
	       if (!(annotation instanceof RequestBody))
	         continue;
	       Object requestBody = thisJoinPoint.getArgs()[index];
	       if(!forcedAuthenticationFilter.finegrainCheckRequest(requestBody))
	       {
			 throw new BFLHttpException(HttpStatus.UNAUTHORIZED,"BFSD-401", "Forced Authencation is failed, Unable to perform this action!!");
	       }
	       logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "thisJoinPoint ::"+thisJoinPoint);
	       logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "thisJoinPoint ::"+requestBody);
	     }
	   }
	 }catch(BFLHttpException e)
	 {
		logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured for logRequestBody "+ e);
		throw new BFLHttpException(HttpStatus.UNAUTHORIZED,"BFSD-401", "Forced Authencation is failed, Unable to perform this action!!");
	 }catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"In BFLAuthorizationAspect:performAuthenticationAuthorizationCheck - " + ERR_STRING);
			throw new BFLTechnicalException(ERR_STRING, e);
	 }
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Exit logRequestBody");
	 }

}