package com.bajaj.bfsd.common.baseclasses;

import java.io.Serializable;

import org.springframework.cloud.context.config.annotation.RefreshScope;

@RefreshScope
public abstract class BFLEntity implements Serializable { //NOSONAR
}
