package com.bajaj.bfsd.common.integration.baseclasses;


public abstract class BFLCamelController { //NOSONAR

}
