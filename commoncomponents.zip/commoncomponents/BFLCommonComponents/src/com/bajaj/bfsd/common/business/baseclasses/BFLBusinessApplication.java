package com.bajaj.bfsd.common.business.baseclasses;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;

@RefreshScope
@SpringBootApplication
@ComponentScans(value = {@ComponentScan("com.bajaj.bfsd.*"),
        @ComponentScan("com.bfl.bfsd.*"), @ComponentScan("com.bfl.common.*")})
//@EnableEurekaClient
public abstract class BFLBusinessApplication { //NOSONAR
}