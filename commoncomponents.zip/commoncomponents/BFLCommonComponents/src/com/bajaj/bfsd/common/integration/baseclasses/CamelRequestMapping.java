package com.bajaj.bfsd.common.integration.baseclasses;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.core.annotation.AliasFor;
import org.springframework.web.bind.annotation.RequestMethod;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface CamelRequestMapping {
	@AliasFor("path")
	String[] value() default {};
	RequestMethod[] method() default {};
}