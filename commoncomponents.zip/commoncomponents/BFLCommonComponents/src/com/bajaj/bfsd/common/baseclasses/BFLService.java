package com.bajaj.bfsd.common.baseclasses;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

@RefreshScope
@Service
public abstract class BFLService { //NOSONAR
}
