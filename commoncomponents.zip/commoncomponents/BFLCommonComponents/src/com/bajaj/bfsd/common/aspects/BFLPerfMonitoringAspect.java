package com.bajaj.bfsd.common.aspects;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bfl.common.exceptions.BFLTechnicalException;

/**
 * Created by Jigar Thakkar
 */
@Aspect
//@Component
@Order(value=2)
public class BFLPerfMonitoringAspect {
	
	private static final String CLASSNAME = BFLPerfMonitoringAspect.class.getName();
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	private String logPerformance;
	
	@Autowired
    private Environment env;

	@Pointcut("within(com.bajaj.bfsd.common.baseclasses.BFLController+)")
    public void controllerBean() {
		//Pointcut method; implementation not needed
	}

    @Pointcut("execution(public * *(..)) && @annotation(org.springframework.web.bind.annotation.RequestMapping)")
    public void methodPointcut() {
    	//Pointcut method; implementation not needed
    }
    
    @Around("controllerBean() && methodPointcut() ")
    public Object logPerfMonitoring(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
    	long startMillis=System.currentTimeMillis();
    	Object returnObject = proceedingJoinPoint.proceed();
    		try {
    	    	String className = proceedingJoinPoint.getSignature().getDeclaringTypeName();
            	className = className.substring(className.lastIndexOf('.')+1,className.indexOf("Controller"));
            	logPerformance = env.getProperty(className+".logPerformance");
    			if ("Y".equals(logPerformance)) {
    				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY,"Error in BFLPerfMonitoringAspect.aroundSampleCreation  logging performance");
    	        	String methodName = proceedingJoinPoint.getSignature().getName();	
                	SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy HH:mm:ss:SSS");
                    long endMillis=System.currentTimeMillis();
                	String startTime = sdf.format(new Date(startMillis));
                	String endTime = sdf.format(new Date(endMillis));
                    StringBuilder logMessage = new StringBuilder();
                    logMessage.append("PERFMON:").append(className).append(".").append(methodName).append(" start:").append(startTime).append(", end:").append(endTime).append(", total time(ms):").append(endMillis - startMillis);
        			logger.info(CLASSNAME, BFLLoggerComponent.UTILITY,logMessage.toString());
    			}    			
        	}
        	catch(Exception e) {
    			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,"Error in BFLPerfMonitoringAspect.aroundSampleCreation. Ignoring & proceeding. Exception:" + e.getMessage());
    			throw new BFLTechnicalException("Issue while logging performance metrics.", e);
        	}
        return returnObject;
    }
}
