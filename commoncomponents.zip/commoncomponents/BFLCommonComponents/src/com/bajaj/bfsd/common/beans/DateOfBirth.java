package com.bajaj.bfsd.common.beans;

import java.io.Serializable;

public class DateOfBirth implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7735324358560804240L;

	private String day;
	
	private String month;
	
	private String year;

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "DateOfBirth [day=" + day + ", month=" + month + ", year=" + year + "]";
	}

	
}	
	
