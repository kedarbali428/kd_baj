package com.bajaj.bfsd.authentication.util;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.beans.DateOfBirth;
import com.bfl.common.exceptions.BFLBusinessException;

public class DateTimeUtil {
	public static final String ALLOWED_DATE_FORMAT = "yyyy-MM-dd";

	@Autowired
	static Environment env;

	public static final String ERR_CD = "GEN-1100";

	private DateTimeUtil() {
	}

	/**
	 * @Desc This method is used to get current date
	 * @return Date
	 */
	public static Timestamp getCurrentDate() {
		Date date = Calendar.getInstance().getTime();
		return new Timestamp(date.getTime());
	}

	/**
	 * @Desc This method is used to get yesterdays date
	 * @return Date
	 */
	public static Date getOneYearLaterDate() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, 1);
		return cal.getTime();
	}

	/**
	 * 715743 get {@link DateOfBirth} from {@link Date} Object
	 * 
	 * @param date
	 * @return
	 */
	public static DateOfBirth getDateOfBirth(Date date) {
		DateOfBirth dateOfBirth = null;
		if (null != date) {
			dateOfBirth = new DateOfBirth();
			Calendar c = Calendar.getInstance();
			c.setTime(date);
			dateOfBirth.setDay(String.valueOf(c.get(Calendar.DAY_OF_MONTH)));
			dateOfBirth.setMonth(String.valueOf(c.get(Calendar.MONTH)));
			dateOfBirth.setYear(String.valueOf(c.get(Calendar.YEAR)));
		}
		return dateOfBirth;
	}

	/**
	 * @author 598520
	 * @param date
	 * @param initDateFormat
	 * @param endDateFormat
	 * @return
	 */
	public static Date changeDateFormat(String inputDate, String fromDateFormat, String toDateFormat) {
		Date initDate;
		Date finalDateFormatted = null;
		if (!StringUtils.isEmpty(inputDate)) {
			try {
				SimpleDateFormat initDtFormatter = new SimpleDateFormat(fromDateFormat);
				initDtFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
				initDate = initDtFormatter.parse(inputDate);

				SimpleDateFormat endDateFormatter = new SimpleDateFormat(toDateFormat);
				endDateFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
				String parsedDate = endDateFormatter.format(initDate);
				finalDateFormatted = endDateFormatter.parse(parsedDate);
			} catch (ParseException pe) {
				throw new BFLBusinessException(ERR_CD, env.getProperty(ERR_CD));
			}
		}
		return finalDateFormatted;
	}

	/**
	 * Converts input string date to Java Date object in default format
	 * 
	 * @param inputDate
	 * @return
	 */
	public static Date getFormattedDate(String inputDate) {
		return convertDateToSpecifiedFormat(inputDate, ALLOWED_DATE_FORMAT);
	}

	/**
	 * Converts input string date to Java Date object in specified format
	 * 
	 * @param inputDate
	 * @param dateFormat
	 * @return
	 */
	public static Date convertDateToSpecifiedFormat(String inputDate, String dateFormat) {
		Date date = null;
		if (!StringUtils.isEmpty(inputDate)) {
			try {

				date = new SimpleDateFormat(dateFormat).parse(inputDate);
			} catch (ParseException pe) {
				throw new BFLBusinessException(ERR_CD, env.getProperty(ERR_CD));
			}
		}
		return date;
	}

	/**
	 * Returns a String date by converting input Java Date to default format.
	 * 
	 * @author abhishek karnani
	 * @param date
	 * @return
	 */
	public static String getStringDate(Date date) {
		return getStringDate(date, ALLOWED_DATE_FORMAT);

	}

	/**
	 * Returns a String date by converting input Java Date to specified format.
	 * 
	 * @param date
	 * @param toDateFormat
	 * @return
	 */
	public static String getStringDate(Date date, String toDateFormat) {
		String dateString = null;
		if (null != date) {
			SimpleDateFormat sdf = new SimpleDateFormat(toDateFormat);
			dateString = sdf.format(date);
		}
		return dateString;
	}

	/**
	 * @author 577467
	 * @param prevExpDate
	 * @return
	 */
	public static String allowedDobFormatStringDate(String prevExpDate) {
		DateTimeFormatter formatter = new DateTimeFormatterBuilder().parseCaseInsensitive().appendPattern("dd-MMM-yyyy")
				.toFormatter(Locale.UK);
		LocalDate ld = LocalDate.parse(prevExpDate, formatter);
		DateTimeFormatter newFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return ld.format(newFormatter);
	}

	public static BigDecimal completedYearsAsPerLastBirthday(Date dob) {
		if (null == dob) {
			return null;
		}
		Calendar dobcal = Calendar.getInstance();
		dobcal.setTime(dob);
		LocalDate currDate = LocalDate.now();
		LocalDate birthDate = LocalDate.of(dobcal.get(Calendar.YEAR), dobcal.get(Calendar.MONTH) + 1,
				dobcal.get(Calendar.DAY_OF_MONTH));
		return new BigDecimal(Period.between(birthDate, currDate).getYears());
	}

	public static boolean validateAgeChange(String dateOfBirth, BigDecimal dbAge) {
		try {
			boolean ageChangeFlag = false;
			Date dob = new SimpleDateFormat(ALLOWED_DATE_FORMAT).parse(dateOfBirth);
			BigDecimal currAge = completedYearsAsPerLastBirthday(dob);
			if (dbAge.compareTo(currAge) != 0) {
				ageChangeFlag = true;
			}
			return ageChangeFlag;
		} catch (ParseException pe) {
			throw new BFLBusinessException(ERR_CD, env.getProperty(ERR_CD));
		}
	}

	/**
	 * @author 577467
	 * @param tenure
	 * @return
	 */
	public static Date getTermEndDate(BigDecimal tenure) {
		Date termEndDate = null;
		if (null != tenure) {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DAY_OF_MONTH, -1);
			cal.add(Calendar.YEAR, tenure.intValueExact());
			termEndDate = cal.getTime();
		}
		return termEndDate;
	}

	public static int getCurrentYear() {
		Date currentDate = Calendar.getInstance().getTime();
		long timestamp = currentDate.getTime();
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(timestamp);
		return cal.get(Calendar.YEAR);
	}

	public static Date getMonthTermEndDate(BigDecimal tenure) {
		Date termEndDate = null;
		if (null != tenure) {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DAY_OF_MONTH, -1);
			cal.add(Calendar.MONTH, tenure.intValueExact());
			termEndDate = cal.getTime();
		}
		return termEndDate;
	}
}
