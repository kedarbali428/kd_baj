package com.bajaj.bfsd.authentication.util;

import java.io.IOException;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class BFLServiceCallProcessorUtil {

	@Autowired
	private BFLLoggerUtilExt logger;

	@Autowired
	private Environment env;

	private static final String CLASSNAME = BFLServiceCallProcessorUtil.class.getName();

	/**
	 * @author Abhishek Karnani
	 * @param requestObject
	 * @return
	 */
	public String prepareRequestJsonForServiceCall(Object requestObject) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside prepareRequestJsonForServiceCall()");
		String requestJson;

		try {
			if (requestObject instanceof JSONObject) {
				logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Exit from prepareRequestJsonForServiceCall() in ");
				return requestObject.toString();
			}
			ObjectMapper mapper = MapperFactory.getInstance();
			requestJson = mapper.writeValueAsString(requestObject);
		} catch (JsonProcessingException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"JsonProcessingException occurred while preparing requestJson for call in prepareRequestJsonForServiceCall()",
					e);
			throw new BFLTechnicalException("EECPH-11901", env.getProperty("EECPH-11901"));
		}

		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Exit from prepareRequestJsonForServiceCall()");
		return requestJson;
	}

	/**
	 * @author Abhishek Karnani
	 * @param responseJson
	 * @param classType
	 * @return Object
	 */
	public Object getResponseObjectFromResponseJsonString(String responseJson, Class<?> classType) {
		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Inside getResponseObjectFromResponseJsonString()");
		Object responseObject = null;
		JSONObject obj = new JSONObject();
		if (!StringUtils.isEmpty(responseJson) && null != classType) {
			try {

				if (classType.isInstance(obj)) {
					responseObject = new JSONObject(responseJson);
				} else {
					ObjectMapper mapper = MapperFactory.getInstance();
					responseObject = mapper.readValue(responseJson, classType);
				}
			} catch (IOException ioe) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "IOException occurred while parsing response json",
						ioe);
				throw new BFLTechnicalException("ECPH-11902", env.getProperty("ECPH-11902"));
			}
		}

		logger.debug(CLASSNAME, BFLLoggerComponent.UTILITY, "Exit from getResponseObjectFromResponseJsonString()");
		return responseObject;
	}

	/**
	 * @param responseJson
	 * @param typeRef
	 * @return
	 */
	public <T> T getResponseListFromResponseJsonString(String responseJson, TypeReference<?> typeRef) {
		T responseList = null;
		if (null != responseJson && !responseJson.isEmpty() && null != typeRef) {
			ObjectMapper mapper = MapperFactory.getInstance();
			try {
				responseList = mapper.readValue(responseJson, typeRef);
			} catch (JsonParseException jpe) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
						"JsonParseException occurred while parsing response json", jpe);
				throw new BFLTechnicalException("GPGP-13108", env.getProperty("GPGP-13108"));
			} catch (JsonMappingException jme) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
						"JsonMappingException occurred while parsing response json", jme);
				throw new BFLTechnicalException("GPGP-13109", env.getProperty("GPGP-13109"));
			} catch (IOException ioe) {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "IOException occurred while parsing response json",
						ioe);
				throw new BFLTechnicalException("GPGP-13110", env.getProperty("GPGP-13110"));
			}
		}
		return responseList;
	}
}
