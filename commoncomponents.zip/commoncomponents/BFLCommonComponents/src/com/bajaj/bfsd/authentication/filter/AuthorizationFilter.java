package com.bajaj.bfsd.authentication.filter;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicy;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicyMap;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;

@Component
public class AuthorizationFilter {

	private static final String CLASSNAME = AuthorizationFilter.class.getName();

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	BFLAuthorizationPolicyMap authMap;

	@Autowired
	CustomDefaultHeaders customHdrs;

	@Value("${api.rolemanagement.checkRoleInUsersAssignedRolesHierarchy.POST.url:http://localhost:8080/v1/roles/users/assignments/validations}")
	private String validateUserRolesUrl;

	@Autowired
	private Environment env;

	private boolean isAuthorizationEnabled;

	public boolean isUserAuthorized(String uri, long userId) {

		boolean retValue = false;

		if (uri == null || uri.trim().length() <= 0
				|| !env.getProperty("authorization.flag", boolean.class, isAuthorizationEnabled)) {
			retValue = true;
			return retValue;
		}

		BFLAuthorizationPolicy policy = authMap.getPolicy(uri);
		if (policy == null) {
			return retValue;
		}

		retValue = policy.isAuthorizationRequired();

		if (retValue) {
			// check locally if user has requested with logged in role
			retValue = policy.hasRole(customHdrs.getDefaultRole());

			if (!retValue) {
				// If not then call role management service to check if the
				// required role is there in user's hierarchy
				retValue = checkInHierarchyIfUserHasPermittedRole(userId, policy);
			}
		}
		else {
			retValue = !retValue;
		}
		return retValue;
	}

	private boolean checkInHierarchyIfUserHasPermittedRole(long userId, BFLAuthorizationPolicy policy) {
		boolean retVal = false;

		HttpHeaders headersManual = new HttpHeaders();
		headersManual.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		JSONObject reqJsonObj = new JSONObject();
		reqJsonObj.put("userId", userId);
		reqJsonObj.put("commaSeparatedRolesToVerify", policy.getRolesStr());
		reqJsonObj.put("defaultRoleName", customHdrs.getDefaultRole());

		ResponseEntity<?> response = BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST, validateUserRolesUrl, null,
				ResponseBean.class, null, reqJsonObj.toString(), headersManual, null);

		if (null != response && HttpStatus.OK.equals(response.getStatusCode())) {

			ResponseBean resBean = (ResponseBean) response.getBody();

			if (resBean != null && StatusCode.SUCCESS.equals(resBean.getStatus())) {
				Object payLoad = resBean.getPayload();
				if (null != payLoad && (boolean) payLoad) {
					retVal = true;
				}
			} else {
				logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
						"checkInHierarchyIfUserHasPermittedRole - Role management service invocation retuned error - "
								+ (resBean!=null?resBean.getStatus():"Rolemanagement Service response payload is null"));
			}
		} else {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY,
					"checkInHierarchyIfUserHasPermittedRole - Role management service invocation retuned error - "
							+ (response == null ? "Rolemanagement Service response is null"
									: response.getStatusCode().toString()));
		}
		return retVal;
	}
}