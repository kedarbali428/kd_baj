package com.bajaj.bfsd.authentication.filter;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicy;
import com.bajaj.bfsd.security.beans.BFLAuthorizationPolicyMap;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bajaj.bfsd.security.beans.UserProfileBean;

@Component
public class AuthenticationFilter {
	private static final String CLASS = AuthenticationFilter.class.getName();

	@Autowired
	UserProfileBean upb;

	@Autowired
	BFLLoggerUtilExt logger;

	@Autowired
	CustomDefaultHeaders customHdrs;

	@Autowired
	BFLAuthorizationPolicyMap authMap;

	private static final String EXC_STRING = "doAuthCheck - access authentication failure. Authentication Service technical issue.";
	private static final String BFSD_401 = "BFSD-401";
	
	@Value("${api.tokenmanagement.validatetoken.GET.url:http://nprodcs-app09-1364047250.ap-southeast-1.elb.amazonaws.com:37015/v1/tokens/validations}")
	private String authServiceURL;

	@Autowired
	private Environment env;

	private boolean isAuthenticationEnabled;

	public String isUserAuthenticated(String uri) {
		String retVal = "";

		boolean isRequired = isAuthenticationRequired(uri);
		if (isRequired) {
			retVal = doAuthenticationCheck();
		}

		return retVal;
	}

	private boolean isAuthenticationRequired(String uri) {
		boolean retVal = true;

		if (!env.getProperty("authentication.flag", boolean.class, isAuthenticationEnabled)
				|| (customHdrs.getUserKey() > 0)) {
			retVal = false;
		} else {
			BFLAuthorizationPolicy policy = authMap.getPolicy(uri);
			if (policy != null) {
				retVal = policy.getIsAuthenticationRequired();
			}
		}
		return retVal;
	}

	private String doAuthenticationCheck() {
		String retVal = "";
		logger.debug(CLASS, BFLLoggerComponent.UTILITY, "doAuthCheck - entering");

		if (customHdrs.getAuthtoken() == null) {
			logger.error(CLASS, BFLLoggerComponent.UTILITY,
					"doAuthCheck - access authentication failure- Security headers missing from request");
			retVal = "BFSD-401";
			return retVal;
		}

		HttpHeaders hdrs = new HttpHeaders();

		ResponseEntity<?> validationResponse = BFLCommonRestClient.invokeRestEndpoint(HttpMethod.GET, authServiceURL,
				null, ResponseBean.class, null, null, hdrs);

		logger.debug(CLASS, BFLLoggerComponent.UTILITY, "doAuthCheck - returning from authentication service call");

		if (null == validationResponse || !HttpStatus.OK.equals(validationResponse.getStatusCode())) {
			logger.error(CLASS, BFLLoggerComponent.UTILITY, EXC_STRING);
			return BFSD_401;
		}

		ResponseBean resBean = (ResponseBean) validationResponse.getBody();
		if (resBean == null || !StatusCode.SUCCESS.equals(resBean.getStatus())) {
			logger.error(CLASS, BFLLoggerComponent.UTILITY, EXC_STRING);
			return BFSD_401;
		}
		
		HashMap<String, String> payLoad = (HashMap<String, String>) resBean.getPayload();
		if (null == payLoad) {
			logger.error(CLASS, BFLLoggerComponent.UTILITY,
					"doAuthCheck - access authentication failure- Authentication Service technical issue - no payload returned");
			return BFSD_401;
		}
		String tokenStatus = payLoad.get("tokenStatus");
		if (tokenStatus == null || ("EXPIRED".equals(tokenStatus) || "INVALID".equals(tokenStatus))) {
			logger.error(CLASS, BFLLoggerComponent.UTILITY,
					"doAuthCheck - access authentication failure- either token has expired or invalid");
			retVal = BFSD_401;
		} else {
			String userKeyStr = String.valueOf(payLoad.get("userId"));
			Long userKey = 0L;
			try {
				userKey = Long.parseLong(userKeyStr);
			} catch (Exception ex) {
				logger.error(CLASS, BFLLoggerComponent.UTILITY, "doAuthCheck - issue parsing userKey", ex);
			}
			customHdrs.setUserkey(userKey);
			customHdrs.setDefaultRole(payLoad.get("defaultRole"));
			customHdrs.setLoginid(payLoad.get("loginId"));
			logger.debug(CLASS, BFLLoggerComponent.UTILITY, "doAuthCheck - access authentication successful");
		}
		return retVal;
	}
}
