package com.bajaj.bfsd.authentication.filter;

import static com.bajaj.bfsd.authentication.util.BFLForcedAuthContants.ACTION_RESUME;
import static com.bajaj.bfsd.authentication.util.BFLForcedAuthContants.ACTION_TERMINATE;
import static com.bajaj.bfsd.authentication.util.BFLForcedAuthContants.ACTION_CONTINUE_NEW;
import static com.bajaj.bfsd.authentication.util.BFLForcedAuthContants.PARAM_MOBDOB_CHANGED;
import static com.bajaj.bfsd.authentication.util.BFLForcedAuthContants.ROLE_CUSTOMER;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.authentication.util.BFLCommonComponentUtil;
import com.bajaj.bfsd.authentication.util.MapperFactory;
import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.cache.service.UserProfileCacheService;
import com.bajaj.bfsd.common.cache.service.entity.UserProfileEntity;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class BFLForcedAuthenticationFilter {

	private static final String CLASSNAME = BFLForcedAuthenticationFilter.class.getName();


	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	UserProfileCacheService userProfileCacheService;
	
	@Autowired
	UserProfileCacheService userProfileServiceImpl;
	
	@Autowired
	protected Environment env;	
	
	@Value("#{'${applicationId.params}'.split(',')}")
	private List<String> applicationIdParams;
	
	@Value("#{'${applicantId.params}'.split(',')}")
	private List<String> applicantIdParams;
	
	@Value("#{'${mobileNumber.params}'.split(',')}")
	private List<String> mobileNumberParams;
	
	@Value("#{'${dateOfBirth.params}'.split(',')}")
	private List<String> dateOfBirthParams;
	
	@Value("#{'${appProcessId.params}'.split(',')}")
	private List<String> appProcessIdParams;
	
	@Value("#{'${applicationApplicantId.params}'.split(',')}")
	private List<String> applicationApplicantIdParams;
	
	@Value("${api.usermanagement.baseprofile.GET.url}")
	private String userProfileBaseUrl;
	
	@Autowired
	CustomDefaultHeaders customHdrs;
	
	public UserProfileEntity fetchUserProfile(boolean reloadAccessMapInCache)
	{
		UserProfileEntity userProfileEntity = null;
		Long userId=customHdrs.getUserKey(); 
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "UserId in fetchUserProfile -- "+userId);
		
		if(ROLE_CUSTOMER.equalsIgnoreCase(customHdrs.getDefaultRole()))
		{
			try{				
				if(!reloadAccessMapInCache) {
					userProfileEntity = userProfileCacheService.get(userId);
				}
				if(null != userProfileEntity && userProfileEntity.getApplicationIds()!=null && !userProfileEntity.getApplicationIds().isEmpty()){
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Applicant Key from userProfile is -- "+userProfileEntity.getApplicantId());
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Mobile Number  from userProfile is -- "+userProfileEntity.getMobileNumber());
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "date Of Birth from userProfile is -- "+userProfileEntity.getDateOfBirth());
					return userProfileEntity;
				}else{
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "UserProfileEntity not found against userId -- "+userId);
					//fetch it from DB via rest call and load into cache.
					//Rest endpoint call for user base entity user-management rest call. 
					userProfileEntity = getBaseUserProfile(userId);
					if(null!=userProfileEntity)
					{
						logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "userProfileCacheService save for userId -- " + userId);
						userProfileCacheService.save(userId, userProfileEntity);
					}
					else{
						logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "userProfileEntity is null so unable to save in cache");
					}
				}
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Exit from fetchUserProfile method");
				//match request to userprofile details
				}catch (Exception e) {
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Error occured while checking Forced Authentication -- "+userId);
					logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Error occured while checking Forced Authentication -- "+e);
				}
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Exit from fetchUserProfile method with userProfileEntity");
		return userProfileEntity;
	}
	
	@SuppressWarnings("unchecked")
	private UserProfileEntity getBaseUserProfile(Long userId) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "get getBaseUserProfile from rest call with db for userid -- " +userId);
		UserProfileEntity baseUserProfileEntity=null;
		String responsePayload;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		JSONObject reqJsonObj = new JSONObject();
		reqJsonObj.put("userKey", userId);
		Map<String, String> params = new HashMap<>();
		params.put("userKey", String.valueOf(userId));
		ResponseEntity<?> response = BFLCommonRestClient.invokeRestEndpoint(HttpMethod.GET,userProfileBaseUrl, null, String.class, params,null , headers);
		if(null != response && HttpStatus.OK.equals(response.getStatusCode())) {
			Object responseObject = response.getBody();
			JSONObject responseJson = getJsonObject(responseObject);
			if(null!=responseJson.get("payload"))
			{
				responsePayload = responseJson.get("payload").toString();	
				baseUserProfileEntity = mapFromJson(responsePayload,UserProfileEntity.class);
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "response from getBaseUserProfile -- "+response);
			}else{
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "payload for getBaseUserProfile is null -- "+userId);
			}
		}else{
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "invalid response from getBaseUserProfile");
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "returning baseUserProfileEntity for userId -- " +userId);
		return baseUserProfileEntity;
	}
	
	private JSONObject getJsonObject(Object object) {
		JSONObject jsonObject = new JSONObject();
		try {
			JSONParser parser = new JSONParser();
			if (object instanceof JSONObject) {
				jsonObject = (JSONObject) object;
			}else {
				Object obj = parser.parse(object.toString());
				jsonObject = (JSONObject) obj;
			}

		} catch (Exception e) {
			logger.error(CLASSNAME, BFLLoggerComponent.UTILITY, "Error occured while parsing :", e);
		}
		return jsonObject;
	}
	
	public <T> T mapFromJson(String jsonString, Class<T> clazz) {
		ObjectMapper mapper = MapperFactory.getInstance();
		try {
			return mapper.readValue(jsonString, clazz);
		} catch (IOException e) {
			logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "Exception occured in JSON to object conversion.", e);
			throw new BFLTechnicalException("JSNMAPEXC_001", env.getProperty("JSNMAPEXC_001"));
		}
	}

	public boolean finegrainCheckRequest(Object object) {
		boolean flag = true;
		if (null != object) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside validateRequest object not null");
			UserProfileEntity userProfileEntity = fetchUserProfile(false);
			if (null != userProfileEntity) {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"inside validateRequest userProfileEntity not null");
				flag = finegrainAuthCheck(object, userProfileEntity);
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "after validateVaptRequest flag -- " + flag);
			} else {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
						"not found userProfileEntity else set as -- " + flag);
				flag = true;
			}
		}
		return flag;
	}
	private boolean finegrainAuthCheck(Object object, UserProfileEntity userProfileEntity) {
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside validateVaptRequest");
		if (null != userProfileEntity) {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside userProfileEntity not null");
			Map<String, Set<Object>> mapAttributeObj = BFLCommonComponentUtil.getFlatMapKeyObjectList(object);
			if (null == mapAttributeObj || mapAttributeObj.isEmpty()) {
				return true;
			}

			Set<String> keySet = mapAttributeObj.keySet();
			boolean resOrTerOrContAction = isResOrTerOrContAction(mapAttributeObj);
			boolean mobdobChanged = isMobDobChanged(mapAttributeObj);
			if(mobdobChanged) {
				logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "MOB or DOB changed in this request & yet to be persisted. So in Authcheck will be ignored-- ");
			}
						
			for (String keyName : keySet) {
				if (keyName == null)
					continue;
				if (applicationIdParams.contains(keyName)) {
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside applicationIdParams.contains(keyName) -- "+keyName);
					List<Long> payloadAppKeys = BFLCommonComponentUtil.getListofLong(mapAttributeObj.get(keyName));
					if(payloadAppKeys!=null) {
						for (Long payloadAppKey : payloadAppKeys) {
							if (!userProfileEntity.getApplicationIds().contains(payloadAppKey)) {
								//reload the cache
								UserProfileEntity updatedUserProfileEntity = fetchUserProfile(true);
								if (!updatedUserProfileEntity.getApplicationIds().contains(payloadAppKey)) {
									logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "ApplicationKey missing in userProfile -- "+payloadAppKey);
									return false;
								}
							}
						}
					}
				} else if (applicantIdParams.contains(keyName)) {
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside applicantIdParams.contains(keyName) -- "+keyName);
					List<Long> applnIds = BFLCommonComponentUtil.getListofLong(mapAttributeObj.get(keyName));
					Long cacheApplicantId = userProfileEntity.getApplicantId();
					if (applnIds != null) {
						if (!applnIds.contains(cacheApplicantId)) {
							logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
									"payloadApplicantId and cacheApplicantId mismatch");
							return false;
						}
					} 
				} else if (appProcessIdParams.contains(keyName)) {
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside appProcessIdParams.contains(keyName) -- "+keyName);
					if(!resOrTerOrContAction) {
						List<String> payloadAppProcessIds = BFLCommonComponentUtil
								.getListofString(mapAttributeObj.get(keyName));
						if(payloadAppProcessIds!=null) {
							for (String payloadAppProcessId : payloadAppProcessIds) {
								if (!userProfileEntity.getAppProcessIds().contains(payloadAppProcessId)) {
									logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "ProcessId missing in userProfile and hence fetching from db -- "+payloadAppProcessId);
									if(!validateProcessIdFromDB(payloadAppProcessId)) {
										logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "ProcessId missing in userProfile and db also -- "+payloadAppProcessId);
										return false;
									}
								}
							}
						}
						
					}else {
						logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "Payload is from Resume or Terminate Action so skipping ProcessId check");
					}
				} else if (applicationApplicantIdParams.contains(keyName)) {
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
							"inside applicationApplicantIdParams.contains(keyName) -- "+keyName);
					List<Long> payloadApplicationApplicantIds = BFLCommonComponentUtil
							.getListofLong(mapAttributeObj.get(keyName));
					if(payloadApplicationApplicantIds!=null) {
						for (Long payloadApplicationApplicantId : payloadApplicationApplicantIds) {
							if (!userProfileEntity.getApplicationApplicantIds().contains(payloadApplicationApplicantId)) {
								//reload the cache
								UserProfileEntity updatedUserProfileEntity = fetchUserProfile(true);
								if (!updatedUserProfileEntity.getApplicationApplicantIds().contains(payloadApplicationApplicantId)) {
									logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "ApplicationApplicantId missing in userProfile -- "+payloadApplicationApplicantId);
									return false;
								}
							}
						}
					}
					
				} else if (!mobdobChanged && dateOfBirthParams.contains(keyName)) {
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside dateOfBirthParams.contains(keyName) -- "+keyName);
					List<String> payloadDateOfBirth = BFLCommonComponentUtil
							.getListofString(mapAttributeObj.get(keyName));
					String cacheDateOfBirth = userProfileEntity.getDateOfBirth();
					if (payloadDateOfBirth != null ) {
						if(!payloadDateOfBirth.contains(cacheDateOfBirth)) {
							logger.error(CLASSNAME, BFLLoggerComponent.SERVICE,
									"payloadDateOfBirth,cacheDateOfBirth mismatch");
							return false;
						}
					}
				} else if (!mobdobChanged && mobileNumberParams.contains(keyName)) {
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside mobileNumberParams.contains(keyName) -- "+keyName);
					List<String> payMobileNumber = BFLCommonComponentUtil.getListofString(mapAttributeObj.get(keyName));
					String cacheMobileNumber = userProfileEntity.getMobileNumber();
					if (payMobileNumber != null) {
						if(!payMobileNumber.contains(cacheMobileNumber)) {
							logger.error(CLASSNAME, BFLLoggerComponent.SERVICE, "payMobileNumber,cacheMobileNumber mismatch");
							return false;
						}
					}
				} else {
					logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "No criteria Matched for check values");
				}
			}
		} else {
			logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "inside userProfileEntity is null");
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE, "exit validateVaptRequest all check passed");
		return true;
	}

	private boolean isResOrTerOrContAction(Map<String, Set<Object>> mapAttributeObj) {
		Set<String> keySet = mapAttributeObj.keySet();
		if (keySet.contains("action")) {
			List<String> actions = BFLCommonComponentUtil.getListofString(mapAttributeObj.get("action"));
			if (actions != null && (actions.contains(ACTION_RESUME) || actions.contains(ACTION_TERMINATE) || actions.contains(ACTION_CONTINUE_NEW))) {
				return true;
			}
		}
		return false;
	}
	
	
	private boolean isMobDobChanged(Map<String, Set<Object>> mapAttributeObj) {
		Set<String> keySet = mapAttributeObj.keySet();
		if (keySet.contains(PARAM_MOBDOB_CHANGED)) {
			List<String> mobdobChanged = BFLCommonComponentUtil.getListofString(mapAttributeObj.get(PARAM_MOBDOB_CHANGED));
			if (mobdobChanged != null && (mobdobChanged.contains("true"))) {
				return true;
			}
		}
		return false;
	}
	
	private boolean validateProcessIdFromDB(String payloadAppProcessId) {
		boolean returnVal = false;
		Long userId = customHdrs.getUserKey();
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Inside validateProcessIdFromDB for processId -- " + payloadAppProcessId);
		UserProfileEntity userProfileEntity = getBaseUserProfile(userId);
		if (null != userProfileEntity && null != userProfileEntity.getAppProcessIds()
				&& userProfileEntity.getAppProcessIds().contains(payloadAppProcessId)) {
			returnVal = true;
		}
		logger.debug(CLASSNAME, BFLLoggerComponent.SERVICE,
				"Exit from validateProcessIdFromDB with return -- " + returnVal);

		return returnVal;
	}
	 
}