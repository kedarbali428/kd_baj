package com.bajaj.bfsd.authentication.util;

public class BFLForcedAuthContants {
	
	public static final String ACTION_RESUME = "resume";
	public static final String ACTION_TERMINATE = "terminate";
	public static final String ACTION_CONTINUE_NEW = "ContinueNew";
	public static final String PARAM_MOBDOB_CHANGED = "mobdobChanged";
	public static final String ROLE_CUSTOMER = "customer";
}