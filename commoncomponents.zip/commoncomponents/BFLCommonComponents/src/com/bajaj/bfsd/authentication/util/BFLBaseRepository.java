package com.bajaj.bfsd.authentication.util;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import java.util.Objects;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.baseclasses.BFLRepository;
import com.bajaj.bfsd.common.beans.Constants;
import com.bajaj.bfsd.common.beans.IntgrnServiceRequest;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.common.domain.MetadataBean;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.common.domain.StatusCode;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLTechnicalException;

@RefreshScope
@Service
public class BFLBaseRepository extends BFLRepository {

	@Autowired
	public BFLLoggerUtilExt logger;

	@Autowired
	public BFLServiceCallProcessorUtil serviceCallProcessor;

	@Autowired
	public Environment env;

	private static final String CLASS_NAME = BFLBaseRepository.class.getName();

	/**
	 * <Desc> This method will prepare the integration request object.
	 * 
	 * @param requestObj
	 *            The data that needs to be sent to endpoint
	 * @param pathParamMap
	 *            The request params if any that needs to be sent to endpoint
	 * @param respObject
	 *            Type of response required from service.
	 * @param reqType
	 *            Type of Http Request
	 * @param additionalParams
	 *            1-> service URL,2-> Service Name,3-> ErrCode.
	 * @return
	 */
	public IntgrnServiceRequest mapIntegrationRequest(Object requestObj, Map<String, String> pathParamMap,
			Class<?> respObject, HttpMethod reqType, String... additionalParams) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "mapIntegrationRequest - started");

		String errorCode = additionalParams[2];
		IntgrnServiceRequest intgrnServiceRequest = new IntgrnServiceRequest();

		intgrnServiceRequest.setPathParamMap(pathParamMap);
		intgrnServiceRequest.setReqObject(requestObj);
		intgrnServiceRequest.setReqType(reqType);
		intgrnServiceRequest.setIntgrnUrl(env.getProperty(additionalParams[0]));
		intgrnServiceRequest.setErrorCode(errorCode);
		intgrnServiceRequest.setErrorMsg(env.getProperty(errorCode));
		intgrnServiceRequest.setClassType(respObject);
		intgrnServiceRequest.setLogServiceName(additionalParams[1]);
		intgrnServiceRequest.setLogMsg(env.getProperty(errorCode));
		if (additionalParams.length >= 4 && "N".equals(additionalParams[3])) {
			intgrnServiceRequest.setExcepReqd(false);
		}

		logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "mapIntegrationRequest - end");
		return intgrnServiceRequest;
	}

	/**
	 * This method is use to call BRE Integration Service. To call this method need
	 * to prepare breIntServiceRequest object with required details.
	 * 
	 * @param intServiceRequest
	 * @return resObj
	 */
	public Object callIntegrationServiceLayer(IntgrnServiceRequest intServiceRequest) {

		logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "Inside callIntegrationServiceLayer()");
		Object resObj = new JSONObject();
		try {
			long startTime = System.currentTimeMillis();
			ResponseEntity<ResponseBean> response = makeServiceCall(intServiceRequest);
			long stopTime = System.currentTimeMillis();

			logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
					"\n\nCall to " + intServiceRequest.getIntgrnUrl() + " Service complete, Response-->" + response
							+ "<--Response ends here. time taken ==" + (stopTime - startTime));

			if (Objects.nonNull(intServiceRequest.getClassType()) && !intServiceRequest.getClassType().isArray()) {

				resObj = intServiceRequest.getClassType().newInstance();

			}
			if (Objects.nonNull(response) && HttpStatus.OK.equals(response.getStatusCode())
					&& Objects.nonNull(response.getBody().getPayload())) {
				JSONObject json = new JSONObject(response.getBody().getPayload().toString());
				Object payload = json.get(Constants.PAYLOAD);
				if (Objects.nonNull(payload)
						&& StatusCode.SUCCESS.toString().equals(json.get(Constants.JSON_KEY_STATUS))) {
					if (Objects.nonNull(intServiceRequest.getClassType())) {
						if(intServiceRequest.getClassType().isArray()) {
							resObj = serviceCallProcessor.getResponseObjectFromResponseJsonString(json.get(Constants.PAYLOAD).toString(),
									intServiceRequest.getClassType());
						} else {
						json = new JSONObject(payload.toString());
						resObj = serviceCallProcessor.getResponseObjectFromResponseJsonString(json.toString(),
								intServiceRequest.getClassType());
						}
					}
				} else {
					logger.error(CLASS_NAME, BFLLoggerComponent.REPOSITORY, intServiceRequest.getLogMsg());
					if (intServiceRequest.isExcepReqd()) {
						throw new BFLBusinessException(intServiceRequest.getErrorCode(),
								intServiceRequest.getErrorMsg());
					}
				}
			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.REPOSITORY, intServiceRequest.getLogMsg());
				if (intServiceRequest.isExcepReqd()) {
					throw new BFLBusinessException(intServiceRequest.getErrorCode(), intServiceRequest.getErrorMsg());
				}
			}
		} catch (InstantiationException | IllegalAccessException e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
					"Error occured while creating instance for " + intServiceRequest.getClassType() + "\n" + e);
			throw new BFLBusinessException(intServiceRequest.getErrorCode(), intServiceRequest.getErrorMsg());
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "Exit from callIntegrationServiceLayer()");
		return resObj;
	}

	private ResponseEntity<ResponseBean> makeServiceCall(IntgrnServiceRequest intServiceRequest) {
		Timestamp requestTimestamp = null;
		Timestamp responceTimestamp = null;
		ResponseEntity<ResponseBean> response = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		String requestJson = serviceCallProcessor.prepareRequestJsonForServiceCall(intServiceRequest.getReqObject());

		logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
				"\n\nCalling " + intServiceRequest.getIntgrnUrl() + " Service with requestJson-->" + requestJson);

		// if reqType is not set then default reqType is GET
		HttpMethod requestType = intServiceRequest.getReqType();
		logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "request Type::" + requestType);
		if (HttpMethod.POST.equals(requestType)) {
			requestTimestamp = new Timestamp(Calendar.getInstance().getTime().getTime());
			response = postServiceCall(intServiceRequest, headers, requestJson);
			responceTimestamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		} else if (HttpMethod.PUT.equals(requestType)) {
			requestTimestamp = new Timestamp(Calendar.getInstance().getTime().getTime());
			response = putServiceCall(intServiceRequest, headers, requestJson);
			responceTimestamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		} else if (HttpMethod.GET.equals(requestType)) {
			requestTimestamp = new Timestamp(Calendar.getInstance().getTime().getTime());
			response = getServiceCall(intServiceRequest, headers, requestJson);
			responceTimestamp = new Timestamp(Calendar.getInstance().getTime().getTime());
		}

		// ************************************<START>DynamoDB****************************************************//

		saveRequestAndResponseInDynamoDb(intServiceRequest, response, requestTimestamp, responceTimestamp);

		// ************************************<END>DynamoDB****************************************************//

		return response;
	}

	private void saveRequestAndResponseInDynamoDb(IntgrnServiceRequest intServiceRequest,
			ResponseEntity<ResponseBean> response, Timestamp requestTimestamp, Timestamp responceTimestamp) {
		Object resObj = null;
		logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "Start== saveRequestAndResponseInDynamoDb");
		// dynamoDbSource is the indicator for dynamoDb to store data in respective
		// table,So we are checking dynamoDbSource is not blank.
		if (!StringUtils.isEmpty(intServiceRequest.getDynamoDBSource())) {
			Map<String, String> pathParamMap = intServiceRequest.getPathParamMap();
			// based on application Id will find the actual record,So we are checking
			// application Id is not blank.
			if (Objects.nonNull(pathParamMap) && !StringUtils.isEmpty(pathParamMap.get(Constants.APPLICATION_ID))) {
				if (null != response) {
					resObj = null != response.getBody().getPayload() ? response.getBody().getPayload().toString()
							: null;
				}
				// call persistExternalServiceResponse method to generate metadataBean.
				persistExternalServiceResponse(resObj, pathParamMap.get(Constants.APPLICATION_ID), intServiceRequest,
						requestTimestamp, responceTimestamp);

			} else {
				logger.error(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
						"============Unable to persist data in dynamo db , Application Id is null============");
			}
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "Exit== saveRequestAndResponseInDynamoDb");
	}

	/**
	 * @author 687122 This method is use to invoke get request endpoint.
	 * @param serviceCallRequest
	 * @param headers
	 * @param requestJson
	 * @return response
	 */
	private ResponseEntity<ResponseBean> getServiceCall(IntgrnServiceRequest serviceCallRequest, HttpHeaders headers,
			String requestJson) {
		ResponseEntity<ResponseBean> response;
		if (serviceCallRequest.getPathParamMap().isEmpty()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "Inside getServiceCall Without Path Param Request");
			response = BFLCommonRestClient.get(serviceCallRequest.getIntgrnUrl(), null, String.class, null, requestJson,
					headers); // serviceCallRequest.getServiceCallReqUrl()
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "Inside getServiceCall With Path Param Request");
			Map<String, String> params = serviceCallRequest.getPathParamMap();
			response = BFLCommonRestClient.get(serviceCallRequest.getIntgrnUrl(), null, String.class, params,
					requestJson, headers);
		}
		return response;
	}

	/**
	 * @author 687122 This method is use to invoke post request endpoint.
	 * @param serviceCallRequest
	 * @param headers
	 * @param requestJson
	 * @return response
	 */
	private ResponseEntity<ResponseBean> postServiceCall(IntgrnServiceRequest serviceCallRequest, HttpHeaders headers,
			String requestJson) {
		ResponseEntity<ResponseBean> response;
		if (serviceCallRequest.getPathParamMap().isEmpty()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
					"Inside postServiceCall Without Path Param Request");
			response = BFLCommonRestClient.create(serviceCallRequest.getIntgrnUrl(), null, String.class, null,
					requestJson, headers);
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "Inside postServiceCall With Path Param Request");
			Map<String, String> params = serviceCallRequest.getPathParamMap();
			response = BFLCommonRestClient.create(serviceCallRequest.getIntgrnUrl(), null, String.class, params,
					requestJson, headers);
		}
		return response;
	}

	/**
	 * @author 687122 This method is use to invoke post request endpoint.
	 * @param serviceCallRequest
	 * @param headers
	 * @param requestJson
	 * @return response
	 */
	private ResponseEntity<ResponseBean> putServiceCall(IntgrnServiceRequest serviceCallRequest, HttpHeaders headers,
			String requestJson) {
		ResponseEntity<ResponseBean> response;

		if (serviceCallRequest.getPathParamMap().isEmpty()) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
					"Inside postServiceCall Without Path Param Request");
			response = BFLCommonRestClient.update(serviceCallRequest.getIntgrnUrl(), null, String.class, null,
					requestJson, headers);
		} else {
			logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "Inside postServiceCall With Path Param Request");
			Map<String, String> params = serviceCallRequest.getPathParamMap();
			response = BFLCommonRestClient.update(serviceCallRequest.getIntgrnUrl(), null, String.class, params,
					requestJson, headers);
		}
		return response;
	}

	/**
	 * This Utility method will log/save all external service response in Dynamo db
	 * table.
	 * 
	 * @author 686009
	 * @param responseBeanClassType
	 * @param applicationId
	 * @param requestObject
	 * @param responceTimestamp
	 * @param requestTimestamp
	 * @param requestSaveTableName
	 */
	private void persistExternalServiceResponse(Object responceObject, String applicationId,
			IntgrnServiceRequest intServiceRequest, Timestamp requestTimestamp, Timestamp responceTimestamp) {
		logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
				"Inside persistExternalServiceResponse() for application- " + applicationId);
		try {

			String requestJson = serviceCallProcessor
					.prepareRequestJsonForServiceCall(intServiceRequest.getReqObject());
			logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
					"External Service Response Json ::" + responceObject);
			MetadataBean metadataBean = new MetadataBean(Constants.DYNAMO_DB_TABLE_NAME_TO_SAVE_BALIC_RESPONSE);

			metadataBean.setRequestPayload(requestJson);
			metadataBean.setRequestTimestamp(requestTimestamp);

			metadataBean.setResponsePayload(responceObject);
			metadataBean.setResponseTimestamp(responceTimestamp);

			metadataBean.setSource(intServiceRequest.getDynamoDBSource());
			metadataBean.setSourcetype(intServiceRequest.getDynamoDBSourceType());

			metadataBean.setApplicationId(applicationId);
			persistUnstructuredData(metadataBean, null);
		} catch (BFLTechnicalException bte) {
			logger.error(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
					"Error Code::" + bte.getCode() + "::Error Message::" + bte.getMessage() + "::Error" + bte);
		}
		logger.debug(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
				"Exit from persistExternalServiceResponse() for application- " + applicationId);
	}

	private void persistUnstructuredData(MetadataBean metadataBean, String correlationId) {
		try {
			// Persist unstructured data
			logger.info(CLASS_NAME, BFLLoggerComponent.REPOSITORY, "Persist unstructured data.....");
			ResponseEntity<ResponseBean> resp = BFLCommonRestClient.persistUnstructureData(metadataBean, correlationId);
			logger.info(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
					"Response from Persist unstructured data - dynamoDb....." + resp);
		} catch (Exception e) {
			logger.error(CLASS_NAME, BFLLoggerComponent.REPOSITORY,
					"Exception while persisting Unstructured Data : " + e);
			throw new BFLTechnicalException("INS-10314", env.getProperty("INS-10314"));
		}
	}

}