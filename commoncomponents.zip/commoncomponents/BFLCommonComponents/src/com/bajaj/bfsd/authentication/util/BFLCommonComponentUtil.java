package com.bajaj.bfsd.authentication.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bfl.common.exceptions.BFLHttpException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class BFLCommonComponentUtil {

	private static final String CLASSNAME = BFLServiceCallProcessorUtil.class.getName();
	
	private static Map<String,String> finalFlatMap;
	
	private static Map<String,Set<Object>> finalFlatMapList;

	private BFLCommonComponentUtil()
	{
		//private Constructor
	}

	public static String mapToJson(Object obj) {
		if(null==obj)
		{
			BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "object to be mapped is null");
			return null;
		}
		String retVal = null;
		try{
		ObjectMapper mapper = MapperFactory.getInstance();
		retVal= mapper.writeValueAsString(obj);
		}catch(Exception e)
		{
			BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "Unable to Map Object" + e);
			BFLLoggerUtil.error(null, CLASSNAME, BFLLoggerComponent.UTILITY, "Unable to Map Object" + e.getMessage());
		}
		return retVal;
	}
	
	public static Map<String,Set<Object>> getFlatMapKeyObjectList(Object object) 
	{
		if(null==object)
		{
			BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "object to be mapped is null");
			return null;
		}
		try{
		String jsonString = mapToJson(object);
		JSONObject jsonObject = new JSONObject(jsonString);
        Set<String> jsonKeys = jsonObject.keySet();
        if(null!=jsonKeys && !jsonKeys.isEmpty())
        {
			BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "jsonKeys not null or empty");
        	processJsonToListMap(jsonObject, jsonKeys);
        }
		}catch(Exception e)
		{
			BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occured while getAllFlatMapKeyObjectList :" + e);
			BFLLoggerUtil.error(null, CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occured while getAllFlatMapKeyObjectList :" + e.getMessage());
		}
		
		return finalFlatMapList;
	}

	private static void processJsonToListMap(JSONObject jsonObject, Set<String> jsonKeys) {
		BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "inside processJsonToListMap");
		finalFlatMapList = new HashMap<>();
		for (String key : jsonKeys) {
		    Object val = jsonObject.get(key);
		    if (val instanceof JSONArray) {
		        JSONArray array = (JSONArray) val;
		        jsonArrayForList(array, key);

		    } else if (val instanceof JSONObject) {
		        JSONObject jsonOb = (JSONObject) val;
		        jsonObjForList(jsonOb, key);
		    } else {
		    	putToListMap(key, val.toString());
		    }
		}
	}
	
	public static Map<String,String> getAllFlatMapKeyValue(Object object) 
	{
		BFLLoggerUtil.info(null, CLASSNAME, BFLLoggerComponent.UTILITY, "inside getAllFlatMapKeyValue");
		try{
		String jsonString = mapToJson(object);
		JSONObject jsonObject = new JSONObject(jsonString);
        Set<String> jsonKeys = jsonObject.keySet();
        if(null!=jsonKeys && !jsonKeys.isEmpty())
        {
           BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "jsonKeys not null or empty");
	       processJsonToMap(jsonObject, jsonKeys);
        }
		}catch(Exception e)
		{
			BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occured while getAllFlatMapKeyValue :" + e);
			BFLLoggerUtil.error(null, CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occured while getAllFlatMapKeyValue :" + e.getMessage());
		}
		
		return finalFlatMap;
	}

	private static void processJsonToMap(JSONObject jsonObject, Set<String> jsonKeys) {
		BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "inside processJsonToMap");
		finalFlatMap = new HashMap<>();
		for (String key : jsonKeys) {
		    Object val = jsonObject.get(key);
		    if (val instanceof JSONArray) {
		        JSONArray array = (JSONArray) val;
		        jsonArray(array, key);

		    } else if (val instanceof JSONObject) {
		        JSONObject jsonOb = (JSONObject) val;
		        jsonObj(jsonOb, key);
		    } else {
		    	finalFlatMap.put(key, val.toString());
		    }
		}
	}
	private static void jsonObj(JSONObject object, String key2) {
		BFLLoggerUtil.info(null, CLASSNAME, BFLLoggerComponent.UTILITY, "inside jsonObj");
	    Set<String> innerKeys = object.keySet();
	    for (String key : innerKeys) {
	        Object val = object.get(key);
	        if (val instanceof JSONArray) {
	            JSONArray array = (JSONArray) val;
	            jsonArray(array,key);
	        } else if (val instanceof JSONObject) {
	            JSONObject jsonOb = (JSONObject) val;
	            jsonObj(jsonOb, key2 + "->" + key);
	        } else {
	        	
	        	finalFlatMap.put(key, val.toString());
	        }
	    }
	}
	
	private static void jsonArray(JSONArray array, String key) {
		BFLLoggerUtil.info(null, CLASSNAME, BFLLoggerComponent.UTILITY, "inside jsonArray");
	    if (array.length() == 0) {
	    	finalFlatMap.put(key,"");
	    } else {
	        for (int i = 0; i < array.length(); i++) {
	            Object jObject = array.get(i);
	            if (jObject instanceof JSONObject) {
	                JSONObject job = (JSONObject) jObject;
	                jsonObj(job, key);
	            }
	        }
	    }
	}
	
	
	
	
	private static void jsonObjForList(JSONObject object, String key2) {
	    Set<String> innerKeys = object.keySet();
	    for (String key : innerKeys) {
	        Object val = object.get(key);
	        if (val instanceof JSONArray) {
	            JSONArray array = (JSONArray) val;
	            jsonArrayForList(array,key);
	        } else if (val instanceof JSONObject) {
	            JSONObject jsonOb = (JSONObject) val;
	            jsonObjForList(jsonOb, key2 + "->" + key);
	        } else {
	        	
	        	putToListMap(key, val.toString());
	        }
	    }
	}
	
	private static void jsonArrayForList(JSONArray array, String key) {
	    if (array.length() == 0) {
	    	putToListMap(key,"");
	    } else {
	        for (int i = 0; i < array.length(); i++) {
	            Object jObject = array.get(i);
	            if (jObject instanceof JSONObject) {
	                JSONObject job = (JSONObject) jObject;
	                jsonObjForList(job, key);
	            }
	        }
	    }
	}
	
	
	private static void putToListMap(String key, Object value){
		if(finalFlatMapList.containsKey(key)){
			finalFlatMapList.get(key).add(value);
		}else{
			Set<Object> paramValueList = new HashSet<>();
			paramValueList.add(value);
			finalFlatMapList.put(key,paramValueList); 
		}
	}

	public static Map<String, List<Object>> getFirstLevelParamMapForInstance(Object obj) { 
		Map<String, List<Object>> mapAttributeObj = null;
		try{
		Class<?> objClass = obj.getClass(); 
		Field[] fields = objClass.getDeclaredFields(); 
		mapAttributeObj = new HashMap<>(); 
		for (Field field : fields) { 
		field.setAccessible(true); 
		if(mapAttributeObj.containsKey(field.getName())){
			mapAttributeObj.get(field.getName()).add(field.get(obj));
		}else{
			List<Object> paramValueList = new ArrayList<>();
			paramValueList.add(field.get(obj));
			mapAttributeObj.put(field.getName(),paramValueList); 
		}
		} 
		}catch(Exception e)
		{
			BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occured while getFirstLevelParamMapForInstance :" + e);
			BFLLoggerUtil.error(null, CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occured while getFirstLevelParamMapForInstance :" + e.getMessage());
		}
		return mapAttributeObj; 
	} 
	
	/**
	 * Converts a list of Object to Long ignoring 0L
	 * @param objects
	 * @return
	 */
	public static List<Long> getListofLong(Set<Object> objects)
	{
		if (null == objects || objects.isEmpty()) {
			return null;
		}
		List<Long> longList = new ArrayList<>();
		for (Object obj : objects) {
			try {
				if (null != obj && !String.valueOf(obj).isEmpty() && !"null".equals(String.valueOf(obj))
						&& Long.valueOf(String.valueOf(obj).trim())>0) {
					longList.add(Long.valueOf(String.valueOf(obj)));
				}
			} catch (Exception e) {
				BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY,
						"Exception occured while getListofLong :" + e);
				BFLLoggerUtil.error(null, CLASSNAME, BFLLoggerComponent.UTILITY,
						"Exception occured while getListofLong :" + e.getMessage());
			}
		}
		if (!longList.isEmpty()) {
			return longList;
		}
		return null;
	}
	
	
	public static List<String> getListofString(Set<Object> objects)
	{
		
		if(null==objects || objects.isEmpty())
		{
			return null; 
		}
		
		List<String>  stringList = new ArrayList<>();
		for(Object obj:objects){
			try{
				if(null != obj) {
					String strParamvalue = String.valueOf(obj);
					if(strParamvalue!=null && !strParamvalue.isEmpty() && !"null".equals(String.valueOf(obj))){
						stringList.add(strParamvalue);
					}
				}
			
			}catch(Exception e)
			{
				BFLLoggerUtil.debug(null, CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occured while getListofString :" + e);
				BFLLoggerUtil.error(null, CLASSNAME, BFLLoggerComponent.UTILITY, "Exception occured while getListofString :" + e.getMessage());
			}
		}
		
		if(!stringList.isEmpty())
		{
			return stringList; 
		}
		return null; 
	}
	
	public static void validateProcessIdForTampering(String action, String nextTaskKey, List<String> allowedKeys) {
		if ("resume".equals(action) && !allowedKeys.contains(nextTaskKey)) {
			throw new BFLHttpException(HttpStatus.UNAUTHORIZED, "FA-401", "Process id has been tampered");
		}
	}
}