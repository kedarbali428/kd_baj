package com.bajaj.bfsd.loanaccount.model;

import java.util.Date;

public class Fee {

	private String feeCategory;

	private String feeCode;
	
	private Number feeAmount;
	
	private Number waiverAmount;
	
	private Number paidAmount;
	
	private String feeMethod;
	
	private Integer scheduleTerms;
	
	private Number paymentID;

	private Number feeBalance;
	
	private Date schdDate;
	
	public Date getSchdDate() {
		return schdDate;
	}

	public void setSchdDate(Date schdDate) {
		this.schdDate = schdDate;
	}

	public String getFeeCategory() {
		return feeCategory;
	}

	public void setFeeCategory(String feeCategory) {
		this.feeCategory = feeCategory;
	}

	public Number getFeeBalance() {
		return feeBalance;
	}

	public void setFeeBalance(Number feeBalance) {
		this.feeBalance = feeBalance;
	}

	public String getFeeCode() {
		return feeCode;
	}

	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}

	public Number getFeeAmount() {
		return feeAmount;
	}

	public void setFeeAmount(Number feeAmount) {
		this.feeAmount = feeAmount;
	}

	public Number getWaiverAmount() {
		return waiverAmount;
	}

	public void setWaiverAmount(Number waiverAmount) {
		this.waiverAmount = waiverAmount;
	}

	public Number getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(Number paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getFeeMethod() {
		return feeMethod;
	}

	public void setFeeMethod(String feeMethod) {
		this.feeMethod = feeMethod;
	}

	public Integer getScheduleTerms() {
		return scheduleTerms;
	}

	public void setScheduleTerms(Integer scheduleTerms) {
		this.scheduleTerms = scheduleTerms;
	}

	public Number getPaymentID() {
		return paymentID;
	}

	public void setPaymentID(Number paymentID) {
		this.paymentID = paymentID;
	}

	@Override
	public String toString() {
		return "Fee [feeCategory=" + feeCategory + ", feeCode=" + feeCode + ", feeAmount=" + feeAmount
				+ ", waiverAmount=" + waiverAmount + ", paidAmount=" + paidAmount + ", feeMethod=" + feeMethod
				+ ", scheduleTerms=" + scheduleTerms + ", paymentID=" + paymentID + ", feeBalance=" + feeBalance + "]";
	}

}
