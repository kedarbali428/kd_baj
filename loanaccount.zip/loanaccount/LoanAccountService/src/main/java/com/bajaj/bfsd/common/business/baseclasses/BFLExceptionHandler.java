package com.bajaj.bfsd.common.business.baseclasses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bfl.common.exceptions.BFLBusinessException;
import com.bfl.common.exceptions.BFLHttpException;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.bfl.common.util.BFLExceptionUtil;

@RefreshScope
@ControllerAdvice
public class BFLExceptionHandler extends ResponseEntityExceptionHandler {

	private static final String CLASS_NAME = BFLExceptionHandler.class.getName();

	@Autowired
	Environment env;

	@Autowired
	BFLLoggerUtilExt bfllogger;

	/**
	 * @param exception
	 * @param request
	 * @return ResponseEntity<ResponseBean>
	 */
	@ExceptionHandler(value = { BFLHttpException.class, BFLTechnicalException.class, BFLBusinessException.class, RuntimeException.class,
			Exception.class })
	public ResponseEntity<ResponseBean> handleConflict(Exception ex, WebRequest request) {
		ResponseBean responseBean = BFLExceptionUtil.handle(ex, env);
		if (ex instanceof BFLHttpException) {
			return new ResponseEntity<>(responseBean, ((BFLHttpException) ex).getStatusCode());
		} else if (ex instanceof BFLBusinessException) {
			return new ResponseEntity<>(responseBean, HttpStatus.OK);
		} else if (ex instanceof BFLTechnicalException) {
			return new ResponseEntity<>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			bfllogger.error(CLASS_NAME, BFLLoggerComponent.CONTROLLER,
					"in handleConflict() method - " + env.getProperty("BFSD-500"), ex);
			return new ResponseEntity<>(responseBean, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
