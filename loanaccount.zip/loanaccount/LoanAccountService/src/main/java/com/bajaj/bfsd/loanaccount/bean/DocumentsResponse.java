package com.bajaj.bfsd.loanaccount.bean;

import java.util.List;

public class DocumentsResponse {

	private List<DownloadDocumentBean> downloads;

	private List<String> documentsList;

	public List<String> getDocumentsList() {
		return documentsList;
	}

	public void setDocumentsList(List<String> documentsList) {
		this.documentsList = documentsList;
	}

	public List<DownloadDocumentBean> getDownloads() {
		return downloads;
	}

	public void setDownloads(List<DownloadDocumentBean> downloads) {
		this.downloads = downloads;
	}
	
}
