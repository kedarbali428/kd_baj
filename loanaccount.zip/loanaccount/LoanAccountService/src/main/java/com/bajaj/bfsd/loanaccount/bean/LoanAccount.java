/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.loanaccount.bean;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * This is bean class for Loan account details.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602       	17/02/2017      Initial Version
 */
@JsonInclude(Include.NON_NULL)
public class LoanAccount implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -4388111105602625138L;

    /**
     * Variable to hold value for loan acct number.
     */
    private String loanAcctNumber;
    
    /**
     * Variable to hold value for loan amount.
     */
    private BigDecimal loanAmount;
    
    /**
     * Variable to hold value for paid amount.
     */
    private BigDecimal paidAmount;
    
    /**
     * Variable to hold value for outstanding amount.
     */
    private BigDecimal outstandingAmount;
    /**
     * Variable to hold value for roi.
     */
    private BigDecimal roi;
    
    /**
     * Variable to hold value for emi amount.
     */
    private BigDecimal emiAmount;
    
    /**
     * Variable to hold value for remaining tenure.
     */
    private BigDecimal remainingTenure;
    
    /**
     * Variable to hold value for total tenure.
     */
    private BigDecimal totalTenure;
    
    /**
     * Variable to hold value for emi paid count.
     */
    private BigDecimal emiPaidCount;
    
    /**
     * Variable to hold value for total emi count.
     */
    private BigDecimal totalEmiCount;
    
    /**
     * Variable to hold value for coapplicant name.
     */
    private String coapplicantName;
    
    /**
     * Variable to hold value for loan product.
     */
    private String loanProduct;
    /**
     * Variable to hold value for loan product type.
     */
    private String loanProductType;

    /**
     * Variable to hold value for linked acct numbers.
     */
    private List<LoanAccount> linkedAcctNumbers;
    
    /**
     * Variable to hold value for menu list.
     */
    private List<String> menuList;
    
    /**
     * Getter method for loan acct number.
     *
     * @return loan acct number
     */
    public String getLoanAcctNumber() {
        return loanAcctNumber;
    }
    
    /**
     * Sets the value of loan acct number.
     *
     * @param loanAcctNumber the new loan acct number
     */
    public void setLoanAcctNumber(String loanAcctNumber) {
        this.loanAcctNumber = loanAcctNumber;
    }
    
    /**
     * Getter method for loan amount.
     *
     * @return loan amount
     */
    public BigDecimal getLoanAmount() {
        return loanAmount;
    }
    
    /**
     * Sets the value of loan amount.
     *
     * @param loanAmount the new loan amount
     */
    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }
    
    /**
     * Getter method for paid amount.
     *
     * @return paid amount
     */
    public BigDecimal getPaidAmount() {
        return paidAmount;
    }

    /**
     * Sets the value of paid amount.
     *
     * @param paidAmount the new paid amount
     */
    public void setPaidAmount(BigDecimal paidAmount) {
        this.paidAmount = paidAmount;
    }

    /**
     * Getter method for outstanding amount.
     *
     * @return outstanding amount
     */
    public BigDecimal getOutstandingAmount() {
        return outstandingAmount;
    }

    /**
     * Sets the value of outstanding amount.
     *
     * @param outstandingAmount the new outstanding amount
     */
    public void setOutstandingAmount(BigDecimal outstandingAmount) {
        this.outstandingAmount = outstandingAmount;
    }

    /**
     * Getter method for roi.
     *
     * @return roi
     */
    public BigDecimal getRoi() {
        return roi;
    }
    
    /**
     * Sets the value of roi.
     *
     * @param roi the new roi
     */
    public void setRoi(BigDecimal roi) {
        this.roi = roi;
    }
    
    /**
     * Getter method for emi amount.
     *
     * @return emi amount
     */
    public BigDecimal getEmiAmount() {
        return emiAmount;
    }
    
    /**
     * Sets the value of emi amount.
     *
     * @param emiAmount the new emi amount
     */
    public void setEmiAmount(BigDecimal emiAmount) {
        this.emiAmount = emiAmount;
    }
    
    /**
     * Getter method for remaining tenure.
     *
     * @return remaining tenure
     */
    public BigDecimal getRemainingTenure() {
        return remainingTenure;
    }
    
    /**
     * Sets the value of remaining tenure.
     *
     * @param remainingTenure the new remaining tenure
     */
    public void setRemainingTenure(BigDecimal remainingTenure) {
        this.remainingTenure = remainingTenure;
    }
    
    /**
     * Getter method for total tenure.
     *
     * @return total tenure
     */
    public BigDecimal getTotalTenure() {
        return totalTenure;
    }
    
    /**
     * Sets the value of total tenure.
     *
     * @param totalTenure the new total tenure
     */
    public void setTotalTenure(BigDecimal totalTenure) {
        this.totalTenure = totalTenure;
    }
    
    /**
     * Getter method for emi paid count.
     *
     * @return emi paid count
     */
    public BigDecimal getEmiPaidCount() {
        return emiPaidCount;
    }
    
    /**
     * Sets the value of emi paid count.
     *
     * @param emiPaidCount the new emi paid count
     */
    public void setEmiPaidCount(BigDecimal emiPaidCount) {
        this.emiPaidCount = emiPaidCount;
    }
    
    /**
     * Getter method for total emi count.
     *
     * @return total emi count
     */
    public BigDecimal getTotalEmiCount() {
        return totalEmiCount;
    }
    
    /**
     * Sets the value of total emi count.
     *
     * @param totalEmiCount the new total emi count
     */
    public void setTotalEmiCount(BigDecimal totalEmiCount) {
        this.totalEmiCount = totalEmiCount;
    }
    
    /**
     * Getter method for coapplicant name.
     *
     * @return coapplicant name
     */
    public String getCoapplicantName() {
        return coapplicantName;
    }
    
    /**
     * Sets the value of coapplicant name.
     *
     * @param coapplicantName the new coapplicant name
     */
    public void setCoapplicantName(String coapplicantName) {
        this.coapplicantName = coapplicantName;
    }
    
    /**
     * Getter method for loan product.
     *
     * @return loan product
     */
    public String getLoanProduct() {
        return loanProduct;
    }

    /**
     * Sets the value of loan product.
     *
     * @param loanProduct the new loan product
     */
    public void setLoanProduct(String loanProduct) {
        this.loanProduct = loanProduct;
    }

    /**
     * Getter method for loan type.
     *
     * @return loan type
     */
    public String getLoanProductType() {
        return loanProductType;
    }
    
    /**
     * Sets the value of loan type.
     *
     * @param loanProductType the new loan type
     */
    public void setLoanProductType(String loanProductType) {
        this.loanProductType = loanProductType;
    }
    
    /**
     * Getter method for linked acct numbers.
     *
     * @return linked acct numbers
     */
    public List<LoanAccount> getLinkedAcctNumbers() {
        return linkedAcctNumbers;
    }
    
    /**
     * Sets the value of linked acct numbers.
     *
     * @param linkedAcctNumbers the new linked acct numbers
     */
    public void setLinkedAcctNumbers(List<LoanAccount> linkedAcctNumbers) {
        this.linkedAcctNumbers = linkedAcctNumbers;
    }
    
    /**
     * Getter method for menu list.
     *
     * @return menu list
     */
    public List<String> getMenuList() {
        return menuList;
    }
    
    /**
     * Sets the value of menu list.
     *
     * @param menuList the new menu list
     */
    public void setMenuList(List<String> menuList) {
        this.menuList = menuList;
    }
}
