package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the INS_PREMIUM_PAY_METHODS database table.
 * 
 */
@Entity
@Table(name="INS_PREMIUM_PAY_METHODS")
@NamedQuery(name="InsPremiumPayMethod.findAll", query="SELECT i FROM InsPremiumPayMethod i")
public class InsPremiumPayMethod implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long inspremiumpaymethodkey;

	private String ippmcode;

	private BigDecimal ippmisactive;

	private String ippmlstupdateby;

	private Timestamp ippmlstupdatedt;

	//bi-directional many-to-one association to InsuranceApplication
	@OneToMany(mappedBy="insPremiumPayMethod")
	private List<InsuranceApplication> insuranceApplications;

	//bi-directional many-to-one association to InsProductCategory
	@ManyToOne
	@JoinColumn(name="INSPRODCATKEY")
	private InsProductCategory insProductCategory;

	public InsPremiumPayMethod() {
	}

	public long getInspremiumpaymethodkey() {
		return this.inspremiumpaymethodkey;
	}

	public void setInspremiumpaymethodkey(long inspremiumpaymethodkey) {
		this.inspremiumpaymethodkey = inspremiumpaymethodkey;
	}

	public String getIppmcode() {
		return this.ippmcode;
	}

	public void setIppmcode(String ippmcode) {
		this.ippmcode = ippmcode;
	}

	public BigDecimal getIppmisactive() {
		return this.ippmisactive;
	}

	public void setIppmisactive(BigDecimal ippmisactive) {
		this.ippmisactive = ippmisactive;
	}

	public String getIppmlstupdateby() {
		return this.ippmlstupdateby;
	}

	public void setIppmlstupdateby(String ippmlstupdateby) {
		this.ippmlstupdateby = ippmlstupdateby;
	}

	public Timestamp getIppmlstupdatedt() {
		return this.ippmlstupdatedt;
	}

	public void setIppmlstupdatedt(Timestamp ippmlstupdatedt) {
		this.ippmlstupdatedt = ippmlstupdatedt;
	}

	public List<InsuranceApplication> getInsuranceApplications() {
		return this.insuranceApplications;
	}

	public void setInsuranceApplications(List<InsuranceApplication> insuranceApplications) {
		this.insuranceApplications = insuranceApplications;
	}

	public InsuranceApplication addInsuranceApplication(InsuranceApplication insuranceApplication) {
		getInsuranceApplications().add(insuranceApplication);
		insuranceApplication.setInsPremiumPayMethod(this);

		return insuranceApplication;
	}

	public InsuranceApplication removeInsuranceApplication(InsuranceApplication insuranceApplication) {
		getInsuranceApplications().remove(insuranceApplication);
		insuranceApplication.setInsPremiumPayMethod(null);

		return insuranceApplication;
	}

	public InsProductCategory getInsProductCategory() {
		return this.insProductCategory;
	}

	public void setInsProductCategory(InsProductCategory insProductCategory) {
		this.insProductCategory = insProductCategory;
	}

}