package com.bajaj.bfsd.loanaccount.bean;

public class CifDetailsBean {
	
	private String apltCustCif;
	private String target;
	/**
	 * @return the apltCustCif
	 */
	public String getApltCustCif() {
		return apltCustCif;
	}
	/**
	 * @param apltCustCif the apltCustCif to set
	 */
	public void setApltCustCif(String apltCustCif) {
		this.apltCustCif = apltCustCif;
	}
	/**
	 * @return the target
	 */
	public String getTarget() {
		return target;
	}
	/**
	 * @param target the target to set
	 */
	public void setTarget(String target) {
		this.target = target;
	}
	

}
