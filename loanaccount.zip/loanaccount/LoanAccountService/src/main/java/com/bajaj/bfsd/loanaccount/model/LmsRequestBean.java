package com.bajaj.bfsd.loanaccount.model;

import java.util.Map;

public class LmsRequestBean {

	private Long applicationId;
	private Long applicantId;
	private Boolean insertNoSQL;
	private Boolean asyncRequired;
	private String httpMethod;
	private String productCode;
	private String requestPayload;
	private String source;
	private Map<String, String> params;
	/**
	 * Target (HFC/BFL)
	 */
	private String target;

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Long getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}

	public Boolean getInsertNoSQL() {
		return insertNoSQL;
	}

	public void setInsertNoSQL(Boolean insertNoSQL) {
		this.insertNoSQL = insertNoSQL;
	}

	public Boolean getAsyncRequired() {
		return asyncRequired;
	}

	public void setAsyncRequired(Boolean asyncRequired) {
		this.asyncRequired = asyncRequired;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getRequestPayload() {
		return requestPayload;
	}

	public void setRequestPayload(String requestPayload) {
		this.requestPayload = requestPayload;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Map<String, String> getParams() {
		return params;
	}

	public void setParams(Map<String, String> params) {
		this.params = params;
	}

	/**
	 * @return the target
	 */
	public String getTarget() {
		return target;
	}

	/**
	 * @param target the target to set
	 */
	public void setTarget(String target) {
		this.target = target;
	}
	
	

}
