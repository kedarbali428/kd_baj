package com.bajaj.bfsd.loanaccount.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.loanaccount.bean.DocumentsResponse;
import com.bajaj.bfsd.loanaccount.dao.DocumentsDao;
import com.bajaj.bfsd.loanaccount.service.DocumentsService;
import com.bajaj.bfsd.loanaccount.util.DocumentConstants;

/**
 * This is a service class for My Documents.
 *
 * @author 412398
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          412398       	27/02/2017      Initial Version
 */
@Service
public class DocumentsServiceImpl  extends BFLComponent  implements DocumentsService{

	@SuppressWarnings("unused")
	private static final String THIS_CLASS = DocumentsServiceImpl.class.getSimpleName();

	@Autowired
	DocumentsDao documentslDao;

	@Value("${docListMock}")
	private String isMocked;

    
	@Override
	public DocumentsResponse getDocuments(Long customerId) {
		DocumentsResponse documentsResponse;
		if("Y".equals(isMocked))
		{
			documentsResponse=getDummyDataForDocuments();
		}else{
			documentsResponse=documentslDao.getDocuments(customerId);
		}
		return documentsResponse;
	}

	private DocumentsResponse getDummyDataForDocuments() {
		DocumentsResponse documentsResponse= new DocumentsResponse();
		 List<String> documentList = new ArrayList<>();   	
    	 documentList.add(DocumentConstants.MENU_KYC_DOCUMENTS);
    	 documentList.add(DocumentConstants.MENU_LOAN_AGREEMENT);
    	 documentList.add(DocumentConstants.MENU_BANK_STATEMENT);
    	 documentList.add(DocumentConstants.MENU_ESIGNED_DOCUMENT);
		documentsResponse.setDocumentsList(documentList);
		return documentsResponse;
	}

}
