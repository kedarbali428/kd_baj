package com.bajaj.bfsd.loanaccount.helper;

import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.ADVEMILOAN;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.AMC_Charge;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.DIEVENT;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.FCEVENT;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.MEEVENT;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.MTLOAN;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.NEFT;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.PPEVENT;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.REDUCEPRINCIPAL;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.REDUCETENOR;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.TDEVENT;
import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.WDEVENT;

import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import javax.enterprise.context.RequestScoped;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.loanaccount.bean.CifDetailsBean;
import com.bajaj.bfsd.loanaccount.bean.DisbursementBean;
import com.bajaj.bfsd.loanaccount.bean.EMIHoliday;
import com.bajaj.bfsd.loanaccount.bean.FeeBean;
import com.bajaj.bfsd.loanaccount.bean.LmsRequestBean;
import com.bajaj.bfsd.loanaccount.bean.LoanAccountResponseBean;
import com.bajaj.bfsd.loanaccount.bean.LoanCollatoralResponseBean;
import com.bajaj.bfsd.loanaccount.bean.LoanCustomerRequestBean;
import com.bajaj.bfsd.loanaccount.bean.LoanDetailBean;
import com.bajaj.bfsd.loanaccount.bean.LoanDetailResponseBean;
import com.bajaj.bfsd.loanaccount.bean.MissedEMI;
import com.bajaj.bfsd.loanaccount.bean.MissedEMIDetailBean;
import com.bajaj.bfsd.loanaccount.bean.OverdueSummaryBean;
import com.bajaj.bfsd.loanaccount.config.MapperFactory;
import com.bajaj.bfsd.loanaccount.dao.ProductDao;
import com.bajaj.bfsd.loanaccount.model.CoApplicant;
import com.bajaj.bfsd.loanaccount.model.CustomerLoanResponse;
import com.bajaj.bfsd.loanaccount.model.Loan;
import com.bajaj.bfsd.loanaccount.model.LoanProductType;
import com.bajaj.bfsd.loanaccount.service.LoanAccountService;
import com.bajaj.bfsd.loanaccount.util.LoanAccountUtil;
import com.bfl.common.exceptions.BFLBusinessException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@RefreshScope
@Component
public class LoanDetailHelper extends BFLComponent {

	private static final String POST = "POST";

	private static final String GET = "GET";

	private static final String HFC = "HFC";

	@Value("${resource-path-pennant-loan-customer}")
	private String resourcePathValueGetLoanCustomer;
	
	@Value("${pennant-authorization}")
	private String authorizationKey;
	
	@Value("${matured_loan_status}")
	private String maturedLoanStatus;

	@Autowired
    private BFLLoggerUtilExt logger;
	
	@Value("${LimitMonth}")
    private Integer underlimit;
	
	@Value("${minimumPaidEMI}")
    private Integer minimumPaidEMI;
	
	@Value("${FreezePeriod}")
    private Integer freezeperiod;
	
	@Value("${LOAN_001}")
    private String errorCodeLOAN;
	
	@Value("${partpayment_loans}")
	private String ppLoans;
	
	@Value("${ppLoansDefaultRecalType}")
	private String ppLoansDefaultRecalType;
	
	
	@Value("${depositHFLoansDefaultRecalType}")
	private String depositHFLoansDefaultRecalType;
	
	
	@Value("${deposit_is_loans}")
	private String diLoans;
	
	@Value("${withdrawals_loans}")
	private String wdLoans;

	@Value("${hybrid_flexi_loans}")
	private String hfLoans;
	
	@Value("${tranche_loans}")
	private String tdLoans;
	
	@Value("${missedemi_loans}")
	private String meLoans;

	@Value("${foreclosure_loans}")
	private String fcLoans;
	
	@Value("${advemi_loans}")
	private String advemiLoans;
    
    @Autowired
    private AsyncClass asyncClass;
    
    @Autowired
    Environment env;
    
    @Autowired
    LoanAccountUtil loanAccountUtil;
    
    @Autowired
    ProductDao productDao;
    
	private static final String THIS_CLASS = LoanDetailHelper.class.getName();
	
	private static final String ACTIVELOANSTATUSFLAG = "A";
	
	public LoanAccountResponseBean getAllActiveLoansForCustomer(List<CifDetailsBean> cifDetailsBeanList, String type) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside getLoanDetailsForCustomer in helper");
		boolean pennantSuccess = false;
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		List<CustomerLoanResponse> loanResponses = new ArrayList<>();
		List<LoanDetailBean> loanDetailBeans = new ArrayList<>();
		if(null != cifDetailsBeanList && !cifDetailsBeanList.isEmpty()) {
			for(CifDetailsBean cifDetailsBean : cifDetailsBeanList) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "CIF no : "+cifDetailsBean.getApltCustCif());
				CustomerLoanResponse loanResponse = getLoanDetailsFromPennantLMS(cifDetailsBean);
				loanResponses.add(loanResponse);
			}
		} else {
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling CustomerId can not be null or empty.");
		    throw new BFLBusinessException("LOAN_01", "Customer id can not be null.");
		}
		List<String>  loanAcctNumbers = new ArrayList<>();
		for(CustomerLoanResponse loanResponse : loanResponses) {
			if(null!=loanResponse && "0000".equals(loanResponse.getReturnStatus().getReturnCode())){
				pennantSuccess = true;				
				List<Future<LoanDetailBean>> futures = new ArrayList<>();
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Loans size:" +loanResponse.getFinances().size());

				for(Loan loan : loanResponse.getFinances()) {
					LoanProductType loanType= productDao.getLoanTypeDesc(loan.getFinType());
					if(null != loanType){
						futures.add(asyncClass.getLoanDetailsByLanNo(loan,loanType,type));
					}
					loanAcctNumbers.add(loan.getFinReference());
				}
				for(Future<LoanDetailBean> future: futures) {
					try {
						while(!future.isDone()) {
							Thread.sleep(1);
						}
						loanDetailBeans.add(future.get());
					} catch(Exception e) {
						logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception while getting Loan Details By Lan No", e);
						throw new BFLBusinessException("LOAN_02", "Exception while getting Loan Details By Lan No from Pennant");
					}			
				}
				  //loanDetailList = prepareLMSResponse(loanResponse,type);
		  		} else if(null!=loanResponse && null!=loanResponse.getReturnStatus() 
		  				&& null!=loanResponse.getReturnStatus().getReturnCode() 
		  				&& null!=loanResponse.getReturnStatus().getReturnText() && !pennantSuccess){
		  			loanAccountResponseBean= new LoanAccountResponseBean();
		  			loanAccountResponseBean.setReturnCode(loanResponse.getReturnStatus().getReturnCode());
		  			loanAccountResponseBean.setReturnText(loanResponse.getReturnStatus().getReturnText());
					logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error Code and Message ::"+loanResponse.getReturnStatus().getReturnCode()+loanResponse.getReturnStatus().getReturnText());
		  		} 
		}
		
		if(!pennantSuccess) {
  			loanAccountResponseBean= new LoanAccountResponseBean();
  			loanAccountResponseBean.setReturnText("No data returned from Pennant");
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "No data returned from Pennant");

  		}
		Double totalLoanAmount = 0.0;
		Double totalOutstandingAmount = 0.0;
		Double totalEmiAmount=0.0;
		for(LoanDetailBean loanDetailBean : loanDetailBeans) {
			totalLoanAmount = totalLoanAmount +loanDetailBean.getLoanISAmount().doubleValue();
			totalOutstandingAmount = totalOutstandingAmount + loanDetailBean.getOutstandingLoanAmount().doubleValue();
			if(null!=loanDetailBean.getEmiAmount()) {
				totalEmiAmount = totalEmiAmount + loanDetailBean.getEmiAmount().doubleValue();
			}
		}
		
		loanAccountResponseBean.setTotalLoanAmount(totalLoanAmount);
		loanAccountResponseBean.setTotalOutstandingAmount(totalOutstandingAmount);
		loanAccountResponseBean.setTotalEmiAmount(totalEmiAmount);
		loanAccountResponseBean.setLoanAcctNumbers(loanAcctNumbers);
		loanAccountResponseBean.setLoanDetails(loanDetailBeans);	
		
		return loanAccountResponseBean;
	}
	
	public LoanAccountResponseBean prepareLMSResponse(LoanAccountResponseBean loanDetailsBean,String type) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "calling inside prepareLMSResponse()::"+"type ::"+type);
		if(null!=type && null!=loanDetailsBean){
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "inside second if end prepareLMSResponse" +loanDetailsBean);
			loanDetailsBean = getLoanDetailsForParticualarLoan(loanDetailsBean,type);
			loanDetailsBean.setEventType(type);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "inside exit second if end prepareLMSResponse" +loanDetailsBean);
		}else{
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "inside second if end prepareLMSResponse" +loanDetailsBean);
			type=null;
			loanDetailsBean = getLoanDetailsForParticualarLoan(loanDetailsBean,type);
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "final inside end prepareLMSResponse" +loanDetailsBean);
		return loanDetailsBean;
	}
	
	private LoanAccountResponseBean getLoanDetailsForParticualarLoan(LoanAccountResponseBean loanDetailsBean, String type) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside getLoanDetailsForParticualarLoan()");
		if(PPEVENT.equals(type))
		{
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside PP getLoanDetailsForParticualarLoan()"+type);
			return getLoanDetailsForPartPayment(loanDetailsBean);
		}else if(FCEVENT.equals(type))
		{
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside FC getLoanDetailsForParticualarLoan()"+type);
			return getLoanDetailsForForeClosure(loanDetailsBean);
		}
		else if(DIEVENT.equals(type))
		{
			return getLoanDetailsForDepositInterestServicing(loanDetailsBean);
		}else if(WDEVENT.equals(type)) {
			return getLoanDetailsForWithdrawal(loanDetailsBean,type);
		}else if(TDEVENT.equals(type)){
			return getLoanDetailsForTranchWithdrawal(loanDetailsBean);
		}else if(MEEVENT.equals(type))
		{
			return getLoanDetailsForMissedEMIPayment(loanDetailsBean);
		}else if(MTLOAN.equals(type))
		{
			return getAllMaturedLoanDetails(loanDetailsBean);
		}else if(ADVEMILOAN.equals(type))
		{
			return getAllAdvanceEMILoanDetails(loanDetailsBean);
		}else if(null==type || !StringUtils.isNotBlank(type))
		{
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "before call getAllActiveLoans() type"+type);
			return getAllActiveLoans(loanDetailsBean);
		}else{
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Exception thorwn getLaonDetailsForCustomer in helper, Invalid value for Type.");
				throw new BFLBusinessException("LOAN_001",errorCodeLOAN);
		}
	}

	private LoanAccountResponseBean getAllActiveLoans(LoanAccountResponseBean loanDetailsBean)
	{
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "inside call getAllActiveLoans()");
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		List<LoanDetailBean> filteredLoans = new ArrayList<>();
		List<LoanDetailBean> allLoans = loanDetailsBean.getLoanDetails();
		Double totalLoanAmount = 0.0;
		Double totalOutstandingAmount = 0.0;
		Double totalEmiAmount=0.0;
		for (LoanDetailBean loanDetailBean : allLoans) {
			//add condition for matured loan details.	
			if("A".equals(loanDetailBean.getLoanStatus()))
			{
				filteredLoans.add(loanDetailBean);	
				totalLoanAmount = totalLoanAmount +loanDetailBean.getLoanAmount().doubleValue();
				totalOutstandingAmount = totalOutstandingAmount + loanDetailBean.getOutstandingLoanAmount().doubleValue();
				if(null!=loanDetailBean.getEmiAmount())
				{
					totalEmiAmount = totalEmiAmount + loanDetailBean.getEmiAmount().doubleValue();
				}
			}
		}
		loanAccountResponseBean.setLoanDetails(filteredLoans);
		loanAccountResponseBean.setTotalLoanAmount(totalLoanAmount);
		loanAccountResponseBean.setTotalOutstandingAmount(totalOutstandingAmount);
		loanAccountResponseBean.setTotalEmiAmount(totalEmiAmount);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "return from getAllActiveLoans() loan returned" +loanAccountResponseBean);
		return loanAccountResponseBean;
	}
	private LoanAccountResponseBean getAllMaturedLoanDetails(LoanAccountResponseBean loanDetailsBean) {
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		List<LoanDetailBean> filteredLoans = new ArrayList<>();
		List<LoanDetailBean> allLoans = loanDetailsBean.getLoanDetails();
		List<String> meLoansList;
		for (LoanDetailBean loanDetailBean : allLoans) {
			//add condition for matured loan details.	
			meLoansList = new ArrayList<>(Arrays.asList(maturedLoanStatus.split(",")));
			if(!meLoansList.isEmpty() && meLoansList.contains(loanDetailBean.getLoanStatus()))
			{
				filteredLoans.add(loanDetailBean);	
			}
		}
		loanAccountResponseBean.setLoanDetails(filteredLoans);
		return loanAccountResponseBean;
	}

	private LoanAccountResponseBean getLoanDetailsForMissedEMIPayment(LoanAccountResponseBean loanDetailsBean) {
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		List<LoanDetailBean> filteredLoans = new ArrayList<>();
		List<LoanDetailBean> allLoans = loanDetailsBean.getLoanDetails();
		List<String> meLoansList;
		if(StringUtils.isNotBlank(meLoans))
		{
			meLoansList = new ArrayList<>(Arrays.asList(meLoans.split(",")));
			for (LoanDetailBean loanDetailBean : allLoans) {
				boolean emiMissed = checkEmiMissedLoan(loanDetailBean);
				if(!meLoansList.isEmpty() && meLoansList.contains(loanDetailBean.getLoanTypeId()) && "A".equals(loanDetailBean.getLoanStatus()) && emiMissed)
				{
					filteredLoans.add(loanDetailBean);
				}
			}
		}
		loanAccountResponseBean.setLoanDetails(filteredLoans);
		return loanAccountResponseBean;
	}

	private boolean checkEmiMissedLoan(LoanDetailBean loanDetailBean)
	{
		boolean missed=false;
		if(null!= loanDetailBean.getMissedEMIDetails() && null!=loanDetailBean.getMissedEMIDetails().getAmountToBePaid() && loanDetailBean.getMissedEMIDetails().getAmountToBePaid().longValue()>0)
		{
			missed =true;
		}
		return missed;
	}
	private LoanAccountResponseBean getLoanDetailsForTranchWithdrawal(LoanAccountResponseBean loanDetailsBean) {
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		List<LoanDetailBean> filteredLoans = new ArrayList<>();
		List<LoanDetailBean> allLoans = loanDetailsBean.getLoanDetails();
		List<String> tdLoansList;
		if(StringUtils.isNotBlank(tdLoans))
		{
		   tdLoansList = new ArrayList<>(Arrays.asList(tdLoans.split(",")));
		   for(LoanDetailBean loanDetailBean : allLoans) {
			if(!tdLoansList.isEmpty() && tdLoansList.contains(loanDetailBean.getLoanTypeId()) && "Partially Disbursed".equals(loanDetailBean.getLoanDisburseStatus()) && "A".equals(loanDetailBean.getLoanStatus()))
			{
				filteredLoans.add(loanDetailBean);
			}
		 }
		}
		loanAccountResponseBean.setLoanDetails(filteredLoans);
		return loanAccountResponseBean;
	}

	private LoanAccountResponseBean getLoanDetailsForWithdrawal(LoanAccountResponseBean loanDetailsBean,String type) {
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		List<LoanDetailBean> filteredLoans = new ArrayList<>();
		List<LoanDetailBean> allLoans = loanDetailsBean.getLoanDetails();
		List<String> wdLoansList ;
		List<String> hfLoansList ;
		if(StringUtils.isNotBlank(wdLoans) && StringUtils.isNotBlank(hfLoans))
		{
			wdLoansList = new ArrayList<>(Arrays.asList(wdLoans.split(",")));
			hfLoansList = new ArrayList<>(Arrays.asList(hfLoans.split(",")));
			for (LoanDetailBean loanDetailBean : allLoans) {
				if(!wdLoansList.isEmpty() && wdLoansList.contains(loanDetailBean.getLoanTypeId()) && "A".equals(loanDetailBean.getLoanStatus()))
				{
					boolean isBounceEMI= checkEMIBounce(loanDetailBean);
					loanDetailBean.setEmiBounceIS(isBounceEMI);
					if(loanDetailBean.isEmiBounceIS())
					{
						loanDetailBean.setEmiBounceISDescription("( Emi is Bounce or Overdue )");
					}
					if(loanDetailBean.isUnderLimitMonth())
					{
						loanDetailBean.setLoanMsgUnderMonthDescription("( First Emi Not Paid )");
					}
					if(loanDetailBean.isFreeze())
					{
						loanDetailBean.setLoanMsgFreezeDescription("( Freezing Period )");
					}
					if(getOverdueChargesExists(loanDetailBean)) 
						loanDetailBean.setOverdueChargesExists("Y");
					else
						loanDetailBean.setOverdueChargesExists("N");
					filteredLoans.add(loanDetailBean);
				
					if(null!=loanDetailBean.getLoanTypeId() && hfLoans.contains(loanDetailBean.getLoanTypeId()))
					{
						if(null!=loanDetailBean.getAvailableLimit())
							loanDetailBean.setAmountAvailableDisbursement(loanDetailBean.getAvailableLimit().doubleValue());
						if(null!=loanDetailBean.getCurrentDroplineLimit())
							loanDetailBean.setTotalLimit(loanDetailBean.getCurrentDroplineLimit().doubleValue());
						if(null!=loanDetailBean.getUtilisation())
							loanDetailBean.setOutstandingLoanAmount(loanDetailBean.getUtilisation().doubleValue());
					}else if(null!=loanDetailBean.getLoanISAmount() && null!=loanDetailBean.getOutstandingLoanISAmount()){
						loanDetailBean.setAmountAvailableDisbursement(loanDetailBean.getLoanISAmount().doubleValue()-loanDetailBean.getOutstandingLoanISAmount().doubleValue());
						loanDetailBean.setTotalLimit(loanDetailBean.getLoanISAmount().doubleValue());	
					}
				}
			}
		}
		loanAccountResponseBean.setLoanDetails(filteredLoans);
		return loanAccountResponseBean;
	}

	private boolean getOverdueChargesExists(LoanDetailBean loanDetailBean) {
		if(null!=loanDetailBean.getFees()) {
		List<FeeBean> fees=loanDetailBean.getFees();
		 for(FeeBean fee: fees) {
			 if(null != fee.getFeeCode() && !fee.getFeeCode().isEmpty() && null != fee.getFeeBalanceAmount()) {
				 if(fee.getFeeCode().equals(AMC_Charge) && fee.getFeeBalanceAmount().longValue()>0){
				 	return true;
				 }
			  }
			 }}
		return false;
	}

	private boolean checkEMIBounce(LoanDetailBean loanDetailBean) {
		boolean flag=false;
		if(null!=loanDetailBean.getMissedEMIDetails() && !loanDetailBean.getMissedEMIDetails().getMissedEMI().isEmpty())
		{
			List<MissedEMI> list = loanDetailBean.getMissedEMIDetails().getMissedEMI();
			for (MissedEMI missedEMI : list) {
				if(missedEMI.getEmiAmount()>0)
				{
					flag=true;
					break;
				}
			}
		}
		return flag;
	}

	private LoanAccountResponseBean getLoanDetailsForPartPayment(LoanAccountResponseBean loanDetailsBean) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside getLoanDetailsForPartPaymentOrForeClosure");
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		List<LoanDetailBean> filteredLoans = new ArrayList<>();
		List<LoanDetailBean> allLoans = loanDetailsBean.getLoanDetails();
		List<String> ppList;
		if(StringUtils.isNotBlank(ppLoans))
		{
			ppList = new ArrayList<>(Arrays.asList(ppLoans.split(",")));
			for (LoanDetailBean loanDetailBean : allLoans) {
				boolean check = mandatoryCheck(loanDetailBean);
				{
					if(!ppList.isEmpty() && ppList.contains(loanDetailBean.getLoanTypeId()) && check) {
						setDefaultRecalType(loanDetailBean);
						filteredLoans.add(loanDetailBean);	
					}
				}
				setMinimumAnountForPartPayment(loanDetailBean);
			}
		}
		loanAccountResponseBean.setLoanDetails(filteredLoans);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside exit getLoanDetailsForPartPaymentOrForeClosure"+loanAccountResponseBean);
		return loanAccountResponseBean;
	}
	
	private void setMinimumAnountForPartPayment(LoanDetailBean loanDetailBean) {
		if(null!=loanDetailBean.getMissedEMIDetails() && null!=loanDetailBean.getMissedEMIDetails().getAmountToBePaid()&& null!=loanDetailBean.getEmiAmount())
		{
			loanDetailBean.setMinimumAmountToPay(loanDetailBean.getEmiAmount().doubleValue()+loanDetailBean.getMissedEMIDetails().getAmountToBePaid());
		}else if(null!=loanDetailBean.getEmiAmount()){
			loanDetailBean.setMinimumAmountToPay(loanDetailBean.getEmiAmount());
		}
	}

	private LoanAccountResponseBean getLoanDetailsForForeClosure(LoanAccountResponseBean loanDetailsBean) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside getLoanDetailsForForeClosure");
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		List<LoanDetailBean> filteredLoans = new ArrayList<>();
		List<LoanDetailBean> allLoans = loanDetailsBean.getLoanDetails();
		List<String> ppList;
		if(StringUtils.isNotBlank(fcLoans))
		{
			ppList = new ArrayList<>(Arrays.asList(fcLoans.split(",")));
			for (LoanDetailBean loanDetailBean : allLoans) {
				boolean check = mandatoryCheck(loanDetailBean);
				if(!ppList.isEmpty() && ppList.contains(loanDetailBean.getLoanTypeId()) && check)
				{
					filteredLoans.add(loanDetailBean);
				}
			}
		}
		loanAccountResponseBean.setLoanDetails(filteredLoans);
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside exit getLoanDetailsForPartPaymentOrForeClosure"+loanAccountResponseBean);
		return loanAccountResponseBean;
	}
	
	private boolean mandatoryCheck(LoanDetailBean loanDetailBean){
		boolean check = false;
		//!loanDetailBean.isFreeze() && !loanDetailBean.isUnderLimitMonth() 
		if(!loanDetailBean.isIsblock() && "A".equals(loanDetailBean.getLoanStatus()))
		{
			check=true;
		}
		if(loanDetailBean.isUnderLimitMonth())
		{
			loanDetailBean.setLoanMsgUnderMonthDescription("( First Emi Not Paid )");
		}
		if(loanDetailBean.isFreeze())
		{
			loanDetailBean.setLoanMsgFreezeDescription("( Freezing Period )");
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside mandatoryCheck return :: "+check +"for loan:: "+loanDetailBean.getLoanAcctNumber());
		return check;
	} 
	
	private LoanAccountResponseBean getLoanDetailsForDepositInterestServicing(LoanAccountResponseBean loanDetailsBean) {
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		List<LoanDetailBean> filteredLoans = new ArrayList<>();
		List<LoanDetailBean> allLoans = loanDetailsBean.getLoanDetails();
		List<String> diLoansList;
		if(StringUtils.isNotBlank(diLoans))
		{
			diLoansList = new ArrayList<>(Arrays.asList(diLoans.split(",")));
			for (LoanDetailBean loanDetailBean : allLoans) {
				boolean check = mandatoryCheck(loanDetailBean);
				if(!diLoansList.isEmpty() && diLoansList.contains(loanDetailBean.getLoanTypeId()) && check)
				{
					setDefaultRecalType(loanDetailBean);
					filteredLoans.add(loanDetailBean);
				}
		 }
		}
		loanAccountResponseBean.setLoanDetails(filteredLoans);
		return loanAccountResponseBean;
	}
	
	private LoanAccountResponseBean getAllAdvanceEMILoanDetails(LoanAccountResponseBean loanDetailsBean) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside getAllDIYLoanDetails");
		LoanAccountResponseBean loanAccountResponseBean = new LoanAccountResponseBean();
		List<LoanDetailBean> filteredLoans = new ArrayList<>();
		List<LoanDetailBean> allLoans = loanDetailsBean.getLoanDetails();
		List<String> diyLoanList;
		if(StringUtils.isNotBlank(advemiLoans))
		{
			diyLoanList = new ArrayList<>(Arrays.asList(advemiLoans.split(",")));
			for (LoanDetailBean loanDetailBean : allLoans) {
				boolean check = mandatoryCheck(loanDetailBean);
				if(!diyLoanList.isEmpty() && diyLoanList.contains(loanDetailBean.getLoanTypeId()) && check)
				{
					filteredLoans.add(loanDetailBean);
				}
			}
		}
		loanAccountResponseBean.setLoanDetails(filteredLoans);
		for(LoanDetailBean loan : loanAccountResponseBean.getLoanDetails()){
			if (null!=loan.getOverdueEMIAmount() && (int)(loan.getOverdueEMIAmount()) > 0){
				loan.setOverdueChargesExists("Y");
		}
		}
		
		logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling inside exit getAllDIYLoanDetails"+loanAccountResponseBean);
		return loanAccountResponseBean;
	}

	private void setDefaultRecalType(LoanDetailBean loanDetailBean) {
		List<String> defaultLoansTermLoan = new ArrayList<>(Arrays.asList(ppLoansDefaultRecalType.split(",")));
		List<String> defaultLoansHF = new ArrayList<>(Arrays.asList(depositHFLoansDefaultRecalType.split(",")));
		if(null != defaultLoansTermLoan && !defaultLoansTermLoan.isEmpty() && defaultLoansTermLoan.contains(loanDetailBean.getLoanTypeId()))
			{
				loanDetailBean.setDefaultRecalType(REDUCETENOR);
			
			}else if(null != defaultLoansHF && !defaultLoansHF.isEmpty() && defaultLoansHF.contains(loanDetailBean.getLoanTypeId()))
			{
				loanDetailBean.setDefaultRecalType(REDUCEPRINCIPAL);
			}
	}
	
	@Component
	public class AsyncClass {
		
		@RequestScoped
		@Autowired
		BFLLoggerUtil logger;
		
		@Autowired
	    private LoanAccountService loanAccountService;
	    
	    @Autowired
	    private ProductDao productDao;
	    
	    @Value("${FreezePeriod}")
	    private Integer freezeperiod;
	    
	    @Value("${LimitMonth}")
	    private Integer underlimit;
	    
	    @Value("${minimumPaidEMI}")
	    private Integer minimumPaidEMI;
	    
		@Async
		public Future<LoanDetailBean> getLoanDetailsByLanNo(Loan loan,LoanProductType loanType , String type) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "calling getLoanDetailsByLanNo() in helper");
			LoanDetailBean detailBean = new LoanDetailBean();
			LoanDetailResponseBean loanDetailByLAN = null;
		//	LoanProductType loanType= productDao.getLoanTypeDesc(loan.getFinType());
			if(null!=loanType && null!=loanType.getLntypdesc())
			{
				detailBean.setLoanType(loanType.getLntypdesc());
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Product Type setting "+loanType.getLntypdesc());
			}
			if(null!=loanType && null!=loanType.getLoanProduct() && null!=loanType.getLoanProduct().getLnproddesc())
			{
				detailBean.setProductType(loanType.getLoanProduct().getLnproddesc());
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Product Type setting "+loanType.getLoanProduct().getLnproddesc());

			}
			if(null!=loanType && null!=loanType.getLntyprepyschmethod())
			{
				detailBean.setScheduleMethod(loanType.getLntyprepyschmethod());
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "setScheduleMethod"+loanType.getLntyprepyschmethod());
			}
			detailBean.setLimitMonth(minimumPaidEMI);
			detailBean.setLoanTypeId(loan.getFinType());
			detailBean.setLoanAmount(loan.getFinAssetValue());
			detailBean.setLoanISAmount(loan.getFinAmount());
			detailBean.setOutstandingLoanAmount(loan.getOutstandingPri());
			detailBean.setEmiAmount(loan.getNextRepayAmount());
			detailBean.setEmiFlag(false); //FIX to call another Pennat API
			detailBean.setLoanAcctNumber(loan.getFinReference());
			detailBean.setLoanDisburseStatus(loan.getDisbStatus());
			detailBean.setProductTypeId(loan.getProduct());
			detailBean.setLoanStatus(loan.getFinStatus());
			detailBean.setLoanStartDate(loan.getFinStartDate());
			detailBean.setLastEMIDate(loan.getMaturityDate());
			detailBean.setApplicationNo(loan.getApplicationNo());
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Before  getLoanDetailsByLanNo()");
			if(null!=loan.getFinReference() && null!=loan.getFinStatus() && (ACTIVELOANSTATUSFLAG).equals(loan.getFinStatus()) )
			{
				loanDetailByLAN = loanAccountService.getLoanDetailsByLanNo(loan.getFinReference(),loanType.getLoanProduct().getLnprodcode());
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Getting  getLoanDetailsByLanNo() ::"+loanDetailByLAN);
			if(null!=loanDetailByLAN && null!=loanDetailByLAN.getFinanceDetail())
			{
				setDetailBeanData(loanDetailByLAN,detailBean);
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Set setDetailBeanData() completed");
			}
			if(null!=loan.getCoApplicants() && !loan.getCoApplicants().isEmpty())
			{
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Get getCoApplicants() staring");
				List<CoApplicant> coApplicants= loan.getCoApplicants();
				detailBean.setCoApplicant(coApplicants);
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Get getCoApplicants() completed");
			}
			if(null!=type && type.equals(ADVEMILOAN) && null!=loanDetailByLAN && (null !=loanDetailByLAN.getFinanceDetail().getSummary().getAdvanceEMIs() && !loanDetailByLAN.getFinanceDetail().getSummary().getAdvanceEMIs().isEmpty())){
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Setting AdvanceEMIs for LAN:"+loanDetailByLAN.getLoanAcctNumber());
				detailBean.setAdvanceEMIs(loanDetailByLAN.getFinanceDetail().getSummary().getAdvanceEMIs());
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "IN FOR LOOP Total Values updated as per loan ::");
			return new AsyncResult<>(detailBean);
		}
		
		private void setDetailBeanData(LoanDetailResponseBean loanDetailByLAN,LoanDetailBean detailBean) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Starting inside setDetailBeanData()");
			if(null!=loanDetailByLAN.getFinanceDetail().getSummary().getCurrentDroplineLimit())
			{
				detailBean.setCurrentDroplineLimit(loanDetailByLAN.getFinanceDetail().getSummary().getCurrentDroplineLimit());
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getSummary().getAvailableLimit())
			{
				detailBean.setAvailableLimit(loanDetailByLAN.getFinanceDetail().getSummary().getAvailableLimit());
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getSummary().getUtilisation())
			{
				detailBean.setUtilisation(loanDetailByLAN.getFinanceDetail().getSummary().getUtilisation());
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getSummary().getOutstandingPri())
			{
				detailBean.setOutstandingLoanISAmount(loanDetailByLAN.getFinanceDetail().getSummary().getOutstandingPri().doubleValue());
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getRoi())
			{
				detailBean.setRoi(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getRoi());
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getApplicationNo())
			{
				detailBean.setApplicationNo(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getApplicationNo());
			}
			if(null!=loanDetailByLAN.getFinanceDetail() && null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getRemainingTenure())
			{
				detailBean.setRemainingTenure(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getRemainingTenure());
			}
			if(null!=loanDetailByLAN.getFinanceDetail() && null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getTotalEmi()){
				detailBean.setTotalEmi(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getTotalEmi());	
			}
			//repayFrq -M0001 -- Need to check and convert this emi cycle date as current month and day e.g M0001 - 01/03/2017 
			//FIX ME
			if(null!=loanDetailByLAN.getFinanceDetail() &&  null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getEMICylceDate())
			{
				detailBean.setEMICylceDate(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getEMICylceDate());	
			}
			if(null!=loanDetailByLAN.getFinanceDetail() &&  null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getOverdueEMIAmount())
			{
				detailBean.setOverdueEMIAmount(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getOverdueEMIAmount());	
			}
			if(null!=loanDetailByLAN.getFinanceDetail() &&  null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getRepaymentMode())
			{
				detailBean.setRepaymentMode(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getRepaymentMode());	
			}
			if(null!=loanDetailByLAN.getFinanceDetail() &&  null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getTotalEMIReceived())
			{
				detailBean.setTotalEMIReceived(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getTotalEMIReceived());	
			}
			if(null!=loanDetailByLAN.getFinanceDetail() &&  null!=loanDetailByLAN.getFinanceDetail().getSummary())
			{
				detailBean.setFirstEMIDate(loanDetailByLAN.getFinanceDetail().getSummary().getFirstInstDate());	
			}
			if(null!=loanDetailByLAN.getFinanceDetail() && null!=loanDetailByLAN.getFinanceDetail().getSummary())
			{
				detailBean.setEmiPaid(loanDetailByLAN.getFinanceDetail().getSummary().getNoPaidInst());
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getDisbursementDate())
			{
				detailBean.setDisbursementDate(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getDisbursementDate());
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getNextEmiDate())
			{
				detailBean.setNextEmiDate(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getNextEmiDate());
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getLoanPaidAmount())
			{
				detailBean.setLoanPaidAmount(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getLoanPaidAmount());
	            if(null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getFinAssetValue())
	            {
	            	detailBean.setLoanPaidPercent(LoanAccountUtil.calculatePercent(detailBean.getLoanPaidAmount(),loanDetailByLAN.getFinanceDetail().getFinanceDetail().getFinAssetValue().doubleValue()));            	
	            }
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getLoanAmount())
			{
				detailBean.setTotalLimit(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getFinAssetValue().doubleValue());
			}
			if(null!=detailBean.getTotalLimit() && null!=loanDetailByLAN.getFinanceDetail().getSummary().getOutstandingPri())
			{
				detailBean.setAvailableAmount(detailBean.getTotalLimit()-loanDetailByLAN.getFinanceDetail().getSummary().getOutstandingPri().doubleValue());
			}
			if(null!=detailBean.getTotalLimit() && null!=loanDetailByLAN.getFinanceDetail().getSummary().getOutstandingPri())
		    {
		    	detailBean.setAmountAvailableDisbursement(detailBean.getTotalLimit()-loanDetailByLAN.getFinanceDetail().getSummary().getOutstandingPri().doubleValue());   	
		    }
			if(null!=loanDetailByLAN.getFinanceDetail().getSummary())
			{
				detailBean.setOverdueEMIAmount(loanDetailByLAN.getFinanceDetail().getSummary().getOverdueTotal());
			}
			if(null!=loanDetailByLAN.getFinanceDetail() && null!=loanDetailByLAN.getFinanceDetail().getSummary() && null!=loanDetailByLAN.getFinanceDetail().getSummary().getNextSchDate())
		    {
				detailBean.setNextEmiDate(loanDetailByLAN.getFinanceDetail().getSummary().getNextSchDate());	
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, " setNextEmiDate()"+detailBean.getNextEmiDate());
				setFreezeData(detailBean);
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "completed setFreezeData()");
		    }
		    if(null!=loanDetailByLAN.getFinanceDetail().getSummary().getFirstInstDate())
		    {
		    	detailBean.setFirstEMIDate(loanDetailByLAN.getFinanceDetail().getSummary().getFirstInstDate());	
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Ending setFirstEMIDate()"+detailBean.getFirstEMIDate());
		    	setUnderLimitData(detailBean); //temp fix
				logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "completed setUnderLimitData()");
		    }
			if(null!=loanDetailByLAN && null!=loanDetailByLAN.getDisbursementBean() && !loanDetailByLAN.getDisbursementBean().isEmpty())
			{
				setDisbursementDetailsData(loanDetailByLAN,detailBean);
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getFees() && !loanDetailByLAN.getFinanceDetail().getFees().isEmpty())
		    {
		       setFeesDetails(loanDetailByLAN,detailBean);
		    }
			if(null!=loanDetailByLAN.getFinanceDetail().getSummary().getOverdueCharge() && !loanDetailByLAN.getFinanceDetail().getSummary().getOverdueCharge().isEmpty())
		    {
		       setOverdueEMIData(loanDetailByLAN.getFinanceDetail().getSummary().getOverdueCharge(),detailBean);
		    }
			if(null!=loanDetailByLAN.getCollatoralResponseBean() && null!=loanDetailByLAN.getCollatoralResponseBean().getCollateralLinkedLoans() && !loanDetailByLAN.getCollatoralResponseBean().getCollateralLinkedLoans().isEmpty())
			{
				setCollatorelDetails(loanDetailByLAN.getCollatoralResponseBean(),detailBean);
			}
			if(null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail() && null!=loanDetailByLAN.getFinanceDetail().getFinanceDetail().getEmiHoliday() && !loanDetailByLAN.getFinanceDetail().getFinanceDetail().getEmiHoliday().isEmpty())
			{
				detailBean.setEmiHoliday(setEMIHolidayList(loanDetailByLAN.getFinanceDetail().getFinanceDetail().getEmiHoliday()));
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Ending setDetailBeanData()");
		}

		private List<EMIHoliday> setEMIHolidayList(List<EMIHoliday> emiHoliday) {
			List<EMIHoliday> emiHolidays = new ArrayList<>();
			for (EMIHoliday emiHolidayMonth : emiHoliday) {
				EMIHoliday holiday = new EMIHoliday();
				holiday.setHolidayMonth(emiHolidayMonth.getHolidayMonth());
				if(emiHolidayMonth.getHolidayMonth().intValue()>=1 && emiHolidayMonth.getHolidayMonth().intValue()<=12)
				{
				  holiday.setMonthName(Month.of(emiHolidayMonth.getHolidayMonth().intValue()).name());
				}
				emiHolidays.add(holiday);
			}
			return emiHolidays;
		}

		private void setFreezeData(LoanDetailBean detailBean) {
			if(null!=detailBean.getNextEmiDate())
			{
		        logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "inside setFreezeData" +detailBean.getNextEmiDate());
				int diff =LoanAccountUtil.getDaysDifferenceForDateWithoutTimeStamp(detailBean.getNextEmiDate());
		        logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "inside setFreezeData"+diff);
		    	if(diff < freezeperiod && diff > 0)
			    {
				    logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "inside if Setting setFreeze TRUE");
					detailBean.setFreeze(true);
			    }else{
				    logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "inside else Not Setting setFreeze TRUE");
			    }
			}else{
		        logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "NextEmiDate Date is not coming" +detailBean.getNextEmiDate());
			}
		}
		
		private void setUnderLimitData(LoanDetailBean detailBean) {
		       logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "setUnderLimitData");
		       if(null!=detailBean.getEmiPaid() && minimumPaidEMI <= detailBean.getEmiPaid().intValue())
		       {
				    logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "inside if Setting UnderLimitMonth FALSE");
					detailBean.setUnderLimitMonth(false);
			   }else{
				        detailBean.setUnderLimitMonth(true);
					    logger.debug(THIS_CLASS, BFLLoggerComponent.UTILITY, "Setting UnderLimitMonth TRUE");
			   }
		}
		
		private void setDisbursementDetailsData(LoanDetailResponseBean loanDetailByLAN, LoanDetailBean detailBean) {
			List<DisbursementBean> disbursements= loanDetailByLAN.getDisbursementBean();
			double totoalDisbursementAmount=0;
			for (DisbursementBean disbursementBeanDetail : disbursements) {
				Double disburseAmount = disbursementBeanDetail.getDisbursementAmount();
				totoalDisbursementAmount = totoalDisbursementAmount + disburseAmount;
				if(NEFT.equals(disbursementBeanDetail.getDisbursementType()))
				{
					detailBean.setDisbursementBean(disbursementBeanDetail);
				}
			}
			detailBean.setDisbursement(disbursements);
			detailBean.setTotalDisburseAmount(totoalDisbursementAmount);
			/**"detailBean.setAmountAvailableDisbursement(detailBean.getLoanAmount().doubleValue()-detailBean.getTotalDisburseAmount())";**/
		}
		
		private void setFeesDetails(LoanDetailResponseBean loanDetailByLAN, LoanDetailBean detailBean) {
			List<FeeBean> fees = loanDetailByLAN.getFinanceDetail().getFees();
			if(null!=fees && !fees.isEmpty())
			{
				detailBean.setFees(fees);
			}
		}
		
		private void setOverdueEMIData(List<OverdueSummaryBean> overdueCharge, LoanDetailBean detailBean) {
			MissedEMIDetailBean missedEMIDetailBean = new MissedEMIDetailBean();	
			Double  amountToBePaid =0.0;
			List<MissedEMI> missedEMI = new ArrayList<>();
			for (OverdueSummaryBean overdueSummaryBean : overdueCharge) {
				 String dateVal = overdueSummaryBean.getSchdDate();
				 String [] dateValues = dateVal.split("-");
				   if(checkMandatory(overdueSummaryBean) || checkBounceCharge(detailBean.getFees(),dateValues[1]))
					{
						Double  totalEmiAmt =0.0;
						Double latePaymentAmt =0.0;
						Double totalBounceCharge = 0.0;
					    MissedEMI emiOverdue = new MissedEMI();
						emiOverdue.setEmiAmount(overdueSummaryBean.getOverdueAmount().doubleValue());
						emiOverdue.setOverdueEMIDate(dateVal);
						emiOverdue.setYear(dateValues[0]);
						emiOverdue.setMonth(dateValues[1]);
						if(!detailBean.getFees().isEmpty())
						{
							//Bounce Charge should set as per Fee Details using code "BC" , feild feebalance
							emiOverdue.setBounceCharges(setBounceCharges(detailBean.getFees(),dateValues[1]));
						}else{
							emiOverdue.setBounceCharges(0d);
						}
						//Late payment penalty set 
						emiOverdue.setLateFeeAmount(overdueSummaryBean.getOverdueChargeAmount().doubleValue()-overdueSummaryBean.getOverdueChargePaid().doubleValue());//fix me
						latePaymentAmt = latePaymentAmt + emiOverdue.getLateFeeAmount();
						totalBounceCharge = totalBounceCharge +emiOverdue.getBounceCharges();
						totalEmiAmt = emiOverdue.getEmiAmount()+latePaymentAmt+totalBounceCharge;
						amountToBePaid = amountToBePaid +totalEmiAmt;
						emiOverdue.setTotalEmiAmount(totalEmiAmt);
						missedEMI.add(emiOverdue);	
					}
			}
			missedEMIDetailBean.setMissedEMI(missedEMI);
			missedEMIDetailBean.setAmountToBePaid(amountToBePaid);
			if(!missedEMI.isEmpty() && amountToBePaid > 0)
			{
				detailBean.setMissedEMIDetails(missedEMIDetailBean);
			}
		}
		
		private boolean checkBounceCharge(List<FeeBean> fees, String month) {
			boolean isbounce=false;
			if(null!=fees && !fees.isEmpty())
			{
				for (FeeBean feeBean : fees) {
					if("BC".equals(feeBean.getFeeCategory()) && null!=feeBean.getSchdDate())
					{
						String dateVal  = LoanAccountUtil.getStampDateWithInString(feeBean.getSchdDate());
						String [] dateValues = dateVal.split("-");
						if(month.equals(dateValues[1]))
						{
							if(feeBean.getFeeAmount().doubleValue() - feeBean.getPaidAmount().doubleValue() >0)
							{
								isbounce=true;
							}
						}
					}
				}
			}
			return isbounce;
		}

		private boolean checkMandatory(OverdueSummaryBean summaryBean) {
			boolean flag=false;
			long diff = summaryBean.getOverdueChargeAmount().longValue() -  summaryBean.getOverdueChargePaid().longValue();
			if(summaryBean.getOverdueAmount().longValue()> 0 || diff > 0)
			{
				flag=true;
			}
			return flag;
		}

		private Double setBounceCharges(List<FeeBean> fees,String month) {
			Double bounceCharge=0.0;
			if(null!=fees && !fees.isEmpty())
			{
				for (FeeBean feeBean : fees) {
					if("BC".equals(feeBean.getFeeCategory())&& null!=feeBean.getSchdDate())
					{
						String dateVal  = LoanAccountUtil.getStampDateWithInString(feeBean.getSchdDate());
						String [] dateValues = dateVal.split("-");
						if(month.equals(dateValues[1]))
						{
							bounceCharge = feeBean.getFeeAmount().doubleValue()-feeBean.getPaidAmount().doubleValue();
						}
					}
				}
			}
			return bounceCharge;
		}

		private void setCollatorelDetails(LoanCollatoralResponseBean collatoralResponseBean, LoanDetailBean detailBean) {
			detailBean.setLinkedLanNo(collatoralResponseBean.getCollateralLinkedLoans());
		}
	}	

	/*private CustomerLoanResponse getLoanDetailsFromPennant(String cif) {
		if(StringUtils.isNotBlank(cif) && StringUtils.isNotBlank(resourcePathValueGetLoanCustomer))
		{
			Map<String, String> params = new HashMap<>();
			params.put(CIF, cif);
		    HttpHeaders headers = new HttpHeaders();
		    headers.add(LoanAccountConstants.AUTHORIZATION, authorizationKey);
			headers.setContentType(MediaType.APPLICATION_JSON);
			@SuppressWarnings("unchecked")
			ResponseEntity<CustomerLoanResponse> lmsResponse = (ResponseEntity<CustomerLoanResponse>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.GET,resourcePathValueGetLoanCustomer,null, CustomerLoanResponse.class, params, null, headers);
			if(null != lmsResponse && HttpStatus.OK.equals(lmsResponse.getStatusCode())) {
				return lmsResponse.getBody();
			}
		}
		return null;
	}*/
	
	private CustomerLoanResponse getLoanDetailsFromPennantLMS(CifDetailsBean cifDetailBean) {
		CustomerLoanResponse customerLoanResponse = null;
		if(StringUtils.isNotBlank(cifDetailBean.getApltCustCif()))
		{
			ObjectMapper mapper = MapperFactory.getInstance();
			String responseFromLMS;
			Map<String,String> params = new HashMap<>();
			//Prepare Request for LMSIntegrationService
			LmsRequestBean lmsRequestBean =  new LmsRequestBean();
			if(HFC.equals(cifDetailBean.getTarget()))
			{
				lmsRequestBean.setHttpMethod(GET);
				params.put("cif", cifDetailBean.getApltCustCif());
				lmsRequestBean.setParams(params);
			}
			else
			{
				lmsRequestBean.setHttpMethod(POST);
				LoanCustomerRequestBean loanRequestBean= new LoanCustomerRequestBean();
				loanRequestBean.setCif(cifDetailBean.getApltCustCif());
				JSONObject json= new JSONObject(loanRequestBean);
				String requestJson=json.toString();
				lmsRequestBean.setRequestPayload(requestJson);
			}
			lmsRequestBean.setTarget(cifDetailBean.getTarget());
			lmsRequestBean.setSource("LOANCUSTOMER"); //source present in centralconfiguration properties file
			String lmsIntegrationRequestBeanString = null;
			try {
				lmsIntegrationRequestBeanString = mapper.writeValueAsString(lmsRequestBean);
			} catch (JsonProcessingException e) {
				throw new BFLBusinessException("JSNMAPEXC_002", env.getProperty("JSNMAPEXC_002"));
			}
			String lmsURL = env.getProperty("api.lms.gateway.POST.url");
			// calling LMSIntegrationService
			responseFromLMS = loanAccountUtil.hitLMSIntegrationService(lmsIntegrationRequestBeanString, lmsURL);
			customerLoanResponse = loanAccountUtil.mapFromJson(responseFromLMS, CustomerLoanResponse.class);
			
			if(customerLoanResponse.getFinances()!=null && !customerLoanResponse.getFinances().isEmpty()){
				List<Loan> financeList =customerLoanResponse.getFinances(); 
				List<Loan>bfsdFinanceList = new ArrayList<Loan>(); 
				for (Loan loanItem : financeList) {
					if("BFSD".equalsIgnoreCase(loanItem.getDivision())) {
							bfsdFinanceList.add(loanItem); 
					}
				}
				customerLoanResponse.setFinances(bfsdFinanceList); 
				}
			 }
		return customerLoanResponse;
	}
	
}
