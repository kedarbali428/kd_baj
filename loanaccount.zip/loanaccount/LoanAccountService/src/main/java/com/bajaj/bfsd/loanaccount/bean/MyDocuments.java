package com.bajaj.bfsd.loanaccount.bean;

import java.io.Serializable;
import java.util.List;


/**
 * This is a Class for fetching applicant details.
 *
 * @author AkankshaK
 * 
 * Version      BugId           User             Date            Description
 * 1.0                          AkankshaK        27/02/2017      Initial Version
 */
public class MyDocuments implements Serializable{
	
	/**
	 * Constant for serialVersionUID.
	 */
	private static final long serialVersionUID = -3218080491930605711L;
	
	/**
	 * List of all documents.
	 */
	private List<String> documentList;

	/**
	 * Getter method for document list.
	 * 
	 * @return documentList
	 */
	public List<String> getDocumentList() {
		return documentList;
	}

	/**
	 * Set the list of all documents.
	 * 
	 * @param documentList
	 */
	public void setDocumentList(List<String> documentList) {
		this.documentList = documentList;
	}
	
}
