package com.bajaj.bfsd.loanaccount.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.loanaccount.bean.DocumentsResponse;
import com.bajaj.bfsd.loanaccount.service.DocumentsService;
import com.bajaj.bfsd.security.beans.CustomDefaultHeaders;
import com.bfl.common.exceptions.BFLBusinessException;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * This is a controller class for My Documents.
 *
 * @author 412398
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          412398          27/02/2017      Initial Version
 */
@RestController
public class DocumentsController  extends BFLController {
    
    private static final String THIS_CLASS = DocumentsController.class.getSimpleName();
    
    @Autowired
    private BFLLoggerUtilExt logger;
    
    @Autowired 
    DocumentsService docuementsService;
    
    @Autowired
	private CustomDefaultHeaders customheaders;
    
    @Value("${APLT_003}")
	private String errorCodeAPLTOneTwo;
    
    @Value("${custThreeSixty}")
	private String custThreeSixtyFlag;
    
    @ApiOperation(value = "Get all documents for the given customer", 
            notes = "Provides all documents details", httpMethod = "GET")
    @ApiImplicitParam(name = "cmptcorrid", required = true,
                    dataType = "string", paramType = "header") 
    @RequestMapping(value = "${api.loanaccount.loandocuments.GET.uri}",
                  method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    public ResponseEntity<ResponseBean> getAllDocuments(
    		@RequestParam (required=false)Long customerId, @RequestHeader HttpHeaders headers){
    	DocumentsResponse documentResponse;
    	if("Y".equals(custThreeSixtyFlag))
    	{
    		documentResponse = callCustomerThreeSixtyFlow();
    	}else{
    		documentResponse = docuementsService.getDocuments(customerId);
    	}
      return new ResponseEntity<>(new ResponseBean(documentResponse), headers, HttpStatus.OK);
}

	private DocumentsResponse callCustomerThreeSixtyFlow() {
		if(null!=customheaders && 0!=customheaders.getApplntId()){
			Long applicantkey = customheaders.getApplntId();
			logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "getAllDocuments - started");
			return docuementsService.getDocuments(applicantkey);
    	}
    	else{
			throw new BFLBusinessException("APLT_003", errorCodeAPLTOneTwo);
		}
		
	}
}
