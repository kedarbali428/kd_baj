package com.bajaj.bfsd.loanaccount.model;

import java.util.List;

public class Loan {

	private String finReference;
	
	private String finType;
	
	private String product;
	
	private String finCcy;
	
	private Number finAmount;
	
	private Number finAssetValue;
	
	private Number numberOfTerms;
	
	private Number loanTenor;
	
	private String maturityDate;
	
	private Number firstEmiAmount;
	
	private Number nextRepayAmount;
	
	private Number paidTotal;
	
	private Number paidPri;
	
	private Number paidPft;
	
	private Number outstandingTotal;
	
	private Number outstandingPri;
	
	private Number outstandingPft;
	
	private Number futureInst;
	
	private String finStatus;
	
	private String disbStatus;
	
	private String finStartDate;
	
	private String applicationNo;

	private List<CoApplicant> coApplicants;
	
	private String division;
	
	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getFinStartDate() {
		return finStartDate;
	}

	public void setFinStartDate(String finStartDate) {
		this.finStartDate = finStartDate;
	}

	public Number getLoanTenor() {
		return loanTenor;
	}

	public void setLoanTenor(Number loanTenor) {
		this.loanTenor = loanTenor;
	}

	public Number getNextRepayAmount() {
		return nextRepayAmount;
	}

	public void setNextRepayAmount(Number nextRepayAmount) {
		this.nextRepayAmount = nextRepayAmount;
	}

	public String getFinStatus() {
		return finStatus;
	}

	public void setFinStatus(String finStatus) {
		this.finStatus = finStatus;
	}

	public String getDisbStatus() {
		return disbStatus;
	}

	public void setDisbStatus(String disbStatus) {
		this.disbStatus = disbStatus;
	}

	public String getFinReference() {
		return finReference;
	}

	public void setFinReference(String finReference) {
		this.finReference = finReference;
	}

	public String getFinType() {
		return finType;
	}

	public void setFinType(String finType) {
		this.finType = finType;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getFinCcy() {
		return finCcy;
	}

	public void setFinCcy(String finCcy) {
		this.finCcy = finCcy;
	}

	public Number getFinAmount() {
		return finAmount;
	}

	public void setFinAmount(Number finAmount) {
		this.finAmount = finAmount;
	}

	public Number getFinAssetValue() {
		return finAssetValue;
	}

	public void setFinAssetValue(Number finAssetValue) {
		this.finAssetValue = finAssetValue;
	}

	public Number getNumberOfTerms() {
		return numberOfTerms;
	}

	public void setNumberOfTerms(Number numberOfTerms) {
		this.numberOfTerms = numberOfTerms;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public Number getFirstEmiAmount() {
		return firstEmiAmount;
	}

	public void setFirstEmiAmount(Number firstEmiAmount) {
		this.firstEmiAmount = firstEmiAmount;
	}

	public Number getPaidTotal() {
		return paidTotal;
	}

	public void setPaidTotal(Number paidTotal) {
		this.paidTotal = paidTotal;
	}

	public Number getPaidPri() {
		return paidPri;
	}

	public void setPaidPri(Number paidPri) {
		this.paidPri = paidPri;
	}

	public Number getPaidPft() {
		return paidPft;
	}

	public void setPaidPft(Number paidPft) {
		this.paidPft = paidPft;
	}

	public Number getOutstandingTotal() {
		return outstandingTotal;
	}

	public void setOutstandingTotal(Number outstandingTotal) {
		this.outstandingTotal = outstandingTotal;
	}

	public Number getOutstandingPri() {
		return outstandingPri;
	}

	public void setOutstandingPri(Number outstandingPri) {
		this.outstandingPri = outstandingPri;
	}

	public Number getOutstandingPft() {
		return outstandingPft;
	}

	public void setOutstandingPft(Number outstandingPft) {
		this.outstandingPft = outstandingPft;
	}

	public Number getFutureInst() {
		return futureInst;
	}

	public void setFutureInst(Number futureInst) {
		this.futureInst = futureInst;
	}

	public List<CoApplicant> getCoApplicants() {
		return coApplicants;
	}

	public void setCoApplicants(List<CoApplicant> coApplicants) {
		this.coApplicants = coApplicants;
	}

	
}
