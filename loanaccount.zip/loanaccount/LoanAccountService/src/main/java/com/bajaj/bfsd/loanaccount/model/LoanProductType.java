package com.bajaj.bfsd.loanaccount.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the LOAN_PRODUCT_TYPES database table.
 * 
 */
@Entity
@Table(name="LOAN_PRODUCT_TYPES")
@NamedQuery(name="LoanProductType.findAll", query="SELECT l FROM LoanProductType l")
public class LoanProductType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long lnprdtypekey;

	private String lntypadddisbmntfuture;

	private String lntypadddisbmntpastcurr;

	private String lntypaecancel;

	private String lntypaecapitalization;

	private String lntypaedepreciation;

	private String lntypaeearlyadvpay;

	private String lntypaeearlysettlmnt;

	private String lntypaegrcend;

	private String lntypaeinstduedate;

	private String lntypaematurity;

	private String lntypaeoverduepenalties;

	private String lntypaeprovision;

	private String lntypaeratechg;

	private String lntypaerepay;

	private String lntypaeschchg;

	private String lntypaewriteoff;

	private String lntypaewriteoffpay;

	private BigDecimal lntypallowgraceprdflg;

	private BigDecimal lntypallwcommitmntflg;

	private BigDecimal lntypallwcommitoverrideflg;

	private String lntypallwearlypaymethods;

	private BigDecimal lntypallwfeeschedulechgflg;

	private BigDecimal lntypallwintpayingrcprdflg;

	private BigDecimal lntypallwintrtrevrepyprdflg;

	private BigDecimal lntypallwlmtoverrideflg;

	private BigDecimal lntypallwmanualstepflg;

	private BigDecimal lntypallwmultipartydisbursflg;

	private BigDecimal lntypallwmultipledisbursflg;

	private BigDecimal lntypallwpenwaivflg;

	private BigDecimal lntypallwriainvmntflg;

	private BigDecimal lntypallwsteppingflg;

	private BigDecimal lntypallwsteppoliciesflg;

	private BigDecimal lntypallwsyndicationflg;

	private String lntypamortizationinsusp;

	private String lntypamortizationnorm;

	private BigDecimal lntypaplyoveduepenaltyflg;

	private String lntypasstcategory;

	private BigDecimal lntypcapintinrepayprdflg;

	private String lntypchrgperamt;

	private BigDecimal lntypcollateralreqflg;

	private String lntypcollateraltypes;

	private String lntypdefpolicy;

	private String lntypdepreciationfreq;

	private BigDecimal lntypdepreciationreqflg;

	private String lntypdesc;

	private String lntypdivision;

	private BigDecimal lntypdwpayreqflg;

	private String lntypfuturedisbmntevent;

	private BigDecimal lntypgenlnrefflg;

	private String lntypgrcactrtreferential;

	private BigDecimal lntypgrcallwintrevingrcprdflg;

	private BigDecimal lntypgrcintcapgrcprdendflg;

	private BigDecimal lntypgrcintcapingraceflg;

	private String lntypgrcintratetyp;

	private String lntypgrcprdschmethod;

	private String lntypgrcrtreviewapplfor;

	private BigDecimal lntypinclgrcdaybfrapplypenalty;

	private BigDecimal lntypinclgrcdaypencalcflg;

	private String lntypintdaysbasis;

	private BigDecimal lntypisactive;

	private BigDecimal lntypisamcreqflg;

	private BigDecimal lntypisinsurancereqflg;

	private BigDecimal lntypissteppingmandatflg;

	private BigDecimal lntypistdsapplicableflg;

	private BigDecimal lntyplmtreqflg;

	private String lntyplstupdateby;

	private Timestamp lntyplstupdatedt;

	private String lntypmarginrt;

	private BigDecimal lntypmaxwaivper;

	private String lntypmindwpayrule;

	private String lntypnormaltopd;

	private String lntypnormaltosusp;

	private BigDecimal lntypopnnewlnaccflg;

	private String lntypoverduepaydays;

	private String lntyppastdueintcalmethod;

	private String lntyppdtonormal;

	private String lntyppdtosusp;

	private String lntyppenaltycalcon;

	private String lntyppenaltychrgtype;

	private String lntypremainfeeschmethod;

	private String lntyprepyactrtrefrt;

	private BigDecimal lntyprepyallwearlyrepayflg;

	private BigDecimal lntyprepyallwearlystlmntflg;

	private BigDecimal lntyprepyallwindctrtflg;

	private BigDecimal lntyprepyallwpartrepayflg;

	private BigDecimal lntyprepyallwrtchganydtflg;

	private BigDecimal lntyprepyforceqlrepayflg;

	private BigDecimal lntyprepyintfreqflg;

	private String lntyprepyintratetype;

	private String lntyprepymethod;

	private String lntyprepypartrepyschchg;

	private String lntyprepyschmethod;

	private String lntypreviewrtapplied;

	private String lntypschcalcreview;

	private String lntypsuspremark;

	private String lntypsusptonormal;

	private String lntypsusptopd;

	private String lntypsusptrigger;

	private String loantype;

	public LoanProductType() {
	}

	//bi-directional many-to-one association to LoanProduct
	@ManyToOne
	@JoinColumn(name="LNPRODKEY")
	private LoanProduct loanProduct;
		
	public LoanProduct getLoanProduct() {
		return loanProduct;
	}

	public void setLoanProduct(LoanProduct loanProduct) {
		this.loanProduct = loanProduct;
	}

	public long getLnprdtypekey() {
		return this.lnprdtypekey;
	}

	public void setLnprdtypekey(long lnprdtypekey) {
		this.lnprdtypekey = lnprdtypekey;
	}

	public String getLntypadddisbmntfuture() {
		return this.lntypadddisbmntfuture;
	}

	public void setLntypadddisbmntfuture(String lntypadddisbmntfuture) {
		this.lntypadddisbmntfuture = lntypadddisbmntfuture;
	}

	public String getLntypadddisbmntpastcurr() {
		return this.lntypadddisbmntpastcurr;
	}

	public void setLntypadddisbmntpastcurr(String lntypadddisbmntpastcurr) {
		this.lntypadddisbmntpastcurr = lntypadddisbmntpastcurr;
	}

	public String getLntypaecancel() {
		return this.lntypaecancel;
	}

	public void setLntypaecancel(String lntypaecancel) {
		this.lntypaecancel = lntypaecancel;
	}

	public String getLntypaecapitalization() {
		return this.lntypaecapitalization;
	}

	public void setLntypaecapitalization(String lntypaecapitalization) {
		this.lntypaecapitalization = lntypaecapitalization;
	}

	public String getLntypaedepreciation() {
		return this.lntypaedepreciation;
	}

	public void setLntypaedepreciation(String lntypaedepreciation) {
		this.lntypaedepreciation = lntypaedepreciation;
	}

	public String getLntypaeearlyadvpay() {
		return this.lntypaeearlyadvpay;
	}

	public void setLntypaeearlyadvpay(String lntypaeearlyadvpay) {
		this.lntypaeearlyadvpay = lntypaeearlyadvpay;
	}

	public String getLntypaeearlysettlmnt() {
		return this.lntypaeearlysettlmnt;
	}

	public void setLntypaeearlysettlmnt(String lntypaeearlysettlmnt) {
		this.lntypaeearlysettlmnt = lntypaeearlysettlmnt;
	}

	public String getLntypaegrcend() {
		return this.lntypaegrcend;
	}

	public void setLntypaegrcend(String lntypaegrcend) {
		this.lntypaegrcend = lntypaegrcend;
	}

	public String getLntypaeinstduedate() {
		return this.lntypaeinstduedate;
	}

	public void setLntypaeinstduedate(String lntypaeinstduedate) {
		this.lntypaeinstduedate = lntypaeinstduedate;
	}

	public String getLntypaematurity() {
		return this.lntypaematurity;
	}

	public void setLntypaematurity(String lntypaematurity) {
		this.lntypaematurity = lntypaematurity;
	}

	public String getLntypaeoverduepenalties() {
		return this.lntypaeoverduepenalties;
	}

	public void setLntypaeoverduepenalties(String lntypaeoverduepenalties) {
		this.lntypaeoverduepenalties = lntypaeoverduepenalties;
	}

	public String getLntypaeprovision() {
		return this.lntypaeprovision;
	}

	public void setLntypaeprovision(String lntypaeprovision) {
		this.lntypaeprovision = lntypaeprovision;
	}

	public String getLntypaeratechg() {
		return this.lntypaeratechg;
	}

	public void setLntypaeratechg(String lntypaeratechg) {
		this.lntypaeratechg = lntypaeratechg;
	}

	public String getLntypaerepay() {
		return this.lntypaerepay;
	}

	public void setLntypaerepay(String lntypaerepay) {
		this.lntypaerepay = lntypaerepay;
	}

	public String getLntypaeschchg() {
		return this.lntypaeschchg;
	}

	public void setLntypaeschchg(String lntypaeschchg) {
		this.lntypaeschchg = lntypaeschchg;
	}

	public String getLntypaewriteoff() {
		return this.lntypaewriteoff;
	}

	public void setLntypaewriteoff(String lntypaewriteoff) {
		this.lntypaewriteoff = lntypaewriteoff;
	}

	public String getLntypaewriteoffpay() {
		return this.lntypaewriteoffpay;
	}

	public void setLntypaewriteoffpay(String lntypaewriteoffpay) {
		this.lntypaewriteoffpay = lntypaewriteoffpay;
	}

	public BigDecimal getLntypallowgraceprdflg() {
		return this.lntypallowgraceprdflg;
	}

	public void setLntypallowgraceprdflg(BigDecimal lntypallowgraceprdflg) {
		this.lntypallowgraceprdflg = lntypallowgraceprdflg;
	}

	public BigDecimal getLntypallwcommitmntflg() {
		return this.lntypallwcommitmntflg;
	}

	public void setLntypallwcommitmntflg(BigDecimal lntypallwcommitmntflg) {
		this.lntypallwcommitmntflg = lntypallwcommitmntflg;
	}

	public BigDecimal getLntypallwcommitoverrideflg() {
		return this.lntypallwcommitoverrideflg;
	}

	public void setLntypallwcommitoverrideflg(BigDecimal lntypallwcommitoverrideflg) {
		this.lntypallwcommitoverrideflg = lntypallwcommitoverrideflg;
	}

	public String getLntypallwearlypaymethods() {
		return this.lntypallwearlypaymethods;
	}

	public void setLntypallwearlypaymethods(String lntypallwearlypaymethods) {
		this.lntypallwearlypaymethods = lntypallwearlypaymethods;
	}

	public BigDecimal getLntypallwfeeschedulechgflg() {
		return this.lntypallwfeeschedulechgflg;
	}

	public void setLntypallwfeeschedulechgflg(BigDecimal lntypallwfeeschedulechgflg) {
		this.lntypallwfeeschedulechgflg = lntypallwfeeschedulechgflg;
	}

	public BigDecimal getLntypallwintpayingrcprdflg() {
		return this.lntypallwintpayingrcprdflg;
	}

	public void setLntypallwintpayingrcprdflg(BigDecimal lntypallwintpayingrcprdflg) {
		this.lntypallwintpayingrcprdflg = lntypallwintpayingrcprdflg;
	}

	public BigDecimal getLntypallwintrtrevrepyprdflg() {
		return this.lntypallwintrtrevrepyprdflg;
	}

	public void setLntypallwintrtrevrepyprdflg(BigDecimal lntypallwintrtrevrepyprdflg) {
		this.lntypallwintrtrevrepyprdflg = lntypallwintrtrevrepyprdflg;
	}

	public BigDecimal getLntypallwlmtoverrideflg() {
		return this.lntypallwlmtoverrideflg;
	}

	public void setLntypallwlmtoverrideflg(BigDecimal lntypallwlmtoverrideflg) {
		this.lntypallwlmtoverrideflg = lntypallwlmtoverrideflg;
	}

	public BigDecimal getLntypallwmanualstepflg() {
		return this.lntypallwmanualstepflg;
	}

	public void setLntypallwmanualstepflg(BigDecimal lntypallwmanualstepflg) {
		this.lntypallwmanualstepflg = lntypallwmanualstepflg;
	}

	public BigDecimal getLntypallwmultipartydisbursflg() {
		return this.lntypallwmultipartydisbursflg;
	}

	public void setLntypallwmultipartydisbursflg(BigDecimal lntypallwmultipartydisbursflg) {
		this.lntypallwmultipartydisbursflg = lntypallwmultipartydisbursflg;
	}

	public BigDecimal getLntypallwmultipledisbursflg() {
		return this.lntypallwmultipledisbursflg;
	}

	public void setLntypallwmultipledisbursflg(BigDecimal lntypallwmultipledisbursflg) {
		this.lntypallwmultipledisbursflg = lntypallwmultipledisbursflg;
	}

	public BigDecimal getLntypallwpenwaivflg() {
		return this.lntypallwpenwaivflg;
	}

	public void setLntypallwpenwaivflg(BigDecimal lntypallwpenwaivflg) {
		this.lntypallwpenwaivflg = lntypallwpenwaivflg;
	}

	public BigDecimal getLntypallwriainvmntflg() {
		return this.lntypallwriainvmntflg;
	}

	public void setLntypallwriainvmntflg(BigDecimal lntypallwriainvmntflg) {
		this.lntypallwriainvmntflg = lntypallwriainvmntflg;
	}

	public BigDecimal getLntypallwsteppingflg() {
		return this.lntypallwsteppingflg;
	}

	public void setLntypallwsteppingflg(BigDecimal lntypallwsteppingflg) {
		this.lntypallwsteppingflg = lntypallwsteppingflg;
	}

	public BigDecimal getLntypallwsteppoliciesflg() {
		return this.lntypallwsteppoliciesflg;
	}

	public void setLntypallwsteppoliciesflg(BigDecimal lntypallwsteppoliciesflg) {
		this.lntypallwsteppoliciesflg = lntypallwsteppoliciesflg;
	}

	public BigDecimal getLntypallwsyndicationflg() {
		return this.lntypallwsyndicationflg;
	}

	public void setLntypallwsyndicationflg(BigDecimal lntypallwsyndicationflg) {
		this.lntypallwsyndicationflg = lntypallwsyndicationflg;
	}

	public String getLntypamortizationinsusp() {
		return this.lntypamortizationinsusp;
	}

	public void setLntypamortizationinsusp(String lntypamortizationinsusp) {
		this.lntypamortizationinsusp = lntypamortizationinsusp;
	}

	public String getLntypamortizationnorm() {
		return this.lntypamortizationnorm;
	}

	public void setLntypamortizationnorm(String lntypamortizationnorm) {
		this.lntypamortizationnorm = lntypamortizationnorm;
	}

	public BigDecimal getLntypaplyoveduepenaltyflg() {
		return this.lntypaplyoveduepenaltyflg;
	}

	public void setLntypaplyoveduepenaltyflg(BigDecimal lntypaplyoveduepenaltyflg) {
		this.lntypaplyoveduepenaltyflg = lntypaplyoveduepenaltyflg;
	}

	public String getLntypasstcategory() {
		return this.lntypasstcategory;
	}

	public void setLntypasstcategory(String lntypasstcategory) {
		this.lntypasstcategory = lntypasstcategory;
	}

	public BigDecimal getLntypcapintinrepayprdflg() {
		return this.lntypcapintinrepayprdflg;
	}

	public void setLntypcapintinrepayprdflg(BigDecimal lntypcapintinrepayprdflg) {
		this.lntypcapintinrepayprdflg = lntypcapintinrepayprdflg;
	}

	public String getLntypchrgperamt() {
		return this.lntypchrgperamt;
	}

	public void setLntypchrgperamt(String lntypchrgperamt) {
		this.lntypchrgperamt = lntypchrgperamt;
	}

	public BigDecimal getLntypcollateralreqflg() {
		return this.lntypcollateralreqflg;
	}

	public void setLntypcollateralreqflg(BigDecimal lntypcollateralreqflg) {
		this.lntypcollateralreqflg = lntypcollateralreqflg;
	}

	public String getLntypcollateraltypes() {
		return this.lntypcollateraltypes;
	}

	public void setLntypcollateraltypes(String lntypcollateraltypes) {
		this.lntypcollateraltypes = lntypcollateraltypes;
	}

	public String getLntypdefpolicy() {
		return this.lntypdefpolicy;
	}

	public void setLntypdefpolicy(String lntypdefpolicy) {
		this.lntypdefpolicy = lntypdefpolicy;
	}

	public String getLntypdepreciationfreq() {
		return this.lntypdepreciationfreq;
	}

	public void setLntypdepreciationfreq(String lntypdepreciationfreq) {
		this.lntypdepreciationfreq = lntypdepreciationfreq;
	}

	public BigDecimal getLntypdepreciationreqflg() {
		return this.lntypdepreciationreqflg;
	}

	public void setLntypdepreciationreqflg(BigDecimal lntypdepreciationreqflg) {
		this.lntypdepreciationreqflg = lntypdepreciationreqflg;
	}

	public String getLntypdesc() {
		return this.lntypdesc;
	}

	public void setLntypdesc(String lntypdesc) {
		this.lntypdesc = lntypdesc;
	}

	public String getLntypdivision() {
		return this.lntypdivision;
	}

	public void setLntypdivision(String lntypdivision) {
		this.lntypdivision = lntypdivision;
	}

	public BigDecimal getLntypdwpayreqflg() {
		return this.lntypdwpayreqflg;
	}

	public void setLntypdwpayreqflg(BigDecimal lntypdwpayreqflg) {
		this.lntypdwpayreqflg = lntypdwpayreqflg;
	}

	public String getLntypfuturedisbmntevent() {
		return this.lntypfuturedisbmntevent;
	}

	public void setLntypfuturedisbmntevent(String lntypfuturedisbmntevent) {
		this.lntypfuturedisbmntevent = lntypfuturedisbmntevent;
	}

	public BigDecimal getLntypgenlnrefflg() {
		return this.lntypgenlnrefflg;
	}

	public void setLntypgenlnrefflg(BigDecimal lntypgenlnrefflg) {
		this.lntypgenlnrefflg = lntypgenlnrefflg;
	}

	public String getLntypgrcactrtreferential() {
		return this.lntypgrcactrtreferential;
	}

	public void setLntypgrcactrtreferential(String lntypgrcactrtreferential) {
		this.lntypgrcactrtreferential = lntypgrcactrtreferential;
	}

	public BigDecimal getLntypgrcallwintrevingrcprdflg() {
		return this.lntypgrcallwintrevingrcprdflg;
	}

	public void setLntypgrcallwintrevingrcprdflg(BigDecimal lntypgrcallwintrevingrcprdflg) {
		this.lntypgrcallwintrevingrcprdflg = lntypgrcallwintrevingrcprdflg;
	}

	public BigDecimal getLntypgrcintcapgrcprdendflg() {
		return this.lntypgrcintcapgrcprdendflg;
	}

	public void setLntypgrcintcapgrcprdendflg(BigDecimal lntypgrcintcapgrcprdendflg) {
		this.lntypgrcintcapgrcprdendflg = lntypgrcintcapgrcprdendflg;
	}

	public BigDecimal getLntypgrcintcapingraceflg() {
		return this.lntypgrcintcapingraceflg;
	}

	public void setLntypgrcintcapingraceflg(BigDecimal lntypgrcintcapingraceflg) {
		this.lntypgrcintcapingraceflg = lntypgrcintcapingraceflg;
	}

	public String getLntypgrcintratetyp() {
		return this.lntypgrcintratetyp;
	}

	public void setLntypgrcintratetyp(String lntypgrcintratetyp) {
		this.lntypgrcintratetyp = lntypgrcintratetyp;
	}

	public String getLntypgrcprdschmethod() {
		return this.lntypgrcprdschmethod;
	}

	public void setLntypgrcprdschmethod(String lntypgrcprdschmethod) {
		this.lntypgrcprdschmethod = lntypgrcprdschmethod;
	}

	public String getLntypgrcrtreviewapplfor() {
		return this.lntypgrcrtreviewapplfor;
	}

	public void setLntypgrcrtreviewapplfor(String lntypgrcrtreviewapplfor) {
		this.lntypgrcrtreviewapplfor = lntypgrcrtreviewapplfor;
	}

	public BigDecimal getLntypinclgrcdaybfrapplypenalty() {
		return this.lntypinclgrcdaybfrapplypenalty;
	}

	public void setLntypinclgrcdaybfrapplypenalty(BigDecimal lntypinclgrcdaybfrapplypenalty) {
		this.lntypinclgrcdaybfrapplypenalty = lntypinclgrcdaybfrapplypenalty;
	}

	public BigDecimal getLntypinclgrcdaypencalcflg() {
		return this.lntypinclgrcdaypencalcflg;
	}

	public void setLntypinclgrcdaypencalcflg(BigDecimal lntypinclgrcdaypencalcflg) {
		this.lntypinclgrcdaypencalcflg = lntypinclgrcdaypencalcflg;
	}

	public String getLntypintdaysbasis() {
		return this.lntypintdaysbasis;
	}

	public void setLntypintdaysbasis(String lntypintdaysbasis) {
		this.lntypintdaysbasis = lntypintdaysbasis;
	}

	public BigDecimal getLntypisactive() {
		return this.lntypisactive;
	}

	public void setLntypisactive(BigDecimal lntypisactive) {
		this.lntypisactive = lntypisactive;
	}

	public BigDecimal getLntypisamcreqflg() {
		return this.lntypisamcreqflg;
	}

	public void setLntypisamcreqflg(BigDecimal lntypisamcreqflg) {
		this.lntypisamcreqflg = lntypisamcreqflg;
	}

	public BigDecimal getLntypisinsurancereqflg() {
		return this.lntypisinsurancereqflg;
	}

	public void setLntypisinsurancereqflg(BigDecimal lntypisinsurancereqflg) {
		this.lntypisinsurancereqflg = lntypisinsurancereqflg;
	}

	public BigDecimal getLntypissteppingmandatflg() {
		return this.lntypissteppingmandatflg;
	}

	public void setLntypissteppingmandatflg(BigDecimal lntypissteppingmandatflg) {
		this.lntypissteppingmandatflg = lntypissteppingmandatflg;
	}

	public BigDecimal getLntypistdsapplicableflg() {
		return this.lntypistdsapplicableflg;
	}

	public void setLntypistdsapplicableflg(BigDecimal lntypistdsapplicableflg) {
		this.lntypistdsapplicableflg = lntypistdsapplicableflg;
	}

	public BigDecimal getLntyplmtreqflg() {
		return this.lntyplmtreqflg;
	}

	public void setLntyplmtreqflg(BigDecimal lntyplmtreqflg) {
		this.lntyplmtreqflg = lntyplmtreqflg;
	}

	public String getLntyplstupdateby() {
		return this.lntyplstupdateby;
	}

	public void setLntyplstupdateby(String lntyplstupdateby) {
		this.lntyplstupdateby = lntyplstupdateby;
	}

	public Timestamp getLntyplstupdatedt() {
		return this.lntyplstupdatedt;
	}

	public void setLntyplstupdatedt(Timestamp lntyplstupdatedt) {
		this.lntyplstupdatedt = lntyplstupdatedt;
	}

	public String getLntypmarginrt() {
		return this.lntypmarginrt;
	}

	public void setLntypmarginrt(String lntypmarginrt) {
		this.lntypmarginrt = lntypmarginrt;
	}

	public BigDecimal getLntypmaxwaivper() {
		return this.lntypmaxwaivper;
	}

	public void setLntypmaxwaivper(BigDecimal lntypmaxwaivper) {
		this.lntypmaxwaivper = lntypmaxwaivper;
	}

	public String getLntypmindwpayrule() {
		return this.lntypmindwpayrule;
	}

	public void setLntypmindwpayrule(String lntypmindwpayrule) {
		this.lntypmindwpayrule = lntypmindwpayrule;
	}

	public String getLntypnormaltopd() {
		return this.lntypnormaltopd;
	}

	public void setLntypnormaltopd(String lntypnormaltopd) {
		this.lntypnormaltopd = lntypnormaltopd;
	}

	public String getLntypnormaltosusp() {
		return this.lntypnormaltosusp;
	}

	public void setLntypnormaltosusp(String lntypnormaltosusp) {
		this.lntypnormaltosusp = lntypnormaltosusp;
	}

	public BigDecimal getLntypopnnewlnaccflg() {
		return this.lntypopnnewlnaccflg;
	}

	public void setLntypopnnewlnaccflg(BigDecimal lntypopnnewlnaccflg) {
		this.lntypopnnewlnaccflg = lntypopnnewlnaccflg;
	}

	public String getLntypoverduepaydays() {
		return this.lntypoverduepaydays;
	}

	public void setLntypoverduepaydays(String lntypoverduepaydays) {
		this.lntypoverduepaydays = lntypoverduepaydays;
	}

	public String getLntyppastdueintcalmethod() {
		return this.lntyppastdueintcalmethod;
	}

	public void setLntyppastdueintcalmethod(String lntyppastdueintcalmethod) {
		this.lntyppastdueintcalmethod = lntyppastdueintcalmethod;
	}

	public String getLntyppdtonormal() {
		return this.lntyppdtonormal;
	}

	public void setLntyppdtonormal(String lntyppdtonormal) {
		this.lntyppdtonormal = lntyppdtonormal;
	}

	public String getLntyppdtosusp() {
		return this.lntyppdtosusp;
	}

	public void setLntyppdtosusp(String lntyppdtosusp) {
		this.lntyppdtosusp = lntyppdtosusp;
	}

	public String getLntyppenaltycalcon() {
		return this.lntyppenaltycalcon;
	}

	public void setLntyppenaltycalcon(String lntyppenaltycalcon) {
		this.lntyppenaltycalcon = lntyppenaltycalcon;
	}

	public String getLntyppenaltychrgtype() {
		return this.lntyppenaltychrgtype;
	}

	public void setLntyppenaltychrgtype(String lntyppenaltychrgtype) {
		this.lntyppenaltychrgtype = lntyppenaltychrgtype;
	}

	public String getLntypremainfeeschmethod() {
		return this.lntypremainfeeschmethod;
	}

	public void setLntypremainfeeschmethod(String lntypremainfeeschmethod) {
		this.lntypremainfeeschmethod = lntypremainfeeschmethod;
	}

	public String getLntyprepyactrtrefrt() {
		return this.lntyprepyactrtrefrt;
	}

	public void setLntyprepyactrtrefrt(String lntyprepyactrtrefrt) {
		this.lntyprepyactrtrefrt = lntyprepyactrtrefrt;
	}

	public BigDecimal getLntyprepyallwearlyrepayflg() {
		return this.lntyprepyallwearlyrepayflg;
	}

	public void setLntyprepyallwearlyrepayflg(BigDecimal lntyprepyallwearlyrepayflg) {
		this.lntyprepyallwearlyrepayflg = lntyprepyallwearlyrepayflg;
	}

	public BigDecimal getLntyprepyallwearlystlmntflg() {
		return this.lntyprepyallwearlystlmntflg;
	}

	public void setLntyprepyallwearlystlmntflg(BigDecimal lntyprepyallwearlystlmntflg) {
		this.lntyprepyallwearlystlmntflg = lntyprepyallwearlystlmntflg;
	}

	public BigDecimal getLntyprepyallwindctrtflg() {
		return this.lntyprepyallwindctrtflg;
	}

	public void setLntyprepyallwindctrtflg(BigDecimal lntyprepyallwindctrtflg) {
		this.lntyprepyallwindctrtflg = lntyprepyallwindctrtflg;
	}

	public BigDecimal getLntyprepyallwpartrepayflg() {
		return this.lntyprepyallwpartrepayflg;
	}

	public void setLntyprepyallwpartrepayflg(BigDecimal lntyprepyallwpartrepayflg) {
		this.lntyprepyallwpartrepayflg = lntyprepyallwpartrepayflg;
	}

	public BigDecimal getLntyprepyallwrtchganydtflg() {
		return this.lntyprepyallwrtchganydtflg;
	}

	public void setLntyprepyallwrtchganydtflg(BigDecimal lntyprepyallwrtchganydtflg) {
		this.lntyprepyallwrtchganydtflg = lntyprepyallwrtchganydtflg;
	}

	public BigDecimal getLntyprepyforceqlrepayflg() {
		return this.lntyprepyforceqlrepayflg;
	}

	public void setLntyprepyforceqlrepayflg(BigDecimal lntyprepyforceqlrepayflg) {
		this.lntyprepyforceqlrepayflg = lntyprepyforceqlrepayflg;
	}

	public BigDecimal getLntyprepyintfreqflg() {
		return this.lntyprepyintfreqflg;
	}

	public void setLntyprepyintfreqflg(BigDecimal lntyprepyintfreqflg) {
		this.lntyprepyintfreqflg = lntyprepyintfreqflg;
	}

	public String getLntyprepyintratetype() {
		return this.lntyprepyintratetype;
	}

	public void setLntyprepyintratetype(String lntyprepyintratetype) {
		this.lntyprepyintratetype = lntyprepyintratetype;
	}

	public String getLntyprepymethod() {
		return this.lntyprepymethod;
	}

	public void setLntyprepymethod(String lntyprepymethod) {
		this.lntyprepymethod = lntyprepymethod;
	}

	public String getLntyprepypartrepyschchg() {
		return this.lntyprepypartrepyschchg;
	}

	public void setLntyprepypartrepyschchg(String lntyprepypartrepyschchg) {
		this.lntyprepypartrepyschchg = lntyprepypartrepyschchg;
	}

	public String getLntyprepyschmethod() {
		return this.lntyprepyschmethod;
	}

	public void setLntyprepyschmethod(String lntyprepyschmethod) {
		this.lntyprepyschmethod = lntyprepyschmethod;
	}

	public String getLntypreviewrtapplied() {
		return this.lntypreviewrtapplied;
	}

	public void setLntypreviewrtapplied(String lntypreviewrtapplied) {
		this.lntypreviewrtapplied = lntypreviewrtapplied;
	}

	public String getLntypschcalcreview() {
		return this.lntypschcalcreview;
	}

	public void setLntypschcalcreview(String lntypschcalcreview) {
		this.lntypschcalcreview = lntypschcalcreview;
	}

	public String getLntypsuspremark() {
		return this.lntypsuspremark;
	}

	public void setLntypsuspremark(String lntypsuspremark) {
		this.lntypsuspremark = lntypsuspremark;
	}

	public String getLntypsusptonormal() {
		return this.lntypsusptonormal;
	}

	public void setLntypsusptonormal(String lntypsusptonormal) {
		this.lntypsusptonormal = lntypsusptonormal;
	}

	public String getLntypsusptopd() {
		return this.lntypsusptopd;
	}

	public void setLntypsusptopd(String lntypsusptopd) {
		this.lntypsusptopd = lntypsusptopd;
	}

	public String getLntypsusptrigger() {
		return this.lntypsusptrigger;
	}

	public void setLntypsusptrigger(String lntypsusptrigger) {
		this.lntypsusptrigger = lntypsusptrigger;
	}

	public String getLoantype() {
		return this.loantype;
	}

	public void setLoantype(String loantype) {
		this.loantype = loantype;
	}

//	public List<LoanApplication> getLoanApplications() {
//		return this.loanApplications;
//	}
//
//	public void setLoanApplications(List<LoanApplication> loanApplications) {
//		this.loanApplications = loanApplications;
//	}
//
//	public LoanApplication addLoanApplication(LoanApplication loanApplication) {
//		getLoanApplications().add(loanApplication);
//		loanApplication.setLoanProductType(this);
//
//		return loanApplication;
//	}
//
//	public LoanApplication removeLoanApplication(LoanApplication loanApplication) {
//		getLoanApplications().remove(loanApplication);
//		loanApplication.setLoanProductType(null);
//
//		return loanApplication;
//	}
//
//	public LoanProduct getLoanProduct() {
//		return this.loanProduct;
//	}
//
//	public void setLoanProduct(LoanProduct loanProduct) {
//		this.loanProduct = loanProduct;
//	}
//
//	public List<LoanRepayScheduleType> getLoanRepayScheduleTypes() {
//		return this.loanRepayScheduleTypes;
//	}
//
//	public void setLoanRepayScheduleTypes(List<LoanRepayScheduleType> loanRepayScheduleTypes) {
//		this.loanRepayScheduleTypes = loanRepayScheduleTypes;
//	}
//
//	public LoanRepayScheduleType addLoanRepayScheduleType(LoanRepayScheduleType loanRepayScheduleType) {
//		getLoanRepayScheduleTypes().add(loanRepayScheduleType);
//		loanRepayScheduleType.setLoanProductType(this);
//
//		return loanRepayScheduleType;
//	}
//
//	public LoanRepayScheduleType removeLoanRepayScheduleType(LoanRepayScheduleType loanRepayScheduleType) {
//		getLoanRepayScheduleTypes().remove(loanRepayScheduleType);
//		loanRepayScheduleType.setLoanProductType(null);
//
//		return loanRepayScheduleType;
//	}

}