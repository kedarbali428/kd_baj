package com.bajaj.bfsd.loanaccount.bean;

public class LoanCustomerRequestBean {
	
	private String cif;

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	
	
	

}
