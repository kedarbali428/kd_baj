package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the APPLICANT_LIMIT_PRODUCTS database table.
 * 
 */
@Entity
@Table(name="APPLICANT_LIMIT_PRODUCTS")
@NamedQuery(name="ApplicantLimitProduct.findAll", query="SELECT a FROM ApplicantLimitProduct a")
public class ApplicantLimitProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long apltlimitprodkey;

	private BigDecimal alblockamt;

	private Timestamp alblockdt;

	@Temporal(TemporalType.DATE)
	private Date alblockenddt;

	private BigDecimal alblockflg;

	@Temporal(TemporalType.DATE)
	private Date alblockstartdt;

	private BigDecimal aleligibilityamt;

	private BigDecimal alisactive;

	@Temporal(TemporalType.DATE)
	private Date allstlimitcalcdt;

	private String allstupdateby;

	private Timestamp allstupdatedt;

	private BigDecimal alnetavblbal;

	private BigDecimal alutilizedamt;

	//bi-directional many-to-one association to ApplicantLimit
	@ManyToOne
	@JoinColumn(name="APLTLIMITKEY")
	private ApplicantLimit applicantLimit;

	//bi-directional many-to-one association to ProductCategory
	@ManyToOne
	@JoinColumn(name="PRODCATKEY")
	private ProductCategory productCategory;

	public ApplicantLimitProduct() {
	}

	public long getApltlimitprodkey() {
		return this.apltlimitprodkey;
	}

	public void setApltlimitprodkey(long apltlimitprodkey) {
		this.apltlimitprodkey = apltlimitprodkey;
	}

	public BigDecimal getAlblockamt() {
		return this.alblockamt;
	}

	public void setAlblockamt(BigDecimal alblockamt) {
		this.alblockamt = alblockamt;
	}

	public Timestamp getAlblockdt() {
		return this.alblockdt;
	}

	public void setAlblockdt(Timestamp alblockdt) {
		this.alblockdt = alblockdt;
	}

	public Date getAlblockenddt() {
		return this.alblockenddt;
	}

	public void setAlblockenddt(Date alblockenddt) {
		this.alblockenddt = alblockenddt;
	}

	public BigDecimal getAlblockflg() {
		return this.alblockflg;
	}

	public void setAlblockflg(BigDecimal alblockflg) {
		this.alblockflg = alblockflg;
	}

	public Date getAlblockstartdt() {
		return this.alblockstartdt;
	}

	public void setAlblockstartdt(Date alblockstartdt) {
		this.alblockstartdt = alblockstartdt;
	}

	public BigDecimal getAleligibilityamt() {
		return this.aleligibilityamt;
	}

	public void setAleligibilityamt(BigDecimal aleligibilityamt) {
		this.aleligibilityamt = aleligibilityamt;
	}

	public BigDecimal getAlisactive() {
		return this.alisactive;
	}

	public void setAlisactive(BigDecimal alisactive) {
		this.alisactive = alisactive;
	}

	public Date getAllstlimitcalcdt() {
		return this.allstlimitcalcdt;
	}

	public void setAllstlimitcalcdt(Date allstlimitcalcdt) {
		this.allstlimitcalcdt = allstlimitcalcdt;
	}

	public String getAllstupdateby() {
		return this.allstupdateby;
	}

	public void setAllstupdateby(String allstupdateby) {
		this.allstupdateby = allstupdateby;
	}

	public Timestamp getAllstupdatedt() {
		return this.allstupdatedt;
	}

	public void setAllstupdatedt(Timestamp allstupdatedt) {
		this.allstupdatedt = allstupdatedt;
	}

	public BigDecimal getAlnetavblbal() {
		return this.alnetavblbal;
	}

	public void setAlnetavblbal(BigDecimal alnetavblbal) {
		this.alnetavblbal = alnetavblbal;
	}

	public BigDecimal getAlutilizedamt() {
		return this.alutilizedamt;
	}

	public void setAlutilizedamt(BigDecimal alutilizedamt) {
		this.alutilizedamt = alutilizedamt;
	}

	public ApplicantLimit getApplicantLimit() {
		return this.applicantLimit;
	}

	public void setApplicantLimit(ApplicantLimit applicantLimit) {
		this.applicantLimit = applicantLimit;
	}

	public ProductCategory getProductCategory() {
		return this.productCategory;
	}

	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}

}