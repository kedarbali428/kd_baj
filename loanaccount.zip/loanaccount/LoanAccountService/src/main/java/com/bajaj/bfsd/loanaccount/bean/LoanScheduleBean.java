package com.bajaj.bfsd.loanaccount.bean;

import java.util.List;

public class LoanScheduleBean {

	private LoanDetailBean financeDetail;
	
	private List<ScheduleBean> schedule;
	
	private ScheduleSummaryBean summary;
	
	private List<FeeBean> fees;

	public LoanDetailBean getFinanceDetail() {
		return financeDetail;
	}

	public void setFinanceDetail(LoanDetailBean financeDetail) {
		this.financeDetail = financeDetail;
	}

	public List<ScheduleBean> getSchedule() {
		return schedule;
	}

	public void setSchedule(List<ScheduleBean> schedule) {
		this.schedule = schedule;
	}

	public ScheduleSummaryBean getSummary() {
		return summary;
	}

	public void setSummary(ScheduleSummaryBean summary) {
		this.summary = summary;
	}

	public List<FeeBean> getFees() {
		return fees;
	}

	public void setFees(List<FeeBean> fees) {
		this.fees = fees;
	}

	

	//insurance and step are not supported by pennant yet so not added here.
	
}
