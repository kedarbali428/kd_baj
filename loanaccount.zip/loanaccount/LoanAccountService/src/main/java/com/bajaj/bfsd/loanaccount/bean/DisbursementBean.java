package com.bajaj.bfsd.loanaccount.bean;

public class DisbursementBean {

	private String disbursementParty;
	
	private String disbursementType;
	
	private String disbursementDate;
	
	private Double disbursementAmount;
	
	private String bankCode;
	
	private String bankName;
	
	private String ifscCode;

	private String branchCode;
	
	private String accountNo;
	
	private String accountHolderName;
	
	private String phoneNumber;

	private String description;
	
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisbursementParty() {
		return disbursementParty;
	}

	public void setDisbursementParty(String disbursementParty) {
		this.disbursementParty = disbursementParty;
	}

	public String getDisbursementType() {
		return disbursementType;
	}

	public void setDisbursementType(String disbursementType) {
		this.disbursementType = disbursementType;
	}

	public String getDisbursementDate() {
		return disbursementDate;
	}

	public void setDisbursementDate(String disbursementDate) {
		this.disbursementDate = disbursementDate;
	}

	public Double getDisbursementAmount() {
		return disbursementAmount;
	}

	public void setDisbursementAmount(Double disbursementAmount) {
		this.disbursementAmount = disbursementAmount;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	@Override
	public String toString() {
		return "DisbursementBean [disbursementParty=" + disbursementParty + ", disbursementType=" + disbursementType
				+ ", disbursementDate=" + disbursementDate + ", disbursementAmount=" + disbursementAmount
				+ ", bankCode=" + bankCode + ", branchCode=" + branchCode + ", accountNo=" + accountNo
				+ ", bankName=" + bankName + ", ifscCode=" + ifscCode
				+ ", accountHolderName=" + accountHolderName + ", phoneNumber=" + phoneNumber + "]";
	}
	
}
