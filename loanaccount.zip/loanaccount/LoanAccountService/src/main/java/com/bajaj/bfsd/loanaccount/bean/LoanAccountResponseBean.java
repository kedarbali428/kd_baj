package com.bajaj.bfsd.loanaccount.bean;

import java.util.List;

public class LoanAccountResponseBean {
	
	private Integer totalLoans;
	
	private List<LoanDetailBean> loanDetails;
	
	private Number totalLoanAmount;
	
	private Number totalOutstandingAmount;
	
	private Number totalEmiAmount;
	
    private List<String>  loanAcctNumbers;
    
    private String mobileNumber;
    
    private String emailID;
        
	private String returnCode;
	
	private String returnText;
	
	private String eventType;
	
	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Integer getTotalLoans() {
		return totalLoans;
	}

	public void setTotalLoans(Integer totalLoans) {
		this.totalLoans = totalLoans;
	}

	public List<LoanDetailBean> getLoanDetails() {
		return loanDetails;
	}

	public void setLoanDetails(List<LoanDetailBean> loanDetails) {
		this.loanDetails = loanDetails;
	}

	public Number getTotalLoanAmount() {
		return totalLoanAmount;
	}

	public void setTotalLoanAmount(Number totalLoanAmount) {
		this.totalLoanAmount = totalLoanAmount;
	}

	public Number getTotalOutstandingAmount() {
		return totalOutstandingAmount;
	}

	public void setTotalOutstandingAmount(Number totalOutstandingAmount) {
		this.totalOutstandingAmount = totalOutstandingAmount;
	}

	public Number getTotalEmiAmount() {
		return totalEmiAmount;
	}

	public void setTotalEmiAmount(Number totalEmiAmount) {
		this.totalEmiAmount = totalEmiAmount;
	}

	public List<String> getLoanAcctNumbers() {
		return loanAcctNumbers;
	}

	public void setLoanAcctNumbers(List<String> loanAcctNumbers) {
		this.loanAcctNumbers = loanAcctNumbers;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnText() {
		return returnText;
	}

	public void setReturnText(String returnText) {
		this.returnText = returnText;
	}

	@Override
	public String toString() {
		return "LoanAccountResponseBean [totalLoans=" + totalLoans + ", loanDetails=" + loanDetails
				+ ", totalLoanAmount=" + totalLoanAmount + ", totalOutstandingAmount=" + totalOutstandingAmount
				+ ", totalEmiAmount=" + totalEmiAmount + "]";
	}
	
}
