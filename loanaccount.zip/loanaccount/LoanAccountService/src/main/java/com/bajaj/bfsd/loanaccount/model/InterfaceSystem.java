package com.bajaj.bfsd.loanaccount.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the INTERFACE_SYSTEMS database table.
 * 
 */
@Entity
@Table(name="INTERFACE_SYSTEMS")
@NamedQuery(name="InterfaceSystem.findAll", query="SELECT i FROM InterfaceSystem i")
public class InterfaceSystem implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long systemkey;

	private String systemcode;

	private BigDecimal systemisactive;

	private String systemlstupdateby;

	private Timestamp systemlstupdatedt;

	private String systemname;

	public long getSystemkey() {
		return systemkey;
	}

	public void setSystemkey(long systemkey) {
		this.systemkey = systemkey;
	}

	public String getSystemcode() {
		return systemcode;
	}

	public void setSystemcode(String systemcode) {
		this.systemcode = systemcode;
	}

	public BigDecimal getSystemisactive() {
		return systemisactive;
	}

	public void setSystemisactive(BigDecimal systemisactive) {
		this.systemisactive = systemisactive;
	}

	public String getSystemlstupdateby() {
		return systemlstupdateby;
	}

	public void setSystemlstupdateby(String systemlstupdateby) {
		this.systemlstupdateby = systemlstupdateby;
	}

	public Timestamp getSystemlstupdatedt() {
		return systemlstupdatedt;
	}

	public void setSystemlstupdatedt(Timestamp systemlstupdatedt) {
		this.systemlstupdatedt = systemlstupdatedt;
	}

	public String getSystemname() {
		return systemname;
	}

	public void setSystemname(String systemname) {
		this.systemname = systemname;
	}

}