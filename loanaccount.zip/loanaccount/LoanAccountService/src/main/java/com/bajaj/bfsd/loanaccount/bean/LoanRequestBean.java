package com.bajaj.bfsd.loanaccount.bean;

public class LoanRequestBean {
	
	private String finReference;

	public String getFinReference() {
		return finReference;
	}

	public void setFinReference(String finReference) {
		this.finReference = finReference;
	}

	
	
	
	

}
