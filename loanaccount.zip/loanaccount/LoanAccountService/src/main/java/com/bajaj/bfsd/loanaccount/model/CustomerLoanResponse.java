package com.bajaj.bfsd.loanaccount.model;

import java.util.List;

public class CustomerLoanResponse {

   private List<Loan> finances;
   
   private ReturnStatus returnStatus;

public List<Loan> getFinances() {
	return finances;
}

public void setFinances(List<Loan> finances) {
	this.finances = finances;
}

public ReturnStatus getReturnStatus() {
	return returnStatus;
}

public void setReturnStatus(ReturnStatus returnStatus) {
	this.returnStatus = returnStatus;
}
	

}
