package com.bajaj.bfsd.loanaccount.model;

import java.util.List;

public class ExtendedDetails {


	private List<ExtendedFields>extendedFields;

	public List<ExtendedFields> getExtendedFields() {
		return extendedFields;
	}

	public void setExtendedFields(List<ExtendedFields> extendedFields) {
		this.extendedFields = extendedFields;
	}




}
