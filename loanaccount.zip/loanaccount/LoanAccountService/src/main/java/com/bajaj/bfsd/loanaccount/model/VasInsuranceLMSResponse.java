package com.bajaj.bfsd.loanaccount.model;

import java.util.List;

public class VasInsuranceLMSResponse {

	private List<VasDetail> vasDetails;
	
	private ReturnStatus returnStatus;

	public List<VasDetail> getVasDetails() {
		return vasDetails;
	}

	public void setVasDetails(List<VasDetail> vasDetails) {
		this.vasDetails = vasDetails;
	}

	public ReturnStatus getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(ReturnStatus returnStatus) {
		this.returnStatus = returnStatus;
	}

	@Override
	public String toString() {
		return "VasInsuranceLMSResponse [vasDetails=" + vasDetails + ", returnStatus=" + returnStatus + "]";
	}
	
}
