package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the VAS_PRODUCT_PLANS database table.
 * 
 */
@Entity
@Table(name="VAS_PRODUCT_PLANS")
@NamedQuery(name="VasProductPlan.findAll", query="SELECT v FROM VasProductPlan v")
public class VasProductPlan implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long vasprodplankey;

	private BigDecimal vpisactive;

	private String vplstupdateby;

	private Timestamp vplstupdatedt;

	private String vpproductcode;

	private String vpproductdesc;

	//bi-directional many-to-one association to VasApplication
	@OneToMany(mappedBy="vasProductPlan")
	private List<VasApplication> vasApplications;

	//bi-directional many-to-one association to VasProductType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="VASPRODTYPEKEY")
	private VasProductType vasProductType;

	//bi-directional many-to-one association to VasProvider
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="VASPROVIDERKEY")
	private VasProvider vasProvider;

	public VasProductPlan() {
	}

	public long getVasprodplankey() {
		return vasprodplankey;
	}

	public void setVasprodplankey(long vasprodplankey) {
		this.vasprodplankey = vasprodplankey;
	}

	public BigDecimal getVpisactive() {
		return this.vpisactive;
	}

	public void setVpisactive(BigDecimal vpisactive) {
		this.vpisactive = vpisactive;
	}

	public String getVplstupdateby() {
		return this.vplstupdateby;
	}

	public void setVplstupdateby(String vplstupdateby) {
		this.vplstupdateby = vplstupdateby;
	}

	public Timestamp getVplstupdatedt() {
		return this.vplstupdatedt;
	}

	public void setVplstupdatedt(Timestamp vplstupdatedt) {
		this.vplstupdatedt = vplstupdatedt;
	}

	public String getVpproductcode() {
		return this.vpproductcode;
	}

	public void setVpproductcode(String vpproductcode) {
		this.vpproductcode = vpproductcode;
	}

	public String getVpproductdesc() {
		return this.vpproductdesc;
	}

	public void setVpproductdesc(String vpproductdesc) {
		this.vpproductdesc = vpproductdesc;
	}

	public List<VasApplication> getVasApplications() {
		return this.vasApplications;
	}

	public void setVasApplications(List<VasApplication> vasApplications) {
		this.vasApplications = vasApplications;
	}

	public VasApplication addVasApplication(VasApplication vasApplication) {
		getVasApplications().add(vasApplication);
		vasApplication.setVasProductPlan(this);

		return vasApplication;
	}

	public VasApplication removeVasApplication(VasApplication vasApplication) {
		getVasApplications().remove(vasApplication);
		vasApplication.setVasProductPlan(null);

		return vasApplication;
	}

	public VasProductType getVasProductType() {
		return this.vasProductType;
	}

	public void setVasProductType(VasProductType vasProductType) {
		this.vasProductType = vasProductType;
	}

	public VasProvider getVasProvider() {
		return this.vasProvider;
	}

	public void setVasProvider(VasProvider vasProvider) {
		this.vasProvider = vasProvider;
	}

}