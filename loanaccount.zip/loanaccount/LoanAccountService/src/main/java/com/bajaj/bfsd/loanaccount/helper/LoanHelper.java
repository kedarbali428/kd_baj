package com.bajaj.bfsd.loanaccount.helper;

import static com.bajaj.bfsd.loanaccount.util.LoanAccountConstants.COLLATERALREF;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import javax.enterprise.context.RequestScoped;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtil;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.bean.AdvanceEMIBean;
import com.bajaj.bfsd.loanaccount.bean.CollateralRequestBean;
import com.bajaj.bfsd.loanaccount.bean.DisbursementBean;
import com.bajaj.bfsd.loanaccount.bean.FeeBean;
import com.bajaj.bfsd.loanaccount.bean.LmsRequestBean;
import com.bajaj.bfsd.loanaccount.bean.LoanCollatoralResponseBean;
import com.bajaj.bfsd.loanaccount.bean.LoanDetailBean;
import com.bajaj.bfsd.loanaccount.bean.LoanDetailResponseBean;
import com.bajaj.bfsd.loanaccount.bean.LoanRequestBean;
import com.bajaj.bfsd.loanaccount.bean.LoanScheduleBean;
import com.bajaj.bfsd.loanaccount.bean.OverdueSummaryBean;
import com.bajaj.bfsd.loanaccount.bean.ScheduleSummaryBean;
import com.bajaj.bfsd.loanaccount.config.MapperFactory;
import com.bajaj.bfsd.loanaccount.dao.FeeDetailDao;
import com.bajaj.bfsd.loanaccount.dao.ProductDao;
import com.bajaj.bfsd.loanaccount.model.Disbursement;
import com.bajaj.bfsd.loanaccount.model.Fee;
import com.bajaj.bfsd.loanaccount.model.FeesType;
import com.bajaj.bfsd.loanaccount.model.LoanCollatoralResponse;
import com.bajaj.bfsd.loanaccount.model.LoanDetail;
import com.bajaj.bfsd.loanaccount.model.LoanResponse;
import com.bajaj.bfsd.loanaccount.model.OverdueSummary;
import com.bajaj.bfsd.loanaccount.model.ScheduleSummary;
import com.bajaj.bfsd.loanaccount.service.impl.LoanAccountServiceImpl;
import com.bajaj.bfsd.loanaccount.util.LoanAccountConstants;
import com.bajaj.bfsd.loanaccount.util.LoanAccountUtil;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RefreshScope
@Component
public class LoanHelper extends BFLComponent  {
	
    private static final String THIS_CLASS = LoanAccountServiceImpl.class.getSimpleName();

	@Value("${resource-path-pennant-loan-lanno}")
	private String  resourcePathValueGetLoanByLanNo;	
	
	@Value("${resource-path-pennant-loan-collateral}")
	private String  resourcePathValueGetLoanCollateral;	
	
	@Value("${pennant-authorization}")
	private String authorizationKey;
  
	@Autowired
    private BFLLoggerUtilExt logger;
	
	@Value("${LimitMonth}")
    private Integer underlimit;
	
	@Value("${FreezePeriod}")
    private Integer freezeperiod;
	
	@Value("${LOAN_001}")
    private String errorCodeLOAN;
	
	@Autowired
	private FeeDetailDao feeDetailDao;
	
	@Autowired
	private ProductDao productDao;
	
	@Autowired
    private AsyncClass asyncClass;
	
	@Autowired
	Environment env; 
	
	@Autowired
	LoanAccountUtil loanAccountUtil;
	
	@Value("${advEmiNum}")
	private int advEmiNum;
	
	@Value("${hfc.pennant.productcodes}")
	private String hfcProductCodes;
	
	
	private static final String CLASS_NAME = LoanHelper.class.getName();
	
	public LoanDetailResponseBean getLoanDetailByLanNo(String lanNo,String loanProduct)
	{
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside  getLoanDetailByLanNo() in loanHelper with LAN number--> "+lanNo);
		LoanDetailResponseBean loanDetailResponseBean = null;
		LoanResponse loanResponse = getLoanDetailsByLanNOFromPennantLMS(lanNo,loanProduct); // get Response from pennant as String
	  	if(null!= loanResponse && "0000".equals(loanResponse.getReturnStatus().getReturnCode()))
	  	{
	  			//loanResponse.setCollateralRef("CT1509900001"); //FIX ME
	  			loanDetailResponseBean = prepareLMSResponseForLoanDetail(loanResponse);
	  	}else if(null!=loanResponse && null!=loanResponse.getReturnStatus() && null!=loanResponse.getReturnStatus().getReturnCode() && null!=loanResponse.getReturnStatus().getReturnText()){
	  		loanDetailResponseBean = new LoanDetailResponseBean();
  			loanDetailResponseBean.setReturnCode(loanResponse.getReturnStatus().getReturnCode());
  			loanDetailResponseBean.setReturnText(loanResponse.getReturnStatus().getReturnText());
  			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Pennant Return error code and message"+loanResponse.getReturnStatus().getReturnCode());
  			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Pennant Return error code and message"+loanResponse.getReturnStatus().getReturnText());

	  	}	
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Final getLoanDetailByLanNo() in loanHelper"+loanDetailResponseBean);
		return loanDetailResponseBean;
	}
	
	private LoanDetailResponseBean prepareLMSResponseForLoanDetail(LoanResponse loanResponse) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside  prepareLMSResponseForLoanDetail() in loanHelper");
		LoanDetailResponseBean loanDetailResponseBean = new LoanDetailResponseBean();
		LoanScheduleBean financeDetailBean = null;
		loanDetailResponseBean.setLoanAcctNumber(loanResponse.getFinReference());
		if(null!=loanResponse.getFinanceSchedule())
		{
			LoanDetail financeDetail = loanResponse.getFinanceSchedule().getFinanceDetail();
			if(null!=financeDetail)
			{
				financeDetailBean = setFinanceDetailBeanData(financeDetail,loanResponse);
				if(null!=loanResponse.getFinanceSchedule().getSummary())
		        {
					financeDetailBean.setSummary(setSummaryData(loanResponse.getFinanceSchedule().getSummary()));
		        }
				if(null!=loanResponse.getFees() && !loanResponse.getFees().isEmpty())
				{
					financeDetailBean.setFees(setFeesDetails(loanResponse.getFees()));
				}
			}
			if(null!=loanResponse.getDisbursement() && !loanResponse.getDisbursement().isEmpty())
			{
				loanDetailResponseBean.setDisbursementBean(this.setDisbursementBeanData(loanResponse.getDisbursement()));
			}
		}
		/*if(null!=loanResponse.getCollaterals() && !loanResponse.getCollaterals().isEmpty()) //if found collatoralId then found linked loans
		{
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Pennant Return Collatorals ");
			//call lms api to get linked loan details
			List<Collateral> collaterals = loanResponse.getCollaterals();
			String loanNumber = loanResponse.getFinReference();
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Pennant Return Collatorals size"+collaterals.size());
			List<Future<LoanCollatoralResponseBean>> futures = new ArrayList<>();
			for (Collateral collateral : collaterals) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Collatorel ID or CollateralRef"+collateral.getCollateralRef());
				futures.add(asyncClass.getLoanCollateralLinkedLoanDetailsFromPennant(collateral.getCollateralRef(),loanNumber));
			}
			for(Future<LoanCollatoralResponseBean> future: futures) {
				try {
					while(!future.isDone()) {
						Thread.sleep(1);
					}
					LoanCollatoralResponseBean loanCollateral = future.get();
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "loanCollaterals details:"+loanCollateral);
					loanDetailResponseBean.setCollatoralResponseBean(loanCollateral);//TODO:should add to a list
				} catch(Exception e) {
					logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exception while getting Loan Details By Lan No", e);
					throw new BFLBusinessException("LOAN_02", "Exception while getting Loan Details By Lan No from Penant");
				}			
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exit if Loop loanCollaterals");
		}*/
		loanDetailResponseBean.setFinanceDetail(financeDetailBean);
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "final return by  prepareLMSResponseForLoanDetail() in loanHelper"+loanDetailResponseBean);
		return loanDetailResponseBean;
	}

	private List<FeeBean> setFeesDetails(List<Fee> fees) {
		List<FeeBean> feesDetails = new ArrayList<>();
		for (Fee fee : fees) {
				FeeBean feeBean = new FeeBean();
				feeBean.setFeeCategory(fee.getFeeCategory());
				feeBean.setFeeAmount(fee.getFeeAmount());
				feeBean.setFeeCode(fee.getFeeCode());
				if(null!=fee.getFeeCode())
				{
					feeBean.setFeeDescription(setFeeDescription(fee.getFeeCode()));
				}
				if(null==fee.getFeeCode() && null!=fee.getFeeCategory())
				{
					feeBean.setFeeDescription(setFeeDescription(fee.getFeeCategory()));
				}
				feeBean.setFeeMethod(fee.getFeeMethod());
				feeBean.setScheduleTerms(fee.getScheduleTerms());
				feeBean.setFeeBalanceAmount(fee.getFeeBalance());
				feeBean.setPaidAmount(fee.getPaidAmount());
				feeBean.setSchdDate(fee.getSchdDate());
				if((null!=fee.getFeeCode() && !fee.getFeeCode().startsWith("VAS")) || (null!=fee.getFeeCategory() && !fee.getFeeCategory().startsWith("VAS")))
				{
					feesDetails.add(feeBean);
				}
		}
		return feesDetails;
	}

	private String setFeeDescription(String feeCode) {
		String description = null;
		FeesType feeType = feeDetailDao.getFeeDetailsByFeeCode(feeCode);
		if(null!=feeType && null!= feeType.getFeedesc() && StringUtils.isNotBlank(feeType.getFeedesc()))
		{
			description = feeType.getFeedesc();
		}
		return description;
    }

	private List<DisbursementBean> setDisbursementBeanData(List<Disbursement> disbursement) {
		List<DisbursementBean> disbursements = new ArrayList<>();
		DisbursementBean disbursementBean = null;
		int count = 1;
		for (Disbursement disbursementDetail : disbursement) {
			if(null!=disbursementDetail)
			{
				disbursementBean= new DisbursementBean();
				disbursementBean.setAccountHolderName(disbursementDetail.getAcHolderName());
				disbursementBean.setAccountNo(disbursementDetail.getAccountNo());
				disbursementBean.setBankCode(disbursementDetail.getBankCode());
				disbursementBean.setBranchCode(disbursementDetail.getBranchCode());
				disbursementBean.setDisbursementAmount(disbursementDetail.getDisbAmount());
				disbursementBean.setDisbursementDate(disbursementDetail.getDisbDate());
				disbursementBean.setDisbursementType(disbursementDetail.getDisbType());
				disbursementBean.setDisbursementParty(disbursementDetail.getDisbParty());
				disbursementBean.setIfscCode(disbursementDetail.getIfsc());
				if("VIJB0001551".equals(disbursementDetail.getIfsc()))
				{
					disbursementBean.setBankName("VIJAYA BANK");
				}
				disbursementBean.setPhoneNumber(disbursementDetail.getPhoneNumber());
				disbursementBean.setDescription("tranche "+count);
				count++;
			}
			disbursements.add(disbursementBean);
		}
		return disbursements;
	}

	private ScheduleSummaryBean setSummaryData(ScheduleSummary summary) {
		ScheduleSummaryBean summaryBean = new ScheduleSummaryBean();
		summaryBean.setAdvPaymentAmount(summary.getAdvPaymentAmount());
		summaryBean.setEffectiveRateOfReturn(summary.getEffectiveRateOfReturn());
		summaryBean.setFeeChargeAmt(summary.getFeeChargeAmt());
		summaryBean.setFinActiveStatus(summary.getFinActiveStatus());
		summaryBean.setFirstEmiAmount(summary.getFirstEmiAmount());
		summaryBean.setFirstInstDate(summary.getFirstInstDate());
		summaryBean.setFullyDisb(summary.getFullyDisb());
		summaryBean.setFutureInst(summary.getFutureInst());
		summaryBean.setFutureTenor(summary.getFutureTenor());
		summaryBean.setLastRepayDate(summary.getLastRepayDate());
		summaryBean.setMaturityDate(summary.getMaturityDate());
		summaryBean.setNextSchDate(summary.getNextSchDate());
		summaryBean.setNumberOfTerms(summary.getNumberOfTerms());
		summaryBean.setOutstandingPft(summary.getOutstandingPft());
		summaryBean.setOutstandingPri(summary.getOutstandingPri());
		summaryBean.setOutstandingTotal(summary.getOutstandingTotal());
		summaryBean.setOverdueInst(summary.getOverdueInst());
		summaryBean.setOverduePft(summary.getOverduePft());
		summaryBean.setOverduePri(summary.getOverduePri());
		summaryBean.setOverdueTotal(summary.getOverdueTotal());
		summaryBean.setPaidPft(summary.getPaidPft());
		summaryBean.setPaidPri(summary.getPaidPri());
		summaryBean.setPaidTotal(summary.getPaidTotal());
		summaryBean.setTotalGracePft(summary.getTotalGracePft());
		summaryBean.setTotalGrossGrcPft(summary.getTotalGrossGrcPft());
		summaryBean.setLoanTenor(summary.getLoanTenor());
		summaryBean.setGraceInst(summary.getGraceInst());
		summaryBean.setFutureGraceInst(summary.getFutureGraceInst());
		summaryBean.setNoPaidInst(summary.getNoPaidInst());
		summaryBean.setTotalProfit(summary.getTotalGracePft());
		setFlexiDetails(summaryBean,summary);
		if(null!= summary.getOverdueCharges() && !summary.getOverdueCharges().isEmpty())
		{
			List<OverdueSummaryBean> overdueSummaryBeans = new ArrayList<>();
			OverdueSummaryBean overdueSummaryBean;
			List<OverdueSummary> overdues = summary.getOverdueCharges();
			for (OverdueSummary overdueSummary : overdues) {
				overdueSummaryBean = new OverdueSummaryBean();
				overdueSummaryBean.setOverdueChargeAmount(overdueSummary.getOdCharge());
				overdueSummaryBean.setSchdDate(overdueSummary.getOdDate());
				overdueSummaryBean.setOverdueChargePaid(overdueSummary.getOdChargePaid());
				overdueSummaryBean.setOverdueInterestPaid(overdueSummary.getOdPftPaid());
				overdueSummaryBean.setOverdueInterestAmount(overdueSummary.getOdPft());
				overdueSummaryBean.setOverdueAmount(overdueSummary.getOdAmount());
				overdueSummaryBeans.add(overdueSummaryBean);
			}
			summaryBean.setOverdueCharge(overdueSummaryBeans);
		}
		if(null!= summary.getAdvEmi() && !summary.getAdvEmi().isEmpty())
		{
			List<AdvanceEMIBean> advanceEMIBeans = new ArrayList<>();
			AdvanceEMIBean advanceEMIBean;
			List<AdvanceEMIBean> advEmis = summary.getAdvEmi();
			
			for (int i=0;i<advEmiNum;i++) {
				if(i<advEmis.size()){
				AdvanceEMIBean emiBean=advEmis.get(i);
				advanceEMIBean = new AdvanceEMIBean();
				advanceEMIBean.setInstAmount(loanAccountUtil.convertRstoPaisa(emiBean.getInstAmount()));
				advanceEMIBean.setInstNo(emiBean.getInstNo());
				
				advanceEMIBeans.add(advanceEMIBean);
				}
			}
			summaryBean.setAdvanceEMIs(advanceEMIBeans);
		}
		return summaryBean;
	}

	private void setFlexiDetails(ScheduleSummaryBean summaryBean, ScheduleSummary summary) {
		if(null!=summary.getCurrentDroplineLimit())
		{
			summaryBean.setCurrentDroplineLimit(summary.getCurrentDroplineLimit());
		}
		if(null!=summary.getUtilisation())
		{
			summaryBean.setUtilisation(summary.getUtilisation());
		}
		if(null!=summary.getAvailableLimit())
		{
			summaryBean.setAvailableLimit(summary.getAvailableLimit());
		}
	}

	private LoanScheduleBean setFinanceDetailBeanData(LoanDetail financeDetail,LoanResponse loanResponse) {
		LoanScheduleBean financeDetailBean = new LoanScheduleBean();
		LoanDetailBean loanDetailBean = new LoanDetailBean();
		loanDetailBean.setLoanType(financeDetail.getFinType());
		loanDetailBean.setLoanAmount(financeDetail.getFinAssetValue());
		loanDetailBean.setOutstandingLoanAmount(loanResponse.getFinanceSchedule().getSummary().getOutstandingPri());
		loanDetailBean.setEmiAmount(loanResponse.getFinanceSchedule().getSummary().getNextRepayAmount()); 
		loanDetailBean.setRemainingTenure(loanResponse.getFinanceSchedule().getSummary().getFutureInst().intValue());
		loanDetailBean.setTotalEmi(loanResponse.getFinanceSchedule().getSummary().getNumberOfTerms().intValue());
		loanDetailBean.setDisbursementDate(loanResponse.getFinanceSchedule().getSummary().getFirstDisbDate());
		loanDetailBean.setRoi(loanResponse.getFinanceSchedule().getFinanceDetail().getRepayPftRate());
		//ROI Impln if it is 0 for getRepayPftRate
		if(null!=loanResponse.getFinanceSchedule().getFinanceDetail())
		 {
				if(null!=loanResponse.getFinanceSchedule().getFinanceDetail().getFinStartDate())
				{
					loanDetailBean.setLoanStartDate(loanResponse.getFinanceSchedule().getFinanceDetail().getFinStartDate());
				}
				loanDetailBean.setDisbursementDate(loanResponse.getFinanceSchedule().getFinanceDetail().getFinStartDate());
				loanDetailBean.setEMICylceDate(Long.parseLong(loanResponse.getFinanceSchedule().getFinanceDetail().getRepayFrq().substring(3)));
				//repayFrq -M0001 -- Need to check and convert this emi cycle date as current month and day e.g M0001 - 01/03/2017 
				//FIX ME
				loanDetailBean.setRepaymentMode(loanResponse.getFinanceSchedule().getFinanceDetail().getFinRepayMethod());
				if(null!=loanResponse.getFinanceSchedule().getFinanceDetail().getNextRepayDate())
				{
					loanDetailBean.setNextEmiDate(loanResponse.getFinanceSchedule().getFinanceDetail().getNextRepayDate());
				}
				if(null!=loanResponse.getFinanceSchedule().getFinanceDetail().getApplicationNo())
				{
					loanDetailBean.setApplicationNo(loanResponse.getFinanceSchedule().getFinanceDetail().getApplicationNo());
				}

			}
			if(null!=loanResponse.getFinanceSchedule().getSummary())
			{
				loanDetailBean.setOverdueEMIAmount(loanResponse.getFinanceSchedule().getSummary().getOverdueTotal());
				loanDetailBean.setLastEMIDate(loanResponse.getFinanceSchedule().getSummary().getMaturityDate());
				// Repay Method suppose to convert to string by DB map 
				loanDetailBean.setTotalEMIReceived(loanResponse.getFinanceSchedule().getSummary().getPaidTotal());
				loanDetailBean.setLoanPaidAmount(loanResponse.getFinanceSchedule().getSummary().getPaidPri().doubleValue());
			}
			if(null!=loanResponse.getFinanceSchedule() && null!=loanResponse.getFinanceSchedule().getFinanceDetail().getFinAssetValue())
			{
				loanDetailBean.setTotalLimit(loanResponse.getFinanceSchedule().getFinanceDetail().getFinAssetValue().doubleValue());
			}
			if(null!=loanResponse.getFinanceSchedule().getFinanceDetail())
			{
				loanDetailBean.setFinAssetValue(financeDetail.getFinAssetValue());
			}
			if(null!=loanResponse.getFees()&& !loanResponse.getFees().isEmpty())
			{
				loanDetailBean.setFees(setFeesDetails(loanResponse.getFees()));
			}
			if(null!=loanResponse.getFinanceSchedule().getPlanEMIHmonths() && !loanResponse.getFinanceSchedule().getPlanEMIHmonths().isEmpty())
			{
				loanDetailBean.setEmiHoliday(loanResponse.getFinanceSchedule().getPlanEMIHmonths());
			}
		financeDetailBean.setFinanceDetail(loanDetailBean);
		return financeDetailBean;
	}
	
	@Component
	public class AsyncClass {
		
		@RequestScoped
		@Autowired
		BFLLoggerUtil logger;
		
		@Value("${resource-path-pennant-loan-collateral}")
		private String  resourcePathValueGetLoanCollateral;
		
		@Value("${pennant-authorization}")
		private String authorizationKey;

		@Async
		public Future<LoanCollatoralResponseBean> getLoanCollateralLinkedLoanDetailsFromPennant(String collatoralId,String loanNumber)
		{
			LoanCollatoralResponseBean loanAccountResponseBean;
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "calling getLaonDetailsForCustomer in helper");
			LoanCollatoralResponse loanResponse = getLoanCollateralDetailsFromPennant(collatoralId); // get Response from pennant as String 
		  	if(null!= loanResponse && "0000".equals(loanResponse.getReturnStatus().getReturnCode()))
		  	{
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Before prepareLMSLoanCollateralResponse() Pannnat Success call and returned data");
		  		loanAccountResponseBean = prepareLMSLoanCollateralResponse(loanResponse,loanNumber);
		  	}else if(null!=loanResponse && null!=loanResponse.getReturnStatus().getReturnCode() && null!=loanResponse.getReturnStatus().getReturnText()){
		  		loanAccountResponseBean=new LoanCollatoralResponseBean();
		  		loanAccountResponseBean.setReturnCode(loanResponse.getReturnStatus().getReturnCode());
		  		loanAccountResponseBean.setReturnText(loanResponse.getReturnStatus().getReturnText());
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Error Code return by Pennant. Code :"+loanResponse.getReturnStatus().getReturnCode()+"Message :"+loanResponse.getReturnStatus().getReturnText());
		  	}else{
		  		loanAccountResponseBean=new LoanCollatoralResponseBean();
		  		loanAccountResponseBean.setReturnText("Pennant Not Returned Data. Something went wrong at Pennant.");
		  	}
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "Final Response Bean return by method "+loanAccountResponseBean);
			return new AsyncResult<>(loanAccountResponseBean);
		}
		
		private LoanCollatoralResponseBean prepareLMSLoanCollateralResponse(LoanCollatoralResponse loanResponse,String loanNumber) {
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "inside prepareLMSLoanCollateralResponse");
			LoanCollatoralResponseBean collatoralResponseBean = new LoanCollatoralResponseBean();
			List<LoanDetailBean> linkedLoans = new ArrayList<>();
			collatoralResponseBean.setCollateralLinkedLoans(linkedLoans);
			if(null!=loanResponse && !loanResponse.getFinances().isEmpty())
			{
				List<LoanDetail> finances =loanResponse.getFinances();
				for (LoanDetail loanDetail : finances) {
					if(null!=loanNumber && null!= loanDetail.getFinReference() &&  !loanDetail.getFinReference().equals(loanNumber))
					{
						logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "inside for loanDetail collatoral");
						LoanDetailBean bean = new LoanDetailBean();
						bean.setLoanAcctNumber(loanDetail.getFinReference());
						bean.setLoanType(loanDetail.getFinType());
						bean.setLoanAmount(loanDetail.getFinAmount());
						linkedLoans.add(bean);
						logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "loan added in collatoral list");
					}
				}
				logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "collatoral loans list"+linkedLoans.size());
			}
			collatoralResponseBean.setCollateralLinkedLoans(linkedLoans);
			logger.debug(CLASS_NAME, BFLLoggerComponent.SERVICE, "return prepareLMSLoanCollateralResponse()"+collatoralResponseBean);
			return collatoralResponseBean;
		}

		private LoanCollatoralResponse getLoanCollateralDetailsFromPennant(String collateralRef) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside  getLoanCollateralDetailsFromPennant() in loanHelper");
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Input ::"+collateralRef);
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "URL ::"+resourcePathValueGetLoanCollateral);
			if(StringUtils.isNoneBlank(collateralRef) && StringUtils.isNoneBlank(resourcePathValueGetLoanCollateral))
			{
				Map<String, String> params = new HashMap<>();
				params.put(COLLATERALREF, collateralRef);
				CollateralRequestBean loanRequestBean= new CollateralRequestBean();
				loanRequestBean.setCollateralRef(collateralRef);
				JSONObject json= new JSONObject(loanRequestBean);
				String requestJson=json.toString();
				HttpHeaders headers = new HttpHeaders();
			    headers.add(LoanAccountConstants.AUTHORIZATION, authorizationKey);
				headers.setContentType(MediaType.APPLICATION_JSON);
				@SuppressWarnings("unchecked")
				//ResponseEntity<LoanCollatoralResponse> lmsResponse = (ResponseEntity<LoanCollatoralResponse>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.GET,resourcePathValueGetLoanCollateral, null, LoanCollatoralResponse.class, params, null, headers);
				ResponseEntity<LoanCollatoralResponse> lmsResponse = (ResponseEntity<LoanCollatoralResponse>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST,resourcePathValueGetLoanCollateral, null, LoanCollatoralResponse.class, null, requestJson, headers);
				if(null != lmsResponse && HttpStatus.OK.equals(lmsResponse.getStatusCode())) {
					logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Penannt Reposne Collatoral ::"+lmsResponse.getBody());
					return lmsResponse.getBody();
				}
			}
			logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Exit  getLoanCollateralDetailsFromPennant() in loanHelper");
			return null;
		}
	}

	

	private LoanResponse getLoanDetailsByLanNOFromPennant(String lanNo) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside  getLoanDetailsByLanNOFromPennant() in loanHelper");
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Input :: "+lanNo +"URL ::"+resourcePathValueGetLoanByLanNo);
		if(StringUtils.isNotBlank(lanNo)&& StringUtils.isNotBlank(resourcePathValueGetLoanByLanNo))
		{
//			Map<String, String> params = new HashMap<>();
//			params.put(FINREFERENCE, lanNo);
			LoanRequestBean loanRequestBean= new LoanRequestBean();
			loanRequestBean.setFinReference(lanNo);
			JSONObject json= new JSONObject(loanRequestBean);
			String requestJson=json.toString();
		    HttpHeaders headers = new HttpHeaders();
		    headers.add(LoanAccountConstants.AUTHORIZATION, authorizationKey);
			headers.setContentType(MediaType.APPLICATION_JSON);
			@SuppressWarnings("unchecked")
			ResponseEntity<LoanResponse> lmsResponse = (ResponseEntity<LoanResponse>) BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST,resourcePathValueGetLoanByLanNo, null, LoanResponse.class, null, requestJson, headers);
			if(null != lmsResponse && HttpStatus.OK.equals(lmsResponse.getStatusCode())) {
				logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "Pennant Reposnse"+lmsResponse.getBody());
				return lmsResponse.getBody();
			}
		}
		logger.debug(THIS_CLASS, BFLLoggerComponent.SERVICE, "return getLoanDetailsByLanNOFromPennant");
		return null;
	}
	
	private LoanResponse getLoanDetailsByLanNOFromPennantLMS(String lanNo,String loanProduct) {
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "Inside  getLoanDetailsByLanNOFromPennant() in loanHelper");
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "Input :: "+lanNo +"URL ::"+resourcePathValueGetLoanByLanNo);
		LoanResponse loanResponse = null;
		if(StringUtils.isNotBlank(lanNo))
		{
			ObjectMapper mapper = MapperFactory.getInstance();
			String lmsIntegrationRequestBeanString;
			String responseFromLMS;
			Map<String,String> params = new HashMap<>();
			// appcoreaccnum in Applications Table is LAN number
			//Application application = productDao.getApplicationByLAN(lanNo);
			//Prepare Request for LMSIntegrationService
			LmsRequestBean lmsRequestBean =  new LmsRequestBean();
			if(hfcProductCodes.contains(loanProduct.toUpperCase().trim()))
			{
				lmsRequestBean.setHttpMethod("GET");
				params.put("finreference", lanNo);
				lmsRequestBean.setParams(params);
				
			}
			else
			{
				lmsRequestBean.setHttpMethod("POST");
				LoanRequestBean loanRequestBean= new LoanRequestBean();
				loanRequestBean.setFinReference(lanNo);
				JSONObject json= new JSONObject(loanRequestBean);
				String requestJson=json.toString();
				lmsRequestBean.setRequestPayload(requestJson);
			}
			lmsRequestBean.setProductCode(loanProduct);
			lmsRequestBean.setSource("LOANLANNO"); //source present in centralconfiguration properties file
			
			try {
				lmsIntegrationRequestBeanString = mapper.writeValueAsString(lmsRequestBean);
			} catch (JsonProcessingException e) {
				throw new BFLTechnicalException("JSNMAPEXC_002", env.getProperty("JSNMAPEXC_002"));
			}
			String lmsURL = env.getProperty("api.lms.gateway.POST.url");
			// calling LMSIntegrationService
			responseFromLMS = loanAccountUtil.hitLMSIntegrationService(lmsIntegrationRequestBeanString, lmsURL);
			loanResponse = loanAccountUtil.mapFromJson(responseFromLMS, LoanResponse.class);
		
		}
		logger.info(THIS_CLASS, BFLLoggerComponent.SERVICE, "return getLoanDetailsByLanNOFromPennant");
		return loanResponse;
	}

	
	
	
}
