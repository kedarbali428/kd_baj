package com.bajaj.bfsd.loanaccount.bean;

public class ApplicantDeatilsForNotification {

	private  String applicantName;
    private String mobileNumber;
    private String emailId;
    
    
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
    
    
	
	
}
