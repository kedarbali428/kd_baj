package com.bajaj.bfsd.loanaccount.dao;

import com.bajaj.bfsd.loanaccount.bean.DocumentsResponse;

@FunctionalInterface
public interface DocumentsDao {

	public DocumentsResponse getDocuments(Long customerId); 
	
}
