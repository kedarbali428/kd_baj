package com.bajaj.bfsd.loanaccount.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class DownloadDocumentBean implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private Long customerId;
	
	private String downloadlink; 
	
	private String doctype;
	private String documentCategory;
	private Timestamp adsstoredt;
	private String doctypeCode;
	private String loanNumber;
	private String docContentType;

	public String getDocContentType() {
		return docContentType;
	}

	public void setDocContentType(String docContentType) {
		this.docContentType = docContentType;
	}

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	public String getDoctypeCode() {
		return doctypeCode;
	}

	public void setDoctypeCode(String doctypeCode) {
		this.doctypeCode = doctypeCode;
	}


	public Timestamp getAdsstoredt() {
		return adsstoredt;
	}

	public void setAdsstoredt(Timestamp adsstoredt) {
		this.adsstoredt = adsstoredt;
	}

	public String getDocumentCategory() {
		return documentCategory;
	}

	public void setDocumentCategory(String documentCategory) {
		this.documentCategory = documentCategory;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getDownloadlink() {
		return downloadlink;
	}

	public void setDownloadlink(String downloadlink) {
		this.downloadlink = downloadlink;
	}

	public String getDoctype() {
		return doctype;
	}

	public void setDoctype(String doctype) {
		this.doctype = doctype;
	}
	
}
