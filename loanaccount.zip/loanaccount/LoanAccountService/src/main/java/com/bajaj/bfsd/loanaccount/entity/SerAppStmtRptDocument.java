package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the SER_APP_STMT_RPT_DOCUMENTS database table.
 * 
 */
@Entity
@Table(name="SER_APP_STMT_RPT_DOCUMENTS")
@NamedQuery(name="SerAppStmtRptDocument.findAll", query="SELECT s FROM SerAppStmtRptDocument s")
public class SerAppStmtRptDocument implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long appstmtdockey;

	private Long applicantkey;

	private String contenttype;

	private BigDecimal documentsize;

	private Timestamp expirydt;

	private String filename;

	private Timestamp generationdt;

	private BigDecimal isactive;

	private String lstupdateby;

	private Timestamp lstupdatedt;

	private BigDecimal refprodappaccflg;

	private String refprodnum;

	private String storagelink;

	private String storagerefnum;

	//bi-directional many-to-one association to SerStmtReportType
	@ManyToOne
	@JoinColumn(name="SERSTMTTYPEKEY")
	private SerStmtReportType serStmtReportType;

	public SerAppStmtRptDocument() {
	}

	public long getAppstmtdockey() {
		return this.appstmtdockey;
	}

	public void setAppstmtdockey(long appstmtdockey) {
		this.appstmtdockey = appstmtdockey;
	}

	public Long getApplicantkey() {
		return this.applicantkey;
	}

	public void setApplicantkey(Long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public String getContenttype() {
		return this.contenttype;
	}

	public void setContenttype(String contenttype) {
		this.contenttype = contenttype;
	}

	public BigDecimal getDocumentsize() {
		return this.documentsize;
	}

	public void setDocumentsize(BigDecimal documentsize) {
		this.documentsize = documentsize;
	}

	public Timestamp getExpirydt() {
		return this.expirydt;
	}

	public void setExpirydt(Timestamp expirydt) {
		this.expirydt = expirydt;
	}

	public String getFilename() {
		return this.filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public Timestamp getGenerationdt() {
		return this.generationdt;
	}

	public void setGenerationdt(Timestamp generationdt) {
		this.generationdt = generationdt;
	}

	public BigDecimal getIsactive() {
		return this.isactive;
	}

	public void setIsactive(BigDecimal isactive) {
		this.isactive = isactive;
	}

	public String getLstupdateby() {
		return this.lstupdateby;
	}

	public void setLstupdateby(String lstupdateby) {
		this.lstupdateby = lstupdateby;
	}

	public Timestamp getLstupdatedt() {
		return this.lstupdatedt;
	}

	public void setLstupdatedt(Timestamp lstupdatedt) {
		this.lstupdatedt = lstupdatedt;
	}

	public BigDecimal getRefprodappaccflg() {
		return this.refprodappaccflg;
	}

	public void setRefprodappaccflg(BigDecimal refprodappaccflg) {
		this.refprodappaccflg = refprodappaccflg;
	}

	public String getRefprodnum() {
		return this.refprodnum;
	}

	public void setRefprodnum(String refprodnum) {
		this.refprodnum = refprodnum;
	}

	public String getStoragelink() {
		return this.storagelink;
	}

	public void setStoragelink(String storagelink) {
		this.storagelink = storagelink;
	}

	public String getStoragerefnum() {
		return this.storagerefnum;
	}

	public void setStoragerefnum(String storagerefnum) {
		this.storagerefnum = storagerefnum;
	}

	public SerStmtReportType getSerStmtReportType() {
		return this.serStmtReportType;
	}

	public void setSerStmtReportType(SerStmtReportType serStmtReportType) {
		this.serStmtReportType = serStmtReportType;
	}

}