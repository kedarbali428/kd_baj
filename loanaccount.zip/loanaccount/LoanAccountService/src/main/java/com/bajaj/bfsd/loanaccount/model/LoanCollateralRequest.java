package com.bajaj.bfsd.loanaccount.model;

public class LoanCollateralRequest {

	private String collateralRef;

	public String getCollateralRef() {
		return collateralRef;
	}

	public void setCollateralRef(String collateralRef) {
		this.collateralRef = collateralRef;
	}

}