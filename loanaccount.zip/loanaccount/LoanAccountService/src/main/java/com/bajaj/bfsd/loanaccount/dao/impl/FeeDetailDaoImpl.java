package com.bajaj.bfsd.loanaccount.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.loanaccount.dao.FeeDetailDao;
import com.bajaj.bfsd.loanaccount.model.FeesType;

@Component
public class FeeDetailDaoImpl extends BFLComponent implements FeeDetailDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public FeesType getFeeDetailsByFeeCode(String feeCode) {
		FeesType feesType = null ;
		Query query = entityManager
				.createQuery("from  FeesType f where f.feecode = :feeCode");
		query.setParameter("feeCode", feeCode);
		
		@SuppressWarnings("unchecked")
		List<FeesType> feesTypes = query.getResultList();
		if(null!=feesTypes &&  !feesTypes.isEmpty())
		{
			feesType = feesTypes.get(0);
		}
		return feesType;
	}

}
