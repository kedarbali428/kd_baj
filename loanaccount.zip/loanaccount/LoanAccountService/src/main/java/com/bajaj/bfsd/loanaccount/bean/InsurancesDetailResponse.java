package com.bajaj.bfsd.loanaccount.bean;

import java.io.Serializable;
import java.util.List;

public class InsurancesDetailResponse implements Serializable{

	private static final long serialVersionUID = 1L;

	private List<InsuranceDetail> insuranceDetails;

	private List<VasDetailBean> vasDetails;

	private String returnCode;
	
	private String returnText;
	
	public List<VasDetailBean> getVasDetails() {
		return vasDetails;
	}

	public void setVasDetails(List<VasDetailBean> vasDetails) {
		this.vasDetails = vasDetails;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnText() {
		return returnText;
	}

	public void setReturnText(String returnText) {
		this.returnText = returnText;
	}

	public List<InsuranceDetail> getInsuranceDetails() {
        return insuranceDetails;
    } 

    public void setInsuranceDetails(List<InsuranceDetail> insuranceDetails) {
        this.insuranceDetails = insuranceDetails;
    }

	@Override
	public String toString() {
		return "InsurancesDetailResponse [insuranceDetails=" + insuranceDetails + ", returnCode=" + returnCode
				+ ", returnText=" + returnText + "]";
	}
    
}
