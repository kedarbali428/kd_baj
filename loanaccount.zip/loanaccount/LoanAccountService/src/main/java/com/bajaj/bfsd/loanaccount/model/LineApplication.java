package com.bajaj.bfsd.loanaccount.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the LINE_APPLICATIONS database table.
 * 
 */
@Entity
@Table(name="LINE_APPLICATIONS")
@NamedQuery(name="LineApplication.findAll", query="SELECT l FROM LineApplication l")
public class LineApplication implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long lineapplicationkey;

	@Temporal(TemporalType.DATE)
	private Date laapprovaldt;

	private BigDecimal labundlepurfeedisc;

	@Temporal(TemporalType.DATE)
	private Date laeffenddt;

	@Temporal(TemporalType.DATE)
	private Date laeffstartdt;

	private BigDecimal laisactive;

	private String lalstupdateby;

	private Timestamp lalstupdatedt;

	private BigDecimal lanetprocessfees;

	private BigDecimal laproductfees;

	private BigDecimal latoteligibilityamt;

	/*//bi-directional many-to-one association to Application
	@ManyToOne
	@JoinColumn(name="APPLICATIONKEY")
	private Application application;

	//bi-directional many-to-one association to LineApplicationProduct
	@OneToMany(mappedBy="lineApplication")
	private List<LineApplicationProduct> lineApplicationProducts;
*/
	public LineApplication() {
	}

	public long getLineapplicationkey() {
		return this.lineapplicationkey;
	}

	public void setLineapplicationkey(long lineapplicationkey) {
		this.lineapplicationkey = lineapplicationkey;
	}

	public Date getLaapprovaldt() {
		return this.laapprovaldt;
	}

	public void setLaapprovaldt(Date laapprovaldt) {
		this.laapprovaldt = laapprovaldt;
	}

	public BigDecimal getLabundlepurfeedisc() {
		return this.labundlepurfeedisc;
	}

	public void setLabundlepurfeedisc(BigDecimal labundlepurfeedisc) {
		this.labundlepurfeedisc = labundlepurfeedisc;
	}

	public Date getLaeffenddt() {
		return this.laeffenddt;
	}

	public void setLaeffenddt(Date laeffenddt) {
		this.laeffenddt = laeffenddt;
	}

	public Date getLaeffstartdt() {
		return this.laeffstartdt;
	}

	public void setLaeffstartdt(Date laeffstartdt) {
		this.laeffstartdt = laeffstartdt;
	}

	public BigDecimal getLaisactive() {
		return this.laisactive;
	}

	public void setLaisactive(BigDecimal laisactive) {
		this.laisactive = laisactive;
	}

	public String getLalstupdateby() {
		return this.lalstupdateby;
	}

	public void setLalstupdateby(String lalstupdateby) {
		this.lalstupdateby = lalstupdateby;
	}

	public Timestamp getLalstupdatedt() {
		return this.lalstupdatedt;
	}

	public void setLalstupdatedt(Timestamp lalstupdatedt) {
		this.lalstupdatedt = lalstupdatedt;
	}

	public BigDecimal getLanetprocessfees() {
		return this.lanetprocessfees;
	}

	public void setLanetprocessfees(BigDecimal lanetprocessfees) {
		this.lanetprocessfees = lanetprocessfees;
	}

	public BigDecimal getLaproductfees() {
		return this.laproductfees;
	}

	public void setLaproductfees(BigDecimal laproductfees) {
		this.laproductfees = laproductfees;
	}

	public BigDecimal getLatoteligibilityamt() {
		return this.latoteligibilityamt;
	}

	public void setLatoteligibilityamt(BigDecimal latoteligibilityamt) {
		this.latoteligibilityamt = latoteligibilityamt;
	}

	/*public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public List<LineApplicationProduct> getLineApplicationProducts() {
		return this.lineApplicationProducts;
	}

	public void setLineApplicationProducts(List<LineApplicationProduct> lineApplicationProducts) {
		this.lineApplicationProducts = lineApplicationProducts;
	}

	public LineApplicationProduct addLineApplicationProduct(LineApplicationProduct lineApplicationProduct) {
		getLineApplicationProducts().add(lineApplicationProduct);
		lineApplicationProduct.setLineApplication(this);

		return lineApplicationProduct;
	}

	public LineApplicationProduct removeLineApplicationProduct(LineApplicationProduct lineApplicationProduct) {
		getLineApplicationProducts().remove(lineApplicationProduct);
		lineApplicationProduct.setLineApplication(null);

		return lineApplicationProduct;
	}
*/
}