/*
 * Copyright 2016-2017 Bajaj Finserv Ltd. All Rights Reserved.
 */
package com.bajaj.bfsd.loanaccount.bean;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * This is a bean class for Insurance detail.
 *
 * @author Upwan G
 * 
 * Version      BugId           UserId           Date            Description
 * 1.0                          Upwan G       	 24/02/2017      Initial Version
 */
public class InsuranceDetail implements Serializable{

   
    /**
     * Constant for serialVersionUID.
     */
    private static final long serialVersionUID = 330487960426782097L;
    
    /**
     * Variable to hold value for policy number.
     */
    private String policyNumber;
    
    /**
     * Variable to hold value for sum assured.
     */
    private BigDecimal sumAssured;
    
    /**
     * Variable to hold value for premium.
     */
    private BigDecimal premium;
    
    /**
     * Variable to hold value for insurance type.
     */
    private String insuranceType;
    
    /**
     * Getter method for policy number.
     *
     * @return policy number
     */
    public String getPolicyNumber() {
        return policyNumber;
    }
    
    /**
     * Sets the value of policy number.
     *
     * @param policyNumber the new policy number
     */
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }
    
    /**
     * Getter method for sum assured.
     *
     * @return sum assured
     */
    public BigDecimal getSumAssured() {
        return sumAssured;
    }
    
    /**
     * Sets the value of sum assured.
     *
     * @param sumAssured the new sum assured
     */
    public void setSumAssured(BigDecimal sumAssured) {
        this.sumAssured = sumAssured;
    }
    
    /**
     * Getter method for premium.
     *
     * @return premium
     */
    public BigDecimal getPremium() {
        return premium;
    }
    
    /**
     * Sets the value of premium.
     *
     * @param premium the new premium
     */
    public void setPremium(BigDecimal premium) {
        this.premium = premium;
    }
    
    /**
     * Getter method for insurance type.
     *
     * @return insurance type
     */
    public String getInsuranceType() {
        return insuranceType;
    }
    
    /**
     * Sets the value of insurance type.
     *
     * @param insuranceType the new insurance type
     */
    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }
}
