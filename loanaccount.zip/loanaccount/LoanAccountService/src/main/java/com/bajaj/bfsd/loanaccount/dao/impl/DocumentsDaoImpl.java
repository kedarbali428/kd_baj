package com.bajaj.bfsd.loanaccount.dao.impl;

import static com.bajaj.bfsd.loanaccount.util.DocumentConstants.IS_ACTIVE;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.bflawsutil.helper.BFLAwsS3Helper;
import com.bajaj.bfsd.common.business.baseclasses.BFLComponent;
import com.bajaj.bfsd.loanaccount.bean.DocumentsResponse;
import com.bajaj.bfsd.loanaccount.bean.DownloadDocumentBean;
import com.bajaj.bfsd.loanaccount.dao.DocumentsDao;
import com.bajaj.bfsd.loanaccount.entity.SerAppStmtRptDocument;

@Component
public class DocumentsDaoImpl extends BFLComponent implements DocumentsDao{

	@PersistenceContext
	EntityManager entityManager;
	
	private static final String THIS_CLASS=DocumentsDaoImpl.class.getSimpleName();
	
	@Autowired
    private BFLLoggerUtilExt logger;
	
	@Value("${aws.dms.bucket}")
	private String dmsBucketName;
	    
	@Autowired
	private BFLAwsS3Helper helper;
	    
	@Override
	public DocumentsResponse getDocuments(Long customerId) {		
		DocumentsResponse  documentsResponse = new DocumentsResponse();
		List<DownloadDocumentBean> downloadDocumentBeans = new ArrayList<>();
		String nativeQueryStr = "select distinct aa.applicantkey,ads.adsstorelink,dt.doctypedesc,dc.doccatdesc,ads.adsstoredt,dt.doctypecode,ap.appcoreaccnum,ads.adscontenttype from application_applicants aa"
				+" inner join applications ap on aa.applicationkey = ap.applicationkey" 
				+" inner join application_documents ad on aa.applicationkey = ad.applicationkey "
				+" inner join application_doc_storage ads on ads.appdockey=ad.appdockey"
				+" inner join document_types dt on dt.doctypekey=ad.doctypekey"
				+" inner join document_categories dc on dc.doccatkey=ad.doccatkey"
				+" where aa.applicantkey=?customerId and ad.ADISACTIVE=1 and ads.ADSISACTIVE=1 order by ads.adsstoredt desc"; //5895
		
		@SuppressWarnings("unchecked")
		List<Object[]> queryData = entityManager.createNativeQuery(nativeQueryStr.replace("?customerId", customerId.toString())).getResultList();
		if(null!=queryData && !queryData.isEmpty())
		{
			for (Object[] applicationDocStorage : queryData) {
				DownloadDocumentBean documentBean = new DownloadDocumentBean();
				documentBean.setDoctype((String)applicationDocStorage[3]);
				documentBean.setDownloadlink(((String)applicationDocStorage[1]).contains("https")?(String)applicationDocStorage[1]:helper.generatePresignedURL(dmsBucketName, (String)applicationDocStorage[1]));
				documentBean.setCustomerId(customerId);
				documentBean.setDocumentCategory((String)applicationDocStorage[2]);
				documentBean.setAdsstoredt((Timestamp)applicationDocStorage[4]);
				documentBean.setDoctypeCode((String)applicationDocStorage[5]);
				documentBean.setLoanNumber((String)applicationDocStorage[6]);
				documentBean.setDocContentType((String)applicationDocStorage[7]);
				downloadDocumentBeans.add(documentBean);
			}
			
		}
		List<DownloadDocumentBean> soaDocs= getDocumentListForStatementAndReports(customerId);
		if(null!=soaDocs && !soaDocs.isEmpty())
		{
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getDocumentListForStatementAndReports - returns list");
			downloadDocumentBeans.addAll(soaDocs);
		}
		documentsResponse.setDownloads(downloadDocumentBeans);
		return documentsResponse;
	}

	@SuppressWarnings("unchecked")
	private List<DownloadDocumentBean>  getDocumentListForStatementAndReports(Long applicantKey) {
		logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getDocumentListForSOA - Stareted");
//		Query query = entityManager.createQuery(
//				"from SerAppStmtRptDocument s where s.applicantkey = :applicantkey and s.serStmtReportType.serstmttypekey=:serstmttypekey and s.isactive=:isActive"
//						+ " and s.appstmtdockey=(SELECT max(t.appstmtdockey)from SerAppStmtRptDocument t where t.applicantkey =:applicantkey and t.serStmtReportType.serstmttypekey=:serstmttypekey and t.isactive=:isActive)")
		Query query = entityManager.createQuery(
				"from SerAppStmtRptDocument s where s.applicantkey = :applicantkey and s.isactive=:isActive order by s.serStmtReportType.serstmttypekey,s.appstmtdockey desc");
		query.setParameter("applicantkey",applicantKey);
		//query.setParameter(STATEMENTTYPEKEY, statementTypeKey)
		query.setParameter(IS_ACTIVE, BigDecimal.ONE);
		List<SerAppStmtRptDocument>  stmntTypeList = query.getResultList();
		if (null!=stmntTypeList && !stmntTypeList.isEmpty()) {
			logger.debug(THIS_CLASS, BFLLoggerComponent.DAO, "getting data for list"+stmntTypeList);
			return prepareResponse(stmntTypeList);
		} 
		return Collections.emptyList();
	}

	private List<DownloadDocumentBean> prepareResponse(List<SerAppStmtRptDocument> stmntTypeList) {
		List<DownloadDocumentBean> downloadDocumentBeans = new ArrayList<>();
		DownloadDocumentBean bean;
		for (SerAppStmtRptDocument serAppStmtRptDocument : stmntTypeList) {
			bean = new DownloadDocumentBean();
			bean.setCustomerId(serAppStmtRptDocument.getApplicantkey());
			bean.setAdsstoredt(serAppStmtRptDocument.getGenerationdt());
			//bean.setDownloadlink(serAppStmtRptDocument.getStoragelink())
			bean.setDownloadlink((serAppStmtRptDocument.getStoragelink()).contains("https")?serAppStmtRptDocument.getStoragelink():helper.generatePresignedURL(dmsBucketName, serAppStmtRptDocument.getStoragelink()));
			bean.setDoctype(serAppStmtRptDocument.getSerStmtReportType().getStatementcode());
			bean.setDocumentCategory(serAppStmtRptDocument.getSerStmtReportType().getDescription());
			downloadDocumentBeans.add(bean);
		}
		return downloadDocumentBeans;
	}
	
	
	
	
	
	
	
	
}
