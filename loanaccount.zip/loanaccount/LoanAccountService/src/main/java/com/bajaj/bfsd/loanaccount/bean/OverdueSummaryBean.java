package com.bajaj.bfsd.loanaccount.bean;

public class OverdueSummaryBean {

	private String schdDate;
	
	private String chargeType;
	
	private Number overdueAmount;
	
	private Number overdueChargeAmount;
	
	private Number overdueChargePaid;
	
	private Number overdueInterestAmount;
	
	private Number overdueInterestPaid;

	public Number getOverdueChargePaid() {
		return overdueChargePaid;
	}

	public void setOverdueChargePaid(Number overdueChargePaid) {
		this.overdueChargePaid = overdueChargePaid;
	}

	public Number getOverdueInterestAmount() {
		return overdueInterestAmount;
	}

	public void setOverdueInterestAmount(Number overdueInterestAmount) {
		this.overdueInterestAmount = overdueInterestAmount;
	}

	public Number getOverdueInterestPaid() {
		return overdueInterestPaid;
	}

	public void setOverdueInterestPaid(Number overdueInterestPaid) {
		this.overdueInterestPaid = overdueInterestPaid;
	}

	public String getSchdDate() {
		return schdDate;
	}

	public void setSchdDate(String schdDate) {
		this.schdDate = schdDate;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public Number getOverdueAmount() {
		return overdueAmount;
	}

	public void setOverdueAmount(Number overdueAmount) {
		this.overdueAmount = overdueAmount;
	}

	public Number getOverdueChargeAmount() {
		return overdueChargeAmount;
	}

	public void setOverdueChargeAmount(Number overdueChargeAmount) {
		this.overdueChargeAmount = overdueChargeAmount;
	}

	
}
