package com.bajaj.bfsd.loanaccount.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.business.baseclasses.BFLController;
import com.bajaj.bfsd.common.domain.ResponseBean;
import com.bajaj.bfsd.loanaccount.bean.InsuranceDetail;
import com.bajaj.bfsd.loanaccount.bean.InsurancesDetailResponse;
import com.bajaj.bfsd.loanaccount.bean.VasDetailBean;
import com.bajaj.bfsd.loanaccount.service.VasInsuranceService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * This is a controller class for Insurance Details.
 *
 * @author 582602
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          582602          23/02/2017      Initial Version
 */
@RestController
public class InsuranceController extends BFLController {
    
    private static final String THIS_CLASS = InsuranceController.class.getSimpleName();
    
    @Autowired
    private BFLLoggerUtilExt logger;
    

    @Autowired 
    private VasInsuranceService vasInsuranceService;
    
    
    @ApiOperation(value = "Get all insurances for the given customer", 
            notes = "Provides all insurance details", httpMethod = "GET")
    @ApiImplicitParam(name = "cmptcorrid", required = true,
                    dataType = "string", paramType = "header") 
    @RequestMapping(value = "${api.loanaccount.loaninsurances.GET.uri}",
                  method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    public ResponseEntity<ResponseBean> getAllVASAndInsurances(
    		@RequestParam(required=false) Long customerId,
    		@RequestParam(required=false) String productcode,
    		@RequestParam String loanNumber, @RequestHeader HttpHeaders headers){
      
      logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getAllVASAndInsurances - started");
     // InsurancesDetailResponse vasInsuranceResponse = vasInsuranceService.getVasAndInsuranceDetails(loanNumber,productcode)
      List<InsuranceDetail> insuranceDetails = new ArrayList<>();
      List<VasDetailBean> vasDetails = new ArrayList<>();
      InsurancesDetailResponse vasInsuranceResponse = new InsurancesDetailResponse();
      vasInsuranceResponse.setInsuranceDetails(insuranceDetails);
      vasInsuranceResponse.setVasDetails(vasDetails);
      logger.info(THIS_CLASS, BFLLoggerComponent.CONTROLLER, "getAllVASAndInsurances - completed");
      return new ResponseEntity<>(new ResponseBean(vasInsuranceResponse), HttpStatus.OK);
    }
}

