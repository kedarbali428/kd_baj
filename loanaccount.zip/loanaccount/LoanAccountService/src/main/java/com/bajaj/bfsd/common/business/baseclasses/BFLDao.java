package com.bajaj.bfsd.common.business.baseclasses;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Repository;

@RefreshScope
@Repository
public abstract class BFLDao { //NOSONAR
}
