package com.bajaj.bfsd.loanaccount.model;

import java.util.List;

public class LoanCollatoralResponse {

	private List<LoanDetail> finances;
	
	private ReturnStatus returnStatus;

	public List<LoanDetail> getFinances() {
		return finances;
	}

	public void setFinances(List<LoanDetail> finances) {
		this.finances = finances;
	}

	public ReturnStatus getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(ReturnStatus returnStatus) {
		this.returnStatus = returnStatus;
	}
	
	
}
