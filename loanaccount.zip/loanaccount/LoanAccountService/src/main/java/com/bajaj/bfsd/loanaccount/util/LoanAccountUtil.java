package com.bajaj.bfsd.loanaccount.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.bajaj.bfsd.common.BFLLoggerComponent;
import com.bajaj.bfsd.common.BFLLoggerUtilExt;
import com.bajaj.bfsd.common.clients.BFLCommonRestClient;
import com.bajaj.bfsd.loanaccount.config.MapperFactory;
import com.bfl.common.exceptions.BFLTechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This is a util class.
 *
 * @author Upwan G
 * 
 * Version      BugId           UserId           Date            Description
 * 1.0                          Upwan G       	 27/03/2017      Initial Version
 */
@Component
public class LoanAccountUtil {

	private static final String SREQ_018="SREQ_018";
	private static final String THIS_CLASS = LoanAccountUtil.class.getSimpleName();
	
	@Autowired
	BFLLoggerUtilExt logger;
	
	@Autowired
	Environment env;
	/**
	 * Instantiates a new service request util.
	 */
	private LoanAccountUtil(){

	}
	/**
	 * Getter method for current timestamp.
	 *
	 * @return current timestamp
	 */
	public static Timestamp getCurrentTimestamp() {
		Date date = Calendar.getInstance().getTime();
		return new Timestamp(date.getTime());
	}

	/**
	 * Maps an Object into a JSON String. Uses a Jackson ObjectMapper.
	 * @param obj The Object to map.
	 * @return A String of JSON.
	 * @throws JsonProcessingException Thrown if an error occurs while mapping.
	 */
	public static String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper mapper = MapperFactory.getInstance();
		return mapper.writeValueAsString(obj);
	}

	/**
	 * Maps a String of JSON into an instance of a Class of type T. Uses a
	 * Jackson ObjectMapper.
	 *
	 * @param <T> the generic type
	 * @param json A String of JSON.
	 * @param clazz A Class of type T. The mapper will attempt to convert the
	 *        JSON into an Object of this Class type.
	 * @return An Object of type T.
	 * @throws IOException Thrown if an error occurs while mapping.
	 */
	public <T> T mapFromJson(String jsonString, Class<T> clazz) {
		ObjectMapper mapper = MapperFactory.getInstance();
		try {
			return mapper.readValue(jsonString, clazz);
		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.SERVICE, "Error occured in Pennant", e);
			throw new BFLTechnicalException("LMS_002", env.getProperty("LMS_002"));
		}
	}

	/**
	 * Getter method for SR number.
	 *
	 * @return SR number
	 */
	public static String getSRNumber(){
		return "SR"+new Random().nextInt();
	}

	/**
	 * Read file.
	 *
	 * @param filename the filename
	 * @return the string
	 */
	public static String readFile(String filename) {
		String result;
		InputStream inputStream;
		BufferedReader br;

		try {
			inputStream = LoanAccountUtil.class.getClassLoader().getResourceAsStream(filename);
			br = new BufferedReader(new InputStreamReader(inputStream));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			while (line != null) {
				sb.append(line);
				line = br.readLine();  
			}
			result = sb.toString();
		} catch (IOException e) {
			throw new BFLTechnicalException("SREQ_017", e);
		}

		return result; 
	}
	public static int getDaysDifferenceForDateWithoutTimeStamp(String emiDate) {
		String diffDays = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date currentDate = new Date();
		Date dateformat;
		try {
			dateformat = sdf.parse(emiDate);
			long diff = dateformat.getTime() - currentDate.getTime();
			diffDays =  String.valueOf(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
		} catch (ParseException e) {
			throw new BFLTechnicalException("SREQ_019", e);
		}  
		return Integer.parseInt(diffDays);
	}



	public static int getDaysDifferenceForDateWithoutTime(String emiDate) {
		String diffDays = null;
		Date currentDate = new Date();
		Date dateformat;
		try {
			dateformat = new SimpleDateFormat("yyyy-MM-dd").parse(emiDate);
			long diff = dateformat.getTime() - currentDate.getTime();
			diffDays =  String.valueOf(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
		} catch (ParseException e) {
			throw new BFLTechnicalException(SREQ_018, e);
		}  
		return Integer.parseInt(diffDays);
	}

	public static Double calculatePercent(Double value, Double outOf)
	{
		if(null!=outOf && null!=value)
		{
			return value*100/outOf;
		}
		return null;
	}

	public static String getStampDateWithInString(Date date){
		if(null!=date)
		{
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'00:00:00");
			return formatter.format(date);
		}
		return null;
	}

	public static String getPredate(String preDate){
		DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss", Locale.ENGLISH);
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH);
		LocalDate date = LocalDate.parse(preDate, inputFormatter);
		String formattedDate = outputFormatter.format(date);
		return formattedDate;
	}
	public static String getExpdate(String preDate){
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Calendar c = Calendar.getInstance();
		Date formattedDate;
		String datetest;
		try {
			formattedDate = formatter.parse(preDate);
			c.setTime(formattedDate);
			c.add(Calendar.YEAR, 1);
			Date expDate = c.getTime();
			datetest=formatter.format(expDate);
		} catch (ParseException e) {
			throw new BFLTechnicalException(SREQ_018, e);
		}
		return datetest;
	}
	
	public String hitLMSIntegrationService(String lmsIntegrationRequestBeanString, String lmsURL) {
		logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY, "Started hitLMSIntegrationService with request -->" +lmsIntegrationRequestBeanString);
		String responsePayload;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		ResponseEntity<?> resp = BFLCommonRestClient.invokeRestEndpoint(HttpMethod.POST,lmsURL, null, String.class, null,lmsIntegrationRequestBeanString , headers);
		if (null != resp && HttpStatus.OK.equals(resp.getStatusCode())) {	
			Object responseObject = resp.getBody();
			JSONObject responseJson = getJsonObject(responseObject);
			responsePayload = (String)responseJson.get("payload");	
			logger.info(THIS_CLASS, BFLLoggerComponent.UTILITY,	" Lms Integration Response : " + responsePayload);
			
		} else {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY,"Error occured while invoking LMSIntegration Service");
			throw new BFLTechnicalException("LMS_001", env.getProperty("LMS_001"));
		}
		return responsePayload;
		
	}
	
	@SuppressWarnings("rawtypes")
	private JSONObject getJsonObject(Object object) {
		JSONObject jsonObject = new JSONObject();
		try {

			JSONParser parser = new JSONParser();
			if (object instanceof JSONObject) {
				jsonObject = (JSONObject) object;
			} else if (object instanceof LinkedHashMap) {
				jsonObject = new JSONObject((Map) object);
			} else {
				Object obj = parser.parse(object.toString());
				jsonObject = (JSONObject) obj;
			}

		} catch (Exception e) {
			logger.error(THIS_CLASS, BFLLoggerComponent.UTILITY, "Error occurred while invoking LMSIntegration Service", e);
			throw new BFLTechnicalException("LMS_001", env.getProperty("LMS_001"));
			
		}
		return jsonObject;
	}
	
	public Number convertRstoPaisa(Number value){
		if(null!=value){
			value= value.longValue()*100;
		}
		return value;
	}

}
