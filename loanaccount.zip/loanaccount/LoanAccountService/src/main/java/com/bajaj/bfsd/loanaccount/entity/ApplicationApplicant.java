package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the APPLICATION_APPLICANTS database table.
 * 
 */
@Entity
@Table(name="APPLICATION_APPLICANTS")
@NamedQuery(name="ApplicationApplicant.findAll", query="SELECT a FROM ApplicationApplicant a")
public class ApplicationApplicant implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false, precision=20)
	private long appapltkey;

	@Column(nullable=false)
	private Timestamp appaplteffdate;

	@Column(precision=1)
	private BigDecimal appapltisactive;

	@Column(length=20)
	private String appapltlstupdateby;

	private Timestamp appapltlstupdatedt;

	@Column(nullable=false, precision=2)
	private BigDecimal applicanttype;

	
	//bi-directional many-to-one association to Applicant
	@ManyToOne
	@JoinColumn(name="APPLICANTKEY", nullable=false)
	private Applicant applicant;

	//bi-directional many-to-one association to Application
	@ManyToOne
	@JoinColumn(name="APPLICATIONKEY", nullable=false)
	private Application application;

	
	public ApplicationApplicant() {
		//Needed by JPA
	}

	public long getAppapltkey() {
		return this.appapltkey;
	}

	public void setAppapltkey(long appapltkey) {
		this.appapltkey = appapltkey;
	}

	public Timestamp getAppaplteffdate() {
		return this.appaplteffdate;
	}

	public void setAppaplteffdate(Timestamp appaplteffdate) {
		this.appaplteffdate = appaplteffdate;
	}

	public BigDecimal getAppapltisactive() {
		return this.appapltisactive;
	}

	public void setAppapltisactive(BigDecimal appapltisactive) {
		this.appapltisactive = appapltisactive;
	}

	public String getAppapltlstupdateby() {
		return this.appapltlstupdateby;
	}

	public void setAppapltlstupdateby(String appapltlstupdateby) {
		this.appapltlstupdateby = appapltlstupdateby;
	}

	public Timestamp getAppapltlstupdatedt() {
		return this.appapltlstupdatedt;
	}

	public void setAppapltlstupdatedt(Timestamp appapltlstupdatedt) {
		this.appapltlstupdatedt = appapltlstupdatedt;
	}

	public BigDecimal getApplicanttype() {
		return this.applicanttype;
	}

	public void setApplicanttype(BigDecimal applicanttype) {
		this.applicanttype = applicanttype;
	}

	

	public Applicant getApplicant() {
		return this.applicant;
	}

	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}

	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}


	

}