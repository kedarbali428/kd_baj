package com.bajaj.bfsd.loanaccount.service;

import com.bajaj.bfsd.loanaccount.bean.DocumentsResponse;

/**
 * This is an interface for Documents details view operations.
 *
 * @author 412398
 * 
 * Version      BugId           UsrId           Date            Description
 * 1.0                          412398          27/02/2012      Initial Version
 */
@FunctionalInterface
public interface DocumentsService {
	
    public DocumentsResponse getDocuments(Long customerId);
    
}
