package com.bajaj.bfsd.loanaccount.dao;

import com.bajaj.bfsd.loanaccount.bean.ApplicantDeatilsForNotification;
import com.bajaj.bfsd.loanaccount.entity.Applicant;
import com.bajaj.bfsd.loanaccount.entity.Application;
import com.bajaj.bfsd.loanaccount.entity.ApplicationApplicant;
import com.bajaj.bfsd.loanaccount.model.LoanProduct;
import com.bajaj.bfsd.loanaccount.model.LoanProductType;

public interface ProductDao {

	public LoanProductType getLoanTypeDesc(String loanType);

	public ApplicantDeatilsForNotification getApplicantdetails(Long applicantid);
	
	public String getproductDesc(String code); 
	public String getInsproductDesc(String code); 
	public String getpolicyNo(String policyno); 
	
	public Applicant getApplicantDetailsByApplicantId(Long applicantID);

	public Application getApplicationByLAN(String lanNo);

	public ApplicationApplicant getAppApplicantByApplicantId(String applicantId);

	public LoanProduct getLoanProduct(String loantype);
	

}
