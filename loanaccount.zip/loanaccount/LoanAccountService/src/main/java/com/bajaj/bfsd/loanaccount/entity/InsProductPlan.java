package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the INS_PRODUCT_PLANS database table.
 * 
 */
@Entity
@Table(name="INS_PRODUCT_PLANS")
@NamedQuery(name="InsProductPlan.findAll", query="SELECT i FROM InsProductPlan i")
public class InsProductPlan implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long insprodplankey;

	private BigDecimal ippisactive;

	private String ipplancode;

	private String ipplandesc;

	private String ipplstupdateby;

	private Timestamp ipplstupdatedt;

	//bi-directional many-to-one association to InsuranceApplication
	@OneToMany(mappedBy="insProductPlan")
	private List<InsuranceApplication> insuranceApplications;

	//bi-directional many-to-one association to InsProductType
	@ManyToOne
	@JoinColumn(name="INSPRODTYPEKEY")
	private InsProductType insProductType;

	//bi-directional many-to-one association to InsProvider
	@ManyToOne
	@JoinColumn(name="INSPROVIDERKEY")
	private InsProvider insProvider;

	public InsProductPlan() {
	}

	public long getInsprodplankey() {
		return this.insprodplankey;
	}

	public void setInsprodplankey(long insprodplankey) {
		this.insprodplankey = insprodplankey;
	}

	public BigDecimal getIppisactive() {
		return this.ippisactive;
	}

	public void setIppisactive(BigDecimal ippisactive) {
		this.ippisactive = ippisactive;
	}

	public String getIpplancode() {
		return this.ipplancode;
	}

	public void setIpplancode(String ipplancode) {
		this.ipplancode = ipplancode;
	}

	public String getIpplandesc() {
		return this.ipplandesc;
	}

	public void setIpplandesc(String ipplandesc) {
		this.ipplandesc = ipplandesc;
	}

	public String getIpplstupdateby() {
		return this.ipplstupdateby;
	}

	public void setIpplstupdateby(String ipplstupdateby) {
		this.ipplstupdateby = ipplstupdateby;
	}

	public Timestamp getIpplstupdatedt() {
		return this.ipplstupdatedt;
	}

	public void setIpplstupdatedt(Timestamp ipplstupdatedt) {
		this.ipplstupdatedt = ipplstupdatedt;
	}

	public List<InsuranceApplication> getInsuranceApplications() {
		return this.insuranceApplications;
	}

	public void setInsuranceApplications(List<InsuranceApplication> insuranceApplications) {
		this.insuranceApplications = insuranceApplications;
	}

	public InsuranceApplication addInsuranceApplication(InsuranceApplication insuranceApplication) {
		getInsuranceApplications().add(insuranceApplication);
		insuranceApplication.setInsProductPlan(this);

		return insuranceApplication;
	}

	public InsuranceApplication removeInsuranceApplication(InsuranceApplication insuranceApplication) {
		getInsuranceApplications().remove(insuranceApplication);
		insuranceApplication.setInsProductPlan(null);

		return insuranceApplication;
	}

	public InsProductType getInsProductType() {
		return this.insProductType;
	}

	public void setInsProductType(InsProductType insProductType) {
		this.insProductType = insProductType;
	}

	public InsProvider getInsProvider() {
		return this.insProvider;
	}

	public void setInsProvider(InsProvider insProvider) {
		this.insProvider = insProvider;
	}

}