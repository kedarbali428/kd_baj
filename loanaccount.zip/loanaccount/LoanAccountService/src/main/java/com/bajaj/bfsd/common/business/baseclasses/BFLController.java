package com.bajaj.bfsd.common.business.baseclasses;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RestController;

@RefreshScope
@RestController
public abstract class BFLController { //NOSONAR
}
