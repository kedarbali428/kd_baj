package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the DOCUMENT_TYPES database table.
 * 
 */
@Entity
@Table(name="DOCUMENT_TYPES")
@NamedQuery(name="DocumentType.findAll", query="SELECT d FROM DocumentType d")
public class DocumentType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=10)
	private long doctypekey;

	@Column(nullable=false, length=50)
	private String doctypecode;

	@Column(nullable=false, length=100)
	private String doctypedesc;

	@Column(precision=1)
	private BigDecimal doctypeisactive;

	@Column(precision=1)
	private BigDecimal doctypeiscustdoc;

	@Column(precision=1)
	private BigDecimal doctypeisexpdtmand;

	@Column(precision=1)
	private BigDecimal doctypeisidnummand;

	@Column(precision=1)
	private BigDecimal doctypeisissuedauthoritymand;

	@Column(precision=1)
	private BigDecimal doctypeisissuedtmand;

	@Column(precision=1)
	private BigDecimal doctypeismanadatory;

	@Column(length=20)
	private String doctypelstupdateby;

	private Timestamp doctypelstupdatedt;

	//bi-directional many-to-one association to ApplicationDocument
	@OneToMany(mappedBy="documentType")
	private List<ApplicationDocument> applicationDocuments;

	//bi-directional many-to-one association to DocumentTypeCategory
	@OneToMany(mappedBy="documentType")
	private List<DocumentTypeCategory> documentTypeCategories;

	public DocumentType() {
		//Needed by JPA
	}

	public long getDoctypekey() {
		return this.doctypekey;
	}

	public void setDoctypekey(long doctypekey) {
		this.doctypekey = doctypekey;
	}

	public String getDoctypecode() {
		return this.doctypecode;
	}

	public void setDoctypecode(String doctypecode) {
		this.doctypecode = doctypecode;
	}

	public String getDoctypedesc() {
		return this.doctypedesc;
	}

	public void setDoctypedesc(String doctypedesc) {
		this.doctypedesc = doctypedesc;
	}

	public BigDecimal getDoctypeisactive() {
		return this.doctypeisactive;
	}

	public void setDoctypeisactive(BigDecimal doctypeisactive) {
		this.doctypeisactive = doctypeisactive;
	}

	public BigDecimal getDoctypeiscustdoc() {
		return this.doctypeiscustdoc;
	}

	public void setDoctypeiscustdoc(BigDecimal doctypeiscustdoc) {
		this.doctypeiscustdoc = doctypeiscustdoc;
	}

	public BigDecimal getDoctypeisexpdtmand() {
		return this.doctypeisexpdtmand;
	}

	public void setDoctypeisexpdtmand(BigDecimal doctypeisexpdtmand) {
		this.doctypeisexpdtmand = doctypeisexpdtmand;
	}

	public BigDecimal getDoctypeisidnummand() {
		return this.doctypeisidnummand;
	}

	public void setDoctypeisidnummand(BigDecimal doctypeisidnummand) {
		this.doctypeisidnummand = doctypeisidnummand;
	}

	public BigDecimal getDoctypeisissuedauthoritymand() {
		return this.doctypeisissuedauthoritymand;
	}

	public void setDoctypeisissuedauthoritymand(BigDecimal doctypeisissuedauthoritymand) {
		this.doctypeisissuedauthoritymand = doctypeisissuedauthoritymand;
	}

	public BigDecimal getDoctypeisissuedtmand() {
		return this.doctypeisissuedtmand;
	}

	public void setDoctypeisissuedtmand(BigDecimal doctypeisissuedtmand) {
		this.doctypeisissuedtmand = doctypeisissuedtmand;
	}

	public BigDecimal getDoctypeismanadatory() {
		return this.doctypeismanadatory;
	}

	public void setDoctypeismanadatory(BigDecimal doctypeismanadatory) {
		this.doctypeismanadatory = doctypeismanadatory;
	}

	public String getDoctypelstupdateby() {
		return this.doctypelstupdateby;
	}

	public void setDoctypelstupdateby(String doctypelstupdateby) {
		this.doctypelstupdateby = doctypelstupdateby;
	}

	public Timestamp getDoctypelstupdatedt() {
		return this.doctypelstupdatedt;
	}

	public void setDoctypelstupdatedt(Timestamp doctypelstupdatedt) {
		this.doctypelstupdatedt = doctypelstupdatedt;
	}

	public List<ApplicationDocument> getApplicationDocuments() {
		return this.applicationDocuments;
	}

	public void setApplicationDocuments(List<ApplicationDocument> applicationDocuments) {
		this.applicationDocuments = applicationDocuments;
	}

	public ApplicationDocument addApplicationDocument(ApplicationDocument applicationDocument) {
		getApplicationDocuments().add(applicationDocument);
		applicationDocument.setDocumentType(this);

		return applicationDocument;
	}

	public ApplicationDocument removeApplicationDocument(ApplicationDocument applicationDocument) {
		getApplicationDocuments().remove(applicationDocument);
		applicationDocument.setDocumentType(null);

		return applicationDocument;
	}

	public List<DocumentTypeCategory> getDocumentTypeCategories() {
		return this.documentTypeCategories;
	}

	public void setDocumentTypeCategories(List<DocumentTypeCategory> documentTypeCategories) {
		this.documentTypeCategories = documentTypeCategories;
	}

	public DocumentTypeCategory addDocumentTypeCategory(DocumentTypeCategory documentTypeCategory) {
		getDocumentTypeCategories().add(documentTypeCategory);
		documentTypeCategory.setDocumentType(this);

		return documentTypeCategory;
	}

	public DocumentTypeCategory removeDocumentTypeCategory(DocumentTypeCategory documentTypeCategory) {
		getDocumentTypeCategories().remove(documentTypeCategory);
		documentTypeCategory.setDocumentType(null);

		return documentTypeCategory;
	}

}