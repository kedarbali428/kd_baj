package com.bajaj.bfsd.loanaccount.model;

import java.util.List;

public class LoanResponse {

  private String finReference;
	
  private LoanSchedule financeSchedule;
  
  private List<Fee> fees;
  
  private List<Disbursement> disbursement;
  
  private String collateralRef;
  
  private List<Collateral> collaterals;
  
  
  private ReturnStatus returnStatus;
  
  private String returnCode;
	
  private String returnText;
 
public List<Collateral> getCollaterals() {
	return collaterals;
}

public void setCollaterals(List<Collateral> collaterals) {
	this.collaterals = collaterals;
}

public ReturnStatus getReturnStatus() {
	return returnStatus;
  }

public void setReturnStatus(ReturnStatus returnStatus) {
	this.returnStatus = returnStatus;
}

public List<Disbursement> getDisbursement() {
	return disbursement;
}

public void setDisbursement(List<Disbursement> disbursement) {
	this.disbursement = disbursement;
}

public String getCollateralRef() {
	return collateralRef;
}

public void setCollateralRef(String collateralRef) {
	this.collateralRef = collateralRef;
}

public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnText() {
		return returnText;
	}

	public void setReturnText(String returnText) {
		this.returnText = returnText;
	}

	public String getFinReference() {
		return finReference;
	}

	public void setFinReference(String finReference) {
		this.finReference = finReference;
	}

	public LoanSchedule getFinanceSchedule() {
		return financeSchedule;
	}

	public void setFinanceSchedule(LoanSchedule financeSchedule) {
		this.financeSchedule = financeSchedule;
	}

	public List<Fee> getFees() {
		return fees;
	}

	public void setFees(List<Fee> fees) {
		this.fees = fees;
	}
	
}
