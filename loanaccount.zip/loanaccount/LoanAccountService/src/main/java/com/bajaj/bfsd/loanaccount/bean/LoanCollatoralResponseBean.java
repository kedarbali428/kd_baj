package com.bajaj.bfsd.loanaccount.bean;

import java.util.List;

public class LoanCollatoralResponseBean {

	private List<LoanDetailBean> collateralLinkedLoans;

	private String returnCode;
	
	private String returnText;
	
	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnText() {
		return returnText;
	}

	public void setReturnText(String returnText) {
		this.returnText = returnText;
	}

	public List<LoanDetailBean> getCollateralLinkedLoans() {
		return collateralLinkedLoans;
	}

	public void setCollateralLinkedLoans(List<LoanDetailBean> collateralLinkedLoans) {
		this.collateralLinkedLoans = collateralLinkedLoans;
	}
	
}
