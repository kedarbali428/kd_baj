package com.bajaj.bfsd.loanaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.bajaj.bfsd.loanaccount.model.ApplicantSysCode;


/**
 * The persistent class for the APPLICANTS database table.
 * 
 */
@Entity
@Table(name="APPLICANTS")
@NamedQuery(name="Applicant.findAll", query="SELECT a FROM Applicant a")
public class Applicant implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false, precision=10)
	private long applicantkey;

	@Column(length=20)
	private String apltaadhaarcardnum;

	@Column(length=10)
	private String apltcommprefchannel;

	@Column(length=20)
	private String apltcorecusid;

	@Column(length=50)
	private String apltcustcif;

	@Temporal(TemporalType.DATE)
	private Date apltdateofbirth;

	@Column(length=10)
	private String apltempid;

	@Column(nullable=false, length=50)
	private String apltfirstname;

	@Column(precision=10)
	private BigDecimal apltgrossmthincome;

	@Column(precision=10, scale=2)
	private BigDecimal apltheight;

	@Temporal(TemporalType.DATE)
	private Date apltinactivedt;

	@Column(precision=1)
	private BigDecimal apltisactive;

	@Column(precision=1)
	private BigDecimal apltisempflag;

	@Column(length=50)
	private String apltlastname;

	@Column(length=20)
	private String apltlstupdateby;

	private Timestamp apltlstupdatedt;

	@Column(length=50)
	private String apltmiddlename;

	@Column(precision=10)
	private BigDecimal apltnetmthincome;

	@Column(length=20)
	private String apltpan;

	@Temporal(TemporalType.DATE)
	private Date apltpassportexpdt;

	@Column(length=50)
	private String apltpassportnum;

	@Column(nullable=false, length=10)
	private String apltstatus;

	@Column(nullable=false)
	private Timestamp apltstatuschgdate;

	@Column(precision=10)
	private BigDecimal aplttotalobligation;

	@Column(precision=10, scale=2)
	private BigDecimal apltweight;

	// bi-directional many-to-one association to BankMasterSysCode
	@OneToMany(mappedBy = "applicant")
	private List<ApplicantSysCode> applicantSysCodes;
	
	//bi-directional many-to-one association to ApplicationApplicant
	@OneToMany(mappedBy="applicant")
	private List<ApplicationApplicant> applicationApplicants;
		
	public Applicant() {
		//Needed by JPA
	}

	public long getApplicantkey() {
		return this.applicantkey;
	}

	public void setApplicantkey(long applicantkey) {
		this.applicantkey = applicantkey;
	}

	public String getApltaadhaarcardnum() {
		return this.apltaadhaarcardnum;
	}

	public void setApltaadhaarcardnum(String apltaadhaarcardnum) {
		this.apltaadhaarcardnum = apltaadhaarcardnum;
	}

	public String getApltcommprefchannel() {
		return this.apltcommprefchannel;
	}

	public void setApltcommprefchannel(String apltcommprefchannel) {
		this.apltcommprefchannel = apltcommprefchannel;
	}

	public String getApltcorecusid() {
		return this.apltcorecusid;
	}

	public void setApltcorecusid(String apltcorecusid) {
		this.apltcorecusid = apltcorecusid;
	}

	public String getApltcustcif() {
		return this.apltcustcif;
	}

	public void setApltcustcif(String apltcustcif) {
		this.apltcustcif = apltcustcif;
	}

	public Date getApltdateofbirth() {
		return this.apltdateofbirth;
	}

	public void setApltdateofbirth(Date apltdateofbirth) {
		this.apltdateofbirth = apltdateofbirth;
	}

	public String getApltempid() {
		return this.apltempid;
	}

	public void setApltempid(String apltempid) {
		this.apltempid = apltempid;
	}

	public String getApltfirstname() {
		return this.apltfirstname;
	}

	public void setApltfirstname(String apltfirstname) {
		this.apltfirstname = apltfirstname;
	}

	public BigDecimal getApltgrossmthincome() {
		return this.apltgrossmthincome;
	}

	public void setApltgrossmthincome(BigDecimal apltgrossmthincome) {
		this.apltgrossmthincome = apltgrossmthincome;
	}

	public BigDecimal getApltheight() {
		return this.apltheight;
	}

	public void setApltheight(BigDecimal apltheight) {
		this.apltheight = apltheight;
	}

	public Date getApltinactivedt() {
		return this.apltinactivedt;
	}

	public void setApltinactivedt(Date apltinactivedt) {
		this.apltinactivedt = apltinactivedt;
	}

	public BigDecimal getApltisactive() {
		return this.apltisactive;
	}

	public void setApltisactive(BigDecimal apltisactive) {
		this.apltisactive = apltisactive;
	}

	public BigDecimal getApltisempflag() {
		return this.apltisempflag;
	}

	public void setApltisempflag(BigDecimal apltisempflag) {
		this.apltisempflag = apltisempflag;
	}

	public String getApltlastname() {
		return this.apltlastname;
	}

	public void setApltlastname(String apltlastname) {
		this.apltlastname = apltlastname;
	}

	public String getApltlstupdateby() {
		return this.apltlstupdateby;
	}

	public void setApltlstupdateby(String apltlstupdateby) {
		this.apltlstupdateby = apltlstupdateby;
	}

	public Timestamp getApltlstupdatedt() {
		return this.apltlstupdatedt;
	}

	public void setApltlstupdatedt(Timestamp apltlstupdatedt) {
		this.apltlstupdatedt = apltlstupdatedt;
	}

	public String getApltmiddlename() {
		return this.apltmiddlename;
	}

	public void setApltmiddlename(String apltmiddlename) {
		this.apltmiddlename = apltmiddlename;
	}

	public BigDecimal getApltnetmthincome() {
		return this.apltnetmthincome;
	}

	public void setApltnetmthincome(BigDecimal apltnetmthincome) {
		this.apltnetmthincome = apltnetmthincome;
	}

	public String getApltpan() {
		return this.apltpan;
	}

	public void setApltpan(String apltpan) {
		this.apltpan = apltpan;
	}

	public Date getApltpassportexpdt() {
		return this.apltpassportexpdt;
	}

	public void setApltpassportexpdt(Date apltpassportexpdt) {
		this.apltpassportexpdt = apltpassportexpdt;
	}

	public String getApltpassportnum() {
		return this.apltpassportnum;
	}

	public void setApltpassportnum(String apltpassportnum) {
		this.apltpassportnum = apltpassportnum;
	}

	public String getApltstatus() {
		return this.apltstatus;
	}

	public void setApltstatus(String apltstatus) {
		this.apltstatus = apltstatus;
	}

	public Timestamp getApltstatuschgdate() {
		return this.apltstatuschgdate;
	}

	public void setApltstatuschgdate(Timestamp apltstatuschgdate) {
		this.apltstatuschgdate = apltstatuschgdate;
	}

	public BigDecimal getAplttotalobligation() {
		return this.aplttotalobligation;
	}

	public void setAplttotalobligation(BigDecimal aplttotalobligation) {
		this.aplttotalobligation = aplttotalobligation;
	}

	public BigDecimal getApltweight() {
		return this.apltweight;
	}

	public void setApltweight(BigDecimal apltweight) {
		this.apltweight = apltweight;
	}

	public List<ApplicantSysCode> getApplicantSysCodes() {
		return applicantSysCodes;
	}

	public void setApplicantSysCodes(List<ApplicantSysCode> applicantSysCodes) {
		this.applicantSysCodes = applicantSysCodes;
	}

	/**
	 * @return the applicationApplicants
	 */
	public List<ApplicationApplicant> getApplicationApplicants() {
		return applicationApplicants;
	}

	/**
	 * @param applicationApplicants the applicationApplicants to set
	 */
	public void setApplicationApplicants(List<ApplicationApplicant> applicationApplicants) {
		this.applicationApplicants = applicationApplicants;
	}
	
	

}